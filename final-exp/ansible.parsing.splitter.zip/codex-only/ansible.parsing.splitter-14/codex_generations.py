

# Generated at 2022-06-23 05:00:58.999453
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a', 'b\n', 'c']) == 'a\nb\nc'
    assert join_args(['a', ' b\n', 'c']) == 'a b\nc'
    assert join_args(['a', '\n', 'b c']) == 'a\nb c'
    assert join_args(['a', '\nb\n', 'c\nd']) == 'a\nb\nc\nd'
    assert join_args(['a', '\n', 'b\n', 'c']) == 'a\nb\nc'


# Generated at 2022-06-23 05:01:08.182209
# Unit test for function split_args
def test_split_args():
    # Test for a list with quoted strings in it
    test1 = ['var=test', '"spaced var"']
    print("Testing split_args on " + str(test1))
    result1 = split_args("var=test \"spaced var\"")
    assert(result1 == test1)

    # Test for a list with nested quoted strings in it
    test2 = ['var=test', '"spaced var with a \\"quote\\" inside"']
    print("Testing split_args on " + str(test2))
    result2 = split_args("var=test \"spaced var with a \\\"quote\\\" inside\"")
    assert(result2 == test2)

    # Test for a list with nested quoted strings with escaped whitespace in it

# Generated at 2022-06-23 05:01:18.091077
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', '\\', '\\', 'b']) == 'a \\\\ b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', '\n', 'b']) == 'a\nb'
    assert join_args(['a\n', 'b', '\n', 'c']) == 'a\nb\nc'



# Generated at 2022-06-23 05:01:25.631038
# Unit test for function join_args
def test_join_args():
    x = ['abcd', 'efghij', '\n', '\n', 'klmn\n']
    y = 'abcd efghij \n \n klmn\n'
    assert join_args(x) == y

    x = ['abcd', 'efghij', '\n', 'klmn\n', 'qrstuvw\n']
    y = 'abcd efghij \n klmn\n qrstuvw\n'
    assert join_args(x) == y



# Generated at 2022-06-23 05:01:33.939408
# Unit test for function split_args
def test_split_args():
    '''
    Tests that the split works properly.
    '''

# Generated at 2022-06-23 05:01:44.196024
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv('k1=v1 k2=v2') == {'k1':'v1','k2':'v2'}
  assert parse_kv('k=v') == {'k':'v'}
  assert parse_kv('k="v"') == {'k':'"v"'}
  assert parse_kv('k=(v)') == {'k':'(v)'}
  assert parse_kv('k="v foo bar baz"') == {'k':'"v foo bar baz"'}
  assert parse_kv('k="$foo"') == {'k':'"$foo"'}
  assert parse_kv('k="$(foo)"') == {'k':'"$(foo)"'}
  assert parse_kv('k="v1 v2"')

# Generated at 2022-06-23 05:01:54.437581
# Unit test for function split_args

# Generated at 2022-06-23 05:02:00.754051
# Unit test for function parse_kv
def test_parse_kv():
  args = "key1=value1 key2=value2 \"key3='value3'"
  print(parse_kv(args))

if __name__ == "__main__":
  test_parse_kv()

# Generated at 2022-06-23 05:02:07.648771
# Unit test for function parse_kv
def test_parse_kv():
    assert {'4': '4', '_raw_params': '2 3', '2': '2', '1': '1'} == parse_kv('1=1 2 3 4=4')
    assert {'_raw_params': '-p 14', 'p': '14'} == parse_kv('-p=14')
    assert {'_raw_params': '  -p 14', 'p': '14'} == parse_kv('  -p=14')


# Generated at 2022-06-23 05:02:12.003179
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '3']) == '1 2 3'
    assert join_args(['1', '2', '3\n']) == '1 2 3\n'


# Generated at 2022-06-23 05:02:23.392907
# Unit test for function join_args
def test_join_args():
    # Case 1:
    # Return True if split_args(join_args(x)) == x
    #   for every argument x
    #
    # Case 2:
    # Return True if join_args(x) == x
    #   for every argument x
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing import split_args
    import random
    import re

    def ansi_escape(text):
        '''
        Removes ANSI escape characters from a string.
        '''
        ansi_escape = re.compile(r'(\x9B|\x1B\[)[0-?]*[ -/]*[@-~]')
        return ansi_escape.sub('', text)


# Generated at 2022-06-23 05:02:33.288301
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1,b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1,b='2'") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1,b=\"2\"") == {'a': '1', 'b': '2'}
    assert parse_kv("a='1,2,3',b=2") == {'a': '1,2,3', 'b': '2'}
    assert parse_kv("a=\"1,2,3\",b=2") == {'a': '1,2,3', 'b': '2'}

# Generated at 2022-06-23 05:02:42.750583
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c=d e= f=g') == {'a': 'b', 'c': 'd', 'e': '', 'f': 'g'}
    assert parse_kv('a=b c="d e" f="gh" e= f=g') == {'a': 'b', 'c': 'd e', 'f': 'gh', 'e': '', '_raw_params': 'f=g'}

# Generated at 2022-06-23 05:02:53.419358
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'a', 'b', 'c']) == 'echo a b c'
    assert join_args(['echo', 'a\nb\nc']) == "echo a\nb\nc"
    assert join_args(['echo', 'a', '\nb', 'c']) == 'echo a \nb c'
    assert join_args(['echo', 'a', '\nb\n', 'c']) == 'echo a \nb\n c'
    assert join_args(['echo', 'a', '"b c"']) == 'echo a "b c"'
    assert join_args(['echo', 'a', '\nb', '"c\nd"']) == 'echo a \nb "c\nd"'

# Generated at 2022-06-23 05:03:05.293986
# Unit test for function join_args
def test_join_args():
    def _simple_assert(a, b):
        assert join_args(split_args(a)) == b
    _simple_assert('a', 'a')
    _simple_assert('a b', 'a b')
    _simple_assert('a b c', 'a b c')
    _simple_assert('a\n b\nc', 'a\n b\nc')
    _simple_assert('a\n\nb', 'a\n\nb')
    _simple_assert('a b\nc', 'a b\nc')
    _simple_assert('a\n b c', 'a\n b c')
    _simple_assert('a b c\nd e f', 'a b c\nd e f')
    _simple_assert('a \'b c\'', 'a \'b c\'')
    _simple_assert

# Generated at 2022-06-23 05:03:20.352826
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('dst=/tmp/test src=/etc/hosts') == dict(dst='/tmp/test', src='/etc/hosts')
    assert parse_kv('dst="/tmp/test" src="/etc/hosts"') == dict(dst='/tmp/test', src='/etc/hosts')
    assert parse_kv('dst=/tmp/test src="/etc/hosts"') == dict(dst='/tmp/test', src='/etc/hosts')
    assert parse_kv("""dst=/tmp/test src="/etc/hosts" """) == dict(dst='/tmp/test', src='/etc/hosts')

# Generated at 2022-06-23 05:03:27.837404
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b x=y') == {u'a': u'b', u'x': u'y'}
    assert parse_kv(u"a='b c' x=y") == {u'a': u'b c', u'x': u'y'}
    assert parse_kv(u"a='b c' x='y z'") == {u'a': u'b c', u'x': u'y z'}
    assert parse_kv(None) == {}
    assert parse_kv(u"a='b c' x='y z'", check_raw=True) == {u'a': u'b c', u'x': u'y z'}

# Generated at 2022-06-23 05:03:35.976670
# Unit test for function split_args
def test_split_args():
    '''
    Tests for function split_args()
    '''

    # test_arguments is an array of arrays that contains the
    # input string (args[0]), the return value that is expected
    # (args[1]), and the error message to print if they don't match

# Generated at 2022-06-23 05:03:43.941744
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a ', 'b']) == 'a  b'
    assert join_args(['a', ' b']) == 'a  b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a\n b']) == 'a\n b'
    assert join_args(['a\n', 'b']) == 'a\n b'



# Generated at 2022-06-23 05:03:49.674848
# Unit test for function parse_kv
def test_parse_kv():
    test_var = parse_kv("name=foo value=\"\\\"bar\\\" baz\"")
    assert test_var == {"name": "foo", "value": '"bar" baz'}



# Generated at 2022-06-23 05:03:59.449140
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', '  bar ', 'baz   ']) == 'foo   bar  baz   '
    assert join_args(['foo', 'bar', '\nbaz']) == 'foo bar\n baz'
    assert join_args(['foo', 'bar', '\nbaz', '\nfoo']) == 'foo bar\n baz\n foo'
    assert join_args(['foo', 'bar', '\nbaz', '\nfoo', 'bar']) == 'foo bar\n baz\n foo bar'

# Generated at 2022-06-23 05:04:06.672789
# Unit test for function split_args

# Generated at 2022-06-23 05:04:17.334976
# Unit test for function join_args

# Generated at 2022-06-23 05:04:28.212394
# Unit test for function parse_kv
def test_parse_kv():
    assert {'one': 'two', 'three': 'four', 'five': 'six', 'seven': 'eight'} == parse_kv('one=two three=four five=six seven=eight')
    assert {'one': 'two', '_raw_params': 'three=four five six seven=eight'} == parse_kv('one=two three=four five six seven=eight', True)
    assert {'_raw_params': 'one=two three=four five six seven=eight'} == parse_kv('one=two three=four five six seven=eight')
    assert {} == parse_kv('')
    assert {'one': '"two three"', 'five': 'six'} == parse_kv('one="two three" five=six')

# Generated at 2022-06-23 05:04:34.981137
# Unit test for function split_args

# Generated at 2022-06-23 05:04:44.104086
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('arg1 arg2 arg3 arg4') == {}
    assert parse_kv('arg1="arg1 value" arg2="arg2 value"') == {u'arg1': u'arg1 value', u'arg2': u'arg2 value'}
    assert parse_kv('arg1="arg1 value" arg2="arg2 value" arg3 arg4') == {u'_raw_params': u'arg3 arg4', u'arg1': u'arg1 value', u'arg2': u'arg2 value'}
    assert parse_kv('arg1=arg1\\ value arg2=arg2\\ value') == {u'arg1': u'arg1 value', u'arg2': u'arg2 value'}

# Generated at 2022-06-23 05:04:55.485815
# Unit test for function split_args
def test_split_args():
    assert split_args(u"a=1 b=2") == ["a=1", "b=2"]
    assert split_args(u"a=1       b=2") == ["a=1", "b=2"]
    assert split_args(u"a=1       b=2   ") == ["a=1", "b=2"]
    assert split_args(u"a=1\nb=2") == ["a=1", "b=2"]
    assert split_args(u"a=1 b=2  c=3\nd=4") == ["a=1", "b=2", "c=3", "d=4"]

# Generated at 2022-06-23 05:05:07.082503
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '2', '3']) == '1 2 3'
    assert join_args(['1 ', '2', ' 3']) == '1  2  3'
    assert join_args(['1', '\n', '2', '\n', ' 3']) == '1\n2\n 3'
    assert join_args(['1', '\n', '\n', '2', '\n', ' 3']) == '1\n\n2\n 3'
    assert join_args(['1', '2', '\n', '3']) == '1 2\n3'
    assert join_args(['1', '2', '3', '\n']) == '1 2 3\n'

# Generated at 2022-06-23 05:05:17.995910
# Unit test for function split_args

# Generated at 2022-06-23 05:05:31.160853
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import Mapping
    assert isinstance(parse_kv("a=very=long=option"), Mapping)
    # FIXME: Find out why the following cases fails
    #assert isinstance(parse_kv("a=very=long=option"), dict)
    #assert isinstance(parse_kv("a=very=long=option"), collections.Mapping)
    parse_kv("a=very=long=option")

    # FIXME: Find out why the following cases fails
    #assert isinstance(parse_kv(u"a=very=long=option"), dict)
    #assert isinstance(parse_kv(u"a=very=long=option"), collections.Mapping)
    parse_kv(u"a=very=long=option")

   

# Generated at 2022-06-23 05:05:42.284721
# Unit test for function parse_kv
def test_parse_kv():
    assert {'arg1': 'foo', 'arg2': 'bar'} == parse_kv('arg1=foo arg2=bar')
    assert {'arg1': 'foo bar', 'arg2': 'bar'} == parse_kv('arg1="foo bar" arg2=bar')
    assert {'arg1': 'foo', 'arg2': 'bar'} == parse_kv("arg1='foo' arg2=bar")
    assert {'arg1': 'foo bar', 'arg2': 'bar'} == parse_kv("arg1='foo bar' arg2=bar")
    assert {'arg1': 'foo', 'arg2': 'bar'} == parse_kv("arg1=foo arg2='bar'")
    assert {'arg1': 'foo bar', 'arg2': 'bar'} == parse

# Generated at 2022-06-23 05:05:52.376009
# Unit test for function join_args
def test_join_args():
    assert join_args(['command', 'arg1']) == 'command arg1'
    assert join_args(['command', 'arg1', 'arg2', 'arg3']) == 'command arg1 arg2 arg3'
    assert join_args(['command', 'arg1\narg2', 'arg3']) == 'command arg1\narg2 arg3'
    assert join_args(['command', 'arg1', 'arg2\narg3']) == 'command arg1 arg2\narg3'
    assert join_args(['command arg1', 'arg2']) == 'command arg1 arg2'
    assert join_args(['command arg1', 'arg2\narg3']) == 'command arg1 arg2\narg3'

# Generated at 2022-06-23 05:06:02.515979
# Unit test for function parse_kv
def test_parse_kv():
    assert {'foo': 'bar', 'one': '2', u'_raw_params': 'one=2 "3 4" \'5 6\'   7'} == parse_kv(u'foo=bar one=2 "3 4" \'5 6\'   7')
    assert {'foo': 'bar', 'one': '2', u'_raw_params': 'one=2 "3 4" \'5 6\'   7'} == parse_kv(u"foo='bar' one=2 \"3 4\" '5 6'   7")
    assert {'foo': 'bar', 'one': '2', u'_raw_params': 'one=2 "3 4" \'5 6\'   7'} == parse_kv(u'foo="bar" one=2 "3 4" \'5 6\'   7')

# Generated at 2022-06-23 05:06:10.747249
# Unit test for function join_args
def test_join_args():
    starting_string = '''
    hello world
    "hello
    world"
    "hello \\"world\\"
    hello world"
    '''
    result = ['hello', 'world', 'hello\nworld',
              'hello "world\nhello world']
    assert join_args(result) == starting_string

# Splits tokens as a shell would, respecting spaces,
# quotes, double-quotes, backslashes and jinja2 blocks.

# Generated at 2022-06-23 05:06:21.228950
# Unit test for function join_args

# Generated at 2022-06-23 05:06:32.762403
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule

    import os
    import sys
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path
    sys.path.append("/home/drew/ansible/module_utils")
    import custom_script_module


# Generated at 2022-06-23 05:06:44.656708
# Unit test for function parse_kv

# Generated at 2022-06-23 05:06:56.410304
# Unit test for function join_args
def test_join_args():
    s = '''
    /bin/mkdir -p /tmp/{{ ansible_hostname }}/
    chdir=/tmp/{{ ansible_hostname }}/
    umask=022
    \n'''
    assert join_args(split_args(s)) == s

# Generated at 2022-06-23 05:07:05.066494
# Unit test for function join_args
def test_join_args():
    assert join_args(['\n', 'ansible-playbook', '--help']) == '\nansible-playbook --help'
    assert join_args(['\n', 'ansible-playbook', '--help\n', 'more', '--options']) == '\nansible-playbook --help\nmore --options'
    assert join_args(['\n', 'ansible-playbook', '"--help\nmore"', '--options']) == '\nansible-playbook "--help\nmore" --options'
    assert join_args(['\n', 'ansible-playbook', '"--help\\nmore"', '--options']) == '\nansible-playbook "--help\\nmore" --options'

# Generated at 2022-06-23 05:07:15.156262
# Unit test for function split_args
def test_split_args():
    print(split_args('a=b c="foo bar"'))
    print(split_args('a=b c="foo \\\'bar\'"'))
    print(split_args('a=b c="foo \\\'bar\\\'"'))
    print(split_args('a=b c=foo bar'))
    print(split_args('a=b c=foo \\ bar'))
    print(split_args('a=b c=python -m foo --bar \\'))
    print(split_args('a=b c=python -m foo --bar \\'))
    print(split_args('a=b c="foo bar\\'))

# Generated at 2022-06-23 05:07:22.360994
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'hello', 'world']) == 'echo hello world'
    assert join_args(['echo', '\nhello', 'world']) == 'echo\nhello world'
    assert join_args(['echo', '\n', 'hello', 'world']) == 'echo\nhello world'
    assert join_args(['echo', 'hello\n', 'world']) == 'echo hello\nworld'
    assert join_args(['echo', 'hello\nworld']) == 'echo hello\nworld'



# Generated at 2022-06-23 05:07:33.814797
# Unit test for function parse_kv
def test_parse_kv():
    # Check if dict is created
    assert(parse_kv('a=b c=d e=f') == {'a': 'b', 'c': 'd', 'e': 'f'})
    # Check if key-value pair is stored correctly if only whitespace is found
    assert(parse_kv(' a = b = c = d') == {'a': 'b = c = d'})
    # Check if multiple key-value pairs are stored correctly if only whitespace is found
    assert(parse_kv(' a = b = c = d e = f') == {'a': 'b = c = d', 'e': 'f'})
    # Check if single item is stored correctly if no equals sign is found
    assert(parse_kv('a') == {})
    # Check if multiple items are stored correctly if no equals sign is found

# Generated at 2022-06-23 05:07:43.771541
# Unit test for function join_args
def test_join_args():
    assert u'ls -l' == join_args([u'ls', u'-l'])
    assert u'ls -l' == join_args([u'ls', u'-l'])
    assert u'ls -l' == join_args([u'ls', u'-l'])
    assert u'ls -l -a' == join_args([u'ls', u'-l', u'-a'])
    assert u'ls -l -a -b' == join_args([u'ls', u'-l', u'-a', u'-b'])
    assert u'ls -l -a\n-b' == join_args([u'ls', u'-l', u'-a', u'-b'])


# Generated at 2022-06-23 05:07:54.564692
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv(u'') == {}
    assert parse_kv(u'a') == {}
    assert parse_kv(u'a=') == {u'a': u''}
    assert parse_kv(u'a=b') == {u'a': u'b'}
    assert parse_kv(u'a=b c') == {u'a': u'b c'}
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}

    assert parse_kv(u'a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-23 05:07:57.624160
# Unit test for function join_args
def test_join_args():
    assert 'echo "foo! bar" \\\n  baz' == join_args(['echo', '"foo! bar"', '\\', '\n', 'baz'])



# Generated at 2022-06-23 05:08:04.576716
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {'a': u'1', 'b': u'2', 'c': u'3'}
    assert parse_kv("a=1 b=2 c='3'") == {'a': u'1', 'b': u'2', 'c': u"3"}
    assert parse_kv("a=1 b=2 c='3 3'") == {'a': u'1', 'b': u'2', 'c': u"3 3"}
    assert parse_kv("a='a b' c='3 3'") == {'a': u'a b', 'c': u"3 3"}

# Generated at 2022-06-23 05:08:16.022240
# Unit test for function join_args
def test_join_args():
    test_list_a = ['echo', '-e', '  "foo \nbar \nbat"']
    joined_a = join_args(test_list_a)
    assert(joined_a == 'echo -e   "foo \nbar \nbat"')
    test_list_b = ['echo', '-e', '"foo \nbar \nbat"']
    joined_b = join_args(test_list_b)
    assert(joined_b == 'echo -e"foo \nbar \nbat"')
    test_list_c = ['echo', '-e', '\\ "foo \nbar \nbat"']
    joined_c = join_args(test_list_c)
    assert(joined_c == 'echo -e \\ "foo \nbar \nbat"')
    test_

# Generated at 2022-06-23 05:08:24.564149
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("foo=bar baz=qux")
    assert (options['foo'] == 'bar')
    assert (options['baz'] == 'qux')

    # test simple variable expansion
    options = parse_kv("cmd='{{foo}}'")
    assert (options['cmd'] == '{{foo}}')

    # test escaped variable expansion
    options = parse_kv("cmd='\\{{foo}}'")
    assert (options['cmd'] == '{{foo}}')

    # test escaped values
    options = parse_kv("cmd='\\\n'")
    assert (options['cmd'] == '\n')

    # test escaped values
    options = parse_kv("cmd='\\\\n'")
    assert (options['cmd'] == '\\n')

    # test escaped non-ascii
   

# Generated at 2022-06-23 05:08:32.722902
# Unit test for function parse_kv
def test_parse_kv():
    def parse_and_check(s, expected, check_raw=True):
        result = parse_kv(s, check_raw=check_raw)
        assert result == expected, 'Parsing string "%s" failed, got %s instead of %s' % (s, result, expected)

    assert parse_kv('', {}) == {}
    assert len(parse_kv("x=1 y=2 z=3")) == 3
    assert parse_kv("x=1 y=2 z=3")['x'] == u'1'
    assert parse_kv("x=1 y=2 z=3")['y'] == u'2'
    assert parse_kv("x=1 y=2 z=3")['z'] == u'3'

# Generated at 2022-06-23 05:08:36.943754
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '1', '\n', 'echo', '2']) == 'echo 1\necho 2'
# End unit test for function join_args


# NOTE: This code is based on python3's shlex.split w/o the posix option

# Generated at 2022-06-23 05:08:44.346465
# Unit test for function join_args
def test_join_args():
    # empty list
    assert join_args([]) == ''
    # one item
    assert join_args(['foo']) == 'foo'
    # one item with spaces
    assert join_args(['foo bar']) == 'foo bar'
    # two items separated by space
    assert join_args(['foo', 'bar']) == 'foo bar'
    # two items separated by newline
    assert join_args(['foo\n', 'bar']) == 'foo\nbar'
    # two items separated by tab
    assert join_args(['foo\t', 'bar']) == 'foo\tbar'



# Generated at 2022-06-23 05:08:53.137555
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('''a=b c=d
                        e='f g'
                        h="i j"''') == {u'a': u'b', u'c': u'd', u'e': u'f g', u'h': u'i j'}

    assert parse_kv('a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'a=b c=d'}

# Generated at 2022-06-23 05:09:04.146774
# Unit test for function split_args

# Generated at 2022-06-23 05:09:09.736369
# Unit test for function join_args
def test_join_args():
    print("test_join_args:", end=" ")
    tokens = split_args('a b "c d"\ne f')
    result = join_args(tokens)
    if result == 'a b "c d"\ne f':
        print("OK")
    else:
        print("FAILED: '%s'" % result)
#end


# Generated at 2022-06-23 05:09:17.431242
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == "foo bar"
    assert join_args(['foo', 'bar', 'baz']) == "foo bar baz"
    assert join_args(['foo', 'bar', 'baz', '\n', 'blam', '\n', '  ', '-e', 'A=1']) == "foo bar baz\nblam\n  -e A=1"



# Generated at 2022-06-23 05:09:27.150835
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', 'b\n']) == 'a b\n'
    assert join_args(['a\n', 'b\n']) == 'a\nb\n'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a', 'b', 'c\n']) == 'a b c\n'

# Generated at 2022-06-23 05:09:36.322351
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': '1', u'b': '2'}
    assert parse_kv("a=1 b='2'") == {u'a': '1', u'b': '2'}
    assert parse_kv("a=1 b=\"2\"") == {u'a': '1', u'b': '2'}
    assert parse_kv("a=1 b=\"2 3 4\"") == {u'a': '1', u'b': '2 3 4'}
    assert parse_kv("a=1 b='2 3 4'") == {u'a': '1', u'b': '2 3 4'}

# Generated at 2022-06-23 05:09:47.402202
# Unit test for function split_args
def test_split_args():
    assert ['a=b', 'c="foo bar"'] == split_args('a=b c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\nc="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b \nc="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b \n c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b \n\n c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b   \n\n c="foo bar"')

# Generated at 2022-06-23 05:09:58.208980
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'foo bar']) == 'echo foo bar'
    assert join_args(['echo', 'foo\nbar']) == 'echo foo\nbar'
    assert join_args(['echo', 'foo\n\nbar']) == 'echo foo\n\nbar'
    assert join_args(['echo', 'foo\n\nbar\n']) == 'echo foo\n\nbar\n'
    assert join_args(['echo', 'foo', 'bar']) == 'echo foo bar'
    assert join_args(['echo', 'foo', 'bar\n']) == 'echo foo bar\n'
    assert join_args(['echo', 'foo\n\nbar', 'baz']) == 'echo foo\n\nbar baz'

# Generated at 2022-06-23 05:10:08.364524
# Unit test for function join_args
def test_join_args():
    teststr = '''mkdir [ -p "{{ vcenter_datacenter_folder }}" ]\n\
                 mkdir -p "{{ vcenter_host_folder }}"\n\
                 mkdir -p "{{ vcenter_vm_folder }}"\n\
                 mkdir -p "{{ vcenter_template_folder }}"
              '''

    s = split_args(teststr)
    result = join_args(s)
    assert result == teststr


# Generated at 2022-06-23 05:10:18.439314
# Unit test for function join_args
def test_join_args():
    # test one simple case
    # if [ -e /some/where ]
    #     ^     ^
    assert join_args(['if', '[', '-e', '/some/where', ']']) == 'if [ -e /some/where ]'

    # test one simple case with newline
    # if [ -e /some/where ]
    # then
    #    ^  ^^
    assert join_args(['if', '[', '-e', '/some/where', ']', '\nthen']) == 'if [ -e /some/where ]\nthen'

    # test a more complex case
    # if [ -e /some/where ] && `echo "this is a $(echo "complex") command"`
    #     ^     ^              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

# Generated at 2022-06-23 05:10:22.375129
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\n', 'bar']) == 'foo\nbar'



# Generated at 2022-06-23 05:10:26.846807
# Unit test for function join_args
def test_join_args():
    test_string = """\
  cmd1 = /usr/bin/test
  cmd2 = /usr/bin/test
  cmd3 = /usr/bin/test"""
    # re-parse
    result = join_args(test_string.split('\n'))
    assert test_string == result



# Generated at 2022-06-23 05:10:38.611585
# Unit test for function join_args
def test_join_args():
    '''
    test function: join_args - join the original cmd based on manipulations by split_args(),
    this retains the original newlines and whitespaces.
    '''
    # pylint: disable=missing-docstring
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb']) == 'a\nb'
    assert join_args(['a ', ' b']) == 'a  b'
    assert join_args(['\na']) == '\na'
    assert join_args(['\n', 'a']) == '\n a'
    assert join_args(['']) == ''
    assert join_args(['a', '', 'b']) == 'a  b'



# Generated at 2022-06-23 05:10:44.174649
# Unit test for function join_args
def test_join_args():
    s = ['foo', 'bar', '\nbaz']
    exp_res = 'foo bar\nbaz'
    res = join_args(s)
    assert(exp_res == res)

    s = ['foo', 'bar', '\n', 'baz']
    exp_res = 'foo bar\n baz'
    res = join_args(s)
    assert(exp_res == res)



# Generated at 2022-06-23 05:10:50.290154
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', 'b']) == 'a b')
    assert(join_args(['a', '\nb']) == 'a \nb')
    assert(join_args(['a', 'b', '\nc']) == 'a b \nc')
    assert(join_args(['a\n', 'b', 'c']) == 'a\n b c')

