

# Generated at 2022-06-23 05:00:59.167020
# Unit test for function split_args

# Generated at 2022-06-23 05:01:11.059684
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k0=v0 k1=v1') == {'k0': 'v0', 'k1': 'v1'}
    assert parse_kv('k0=v0 k1=') == {'k0': 'v0', 'k1': ''}
    assert parse_kv(' k0 = v0  ') == {'k0': 'v0'}
    assert parse_kv('') == {}
    assert parse_kv(' ') == {}
    assert parse_kv('=') == {}
    assert parse_kv(' = ') == {}
    assert parse_kv(' = x ') == {'_raw_params': ' = x '}

# Generated at 2022-06-23 05:01:20.887446
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a b', 'c', 'd']) == 'a b c d'
    assert join_args(['\na b', 'c', 'd']) == '\na b c d'
    assert join_args(['\na\nb', 'c', 'd']) == '\na\nb c d'
    assert join_args(['a\nb', 'c', 'd']) == 'a\nb c d'
    assert join_args(['\n', 'a\nb', 'c', 'd']) == '\n a\nb c d'
    assert join_args([]) == ''



# Generated at 2022-06-23 05:01:29.906185
# Unit test for function join_args
def test_join_args():
    '''
    Test case for function test_join_args

    '''
    # Test 1: Empty list
    assert join_args([]) == ''
    # Test 2: List with 1 element
    assert join_args(['a']) == 'a'
    # Test 3: List with 3 elements
    assert join_args(['a', 'b', 'c']) == 'a b c'
    # Test 4: List with 3 elements with one new line character
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    # Test 5: List with 3 elements with two new line character
    assert join_args(['a', '\nb', '\nc']) == 'a\nb\nc'



# Generated at 2022-06-23 05:01:39.120589
# Unit test for function split_args
def test_split_args():
    data = []
    data.append(dict(
        args='foo bar',
        expected=['foo bar'],
    ))
    data.append(dict(
        args='foo "bar"',
        expected=['foo "bar"'],
    ))
    data.append(dict(
        args='foo "bar baz"',
        expected=['foo "bar baz"'],
    ))
    data.append(dict(
        args='foo "bar \'baz"',
        expected=['foo "bar \'baz"'],
    ))
    data.append(dict(
        args='foo "bar" \'baz',
        expected=['foo "bar" \'baz'],
    ))


# Generated at 2022-06-23 05:01:47.925085
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k1=v1  k2=v2') == {'k1': 'v1', 'k2': 'v2'}
    assert parse_kv('k1=v1  k2= v2') == {'k1': 'v1', 'k2': 'v2'}
    assert parse_kv('k1=v1  k2 = v2') == {'k1': 'v1', 'k2': 'v2'}
    assert parse_kv('k1=v1  k2 =v2') == {'k1': 'v1', 'k2': 'v2'}
    assert parse_kv('k1=v1  k2 = "2 spaces"') == {'k1': 'v1', 'k2': '2 spaces'}

# Generated at 2022-06-23 05:01:56.395906
# Unit test for function parse_kv
def test_parse_kv():
    dict1 = parse_kv('a=b b=c')
    assert dict1['a'] == 'b'
    assert dict1['b'] == 'c'
    dict2 = parse_kv('a=b c=d')
    assert dict2['a'] == 'b'
    assert dict2['c'] == 'd'
    dict3 = parse_kv('a=b c=d')
    assert dict3['a'] == 'b'
    assert dict3['c'] == 'd'

    dict4 = parse_kv('a=b c=d')
    assert dict4['a'] == 'b'
    assert dict4['c'] == 'd'

    dict5 = parse_kv('a=b c=d b=c')
    assert dict5['a'] == 'b'
    assert dict

# Generated at 2022-06-23 05:02:10.479582
# Unit test for function parse_kv
def test_parse_kv():
    import json
    # Single key value
    data = "key=value"
    expect = {"key":"value"}
    actual = parse_kv(data)
    assert(expect == actual)

    # Double key value
    data = "key=value other_key=other_value"
    expect = {"key":"value", "other_key":"other_value"}
    actual = parse_kv(data)
    assert(expect == actual)

    # Single key value but key is empty
    data = "=value"
    expect = {}
    actual = parse_kv(data)
    assert(expect == actual)

    # Single key value but value is empty
    data = "key="
    expect = {"key":""}
    actual = parse_kv(data)
    assert(expect == actual)

    # Single

# Generated at 2022-06-23 05:02:15.521059
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['token']) == 'token'
    assert join_args(['token1', 'token2']) == 'token1 token2'
    assert join_args(['token1\n', 'token2']) == 'token1\n token2'



# Generated at 2022-06-23 05:02:25.719721
# Unit test for function split_args
def test_split_args():
    '''
    unit test for function split_args
    '''

# Generated at 2022-06-23 05:02:32.113908
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['first\n', 'middle', 'last']) == 'first\n middle last'
    assert join_args(['first', 'middle\n', 'last\n']) == 'first middle\n last\n'
    assert join_args(['first\n', 'middle\n', 'last']) == 'first\n middle\n last'




# Generated at 2022-06-23 05:02:42.605408
# Unit test for function join_args
def test_join_args():
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', '\\=c']) == 'a b \\=c'
    assert join_args(['a', 'b', 'c', 'd']) == 'a b c d'
    assert join_args(['a', 'b', '\\=c', 'd']) == 'a b \\=c d'
    assert join_args(['a', 'b', '\\=c', '\\=d']) == 'a b \\=c \\=d'
    assert join_args(['a', 'b', '\\=c', '\\=d', 'e']) == 'a b \\=c \\=d e'

# Generated at 2022-06-23 05:02:53.296754
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == dict(foo='bar', baz='qux')
    assert parse_kv(r'foo="hello world" baz=qux') == dict(foo='hello world', baz='qux')
    assert parse_kv(r"foo='hello world' baz=qux") == dict(foo='hello world', baz='qux')
    assert parse_kv('foo=\'bar baz=qux\'') == dict(foo='bar baz=qux')
    assert parse_kv(r'foo=bar \'baz qux\'') == dict(foo='bar', _raw_params='baz qux')

# Generated at 2022-06-23 05:03:05.293679
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:20.353014
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c='d e'") == ["a=b", "c='d e'"]
    assert split_args("a=b c=\"d e\"") == ["a=b", "c=\"d e\""]
    assert split_args("a=b c='d \"e\"'") == ["a=b", "c='d \"e\"'"]
    assert split_args("a=b c=\"d 'e'\"") == ["a=b", "c=\"d 'e'\""]
    assert split_args("a=b 'c=d e'") == ["a=b", "'c=d e'"]
    assert split

# Generated at 2022-06-23 05:03:30.444813
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=b c=\\ d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=\\ d e=f') == {u'a': u'b', u'c': u'd', u'e': u'f'}
    assert parse_kv('a=b c=\\" d e=f') == {u'a': u'b', u'c': u'\\" d', u'e': u'f'}
    assert parse_kv('a=\'b c=\\\' d\'') == {u'a': u'\'b c=\\\' d\''}

# Generated at 2022-06-23 05:03:41.928357
# Unit test for function split_args
def test_split_args():
    test_string = '''
    {{ foo }} bar baz "a=1 b=2" 'a=1 b=2'
    {% raw %}
    {% set foo = bar %}
    {% endraw %}

    {% set yep = (foo == bar) ? 'a=1 b=2' : "a=1 b=2" %}
    {% if yep == 'a=1 b=2' %}
        echo "hello"
    {% endif %}

    {# oh hi #}

    {% comment %}
    {% endcomment %}
    '''

# Generated at 2022-06-23 05:03:44.429601
# Unit test for function join_args
def test_join_args():
    assert '1 \n2 \n3' == join_args(['1', '\n', '2', ' ', '\n', '3'])


# Generated at 2022-06-23 05:03:52.934052
# Unit test for function join_args
def test_join_args():
    # Test 1
    assert join_args(['abc', 'def', 'ghi']) == "abc def ghi"

    # Test 2
    assert join_args(['abc', 'def\nghi']) == "abc\ndef\nghi"

    # Test 3
    assert join_args(['abc', 'def', 'ghi\njkl']) == "abc def\nghi\njkl"



# Generated at 2022-06-23 05:04:01.864353
# Unit test for function split_args
def test_split_args():
    def compare(a, b):
        r = 'fail'
        try:
            a = split_args(a)
            b = split_args(b)
            r = 'ok' if a == b else 'fail'
        except Exception as e:
            if a == b == 'fail':
                r = 'ok'
                pass

        print(a, b, r)

    # splits on spaces, but ignores those within jinja2 blocks and quotes
    test = "a=b c=\"foo bar\""
    result = [u'a=b', u'c="foo bar"']
    compare(test, result)

    # jinja2 blocks
    test = "a={{foo}}"
    result = [u'a={{foo}}']
    compare(test, result)

    # multiple tokens

# Generated at 2022-06-23 05:04:08.594162
# Unit test for function parse_kv
def test_parse_kv():
    assert dict(parse_kv('n=v b=2 c=three a=1')) == {u'a': '1', u'b': '2', u'c': 'three', u'n': 'v'}
    assert dict(parse_kv('n=v b=2 c=three a=1', check_raw=True)) == {u'a': '1', u'b': '2', u'c': 'three', u'n': 'v', u'_raw_params': u'n=v b=2 c=three a=1'}
    assert dict(parse_kv('n=v b=2 c=three a=1', check_raw=False)) == {u'a': '1', u'b': '2', u'c': 'three', u'n': 'v'}
    


# Generated at 2022-06-23 05:04:17.606674
# Unit test for function split_args

# Generated at 2022-06-23 05:04:24.702405
# Unit test for function join_args
def test_join_args():
    args = ['foo\nbar',
            'baz']
    test = r'''foo
bar baz'''
    assert(join_args(args) == test)
    args = ['foo \nbar',
            'baz']
    test = r'''foo
bar baz'''
    assert(join_args(args) == test)
    args = ['foo',
            'bar\nbaz']
    test = r'''foo bar
baz'''
    assert(join_args(args) == test)


# Generated at 2022-06-23 05:04:35.287192
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:37.896958
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a b', '\nc d']) == 'a b\nc d'


# Generated at 2022-06-23 05:04:47.845915
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args("foo='bar'") == ["foo='bar'"]
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo=\"bar baz\"") == ["foo=\"bar baz\""]
    assert split_args("foo='bar baz'\nbam=baz") == ["foo='bar baz'", "bam=baz"]
    assert split_args("foo='bar=baz'") == ["foo='bar=baz'"]

# Generated at 2022-06-23 05:04:50.903364
# Unit test for function join_args
def test_join_args():
    s = ['ls', '-l', '\n', '-a']
    assert 'ls -l \n -a' == join_args(s)
    assert 'ls' == join_args(['ls'])



# Generated at 2022-06-23 05:05:01.671341
# Unit test for function parse_kv
def test_parse_kv():
    input = """option1=value1 option2=value2 option3='value 3' option4="value4" option5="value5" option6=value6 option7="value7" option8="value8" option9="value9" option10=value10"""

# Generated at 2022-06-23 05:05:03.131927
# Unit test for function parse_kv
def test_parse_kv():
    pass

# vim: set et sts=4 sw=4 ts=4:

# Generated at 2022-06-23 05:05:13.714046
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value') == {'key': 'value'}
    assert parse_kv('key=value other_key=other_value') == {'key': 'value', 'other_key': 'other_value'}
    assert parse_kv("key='a=b'") == {'key': 'a=b'}
    assert parse_kv('key="a=b\\"') == {'key': 'a=b"'}
    assert parse_kv('key="a=b=c"') == {'key': 'a=b=c'}
    assert parse_kv('key=a\\=b other_key=c\\=d') == {'key': 'a=b', 'other_key': 'c=d'}

# Generated at 2022-06-23 05:05:22.856258
# Unit test for function split_args
def test_split_args():
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz\"') == ['foo', '"bar baz"']
    assert split_args('foo bar\\') == ['foo', 'bar']
    assert split_args('foo bar\\\n baz') == ['foo', 'bar\n', 'baz']
    assert split_args('foo bar "baz \\"qux\\""') == ['foo', 'bar', '"baz "qux""']
    assert split_args('foo {{ bar }} baz') == ['foo', '{{', 'bar', '}}', 'baz']
    assert split_args('foo {% bar %} baz') == ['foo', '{%', 'bar', '%}', 'baz']

# Generated at 2022-06-23 05:05:29.780167
# Unit test for function split_args
def test_split_args():
    '''
    Function to test the proper behavior of split_args()
    '''

    # check for properly split quotes
    assert split_args('foo bar "baz the thing"') == ["foo", "bar", '"baz the thing"']

    # check for proper scaling of quotes
    assert split_args('"foo bar" "baz the thing"') == ['"foo bar"', '"baz the thing"']

    # check that we don't split jinja2 blocks in the middle
    assert split_args('foo bar {{ baz }}') == ["foo", "bar", "{{ baz }}"]

    # check that we don't split jinja2 blocks that are over multiple lines

# Generated at 2022-06-23 05:05:34.052280
# Unit test for function join_args
def test_join_args():
    '''
    Test of the function join_args().
    '''
    assert join_args(['a', '"b c', 'd"']) == 'a "b c\nd"'



# Generated at 2022-06-23 05:05:45.089131
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"this=that something=else") == { u"this" : u"that", u"something": u"else" }
    assert parse_kv(u"thissomething=else") == { u"thissomething": u"else" }
    assert parse_kv(u"this=that somethingelse") == { u"this": u"that", u"_raw_params": u"somethingelse" }
    assert parse_kv(u"this=that something='else here'") == { u"this": u"that", u"something": u"else here" }
    assert parse_kv(u"this=that something=\"else here\"") == { u"this": u"that", u"something": u"else here" }

# Generated at 2022-06-23 05:05:54.908789
# Unit test for function parse_kv
def test_parse_kv():
    # Ensure that key/value parsing works with quoted values and escaped quotes
    assert parse_kv("a='b c' d='e\"f' g=\"h'i\"") == {
        'a': 'b c',
        'd': 'e"f',
        'g': "h'i",
    }
    # Test parsing of escaped double quotes
    args = "a='b\"c' b='d\"e\"f' g=\"h'i\""
    assert parse_kv(args) == parse_kv(args)
    # Test parsing of escaped single quotes
    args = "a='b c' d='e\\'f' g=\"h'i\""
    assert parse_kv(args) == parse_kv(args)
    # Test parsing of unquoted equal signs

# Generated at 2022-06-23 05:06:04.100201
# Unit test for function join_args
def test_join_args():
    s = ['test', '-f', 'a', '\nb', '-g', '\nc']
    assert join_args(s) == 'test -f a\nb -g\nc'
    s = ['test', '-f', 'a', 'b', '-g', 'c\n']
    assert join_args(s) == 'test -f a b -g c\n'
    s = ['test', '-f', 'a', 'b', '-g', 'c']
    assert join_args(s) == 'test -f a b -g c'
    s = ['a', '\n', 'b']
    assert join_args(s) == 'a\nb'
    s = ['a', '\n', '\nb']

# Generated at 2022-06-23 05:06:08.814563
# Unit test for function split_args
def test_split_args():
    import sys

    if sys.version_info > (3,):
        # strings are already unicode in Python3, so don't need to convert
        _unicode = lambda x: x
    else:
        _unicode = lambda x: to_text(x)

    # The following tests are taken from core's test/unit/test_parse.yml
    # Each test is in the form of a tuple:
    #   (input_string, expected_output_list)


# Generated at 2022-06-23 05:06:17.370639
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar baz']) == 'foo bar baz'
    assert join_args(['foo', '  bar baz']) == 'foo   bar baz'
    assert join_args(['foo', '\nbar baz']) == 'foo\nbar baz'
    assert join_args(['foo', '\n', 'bar baz']) == 'foo\nbar baz'
    assert join_args(['foo', '\n  bar baz']) == 'foo\n  bar baz'
    assert join_args(['foo', '\n  bar baz']) == 'foo\n  bar baz'



# Generated at 2022-06-23 05:06:24.918765
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-23 05:06:35.381178
# Unit test for function split_args
def test_split_args():
    from ansible.utils import split_args


# Generated at 2022-06-23 05:06:41.270940
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c", "d"]) == "a b c d"
    assert join_args(["a", "b\nc", "d"]) == "a\nb c\nd"
    assert join_args(["aa", "bb", "cc", "dd"]) == "aa bb cc dd"



# Generated at 2022-06-23 05:06:50.505829
# Unit test for function parse_kv
def test_parse_kv():
    def assert_kv(text, expected):
        actual = parse_kv(text)
        assert actual == expected

    assert_kv(u'key="value"', {u'key': u'value'})
    assert_kv(u'key=value', {u'key': u'value'})
    assert_kv(u"key='value'", {u'key': u'value'})
    assert_kv(u"key=value another", {u'key': u'value', u'_raw_params': u'another'})
    assert_kv(u'key="value another"', {u'key': u'value another'})
    assert_kv(u'key="value" another', {u'key': u'value', u'_raw_params': u'another'})

# Generated at 2022-06-23 05:06:57.406474
# Unit test for function join_args
def test_join_args():
    assert(join_args(['echo']) == 'echo')
    assert(join_args(['echo', 'hello']) == 'echo hello')
    assert(join_args(['echo', 'hello', 'world']) == 'echo hello world')
    assert(join_args(['echo', 'hello\nworld']) == 'echo hello\nworld')
    assert(join_args(['echo', '\n', 'hello', 'world']) == 'echo \nhello world')



# Generated at 2022-06-23 05:07:07.223766
# Unit test for function split_args
def test_split_args():
    '''
    Simple test to ensure correct behaviour of the
    split_args() function
    '''

    # test escaping of quotes
    result = split_args("a=\"b \\\"c\\\"\" d=e")
    assert len(result) == 2
    assert result[0] == "a=\"b \\\"c\\\"\""
    assert result[1] == "d=e"

    # test splitting of quotes
    result = join_args(split_args("a=\"b'c\" d=e"))
    assert result == "a=\"b'c\" d=e"

    # test quote balance

# Generated at 2022-06-23 05:07:16.421408
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar bar="baz"') == { u'foo': u'bar', u'bar': u'baz' }
    assert parse_kv(u'foo=bar bar="baz foo=bar"') == { u'foo': u'bar', u'bar': u'baz foo=bar' }
    assert parse_kv(u'foo=bar bar=baz="foo bar"') == { u'foo': u'bar', u'bar': u'baz=foo bar' }
    assert parse_kv(u'foo=bar bar=baz=foo') == { u'foo': u'bar', u'bar': u'baz=foo' }

# Generated at 2022-06-23 05:07:27.855968
# Unit test for function join_args
def test_join_args():
    assert join_args(["A", "\n", "B"]) == "A\nB"
    assert join_args(["A", "B", "C"]) == "A B C"
    assert join_args(["A\n", "B C"]) == "A\nB C"
    assert join_args(["A \n", "\n", "B"]) == "A \n\nB"
    assert join_args(["A", "B", "\nC"]) == "A B\nC"
    assert join_args(["A", "B C"]) == "A B C"
    assert join_args(["A", "B\nC"]) == "A B\nC"
    assert join_args(["A", "", "B"]) == "A  B"
    assert join_args

# Generated at 2022-06-23 05:07:36.057884
# Unit test for function parse_kv
def test_parse_kv():
    def assert_parse(args, expect):
        if isinstance(args, dict):
            args = join_args(args)
        options = parse_kv(args)
        assert options == expect

    assert_parse('a=1 b=2', {u'a': u'1', u'b': u'2'})
    assert_parse('a=1 b=2 c=3 d=4', {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'})
    assert_parse('a="1" b="2" c="3" d="4"', {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'})

# Generated at 2022-06-23 05:07:47.390159
# Unit test for function join_args
def test_join_args():
    x =['command1','command2','command3','','','','','','','','','','','','','','','','','','','','','','']
    y = join_args(x)
    assert y == 'command1 command2 command3  '
    cmd = '''echo "foo bar"
echo "foo "
echo "foo
bar"
echo 'foo'
echo 'foo bar'
echo 'foo '
echo 'foo
bar'
echo "foo"
echo 'foo'
echo foo
echo "foo
bar"
echo 'foo
bar'
echo "foo
bar
"
echo 'foo
bar
'
'''

# Generated at 2022-06-23 05:07:58.129972
# Unit test for function split_args

# Generated at 2022-06-23 05:08:02.025323
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', '\nbar', 'baz']) == 'foo \nbar baz'
    assert join_args(['foo', '\n', 'bar', '\n', 'baz']) == 'foo \n bar \n baz'



# Generated at 2022-06-23 05:08:13.562951
# Unit test for function join_args
def test_join_args():
    if join_args([]) != '':
        raise AssertionError('join_args([] should == "")')
    if join_args(['1']) != '1':
        raise AssertionError('join_args(["1"]) should == "1"')
    if join_args(['1', '2']) != '1 2':
        raise AssertionError('join_args(["1", "2"]) should == "1 2"')
    if join_args(['1 2']) != '1 2':
        raise AssertionError('join_args(["1 2"]) should == "1 2"')

# Generated at 2022-06-23 05:08:23.581978
# Unit test for function split_args
def test_split_args():
    # args is a string, containing the arguments to be split
    # expected is a list of strings, containing the expected outputs from split_args
    # name is an optional string, containing the name of the test case
    #
    # this function tests the split_args function by running it on each
    # provided argument case and comparing the result to the expected output
    # and then prints a success message for that test case if the two match
    #
    # returns a list of strings, containing the names of the test cases given
    def run_test(args, expected, name=None):
        # split the provided args into a list of strings using split_args
        result = split_args(args)

        # if the name was not given, use the first 30 characters of the args string
        if name is None:
            name = args[:30]

        # if the number

# Generated at 2022-06-23 05:08:32.040282
# Unit test for function parse_kv
def test_parse_kv():
    # TODO: Test that options with no value are parsed correctly (e.g. 'foo=bar'),
    # see issue #11534
    import json

# Generated at 2022-06-23 05:08:42.422597
# Unit test for function join_args
def test_join_args():
    s = ['hostname\n', '  hostname\n', '\n', 'hostname\n', 'hostname\n']
    result = join_args(s)
    assert result == 'hostname\n  hostname\n\nhostname\nhostname\n'
    s = ['hostname\n', '      hostname\n', '\n', '   hostname\n', 'hostname\n']
    result = join_args(s)
    assert result == 'hostname\n      hostname\n\n   hostname\nhostname\n'
    s = ['hostname\n', '      hostname\n', '\n', '   hostname\n', 'hostname\n', ' ']
    result = join_args(s)

# Generated at 2022-06-23 05:08:51.208684
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests import unittest
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestSplitArgs(unittest.TestCase):

        def __assert_join_split_preserves_args(self, arg_str):
            """Ensure that splitting args and then rejoining them does not change the original arg_str"""
            new_args = join_args(split_args(arg_str))
            self.assertEqual(arg_str, new_args)

        def __assert_split_args_eq(self, arg_str, expected):
            """Ensure that split_args outputs the expected list of args"""
            args = split_args(arg_str)
            self.assertEqual(expected, args)


# Generated at 2022-06-23 05:08:55.735703
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    assert join_args(['a\n', 'b', '\nc']) == 'a\nb c'


# Generated at 2022-06-23 05:09:07.074293
# Unit test for function split_args
def test_split_args():
    print("testing split_args")
    # Check that we raise an error when there's an unbalanced jinja2 block
    try:
        split_args("{{ foo }} bar")
        assert False
    except AnsibleParserError:
        pass

    # Check that we raise an error when there's an unbalanced Jinja2 print block
    try:
        split_args("{{ foo }} \\\nbar")
        assert False
    except AnsibleParserError:
        pass

    # Check that we raise an error when there's an unbalanced quoted string
    try:
        split_args("\" foo bar")
        assert False
    except AnsibleParserError:
        pass

    # Check that we don't raise an error when there's a balanced quoted string

# Generated at 2022-06-23 05:09:18.326029
# Unit test for function parse_kv

# Generated at 2022-06-23 05:09:27.599855
# Unit test for function join_args

# Generated at 2022-06-23 05:09:38.067281
# Unit test for function split_args
def test_split_args():
    import unittest
    import ansible.utils.shlex

    class TestSplitArgs(unittest.TestCase):

        def test_value(self):
            teststr = "  a=b   c=d  "
            teststr_result = ['a=b', 'c=d']
            val = split_args(teststr)
            self.assertEqual(val, teststr_result)

        def test_value_newlines(self):
            teststr = "  a=b   c=d  \n  e=f   g=h  "
            teststr_result = ['a=b', 'c=d\n', 'e=f', 'g=h']
            val = split_args(teststr)
            self.assertEqual(val, teststr_result)


# Generated at 2022-06-23 05:09:48.790417
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.six import PY3

    # Using string literals with unicode escapes on
    # Python 2 would mean that split_args has to
    # deal with those escapes.  Since they're just
    # test strings, it makes sense to skip that.
    if PY3:
        test_string = 'a=1 b=2 c="foo bar" d=\'foo bar\' e="foo \\\'bar\\\\" f=\\" g=\\\\" h=\\\\\\" i=foo\\\\\\"j=foo j=\nj'
        params = split_args(test_string)

# Generated at 2022-06-23 05:09:51.737743
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\nbar']) == 'foo\nbar'


# Generated at 2022-06-23 05:10:00.555720
# Unit test for function split_args

# Generated at 2022-06-23 05:10:04.372578
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'foo', 'bar', 'baz', '\necho', 'foo', 'bar', 'baz\n']
    if not 'foo bar baz\necho foo bar baz\n' == join_args(s):
        # Unit test failed
        return False
    return True



# Generated at 2022-06-23 05:10:15.572836
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c', '\n', 'd', 'e', 'f']) == 'a b c\nd e f'
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a', 'b\nc', '\n', 'd\ne']) == 'a b\nc\nd e'
    assert join_args([r'a', r'b\nc', '\n', r'd\ne']) == r'a b\nc\nd\ne'
    assert join_args([r'"', r'b\nc', '\n', r'd"e']) == r'" b\nc\nd"e'

# Generated at 2022-06-23 05:10:26.096581
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a', '\\\nb']) == 'a \\b'
    assert join_args(['a\n', '\\\nb']) == 'a\n \\b'
    assert join_args(['a', '\\\n', 'b']) == 'a  \nb'
    assert join_args(['a\n', '\\\n', 'b']) == 'a\n \nb'
    assert join_args(['a\n', '\\\n', 'b\n']) == 'a\n \nb\n'
   

# Generated at 2022-06-23 05:10:32.670245
# Unit test for function split_args
def test_split_args():

    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz" qux') == ['foo', '"bar baz"', 'qux']
    assert split_args('foo "bar baz" "qux quux"') == ['foo', '"bar baz"', '"qux quux"']
    assert split_args('foo "bar baz" "qux quux" corge') == ['foo', '"bar baz"', '"qux quux"', 'corge']

# Generated at 2022-06-23 05:10:42.662835
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d=\'{"bar":"foo"}\'') == ['a=b', 'c="foo bar"', "d='{\"bar\":\"foo\"}'"]
    assert split_args('a=b c="foo bar" d="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split_args('a=b c="foo bar" d="{{ foo }}"') == ['a=b', 'c="foo bar"', 'd="{{ foo }}"']
    assert split

# Generated at 2022-06-23 05:10:53.464755
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv(u'one') == {u'_raw_params': u'one'}
    assert parse_kv(u'one=') == {u'one': u''}
    assert parse_kv(u'one= two') == {u'one': u'two', u'_raw_params': u'two'}
    assert parse_kv(u'one=two three') == {u'one': u'two', u'_raw_params': u'three'}