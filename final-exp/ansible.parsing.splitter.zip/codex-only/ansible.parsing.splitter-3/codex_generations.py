

# Generated at 2022-06-23 05:00:52.016122
# Unit test for function parse_kv
def test_parse_kv():
    params="""creates=removes=/bin/true chdir=warn=no executable=/bin/bash stdin=/bin/sh foo=bar fred=wilma echo=foo"""
    parsed = parse_kv(params)
    assert parsed == {u'creates': u'/bin/true', u'chdir': u'', u'warn': u'no', u'executable': u'/bin/bash', u'stdin': u'/bin/sh', u'foo': u'bar', u'fred': u'wilma', u'_raw_params': u'echo=foo'}



# Generated at 2022-06-23 05:01:03.117529
# Unit test for function parse_kv

# Generated at 2022-06-23 05:01:13.520310
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', 'baz']) == 'foo bar baz'
    assert join_args(['foo', '', 'bar', 'baz']) == 'foo   bar baz'
    assert join_args(['foo', 'bar', '', 'baz']) == 'foo bar   baz'
    assert join_args(['foo', 'bar', 'baz', '']) == 'foo bar baz '
    assert join_args(['foo', 'bar\nbaz']) == 'foo bar\nbaz'
    assert join_args(['foo', 'bar', '\nbaz']) == 'foo bar \nbaz'
    assert join_args(['foo', 'bar', 'baz\n']) == 'foo bar baz\n'

# Generated at 2022-06-23 05:01:23.072955
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1 b=2 _raw_params=c=3") == {'a': '1', 'b': '2', '_raw_params': 'c=3'}
    assert parse_kv("a=1,b=2", check_raw=True) == {'a': '1', 'b': '2', '_raw_params': 'a=1,b=2'}
    assert parse_kv("a=1,b=2", check_raw=False) == {'a': '1', 'b': '2'}

# Generated at 2022-06-23 05:01:32.131211
# Unit test for function split_args
def test_split_args():
    import unittest
    import sys
    from ansible.parsing.split import split_args, join_args


# Generated at 2022-06-23 05:01:42.129666
# Unit test for function join_args
def test_join_args():
    for cmd, expected_cmd in {
        ["ls", "-l", "/"]: 'ls -l /',
        ["ls", "-l", "/", '|', "grep", "tmp"]: 'ls -l / | grep tmp',
        ["ls", "-l", "/", '|', "\n", "grep", "tmp"]: 'ls -l / | \n grep tmp',
        ["echo", '"', "hello", "world", '"']: 'echo "hello world"',
        ["echo", "'", "hello", "world", "'"]: "echo 'hello world'",
        ["echo", "'", "hello", '\n', "world", "'"]: "echo 'hello \n world'",
    }.items():
        assert expected_cmd == join_args(cmd)



# Generated at 2022-06-23 05:01:52.970848
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'abc'
    assert join_args(['a', '\nb', 'c']) == 'a\nb c'
    assert join_args(['a', '\n', 'b', 'c']) == 'a\nb c'
    assert join_args(['a', '\n']) == 'a\n'
    assert join_args(['a', 'b']) == 'ab'
    assert join_args(['a', 'b', '\n', 'c']) == 'ab\nc'
    assert join_args(['a', 'b', '\n']) == 'ab\n'
    assert join_args(['a', 'b', '\n', 'c', '\n']) == 'ab\nc\n'

# Generated at 2022-06-23 05:02:02.797274
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a b', 'c']) == 'a b c'
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb']) == 'a \nb'
    assert join_args(['a\n', 'b']) == 'a\n b'
    assert join_args(['a\n', 'b\n']) == 'a\n b\n'
    assert join_args(['a\n', 'b\n', 'c\n']) == 'a\n b\n c\n'
    assert join_args(['"a"', 'b']) == '"a" b'

# Generated at 2022-06-23 05:02:12.990765
# Unit test for function parse_kv
def test_parse_kv():
    # Test a string passed without quotes, without spaces between items of the string
    orig_args = '"arg1=foo arg2=bar arg3=baz"'
    check_raw = False
    try:
        options = parse_kv(orig_args, check_raw)
    except AnsibleParserError:
        raise AssertionError()
    assert 'arg1' in options and options['arg1'] == 'foo'
    assert 'arg2' in options and options['arg2'] == 'bar'
    assert 'arg3' in options and options['arg3'] == 'baz'
    assert '_raw_params' not in options

    # Test a string passed without quotes, with spaces between items of the string
    orig_args = '"arg1=foo arg2=bar arg3=baz"'
    check_raw = False


# Generated at 2022-06-23 05:02:21.400597
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', 'b', 'c']) == 'a b c')
    assert(join_args(['a\nb', 'c\n', 'd\n']) == 'a\nb\nc\n d\n')
    assert(join_args(['a\n', 'b\n', 'c\n', 'd\n']) == 'a\nb\nc\nd\n')


# Generated at 2022-06-23 05:02:28.411183
# Unit test for function join_args
def test_join_args():
    cmd = [
        'git clone https://github.com/ansible/ansible.git',
        '-b stable-2.1',
        '--depth 1',
        '\n',
        '/opt/ansible',
    ]
    assert join_args(cmd) == ('git clone https://github.com/ansible/ansible.git'
                              ' -b stable-2.1 --depth 1 \n'
                              '/opt/ansible')
# End unit test for function join_args


# Generated at 2022-06-23 05:02:37.882672
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == dict(foo="bar")
    assert parse_kv("foo=bar bar=baz") == dict(foo="bar", bar="baz")

    assert parse_kv("foo=\"bar\"") == dict(foo="bar")
    assert parse_kv("foo=\"bar\"  bar=\"baz\"") == dict(foo="bar", bar="baz")

    assert parse_kv("foo='bar'") == dict(foo="bar")
    assert parse_kv("foo='bar'  bar='baz'") == dict(foo="bar", bar="baz")

    assert parse_kv("foo='bar'  bar='baz'", check_raw=True) == dict(foo="bar", bar="baz")


# Generated at 2022-06-23 05:02:44.416445
# Unit test for function split_args
def test_split_args():
    # test basic functionality
    assert split_args(u'''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']

    # test that escaped quotes are preserved correctly
    assert split_args(u'''c=1 d="foo\"bar"''') == ['c=1', 'd="foo\"bar"']
    assert split_args(u'''e=2 f=\'foo\\\'bar\'''') == ['e=2', "f='foo\\'bar'"]

    # test that escaped spaces are not broken up into separate args
    assert split_args(u'''g=3 h=foo\\ bar''') == ['g=3', 'h=foo\\ bar']

# Generated at 2022-06-23 05:02:48.863506
# Unit test for function split_args
def test_split_args():
    a = 'a=b c="foo bar"'
    e = ['a=b', 'c="foo bar"']
    assert e == split_args(a)

    a = "foo bar\n"
    e = ['foo', 'bar']
    assert e == split_args(a)

    a = "foo bar biz baz"
    e = ['foo', 'bar', 'biz', 'baz']
    assert e == split_args(a)

    a = "foo\nbar biz\nbaz"
    e = ['foo', 'bar', 'biz', 'baz']
    assert e == split_args(a)

    a = "foo bar\nbiz baz"
    e = ['foo', 'bar', 'biz', 'baz']
    assert e == split_args(a)


# Generated at 2022-06-23 05:02:56.810376
# Unit test for function split_args
def test_split_args():
    args = "foo=true bar={{ baz }}"
    result = split_args(args)
    assert(result == ['foo=true', 'bar={{ baz }}'])
    args = "{% if foo %}foo is true{% else %}foo is false{% endif %}"
    result = split_args(args)
    assert(result == ['{% if foo %}foo is true{% else %}foo is false{% endif %}'])
    args = "foo='{{ baz }}' bar={{ baz }}"
    result = split_args(args)
    assert(result == ['foo=\'{{ baz }}\'', 'bar={{ baz }}'])
test_split_args()

# Generated at 2022-06-23 05:03:04.305385
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("a=b c=d", check_raw=False)
    assert options == {'a': 'b', 'c': 'd'}

    options = parse_kv("a=b c=d", check_raw=True)
    assert options == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}

    options = parse_kv('a="b c" d=e', check_raw=True)
    assert options == {'a': 'b c', 'd': 'e', '_raw_params': 'a="b c" d=e'}

    options = parse_kv('a=b c="d e"', check_raw=True)

# Generated at 2022-06-23 05:03:19.387036
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {"a": "b", "c": "d"}
    assert parse_kv(u'a=b c=d') == {"a": "b", "c": "d"}
    assert parse_kv(u'a=b c=d') == {"a": "b", "c": "d"}
    assert parse_kv('a=b c=d') == {"a": "b", "c": "d"}
    assert parse_kv(u'a=b c=d') == {"a": "b", "c": "d"}
    assert parse_kv('a= "b c=d"') == {"a": "b c=d"}
    assert parse_kv('a= "b c=d"') == {"a": "b c=d"}

# Generated at 2022-06-23 05:03:29.988919
# Unit test for function parse_kv
def test_parse_kv():
    import os
    raw_params = 'arg1=foo\'bar\'baz arg2=\\\'foobar\\\' arg3=\\"foobar\\" arg4="foo\'bar" arg5=foo\\\'\\"\\"bar arg6="foo\\\'\\"bar" arg7=\'foo\\\'bar\\\'arg8=foo\\\'bar\\\'\''
    option = parse_kv(raw_params)
    print(option)
    assert option['arg1'] == u'foobarbaz'
    assert option['arg2'] == u'\'foobar\''
    assert option['arg3'] == u'"foobar"'
    assert option['arg4'] == u"foo'bar"
    assert option['arg5'] == u'foo\'"bar'
    assert option['arg6'] == u"foo'\"bar"


# Generated at 2022-06-23 05:03:34.138087
# Unit test for function join_args
def test_join_args():
    a = "echo 'A B C' D;\necho 'A B C' D"
    b = split_args(a)
    c = join_args(b)

    return c == a


# Generated at 2022-06-23 05:03:41.668890
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', 'b c']) == 'a b c'
    assert join_args(['a\n', 'b', 'c']) == 'a\n b c'
    assert join_args(['a', 'b\n', 'c']) == 'a b\n c'
    assert join_args(['a', 'b\n', 'c d']) == 'a b\n c d'



# Generated at 2022-06-23 05:03:48.514308
# Unit test for function join_args
def test_join_args():
    assert join_args(["arg1", "arg2", "arg3"]) == "arg1 arg2 arg3"
    assert join_args(["arg1\n", "arg2\n", "arg3\n"]) == "arg1\narg2\narg3\n"
    assert join_args(["arg1", "arg2\n", "arg3"]) == "arg1 arg2\narg3"
    assert join_args(["arg1\n", "arg2", "arg3\n"]) == "arg1\narg2 arg3\n"


# Generated at 2022-06-23 05:03:51.555005
# Unit test for function join_args
def test_join_args():
    # This is not a comprehensive unit test.
    input = u'''
{% for i in range(0, 1) %}
echo {{ "i is " + i }}

{% endfor %}
'''
    assert join_args(split_args(input)) == input.rstrip()



# Generated at 2022-06-23 05:04:03.664748
# Unit test for function split_args
def test_split_args():
    res = split_args("what")
    assert res == ["what"], res

    res = split_args("what 'is'")
    assert res == ["what", "'is'"], res

    res = split_args("'what' is")
    assert res == ["'what'", "is"], res

    res = split_args("'what is' this")
    assert res == ["'what is'", "this"], res

    res = split_args("'what is' this")
    assert res == ["'what is'", "this"], res

    res = split_args("'what is' this\n'or is it'")
    assert res == ["'what is'", "this\n'or is it'"], res

    res = split_args("'what is' this\n'or is it'\n")
    assert res

# Generated at 2022-06-23 05:04:13.497992
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test of parse_kv
    '''
    # test simple cases
    assert parse_kv('a=b') == {'a': 'b'}
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    # test quoting
    assert parse_kv('a=b\ c=d') == {'a': 'b c=d'}
    assert parse_kv('a=b\\ c=d') == {'a': 'b\\ c=d'}
    assert parse_kv('a="b c"') ==  {'a': 'b c'}
    assert parse_kv('a="b c" x=y') ==  {'a': 'b c', 'x': 'y'}
    # test lists

# Generated at 2022-06-23 05:04:20.779921
# Unit test for function parse_kv
def test_parse_kv():

    # Test empty case
    assert {} == parse_kv('')

    # Test single key/value pair
    assert {u'foo': u'bar'} == parse_kv('foo=bar')

    # Test multiple key/value pairs
    assert {u'foo': u'bar', u'abc': u'def'} == parse_kv('foo=bar abc=def')

    # Test quotes around value
    assert {u'foo': u'bar baz'} == parse_kv('foo="bar baz"')

    # Test spaces between key and value
    assert {u'foo': u'bar'} == parse_kv('foo = bar')

    # Test spaces between key and value and quotes around value
    assert {u'foo': u'bar'} == parse_kv('foo = "bar"')



# Generated at 2022-06-23 05:04:32.314701
# Unit test for function join_args
def test_join_args():
    "Check valid input"
    args = [ u'"foo bar"', u'baz']
    expected_result = u'"foo bar" baz'
    assert join_args(args) == expected_result
    args = [u'foo', u"bar baz"]
    expected_result = u'foo "bar baz"'
    assert join_args(args) == expected_result
    args = [u'foo', u"bar", u"baz"]
    expected_result = u'foo bar baz'
    assert join_args(args) == expected_result
    args = [ u'foo\nbar', u'baz']
    expected_result = u'foo\nbar baz'
    assert join_args(args) == expected_result
    args = [ u'foo', u'bar\nbaz']
    expected

# Generated at 2022-06-23 05:04:37.149767
# Unit test for function join_args
def test_join_args():
    assert join_args(['first', 'second', 'third']) == 'first second third'
    assert join_args(['first', '\nsecond', '\nthird']) == 'first\nsecond\nthird'
    assert join_args(['first', '\nsecond', ' ', '\nthird']) == 'first\nsecond \nthird'



# Generated at 2022-06-23 05:04:40.560308
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '-n', 'test']) == 'echo -n test'
    assert join_args(['echo', '-n', 'test\n']) == 'echo -n test\n'



# Generated at 2022-06-23 05:04:51.964043
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == { 'a': 'b', 'c': 'd' }
    assert parse_kv("a=b c=d e") == { 'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv("a=b c=d e f") == { 'a': 'b', 'c': 'd', '_raw_params': 'e f'}
    assert parse_kv('a=b "c=d e" f') == { 'a': 'b', 'c=d e': 'f', '_raw_params': ''}
    assert parse_kv('a=b "c=d e" f') == { 'a': 'b', 'c=d e': 'f', '_raw_params': ''}

# Generated at 2022-06-23 05:05:02.451671
# Unit test for function split_args
def test_split_args():
    # test normal args
    args = u'git clone "https://github.com/ansible/ansible.git" /tmp/ansible'
    p = split_args(args)
    assert p == ['git', 'clone', 'https://github.com/ansible/ansible.git', '/tmp/ansible']
    # test escaped quotes
    args = u'git clone https://github.com/ansible/ansible.git\\" /tmp/ansible'
    p = split_args(args)
    assert p == ['git', 'clone', 'https://github.com/ansible/ansible.git"', '/tmp/ansible']
    # test args with escaped spaces
    args = 'git clone https://github.com/ansible/ansible.git \\\\ /tmp/ansible'

# Generated at 2022-06-23 05:05:11.699387
# Unit test for function split_args
def test_split_args():

    # {% }}, {{ }, {# #}, and '" are all expected to be balanced
    def _balance_check(msg, args):
        try:
            tokens = split_args(args)
        except AnsibleParserError as e:
            raise AssertionError('''\
%s
split_args(%r) failed
''' % (msg, args))
        else:
            assert isinstance(tokens, list), 'Not a list: %r' % tokens
            for token in tokens:
                assert '{%' not in token, 'Found {%% in: %r' % token
                assert '%}' not in token, 'Found %%} in: %r' % token
                assert '{#' not in token, 'Found {# in: %r' % token

# Generated at 2022-06-23 05:05:21.432986
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("key1=value1 key2=value2")
    assert len(options) == 2
    assert options['key1'] == 'value1'
    assert options['key2'] == 'value2'
    options = parse_kv("key1=value1 key2=value2 key3=value3 key2=value2_2")
    assert len(options) == 3
    assert options['key1'] == 'value1'
    assert options['key2'] == 'value2_2'
    assert options['key3'] == 'value3'
    options = parse_kv("key1='value1' key2='value2' key3='value3'")
    assert len(options) == 3
    assert options['key1'] == 'value1'
    assert options['key2'] == 'value2'

# Generated at 2022-06-23 05:05:31.581593
# Unit test for function parse_kv
def test_parse_kv():
    '''Test parse kv.'''
    options = parse_kv("a=b c='d e' f=\"g h\" i 'j k'")
    assert options['a'] == 'b'
    assert options['c'] == 'd e'
    assert options['f'] == 'g h'
    assert options['i'] == 'j k'
    assert options[u'_raw_params'] == 'a=b c=\'d e\' f="g h" i \'j k\''

    options = parse_kv("a=b c=\"$HOME\" d='$HOME'")
    assert options['a'] == 'b'
    assert options['c'] == '$HOME'
    assert options['d'] == '$HOME'

    options = parse_kv("a=b c=d")
    assert options['a']

# Generated at 2022-06-23 05:05:38.643372
# Unit test for function join_args
def test_join_args():
    assert(join_args(['echo', 'hello']) == 'echo hello')
    assert(join_args(['echo', 'hello', 'world']) == 'echo hello world')
    assert(join_args(['echo', 'hello \\\nworld']) == 'echo hello \\world')
    assert(join_args(['echo', 'hello\nworld']) == 'echo hello\nworld')
    assert(join_args(['echo', 'hello\rworld']) == 'echo hello\rworld')
    assert(join_args(['echo', 'hello\r\nworld']) == 'echo hello\r\nworld')


# Generated at 2022-06-23 05:05:45.941035
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=foo\\ bar") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=foo\\\\ bar") == ['a=b', 'c=foo\\\\ bar']
    assert split_args("a=b c=\"foo\\\\ bar\"") == ['a=b', 'c="foo\\\\ bar"']
    assert split_args("a=b c=\"foo\\\" bar\"") == ['a=b', 'c="foo\\" bar"']

# Generated at 2022-06-23 05:05:55.486710
# Unit test for function split_args
def test_split_args():
    assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args('''a b
c''') == ['a', 'b\nc']
    assert split_args('''a b
c d''') == ['a', 'b\nc', 'd']
    assert split_args('''a b
c d e''') == ['a', 'b\nc', 'd', 'e']
    assert split_args('a b c\nd') == ['a', 'b', 'c\nd']
    assert split_args('a=b c=d e=f') == ['a=b', 'c=d', 'e=f']

# Generated at 2022-06-23 05:06:04.361105
# Unit test for function split_args

# Generated at 2022-06-23 05:06:15.691418
# Unit test for function join_args
def test_join_args():
    def my_assert(s, expected):
        if join_args(split_args(s)) != expected:
            raise Exception("Assert failed on input string '%s'" % s)

    my_assert("foo", "foo")
    my_assert("foo bar", "foo bar")
    my_assert("foo\nbar", "foo\nbar")
    my_assert("foo\nbar\n", "foo\nbar\n")
    my_assert("foo\nbar\n\n", "foo\nbar\n")
    my_assert("foo\n\nbar", "foo\n\nbar")
    my_assert("foo\n\nbar\n\n", "foo\n\nbar\n")

    my_assert("foo 'bar baz'", "foo 'bar baz'")


# Generated at 2022-06-23 05:06:26.046081
# Unit test for function join_args
def test_join_args():
    """
    Tests the join_args function
    """
    # split_args() generates a list of strings
    # by default. No join operation is needed
    assert join_args(['a', 'b', 'c']) == 'a b c'

    # The split_args() function preserves escaped quotes.
    # show this is recovered properly by join_args()
    assert join_args(['a', '"b"', 'c']) == 'a "b" c'

    # if split_args() encounters unterminated quotes
    # it will start a new element. This should be
    # automatically joined.
    assert join_args(['a', '"b', 'c']) == 'a "b c'

    # When a newline is included in an element
    # split_args() will preserve it, but does not
    # include

# Generated at 2022-06-23 05:06:36.244147
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv(u"creates=/tmp/foo removes=/tmp/bar") == dict(creates=u'/tmp/foo', removes=u'/tmp/bar')

    assert parse_kv(u"creates=/tmp/foo removes=/tmp/bar foo=one bar=two") == dict(creates=u'/tmp/foo', removes=u'/tmp/bar', foo=u'one', bar=u'two')

    assert parse_kv(u"creates=/tmp/foo removes=/tmp/bar foo=one bar=two foobar") == dict(creates=u'/tmp/foo', removes=u'/tmp/bar', foo=u'one', bar=u'two', _raw_params=u'foobar')


# Generated at 2022-06-23 05:06:47.454877
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d',check_raw=True)=={'a': 'b', 'c': 'd', u'_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d', check_raw=False) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=1 b=2 c=3', check_raw=False) == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b=2 c=3', check_raw=True) == {'a': '1', 'b': '2', 'c': '3', u'_raw_params': 'a=1 b=2 c=3'}
    assert parse_

# Generated at 2022-06-23 05:06:58.673516
# Unit test for function split_args
def test_split_args():
    # Split args on whitespace, but intelligently reassembles
    # those that may have been split over a jinja2 block or quotes.

    # Given this input:
    input_args1 = '''a=b c="foo bar"'''
    # We expect the following output:
    output_args1 = ['a=b', 'c="foo bar"']
    # When we run the following test:
    print(split_args(input_args1))
    assert split_args(input_args1) == output_args1

    # Given this input
    input_args2 = '''a=b c='foo bar' d="foo bar"'''
    # We expect the following output:
    output_args2 = ['a=b', "c='foo bar'", 'd="foo bar"']
    # When we run the

# Generated at 2022-06-23 05:07:06.491148
# Unit test for function join_args
def test_join_args():
    assert join_args(["a b", "c"]) == "a b c"
    assert join_args(["a\nb", "c"]) == "a\nb c"
    assert join_args(["a\nb", "c", "d"]) == "a\nb c d"
    assert join_args(["a\nb", "c\nd"]) == "a\nb c\nd"
    assert join_args(["a\nb", "c\nd\ne"]) == "a\nb c\nd\ne"
    assert join_args(["a\nb", "\nc"]) == "a\nb \nc"



# Generated at 2022-06-23 05:07:15.974678
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo="bar" bar="baz"') == {u'foo': u'bar', u'bar': u'baz'}
    assert parse_kv("foo='bar' bar='baz'") == {u'foo': u'bar', u'bar': u'baz'}
    assert parse_kv("foo='bar bar' bar='baz'") == {u'foo': u'bar bar', u'bar': u'baz'}
    assert parse_kv("foo='bar bar' bar='baz baz'") == {u'foo': u'bar bar', u'bar': u'baz baz'}

# Generated at 2022-06-23 05:07:27.551499
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("name=Hello World") == {u'name': u'Hello World'}
    assert parse_kv(u"name=Hello World") == {u'name': u'Hello World'}

    # Key with whitespace, value with quotes
    assert parse_kv("name = \"World\"") == {u'name': u'World'}
    assert parse_kv("name='World'") == {u'name': u'World'}
    assert parse_kv("name=World") == {u'name': u'World'}
    # Single quotes in single quoted value
    assert parse_kv("name='Don\\'t go here'") == {u'name': u"Don't go here"}
    # Double quotes in single quoted value

# Generated at 2022-06-23 05:07:35.486697
# Unit test for function join_args
def test_join_args():
    assert join_args(['a\n','b','c','d']) == 'a\nb c d'
    assert join_args(['a\n','b','c','d\n']) == 'a\nb c d\n'
    assert join_args(['a\n','b','c','d\n','e']) == 'a\nb c d\ne'
    assert join_args(['a\n',' b c ',' d\n',' e']) == 'a\n b c  d\n e'
    assert join_args(['a\n',' b c\n',' d\n',' e']) == 'a\n b c\n d\n e'



# Generated at 2022-06-23 05:07:46.843108
# Unit test for function split_args
def test_split_args():
    import pytest

    @pytest.fixture
    def counts():
        return {
            "print_depth": 0,
            "block_depth": 0,
            "comment_depth": 0,
            "inside_quotes": False,
        }

    def test_wrapper(input_string, expected_output, counts):
        assert split_args(input_string) == expected_output
        assert counts["print_depth"] == 0
        assert counts["block_depth"] == 0
        assert counts["comment_depth"] == 0
        assert counts["inside_quotes"] == False

    # Empty string
    test_wrapper("", [], counts())

    # Short string without any jinja/quotes
    test_wrapper("this is a string", ["this", "is", "a", "string"], counts())

    # Short string with only

# Generated at 2022-06-23 05:07:53.012720
# Unit test for function join_args
def test_join_args():
    str = ['-t', 'foo', '-b', 'bar']
    result = join_args(str)
    assert result == '-t foo -b bar'
    str = ['-t', 'foo', 'bar']
    result = join_args(str)
    assert result == '-t foo bar'
    str = ['-t', 'foo', '\nbar']
    result = join_args(str)
    assert result == '-t foo\nbar'



# Generated at 2022-06-23 05:08:02.196538
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("a=x b=y")
    assert result == {"a": "x", "b": "y"}, "parse_kv() failed"

    result = parse_kv("a=x b=y c")
    assert result == {"a": "x", "b": "y", "_raw_params": "c"}, "parse_kv() failed"

# Split args adapted from rspeer's answer here:
# http://stackoverflow.com/questions/14693701/how-can-i-remove-the-ansi-escape-sequences-from-a-string-in-python

# Generated at 2022-06-23 05:08:05.976262
# Unit test for function join_args
def test_join_args():
    test_list = ['hi', '\n', 'new', '\n', 'line']
    result = join_args(test_list)
    expected = 'hi\nnew\nline'
    if result == expected:
        print('Successful')
    else:
        print('Failed')
#test_join_args()



# Generated at 2022-06-23 05:08:17.574676
# Unit test for function split_args
def test_split_args():
    '''
    Unit test to verify proper handling of various quote and jinja2 block
    combinations.
    '''

# Generated at 2022-06-23 05:08:28.368012
# Unit test for function split_args
def test_split_args():
    import pytest

    # Test quotes
    assert split_args("a=b 'c=d'") == ['a=b', "'c=d'"]
    assert split_args("a=b \"c=d\"") == ['a=b', '"c=d"']
    assert split_args("a=b \"c d\"") == ['a=b', '"c d"']
    assert split_args('a=b "c d"') == ['a=b', '"c d"']
    assert split_args("a=b 'c d'") == ['a=b', "'c d'"]
    assert split_args('a=b \'c d\'') == ['a=b', "'c d'"]

# Generated at 2022-06-23 05:08:40.366835
# Unit test for function parse_kv
def test_parse_kv():

    def _test(line, expected):
        result = parse_kv(line)
        if result != expected:
            raise AssertionError("Expected %r, got %r" % (expected, result))

    _test(None, {})
    _test("", {})
    _test('"a" "b"', {'a': 'b'})
    _test("'a' 'b'", {'a': 'b'})
    _test('"a"="b"', {'a': 'b'})
    _test('a=1 "b=2" c="d 3"', {'a': '1', 'b': '2', 'c': 'd 3'})

# Generated at 2022-06-23 05:08:49.620649
# Unit test for function split_args

# Generated at 2022-06-23 05:08:57.034734
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello', '\nworld']) == 'hello\nworld'
    assert join_args(['hello\n', 'world']) == 'hello\nworld'



# Generated at 2022-06-23 05:09:08.350041
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("src=foo") == {'src': 'foo'}
    assert parse_kv("src=foo\n dest=bar") == {'src': 'foo', 'dest': 'bar'}
    assert parse_kv("src=foo\n dest=bar\n") == {'src': 'foo', 'dest': 'bar'}
    assert parse_kv("src=foo\n dest=bar\n", check_raw=True) == {'src': 'foo', 'dest': 'bar', u'_raw_params': None}

# Generated at 2022-06-23 05:09:19.841614
# Unit test for function split_args
def test_split_args():
    try:
        split_args('a=b c=d')
    except AnsibleParserError:
        pytest.fail('split_args fails to handle simple assignment')
    try:
        split_args('  a=b  c=d')
    except AnsibleParserError:
        pytest.fail('split_args fails to handle leading spaces')
    try:
        split_args('a=b  c=d  ')
    except AnsibleParserError:
        pytest.fail('split_args fails to handle trailing spaces')
    try:
        split_args('a=b\tc=d')
    except AnsibleParserError:
        pytest.fail('split_args fails to handle tabs')
    try:
        split_args('a=b c="d e"')
    except AnsibleParserError:
        pytest

# Generated at 2022-06-23 05:09:30.865263
# Unit test for function split_args
def test_split_args():
    items = []

    # test 1 - simple param
    items.append("foo=bar")
    assert split_args("foo=bar") == items

    # test 2 - simple param with spaces
    items.append("foo = bar")
    items.append("foo= bar")
    assert split_args("foo = bar") == items
    assert split_args("foo= bar") == items

    # test 3 - 2 simple params with spaces
    items.append("baz=qux")
    items.append("baz = qux")
    assert split_args("foo = bar baz=qux") == items
    assert split_args("foo= bar baz = qux") == items
    assert split_args("foo = bar baz = qux") == items

    # test 4 - quoted param
    items.append("foo=\"bar\"")

# Generated at 2022-06-23 05:09:33.911475
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', '\nc']) == 'a b\nc'
    assert join_args(['a', '\n', 'b', '\nc']) == 'a\n b\nc'



# Generated at 2022-06-23 05:09:45.185883
# Unit test for function join_args
def test_join_args():
    test_input1 = ['true', '&&', 'false']
    test_input2 = ['true', '&&', '\nfalse']
    test_input3 = ['echo', 'foo', '&&', '\n\necho', '"bar space"', '&&', '\n\necho', '\'single quotes\'']

    expected_result1 = 'true && false'
    expected_result2 = 'true && \nfalse'
    expected_result3 = 'echo foo && \n\necho "bar space" && \n\necho \'single quotes\''

    actual_result1 = join_args(test_input1)
    actual_result2 = join_args(test_input2)
    actual_result3 = join_args(test_input3)

    assert actual_result1 == expected_result1

# Generated at 2022-06-23 05:09:56.749482
# Unit test for function join_args
def test_join_args():
    assert join_args(['ls \\\n', '-l']) == 'ls \\\n   -l'
    assert join_args(['ls', '-l']) == 'ls -l'
    assert join_args(['ls \\\n', '-l \\\n', '-R']) == 'ls \\\n   -l \\\n   -R'
    assert join_args(['ls', '-l \\\n', '-R']) == 'ls -l \\\n   -R'
    assert join_args(['ls \\\n', '-l', '-R']) == 'ls \\\n   -l -R'
    assert join_args(['ls', '-l', '-R \\\n']) == 'ls -l -R \\\n'

# Generated at 2022-06-23 05:10:04.885835
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("ansible_ssh_user=root ansible_ssh_pass=hunter2") == {'ansible_ssh_pass': 'hunter2', 'ansible_ssh_user': 'root'}
    assert parse_kv("ansible_ssh_user=root ansible_ssh_pass=hunter2=3") == {'ansible_ssh_pass': 'hunter2=3', 'ansible_ssh_user': 'root'}
    assert parse_kv("ansible_ssh_user=root ansible_ssh_pass=hunter2=\"3") == {'ansible_ssh_pass': '"hunter2=3', 'ansible_ssh_user': 'root'}



# Generated at 2022-06-23 05:10:15.836491
# Unit test for function join_args
def test_join_args():
    assert join_args(('echo', 'test')) == 'echo test'
    assert join_args(('echo', 'test', 'test2')) == 'echo test test2'
    assert join_args(('echo', 'test', '\n', 'test2')) == 'echo test\n test2'
    assert join_args(('echo', 'test', '\\\n', 'test2')) == 'echo test \\ test2'
    assert join_args(('echo', '\\\n', 'test', '\\\n', 'test2')) == 'echo \\ test \\ test2'
    assert join_args(('echo', '\\\n', 'test', '\\\n', 'test2', '\n', 'test3')) == 'echo \\ test \\ test2\n test3'



# Generated at 2022-06-23 05:10:26.307774
# Unit test for function join_args
def test_join_args():
    cmd_lines = []
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "here"')
    cmd_lines.append('echo "there"')
    cmd_lines.append('echo "there"')
    cmd_lines.append('echo "there"')
    cmd_lines.append('echo "there"')

# Generated at 2022-06-23 05:10:38.570535
# Unit test for function split_args

# Generated at 2022-06-23 05:10:48.187947
# Unit test for function parse_kv