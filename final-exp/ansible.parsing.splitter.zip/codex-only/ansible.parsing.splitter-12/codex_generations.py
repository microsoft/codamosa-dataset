

# Generated at 2022-06-23 05:00:58.999377
# Unit test for function split_args

# Generated at 2022-06-23 05:01:08.183347
# Unit test for function split_args
def test_split_args():
    assert split_args("chmod 777 /path/to/a/b/c.txt") == ["chmod", "777", "/path/to/a/b/c.txt"]
    assert split_args("chmod {{ a }} /path/to/a/b/c.txt") == ["chmod", "{{", "a", "}}", "/path/to/a/b/c.txt"]
    assert split_args("echo '{{ a }}'") == ["echo", "'{{", "a", "}}'"]
    assert split_args("chmod 666 /path/to/a/b/c.txt") == ["chmod", "666", "/path/to/a/b/c.txt"]

# Generated at 2022-06-23 05:01:17.653087
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("some args") == {}
    assert parse_kv("some args", check_raw=True) == {'_raw_params': 'some args'}
    assert parse_kv("some=args") == {'some': 'args'}
    assert parse_kv("some=args", check_raw=True) == {'some': 'args'}
    assert parse_kv("some=args creates=/some/file") == {'some': 'args', 'creates': '/some/file'}
    assert parse_kv("some=args creates=/some/file", check_raw=True) == {'some': 'args', 'creates': '/some/file'}
    assert parse_kv("some=\"args\"") == {'some': '"args"'}

# Generated at 2022-06-23 05:01:20.746151
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c']) == 'a b c'
    assert join_args(['a','b','c','\nd','e','f','\ng','\th','i']) == 'a b c\nd e f\ng\th i'



# Generated at 2022-06-23 05:01:30.349631
# Unit test for function parse_kv
def test_parse_kv():
    # No Errors:
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo = bar") == {'foo': 'bar'}
    assert parse_kv("foo= bar") == {'foo': 'bar'}
    assert parse_kv("foo =bar") == {'foo': 'bar'}
    assert parse_kv("foo = bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar=baz") == {'foo': 'bar=baz'}
    assert parse_kv("foo bar=baz") == {'foo bar': 'baz'}
    assert parse_kv("foo=bar baz") == {'foo': 'bar baz'}

# Generated at 2022-06-23 05:01:36.282091
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b c', 'def', 'g']) == 'a b c def g'
    assert join_args(['\n', 'ab  c', '\ndef', 'g']) == '\nab  c\ndef g'
    assert join_args(['ab  c', '\ndef', 'g', '\n']) == 'ab  c\ndef g\n'



# Generated at 2022-06-23 05:01:41.521574
# Unit test for function parse_kv
def test_parse_kv():
    kv_string = '"foo=bar bif=baz" something=other things=things'
    options = parse_kv(kv_string)
    assert options['foo'] == 'bar'
    assert options['bif'] == 'baz'
    assert options['something'] == 'other'
    assert options['things'] == 'things'
    assert options['_raw_params'] == 'things=things'


# Generated at 2022-06-23 05:01:50.350978
# Unit test for function split_args
def test_split_args():
    def compare_result(test_str):
        parsed_str = split_args(test_str)
        reformatted_str = join_args(parsed_str)
        assert(reformatted_str == test_str)

    # test some simple cases to start
    test_str = 'a=b c="foo bar"'
    compare_result(test_str)
    test_str = 'a=b c="foo \\\'bar\\\'"'
    compare_result(test_str)
    test_str = 'a=b c="foo bar\"'
    compare_result(test_str)

    # test some spaces and newlines
    test_str = 'a=b c="foo\nbar"'
    compare_result(test_str)
    test_str = 'a=b c="foo \nbar"'

# Generated at 2022-06-23 05:02:01.076955
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar bam=baz') == {u'foo': u'bar', u'bam': u'baz'}
    assert parse_kv(u"foo='bar bam'") == {u'foo': u'bar bam'}
    assert parse_kv(u"foo='bar\\nbam'") == {u'foo': u'bar\nbam'}
    assert parse_kv(u"foo='bar\\nbam' spam=foo") == {u'foo': u'bar\nbam', u'spam': u'foo'}

# Generated at 2022-06-23 05:02:11.797990
# Unit test for function join_args

# Generated at 2022-06-23 05:02:23.353492
# Unit test for function split_args

# Generated at 2022-06-23 05:02:33.240450
# Unit test for function split_args

# Generated at 2022-06-23 05:02:42.389264
# Unit test for function split_args
def test_split_args():

    # test handling of quotes and jinja2 blocks
    assert split_args('"foo"') == ['\'foo\'']
    assert split_args('a=b \'foo bar\'') == ['a=b', '\'foo bar\'']
    assert split_args('a=b \'foo bar\'') == ['a=b', '\'foo bar\'']
    assert split_args('a=b \'{{foo}} {{bar}}\'') == ['a=b', '\'{{foo}} {{bar}}\'']
    assert split_args('a=b c="{{foo}} bar"') == ['a=b', 'c="{{foo}} bar"']
    assert split_args('a=b c="{{foo}} bar"') == ['a=b', 'c="{{foo}} bar"']

# Generated at 2022-06-23 05:02:53.112302
# Unit test for function split_args
def test_split_args():
    assert split_args('a b"c d"') == ['a', 'b"c d"']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c" d') == ['a="b c"', 'd']
    assert split_args('a="b c" d') == ['a="b c"', 'd']
    assert split_args('a="b=c" d') == ['a="b=c"', 'd']
    assert split_args('a="b=c" d=e') == ['a="b=c"', 'd=e']
    assert split_args('a="b=c" d="e f"') == ['a="b=c"', 'd="e f"']

# Generated at 2022-06-23 05:03:01.935925
# Unit test for function split_args
def test_split_args():
    argstring = "a=b foo=bar myname=\"{{something}}\""
    params = split_args(argstring)
    assert params == ['a=b', 'foo=bar', 'myname="{{something}}"']

    argstring = "a=b foo=bar myname=\"{{something}}\""
    params = split_args(argstring)
    assert params == ['a=b', 'foo=bar', 'myname="{{something}}"']

# Generated at 2022-06-23 05:03:08.148371
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c"]) == 'a b c'
    assert join_args(["a\n", "b", "c"]) == 'a\n b c'
    assert join_args(["a\n", "\n", "b\n", "c"]) == 'a\n\n b\n c'



# Generated at 2022-06-23 05:03:15.999816
# Unit test for function parse_kv
def test_parse_kv():
    assert dict(parse_kv('foo=bar')) == {u'foo': u'bar'}
    assert dict(parse_kv(' foo=bar ')) == {u'foo': u'bar'}
    assert dict(parse_kv('foo=bar  baz=qux')) == {u'foo': u'bar', u'baz': u'qux'}
    assert dict(parse_kv('foo=bar  baz=qux  ')) == {u'foo': u'bar', u'baz': u'qux'}
    assert dict(parse_kv(' foo=bar  baz=qux  ')) == {u'foo': u'bar', u'baz': u'qux'}
    # Python 2 does not support sort_keys=True in json.dumps
   

# Generated at 2022-06-23 05:03:24.912661
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import OrderedDict


# Generated at 2022-06-23 05:03:34.107730
# Unit test for function split_args
def test_split_args():
    '''
    Unit tests to make sure that we can handle the various
    different types of jinja2 blocks.
    '''

    args = """
    {{ foo }}
    {{ foo }}
    {{ foo }}
    """
    parsed = split_args(args)
    assert len(parsed) == 3, "failed to split arguments where args contain jinja2 print blocks only"
    for token in parsed:
        assert token.strip() == "{{ foo }}", "failed to split arguments where args contain jinja2 print blocks only"

    args = """
      {% foo %}
      {% foo %}
      {% foo %}
    """
    parsed = split_args(args)
    assert len(parsed) == 3, "failed to split arguments where args contain jinja2 non-print blocks only"
   

# Generated at 2022-06-23 05:03:44.306969
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar=baz') == ['foo', 'bar=baz']
    assert split_args('foo="bar baz"') == ['foo="bar baz"']
    assert split_args('foo="bar baz" bar=baz') == ['foo="bar baz"', 'bar=baz']
    assert split_args('foo="bar baz" "bar=baz"') == ['foo="bar baz"', '"bar=baz"']
    assert split_args('foo="bar baz" "bar=baz" ?\\') == ['foo="bar baz"', '"bar=baz"', '?']

# Generated at 2022-06-23 05:03:50.597450
# Unit test for function parse_kv
def test_parse_kv():
    arguments = "ip=192.168.1.1 env=TEST1=test1,TEST2=test2 env=TEST3=test3 env=TEST4=test4"
    parsed = parse_kv(arguments)
    assert parsed["ip"] == u"192.168.1.1"
    assert parsed["env"] == u"TEST1=test1,TEST2=test2,TEST3=test3,TEST4=test4"

# Function to split arguments into a list
# This is adapted from the to_list function in the utils module

# Generated at 2022-06-23 05:04:00.138854
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("src=/some/path state=directory") == {"state": "directory", "src": "/some/path"}
    assert parse_kv("mode=0644 src=/some/path") == {"mode": "0644", "src": "/some/path"}
    assert parse_kv("src=/etc/motd dest=/etc/motd backup=yes") == {"src": "/etc/motd", "backup": "yes", "dest": "/etc/motd"}
    assert parse_kv("src=/etc/motd dest=/etc/motd state=absent") == {"src": "/etc/motd", "state": "absent", "dest": "/etc/motd"}

# Generated at 2022-06-23 05:04:10.603045
# Unit test for function split_args

# Generated at 2022-06-23 05:04:19.311953
# Unit test for function split_args
def test_split_args():
    # a simple check to make sure we can handle a simple string
    assert_equal(split_args("foo bar"), [u"foo", u"bar"])

    # a simple check to make sure we can handle a single quoted string
    assert_equal(split_args("'foo bar'"), [u"'foo bar'"])

    # a simple check to make sure we can handle a double quoted string
    assert_equal(split_args("\"foo bar\""), [u"\"foo bar\""])

    # a simple check to make sure we split on newlines
    assert_equal(split_args("a=b\nc=d"), [u"a=b", u"c=d"])

    # check that we can handle an unbalanced jinja2 block

# Generated at 2022-06-23 05:04:29.831985
# Unit test for function parse_kv
def test_parse_kv():
    '''
    test_parse_kv: Tests various combinations of k=v pairs to make sure they get converted properly
    '''
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}
    # test spaces around the = sign
    assert parse_kv(' foo=bar ') == {u'foo': u'bar'}
    assert parse_kv(' foo= bar ') == {u'foo': u'bar'}
    assert parse_kv(' foo = bar ') == {u'foo': u'bar'}
    # test spaces around the k and v

# Generated at 2022-06-23 05:04:40.382882
# Unit test for function parse_kv
def test_parse_kv():
    args = [
        'Foo=bar',
        '"Baz="=Qux',
        'A="B',
        'C"=D',
        'E F=G H',
        'I=J \\"K L"=M',
        'N="O \\P"',
        '"\\"Q=R"',
        'S="T',
        'U"',
        'V=\\U"W',
        'X"',
        '"Y=\\\\Z"',
        '"=',
    ]

# Generated at 2022-06-23 05:04:51.625199
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','\n','b']) == 'a\nb'
    assert join_args(['a',' \t','b']) == 'a b'
    assert join_args(['a',' b','c']) == 'a b c'
    assert join_args(['a','b','\n','\nc']) == 'a b\n\nc'
    assert join_args(['a','b','\t','\tc']) == 'a b \tc'
    assert join_args(['a','b\t','\t','c']) == 'a b\t \tc'
    assert join_args(['a','b\t','\t','\n','c']) == 'a b\t \n c'

# Generated at 2022-06-23 05:05:02.292823
# Unit test for function join_args
def test_join_args():
    assert "foo bar" == join_args(["foo", "bar"])
    assert "foo\nbar" == join_args(["foo", "bar"], preserve_newlines=True)
    assert "foo bar" == join_args(["foo ", "\n", "bar"])
    assert "foo bar" == join_args(["foo", "  ", "\n  ", "bar"])
    assert "foo bar" == join_args(["foo", "\n", "bar"], preserve_newlines=True)
    assert "foo bar" == join_args(["foo", "\n", "bar"], preserve_newlines=False)
    assert "foo bar" == join_args(["foo", "\n  ", "bar"], preserve_newlines=False)

# Generated at 2022-06-23 05:05:11.796391
# Unit test for function split_args

# Generated at 2022-06-23 05:05:21.354096
# Unit test for function join_args
def test_join_args():
    test_data = [
        ([u'ls', u'-l'], u'ls -l'),
        ([u'ls', u'-l'], u'ls -l'),
        ([u'ls', u'-l'], u'ls -l '),
        ([u'ls', u'-l'], u'ls -l  '),
        ([u'ls', u'-l'], u'ls -l\n'),
        ([u'ls', u'-l', u'-R'], u'ls -l -R\n'),
        ([u'ls', u'-l', u'-R'], u'ls -l -R\n  '),
    ]
    for expected, input in test_data:
        output = join_args(expected)

# Generated at 2022-06-23 05:05:27.001886
# Unit test for function join_args
def test_join_args():
    '''
    Test the function join_args()
    '''
    s = """
    aaa=bbb ddd=eee
    fff=ggg
    """
    s = s.split()
    assert join_args(s) == "aaa=bbb ddd=eee\nfff=ggg"



# Generated at 2022-06-23 05:05:37.235667
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', '"hello world"']) == 'echo "hello world"'
    assert join_args(['echo \\"hello world\\"']) == 'echo "hello world"'
    assert join_args(['echo', '\\"hello world\\"']) == 'echo "hello world"'
    assert join_args(['echo', '\\"hello world\\" \\"hello world\\"']) == 'echo "hello world" "hello world"'
    assert join_args(['echo', '"hello world" "hello world"']) == 'echo "hello world" "hello world"'
    assert join_args(['echo', '\\"hello world\\" "hello world"']) == 'echo "hello world" "hello world"'

# Generated at 2022-06-23 05:05:41.763078
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello', 'world\nhello']) == 'helloworld\nhello'
    assert join_args(['hello\nworld']) == 'hello\nworld'
    assert join_args(['hello\nworld\nhello']) == 'hello\nworld\nhello'



# Generated at 2022-06-23 05:05:51.962288
# Unit test for function parse_kv
def test_parse_kv():
    testinput = b"k1=v1 k2=v2 k3='v3 is escaped with spaces' k4=\"v4 is escaped with spaces\" k5=v5=v5a k6=v6==v6a k7=v7 in quotes k8=v8 in \"quotes with escaped quote\" k9=v9 in double quotes k10=\"v10 in 'double quotes with escaped single quote'\""

    result = parse_kv(testinput, check_raw=False)

# Generated at 2022-06-23 05:06:02.325024
# Unit test for function join_args
def test_join_args():
    '''
    Unit test for function join_args
    '''
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import assertCountEqual

    assertCountEqual(join_args([]), '')
    assertCountEqual(join_args(['abc']), 'abc')
    assertCountEqual(join_args(['abc', 'def']), 'abc def')
    assertCountEqual(join_args(['abc', 'def', 'ghi']), 'abc def ghi')
    assertCountEqual(join_args(['abc\n', 'def', 'ghi']), to_bytes('abc\ndef ghi'))

# Generated at 2022-06-23 05:06:14.992943
# Unit test for function parse_kv
def test_parse_kv():
    assert dict() == parse_kv(None)
    assert dict() == parse_kv('')
    assert dict(_raw_params='true') == parse_kv('true')
    assert dict(_raw_params='-x') == parse_kv('-x')
    assert dict(_raw_params='; echo hi') == parse_kv('; echo hi')
    assert dict(_raw_params='a=b', c=u'c') == parse_kv('a=b c="c"')
    assert dict(_raw_params='a=b', c=u'c') == parse_kv('a=b c=c')
    assert dict(_raw_params='a=b', c=u'"') == parse_kv('a=b c="')

# Generated at 2022-06-23 05:06:22.661317
# Unit test for function split_args
def test_split_args():
    def _test(args, expected):
        actual = split_args(args)
        assert actual == expected, "'%s' != '%s'" % (actual, expected)
    _test("a=b", ["a=b"])
    _test("a=b c=d", ["a=b", "c=d"])
    _test("a=b 'c=d'", ["a=b", "c=d"])
    _test("a=b \"c=d\"", ["a=b", "c=d"])
    _test("a=b 'c=\"'", ["a=b", "c=\""])
    _test("{{foo}}", ["{{foo}}"])
    _test("{{foo}} bar", ["{{foo}}", "bar"])

# Generated at 2022-06-23 05:06:31.130843
# Unit test for function join_args
def test_join_args():
    assert join_args(['hello', 'world']) == 'hello world'
    assert join_args(['hello', '\nworld']) == 'hello world'
    assert join_args(['hello\n', 'world']) == 'hello world'
    assert join_args(['bullshit\n', 'world']) == 'bullshit world'
    assert join_args(['bullshit\n', '\'world\'']) == 'bullshit \'world\''
    assert join_args(['bullshit\n', '"world"']) == 'bullshit "world"'



# Generated at 2022-06-23 05:06:39.622840
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo \\ bar") == ['foo', 'bar']
    assert split_args("foo \\\n bar") == ['foo', 'bar']
    assert split_args("foo bar\\\n baz") == ['foo', 'barbaz']
    assert split_args("foo bar\\\n\n baz") == ['foo', 'bar', 'baz']
    assert split_args("foo='bar \\\n baz'") == ["foo='bar baz'"]
    assert split_args("foo='bar \\\n \\' baz'") == ["foo='bar '\\' baz'"]

# Generated at 2022-06-23 05:06:49.315150
# Unit test for function join_args
def test_join_args():
    print("test_join_args")
    assert join_args(['1', '2', '3']) == '1 2 3'
    assert join_args(['1', '2', '\n', '3']) == '1 2\n3'
    assert join_args(['1', '\n', '2', '3']) == '1\n2 3'
    assert join_args(['1', '2', '\n', '3', '\n']) == '1 2\n3\n'
    assert join_args(['\n', '1', '2', '\n', '3', '\n']) == '\n1 2\n3\n'

# Generated at 2022-06-23 05:07:00.326717
# Unit test for function split_args
def test_split_args():
    # basic example
    assert split_args(u'a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # example with escaped quotes
    assert split_args(u'a=b c="foo \\" bar"') == ['a=b', 'c="foo \\" bar"']

    # example with escaped newlines
    #assert split_args(u'a=b c="foo \\\n bar"') == ['a=b', 'c="foo \\\n bar"']

    # example with raw args and equals sign (issue #19294)
    assert split_args(u'foo -e "a=b c=\\"d e=\\"f"') == ['foo', '-e', 'a=b c="d e="f"']

    # examples with multi-blocks
    assert split

# Generated at 2022-06-23 05:07:11.846009
# Unit test for function split_args
def test_split_args():
    import ansible.utils.unsafe_proxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def ap(val):
        return ansible.utils.unsafe_proxy.AnsibleUnsafeText(val)

    def val(val):
        return val._get_unsafe_proxy()._value()

    def test_split(args, check):
        out_args = split_args(args)
        assert out_args == check, "Expected: %s Got: %s" % (check, out_args)

    test_split(ap(u'a=b c="foo bar"'), [ap(u'a=b'), ap(u'c="foo bar"')])

# Generated at 2022-06-23 05:07:22.629544
# Unit test for function split_args

# Generated at 2022-06-23 05:07:34.084758
# Unit test for function join_args
def test_join_args():
    # Using a function to test the function:
    # join_args(split_args(s)) == s
    # FIXME: make these real unit tests
    from nose.tools import assert_equal
    assert_equal(join_args(split_args('a b "c" d')), 'a b "c" d')
    assert_equal(join_args(split_args('a b "c d" e f')), 'a b "c d" e f')
    assert_equal(join_args(split_args('a b "c \\"d\\" e" f g')), 'a b "c \\"d\\" e" f g')
    assert_equal(join_args(split_args('a b "c \\"d\\" e" f g')), 'a b "c \\"d\\" e" f g')


# Generated at 2022-06-23 05:07:41.467891
# Unit test for function join_args
def test_join_args():
    s = [u'foo', u'\'bar baz\'', u'\'qux', u'quux\'']
    assert join_args(s) == u'foo \'bar baz\' \'qux quux\''
    s = [u'foo', u'bar', u'baz']
    assert join_args(s) == u'foo bar baz'
    s = [u'foo', u'', u'bar']
    assert join_args(s) == u'foo \nbar'



# Generated at 2022-06-23 05:07:52.928179
# Unit test for function split_args
def test_split_args():
    a = 'a=b c="foo bar" \\\ne=f'
    assert split_args(a) == ['a=b', 'c="foo bar"', 'e=f']
    a = "a=b c=\"foo bar\" \\\ne=f"
    assert split_args(a) == ['a=b', 'c="foo bar"', 'e=f']
    a = "a=b c=\"foo bar\" \\  \\\ne=f"
    assert split_args(a) == ['a=b', 'c="foo bar"', 'e=f']
    a = """a=b c="foo bar"
e=f"""
    assert split_args(a) == ['a=b', 'c="foo bar"', 'e=f']

# Generated at 2022-06-23 05:08:02.196075
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar', '"baz s', 'bam"']) == 'foo bar "baz s bam"'
    assert join_args(['foo', 'bar', '"baz\\"s', 'bam"']) == 'foo bar "baz\\"s bam"'
    assert join_args(['foo', 'bar', 'baz\\s', 'bam']) == 'foo bar baz\\s bam'
    assert join_args(['foo', 'bar', 'baz\\\\s', 'bam']) == 'foo bar baz\\\\s bam'
    assert join_args(['foo', 'bar', "'baz s", 'bam']) == 'foo bar \'baz s bam'

# Generated at 2022-06-23 05:08:12.082807
# Unit test for function split_args
def test_split_args():
    assert split_args(u'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u'a=b c="foo bar" d="foo\"bar"') == ['a=b', 'c="foo bar"', 'd="foo"bar"']
    assert split_args(u"a=b 'c=foo bar'") == ['a=b', "'c=foo bar'"]
    assert split_args(u"a=b 'c=foo bar' d='foo\"bar'") == ['a=b', "'c=foo bar'", "d='foo\"bar'"]

# Generated at 2022-06-23 05:08:22.497001
# Unit test for function parse_kv

# Generated at 2022-06-23 05:08:31.609732
# Unit test for function split_args

# Generated at 2022-06-23 05:08:42.091074
# Unit test for function parse_kv
def test_parse_kv():

    # Testing escaped quotes
    assert parse_kv('a=b\\"c') == {u'a': 'b"c'}

    for arg in [u'a=b', u'a=b c=d', u'a=b c="d e"', u"a=b c='d e'", u"a=b c=d\ne=f"]:
        assert parse_kv(arg) == parse_kv(arg.encode('utf-8'))

    # FIXME: the following would be better as a doctest (or just a test)

# Generated at 2022-06-23 05:08:50.175026
# Unit test for function parse_kv
def test_parse_kv():
    for inp_str, exp_res in [("a=1 b=2", {"a":"1", "b":"2"}),
                             ("a='b c' d=3", {"a":"b c", "d":"3"}),
                             ("a=1 b='c d' e=4", {"a":"1", "e":"4", "_raw_params":"b='c d'"})
                             ]:
        res = parse_kv(inp_str)
        assert res == exp_res


# Generated at 2022-06-23 05:09:01.188557
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test the parser used to split a string of key/value items into a dict.
    :return:
    '''

    # Test the simple kv case
    test_text = "k1=v1 k2=v2"
    assert parse_kv(test_text) == {u'k2': u'v2', u'k1': u'v1'}

    # Test the case where some of the parameters are not kv
    test_text = "k1=v1 k2=v2 k3 k4=v4"
    assert parse_kv(test_text) == {u'k2': u'v2', u'k1': u'v1', u'_raw_params': "k3 k4=v4"}

    # Test the case where some of the parameters have escaped equal signs


# Generated at 2022-06-23 05:09:09.604439
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {"foo": "bar"}
    assert parse_kv("foo=bar foo=baz") == {"foo": "baz"}
    assert parse_kv("foo='bar'") == {"foo": "bar"}
    assert parse_kv("foo='bar baz'") == {"foo": "bar baz"}
    assert parse_kv("foo=bar baz") == {"foo": "bar", "_raw_params": "baz"}
    assert parse_kv("foo='bar' baz") == {"foo": "bar", "_raw_params": "baz"}
    assert parse_kv("foo='bar'\\ baz") == {"foo": "bar baz"}
    assert parse_kv("foo=\"bar\"\\ baz") == {"foo": "bar baz"}




# Generated at 2022-06-23 05:09:21.028827
# Unit test for function split_args
def test_split_args():
    def compare(args, expected):
        actual = split_args(args)
        print("expected:", expected)
        print("actual  :", actual)
        assert expected == actual
    yield compare, 'foo=bar name=test', ['foo=bar', 'name=test']
    yield compare, 'chdir={{ path }} name=test', ['chdir={{ path }}', 'name=test']
    yield compare, 'creates={{ path }} name=test', ['creates={{ path }}', 'name=test']
    yield compare, 'removes={{ path }} name=test', ['removes={{ path }}', 'name=test']
    yield compare, 'chdir={{ path }} creates={{ create_path }} name=test', ['chdir={{ path }}', 'creates={{ create_path }}', 'name=test']

# Generated at 2022-06-23 05:09:26.992812
# Unit test for function join_args
def test_join_args():
    assert join_args(['p1', 'p2']) == 'p1 p2'
    assert join_args(['p1', ' p2']) == 'p1  p2'
    assert join_args(['p1', '\np2']) == 'p1\np2'
    assert join_args(['p1', '\n', 'p2']) == 'p1\np2'



# Generated at 2022-06-23 05:09:32.241872
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz="quux quuux"') == {
        'foo': 'bar',
        'baz': 'quux quuux',
        }
    assert parse_kv('foo=bar baz="quux \\" quuux"') == {
        'foo': 'bar',
        'baz': 'quux " quuux',
        }


# Generated at 2022-06-23 05:09:39.929122
# Unit test for function split_args
def test_split_args():
    """
    Test that split_args does the right thing
    """

# Generated at 2022-06-23 05:09:50.917970
# Unit test for function split_args

# Generated at 2022-06-23 05:10:01.287414
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.six import PY3
    from ansible.compat.tests import unittest

    class Tester(unittest.TestCase):
        def test_simple(self):
            data = parse_kv('one=1')
            self.assertEqual(data, {'one': '1'})

        # \= is escaped, does not break parsing
        def test_no_equals(self):
            data = parse_kv('one=1 two=2 three\=3')
            self.assertEqual(data, {'one': '1', 'two': '2', 'three=3': ''})

        def test_no_key(self):
            data = parse_kv('one=1 two=')

# Generated at 2022-06-23 05:10:12.345293
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=1') == {'a': '1'}
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=b=1') == {'a': 'b=1'}
    assert parse_kv('a="b=1"') == {'a': 'b=1'}
    assert parse_kv('a="b=1 c=2"') == {'a': 'b=1 c=2'}
    assert parse_kv("a='b=1 c=2'") == {'a': 'b=1 c=2'}

# Generated at 2022-06-23 05:10:23.510021
# Unit test for function split_args
def test_split_args():
    # test basic splitting and reassembly
    test1 = "foo bar baz"
    result1 = split_args(test1)
    assert result1 == test1.split(' ')

    # test quotes and newlines
    test2 = 'foo "bar baz"\nqux quux\nquuz qux'
    result2 = split_args(test2)
    assert result2 == test2.split(' ')

    # test jinja2 blocks and newlines
    test3 = '{{ foo }}\n{% bar %}'
    result3 = split_args(test3)
    assert result3 == test3.split(' ')

    # test empty string
    test4 = ''
    result4 = split_args(test4)
    assert result4 == ['']

    # test paired block types
    test

# Generated at 2022-06-23 05:10:32.957557
# Unit test for function parse_kv
def test_parse_kv():
    parsed_dict = parse_kv('creates=/abc/def dog=elephant')
    assert parsed_dict['dog'] == u'elephant'
    assert 'creates' not in parsed_dict

    parsed_dict = parse_kv('creates=/abc/def dog=elephant', check_raw=True)
    assert parsed_dict['dog'] == u'elephant'
    assert parsed_dict['creates'] == u'/abc/def'

#
# join_args adapted from rspeer's answer here:
# http://stackoverflow.com/questions/4020539/process-escape-sequences-in-a-string-in-python
#

# Generated at 2022-06-23 05:10:44.396072
# Unit test for function parse_kv
def test_parse_kv():
    '''
    This test case checks the parse_kv function using a set of values.
    '''
    class MyParserError(Exception):
        pass

    def my_unquote(data=''):
        return data

    def my_to_text(value, errors='strict'):
        return value

    def my_split_args(args):
        return args

    def my_join_args(args):
        return args

    my_dict = {
        'ansible': 'Ansible is great',
        'ansible_facts': 'I like Ansible facts'
    }

    my_list = ['ansible', '=', 'Ansible is great', 'ansible_facts', '=', 'I like Ansible facts']

    assert parse_kv(my_list) == my_dict

    # assert parse

# Generated at 2022-06-23 05:10:48.017434
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'foo', 'bar']) == 'echo foo bar'
    assert join_args(['echo', 'foo', '\n', 'bar']) == 'echo foo \n bar'

