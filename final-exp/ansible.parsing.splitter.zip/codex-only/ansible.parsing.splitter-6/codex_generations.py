

# Generated at 2022-06-23 05:00:59.055493
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}

    # args with one split
    assert parse_kv('var=1') == {u"var": u"1"}
    assert parse_kv('var=1', check_raw=True) == {u"var": u"1"}

    # args with multiple splits
    assert parse_kv('var=1 var2=2') == {u"var": u"1",u"var2": u"2"}
    assert parse_kv('var=1 var2=2', check_raw=True) == {u"var": u"1",u"var2": u"2"}

    # args with multiple splits, non-kv

# Generated at 2022-06-23 05:01:07.909946
# Unit test for function join_args
def test_join_args():
    test_cases = [
        (['echo', 'foo', 'bar'], 'echo foo bar'),
        (['echo', 'foo', '\nbar'], 'echo foo \nbar'),
        (['echo', 'foo', '\n', 'bar'], 'echo foo \n bar'),
        (['sudo', 'echo', 'foo', '\n', 'bar'], 'sudo echo foo \n bar'),
    ]
    for (s, result) in test_cases:
        assert join_args(s) == result



# Generated at 2022-06-23 05:01:19.928405
# Unit test for function split_args
def test_split_args():
    # Test cases with single newlines
    assert split_args(u"") == []
    assert split_args(u"a=b") == [u'a=b']
    assert split_args(u"a=b c=d") == [u'a=b', u'c=d']
    assert split_args(u"a=b c=d\ne=f g=h") == [u'a=b', u'c=d', u'e=f', u'g=h']
    assert split_args(u"a=b c=d\ne=f g=h\ni=j") == [u'a=b', u'c=d', u'e=f', u'g=h', u'i=j']


# Generated at 2022-06-23 05:01:26.051134
# Unit test for function join_args
def test_join_args():
    # Test1
    test_list = ['foo', 'bar']
    result_list = join_args(test_list)
    assert result_list == 'foo bar'
    # Test2
    test_list = ['foo', 'bar', '\n', 'baz']
    result_list = join_args(test_list)
    assert result_list == 'foo bar\nbaz'


# Generated at 2022-06-23 05:01:37.089089
# Unit test for function parse_kv
def test_parse_kv():
    # testing with single arguments, the function parse_kv should return a dict
    assert isinstance(parse_kv("foo=bar"), dict)
    assert isinstance(parse_kv("foo='bar'"), dict)
    assert isinstance(parse_kv("foo=\"bar\""), dict)
    # testing with multiple arguments, the function parse_kv should return a dict
    assert isinstance(parse_kv("foo=bar:spam=eggs"), dict)
    assert isinstance(parse_kv("foo=bar:spam='eggs'"), dict)
    assert isinstance(parse_kv("foo=bar:spam=\"eggs\""), dict)
    # testing with multiple arguments, no values to key
    assert isinstance(parse_kv("foo=:spam=eggs"), dict)
    # testing with multiple

# Generated at 2022-06-23 05:01:45.911043
# Unit test for function split_args

# Generated at 2022-06-23 05:01:50.090103
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\nbar']) == 'foo \nbar'
    assert join_args(['\nfoo', 'bar']) == '\nfoo bar'



# Generated at 2022-06-23 05:02:00.981941
# Unit test for function join_args
def test_join_args():
    samples = [
        ['foo', 'bar'],
        ['foo bar'],
        ['foo', 'bar', 'baz'],
        ['foo', 'bar', 'baz', ''],
        ['foo', 'bar', ' baz'],
        ['', 'foo bar'],
        ['', ' foo bar'],
        ['foo \n bar'],
        ['foo \n bar', 'baz'],
        ['foo \n  bar', 'baz'],
        ['foo \n  bar', '', ' baz'],
        ['foo \n \n bar', '', ' baz'],
        ['foo \n \n bar', '', ' baz\n'],
        [''],
    ]

    for sample in samples:
        result = join_args(sample)
        assert result == ' '.join

# Generated at 2022-06-23 05:02:07.851594
# Unit test for function join_args
def test_join_args():
    orig_cmd = '''arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9
    arg10 arg11 arg12 arg13 arg14 arg15 arg16 arg17 arg18
    arg19 arg20 arg21 arg22 arg23 arg24 arg25 arg26 arg27
    arg28 arg29 arg30 arg31 arg32 arg33'''
    l = split_args(orig_cmd)
    result = join_args(l)
    assert result == orig_cmd



# Generated at 2022-06-23 05:02:13.979126
# Unit test for function join_args
def test_join_args():
    def assertion(args, expectation):
        result = join_args(args)
        assert result == expectation, "Result {} does not equal expectation {}".format(result, expectation)
    assertion(['Hello'], 'Hello')
    assertion(['Hello', 'world'], 'Hello world')
    assertion(['Hello', 'world\n'], 'Hello\nworld\n')
    assertion(['Hello', 'world\n', 'How are you\n'], 'Hello\nworld\nHow are you\n')



# Generated at 2022-06-23 05:02:24.740828
# Unit test for function split_args
def test_split_args():
    assert split_args(" a=b c=\"foo bar\" ") == ['a=b', 'c="foo bar"']
    assert split_args(" a=\"foo {{ bar }} \" ") == ['a="foo {{ bar }} "']
    assert split_args("a={{ b }}") == ['a={{ b }}']
    assert split_args("a=\"{{ b }}\"") == ['a="{{ b }}"']
    assert split_args("a=\"{{ b }}\" c={{ d }}") == ['a="{{ b }}"', 'c={{ d }}']
    assert split_args("a=b c=\"foo {{ bar }}\" ") == ['a=b', 'c="foo {{ bar }}"']

# Generated at 2022-06-23 05:02:37.684370
# Unit test for function split_args
def test_split_args():
    u'''
    This test suite raises the following error when the test fails.
    The details of the error is not very interesting, so we pass
    in stdin, stdout and stderr as shown below.
    '''
    # set locale to UTF-8 as "\u" is used in the test string
    #locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')

    import sys
    import unittest
    import io
    import os

    class TestSplitArgs(unittest.TestCase):
        def setUp(self):
            self.split_args = split_args


# Generated at 2022-06-23 05:02:44.012502
# Unit test for function split_args
def test_split_args():
    import copy
    import pickle
    import codecs
    input_args = b'a=b c="foo bar"'
    python_result = split_args(input_args)
    # Write out the result of the python split_args using the pickle module
    with open('python_result.pkl', 'wb') as outfile:
        pickle.dump(python_result, outfile)
    # Read in the result of the perl version of split_args
    with codecs.open('perl_result.pkl', 'rb', encoding='utf-8') as infile:
        perl_result = pickle.load(infile)
    # Compare the results, should be equal
    assert python_result == perl_result


# Generated at 2022-06-23 05:02:54.383635
# Unit test for function split_args

# Generated at 2022-06-23 05:03:05.440052
# Unit test for function join_args
def test_join_args():
    assert join_args(['echo', 'a', 'b', 'c']) == 'echo a b c'
    assert join_args(['echo "Hello World"']) == 'echo "Hello World"'
    assert join_args(['echo', '"Hello World"']) == 'echo "Hello World"'
    assert join_args(['echo', 'Hello World']) == 'echo Hello World'
    assert join_args(['echo', '"Hello', 'World"']) == 'echo "Hello World"'
    assert join_args(['echo', '"Hello \' World"']) == 'echo "Hello \' World"'
    assert join_args(['echo', '"Hello', 'World"', '&&', 'echo', 'Goodbye']) == 'echo "Hello World" && echo Goodbye'

# Generated at 2022-06-23 05:03:20.496185
# Unit test for function split_args
def test_split_args():
    assert split_args(u'foo') == [u'foo']
    assert split_args(u'foo "bar baz"') == [u'foo', u'"bar baz"']
    assert split_args(u'foo "bar \\"baz\\""') == [u'foo', u'"bar \\"baz\\""']
    assert split_args(u'foo "bar baz" qux') == [u'foo', u'"bar baz"', u'qux']
    assert split_args(u'foo "bar baz" qux') == [u'foo', u'"bar baz"', u'qux']
    assert split_args(u'foo=bar name="baz qux"') == [u'foo=bar', u'name="baz qux"']

# Generated at 2022-06-23 05:03:30.563676
# Unit test for function split_args
def test_split_args():
    assert split_args(r'''hello "world" this\'s "a a a \'a\' \'a\' a a"''') == ['hello', 'world', r"this\'s", r"a a a \'a\' \'a\' a a"]
    assert split_args(r'''hello "world" "this's" "a a a \'a\' \'a\' a a"''') == ['hello', 'world', r"this's", r"a a a \'a\' \'a\' a a"]
    assert split_args(r'''hello "world" this\'s "a a a \'a\' \'a\' \"a\" \"a\" a a"''') == ['hello', 'world', r"this\'s", r"a a a \'a\' \'a\' \"a\" \"a\" a a"]

# Generated at 2022-06-23 05:03:37.892080
# Unit test for function parse_kv
def test_parse_kv():
    from nose.tools import assert_equals
    # Simple key=value
    assert_equals(
        {'name': 'ansible'},
        parse_kv('name=ansible', check_raw=False)
    )

    # Multiple key=value pairs
    assert_equals(
        {'name': 'ansible', 'state': 'present'},
        parse_kv('name=ansible state=present', check_raw=False)
    )

    # Quoted args
    assert_equals(
        {'name': 'ansible test'},
        parse_kv('name="ansible test"', check_raw=False)
    )

    # Multiple quoted args

# Generated at 2022-06-23 05:03:47.170936
# Unit test for function split_args
def test_split_args():
    def do_test(args, expected):
        result = join_args(split_args(args))
        assert result == expected, "split_args did not work on %r" % args
    do_test("'foo' \"bar\"", "foo bar")
    do_test('a=b c="foo bar"', 'a=b c="foo bar"')
    do_test("a=b c='foo bar'", "a=b c='foo bar'")
    do_test("a=b c=\"foo bar\"", 'a=b c="foo bar"')
    do_test("a=b c=\"foo bar ", 'a=b c="foo bar ')
    do_test("a=b c=\"foo\nbar\"", "a=b c=\"foo\nbar\"")

# Generated at 2022-06-23 05:03:57.633041
# Unit test for function join_args
def test_join_args():
    '''
    Tests if the function can correctly split and join the arguments
    '''
    # Test with a simple string
    s = 'simple string'
    assert join_args(split_args(s)) == s

    # Test with a string with escaped quotes
    s = '\\"escaped quotes\\"'
    assert join_args(split_args(s)) == s

    # Test with a string with non escaped quotes
    s = '"non escaped quotes"'
    assert join_args(split_args(s)) == s

    # Test with a string with quotes at the start and end
    s = '"quotes at end and start" outer quotes'
    assert join_args(split_args(s)) == s



# Generated at 2022-06-23 05:04:01.801988
# Unit test for function join_args
def test_join_args():
    test_str = '\t     test\tstring \t\\\nwith\nvarious escaped and\nnon-escaped \\\ncharacters\n'
    if join_args(split_args(test_str)) != test_str:
        print("ERROR: join_args did not return original string as expected.")



# Generated at 2022-06-23 05:04:08.515051
# Unit test for function split_args
def test_split_args():
    '''
    This function is a unit test for the split_args function 
    '''
    # a test case dictionary with the following keys:
    # args : the argument string to test
    # result : the 'correct' output of the function

# Generated at 2022-06-23 05:04:18.920003
# Unit test for function split_args
def test_split_args():

    # test jinja2 blocks
    assert split_args('') == []
    assert split_args('foo bar') == ['foo bar']
    assert split_args('foo {% bar %}') == ['foo', '{% bar %}']
    assert split_args('{% foo %} bar') == ['{% foo %}', 'bar']
    assert split_args('foo {% bar %} baz') == ['foo', '{% bar %}', 'baz']
    assert split_args('foo {% bar %} baz {% qux %}') == ['foo', '{% bar %}', 'baz', '{% qux %}']
    assert split_args('{% foo %} bar {% baz %}') == ['{% foo %}', 'bar', '{% baz %}']

# Generated at 2022-06-23 05:04:28.806502
# Unit test for function parse_kv
def test_parse_kv():
    '''
    For a given key-value pair string, parse_kv()
    should return a dict with the key-value pair
    '''
    args = 'key=value'
    assert parse_kv(args)['key'] == 'value'

    args = 'key = value'
    assert parse_kv(args)['key'] == 'value'

    args = ' key = value'
    assert parse_kv(args)['key'] == 'value'

    args = ' key =value'
    assert parse_kv(args)['key'] == 'value'

    # test newline in string values
    args = 'key = value1\nvalue2'
    assert parse_kv(args)['key'] == 'value1\nvalue2'

    # test escaping spaces

# Generated at 2022-06-23 05:04:35.301206
# Unit test for function join_args
def test_join_args():
    test_str = ("hello\ngoodbye\n"
                "hello goodbye\n"
                "hello  goodbye\n"
                "  hello  goodbye  \n"
                "hello goodbye\n"
                "hello 'goodbye'\n"
                "hello \"goodbye\"\n"
                "goodbyes \n"
                "goodbyes\n")

    l = test_str.split('\n')
    result = join_args(l)
    assert result == test_str, 'join_args(split_args()) should return original string'



# Generated at 2022-06-23 05:04:38.679942
# Unit test for function join_args
def test_join_args():
    assert join_args(['arbitrary', 'string']) == 'arbitrary string'
    assert join_args(['string', 'string\n', 'string']) == 'string string\n string'
    assert join_args(['string', '  string\n', 'string']) == 'string   string\n string'



# Generated at 2022-06-23 05:04:41.642318
# Unit test for function join_args
def test_join_args():
    assert join_args(['a b', 'c d']) == 'a b c d'
    assert join_args(['a\nb', 'c d']) == 'a\nb c d'


# Generated at 2022-06-23 05:04:44.591760
# Unit test for function join_args
def test_join_args():
    test_cmd = ['echo', '$HOME', '"abc def"', '\\', '\'abc\n def\'']
    print(join_args(test_cmd))

# Generated at 2022-06-23 05:04:55.879419
# Unit test for function parse_kv
def test_parse_kv():

    class test_entries:
        def __init__(self, val, res):
            self.val = val
            self.res = res

    # test data
    entries = [
        test_entries("a=1 b=\\=3 c='d e' d=\"f g\"", {'a': '1', 'b': '=3', 'c': 'd e', 'd': 'f g'}),
        test_entries("a=1 b=\\=3 c='d e' d=\"f g", {'a': '1', 'b': '=3', 'c': "d e' d=\"f g"}),
        test_entries("a='b c'\"d e\" f=3", {'a': 'b c"d e', 'f': '3'}),
    ]


# Generated at 2022-06-23 05:05:07.229768
# Unit test for function split_args

# Generated at 2022-06-23 05:05:18.624196
# Unit test for function split_args
def test_split_args():
    import sys
    import nose
    import pprint
    import json

    def check(actual, expected):
        if actual != expected:
            pprint.pprint({'actual': actual, 'expected': expected})
            raise Exception()


# Generated at 2022-06-23 05:05:26.591041
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b\nc=d') == ['a=b', 'c=d']
    assert split_args('a=b\n\nc=d') == ['a=b', 'c=d']
    assert split_args('a=b \nc=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d e=f') == ['a=b', 'c=d', 'e=f']
    assert split_args('a=b "c=d e=f"') == ['a=b', '"c=d e=f"']

# Generated at 2022-06-23 05:05:36.884853
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=b c='d e' f=\"g h\"") == {u"a": u"b", u"c": u"d e", u"f": u"g h"}
    assert parse_kv(u"a='b c' d=\"e f\"") == {u"a": u"b c", u"d": u"e f"}
    assert parse_kv(u"a='b c' d=\"e f\"", check_raw=True) == {u"a": u"b c", u"d": u"e f", u"_raw_params": u"a='b c' d=\"e f\""}

# Generated at 2022-06-23 05:05:45.136201
# Unit test for function join_args
def test_join_args():
    from ..lookup.core import _get_lookup_plugin_for_term
    lookup = _get_lookup_plugin_for_term('')

    # Test normal split/join
    s = [u'arg1', u'arg2', u'arg3']
    joined = join_args(s)
    assert ' '.join(s) == joined
    assert s == lookup._split_args(joined)

    # Test newlines in the joined args
    joined = join_args([u'a1', u'a\n2', u'a3'])
    assert 'a1 a\n2 a3' == joined
    assert s == lookup._split_args(joined)

    # Test newlines in the joined args
    joined = join_args([u'a1', u'a\n2', u'a3'])

# Generated at 2022-06-23 05:05:53.410674
# Unit test for function split_args
def test_split_args():
    debug = False
    import os
    from collections import namedtuple
    test_path = os.path.dirname(os.path.realpath(__file__))
    tests = []
    Test = namedtuple('Test', ['input', 'expected'])
    input_file = open(os.path.join(test_path, 'split_args_input.txt'), 'rU')
    output_file = open(os.path.join(test_path, 'split_args_output.txt'), 'rU')
    while True:
        try:
            input_line = input_file.next()
            output_line = output_file.next()
            tests.append(Test(input=input_line, expected=output_line))
        except:
            break


# Generated at 2022-06-23 05:06:03.125061
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule

    # In order to get the best results:
    # 1. Use the 'argspec' parameter in AnsibleModule
    # 2. Include '_ansible_args' in the returned value of the function under test (in this case 'action' since that's what's usually returned)
    # 3. Use the format of the output of parse_kv()
    # NOTE: If you provide an 'argspec' to AnsibleModule, any args not listed in the argspec will end up in the '_raw_params' field of the result from parse_kv()
    # NOTE: If the dictionary returned from parse_kv() is used as kwargs to AnsibleModule, then the _ansible_args field is ignored. It

# Generated at 2022-06-23 05:06:12.929514
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('this=that') == dict(this='that')
    assert parse_kv('this="that"') == dict(this='that')
    assert parse_kv('this="that=""this""') == dict(this='that="this"')
    assert parse_kv('this="that=this"') == dict(this='that=this')
    assert parse_kv('this=that this=other') == dict(this='other')
    assert parse_kv(u'a="b"') == dict(a='b')
    assert parse_kv(u'a="b" c d') == dict(a='b', _raw_params=u'c d')
    assert parse_kv(u'a="b" c=d') == dict(a='b', c='d')
    assert parse_

# Generated at 2022-06-23 05:06:23.257906
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=quux") == dict(foo='bar', baz='quux')
    assert parse_kv("foo=bar baz=quux", check_raw=True) == dict(foo='bar', baz='quux', _raw_params=u'foo=bar baz=quux')
    assert parse_kv("a b c=d e f=g") == dict(c='d', f='g')
    assert parse_kv("a b c=d e f=g", check_raw=True) == dict(c='d', f='g', _raw_params=u'a b c=d e f=g')
    assert parse_kv(u"foo='bar baz' blah=blah") == dict(foo='bar baz', blah='blah')
   

# Generated at 2022-06-23 05:06:31.308457
# Unit test for function join_args
def test_join_args():
    import pprint

# Generated at 2022-06-23 05:06:42.471110
# Unit test for function split_args
def test_split_args():
    def do_test_split_args(args, expected):
        results = split_args(args)
        assert results == expected, "splitting [{0}] failed: expected {1}, got {2}".format(args, expected, results)

    do_test_split_args("foo=bar baz=zip", ['foo=bar', 'baz=zip'])
    do_test_split_args("hello world", ['hello', 'world'])
    do_test_split_args("hello world", ['hello', 'world'])
    do_test_split_args("hello=world", ['hello=world'])
    do_test_split_args("foo='bar baz'", ["foo='bar baz'"])
    do_test_split_args("foo=\"bar baz\"", ['foo="bar baz"'])

# Generated at 2022-06-23 05:06:51.381475
# Unit test for function split_args
def test_split_args():
    """
    Run unit test for function split_args()
    """
    import sys
    import os
    import unittest
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), u".."))

    class TestSplitArgs(unittest.TestCase):
        """
        Test split_args()
        """
        maxDiff = None

        def test_split_args(self):
            """
            Test split_args()
            """

            # Simple split without quotes
            args1 = u"one two three four"
            expected1 = [u"one", u"two", u"three", u"four"]
            result1 = split_args(args1)
            self.assertEquals(expected1, result1)

            # Split with quotes

# Generated at 2022-06-23 05:06:54.494071
# Unit test for function join_args
def test_join_args():
    test = ['a', 'b', '\nc', '\n  d']
    assert join_args(test) == 'a b\nc\n  d'


# Generated at 2022-06-23 05:07:02.974296
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test of function parse_kv

    Test different types of key-value pairs as well as values with embedded
    quotes and escaped quotes.
    '''
    from ansible.parsing.vault import VaultLib
    import sys

    # Need to do this because this is not being run as ansible-test
    vault_secret = VaultLib(password_filename='test/test_vault.txt')
    vault_secret.secrets_to_file('test/test_vault.txt')


# Generated at 2022-06-23 05:07:13.809633
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar", check_raw=False) == {u'foo': u'bar'}
    assert parse_kv("foo='bar'", check_raw=False) == {u'foo': u'bar'}
    assert parse_kv("foo='bar bam'", check_raw=False) == {u'foo': u'bar bam'}
    assert parse_kv("foo=\"bar bam\"", check_raw=False) == {u'foo': u'bar bam'}
    assert parse_kv("foo=bar bam", check_raw=False) == {u'foo': u'bar', u'_raw_params': u'bam'}

# Generated at 2022-06-23 05:07:24.026408
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Basic unit test for the parse_kv function.
    '''
    import sys

    # Support Python 2.6, which doesn't have the assertDictEqual method
    # in its unittest module.
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestParseKV(unittest.TestCase):
        '''
        Test class for parse_kv function.
        '''
        def test_parse_kv_none(self):
            '''
            Test that parse_kv returns an empty dict when passed None.
            '''
            result = parse_kv(None)
            self.assertDictEqual(result, {})


# Generated at 2022-06-23 05:07:34.490452
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a b']) == 'a b'
    assert join_args(['a b c']) == 'a b c'
    assert join_args(['a b c\n', 'd e f']) == 'a b c\nd e f'
    assert join_args(['a b c\n', '\nd e f']) == 'a b c\n\nd e f'
    assert join_args(['a b c\n', '\nd e f\n', 'g']) == 'a b c\n\nd e f\ng'

# Generated at 2022-06-23 05:07:40.672813
# Unit test for function join_args
def test_join_args():
    assert join_args(['a','b','c'])=='a b c'
    assert join_args(['a','b','c','\n','d','e','f'])=='a b c\n d e f'
    assert join_args(['a','b','c','\n','\n','d','e','f'])=='a b c\n\n d e f'



# Generated at 2022-06-23 05:07:48.085049
# Unit test for function join_args
def test_join_args():
    s = ['echo', 'hi', 'there']
    result = join_args(s)
    assert result == 'echo hi there'

    s = ['echo', 'hi\nthere']
    result = join_args(s)
    assert result == 'echo\nhi\nthere'

    s = ['echo', 'hi\nthere', 'how', 'are', 'you']
    result = join_args(s)
    assert result == 'echo\nhi\nthere how are you'



# Generated at 2022-06-23 05:07:57.794449
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', 'b']) == 'a b')
    assert(join_args(['a', 'b', 'c']) == 'a b c')
    assert(join_args(['a', 'b', 'c ']) == 'a b c ')
    assert(join_args(['a ', 'b', 'c']) == 'a b c')
    assert(join_args(['a', 'b', 'c ']) == 'a b c ')
    assert(join_args(['a', 'b', '\nc']) == 'a b\nc')
    assert(join_args(['a', 'b', '\n', 'c']) == 'a b\n c')

# Generated at 2022-06-23 05:08:05.814454
# Unit test for function parse_kv
def test_parse_kv():
    # Simple test of 'key=value'
    assert parse_kv('foo=bar') == {u'foo': u'bar'}

    # Test with option requiring quoting
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}

    # Test with a single positional parameter
    assert parse_kv('foo') == {u'_raw_params': u'foo'}
    assert parse_kv('"foo"') == {u'_raw_params': u'"foo"'}

    # Test with option with an embedded equals sign
    assert parse_kv(r'foo=foo\=bar') == {u'foo': u'foo=bar'}

    # Test with positional parameter with an embedded equals sign

# Generated at 2022-06-23 05:08:17.194608
# Unit test for function parse_kv
def test_parse_kv():
    kv_string1 = "key1=value1 key2=value2 key3=value3"
    kv_string2 = "key1=value1 key2=value2 key3=value3 key4=value4"
    kv_string3 = "key1=\"value1\" key2=\"value2\" key3=\"value3\""
    kv_string4 = "key1=\"value1\" key2=\"value2\" key3=\"value3\" key4=\"value4\""
    kv_string5 = "key1=\"value1 value2\" key2=\"value3 value4\" key3=value5"
    kv_string6 = "key1=\"value1\" key2=\"value2"
    kv_string7 = "key1='value1' key2='value2'"

# Generated at 2022-06-23 05:08:28.216378
# Unit test for function split_args
def test_split_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes

    def t(s, expected):
        result = split_args(s)
        assert result == expected, (s, expected, result)


# Generated at 2022-06-23 05:08:39.770793
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.text_compat import StringIO

    #
    # Test cases
    #

# Generated at 2022-06-23 05:08:52.111129
# Unit test for function split_args
def test_split_args():
    test_string = '''\
{{ one }} {{ two }}
{{ three }}

four="five"
six=seven
eight="nine ten"
'''
    result = split_args(test_string)
    assert result == [
        '{{', 'one', '}}', '{{', 'two', '}}', '{{', 'three', '}}',
        'four="five"', 'six=seven', 'eight="nine ten"'
    ]

    assert join_args(result) == test_string

    test_string = '''\
{% foo %}
'''
    result = split_args(test_string)
    assert result == [
        '{%', 'foo', '%}'
    ]

    assert join_args(result) == test_string


# Generated at 2022-06-23 05:08:54.484235
# Unit test for function join_args
def test_join_args():
    assert join_args(["p1", "p2", "p3"]) == "p1 p2 p3"



# Generated at 2022-06-23 05:09:05.704493
# Unit test for function split_args

# Generated at 2022-06-23 05:09:16.092894
# Unit test for function parse_kv
def test_parse_kv():
    print('\nUnit test for function parse_kv')
    print(parse_kv(''))
    print(parse_kv('a=1'))
    print(parse_kv('a=1 b=2'))
    print(parse_kv('a="1" b="c=d"'))
    print(parse_kv('a="1" b="c=d e=f\"" g=h'))
    print(parse_kv('a="1" b="c=d e=f\"" g=h', check_raw=True))
    print(parse_kv('a="1" b=c=d'))
    print(parse_kv('a=b c=d'))

# Generated at 2022-06-23 05:09:26.493454
# Unit test for function parse_kv
def test_parse_kv():
    #Single argument with quoted equals
    args = parse_kv(u'foo="bar=baz"')
    assert args[u'foo'] == u'bar=baz'
    #Single argument with unquoted equals
    args = parse_kv(u'foo=bar=baz')
    assert args[u'foo'] == u'bar=baz'
    #Single argument with non-escaped equals
    args = parse_kv(u'foo=bar\=baz')
    assert args[u'foo'] == u'bar=baz'
    #Single argument with escaped equals
    args = parse_kv(u'foo=bar\\=baz')
    assert args[u'foo'] == u'bar\\=baz'
    #Single argument with escaped and quoted equals

# Generated at 2022-06-23 05:09:37.041887
# Unit test for function join_args
def test_join_args():
    assert(join_args(['foo', 'bar', 'baz']) == 'foo bar baz')
    assert(join_args(['foo', 'bar', '\nbaz']) == 'foo bar\nbaz')
    assert(join_args(['foo', '\nbar', 'baz']) == 'foo\nbar baz')
    assert(join_args(['foo', '\n\nbar']) == 'foo\n\nbar')
    assert(join_args(['foo', '\nbar\nbaz']) == 'foo\nbar\nbaz')
    assert(join_args(['foo', '\n\nbar\nbaz']) == 'foo\n\nbar\nbaz')

# Generated at 2022-06-23 05:09:45.705150
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b', 'Should join args with spaces'
    assert join_args(['a', 'b', 'c']) == 'a b c', 'Should join args with spaces'
    assert join_args(['a', '\n', '\n', 'b']) == 'a \n \n b', 'Should join args with spaces'
    assert join_args(['a', '\n', '\n', 'b', '\n', 'c']) == 'a \n \n b \n c', 'Should join args with spaces'



# Generated at 2022-06-23 05:09:56.944906
# Unit test for function split_args

# Generated at 2022-06-23 05:10:07.657210
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "foo bar" "foo bar"') == ['foo', 'bar', '"foo bar"', '"foo bar"']
    assert split_args('a=b c="foo bar" d="foo \\"bar\\" baz"') == ['a=b', 'c="foo bar"', 'd="foo \\"bar\\" baz"']
    assert split_args("foo bar 'foo bar' 'foo bar'") == ['foo', 'bar', "'foo bar'", "'foo bar'"]

# Generated at 2022-06-23 05:10:17.998481
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import ansible
    test_dir = os.path.dirname(os.path.realpath(__file__))
    module_utils_dir = os.path.dirname(test_dir)
    module_lib_dir = os.path.dirname(module_utils_dir)
    msg = "looked for %s in %s,%s,%s" % (
        'ansible/module_utils/basic.py',
        test_dir, module_utils_dir, module_lib_dir)
    try:
        from ansible.module_utils.basic import AnsibleModule
    except ImportError:
        module = None
        print(msg)
    import pytest
    from ansible.module_utils.basic import AnsibleModule, split_args


# Generated at 2022-06-23 05:10:23.718521
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo']) == 'foo'
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo\n']) == 'foo\n'
    assert join_args(['foo', '\n']) == 'foo \n'
    assert join_args(['foo', 'bar\n']) == 'foo bar\n'



# Generated at 2022-06-23 05:10:26.269704
# Unit test for function join_args
def test_join_args():
    assert(join_args(['a', 'b']) == 'a b')
    assert(join_args(['a', '\nb']) == 'a\nb')



# Generated at 2022-06-23 05:10:35.391791
# Unit test for function split_args
def test_split_args():
        _MULTI_ITEM_CASES = [
            {
                'input': 'a=b c="foo bar"',
                'output': ['a=b', 'c="foo bar"'],
            }
        ]


# Generated at 2022-06-23 05:10:46.152982
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test function parse_kv
    '''
    assert parse_kv("a=1 x=2") == {"a": "1", "x": "2"}
    assert parse_kv("a=1,x=2") == {"a": "1", "x": "2"}
    assert parse_kv("a=1;x=2") == {"a": "1", "x": "2"}
    assert parse_kv("a=1; x=2") == {"a": "1", "x": "2"}
    assert parse_kv("a=1\\=2 x=2") == {"a": "1=2", "x": "2"}

# Generated at 2022-06-23 05:10:55.193204
# Unit test for function join_args