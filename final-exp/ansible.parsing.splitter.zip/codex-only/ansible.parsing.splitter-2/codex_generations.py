

# Generated at 2022-06-23 05:00:54.039853
# Unit test for function join_args

# Generated at 2022-06-23 05:00:58.907571
# Unit test for function join_args
def test_join_args():
    arg = ["mystring1", "mystring2", "mystring3\n", "mystring4\n", "mystring5"]
    cmd = join_args(arg)
    assert cmd == "mystring1 mystring2 mystring3\nmystring4\nmystring5"



# Generated at 2022-06-23 05:01:08.102619
# Unit test for function parse_kv

# Generated at 2022-06-23 05:01:12.824486
# Unit test for function join_args
def test_join_args():
    s = ['hello', 'world', '\n', 'hi', 'there']
    expected_return = 'hello world\nhi there'
    assert join_args(s) == expected_return



# Generated at 2022-06-23 05:01:21.304558
# Unit test for function parse_kv
def test_parse_kv():
    ''' helper function for unit testing without pytest, coverage etc. '''
    import glob
    import json
    import os

    for path in glob.glob(
        os.path.join(os.path.dirname(__file__), 'parse_kv', '*.json')
    ):
        with open(path) as f:
            data = json.loads(to_text(f.read()))

        actual = parse_kv(data['cmdline'], data['check_raw'])

        # For debugging test failures.
        if actual != data['expected']:
            with open(path + '.actual', 'w') as f:
                f.write(json.dumps(actual, indent=2, sort_keys=True))

        assert actual == data['expected']



# Generated at 2022-06-23 05:01:31.216356
# Unit test for function split_args
def test_split_args():
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ['input', 'output'])


# Generated at 2022-06-23 05:01:35.125808
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a\n  b']) == 'a\n  b'



# Generated at 2022-06-23 05:01:45.143917
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"test=test me=me")[u'test'] == u'test'
    assert parse_kv(u"test=test\ me=me")[u'test'] == u'test me'
    assert parse_kv(u'test="test me"')[u'test'] == u'test me'
    assert parse_kv(u"test='test me'")[u'test'] == u'test me'
    assert parse_kv(u'test=\'test "me"\'')[u'test'] == u'test "me"'
    assert parse_kv(u"test=test\=me")[u'test'] == u'test=me'
    assert parse_kv(u'test=t\\est me')[u'test'] == u't\\est me'


# Generated at 2022-06-23 05:01:54.950082
# Unit test for function split_args

# Generated at 2022-06-23 05:02:08.353203
# Unit test for function join_args
def test_join_args():
    '''
    Validate the join_args() function
    '''
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\n', '"', 'b']) == 'a\n " b'
    assert join_args(['a\n', '"', 'b\n']) == 'a\n " b\n'
    assert join_args(['a\n', '"', 'b\n', '"', 'c']) == 'a\n " b\n " c'
    assert join_args(['a\n', '"', 'b\n', '"', 'c\n']) == 'a\n " b\n " c\n'



# Generated at 2022-06-23 05:02:20.882667
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"key=value") == {u"key": u"value"}
    assert parse_kv(u"key=\"value") == {u"key": u"value"}
    assert parse_kv(u"key=\"value\"") == {u"key": u"value"}
    assert parse_kv(u"key=\"value\" key2=value2") == {u"key": u"value", u"key2": u"value2"}
    assert parse_kv(u"key=\"value\"     key2=value2") == {u"key": u"value", u"key2": u"value2"}
    assert parse_kv(u"key='value'") == {u"key": u"value"}

# Generated at 2022-06-23 05:02:31.553430
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    def t(input, expected):
        result = split_args(input)
        module.assertEqual(result, expected, u'input: %s' % input)
        module.assertEqual(join_args(result), input, u'input: %s' % input)

    t('foo=bar bar=baz', ["foo=bar", "bar=baz"])
    t('foo=bar bar=baz \\\nqux=quux', ["foo=bar", "bar=baz", "qux=quux"])
    t('foo=bar bar=baz \\\n\\\nbif=baz', ["foo=bar", "bar=baz", "bif=baz"])


# Generated at 2022-06-23 05:02:40.550399
# Unit test for function parse_kv
def test_parse_kv():
    for (input, expected_output) in [
        ('foo=bar',                     {'foo': 'bar'}),
        ('foo="bar baz"',               {'foo': 'bar baz'}),
        ('foo=bar  baz=qux',            {'foo': 'bar', 'baz': 'qux'}),
        ('key=val =foo="baz bar" baz',  {'key': 'val', '_raw_params': '=foo="baz bar" baz'}),
        ('foo bar baz',                 {'_raw_params': 'foo bar baz'}),
        ('',                            {}),
    ]:
        output = parse_kv(input)
        assert output == expected_output, '%r != %r' % (output, expected_output)



# Generated at 2022-06-23 05:02:51.937833
# Unit test for function join_args
def test_join_args():
    s = ['a', ' ', 'b', '\n', 'c', 'd']
    assert join_args(s) == 'a b\nc d'
    s = ['abcd']
    assert join_args(s) == 'abcd'
    s = ['a', 'b', 'c\nd']
    assert join_args(s) == 'a b c\nd'
    s = ['a', 'b', 'c', '\nd']
    assert join_args(s) == 'a b c\nd'
    s = ['a', 'b', 'c\n', 'd']
    assert join_args(s) == 'a b c\nd'
    s = ['a', '\n', 'b', '\nd']
    assert join_args(s) == 'a\nb\nd'
    s

# Generated at 2022-06-23 05:03:00.406491
# Unit test for function parse_kv
def test_parse_kv():
    def test(s, r):
        if parse_kv(s) != r:
            raise Exception('fail')


# Generated at 2022-06-23 05:03:10.862596
# Unit test for function join_args
def test_join_args():
    assert join_args(['1', '\n2 3']) == '1\n2 3'
    assert join_args(['1', '2 3']) == '1 2 3'
    assert join_args(['\n1', '\n\n2 3']) == '\n1\n\n2 3'
    assert join_args(['\n1', '\n\n2 3', '\n\n']) == '\n1\n\n2 3\n\n'
    assert join_args([]) == ''
    assert join_args(['\n']) == '\n'



# Generated at 2022-06-23 05:03:21.729679
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}

    # Make sure that one can pass an empty string to a string
    # parameter without causing an error
    assert parse_kv('creates=') == {'creates': ''}

    assert parse_kv('a=simple b="with space" c="weird=test" d="quote=\\"test\\"" e="backslash=\\\\test"') == \
        {u'a': u'simple', u'b': u'with space', u'c': u'weird=test', u'd': u'quote="test"', u'e': u'backslash=\\test'}

    assert parse_kv('a=complex b="whitespace=  \t \r \n" c="weird= test"')

# Generated at 2022-06-23 05:03:32.097343
# Unit test for function split_args

# Generated at 2022-06-23 05:03:43.017643
# Unit test for function join_args
def test_join_args():
    # Leading newline
    assert join_args(['\n']) == '\n'
    assert join_args(['\n', 'a']) == '\na'
    assert join_args(['\n', 'a', 'b']) == '\na b'
    assert join_args(['\n', 'a', 'b', 'c']) == '\na b c'
    # Leading newlines
    assert join_args(['\n\n']) == '\n\n'
    assert join_args(['\n\n', 'a']) == '\n\na'
    assert join_args(['\n\n', 'a', 'b']) == '\n\na b'
    # No leading newlines
    assert join_args(['a']) == 'a'
    assert join

# Generated at 2022-06-23 05:03:56.283068
# Unit test for function split_args
def test_split_args():
    # Don't import this in the module so that this test can run without the
    # unified module_utils
    from ansible.module_utils import basic

    def run_test(args, expect):
        result = split_args(args)
        if expect != result:
            print("Test failed: expected: %s, got %s" % (expect, result))

    def run_test_join_args(args, expect):
        result = join_args(args)
        if expect != result:
            print("Test failed: expected: %s, got %s" % (expect, result))

    print("Testing for split_args and join_args")
    # There are many more cases to test, but this is a reasonable start.
    #
    # Note that all of the arguments are only using space as a separator
    # so newlines

# Generated at 2022-06-23 05:04:06.746697
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\\\\bar"') == ['a=b', 'c="foo\\\\bar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']
    assert split_args('a=b c=foo\\\\\\bar') == ['a=b', 'c=foo\\\\\\bar']
    assert split_args('a=b c="foo\\"bar" d=e') == ['a=b', 'c="foo\\"bar"', 'd=e']

# Generated at 2022-06-23 05:04:15.735289
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ""
    assert join_args(["a"]) == "a"
    assert join_args(["a", "b"]) == "a b"
    assert join_args(["a\n", "b"]) == "a\nb"
    assert join_args(["a\n", "b", "c"]) == "a\nb c"
    assert join_args(["a\n", "b", "c\n", "d"]) == "a\nb c\nd"
    assert join_args(["a\n", "b", "c\n\n", "d"]) == "a\nb c\n\nd"



# Generated at 2022-06-23 05:04:21.686505
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: add tests for the whitespace handling support
    assert parse_kv('') == {}
    assert parse_kv('a="1"') == {u'a': u'1'}
    assert parse_kv('a="1" b="2"') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('"a"="1" "b"="2"') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a "a"="1" "b"="2"') == {u'a': None, u'a': u'1', u'b': u'2'}

# Generated at 2022-06-23 05:04:32.981265
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key1=value1 key2=value2') == {'key1': 'value1', 'key2': 'value2'}
    assert parse_kv('key1=value1 key2=value2', check_raw=True) == {'key1': 'value1', 'key2': 'value2'}

    assert parse_kv('key1=value1 key2') == {'key1': 'value1'}
    assert parse_kv('key1=value1 key2', check_raw=True) == {'key1': 'value1', '_raw_params': 'key2'}

    assert parse_kv('key1=value1 key2=arg1 arg2 arg3') == {'key1': 'value1'}

# Generated at 2022-06-23 05:04:42.622558
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('a=1 b=2') == {'a': '1', 'b': '2'})
    assert(parse_kv('a=b \= c=d') == {'a': 'b = c', 'd': None})
    assert(parse_kv('a=1 b=2', check_raw=True) == {'a': '1', 'b': '2', '_raw_params': None})
    assert(parse_kv('a=1 b=2', check_raw=True) == {'a': '1', 'b': '2', '_raw_params': None})
    assert(parse_kv('a=1 b=2', check_raw=True) == {'a': '1', 'b': '2', '_raw_params': None})

# Generated at 2022-06-23 05:04:54.195079
# Unit test for function split_args
def test_split_args():
    # Simple test
    assert split_args('foo bar') == ['foo', 'bar']

    # Test a string with quotes and jinja2 blocks
    args = """
    install python "{{
        jinja2_block
    }}" -y
    """.strip()
    assert split_args(args) == ['install', 'python', '"{{\n    jinja2_block\n}}"', '-y']

    # Test args with escapes
    assert split_args('"\\"foo \\" bar"') == ['"foo " bar']

    # Test args with continued lines
    assert split_args('"fo \\' + '\n' + 'o bar"') == ['"foo bar"']
    assert split_args('foo \\\nbar') == ['foo', 'bar']

    # Test args with blanks


# Generated at 2022-06-23 05:05:06.248661
# Unit test for function parse_kv
def test_parse_kv():
    print ('Testing parse_kv')
    # None
    assert parse_kv(None) == {}
    # Empty
    assert parse_kv('') == {}
    # Simple with one equal sign
    assert parse_kv('moo=cow') == {'moo': 'cow'}
    # Simple with two equal signs
    assert parse_kv('moo=cow=fish') == {'moo': 'cow=fish'}
    # Simple with two equal signs, different positions
    assert parse_kv('moo=cow fish=cat') == {'moo': 'cow', 'fish': 'cat'}
    # Simple with one equal sign and whitespace
    assert parse_kv('moo = cow') == {'moo': 'cow'}
    # Simple with three equal signs
    assert parse_kv

# Generated at 2022-06-23 05:05:12.951312
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a\nb', 'c']) == 'a\nb c'
    assert join_args(['a', 'b\nc']) == 'a b\nc'
    assert join_args(['a\nb\nc']) == 'a\nb\nc'
    assert join_args([]) == ''



# Generated at 2022-06-23 05:05:22.232369
# Unit test for function join_args
def test_join_args():
    s = ['foo=bar', 'baz=qux']
    assert join_args(s) == 'foo=bar baz=qux'
    s = ['foo=bar', 'arg1', 'arg2', 'arg3']
    assert join_args(s) == 'foo=bar arg1 arg2 arg3'
    s = ['foo=bar', 'arg1', 'arg2', 'arg3\n', 'foo=baz']
    assert join_args(s) == 'foo=bar arg1 arg2 arg3\nfoo=baz'

# Generated at 2022-06-23 05:05:30.030228
# Unit test for function join_args
def test_join_args():
    '''
    Test for function join_args()
    '''
    assert join_args(['-a', '-b', '-c']) == '-a -b -c'
    assert join_args(['a', ' ', 'b']) == 'a b'
    assert join_args(['a\tb', 'c']) == 'a\tb c'
    assert join_args(['a\n', 'b']) == 'a\nb'
    assert join_args(['a', 'b\n']) == 'a b\n'



# Generated at 2022-06-23 05:05:41.501422
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("A=1 B=2 C='3' D=\"4\" E=yeah\\= F='\\' G=\\\" H=\\\nI") == {'A': '1', 'B': '2', 'C': "'3'", 'D': '"4"', 'E': 'yeah=', 'F': "'", 'G': '"', 'H': '\\nI'}

# Generated at 2022-06-23 05:05:51.507560
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo', 'bar']) == 'foo bar'
    assert join_args(['foo', '\nbar']) == 'foo \nbar'
    assert join_args(['\nfoo', '\nbar']) == '\nfoo \nbar'
    assert join_args(['foo', '\n\nbar']) == 'foo \n\nbar'
    assert join_args(['foo', '\n\n\nbar']) == 'foo \n\n\nbar'
    assert join_args(['foo', '\n    bar']) == 'foo \n    bar'
    assert join_args(['foo', '\n    \nbar']) == 'foo \n    \nbar'

# Generated at 2022-06-23 05:05:57.559417
# Unit test for function parse_kv
def test_parse_kv():
    # Pass tests
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar', True) == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=bat') == {'foo': 'bar', 'baz': 'bat'}
    assert parse_kv('foo=bar baz=bat', True) == {'foo': 'bar', 'baz': 'bat'}
    assert parse_kv('foo = bar') == {'foo': 'bar'}
    assert parse_kv('foo = bar', True) == {'foo': 'bar'}
    assert parse_kv('foo = bar baz = bat') == {'foo': 'bar', 'baz': 'bat'}

# Generated at 2022-06-23 05:06:05.546630
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c={{ foo }} d={{ bar }}") == ['a=b', 'c={{ foo }}', 'd={{ bar }}']
    assert split_args("a=b c='foo bar' d={{ foo }}") == ['a=b', "c='foo bar'", 'd={{ foo }}']
    assert split_args("a=b c=\"foo bar\" d={{ foo }}") == ['a=b', 'c="foo bar"', 'd={{ foo }}']

# Generated at 2022-06-23 05:06:09.469669
# Unit test for function join_args
def test_join_args():
    input_args = ['test\n', '1 1', '2 2', '3 3']
    expected_output = 'test\n 1 1 2 2 3 3'
    assert(join_args(input_args) == expected_output)



# Generated at 2022-06-23 05:06:13.022349
# Unit test for function join_args
def test_join_args():
    assert join_args([u'a', u'b', u'\nc', u'd', u'\n']) == 'a b\nc d\n'
    assert join_args([u'a', u'\nc', u'd', u'\n']) == 'a\nc d\n'



# Generated at 2022-06-23 05:06:21.561499
# Unit test for function split_args

# Generated at 2022-06-23 05:06:33.052056
# Unit test for function split_args

# Generated at 2022-06-23 05:06:37.882621
# Unit test for function join_args
def test_join_args():
    orig = '''
    foo bar "hello, world"

    > foo

    < bar
    '''
    expected = orig
    test = join_args(split_args(orig, posix=(False, False)))
    assert test == expected, (test, expected)


# Generated at 2022-06-23 05:06:45.663378
# Unit test for function split_args
def test_split_args():
    import unittest
    import sys

    class TestParser(unittest.TestCase):

        def check_parse(self, args, result):
            params = split_args(args)
            result = result.split('\n')
            self.assertEqual(params, result, "Failed to parse %s" % args)

        def test_simple_args(self):
            ''' simple argument parsing '''
            args = 'foo=bar key="some value"'
            result = args
            self.check_parse(args, result)

        def test_override_args(self):
            ''' argument parsing overrides '''
            args = '''key=value1 key="value2" key='value3' '''
            #All three assignments are treated as different commands

# Generated at 2022-06-23 05:06:49.628056
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('key1=val1 key2=val2 key3="val 3" key4=val4')
    assert options == {u'key1': u'val1', u'key3': u'val 3', u'key2': u'val2', u'key4': u'val4'}


# Generated at 2022-06-23 05:07:00.626838
# Unit test for function join_args

# Generated at 2022-06-23 05:07:11.939333
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('"foo=bar"') == {u'"foo': u'bar"'}
    assert parse_kv('foo') == {}
    assert parse_kv('foo=bar baz=qux') == {u'baz': u'qux', u'foo': u'bar'}
    assert parse_kv('bin/vim') == {u'_raw_params': u'bin/vim'}
    assert parse_kv('"foo=bar" "baz=qux"') == {u'"baz': u'qux"', u'"foo': u'bar"'}

# Generated at 2022-06-23 05:07:22.717448
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('key1=val1 key2=val2 key3="val3 with spaces"')
    assert options == {
        'key1': 'val1',
        'key2': 'val2',
        'key3': 'val3 with spaces'
    }

    options = parse_kv('''key1=val1 key2=val\=with\=escaped\=equals key3="val3 with spaces"''')
    assert options == {
        'key1': 'val1',
        'key2': 'val=with=escaped=equals',
        'key3': 'val3 with spaces'
    }


# Generated at 2022-06-23 05:07:34.168098
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for the split_args() function in this module.
    '''

    assert split_args("a") == ["a"]
    assert split_args("a b c") == ["a", "b", "c"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a='b c'") == ["a='b c'"]
    assert split_args("a='b c' d='e f'") == ["a='b c'", "d='e f'"]
    assert split_args("a={{b}}") == ["a={{b}}"]
    assert split_args("a={{b}} c={{d}}") == ["a={{b}}", "c={{d}}"]

# Generated at 2022-06-23 05:07:45.315059
# Unit test for function parse_kv
def test_parse_kv():
    #smoke test it exists
    parse_kv('some=option')
    #test that simple item works
    assert parse_kv('some=option') == {'some':'option'}
    #test that multiple items work
    assert parse_kv('one=a two=b three=c') == {'one':'a','two':'b','three':'c'}
    #test that order of items is preserved
    assert parse_kv('one=1 two=2 one=3') == {'one':'1','two':'2','one':'3'}
    #test that types are preserved
    assert parse_kv('one=1 two="2" three=3.0 four=true') == {'one':'1','two':'2','three':'3.0','four':'true'}




# Generated at 2022-06-23 05:07:55.877510
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_unicode
    assert parse_kv(None) == ImmutableDict()
    # test that the parse_kv handles all characters
    invalid_char = "]\x7f"
    assert parse_kv(invalid_char)['_raw_params'] == to_unicode(invalid_char)
    # test that the parse_kv handles escaped characters

# Generated at 2022-06-23 05:08:03.959021
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.module_utils.common.args import to_text
    from ansible.module_utils.common.args import to_bytes
    from ansible.module_utils.common.args import split_args


# Generated at 2022-06-23 05:08:06.254619
# Unit test for function join_args
def test_join_args():
    s = ["a", "b c", "d"]
    assert join_args(s) == 'a b c d'



# Generated at 2022-06-23 05:08:17.631661
# Unit test for function split_args
def test_split_args():
    # Test simple args
    args = "a=b c=\"foo bar\""
    assert split_args(args) == ['a=b', 'c="foo bar"']

    # Newlines should be preserved
    args = "a=b\nc=\"foo bar\""
    assert split_args(args) == ['a=b\n', 'c="foo bar"']

    # Make sure we don't include an extra empty entry at the end
    args = "a=b\n"
    assert split_args(args) == ['a=b\n']

    # Args can have quotes in them
    args = 'a=b c="foo\\"bar"'
    assert split_args(args) == ['a=b', 'c="foo\\"bar"']

    # Arg values can have escaped spaces

# Generated at 2022-06-23 05:08:28.405774
# Unit test for function parse_kv
def test_parse_kv():
    # test with quoted equals, it should be unescaped
    assert parse_kv(r"foo='bar=baz'", check_raw=False) == {u'foo': u'bar=baz'}

    # test with escaped equals, it should be escaped
    assert parse_kv(r"foo=bar\=baz", check_raw=False) == {u'foo': u'bar=baz'}
    assert parse_kv(r"foo=bar\\\=baz", check_raw=False) == {u'foo': u'bar\\=baz'}
    assert parse_kv(r"foo=bar\\\=baz=bar", check_raw=False) == {u'foo': u'bar\\=baz=bar'}

    # test with empty quoted strings
    assert parse_k

# Generated at 2022-06-23 05:08:35.543585
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b', 'c']) == 'a b c'
    assert join_args(['a', '\nb', '\nc']) == 'a\nb\nc'
    assert join_args(['a', '\nb', 'c', '\n']) == 'a\nb c\n'
    assert join_args(['a', '\nb', '\n', 'c']) == 'a\nb\n c'



# Generated at 2022-06-23 05:08:44.900781
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz\nfoo"') == ['foo', '"bar baz\nfoo"']
    assert split_args('foo "bar\n baz"') == ['foo', '"bar\n baz"']
    assert split_args('foo "bar\n {# comment #} baz"') == ['foo', '"bar\n {# comment #} baz"']
    assert split_args('foo "bar\n {% foo %} baz"') == ['foo', '"bar\n {% foo %} baz"']

# Generated at 2022-06-23 05:08:53.376577
# Unit test for function join_args
def test_join_args():
    assert 'foo bar baz' == join_args(['foo', 'bar', 'baz'])
    assert 'foo bar baz' == join_args(['foo\n', 'bar', 'baz'])
    assert '"foo bar" baz' == join_args(['"foo bar"', 'baz'])
    assert 'foo "bar baz"' == join_args(['foo', '"bar baz"'])
    assert 'echo This is a "test case".' == join_args(['echo', 'This', 'is', 'a', '"test case".'])
    assert 'foo bar "baz foo" bar' == join_args(['foo bar', '"baz foo" bar'])

# Generated at 2022-06-23 05:09:04.367057
# Unit test for function split_args
def test_split_args():
    # Testing split_args with basic multiple space-separated strings
    assert split_args("foo=bar cat=bat") == ["foo=bar", "cat=bat"]

    # Testing split_args with quoted strings
    assert split_args("\"foo bar bat\"") == ["foo bar bat"]
    assert split_args("\'foo bar bat\'") == ["foo bar bat"]
    assert split_args("\'foo bar bat\'" + " \'bar\\\'s foo\'") == ["foo bar bat", "bar\\\'s foo"]
    assert split_args("\'foo bar bat\'" + " \"bar\'s foo\"") == ["foo bar bat", "bar\'s foo"]
    assert split_args("\"foo bar bat\"" + " \'bar\\\'s foo\'") == ["foo bar bat", "bar\\\'s foo"]
    assert split_args

# Generated at 2022-06-23 05:09:15.129694
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for function parse_kv
    '''
    assert parse_kv("name='james cammarata'") == {"name": "james cammarata"}
    assert parse_kv("name=\"james cammarata\"") == {"name": "james cammarata"}

    assert parse_kv("name='james'\" cam\"'marata'") == {"name": "james cammarata"}
    assert parse_kv("name=\"james' cammarata\"") == {"name": "james' cammarata"}

    assert parse_kv("name=james cammarata") == {"name": "james cammarata"}
    assert parse_kv("name=james' cammarata") == {"name": "james' cammarata"}

# Generated at 2022-06-23 05:09:25.943196
# Unit test for function parse_kv
def test_parse_kv():
    print ("Testing parse_kv")
    assert parse_kv('a=b c="foo bar"') == {'a': 'b', 'c': 'foo bar'}
    assert parse_kv('a=b c="foo bar" d=') == {'a': 'b', 'c': 'foo bar', 'd': ''}
    assert parse_kv(u"a=b c='foo bar'") == {'a': 'b', 'c': 'foo bar'}
    assert parse_kv(u'a=b c="foo bar" d') == {'a': 'b', 'c': 'foo bar', '_raw_params' : u'd'}

# Generated at 2022-06-23 05:09:28.578148
# Unit test for function join_args
def test_join_args():
    test_string = """
    hello
    goodworld
    1
    2"""
    result = join_args(split_args(test_string))
    assert result == test_string


# Generated at 2022-06-23 05:09:37.627231
# Unit test for function split_args
def test_split_args():

    # a basic test where the input exactly matches the output
    print("Running basic split_args test")
    argstr = "a=1 b=2 c=3"
    result = split_args(argstr)
    for t in result:
        print("%s," % t, end=' ')
    print("")
    assert argstr == join_args(result)

    # a test where the args are split across lines
    print("Running split_args test with line breaks")
    argstr = '''a=1
b=2
c=3'''
    result = split_args(argstr)
    for t in result:
        print("%s," % t, end=' ')
    print("")
    assert argstr == join_args(result)

    # a test where the args are split within quotes

# Generated at 2022-06-23 05:09:48.325340
# Unit test for function split_args
def test_split_args():
    # test basic arg splitting, no jinja2 blocks or quotes
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    # test if it handles line continuations
    assert split_args("a=b \\\n c=d") == ['a=b', 'c=d']
    # test if it handles line continuations inside quotes
    assert split_args("a=b \\ \n c=d") == ['a=b  c=d']
    # test if it handles line continuations inside jinja2 blocks
    assert split_args("a='{{ b }} \\ c=d") == ["a='{{ b }} \ c=d"]
    # test if it handles jinja2 blocks inside quotes

# Generated at 2022-06-23 05:09:59.132362
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert parse_kv(u'foo="bar"') == {u'foo': u'bar'}
    assert parse_kv(u"foo='bar'") == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar" baz') == {u'foo': u'bar', u'baz': u''}

# Generated at 2022-06-23 05:10:09.351816
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'arg1=apple') == {u'arg1': u'apple'}
    assert parse_kv(u'arg1=apple arg2=orange') == {u'arg1': u'apple', u'arg2': u'orange'}
    assert parse_kv(u'''arg1=apple arg2=orange''') == {u'arg1': u'apple', u'arg2': u'orange'}
    assert parse_kv(u'''arg1=apple arg2=orange''') == {u'arg1': u'apple', u'arg2': u'orange'}
    assert parse_kv(u'''arg1=apple arg2=orange''') == {u'arg1': u'apple', u'arg2': u'orange'}
    assert parse_kv

# Generated at 2022-06-23 05:10:19.144582
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == { u'a': u'b' }
    assert parse_kv('a=b c=d') == { u'a': u'b', u'c': u'd' }
    assert parse_kv(u'a=b c=d') == { u'a': u'b', u'c': u'd' }
    assert parse_kv(u'a=b c=d', True) == { u'a': u'b', u'c': u'd' }
    assert parse_kv(u'a=b c=d', check_raw=True) == { u'a': u'b', u'c': u'd' }

# Generated at 2022-06-23 05:10:28.244901
# Unit test for function split_args

# Generated at 2022-06-23 05:10:39.890075
# Unit test for function split_args
def test_split_args():
    ''' Unit tests for function split_args '''


# Generated at 2022-06-23 05:10:51.074396
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(u'name="hello world" state=absent age=42')
    assert options['name'] == u"hello world"
    assert options['state'] == u"absent"
    assert options['age'] == u"42"
    assert len(options) == 3
    assert '_raw_params' not in options

    options = parse_kv(u'name="hello world" state=absent anotherparam')
    assert options['name'] == u"hello world"
    assert options['state'] == u"absent"
    assert 'age' not in options
    assert len(options) == 2
    assert '_raw_params' in options
    assert options['_raw_params'] == u'anotherparam'
