

# Generated at 2022-06-23 05:00:59.044574
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common.utils import assert_equal

    assert_equal(parse_kv("a=b c='d e' f='g=h'"),
                 {u'a': u'b', u'c': u'd e', u'f': u'g=h'})

    assert_equal(parse_kv(None), {})

    assert_equal(parse_kv("a=b c d"),
                 {u'a': u'b', u'_raw_params': u'c d'})
    assert_equal(parse_kv("a=b c d", True),
                 {u'a': u'b', u'_raw_params': u'c d'})

# Generated at 2022-06-23 05:01:11.015151
# Unit test for function parse_kv
def test_parse_kv():
    # Test #1
    a = '''
        action=msg
        option1=val1
        option2=val2
        option3=val3
    '''
    result = parse_kv(a, check_raw=True)
    assert result['action'] == 'msg'
    assert result['option1'] == 'val1'
    assert result['option2'] == 'val2'
    assert result['option3'] == 'val3'
    assert result['_raw_params'] == 'msg'

    # Test #2
    a = '''
        option1=val1
        option2=val2
        option3=val3
        action=msg
    '''
    result = parse_kv(a, check_raw=True)
    assert result['option1'] == 'val1'

# Generated at 2022-06-23 05:01:16.300818
# Unit test for function split_args
def test_split_args():
    ra = split_args

    assert ['foo'] == ra('foo')
    assert ['foo', 'bar'] == ra('foo bar')
    assert ['foo', 'bar baz'] == ra('foo bar baz')
    assert ['foo', 'bar baz'] == ra('foo   bar baz')
    assert ['foo', 'bar', 'baz'] == ra('foo bar baz')
    assert ['foo=bar', 'bar=baz', 'baz=foo'] == ra('foo=bar bar=baz baz=foo')
    assert ['foo="bar baz"', 'bar=baz'] == ra('foo="bar baz" bar=baz')
    assert ['foo=bar', 'bar="baz foo"'] == ra('foo=bar bar="baz foo"')

# Generated at 2022-06-23 05:01:24.317263
# Unit test for function join_args
def test_join_args():
    s = ['ls', '-la']
    assert join_args(s) == 'ls -la'
    s = ['echo', '" ' + '\\' + 'n "']
    assert join_args(s) == 'echo " ' + '\\' + 'n "'
    s = ['echo', 'a " b " c']
    assert join_args(s) == 'echo a " b " c'
    s = ['echo', '" a "\\' + 'n" b "']
    assert join_args(s) == 'echo " a "\\' + 'n" b "'
    s = ['echo', 'a " b \\' + 'n" c']
    assert join_args(s) == 'echo a " b \\' + 'n" c'

# Generated at 2022-06-23 05:01:33.093509
# Unit test for function parse_kv
def test_parse_kv():
    pkv = parse_kv
    assert pkv("x=y z=p") == dict(x='y', z='p')
    assert pkv("x=y z=p ") == dict(x='y', z='p')
    assert pkv("x=y z=p x=t") == dict(x='t', z='p')
    assert pkv("x=y z='p y' x=t") == dict(x='t', z="p y")
    assert pkv("x=y z='p y' x='t y'") == dict(x="t y", z="p y")

# Generated at 2022-06-23 05:01:42.147093
# Unit test for function split_args
def test_split_args():
    # Test without jinja2 expressions
    assert split_args('') == []
    assert split_args('a b c') == ['a', 'b', 'c']
    assert split_args('a b \\\nc') == ['a', 'b', 'c']
    assert split_args('a b \\\n\\\nc') == ['a', 'b', 'c']
    assert split_args('a b c\\') == ['a', 'b', 'c\\']
    assert split_args('  a  b  c  ') == ['a', 'b', 'c']
    assert split_args('a "b c"') == ['a', '"b c"']
    assert split_args("a 'b c'") == ['a', "'b c'"]
    assert split_args('a "b\t c"')

# Generated at 2022-06-23 05:01:50.743219
# Unit test for function parse_kv
def test_parse_kv():
    test_string = "key1=val1 key2='val2' key3='val3' key4='val4' key5='val5' key6='val6' key7='val7' key8='val8' key9='val9' key10='val10' create=value"
    test_string_2 = "key1=val1 key2='val2' key3='val3' key4='val4' key5='val5' key6='val6' key7='val7' key8='val8' key9='val9' key10='val10' creates=value"

# Generated at 2022-06-23 05:01:58.011343
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("") == {}
    assert parse_kv("a=b") == {'a': 'b'}
    assert parse_kv("a='b c'") == {'a': 'b c'}
    assert parse_kv("a='b c' d=e") == {'a': 'b c', 'd': 'e'}
    assert parse_kv("a=b d=e") == {'a': 'b', 'd': 'e'}
    assert parse_kv("a='b c' d='e f'") == {'a': 'b c', 'd': 'e f'}
    assert parse_kv("a=\"b c\" d=\"e f\"") == {'a': "b c", 'd': "e f"}

# Generated at 2022-06-23 05:02:05.608311
# Unit test for function join_args
def test_join_args():
    assert join_args([]) == ''
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a\nb', 'b']) == 'a\nb b'
    assert join_args(['a\nb', 'b', 'c\nd']) == 'a\nb b c\nd'



# Generated at 2022-06-23 05:02:19.567053
# Unit test for function join_args

# Generated at 2022-06-23 05:02:30.857859
# Unit test for function split_args

# Generated at 2022-06-23 05:02:40.010993
# Unit test for function split_args
def test_split_args():
    def assert_split(expect, given):
        result = split_args(given)
        if len(expect) != len(result):
            import pdb
            pdb.set_trace()
        assert len(expect) == len(result), "Expected %s tokens, got %s" % (len(expect), len(result))
        for idx, val in enumerate(expect):
            assert val == result[idx], "Expected %s, got %s" % (val, result[idx])

    assert_split(['a', 'b', 'c'], 'a b c')
    assert_split(['a', 'b', 'c'], 'a b c ')
    assert_split(['a', 'b', 'c'], 'a\nb \n\nc')
    assert_split

# Generated at 2022-06-23 05:02:51.858920
# Unit test for function parse_kv
def test_parse_kv():
    # TODO: write this test
    pass

# Split args implementation adapted from rspeer's answer here:
# http://stackoverflow.com/questions/3319665/python-split-string-based-on-space-but-preserve-quoted-substrings
#
# Splits a string of shell arguments into a list of individual
# arguments, taking into account quoted substrings and escaped
# characters.
_RE_SPLIT_ARGS = re.compile(r'''((?:[^ \t\r\n"']|"[^"]*"|'[^']*')+)''')
_RE_UNQUOTE_ARGS = re.compile(r"""(\\.)|"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)'""")



# Generated at 2022-06-23 05:02:58.519632
# Unit test for function join_args
def test_join_args():
    data = [
        ('a b c', ['a', 'b', 'c']),
        ('a\n b\nc', ['a', '\n b', 'c']),
        ('a b "c d"', ['a', 'b', 'c d']),
        ('a b "c\nd"', ['a', 'b', 'c\nd']),
        ('a b "c\nd" e', ['a', 'b', 'c\nd', 'e']),
    ]
    for expected, splitted in data:
        joined = join_args(splitted)
        assert joined == expected, joined



# Generated at 2022-06-23 05:03:07.264010
# Unit test for function split_args
def test_split_args():
    '''
    This is really only for me to run if I need to quickly
    ensure that my changes to split/join_args do not break
    anything
    '''
    import sys

    if sys.argv[1] == 'split':
        try:
            params = split_args(sys.argv[2])
            print("Split '%s' into: %s" % (sys.argv[2], params))
        except Exception as e:
            print("Failed to split on: %s" % sys.argv[2])
            print(e)


# Generated at 2022-06-23 05:03:15.184001
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 cde') == {u'a': u'1', u'b': u'2', u'cde': u'', u'_raw_params': u'cde'}
    assert parse_kv('foo bar=1') == {u'bar': u'1', u'foo': u'', u'_raw_params': u'foo'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}
    assert parse_kv('foo=bar_baz') == {u'foo': u'bar_baz'}
    assert parse_kv('foo=bar_baz') == {u'foo': u'bar_baz'}

# Generated at 2022-06-23 05:03:24.357590
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:33.878430
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:45.444959
# Unit test for function parse_kv

# Generated at 2022-06-23 05:03:57.758061
# Unit test for function split_args
def test_split_args():
    '''Unit test for function split_args'''
    assert split_args("this is a test") == ["this", "is", "a", "test"]
    assert split_args("this is a test\nwith a newline") == ["this", "is", "a", "test\nwith", "a", "newline"]
    assert split_args("this is a test with spaces") == ["this", "is", "a", "test", "with", "spaces"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']

# Generated at 2022-06-23 05:04:08.380448
# Unit test for function split_args

# Generated at 2022-06-23 05:04:14.020948
# Unit test for function split_args
def test_split_args():
    '''
    Test to make sure we're getting the expected output from split_args.
    '''

    # This is a list of tuples, where each tuple has the following structure:
    #   (input, expected output)
    tests = []

    # Test with a simple command, without any special characters
    tests.append(
        (
            'useradd johndoe',
            ['useradd', 'johndoe'],
        )
    )

    # Test with a simple command, with a quoted argument
    tests.append(
        (
            'usermod -c "John Doe" johndoe',
            ['usermod', '-c', '"John Doe"', 'johndoe'],
        )
    )

    # Test with a simple command, but with a quoted argument where the
    # entire argument is quoted

# Generated at 2022-06-23 05:04:19.385296
# Unit test for function split_args
def test_split_args():
    def _test(args, expected_params):
        params = split_args(args)
        assert params == expected_params


# Generated at 2022-06-23 05:04:29.820368
# Unit test for function parse_kv

# Generated at 2022-06-23 05:04:40.383680
# Unit test for function join_args
def test_join_args():
    # None
    assert not join_args(None)
    # empty list
    assert not join_args([])
    # simple join
    assert join_args(['a', 'b']) == u'a b'
    # multiple lines
    assert join_args(['a', 'b', '\nc', 'd']) == u'a b\nc d'
    # single line
    assert join_args(['a', 'b', 'c', 'd']) == u'a b c d'
    # single line, no space
    assert join_args(['a', 'b', 'c', 'd'], space=False) == u'abcd'
    # multiple lines, no space (empty element)

# Generated at 2022-06-23 05:04:47.805815
# Unit test for function join_args
def test_join_args():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert join_args(['a', 'b']) == u'a b'
    assert join_args(['a\n', 'b']) == u"a\nb"
    assert join_args(['a', '  b']) == u'a   b'
    assert join_args(['a\n', '\tb']) == u"a\n\tb"
    assert join_args(['a', '\n\tb']) == u"a\n\tb"
    assert join_args(['a', '\n', '\tb']) == u"a\n\tb"

    assert join_args([u'a', 'b']) == u'a b'

# Generated at 2022-06-23 05:04:58.606342
# Unit test for function split_args
def test_split_args():
    # Test the function using a unit test instead of a simple invocation which would
    # like the actual call result in the stdout. This enables the test to be
    # used in automation.

    args = '{{a=b}} {% c=d %} {# e=f #} id1="{{g=h} {{i=j}} {# k=l #} {% m=n %} {{}} {{% }} {{{#" id2="o" p="q r" s=\'t {%u=v%} w {{x=y}}\'"'

    try:
        results = split_args(args)
    except AnsibleParserError:
        assert False, "Unbalanced jinja2 block or quotes."

# Generated at 2022-06-23 05:05:07.297022
# Unit test for function join_args
def test_join_args():
    assert join_args(["foo", "bar"]) == "foo bar"
    assert join_args(["foo", "bar", "baz"]) == "foo bar baz"
    assert join_args(["foo \n", "bar"]) == "foo \nbar"
    assert join_args(["foo", "bar\n"]) == "foo bar\n"
    assert join_args(["foo", "bar\n", "baz"]) == "foo bar\nbaz"
    assert join_args(["foo\n", "bar"]) == "foo\nbar"
    assert join_args(["foo", "\nbar"]) == "foo \nbar"
    assert join_args(["foo\n", "\nbar"]) == "foo\n\nbar"



# Generated at 2022-06-23 05:05:18.629397
# Unit test for function join_args
def test_join_args():
    # Test case 1
    # Input:
    # Setup: Hello=world newline=world
    # Action: Hello=world
    # Teardown:
    # Verify: Setup: Hello=world newline=world
    # Action: Hello=world
    # Teardown:

    s = [u'Setup:', u'Hello=world', u'newline=world',
         u'Action:', u'Hello=world', u'Teardown:']
    assert join_args(s) == (u'Setup:\nHello=world newline=world\n'
                             u'Action: Hello=world\n'
                             u'Teardown:')

    # Test case 2
    # Input:
    # Setup: Hello=world newline=world
    # Action: Hello=world
    # Teardown:
    #

# Generated at 2022-06-23 05:05:26.590194
# Unit test for function parse_kv
def test_parse_kv():

    sr = '"'
    eq = '='
    sq = "'"
    bs = '\\'


# Generated at 2022-06-23 05:05:30.648232
# Unit test for function split_args
def test_split_args():
    # test variables
    args = "a=b c=\"foo \\\" bar\" d='foo \\\' bar'"
    result = split_args(args)
    try:
        assert result == ['a=b', 'c="foo \\" bar"', "d='foo \\' bar'"]
        print("Test passed!")
    except AssertionError:
        print("Test failed!")

# test_split_args()

# Generated at 2022-06-23 05:05:41.787126
# Unit test for function parse_kv
def test_parse_kv():
  import pytest
  assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
  assert parse_kv('"a"="1 2" "b"="3"') == {'a': '1 2', 'b': '3'}
  assert parse_kv('"a"="1 2" "b"="3 4"') == {'a': '1 2', 'b': '3 4'}
  assert parse_kv('"a"="1=2" "b"="3=4"') == {'a': '1=2', 'b': '3=4'}

# Generated at 2022-06-23 05:05:52.010059
# Unit test for function split_args
def test_split_args():
    '''
    Simple test based on examples in the docstring
    '''

# Generated at 2022-06-23 05:05:59.603955
# Unit test for function join_args
def test_join_args():
    # split_args("a b") returns [["a"], ["b"]]
    assert join_args([["a"], ["b"]]) == u"a b"

    # split_args("a \\\n b") returns [["a", "\\"], ["b"]]
    assert join_args([["a", "\\"], ["b"]]) == u"a \\\n b"

    # split_args("a \\\n\t b") returns [["a", "\\"], ["b"]]
    assert join_args([["a", "\\"], ["b"]]) == u"a \\\n b"

    # split_args("a \\ \\\n\t b") returns [["a", "\\", "\\"], ["b"]]

# Generated at 2022-06-23 05:06:04.945810
# Unit test for function join_args
def test_join_args():
    assert join_args(['a']) == 'a'
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a=b', 'c=d']) == 'a=b c=d'
    assert join_args(['a=b\nc=d']) == 'a=b\nc=d'



# Generated at 2022-06-23 05:06:07.644196
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('arg1=val1 arg2=val2') == dict(arg1='val1', arg2='val2')



# Generated at 2022-06-23 05:06:17.726094
# Unit test for function join_args
def test_join_args():
    assert join_args(['filename']) == 'filename'
    assert join_args(['/path/to/filename']) == '/path/to/filename'
    assert join_args(['filename', 'name=value']) == 'filename name=value'
    assert join_args(['filename', 'name=value', 'name2=value2']) == 'filename name=value name2=value2'
    assert join_args(['filename', 'name=value', 'name2=value2', 'name3=value3']) == 'filename name=value name2=value2 name3=value3'

# Generated at 2022-06-23 05:06:25.208806
# Unit test for function split_args
def test_split_args():
    '''Test splitting of arguments'''
    import os
    import sys
    import pytest

    # Test normal arguments
    args = "a b=c"
    result = split_args(args)
    assert result == ['a', 'b=c']

    # Test arguments with quotes
    args = "a b='c d'"
    result = split_args(args)
    assert result == ['a', 'b=\'c d\'']

    # Test arguments with jinja2 snippets
    args = "a b={{ c }}"
    result = split_args(args)
    assert result == ['a', 'b={{ c }}']

    # Test arguments with jinja2 snippets and quotes
    args = "a b={{ 'c d' }}"
    result = split_args(args)

# Generated at 2022-06-23 05:06:35.631993
# Unit test for function join_args
def test_join_args():
    assert join_args(['a', 'b']) == 'a b'
    assert join_args(['a \n', 'b']) == 'a \nb'
    assert join_args(['a \r\n', 'b']) == 'a \r\nb'
    assert join_args(['a \r\nb']) == 'a \r\nb'
    assert join_args(['a \r\n b']) == 'a \r\n b'
    assert join_args(['a \n\t b']) == 'a \n\t b'
    assert join_args(['a', 'b', 'c', '"d e"', '"f g"', '"h i"']) == 'a b c "d e" "f g" "h i"'

# Generated at 2022-06-23 05:06:46.815324
# Unit test for function join_args
def test_join_args():
    assert(join_args(['foo', 'bar']) == 'foo bar')
    assert(join_args(['foo', '', 'bar']) == 'foo  bar')
    assert(join_args(['foo', '\n', 'bar']) == 'foo \nbar')
    assert(join_args(['', '', 'foo', '\n', 'bar']) == '   foo \nbar')
    assert(join_args(['foo', '', 'bar\n']) == 'foo  bar\n')
    assert(join_args(['foo', 'bar', '\n']) == 'foo bar \n')
    assert(join_args(['foo\n', 'bar']) == 'foo\nbar')

# Generated at 2022-06-23 05:06:54.076244
# Unit test for function split_args
def test_split_args():
    cur_dir = os.path.dirname(__file__)
    input_file = os.path.join(cur_dir, 'split_args_input.txt')
    output_file = os.path.join(cur_dir, 'split_args_output.txt')
    with open(input_file, 'r') as f:
        input_strs = f.read().splitlines()
    with open(output_file, 'r') as f:
        output_strs = f.read().splitlines()
    for idx, line in enumerate(input_strs):
        output = split_args(line)
        assert output == output_strs[idx].split(' ')



# Generated at 2022-06-23 05:07:02.648016
# Unit test for function parse_kv
def test_parse_kv():
    inputs = ["foo=bar", "foo='bar'", "foo='ba\"r'", "foo=\"ba'r\"", "foo=\"bar\\\"bax\"", "foo=bar\\'bax", "foo=bar\\'bax\"", "foo=bar\\\"bax", "foo=bar\\\"bax\"", "foo=bar\\bax", "foo='bar\\'bax", 'foo="bar\\"bax"']

# Generated at 2022-06-23 05:07:13.605355
# Unit test for function parse_kv
def test_parse_kv():
    '''Validate the functionality of parse_kv.'''
    # Empty string
    assert parse_kv('') == {}
    # Single key=val
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    # Positional arguments, no =
    assert parse_kv('foo bar baz') == {'_raw_params': 'foo bar baz'}
    # Positional arguments, with =
    assert parse_kv('foo=bar baz') == {'_raw_params': 'foo=bar baz'}
    # Escaped =
    assert parse_kv('foo\=bar') == {'_raw_params': 'foo\=bar'}
    # Escaped \

# Generated at 2022-06-23 05:07:19.884775
# Unit test for function join_args
def test_join_args():
    """Test join_args function
    """
    assert join_args(['the_first_arg', 'the_second_arg']) == 'the_first_arg the_second_arg'
    assert join_args(['the_first_arg', 'the_second_arg', '\nthe_third_arg']) == 'the_first_arg the_second_arg\nthe_third_arg'



# Generated at 2022-06-23 05:07:30.230860
# Unit test for function split_args

# Generated at 2022-06-23 05:07:39.212476
# Unit test for function split_args
def test_split_args():
    '''
    Test our split_args() function with a variety of inputs
    '''


# Generated at 2022-06-23 05:07:49.658365
# Unit test for function split_args
def test_split_args():
    # Test 'unescaped equal sign'
    if split_args('a=b c="foo bar"') != ['a=b', 'c="foo bar"']:
        return False
    
    # Test 'escaped equal sign'
    if split_args('a\=b c\="foo bar"') != ['a\=b', 'c\="foo bar"']:
        return False
    
    # Test 'spaces inside quoted strings'
    if split_args('a="foo bar" c="foo bar"') != ['a="foo bar"', 'c="foo bar"']:
        return False

    # Test 'escaped spaces inside quoted strings'
    if split_args('a="foo\ bar" c="foo\ bar"') != ['a="foo\ bar"', 'c="foo\ bar"']:
        return False

    # Test

# Generated at 2022-06-23 05:07:59.134127
# Unit test for function split_args

# Generated at 2022-06-23 05:08:01.530749
# Unit test for function join_args
def test_join_args():
    a = ['a', 'b c', "d\nef\n", 'g h i']
    b = join_args(a)
    assert b == "a\nb c\nd\nef\n\ng h i"


# Generated at 2022-06-23 05:08:13.093676
# Unit test for function split_args
def test_split_args():
    # Test basic function
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c=d\ne=f") == ["a=b", "c=d\ne=f"]
    # Test quoted strings
    assert split_args("c='foo bar'") == ["c='foo bar'"]
    assert split_args("c=\"foo bar\"") == ["c=\"foo bar\""]
    assert split_args("c='foo bar' d='foo\nbar'") == ["c='foo bar'", "d='foo\nbar'"]

# Generated at 2022-06-23 05:08:23.224030
# Unit test for function parse_kv
def test_parse_kv():
    def _test_parse_kv(args, result, check_raw=False):
        assert parse_kv(args, check_raw) == result

    # Test with no arguments
    _test_parse_kv(None, {})
    # Test with some simple arguments
    _test_parse_kv("one=1 two=2", {
        u'one': u'1',
        u'two': u'2',
    })
    # Test that quoting works

# Generated at 2022-06-23 05:08:27.272745
# Unit test for function join_args
def test_join_args():
    assert join_args(["one", "two"]) == "one two"
    assert join_args(["one ", "two"]) == "one  two"
    assert join_args(["one\n", "two"]) == "one\ntwo"



# Generated at 2022-06-23 05:08:38.892357
# Unit test for function parse_kv
def test_parse_kv():
    # split_args tests
    assert split_args(u"") == []
    assert split_args(u"one") == [u"one"]
    assert split_args(u"one two") == [u"one", u"two"]
    assert split_args(u"one two three") == [u"one", u"two", u"three"]
    assert split_args(u'"one"') == [u"one"]
    assert split_args(u"'one'") == [u"one"]
    assert split_args(u"one two \"three four\" five") == [u"one", u"two", u"three four", u"five"]
    assert split_args(u"one two 'three four' five") == [u"one", u"two", u"three four", u"five"]

# Generated at 2022-06-23 05:08:48.297818
# Unit test for function split_args

# Generated at 2022-06-23 05:08:53.853056
# Unit test for function parse_kv
def test_parse_kv():
    #Test for dictionary
    test_result = parse_kv("a=b c=d")
    assert test_result == {"a":"b", "c":"d"}, "Error in parse_kv: %s" % test_result
    #Test for dictionary with quotes
    test_result = parse_kv("a='b' c='d'")
    assert test_result == {"a":"b", "c":"d"}, "Error in parse_kv: %s" % test_result
    #Test for dictionary with no quoted value
    test_result = parse_kv("a='b' c=d")
    assert test_result == {"a":"b", "c":"d"}, "Error in parse_kv: %s" % test_result
    #Test for dictionary with no quoted value and spaces

# Generated at 2022-06-23 05:08:56.997803
# Unit test for function join_args
def test_join_args():
    assert join_args(['foo','bar','baz']) == 'foo bar baz'
    assert join_args(['foo\nbar','baz']) == 'foo\nbar baz'



# Generated at 2022-06-23 05:09:01.892622
# Unit test for function join_args
def test_join_args():
    assert join_args(["a", "b", "c"]) == "a b c"
    assert join_args(["a", "\nb", "c"]) == "a\nb c"
    assert join_args(["a", "\n", "b", "c"]) == "a\n b c"



# Generated at 2022-06-23 05:09:13.246502
# Unit test for function split_args
def test_split_args():
    tests = [
        ('a=b', ['a=b']),
        ('a=b c="foo bar"', ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar" {{stuff}} d=e',
         ['a=b', 'c="foo bar"', '{{', 'stuff', '}}', 'd=e']),
        ('a=b c="foo bar" {%stuff%} d=e',
         ['a=b', 'c="foo bar"', '{%', 'stuff', '%}', 'd=e']),
        ('a=b c="foo bar" {#stuff#} d=e',
         ['a=b', 'c="foo bar"', '{#', 'stuff', '#}', 'd=e']),
    ]

# Generated at 2022-06-23 05:09:22.311937
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('arg1=val1 arg2=val2') == {u'arg1': u'val1', u'arg2': u'val2'}
    assert parse_kv('arg1=val1 arg2=val2 arg3=val3') == {u'arg1': u'val1', u'arg2': u'val2', u'arg3': u'val3'}
    assert parse_kv('arg1="val1" arg2="val2" arg3="val3"') == {u'arg1': u'val1', u'arg2': u'val2', u'arg3': u'val3'}

# Generated at 2022-06-23 05:09:33.320474
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv(u"     ", check_raw=False) == dict()
    assert parse_kv(u"a=1", check_raw=False) == dict(a=u"1")
    assert parse_kv(u"a=1 b=2 c=3", check_raw=False) == dict(a=u"1", b=u"2", c=u"3")
    assert parse_kv(u"a=\"1 2 3\" b=2", check_raw=False) == dict(a=u"1 2 3", b=u"2")
    assert parse_kv(u"a=\"1 \\\"2\\\" 3\" b=2", check_raw=False) == dict(a=u"1 \\\"2\\\" 3", b=u"2")
    assert parse_kv

# Generated at 2022-06-23 05:09:39.632468
# Unit test for function split_args
def test_split_args():
    original_string = "hostname={{ inventory_hostname }} remote_user={{ ansible_user }}"
    result = split_args(original_string)
    print(result)
    assert len(result) == 2
    assert result[0] == "hostname={{ inventory_hostname }}"
    assert result[1] == "remote_user={{ ansible_user }}"

test_split_args()


# Generated at 2022-06-23 05:09:50.705758
# Unit test for function parse_kv
def test_parse_kv():
    print("Running test_parse_kv")
    str = u"foo=bar bar=baz"
    o = parse_kv(str)
    assert o[u'foo'] == u'bar'
    assert o[u'bar'] == u'baz'

    str = u"foo='bar bar' bar='baz baz'"
    o = parse_kv(str, check_raw=True)
    assert o[u'foo'] == u'bar bar'
    assert o[u'bar'] == u'baz baz'
    assert o[u'_raw_params'] == u'foo=\'bar bar\' bar=\'baz baz\''

    str = u"foo='bar bar' bar='baz baz' baz='foo=baz' biz='foo=baz'"
    o

# Generated at 2022-06-23 05:10:01.152247
# Unit test for function split_args
def test_split_args():
    from collections import namedtuple

    TestSet = namedtuple('TestSet', ['input', 'expected'])


# Generated at 2022-06-23 05:10:10.509777
# Unit test for function split_args
def test_split_args():
    def run_test_set(test_input, expected_output):
        assert test_input == join_args(split_args(test_input))


# Generated at 2022-06-23 05:10:19.960136
# Unit test for function split_args
def test_split_args():
    def split(s):
        return split_args(s)

    assert split('') == ['']
    assert split('hello') == ['hello']
    assert split('hello world') == ['hello', 'world']
    assert split('hello world ') == ['hello', 'world', '']
    assert split(' hello world') == ['', 'hello', 'world']
    assert split('hello world\\') == ['hello', 'world\\']
    assert split('hello\\ world') == ['hello\\', 'world']
    assert split('hello world\\\nnext') == ['hello', 'world\\\n', 'next']

    assert split('foo=bar baz=qux') == ['foo=bar', 'baz=qux']

# Generated at 2022-06-23 05:10:25.339311
# Unit test for function split_args
def test_split_args():
    args = """a=b c='d e' f="g 'h' i" j='k "l" m' n="o 'p' q" r=s\tt"""
    tokenized = split_args(args)
    split = [x.strip() for x in args.split()]

    assert tokenized == split


# Generated at 2022-06-23 05:10:37.357615
# Unit test for function parse_kv
def test_parse_kv():
    # Test single key/value with spaces
    expected = {'foo': 'bar baz'}
    assert parse_kv('foo=' + '"' + expected['foo'] + '"') == expected

    # Test key/value with spaces in both
    expected = {'foo bar': 'baz bang'}
    assert parse_kv('foo\ bar=' + '"' + expected['foo bar'] + '"') == expected

    # Test multiple kv pairs
    expected = {'foo': 'bar',
                'buzz': 'bang'}
    assert parse_kv('foo=' + '"' + expected['foo'] + '" ' +
                    'buzz=' + '"' + expected['buzz'] + '"') == expected

    # Test unquoted freeform arguments

# Generated at 2022-06-23 05:10:47.293742
# Unit test for function parse_kv
def test_parse_kv():
    exp = dict(
        some_key='some value',
        key_with_no_value='',
        key_with_equals='value with equals=oh no',
        key_with_equals_no_value='',
        optional1='',
        optional2='',
        optional3='',
        good_list='some,list,of,values',
        list_with_no_value=''
    )
    res = parse_kv('''
        some_key=some value
        key_with_equals=value with equals\=oh no
        key_with_no_value
        good_list=some,list,of,values
        key_with_equals_no_value=
        list_with_no_value
        optional1
        optional2=
        optional3=''')

# Generated at 2022-06-23 05:10:55.711937
# Unit test for function parse_kv
def test_parse_kv():
    def _test(line, expected, check_raw=False):
        actual = parse_kv(line, check_raw=check_raw)
        assert actual == expected

    _test(
        "foo=bar baz='hello world'",
        {'foo': 'bar', 'baz': 'hello world'},
    )
    _test(
        "foo=bar foo='bar'",
        {'foo': 'bar'},
    )
    _test(
        "foo=bar foo='bar' foo=baz",
        {'foo': 'baz'},
    )
    _test(
        "foo=bar foo=baz foo='bar'",
        {'foo': 'bar'},
    )