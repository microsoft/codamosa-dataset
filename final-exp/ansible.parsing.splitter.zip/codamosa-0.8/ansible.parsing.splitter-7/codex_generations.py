

# Generated at 2022-06-11 08:54:35.705742
# Unit test for function split_args
def test_split_args():

    assert split_args('foo') == ['foo']
    assert split_args('foo=bar') == ['foo=bar']
    assert split_args('foo=bar bar=foo') == ['foo=bar', 'bar=foo']
    assert split_args('foo=bar\nbar=foo') == ['foo=bar\n', 'bar=foo']
    assert split_args('foo="bar"') == ['foo="bar"']
    assert split_args('foo="bar" bar="foo"') == ['foo="bar"', 'bar="foo"']
    assert split_args('foo="bar"\nbar="foo"') == ['foo="bar"\n', 'bar="foo"']
    assert split_args("foo='bar'") == ['foo=\'bar\'']

# Generated at 2022-06-11 08:54:47.028775
# Unit test for function parse_kv
def test_parse_kv():
    assert {u'_raw_params': u'hello world'} == parse_kv(u'hello world')
    assert {u'foo': u'bar', u'_raw_params': u'hello world'} == parse_kv(u'foo=bar hello world')
    assert {u'foo': u'bar', u'_raw_params': u'hello world'} == parse_kv(u"'foo=bar' hello world")
    assert {u'foo': u"bar's"} == parse_kv(u"'foo=bar\\'s'")
    assert {u'foo': u'bar', u'_raw_params': u"foo=bar's"} == parse_kv(u"foo=bar's")

# Generated at 2022-06-11 08:54:58.378884
# Unit test for function split_args
def test_split_args():
    # assert split_args
    assert ['foo'] == split_args('foo')
    assert ['foo', 'bar'] == split_args('foo bar')
    assert ['foo', 'foo2=bar', 'bar'] == split_args('foo foo2=bar bar')
    assert ['foo', 'bar bar'] == split_args('foo "bar bar"')
    assert ['foo', "bar bar"] == split_args("foo 'bar bar'")
    assert ['foo', 'bar bar', 'bar2=biz'] == split_args("foo 'bar bar' bar2=biz")
    assert ['foo', 'bar', 'bar2=biz biz2'] == split_args("foo bar bar2=biz biz2")

# Generated at 2022-06-11 08:55:10.174064
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("") == {}
    assert parse_kv("arg1=val1 arg2=val2") == { u"arg1": u"val1", u"arg2": u"val2" }
    assert parse_kv("arg1=val1 arg2=val2 arg3=val3 arg4=val4") == { u"arg1": u"val1", u"arg2": u"val2", u"arg3": u"val3", u"arg4": u"val4" }
    assert parse_kv("arg1=val1 arg2=val2 arg3=val3 arg4=val4") == { u"arg1": u"val1", u"arg2": u"val2", u"arg3": u"val3", u"arg4": u"val4" }

# Generated at 2022-06-11 08:55:20.314024
# Unit test for function split_args
def test_split_args():
    # Test that we can properly split basic args
    assert split_args(u'foo bar') == [u'foo', u'bar']
    assert split_args(u'foo bar baz') == [u'foo', u'bar', u'baz']
    assert split_args(u'foo "bar baz"') == [u'foo', u'"bar baz"']
    assert split_args(u'foo "bar baz" spam') == [u'foo', u'"bar baz"', u'spam']
    assert split_args(u'foo "bar baz" spam ham') == [u'foo', u'"bar baz"', u'spam', u'ham']

    # Test that we can properly split args with newlines

# Generated at 2022-06-11 08:55:32.175344
# Unit test for function split_args
def test_split_args():
    assert split_args('one "two three" +four') == ['one', '"two three"', '+four']
    assert split_args('one "two three" "four five"') == ['one', '"two three"', '"four five"']
    assert split_args('one "two three" "four five" six seven') == ['one', '"two three"', '"four five"', 'six', 'seven']
    assert split_args('one "two three"{{four}}"four five"') == ['one', '"two three"{{four}}"four five"']
    assert split_args('one "two three"{{four}}"four five"') == ['one', '"two three"{{four}}"four five"']

# Generated at 2022-06-11 08:55:42.087037
# Unit test for function split_args
def test_split_args():
    result = split_args(u"foo")
    assert result == [u"foo"]

    result = split_args(u"foo bar")
    assert result == [u"foo", u"bar"]

    result = split_args(u"foo bar baz")
    assert result == [u"foo", u"bar", u"baz"]

    result = split_args(u"foo\nbar")
    assert result == [u"foo\n", u"bar"]

    result = split_args(u"foo bar\nbaz")
    assert result == [u"foo", u"bar\n", u"baz"]

    result = split_args(u"foo=bar")
    assert result == [u"foo=bar"]

    result = split_args(u"foo=bar baz=bam")
    assert result

# Generated at 2022-06-11 08:55:52.213388
# Unit test for function split_args
def test_split_args():
    # Test base case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test quoting
    assert split_args('a="foo bar"') == ['a="foo bar"']
    assert split_args('a=\'foo bar\'') == ['a=\'foo bar\'']
    assert split_args('a="foo bar') == ['a="foo bar']
    assert split_args('a=\'foo bar') == ['a=\'foo bar']
    assert split_args('a="foo bar\'') == ['a="foo bar\'']

    # test Escaping
    assert split_args(r'a=foo\ bar') == [r'a=foo\ bar']

# Generated at 2022-06-11 08:56:02.502387
# Unit test for function parse_kv

# Generated at 2022-06-11 08:56:12.191634
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'param=value') == {u'param': u'value'}
    assert parse_kv(u'param="value"') == {u'param': u'value'}
    assert parse_kv(u"param='value'") == {u'param': u'value'}
    assert parse_kv(u'param=value param2="value2"') == {u'param': u'value', u'param2': u'value2'}
    assert parse_kv(u'param=true param2=true') == {u'param': u'true', u'param2': u'true'}
    assert parse_kv(u'param="true" param2="true"') == {u'param': u'true', u'param2': u'true'}
    assert parse

# Generated at 2022-06-11 08:56:33.882317
# Unit test for function parse_kv
def test_parse_kv():
    def assert_parse_kv(args, expected):
        ret = parse_kv(args)
        assert ret == expected, "parse_kv(%s) returned %s instead of %s" % (args, ret, expected)

    assert_parse_kv(None, {})
    assert_parse_kv('', {})
    assert_parse_kv('foo=bar', {'foo': 'bar'})
    assert_parse_kv('foo=bar baz=qux', {'foo': 'bar', 'baz': 'qux'})
    assert_parse_kv('foo=bar baz=qux ', {'foo': 'bar', 'baz': 'qux'})

# Generated at 2022-06-11 08:56:44.280979
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="so\'mething else"') == ['a=b', 'c="foo bar"', "d=so'mething else"]
    assert split_args('a=b c="foo bar" d="so\'mething else" e') == ['a=b', 'c="foo bar"', "d=so'mething else", 'e']
    assert split_args('a=b c="foo bar" d="so\'mething else" e') == ['a=b', 'c="foo bar"', "d=so'mething else", 'e']
    assert split_args('a=b c="foo bar" d="so\'mething else" e')

# Generated at 2022-06-11 08:56:54.063078
# Unit test for function split_args

# Generated at 2022-06-11 08:57:02.254503
# Unit test for function split_args

# Generated at 2022-06-11 08:57:12.150819
# Unit test for function split_args
def test_split_args():
    # test split on space and then put back together so we know we're getting
    # the same thing back that we started with
    foo = u"""a=b c="foo bar" d='{\"x\": "y"}' foo="{{ bar }}}" data='{ "a": {{ b }} }' """
    split_foo = split_args(foo)
    assert join_args(split_foo) == foo

    # test that quotes with spaces and no equal sign puts the quotes and
    # the spaces back together
    bar = u"a=\"foo bar\""
    split_bar = split_args(bar)
    assert join_args(split_bar) == bar

    # test that quotes and spaces around an equal sign are kept
    # together after the split
    baz = u"a=\"foo bar\" = b"

# Generated at 2022-06-11 08:57:21.843225
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("hello=world") == {u'hello': u'world'}
    assert parse_kv("hello=world;foo=bar") == {u'hello': u'world', u'foo': u'bar'}
    assert parse_kv("hello=world;foo=bar; command=systemctl restart httpd") == {u'hello': u'world', u'foo': u'bar', u'command': u'systemctl restart httpd'}
    assert parse_kv("hello world") == {u'_raw_params': u'hello world'}
    assert parse_kv("hello=world;foo bar") == {u'hello': u'world', u'_raw_params': u'foo bar'}
    assert parse_kv("hello=world;foo bar; command=systemctl restart httpd")

# Generated at 2022-06-11 08:57:30.665388
# Unit test for function parse_kv
def test_parse_kv():
    "Test the parse_kv function"
    assert parse_kv('name=val') == dict(name='val')
    assert parse_kv('name1=val1 name2=val2') == dict(name1='val1', name2='val2')
    assert parse_kv('name1=val1 name2=val2 creates=/tmp/foo') == dict(name1='val1', name2='val2', creates='/tmp/foo')
    assert parse_kv('name1=val1 name2=val2 creates="$HOME/foo bar/baz"') == dict(name1='val1', name2='val2', creates='$HOME/foo bar/baz')
    assert parse_kv('name1=val1 name2=val2 creates="$HOME/foo bar/baz"'.split()) == dict

# Generated at 2022-06-11 08:57:34.816443
# Unit test for function parse_kv
def test_parse_kv():
    raw_params = [u"foo=x", u"bar=Y", u"baz='Z'", u"one two=three"]
    expected = dict(foo='x', bar='Y', baz='Z', _raw_params=join_args(raw_params))
    assert parse_kv(join_args(raw_params), check_raw=True) == expected


# Generated at 2022-06-11 08:57:43.579677
# Unit test for function split_args
def test_split_args():
    # These should all spit out the exact same list
    # because we don't care about whitespace inside strings
    assert split_args(u"blah") == ['blah']
    assert split_args(u"blah foo bar baz") == ['blah', 'foo', 'bar', 'baz']
    assert split_args(u"blah foo bar baz") == split_args(u"blah    foo          bar baz")
    assert split_args(u"blah foo bar baz") == split_args(u"blah\nfoo\n\nbar baz")

    # Make sure items with spaces are preserved
    assert split_args(u'blah foo="bar baz"') == ['blah', u'foo="bar baz"']

    # Check that whitespace within jinja2 {{ }} blocks is preserved

# Generated at 2022-06-11 08:57:48.049885
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv(args="a=b c='d e' f=\"g h i\""))
    print(parse_kv(args="a=b c='d e' f=\"g h i\" j='k=l m=n' o=\"p=q r=s\" t=p=q"))

# Split args (populates varnames dict)

# Generated at 2022-06-11 08:58:15.762978
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c=') == {u'a': u'b', u'c': u''}
    assert parse_kv('a=b c= d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b\\ c d=e ') == {u'a': u'b c', u'd': u'e'}
    assert parse_kv('a=b\\=c d=e ') == {u'a': u'b=c', u'd': u'e'}

# Generated at 2022-06-11 08:58:24.986121
# Unit test for function parse_kv
def test_parse_kv():
    # Test that key=val parsing works
    assert(parse_kv(u'foo=bar') == {u'foo': u'bar'})
    assert(parse_kv(u"foo='bar'") == {u'foo': u'bar'})
    assert(parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'})
    assert(parse_kv(u'foo=bar,baz=quux') == {u'foo': u'bar', u'baz': u'quux'})
    assert(parse_kv(u"foo='bar baz',lorem=ipsum") == {u'foo': u'bar baz', u'lorem': u'ipsum'})

# Generated at 2022-06-11 08:58:30.626680
# Unit test for function split_args
def test_split_args():
    '''
    Testing function split_args
    '''

    import pytest


# Generated at 2022-06-11 08:58:36.001902
# Unit test for function parse_kv
def test_parse_kv():
    # Test simple testcases,
    # move out any complicated testcases to test_runner.py
    a = {
        'x': '1',
        'y': '2',
        'z': '3'}
    b = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': 'v3'}
    c = {
        'k1': 'v1',
        'k2': 'v2',
        'k3': 'v3',
        '_raw_params': 'k4=v4 k5=v5'}

# Generated at 2022-06-11 08:58:48.103375
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv("") == {}
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a='b c'") == {u'a': u'b c'}
    assert parse_kv("a=\"b c\"") == {u'a': u'b c'}
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a='b=c'") == {u'a': u'b=c'}

# Generated at 2022-06-11 08:58:56.538528
# Unit test for function split_args
def test_split_args():
    # Test comment opening and closing
    tokens = split_args('host vars: {# testcomment #}')
    assert len(tokens) == 2
    tokens = split_args('host vars: {# testcomment #} {# testcomment #}')
    assert len(tokens) == 2

    # Test double quoted strings
    tokens = split_args('host vars: "testvar={{ testvar }}"')
    assert len(tokens) == 2
    tokens = split_args('host vars: "testvar={{ testvar }}" "testvar={{ testvar }}"')
    assert len(tokens) == 2

    # Test single quoted strings
    tokens = split_args('host vars: \'testvar={{ testvar}}\'')
    assert len(tokens) == 2
    tokens

# Generated at 2022-06-11 08:59:06.786742
# Unit test for function split_args
def test_split_args():
    """Unit test for function split_args"""
    from urllib import quote_plus
    # set up a list of args that create a variety of scenarios
    # for testing split_args()
    test_args = []
    test_args.append("/bin/foo")
    test_args.append("/bin/bar biz")
    test_args.append("/bin/baz'biz bang")
    test_args.append("/bin/baz'biz bang'")
    test_args.append("/bin/baz\"biz bang'")
    test_args.append("/bin/baz\"biz' bang\"")
    test_args.append("/bin/baz\"biz' bang\"'")
    test_args.append("/bin/baz\"biz' bang\"\\'")
    test_args.append

# Generated at 2022-06-11 08:59:09.459907
# Unit test for function parse_kv
def test_parse_kv():
    # TODO: update this test
    pass


# ###############################################################################
#



# Generated at 2022-06-11 08:59:20.573391
# Unit test for function parse_kv
def test_parse_kv():
    """
    A function to test the parsing of parameters passed as key/value pairs.
    """


# Generated at 2022-06-11 08:59:33.172107
# Unit test for function parse_kv
def test_parse_kv():
    d = parse_kv('foo= bar=blaz')
    assert d == dict(foo='', bar='blaz')

    d = parse_kv('foo= bar=blaz foo=sox')
    assert d == dict(foo='sox', bar='blaz')

    d = parse_kv('foo=bar\=blaz')
    assert d == dict(foo='bar=blaz')

    d = parse_kv("foo='bar\\'blaz'")
    assert d == dict(foo="bar'blaz")

    d = parse_kv('foo="bar\\"blaz"')
    assert d == dict(foo='bar"blaz')

    d = parse_kv("foo=\'bar\\'blaz\'")
    assert d == dict(foo="bar'blaz")


# Generated at 2022-06-11 08:59:55.144532
# Unit test for function parse_kv
def test_parse_kv():
    # Tests arguments as a string
    assert parse_kv('foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}

    # Tests unicode characters
    assert parse_kv('foo=bar baz=qu\xe8ux') == {u'foo': u'bar', u'baz': u'qu\xe8ux'}

    # Tests unicode characters with hex escapes
    assert parse_kv('foo=bar baz=qu\\u00e8ux') == {u'foo': u'bar', u'baz': u'qu\xe8ux'}

    # Tests double quoted strings
    assert parse_kv('foo=bar baz="quux"') == {u'foo': u'bar', u'baz': u'quux'}



# Generated at 2022-06-11 09:00:04.479046
# Unit test for function split_args
def test_split_args():
    '''
    This function tests the split_args function
    '''
    # To run under python2, please un-comment the following two lines
    # import sys
    # reload(sys)
    # sys.setdefaultencoding('utf8')

    from yaml import safe_dump

# Generated at 2022-06-11 09:00:12.836335
# Unit test for function split_args

# Generated at 2022-06-11 09:00:21.440277
# Unit test for function split_args
def test_split_args():
    # We're just testing for proper handling of quotes and jinja2 blocks here
    args = '''foo="{{bar}}" qux='{{quux}}' norf="{{quuux}} {{quuuux}}" baz="{{ quuuuux.ex }}" thud="{{ quuuuuux.ex.ex }}"'\n'{{splat}}' "{{foo}}"\'\\\n\\' zot bar="{{baz}}"'''

# Generated at 2022-06-11 09:00:32.078069
# Unit test for function parse_kv
def test_parse_kv():
    ''' Parse the input string, verify expected options
    '''
    # options with values
    args = 'cmd="echo foo" state=absent'
    result = parse_kv(args)
    # Validate that the command is as expected
    assert result["cmd"] == "echo foo"
    # Validate that the option is as expected
    assert result["state"] == "absent"
    # Validate that there are no other options
    assert len(result) == 2

    # options with values with escaped quotes
    args = 'cmd="echo \\"foo\\"" state=absent'
    result = parse_kv(args)
    # Validate that the command is as expected
    assert result["cmd"] == "echo \"foo\""
    # Validate that the option is as expected

# Generated at 2022-06-11 09:00:41.379251
# Unit test for function split_args

# Generated at 2022-06-11 09:00:53.464956
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.listify import listify_lookup_plugin_terms

# Generated at 2022-06-11 09:01:00.035748
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ["a=b", 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\"\nd=e f=\"baz qux\"") == ["a=b", 'c="foo bar"', 'd=e', 'f="baz qux"']
    assert split_args("a=b c=\"foo\nbar\"\nd=e") == ["a=b", 'c="foo\nbar"', "d=e"]

# Generated at 2022-06-11 09:01:11.589278
# Unit test for function parse_kv

# Generated at 2022-06-11 09:01:21.833689
# Unit test for function split_args

# Generated at 2022-06-11 09:01:46.396441
# Unit test for function split_args

# Generated at 2022-06-11 09:01:52.662750
# Unit test for function split_args

# Generated at 2022-06-11 09:02:01.539940
# Unit test for function split_args
def test_split_args():
    assert ['a=b', 'c="foo bar"'] == split_args('a=b c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\nc="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b   c="foo bar"')
    assert ['a=b', 'c="foo bar"'] == split_args('a=b\n   c="foo bar"')
    assert ['a="b b"', 'c="foo bar"'] == split_args('a="b b"\n   c="foo bar"')
    assert ['a="b b"', 'c="foo bar"'] == split_args('a="b b"\n   c="foo bar"')

# Generated at 2022-06-11 09:02:11.916269
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv(None)
    assert parse_kv("a=1") == {"a": "1"}
    assert parse_kv("a=1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv("a='1' b='2'") == {"a": "1", "b": "2"}
    assert parse_kv("a='1' b=\"2\"") == {"a": "1", "b": "2"}
    assert parse_kv("a='1' b=\"2\" c=3") == {"a": "1", "b": "2", "c": "3"}
    assert parse_kv("a='1' b='2' c=3") == {"a": "1", "b": "2", "c": "3"}

# Generated at 2022-06-11 09:02:19.757978
# Unit test for function split_args
def test_split_args():
    # create a random string of args to use
    import random
    import string
    try:
        # py3
        char_set = string.ascii_letters + string.digits + string.punctuation + ' '
    except AttributeError:
        # py2
        char_set = string.letters + string.digits + string.punctuation + ' '
    args = ''.join(random.choice(char_set) for i in range(200))

    params = split_args(args)
    joined = join_args(params)
    assert args == joined

# Generated at 2022-06-11 09:02:29.177014
# Unit test for function parse_kv
def test_parse_kv():
    """
    Simple unit test for parse_kv
    """
    assert parse_kv('a=b') == {'a': 'b'}
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b c="d e f" g') == {'a': 'b', 'c': 'd e f', '_raw_params': 'g'}
    assert parse_kv("a=b c=\"d'e f\" g") == {'a': 'b', 'c': "d'e f", '_raw_params': 'g'}


# Generated at 2022-06-11 09:02:37.080021
# Unit test for function split_args
def test_split_args():
    string = """a=b c="foo bar"
d=e f="foo=bar baz"
g=h i='foo=bar baz'
j=k l='foo = "bar baz"'
m=n o='foo = '"'"'bar baz'"'"'
p=q r='foo '"'"'= bar baz'"'"'
s=t u="foo\"bar\"baz"
v=w x='foo"bar"baz'
y=z aa='foo"'"'bar"'"'baz'"""

# Generated at 2022-06-11 09:02:45.489085
# Unit test for function parse_kv
def test_parse_kv():
    # Test with no args to make sure empty dict is returned
    assert parse_kv(None) == {}
    assert parse_kv("") == {}

    # Test with valid k=v pairs
    options = parse_kv("foo=bar baz=faz")
    assert options['foo'] == 'bar'
    assert options['baz'] == 'faz'

    # Test that lone keys are put into _raw_params
    options = parse_kv("foo")
    assert 'foo' not in options
    assert options[u'_raw_params'] == 'foo'

    # Test that non-key=value arguments are put into _raw_params
    options = parse_kv("foo bar")
    assert 'foo' not in options
    assert 'bar' not in options

# Generated at 2022-06-11 09:02:56.045048
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:06.260553
# Unit test for function parse_kv
def test_parse_kv():
    import yaml
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_native

    check_raw = True

    # FIXME: make the retrieval of this list of shell/command options a function, so the list is centralized
    shell_options_as_str = "creates, removes, chdir, executable, warn, stdin, stdin_add_newline, strip_empty_ends"
    shell_options = set(shell_options_as_str.split(','))

    tests = (
        # kwargs in the args string, check_raw is True, should end up in the
        # options dictionary
        (u"creates=/tmp/something", {u'creates': u'/tmp/something'}, True),
    )


# Generated at 2022-06-11 09:03:50.090036
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=quux") == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv("foo=bar baz=quux", check_raw=True) == {u'foo': u'bar', u'baz': u'quux', u'_raw_params': u'foo=bar baz=quux'}
    assert parse_kv("foo=bar baz=quux cmd='foo baz'", check_raw=True) == {u'foo': u'bar', u'baz': u'quux', u'_raw_params': u'foo=bar baz=quux', u'cmd': u"foo baz"}

# Generated at 2022-06-11 09:03:58.317230
# Unit test for function parse_kv
def test_parse_kv():
    def assertOptionsDict(args, kwoptions):
        options = parse_kv(args, **kwoptions)
        # print(args)
        # print(options)
        if len(kwoptions) > 0:
            for k in kwoptions:
                assert options[k] == kwoptions[k]
        return options

    assertOptionsDict('a=1', {'a': '1'})
    assertOptionsDict('a=1 b=2', {'a': '1', 'b': '2'})
    assertOptionsDict('a=1 b="2"', {'a': '1', 'b': '2'})
    assertOptionsDict('a=1 b="2 3"', {'a': '1', 'b': '2 3'})