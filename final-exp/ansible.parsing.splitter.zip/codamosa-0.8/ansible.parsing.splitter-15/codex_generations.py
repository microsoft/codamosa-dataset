

# Generated at 2022-06-11 08:55:06.925510
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('foo=bar biz=biz_bar') == {'foo': 'bar', 'biz': 'biz_bar'}
    assert parse_kv('foo=bar biz=biz_bar', check_raw=True) == {'foo': 'bar', 'biz': 'biz_bar', '_raw_params': ''}
    assert parse_kv('foo=bar biz=biz_bar raw_params=foo bar biz') == {'foo': 'bar', 'biz': 'biz_bar', 'raw_params': 'foo bar biz'}

# Generated at 2022-06-11 08:55:14.058900
# Unit test for function split_args
def test_split_args():
    # default join_args
    args = 'a=b c="foo bar"'
    result = split_args(args)
    assert result == ['a=b', 'c="foo bar"']
    # args with spaces
    args = 'a=b\n c=foo bar'
    result = split_args(args)
    assert result == ['a=b', 'c=foo bar']
    # args with j2 quotes
    args = 'a=b {{ c=foo }} "bar"'
    result = split_args(args)
    assert result == ['a=b', '{{ c=foo }}', '"bar"']
    # args with j2 blocks
    args = 'a=b {% c=foo %} d="bar"'
    result = split_args(args)

# Generated at 2022-06-11 08:55:25.684257
# Unit test for function split_args

# Generated at 2022-06-11 08:55:37.942731
# Unit test for function split_args
def test_split_args():
    print("Testing split_args")
    args = 'param=value'
    params = split_args(args)
    assert len(params) == 1
    assert params[0] == 'param=value'

    args = 'param=foo="bar" other=something'
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == 'param=foo="bar"'
    assert params[1] == 'other=something'
    
    args = 'param=foo="bar" \\\\other=something'
    params = split_args(args)
    assert len(params) == 2
    assert params[0] == 'param=foo="bar"'
    assert params[1] == '\\\\other=something'
    

# Generated at 2022-06-11 08:55:46.669403
# Unit test for function split_args

# Generated at 2022-06-11 08:55:57.321312
# Unit test for function split_args

# Generated at 2022-06-11 08:56:01.800449
# Unit test for function split_args
def test_split_args():
    args = 'command arg "with spaces" "and jinja2 {{ foo }} inside" arg2 \'and arg3\''
    params = split_args(args)
    result = join_args(params)
    assert result == args, 'result did not match original'

if __name__ == "__main__":
    test_split_args()

# Generated at 2022-06-11 08:56:11.808254
# Unit test for function split_args
def test_split_args():
    assert split_args("this is unquoted") == ['this', 'is', 'unquoted']
    assert split_args("this 'is quoted'") == ['this', "'is quoted'"]
    assert split_args("this \"is quoted\"") == ['this', '"is quoted"']
    assert split_args("'this is 'quoted'") == ["'this is 'quoted'"]
    assert split_args("'this is 'quoted'") == ["'this is 'quoted'"]
    assert split_args("'this is \'quoted'") == ["'this is \'quoted'"]
    assert split_args("'this \"is\" quoted'") == ["'this \"is\" quoted'"]
    assert split_args("'this \"is\" quoted'") == ["'this \"is\" quoted'"]
    assert split_

# Generated at 2022-06-11 08:56:22.699559
# Unit test for function split_args
def test_split_args():
    a = """
        a=b c="foo bar" d={{ foo }} e="{{ foo }}" f="foo\\
        bar" g=\\" foo \\""
        """
    result = [u'a=b', u'c="foo bar"', u'd={{ foo }}', u'e="{{ foo }}"', u'f="foobar"', u'g=" foo "']
    assert split_args(a) == result

    a = u'a=b c="foo bar" d="{{foo}}" e="{{ foo }}" f=\\"foo\\" g="foo\\" bar"'
    result = [u'a=b', u'c="foo bar"', u'd="{{foo}}"', u'e="{{ foo }}"', u'f="foo"', u'g="foo" bar"']
   

# Generated at 2022-06-11 08:56:32.932418
# Unit test for function split_args
def test_split_args():
    assert split_args('') == ['']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a b\nc d') == ['a b', 'c d']
    assert split_args('a="1 2" b=c') == ['a="1 2"', 'b=c']
    assert split_args('a="1 2" b=c\nd="3 4" e=f') == ['a="1 2" b=c', 'd="3 4" e=f']
    assert split_args("{{ foo }} bar='baz qux'") == ['{{ foo }}', "bar='baz qux'"]

# Generated at 2022-06-11 08:56:52.604501
# Unit test for function parse_kv
def test_parse_kv():
    text_input = "key1=value1 key2=value2 foo"
    expected_output = {'key1': 'value1', 'key2': 'value2', '_raw_params': 'foo'}
    assert parse_kv(text_input, check_raw=True) == expected_output



# Generated at 2022-06-11 08:57:01.239151
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo bar baz\n one two') == ['foo', 'bar', 'baz\n', 'one', 'two']
    assert split_args(u'a="foo bar"\n b="baz buzz"') == [u'a="foo bar"', u'b="baz buzz"']
    assert split_args(u'a="{{ foo }} bar"') == [u'a="{{ foo }} bar"']
    assert split_args(u'a="{{ foo }} bar {{ baz }}"') == [u'a="{{ foo }} bar {{ baz }}"']

# Generated at 2022-06-11 08:57:10.928403
# Unit test for function parse_kv
def test_parse_kv():
    # Check for both key=value and key=value-with-equals
    assert parse_kv('foo=bar baz=blah') == dict(foo='bar', baz='blah'), "Error parsing assignment of multiple key-value pairs"
    assert parse_kv('foo=bar=baz') == dict(foo='bar=baz'), "Error parsing assignment of single key-value pair with equals embedded in value"

    # Check that escaped equals are preserved in the raw_params
    assert '_raw_params' not in parse_kv('foo=bar baz=blah'), "Error parsing assignment of multiple key-value pairs and no free-form params"
    assert parse_kv('foo=bar\\=baz') == dict(foo='bar=baz'), "Error parsing assignment of single key-value pair with escaped equals embedded in value"


# Generated at 2022-06-11 08:57:20.878464
# Unit test for function parse_kv
def test_parse_kv():
    # Test a simple command-line string with one key/value pair
    args = "key=value"
    options = parse_kv(args)
    assert options

    assert options[u'key'] == u'value'

    # Test a simple command-line string with two key/value pairs
    args = "key1=value1 key2=value2"
    options = parse_kv(args)
    assert options

    assert options[u'key1'] == u'value1'
    assert options[u'key2'] == u'value2'

    # Test a simple command-line string with one double-quoted value
    args = 'key="value"'
    options = parse_kv(args)
    assert options

    assert options[u'key'] == u'value'

    # Test a simple command-line string with one

# Generated at 2022-06-11 08:57:29.772730
# Unit test for function parse_kv
def test_parse_kv():
    # assert successful parsing of strings, and convert to unicode
    assert isinstance(parse_kv("key=value")['key'], unicode)
    assert isinstance(parse_kv('key1=value1 key2=value2')['key2'], unicode)
    assert isinstance(parse_kv('key=value1,key2=value2')['key2'], unicode)
    assert isinstance(parse_kv('key1="value1",key2="value2"')['key1'], unicode)
    assert isinstance(parse_kv('key="value with space"')['key'], unicode)
    assert isinstance(parse_kv('key="value with space and , comma"')['key'], unicode)

# Generated at 2022-06-11 08:57:38.364245
# Unit test for function parse_kv
def test_parse_kv():
    """ Make sure that we can parse a variety of edge cases correctly """

    # FIXME: This test is overly complex and needs to be simplified

    s = "foo=bar"
    a = parse_kv(s)
    assert a == {'foo': 'bar'}, "Expected {'foo': 'bar'}, got %s" % a

    s = '"foo=bar"'
    a = parse_kv(s)
    assert a == {u'_raw_params': '"foo=bar"'}, "Expected {'_raw_params': 'foo=bar'}, got %s" % a

    s = 'foo="bar"'
    a = parse_kv(s)
    assert a == {u'foo': u'"bar"'}, "Expected {'foo': '\"bar\"'}, got %s" % a



# Generated at 2022-06-11 08:57:47.258180
# Unit test for function split_args

# Generated at 2022-06-11 08:57:56.515928
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test parse_kv function.
    '''

# Generated at 2022-06-11 08:58:05.822920
# Unit test for function split_args
def test_split_args():
    failed = 0

    # Test to make sure that split_args can parse out the args
    # and reassemble them properly with many of the conditions
    # mentioned in the docstring for it.

# Generated at 2022-06-11 08:58:15.444761
# Unit test for function parse_kv
def test_parse_kv():
    args = '''first_param="one=1;two=2" second_param=3 third_param="4;5=six"'''
    expected = {u'first_param': u'one=1;two=2',
                u'second_param': u'3',
                u'third_param': u'4;5=six'}

    result = parse_kv(args)
    assert result == expected

    args = '''first_param="one=1;two=2" second_param=3 third_param="4;5=six" non_kv_param=arg1 arg2 arg3'''

# Generated at 2022-06-11 08:58:27.409142
# Unit test for function split_args

# Generated at 2022-06-11 08:58:33.307174
# Unit test for function split_args
def test_split_args():
    assert split_args(u'''echo 'hello there' {# this is a comment #}
                                              'this is a string {{ 1 + 1 }}' '\a'
                           ''') == [u"echo", u"'hello there'", u"'this is a string {{ 1 + 1 }}'", u"\\'\\a\\'"]
    assert split_args(u'''echo 'hello there' {# this is a comment #}
                                              "this is a string {{ 1 + 1 }}" '\a'
                           ''') == [u"echo", u"'hello there'", u'"this is a string {{ 1 + 1 }}"', u"\\'\\a\\'"]

# Generated at 2022-06-11 08:58:44.517946
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a="b b" c="d d"') == {u'a': u'b b', u'c': u'd d'}
    assert parse_kv('a="b b" c="d=d"') == {u'a': u'b b', u'c': u'd=d'}
    assert parse_kv('a="b b" c="d\'d"') == {u'a': u'b b', u'c': u'd\'d'}

# Generated at 2022-06-11 08:58:54.594412
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=woohoo') == {'foo': 'bar', 'baz': 'woohoo'}
    assert parse_kv('foo') == {}
    assert parse_kv('foo=bar baz') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=') == {'foo': 'bar'}
    assert parse_kv('foo bar') == {}
    assert parse_kv('foo=bar "baz=woohoo"') == {'foo': 'bar', 'baz': 'woohoo'}

# Generated at 2022-06-11 08:58:55.385397
# Unit test for function split_args
def test_split_args():
    # TODO
    pass

# Generated at 2022-06-11 08:59:05.323006
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b='c d' e='f=g'") == { 'a': '1', 'b': 'c d', 'e': 'f=g' }
    assert parse_kv("a=b='c' d=e") == { 'a': 'b=c', 'd': 'e' }
    assert parse_kv("a== b=c") == { 'a': '=', 'b': 'c' }
    assert parse_kv("a='\\\\' b=c") == { 'a': '\\', 'b': 'c' }
    assert parse_kv("a='\\\"' b=c") == { 'a': '"', 'b': 'c' }

# Generated at 2022-06-11 08:59:17.346503
# Unit test for function split_args
def test_split_args():
    params = split_args("foo bar=baz")
    assert params == ["foo", "bar=baz"]

    params = split_args("foo bar=baz\njohn=doe")
    assert params == ["foo", "bar=baz\n", "john=doe"]

    params = split_args("foo 'bar baz'")
    assert params == ["foo", "'bar baz'"]

    params = split_args("foo 'bar baz' john=doe")
    assert params == ["foo", "'bar baz'", "john=doe"]

    params = split_args("foo \"bar baz\"")
    assert params == ["foo", "\"bar baz\""]

    params = split_args("foo \"bar baz\" john=doe")

# Generated at 2022-06-11 08:59:25.997627
# Unit test for function parse_kv
def test_parse_kv():
    assert {'a':'1', 'b':'2', 'c':'3', '4':'4'} == parse_kv(u"a=1 b=2 c=3 4")
    assert {'a':'1', 'b':'2', 'c':'3', '4':'"4'} == parse_kv(u"a=1 b=2 c=3 4=\"4")
    # FIXME: the next line should work, since the first '4' is not the key, but the value of the key 'c'
    # assert {'a':'1', 'b':'2', 'c':'3', '4':'4'} == parse_kv(u"a=1 b=2 c=3\\=4 4")

# Generated at 2022-06-11 08:59:31.739496
# Unit test for function split_args
def test_split_args():
    '''
    Ensure the correct splitting of arguments.
    '''

    # Test with no quotes or block markers.
    assert split_args('a=x b=y c d') == ['a=x', 'b=y', 'c', 'd']

    # Test with single and double quotes.
    assert split_args('a=x b="1 2 3" c=d') == ['a=x', 'b="1 2 3"', 'c=d']
    assert split_args("a=x b='1 2 3' c=d") == ["a=x", "b='1 2 3'", "c=d"]

    # Test with escaped quotes and escaped spaces.

# Generated at 2022-06-11 08:59:42.960300
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b c') == ['a="b c']
    assert split_args('a="b c\\') == ['a="b c\\']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo \\\nbar') == ['foo', 'bar']
    assert split_args('foo \\\r\nbar') == ['foo', 'bar']
    assert split_args('foo bar\\\nbaz') == ['foo', 'bar\\\nbaz']

# Generated at 2022-06-11 08:59:57.806453
# Unit test for function split_args

# Generated at 2022-06-11 09:00:03.843938
# Unit test for function parse_kv
def test_parse_kv():
    kv_string = u"foo=bar baz='this is a string' meh='{\"a\": 1, \"b\": {\"c\":\"d\"}}' moo=cow"
    options = parse_kv(kv_string)

    # make sure this is a dict, not a list
    assert isinstance(options, dict)
    assert len(options) == 3
    assert options['foo'] == u'bar'
    assert options['baz'] == u"this is a string"



# Generated at 2022-06-11 09:00:12.680874
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:21.275073
# Unit test for function parse_kv
def test_parse_kv():
    def get_arg_count(args):
        return len(unquote(split_args(args)))

    assert get_arg_count(r'echo hi') == 1
    assert get_arg_count(r"echo 'hi'") == 1
    assert get_arg_count(r"echo 'hi there'") == 1
    assert get_arg_count(r'''echo 'hi "there"' '1' '\"2\"' "3" "'4' 5" \\6''') == 6
    assert get_arg_count(r'''echo '"hello"' "\"goodbye\""''') == 2
    assert get_arg_count(r'''git clone -o jmc 'https://github.com/ansible/ansible.git' "~/ansible"''') == 4

# Generated at 2022-06-11 09:00:31.929327
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:41.192606
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:53.342697
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'FOO=BAR') == {'FOO': 'BAR'}
    assert parse_kv(u'FOO="BAR"') == {'FOO': 'BAR'}
    assert parse_kv(u'FOO="BAR=BAZ"') == {'FOO': 'BAR=BAZ'}
    assert parse_kv(u'FOO="BAR=BAZ" AAA=BBB') == {'FOO': 'BAR=BAZ', 'AAA': 'BBB'}
    assert parse_kv(u'FOO="BAR=BAZ" AAA=BBB CCC="DDD=EEE"') == {'FOO': 'BAR=BAZ', 'AAA': 'BBB', 'CCC': 'DDD=EEE'}
    assert parse

# Generated at 2022-06-11 09:00:59.993706
# Unit test for function split_args
def test_split_args():
    '''
    Unit test for the split_args() function
    '''
    import sys
    try:
        from test.support import captured_stdout
    except ImportError:
        from ansible.utils.shlex import captured_stdout

    def check_split_args(inputstring, expected_result, expected_failure=False):
        if expected_failure:
            if split_args(inputstring) == expected_result:
                print(u'FAILED: Input: {0} did NOT raise an exception when it should have.'.format(inputstring))
                sys.exit(1)
            else:
                print(u'PASS: Input: {0} threw an exception, as expected.'.format(inputstring))

# Generated at 2022-06-11 09:01:11.538085
# Unit test for function split_args

# Generated at 2022-06-11 09:01:21.833769
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('foo=bar') == dict(foo='bar')
    assert parse_kv('foo=bar foo2=bar2 foo3="bar3 is a test"') == dict(foo='bar', foo2='bar2', foo3='bar3 is a test')
    assert parse_kv('foo=bar "foo2=bar2" foo3="bar3 is a test"') == dict(foo='bar', foo2='bar2', foo3='bar3 is a test')
    assert parse_kv('foo=bar "foo2=bar2" foo3="bar3 is a test"') == dict(foo='bar', foo2='bar2', foo3='bar3 is a test')

# Generated at 2022-06-11 09:01:38.518579
# Unit test for function split_args
def test_split_args():
    class Test(object):
        def __init__(self, name, string, expected):
            self.name = name
            self.string = string
            self.expected = expected

        def run(self):
            result = split_args(self.string)
            if self.expected != result:
                raise Exception("%s: Expected %s, got %s" % (self.name, self.expected, result))


# Generated at 2022-06-11 09:01:47.628860
# Unit test for function parse_kv
def test_parse_kv():
    data = 'foo=bar baz=ugly bat="a b c" bam=\'a b c\' baf=1 bag=2.0'
    result = parse_kv(data)
    assert len(result) == 5
    assert result['foo'] == 'bar'
    assert result['baz'] == 'ugly'
    assert result['bat'] == 'a b c'
    assert result['bam'] == 'a b c'
    assert result['baf'] == '1'
    assert result['bag'] == '2.0'

    data = '''foo=bar baz=ugly bat="a b c" bam='a b c' "bah=1" baf=1 bag=2.0
    '''
    result = parse_kv(data)
    assert len(result) == 6
   

# Generated at 2022-06-11 09:01:55.613826
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv("") == {})
    assert(parse_kv("a=b") == {'a': 'b'})
    assert(parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'})
    assert(parse_kv(u"echo 'A=C'", check_raw=True) == {u'_raw_params': u"echo 'A=C'"})
    assert(parse_kv(u'echo "A=C"', check_raw=True) == {u'_raw_params': u"echo \"A=C\""})

# Generated at 2022-06-11 09:02:04.583412
# Unit test for function parse_kv

# Generated at 2022-06-11 09:02:15.996010
# Unit test for function parse_kv
def test_parse_kv():
    s = u'foo=bar one=two three="four four"'
    expected = {
        u'foo': u'bar',
        u'one': u'two',
        u'three': u'four four',
        u'_raw_params': u'foo=bar one=two three="four four"',
    }
    ret = parse_kv(s, check_raw=True)
    assert ret == expected

    s = u'foo=bar one=two'
    expected = {
        u'foo': u'bar',
        u'one': u'two',
        u'_raw_params': u'foo=bar one=two',
    }
    ret = parse_kv(s, check_raw=True)
    assert ret == expected

    s = u'foo=bar one=two three'


# Generated at 2022-06-11 09:02:25.148085
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=simple b="with spaces" c="this=that" d=and\\=also\\=this') == {'a': 'simple',
                                                                                   'b': 'with spaces',
                                                                                   'c': 'this=that',
                                                                                   'd': 'and=also=this',
                                                                                   u'_raw_params': ''}
    assert parse_kv(u'a="b is \'quoted\'" c="and this \"is too\""') == {u'a': u"b is 'quoted'",
                                                                       u'c': u'and this "is too"',
                                                                       u'_raw_params': ''}

# Generated at 2022-06-11 09:02:33.977731
# Unit test for function parse_kv
def test_parse_kv():
    args = "a=b c=d"
    result = parse_kv(args)
    assert result['a'] == 'b'
    assert result['c'] == 'd'

# Test a single-quoted string
    args = "'a=b' 'c=d'"
    result = parse_kv(args)
    assert result['a'] == 'b'
    assert result['c'] == 'd'

# Test a double-quoted string
    args = '"a=b" "c=d"'
    result = parse_kv(args)
    assert result['a'] == 'b'
    assert result['c'] == 'd'

# Test a string with a newline
    args = '"foo\nbar" "baz"'
    result = parse_kv(args)
    assert result

# Generated at 2022-06-11 09:02:42.036547
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar \n xyz') == ['a=b', 'c="foo bar', 'xyz']
    assert split_args('a=b c="foo bar\nxyz') == ['a=b', 'c="foo bar\nxyz']
    assert split_args('a=b c="foo bar\nxyz\nabc') == ['a=b', 'c="foo bar\nxyz', 'abc']

# Generated at 2022-06-11 09:02:52.380729
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b some_option="another value"') == dict(a='b', some_option=u'another value')
    assert parse_kv(u'a=b "some option"=another_value') == dict(a='b', some='option', another_value='')
    assert parse_kv(u'a=b some_option=\'another value\'') == dict(a='b', some_option=u'another value')
    assert parse_kv(u'a=b some_option="another\\"value"') == dict(a='b', some_option=u'another"value')
    assert parse_kv(u'a=b some_option=\\"another value') == dict(a='b', some_option=u'"another value')
    assert parse_kv

# Generated at 2022-06-11 09:02:58.856594
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("key=value key2=value") == {u'key': u'value', u'key2': u'value'}
    assert parse_kv('key="" key2=""') == {u'key': u'""', u'key2': u'""'}
    assert parse_kv("key=value key2=value", True) == {u'key': u'value', u'key2': u'value'}



# Generated at 2022-06-11 09:03:13.896327
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common._collections_compat  import OrderedDict

    # Test cases are a list in the format:
    # ( test_input, expected_output, test_id)

# Generated at 2022-06-11 09:03:25.841836
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:34.649195
# Unit test for function parse_kv
def test_parse_kv():
    data = parse_kv('foo=bar baz=qux one=two', check_raw=True)
    assert data.get('foo', None) == 'bar'
    assert data.get('baz', None) == 'qux'
    assert data.get('one', None) == 'two'
    assert data.get('_raw_params', None) is None

    data = parse_kv('foo=bar baz=qux one two three', check_raw=True)
    assert data.get('foo', None) == 'bar'
    assert data.get('baz', None) == 'qux'
    assert data.get('_raw_params', None) == 'one two three'

    data = parse_kv('foo=bar baz=qux one=two three=four', check_raw=True)


# Generated at 2022-06-11 09:03:40.691805
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:51.512414
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=g') == {u'a': u'b', u'c': u'd e', u'f': u'g'}
    assert parse_kv('a="b=c" d="e=f"') == {u'a': u'b=c', u'd': u'e=f'}
    assert parse_kv('name=foo state=present groups=wheel') == {u'name': u'foo', u'state': u'present', u'groups': u'wheel'}
    assert parse_kv('creates="/tmp/foo"') == {u'creates': u'/tmp/foo'}



# Generated at 2022-06-11 09:03:58.965890
# Unit test for function split_args

# Generated at 2022-06-11 09:04:06.432129
# Unit test for function parse_kv