

# Generated at 2022-06-11 08:54:35.768441
# Unit test for function parse_kv
def test_parse_kv():
    # FIXME: add a proper unit test
    print(parse_kv(u"""a=b"""))


# Generated at 2022-06-11 08:54:47.069364
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz') == {u'foo': u'bar', u'_raw_params': u'baz'}
    assert parse_kv('foo=bar baz=blah') == {u'foo': u'bar', u'baz': u'blah'}
    assert parse_kv('foo=bar baz\\=boo') == {u'foo': u'bar', u'_raw_params': u'baz=boo'}
    assert parse_kv('foo=bar baz\\==boo') == {u'foo': u'bar', u'baz=': u'boo'}
    assert parse_kv('foo=bar baz\\===boo')

# Generated at 2022-06-11 08:54:58.431571
# Unit test for function split_args
def test_split_args():
    ''' check for failure cases '''
    # failure case 1: an unterminated quote, should raise a ValueError
    try:
        split_args("a='b c d")
    except ValueError:
        pass
    else:
        raise AssertionError("failed to raise when splitting on unterminated quotes")

    # failure case 2: an unbalanced jinja2 block, should raise an AnsibleParserError
    try:
        split_args("a='{{ foo }}")
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("failed to raise when splitting on an unbalanced jinja2 block")

    # failure case 3: an unbalanced jinja2 block, should raise an AnsibleParserError

# Generated at 2022-06-11 08:55:10.163727
# Unit test for function parse_kv
def test_parse_kv():
    kv = parse_kv('creates=/tmp/foo executable=/bin/sh')
    assert isinstance(kv, dict)
    assert len(kv) == 2
    assert kv['creates'] == '/tmp/foo'
    assert kv['executable'] == '/bin/sh'

    kv = parse_kv('creates=/bin/sh removes=/bin/ls')
    assert isinstance(kv, dict)
    assert len(kv) == 2
    assert kv['creates'] == '/bin/sh'
    assert kv['removes'] == '/bin/ls'

    kv = parse_kv('creates=/bin/sh removes=/bin/ls two=two')
    assert isinstance(kv, dict)
    assert len(kv) == 3

# Generated at 2022-06-11 08:55:20.312334
# Unit test for function parse_kv
def test_parse_kv():

    assert {} == parse_kv(None)
    assert {'a': 'b', 'd': 'e f'} == parse_kv(u"a=b c=d e= f='e f'")
    assert {'a': 'b', 'd': 'e f'} == parse_kv(u"a=b c=d e= f=\"e f\"")
    assert {'a': 'b', 'd': 'e f'} == parse_kv(u'a=b c=d e= f="e f"')
    assert {'a': 'b', 'd': 'e f'} == parse_kv(u'a=b c=d e= f=\'e f\'')

# Generated at 2022-06-11 08:55:32.174697
# Unit test for function split_args
def test_split_args():

    quotes = [
        u'"',
        u"'"
    ]
    spaces = [
        u' ',
        u''
    ]
    newlines = [
        u'\n',
        u''
    ]
    for quote in quotes:
        for space in spaces:
            for newline in newlines:
                args = join_args([
                    u"foo{0}bar{0}baz".format(quote),
                    u"foo={0}{0}{0}{0}{0}".format(quote),
                    u"bar={0}{0}{0}".format(quote),
                    u"baz={0}{0}{0}".format(quote)
                ])
                args_split = split_args(args)
                args_joined = join_args(args_split)
                assert args == args_joined

   

# Generated at 2022-06-11 08:55:42.121178
# Unit test for function split_args
def test_split_args():
    assert split_args("echo 'it''s'") == ['echo', '\'it\'\'s\'']
    assert split_args("echo 'it\'s'") == ['echo', '\'it\\\'s\'']
    assert split_args('''echo 'it's' '"world"' "\'world\' \"hello\"" '"world"' '\"world\" \'hello\'' "\"world\" 'hello'" 'world' hello''') == ['echo', '\'it\\\'s\'', '\'"world"\'', '"\\\'world\\\' \\"hello\\""', '\'"world"\'', '"\\"world\\" \\\'hello\\\'"', '"\\"world\\" \'hello\'"', 'world', 'hello']

# Generated at 2022-06-11 08:55:52.212701
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv(u"foo=bar bar=baz temp=`pwd` echo='foo bar'")
    assert result == {'foo': u'bar', 'bar': u'baz', 'temp': u'`pwd`', 'echo': u"'foo bar'", '_raw_params': u'temp=`pwd` echo=\'foo bar\''}, result
    result = parse_kv(u"foo=bar bar=baz temp=`pwd` echo='foo bar'", check_raw=True)
    assert result == {'foo': u'bar', 'bar': u'baz', 'temp': u'`pwd`', 'echo': u"'foo bar'"}, result

# Split a string of arguments into a list of args, handling
# quoted arguments and escaped characters

# Generated at 2022-06-11 08:56:02.501852
# Unit test for function split_args
def test_split_args():
    def _test(input_value, expected_output, msg):
        actual_output = split_args(input_value)
        if actual_output != expected_output:
            print("""test_split_args:
Failed on input: {0}
Expected: {1}
Actual: {2}""".format(repr(input_value),
                  repr(expected_output),
                  repr(actual_output)))
        else:
            print("test_split_args: {0}".format(msg))

    # Empty string
    _test('', [''], "Empty string")

    # Simple strings without any quoting
    _test('foo', ['foo'], "Simple string without any quoting")
    _test('foo bar', ['foo', 'bar'], "Simple string with spaces without any quoting")

# Generated at 2022-06-11 08:56:12.192316
# Unit test for function split_args
def test_split_args():
    # Basic tests for split_args()
    # Test for unbalanced quotes
    try:
        split_args(u"""'foo""")
    except AnsibleParserError:
        pass
    else:
        raise AssertionError(u"Expected exception for unbalanced quotes")

    # Test for unbalanced jinja2 blocks
    try:
        split_args(u"{{ foo")
    except AnsibleParserError:
        pass
    else:
        raise AssertionError(u"Expected exception for unbalanced jinja2 blocks")


    # Test for line continuation
    try:
        split_args(u"ls -alh \\")
    except AnsibleParserError:
        raise AssertionError(u"Unexpected exception for line continuation")

    # Test for invalid line continuation

# Generated at 2022-06-11 08:56:29.010689
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('arg=foo') == dict(arg=u'foo')
    assert parse_kv('arg1="foo" arg2=\'bar\'') == dict(arg1=u'foo', arg2=u'bar')
    assert parse_kv('arg1="foo" arg2=\'bar\' arg3=oops') == dict(arg1=u'foo', arg2=u'bar', _raw_params='arg3=oops')



# Generated at 2022-06-11 08:56:33.391210
# Unit test for function parse_kv
def test_parse_kv():
    args = "a=1 b='2' c=\"3\" d ='"
    options = parse_kv(args)
    assert options['a'] == '1'
    assert options['b'] == '2'
    assert options['c'] == '3'
    assert options['d'] == ''
    assert options['_raw_params'] == "d =' 4=4"



# Generated at 2022-06-11 08:56:44.156721
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv(u"foo=bar vvv=ccc=ddddd 'q = w = e'='q=w=e' d' '   f  =  b  '='  b   '")
    assert result == {u'vvv': u'ccc=ddddd', u'foo': u'bar', u'd f  =  b  ': u"b   ", u'q = w = e': u'q=w=e'}
    result = parse_kv(u"foo=bar vvv='ccc=ddddd' 'q = w = e'='q=w=e' d' '   f  =  b  '='  b   '")

# Generated at 2022-06-11 08:56:53.927709
# Unit test for function split_args
def test_split_args():
    from copy import deepcopy
    import pickle

# Generated at 2022-06-11 08:57:02.194053
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:12.114759
# Unit test for function split_args
def test_split_args():

    assert split_args("-h -i inventory") == ["-h", "-i", "inventory"]
    assert split_args("-h -i \"inventory\"") == ["-h", "-i", '"inventory"']
    assert split_args("-h -i 'inventory'") == ["-h", "-i", "'inventory'"]
    assert split_args("-h -i 'inventory with spaces'") == ["-h", "-i", "'inventory with spaces'"]
    assert split_args("-h -i 'inventory with spaces' playbook.yaml") == ["-h", "-i", "'inventory with spaces'", "playbook.yaml"]
    assert split_args("\"-h -i inventory\" playbook.yaml") == ["\"-h -i inventory\"", "playbook.yaml"]

# Generated at 2022-06-11 08:57:21.804306
# Unit test for function split_args
def test_split_args():
    assert split_args(u"{{ foo }}") == [u"{{ foo }}"]
    assert split_args(u"{{foo}}") == [u"{{foo}}"]
    assert split_args(u"{% foo %}") == [u"{% foo %}"]
    assert split_args(u"{%foo%}") == [u"{%foo%}"]
    assert split_args(u"{{ ''' foo ''' }}") == [u"{{ ''' foo ''' }}"]
    assert split_args(u"{{''' foo '''}}") == [u"{{''' foo '''}}"]
    assert split_args(u"{% ''' foo ''' %}") == [u"{% ''' foo ''' %}"]

# Generated at 2022-06-11 08:57:30.627581
# Unit test for function split_args

# Generated at 2022-06-11 08:57:39.233122
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function parse_kv:')
    result = parse_kv("a=1 b=2 c='3 z' d=\"4 y\"")
    print('    %s' %result)
    assert result == {'a': '1', 'b': '2', 'c': '3 z', 'd': '4 y'}
    result = parse_kv("a='1 2' b=\"3 4\"")
    print('    %s' %result)
    assert result == {'a': '1 2', 'b': '3 4'}
    result = parse_kv("a='1 2' b=\"3 4\" c='5 \" 6' d=\"7 ' 8\"")
    print('    %s' %result)

# Generated at 2022-06-11 08:57:48.191634
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv('foo=bar x=y'))
    assert parse_kv('foo=bar x=y') == {'foo': 'bar', 'x': 'y'}
    assert parse_kv('name="foo bar"') == {'name': 'foo bar'}
    assert parse_kv('') == {}
    assert parse_kv('foo') == {'_raw_params': 'foo'}
    assert parse_kv('foo bar') == {'_raw_params': 'foo bar'}
    assert parse_kv('foo="bar bar"') == {'foo': 'bar bar'}
    assert parse_kv('foo=bar bar=foo') == {'foo': 'bar', 'bar': 'foo'}

# Generated at 2022-06-11 08:58:09.054912
# Unit test for function split_args
def test_split_args():
    assert split_args(r'''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']
    assert split_args(r'''a=b c="foo bar"''') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 08:58:16.501039
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv('a=1,b=3') == {'a':'1','b':'3'}
  assert parse_kv('a=a\\,b,b=3') == {'a':'a,b','b':'3'}
  assert parse_kv('a=a\\=b,b=3') == {'a':'a=b','b':'3'}
  assert parse_kv('a=a\\=b,b=3') == {'a':'a=b','b':'3'}
  assert parse_kv('a=a\\\\,b,b=3') == {'a':'a\\\\','b':'3'}

# Generated at 2022-06-11 08:58:25.450137
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:31.142839
# Unit test for function split_args
def test_split_args():
    # Simple example
    assert split_args("arg1 arg2 arg3") == ["arg1", "arg2", "arg3"]
    # Simple example with new line
    assert split_args("arg1 arg2 arg3\n") == ["arg1", "arg2", "arg3\n"]
    # Simple example with spaces before
    assert split_args("    arg1 arg2 arg3") == ["arg1", "arg2", "arg3"]
    # Simple example with spaces after
    assert split_args("arg1 arg2 arg3    ") == ["arg1", "arg2", "arg3    "]
    # Example with line continuation
    assert split_args("arg1 arg2 arg3\\ arg4 arg5 arg6") == ["arg1", "arg2", "arg3 arg4", "arg5", "arg6"]
    #

# Generated at 2022-06-11 08:58:40.109004
# Unit test for function split_args
def test_split_args():
    parsed = split_args('foo="bar baz"')
    assert parsed == ['foo="bar baz"']

    parsed = split_args('foo="bar baz" foo2="bar2 baz"')
    assert parsed == ['foo="bar baz"', 'foo2="bar2 baz"']

    parsed = split_args('foo="bar baz" \ foo2="bar2 baz"')
    assert parsed == ['foo="bar baz"', 'foo2="bar2 baz"']

    parsed = split_args('foo="bar baz" \\\nfoo2="bar2 baz"')
    assert parsed == ['foo="bar baz"', 'foo2="bar2 baz"']


# Generated at 2022-06-11 08:58:51.683953
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:58.678448
# Unit test for function split_args
def test_split_args():
    # Test with Jinja2 print block
    args = '''printf '{{ foo }}'
        {{ bar }}
        {{ baz }}'''
    assert split_args(args) == ['printf', '\'{{ foo }}\'\n        {{ bar }}\n        {{ baz }}']
    # Test with Jinja2 block
    args = '''{% foo %}
        {% bar %}
        {% baz %}'''
    assert split_args(args) == ['{% foo %}\n        {% bar %}\n        {% baz %}']
    # Test with Jinja2 comment block
    args = '''{# foo #}
        {# bar #}
        {# baz #}'''

# Generated at 2022-06-11 08:59:10.318963
# Unit test for function split_args
def test_split_args():
    # Test 1: classic use case: args = "a=b c=d"
    args = "a=b c=d"
    params = split_args(args)
    assert params == ['a=b', 'c=d']

    # Test 2: classic use case: args = "a='b c' d='e f'"
    args = "a='b c' d='e f'"
    params = split_args(args)
    assert params == ['a=\'b c\'', 'd=\'e f\'']

    # Test 3: classic use case, but with double quote: args = 'a="b c" d="e f"'
    args = 'a="b c" d="e f"'
    params = split_args(args)
    assert params == ['a="b c"', 'd="e f"']



# Generated at 2022-06-11 08:59:20.992308
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv('foo=bar baz=quux', check_raw=True) == {u'foo': u'bar', u'baz': u'quux', u'_raw_params': u'foo=bar baz=quux'}
    assert parse_kv('foo bar') == {u'_raw_params': u'foo bar'}
    assert parse_kv('foo bar', check_raw=True) == {u'_raw_params': u'foo bar'}

# Generated at 2022-06-11 08:59:27.010937
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a='foo bar'") == ['a=\'foo bar\'']
    assert split_args("a=bar") == ['a=bar']
    assert split_args("a b") == ['a', 'b']
    assert split_args("a='b c'") == ['a=\'b c\'']
    assert split_args("a=\"b c\"") == ['a="b c"']
    input_str = "a=b c=\"{{ d }}\nef\" {{ g }} {% h %} {# i #}j"

# Generated at 2022-06-11 08:59:45.329223
# Unit test for function split_args
def test_split_args():
    ''' test split_args function '''

# Generated at 2022-06-11 08:59:54.767825
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=/some/path') == {'creates': '/some/path'}
    assert parse_kv('creates=/some/path removes=/some/path/else') == {'creates': '/some/path', 'removes': '/some/path/else'}
    assert parse_kv('creates=/some/path removes=/some/path/else warning=false') == {'creates': '/some/path', 'removes': '/some/path/else', '_raw_params': 'warning=false'}

# Split a string of parameters using the following rules:
# - double-quoted strings can contain whitespace and equal signs
# - single-quoted strings can contain equal signs and no whitespace
#
# More complex quoting is not supported, but should generally not be necessary
# in Ansible.
#

# Generated at 2022-06-11 09:00:03.803891
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args function
    '''
    def _test_unbalanced(input_args):
        '''
        Confirm exception is raised for unbalanced blocks or quotes.
        '''
        try:
            _ = split_args(input_args)
        except Exception as e:
            if 'unbalanced' in str(e):
                return True
        return False

    # confirm simple case of split on space
    assert split_args('a b c') == ['a', 'b', 'c']

    # confirm split on multi-character separator
    assert split_args('a_b_c', '_') == ['a', 'b', 'c']

    # confirm no split on quoted text

# Generated at 2022-06-11 09:00:12.626901
# Unit test for function parse_kv
def test_parse_kv():
    args = [
        'execute=False',
        'ignore_errors=True',
        'module=command',
        '_raw_params="echo hi"',
        '_uses_shell=True',
        'chdir=/tmp',
        'executable=bash',
        'strip_empty_ends=False',
        'stdin=heya',
        'stdin_add_newline=False',
        'warn=False',
    ]

# Generated at 2022-06-11 09:00:21.232534
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" \\') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" \\ ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" \\ \nd="foo bar"') == ['a=b', 'c="foo bar"', 'd="foo bar"']

# Generated at 2022-06-11 09:00:31.890841
# Unit test for function parse_kv
def test_parse_kv():
    from unittest import TestCase

    class TestParseKV(TestCase):
        def test_no_args(self):
            assert parse_kv(None) == {}
            assert parse_kv('') == {}

        def test_basic(self):
            assert parse_kv('a=b') == {'a': 'b'}

        def test_quote_arg(self):
            assert parse_kv('b="a b"') == {'b': 'a b'}

        def test_quote_arg_escape(self):
            assert parse_kv('c="a=b"') == {'c': 'a=b'}

        def test_quote_arg_escape2(self):
            assert parse_kv('c="a=b"') == {'c': 'a=b'}

# Generated at 2022-06-11 09:00:41.005463
# Unit test for function parse_kv
def test_parse_kv():
    """
    This tests the parse_kv function.
    These ones are from ansible/test/units/parsing/test_vault.
    """
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo=bar baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo=bar "baz foo"=foo') == {'foo': 'bar', 'baz foo': 'foo'}
    assert parse_kv('foo=bar "baz foo=foo"=foo') == {'foo': 'bar', 'baz foo=foo': 'foo'}

# Generated at 2022-06-11 09:00:53.217183
# Unit test for function split_args
def test_split_args():
    #Test 1 - Normal command
    test1_cmd = "yum -y install nginx"
    test1_result = ['yum', '-y', 'install', 'nginx']
    assert split_args(test1_cmd) == test1_result

    #Test 2 - Make sure quotes are parsed properly
    test2_cmd = "useradd -m -p '{{ user_pwd }}' {{ user_name }}"
    test2_result = ['useradd', '-m', '-p', "'{{ user_pwd }}'", '{{ user_name }}']
    assert split_args(test2_cmd) == test2_result

    #Test 3 - Mix up quotes and jinja2 blocks

# Generated at 2022-06-11 09:01:03.887723
# Unit test for function parse_kv
def test_parse_kv():
    print("Running test_parse_kv")
    option_dict = parse_kv("")
    assert option_dict == {}

    option_dict = parse_kv("hello=world")
    assert option_dict == {"hello": "world"}

    option_dict = parse_kv("hello=\"world\"")
    assert option_dict == {"hello": "world"}

    option_dict = parse_kv("hello=\"wor ld\"")
    assert option_dict == {"hello": "wor ld"}

    option_dict = parse_kv("hello='wor ld'")
    assert option_dict == {"hello": "wor ld"}

    option_dict = parse_kv("hello=\"wor ld", check_raw=True)

# Generated at 2022-06-11 09:01:16.249256
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(args=None)
    assert options == {}
    options = parse_kv(args=u'key1=value1')
    assert options == {u'key1': u'value1'}
    options = parse_kv(args=u'key1=value1 key2=value2')
    assert options == {u'key1': u'value1', u'key2': u'value2'}
    options = parse_kv(args=u'key1=value1 key2=value2 key3=value3')
    assert options == {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3'}

# Generated at 2022-06-11 09:01:34.335480
# Unit test for function parse_kv
def test_parse_kv():
    # What we know about it
    assert parse_kv('key1=value1 key2=value2') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv('"key1=value1" key2=value2') == {u'key2': u'value2'}
    assert parse_kv('''key1=value1 "key2=value2"''') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv(None) == {}
    assert parse_kv('key1=value1 \\= key2=value2') == {u'key1': u'value1 = key2', u'key2': u'value2'}

# Generated at 2022-06-11 09:01:44.481911
# Unit test for function parse_kv
def test_parse_kv():
    parser = parse_kv

# Generated at 2022-06-11 09:01:51.612349
# Unit test for function split_args
def test_split_args():
    def _test(args, expect, check_raw=False):
        got = parse_kv(args, check_raw=check_raw)
        assert expect == got, "For $$${args}$$$, got $$${got}$$$, expected $$${expect}$$$"
    # simple args
    _test("a=1 b=2", {"a":"1", "b":"2"})
    _test("a=1\nb=2", {"a":"1", "b":"2"})
    _test("a=1 b=2 c='foo bar'", {"a":"1", "b":"2", "c":"foo bar"})
    _test("a=1 b=2 c='foo bar'", {"a":"1", "b":"2", "c":"foo bar"})

# Generated at 2022-06-11 09:01:59.119882
# Unit test for function parse_kv
def test_parse_kv():
    data = dict(
        creates = '/path/to/a',
        removes = '/path/to/b',
        chdir = '/some/path',
        executable = '/usr/bin/perl',
        warn = True,
        stdin = 'some input',
        stdin_add_newline = True,
        strip_empty_ends = True,
    )

    options = parse_kv(join_args(['%s=%s' % (k, to_text(v)) for k, v in data.items()]), check_raw=True)
    assert options == data
    assert len(options) == len(data)

# Unit tests for function join_args

# Generated at 2022-06-11 09:02:07.306563
# Unit test for function split_args
def test_split_args():
  VALUE = "a=b c='d e f' g='h i j' l='m n o'\n  p='q r s' t='u v w' x='y z' x2='y z'"
  TARGET = ["a=b", "c='d e f'", "g='h i j'", "l='m n o'", "p='q r s'", "t='u v w'", "x='y z'", "x2='y z'"]

  result = split_args(VALUE)

  assert result == TARGET, "split_args produces unexpected output"
# run unit tests if executed as a main program
if __name__ == '__main__':
  test_split_args()

# Generated at 2022-06-11 09:02:18.731237
# Unit test for function split_args
def test_split_args():
    assert split_args("one two") == ["one", "two"]
    assert split_args("one 'two three'") == ["one", "'two three'"]
    assert split_args("one 'two ''three four'''") == ["one", "'two ''three four'''"]
    assert split_args("one 'two ''three four \\''five'") == ["one", "'two ''three four \\''five"]
    assert split_args("one 'two two' three") == ["one", "'two two'", "three"]
    assert split_args("one 'two two' three '''four'") == ["one", "'two two'", "three", "'''four'"]
    assert split_args("one 'two two' three '''four' four'") == ["one", "'two two'", "three", "'''four' four'"]

# Generated at 2022-06-11 09:02:27.993573
# Unit test for function split_args
def test_split_args():
    # quotes, jinja2 tokens, escaped quotes, escaped jinja2 tokens
    # all inside quotes
    input_str = '\'arg1=value1 arg2={{ foo }} arg3="{{ "foo" }}" arg4="{{ foo }}foo" arg5="{{ "foo" }}\\"\'\''
    expected_result = ['arg1=value1', 'arg2={{ foo }}', 'arg3="{{ "foo" }}"', 'arg4="{{ foo }}foo"', 'arg5="{{ "foo" }}\\"\'"']

    assert split_args(input_str) == expected_result

    # same as above, but with spaces before the quotes

# Generated at 2022-06-11 09:02:30.815001
# Unit test for function parse_kv
def test_parse_kv():
    args = "arg1=val1 arg2=val2 arg3=val3"
    assert parse_kv(args) == {'arg1': 'val1', 'arg2': 'val2', 'arg3': 'val3'}



# Generated at 2022-06-11 09:02:38.710427
# Unit test for function split_args
def test_split_args():
    test_string="hello\nworld"
    assert(split_args(test_string) == [u'hello\nworld'])
    test_string='''"hello world"\n"goodbye world"'''
    assert(split_args(test_string) == [u'"hello world"\n"goodbye world"'])
    test_string="{{foo}} {{bar}}"
    assert(split_args(test_string) == [u'{{foo}}', u'{{bar}}'])
    test_string='''"{{foo}}" "{{bar}}"'''
    assert(split_args(test_string) == [u'"{{foo}}" "{{bar}}"'])
    test_string='''"{{foo}}\nbar" "{{bar}}"'''

# Generated at 2022-06-11 09:02:48.087634
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:04.677257
# Unit test for function split_args
def test_split_args():
    import os
    import sys
    import shlex
    import tempfile
    import subprocess
    import re
    import signal

    _, test_exec = tempfile.mkstemp()
    _, test_tmp = tempfile.mkstemp()


# Generated at 2022-06-11 09:03:10.416210
# Unit test for function parse_kv
def test_parse_kv():
    # test regular unquoted key value pairs
    assert parse_kv("a=b c=d") == dict(a='b', c='d')
    assert parse_kv("a=b c=d e=f") == dict(a='b', c='d', e='f')
    assert parse_kv("a=b c=d e=f g=h") == dict(a='b', c='d', e='f', g='h')
    assert parse_kv("a=b c=d e=f g=h i=j") == dict(a='b', c='d', e='f', g='h', i='j')

    # test quotes
    assert parse_kv("a='b c' d=e") == dict(a='b c', d='e')

# Generated at 2022-06-11 09:03:22.538972
# Unit test for function parse_kv
def test_parse_kv():
    author = {'name': 'John Smith',
              'bogus_key': 'bogus_value',
              'age': '20',
              'books': 'little red riding hood,golden egg',
              'address': 'red house,#123,9th street',
              '_raw_params': '-name="John Smith" --bogus_key="bogus_value" age=20 \
                              books="little red riding hood,golden egg" \
                              address="red house,#123,9th street"'}
    result = parse_kv('-name="John Smith" --bogus_key="bogus_value" age=20 books="little red riding hood,golden egg" address="red house,#123,9th street"', check_raw=True)

    assert result == author

#

# Generated at 2022-06-11 09:03:31.803922
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function, does not cover all possible
    cases, but does cover the most common cases that were
    problematic before
    '''

    # test_input, desired_result

# Generated at 2022-06-11 09:03:39.224756
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv(None) == {}
  assert parse_kv('') == {}
  assert parse_kv('a=b') == {'a':'b'}
  assert parse_kv('a=b c=d') == {'a':'b', 'c':'d'}
  assert parse_kv('a="b c" d=e') == {'a':'b c', 'd':'e'}
  assert parse_kv('a="b \"c\"" d=e') == {'a':'b "c"', 'd':'e'}
  assert parse_kv('a=b "c d"=e') == {'a':'b', 'c d':'e'}

# Generated at 2022-06-11 09:03:51.675622
# Unit test for function split_args
def test_split_args():

    # test jinja2 blocks
    test_1 = """{{foo}}"""
    assert split_args(test_1) == ['{{', 'foo', '}}']
    test_2 = """{{foo}} bar"""
    assert split_args(test_2) == ['{{', 'foo', '}}', 'bar']
    test_3 = """{{foo}} bar {% if bar %} {{ foo }} {% endif %}"""
    assert split_args(test_3) == ['{{', 'foo', '}}', 'bar', '{%', 'if', 'bar', '%}', '{{', 'foo', '}}', '{%', 'endif', '%}']
    test_4 = """{{ foo }} {{ bar }}"""

# Generated at 2022-06-11 09:03:53.937656
# Unit test for function parse_kv
def test_parse_kv():
    assert {u'key': u'value', u'key2': u'value=value'} == parse_kv("key=value key2='value=value'")


# Generated at 2022-06-11 09:04:02.185753
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar" d="this is a \"test\""') == ['a=b', 'c="foo bar"', 'd="this is a \"test\""']
    assert split_args('a=b c="foo bar" d="this is a \'test\'"') == ['a=b', 'c="foo bar"', 'd="this is a \'test\'"']
    assert split_args("a=b c='foo bar' d='this is a \"test\"'") == ['a=b', 'c=\'foo bar\'', 'd=\'this is a \"test\"\'']