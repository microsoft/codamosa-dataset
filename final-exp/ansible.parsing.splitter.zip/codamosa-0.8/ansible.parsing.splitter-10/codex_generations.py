

# Generated at 2022-06-11 08:54:37.790478
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2 c=3') == dict(a='1', b='2', c='3')
    assert parse_kv('a=1 b=2 c=') == dict(a='1', b='2', c='')
    assert parse_kv('a=1 b=2 c') == dict(a='1', b='2', _raw_params='c')
    assert parse_kv('a=1 b=2 c=3 d') == dict(a='1', b='2', c='3', _raw_params='d')
    assert parse_kv('a=1 b=2 "c=3 d"') == dict(a='1', b='2', c='3 d')

# Generated at 2022-06-11 08:54:49.062271
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:01.088132
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic key-value
    assert parse_kv('foo=bar') == {'foo': 'bar'}

    # Test multiple keys
    assert parse_kv('foo=bar baz=faz') == {'foo': 'bar', 'baz': 'faz'}

    # Test escaped keys
    assert parse_kv(r'foo\ bar=bar') == {r'foo bar': 'bar'}

    # Test escaped equals
    assert parse_kv(r'foo\=bar=bar') == {r'foo=bar': 'bar'}

    # Test escaped keys and equals
    assert parse_kv(r'foo\=bar\ baz=bar') == {r'foo=bar baz': 'bar'}

    # Test escaped quotes
    assert parse_kv(r"foo='bar'")

# Generated at 2022-06-11 08:55:12.084963
# Unit test for function split_args

# Generated at 2022-06-11 08:55:23.567211
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.six import PY3

    def do(s):
        return join_args(split_args(s))

    assert do('a=b c="foo bar"') == u'a=b c="foo bar"'
    assert do(u'a=b c="foo bar"') == u'a=b c="foo bar"'
    assert do(u"a='b c'") == u"a='b c'"
    assert do(u'a=b c=\\"foo bar\\"') == u'a=b c="foo bar"'
    assert do(u"a=b c=\\'foo bar\\'") == u"a=b c='foo bar'"
    assert do(u"a=b c=\\'foo\\'") == u"a=b c='foo'"
    assert do

# Generated at 2022-06-11 08:55:35.815130
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('kv1=foo') == {'kv1': 'foo'}
    assert parse_kv('kv1=one two') == {'kv1': 'one two'}
    assert parse_kv('kv1="one two"') == {'kv1': 'one two'}
    assert parse_kv('kv1=\'one two\'') == {'kv1': 'one two'}
    assert parse_kv('kv1=\'one two\' kv2=1 "kv3=three four"') == {'kv1': 'one two', 'kv2': '1', 'kv3': 'three four'}

# Generated at 2022-06-11 08:55:43.864638
# Unit test for function split_args

# Generated at 2022-06-11 08:55:54.229282
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=quux") == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv("foo=bar baz=quux nux") == {'foo': 'bar', 'baz': 'quux nux', '_raw_params': 'nux'}
    assert parse_kv("foo=bar baz=quux nux", check_raw=False) == {'foo': 'bar', 'baz': 'quux nux'}
    assert parse_kv("foo=bar baz='qu\'ux' nux", check_raw=False) == {'foo': 'bar', 'baz': 'qu\'ux', '_raw_params': 'nux'}

# Generated at 2022-06-11 08:56:04.971340
# Unit test for function split_args
def test_split_args():
    assert split_args('no params') == ['no', 'params']
    assert split_args('--options "demo"'), ['--options', '"demo"']
    assert split_args('--options "demo with spaces"'), ['--options', '"demo with spaces"']
    assert split_args('--options "demo with spaces" --second-option') == ['--options', '"demo with spaces"', '--second-option']
    assert split_args('--options "demo with spaces"\n--second-option') == ['--options', '"demo with spaces"', '--second-option']
    assert split_args('--options "demo with spaces \\\\"') == ['--options', '"demo with spaces \\"']

# Generated at 2022-06-11 08:56:14.049346
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("foo") == ['foo']
    assert split_args("echo 'a=b'") == ["echo 'a=b'"]
    assert split_args("escape=this\\ stuff") == ['escape=this\\ stuff']
    assert split_args("escape=this\\ stuff\\ and\\ that") == ['escape=this\\ stuff\\ and\\ that']
    assert split_args("a=b c=d e=\"foo bar\"") == ['a=b', 'c=d', 'e="foo bar"']
    assert split_args("a=b c=d e=\"foo bar\"") == ['a=b', 'c=d', 'e="foo bar"']

# Generated at 2022-06-11 08:56:50.898749
# Unit test for function parse_kv

# Generated at 2022-06-11 08:56:59.915728
# Unit test for function split_args

# Generated at 2022-06-11 08:57:01.161505
# Unit test for function parse_kv
def test_parse_kv():
    # TODO: Write tests for function parse_kv
    pass


# Generated at 2022-06-11 08:57:10.844632
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:20.792241
# Unit test for function parse_kv
def test_parse_kv():

    # no changes are needed for this to pass
    x = parse_kv("a=b c=d")
    assert len(x.keys()) == 2
    assert x['a'] == 'b'
    assert x['c'] == 'd'

    x = parse_kv("a=b c=d  e=f  g h")
    assert len(x.keys()) == 3
    assert x['a'] == 'b'
    assert x['c'] == 'd'
    assert x['e'] == 'f'
    assert x['_raw_params'] == "g h"

    x = parse_kv("""a=b c=d  e=f
g h
""")
    assert len(x.keys()) == 3
    assert x['a'] == 'b'

# Generated at 2022-06-11 08:57:29.695917
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:38.326229
# Unit test for function split_args

# Generated at 2022-06-11 08:57:47.215873
# Unit test for function split_args
def test_split_args():
  from textwrap import dedent
  def f(args, expected):
      r = split_args(args)
      msg = "%s: Expected=%s; got=%s" % (args, expected, r)
      assert r == expected, msg
  f("a=b", ['a=b'])
  f("a=b \"c=d\" e='f' g=\"h=i\"", ['a=b', '"c=d"', "e='f'", 'g="h=i"'])
  f("a={{ 'b=c' }}", ['a={{', "'b=c'", '}}'])
  f("a=\"{{ 'b=c' }}\"", ['a="{{', "'b=c'", '}}"'])

# Generated at 2022-06-11 08:57:56.472551
# Unit test for function split_args
def test_split_args():
    assert split_args(u'') == []
    assert split_args(u'a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u'  a=b c="foo bar"') == ['  a=b', 'c="foo bar"']
    assert split_args(u"a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args(u"a=b c=foo\\ bar") == ['a=b', "c=foo bar"]
    assert split_args(u"a=b c=foo\\") == ['a=b', "c=foo\\"]
    assert split_args(u"a=b c=\\") == ['a=b', "c=\\"]

# Generated at 2022-06-11 08:58:05.750883
# Unit test for function split_args
def test_split_args():
    '''
    Calls split_args on a list of arguments, and asserts we get the expected
    output.
    '''

    # no args
    assert [] == split_args('')

    # single arg
    assert ['a'] == split_args('a')
    assert ['a/b'] == split_args('a/b')
    assert ['a/b/'] == split_args('a/b/')

    # two simple args
    assert ['a', 'b'] == split_args('a b')
    assert ['a', ' b'] == split_args('a  b')
    assert ['a', ' b'] == split_args('a \n b')

    # three simple args
    assert ['a', 'b', 'c'] == split_args('a b c')

# Generated at 2022-06-11 08:58:27.357696
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b\nc=\"foo bar\"") == ['a=b', 'c="foo bar"']

    # test nesting
    assert split_args("a=\"{{b}}\"") == ['a="{{b}}"']
    assert split_args("a=\"{{b}}\" c=d") == ['a="{{b}}"', 'c=d']
    assert split_args("a=\"{{b}}\" c=d e=\"{{f}}\"") == ['a="{{b}}"', 'c=d', 'e="{{f}}"']

# Generated at 2022-06-11 08:58:34.373809
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parsing of key=value args')

# Generated at 2022-06-11 08:58:45.835993
# Unit test for function split_args
def test_split_args():
    assert split_args(u"param1 param2") == ["param1", "param2"]
    assert split_args(u"param1 param2\nparam3") == ["param1", "param2\nparam3"]
    assert split_args(u"param1='foo bar' param2") == ["param1='foo bar'", "param2"]
    assert split_args(u"param1='foo bar' param2\nparam3") == ["param1='foo bar'", "param2\nparam3"]
    assert split_args(u"param1=\"foo bar\" param2") == ["param1=\"foo bar\"", "param2"]
    assert split_args(u"param1=\"foo bar\" param2\nparam3") == ["param1=\"foo bar\"", "param2\nparam3"]
    assert split_args

# Generated at 2022-06-11 08:58:55.341579
# Unit test for function parse_kv
def test_parse_kv():
    print("Basic test of parse_kv()")
    # Test parsing of single key-value pair
    args = "greeting=hello world"
    options = parse_kv(args)
    assert options['greeting'] == "hello world"
    # Test parsing of multiple key-value pairs
    args = "greeting=hello world salutation=goodbye planet"
    options = parse_kv(args)
    assert options['greeting'] == "hello world"
    assert options['salutation'] == "goodbye planet"
    # Test parsing of multiple key-value pairs
    args = "greeting=hello world salutation=goodbye planet"
    options = parse_kv(args)
    assert options['greeting'] == "hello world"
    # Test parsing of multiple key-value pairs

# Generated at 2022-06-11 08:59:05.279245
# Unit test for function split_args
def test_split_args():
    # Test simple params
    assert split_args('a b c') == ['a', 'b', 'c']

    # Test different quoting schemes
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Test spaces inside quotes
    assert split_args('c="foo bar"') == ['c="foo bar"']
    assert split_args("c='foo bar'") == ["c='foo bar'"]

    # Test line continuation
    assert split_args('c="foo bar\\"') == ['c="foo bar\\']
    assert split_args("c='foo bar\\'") == ["c='foo bar\\"]

# Generated at 2022-06-11 08:59:08.474997
# Unit test for function parse_kv
def test_parse_kv():
    print('test')
    a = 'a=b b=c'
    b = parse_kv(a)
    print(b)
test_parse_kv()

# Generated at 2022-06-11 08:59:19.838162
# Unit test for function parse_kv
def test_parse_kv():
    play_source = dict(
        name = "test",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='rm -rf /tmp/a /tmp/b')),
            dict(action=dict(module='shell', args='echo test="a b" c=d e=')),
            dict(action=dict(module='shell', args='echo test=a\ b\ c d=e')),
            dict(action=dict(module='shell', args='test ! -d /tmp/a')),
            dict(action=dict(module='shell', args='test ! -d /tmp/b')),
        ]
    )
    # play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    # t

# Generated at 2022-06-11 08:59:26.266350
# Unit test for function split_args
def test_split_args():
    # Test the initial split on newlines
    assert split_args('foo\nbar\nbaz') == ['foo', 'bar', 'baz']

    # Test line continuation
    assert split_args(r'foo \ bar') == ['foo bar']
    assert split_args(r'foo \ bar \ baz') == ['foo bar baz']
    assert split_args(r'foo\nbar \ baz') == ['foo', 'bar baz']
    assert split_args(r'foo \ bar\nbaz') == ['foo bar', 'baz']

    # Test quotes
    assert split_args('a="foo bar"') == ['a="foo bar"']
    assert split_args("a='foo bar'") == ["a='foo bar'"]

# Generated at 2022-06-11 08:59:32.265173
# Unit test for function split_args

# Generated at 2022-06-11 08:59:43.367841
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert parse_kv(u"foo=bar") == {u"foo": u"bar"}
    assert parse_kv(u"foo='bar baz'") == {u"foo": u"bar baz"}
    assert parse_kv(u'foo="bar baz"') == {u"foo": u"bar baz"}
    assert parse_kv(u'foo="bar baz') == {u"foo": u"bar", u"baz": u""}
    assert parse_kv(u"foo=bar baz=baz") == {u"foo": u"bar", u"baz": u"baz"}

# Generated at 2022-06-11 09:00:03.426971
# Unit test for function split_args
def test_split_args():
    # -- Unit test for function split_args
    # -- Author: Boris Stoyanov <bstoyanov@vmware.com>
    sample = 'echo "123" {{ foo }}'
    assert split_args(sample) == ['echo', '"123"', '{{', 'foo', '}}']
    sample = 'a="b c" d=e'
    assert split_args(sample) == ['a="b c"', 'd=e']
    sample = r'''a='b c'"d=e' 'f g\'h' "i'j\"k" '''
    assert split_args(sample) == ['a=\'b c"d=e\'', '\'f g\\\'h\'', '"i\'j\\"k"']

# Generated at 2022-06-11 09:00:12.378294
# Unit test for function split_args
def test_split_args():
    params = []

    # [itemidx, item, tokens, params]

# Generated at 2022-06-11 09:00:20.978638
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:31.488434
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:40.402217
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:52.937839
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=1 b="2" c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv(u'a=1 b="2 3" c=4') == {u'a': u'1', u'b': u'2 3', u'c': u'4'}
    assert parse_kv(u'a=1 b="2=3" c=4') == {u'a': u'1', u'b': u'2=3', u'c': u'4'}

# Generated at 2022-06-11 09:00:59.764901
# Unit test for function split_args
def test_split_args():
    '''Simple unit test for function split_args'''
    # Simple case
    params = split_args("a=b c=d")
    assert params == ["a=b", "c=d"]

    # With newline
    params = split_args("a=b\nc=d")
    assert params == ["a=b", "c=d"]

    # With escaped newline
    params = split_args("a=b\\\nc=d")
    assert params == ["a=b", "c=d"]

    # With escaped quotes
    params = split_args("a=b\\\"c=d\\\"")
    assert params == ["a=b\\\"c=d\\\""]

    # With quotes
    params = split_args("a=b c=\"d\"")

# Generated at 2022-06-11 09:01:11.280053
# Unit test for function split_args
def test_split_args():
    from collections import namedtuple
    from difflib import unified_diff
    from textwrap import dedent

    Test = namedtuple('Test', ['input', 'expected'])

# Generated at 2022-06-11 09:01:21.704596
# Unit test for function split_args

# Generated at 2022-06-11 09:01:33.484217
# Unit test for function split_args
def test_split_args():
    assert split_args(u"{{ foo }}") == [u"{{ foo }}"]
    assert split_args(u"{{ foo }} {% bar %}") == [u"{{ foo }}", u"{% bar %}"]
    assert split_args(u"{{foo}} {% bar %}") == [u"{{foo}}", u"{% bar %}"]
    assert split_args(u"{{foo}}{{bar}} {% baz %}") == [u"{{foo}}{{bar}}", u"{% baz %}"]
    assert split_args(u"{{foo}}  {{bar}} {% baz %}") == [u"{{foo}}", u"{{bar}}", u"{% baz %}"]

# Generated at 2022-06-11 09:01:49.983077
# Unit test for function split_args
def test_split_args():
    # TODO: This is a slow test, it should be split into multiple tests
    uniques = set()
    duplicates = []

# Generated at 2022-06-11 09:01:58.762389
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for parse_kv, which is also exported as parse_kv_list. Please
    keep this up to date with the latest changes:
    https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/basic.py
    '''
    def check_kv(args, result, check_raw=False):
        assert args is not None
        assert result is not None
        kv = parse_kv(args, check_raw=check_raw)
        assert kv == result, '%r != %r (check_raw=%r)' % (kv, result, check_raw)


# Generated at 2022-06-11 09:02:08.189443
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d', check_raw=True) == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u'a=b c=d e') == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}
    assert parse_kv(u'a=b c=d e', check_raw=True) == {u'a': u'b', u'c': u'd', u'_raw_params': u'e'}

# Generated at 2022-06-11 09:02:19.339463
# Unit test for function parse_kv
def test_parse_kv():
    print("Testing function parse_kv")
    print("parsing 'a=b c=d'")
    print("Should get {'a': 'b', 'c': 'd'}")
    print("Got: ", parse_kv("a=b c=d"))
    print("parsing 'a=b c=\"a c\" d=\\'e f\\''")
    print("Should get {'a': 'b', 'c': 'a c', 'd': '\\'e f\\''}")
    print("Got: ", parse_kv("a=b c=\"a c\" d=\\'e f\\'"))
    print("parsing 'a=b'")
    print("Should get {'a': 'b'}")
    print("Got: ", parse_kv("a=b"))
    print

# Generated at 2022-06-11 09:02:28.742932
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(args="openshift_master_identity_providers=[{'name': 'htpasswd_auth', 'login': 'true', 'challenge': 'true', 'kind': 'HTPasswdPasswordIdentityProvider', 'filename': 'htpasswd_auth'}]") == {"openshift_master_identity_providers":"[{'name': 'htpasswd_auth', 'login': 'true', 'challenge': 'true', 'kind': 'HTPasswdPasswordIdentityProvider', 'filename': 'htpasswd_auth'}]"}
    assert parse_kv(args='') == {}
    assert parse_kv(args="task_name='task_name'") == {'task_name': 'task_name'}

# Generated at 2022-06-11 09:02:36.678041
# Unit test for function parse_kv
def test_parse_kv():

    # Test basic case
    assert parse_kv('foo=bar') == {'foo': u'bar'}
    assert parse_kv('foo=bar bar=baz') == {'foo': u'bar', 'bar': u'baz'}

    # Test empty option value
    assert parse_kv('foo=') == {'foo': u''}

    # Test empty option name
    assert parse_kv('=bar') == {'': u'bar'}

    # Test empty option name and value
    assert parse_kv('=') == {'': u''}

    # Test escaping =
    assert parse_kv('foo\=bar=baz') == {'foo=bar': u'baz'}

    # Test escaping \\ in option name

# Generated at 2022-06-11 09:02:44.894087
# Unit test for function parse_kv
def test_parse_kv():
    args_dict = parse_kv('foo=bar baz=quux')
    assert 1 == len(args_dict)
    assert 'bar' == args_dict['foo']
    assert 'quux' == args_dict['baz']

    args_dict = parse_kv('foo=bar baz=quux _raw_params=\\"hello world\\"')
    assert 2 == len(args_dict)
    assert 'bar' == args_dict['foo']
    assert 'quux' == args_dict['baz']
    assert 'hello world' == args_dict['_raw_params']

    # Test with positional arguments
    args_dict = parse_kv('foo=bar baz quux')
    assert 2 == len(args_dict)
    assert 'bar' == args_dict['foo']

# Generated at 2022-06-11 09:02:55.599008
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}

    assert parse_kv('a=b') == {
        'a': 'b'
    }
    assert parse_kv('a="b"') == {
        'a': 'b'
    }
    assert parse_kv('a="b b"') == {
        'a': 'b b'
    }
    assert parse_kv('a=1') == {
        'a': '1'
    }
    assert parse_kv('a=1 b=2') == {
        'a': '1',
        'b': '2'
    }

# Generated at 2022-06-11 09:03:06.215840
# Unit test for function parse_kv
def test_parse_kv():
    # Basic test case
    arg = "foo=bar"
    assert parse_kv(arg) == {u'foo': u'bar'}

    # Value quoting test case
    arg = "foo='bar baz'"
    assert parse_kv(arg) == {u'foo': u'bar baz'}

    # Value quoting test case #2
    arg = "foo='bar=baz'"
    assert parse_kv(arg) == {u'foo': u'bar=baz'}

    # Multiple args
    arg = "foo='bar baz' arg='foo bar'"
    assert parse_kv(arg) == {u'foo': u'bar baz', u'arg': u'foo bar'}

    # Tuple args
    arg = "foo='bar baz' arg=('foo bar')"


# Generated at 2022-06-11 09:03:15.974768
# Unit test for function split_args

# Generated at 2022-06-11 09:03:33.507751
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:40.114469
# Unit test for function split_args
def test_split_args():
    assert split_args("echo hello world") == ["echo", "hello", "world"]
    assert split_args("echo 'hello world'") == ["echo", "'hello world'"]
    assert split_args("echo \"hello world\"") == ["echo", "\"hello world\""]
    assert split_args("echo '{'") == ["echo", "'{'"]
    assert split_args("echo '}}'") == ["echo", "'}}'"]
    assert split_args("echo 'foo {{bar}} baz'") == ["echo", "'foo {{bar}} baz'"]
    assert split_args("echo foo\\ bar") == ["echo", "foo\\", "bar"]
    assert split_args("echo '{#'") == ["echo", "'{#'"]

# Generated at 2022-06-11 09:03:52.208050
# Unit test for function parse_kv
def test_parse_kv():
    #TODO:
    # Check if decode_escapes work properly
    assert parse_kv('a=1 b=2 c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('c=3 b=2 a=1') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 b=2 c=3 a=4') == {u'a': u'4', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 a=2 a=3') == {u'a': u'3'}
    assert parse_kv('a=b c=d')

# Generated at 2022-06-11 09:04:01.028167
# Unit test for function parse_kv