

# Generated at 2022-06-11 08:54:43.316409
# Unit test for function split_args

# Generated at 2022-06-11 08:54:51.647082
# Unit test for function parse_kv
def test_parse_kv():
    print("***** Testing parse_kv function *****")

    # Test 1:
    print("*** Test 1 ***")
    test1_args = "one two=three four=\"five six seven eight\" nine= ten=eleven"
    result1 = parse_kv(test1_args)

    print("Result:")
    print(result1)
    print("Expected:")
    print({'one': None, 'two': 'three', 'four': 'five six seven eight', 'nine': '', 'ten': 'eleven'})

    # Test 2:
    print("*** Test 2 ***")
    test2_args = "one=two three=four five=six seven=eight nine ten=eleven"
    result2 = parse_kv(test2_args)

    print("Result:")
    print(result2)


# Generated at 2022-06-11 08:55:04.279937
# Unit test for function split_args
def test_split_args():
  assert split_args("/usr/bin/docker run -t -i -v {{ foo }}:/etc/ansible/facts.d -v {{ bar }}:/tmp/artifacts {{ baz }}") == ['/usr/bin/docker', 'run', '-t', '-i', '-v', '{{ foo }}:/etc/ansible/facts.d', '-v', '{{ bar }}:/tmp/artifacts', '{{ baz }}']
  assert split_args("docker run -t -i -v {{ foo }}:/etc/ansible/facts.d -v {{ bar }}:/tmp/artifacts {{ baz }}") == ['docker', 'run', '-t', '-i', '-v', '{{ foo }}:/etc/ansible/facts.d', '-v', '{{ bar }}:/tmp/artifacts', '{{ baz }}']
  assert split

# Generated at 2022-06-11 08:55:14.068498
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:25.684570
# Unit test for function split_args
def test_split_args():
    # Note: some structutal test cases are in test_module_utils.py

    # Here we're testing the "smartness" of split_args.  You'll go mad if you
    # try to carefully craft a test case for every possible combination of
    # whitespace and quotes.  We're just going to check a couple of cases that
    # might actually happen in practice.

    def assert_split_args(args, expected):
        actual = split_args(args)
        assert actual == expected, "Expected {0} but got {1}".format(expected, actual)

        # Make sure we can re-assemble the arguments
        assert join_args(actual) == args, \
            "Re-assemble failed for args {0}".format(args)

    assert_split_args('foo', ['foo'])
    assert_split_

# Generated at 2022-06-11 08:55:37.942408
# Unit test for function split_args

# Generated at 2022-06-11 08:55:46.668498
# Unit test for function split_args
def test_split_args():
    assert split_args('this is my argument') == ['this', 'is', 'my', 'argument']
    assert split_args('this is my "argument"'), ['this', 'is', 'my', '"argument"']
    assert split_args('this is my "argu\\"ment"'), ['this', 'is', 'my', '"argu\\', '"ment"']
    assert split_args('this is my "argu\\"ment" with another arg'), ['this', 'is', 'my', '"argu\\', '"ment"', 'with', 'another', 'arg']
    assert split_args('this is my \'argu\\\'ment\''), ['this', 'is', 'my', '\'argu\\\'', 'ment\'']

# Generated at 2022-06-11 08:55:57.320776
# Unit test for function split_args
def test_split_args():
    # this is a helper function that asserts that the given args
    # result in the expected output when split_args() is run against them
    def assert_split_args(args, expected):
        actual = split_args(args)
        assert actual == expected, "Expected %r, but got %r when splitting %r" % (expected, actual, args)

    # simple args with no spaces
    assert_split_args("foo", ["foo"])
    assert_split_args("foo=bar", ["foo=bar"])
    assert_split_args("foo='bar'", ["foo='bar'"])
    assert_split_args("foo=\"bar\"", ["foo=\"bar\""])
    assert_split_args("foo=\"bar&baz\"", ["foo=\"bar&baz\""])

# Generated at 2022-06-11 08:56:07.811407
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}
    assert parse_kv('foo=bar baz=quux spam="foo bar"') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'foo bar'}
    assert parse_kv('foo=bar baz=quux spam="foo\nbar"') == {u'foo': u'bar', u'baz': u'quux', u'spam': u'foo\nbar'}
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}

# Generated at 2022-06-11 08:56:17.648525
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('gibberish={% if foo %} bar {% endif %}') == ['gibberish={% if foo %} bar {% endif %}']
    assert split_args('a="{{ b }}"') == ['a="{{ b }}"']
    assert split_args('a=b\nc="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']
    assert split_args('a=b c="foo\\"bar"') == ['a=b', 'c="foo\\"bar"']

# Generated at 2022-06-11 08:56:41.740620
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv('check_command  =  "check_dummy!200"   '))
    print(parse_kv('check_command  =  check_dummy!200'))
    print(parse_kv('command = /usr/bin/mycommand other=args'))
    print(parse_kv('command = /usr/bin/mycommand "other args"'))
    print(parse_kv('command = /usr/bin/mycommand "other args" --extra=arg'))
    print(parse_kv('command = /usr/bin/mycommand "other args" --extra=arg --extra2'))
    print(parse_kv('command = /usr/bin/mycommand "other args" --extra=arg --extra2=extra2'))

# Generated at 2022-06-11 08:56:50.461845
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('foo=bar baz=biz') == ['foo=bar', 'baz=biz']
    assert split_args('foo="bar baz" biz="biz baz"') == ['foo="bar baz"', 'biz="biz baz"']
    assert split_args('{{ foo }}') == ['{{', 'foo', '}}']
    assert split_args('a=b {{ foo }}') == ['a=b', '{{', 'foo', '}}']

# Generated at 2022-06-11 08:56:59.526890
# Unit test for function split_args
def test_split_args():
    assert split_args('1 2 3') == ['1', '2', '3']
    assert split_args('1 2\\\n 3') == ['1', '2\\\n', '3']
    assert split_args('1 2 3\\\n') == ['1', '2', '3\\\n']
    assert split_args('1 2 3\n4\n') == ['1', '2', '3\n', '4\n']
    assert split_args('1\n2\n3\n') == ['1\n', '2\n', '3\n']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

# Generated at 2022-06-11 08:57:09.214310
# Unit test for function parse_kv
def test_parse_kv():
    string = "key1=fartblaster key2=bus key3=monkey"
    options = parse_kv(string)
    assert isinstance(options, dict)
    assert 'key1' in options.keys()
    assert 'key2' in options.keys()
    assert 'key3' in options.keys()
    assert options['key1'] == 'fartblaster'
    assert options['key2'] == 'bus'
    assert options['key3'] == 'monkey'

    string = "key1=fartblaster key2=X=1 key3=monkey"
    options = parse_kv(string)
    assert isinstance(options, dict)
    assert 'key1' in options.keys()
    assert 'key2' in options.keys()
    assert 'key3' in options.keys()

# Generated at 2022-06-11 08:57:19.037039
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar'], "simple split failed"
    assert split_args('foo\\ bar') == ['foo bar'], "escaped newline in space-split failed"
    assert split_args('') == [], "empty split failed"
    assert split_args('             ') == [], "just whitespace failed"
    assert split_args('foo=bar') == ['foo=bar'], "simple key=value failed"
    assert split_args('foo="ba r"') == ['foo="ba r"'], "quoted string failed"
    assert split_args('foo="bar"') == ['foo=bar'], "quoted string no spaces failed"

# Generated at 2022-06-11 08:57:27.895299
# Unit test for function parse_kv
def test_parse_kv():
    import os
    import sys
    import yaml
    from ansible.parsing.dataloader import DataLoader

    from ansible.module_utils import basic

    parser = basic.AnsibleModule(
        argument_spec = dict(
            arg1 = dict(required=True),
            arg2 = dict(required=True),
            arg3 = dict(required=True),
        ),
        supports_check_mode=True
    )

    modulename = os.path.splitext(os.path.basename(__file__))[0]
    parameters = parse_kv(parser.params["arg1"])

    print("Running test cases ...")
    print("actual %s" % (parameters))
    print("expected %s" % (dict()))
    assert parameters == dict()

    parameters = parse

# Generated at 2022-06-11 08:57:36.587363
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'') == {}
    assert parse_kv(u'x=y') == {u'x': u'y'}
    assert parse_kv(u'x=y z=w') == {u'x': u'y', u'z': u'w'}
    assert parse_kv(u'x=') == {u'x': u''}
    assert parse_kv(u'x="y"') == {u'x': u'y'}
    assert parse_kv(u'x=\'"y\'') == {u'x': u'"y'}
    assert parse_kv(u'x=y z="w v"') == {u'x': u'y', u'z': u'w v'}

# Generated at 2022-06-11 08:57:45.242606
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b") == { "a": "b" }
    assert parse_kv("a=b c=d") == { "a": "b", "c": "d" }
    assert parse_kv("a=b 'c=d'") == { "a": "b", "c=d": "" }
    # when given invalid or unquoted shell syntax, should do its best to parse it
    assert parse_kv("a=b 'c=d e=f'") == { "a": "b", "c=d e=f": "" }
    assert parse_kv("a=b x=y c=d") == { "a": "b", "c": "d", "x": "y" }

# Generated at 2022-06-11 08:57:54.623923
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test of function parse_kv.
    '''
    # pass only test case
    assert parse_kv('hello=world') == {'hello': 'world'}
    assert parse_kv('hello = world') == {'hello': 'world'}
    assert parse_kv('hello= world') == {'hello': 'world'}
    assert parse_kv('hello =world') == {'hello': 'world'}
    assert parse_kv('hello= world extra') == {'hello': 'world extra'}
    assert parse_kv('content="hello=world extra"') == {'content': 'hello=world extra'}
    assert parse_kv('content="hello=world extra" hello=world') == {'content': 'hello=world extra', 'hello': 'world'}
   

# Generated at 2022-06-11 08:58:03.942765
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.basic import AnsibleModule, module_args_parser

    def run_module():
        # load the module
        module = AnsibleModule(
            argument_spec=dict(
                _ansible_selinux_special_fs=dict(),
                _raw_params=dict(type='str'),
                _uses_shell=dict(type='bool'),
                argv=dict(type='list'),
                chdir=dict(type='path'),
                creates=dict(type='path'),
                executable=dict(type='path'),
                removes=dict(type='path'),
                strip_empty_ends=dict(type='bool'),
                warn=dict(type='bool'),
            ),
            # not checking because of daisy chain to file module
            bypass_checks=True,
        )

        import sys


# Generated at 2022-06-11 08:58:21.674754
# Unit test for function split_args

# Generated at 2022-06-11 08:58:30.154954
# Unit test for function parse_kv
def test_parse_kv():
    inp = u"/usr/bin/foo bar=baz"
    expected = dict(executable=u'/usr/bin/foo', _raw_params=u'bar=baz')
    assert parse_kv(inp) == expected

    inp = u"rm -rf /tmp/foo --force"
    expected = dict(creates=u'/tmp/foo', _raw_params=u'--force')
    assert parse_kv(inp) == expected

    inp = u'\s-\Syntax\sError\s-\srm\s-\sfoo'
    expected = dict(_raw_params=inp)
    assert parse_kv(inp) == expected

    inp = u'rm -rf /tmp/foo --force=false'

# Generated at 2022-06-11 08:58:38.473646
# Unit test for function split_args
def test_split_args():

    # Basic testing
    assert split_args('a=b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args(' a = b ') == ['a=b']
    assert split_args('a= b') == ['a=b']
    assert split_args('a =b') == ['a=b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d e=f') == ['a=b', 'c=d', 'e=f']
    assert split_args('a=b\nc=d') == ['a=b','c=d']

    # Quotes

# Generated at 2022-06-11 08:58:50.235740
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value') == {'key': 'value'}
    assert parse_kv('key1=value1 key2=value2') == {'key1': 'value1',
                                                   'key2': 'value2'}
    assert parse_kv('key1=value1 key2=value2 key3=') == {'key1': 'value1',
                                                         'key2': 'value2',
                                                         'key3': ''}
    assert parse_kv('key1=value1 key2="value2"') == {'key1': 'value1',
                                                     'key2': 'value2'}

# Generated at 2022-06-11 08:58:57.797091
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common._collections_compat import Mapping

    def test_split_args_parse(s, expected_results):
        results = split_args(s)
        assert isinstance(results, (list, Mapping, tuple))
        assert results == expected_results, "Expected %s but got %s" % (
            expected_results, results)

    test_split_args_parse(
        'a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    test_split_args_parse(
        "a='b c'", ["a='b c'"])
    test_split_args_parse(
        "first='b c'\\\nsecond='foo bar'",
        ["first='b c'\\", "second='foo bar'"])
   

# Generated at 2022-06-11 08:59:09.400523
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a=b "c=d"') == ['a=b', 'c=d']
    assert split_args('a=b "c=d e=f"') == ['a=b', 'c=d e=f']
    assert split_args('a=b "c=d \\"e=f\\""') == ['a=b', 'c=d \\"e=f\\"']
    assert split_args('a=b "c=d \\"e=f\\"" g=h') == ['a=b', 'c=d \\"e=f\\"', 'g=h']

# Generated at 2022-06-11 08:59:20.538162
# Unit test for function split_args
def test_split_args():
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('foo "bar foobar"') == [u'foo', u'"bar foobar"']
    assert split_args('"foo bar" foobar') == [u'"foo bar"', u'foobar']

    assert split_args('"foo bar"{{ baz }}') == [u'"foo bar"', u'{{', u'baz', u'}}']
    assert split_args('"foo bar"{% baz %}foobar') == [u'"foo bar"', u'{%', u'baz', u'%}', u'foobar']

# Generated at 2022-06-11 08:59:33.131409
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == dict(foo="bar")
    assert parse_kv("foo='bar'") == dict(foo="bar")
    assert parse_kv("'foo=bar'") == dict(_raw_params="foo=bar")
    assert parse_kv('foo="bar"') == dict(foo="bar")
    assert parse_kv('"foo=bar"') == dict(_raw_params="foo=bar")
    assert parse_kv('foo=bar baz=bang') == dict(foo="bar", baz="bang")
    assert parse_kv("foo='bar baz' bang='foo bar'") == dict(foo="bar baz", bang="foo bar")
    assert parse_kv("foo='bar baz'") == dict(foo="bar baz")
    assert parse_

# Generated at 2022-06-11 08:59:43.925382
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar\nblah') == ['foo', 'bar\n', 'blah']
    assert split_args('foo bar\\\nblah') == ['foo', 'barblah']
    assert split_args('foo "bar \\\nblah"') == ['foo', '"bar blah"']
    assert split_args(r"foo 'bar \\nblah'") == [r"foo", r"'bar \nblah'"]
    assert split_args(r"foo 'bar \\\'nblah'") == [r"foo", r"'bar \'nblah'"]

# Generated at 2022-06-11 08:59:49.215513
# Unit test for function parse_kv
def test_parse_kv():
    def test(x, expected):
        assert parse_kv(x) == expected

    # test empty input
    test('', {})
    test(None, {})

    # test basic input (simple key)
    test('foo=bar', {u'foo': u'bar'})

    # test values without a key
    test('"foo1', {u'_raw_params': u'"foo1'})
    test('foo1"', {u'_raw_params': u'foo1"'})
    test('=foo1', {u'_raw_params': u'=foo1'})
    test('=foo1=foo2', {u'_raw_params': u'=foo1=foo2'})

# Generated at 2022-06-11 09:00:06.084762
# Unit test for function split_args
def test_split_args():
    import pytest

# Generated at 2022-06-11 09:00:12.590310
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv')
    if parse_kv('') != {}:
        raise Exception('parse_kv failed')
    if parse_kv('foo=bar') != {u'foo': u'bar'}:
        raise Exception('parse_kv failed')
    if parse_kv('foo=bar baz=foo') != {u'foo': u'bar', u'baz': u'foo'}:
        raise Exception('parse_kv failed')
    if parse_kv('foo="bar" baz=foo') != {u'foo': u'bar', u'baz': u'foo'}:
        raise Exception('parse_kv failed')

# Generated at 2022-06-11 09:00:21.190328
# Unit test for function split_args
def test_split_args():
    # Ensure that unbalanced args raise an exception
    for args in [u"arg1 arg2 {{ arg3 }}",
                 u"arg1 arg2 {% arg3 %}",
                 u"arg1 arg2 {# arg3 #}",
                 u"arg1 'arg2'",
                 u"arg1 \"arg2\"",
                 ]:
        try:
            split_args(args)
        except AnsibleParserError:
            pass
        else:
            assert False, "args %s should have raised an exception" % args

    # Ensure that we can handle comments and nested args

# Generated at 2022-06-11 09:00:31.847504
# Unit test for function parse_kv
def test_parse_kv():
    # Create a dictionary of tests and expected results
    test_data = dict()

    # simple tests
    test_data[''] = dict()
    test_data['a'] = dict()
    test_data['a=b'] = {'a': 'b'}
    test_data['a=b c=d'] = {'a': 'b', 'c': 'd'}
    test_data['a=b c=d e'] = {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    test_data['a=b c=d e f'] = {'a': 'b', 'c': 'd', '_raw_params': 'e f'}

# Generated at 2022-06-11 09:00:41.005293
# Unit test for function split_args
def test_split_args():
    # Test #1
    assert split_args('a=b') == ['a=b']
    # Test #2
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    # Test #3
    assert split_args('a=b c="foo \\"bar\\" qux"') == ['a=b', 'c="foo \\"bar\\" qux"']
    # Test #4
    assert split_args('a=b c="foo \\"bar qux"') == ['a=b', 'c="foo \\"bar qux"']
    # Test #5
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar\\"']
    # Test #6

# Generated at 2022-06-11 09:00:53.217217
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a='foo bar'") == ["a='foo bar'"]
    assert split_args("a=\"foo bar\"") == ['a="foo bar"']
    assert split_args("a=10 c=20") == ['a=10', 'c=20']
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c='foo bar' d=20") == ['a=b', "c='foo bar'", 'd=20']

# Generated at 2022-06-11 09:00:58.476461
# Unit test for function split_args
def test_split_args():
    tests = dict(
        cmd='foo "bar baz"',
        args=['foo', '"bar baz"'],
        jinja2_args=['foo', '"{{ foo.bar }} baz"'],
        print_depth=0,
        block_depth=0,
        comment_depth=0,
    )
    assert split_args(tests['cmd']) == tests['args']
    assert split_args(tests['jinja2_args'][1]) == tests['args']

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 09:01:09.397985
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import shlex_quote

    assert parse_kv('foo=bar baz=qux', check_raw=boolean(True)) == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz=qux', check_raw=boolean(False)) == {u'foo': u'bar', u'baz': u'qux'}

    assert parse_kv('foo="bar baz" "q=ux"', check_raw=boolean(True)) == {u'foo': u'bar baz', u'q=ux': u''}

# Generated at 2022-06-11 09:01:20.705864
# Unit test for function split_args
def test_split_args():
    ''' test split_args as found in module_utils/basic.py '''
    import sys
    import platform

    # Python 3.2 changed the quoting algorithm and caused the unit test to fail.
    # If we're running on 3.2, skip all of the module utils tests
    if sys.version_info[:2] == (3, 2):
        print("Skipping module utils tests as Ansible does not officially support Python 3.2")
        return

    # FIXME: move this unit test out of here, and into tests/unit/module_utils/basic.py
    # this was moved here so it could be run when the module_utils directory is imported
    # for backwards compatibility.

    # Expected vs. actual arg strings

# Generated at 2022-06-11 09:01:25.116650
# Unit test for function split_args
def test_split_args():
    print ("Unit test for function split_args")
    try:
        print (split_args('a=b c="foo bar"'))
        print (split_args('echo {{ item }}'))
        print (split_args('echo {{ item }}\necho {{ item }}'))
        print (split_args('echo {{ item }}\\\necho {{ item }}'))
        print (split_args('echo {{ item }}\\'))
        print ("PASS")
    except:
        print ("FAILED")


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 09:01:41.731934
# Unit test for function split_args
def test_split_args():

    # test 1: simple args
    assert split_args(u'foo=bar baz') == [u'foo=bar', u'baz']

    # test 2: basic quotes
    assert split_args(u'foo="bar baz" spam') == [u'foo=bar baz', u'spam']

    # test 3: escaped quotes
    assert split_args(u'foo="bar\"baz\"spam"') == [u'foo=bar"baz"spam']

    # test 4: escaped quotes at end
    assert split_args(u'foo="bar\"baz\"spam\\"') == [u'foo=bar"baz"spam"']

    # test 5: escaped quotes at end

# Generated at 2022-06-11 09:01:50.132682
# Unit test for function split_args
def test_split_args():
    """This function contains unittests for split_args"""
    # This is a simple command line with a single param
    output = split_args(u'foo=bar')
    assert len(output) == 1
    assert output[0] == 'foo=bar'

    # A command line with extra spaces
    output = split_args(u'foo=bar   baz=stuff')
    assert len(output) == 2
    assert output[0] == 'foo=bar'
    assert output[1] == 'baz=stuff'

    # A command line with a space in a quoted string
    output = split_args(u'foo=bar "baz stuff"')
    assert len(output) == 2
    assert output[0] == 'foo=bar'
    assert output[1] == '"baz stuff"'

    # A command

# Generated at 2022-06-11 09:01:58.919058
# Unit test for function split_args

# Generated at 2022-06-11 09:02:08.405353
# Unit test for function split_args

# Generated at 2022-06-11 09:02:19.493452
# Unit test for function parse_kv
def test_parse_kv():
    def kv_compare(str, expect_opts, expect_params):
        opts = parse_kv(str, True)
        for k in expect_opts:
            assert opts[k] == expect_opts[k]
        if expect_params is None:
            assert not '_raw_params' in opts
        else:
            assert opts['_raw_params'] == expect_params

    kv_compare(
        'foo=abc bar="baz ff"',
        {'foo': u'abc', 'bar': u'baz ff'},
        None
    )

    kv_compare(
        'foo bar=baz',
        {},
        'foo bar=baz'
    )


# Generated at 2022-06-11 09:02:28.902521
# Unit test for function split_args
def test_split_args():
    # Simple splitting test
    args = 'echo "test" "cmd"'
    assert split_args(args) == [u'echo', u'"test"', u'"cmd"']

    # Test splitting on quotes
    args = 'echo "test cmd"'
    assert split_args(args) == [u'echo', u'"test cmd"']

    args = 'echo "test cmd'
    assert split_args(args) == [u'echo', u'"test cmd']

    args = 'echo "test cmd\\'
    assert split_args(args) == [u'echo', u'"test cmd\\']

    args = 'echo "test cmd\\" '
    assert split_args(args) == [u'echo', u'"test cmd\\"']

    args = 'echo "test cmd\\" more'

# Generated at 2022-06-11 09:02:36.823241
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value') == {'key': 'value'}
    assert parse_kv('key=value value2=value2') == {'key': 'value', 'value2': 'value2'}

    assert parse_kv('') == {}

    assert parse_kv('k1=v1 k2=v2 k3') == {'k1': 'v1', 'k2': 'v2', '_raw_params': 'k3'}
    assert parse_kv('k1=v1 k2=v2 k3', check_raw=False) == {'k1': 'v1', 'k2': 'v2'}


# Generated at 2022-06-11 09:02:45.049702
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar bar=baz') == {'foo': 'bar',
                                           'bar': 'baz'}
    assert parse_kv('') == {}

    # raw params
    assert parse_kv('host=hostname -v') == {'host': 'hostname',
                                            '_raw_params': '-v'}
    assert parse_kv('host=hostname -v -vv') == {'host': 'hostname',
                                                '_raw_params': '-v -vv'}
    assert parse_kv('host=hostname -v -vv', check_raw=True) == {'host': 'hostname',
                                                                '_raw_params': '-v -vv'}

# Generated at 2022-06-11 09:02:47.435606
# Unit test for function split_args
def test_split_args():
    raise NotImplementedError("test_split_args is not implemented")
# test_split_args()

# Generated at 2022-06-11 09:02:58.514806
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing function parse_kv\n')
    r = parse_kv('asdf=foo asdf2 = foo2 baz=')
    assert r == {'asdf': 'foo', 'asdf2': 'foo2', 'baz': ''}
    r = parse_kv('asdf=foo asdf2 = "foo2 with spaces" baz=')
    assert r == {'asdf': 'foo', 'asdf2': 'foo2 with spaces', 'baz': ''}
    r = parse_kv('"asdf=foo asdf2 =" "foo2 with spaces" baz=')
    assert r == {u'asdf=foo asdf2 =': 'foo2 with spaces', 'baz': ''}

# Generated at 2022-06-11 09:03:16.105240
# Unit test for function parse_kv
def test_parse_kv():
  x='-a a="c" -b b="d" -c c="e" -a f="g" --a f="g" --b a=b --b e="f"'
  print(parse_kv(x))

test_parse_kv()

# Generated at 2022-06-11 09:03:27.853776
# Unit test for function parse_kv
def test_parse_kv():
    d = parse_kv(u"src=/tmp/foo dest=/tmp/bar")
    assert d[u'src'] == u'/tmp/foo'
    assert d[u'dest'] == u'/tmp/bar'
    d = parse_kv(u"src=/tmp/foo 'dest=/tmp/bar'")
    assert d[u'src'] == u'/tmp/foo'
    assert d[u'dest'] == u'/tmp/bar'
    d = parse_kv(u"src=/tmp/foo 'dest=/tmp/b=ar'")
    assert d[u'src'] == u'/tmp/foo'
    assert d[u'dest'] == u'/tmp/b=ar'

# Generated at 2022-06-11 09:03:36.567284
# Unit test for function parse_kv
def test_parse_kv():

    def check(v1, v2):
        v3 = parse_kv(v1, check_raw=False)
        assert v2 == v3

    # Check that both with and without leading spaces in the option name work
    check('foo=bar', dict(foo='bar'))
    check('   foo=bar', dict(foo='bar'))

    # Check that both with and without quotes work
    check('foo="bar"', dict(foo='bar'))
    check("foo='bar'", dict(foo='bar'))
    check("foo='bar baz'", dict(foo='bar baz'))
    check("foo=\"bar bar\"", dict(foo='bar bar'))
    check("foo='bar\"bar'", dict(foo='bar"bar'))

# Generated at 2022-06-11 09:03:47.307903
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test of the parse_kv function. Pass or fail output will be displayed.
    '''

    #
    # A list of tuples of acceptable input and expected output
    #

# Generated at 2022-06-11 09:03:57.552402
# Unit test for function parse_kv
def test_parse_kv():
    assert (parse_kv('a=b c="d e" f=\'g h\'') == {'a': 'b', 'c': 'd e', 'f': 'g h'})
    assert (parse_kv('a=b c="d e" f=\'g h\' i') == {'_raw_params': 'i', 'a': 'b', 'c': 'd e', 'f': 'g h'})
    assert (parse_kv('a=b c="d e" f=\'g h\' i', check_raw=True) == {'a': 'b', 'c': 'd e', 'f': 'g h', '_raw_params': 'i'})