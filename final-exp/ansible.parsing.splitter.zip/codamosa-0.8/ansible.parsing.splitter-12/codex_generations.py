

# Generated at 2022-06-11 08:54:32.005993
# Unit test for function split_args
def test_split_args():
    failure_count = 0
    # Generate list of tests from test_data.txt
    test_data = open('test_data.txt', 'r')
    tests = [tuple(line.strip().split('|')) for line in test_data]
    #for t in tests:
    for test in tests:
        args, expected = test
        result = split_args(args)
        expected = expected.split(',')
        # Remove empty strings
        result = filter(None, result)
        expected = filter(None, expected)
        if set(result) != set(expected):
            print("{0} | {1} | {2}".format(args, expected, result))
            failure_count += 1
    print("{0} tests failed".format(failure_count))

# Generated at 2022-06-11 08:54:42.967809
# Unit test for function parse_kv
def test_parse_kv():
    # Test with no arguments
    assert parse_kv('') == {}
    # Test with simple arguments
    assert parse_kv('arg1=value1 arg2=value2') == {
        "arg1": "value1",
        "arg2": "value2",
    }
    # Test with escaped arguments
    assert parse_kv('arg1=value1 arg2=value2\ a arg3=value3\ b') == {
        "arg1": "value1",
        "arg2": "value2 a",
        "arg3": "value3 b",
    }
    # Test with escaped "="

# Generated at 2022-06-11 08:54:49.796762
# Unit test for function split_args
def test_split_args():
    print('*** split_args testing')

# Generated at 2022-06-11 08:54:58.440581
# Unit test for function split_args
def test_split_args():
    """
    Basic test of split and join args.  We want to make sure that args
    that are split are joined back together properly after parsing.
    """

# Generated at 2022-06-11 08:55:10.208707
# Unit test for function split_args

# Generated at 2022-06-11 08:55:17.409873
# Unit test for function split_args

# Generated at 2022-06-11 08:55:29.391875
# Unit test for function split_args
def test_split_args():
    """
    Unit test for function split_args
    """

# Generated at 2022-06-11 08:55:40.548913
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    if split_args("a=b c=\"foo bar\"") != ['a=b', "c=\"foo bar\""]:
        raise AssertionError('split_args("a=b c=\"foo bar\"") != ["a=b", "c=\"foo bar\""]')

# Generated at 2022-06-11 08:55:50.454182
# Unit test for function split_args
def test_split_args():
    res = split_args(u"echo foo bar")
    assert res == [u"echo", u"foo", u"bar"]

    res = split_args(u"echo {{ foo }}")
    assert res == [u"echo", u"{{ foo }}"]

    res = split_args(u"echo {{ foo }} bar {{ baz }}")
    assert res == [u"echo", u"{{ foo }} bar {{ baz }}"]

    res = split_args(u"echo '{{ foo }}'")
    assert res == [u"echo", u"'{{ foo }}'"]

    res = split_args(u"echo '{{ foo }}' '{{ bar }}'")
    assert res == [u"echo", u"'{{ foo }}' '{{ bar }}'"]

    res = split_args(u"echo \"{{ foo }}\"")


# Generated at 2022-06-11 08:56:00.517796
# Unit test for function split_args

# Generated at 2022-06-11 08:56:33.001355
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("creates=/tmp/file1 removes=/tmp/file2") == {"creates": "/tmp/file1",
                                                           "removes": "/tmp/file2"}
    # This test reveals a subtle bug in the code in parse_kv
    assert parse_kv("creates=/tmp/file1=1 removes=/tmp/file2") == {"creates": "/tmp/file1=1",
                                                          "removes": "/tmp/file2"}

    # Test for a valid ASCII-encoded Unicode character (SPACE).
    # Python does not have support for ASCII when using the "unicode-escape"
    # codec.  One workaround is to use str.decode() with a default encoding
    # of "ASCII" for "unicode-escape" characters.
    #
    # !!! DANG

# Generated at 2022-06-11 08:56:43.852880
# Unit test for function parse_kv
def test_parse_kv():
    def test_opt(options, key, value):
        assert options[key] == value

    # test key=value parsing
    options = parse_kv('one=1 two=2')
    yield test_opt, options, 'one', '1'
    yield test_opt, options, 'two', '2'

    # test string quoting
    options = parse_kv('one="1 two three" two=2')
    yield test_opt, options, 'one', '1 two three'
    yield test_opt, options, 'two', '2'

    # test free form string parsing
    options = parse_kv('one=1 two=2 three four five=five six seven')
    yield test_opt, options, '_raw_params', 'three four five=five six seven'
    yield test_opt, options, 'one',

# Generated at 2022-06-11 08:56:53.627687
# Unit test for function split_args
def test_split_args():
    def _assert_split(s):
        spl = split_args(" ".join(s))
        assert len(s) == len(spl), "Test: {0}, Split: {1}".format(" ".join(s), spl)
        for i in range(0, len(s)):
            assert s[i] == spl[i], "Test: {0}, Split: {1}".format(" ".join(s), spl)

    _assert_split(["a=b", "c=\"foo bar\""])
    _assert_split(["a=b", "c=\"foo bar\"", "creates=x"])
    _assert_split(["a=b", "c=\"foo bar\"", "creates=x", "d=\"{{ foo }}\""])

# Generated at 2022-06-11 08:57:02.001512
# Unit test for function split_args
def test_split_args():
    """
    Test split_args() against a variety of input strings
    """
    # Tests that are expected to pass

# Generated at 2022-06-11 08:57:11.958823
# Unit test for function split_args
def test_split_args():
    # Test simple case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test unterminated string in quotes
    try:
        split_args('a=b c="foo')
        raise AssertionError("failed to catch unterminated string in quotes")
    except Exception:
        pass

    # Test unterminated string in quotes in context
    try:
        split_args('a=b c="foo bar" r="doomed')
        raise AssertionError("failed to catch unterminated string in quotes")
    except Exception:
        pass

    # Test string with newline
    assert split_args('a=b c="foo\nbar"') == ['a=b', 'c="foo\nbar"']

    # Test string with newline and

# Generated at 2022-06-11 08:57:21.679937
# Unit test for function split_args
def test_split_args():
    # FIXME: put these in a py.test or nosetests test case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo \\\'bar baz\\\' boo"') == ['a=b', 'c="foo \\\'bar baz\\\' boo"']
    assert split_args('a=b "c=\\\\"') == ['a=b', '"c=\\\\"']
    assert split_args('a=b "c=\\\\ "') == ['a=b', '"c=\\\\ "']
    assert split_args('a=b "c=\\\\ "') == ['a=b', '"c=\\\\ "']

# Generated at 2022-06-11 08:57:30.513914
# Unit test for function parse_kv
def test_parse_kv():
    """
    test for function parse_kv
    """
    # should get non dict back if args is None
    assert isinstance(parse_kv(None), dict) is True

    # should get empty dict back if args is an empty string
    assert isinstance(parse_kv(''), dict) is True
    assert parse_kv('') == {}

    # should get empty dict back if args is a string of one or more spaces
    assert isinstance(parse_kv(' '), dict) is True
    assert parse_kv(' ') == {}
    assert isinstance(parse_kv('   '), dict) is True
    assert parse_kv('   ') == {}

    # should correctly parse simple key-value args
    assert isinstance(parse_kv('key=value'), dict) is True
    assert parse_

# Generated at 2022-06-11 08:57:38.799078
# Unit test for function parse_kv
def test_parse_kv():
    #Test if the empty string is parsed correctly
    assert parse_kv("") == {}

    #Test if key values are parsed correctly
    assert parse_kv("key=value") == {"key":"value"}
    assert parse_kv("key=value1 value2") == {"key":"value1 value2"}
    assert parse_kv("key=\"value1 value2\"") == {"key":"value1 value2"}

    #Test if multiple key values are parsed correctly
    assert parse_kv("key1=value1 key2=value2") == {"key1":"value1", "key2":"value2"}
    assert parse_kv("key1=\"value1 value2\" key2=value2") == {"key1":"value1 value2", "key2":"value2"}


# Generated at 2022-06-11 08:57:47.703926
# Unit test for function split_args

# Generated at 2022-06-11 08:57:57.028701
# Unit test for function split_args
def test_split_args():
#        print "Parsing: %s" % self.line
    ok = True
    params = []
    arg_s = 'a=b c="foo bar"'
    params = split_args(arg_s)
    if params[0] != 'a=b' or params[1] != 'c="foo bar"' or len(params) != 2:
        ok = False
    arg_s = 'ansible_ssh_user={{ ansible_ssh_user }}'
    params = split_args(arg_s)
    if params[0] != 'ansible_ssh_user={{ ansible_ssh_user }}' or len(params) != 1:
        ok = False
    arg_s = 'ansible_ssh_user="{{ ansible_ssh_user }}"'
    params = split_args(arg_s)


# Generated at 2022-06-11 08:58:32.577757
# Unit test for function parse_kv
def test_parse_kv():
    args = """creates=/tmp/foo removes=/tmp/bar chdir=/tmp/bam stdin=hello world executable=/usr/bin/python warn=False"""
    options = parse_kv(args, check_raw=True)
    assert options.get('creates').endswith('/tmp/foo')
    assert options.get('removes').endswith('/tmp/bar')
    assert options.get('chdir').endswith('/tmp/bam')
    assert options.get('stdin') == 'hello world'
    assert options.get('executable').endswith('/usr/bin/python')
    assert options.get('warn') == 'False'
    raw_params = options.get('_raw_params')
    # make sure there are no embedded quotes in the returned value

# Generated at 2022-06-11 08:58:43.213676
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("A=B C=D E=F") == {u'A': u'B', u'C': u'D', u'E': u'F'}
    assert parse_kv("A=B C=D E=F", check_raw=True) == {u"A": u'B', u'C': u'D', u'E': u'F', u'_raw_params': u''}
    assert parse_kv("A=B C=D E=F G") == {u'A': u'B', u'C': u'D', u'E': u'F G'}

# Generated at 2022-06-11 08:58:50.294182
# Unit test for function parse_kv
def test_parse_kv():
    arg = '''
    this is a test
    foo="this is a \\"quoted\\" string" bar='this is a \\\' single quoted\\\' string'
    baz=3
    '''
    assert parse_kv(arg) == dict(
        _raw_params='this is a test',
        foo='this is a "quoted" string',
        bar="this is a ' single quoted' string",
        baz='3'
    )



# Generated at 2022-06-11 08:58:55.841873
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar a=B b c=') == dict(foo=u'bar', a=u'B', b=None, c=u'')
    assert parse_kv("foo='   a   b   c   '") == dict(foo=u'   a   b   c   ')
    assert parse_kv("foo='   a   b   c   '", check_raw=True) == dict(foo=u'   a   b   c   ', _raw_params=u"foo='   a   b   c   '")
    assert parse_kv("foo='a b c'") == dict(foo=u'a b c')

# Generated at 2022-06-11 08:59:05.902935
# Unit test for function parse_kv
def test_parse_kv():
    kv_string1 = "a=b c=d"
    kv_dict1 = parse_kv(kv_string1)
    assert kv_dict1.get("a") == "b"
    assert kv_dict1.get("c") == "d"

    kv_string2 = "a=b c=d e"
    kv_dict2 = parse_kv(kv_string2)
    assert kv_dict2.get("a") == "b"
    assert kv_dict2.get("c") == "d"
    assert kv_dict2.get("_raw_params") == "e"

    kv_string3 = "a=b c=d e=f g"
    kv_dict3 = parse_kv(kv_string3)
   

# Generated at 2022-06-11 08:59:17.812523
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar arg1 arg2 arg3') == {u'foo': u'bar', u'_raw_params': u'arg1 arg2 arg3'}
    assert parse_kv('foo=bar baz="boo far"') == {u'foo': u'bar', u'baz': u'boo far'}
    assert parse_kv('foo=bar baz="foo bar" arg1 arg2 arg3') == {u'foo': u'bar', u'baz': u'foo bar', u'_raw_params': u'arg1 arg2 arg3'}

# Generated at 2022-06-11 08:59:25.278266
# Unit test for function split_args
def test_split_args():
    def test(line, expected):
        print(line)
        args = split_args(line)
        print(args)
        assert args == expected
        assert join_args(args) == line

    test('foo bar', ['foo', 'bar'])
    test('foo bar="baz quux"', ['foo', 'bar="baz quux"'])
    test('foo bar="baz \\"quux\\""', ['foo', 'bar="baz \\"quux\\""'])
    test('foo bar="baz \\"quux\\" blah"', ['foo', 'bar="baz \\"quux\\" blah"'])
    test('foo bar="baz \\\\"quux\\\\\\" blah"', ['foo', 'bar="baz \\\\"quux\\\\\\" blah"'])

# Generated at 2022-06-11 08:59:30.462777
# Unit test for function split_args
def test_split_args():
    def assert_split(args, expected):
        result = split_args(args)
        assert result == expected, u"Failed to split: %r" % args

    assert_split("a=b c=d", ["a=b", "c=d"])
    assert_split("a=b 'c d'", ["a=b", "'c d'"])
    assert_split("a=b 'c d", ["a=b", "'c", "d"])
    assert_split("a=b c=d 'e f'", ["a=b", "c=d", "'e f'"])
    assert_split("a=b c=d \"e f\"", ["a=b", "c=d", "\"e f\""])

# Generated at 2022-06-11 08:59:42.032917
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo\nbar') == ['foo\n', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "bar baz') == ['foo', '"bar', 'baz']
    assert split_args('foo "bar \'baz') == ['foo', '"bar', '\'baz']
    assert split_args('foo bar\nbaz') == ['foo', 'bar\n', 'baz']
    assert split_args('foo bar\\\nbaz') == ['foo', 'bar\\\nbaz']

# Generated at 2022-06-11 08:59:48.379508
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:11.277362
# Unit test for function parse_kv
def test_parse_kv():
    def kv_to_str(kv):
        return ' '.join([str(k) + '=' + str(v) for k, v in kv.items()])

    def assert_kv_equal(s, kv):
        assert parse_kv(s) == kv

    assert_kv_equal('', {})
    assert_kv_equal('a=1 b=2 c=3', {'a': '1', 'b': '2', 'c': '3'})
    assert_kv_equal(kv_to_str({'a': '1', 'b': '2', 'c': '3'}), {'a': '1', 'b': '2', 'c': '3'})

# Generated at 2022-06-11 09:00:15.234122
# Unit test for function parse_kv
def test_parse_kv():
    params = 'foo=bar baz=qux "th=is is=a test" this="is a=test"'
    output = {'foo': 'bar', 'baz': 'qux', "th=is is=a test": None, 'this': 'is a=test'}
    assert parse_kv(params) == output



# Generated at 2022-06-11 09:00:24.345295
# Unit test for function split_args

# Generated at 2022-06-11 09:00:34.366676
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args()
    '''
    assert split_args("a=b c=\"foo bar\"") == ["a=b", "c=\"foo bar\""]
    assert split_args("a='b'{{foo}}bar") == ["a='b'{{foo}}bar"]
    assert split_args("a='b{{foo}}bar'") == ["a='b{{foo}}bar'"]
    assert split_args("a='b\"{{foo}}bar'") == ["a='b\"{{foo}}bar'"]
    assert split_args("a=b bar") == ["a=b", "bar"]
    assert split_args("a=b 'bar'") == ["a=b", "'bar'"]

# Generated at 2022-06-11 09:00:44.537910
# Unit test for function split_args
def test_split_args():
    test_input = ("""

      this='is' a="test" for splitting 'args properly'

      """)
    output = parse_kv(test_input)
    assert output == {u'this': u'is', u'a': u'test', u'for': u'splitting', u'args': u'properly'}

    # test that we can properly handle jinja blocks
    # inside "single" quotes
    test_input = """this='foo {{bar}} baz'"""
    output = parse_kv(test_input)
    assert output == {u'this': u'foo {{bar}} baz'}

    # test that we can properly handle jinja blocks
    # and double quotes inside "single" quotes
    test_input = """this='foo {{bar}} baz "foo" '"""
   

# Generated at 2022-06-11 09:00:55.876577
# Unit test for function parse_kv
def test_parse_kv():
    '''
    function: ansible.module_utils.common.parse_kv
    purpose: verify that all possible key value combinations
             are correctly split
    '''

# Generated at 2022-06-11 09:01:06.719615
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=foo') == {u'a': u'foo'}
    assert parse_kv('a=foo b=bar') == {u'a': u'foo', u'b': u'bar'}
    assert parse_kv('a=foo b= bar') == {u'a': u'foo', u'b': u'bar'}
    assert parse_kv('a=foo b= bar c="quux vut"') == {u'a': u'foo', u'b': u'bar', u'c': u'quux vut'}

# Generated at 2022-06-11 09:01:18.964003
# Unit test for function split_args
def test_split_args():
    args = "{{ foo }}"
    assert split_args(args) == ['{{ foo }}']

    args = "{{ foo }} bar"
    assert split_args(args) == ['{{ foo }}', 'bar']

    args = "{{ foo }}bar"
    assert split_args(args) == ['{{ foo }}bar']

    args = "{{ foo }}    bar"
    assert split_args(args) == ['{{ foo }}', 'bar']

    args = "{{ foo }} \n bar"
    assert split_args(args) == ['{{ foo }}', 'bar']

    # use lots of spaces and tabs to test consecutive newlines
    args = "spam with {{ lots }} \n of \n {{ whitespace }} \t and {{ tabs }}"

# Generated at 2022-06-11 09:01:25.360428
# Unit test for function parse_kv
def test_parse_kv():
    # Test invalid input
    invalid_input = "foo bar baz"
    try:
        parse_kv(invalid_input)
        assert False
    except AnsibleParserError:
        pass

    # Test without raw params
    simple_input = "foo=bar baz=biz"
    result = parse_kv(simple_input)
    assert result.get('foo') == "bar"
    assert result.get('baz') == "biz"
    assert len(result.keys()) == 2

    # Test with raw params
    complex_input = "foo=bar baz=biz 'weird param'='with spaces'"
    result = parse_kv(complex_input)
    assert result.get('foo') == "bar"
    assert result.get('baz') == "biz"

# Generated at 2022-06-11 09:01:36.350409
# Unit test for function parse_kv

# Generated at 2022-06-11 09:01:51.369037
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.text.converters import to_bytes
    import mock

    def _count_jinja2_blocks(token, cur_depth, open_token, close_token):
        '''
        this function counts the number of opening/closing blocks for a
        given opening/closing type and adjusts the current depth for that
        block based on the difference
        '''
        num_open = token.count(open_token)
        num_close = token.count(close_token)
        if num_open != num_close:
            cur_depth += (num_open - num_close)
            if cur_depth < 0:
                cur_depth = 0
        return cur_depth

    def _decode_escapes(s):
        def decode_match(match):
            return codecs.dec

# Generated at 2022-06-11 09:02:00.251283
# Unit test for function split_args

# Generated at 2022-06-11 09:02:10.111618
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1') == {u'a': u'1'}
    assert parse_kv('"a"="1"') == {u'a': u'1'}
    assert parse_kv('a=1 b=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv('a=b+c') == {u'a': u'b+c'}
    assert parse_kv('a="b c"') == {u'a': 'b c'}
    assert parse_kv('a="b"c"') == {u'a': u'bc'}
    assert parse_kv('a="b\"c"')

# Generated at 2022-06-11 09:02:10.940320
# Unit test for function parse_kv
def test_parse_kv():
    pass


# Generated at 2022-06-11 09:02:21.117366
# Unit test for function parse_kv
def test_parse_kv():
    # if we get a dict as input, return it
    assert parse_kv({'a': 1}) == {'a': 1}

    # check a string
    assert parse_kv('a=1') == {'a': '1'}

    # check to make sure a raw parameter is detected
    assert parse_kv('a=1 b=1') == {'a': '1', 'b': '1'}

    # check quotes
    assert parse_kv('a="b c"') == {'a': 'b c'}
    assert parse_kv('a="b=c d"') == {'a': 'b=c d'}
    assert parse_kv("a='b c'") == {'a': 'b c'}

# Generated at 2022-06-11 09:02:30.539157
# Unit test for function split_args
def test_split_args():
    # This method is used by the unquoted_as_args
    # migration script. We should update the test
    # as part of this ticket.

    # basic args
    assert split_args(u"a=b c='foo bar'") == [u"a=b", u"c='foo bar'"]
    assert split_args(u"a=b c=\"foo bar\"") == [u"a=b", u"c=\"foo bar\""]
    assert split_args(u"a=b c=foo\\ bar") == [u"a=b", u"c=foo\\ bar"]

    # whitespace separators
    assert split_args(u"a=b\nc='foo bar'") == [u"a=b", u"c='foo bar'"]

# Generated at 2022-06-11 09:02:38.450025
# Unit test for function parse_kv
def test_parse_kv():
    assert( parse_kv('foo=bar x=y') == {u'foo': u'bar', u'x': u'y'})
    assert( parse_kv('foo=bar baz') == {u'_raw_params': u'foo=bar baz'})
    assert( parse_kv('foo=bar baz', check_raw=True) == {u'foo': u'bar', u'_raw_params': u'baz'})

    # ensure we properly handle quoted parameters which may contain escaped quotes
    assert( parse_kv('foo="foo bar" baz') == {u'foo': 'foo bar', u'_raw_params': u'baz'})

# Generated at 2022-06-11 09:02:47.725368
# Unit test for function split_args
def test_split_args():
    arguments = '''{{foo}} bar {{baz}} "{{bat}} {{bat}}" '{{bat}} {{bat}}' asdf=jkl {{foo}}=bar {%flim%} flam=true asdf=jkl flim=flam
asdf=jkl {% flim=flam %} asdf=jkl {{ foo }}={{ bar }} flim={{ flam }}
{{ foo }}={{ bar }}'''

# Generated at 2022-06-11 09:02:58.835865
# Unit test for function split_args
def test_split_args():
    import sys
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import textwrap

    class TestCase(unittest.TestCase):
        def assertSplitEqual(self, string, expected):
            actual = split_args(string)
            msg = textwrap.dedent(
                u"""\
                Expected: %r
                Actual: %r
                """
                ) % (expected, actual)
            self.assertEqual(actual, expected, msg)

        def test_simple(self):
            self.assertSplitEqual(u"foo bar baz", [u"foo", u"bar", u"baz"])


# Generated at 2022-06-11 09:03:07.256663
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=') == {'foo': ''}
    assert parse_kv('foo= bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar creates=yup') == {'foo': 'bar', 'creates': 'yup'}
    assert parse_kv('foo=bar creates=yup removes=bah') == {'foo': 'bar', 'creates': 'yup', 'removes': 'bah'}
    assert parse_kv('foo=bar creates=yup removes=bah') == {'foo': 'bar', 'creates': 'yup', 'removes': 'bah'}

# Generated at 2022-06-11 09:03:28.730782
# Unit test for function split_args
def test_split_args():
    test_cases = dict()
    test_cases.update(split_test_cases)
    test_cases.update(kv_test_cases)
    test_cases.update(quotes_test_cases)
    test_cases.update(jinja_test_cases)
    test_cases.update(other_test_cases)

    for expected_output, input_ in test_cases.items():
        actual_output = split_args(input_)
        assert actual_output == expected_output, "For input: %r, expected: %r, but got: %r" % (input_, expected_output, actual_output)


# Generated at 2022-06-11 09:03:37.286260
# Unit test for function parse_kv
def test_parse_kv():
    kv_dict = parse_kv("key1=val1 key2=val2 key3=val3 key4='val 4' key5=\"val5\" key6=val6", check_raw=True)
    assert kv_dict['key1'] == 'val1'
    assert kv_dict['key2'] == 'val2'
    assert kv_dict['key3'] == 'val3'
    assert kv_dict['key4'] == 'val 4'
    assert kv_dict['key5'] == 'val5'
    assert kv_dict['key6'] == 'val6'
    assert kv_dict['_raw_params'] is None
    kv_dict = parse_kv("creates=/tmp/foobar removes=/tmp/foobar", check_raw=True)
    assert kv_

# Generated at 2022-06-11 09:03:49.195215
# Unit test for function parse_kv
def test_parse_kv():
    """
    Make sure that the k= v= form works
    Make sure quotes work in the parameters
    Make sure that escaped quotes work and are kept as part of the value
    :return:
    """
    assert parse_kv('a=b b="c" d="\\\\\"e"') == {'a': 'b', 'b': 'c', 'd': '\\\"e'}
    assert parse_kv(None) == {}



# Generated at 2022-06-11 09:03:58.008128
# Unit test for function split_args