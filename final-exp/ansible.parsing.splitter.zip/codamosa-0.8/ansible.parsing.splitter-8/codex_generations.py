

# Generated at 2022-06-11 08:54:38.680145
# Unit test for function split_args
def test_split_args():
    import pprint
    args = u"""a=b c="foo bar" d={% if foo %}hello{% endif %} e={# hi #} foo="bar" b={{ bar }}"""
    pprint.pprint(split_args(args))

# Generated at 2022-06-11 08:54:43.694197
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('a="b c" b="c d"') == ['a="b c"', 'b="c d"']
    assert split_args('''a="b c" b="c d"''') == ['a="b c"', 'b="c d"']
    assert split_args('''a="b c"\nb="c d"''') == ['a="b c"', 'b="c d"']
    assert split_args('''a="b\nc"\nb="c d"''') == ['a="b\nc"', 'b="c d"']

# Generated at 2022-06-11 08:54:51.447898
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv')
    tests = [
        ('a=1 b=2', {'a': '1', 'b': '2'}),
        ('a=1 b=2 c=3 d=4', {'a': '1', 'b': '2', 'c': '3', 'd': '4'}),
        ('a=1  b=2', {'a': '1', 'b': '2'}),
        ('foo=bar "bar foo"=baz', {'bar foo': 'baz', 'foo': 'bar'}),
    ]
    for argv, expected in tests:
        result = parse_kv(argv)
        assert result == expected
        assert type(result) == type(expected)

# Generated at 2022-06-11 08:55:04.068779
# Unit test for function split_args

# Generated at 2022-06-11 08:55:13.881743
# Unit test for function parse_kv
def test_parse_kv():
  # string with no key=value
  assert {'_raw_params': 'yolo'} == parse_kv('yolo')
  # string with no key=value
  assert {'_raw_params': 'yolo'} == parse_kv('"yolo"')
  # string with key=value
  assert {'_raw_params': 'yolo', 'key': 'value'} == parse_kv('yolo key=value')
  # string with key=value
  assert {'_raw_params': 'yolo', 'key': 'value'} == parse_kv('yolo "key=value"')
  # string with key=value with space on right side of key and left side of value

# Generated at 2022-06-11 08:55:25.474643
# Unit test for function parse_kv
def test_parse_kv():
    # test with various parameter separators
    # notice we have to use literal strings here to avoid editor autoformatting
    assert parse_kv('key1=value1 key2="value with spaces"') == {
        u'key1': u'value1',
        u'key2': u'value with spaces',
    }
    assert parse_kv("key1=value1 key2='value with spaces'") == {
        u'key1': u'value1',
        u'key2': u'value with spaces',
    }
    assert parse_kv('key1=value1 key2=\'value with spaces\'') == {
        u'key1': u'value1',
        u'key2': u'value with spaces',
    }

    # test without spaces

# Generated at 2022-06-11 08:55:37.686288
# Unit test for function parse_kv
def test_parse_kv():
	assert parse_kv('a=b c="d=e"') == {'a': 'b', 'c': 'd=e'}, 'a=b c="d=e"'
	assert parse_kv('a="b=c" d="e=f" g="h=i"') == {'a': 'b=c', 'd': 'e=f', 'g': 'h=i'}, 'a="b=c" d="e=f" g="h=i"'
	assert parse_kv('a=b c=d e=f g=h i=j') == {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j'}, 'a=b c=d e=f g=h i=j'

# Generated at 2022-06-11 08:55:46.208860
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('"foo=a"') == {'foo': 'a'}
    assert parse_kv('foo=a') == {'foo': 'a'}
    assert parse_kv('foo="a"') == {'foo': 'a'}
    assert parse_kv('foo="a, b"') == {'foo': 'a, b'}
    assert parse_kv('foo="a, b",bar="c, d"') == {'foo': 'a, b', 'bar': 'c, d'}
    assert parse_kv('foo=bar baz') == {'foo': 'bar', '_raw_params': 'baz'}
    assert parse_kv('foo=bar\nbaz') == {'foo': 'bar', '_raw_params': 'baz'}


# Generated at 2022-06-11 08:55:56.840179
# Unit test for function parse_kv

# Generated at 2022-06-11 08:56:07.410652
# Unit test for function split_args
def test_split_args():
    import datetime
    cur_library_location = os.path.dirname(os.path.realpath(__file__))
    cur_tests_location = os.path.dirname(cur_library_location)
    src_dir = os.path.dirname(cur_tests_location)
    testdata_dir = os.path.join(src_dir, 'testdata')
    test_cases = os.path.join(testdata_dir, 'split_args_data.json')
    with open(test_cases, 'r') as split_args_data:
        data_string = " ".join(split_args_data.readlines())
        data = json.loads(data_string)
        for test_case in data["test_cases"]:
            results = split_args(test_case["args"])

# Generated at 2022-06-11 08:56:21.967575
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d") == {'a': 'b', 'c': 'd'}
    assert parse_kv("a=b c=d e") == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv("a=b c=d e= f=g") == {'a': 'b', 'c': 'd', '_raw_params': 'e= f=g'}


# from ansible.utils.args import split_args

# Generated at 2022-06-11 08:56:32.397498
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args
    :return:
    '''

# Generated at 2022-06-11 08:56:37.832187
# Unit test for function split_args
def test_split_args():
    assert split_args('echo "one two three"') == ['echo', '"one two three"']
    assert split_args('echo "one two three') == ['echo', '"one two three']
    assert split_args('echo "one two ${foo}"') == ['echo', '"one two ${foo}"']
    assert split_args('echo "one two ${foo') == ['echo', '"one two ${foo']
    assert split_args('echo "one two $foo"') == ['echo', '"one two $foo"']
    assert split_args('echo "one two $foo') == ['echo', '"one two $foo']
    assert split_args('echo "one two ${foo}') == ['echo', '"one two ${foo}']

# Generated at 2022-06-11 08:56:45.520606
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar\\n\\n"') == ['a=b', 'c="foo bar\\n\\n"']
    assert split_args('a=b c="foo bar\\n\\n" d=3') == ['a=b', 'c="foo bar\\n\\n"', 'd=3']
    assert split_args('a=b c="foo bar\\n\\n" d=3 e="quoted\\n"') == ['a=b', 'c="foo bar\\n\\n"', 'd=3', 'e="quoted\\n"']

# Generated at 2022-06-11 08:56:55.197001
# Unit test for function parse_kv
def test_parse_kv():
    # No exceptions in this test
    
    # Test one
    # Parse dict
    args = "foo=bar baz=bam"
    parsed = parse_kv(args)
    print(parsed)
    print({"foo": "bar", "baz": "bam"})
    assert parsed == {"foo": "bar", "baz": "bam"}

    # Test two
    # Parse list
    args = 'foo="bar baz" baz=\'bam\''
    parsed = parse_kv(args)
    print(parsed)
    print({"foo": "bar baz", "baz": "bam"})
    assert parsed == {"foo": "bar baz", "baz": "bam"}
    # There should be some additional tests here



# Generated at 2022-06-11 08:57:02.931698
# Unit test for function split_args
def test_split_args():
    # Basic tests
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b \\n c=d") == ['a=b', 'c=d']
    assert split_args("a=b\\nc=d") == ['a=b\nc=d']
    assert split_args("a=b\\nc=d").count("\n") == 1
    assert split_args("a=b\\\\nc=d") == ['a=b\\nc=d']
    assert split_args("a=b\\\\nc=d").count("\\") == 2

    # Custom tests for the way we use split_args
    assert split_args("a=b c=d") == ['a=b', 'c=d']

# Generated at 2022-06-11 08:57:12.820543
# Unit test for function split_args

# Generated at 2022-06-11 08:57:22.313694
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {"foo": "bar"}
    assert parse_kv("foo='bar baz'") == {"foo": "bar baz"}
    assert parse_kv("foo=\"bar' baz\"") == {"foo": "bar' baz"}
    assert parse_kv("one two") == {"_raw_params": "one two"}
    assert parse_kv("one two='three four'") == {"two": "three four", "_raw_params": "one"}
    assert parse_kv("one=\"two' three four\"") == {"one": "two' three four"}
    assert parse_kv("one='two\\' three\\' four'") == {"one": "two' three' four"}

# Generated at 2022-06-11 08:57:31.271996
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.ansible_release import __version__
    from ansible.plugins.connection.local import Connection
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible import context
    import os
    import sys
    import json

    # Ignore deprecation warning
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    # Assume that ansible is installed in ../.. relative to this file
    ansible_basedir = os.path.absp

# Generated at 2022-06-11 08:57:39.735246
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv("a=1 b=2 c=3") == {
        'a' : '1',
        'b' : '2',
        'c' : '3',
    }
    assert parse_kv("a=1 b=\" c d \" e=3") == {
        'a' : '1',
        'b' : ' c d ',
        'e' : '3',
    }
    assert parse_kv("a=1 b=\" c d e=f g=h \" i=3") == {
        'a' : '1',
        'b' : ' c d e=f g=h ',
        'i' : '3',
    }

# Generated at 2022-06-11 08:57:55.882875
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('one=1 two=2 three="hello world"') == {'one': '1', 'two': '2', 'three': 'hello world'})
    assert(parse_kv('one=1 two=2 three="hello world"', check_raw=True) == {'one': '1', 'two': '2', 'three': 'hello world'})
    assert(parse_kv('one=1 two=2 three=hello\\ world', check_raw=True) == {'one': '1', 'two': '2', 'three': 'hello world'})
    assert(parse_kv('one=1 two=2 three="hello world" four', check_raw=True)[u'_raw_params'].strip() == 'four')

# Generated at 2022-06-11 08:58:05.228695
# Unit test for function split_args

# Generated at 2022-06-11 08:58:15.066991
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping, Collection

    # Test that all types of strings were passed in
    assert isinstance(parse_kv(b'key=val'), MutableMapping)
    assert isinstance(parse_kv(u'key=val'), MutableMapping)
    if PY3:
        assert isinstance(parse_kv('key=val'), MutableMapping)

    # Test that the string was parsed correctly
    assert parse_kv(u'key=val') == {u'key': u'val'}
    assert parse_kv(b'key=val') == {b'key': b'val'}

# Generated at 2022-06-11 08:58:23.988766
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:29.058152
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz="qux"') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv('foo=bar baz="qux"', check_raw=True) == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'foo=bar baz="qux"'}



# Generated at 2022-06-11 08:58:32.823335
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('first=apple') == {'first': 'apple'}
    assert parse_kv('first=apple second=banana') == {'first': 'apple', 'second': 'banana'}
    assert parse_kv('first=apple second=banana third=cherry') == {'first': 'apple', 'second': 'banana', 'third': 'cherry'}



# Generated at 2022-06-11 08:58:43.674457
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('a=b c="d e" f=5') == {"a": "b", "c": "d e", "f": "5"}
    assert parse_kv(' "a = b" ') == {"a = b": None}
    assert parse_kv('a=b c= d= e') == {"a": "b", "c": "", "d": "", "e": None}
    assert parse_kv('a=b c= d= e', check_raw=True) == {"a": "b", "c": "", "d": "", "e": "", "_raw_params": 'a=b c= d= e'}

# Generated at 2022-06-11 08:58:53.991362
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('foo=bar', check_raw=False) == dict(foo='bar'))
    assert(parse_kv('foo=bar baz=qux', check_raw=False) == dict(foo='bar', baz='qux'))

    # Test unicode decoding when check_raw is False
    assert(parse_kv(u'foo=bar\N{SNOWMAN}', check_raw=False) == dict(foo='bar\N{SNOWMAN}'))
    assert(parse_kv(u'foo="bar\N{SNOWMAN}"', check_raw=False) == dict(foo='bar\N{SNOWMAN}'))

# Generated at 2022-06-11 08:59:00.011850
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv(args=u'creates=/tmp/foo executable=/bin/bash removes=/tmp/bar chdir=/tmp/baz stdin_add_newline=True warn=yes')
    # TODO: Fix assertion, see #13737
    # assert options == {'creates': '/tmp/foo', 'executable': '/bin/bash', 'removes': '/tmp/bar', 'chdir': '/tmp/baz', 'stdin_add_newline': 'True', 'warn': 'yes'}
    assert options != {'creates': '/tmp/foo', 'executable': '/bin/bash', 'removes': '/tmp/bar', 'chdir': '/tmp/baz', 'stdin_add_newline': 'True', 'warn': 'yes'}


# Generated at 2022-06-11 08:59:11.981239
# Unit test for function parse_kv
def test_parse_kv():
    args = 'creates=/tmp/foo executable=/bin/bash removes=/tmp/bar'
    p = parse_kv(args)
    assert p['creates'] == '/tmp/foo'
    assert p['executable'] == '/bin/bash'
    assert p['removes'] == '/tmp/bar'

    args = 'creates=/tmp/foo executable=/bin/bash  foo=bar  "blah=blah blah"'
    p = parse_kv(args)
    assert p['creates'] == '/tmp/foo'
    assert p['executable'] == '/bin/bash'
    assert p['foo'] == 'bar'
    assert p['_raw_params'] == '"blah=blah blah"'


# Generated at 2022-06-11 08:59:30.697546
# Unit test for function split_args
def test_split_args():
    assert split_args("a b") == ["a", "b"]
    assert split_args("a b\nc") == ["a", "b\n", "c"]
    assert split_args("a \"test") == ["a", "\"test"]
    assert split_args("a 'test") == ["a", "'test"]
    assert split_args("a 'test\\'test'") == ["a", "'test\\'test'"]
    assert split_args("a \"test\\\"test\"") == ["a", "\"test\\\"test\""]
    assert split_args("a \"test \\\" test\"") == ["a", "\"test \\\" test\""]
    assert split_args("a 'test \\' test'") == ["a", "'test \\' test'"]

# Generated at 2022-06-11 08:59:42.109624
# Unit test for function split_args
def test_split_args():
    import pytest
    from ansible.parsing.splitter import split_args

    def assert_split(input_string, expected_output):
        # 1. We split input_string with split_args and store the result
        # in actual_output.
        actual_output = split_args(input_string)

        # 2. We compare actual_output with expected_output.
        assert actual_output == expected_output, "expected input: %s, got %s" % (expected_output, actual_output)

    assert_split("simple", ["simple"])
    assert_split("simple with space", ["simple", "with", "space"])
    assert_split("with multiple spaces", ["with", "multiple", "spaces"])

# Generated at 2022-06-11 08:59:48.413784
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('   ') == {}
    assert parse_kv('a=b') == dict(a='b')
    assert parse_kv('a=b c=d') == dict(a='b', c='d')
    assert parse_kv('a=b c="d e"') == dict(a='b', c='d e')
    assert parse_kv('a=b c="d=e"') == dict(a='b', c='d=e')
    assert parse_kv('a="\\"b"') == dict(a='"b')

# Generated at 2022-06-11 08:59:57.888306
# Unit test for function parse_kv
def test_parse_kv():
    import yaml

    def _test(input_string, expected_output_string):
        input_dict = parse_kv(input_string)
        expected_output_dict = yaml.load(expected_output_string)
        assert input_dict == expected_output_dict, 'Input string: %s Expected: %s Got: %s' % (input_string, expected_output_string, input_dict)

    # Non-raw parameters
    _test('a=b c=d', 'a: b\nc: d')
    _test('a=b c=d ', 'a: b\nc: d')
    _test(' a=b c=d', 'a: b\nc: d')
    _test(' a=b c=d ', 'a: b\nc: d')

    # Raw parameters
    _test

# Generated at 2022-06-11 09:00:08.306490
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"') == {'foo': 'bar baz'}
    assert parse_kv('foo="bar \'baz\'"') == {'foo': "bar 'baz'"}
    assert parse_kv('foo=bar baz') == {'_raw_params': 'foo=bar baz'}
    assert parse_kv('foo="bar baz') == {'_raw_params': 'foo="bar baz'}
    assert parse_kv('foo=bar baz', True) == {'_raw_params': 'foo=bar baz'}
    assert parse_kv('') == {}
    assert parse_kv(None) == {}

# Generated at 2022-06-11 09:00:16.490057
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=wibble1 wibble2=wibble3 wibble4=') == {u'baz': 'wibble1', u'wibble4': '', u'wibble2': 'wibble3', u'foo': 'bar'}
    assert parse_kv(u'') == {}
    assert parse_kv('') == {}
    assert parse_kv(u'foo=bar baz bah=woot') == {u'bah': 'woot', u'foo': 'bar'}
    assert parse_kv(u'cmd /opt="foo bar"') == {u'cmd': '/opt="foo bar"'}

# Generated at 2022-06-11 09:00:25.798053
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv("", check_raw=False) == {}
    assert parse_kv(None, check_raw=False) == {}
    assert parse_kv("var=hello", check_raw=False) == {'var': 'hello'}
    assert parse_kv("var=hello foo=bar", check_raw=False) == {'var': 'hello', 'foo': 'bar'}
    assert parse_kv("var='hello world'", check_raw=False) == {'var': 'hello world'}
    assert parse_kv("var=\"hello world\"", check_raw=False) == {'var': 'hello world'}
    assert parse_kv("var=hello\ world", check_raw=False) == {'var': 'hello world'}

# Generated at 2022-06-11 09:00:35.541973
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    assert parse_kv('a=b c="d d"') == {u'a': u'b', u'c': u'd d'}
    assert parse_kv('a=b c="d=d"') == {u'a': u'b', u'c': u'd=d'}
    assert parse_kv('a=b c="d\=d"') == {u'a': u'b', u'c': u'd=d'}
    assert parse_kv('a=b c="d\\"d"') == {u'a': u'b', u'c': u'd"d'}

# Generated at 2022-06-11 09:00:46.236302
# Unit test for function parse_kv
def test_parse_kv():
    # Test parsing of escaped spaces and quotes
    value = '{\\"a\\" :\\"1\\", \\"b\\": \\"2\\"}'
    assert parse_kv(value)['b'] == '2', "Failed to parse a string with escaped quotes and spaces"
    # Test parsing of escaped equal sign
    value = 'foo\\=bar=baz'
    assert parse_kv(value)['foo=bar'] == 'baz', "Failed to parse a string with escaped equal sign"
    # Test parsing of a string with extra spaces around the equal sign
    value = 'foo = bar'
    assert parse_kv(value)['foo'] == 'bar', "Failed to parse a string with extra spaces around the equal sign"
    # Test parsing of a string with extra spaces around the equal sign and with one key value pair


# Generated at 2022-06-11 09:00:53.427666
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar baz=blam") == {'foo': 'bar', 'baz': 'blam'}
    assert parse_kv("foo=bar baz bar=bam") == {'foo': 'bar', 'baz': "bar=bam"}
    assert parse_kv("foo='bar baz' bar=bam") == {'foo': 'bar baz', 'bar': 'bam'}



# Generated at 2022-06-11 09:01:09.460454
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo bar "hello world"') == ['foo', 'bar', '"hello world"']
    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\') == ['a=b', 'c="foo bar']
    assert split_args('a=b c="foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar\\""') == ['a=b', 'c="foo bar""']

# Generated at 2022-06-11 09:01:20.742763
# Unit test for function split_args
def test_split_args():
    '''
    Tests for function split_args()
    '''

# Generated at 2022-06-11 09:01:25.063602
# Unit test for function split_args
def test_split_args():
    '''
    Attempt to test the split_args() function by running some input
    through it and then checking the result to see if we get the
    correct output.
    '''

    # test data list

# Generated at 2022-06-11 09:01:33.905195
# Unit test for function split_args
def test_split_args():
    print('*' * 30)
    print('test_split_args...')
    for s in [
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
        'a=b c="foo bar"',
    ]:
        print('-' * 30)
        print(split_args(s))

# Generated at 2022-06-11 09:01:38.033542
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d e" f=\'g h\'') == {'a': 'b', 'c': 'd e', 'f': 'g h'}


# FIXME: could be deprecated?  We have shlex.split now

# Generated at 2022-06-11 09:01:47.211184
# Unit test for function parse_kv

# Generated at 2022-06-11 09:01:55.022304
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv('')
    assert {u'one': u'two'} == parse_kv(u'one=two')
    assert {u'one': u'two'} == parse_kv(u'one=two')
    assert {u'one': u'two', u'three': u'four'} == parse_kv(u'one=two three=four')
    assert {u'one': u'two', u'three': u'four'} == parse_kv(u'one=two\ three=four')
    assert {u'one': u'two', u'three': u'four'} == parse_kv(u'one=two\\ three=four')

# Generated at 2022-06-11 09:02:04.075838
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"""a=b c="d e" f="g\"h" i=\\"j k='' "l=m n=o" p=\\ 'q=r'""", check_raw=True) == {u'a': u'b', u'c': u'd e', u'f': u'g"h',
                                                                                                 u'i': u'"j', u'k': u"''", u'l=m': u'o',
                                                                                                 u'p': u"\\", u'_raw_params': u"'q=r'",
                                                                                                 u'stdin_add_newline': False,
                                                                                                 u'strip_empty_ends': True}

# Generated at 2022-06-11 09:02:15.279914
# Unit test for function parse_kv
def test_parse_kv():
    s = "creates=foo executable=bar removes=baz"

    assert parse_kv(s) == {u'creates': u'foo', u'executable': u'bar', u'removes': u'baz'}

    s = "creates=false executable=false removes=false"

    assert parse_kv(s) == {u'creates': u'false', u'executable': u'false', u'removes': u'false'}

    # the following three are only safe because the shell module is
    # the only module so far which makes use of the _raw_params functionality
    s = "foo \"bar baz\""
    assert parse_kv(s) == {u'_raw_params': u'foo "bar baz"'}

    s = "foo 'bar baz'"

# Generated at 2022-06-11 09:02:24.630630
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar bar=baz') == {'foo': 'bar', 'bar': 'baz'}
    assert parse_kv('foo="bar bar"') == {'foo': 'bar bar'}
    assert parse_kv('foo="bar \\"bar baz\\""') == {'foo': 'bar "bar baz"'}
    assert parse_kv('foo="bar \\nbar"') == {'foo': 'bar \nbar'}
    assert parse_kv('foo=bar bar=baz bar baz') == {'foo': 'bar', 'bar': 'baz', '_raw_params': 'bar baz'}
    assert parse_kv('foo="bar bar" bar baz')

# Generated at 2022-06-11 09:02:37.150886
# Unit test for function parse_kv
def test_parse_kv():

    from ansible.module_utils.six.moves import shlex_quote

    s = "a=b b=c c=\"d\" d='e' e=f f=1 2=3 4=5"
    e = {u'a': u'b', u'b': u'c', u'c': u'd', u'd': u'e', u'e': u'f', u'f': u'1', u'_raw_params': u'2=3 4=5'}
    assert parse_kv(s, True) == e

    s = "a=b b=c c=\"d\" d='e' e=f f=1 2=3 4=5"

# Generated at 2022-06-11 09:02:45.575674
# Unit test for function split_args

# Generated at 2022-06-11 09:02:56.124492
# Unit test for function parse_kv
def test_parse_kv():
    # Test empty
    assert parse_kv("") == {}

    # Test single explicit key=value
    assert parse_kv("key=value") == {"key": "value"}

    # Test multiple explicit key=value
    assert parse_kv("key1=value1 key2=value2") == {"key1": "value1", "key2": "value2"}

    # Test single implicit key
    assert parse_kv("key") == {"key": None}

    # Test multiple implicit key
    assert parse_kv("key1 key2") == {"key1": None, "key2": None}

    # Test multiple implicit and explicit key
    assert parse_kv("key1 key2 key3=value3") == {"key1": None, "key2": None, "key3": "value3"}

    # Test quoutes

# Generated at 2022-06-11 09:03:06.323120
# Unit test for function parse_kv
def test_parse_kv():
    for argstring,expected in string_test_cases:
        assert parse_kv(argstring)==expected
###########
# Unit tests for parse_kv
# Directly from the examples in the doc string
###########

# Generated at 2022-06-11 09:03:16.421898
# Unit test for function split_args
def test_split_args():
    ''' test for function split_args '''
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})

    # test various unbalanced cases
    for args in [
        u'{{',
        u'{{{',
        u'{{{ {',
        u'"foo',
        u'"foo\''
    ]:
        try:
            split_args(args)
        except AnsibleParserError as e:
            module.fail_json(msg="failed to split args in case '{0}', as expected: {1}".format(args, to_text(e)))
        else:
            module.fail_json(msg="expected to fail splitting args in case '{0}'".format(args))

    # test a balanced set of examples

# Generated at 2022-06-11 09:03:28.002661
# Unit test for function split_args
def test_split_args():
    #Test for simple quotation
    result = split_args("a=b c='d e' f='g h i'")
    assert result == ['a=b', "c='d e'", "f='g h i'"]

    #Test for simple double quotation
    result = split_args("a=b c=\"d e\" f=\"g h i\"")
    assert result == ['a=b', "c=\"d e\"", "f=\"g h i\""]

    #Test for single quotes
    result = split_args("a=b c='d e' f=\"g h i\"")
    assert result == ['a=b', "c='d e'", "f=\"g h i\""]

    #Test for double quotes
    result = split_args("a=b c=\"d e\" f='g h i'")
    assert result

# Generated at 2022-06-11 09:03:36.707243
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == { 'foo': 'bar' }
    assert parse_kv('foo="bar baz"') == { 'foo': 'bar baz' }
    assert parse_kv('foo="bar baz" x=y') == { 'foo': 'bar baz', 'x': 'y' }
    assert parse_kv('foo="bar baz" x=y spam=eggs') == { 'foo': 'bar baz', 'x': 'y', 'spam': 'eggs' }
    assert parse_kv('foo="bar baz" x=y spam=eggs ham') == { 'foo': 'bar baz', 'x': 'y', 'spam': 'eggs', '_raw_params': 'ham' }
   

# Generated at 2022-06-11 09:03:47.458758
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv("a = 1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv("a=1 b =2") == {"a": "1", "b": "2"}
    assert parse_kv("a=1 b= 2") == {"a": "1", "b": "2"}
    assert parse_kv("a=1 b=2 ") == {"a": "1", "b": "2"}
    assert parse_kv("a=1 b = 2 ") == {"a": "1", "b": "2"}
    assert parse_kv("a=1 b = 2") == {"a": "1", "b": "2"}
   

# Generated at 2022-06-11 09:03:57.646418
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == {'foo': 'bar', 'baz': 'qux'}
    assert parse_kv('foo="bar baz" qux=quux') == {'foo': 'bar baz', 'qux': 'quux'}
    assert parse_kv('foo="bar qux=quux" baz=qux') == {'foo': 'bar qux=quux', 'baz': 'qux'}
    assert parse_kv('foo=bar baz=qux quux') == {'foo': 'bar', 'baz': 'qux', '_raw_params': 'quux'}

# Generated at 2022-06-11 09:04:05.244200
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for function parse_kv
    '''

    # Relative to root of repo
    from ansible.module_utils import basic
    this_module = basic.AnsibleModule(
        argument_spec=dict(),
    )
