

# Generated at 2022-06-11 08:55:14.251008
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:25.868698
# Unit test for function split_args
def test_split_args():
    # Test 1 without nested quotes
    res = split_args('/usr/bin/foo "bar baz"')
    assert ' '.join(res) == '/usr/bin/foo "bar baz"'

    # Test 2 with nested quotes
    res = split_args('/usr/bin/foo "bar baz" this "was ""quoted"" in the middle"')
    assert ' '.join(res) == '/usr/bin/foo "bar baz" this "was ""quoted"" in the middle"'

    # Test 3 with nested jinja2 blocks
    res = split_args("/usr/bin/foo {{ 'bar baz' }} this {{ 'was ""quoted"" in the middle' }}")

# Generated at 2022-06-11 08:55:38.081520
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.vars import combine_vars
    vars = combine_vars(dict(), dict(user='tom'))
    assert parse_kv("", check_raw=False) == {}
    assert parse_kv("a=b", check_raw=False) == {u'a': u'b'}
    assert parse_kv("x={{ user }}", check_raw=False, vars=vars) == {u'x': u'tom'}
    assert parse_kv("a=b c=d", check_raw=False) == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=\"b b\" c=d", check_raw=False) == {u'a': u'b b', u'c': u'd'}
   

# Generated at 2022-06-11 08:55:47.009810
# Unit test for function split_args
def test_split_args():
    __tracebackhide__ = True
    if platform.system() != 'Windows':
        actual = ['a=b', 'c="foo bar"']
        assert split_args("a=b c=\"foo bar\"") == actual, "split_args() failed to process a=b c=\"foo bar\""
    else:
        actual = ['a=b', 'c=^"foo bar^"']
        assert split_args("a=b c=^\"foo bar^\"") == actual, "split_args() failed to process a=b c=^\"foo bar^\""

    actual = ['a=b', 'c="foo', 'bar"']
    assert split_args("a=b c=\"foo\nbar\"") == actual, "split_args() failed to process a=b c=\"foo\nbar\""


# Generated at 2022-06-11 08:55:57.596516
# Unit test for function split_args
def test_split_args():
    def check_split_args(msg, original, final):
        split = split_args(original)
        assert split == final, "%s: split_args returned unexpected result for %s: %s" % (msg, original, split)

    # check basic split
    check_split_args("Basic split", "a=b c=d e=f", ["a=b", "c=d", "e=f"])
    # check split of argument with embedded newlines
    check_split_args("Split with newline", "a=b\nc=d\ne=f", ["a=b", "c=d", "e=f"])
    # check split of argument with embedded spaces

# Generated at 2022-06-11 08:56:08.049563
# Unit test for function split_args

# Generated at 2022-06-11 08:56:15.671992
# Unit test for function parse_kv
def test_parse_kv():
    print("test_parse_kv")
    kw = " a=b c=d e='f g' h='i j' klm=nop 'qr st=uv' wx='yz ab' cd='e f'"
    res = parse_kv(kw)
    expected = {'a': 'b', 'c': 'd', 'e': 'f g', 'h': 'i j', 'klm': 'nop', 'qr st': 'uv', 'wx': 'yz ab', 'cd': 'e f'}
    assert res == expected, "test_parse_kv failed"

test_parse_kv()


# Generated at 2022-06-11 08:56:26.965385
# Unit test for function parse_kv
def test_parse_kv():
    # simple key value pairs
    assert parse_kv('key=val') == dict(key=u'val')
    assert parse_kv('key1=val1 key2=val2 key3=val3') == dict(key1=u'val1', key2=u'val2', key3=u'val3')
    assert parse_kv('key1=val1 key2=val2 key3=val3 key4=' + u'\u0fff') == dict(key1=u'val1', key2=u'val2', key3=u'val3', key4=u'\u0fff')

    # quoted values
    assert parse_kv('key="a=b c=d"') == dict(key=u'a=b c=d')

# Generated at 2022-06-11 08:56:35.186041
# Unit test for function parse_kv
def test_parse_kv():
    import re

# Generated at 2022-06-11 08:56:44.554180
# Unit test for function parse_kv
def test_parse_kv():
    # For simple dictionary, should return the dictionary
    assert parse_kv("a=b c=d") == {u'c': u'd', u'a': u'b'}
    # For quoted values, should strip quotes
    assert parse_kv("a='b c' d='e f'") == {u'd': u'e f', u'a': u'b c'}
    # For escaped quotes, should strip quotes
    assert parse_kv("a=\"b c\" d=\"e f\"") == {u'd': u'e f', u'a': u'b c'}
    # For escaped values, should strip escape
    assert parse_kv("a='b\\ c' d='e\\ f'") == {u'd': u'e c', u'a': u'b c'}
    # For simple list,

# Generated at 2022-06-11 08:57:00.466794
# Unit test for function split_args
def test_split_args():
    def run(expected, args):
        print("\n{}".format(args))
        actual = split_args(args)
        print(actual)
        print(expected)
        assert expected == actual

    run(['"a b"', 'c'], '"a b" c')
    run(['a', '"b c"'], 'a "b c"')
    run(['a', 'b', 'c'], 'a b c')
    run(['a', 'b', 'c'], 'a\nb\nc')
    run(['a', 'b', 'c'], 'a\\\nb c')
    run(['a', 'b', 'c'], 'a\\ b c')
    run(['a', 'b', 'c'], 'a b\\ c')

# Generated at 2022-06-11 08:57:10.250619
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.basic import jsonify
    from ansible.compat.tests import unittest
    from ansible.module_utils import basic

    class TestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestCase, self).__init__(*args, **kwargs)
            self.assertFalse(hasattr(self, 'assert_equal'))

    # we need ansible to be importable so we can use the common error class
    module_loader, pathfinder = basic._setup_loader(None)


# Generated at 2022-06-11 08:57:20.165393
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args(' foo ') == ['foo']
    assert split_args('foo\nbar') == ['foo\nbar']
    assert split_args(' foo\nbar ') == ['foo\nbar']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args(' foo bar ') == ['foo', 'bar']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args(' foo bar baz ') == ['foo', 'bar', 'baz']
    assert split_args('foo\nbar\nbaz') == ['foo\nbar\nbaz']
    assert split_args(' foo\nbar\nbaz ') == ['foo\nbar\nbaz']


# Generated at 2022-06-11 08:57:28.941560
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=5 b=3 c=2') == { 'a' : '5', 'b' : '3', 'c' : '2' }
    assert parse_kv("a=b 'c d'=e") == { 'a' : 'b', 'c d' : 'e' }
    assert parse_kv("a=b 'c d'=e f=g") == { 'a' : 'b', 'c d' : 'e', 'f' : 'g' }
    assert parse_kv("a=b 'c d'=e f=g h='i j'") == { 'a' : 'b', 'c d' : 'e', 'f' : 'g', 'h' : 'i j' }

# Generated at 2022-06-11 08:57:33.927966
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('a=b c=d') == dict(a='b', c='d'))
    assert(parse_kv('a=b c=d', check_raw=True) == dict(a='b', c='d'))
    assert(parse_kv(u'username:password=my:pass', check_raw=True) == dict(username='password', _raw_params=u'my:pass'))



# Generated at 2022-06-11 08:57:42.820860
# Unit test for function split_args

# Generated at 2022-06-11 08:57:51.504705
# Unit test for function split_args

# Generated at 2022-06-11 08:58:01.050374
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:12.340407
# Unit test for function parse_kv
def test_parse_kv():
    res = parse_kv('key=value arg=1 arg=2 arg="quoted arg" arg=\'quoted arg\'')
    assert res['key'] == 'value'
    assert res['arg'] == '2'
    assert res.get('_raw_params') == 'arg=1 arg="quoted arg" arg=\'quoted arg\''

    res = parse_kv('arg=1 arg=2 arg="quoted arg" arg=\'quoted arg\' key=value')
    assert res['key'] == 'value'
    assert res['arg'] == '2'
    assert res.get('_raw_params') == 'arg=1 arg="quoted arg" arg=\'quoted arg\''


# Generated at 2022-06-11 08:58:22.234039
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:52.847107
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic single key/value
    assert parse_kv('foo=bar') == {'foo': 'bar'}

    # Test key/value with unicode characters
    assert parse_kv('ужин=компот') == {'ужин': 'компот'}

    # Test multiple key/values
    assert parse_kv('foo=bar baz=foobar') == {'foo': 'bar', 'baz': 'foobar'}

    # Test multiple key/values with unicode characters
    assert parse_kv('ужин=компот обед=мясо') == {'ужин': 'компот', 'обед': 'мясо'}

# Generated at 2022-06-11 08:59:00.640067
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("creates=/tmp/foo removes=/tmp/bar chdir=/tmp executable=/bin/bash stdin=123")
    assert result == {u'chdir': u'/tmp', u'creates': u'/tmp/foo', u'removes': u'/tmp/bar', u'executable': u'/bin/bash', u'stdin': u'123'}

    result = parse_kv('a=complex\\=value,with,commas and other characters', True)
    assert result == {u'a': u'complex=value,with,commas and other characters', u'_raw_params': u'a=complex\\=value,with,commas and other characters'}

    result = parse_kv(u'a=b\\u2014and\\U0001d122c', True)

# Generated at 2022-06-11 08:59:12.769609
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'name=value') == {u'name': u'value'}
    assert parse_kv(u"name='value'", check_raw=True) == {u'name': u'value'}
    assert parse_kv(u"name='val\\'ue'", check_raw=True) == {u'name': u"val'ue"}
    assert parse_kv(u"name='val\\ue'", check_raw=True) == {u'name': u'value'}
    assert parse_kv(u'name=val\\ ue', check_raw=True) == {u'name': u'value'}

# Generated at 2022-06-11 08:59:22.485909
# Unit test for function split_args
def test_split_args():

    def assert_split(myargs, result):
        myresult = split_args(myargs)
        assert myresult == result, "split_args(%r) should be %r but was actually %r" % (myargs, result, myresult)

    assert_split('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    assert_split('a=b c="foo\nbar"', ['a=b', 'c="foo\nbar"'])
    assert_split('a=b c="foo\\nbar"', ['a=b', 'c="foo\\nbar"'])
    assert_split('a="b c"', ['a="b c"'])
    assert_split('a=b c="foo\\"bar"', ['a=b', 'c="foo\\"bar"'])


# Generated at 2022-06-11 08:59:34.885672
# Unit test for function parse_kv
def test_parse_kv():
    # Test no args
    assert parse_kv(None) == {}

    # Test args with multi-line vars
    assert parse_kv("a=1\nb=2\nc=3") == {}

    # Test args with quotes in var names
    assert parse_kv("'a'=1\n'b'=2\n'c'=3") == {}

    # Test args with spaces in var names
    assert parse_kv("a b=1\n'b'_c=2\nd 'e'=3") == {}

    # Test args with escaped spaces in var names
    assert parse_kv("a\\ b=1\n'b'_c=2\nd\\ 'e'=3") == {}

    # Test args with quoted strings

# Generated at 2022-06-11 08:59:44.937014
# Unit test for function parse_kv
def test_parse_kv():
        from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean

        def assert_equiv(src, dest):
            assert parse_kv(src) == dest

        assert_equiv('"a=1 b=2"', {u'a': u'1', u'b': u'2'})
        assert_equiv('"a=1 b=2 c=3"', {u'a': u'1', u'b': u'2', u'c': u'3'})
        assert_equiv('"a=1 b=2 c=3 x=y"', {u'a': u'1', u'b': u'2', u'c': u'3', u'x': u'y'})

# Generated at 2022-06-11 08:59:54.180639
# Unit test for function split_args
def test_split_args():
    assert(join_args(split_args('foo bar "baz faz"')) == 'foo bar "baz faz"')
    assert(join_args(split_args('foo "baz faz"')) == 'foo "baz faz"')
    assert(join_args(split_args('foo bar "baz faz')) == 'foo bar "baz faz')
    assert(join_args(split_args('foo bar "baz faz\\""')) == 'foo bar "baz faz\\""')
    assert(join_args(split_args('foo bar "baz faz\\"" bof')) == 'foo bar "baz faz\\"" bof')
    assert(join_args(split_args('{{ ansible_managed }}')) == '{{ ansible_managed }}')

# Generated at 2022-06-11 09:00:03.230484
# Unit test for function split_args
def test_split_args():
    assert split_args("foo bar") == ['foo', 'bar']
    assert split_args("foo bar baz") == ['foo', 'bar', 'baz']
    assert split_args("foo 'bar baz'") == ['foo', "'bar baz'"]
    assert split_args("foo \"bar baz\"") == ['foo', '"bar baz"']
    assert split_args("foo 'bar baz' qux") == ['foo', "'bar baz'", 'qux']
    assert split_args("foo 'bar\\\\ baz' qux") == ['foo', "'bar\\\\", 'baz' 'qux']
    assert split_args("foo 'bar\\' baz' qux") == ['foo', "'bar\\'", 'baz' 'qux']

# Generated at 2022-06-11 09:00:12.260212
# Unit test for function split_args
def test_split_args():
    result = split_args(u"foo=bar baz='this is unbalanced'")
    assert result == [u'foo=bar', u"baz='this is unbalanced'"]

    result = split_args(u"foo=bar baz='this is unbalanced")
    assert result == [u'foo=bar', u"baz='this is unbalanced"]

    result = split_args(u"foo='bar baz" )
    assert result == [u'foo=\'bar baz']

    result = split_args(u"foo='bar baz'")
    assert result == [u'foo=\'bar baz\'']

    result = split_args(u"foo=\"bar baz" )
    assert result == [u'foo="bar baz']

# Generated at 2022-06-11 09:00:20.848690
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:40.164082
# Unit test for function split_args
def test_split_args():
    import sys
    import inspect
    import os
    import unittest
    from argparse import ArgumentParser

    # Hack the path so that the testsuite can find the ansible include given that
    # we are not running it with ansible-playbook
    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, 'lib'))

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.module_utils.common.text.converters import (
        to_bytes,
    )

    from ansible.module_utils.common.text.formatters import (
        to_text,
    )

    from ansible.module_utils.common.text.dict2txt import (
        dict2txt,
    )


# Generated at 2022-06-11 09:00:52.768627
# Unit test for function split_args
def test_split_args():
    if not split_args('a b \"c d\"') == ['a', 'b', 'c d']:
        raise AssertionError()
    if not split_args('a b \"c d') == ['a', 'b', '\"c', 'd']:
        raise AssertionError()
    if not split_args('a b \'c d\'') == ['a', 'b', 'c d']:
        raise AssertionError()
    if not split_args('a b \'c d') == ['a', 'b', '\'c', 'd']:
        raise AssertionError()
    if not split_args('a b "c d') == ['a', 'b', '"c', 'd']:
        raise AssertionError()

# Generated at 2022-06-11 09:00:59.671078
# Unit test for function parse_kv
def test_parse_kv():
    args = u"foo=123 bar=Hello\\ World baz=\\'Hello World\\'"
    assert parse_kv(args) == { u'foo': u'123', u'bar': u'Hello World', u'baz': u'\'Hello World\'' }

    # Make sure unquote() is called
    args = u"foo=123 bar=\'Hello World\' baz=\\'Hello World\\'"
    assert parse_kv(args) == { u'foo': u'123', u'bar': u'Hello World', u'baz': u'\'Hello World\'' }

    # Make sure a second equal sign is not treated as a separator
    args = u"foo=123 bar=Hello=World baz=Hello=World"

# Generated at 2022-06-11 09:01:11.193786
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('creates=/tmp/a_file') == {u'creates': u'/tmp/a_file'}
    assert parse_kv('creates=/tmp/a_file,remove=s/a/b/') == {u'creates': u'/tmp/a_file', u'remove': u's/a/b/'}
    assert parse_kv('foo=bar baz') == {u'foo': u'bar', u'_raw_params': u'baz'}
    assert parse_kv('foo=bar baz=quux') == {u'foo': u'bar', u'baz': u'quux'}

# Generated at 2022-06-11 09:01:21.633836
# Unit test for function split_args

# Generated at 2022-06-11 09:01:33.440639
# Unit test for function split_args

# Generated at 2022-06-11 09:01:43.765938
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic functionality
    assert parse_kv(u"foo=bar") == {"foo": "bar"}
    assert parse_kv(u"foo='bar'") == {"foo": "bar"}
    assert parse_kv(u"foo=\"bar\"") == {"foo": "bar"}

    # Test corner cases
    assert parse_kv(u"foo=bar foo bar") == {"foo": "bar"}
    assert parse_kv(u"foo=bar foo = bar") == {"foo": "bar"}
    assert parse_kv(u"foo=bar foo = bar baz=qux") == {"foo": "bar", "baz": "qux"}

    # Test multiple values

# Generated at 2022-06-11 09:01:51.154745
# Unit test for function parse_kv
def test_parse_kv():
    # Simple test
    assert parse_kv("a=2 b=3") == {u'a': u'2', u'b': u'3'}

    # Test with spaces
    assert parse_kv("a=2 b=3  c=4") == {u'a': u'2', u'b': u'3', u'c': u'4'}

    # Test with more spaces
    assert parse_kv(" a =2   b= 3   c = 4 ") == {u'a': u'2', u'b': u'3', u'c': u'4'}

    # Test with quotes
    assert parse_kv('a="2" b="3"') == {u'a': u'2', u'b': u'3'}

    # Test with escaped quotes
    assert parse_

# Generated at 2022-06-11 09:02:00.053489
# Unit test for function split_args
def test_split_args():
    assert split_args(u'') == [u'']
    assert split_args(u'a') == [u'a']
    assert split_args(u'something') == [u'something']

    assert split_args(u'a=b') == [u'a=b']
    assert split_args(u'a="b c"') == [u'a="b c"']
    assert split_args(u'a="b c" d=e') == [u'a="b c"', u'd=e']

    # Make sure the balanced checks are working
    assert split_args(u'{{')[0] == u'{{'
    assert split_args(u'}}')[0] == u'}}'
    assert split_args(u'{%')[0] == u'{%'

# Generated at 2022-06-11 09:02:09.903085
# Unit test for function split_args

# Generated at 2022-06-11 09:02:29.329992
# Unit test for function parse_kv

# Generated at 2022-06-11 09:02:37.221493
# Unit test for function split_args

# Generated at 2022-06-11 09:02:45.700916
# Unit test for function split_args
def test_split_args():
    """
    Unit test for function split_args
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Test direct call
    args = 'foo bar baz'
    params = split_args(args)
    assert isinstance(params, list)
    assert len(params) == 3
    assert params[0] == 'foo'
    assert params[1] == 'bar'
    assert params[2] == 'baz'
    # Test AnsibleModule call
    module = AnsibleModule(argument_spec=dict(
        foobar=dict(type='str', required=True),
        foobar_dict=dict(type='dict')
        ),
        supports_check_mode=False
    )
    module_

# Generated at 2022-06-11 09:02:56.162880
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    import sys
    import os
    import ansible.modules.utilities.logic
    import ansible.modules.utilities.raw
    import ansible.modules.utilities.command

    # workaround to prevent deprecation warning
    sys.stdout = StringIO()

    # create vault secret
    vault_secret = "mysecret"
    v = VaultEditor(VaultLib(vault_secret))

    # encrypt args string
    args = "a=b c=\"a space\""
    encrypted = v.encrypt(args)

    # decrypt args string
    args = v.decrypt(encrypted)

    # check that args is correctly decrypted


# Generated at 2022-06-11 09:03:06.127689
# Unit test for function parse_kv
def test_parse_kv():
    "Test parse_kv"
    test1, expected1 = "a=b c=d e=f", {"a":"b", "c":"d", "e": "f"}
    test2, expected2 = "a=\"b c=d e\" f=g", {"a":"b c=d e", "f": "g"}
    test3, expected3 = "a=b c=d e=f", {"a":"b", "c":"d", "e": "f"}

    assert(parse_kv(test1) == expected1)
    assert(parse_kv(test2) == expected2)
    assert(parse_kv(test3) == expected3)

    print("All tests passed")
    # Unit test for function test_split_args

# Generated at 2022-06-11 09:03:15.904540
# Unit test for function split_args
def test_split_args():
    import types
    # Tests for the old (1.x) style

# Generated at 2022-06-11 09:03:27.741109
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo=\"bar\"") == {u'foo': u'bar'}
    assert parse_kv("foo=\"bar\" baz=\"blip\"") == {u'foo': u'bar', u'baz': u'blip'}
    assert parse_kv("/usr/bin/foo bar baz") == {u'_raw_params': u'/usr/bin/foo bar baz'}
    assert parse_kv("foo=\"bar baz\" blip=blop") == {u'foo': u'bar baz', u'blip': u'blop'}

# Generated at 2022-06-11 09:03:36.458377
# Unit test for function split_args
def test_split_args():
    def _compare(input, output):
        split = split_args(input)
        joined = join_args(split)
        assert output == joined

    _compare(r'a=b c="foo bar"', 'a=b c="foo bar"')
    _compare('a=b c="foo bar" baz={{ hi }}', 'a=b c="foo bar" baz={{ hi }}')
    _compare('a=b c="foo bar" baz={{ hi }} foo={{ bar }}', 'a=b c="foo bar" baz={{ hi }} foo={{ bar }}')
    _compare('a=b c="foo bar" baz={{ hi }}\nfoo={{ bar }}', 'a=b c="foo bar" baz={{ hi }}\nfoo={{ bar }}')


# Generated at 2022-06-11 09:03:47.229125
# Unit test for function parse_kv
def test_parse_kv():
    # Split on spaces, except when inside quotes
    assert parse_kv('foo bar=baz') == {'foo': '', 'bar': 'baz'}
    assert parse_kv("foo bar='123 123'") == {'foo': '', 'bar': '123 123'}
    assert parse_kv("foo bar=\"123 123\"") == {'foo': '', 'bar': '123 123'}
    assert parse_kv("arg1='http://foo.bar/baz' arg2=hello") == {'arg1': 'http://foo.bar/baz', 'arg2': 'hello'}

# Generated at 2022-06-11 09:03:57.488501
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils._text import to_text

    # Basic test
    kvexp = {'k0': 'v0', 'k1': 'v1', 'k2': 'v2', 'k3': 'v3', 'k4': 'v4', 'k5': 'v5'}
    kvstr = to_text('k0=v0 k1=v1 k2=v2 k3=v3 k4=v4 k5=v5')

    assert parse_kv(kvstr) == kvexp

    # Check that joining and splitting works by using join_args()
    # and split_args() as the parsing functions instead of manually.
    assert parse_kv(join_args(parse_kv(kvstr))) == kvexp

    # Test with duplicate keys in the string
