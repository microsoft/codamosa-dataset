

# Generated at 2022-06-11 08:54:52.892208
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=foo\nbar=baz") == ['a=b', 'c=foo', 'bar=baz']
    assert split_args("a=b c=foo\\\nbar=baz") == ['a=b', 'c=foobar=baz']
    assert split_args("a=b c=foo\\\n  bar=baz") == ['a=b', 'c=foo  bar=baz']
    assert split_args("a=b c=foo\\\n  bar=baz\\\n  foo2=bar2")

# Generated at 2022-06-11 08:55:05.576826
# Unit test for function split_args
def test_split_args():
    # Simple tests
    assert(split_args('foo bar "baz wiz"') == ['foo', 'bar', '"baz wiz"'])

    # Try things with spaces
    assert(split_args('foo\nbar "baz\nwiz"') == ['foo\nbar', '"baz\nwiz"'])
    #assert(split_args('foo \nbar "baz\nwiz"') == ['foo', '\nbar', '"baz\nwiz"'])
    assert(split_args('foo \nbar "baz\nwiz"') == ['foo\nbar', '"baz\nwiz"'])

    # Make sure that line continuation doesn't break things

# Generated at 2022-06-11 08:55:12.329059
# Unit test for function split_args

# Generated at 2022-06-11 08:55:23.993392
# Unit test for function split_args
def test_split_args():
    class DummyModule():
        pass
    # success case
    assert split_args(u'"1" "2" "3" "4"') == ['1', '2', '3', '4']

    # just ensure we don't blow up here while parsing this line
    assert split_args('/usr/bin/php') == ['/usr/bin/php']

    # double quotes used to be broken but this was fixed
    # in the parser rewrite because it was easier to test
    assert split_args(u'"1" "2" "3" "and 4"') == ['1', '2', '3', 'and 4']

    # test with a jinja2 tag inside quotes
    assert split_args(u'"1" "{{2} 3}" "4"') == ['1', '{{2} 3}', '4']

    #

# Generated at 2022-06-11 08:55:36.180632
# Unit test for function split_args

# Generated at 2022-06-11 08:55:44.051419
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import OrderedDict

# Generated at 2022-06-11 08:55:54.474027
# Unit test for function split_args

# Generated at 2022-06-11 08:56:05.197972
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1") == {u'a': u'1'}
    assert parse_kv("a=1 b=1") == {u'a': u'1', u'b': u'1'}
    assert parse_kv("a='1' b=\"1\" c=1 d=\"1\"") == {u'a': u'1', u'b': u'1', u'c': u'1', u'd': u'1'}
    assert parse_kv("a=\"1=1\" b=\"1\" c=1 d=\"1\"") == {u'a': u'1=1', u'b': u'1', u'c': u'1', u'd': u'1'}

# Generated at 2022-06-11 08:56:14.387607
# Unit test for function split_args

# Generated at 2022-06-11 08:56:25.795890
# Unit test for function split_args
def test_split_args():
    import json
    import os
    import sys

    def _load_yaml_fixture(filename):
        with open(filename, 'r', errors='replace') as f:
            return f.read()

    fixture_dir = '_test/unittests/parsing/split_args/'

    # Example of how to skip a test
    #for test in ['test_skip']:
    #    try:
    #        os.remove(fixture_dir + test + '.out')
    #    except OSError:
    #        pass

    for test in os.listdir(fixture_dir):
        if test.endswith('.yaml'):
            print('Testing ' + test)
            data = _load_yaml_fixture(fixture_dir + test)

# Generated at 2022-06-11 08:56:45.312229
# Unit test for function parse_kv
def test_parse_kv():
    assert {} == parse_kv(u'')
    assert {u'key': u'value'} == parse_kv(u'key="value"')
    assert {u'key': u'value'} == parse_kv(u"key='value'")
    assert {u'key': u'val ue'} == parse_kv(u"key='val ue'")
    assert {u'key': u'value'} == parse_kv(u'key=value')

    assert {u'key': u''} == parse_kv(u'key=')
    assert {u'key': u''} == parse_kv(u'key = ')
    assert {u'key': u''} == parse_kv(u"key=''")

# Generated at 2022-06-11 08:56:55.021880
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="d e"') == {u'a': u'b', u'c': u'd e'}
    assert parse_kv(u'a="b c" d="e f"') == {u'a': u'b c', u'd': u'e f'}
    assert parse_kv(u'a="b c"\nd="e f"') == {u'a': u'b c', u'd': u'e f'}
    assert parse_kv(u'a=b c="d e') == {u'_raw_params': u'a=b c="d e'}

# Generated at 2022-06-11 08:57:02.834597
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=foobar") == dict(foo="bar", baz="foobar")
    assert parse_kv(u"foo='bar' baz='foobar'") == dict(foo="bar", baz="foobar")
    assert parse_kv(u"foo=\"bar\" baz=\"foobar\"") == dict(foo="bar", baz="foobar")
    assert parse_kv(u"foo=bar:baz=foobar") == dict(foo="bar:baz=foobar")
    assert parse_kv(u"foo='bar:baz=foobar'") == dict(foo="bar:baz=foobar")

# Generated at 2022-06-11 08:57:12.672923
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv("") == {})
    assert(parse_kv("a") == {'_raw_params': "a"})
    assert(parse_kv("a=1") == {'a': '1'})
    assert(parse_kv("a=1 b=2") == {'a': '1', 'b': '2'})
    assert(parse_kv("a=1 b=2,3 c=4") == {'a': '1', 'b': '2,3', 'c': '4'})
    assert(parse_kv("a=1 b=2,3 c=4", check_raw=True) == {'a': '1', 'b': '2,3', 'c': '4'})

# Generated at 2022-06-11 08:57:18.740053
# Unit test for function parse_kv
def test_parse_kv():
    answer = {'a': 'Hello World', 'b': 'test', 'c': u'India', 'd': 'three', 'e': 'one two', '_raw_params':"a=Hello World b=test c='India' d='three' e=one\\ two"}
    input = "a=Hello World b=test c='India' d='three' e=one\\ two"
    result = parse_kv(input)
    assert result == answer



# Generated at 2022-06-11 08:57:27.663186
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b') == {u'a': u'b'}
    assert parse_kv(u'   a=b   ') == {u'a': u'b'}
    assert parse_kv(u'   a =  b   ') == {u'a': u'b'}
    assert parse_kv(u"a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv(u"a='b c'") == {u'a': u'b c'}
    assert parse_kv(u"a='b c' d='e f'") == {u'a': u'b c', u'd': u'e f'}

# Generated at 2022-06-11 08:57:36.334136
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar one two') == dict(foo='bar one two')
    assert parse_kv('"foo=bar one two"') == dict(foo='bar one two')
    assert parse_kv('"foo=bar one two') == dict(foo='"bar one two')
    assert '_raw_params' not in parse_kv('foo=bar one two')
    assert '_raw_params' not in parse_kv('"foo=bar one two"')
    assert '_raw_params' not in parse_kv('foo=bar one two', check_raw=True)
    assert 'one two' in parse_kv('foo=bar one two', check_raw=True)['_raw_params']

# Generated at 2022-06-11 08:57:39.233103
# Unit test for function split_args
def test_split_args():
    test_str1 = "foo=bar baz=\"{{ foo }}\""
    result_str1 = ['foo=bar', 'baz="{{ foo }}"']
    assert(result_str1 == split_args(test_str1))

# Generated at 2022-06-11 08:57:48.200477
# Unit test for function split_args
def test_split_args():
    def test_split(string, answer):
        result = split_args(string)
        if result != answer:
            raise AssertionError("splitting of '%s' failed, got %s instead of %s" % (string, result, answer))

    test_split("foo", ["foo"])
    test_split("'foo'", ["'foo'"])
    test_split("'foo bar'", ["'foo bar'"])
    test_split("'foo' 'bar'", ["'foo'", "'bar'"])
    test_split("foo bar", ["foo", "bar"])
    test_split("foo bar baz", ["foo", "bar", "baz"])
    test_split("foo\nbar\nbaz", ["foo", "bar", "baz"])

# Generated at 2022-06-11 08:57:57.549399
# Unit test for function parse_kv
def test_parse_kv():
    
    # Test for empty string
    original = ['']
    parsed_kv = parse_kv(original)
    assert parsed_kv == {}

    # Test for a list of arguments with a single key-value pair and an unnamed argument
    original = [
        'key=value',
        'unnamed_argument'
    ]
    parsed_kv = parse_kv(original)
    assert parsed_kv == {
        'key': 'value',
        '_raw_params': 'unnamed_argument'
    }
    # Test for a list of arguments with a key-value pair with a space and an unnamed argument
    original = [
        'key:=value',
        'unnamed_argument'
    ]
    parsed_kv = parse_kv(original)

# Generated at 2022-06-11 08:58:21.506710
# Unit test for function split_args
def test_split_args():
    def assert_split_args(input_str, expected_split, msg=''):
        split_str = split_args(input_str)
        try:
            assert(split_str == expected_split)
        except AssertionError:
            print("\nInput String:")
            print("    " + repr(input_str))
            print("Expected Split:")
            print("   ", repr(expected_split))
            print("Actual Split:")
            print("    ", repr(split_str))
            raise

    # Test cases that should split

# Generated at 2022-06-11 08:58:30.032909
# Unit test for function parse_kv
def test_parse_kv():
    import ast

# Generated at 2022-06-11 08:58:38.150813
# Unit test for function split_args
def test_split_args():
    # Basic test for the function
    assert split_args(u"echo '{{ foo }}'") == [u"echo", u"'{{ foo }}'"]
    assert split_args(u'echo "{{ foo }}"') == [u'echo', u'"{{ foo }}"']
    assert split_args(u"echo foo{{ foo }}bar") == [u"echo", u"foo{{ foo }}bar"]
    assert split_args(u"echo foo{{ foo }} bar") == [u"echo", u"foo{{ foo }} bar"]

    # test multiple levels of quotes and jinja2
    assert split_args("echo '{{ foo }} {{ foo }}'") == ["echo", "'{{ foo }} {{ foo }}'"]

# Generated at 2022-06-11 08:58:49.962760
# Unit test for function split_args
def test_split_args():
    assert split_args("") == []
    assert split_args("one") == ["one"]
    assert split_args("one two") == ["one", "two"]
    assert split_args("one two three") == ["one", "two", "three"]
    assert split_args("one 'two three'") == ["one", "'two three'"]
    assert split_args("one \"two three\"") == ["one", "\"two three\""]
    assert split_args("one={{ two }}") == ["one={{ two }}"]
    assert split_args("one {{ two }}") == ["one", "{{ two }}"]
    assert split_args("one={{ two }} three") == ["one={{ two }}", "three"]
    assert split_args("one {{ two }} three") == ["one", "{{ two }}", "three"]
   

# Generated at 2022-06-11 08:58:57.621852
# Unit test for function parse_kv
def test_parse_kv():
    import unittest
    import sys
    import json

    class TestParseKV(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_parse_kv_returns_dict(self):
            self.assertEqual(type(parse_kv('')), type({}))

        def test_parse_kv_returns_dict_with_correct_values(self):
            self.assertEqual(
                parse_kv('test=val'),
                { 'test': 'val' }
            )


# Generated at 2022-06-11 08:59:09.050633
# Unit test for function split_args
def test_split_args():

    assert(split_args("a=b\\\nc=d") == [u'a=b', u'c=d'])
    assert(split_args("a=\"hello world\"") == [u'a="hello world"'])
    assert(split_args("a=b c=d") == [u'a=b', u'c=d'])
    assert(split_args("a=b c=d\\\ne=f") == [u'a=b', u'c=d', u'e=f'])
    assert(split_args("a=\"b c\" d=e") == [u'a="b c"', u'd=e'])

# Generated at 2022-06-11 08:59:20.377911
# Unit test for function split_args
def test_split_args():

    ############
    # Basic
    ############

    args = "a=b c='foo bar' d=\"foo bar\""
    res = ['a=b', "c='foo bar'", 'd="foo bar"']
    assert split_args(args) == res


    ############
    # Basic with a new line
    ############

    args = "a=b\n c='foo bar'\n"
    res = ['a=b', "c='foo bar'"]
    assert split_args(args) == res


    ############
    # Basic with a new line
    ############

    args = "a=b\n c='foo bar'\n"
    res = ['a=b', "c='foo bar'"]
    assert split_args(args) == res


    #########

# Generated at 2022-06-11 08:59:26.534439
# Unit test for function split_args
def test_split_args():
    # This is some text that, if it is in
    # a playbook, might get misinterpreted by
    # the templating engine
    test1 = '''
        shell: /usr/bin/super_long_command --flag1=foo --flag2={{ foo }}
    '''
    # This is the same text, with all the
    # jinja2 stuff removed
    # Note that we have a long string over multiple lines.
    # jinja2 would escape everything, even the \n characters,
    # so that's what we need to check for
    test1_no_jinja2 = '''
        shell: /usr/bin/super_long_command --flag1=foo --flag2=
    '''
    # This is some text that, while not valid
    # in a playbook, might be output by something
    #

# Generated at 2022-06-11 08:59:32.688489
# Unit test for function split_args
def test_split_args():
    # Some simple non-complex tests
    print("---------------------------------------------------")
    print("Simple non-complex tests")
    assert split_args("a b 'c d' e") == ["a", "b", "'c d'", "e"]
    assert split_args("a b \"c d\" e") == ["a", "b", "\"c d\"", "e"]
    assert split_args("a b \"c d e\" e") == ["a", "b", "\"c d e\"", "e"]
    assert split_args("a b # test comment") == ["a", "b", "# test comment"]
    assert split_args("a b % test comment") == ["a", "b", "% test comment"]

# Generated at 2022-06-11 08:59:43.629888
# Unit test for function parse_kv
def test_parse_kv():

    # Test for option with equals sign
    assert parse_kv('foo=bar') == dict(foo='bar')

    # Test for option without equals sign (converts to bool True)
    assert parse_kv('foo') == dict(foo=True)

    # Test for option without equals sign (converts to bool True)
    assert parse_kv('foo=') == dict(foo='')

    # Test for "invalid" option with equals sign
    assert parse_kv('foo=bar=bar') == dict(foo='bar=bar')

    # Test for option that's zero
    assert parse_kv('foo=0') == dict(foo='0')

    # Test for option that's 1
    assert parse_kv('foo=1') == dict(foo='1')

    # Test for option that contains "="

# Generated at 2022-06-11 09:00:16.286617
# Unit test for function split_args

# Generated at 2022-06-11 09:00:25.553794
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=1 bar=2') == {'foo': '1', 'bar': '2'}
    assert parse_kv("foo='one two' bar=2") == {'foo': 'one two', 'bar': '2'}
    assert parse_kv("foo=one\\ two bar=2") == {'foo': 'one two', 'bar': '2'}
    assert parse_kv("foo=one\two bar=2") == {'foo': 'one\two', 'bar': '2'}
    assert parse_kv("foo=one\tw\x00o bar=2") == {'foo': 'one\tw\x00o', 'bar': '2'}

# Generated at 2022-06-11 09:00:35.360603
# Unit test for function split_args

# Generated at 2022-06-11 09:00:45.993575
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'first=args')[u'first'] == u'args'
    assert parse_kv(u'first=args second=val')[u'second'] == u'val'
    assert parse_kv(u"first='this is literally args'")[u'first'] == u'this is literally args'
    assert parse_kv(u"first='this is literally args' second=val")[u'first'] == u'this is literally args'
    assert parse_kv(u"first='this is literally args' second=val")[u'second'] == u'val'
    assert parse_kv(u"first='this is literally args' second=val third=test")[u'first'] == u'this is literally args'

# Generated at 2022-06-11 09:00:56.708565
# Unit test for function split_args
def test_split_args():
    # These function calls should not raise the ParseError
    split_args("a='b' c={{d}} e={{ f | quote }} g='{{ h | quote }} i={{j}} {{k}}'")
    split_args("executable={{ EXEC }} {{ CMD }}")
    split_args("executable=/bin/echo {{ CMD }}")
    split_args("executable={{ EXEC }} {{ CMD }} creates={{ CREATES }}")
    split_args("executable={{ EXEC }} {{ CMD }} creates={{ CREATES }} removes={{ REMOVES }}")
    split_args("executable={{ EXEC }} {{ CMD }} creates={{ CREATES }} removes={{ REMOVES }} chdir={{ CHDIR }}")

# Generated at 2022-06-11 09:01:08.002503
# Unit test for function split_args
def test_split_args():
    assert_split('')

    assert_split('', '""')
    assert_split('foo', '"foo"')
    assert_split('foo\\ bar', '"foo bar"')
    assert_split('foo bar foo bar', '"foo bar foo bar"')
    assert_split('foo bar foo bar', '"foo bar" "foo bar"')
    assert_split('foo bar foo bar', '"foo bar"foo bar')
    assert_split('foo bar foo bar', 'foo bar"foo bar"')

    assert_split('foo', "'foo'")
    assert_split('foo\\ bar', "'foo bar'")
    assert_split('foo bar foo bar', "'foo bar foo bar'")
    assert_split('foo bar foo bar', "'foo bar' 'foo bar'")

# Generated at 2022-06-11 09:01:19.764728
# Unit test for function split_args
def test_split_args():
    # examples from various modules
    assert split_args('foo=bar key=value') == ['foo=bar', 'key=value']
    assert split_args('foo=bar "key with spaces"=value') == ['foo=bar', '"key with spaces"=value']
    assert split_args('foo=bar "key with spaces"=value') == ['foo=bar', '"key with spaces"=value']
    assert split_args('create mode=0640 owner=apache group=apache') == ['create', 'mode=0640', 'owner=apache', 'group=apache']

# Generated at 2022-06-11 09:01:31.273068
# Unit test for function parse_kv
def test_parse_kv():

    # test for key/value pairs
    test_value = "key=value key2=value2 key3=value3"
    result = parse_kv(test_value)

    assert result['key'] == "value" and result['key2'] == "value2" and result['key3'] == "value3"

    # test for values with spaces
    test_value = "key='value with spaces' key2=\"value with spaces\""
    result = parse_kv(test_value)

    assert result['key'] == "value with spaces" and result['key2'] == "value with spaces"

    # test for values with escaped quotes
    test_value = "key=\"value with escaped 'single' quotes inside double quotes\" key2='value with escaped \"double\" quotes inside single quotes'"
    result = parse_kv(test_value)



# Generated at 2022-06-11 09:01:41.417113
# Unit test for function split_args
def test_split_args():
    print("="*40)
    print("test of split_args()")
    print("="*40)

    def tta(e, a, m=None):
        if m is None:
            m = "expected split:  '%s'\nfrom raw string: '%s'" % (e, a)
        if e != split_args(a):
            raise Exception(m)

    # Make sure quotes are preserved
    tta(["'a'"], "'a'")
    tta(['"a"'], '"a"')

    # Basic tests.  Easy to make sure the join_args() gives us the
    # correct input string
    tta(["a"], "a")
    tta(["a"], "a")
    tta(["a", "b", "c"], "a b c")
   

# Generated at 2022-06-11 09:01:49.860313
# Unit test for function parse_kv
def test_parse_kv():
    assert {'a': 'b', 'c': 'd'} == parse_kv('c=d a=b')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a=b c=d')
    assert {'user': 'johndoe', 'password': 's3cr3t'} == parse_kv('user=johndoe password=s3cr3t')
    assert {'a': 'b', 'c': 'd'} == parse_kv('c=d a=b')
    assert {'a': 'b', 'c': 'd'} == parse_kv('a=b c=d')
    assert {'a': 'b', 'c': 'd'} == parse_kv('  c=d  a=b ')

# Generated at 2022-06-11 09:02:11.877026
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test function parse_kv.
    '''

    # Test with raw_params
    assert parse_kv(u'a=b c=d e=f', check_raw=True) == {u'a': u'b', u'c': u'd', u'e': u'f', u'_raw_params': u'a=b c=d e=f'}
    assert parse_kv(u'a="b c" d=e f=g', check_raw=True) == {u'a': u'b c', u'd': u'e', u'f': u'g', u'_raw_params': u'a="b c" d=e f=g'}

# Generated at 2022-06-11 09:02:22.025055
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('x={{ foo bar }}') == ['x={{ foo bar }}']
    assert split_args('x={{ foo }} bar {{ baz }}') == ['x={{ foo }} bar {{ baz }}']
    assert split_args('x={{ foo }}\\\nbar {{ baz }}') == ['x={{ foo }}\\\nbar {{ baz }}']
    assert split_args('x={{ foo }}\\\nbar') == ['x={{ foo }}\\\nbar']
    assert split_args('x={{ foo }}\nbar') == ['x={{ foo }}\nbar']

# Generated at 2022-06-11 09:02:31.247310
# Unit test for function split_args
def test_split_args():
    assert split_args('foo') == ['foo']
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('foo {% foo %} bar') == ['foo', '{% foo %}', 'bar']
    assert split_args('foo {% foo %}{% bar %} bar') == ['foo', '{% foo %}{% bar %}', ' bar']
    assert split_args('foo {% foo %} bar {% foo %}') == ['foo', '{% foo %}', 'bar', '{% foo %}']
    assert split_args('foo "bar" baz') == ['foo', '"bar"', 'baz']

# Generated at 2022-06-11 09:02:39.164410
# Unit test for function split_args

# Generated at 2022-06-11 09:02:48.792643
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar biz=bat') == {
        u'foo': u'bar',
        u'biz': u'bat',
    }

    assert parse_kv(u'foo=bar biz=bat', check_raw=True) == {
        u'foo': u'bar',
        u'biz': u'bat',
    }

    assert parse_kv(u'foo=bar biz=bat', check_raw=True) == {
        u'foo': u'bar',
        u'biz': u'bat',
    }

    assert parse_kv(u'foo=foo\=bar biz=bat', check_raw=True) == {
        u'foo': u'foo=bar',
        u'biz': u'bat',
    }

    assert parse_

# Generated at 2022-06-11 09:02:51.347858
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("A=1 B=2 C=3") == dict(A='1', B='2', C='3')


# Generated at 2022-06-11 09:03:02.223530
# Unit test for function split_args
def test_split_args():
    def _check(s, result):
        j = join_args(result)
        if j != s:
            print("ERROR: expected result %s when joining %s, but got %s instead" % (s, result, j))
        assert j == s

    _check('echo $HOME', ['echo', '$HOME'])
    _check('echo ${HOME}', ['echo', '${HOME}'])
    _check('echo "a=b c=d"', ['echo', '"a=b c=d"'])
    _check('echo "a=b c=d"', ['echo', '"a=b', 'c=d"'])
    _check('echo "a=b c=d"', ['echo', '"a=b c=d"'])


# Generated at 2022-06-11 09:03:08.999108
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == dict(foo='bar')
    assert parse_kv('foo="bar bar bar"') == dict(foo='bar bar bar')
    assert parse_kv('foo=""') == dict(foo='')
    assert parse_kv('foo="a=b"') == dict(foo='a=b')
    # NOTE: this is actually not valid shell syntax, but we're allowing it as
    # a precedent has been set.
    assert parse_kv('foo=bar=baz') == dict(foo='bar=baz')
    assert parse_kv('foo="bar=baz"') == dict(foo='bar=baz')
#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Generated at 2022-06-11 09:03:20.300994
# Unit test for function split_args

# Generated at 2022-06-11 09:03:30.346532
# Unit test for function parse_kv
def test_parse_kv():
    # Verify that a simple list of key=value pairs works
    assert parse_kv('a=b c=d') == dict(a='b', c='d')

    # Verify that an escaped equals sign works
    assert parse_kv('a\==b') == dict(a='=', b=None)

    # Verify that an unescaped equals sign works
    assert parse_kv('a=b e=f') == dict(a='b', e='f')

    # Verify that escaped spaces work
    assert parse_kv(r'a\ b=c d\ e=f') == dict(a_b='c', d_e='f')

    # Verify that an unescaped space before the equals sign is an error

# Generated at 2022-06-11 09:03:53.152311
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:59.884375
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.six import PY3

    # single_kv_str = u'ansible_ssh_host=a.b.c.d'
    # multi_kv_str = u'ansible_ssh_host=a.b.c.d verbose=yes'
    kv_str = u'ansible_ssh_host=a.b.c.d  verbose=yes  foo=bar h=2 w=3'
    if PY3:
        free_params_str = u"ls '-al /tmp'"
        free_params_str_enc = u"ls '-al /tmp'"
    else:
        free_params_str = u"ls u'-al /tmp'"
        free_params_str_enc = u"ls u\"-al /tmp\""