

# Generated at 2022-06-11 08:55:06.444508
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo {{bar}}" d="{{ foo }}" e="foo}}bar" f={{ bar }} g={{bar }} h="{{foo}} bar" i="foo bar"') == ['a=b', 'c="foo {{bar}}"', 'd="{{ foo }}"', 'e="foo}}bar"', 'f={{ bar }}', 'g={{bar }}', 'h="{{foo}} bar"', 'i="foo bar"']

# Generated at 2022-06-11 08:55:15.363877
# Unit test for function split_args
def test_split_args():
    # Test for issue #31706
    assert split_args('echo "{{hostname}}.{{domain}}"') == ['echo', '"{{hostname}}.{{domain}}"']
    assert split_args('echo "{{hostname}} {{domain}}"') == ['echo', '"{{hostname}} {{domain}}"']
    assert split_args('echo "{{hostname}} {% domain %}"') == ['echo', '"{{hostname}} {% domain %}"']
    assert split_args('echo "{{ hostname }} {% domain %}"') == ['echo', '"{{ hostname }} {% domain %}"']
    assert split_args('echo "{{ hostname }} {% domain %} {{subdomain}}"') == ['echo', '"{{ hostname }} {% domain %} {{subdomain}}"']

# Generated at 2022-06-11 08:55:26.952403
# Unit test for function parse_kv
def test_parse_kv():
    # Basic test 1
    assert parse_kv("a = b = c = a = b = c = a = b = c") == {"a": "b = c = a = b = c = a = b = c"}

    # Basic test 2
    assert parse_kv("a=b") == {"a": "b"}

    # Basic test 3
    assert parse_kv("a=b c=d") == {"a": "b", "c": "d"}

    # Consecutive equals in value
    assert parse_kv("a=b==c==d") == {"a": "b==c==d"}

    # Key without value
    assert parse_kv("a= b=c") == {"a": "b=c"}

    # Key without value, at the end

# Generated at 2022-06-11 08:55:38.956298
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key1=val1 key2=val2') == {'key1': 'val1', 'key2': 'val2'}
    assert parse_kv('key1=val1\nkey2=val2') == {'key1': 'val1', 'key2': 'val2'}
    assert parse_kv('key1=val1  key2=val2') == {'key1': 'val1', 'key2': 'val2'}
    assert parse_kv('key1 = val1 key2 = val2') == {'key1': 'val1', 'key2': 'val2'}
    assert parse_kv('key1 = val1 key2=val2') == {'key1': 'val1', 'key2': 'val2'}
    assert parse_kv

# Generated at 2022-06-11 08:55:48.352421
# Unit test for function parse_kv
def test_parse_kv():
    test = parse_kv('a=b c="d e" f=\'g h\' i=\\"j\\" k=\\\\l')
    assert test['a'] == 'b'
    assert test['c'] == 'd e'
    assert test['f'] == 'g h'
    assert test['i'] == '"j"'
    assert test['k'] == '\\l'
    assert not '_raw_params' in test

    # Test escaping of the parameters
    test = parse_kv('a="b=c" d="e\'" f=\'g"h\' i=\\"j\\" k=\\\\l')
    assert test['a'] == 'b=c'
    assert test['d'] == "e'"
    assert test['f'] == 'g"h'

# Generated at 2022-06-11 08:55:58.709466
# Unit test for function parse_kv
def test_parse_kv():
   cmd = r"/bin/echo myvar=this is my text"
   cmd2 = r"/bin/echo myvar=this is my text command=echo myvar=this is my text"

   #import pudb; pu.db
   orig_options = parse_kv(cmd,check_raw=True)
   options = parse_kv(cmd)
   options2 = parse_kv(cmd2)
   assert options == orig_options
   assert options2['command'] == 'echo myvar=this is my text'
   assert options['myvar']=='this is my text'
   assert options2['myvar']=='this is my text'

#=== FUNCTION ================================================================
# Name: split_args
# Description: Split a string into a list of arguments.
#              Supports unquoting and single back

# Generated at 2022-06-11 08:56:09.095779
# Unit test for function split_args
def test_split_args():
    # Case 1: simple args
    args = "This is a series of args"
    expected_params = ["This", "is", "a", "series", "of", "args"]
    params = split_args(args)
    assert params == expected_params

    # Case 2: args with block
    args = """This is a series of args with a {{ jinja2_block }}"""
    expected_params = ["This", "is", "a", "series", "of", "args", "with","a", "{{", "jinja2_block", "}}"]
    params = split_args(args)
    assert params == expected_params

    # Case 3: args with block, with spaces between words
    args = """This is a series of args with a {{ jinja2_block }}"""

# Generated at 2022-06-11 08:56:19.271818
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c='d e' f=\"g h\"") == ['a=b', "c='d e'", 'f="g h"']
    assert split_args("a=b c='d e' f=\"g h\" i=\\\nj") == ['a=b', "c='d e'", 'f="g h"', 'i=\\\nj']
    assert split_args("a=\"{{ foo }}\" b=\"{{ bar }}\"") == ['a="{{ foo }}"', 'b="{{ bar }}"']
    assert split_args("a=\"{{ foo }}\" b=\"{{ bar }}\" c='{{ baz }}'") == ['a="{{ foo }}"', 'b="{{ bar }}"', "c='{{ baz }}'"]

# Generated at 2022-06-11 08:56:30.644708
# Unit test for function split_args

# Generated at 2022-06-11 08:56:41.942986
# Unit test for function parse_kv
def test_parse_kv():
    # Empty
    assert parse_kv('') == {}
    # Basic pair
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    # Basic pair with whitespace
    assert parse_kv(' foo = bar ') == {'foo': 'bar'}
    # Multiple pairs
    assert parse_kv('foo=bar x=y') == {'foo': 'bar', 'x': 'y'}
    # Pair with different delimiter
    assert parse_kv('foo:bar') == {}
    # Pair with value containing equals
    assert parse_kv('foo=a=b') == {'foo': 'a=b'}
    # Pair with value containing equals escaped
    assert parse_kv('foo=a\=b') == {'foo': 'a=b'}
    #

# Generated at 2022-06-11 08:57:03.847448
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz') == dict(foo='bar baz')
    assert parse_kv('baz foo=bar') == dict(baz='foo=bar')
    assert parse_kv('foo=bar baz foo=bar') == dict(foo='bar foo=bar')
    assert parse_kv('foo="bar baz"') == dict(foo='bar baz')
    assert parse_kv('foo=bar baz="bink boink"') == dict(foo='bar', baz='bink boink')
    assert parse_kv('foo=bar baz=') == dict(foo='bar', baz='')
    assert parse_kv('foo=\'bar baz\'') == dict(foo='bar baz')

# Generated at 2022-06-11 08:57:13.800704
# Unit test for function parse_kv
def test_parse_kv():
    # Test simple use cases of function parse_kv
    assert parse_kv("key=value") == {"key": "value"}
    assert parse_kv("key1=value1 key2=value2") == {"key1": "value1", "key2": "value2"}
    assert parse_kv("key1=value1 key2=value2 key3=value3 key4=value4") == {"key1": "value1", "key2": "value2", "key3": "value3", "key4": "value4"}

    # Test for string containing a single value without an equals sign
    assert parse_kv("value") == {} # Since there is no key to pair with value, it is ignored

    # Test for string containing multiple values without an equals sign
    assert parse_kv("value1 value2") == {} # Since

# Generated at 2022-06-11 08:57:23.180842
# Unit test for function parse_kv
def test_parse_kv():
    in_dict={u'ARG1': u'VALUE1', u'ARG2': u'VALUE2', u'ARG3': u'VALUE3', u'ARG4': u'VALUE4'}
    #in_dict={u'ARG1': u'VALUE1', u'ARG2': u'VALUE2', u'ARG3': u'VALUE3', u'ARG4': u'VALUE4', u'_raw_params': u'ARG5='VALUE5''}
    in_string='ARG1=VALUE1 ARG2=VALUE2 ARG3=VALUE3 ARG4=VALUE4'
    #in_string='ARG1=VALUE1 ARG2=VALUE2 ARG3=VALUE3 ARG4=VALUE4 ARG5=VALUE5'


# Generated at 2022-06-11 08:57:32.155709
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar not"') == {'foo': 'bar not'}
    assert parse_kv('foo=bar baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo=bar baz=foo', check_raw=True) == {'foo': 'bar', 'baz': 'foo', '_raw_params': None}
    assert parse_kv('foo=bar baz=foo not-k-v') == {'foo': 'bar', 'baz': 'foo'}

# Generated at 2022-06-11 08:57:40.703879
# Unit test for function parse_kv
def test_parse_kv():
    # Allowed characters in a variable name
    varname_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_"
    # Characters that are accepted as whitespace
    whitespace_chars = ' \t'
    # Characters that are accepted as quoting characters
    quoting_chars = "'\""
    # Characters that have a special meaning in a var=value string
    special_chars = '=' + whitespace_chars + quoting_chars
    # Characters that are accepted as "normal" characters, with no special meaning
    normal_chars = varname_chars + string.digits
    # Characters that are accepted as meta-characters
    meta_chars = '\\' + special_chars

    # Generate all combinations

# Generated at 2022-06-11 08:57:49.659709
# Unit test for function parse_kv
def test_parse_kv():

    # test empty
    assert parse_kv("") == {}

    # test normal
    assert parse_kv("a=b c=d") == {"a": "b", "c": "d"}

    # test escaped
    assert parse_kv("a='b b' c=\"d d\"") == {"a": "b b", "c": "d d"}

    # test freeform
    assert parse_kv("a=b c=d foo bar") == {"a": "b", "c": "d", "_raw_params": "foo bar"}

    # test mixed
    assert parse_kv("a=b c=d foo bar baz=foo") == {"a": "b", "c": "d", "baz": "foo", "_raw_params": "foo bar"}

    # test quoted delimiters
    assert parse

# Generated at 2022-06-11 08:57:54.709704
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv('k=v list=v1,v2,v3 name= "hello world"')
    assert result['k'] == 'v'
    assert result['list'] == 'v1,v2,v3'
    assert result['name'] == 'hello world'
    assert result['_raw_params'] == 'list=v1,v2,v3'


# Generated at 2022-06-11 08:58:04.028436
# Unit test for function parse_kv
def test_parse_kv():
    assert {'a': 'b'} == parse_kv('a=b')
    assert {u'a': u'b'} == parse_kv(u'a=b')
    assert {u'a': u'a b'} == parse_kv(u'a="a b"')
    assert {u'a': u'a b'} == parse_kv(u'a=a\ b')
    assert {u'a': u'a=b'} == parse_kv(u'a=a\=b')
    assert {u'a': u'="'} == parse_kv(u"a=\\\"\\=")
    assert {u'a': u'=\\"='} == parse_kv(u"a=\\=\\\\\\\"\\=")

# Generated at 2022-06-11 08:58:14.379432
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv('''foo=bar key="with spaces" key2=\'some value\' key3="a=b c=d" key4=a=b c=d''')

    assert options['foo'] == 'bar'
    assert options['key'] == 'with spaces'
    assert options['key2'] == 'some value'
    assert options['key3'] == 'a=b c=d'
    assert options['key4'] == 'a=b c=d'

    assert '_raw_params' not in options


# Generated at 2022-06-11 08:58:23.426474
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar arg1 arg2') == {u'foo': u'bar', u'_raw_params': u'arg1 arg2'}
    assert parse_kv('foo="bar baz" arg1 arg2') == {u'foo': u'bar baz', u'_raw_params': u'arg1 arg2'}
    assert parse_kv("foo='bar baz' arg1 arg2") == {u'foo': u'bar baz', u'_raw_params': u'arg1 arg2'}

# Generated at 2022-06-11 08:58:43.503588
# Unit test for function split_args
def test_split_args():
    assert split_args(u'foo=bar') == [u'foo=bar']
    assert split_args(u'foo="one two"') == [u'foo="one two"']
    assert split_args(u'foo="one \\"two\\""') == [u'foo="one \\"two\\""']
    assert split_args(u"foo='one two'") == [u"foo='one two'"]
    assert split_args(u"foo='one two'\\") == [u"foo='one two'"]
    assert split_args(u"foo='one two'\\\nbar='baz dib'") == [u"foo='one two'", u"bar='baz dib'"]

# Generated at 2022-06-11 08:58:53.876859
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv with list')
    args = '''key1=value1,key2=value2,key3=value3,key4=value4'''
    expected = {u'key1': u'value1', u'key2': u'value2', u'key3': u'value3', u'key4': u'value4'}
    result = parse_kv(args)
    assert expected == result
    print('SUCCESS\n')

    print('Testing parse_kv with one item')
    args = '''key1=value1'''
    expected = {u'key1': u'value1'}
    result = parse_kv(args)
    assert expected == result
    print('SUCCESS\n')

    print('Testing parse_kv with dictionary')
    args

# Generated at 2022-06-11 08:58:59.945516
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"  ') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"\n') == ['a=b', 'c="foo bar"']
    assert split_args('a=b\nc="foo\nbar"\n') == ['a=b', 'c="foo\nbar"']

    assert split_args('a=b c="foo bar') == ['a=b', 'c="foo', 'bar']
    assert split_args('a=b c="foo bar\\') == ['a=b', 'c="foo', 'bar\\']

# Generated at 2022-06-11 08:59:11.486695
# Unit test for function parse_kv
def test_parse_kv():
    test_str = """
    foo=bar
    bar="with=embedded=equals"
    baz="value with spaces"
    foobar2=newvalue
    """
    try:
        d = parse_kv(test_str)
    except Exception as e:
        print(e)
    #print(d)
    assert d['foo'] == u'bar'
    assert d['bar'] == u'with=embedded=equals'
    assert d['baz'] == u'value with spaces'
    assert d['foobar2'] == u'newvalue'
    assert d['_raw_params'] == u'foobar="value with spaces" foobar2=newvalue'
    print("Test passed")


# Based on a function of the same name in Fabric

# Generated at 2022-06-11 08:59:16.729516
# Unit test for function parse_kv
def test_parse_kv():
    # Here, you can have some tests for the parse_kv method
    # The usual syntax is:
    #     assertEqual( <expected_output>, <returned_output> )
    # You can put anything here, but no one will ever read it,
    # we should probably find a better way to test this code.
    assert True



# Generated at 2022-06-11 08:59:25.738281
# Unit test for function parse_kv

# Generated at 2022-06-11 08:59:36.888506
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo=bar baz=quux', check_raw=True) == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo=bar baz=quux spam') == {'foo': 'bar', 'baz': 'quux', '_raw_params': 'spam'}
    assert parse_kv('foo=bar baz=quux spam', check_raw=True) == {'foo': 'bar', 'baz': 'quux', '_raw_params': 'spam'}


# Generated at 2022-06-11 08:59:45.028046
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo_var=foo-value bar_var="bar-value" var3=bar_var=foo') == dict(foo_var='foo-value', bar_var='bar-value', var3='bar_var=foo', _raw_params='bar_var=foo')
    assert parse_kv('foo_var=foo-value "bar var"="bar value"') == dict(foo_var='foo-value', bar_var='bar value')
    assert parse_kv("foo_var=foo-value\nbar_var=bar-value") == dict(foo_var='foo-value', bar_var='bar-value')



# Generated at 2022-06-11 08:59:54.334132
# Unit test for function split_args
def test_split_args():
    import ast
    import tempfile

    def _write_split_args_to_file(string):
        fd, path = tempfile.mkstemp()
        with open(path, 'w') as f:
            f.write(string)
        return (fd, path)

    assert split_args('echo "arg with spaces"') == ['echo', '"arg with spaces"']
    assert split_args('echo "arg with spaces" argwithnospaces') == ['echo', '"arg with spaces"', 'argwithnospaces']
    assert split_args('echo "arg with spaces" argwithnospaces "more with spaces"') == ['echo', '"arg with spaces"', 'argwithnospaces', '"more with spaces"']

# Generated at 2022-06-11 09:00:03.349077
# Unit test for function split_args
def test_split_args():
    '''
    test_split_args
        Given a set of input args, assert that the parsed versions are
        equivalent and in the same order.
    '''

# Generated at 2022-06-11 09:00:18.857216
# Unit test for function split_args
def test_split_args():
    # simple test case
    test_string = "a=b c='foo bar'"
    assert split_args(test_string) == ["a=b", "c='foo bar'"]

    # test case with escapes
    test_string = r"a=b c='foo\ bar'"
    assert split_args(test_string) == ["a=b", "c='foo\\ bar'"]

    # test case with embeded jinja blocks
    test_string = r"foo bar {{foobar}} baz"
    assert split_args(test_string) == ["foo", "bar", "{{foobar}}", "baz"]

    # test case with nested jinja blocks
    test_string = r"foo bar {{{{foobar}}}} baz"

# Generated at 2022-06-11 09:00:29.024392
# Unit test for function parse_kv
def test_parse_kv():
    args = "a=b b=c d=\"e\" f='g' h=\"i j\" k='l m' n='o\'p' q='r\"s' t=\"u'v'\""
    options = parse_kv(args)
    assert options['a'] == 'b'
    assert options['b'] == 'c'
    assert options['d'] == 'e'
    assert options['f'] == 'g'
    assert options['h'] == 'i j'
    assert options['k'] == 'l m'
    assert options['n'] == "o'p"
    assert options['q'] == 'r"s'
    assert options['t'] == "u'v'"


# Generated at 2022-06-11 09:00:36.597540
# Unit test for function parse_kv
def test_parse_kv():
    args = "chdir=/var/lib/awx"
    output = parse_kv(args, check_raw=True)
    assert output == {u'_raw_params': u'', u'chdir': u'/var/lib/awx'}
    assert output == {u'chdir': u'/var/lib/awx', u'_raw_params': u''}
    assert output != {u'chdir': u'/var/lib/awx'}
    assert output != {u'chdir': u'/var/lib/awx', u'_raw_params': u'chdir=/var/lib/awx'}


# Generated at 2022-06-11 09:00:44.043607
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d x=') == {'a': 'b', 'c': 'd', 'x': None}
    assert parse_kv(u'a=b c=d x="$HOME"') == {u'a': u'b', u'c': u'd', u'x': u'$HOME', u'_raw_params': u'a=b c=d x="$HOME"'}



# Generated at 2022-06-11 09:00:55.483219
# Unit test for function split_args
def test_split_args():
    # negative test for nesting error (issue #34454)
    try:
        split_args('{{{ "foo" }}}')
    except AnsibleParserError:
        pass
    else:
        raise AssertionError('unbalanced jinja2 block nesting should have been detected')

    inp = 'foo bar baz'
    outp = ['foo', 'bar', 'baz']
    assert split_args(inp) == outp

    inp = 'foo bar baz    '
    outp = ['foo', 'bar', 'baz']
    assert split_args(inp) == outp

    inp = 'foo {{ bar }}baz'
    outp = ['foo', '{{ bar }}baz']
    assert split_args(inp) == outp

    inp = 'foo {{ bar }} baz'

# Generated at 2022-06-11 09:01:06.455546
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(" a=b") == {u'a': u'b'}
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c='d e'") == {u'a': u'b', u'c': u'd e'}
    assert parse_kv("a=b c=\"d e\"") == {u'a': u'b', u'c': u'd e'}
    assert parse_kv("a=b c=\"d e f\"") == {u'a': u'b', u'c': u'd e f'}

# Generated at 2022-06-11 09:01:11.535980
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=1 bar="hello\\\\ world" baz=\'this is a quoted "blah" string\' one=1') == {'foo':'1', 'bar':'hello\\ world', 'baz':'this is a quoted "blah" string', 'one':'1'}


# Generated at 2022-06-11 09:01:21.839635
# Unit test for function parse_kv
def test_parse_kv():
    value = "a=1"
    expect = {u'a': u'1'}
    result = parse_kv(value)
    assert result == expect, "%s != %s" % (result, expect)

    value = "a=1 b=2"
    expect = {u'a': u'1', u'b': u'2'}
    result = parse_kv(value)
    assert result == expect, "%s != %s" % (result, expect)

    value = "a=1 b='hello world' c=\"goodbye cruel world\""
    expect = {u'a': u'1', u'b': u'hello world', u'c': u'goodbye cruel world'}
    result = parse_kv(value)

# Generated at 2022-06-11 09:01:33.483993
# Unit test for function parse_kv
def test_parse_kv():
    # Testing values with '=', '\n', and '\t'
    parse_kv_test_1 = """
    key_1=value_1
    key_2=value_2
    key_3=value_3
    """

    # Testing values with quotes surrounding values
    parse_kv_test_2 = """
    key_1="value_1"
    key_2='value_2'
    key_3='value_3'
    """

    # Testing values with escaped quotes in values
    parse_kv_test_3 = """
    key_1="value_\\"1"
    key_2='value_\\'2'
    key_3='value_\\'3'
    """

    # Testing values with escaped quotes surrounding values

# Generated at 2022-06-11 09:01:43.810736
# Unit test for function parse_kv

# Generated at 2022-06-11 09:01:57.726924
# Unit test for function parse_kv

# Generated at 2022-06-11 09:02:06.707682
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c="d" e="f g" h=i j="k" l=m n=o p=q') == {"a": "b", "c": "d", "e": "f g", "h": "i", "j": "k", "l": "m", "n": "o", "p": "q"}
    assert parse_kv('f g') == {"_raw_params": "f g"}
    assert parse_kv('f=g') == {"f": "g"}
    assert parse_kv('f="g"') == {"f": "g"}
    assert parse_kv('f=g h="i"') == {"f": "g", "h": "i"}

# Generated at 2022-06-11 09:02:18.386062
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("nospace=123")
    assert result == dict(nospace="123")
    result = parse_kv("not-escaped=a=b")
    assert result == dict(not_escaped="a=b")
    result = parse_kv("escaped=\\=a\\=b")
    assert result == dict(escaped="=a=b")
    result = parse_kv("key=1 key2=2")
    assert result == dict(key="1", key2="2")
    result = parse_kv("key=1 key2=2 ", check_raw=True)
    assert result == dict(key="1", key2="2", _raw_params="")
    result = parse_kv("key=1 key2=2 key3", check_raw=True)

# Generated at 2022-06-11 09:02:27.559173
# Unit test for function parse_kv
def test_parse_kv():
    assert(parse_kv('AuthorizedKeysCommand=foo AuthorizedKeysCommandUser=bar') == {
        'AuthorizedKeysCommand': 'foo',
        'AuthorizedKeysCommandUser': 'bar'
    })
    assert(parse_kv('') == {})
    assert(parse_kv('"AuthorizedKeysCommand=foo" "AuthorizedKeysCommandUser=bar"') == {
        'AuthorizedKeysCommand': 'foo',
        'AuthorizedKeysCommandUser': 'bar'
    })
    assert(parse_kv('foo=\'bar\'') == {
        'foo': 'bar'
    })
    assert(parse_kv('foo=bar') == {
        'foo': 'bar'
    })

# Generated at 2022-06-11 09:02:35.707790
# Unit test for function parse_kv
def test_parse_kv():
    '''Unit test for function parse_kv'''
    # test that if no args are passed, None is returned
    assert parse_kv(args=None) == {}
    # test that empty string is returned
    assert parse_kv(args='') == {}
    # test that simple string is correctly parsed
    simple_args = 'arg1="blah" arg2="blee"'
    assert parse_kv(args=simple_args) == {'arg1': 'blah', 'arg2': 'blee'}
    # test that escaped args are correctly parsed
    escaped_args = 'arg1="bl\\"ah" arg2="b\\"lee"'
    assert parse_kv(args=escaped_args) == {'arg1': 'bl"ah', 'arg2': 'b"lee'}
    # test

# Generated at 2022-06-11 09:02:43.862723
# Unit test for function split_args
def test_split_args():
    _assert_split_args('a=b c=d', ['a=b', 'c=d'])
    _assert_split_args('foo bar', ['foo', 'bar'])
    _assert_split_args('foo', ['foo'])
    _assert_split_args('foo "', ['foo', '"'])
    _assert_split_args('foo ""', ['foo', '""'])
    _assert_split_args('"foo bar"', ['"foo bar"'])
    _assert_split_args('"foo bar baz"', ['"foo bar baz"'])
    _assert_split_args('"foo', ['\'"foo'])
    _assert_split_args('funny string "with quote" "and another"', ['funny', 'string', '"with quote"', '"and another"'])

# Generated at 2022-06-11 09:02:54.580642
# Unit test for function split_args
def test_split_args():

    # Test cases that should not raise an exception
    assert split_args('') == []
    assert split_args(u'foo') == [u'foo']
    assert split_args(u'foo bar') == [u'foo', u'bar']
    assert split_args(u'foo bar baz') == [u'foo', u'bar', u'baz']
    assert split_args(u'foo bar baz quux') == [u'foo', u'bar', u'baz', u'quux']
    assert split_args(u'    foo    bar    baz    quux    ') == [u'foo', u'bar', u'baz', u'quux']

# Generated at 2022-06-11 09:03:05.039220
# Unit test for function split_args
def test_split_args():
    # single quotes
    assert split_args('simple') == ['simple']
    assert split_args("'simple'") == ['\'simple\'']
    assert split_args("'simp le'") == ['\'simp le\'']
    assert split_args("'simp le' 'more'") == ['\'simp le\'', "'more'"]
    assert split_args("'simp le' 'm\\'ore'") == ['\'simp le\'', "'m\\'ore'"]
    assert split_args("'simp le' 'm\\'ore' 'finally'") == ['\'simp le\'', "'m\\'ore'", "'finally'"]
    # double quotes
    assert split_args('"simple"') == ['"simple"']

# Generated at 2022-06-11 09:03:15.018597
# Unit test for function split_args
def test_split_args():
    # Test basic functionality
    param = "i am a string"
    assert [param] == split_args("i am a string")

    # Test empty string
    assert [] == split_args("")

    # Test a simple quoted string
    param = "i am a string"
    assert [param] == split_args('"i am a string"')

    # Test a string with embedded double quotes
    param = 'i am a "string"'
    assert [param] == split_args('i am a "string"')

    # Test a string with embedded single quotes
    param = "i am a 'string'"
    assert [param] == split_args("i am a 'string'")

    # Test an escaped embedded single quote
    param = "i am a \'string'"
    assert [param] == split_args("i am a \'string\'")

# Generated at 2022-06-11 09:03:27.046085
# Unit test for function split_args

# Generated at 2022-06-11 09:03:47.346421
# Unit test for function split_args
def test_split_args():
    '''
    tests the split_args function against all possible jinja2 blocks and quotes
    '''

    # single block tests
    single_quotes = split_args("'{{ foo }}'")
    assert single_quotes == ["'{{ foo }}'"]
    double_quotes = split_args('"{{ foo }}"')
    assert double_quotes == ['"{{ foo }}"']
    print_block = split_args("{{ foo }}")
    assert print_block == ["{{ foo }}"]
    block_block = split_args("{% foo %}")
    assert block_block == ["{% foo %}"]
    comment_block = split_args("{# foo #}")
    assert comment_block == ["{# foo #}"]
    empty_quotes = split_args("''")
    assert empty_

# Generated at 2022-06-11 09:03:57.584950
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'c': u'3', u'b': u'2'}
    assert parse_kv("a=\"1\" b=2 c=3") == {u'a': u'1', u'c': u'3', u'b': u'2'}
    assert parse_kv("a=\"1 2 3\" b=2 c=3") == {u'a': u'1 2 3', u'c': u'3', u'b': u'2'}


# Generated at 2022-06-11 09:04:05.177901
# Unit test for function parse_kv
def test_parse_kv():
    # Note that this test_parse_kv() is only for parsing - specific
    # flag options parsing test is in test_module_utils_common.py
    assert parse_kv('a=b c=d', True) == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d', False) == {'a': 'b', 'c': 'd', '_raw_params': 'a=b c=d'}
    assert parse_kv('a=b c=d e', False) == {'a': 'b', 'c': 'd', 'e': True, '_raw_params': 'a=b c=d e'}
    assert parse_kv('a=b c=d e', True)