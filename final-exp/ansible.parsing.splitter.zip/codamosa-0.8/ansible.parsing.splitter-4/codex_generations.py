

# Generated at 2022-06-11 08:55:16.554112
# Unit test for function split_args

# Generated at 2022-06-11 08:55:28.215176
# Unit test for function split_args
def test_split_args():
    import copy

    # TODO: If a key starts with "{{", we should not coalesce that to the previous token.
    # This was actually a bug, but was already here. We need to fix it, but it's a subtle bug
    # and all the code is correct. The issue is that we would split on "{{ vars.foo }}" but
    # not re-assemble it. The reason for this was that we were using a "split" operation,
    # which does not include the delimiter in the elements of the list returned. The previous
    # token that we would concatenate would be "--foo=" and then when the next element, which
    # starts with "{{", would be concatenated on, it would end up "--foo={{ vars.foo }}". We
    # would then treat this as one argument, which is incorrect. The solution to

# Generated at 2022-06-11 08:55:39.942960
# Unit test for function split_args

# Generated at 2022-06-11 08:55:49.568201
# Unit test for function split_args
def test_split_args():

    # Test 1: Simple string
    #
    # Given:
    #
    #   args: a=b c="foo bar"
    #
    expected = ['a=b', 'c="foo bar"']
    assert expected == split_args('a=b c="foo bar"')

    # Test 2: J2 inside quotes at end of string
    #
    # Given:
    #
    #   args: a=b c="{% foo bar %}"
    #
    expected = ['a=b', 'c="{% foo bar %}"']
    assert expected == split_args('a=b c="{% foo bar %}"')

    # Test 3: J2 inside quotes at start of string
    #
    # Given:
    #
    #   args: "{% foo bar %}" a=b
    #
   

# Generated at 2022-06-11 08:55:59.764223
# Unit test for function split_args

# Generated at 2022-06-11 08:56:10.102269
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=\"foo bar\"\n") == ['a=b', 'c=foo bar']
    assert split_args("a=b c=\"foo bar\"\n   d=e") == ['a=b', 'c=foo bar', 'd=e']
    assert split_args("a=b c=\"foo bar\"\n d=e") == ['a=b', 'c=foo bar', 'd=e']
    assert split_args("a=b c=\"foo   bar\"\n d=e") == ['a=b', 'c=foo   bar', 'd=e']

# Generated at 2022-06-11 08:56:20.850446
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b") == ["a=b"]
    assert split_args("a=b c=d") == ["a=b", "c=d"]
    assert split_args("a=b c='d e' f='g h'") == ["a=b", "c='d e'", "f='g h'"]
    assert split_args("a=b c={{ d }} e={{ f }}") == ["a=b", "c={{ d }}", "e={{ f }}"]
    assert split_args("a=b c={{ d }} e={{ f }} g=h") == ["a=b", "c={{ d }}", "e={{ f }}", "g=h"]

# Generated at 2022-06-11 08:56:23.717507
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("foo=123 bar")
    assert options["foo"] == "123"
    assert options["_raw_params"] == "bar"



# Generated at 2022-06-11 08:56:33.455471
# Unit test for function split_args
def test_split_args():
    def _prove(args, expected):
        args = split_args(args)
        assert args == expected, ("args did not match expected: %s != %s" % (args, expected))

    _prove('foo=bar', ['foo=bar'])
    _prove('foo=bar arg', ['foo=bar', 'arg'])
    _prove('foo=bar\narg', ['foo=bar\narg'])
    _prove('foo=bar arg1 arg2', ['foo=bar', 'arg1', 'arg2'])
    _prove('foo=bar arg1 arg2\narg3 arg4', ['foo=bar', 'arg1', 'arg2\narg3', 'arg4'])

# Generated at 2022-06-11 08:56:44.187035
# Unit test for function parse_kv
def test_parse_kv():
    args = "creates=/tmp/foo executable=/bin/sh removes=/tmp/bar"
    assert parse_kv(args, check_raw=False) == dict(creates='/tmp/foo', executable='/bin/sh', removes='/tmp/bar')

    args = "creates=/tmp/foo chdir=/tmp param=value executable=/bin/sh param2='foo bar'"
    result = parse_kv(args, check_raw=True)
    assert result == dict(creates='/tmp/foo', chdir='/tmp', executable='/bin/sh', _raw_params="param=value param2='foo bar'")

    args = "arg1 param1=value1 'param two=value two'"
    result = parse_kv(args, check_raw=True)

# Generated at 2022-06-11 08:56:59.607931
# Unit test for function parse_kv
def test_parse_kv():
    def assert_kv(s, e):
        r = parse_kv(s)
        assert r == e, ('parsing "%s" failed:\nreturned:\n%s\nexpected:\n%s\n' % (s, r, e))

    # assert_kv('foo=bar', {'foo': 'bar'})
    # assert_kv('foo = bar = baz', {'_raw_params': 'foo = bar = baz'})
    # assert_kv('foo=bar\nbaz=bang', {'foo': 'bar', '_raw_params': 'baz=bang'})
    # assert_kv('foo=bar baz=bang', {'foo': 'bar', '_raw_params': 'baz=bang'})
    # assert_kv('foo=bar\nb

# Generated at 2022-06-11 08:57:09.297907
# Unit test for function split_args
def test_split_args():

    # Test unbalanced error
    try:
        split_args('foo bar{{foo')
        assert False
    except:
        assert True

    try:
        split_args('foo bar{%foo')
        assert False
    except:
        assert True

    # Test list creation
    assert split_args("foo=bar") == ["foo=bar"]
    assert split_args("foo='bar baz'") == ["foo='bar baz'"]
    assert split_args("foo=\"bar baz\"") == ["foo=\"bar baz\""]
    assert split_args("foo='bar baz") == ["foo='bar baz"]
    assert split_args("foo=\"'bar baz") == ["foo=\"'bar baz"]
    assert split_args("foo=\"bar baz'") == ["foo=\"bar baz'"]
   

# Generated at 2022-06-11 08:57:19.141538
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Run tests on parse_kv()
    '''
    assert parse_kv('') == {}
    assert parse_kv(None) == {}
    assert parse_kv('this') == {'_raw_params': 'this'}
    assert parse_kv('this=that') == {'this': 'that'}
    assert parse_kv('this=that no=way') == {'this': 'that', 'no': 'way'}
    assert parse_kv('this="a thing"') == {'this': 'a thing'}
    assert parse_kv('this="a=thing"') == {'this': 'a=thing'}
    assert parse_kv('this="thing=with=equals"') == {'this': 'thing=with=equals'}

# Generated at 2022-06-11 08:57:28.010481
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:32.096001
# Unit test for function split_args

# Generated at 2022-06-11 08:57:33.925050
# Unit test for function split_args
def test_split_args():
    import doctest
    doctest.testmod(verbose=False)
if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 08:57:42.897070
# Unit test for function parse_kv
def test_parse_kv():
    # Check basic functionality
    assert parse_kv(u'foo=bar') == {u'foo': u'bar'}
    assert parse_kv(u'foo="bar"') == {u'foo': u'bar'}
    assert parse_kv(u'foo=bar baz') == {u'foo': u'bar', u'_raw_params': u'baz'}
    # Check quoting
    assert parse_kv(u'foo="bar \'baz\' bat"') == {u'foo': u"bar 'baz' bat"}
    assert parse_kv(u"foo='bar \"baz\" bat'") == {u'foo': u'bar "baz" bat'}

# Generated at 2022-06-11 08:57:51.271775
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {"foo": "bar"}
    assert parse_kv('foo=bar baz') == {"foo": "bar baz"}
    assert parse_kv('foo="bar baz"') == {"foo": "bar baz"}
    assert parse_kv("foo='bar baz'") == {"foo": "'bar baz'"}
    assert parse_kv("foo='bar baz' poe=alive charles=cc") == {"foo": "'bar baz'", "poe": "alive", "charles": "cc"}
    assert parse_kv("foo='bar baz' poe=\"alive charles=cc\"") == {"foo": "'bar baz'", "poe": "alive charles=cc"}



# Generated at 2022-06-11 08:58:00.889486
# Unit test for function parse_kv
def test_parse_kv():
    # This is a simple test that verifies that we can properly decode
    # certain escape sequences that are used by the command/shell module
    #
    # The following was discovered to be incorrect parsing in 2.0.0.2
    arg_str = (u"multi_line_string=prefix_blank_line\n"
               u"\n"
               u"prefix_tab_line\t\n"
               u"suffix_tab_line\t\n"
               u"\n"
               u"suffix_blank_line\n"
               u"")
    option_dict = parse_kv(arg_str)
    print(option_dict)

# Generated at 2022-06-11 08:58:12.147204
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1   b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1\tb=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a='1 2' b='3 4'") == {'a': '1 2', 'b': '3 4'}
    assert parse_kv("a='1 2' b='3 4'") == {'a': '1 2', 'b': '3 4'}

# Generated at 2022-06-11 08:58:30.881722
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:32.194096
# Unit test for function parse_kv
def test_parse_kv():
    # TODO: write this unit test
    pass
# END of unit test for function parse_kv



# Generated at 2022-06-11 08:58:42.407866
# Unit test for function split_args
def test_split_args():
    def run_test(args, expected_outputs):
        args = to_text(args)
        print('args:', args)
        print('expected_outputs:', expected_outputs)
        parsed_args = split_args(args)
        print('parsed_args:', parsed_args)

        try:
            assert parsed_args == expected_outputs
        except AssertionError:
            print('ERROR: parsed_args != expected_args')
            raise


# Generated at 2022-06-11 08:58:53.133461
# Unit test for function split_args

# Generated at 2022-06-11 08:59:01.164890
# Unit test for function split_args

# Generated at 2022-06-11 08:59:13.593239
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2 c='hello world' d='space=blah'") == dict(a='1', b='2', c='hello world', d='space=blah')
    assert parse_kv(u"a=1 b=2 c='hello world' d='space=blah'\n") == dict(a='1', b='2', c='hello world', d='space=blah')
    assert parse_kv(u"a=1 b=2 c='hello world' d='space=blah'\nmore stuff\n") == dict(a='1', b='2', c='hello world', d='space=blah', _raw_params='more stuff')

# Generated at 2022-06-11 08:59:22.848290
# Unit test for function split_args
def test_split_args():
    args = 'echo "{{ foo }}" and {{ bar }} {{ "bar" }}\n{{ baz }} and this is a test'
    res = ['echo "{{ foo }}"', 'and', '{{ bar }}', '{{ "bar" }}', '{{ baz }}', 'and', 'this', 'is', 'a', 'test']
    assert(res == split_args(args))

    args = 'echo "{{ foo }}" and {{ bar }} {{ "bar" }} {{ baz }} and this is a test'
    res = ['echo "{{ foo }}"', 'and', '{{ bar }}', '{{ "bar" }}', '{{ baz }}', 'and', 'this', 'is', 'a', 'test']
    assert(res == split_args(args))


# Generated at 2022-06-11 08:59:35.258673
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"creates=/var/log/foo,removes=/tmp/bar") == \
        {u'creates': u'/var/log/foo', u'removes': u'/tmp/bar'}
    assert parse_kv(u'stdout=True,stderr=False,stdin=False') == \
        {u'stdout': u'True', u'stderr': u'False', u'stdin': u'False'}
    assert parse_kv(u"creates=/var/log/foo arg1 arg2 arg3") == \
        {u'creates': u'/var/log/foo', u'_raw_params': u'arg1 arg2 arg3'}

# Generated at 2022-06-11 08:59:40.466820
# Unit test for function parse_kv
def test_parse_kv():
    x = parse_kv(u'/bin/bash -c "echo hello" warn=yes', check_raw=True)
    assert x == {
        u'warn': u'yes',
        u'_raw_params': u'"/bin/bash -c \\"echo hello\\""',
    }



# Generated at 2022-06-11 08:59:47.591817
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:07.304036
# Unit test for function split_args

# Generated at 2022-06-11 09:00:14.867478
# Unit test for function split_args
def test_split_args():
    assert split_args(r"find -type f -exec ls -alth \;") == ['find', '-type', 'f', '-exec', 'ls -alth \\;']

    # Original string:
    #     - name: test with items
    #       command: /bin/foo "{{item}}"
    #       with_items:
    #         - a b c
    #         - d e f
    assert split_args("/bin/foo {{item}}") == ['/bin/foo', '{{item}}']
    assert split_args("/bin/foo {{item1}} {{item2}}") == ['/bin/foo', '{{item1}}', '{{item2}}']

# Generated at 2022-06-11 09:00:23.976716
# Unit test for function split_args
def test_split_args():

    # test 1:
    test_args = "param1=value1 param2='value two' param3=\"value three\""
    expected_result = ['param1=value1', "param2='value two'", 'param3="value three"']
    actual_result = split_args(test_args)
    assert actual_result == expected_result, 'test 1 failed: expected: {0}'.format(expected_result)

    # test 2:

# Generated at 2022-06-11 09:00:34.017922
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:44.232817
# Unit test for function split_args
def test_split_args():
    def run_test(input, expected_output):
        output = split_args(input)
        assert output == expected_output


# Generated at 2022-06-11 09:00:55.664597
# Unit test for function split_args
def test_split_args():
    assert split_args("{% foo") == ["{%", "foo"]
    assert split_args("{% foo %}") == ["{% foo %}"]
    assert split_args("{{ foo") == ["{{", "foo"]
    assert split_args("{{ foo }}") == ["{{ foo }}"]
    assert split_args("{# foo") == ["{#", "foo"]
    assert split_args("{# foo #}") == ["{# foo #}"]
    assert split_args("foo 'bar'") == ["foo", "'bar'"]
    assert split_args("foo \"bar\"") == ["foo", "\"bar\""]
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]

# Generated at 2022-06-11 09:01:06.592034
# Unit test for function split_args

# Generated at 2022-06-11 09:01:18.845349
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.basic import AnsibleModule

    # a string with only key/value options
    # a string with only bare options
    # a string with key/value options and bare options

# Generated at 2022-06-11 09:01:25.291064
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'set1=1 set2=set-\u00e9-\N{SNOWMAN} false false=true true=false') == { u'set1': u'1', u'set2': u'set-\u00e9-\N{SNOWMAN}', u'false': True, u'true': False }
    assert parse_kv(u'set1=1 set2=\\"set\\" set3=\'set\'') == { u'set1': u'1', u'set2': u'set', u'set3': u'set' }
    assert parse_kv(u'=== false = "''" =') == { u'===': u'false', u'=': u"''" }

# Generated at 2022-06-11 09:01:36.293742
# Unit test for function parse_kv

# Generated at 2022-06-11 09:01:52.695659
# Unit test for function split_args

# Generated at 2022-06-11 09:02:01.578357
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=glarch') == {u'foo': u'bar', u'baz': u'glarch'}
    assert parse_kv('foo=bar baz=glarch ') == {u'foo': u'bar', u'baz': u'glarch'}
    assert parse_kv('foo=bar baz=glarch ') == {u'foo': u'bar', u'baz': u'glarch'}
    assert parse_kv('foo=bar baz=glarch') == {u'foo': u'bar', u'baz': u'glarch'}

# Generated at 2022-06-11 09:02:05.062142
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=one=1 b=two=2") == {u'a': u'one=1', u'b': u'two=2'}
    assert parse_kv("a='1 2' b=2") == {u'a': u'1 2', u'b': u'2'}
    assert parse_kv("a=\"1 2\" b=2") == {u'a': u'1 2', u'b': u'2'}
    assert parse_kv("a=\"1\"\"2\" b=2") == {u'a': u'1"2', u'b': u'2'}

# Generated at 2022-06-11 09:02:16.690141
# Unit test for function parse_kv
def test_parse_kv():

    assert parse_kv('arg1=val1') == {'arg1': 'val1'}
    assert parse_kv('arg1="val1"') == {'arg1': '"val1"'}
    assert parse_kv('arg1="val1 val2"') == {'arg1': '"val1 val2"'}
    assert parse_kv('arg1="val1 val2" arg2="val3"') == {'arg1': '"val1 val2"', 'arg2': '"val3"'}
    assert parse_kv('arg1="val1 val2" arg2=val3') == {'arg1': '"val1 val2"', 'arg2': 'val3'}

# Generated at 2022-06-11 09:02:25.586166
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}

opts = """
    - name: task with remote user
      ping:
      become: yes
      become_user: foo
      become_method: sudo
      become_flags: '-H -S'
      become_exe: /usr/bin/sudo
      become_flags: '-H -S'
      connect_timeout: 10
      retries: 3
      delay: 10
      remote_user: "{{ foo }}"
      ignore_errors: yes
"""


# Generated at 2022-06-11 09:02:34.393829
# Unit test for function parse_kv
def test_parse_kv():
    # Test simple strings with equals
    assert parse_kv('a=b') == {u'a': u'b'}
    # Test simple strings with whitespace
    assert parse_kv(' a = b ') == {u'a': u'b'}
    # Test simple strings with escapes
    assert parse_kv('a \= b') == {u'a = b': u''}
    # Test simple strings with quotes
    assert parse_kv('a="b"') == {u'a': u'b'}
    # Test simple strings with escapes and quotes
    assert parse_kv('a="b \\\\"') == {u'a': u'b "'}
    assert parse_kv('a=b c=d') == {u'a': u'b', u'c': u'd'}
    #

# Generated at 2022-06-11 09:02:42.481921
# Unit test for function parse_kv

# Generated at 2022-06-11 09:02:52.828002
# Unit test for function split_args
def test_split_args():

    test_input = '''a=b c="foo bar" d="x y z" e="a ' b" f='a " b' g="a \\' b" h='a \\" b' i="a \\\\\\" b" j=foo \
k=bar l="foo bar" m="foo bar" n="foo \' bar"' o="foo \" bar" p='foo \' bar' q="foo \\\" bar" r='foo \\\' bar' s="foo \\\\\\\' bar" t='foo \\\\\\\' bar' \
u="foo \\\\\\\\" bar" v='foo \\\\\\\\" bar'\nw="foo \\\\\\\\" bar" x='foo \\\\\\\\" bar'\n'''

# Generated at 2022-06-11 09:03:03.543432
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:06.828749
# Unit test for function parse_kv
def test_parse_kv():
    print("==> enter test_parse_kv")
    msg = "parse_kv FAILED"
    try:
        # FIXME: implement unit tests
        assert False, msg
    except AssertionError as e:
        print(msg)
        print(e)
    print("<== exit test_parse_kv")


# Generated at 2022-06-11 09:03:27.739266
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b='c d' c=\"e f\"") == {u'a': u'1', u'b': u'c d', u'c': u'e f'}
    assert parse_kv(u"a=1 b=\"c d\" c=\"e f\"") == {u'a': u'1', u'b': u'c d', u'c': u'e f'}
    assert parse_kv(u"a=1 b='c d' c=\"e f\" g=\"\"") == {u'a': u'1', u'b': u'c d', u'c': u'e f', u'g': u''}

# Generated at 2022-06-11 09:03:36.458219
# Unit test for function parse_kv
def test_parse_kv():

    def assert_kv_parse(args_str, expected):
        args = parse_kv(args_str)
        assert args == expected, 'Expected: %s, got %s' % (expected, args)

    # Basic test
    assert_kv_parse('foo=bar', {u'foo': u'bar'})

    # Test vars with spaces
    assert_kv_parse('foo="hello world" bar={{ baz }}', {u'foo': u'hello world', u'bar': u'{{ baz }}'})

    # Test vars with escaped spaces
    assert_kv_parse('foo="hello\\ world" bar={{ baz }}', {u'foo': u'hello world', u'bar': u'{{ baz }}'})

    # Test vars with escaped quotes
    assert_kv

# Generated at 2022-06-11 09:03:47.229533
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=A') == {u'a': u'A'}
    assert parse_kv('a=A b=B') == {u'a': u'A', u'b': u'B'}
    assert parse_kv('a=A b=B c=C') == {u'a': u'A', u'b': u'B', u'c': u'C'}
    assert parse_kv('a=A,b=B,c=C') == {u'a': u'A', u'b': u'B', u'c': u'C'}
    assert parse_kv('a="A",b="B",c="C"') == {u'a': u'A', u'b': u'B', u'c': u'C'}

# Generated at 2022-06-11 09:03:49.421111
# Unit test for function parse_kv
def test_parse_kv():
    pass  # (todo)


# Generated at 2022-06-11 09:03:56.035207
# Unit test for function split_args

# Generated at 2022-06-11 09:04:03.784288
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv("a=a b=b'b c=\"c\\\"\" t='1 2 3' f=4,5,6 d=yes e=True f=on q='' r=\"\" s= s2=\" \" s3=\\\\")
    assert result['a'] == 'a'
    assert result['b'] == "b'b"
    assert result['c'] == 'c"'
    assert result['t'] == '1 2 3'
    assert result['f'] == '4,5,6'
    assert result['d'] == 'yes'
    assert result['e'] == 'True'
    assert result['f'] == 'on'
    assert result['q'] == ''
    assert result['r'] == ''
    assert result['s'] == ''
    assert result['s2'] == " "
    assert result