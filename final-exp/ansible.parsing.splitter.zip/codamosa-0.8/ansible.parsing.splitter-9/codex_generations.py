

# Generated at 2022-06-11 08:54:25.757991
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k=v foo=bar') == dict(k='v',foo='bar')
    assert parse_kv('k=v foo=bar', check_raw=True) == dict(k='v',foo='bar')

    assert parse_kv('k=v foo=bar raw') == dict(k='v',foo='bar')
    assert parse_kv('k=v foo=bar raw', check_raw=True) == dict(k='v',foo='bar',_raw_params='raw')

    assert parse_kv('k=v foo=bar raw1 raw2') == dict(k='v',foo='bar')

# Generated at 2022-06-11 08:54:30.338081
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('foo bar') == ['foo', 'bar']
    assert split_args('foo \\\nbar') == ['foo', 'bar']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo "\\"bar\\" \\\\\\"baz\\""') == ['foo', '"\\"bar\\" \\\\\\"baz\\""']
    assert split_args('foo "\\\\"bar\\\\" \\\\\\\\"baz\\\\""') == ['foo', '"\\\\"bar\\\\" \\\\\\\\"baz\\\\""']

# Generated at 2022-06-11 08:54:35.197344
# Unit test for function split_args

# Generated at 2022-06-11 08:54:40.264650
# Unit test for function split_args
def test_split_args():
    assert split_args(r"""{{foo}} {{bar}}""") == ["{{foo}}", "{{bar}}"]
    assert split_args(r"""{{foo}}
    {{bar}}""") == ["{{foo}}", "{{bar}}"]
    assert split_args(r"""{{foo}} {{bar}}\
    {{baz}}""") == ["{{foo}}", "{{bar}}", "{{baz}}"]
    assert split_args(r"""{{foo}} \{{bar}}""") == ["{{foo}}", "\{{bar}}"]
    assert split_args(r"""{{foo}} \'{{bar}}""") == ["{{foo}}", "\'{{bar}}"]
    assert split_args(r"""foo='{{bar}}'""") == ["foo='{{bar}}'"]

# Generated at 2022-06-11 08:54:50.497199
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:03.131132
# Unit test for function split_args

# Generated at 2022-06-11 08:55:13.245025
# Unit test for function split_args
def test_split_args():

    args = "a={{ b }} c='d'"
    result = split_args(args)
    assert result == ['a={{ b }}', "c='d'"]

    args = 'a={{b}} c="d"'
    result = split_args(args)
    assert result == ['a={{b}}', 'c="d"']

    args = "a=\"{{'{{b}}'}}\""
    result = split_args(args)
    assert result == ["a=\"{{'{{b}}'}}\""]

    # test multiline args
    args = "a='b\nc'"
    result = split_args(args)
    assert result == ["a='b\nc'"]

    # test line continuations
    args = "a='b'\\\nc='d'"

# Generated at 2022-06-11 08:55:24.894156
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=") == ['a=b', 'c=']
    assert split_args("a=b c=d e=") == ['a=b', 'c=d', 'e=']
    assert split_args("a=b c='d e='") == ['a=b', "c='d e='"]
    assert split_args('a=b c="d e="') == ['a=b', 'c="d e="']
    assert split_args('a=b\n c=d') == ['a=b', 'c=d']
    assert split_args('a=b c=d\n e=f') == ['a=b', 'c=d', 'e=f']


# Generated at 2022-06-11 08:55:37.101523
# Unit test for function split_args
def test_split_args():

    assert split_args(u"/usr/bin/foo") == [u"/usr/bin/foo"]
    assert split_args(u"/usr/bin/foo bar") == [u"/usr/bin/foo", u"bar"]
    assert split_args(u'/usr/bin/foo\nbar') == [u'/usr/bin/foo', u'bar']
    assert split_args(u"/usr/bin/foo\nbar") == [u"/usr/bin/foo", u"bar"]
    assert split_args(u'/usr/bin/foo\\\nbar') == [u'/usr/bin/foo', u'bar']
    assert split_args(u'/usr/bin/foo bar\nbar') == [u'/usr/bin/foo', u'bar', u'bar']
    assert split_

# Generated at 2022-06-11 08:55:44.741366
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {u'foo': u'bar'}
    assert parse_kv("foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv("foo='bar\'baz'") == {u'foo': u"bar'baz"}
    assert parse_kv("foo=\"bar'baz\"") == {u'foo': u"bar'baz"}
    assert parse_kv("foo='bar\"baz'") == {u'foo': u'bar"baz'}
    assert parse_kv("foo=\"bar\"'baz'") == {u'foo': u'baz'}
    assert parse_kv("foo=bar baz") == {u'_raw_params': u"foo=bar baz"}


# Generated at 2022-06-11 08:56:10.877674
# Unit test for function parse_kv
def test_parse_kv():
    try:
        parse_kv('cmd=test param1=test1 param2="testing" param3=test3')
    except AnsibleParserError:
        assert False

    d = parse_kv('abc=1 cde=2 efg="testing 123" hij="testing 456" xyz=789')
    assert d['abc'] == '1'
    assert d['cde'] == '2'
    assert d['efg'] == 'testing 123'
    assert d['hij'] == 'testing 456'
    assert d['xyz'] == '789'

    try:
        parse_kv('abc=1 cde=2 efg="testing 123 hij="testing 456" xyz=789')
    except AnsibleParserError:
        assert True


# Generated at 2022-06-11 08:56:21.694073
# Unit test for function split_args
def test_split_args():
    '''
    Test the split_args function with a variety of inputs
    '''

    inputs = []
    expected = []

    # input with simple single parameter
    inputs.append('foo')
    expected.append(['foo'])

    # input with simple single parameter with an '='
    inputs.append('foo=bar')
    expected.append(['foo=bar'])

    # input with simple two params separated by a space
    inputs.append('foo bar')
    expected.append(['foo', 'bar'])

    # input with two params containing '='s with a space between them
    inputs.append('foo=bar bar=foo')
    expected.append(['foo=bar', 'bar=foo'])

    # input with two params with a space in one of them
    inputs.append('foo=bar baz')
    expected

# Generated at 2022-06-11 08:56:32.210878
# Unit test for function parse_kv
def test_parse_kv():
    import time
    start_time = time.time()
    print ("start Time", start_time)

# Generated at 2022-06-11 08:56:43.163884
# Unit test for function split_args
def test_split_args():
    def eq(n, xs, ys):
        if xs != ys:
            raise AssertionError("Test %d failed: got %r instead of %r" % (n, xs, ys))

    eq(1, split_args('a=b'), ['a=b'])
    eq(2, split_args('a="b c"'), ['a="b c"'])
    eq(3, split_args('a="b c d"'), ['a="b c d"'])
    eq(4, split_args('a="b c d" e=f'), ['a="b c d"', 'e=f'])
    eq(5, split_args('a="b c" e="f g"'), ['a="b c"', 'e="f g"'])

# Generated at 2022-06-11 08:56:52.648260
# Unit test for function split_args
def test_split_args():
    # If a newline is included in the string, then it should be included in the returned list of params
    # The newline should be part of the last param in the list
    assert split_args("a=b\nfoo=bar") == ["a=b\nfoo=bar"]
    # A space should be part of the last param in the list
    assert split_args("a=b foo=bar") == ["a=b foo=bar"]
    # A backslash followed by a newline should be ignored
    assert split_args("a=b\\\nfoo=bar") == ["a=bfoo=bar"]
    # If a newline is included in a quoted string, then it should be included in the quoted string

# Generated at 2022-06-11 08:56:59.058060
# Unit test for function split_args

# Generated at 2022-06-11 08:57:08.594695
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1") == {"a": "1"}
    assert parse_kv("a=1 b=hello world") == {"a": "1", "b": "hello world"}
    assert parse_kv("a=1 b = hello world") == {"a": "1", "b ": "hello world"}
    assert parse_kv("a=1 b =hello world") == {"a": "1", "b ": "hello world"}
    assert parse_kv("a=1 b= hello world") == {"a": "1", "b": "hello world"}
    assert parse_kv("a=1 b= hello") == {"a": "1", "b": "hello"}
    assert parse_kv("a=1 b=hello") == {"a": "1", "b": "hello"}

# Generated at 2022-06-11 08:57:18.511272
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(r'a=b') == {'a': 'b'}
    assert parse_kv(r'a="b b"') == {'a': '"b b"'}
    assert parse_kv(r'a="\""') == {'a': '"\\"'}
    assert parse_kv(r'a=b "c d"') == {'a': 'b', '_raw_params': r'"c d"'}
    assert parse_kv(r'a=b "c\\" d"') == {'a': 'b', '_raw_params': r'"c\" d"'}
    assert parse_kv(r'a=b "c\\\\" d') == {'a': 'b', '_raw_params': r'"c\\" d'}
    assert parse_

# Generated at 2022-06-11 08:57:27.443455
# Unit test for function split_args

# Generated at 2022-06-11 08:57:36.136237
# Unit test for function split_args
def test_split_args():
    params = ['foo="bar baz"', 'goo="bar\\" baz"', 'hoo="bar\n baz"', '{"foo": "bar"}', 'oo="bar \' baz"', 'boo="bar \\\" baz"', '{% if 1 %}2{% endif %}', '{# foo #}', 'foo="bar\nbaz"', 'foo=a\\b', 'foo="bar\\nbaz"', 'spam="eggs\n=foo"', 'foo', 'bar']

# Generated at 2022-06-11 08:57:53.383852
# Unit test for function parse_kv
def test_parse_kv():
    def is_empty(d):
        return len(d.items()) == 0

    s = 'a=b c="with spaces" d="and = signs"'
    assert parse_kv(s) == dict(a='b', c='with spaces', d='and = signs')

    assert is_empty(parse_kv(None))

    s = 'a= escapes\=asdf'
    assert parse_kv(s) == dict(a='escapes=asdf')

    s = 'a=blah "b = c" "d=e f" g="h"'
    assert parse_kv(s) == dict(a='blah', b='=', c='', d='e', f='', g='h')



# Generated at 2022-06-11 08:58:02.930344
# Unit test for function split_args
def test_split_args():
    '''
    Test that split_args() correctly splits a string into a list of arguments
    :return:
    '''
    print('####')

    def check(str1, str2):
        print ('Start: {0}'.format(str1))
        print ('Expected: {0}'.format(str2))
        print ('Got: {0}'.format(split_args(str1)))
        print ('-----------------')

    # Empty string
    check('', [''])
    # String with spaces
    check(' ', [' '])
    # String with spaces and text
    check(' ', [' '])
    # String with spaces
    check('  ', ['  '])
    # String with spaces
    check('   ', ['   '])
    # String with spaces and text
    check('abc', ['abc'])
    #

# Generated at 2022-06-11 08:58:13.643257
# Unit test for function split_args
def test_split_args():
    """
    Simple unit test for function split_args(args)
    """
    print("Testing split_args()...")
    test_1 = "one 'two three'\nfour=5 six=seven"
    test_2 = "a='foo \"bar\"' b='foo\nbar' {c}"
    test_3 = "{% block foo %}{{ bar }} {{ baz }}\n{{ qux }}\n"
    test_4 = "a='{{ foo }}'\n{% if bar == 'baz' %}b='3'{% endif %}"
    test_5 = "{% if a = b %}true{% endif %} !false"
    test_6 = "a='{{ foo }}'"

# Generated at 2022-06-11 08:58:18.776675
# Unit test for function split_args
def test_split_args():
    '''
    We need to unit test this function to make sure that we don't have to
    rewrite it in the future if bugs are found or new functionality is needed.
    Doing this by hand is extremely difficult as it gets very hard
    to determine exactly where whitespace was split.

    Instead this will test a bunch of different argument cases to make sure
    the output of this function is what we'd expect
    '''

    # this is a list of tuples, with each tuple containing the input string
    # and the expected result from the function

# Generated at 2022-06-11 08:58:27.365463
# Unit test for function parse_kv
def test_parse_kv():
    import json
    import pytest
    kv = '''a=1 b="2" "c=three = one =" gotcha=\'four=four\' 'quoted="with equals"
    five = 5 escaped=\\"quoted\\" escaped2=\\'quoted\\'
    escaped3=\\\\"quoted\\\\" octal=\\001' 'octal2=\\056 hello=world
    '''

    kv_result = parse_kv(kv)
    print(json.dumps(kv_result))
    assert 'a' in kv_result
    assert 'b' in kv_result
    assert 'c' in kv_result
    assert 'gotcha' in kv_result
    assert 'quoted' in kv_result
    assert 'octal' in kv_result
   

# Generated at 2022-06-11 08:58:33.272883
# Unit test for function split_args

# Generated at 2022-06-11 08:58:44.446132
# Unit test for function split_args

# Generated at 2022-06-11 08:58:54.520626
# Unit test for function split_args

# Generated at 2022-06-11 08:59:04.132630
# Unit test for function split_args
def test_split_args():
    # Test normal case
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Test no options
    assert split_args('') == []

    # Test jinja2 blocks
    assert split_args('{{ foo }}') == ['{{ foo }}']
    assert split_args('{% foo %}') == ['{% foo %}']
    assert split_args('{# foo #}') == ['{# foo #}']
    assert split_args('{% foo %} {{ bar }} {# biz #}') == ['{% foo %}', '{{ bar }}', '{# biz #}']

    # Test quotes
    assert split_args('"foo bar"') == ['"foo bar"']

# Generated at 2022-06-11 08:59:16.288864
# Unit test for function parse_kv
def test_parse_kv():
    parsed = parse_kv(u'"foo"=bar baz=blurp')
    assert (u'foo' in parsed) and (parsed[u'foo'] == u'bar')
    assert (u'baz' in parsed) and (parsed[u'baz'] == u'blurp')

    parsed = parse_kv(u'"foo"=b\'ar baz=blurp')
    assert (u'foo' in parsed) and (parsed[u'foo'] == u'b\'ar')
    assert (u'baz' in parsed) and (parsed[u'baz'] == u'blurp')

    parsed = parse_kv(u'"foo"="bar" baz=blurp')

# Generated at 2022-06-11 08:59:34.245524
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"key=value") == {u"key": u"value"}
    assert parse_kv(u"key=value other key=val") == {
        u"key": u"value",
        u"other": u"key=val",
    }
    assert parse_kv(u"singlequoted='single quoted'") == {
        u"singlequoted": u"single quoted",
    }
    assert parse_kv(u"doublequoted=\"double quoted\"") == {
        u"doublequoted": u"double quoted",
    }
    assert parse_kv(u"slashed\\=equals=value") == {
        u"slashed=equals": u"value",
    }

# Generated at 2022-06-11 08:59:44.536547
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for function parse_kv
    '''
    # github issue #12240
    result = parse_kv("a=b c=d e=f g=h")
    assert result == dict(a='b', c='d', e='f', g='h')

    # github issue #14288
    result = parse_kv("state=present name='{\"key\": \"value\"}'")
    assert result == dict(state='present', name='{"key": "value"}')

    result = parse_kv("name='{\"key': \"value\"}'")
    assert result == dict(name='{"key": "value"}')

    result = parse_kv("name='{\"key\": \"value\"}' state=present")

# Generated at 2022-06-11 08:59:49.825631
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('arg1="value1" arg2="escaped \\"test\\"" arg3="non-escaped \\"test\\"" arg4=test') == {'arg1': 'value1', 'arg2': 'escaped "test"', 'arg4': 'test', 'arg3': 'non-escaped "test"', '_raw_params': 'arg1="value1" arg2="escaped \\"test\\"" arg3="non-escaped \\"test\\"" arg4=test'}




# Generated at 2022-06-11 08:59:58.888004
# Unit test for function parse_kv
def test_parse_kv():
    orig_str = r"creates=/etc/ssh/sshd_config removes=/etc/ssh/sshd_config.bak selinux_role=role_t selinux_type=sshd_config_t path=/etc/ssh/sshd_config state=present owner=root group=root mode=0600"
    kv_dict = parse_kv(orig_str)
    assert(kv_dict['creates'] == '/etc/ssh/sshd_config')
    assert(kv_dict['removes'] == '/etc/ssh/sshd_config.bak')
    assert(kv_dict['selinux_type'] == 'sshd_config_t')
    assert(kv_dict['selinux_role'] == 'role_t')

# Generated at 2022-06-11 09:00:09.147060
# Unit test for function split_args

# Generated at 2022-06-11 09:00:14.763556
# Unit test for function split_args
def test_split_args():
    ''' Check function split_args '''

    def call(args):
        ''' Test helper to invoke method, always include location info. '''
        return split_args(args)

    # Test

# Generated at 2022-06-11 09:00:20.630420
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('x=1 y=2') == {'x': '1', 'y': '2'}
    assert parse_kv('x=1 "y =bar"') == {'x': '1', 'y =bar': None}
    assert parse_kv(u'x=1 "y =bar"') == {'x': '1', 'y =bar': None}
    assert parse_kv(u'x=1 "y=bar"') == {'x': '1', u'y=bar': None}



# Generated at 2022-06-11 09:00:31.171023
# Unit test for function parse_kv
def test_parse_kv():
    # Test basics
    assert parse_kv('key1=val1 key2=val2 key3=val3') == {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3"
    }
    assert parse_kv('key1=val1   key2=val2   key3=val3') == {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3"
    }
    assert parse_kv('key1=val1\n  key2=val2\nkey3=val3') == {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3"
    }

# Generated at 2022-06-11 09:00:40.204749
# Unit test for function parse_kv
def test_parse_kv():
    # parse_kv(args, check_raw=False)
    print('test_parse_kv()')
    import os
    import json
    import requests
    def get_json(url):
        r = requests.get(url)
        if r.status_code != 200:
            return None
        return json.loads(r.text)
    def get_test(test_id):
        return get_json('http://play.golang.org/api/share/%s' % test_id)['query']
    def get_cases():
        rsp = get_json('http://play.golang.org/api/share/list')
        if rsp is None:
            return None

# Generated at 2022-06-11 09:00:52.767566
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Unit test for function parse_kv.
    '''
    assert parse_kv("a=1 b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1 b=2 c") == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv("a=1 b=2 c= d") == {'a': '1', 'b': '2', 'c': '', '_raw_params': 'd'}
    assert parse_kv("a=1 b=2 c=") == {'a': '1', 'b': '2', 'c': ''}
    assert parse_kv("") == {}

# Generated at 2022-06-11 09:01:08.736893
# Unit test for function split_args

# Generated at 2022-06-11 09:01:17.184345
# Unit test for function split_args
def test_split_args():
    import pytest
    my_args = '''
    "my var=foo"
    my var2=bar
    # my comment
    myvar3=baz
    '''
    my_results = ['my var="foo"', 'my var2=bar', '# my comment', 'myvar3=baz']

    # Arrange
    # Act
    my_result = split_args(my_args)
    # Assert
    assert(my_result == my_results)


# Generated at 2022-06-11 09:01:24.306848
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=c d=d') == dict(a='b', c='c', d='d')
    assert parse_kv('a=b c=c d=d , e=f') == dict(a='b', c='c', d='d , e=f')
    assert parse_kv("""a=b c=c 'd=d , e=f'""") == dict(a='b', c='c', d="d , e=f")
    assert parse_kv("""a=b c=c 'd=d , e=f' , g=h""") == dict(a='b', c='c', d="d , e=f" , g='h')

# Generated at 2022-06-11 09:01:35.589262
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=v"alue') == {u'key': u'v"alue'}
    assert parse_kv('key=value') == {u'key': u'value'}
    assert parse_kv('key=value ') == {u'key': u'value'}
    assert parse_kv(' key = value ') == {u'key': u'value'}
    assert parse_kv(' key= value ') == {u'key': u'value'}
    assert parse_kv(' key1= value1 key2= value2 ') == {u'key1': u'value1', u'key2': u'value2'}

# Generated at 2022-06-11 09:01:45.466419
# Unit test for function parse_kv
def test_parse_kv():
    # Valid input
    assert parse_kv("a=b") == {u'a': u'b'}
    assert parse_kv("a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d                                                                                  ") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("  a=b c=d") == {u'a': u'b', u'c': u'd'}
    assert parse_kv("a=b c=d ") == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-11 09:01:52.146980
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {"foo":"bar"}
    assert parse_kv('foo="bar=blip"') == {"foo":"bar=blip"}
    assert parse_kv('foo="bar=blip" biz=blam') == {"foo":"bar=blip","biz":"blam"}
    assert parse_kv('foo="bar=blip biz=blam"') == {"foo":"bar=blip biz=blam"}
    assert parse_kv('foo="bar blip" biz=blam') == {"foo":"bar blip","biz":"blam"}
    assert parse_kv('foo=bar biz=blam') == {"foo":"bar","biz":"blam"}

# Generated at 2022-06-11 09:02:01.025151
# Unit test for function parse_kv
def test_parse_kv():
    import sys
    import json
    if len(sys.argv) != 3:
        print("Usage: ./parse_kv-test.py <option_string> <expected_output_json>")
        sys.exit(-1)

    input_string = sys.argv[1]
    expected_output_json = sys.argv[2]
    test_output = parse_kv(input_string, check_raw=True)
    test_output_json = json.dumps(test_output)
    if test_output_json == expected_output_json:
        print("{} => {}: pass".format(input_string, test_output_json))
        sys.exit(0)
    else:
        print("{} => {}: fail".format(input_string, test_output_json))

# Generated at 2022-06-11 09:02:11.288771
# Unit test for function parse_kv
def test_parse_kv():
    # Test #1: Unquoted values
    args = "a=b c='d e' f=\"g h\""
    expected = {
        'a': 'b',
        'c': "d e",
        'f': "g h",
    }

    actual = parse_kv(args)
    assert expected == actual

    # Test #2: Quoted values
    args = "a=\"b\" c=\"d e\" f=\'g h\'"
    actual = parse_kv(args)
    assert expected == actual

    # Test #3: Quoted values with shell special characters
    args = "a=\"b=c*d\" c=\"d e$f\" f=\'g h\"i\'"
    expected['a'] = 'b=c*d'
    expected['c'] = 'd e$f'


# Generated at 2022-06-11 09:02:21.433092
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'') == {}
    assert parse_kv(u'a=1') == {u'a': u'1'}
    assert parse_kv(u'a=1 b=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv(u'a=b=c d=e f=g') == {u'a': u'b=c', u'd': u'e', u'f': u'g'}
    assert parse_kv(u'this\ that') == {u'_raw_params': u'this\ that'}

# Generated at 2022-06-11 09:02:30.774604
# Unit test for function parse_kv

# Generated at 2022-06-11 09:02:49.769624
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c') == {'a': 'b c'}
    assert parse_kv('a=b c ') == {'a': 'b c'}
    assert parse_kv('a=b  c') == {'a': 'b c'}
    assert parse_kv('a=b  c ') == {'a': 'b c'}
    assert parse_kv(' a=b  c ') == {'a': 'b c'}
    assert parse_kv(' a=b  c ') == {'a': 'b c'}
    assert parse_kv(' a=b  c ') == {'a': 'b c'}

# Generated at 2022-06-11 09:03:01.020901
# Unit test for function parse_kv
def test_parse_kv():
    # test with a quote in the value.
    options = parse_kv({u'arg1=foo arg2=bar arg3=reboot\\\'s'})
    assert options == {u'arg1': u'foo', u'arg2': u'bar', u'arg3': u"reboot's", u'_raw_params': u'arg1=foo arg2=bar arg3=reboot\\\'s'}
    # test without a quote in the value
    options = parse_kv({u'arg1=foo arg2=bar'})
    assert options == {u'arg1': u'foo', u'arg2': u'bar', u'_raw_params': u'arg1=foo arg2=bar'}
    # test with a space after =

# Generated at 2022-06-11 09:03:08.230743
# Unit test for function parse_kv
def test_parse_kv():
    test1 = "These are some \"key\"='value pairs' with a 'quoted arg' that has spaces=with values"
    test2 = 'creates=/some/file \"some key\"=some_value removes=/some/file'
    test3 = 'chdir=/some/dir \"more keys\"=more_values'
    test4 = 'creates=/some/file \"some key\"=some_value removes=/some/file chdir=/some/dir \"more keys\"=more_values'
    test5 = 'echo "This is some = test"'
    test6 = 'echo "This is some \\" = test"'
    test7 = 'param1=val1 param2=val2 executes=command with spaces'
    test8 = "param1=val1 param2=val2 executes=command \\ with \\ spaces"

# Generated at 2022-06-11 09:03:19.198343
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k=v', check_raw=False) == {u'k': u'v'}
    assert parse_kv('\\=k=v', check_raw=False) == {u'=k': u'v'}
    assert parse_kv('k\\=v', check_raw=False) == {u'k=v': u''}
    assert parse_kv('k=v arg1 arg2', check_raw=False) == \
           {u'_raw_params': u'arg1 arg2', u'k': u'v'}
    assert parse_kv('arg1 arg2 k=v', check_raw=False) == \
           {u'_raw_params': u'arg1 arg2', u'k': u'v'}

# Generated at 2022-06-11 09:03:29.566477
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv("") == {}
    assert parse_kv("a=1") == {u'a': u'1'}
    assert parse_kv("a=1 b=2") == {u'a': u'1', u'b': u'2'}
    assert parse_kv("a=1 b=2 c=3") == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv("a=1 b=2 c=3 d=4") == {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4'}

# Generated at 2022-06-11 09:03:37.896978
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b c=d e=f") == dict(a='b', c='d', e='f')
    assert parse_kv("a='b c= d' e=f") == dict(a='b c= d', e='f')
    assert parse_kv('a="b\\" c= d" e=f') == dict(a='b" c= d', e='f')
    assert parse_kv("a='b c= d' e=f z=''") == dict(a='b c= d', e='f', z='')
    assert parse_kv("a='b c= d' e=f z='' bar") == dict(a='b c= d', e='f', z='', _raw_params='bar')

    # Triple quote test
    parsed = parse

# Generated at 2022-06-11 09:03:50.090036
# Unit test for function parse_kv
def test_parse_kv():
    args = parse_kv('x=1 y=2 z=3')
    assert args == {'x': '1', 'y': '2', 'z': '3'}

    args = parse_kv('x=1 y = 2 z= 3')
    assert args == {'x': '1', 'y': '2', 'z': '3'}

    args = parse_kv('x=1 y=2 z= 3')
    assert args == {'x': '1', 'y': '2', 'z': '3'}

    args = parse_kv('x = 1 y = 2 z = 3')
    assert args == {'x': '1', 'y': '2', 'z': '3'}

    args = parse_kv('x = 1 y = 2 z = 3')

# Generated at 2022-06-11 09:03:57.489779
# Unit test for function parse_kv
def test_parse_kv():
    args = 'foo=bar baz=quux'
    options = parse_kv(args)

    assert len(options) == 2
    assert options[u'foo'] == u'bar'
    assert options[u'baz'] == u'quux'
    assert '_raw_params' not in options

    args = 'foo=\'' + ' '.join(('bar;',
                                'bar;',
                                'bar;',
                                'bar',
                                )) + '\''
    options = parse_kv(args)

    assert len(options) == 1
    assert options[u'foo'] == u'\'bar;bar;bar;bar\''
