

# Generated at 2022-06-11 08:54:25.328389
# Unit test for function split_args
def test_split_args():
    my_arguments = ['a=b', 'c="foo bar"', 'd="foo\\"bar"']
    assert split_args('\n'.join(my_arguments)) == my_arguments

    my_arguments = ['foo=bar_with_underscores', '123=456', 'foo="with spaces"']
    assert split_args(u' '.join(my_arguments)) == my_arguments

    my_arguments = [u'one', u'\\\n', u'two']
    assert split_args(' '.join(my_arguments)) == [u'one two']

    my_arguments = [u'a="b c"']
    assert split_args(u' '.join(my_arguments)) == my_arguments


# Generated at 2022-06-11 08:54:34.608974
# Unit test for function parse_kv
def test_parse_kv():
    string1 = 'keyA=val1 keyB=val2 "keyC=foo bar" keyD=\'foo bar\''
    result1 = {'keyD': 'foo bar', 'keyB': 'val2', 'keyA': 'val1', 
               'keyC': 'foo bar', '_raw_params': 'keyA=val1 keyB=val2 keyD=\'foo bar\''}
    assert parse_kv(string1) == result1

    string2 = 'keyA=val1 keyB=val2 "keyC=foo\=bar" keyD=\'foo\=bar\''

# Generated at 2022-06-11 08:54:39.659339
# Unit test for function split_args
def test_split_args():
    from ansible.utils import module_docs

    # a list of tuples, each tuple containing the args to test and the
    # expected result of the function

# Generated at 2022-06-11 08:54:44.579572
# Unit test for function split_args
def test_split_args():
    ''' Test split_args() '''
    print("testing split_args()")

# Generated at 2022-06-11 08:54:53.508055
# Unit test for function split_args
def test_split_args():
    # Test for the general case of
    # 1. jinja2 block
    # 2. quotes
    # 3. whitespaces
    # 4. line continuation
    test_cases = [
        'a b c d e f g',
        'a {% b %} c d "e f" g',
        'a {{ b }} c d "e f" g',
        'a {# b #} c d "e f" g',
        'a b c d e f g \\',
        'a b c d e f g \\ '
    ]
    for test_case in test_cases:
        print('test_case: {0}'.format(test_case))
        print(split_args(test_case))


if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 08:55:06.141695
# Unit test for function parse_kv
def test_parse_kv():
    # Function "parse_kv" must return a dict.
    import json
    assert type(parse_kv("{path}/myhost.example.com")) == type({})

    # Function parse_kv must return the same result as the in-line python
    # function.
    args = "key1=value1 key2=value2 key3='{{value3}}'"
    options = {}
    vargs = split_args(args)
    raw_params = []
    for orig_x in vargs:
        x = _decode_escapes(orig_x)
        if "=" in x:
            pos = 0

# Generated at 2022-06-11 08:55:15.183981
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1,b=2") == {'a': '1', 'b': '2'}
    assert parse_kv("a=1,b=2,ignoreme") == {'a': '1', 'b': '2', '_raw_params': 'ignoreme'}
    assert parse_kv("a=1,b=2,ignoreme", check_raw=False) == {'a': '1', 'b': '2'}
    assert parse_kv("a=1,b=2,ignoreme", check_raw=True) == {'a': '1', 'b': '2', '_raw_params': 'ignoreme'}
    assert parse_kv("a='a b'") == {'a': "'a b'"}

# Generated at 2022-06-11 08:55:26.791436
# Unit test for function parse_kv
def test_parse_kv():
    import unittest
    options = parse_kv('creates=/tmp/foo executable=/bin/bash removes=/tmp/bar')
    assert options == {'creates': '/tmp/foo', 'executable': '/bin/bash', 'removes': '/tmp/bar'}, options
    options = parse_kv('arg1=val1 arg2="arg two" arg3=val3')
    assert options == {'arg1': 'val1', 'arg2': 'arg two', 'arg3': 'val3'}, options
    options = parse_kv('arg1=val1 arg2="arg two" arg3=val3', check_raw=True)

# Generated at 2022-06-11 08:55:38.841909
# Unit test for function split_args
def test_split_args():
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']
    assert split_args('"foo bar"') == ['"foo bar"']
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo bar="baz qux"') == ['foo', 'bar=baz qux']
    assert split_args('foo bar="baz') == ['foo', 'bar="baz']
    assert split_args('bar=baz') == ['bar=baz']
    assert split_args('bar="baz') == ['bar="baz']
    assert split_args('bar="baz"') == ['bar=baz']

# Generated at 2022-06-11 08:55:48.352032
# Unit test for function parse_kv
def test_parse_kv():
    # key with =
    k = u'src=/tmp/abc=123/file.tar.gz'
    # value with =
    v = u'a=b /tmp/abc=123/file.tar.gz'
    # key with space
    ks = u'src /tmp/abc=123/file.tar.gz'
    # value with space
    vs = u'a b /tmp/abc=123/file.tar.gz'
    # key with = and space
    kvs = u'src /tmp/abc=123/file.tar.gz=test'
    # value with = and space
    vvs = u'a b /tmp/abc=123/file.tar.gz=test'

    # parsed dict should be:
    expected_dict = dict()

# Generated at 2022-06-11 08:56:29.927092
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 c=3") == { u'a': '1', u'b': '2', u'c': '3' }
    assert parse_kv("a=1 b=2 c=3 d") == { u'a': '1', u'b': '2', u'c': '3', u'_raw_params': 'd' }
    assert parse_kv("a=1 b=2 \"c=3 d\"") == { u'a': '1', u'b': '2', u'c': '3 d' }
    assert parse_kv("a=1 b=2 \"c=3 d\" e") == { u'a': '1', u'b': '2', u'c': '3 d', u'_raw_params': 'e' }
   

# Generated at 2022-06-11 08:56:36.471765
# Unit test for function split_args
def test_split_args():
    '''
    Test for different edge cases to cover the full code path
    '''
    # Test for edge case where we have a single quoted string
    assert split_args(u"foo='bar'") == [u"foo='bar'"]

    # Test for edge case where we have two quoted strings with no spaces between
    assert split_args(u"foo='bar'baz='qux'") == [u"foo='bar'baz='qux'"]

    # Test for edge case where we have two quoted strings with spaces between
    assert split_args(u"foo='bar' baz='qux'") == [u"foo='bar'", u"baz='qux'"]

    # Test for edge case where we have two quoted strings with spaces between and a space at the end

# Generated at 2022-06-11 08:56:45.008181
# Unit test for function split_args
def test_split_args():
    # Test spliting on spaces
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', 'c=\'foo bar\'']
    assert split_args('a=b c=\'foo\nbar\'') == ['a=b', 'c=\'foo\nbar\'']
    assert split_args('a=b c=\'foo\\\nbar\'') == ['a=b', 'c=\'foo\\\nbar\'']
    assert split_args('a=b c=\'foo\\\'\nbar\'') == ['a=b', 'c=\'foo\\\'\nbar\'']
    # Test splitting on newlines
    assert split_

# Generated at 2022-06-11 08:56:54.763730
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:02.672952
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils._text import to_text


# Generated at 2022-06-11 08:57:12.519618
# Unit test for function split_args

# Generated at 2022-06-11 08:57:22.120921
# Unit test for function split_args

# Generated at 2022-06-11 08:57:31.074229
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("test=test") == {'test': "test"}
    assert parse_kv("test=test one=two three=four") == {'test': "test", 'one': "two", 'three': "four"}
    assert parse_kv("test=test one=two three=four five") == {'test': "test", 'one': "two", 'three': "four", '_raw_params': "five"}
    assert parse_kv("test='test one=two' three=four") == {'test': "test one=two", 'three': "four"}
    assert parse_kv("test='test one=two three=four'") == {'test': "test one=two three=four"}

# Generated at 2022-06-11 08:57:39.542672
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('arg1=\"foo\" arg2=\\\"bar\\\"') == {u'arg1': u'foo', u'arg2': u'"bar"'}
    assert parse_kv('arg1=\"foo\" arg2=\"bar\" arg3=baz') == {u'arg1': u'foo', u'arg2': u'bar', u'arg3': u'baz'}
    assert parse_kv('arg1=\"foo\" arg2=\"bar\" arg3=baz arg4') == {u'arg1': u'foo', u'arg2': u'bar', u'arg3': u'baz', u'_raw_params': u'arg4'}

# Generated at 2022-06-11 08:57:48.497452
# Unit test for function split_args
def test_split_args():
    result = split_args("ls {{ foo }} \"{{ bar }}\" '{{ baz }}'")
    assert(result[0] == 'ls')
    assert(result[1] == '{{ foo }}')
    assert(result[2] == '"{{ bar }}"')
    assert(result[3] == "'{{ baz }}'")
    try:
        split_args("{{ foo }")
        assert False, "Jinja2 block without end didn't fail"
    except Exception as e:
        assert str(e).startswith("failed at splitting arguments"), "Incorrect exception on unbalanced Jinja2 block: " + str(e)

    result = split_args("ls {{ foo }} \"{{ bar }}\" '{{ baz }}' ")
    assert(result[0] == 'ls')

# Generated at 2022-06-11 08:58:15.595232
# Unit test for function split_args
def test_split_args():
    import unittest
    import mock

    class TestSplitArgs(unittest.TestCase):
        def test_split_args_normal(self):
            test_string = "cat foo.txt /tmp/bar.txt"
            expected_return = ['cat', 'foo.txt', '/tmp/bar.txt']
            self.assertEqual(split_args(test_string), expected_return)

        def test_split_args_newlines(self):
            test_string = "cat foo.txt \\\n/tmp/bar.txt"
            expected_return = ['cat', 'foo.txt', '/tmp/bar.txt']
            self.assertEqual(split_args(test_string), expected_return)


# Generated at 2022-06-11 08:58:24.633225
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar baz=foo') == {u'foo': u'bar', u'baz': u'foo'}
    assert parse_kv('foo=bar baz=foo', check_raw=True) == {u'foo': u'bar', u'baz': u'foo'}
    assert parse_kv('foo=bar baz=foo qux=foo', check_raw=True) == {u'foo': u'bar', u'baz': u'foo', u'_raw_params': u'qux=foo'}

# Generated at 2022-06-11 08:58:30.188776
# Unit test for function split_args

# Generated at 2022-06-11 08:58:38.517660
# Unit test for function split_args

# Generated at 2022-06-11 08:58:50.294361
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'arg1=val1') == {u'arg1': u'val1'}
    assert parse_kv(u'arg1="val1"') == {u'arg1': u'val1'}
    assert parse_kv(u'arg1=val1 arg2=val2') == {u'arg1': u'val1', u'arg2': u'val2'}
    assert parse_kv(u'arg1=val1 arg2="val2 test"') == {u'arg1': u'val1', u'arg2': u'val2 test'}

# Generated at 2022-06-11 08:58:57.824832
# Unit test for function split_args

# Generated at 2022-06-11 08:59:09.409853
# Unit test for function split_args
def test_split_args():
    def test(args, expected):
        print('Args', repr(args))
        print('Expected', repr(expected))
        got = split_args(args)
        print('Got     ', repr(got))
        if got != expected:
            print('Test failed')
            raise AssertionError
        else:
            print('Test passed')
        print('')

    test('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    test('a="foo bar" c=d', ['a="foo bar"', 'c=d'])
    test('a=b c="foo bar', ['a=b', 'c="foo bar'])
    test('a=b c=\'foo bar', ['a=b', 'c=\'foo bar'])

# Generated at 2022-06-11 08:59:20.538225
# Unit test for function parse_kv
def test_parse_kv():
    # Test empty input
    assert parse_kv(None) == {}
    assert parse_kv(u'') == {}

    # Test quoted input
    assert parse_kv(u'a=b') == {u'a': u'b'}
    assert parse_kv(u'a="b c"') == {u'a': u'b c'}
    assert parse_kv(u"a='b c'") == {u'a': u'b c'}
    assert parse_kv(u'a=b c') == {u'a': u'b', u'_raw_params': u'c'}
    assert parse_kv(u'a="b=c"') == {u'a': u'b=c'}

# Generated at 2022-06-11 08:59:26.665757
# Unit test for function split_args
def test_split_args():
    # Remove the 'pass' statement when you start implementing your test function
    #pass
    assert_equals(['a=b', 'c="foo bar"'], split_args("a=b c=\"foo bar\""))
    assert_equals(['echo', '-n', "foo bar"], split_args("echo -n \"foo bar\""))
    assert_equals(['foo bar'], split_args("\"foo bar\""))
    assert_equals(['a=b"', 'c=d'], split_args("a=b\" c=d"))
    assert_equals(['a=b\\\'', 'c=d'], split_args("a=b\\\' c=d"))

# Generated at 2022-06-11 08:59:39.476026
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic parsing
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar bam=boo') == {u'foo': u'bar', u'bam': u'boo'}
    assert parse_kv('foo=bar bam=boo=baz jaz=loo') == {u'foo': u'bar', u'bam': u'boo=baz', u'jaz': u'loo'}
    assert parse_kv('foo="bar bam"') == {u'foo': u'"bar bam"'}
    assert parse_kv('foo=\'bar bam\'') == {u'foo': u'\'bar bam\''}

    # Test escaping

# Generated at 2022-06-11 08:59:57.640158
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(None) == {}
    assert parse_kv('') == {}
    assert parse_kv('k=v') == {'k': 'v'}
    assert parse_kv(' k = v ') == {'k': 'v'}
    assert parse_kv('"k=v"') == {'k=v': ''}
    assert parse_kv('k="vv v"') == {'k': 'vv v'}
    assert parse_kv('k=v "a b"') == {'k': 'v', '_raw_params': '"a b"'}
    assert parse_kv('k=v "a b"', check_raw=True) == {'k': 'v', '_raw_params': '"a b"'}

# Generated at 2022-06-11 09:00:08.080044
# Unit test for function split_args

# Generated at 2022-06-11 09:00:16.087725
# Unit test for function split_args
def test_split_args():
    # Quotes
    assert split_args(r"a=\"b c\"") == ['a="b c"']
    assert split_args(r"a='b c'") == ["a='b c'"]
    assert split_args(r"a=b c") == ['a=b', 'c']
    assert split_args(r"a=b c d") == ['a=b', 'c', 'd']
    assert split_args(r"a=\"b c\" d") == ['a="b c"', 'd']
    assert split_args(r"a=\"b c\" d e") == ['a="b c"', 'd', 'e']
    assert split_args(r"a=\"b c\" d e f") == ['a="b c"', 'd', 'e', 'f']
    assert split_args

# Generated at 2022-06-11 09:00:25.406600
# Unit test for function parse_kv
def test_parse_kv():
    print('Testing parse_kv function')
    print(parse_kv(b"foo=bar"))
    print(parse_kv(b"foo = bar"))
    print(parse_kv(b"foo= bar"))
    print(parse_kv(b"foo =bar"))
    print(parse_kv(b"'foo'='bar'"))
    print(parse_kv(b"foo='bar bar'"))
    print(parse_kv(b'foo=None', check_raw=True))
    print(parse_kv(b'foo=bar splits "This is a test"'))
    print(parse_kv(b'foo=bar splits "This is a test"', check_raw=True))
    print(parse_kv(b"foo='bar bar' splits 'This is a test'"))

# Generated at 2022-06-11 09:00:35.282554
# Unit test for function split_args
def test_split_args():
    '''
    Test function split_args()
    '''
    result_1 = split_args('echo foo')
    assert result_1 == ['echo foo'], result_1

    result_2 = split_args('echo "foo bar"')
    assert result_2 == ['echo "foo bar"'], result_2

    result_3 = split_args('echo "foo bar" \\')
    assert result_3 == ['echo "foo bar" \\'], result_3

    result_4 = split_args('echo "foo bar" \\ \\\\nfoo')
    assert result_4 == ['echo "foo bar" \\ \\\\nfoo'], result_4

    result_5 = split_args('echo "foo bar" \\ \\\\nfoo \\')

# Generated at 2022-06-11 09:00:45.930938
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=/tmp/file1') == {'creates': '/tmp/file1'}
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('arg1=1 args="arg2=2" arg3=3') == {
        'arg1': '1', 'args': 'arg2=2', 'arg3': '3'
    }

    # The parser should ignore any args that don't contain an =
    assert parse_kv('arg1=1 arg2=2 non_arg3 non_arg4=4') == {
        'arg1': '1', 'arg2': '2', 'non_arg4': '4'
    }

    # The parser should recognize escaped = characters as values

# Generated at 2022-06-11 09:00:56.643606
# Unit test for function split_args
def test_split_args():
    assert(split_args('') == [] and split_args('a b c') == ['a', 'b', 'c'])
    assert(split_args('a "b c"') == ['a', '"b c"'])
    assert(split_args('a "b c" d') == ['a', '"b c"', 'd'])
    assert(split_args('a "b c" d "e f"') == ['a', '"b c"', 'd', '"e f"'])
    assert(split_args('a "b c" d "e f" g') == ['a', '"b c"', 'd', '"e f"', 'g'])

# Generated at 2022-06-11 09:01:08.269642
# Unit test for function split_args
def test_split_args():
    import nose.tools as nt


# Generated at 2022-06-11 09:01:19.918792
# Unit test for function split_args
def test_split_args():
    # Some simple tests, want to get more in-depth than this soon
    assert split_args('a b') == ['a', 'b']
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="b c"') == ['a="b c"']
    assert split_args('a="b \"c\" d"') == ['a="b \"c\" d"']
    assert split_args('a=b c="{{ d }} e"') == ['a=b', 'c="{{ d }} e"']
    assert split_args('a=b c="{{ d %} e"') == ['a=b', 'c="{{ d %} e"']

# Generated at 2022-06-11 09:01:25.875490
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=d") == ['a=b', 'c=d']
    assert split_args("a=b c=d e=f") == ['a=b', 'c=d', 'e=f']
    assert split_args("a={{foo}} b={{bar}} c=d") == ['a={{foo}}', 'b={{bar}}', 'c=d']
    assert split_args("a={{foo}}\nb={{bar}}\nc=d") == ['a={{foo}}\n', 'b={{bar}}\n', 'c=d']
    assert split_args("a={{foo}}\nb={{bar}}\nc=\"d e f\"") == ['a={{foo}}\n', 'b={{bar}}\n', 'c="d e f"']


# Generated at 2022-06-11 09:01:42.366631
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar', check_raw=True) == {'foo': 'bar'}
    assert parse_kv('foo="bar baz"', check_raw=True) == {'foo': 'bar baz'}
    assert parse_kv('foo=bar baz', check_raw=True) == {u'_raw_params': 'foo=bar baz'}
    assert parse_kv('foo="bar baz" spam ham') == {u'_raw_params': 'foo="bar baz" spam ham'}
    assert parse_kv('foo="bar baz" spam ham', check_raw=True) == {u'foo': u'bar baz', u'_raw_params': u'spam ham'}
    assert parse_kv('foo=bar baz="foo bar"')

# Generated at 2022-06-11 09:01:50.424862
# Unit test for function split_args
def test_split_args():
    args_list = [
        'a=b c="foo bar"',
        'a=b c=\'foo bar\'',
        'a=b c=\'foo bar\' d=\'123 456\'',
        'a=b c="foo bar" d=\'123 456\'',
        'a=b c="foo bar" d=\'123 456\' e="hello world"',
        'a=b c="foo bar" d=\'123 456\' e="hello world" f=\'html is <a href="google.com">cool</a>\'',
        'a=b c="foo bar" d=\'123 456\' e="hello world" f=\'html is <a href="google.com">cool</a>\' g=\'escape\'\''
    ]


# Generated at 2022-06-11 09:01:59.197863
# Unit test for function parse_kv
def test_parse_kv():
    print('\n[+] Running parse_kv test...')
    for arg, result in parse_kv_test_cases:
        print('[?] Testing string: {}'.format(arg))
        options = parse_kv(arg)
        assert options == result, 'Unexpected result: {}'.format(options)



# Generated at 2022-06-11 09:02:08.830453
# Unit test for function split_args

# Generated at 2022-06-11 09:02:19.758789
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test for parse_kv function
    '''
    from ansible.module_utils.basic import AnsibleModule
    import json

    # test from the actual module
    module = AnsibleModule(argument_spec=dict())
    args = module.params['argv']
    args = "param1=5 param2=6 param3=9 param4=\"'=\\\\this is a long string'\" param5='single quotes are valid too' param6={{params.param6}} param7={{params_with_braces}}"
    data = parse_kv(args)

# Generated at 2022-06-11 09:02:29.176964
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=c') == dict(a='1', b='c')
    assert parse_kv('a=1 b="c d"') == dict(a='1', b='c d')
    assert parse_kv('a b=c') == dict(a=None, b='c')
    assert parse_kv('a="c d" b=c') == dict(a='c d', b='c')
    assert parse_kv('a=b c=d') == dict(a='b', c='d')
    assert parse_kv('a=b:c=d') == dict(a='b:c=d')
    assert parse_kv('"a"="b:c=d"') == dict(a='b:c=d')

# Generated at 2022-06-11 09:02:37.081217
# Unit test for function parse_kv
def test_parse_kv():
    # Test a string that  contains a single key=value pair
    options = parse_kv('key=value')
    assert len(options.keys()) == 1
    assert options.keys()[0] == 'key'
    assert options.get('key') == 'value'

    # Test a string that contains multiple key=value pairs
    options = parse_kv('key1=value1 key2=value2')
    assert len(options.keys()) == 2
    assert options.get('key1') == 'value1'
    assert options.get('key2') == 'value2'

    # Test a string that contains a key=value pair and a parameter
    options = parse_kv('key=value param')
    assert len(options.keys()) == 2
    assert options.get('key') == 'value'
    assert options.get

# Generated at 2022-06-11 09:02:45.488377
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=1 b="a=b" c=foo d="a=b c=d"') == ['a=1', 'b="a=b"', 'c=foo', 'd="a=b c=d"']
    assert split_args('a=b c="{{ foo }}"') == ['a=b', 'c="{{ foo }}"']
    assert split_args('a="b c {{ foo }}"') == ['a="b c {{ foo }}"']
    assert split_args('a=b c="foo bar {{ foo }}"') == ['a=b', 'c="foo bar {{ foo }}"']
    assert split_args("a=b c='foo bar {{ foo }}'")

# Generated at 2022-06-11 09:02:56.094448
# Unit test for function split_args
def test_split_args():

    # Test some things that should work as expected
    assert split_args(None) == []
    assert split_args(u'') == ['']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b \\\\ c="foo bar"') == [u'a=b \\\\', u'c="foo bar"']
    assert split_args(u'a=b \\ c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u"a='b c'") == [u"a='b c'"]
    assert split_args(u'a="b c"') == [u'a="b c"']
    assert split_

# Generated at 2022-06-11 09:03:06.293095
# Unit test for function parse_kv

# Generated at 2022-06-11 09:03:24.143446
# Unit test for function parse_kv
def test_parse_kv():
    test_str = "arg1=value1 arg2='value 2' arg3=\"value 3\" arg4=value\\'4"

    test_result = parse_kv(test_str, False)

    assert type(test_result) == type(dict())

    assert len(test_result) == 4

    assert 'arg1' in test_result.keys()
    assert 'arg2' in test_result.keys()
    assert 'arg3' in test_result.keys()
    assert 'arg4' in test_result.keys()
    assert '_raw_params' not in test_result.keys()

    assert test_result['arg1'] == 'value1'
    assert test_result['arg2'] == 'value 2'
    assert test_result['arg3'] == 'value 3'

# Generated at 2022-06-11 09:03:33.435242
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('', check_raw=True) == {}
    assert parse_kv('a=b', check_raw=True) == {'a': 'b'}
    assert parse_kv('a=b c=d', check_raw=True) == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c="d" e=f', check_raw=True) == {'a': 'b', 'c': 'd', 'e': 'f'}
    assert parse_kv('a=b=c', check_raw=True) == {'a': 'b=c'}
    assert parse_kv('a=b\=c', check_raw=True) == {'a': 'b=c'}

# Generated at 2022-06-11 09:03:38.798209
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test the parse_kv function
    '''
    args = ''
    options = parse_kv(args)
    assert options == {}

    args = 'one_var=1 two_var=2 three_var'
    options = parse_kv(args)
    assert options == {u'one_var': '1', u'two_var': '2', u'_raw_params': u'three_var'}
    assert options[u'_raw_params'].split(u' ') == [u'three_var']



# Generated at 2022-06-11 09:03:43.987032
# Unit test for function split_args
def test_split_args():
    a = "{{ foo }}\n{{ bar }}"
    b = "{{ foo }} {{ bar }}"
    c = '{{ foo }}\\\n{{ bar }}'

    results = [a, b, c]
    for r in results:
        print(split_args(r))

# Generated at 2022-06-11 09:03:54.991444
# Unit test for function parse_kv

# Generated at 2022-06-11 09:04:03.035206
# Unit test for function split_args
def test_split_args():
    tests_failed = 0
    # test quoting
    # single quotes, double quotes