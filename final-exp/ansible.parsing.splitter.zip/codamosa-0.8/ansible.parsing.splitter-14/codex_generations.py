

# Generated at 2022-06-11 08:54:32.323097
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'a=b c="foo bar"') == {'a': u'b', 'c': u'foo bar'}
    assert parse_kv(u'a="foo bar" c=b') == {'a': u'foo bar', 'c': u'b'}
    assert parse_kv(u'a=b c="foo bar" d') == {'a': u'b', 'c': u'foo bar', '_raw_params': u'd'}
    assert parse_kv(u'a=b c="foo bar" d e') == {'a': u'b', 'c': u'foo bar', '_raw_params': u'd e'}

# Generated at 2022-06-11 08:54:37.231847
# Unit test for function split_args

# Generated at 2022-06-11 08:54:42.290440
# Unit test for function split_args

# Generated at 2022-06-11 08:54:47.973006
# Unit test for function split_args
def test_split_args():
    '''
    this function is a unit test for the split_args function
    '''
    from pprint import pprint
    from collections import namedtuple

    TestCase = namedtuple('TestCase', 'in_string desired_out')
    ans_cases = []
    ans_cases.append(TestCase(in_string=u"foo", desired_out=[u"foo"]))
    ans_cases.append(TestCase(in_string=u"foo bar", desired_out=[u"foo", u"bar"]))
    ans_cases.append(TestCase(in_string=u"foo 'bar baz'", desired_out=[u"foo", u"'bar baz'"]))

# Generated at 2022-06-11 08:55:00.348746
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar baz=qux') == dict(foo='bar', baz='qux')
    assert parse_kv(
        'foo="bar bar" baz=\'qux qux\'') == dict(foo='bar bar', baz='qux qux')
    assert parse_kv(
        'foo=bar_bar baz=qux_qux') == dict(foo='bar_bar', baz='qux_qux')
    assert parse_kv(
        'foo=bar-bar baz=qux-qux') == dict(foo='bar-bar', baz='qux-qux')

# Generated at 2022-06-11 08:55:11.515667
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:18.030402
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:29.852223
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(b'foo=bar arg=value') == {u'foo': u'bar', u'arg': u'value'}
    assert parse_kv(b"a='b c'") == {u'a': u'b c'}
    assert parse_kv(b"a=\"b c\"") == {u'a': u'b c'}
    assert parse_kv(b"a=b\\ c") == {u'a': u'b c'}
    assert parse_kv(b"a=b\\\\c") == {u'a': u'b\\c'}
    assert parse_kv(b"a=b\\\\\\c") == {u'a': u'b\\c'}

# Generated at 2022-06-11 08:55:37.426703
# Unit test for function parse_kv
def test_parse_kv():
    args = u"test=test1 test2=test3 test4=\"test 5\""
    print(parse_kv(args))
    args = u"test=test1 test2=test3 test4=\\\"test5\\\""
    print(parse_kv(args))

# Split args inspired by code from fabric (fabfile.org)
# https://github.com/fabric/fabric/blob/master/fabric/utils.py

# Generated at 2022-06-11 08:55:45.568307
# Unit test for function split_args
def test_split_args():
    from ansible.compat.tests.mock import patch

    with patch('ansible.module_utils.common.args.sys.argv', ["argv0", "-vvvv", "-c", "ping", "localhost", "-i", "./hosts"]):
        assert split_args('"foo bar" b="a b" c="a \" quoted string"') == ['foo bar', 'b="a b"', 'c="a \\" quoted string"']
        assert split_args(r'foo "foo bar"') == ['foo', 'foo bar']
        assert split_args(r'foo "a \' quoted string"') == ['foo', 'a \' quoted string']
        assert split_args(r'foo "a \" quoted string"') == ['foo', 'a " quoted string']

# Generated at 2022-06-11 08:56:16.327267
# Unit test for function split_args
def test_split_args():
    import random
    import string

    def randomString(stringLength=10):
        """Generate a random string of fixed length """
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(stringLength))

    def randomQuotedString(stringLength=10):
        return '"{}"'.format(randomString(stringLength))

    def randomWord(stringLength=10):
        return randomString(stringLength)

    def randomWordQuoted(stringLength=10):
        word = randomWord(stringLength)
        return f'"{randomWord(stringLength)}"'

    def randomNumber():
        return str(random.randint(0, 1000))

    def randomVariableWord():
        return f'{{{randomWord()}}}'


# Generated at 2022-06-11 08:56:27.786952
# Unit test for function split_args
def test_split_args():
    print("Testing split_args()")

    # Empty list
    assert [] == split_args("")

    # Single, simple arg
    assert ["a"] == split_args("a")

    # Multiple, simple arg
    assert ["a", "b"] == split_args("a b")

    # Multiple, simple arg, multiple spaces
    assert ["a", "b"] == split_args("a   b")

    # Multiple, simple arg, multiple newlines
    assert ["a", "b"] == split_args("a\nb")

    # String with variable
    assert ["a={{b}}"] == split_args("a={{b}}")

    # String with variable, multiple spaces
    assert ["a={{b}}"] == split_args("a={{b}}   ")

    # String with variable, multiple spaces, multiple newlines
   

# Generated at 2022-06-11 08:56:35.581417
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"a=1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv(u"a=1 b=2") == {"a": "1", "b": "2"}
    assert parse_kv(u"a=1 b=2 c=3") == {"a": "1", "b": "2", "c": "3"}
    assert parse_kv(u"a=1 b='two' c=3") == {"a": "1", "b": "two", "c": "3"}
    assert parse_kv(u"a=1 b='two, three' c=3") == {"a": "1", "b": "two, three", "c": "3"}

# Generated at 2022-06-11 08:56:44.698408
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args(u'a=b c="foo bar"') == [u'a=b', u'c="foo bar"']
    assert split_args(u'a=b c="1=2 3=4"') == [u'a=b', u'c="1=2 3=4"']
    assert split_args('a \="b c') == ['a', '\\="b', 'c']
    assert split_args('a \\=\'b c') == ['a', '\\=\'b', 'c']
    assert split_args('a \\\"="b c') == ['a', '\\"="b', 'c']

# Generated at 2022-06-11 08:56:54.549634
# Unit test for function split_args

# Generated at 2022-06-11 08:57:02.216120
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    raw = '''
    creates=/tmp/foo
    chdir=/tmp
    removes=*
    "date > /tmp/testfile.txt"
    "date > /tmp/anotherfile.txt"
    '''
    expected = {
        u'creates': u'/tmp/foo',
        u'chdir': u'/tmp',
        u'removes': u'*',
        u'_raw_params': u'''
    "date > /tmp/testfile.txt"
    "date > /tmp/anotherfile.txt"''',
    }
    vault_secret = u'12345'
    vault_password_file = VaultLib.create_vault_password_file

# Generated at 2022-06-11 08:57:12.104447
# Unit test for function parse_kv
def test_parse_kv():
    def _assert_parse_kv(args, expected):
        actual = parse_kv(args)
        assert actual == expected, "Args: %s, Expected: %s, Actual: %s" % (args, expected, actual)

    _assert_parse_kv(None, {})
    _assert_parse_kv('', {})
    _assert_parse_kv('one', {'_raw_params': 'one'})
    _assert_parse_kv('one two three four five', {'_raw_params': 'one two three four five'})
    _assert_parse_kv('one "two three" four five', {'_raw_params': 'one "two three" four five'})

# Generated at 2022-06-11 08:57:21.804200
# Unit test for function split_args
def test_split_args():
    args = 'a=b c="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"']

    args = 'a=b c="foo bar" \\'
    assert split_args(args) == ['a=b', 'c="foo bar"', '\\']

    args = 'a=b c="foo bar" \\' \
           '\nd=e f="foo bar"'
    assert split_args(args) == ['a=b', 'c="foo bar"', '\\\nd=e', 'f="foo bar"']

    args = 'a=b c="foo bar" \\' \
           '\n d=e f="foo bar"'

# Generated at 2022-06-11 08:57:30.629054
# Unit test for function split_args
def test_split_args():
    # Test parsing of regular arguments
    args = 'a=foo bar=baz'
    expected = ['a=foo', 'bar=baz']
    parsed_args = split_args(args)
    assert parsed_args == expected, "Parsing of '%s' failed, expected '%s', got '%s'" % (args, expected, parsed_args)

    # Test parsing of arguments with quotes
    args = 'a=foo bar="baz one"'
    expected = ['a=foo', 'bar="baz one"']
    parsed_args = split_args(args)
    assert parsed_args == expected, "Parsing of '%s' failed, expected '%s', got '%s'" % (args, expected, parsed_args)

    # Test parsing of arguments in jinja blocks

# Generated at 2022-06-11 08:57:39.232923
# Unit test for function parse_kv
def test_parse_kv():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    def pkv_assert(assertion, comment, input, expected_return):
        ret = parse_kv(input)

        if not isinstance(assertion, string_types):
            assertion(ret)
        elif assertion == 'is':
            assert ret == expected_return, comment
        elif assertion == 'is_a':
            assert isinstance(ret, Mapping), comment
        else:
            raise AssertionError("Unknown assertion: {0}".format(assertion))

    pkv_assert('is', 'Empty string should return empty dict', '', {})

# Generated at 2022-06-11 08:57:58.194009
# Unit test for function split_args

# Generated at 2022-06-11 08:58:08.802927
# Unit test for function parse_kv
def test_parse_kv():
    print('Test 1:')
    p = parse_kv('a=b c=d e=')
    print('Returned: %s' % p)
    print('Expected:', "{'a': 'b', 'e': '', 'c': 'd'}")
    print('Test 2:')
    p = parse_kv('''a="b=c d" e=f''')
    print('Returned: %s' % p)
    print('Expected:', "{'a': 'b=c d', 'e': 'f'}")
    print('Test 3:')
    p = parse_kv('''a="b=c d" e=f''', True)
    print('Returned: %s' % p)

# Generated at 2022-06-11 08:58:16.387503
# Unit test for function parse_kv
def test_parse_kv():
    """
    Testing parsing of key=value arguments
    """

# Generated at 2022-06-11 08:58:25.296887
# Unit test for function parse_kv
def test_parse_kv():
    import json
    # Parse a simple key=value pair
    assert parse_kv("foo=bar") == {u"foo": u"bar"}
    # Make sure that spaces around the  = sign don't matter
    assert parse_kv("foo =bar") == {u"foo": u"bar"}
    assert parse_kv("foo= bar") == {u"foo": u"bar"}
    assert parse_kv("foo = bar") == {u"foo": u"bar"}
    # Make sure multiple key values are parsed correctly
    assert parse_kv("foo=bar,baz=bar") == {u"foo": u"bar", u"baz": u"bar"}

# Generated at 2022-06-11 08:58:30.974004
# Unit test for function split_args
def test_split_args():
    '''
    Tests various sample input strings to make sure that the output
    is what we would expect.
    '''
    #
    # Formatting of this test is a list of tuples, each tuple contains the following elements
    #     1. args (string): the input string to be parsed by split_args()
    #     2. expected (list): the desired result of input_string
    #

# Generated at 2022-06-11 08:58:39.819037
# Unit test for function split_args
def test_split_args():
    """
    Test function split_args
    """
    def _test_split_args(args, expected, msg=""):
        """
        Test function split_args
        """
        result = split_args(args)
        assert result == expected, msg

    _test_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'], "Simple key/value pair")
    _test_split_args('a=b   c="foo bar"', ['a=b', 'c="foo bar"'], "Simple key/value pair with extra spaces")

# Generated at 2022-06-11 08:58:47.045482
# Unit test for function parse_kv
def test_parse_kv():
    res = parse_kv('foo=bar baz=zort')
    assert res == {u'foo': u'bar', u'_raw_params': u'baz=zort'}, res
    res = parse_kv(u'foo=bar baz=zort "foo=with spaces"')
    assert res == {u'foo': u'bar', u'_raw_params': u'"foo=with spaces"' }, res


# Generated at 2022-06-11 08:58:52.311388
# Unit test for function split_args
def test_split_args():
    import yaml

    # Tests
    test_cases = yaml.load(open(__file__.replace('.py', '.yaml')))

    def p(input, output):
        assert output == split_args(input)

    for test in test_cases['tests']:
        p(test['input'], test['output'])

if __name__ == '__main__':
    test_split_args()

# Generated at 2022-06-11 08:58:59.055968
# Unit test for function split_args
def test_split_args():
    reasons = []

    # Create a list of test cases, where each entry is a tuple consisting
    # of a string, a bool indicating whether an error is expected and the
    # expected output when no error is raised.

# Generated at 2022-06-11 08:59:11.085050
# Unit test for function split_args
def test_split_args():
    # Test with empty string
    assert split_args('') == ['']

    # Test with a simple key-value pair
    assert split_args('a=b') == ['a=b']

    # Test with a simple key-value pair with space before and after '='
    assert split_args('a = b') == ['a', '=', 'b']

    # Test with quotes around argument
    assert split_args('"a=b"') == ['"a=b"']

    # Test with quotes around argument and space before '='
    assert split_args('"a = b"') == ['"a', '=', 'b"']

    # Test with quotes around argument, space before '=', and space before and after
    assert split_args('"a = b"') == ['"a', '=', 'b"']

   

# Generated at 2022-06-11 08:59:27.516318
# Unit test for function split_args
def test_split_args():
    # Testing the happy path with no jinja2 blocks or quotation
    test_data = "foo bar=baz"
    assert split_args(test_data) == ['foo', 'bar=baz']

    # Testing a single value with spaces
    test_data = "foo bar"
    assert split_args(test_data) == ['foo bar']

    # Testing a single value with spaces in quotes
    test_data = 'foo bar'
    assert split_args(test_data) == ['foo bar']

    # Testing spaces in quotes
    test_data = 'foo "bar baz"'
    assert split_args(test_data) == ['foo', '"bar baz"']

    # Testing spaces in quotes
    test_data = "foo 'bar baz'"

# Generated at 2022-06-11 08:59:40.415072
# Unit test for function split_args
def test_split_args():
    def _test(input, expected):
        actual = split_args(input)
        print(actual)
        assert actual == expected

    _test(
        '''a=b c="foo bar"''',
        [u'a=b', u'c="foo bar"']
    )

    _test(
        '''a=b c="foo bar''',
        [u'a=b', u'c="foo bar']
    )

    _test(
        '''a=b c="foo bar''',
        [u'a=b', u'c="foo bar']
    )

    _test(
        'a=b c="foo bar"',
        [u'a=b', u'c="foo bar"']
    )


# Generated at 2022-06-11 08:59:47.545111
# Unit test for function split_args
def test_split_args():
    # test with simple args
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # test with an unterminated quoted string
    try:
        split_args('a=b c="foo')
        assert False, 'should have raised an AnsibleParserError'
    except AnsibleParserError:
        pass

    # test line continuations
    assert split_args('a=b \\ c=d') == ['a=b', 'c=d']
    assert split_args('a=b \\\\ c=d') == ['a=b', '\\\\ c=d']
    assert split_args('a=b \\\\ \n c=d') == ['a=b', '\\\\', 'c=d']

# Generated at 2022-06-11 08:59:57.143737
# Unit test for function split_args
def test_split_args():
    # Basic tests
    inp = 'a=b c="foo bar"'
    outp = ['a=b', 'c="foo bar"']
    assert split_args(inp) == outp

    inp = 'a=b "c=foo bar"'
    outp = ['a=b', '"c=foo bar"']
    assert split_args(inp) == outp

    inp = 'a=b "c=foo bar" d="foo bar"'
    outp = ['a=b', '"c=foo bar"', 'd="foo bar"']
    assert split_args(inp) == outp

    # Test no spaces
    inp = 'a=b c="foobar"'
    outp = ['a=b', 'c="foobar"']
    assert split_args(inp) == outp

    # Test with

# Generated at 2022-06-11 09:00:07.438038
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.text.converters import to_native
    # Used for this test only
    class AnsibleParserError(Exception):
        def __init__(self, message, orig_exc=None):
            self.message = message
            self.orig_exc = orig_exc

    input = """
    {{foo}} {{bar}}
    {{baz}}
    """
    params = split_args(input)
    assert params == ['{{foo}}', '{{bar}}'], "split_args() should return a list whose elements have one Jinja template, brackets and all: '{0}'".format(to_native(params))

    input = """
    {% foo %}
    {% bar %}
    """
    params = split_args(input)

# Generated at 2022-06-11 09:00:13.895185
# Unit test for function split_args
def test_split_args():
    test_cases = [
        ('a=b c="foo bar"',     ['a=b', 'c="foo bar"']),
        ('a=b c="foo bar" d="g\'h"', ['a=b', 'c="foo bar"', 'd="g\'h"']),
        ('{{j2var1}} "foo {{ j2var2 }} bar" {{j2var3}}', ['{{j2var1}}', '"foo {{ j2var2 }} bar"', '{{j2var3}}']),
        ('"foo bar',            ['"foo bar'])
    ]

    for test_case in test_cases:
        args, expected_result = test_case
        result = split_args(args)

# Generated at 2022-06-11 09:00:22.955539
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b') == {u'a': u'b'}
    assert parse_kv('a=1') == {u'a': u'1'}

    assert parse_kv('a=b c=d') == {u'c': u'd', u'a': u'b'}
    assert parse_kv('a=b c=d e=f') == {u'c': u'd', u'e': u'f', u'a': u'b'}
    assert parse_kv('a="b c" d="e f"') == {u'd': u'e f', u'a': u'b c'}

# Generated at 2022-06-11 09:00:33.080872
# Unit test for function split_args
def test_split_args():
    result = split_args('foo bar "this is a test"')
    assert result == [u'foo', u'bar', u'"this is a test"']
    result = split_args('foo bar "this is a test')
    try:
        assert False
    except AnsibleParserError as e:
        assert 'unbalanced jinja2 block or quotes' in to_native(e)
    result = join_args(result)
    assert result == 'foo bar "this is a test"'
    result = split_args('foo bar "this is a test\\\\"')
    assert result == [u'foo', u'bar', u'"this is a test\\\\"']
    result = join_args(result)
    assert result == 'foo bar "this is a test\\\\"'

# Generated at 2022-06-11 09:00:42.674578
# Unit test for function parse_kv
def test_parse_kv():
    # Test correct quotes handling
    assert parse_kv('; echo "ml-power-cycle"')  == {u'_raw_params': u'; echo "ml-power-cycle"'}
    assert parse_kv('; echo "ml-power-cycle"')[u'_raw_params'].endswith(u'"')
    assert parse_kv('; echo "ml-power-cycle"')[u'_raw_params'].startswith(u'; echo "')
    assert parse_kv(u"arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9 arg10") == {u'_raw_params': u'arg1 arg2 arg3 arg4 arg5 arg6 arg7 arg8 arg9 arg10'}

# Generated at 2022-06-11 09:00:54.657016
# Unit test for function parse_kv
def test_parse_kv():
    #
    # Option 1 - Using Assert
    #
    # Array to List
    test_case = ['foo=bar', 'boo=boo', 'baz="bar baz"', 'tf=\'bar boo\'']
    expResult = {u'baz': u'bar baz',
                 u'boo': u'boo',
                 u'foo': u'bar',
                 u'tf': u'bar boo'}
    actResult = parse_kv(join_args(test_case))
    assert expResult == actResult
    #
    # Option 2 - Using Exception
    #
    # Empty Dictionary
    test_case = {}
    expResult = {}
    actResult = parse_kv(join_args(test_case))

# Generated at 2022-06-11 09:01:22.761831
# Unit test for function split_args
def test_split_args():
    args = ['echo "this is a test"', '&&', 'echo "this is another test"', '&&', 'echo "this is a "third" test"']
    assert split_args(join_args(args)) == args

    args = ['echo "{{ foo | upper }}"']
    assert split_args(join_args(args)) == args

    args = ['echo "{{ foo | upper }}" \\', '&&', 'echo "{{ foo | lower }}"']
    assert split_args(join_args(args)) == args

    args = ['echo "{{ foo | upper }}" \\', 'bar="{{ foo }}"']
    assert split_args(join_args(args)) == args


# Generated at 2022-06-11 09:01:33.948210
# Unit test for function split_args
def test_split_args():
    # Basic test for demonstrating join_args/split_args doesn't
    # modify anything.
    # It is not complete.
    s = "foo"
    assert join_args(split_args(s)) == s

    s = "foo='bar baz'"
    assert join_args(split_args(s)) == s

    s = "foo='bar'\nbar=baz"
    assert join_args(split_args(s)) == s

    s = "foo=bar {{foo}} bar"
    assert join_args(split_args(s)) == s

    s = "foo=bar {{foo}} bar\nfoo=baz"
    assert join_args(split_args(s)) == s

    s = "'foo=bar' {{foo}} bar"
    assert join_args(split_args(s)) == s

# Generated at 2022-06-11 09:01:44.221560
# Unit test for function parse_kv
def test_parse_kv():
    # Some known values
    assert parse_kv('foo=bar') == {u'foo': u'bar'}
    assert parse_kv('foo=bar key=value') == {u'foo': u'bar', u'key': u'value'}

    # String argument
    assert parse_kv('foo="bar baz"') == {u'foo': u'bar baz'}

    # String argument with an equals
    assert parse_kv('foo="bar=baz"') == {u'foo': u'bar=baz'}

    # String argument with an escaped equals
    assert parse_kv('foo="bar\\=baz"') == {u'foo': u'bar=baz'}

    # Free-form arguments

# Generated at 2022-06-11 09:01:51.469039
# Unit test for function parse_kv
def test_parse_kv():
    '''
    Test the function parse_kv, by supplying the function with a query and
    then the expected output ansible should receive
    '''

    # Test a basic string
    assert parse_kv('key=value') == {u'key': u'value'}

    # Test string with spaces in value
    assert parse_kv('key=value me') == {u'key': u'value me'}

    # Test string with semicolons in value
    assert parse_kv('key=value;me') == {u'key': u'value;me'}

    # Test string with escaped equals in value
    assert parse_kv("key=value\=value") == {u'key': u'value=value'}

    # Test string with escaped single quotes in value

# Generated at 2022-06-11 09:02:00.405676
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 'b = 2' C='3'") == {"a": "1", "b": "2", "C": "3"}
    assert parse_kv("a=1 D=4 'b = 2' C='3'") == {"a": "1", "b": "2", "C": "3", "D": "4"}
    assert parse_kv("a=1 'b = 2' 'C=3'") == {"a": "1", "b": "2", "C": "3"}
    assert parse_kv("'b = 2' C='3' a=1") == {"a": "1", "b": "2", "C": "3"}
    assert parse_kv("a='1 2'") == {"a": "1 2"}

# Generated at 2022-06-11 09:02:10.516094
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a="b c" d="e f"') == {'a': 'b c', 'd': 'e f'}
    assert parse_kv('a=1 b=2 c') == {'a': '1', 'b': '2', '_raw_params': 'c'}
    assert parse_kv('a="b c" d="e f" g h') == {'a': 'b c', 'd': 'e f', '_raw_params': 'g h'}

# Generated at 2022-06-11 09:02:20.841473
# Unit test for function parse_kv
def test_parse_kv():
    def _assert_kv(str, expected):
        assert expected == parse_kv(str)

    # Regression test for ANSIBLE-1522
    _assert_kv(r"creates='/tmp/foo\=bar' removes='/tmp/baz\=qux' chdir='/tmp/quux\=quuz' executable='/bin/sh\=bash'",
               {'creates': '/tmp/foo=bar', 'removes': '/tmp/baz=qux', 'chdir': '/tmp/quux=quuz', 'executable': '/bin/sh=bash'})

    # Regression test for ANSIBLE-1522

# Generated at 2022-06-11 09:02:30.298168
# Unit test for function split_args
def test_split_args():
    # Trivial tests first
    assert split_args('') == ['', '']
    assert split_args(' ') == ['', '']
    assert split_args('\n') == ['\n']
    assert split_args('a') == ['a']
    assert split_args('a b') == ['a', 'b']
    assert split_args('a b  ') == ['a', 'b', '', '']

    # quote parsing

# Generated at 2022-06-11 09:02:38.183849
# Unit test for function split_args
def test_split_args():
    def test_split(arg, expected_output):
        res = split_args(arg)
        assert res == expected_output, "Failed to split args from: {0}".format(arg)

    test_split('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    test_split('a=b "c=foo bar"', ['a=b', '"c=foo bar"'])
    test_split('"a=b c=foo bar"', ['"a=b c=foo bar"'])
    test_split('a=b "c=foo bar" d={{ ee }}', ['a=b', '"c=foo bar"', 'd={{', 'ee', '}}'])

# Generated at 2022-06-11 09:02:47.395667
# Unit test for function split_args
def test_split_args():
    '''
    Test function for split_args
    '''

    # results to check against
    # any string that is a value in the dict, should return a list
    # that equals the key

# Generated at 2022-06-11 09:03:06.354513
# Unit test for function split_args
def test_split_args():
    def check(input_args, expected_result):
        actual_result = split_args(input_args)
        print("actual_result=", actual_result)
        print("expected_result=", expected_result)
        assert actual_result == expected_result, "Failed to split args '%s'" % input_args

    check("a=b c='foo bar'", ['a=b', "c='foo bar'"])
    check("a=b c=\"foo bar\"", ['a=b', 'c="foo bar"'])
    check("a=b c=\"foo bar", ['a=b', 'c="foo bar'])
    check("a=b c=\"foo bar\" before", ['a=b', 'c="foo bar"', "before"])

# Generated at 2022-06-11 09:03:16.177508
# Unit test for function split_args
def test_split_args():
    def test(args, expected):
        actual = split_args(args)
        assert actual == expected, 'Expected {0}, actual {1}'.format(expected, actual)

    # Various places to start quotes
    test('""', [''])
    test('"', ['', ''])

    # Various places to end quotes
    test('""', [''])
    test('""\\', [''])
    test('\\""', ['\\'])
    test('\\""""', ['\\'])

    # Various places to start and end quotes
    test('"a"', ['a'])
    test('a"', ['a', ''])
    test('"a', ['', 'a'])

    # Various places to escape quotes inside quotes
    test('"\\""', ['"'])

# Generated at 2022-06-11 09:03:27.890802
# Unit test for function split_args

# Generated at 2022-06-11 09:03:36.599789
# Unit test for function split_args
def test_split_args():
    '''
    This is a unit test for the split_args function.
    '''

# Generated at 2022-06-11 09:03:47.348220
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=b c=d') == {u'a': u'b', 'c': 'd'}
    assert parse_kv('a=b c=d') == {u'a': u'b', 'c': 'd'}
    # If a raw param begins with '-', we quote it so that it is not treated like an option
    assert parse_kv('a=b c=-d') == {u'a': u'b', u'_raw_params': 'c=-d'}
    # The above case also holds true if the raw param begins with a single-quote
    assert parse_kv("a=b c='-d'") == {u'a': u'b', u'_raw_params': u"c='-d'"}
    # Double-quoted params are left alone, as

# Generated at 2022-06-11 09:03:51.535325
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv('foo=1 bar=2')
    assert result == {'foo': '1', 'bar': '2'}

    result = parse_kv(u'foo="bar baz"')
    assert result == {'foo': u'bar baz'}

    result = parse_kv(u'foo="bar baz" bar="baz bar"')
    assert result == {'foo': u'bar baz', 'bar': u'baz bar'}

    result = parse_kv(u"foo=bar\\=baz")
    assert result == {'foo': u'bar=baz'}

    result = parse_kv(u"foo=bar\\=baz bar=baz\\=foo")

# Generated at 2022-06-11 09:03:58.992541
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == { u'foo': u'bar' }

    # ansible/ansible #43121
    assert parse_kv('foo="bar baz"') == { u'foo': u'bar baz' }
    assert parse_kv("foo='bar baz'") == { u'foo': u'bar baz' }

    # ansible/ansible #47865
    assert parse_kv('''arg1="herpderp \" with quote"''', check_raw=True) == { u'arg1': u'herpderp " with quote', u'_raw_params': u'arg1="herpderp " with quote"' }

# Generated at 2022-06-11 09:04:06.461493
# Unit test for function split_args
def test_split_args():
    import json
    import sys
    import os
    # Tokenize rules
    # 1. Split on newline regardless of quoting or block state
    # 2. Split on space unless inside a quoted string or
    #    inside a jinja2 block

    # Handling of jinja2 blocks:
    # each jinja2 block starts and ends with a set of
    # delimiters.  Brace delimited blocks will be
    # treated differently than quotes, in that we will
    # not reverse the logic of the quotes, but instead
    # simply prevent whitespace from splitting tokens
    # inside braces (since ansible does this).

    # jinja2 blocks may be nested, and therefore when we
    # see a delimiter for a given block type, we need to
    # see the block depth and then determine if we're at
    # the outer-most