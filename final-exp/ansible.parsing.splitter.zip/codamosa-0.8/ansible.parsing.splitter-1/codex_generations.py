

# Generated at 2022-06-11 08:54:35.244002
# Unit test for function split_args

# Generated at 2022-06-11 08:54:40.313208
# Unit test for function split_args
def test_split_args():
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("test \"test with spaces\"") == ['test', '"test with spaces"']
    assert split_args("test 'test with spaces'") == ['test', "'test with spaces'"]
    assert split_args("test 'test quoted\" with spaces'") == ['test', "'test quoted\" with spaces'"]
    assert split_args("test 'test quoted\" with spaces' abc=def") == ['test', "'test quoted\" with spaces'", 'abc=def']
    assert split_args("test 'test quoted\" with spaces' abc=def ghi=\"jkl mno\"") == ['test', "'test quoted\" with spaces'", 'abc=def', 'ghi="jkl mno"']
   

# Generated at 2022-06-11 08:54:48.777193
# Unit test for function parse_kv
def test_parse_kv():
    # Test case where vars are not passed
    assert parse_kv(None) == {}
    # Test case where vars are passed as string
    assert parse_kv('key1=val1 key2=val2 key1=val3') == {'key1': 'val3', 'key2': 'val2'}
    # Test case where vars are passed as list
    assert parse_kv(['key1=val1', 'key2=val2', 'key1=val3']) == {'key1': 'val3', 'key2': 'val2'}

# Generated at 2022-06-11 08:55:00.987791
# Unit test for function split_args
def test_split_args():
    # Positive test cases
    assert split_args('arg1 arg2 arg3=val3') == ['arg1', 'arg2', 'arg3=val3']
    assert split_args('arg1=val1 arg2=val2') == ['arg1=val1', 'arg2=val2']
    assert split_args('arg1="val1 val2"') == ['arg1="val1 val2"']
    assert split_args('arg1="val1 val2" arg2="val 22"') == ['arg1="val1 val2"', 'arg2="val 22"']
    assert split_args('arg1="{% foo %}"') == ['arg1="{% foo %}"']
    assert split_args('arg1="{{ foo }}"') == ['arg1="{{ foo }}"']

# Generated at 2022-06-11 08:55:03.164160
# Unit test for function parse_kv
def test_parse_kv():
    a = "1=2 foo=bar baz='' flub=4"

    assert parse_kv(a) == dict(foo='bar', baz='', flub='4', _raw_params='1=2')
    assert parse_kv(a, check_raw=True) == dict(foo='bar', baz='', flub='4')



# Generated at 2022-06-11 08:55:10.528243
# Unit test for function split_args
def test_split_args():
    # Use cases borrowed and adapted from Ansible core cases
    # test bare
    assert split_args('foo') == ['foo']

    # test simple space split
    assert split_args('foo bar baz') == ['foo', 'bar', 'baz']

    # test quotes
    assert split_args('foo "bar baz"') == ['foo', '"bar baz"']
    assert split_args('foo \'bar baz\'') == ['foo', '\'bar baz\'']
    assert split_args('foo "bar \'baz\'"') == ['foo', '"bar \'baz\'"']
    assert split_args('foo "bar \'baz\' quz"') == ['foo', '"bar \'baz\' quz"']
    assert split_args('foo "bar \'baz\' \'quz\'"')

# Generated at 2022-06-11 08:55:17.603421
# Unit test for function split_args

# Generated at 2022-06-11 08:55:29.449516
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=/tmp/foo executable=/bin/bash') == \
        {'creates': '/tmp/foo', 'executable': '/bin/bash'}
    assert parse_kv('creates=/tmp/foo') == {'creates': '/tmp/foo'}
    assert parse_kv('') == {}
    assert parse_kv('"key"="value"') == {'key': 'value'}
    assert parse_kv("key='value'") == {'key': 'value'}
    assert parse_kv("key=value") == {'key': 'value'}
    assert parse_kv("foo='this is a thing' bar='this is another'") == {
        'foo': 'this is a thing',
        'bar': 'this is another',
    }
   

# Generated at 2022-06-11 08:55:38.616892
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c=d') == ['a=b', 'c=d']
    assert split_args('a="foo bar" c="foo bar"') == ['a="foo bar"', 'c="foo bar"']
    assert split_args('a="foo bar" c="foo bar" d=e') == ['a="foo bar"', 'c="foo bar"', 'd=e']
    assert split_args('a="foo bar" c="foo bar"\nd=e') == ['a="foo bar"', 'c="foo bar"\n', 'd=e']



# Generated at 2022-06-11 08:55:42.352831
# Unit test for function parse_kv
def test_parse_kv():
    args = 'key="value with spaces" another-key="another value"'
    r = parse_kv(args)
    assert('key' in r and 'another-key' in r)
    assert(r['key'] == 'value with spaces')
    assert(r['another-key'] == 'another value')



# Generated at 2022-06-11 08:56:13.287037
# Unit test for function parse_kv
def test_parse_kv():
    a = parse_kv("a=b c=d")
    assert a == {u'a': u'b', u'c': u'd'}
    b = parse_kv("a=b c='d e' f=\"g h\"")
    assert b == {u'a': u'b', u'c': u'd e', u'f': u'g h'}
    c = parse_kv("a='b c' d='e=f'")
    assert c == {u'a': u'b c', u'd': u'e=f'}
    d = parse_kv("a=\"b'c\" d='e\"f'")
    assert d == {u'a': u"b'c", u'd': u'e"f'}

# Generated at 2022-06-11 08:56:24.586511
# Unit test for function parse_kv
def test_parse_kv():

    # Test basic functionality with some standard ansible options
    #
    # Also test that unicode sequence escapes are decoded properly
    #
    # Also test that trailing ; is discarded
    data = "a=1; b='2'; c=3; d='4'; u='\\u2713'; U='\\U00002713'; x='\\x3d'; n='\\N{RIGHTWARES}';"
    expected = {u'a': u'1', u'b': u'2', u'c': u'3', u'd': u'4', u'u': u'\u2713', u'U': u'\u2713', u'x': u'=', u'n': u'\u2713'}
    assert expected == parse_kv(data)

# Generated at 2022-06-11 08:56:33.998410
# Unit test for function parse_kv
def test_parse_kv():
    # This ensures all of the shell/command options are handled correctly
    # and that the raw key/value string is preserved for those that are
    # not. (The option is 'warn' instead of 'create' to reduce the chance
    # of a false positive, since that argument is a common one.
    args = 'warn=yes executable=/bin/true creates=/tmp/yep'
    options = {u'executable': u'/bin/true', u'creates': u'/tmp/yep', u'warn': u'yes'}
    assert parse_kv(args, True) == options
    args = 'warn=yes creates=/tmp/yep'
    options = {u'creates': u'/tmp/yep', u'warn': u'yes', u'_raw_params': u'warn=yes creates=/tmp/yep'}

# Generated at 2022-06-11 08:56:44.282031
# Unit test for function parse_kv

# Generated at 2022-06-11 08:56:54.060151
# Unit test for function split_args
def test_split_args():
    print('Testing split_args()')

# Generated at 2022-06-11 08:57:01.524177
# Unit test for function split_args

# Generated at 2022-06-11 08:57:11.364304
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'foo=bar baz=qux') == {u'foo': u'bar', u'baz': u'qux'}
    assert parse_kv(u'foo=bar=baz') == {u'foo': u'bar=baz'}
    assert parse_kv(u'foo=bar biz') == {u'foo': u'bar', u'_raw_params': u'biz'}
    assert parse_kv(u'foo=bar "biz=buz" ') == {u'foo': u'bar', u'_raw_params': u'"biz=buz"'}
    assert parse_kv(u'foo=bar biz=buz') == {u'foo': u'bar', u'biz': u'buz'}
    assert parse_k

# Generated at 2022-06-11 08:57:21.129233
# Unit test for function parse_kv

# Generated at 2022-06-11 08:57:30.002546
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('') == {}
    assert parse_kv('a=b c=d') == {'a': 'b', 'c': 'd'}
    assert parse_kv('a=b c=d e') == {'a': 'b', 'c': 'd', '_raw_params': 'e'}
    assert parse_kv('a=b "c=d e" "a=8 \\" b=9"') == {'a': 'b', 'c': 'd e', 'a': '8 " b=9'}
    assert parse_kv('a="b=c d=e"') == {'a': 'b=c d=e'}
    assert parse_kv('a=b=c') == {'a': 'b=c'}
    assert parse_kv

# Generated at 2022-06-11 08:57:38.598856
# Unit test for function parse_kv
def test_parse_kv():
    # test basic split
    assert parse_kv('a=1 b=2 c=3') == {'a': '1', 'b': '2', 'c': '3'}
    assert parse_kv('a=1 b="2 3" c=4') == {'a': '1', 'b': '2 3', 'c': '4'}
    assert parse_kv('a=1 b="2=3" c=4') == {'a': '1', 'b': '2=3', 'c': '4'}
    # nested quotes
    assert parse_kv('x=1 y="{{2+3}}" z=4') == {'x': '1', 'y': '{{2+3}}', 'z': '4'}
    # unbalanced quotes are not allowed

# Generated at 2022-06-11 08:57:52.481353
# Unit test for function split_args
def test_split_args():
    s = "user={{ansible_user_id}} age=21"
    print(split_args(s))


# Generated at 2022-06-11 08:58:01.795889
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {
        u'a': u'1',
        u'b': u'2',
    }

    assert parse_kv('a=1 b=2 c=3 d=4') == {
        u'a': u'1',
        u'b': u'2',
        u'c': u'3',
        u'd': u'4',
    }

    assert parse_kv('a=1 b=2 c=3 d="4 foo"') == {
        u'a': u'1',
        u'b': u'2',
        u'c': u'3',
        u'd': u'4 foo',
    }

    assert parse_kv('a=1 b=2 c=3 d=\'"4 foo"\'')

# Generated at 2022-06-11 08:58:12.902542
# Unit test for function parse_kv
def test_parse_kv():
    for input, output in [
        ('foo=bar', {u'foo': u'bar'}),
        ('foo="bar"', {u'foo': u'bar'}),
        ('foo="bar baz"', {u'foo': u'bar baz'}),
        ('foo="bar \\"baz\\""', {u'foo': u'bar "baz"'}),
        ('foo=bar baz=qux', {u'foo': u'bar', u'baz': u'qux'}),
        ('foo bar baz', {u'_raw_params': u'foo bar baz'}),
        ('foo bar baz=qux', {u'_raw_params': u'foo bar baz=qux'}),
        (None, {}),
    ]:
        assert parse_

# Generated at 2022-06-11 08:58:22.359228
# Unit test for function parse_kv
def test_parse_kv():
    """
    parser_kv() tests
    :return:
    """
    assert parse_kv(u'creates=/tmp/foo removes=/tmp/bar') == {u'creates': u'/tmp/foo', u'removes': u'/tmp/bar'}
    assert parse_kv(u"creates=/tmp/foo removes='/tmp/bar baz'") == {u'creates': u'/tmp/foo', u'removes': u"'/tmp/bar baz'"}

# Generated at 2022-06-11 08:58:30.702833
# Unit test for function parse_kv
def test_parse_kv():
    args = u'key1=value1 key2=value2'
    res = parse_kv(args)
    expected = {u'key1': u'value1', u'key2': u'value2'}
    assert res == expected

    args = u'key1=value1 key2="value2 with spaces"'
    res = parse_kv(args)
    expected = {u'key1': u'value1', u'key2': u'value2 with spaces'}
    assert res == expected

    args = u'key1="with spaces" key2=\'value2 with spaces\''
    res = parse_kv(args)
    expected = {u'key1': u'with spaces', u'key2': u'value2 with spaces'}
    assert res == expected


# Generated at 2022-06-11 08:58:32.542983
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b=2 cde=3") == dict(a="1", b="2", cde="3")


# Generated at 2022-06-11 08:58:43.164488
# Unit test for function parse_kv
def test_parse_kv():
    result = parse_kv('foo=bar baz=qux')
    assert result == {u'foo': u'bar', u'baz': u'qux'}, 'result was %s' % result

    result = parse_kv('foo=bar baz=qux zap')
    assert result == {u'foo': u'bar', u'baz': u'qux', u'_raw_params': u'zap'}, 'result was %s' % result

    result = parse_kv('foo=bar baz=qux zap=zippy')
    assert result == {u'foo': u'bar', u'baz': u'qux', u'zap': u'zippy'}, 'result was %s' % result


# Generated at 2022-06-11 08:58:53.613626
# Unit test for function parse_kv
def test_parse_kv():
    # Test for handling escaped quotations, inspired by #13125
    input_str = '''"a"b=cd=ef='gh'i="j"k=lm'no'p=q'''
    options = parse_kv(input_str)
    assert len(options) == 4
    assert options['ab'] == 'cd=ef'
    assert options['ghi'] == 'jk'
    assert options['lmp'] == 'q'
    assert options['_raw_params'] == '"ab" cd=ef gh=i jk lm=no p'
    options = parse_kv(input_str, check_raw=False)
    assert len(options) == 3
    assert options['ab'] == 'cd=ef'
    assert options['ghi'] == 'jk'
    assert options['lmp']

# Generated at 2022-06-11 08:58:59.656395
# Unit test for function parse_kv
def test_parse_kv():
    # given
    args = to_text(r'''= '\n is not a newline' \= "a literal \" equals"
                \n=\na\nescape\tsequence\ris\r\npresent\n''')
    # when
    d = parse_kv(args)
    # then
    assert d == {
        u'=': u'\n is not a newline',
        u'\\=': u'a literal " equals',
        u'\n': u'a\nescape\tsequence\ris\npresent\n',
        u'_raw_params': u'\'\\n is not a newline\' \\\'a literal \\" equals\' \\n\'a\\nescape\\tsequence\\ris\\npresent\\n\''
    }



# Generated at 2022-06-11 08:59:11.622002
# Unit test for function split_args
def test_split_args():
    def _assert_split_args(args, expected_result):
        result = split_args(args)
        assert expected_result == result, ('Expected split args to be %s but got %s for %s' % (expected_result, result, args))
    _assert_split_args('a=b c=d', ['a=b', 'c=d'])
    _assert_split_args('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _assert_split_args('a=b c="foo bar" d="{{ foo }}"', ['a=b', 'c="foo bar"', 'd="{{ foo }}"'])

# Generated at 2022-06-11 08:59:24.875105
# Unit test for function split_args
def test_split_args():
    # test basic case of no spaces, one word
    assert split_args(u'foo') == [u'foo']
    # test case with a space then a word
    assert split_args(u' foo') == [u'foo']
    # test case with a newline, no spaces
    assert split_args(u'foo\n') == [u'foo\n']
    # test case with a newline, no spaces, and a trailing space
    assert split_args(u'foo \n') == [u'foo\n']
    # test case with a newline with spaces
    assert split_args(u'  foo \n') == [u'foo\n']
    assert split_args(u'foo bar') == [u'foo', u'bar']
    # test case with a jinja2 print block and no spaces


# Generated at 2022-06-11 08:59:37.135407
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(args=None) == {}
    assert parse_kv(args="") == {}
    assert parse_kv(args="foo=bar") == {"foo": "bar"}
    assert parse_kv(args="foo=bar bar=baz") == {"foo": "bar", "bar": "baz"}
    assert parse_kv(args='foo="bar baz"') == {"foo": "bar baz"}
    assert parse_kv(args='foo="bar \\"baz\\""') == {"foo": 'bar "baz"'}
    assert parse_kv(args="foo=bar bar=baz biz=buzz") == {"foo": "bar", "bar": "baz", "biz": "buzz"}

# Generated at 2022-06-11 08:59:46.133621
# Unit test for function parse_kv
def test_parse_kv():
    # from the docs
    assert parse_kv(u"creates=/tmp/foo removes=/tmp/bar") == {u"creates": u"/tmp/foo", u"removes": u"/tmp/bar"}

    # check_raw=False should skip free-form args
    assert parse_kv(u"/usr/bin/myapp --debug --log=/tmp/foo.log", check_raw=False) == {u"/usr/bin/myapp": u"--debug --log=/tmp/foo.log"}

    # check_raw=True should capture free-form args

# Generated at 2022-06-11 08:59:55.834767
# Unit test for function split_args
def test_split_args():
    print("test_split_args")
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=b c=\"foo bar\" d='foo bar'") == ['a=b', 'c="foo bar"', 'd=foo bar']
    assert split_args("a=b c=\"foo bar\" d='foo bar' e=f g=h") == ['a=b', 'c="foo bar"', "d='foo bar'", 'e=f', 'g=h']

# Generated at 2022-06-11 09:00:05.511857
# Unit test for function split_args
def test_split_args():
    def _assert_split(args, result):
        actual = split_args(args)
        assert actual == result or actual == [to_text(x) for x in result], 'Parsed args "%s" did not match expected result: expected=%s, got=%s' % (args, result, actual)

    _assert_split('a=b c="foo bar"', ['a=b', 'c="foo bar"'])
    _assert_split('a=b c="foo \\"bar\\""', ['a=b', 'c="foo \\"bar\\""'])
    _assert_split('a=b c=\'foo bar\'', ['a=b', "c='foo bar'"])

# Generated at 2022-06-11 09:00:13.226007
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('cheese=brie') == dict(cheese='brie')
    assert parse_kv('cheese=brie,bread=chapati') == dict(cheese='brie', bread='chapati')
    assert parse_kv('cheese=brie bread=chapati') == dict(cheese='brie', bread='chapati')
    assert parse_kv('cheese=brie,bread=chapati,soup="chicken broth"') == dict(cheese='brie', bread='chapati', soup='chicken broth')

# Generated at 2022-06-11 09:00:22.066281
# Unit test for function split_args

# Generated at 2022-06-11 09:00:32.442375
# Unit test for function parse_kv

# Generated at 2022-06-11 09:00:41.940411
# Unit test for function parse_kv
def test_parse_kv():
    params = "single=word arg=with spaces arg=with\\ equals x=false y=true z=0 a=2\\>1 b=\'quoted value'"

    # test parse_kv's return value
    ret = parse_kv(params)
    assert('single' in ret and ret['single'] == 'word')
    assert('arg' in ret and ret['arg'] == 'with spaces')
    assert('x' in ret and ret['x'] == 'false')
    assert('y' in ret and ret['y'] == 'true')
    assert('z' in ret and ret['z'] == '0')
    assert('a' in ret and ret['a'] == '2>1')
    assert('b' in ret and ret['b'] == 'quoted value')

# Generated at 2022-06-11 09:00:53.817407
# Unit test for function parse_kv
def test_parse_kv():

    # Case 1: simple key-words without values
    #         a=b c=d e=f
    #         expected result: {'a': 'b', 'c': 'd', 'e': 'f'}
    input = u"a=b c=d e=f"
    expected = {u'a': u'b', u'c': u'd', u'e': u'f'}
    result = parse_kv(input)
    assert result == expected

    # Case 2: simple key-words with values
    #         a=b c="string with spaces" e=f
    #         expected result: {'a': 'b', 'c': 'string with spaces', 'e': 'f'}
    input = u"a=b c=\"string with spaces\" e=f"

# Generated at 2022-06-11 09:01:10.022706
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo="bar baz" bam={{ hello }}') == {u'foo': u'bar baz', u'bam': u'{{ hello }}'}
    assert parse_kv('foo="bar baz" bam={{ hello }}', check_raw=True) == {u'foo': u'bar baz', u'bam': u'{{ hello }}', u'_raw_params': u'foo="bar baz" bam={{ hello }}'}
    assert parse_kv('bar baz = "{{ hello }}"', check_raw=True) == {u'bar baz': u'{{ hello }}', u'_raw_params': u'bar baz = "{{ hello }}"'}



# Generated at 2022-06-11 09:01:21.029610
# Unit test for function split_args
def test_split_args():
    # Test 1
    test1 = 'a=b c="foo bar"'
    result1 = split_args(test1)
    if result1 != ['a=b', 'c="foo bar"']:
        print('Test 1 failed')

    # Test 2
    test2 = 'a=b c="foo  bar"'
    result2 = split_args(test2)
    if result2 != ['a=b', 'c="foo  bar"']:
        print('Test 2 failed')

    # Test 3
    test3 = 'a=b c="foo bar"\nd=e f="some other thing"'
    result3 = split_args(test3)
    if result3 != ['a=b', 'c="foo bar"', 'd=e', 'f="some other thing"']:
        print('Test 3 failed')

    # Test

# Generated at 2022-06-11 09:01:25.328069
# Unit test for function split_args
def test_split_args():
    def assert_split_args(actual, expected):
        assert actual == expected, 'Expected:\n{0}Got:\n{1}'.format(expected, actual)
    assert_split_args(split_args('a=b'), ['a=b'])
    assert_split_args(split_args('a=b c=d'), ['a=b', 'c=d'])
    assert_split_args(split_args('a=b "c d"'), ['a=b', '"c d"'])
    assert_split_args(split_args(r'a=b "c\"d"'), ['a=b', r'"c\"d"'])
    assert_split_args(split_args(r'a=b "c\\d"'), ['a=b', r'"c\\d"'])
    assert_split_

# Generated at 2022-06-11 09:01:36.352258
# Unit test for function split_args

# Generated at 2022-06-11 09:01:43.256604
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=1 b='a b' c='1 2' d=1\\ e=2") == {u'a': u'1', u'b': u'a b', u'c': u'1 2', u'd': u'1 e', u'_raw_params': u'a=1 b=a\\ b c=1\\ 2 d=1\\\\ e=2'}


# TODO: deprecate this so we can just use shlex.split()
# once Python 2.6 is not longer supported.

# Generated at 2022-06-11 09:01:50.852762
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u"foo=bar baz=qux") == {u'baz': u'qux', u'foo': u'bar'}
    assert parse_kv(u"foo='bar baz'") == {u'foo': u'bar baz'}
    assert parse_kv(u"foo='bar \"baz\"'") == {u'foo': u'bar "baz"'}
    assert parse_kv(u"foo=bar \"baz=qux\"") == {u'foo': u'bar "baz=qux"'}
    assert parse_kv(u"foo=\"bar 'baz'\"") == {u'foo': u"bar 'baz'"}

# Generated at 2022-06-11 09:01:59.732284
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('k=v') == {'k': 'v'}
    assert parse_kv('k = v') == {'k': 'v'}
    assert parse_kv('k =') == {'k': ''}
    assert parse_kv('k=') == {'k': ''}
    assert parse_kv('k') == {'k': ''}
    assert parse_kv('k v') == {'_raw_params': 'k v'}
    assert parse_kv('k=v a=b') == {'k': 'v', 'a': 'b'}
    assert parse_kv('k=v a') == {'k': 'v', '_raw_params': 'a'}
    assert parse_kv('k=') == {'k': ''}
   

# Generated at 2022-06-11 09:02:09.498782
# Unit test for function split_args
def test_split_args():
    '''
    Will return the a dictionary where the key is the raw input string and the value
    is the expected list that should come out of split_args.
    '''

    # Each of the dictionary keys is a string that will be parsed by split_args
    # Each of the dictionary values is a list of strings that we expect
    # split_args to return for each of the respective keys

    # The keys and values are not meant to be exhaustive, but rather to just
    # show examples of how split_args should behave.


# Generated at 2022-06-11 09:02:20.176960
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1') == {u'a': u'1'}
    assert parse_kv('a=1 b=2') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1 "b=2"') == {u'a': u'1', u'b': u'2'}
    assert parse_kv('a=1 "b=2" c=3') == {u'a': u'1', u'b': u'2', u'c': u'3'}
    assert parse_kv('a=1 "b=2" c=3 "d e"') == {u'a': u'1', u'b': u'2', u'c': u'3', u'd e': u''}

# Generated at 2022-06-11 09:02:29.635221
# Unit test for function split_args

# Generated at 2022-06-11 09:02:42.751230
# Unit test for function parse_kv
def test_parse_kv():
    # Test basic parsing
    data = 'name0=value0 name1=value1 name2="value2 is a string" name3=\'value3 is a string\''
    parsed_data = parse_kv(data)
    assert parsed_data.get('name0') == u'value0'
    assert parsed_data.get('name1') == u'value1'
    assert parsed_data.get('name2') == u'value2 is a string'
    assert parsed_data.get('name3') == u'value3 is a string'

    # Test parsing with escaped quotes

# Generated at 2022-06-11 09:02:53.256907
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("foo='bar baz' x=1")
    assert options == {'foo': u'bar baz', 'x':u'1'}, options

    options = parse_kv("file=/tmp/a 'a b'=3")
    assert options == {u'a b': u'3', u'file': u'/tmp/a'}, options

    # pre-quoted values
    options = parse_kv('param=["foo", "bar"]')
    assert options == {'param': u'["foo", "bar"]'}, options

    options = parse_kv("param=['foo', 'bar']")
    assert options == {u'param': u"['foo', 'bar']"}, options

    # default is shell=True
    options = parse_kv("echo foo bar")
    assert options

# Generated at 2022-06-11 09:02:57.813308
# Unit test for function split_args
def test_split_args():
    from ansible.parsing.splitter import split_args
    assert split_args("a=b c=\"foo bar\"") == ['a=b', 'c="foo bar"']
    assert split_args("a=\"b c\" d=e") == ['a="b c"', 'd=e']

# Generated at 2022-06-11 09:03:01.785407
# Unit test for function parse_kv
def test_parse_kv():
    print("input string: 'a=b c=d e= f=g'")
    print(parse_kv("a=b c=d e= f=g"))

if __name__ == '__main__':
    test_parse_kv()

# Generated at 2022-06-11 09:03:08.713899
# Unit test for function split_args
def test_split_args():
    assert split_args(u'stuff') == [u'stuff']
    assert split_args(u'''stuff "with space" "stuff with {{jinja2}} inside quotes"''') == [u'stuff', u'"with space"', u'"stuff with {{jinja2}} inside quotes"']
    assert split_args(u"'''stuff with 'quotes' and {#jinja2 comments#} in it'''") == [u"'''stuff with 'quotes' and {#jinja2 comments#} in it'''"]

# Generated at 2022-06-11 09:03:19.939937
# Unit test for function split_args
def test_split_args():
    assert split_args('') == []
    assert split_args(';') == [';']
    assert split_args('&&') == ['&&']
    assert split_args('{% if True %}foo{% endif %} bar') == ['{% if True %}foo{% endif %}', 'bar']
    assert split_args('foo{{ True }}bar') == ['foo{{ True }}bar']
    assert split_args('foo {% True %}bar') == ['foo', '{% True %}bar']
    assert split_args('foo {% True %} bar') == ['foo', '{% True %}', 'bar']

# Generated at 2022-06-11 09:03:30.099304
# Unit test for function parse_kv
def test_parse_kv():
    print(parse_kv("foo=bar"))
    print(parse_kv("foo='bar z'"))
    print(parse_kv("foo='bar z' x='y'"))
    print(parse_kv("foo='bar z' x='y' z"))
    print(parse_kv("""foo="bar z" x="y" z"""))
    print(parse_kv("""foo="bar z" 'x="y" z'"""))
    print(parse_kv("foo=bar a='1 2 3'"))
    print(parse_kv("foo=bar a='1 2 3' b=c"))
    print(parse_kv("foo=bar b=c 'a=\"1 2 3\"'"))

# Split arguments adapted from rspeer's answer here:
# http://stackoverflow.

# Generated at 2022-06-11 09:03:38.258348
# Unit test for function parse_kv
def test_parse_kv():
    # function parse_kv
    assert parse_kv(u"a=b c=d") == {u"a": u"b", u"c": u"d"}, "Problem parsing kv options, a=b c=d"
    assert parse_kv(u"a=b c=d e=f") == {u"a": u"b", u"c": u"d", u"e": u"f"}, "Problem parsing kv options, a=b c=d e=f"
    assert parse_kv(u"a=b c=d e=f g=h") == {u"a": u"b", u"c": u"d", u"e": u"f", u"g": u"h"}, "Problem parsing kv options, a=b c=d e=f g=h"

# Generated at 2022-06-11 09:03:50.689439
# Unit test for function split_args
def test_split_args():
    """
    Unit test for function split_args
    """
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # test that newlines get properly preserved inside quotes
    result = split_args('a="foo\nbar" b="foo\\\nbar"  c="foo\n\\\nbar"')
    assert result == ['a="foo\nbar"', 'b="foo\\\nbar"', 'c="foo\n\\\nbar"']

    # test that jinja blocks are correctly reassembled
    result = split_args('a={{foo}} b="{{foo}}" c="{{foo}} {{bar}}"')
    assert result == ['a={{foo}}', 'b="{{foo}}"', 'c="{{foo}} {{bar}}"']

# Generated at 2022-06-11 09:03:58.590974
# Unit test for function parse_kv
def test_parse_kv():
    kvargs = ['a=1', 'b=2']
    kvargs2 = ['a1=1', 'b2=2']

    assert(parse_kv("a=1 b=2") == {'a': '1', 'b': '2'})
    assert(parse_kv("a=1 b=2") == parse_kv("b=2 a=1"))

    assert(parse_kv("a=1 b=2 c=3") == {'a': '1', 'b': '2', 'c': '3'})
    assert(parse_kv("a=1 b=2 c=3") == parse_kv("b=2 a=1 c=3"))