

# Generated at 2022-06-11 08:55:36.492409
# Unit test for function split_args
def test_split_args():

    def _run_test(input, expected):
        result = split_args(input)
        if result != expected:
            err = u"failed to parse args '{0}', got '{1}' instead of '{2}'".format(input, result, expected)
            raise AssertionError(err)

    _run_test("a=b", ["a=b"])
    _run_test("a='b c'", ["a='b c'"])
    _run_test("a='b c' d='e f'", ["a='b c'", "d='e f'"])
    _run_test("a=\"b c\" d=\"e f\"", ["a=\"b c\"", "d=\"e f\""])

# Generated at 2022-06-11 08:55:44.195618
# Unit test for function parse_kv

# Generated at 2022-06-11 08:55:54.573776
# Unit test for function parse_kv
def test_parse_kv():
    options = {"_raw_params": [], "creates": "/tmp/bar", "executable": None}
    assert(parse_kv("creates=/tmp/bar",True)==options)
    options = {"_raw_params": [], "creates": "/tmp/bar", "executable": None}
    assert(parse_kv("creates=/tmp/bar",False)==options)
    options = {"a":"b","_raw_params": ["c=d"]}
    assert(parse_kv("a=b c=d",True)==options)
    options = {"a":"b","_raw_params": [], "executable": None}
    assert(parse_kv("a=b c=d",False)==options)
    options = {"a": "b", "t": "t"}

# Generated at 2022-06-11 08:56:05.332063
# Unit test for function split_args
def test_split_args():
    import pytest

# Generated at 2022-06-11 08:56:09.467126
# Unit test for function split_args
def test_split_args():
    '''
    Test split_args() with various args input.
    '''
    # Simple example
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Example that includes double-quotes
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']

    # Example that includes a single-quote
    assert split_args("a=b c='foo bar'") == ['a=b', "c='foo bar'"]

    # Example that includes single quote inside a double quotes

# Generated at 2022-06-11 08:56:19.851730
# Unit test for function split_args
def test_split_args():
    assert split_args('echo "here is a test"') == ['echo', '"here is a test"']
    assert split_args('echo "here \'is a test"') == ['echo', '"here \'is a test"']
    assert split_args('{{ ansible_env.HOME }}') == ['{{', 'ansible_env.HOME', '}}']
    assert split_args('{{ ansible_env.HOME }}\n') == ['{{', 'ansible_env.HOME', '}}']
    assert split_args('{{ ansible_env.HOME }}\necho "here is a test"') == ['{{', 'ansible_env.HOME', '}}\necho', '"here is a test"']

# Generated at 2022-06-11 08:56:30.927777
# Unit test for function parse_kv
def test_parse_kv():
    args = 'foo=bar dog=cat one=two "three=four five six" seven=eight "nine=ten eleven"'
    parsed = parse_kv(args)
    assert sorted(parsed.keys()) == ['dog', 'foo', 'seven', '_raw_params']
    assert parsed['dog'] == 'cat'
    assert parsed['foo'] == 'bar'
    assert parsed['seven'] == 'eight'
    assert parsed['_raw_params'] == '"three=four five six" "nine=ten eleven"'

    args = 'foo=bar two="three=four five six" "seven=eight nine ten" eleven=twelve'
    parsed = parse_kv(args)
    assert sorted(parsed.keys()) == ['_raw_params', 'eleven', 'foo', 'two']
    assert parsed['foo']

# Generated at 2022-06-11 08:56:42.216339
# Unit test for function split_args
def test_split_args():
    # Helper function for outputs a helpful error for tests
    def assert_split_args_test(test_num, actual, expected):
        assert actual == expected, "test {0} failed".format(test_num)
    # Basic test
    assert_split_args_test('1.1', split_args("abc def ghi jkl"), ["abc", "def", "ghi", "jkl"])
    # Quotation marks
    assert_split_args_test('2.1', split_args("'abc' 'def' 'ghi' 'jkl'"), ["'abc'", "'def'", "'ghi'", "'jkl'"])
    assert_split_args_test('2.2', split_args("'abc def'"), ["'abc def'"])

# Generated at 2022-06-11 08:56:51.162129
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=foo b="bar baz" c=') == {'a': 'foo', 'b': 'bar baz', 'c': ''}
    assert parse_kv('a=foo b="bar baz" c= d=e=f g') == {'a': 'foo', 'b': 'bar baz', 'c': '', 'g': 'd=e=f'}
    assert parse_kv('a=foo b="bar baz" c= d=e=f g h=\\"i \\" j') == {'a': 'foo', 'b': 'bar baz', 'c': '', 'g': 'd=e=f h="i " j'}

# Generated at 2022-06-11 08:57:00.101010
# Unit test for function parse_kv
def test_parse_kv():
    """
    >>> test_parse_kv()
    True
    """

# Generated at 2022-06-11 08:57:20.791854
# Unit test for function split_args
def test_split_args():
    """
    Test split_args function
    """
    # Simple test
    result = split_args("abc dfddf")
    assert len(result) == 2
    assert result[0] == 'abc'
    assert result[1] == 'dfddf'

    # Argument with space
    result = split_args("abc def def def def def def def def def def def def def def")
    assert len(result) == 2
    assert result[0] == 'abc'
    assert result[1] == 'def def def def def def def def def def def def def'

    # Argument with quotes
    result = split_args("abc 'def def def def def def def def def def def def def def'")
    assert len(result) == 2
    assert result[0] == 'abc'

# Generated at 2022-06-11 08:57:29.695355
# Unit test for function split_args

# Generated at 2022-06-11 08:57:38.287581
# Unit test for function split_args

# Generated at 2022-06-11 08:57:47.217187
# Unit test for function split_args
def test_split_args():
    import pytest
    result = split_args(args='')
    assert result == []

    result = split_args(args='-a')
    assert result == [u'-a']

    result = split_args(args='foo=bar')
    assert result == [u'foo=bar']

    result = split_args(args='foo=bar baz=foo')
    assert result == [u'foo=bar', u'baz=foo']

    result = split_args(args='jet fuel can\'t melt steel beams')
    assert result == [u'jet', u'fuel', u"can't", u'melt', u'steel', u'beams']

    result = split_args(args='this is "one arg"')
    assert result == [u'this', u'is', u'"one arg"']

   

# Generated at 2022-06-11 08:57:56.473137
# Unit test for function parse_kv
def test_parse_kv():
    ''' test_parse_kv '''
    # old style with spaces
    s = "a=1 b=2 c=foo bar"
    assert parse_kv(s) == dict(a="1", b="2", c="foo", _raw_params="bar")

    # old style with underscores
    s = "a=1 b=2 c=foo_bar"
    assert parse_kv(s) == dict(a="1", b="2", c="foo_bar")

    # old style with colons
    s = "a=1 b=2 c=foo:bar"
    assert parse_kv(s) == dict(a="1", b="2", c="foo:bar")

    # old style with escaped equals
    s = "a=1 b=2 c=foo\\=bar"
    assert parse

# Generated at 2022-06-11 08:58:05.749577
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo=bar baz=quux') == {'foo': 'bar', 'baz': 'quux'}
    assert parse_kv('foo = bar = baz') == {'foo': 'bar = baz'}
    assert parse_kv('foo="bar bar"') == {'foo': 'bar bar'}
    assert parse_kv("foo='bar bar'") == {'foo': 'bar bar'}
    assert parse_kv('foo="bar bar" bar=baz') == {'foo': 'bar bar', 'bar': 'baz'}
    assert parse_kv("foo='bar bar' bar=baz") == {'foo': 'bar bar', 'bar': 'baz'}

# Generated at 2022-06-11 08:58:15.420211
# Unit test for function parse_kv

# Generated at 2022-06-11 08:58:24.428273
# Unit test for function parse_kv
def test_parse_kv():
    # test 1
    kv1 = "first=one second=\"two three\" fourth=four"
    res1 = parse_kv(kv1)
    assert res1 == {u'first': u'one', u'second': u'two three', u'fourth': u'four'}
    # test 2
    kv2 = "first='one' second='two\ three' fourth='four'"
    res2 = parse_kv(kv2)
    assert res2 == {u'first': u'one', u'second': u'two three', u'fourth': u'four'}
    # test 3
    kv3 = "first=\"one\" second=\"two\ three\" fourth=\"four\""
    res3 = parse_kv(kv3)

# Generated at 2022-06-11 08:58:29.978963
# Unit test for function split_args

# Generated at 2022-06-11 08:58:38.065399
# Unit test for function split_args

# Generated at 2022-06-11 08:59:10.810899
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('a=1 b=2') == {'a': '1', 'b': '2'}
    assert parse_kv('a=1 b=2 c=') == {'a': '1', 'b': '2', 'c': ''}
    assert parse_kv('a=1 b=2 c=') == {'a': '1', 'b': '2', 'c': ''}
    assert parse_kv('a b c=3') == {u'_raw_params': u'a b c=3'}
    assert parse_kv(u'a="foo bar"', True) == {'a': u'foo bar'}

# Generated at 2022-06-11 08:59:21.409010
# Unit test for function split_args
def test_split_args():
    assert split_args("foo") == ["foo"]
    assert split_args("foo bar") == ["foo", "bar"]
    assert split_args("foo bar baz") == ["foo", "bar", "baz"]
    assert split_args("foo \"bar baz\"") == ["foo", '"bar baz"']
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo \"bar baz\"") == ["foo", '"bar baz"']
    assert split_args("foo 'bar baz'") == ["foo", "'bar baz'"]
    assert split_args("foo \"bar baz'") == ["foo", '"bar baz\'']

# Generated at 2022-06-11 08:59:25.243838
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('creates=foo executable=bar') == { u'creates': u'foo', u'executable': u'bar' }


# Testing helper function to split args into a list.

# Generated at 2022-06-11 08:59:37.712693
# Unit test for function parse_kv
def test_parse_kv():
    import os
    import tempfile
    import shutil
    test_dir = os.path.join(tempfile.gettempdir(), 'test_parse_kv')
    os.makedirs(test_dir)
    test_file = os.path.join(test_dir, 'testfile')

# Generated at 2022-06-11 08:59:46.396425
# Unit test for function split_args
def test_split_args():
    # Some test cases
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\'foo bar\'') == ['a=b', "c='foo bar'"]
    assert split_args('a=b c=\\"foo bar\\"') == ['a=b', 'c="foo bar"']
    assert split_args('a=b c=\\\'foo bar\\\'') == ['a=b', "c='foo bar'"]
    assert split_args('a=b c="foo bar\' baz"') == ['a=b', "c='foo bar\' baz'"]

# Generated at 2022-06-11 08:59:55.951748
# Unit test for function split_args

# Generated at 2022-06-11 09:00:03.959866
# Unit test for function split_args
def test_split_args():
    import io
    import sys

    from ansible.parsing.utils.yaml import from_yaml

    stream = io.StringIO()
    sys.stdout = stream

    with open('test/units/library/test_parsing.yml', 'rb') as f:
        for case in from_yaml(f):
            tokenize = case['tokenize']
            expected = case['expected']
            actual = split_args(tokenize)

            assert expected == actual, 'input: "%s", expected: "%s", actual: "%s"' % (tokenize, expected, actual)
            print(u'PASSED: %s' % tokenize)

    sys.stdout = sys.__stdout__

# Generated at 2022-06-11 09:00:12.708065
# Unit test for function split_args
def test_split_args():
    def assert_split_args_result(args, expected_result):
        split_args_result = split_args(args)
        assert split_args_result == expected_result, '%s => %s but got %s' % (repr(args), repr(expected_result), repr(split_args_result))

    def assert_split_args_error(args, error_regex):
        try:
            split_args(args)
            assert False, "Expected an exception for " + repr(args)
        except AnsibleParserError as e:
            exception_text = str(e)

# Generated at 2022-06-11 09:00:21.316846
# Unit test for function split_args

# Generated at 2022-06-11 09:00:31.969866
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("a=b", check_raw=False) == {"a": "b"}
    assert parse_kv("a=b c=d", check_raw=False) == {"a": "b", "c": "d"}
    assert parse_kv("a='b c' c='d e' f=g", check_raw=False) == {"a": "b c", "c": "d e", "f": "g"}
    assert parse_kv("a='b c' c='d e' f=g", check_raw=True) == {"a": "b c", "c": "d e", "f": "g"}
    assert parse_kv("creates=foo rm -rf /", check_raw=True) == {"creates": "foo", "_raw_params": "rm -rf /"}


# Generated at 2022-06-11 09:00:51.247714
# Unit test for function split_args

# Generated at 2022-06-11 09:00:58.214796
# Unit test for function parse_kv
def test_parse_kv():
    # Arrange
    data1 = "name=bob age=63"
    data2 = "name=bob age=\"63 flying around in a space ship\""

    # Act
    dict_data1 = parse_kv(data1)
    dict_data2 = parse_kv(data2)

    # Assert
    assert "name" in dict_data1 and dict_data1["name"] == "bob" and "age" in dict_data1 and dict_data1["age"] == "63", "parse_kv not working as expected"
    assert "name" in dict_data2 and dict_data2["name"] == "bob" and "age" in dict_data2 and dict_data2["age"] == "63 flying around in a space ship", "parse_kv not working as expected"



# Generated at 2022-06-11 09:01:09.131186
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv("foo=bar") == {'foo': 'bar'}
    assert parse_kv("foo=bar biz=boz") == {'foo': 'bar', 'biz': 'boz'}
    assert parse_kv("foo=bar biz=boz biz='a b'") == {'foo': 'bar', 'biz': 'boz', 'biz': 'a b'}
    assert parse_kv("foo=bar biz=boz biz='a b'") == {'foo': 'bar', 'biz': 'boz', 'biz': 'a b'}
    assert parse_kv("foo=ba r biz=boz biz='a b'") == {'foo': 'ba r', 'biz': 'boz', 'biz': 'a b'}
    assert parse_k

# Generated at 2022-06-11 09:01:20.557637
# Unit test for function parse_kv
def test_parse_kv():
    test_str = "key1=val1 key2='val2 val3' key3=val4 \\=val5 key4='val6\\=val7'"
    options = parse_kv(test_str, check_raw=False)
    assert options == {
        u'key1': u'val1',
        u'key2': u'val2 val3',
        u'key3': u'val4 \\=val5',
        u'key4': u'val6\\=val7'
    }

    test_str = "key1=val1 key2='val2 val3' key3=val4 \\=val5 key4='val6\\=val7' 'arg1 arg2' arg3\\=arg4"
    options = parse_kv(test_str, check_raw=True)
    assert options

# Generated at 2022-06-11 09:01:31.961654
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(u'first=one second=two') == {u'first': u'one', u'second': u'two'}
    assert parse_kv(u'first=one\\=two second=\\"three \\"four\\" five\\" six=seven') == {u'first': u'one=two', u'second': u'"three "four" five"', u'six': u'seven'}
    assert parse_kv(u'first=one second=\\"two three') == {u'first': u'one', u'second': u'\\"two', u'_raw_params': u'three'}

# Generated at 2022-06-11 09:01:41.959981
# Unit test for function parse_kv
def test_parse_kv():
  assert parse_kv("first_key=first_value second_key=second_value") == {'first_key': 'first_value', 'second_key': 'second_value'}
  assert parse_kv("first_key=first_value second_key=") == {'first_key': 'first_value'}
  assert parse_kv("first_key= first_value second_key=") == {'first_key': 'first_value'}
  assert parse_kv("first_key=first_value", check_raw=True) == {'first_key': 'first_value'}
  
  try: 
    parse_kv("first_key=first_value second_key")
  except AnsibleParserError as e:
    assert e.message == "Unable to parse argument string"

# Generated at 2022-06-11 09:01:49.794591
# Unit test for function parse_kv
def test_parse_kv():
    print('testing parse_kv')
    try:
        string = "foo=1 bar=2 baz=3"
        res = parse_kv(string)
        assert 'baz' in res and res['baz'] == '3'
    except AssertionError as e:
        print('test failed')
        print(e)
        return False
    try:
        string = u"foo=1 bar=2 baz=3"
        res = parse_kv(string)
        assert 'baz' in res and res['baz'] == '3'
    except AssertionError as e:
        print('test failed')
        print(e)
        return False
    print('passed')
    return True



# Generated at 2022-06-11 09:01:58.545458
# Unit test for function split_args
def test_split_args():
    assert split_args('a=b c="foo bar"') == ['a=b', 'c="foo bar"']
    assert split_args('"{{foo}} bar"') == ['{{foo}} bar']
    assert split_args('"{{foo}} bar" a=b') == ['{{foo}} bar', 'a=b']
    assert split_args('"{{foo}} bar" a=b\nc="foo bar"') == ['{{foo}} bar', 'a=b', 'c="foo bar"']
    assert split_args('"{{foo}} bar" a=b\nc="foo bar"\n') == ['{{foo}} bar', 'a=b', 'c="foo bar"' ]
    assert split_args('"{{foo}} \\"bar"') == ['{{foo}} "bar']

# Generated at 2022-06-11 09:02:07.943954
# Unit test for function split_args

# Generated at 2022-06-11 09:02:19.149212
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('foo=bar') == {'foo': 'bar'}
    assert parse_kv('foo="bar"') == {'foo': 'bar'}
    assert parse_kv('foo="bar=baz"') == {'foo': 'bar=baz'}
    assert parse_kv('foo=bar baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo="bar" baz=foo') == {'foo': 'bar', 'baz': 'foo'}
    assert parse_kv('foo="bar" baz="foo"') == {'foo': 'bar', 'baz': 'foo'}

# Generated at 2022-06-11 09:02:35.634638
# Unit test for function split_args
def test_split_args():
    '''
    Test cases for AnsibleModule._load_params() using a string with args
    '''


# Generated at 2022-06-11 09:02:43.719801
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv(args='creates=/tmp/foo') == {u'creates': u'/tmp/foo'}
    assert parse_kv(args='creates=/tmp/foo removes=/tmp/bar') == {u'creates': u'/tmp/foo', u'removes': u'/tmp/bar'}
    assert parse_kv(args='creates=/tmp/foo removes=/tmp/bar chdir=/tmp') == {u'creates': u'/tmp/foo', u'removes': u'/tmp/bar', u'chdir': u'/tmp'}

    # raw parameters should be taken into account

# Generated at 2022-06-11 09:02:54.405002
# Unit test for function split_args

# Generated at 2022-06-11 09:03:04.895164
# Unit test for function split_args

# Generated at 2022-06-11 09:03:14.894014
# Unit test for function split_args

# Generated at 2022-06-11 09:03:26.926497
# Unit test for function parse_kv
def test_parse_kv():
    options = parse_kv("a = 1 b=2 b = 3")
    assert len(options.keys()) == 2
    for k in options:
        assert k in ["a", "b"], "got an unexpected key %s" % k
    expected_options = {"a": "1", "b": "3"}
    assert options == expected_options, "unexpected results: %s" % str(options)
    options = parse_kv("a='1 b=2' b=3")
    expected_options = {"a": "1 b=2", "b": "3"}
    assert options == expected_options, "unexpected results: %s" % str(options)
    options = parse_kv("a='1 b=\\'2\\'' b=3")

# Generated at 2022-06-11 09:03:35.691141
# Unit test for function split_args
def test_split_args():
    item = "foo='bar baz' {{ foo }}"
    params = split_args(item)
    assert params == ['foo=\'bar baz\'', '{{', 'foo', '}}']

    item = "foo='bar baz' {{ foo }} {% if foo %}foo{% endif %}"
    params = split_args(item)
    assert params == ['foo=\'bar baz\'', '{{', 'foo', '}}', '{%', 'if foo %}foo{% endif %}']

    item = "foo='bar baz' {{ foo }} {% if foo %}foo{% endif %} {# foo #}"
    params = split_args(item)

# Generated at 2022-06-11 09:03:41.130449
# Unit test for function split_args
def test_split_args():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    def split_and_join(args):
        return join_args(split_args(args))

    # Basic tests
    assert split_and_join('a b c') == u'a b c'
    assert split_and_join(' a b c') == u'a b c'
    assert split_and_join('a b c ') == u'a b c'
    assert split_and_join(' a b c ') == u'a b c'
    assert split_and_join(' a b c\n') == u'a b c\n'

    # Quotes inside args should be retained
    assert split_and_join('a "b c" d') == u'a "b c" d'
    assert split_and_

# Generated at 2022-06-11 09:03:52.993818
# Unit test for function parse_kv
def test_parse_kv():
    assert parse_kv('key=value') == {u'key': u'value'}
    assert parse_kv('key1=value1 key2=value2') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv('key1=value1 key2=value2') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv('key1="value1" key2=\'value2\'') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse_kv('key1="value1" key2=value2') == {u'key1': u'value1', u'key2': u'value2'}
    assert parse

# Generated at 2022-06-11 09:03:59.799916
# Unit test for function split_args
def test_split_args():
    assert split_args("mkdir /home/foo") == ['mkdir', '/home/foo']
    assert split_args("mkdir '/home/foo'") == ["mkdir", "'/home/foo'"]
    assert split_args("mkdir \"/home/foo\"") == ['mkdir', '"/home/foo"']
    assert split_args("mkdir '/home/foo/bar/baz'") == ['mkdir', "'/home/foo/bar/baz'"]
    assert split_args("mkdir \"/home/foo/bar/baz\"") == ['mkdir', '"/home/foo/bar/baz"']
    assert split_args("mkdir `/home/foo/bar/baz`") == ['mkdir', '`/home/foo/bar/baz`']
    assert split_