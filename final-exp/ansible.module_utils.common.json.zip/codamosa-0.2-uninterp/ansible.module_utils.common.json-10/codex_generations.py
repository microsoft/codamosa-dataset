

# Generated at 2022-06-16 22:27:41.375000
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:27:53.552235
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # Test unsafe object
    unsafe_text = text_type('secret')
    unsafe_text.__UNSAFE__ = True

# Generated at 2022-06-16 22:28:04.194759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # vault object
    vault_secret = VaultSecret(VaultPassword('secret'))
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')
    vault_object = vault_lib.decrypt(vault_text)
    assert isinstance(vault_object, text_type)
    assert vault_object == 'secret'
    assert AnsibleJSONEncoder().default(vault_object) == {'__ansible_vault': vault_text}

    # unsafe object
    unsafe_object = vault_lib.unsafe

# Generated at 2022-06-16 22:28:17.505456
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:29.195550
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('vault_text', errors='surrogate_or_strict'))
    vault_text_decrypted = vault.decrypt(vault_text)

    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': to_text(vault_text, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-16 22:28:41.657356
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-16 22:28:49.359935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'vault_password'

# Generated at 2022-06-16 22:29:00.641081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_secret = VaultSecret('secret')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')

    vault_obj = vault_lib.decrypt(vault_text)
    unsafe_obj = vault_lib.decrypt(vault_text, unsafe=True)

    assert isinstance(vault_obj, text_type)
    assert isinstance(unsafe_obj, text_type)

    assert vault_obj.__ENCRYPTED__
    assert vault_obj.__UNSAFE__

    assert unsafe_obj.__ENCRYPTED__
    assert unsafe_

# Generated at 2022-06-16 22:29:12.069262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test with vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:29:23.015424
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:29:36.008229
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to

# Generated at 2022-06-16 22:29:47.362288
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:29:58.308867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.module_utils.common._collections_compat import Mapping

    # VaultLib object
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'
    assert getattr(vault_obj, '__ENCRYPTED__', False)

    # Mapping object
    mapping_obj = {'key': 'value'}

# Generated at 2022-06-16 22:30:10.381196
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:30:20.260953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test vault object
    vault_password = 'test'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:32.731427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleUnsafe
    class AnsibleUnsafe(str):
        __UNSAFE__ = True
    class AnsibleUnsafeEncrypted(AnsibleUnsafe):
        __ENCRYPTED__ = True

    encoder = AnsibleJSONEncoder()
    assert encoder.default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert encoder.default(AnsibleUnsafeEncrypted('test')) == {'__ansible_vault': 'test'}

    # Test for datetime.date
    assert encoder.default(datetime.date(2019, 1, 1)) == '2019-01-01'

    # Test for datetime.datetime

# Generated at 2022-06-16 22:30:44.116815
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type

    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSON

# Generated at 2022-06-16 22:30:54.181274
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256

# Generated at 2022-06-16 22:31:05.211950
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test with vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:31:16.923451
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import xrange

    # test for vault object
    vault_password = 'test'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:31:29.682457
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('password')

# Generated at 2022-06-16 22:31:41.080805
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-16 22:31:51.300375
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    class AnsibleUnsafeVault(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class AnsibleUnsafeVault2(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class AnsibleUnsafeVault3(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True


# Generated at 2022-06-16 22:32:00.657854
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:32:11.825372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)
    assert not getattr(vault_obj, '__SAFE__', False)

# Generated at 2022-06-16 22:32:24.034077
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:32:31.471319
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('text')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, string_types)
    assert vault_obj == 'text'
    assert getattr(vault_obj, '__ENCRYPTED__', False)

# Generated at 2022-06-16 22:32:44.520945
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:32:55.481619
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:33:04.023702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(u'vault_text')
    vault_object = vault.decrypt(vault_text)

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_object) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_object) == vault_text

    # Test for unsafe object

# Generated at 2022-06-16 22:33:16.513945
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.common.collections import ImmutableDict

    # test vault object
    vault_password = VaultPassword('test')
    vault_secret = VaultSecret('test', vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:33:22.913830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVTagLen16
    from ansible.parsing.vault import VaultAES256GCMNoIVTagLen8
    from ansible.parsing.vault import VaultAES256GCMNoIVTagLen4

# Generated at 2022-06-16 22:33:32.101225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test for VaultLib
    vault_secret = VaultSecret('test')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_obj = vault_lib.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert isinstance(vault_obj, VaultLib)
    assert vault_obj.__ENCRYPTED__ is True
    assert vault_obj.__UNSAFE__ is False
    assert vault_obj.__repr__() == "VaultLib(VaultSecret('test'))"
    assert vault_

# Generated at 2022-06-16 22:33:43.658232
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # test for vault object
    vault_password = 'test_password'
    vault_text = 'test_vault_text'
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}

# Generated at 2022-06-16 22:33:54.207271
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:03.034802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)

    # test default
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}

    # test vault_to_text
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

# Generated at 2022-06-16 22:34:15.770727
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import xrange

    # test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:34:25.506583
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_bytes

# Generated at 2022-06-16 22:34:35.885142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test vault object

# Generated at 2022-06-16 22:34:45.918378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = text_type(vault.encrypt('secret'))

    # Test default
    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault) == {'__ansible_vault': vault_text}

    # Test vault_to_text
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault) == vault_text

# Generated at 2022-06-16 22:34:58.317464
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(1.0+1.0j) == '1.0+1.0j'
    assert AnsibleJSONEncoder().default('') == ''
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default(u'test') == 'test'
    assert AnsibleJSONEncoder().default(u'\u00e9') == u'\u00e9'

# Generated at 2022-06-16 22:35:06.123042
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:35:17.697984
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    vault = VaultLib([])
    vault_str = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_str)

    # test vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_str}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_str

    # test unsafe object
    assert AnsibleJSONEncoder().default(vault_obj.unwrap()) == {'__ansible_unsafe': 'test'}

# Generated at 2022-06-16 22:35:26.177348
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:35:35.212081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:35:46.958805
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:35:54.824710
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-16 22:36:07.212628
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib([VaultSecret(vault_password)])

# Generated at 2022-06-16 22:36:17.405521
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_bytes, to_text

# Generated at 2022-06-16 22:36:29.449066
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:36:44.729986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    from ansible.parsing.vault import VaultLib

    # Create a vault object
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Create an unsafe object
    class Unsafe(text_type):
        __UNSAFE__ = True

    unsafe_text = Unsafe('secret')

    # Create a mapping object
    mapping = {'a': 'b'}

    # Create a date object
    date = datetime.date(2019, 1, 1)

    # Create a datetime object
    datetime_obj = datetime.datetime(2019, 1, 1, 0, 0, 0)



# Generated at 2022-06-16 22:36:56.688513
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:37:04.740881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import string_types

    # Test vault object
    vault_password = VaultPassword('test')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_obj = vault_lib.encrypt('test')
    assert isinstance(vault_obj, string_types)
    assert vault_obj.__ENCRYPTED__
    assert vault_obj.__UNSAFE__

    # Test unsafe object
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    unsafe_obj = AnsibleUnsafeText

# Generated at 2022-06-16 22:37:15.245688
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import range

    # Test for VaultLib
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == text_type(vault_obj)
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for Mapping

# Generated at 2022-06-16 22:37:26.012477
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type

    # Test for vault object
    vault_password = VaultPassword('password')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')
    vault_obj = vault_lib.decrypt(vault_text)
    assert isinstance(vault_obj, binary_type)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}


# Generated at 2022-06-16 22:37:37.249703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20Poly1305