

# Generated at 2022-06-16 22:27:43.344185
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test vault object
    vault_password = 'test_password'
    vault_obj = VaultLib(vault_password)
    vault_text = 'test_vault'
    vault_ciphertext = vault_obj.encrypt(vault_text)
    vault_obj = vault_obj.decrypt(vault_ciphertext)

    # Test unsafe object
    unsafe_text = 'test_unsafe'
    unsafe_obj = text_type(unsafe_text)
    unsafe_obj.__UNSAFE__ = True

    # Test hostvars object

# Generated at 2022-06-16 22:27:55.168115
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test with a VaultLib object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:28:05.404393
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)

    # Test vault object

# Generated at 2022-06-16 22:28:17.954204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

    # Test for vault object
    vault_password = to_bytes('vault_password')
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt(to_bytes('test_vault'))
    vault_obj = vault.decrypt(ciphertext)

# Generated at 2022-06-16 22:28:30.305329
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:42.927038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:28:54.236002
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    assert isinstance(vault_obj, text_type)
    assert vault_

# Generated at 2022-06-16 22:29:02.939728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('secret'))

    # test vault
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # test unsafe

# Generated at 2022-06-16 22:29:13.913081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTagNoSalt
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTagNoSaltNoIter

# Generated at 2022-06-16 22:29:23.229425
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

# Generated at 2022-06-16 22:29:36.008392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:29:47.362677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'hello world')

    # test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == text_type(vault_text)

    # test unsafe object
    from ansible.module_utils.common._collections_compat import AnsibleUnsafe
    unsafe_text = AnsibleUnsafe(b'hello world')

# Generated at 2022-06-16 22:29:55.245400
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('test', vault_id='test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('test', vault_id='test', vault_password='test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnic

# Generated at 2022-06-16 22:30:07.270431
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:30:18.184831
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:30.776467
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import string_types

# Generated at 2022-06-16 22:30:38.516218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([VaultSecret('password')])
    vault_obj.decrypt('$ANSIBLE_VAULT;1.1;AES256\n3534353933383634353633383630663737643533373566333737353533353633\n3534353933383634353633383630663737643533373566333737353533353633\n')
    assert isinstance(AnsibleJSONEncoder().default(vault_obj), dict)


# Generated at 2022-06-16 22:30:51.438191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for unsafe object
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for hostvars and other

# Generated at 2022-06-16 22:31:02.651486
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.1) == 1.1
    assert AnsibleJSONEncoder().default("") == ""
    assert AnsibleJSONEncoder().default("abc") == "abc"
    assert AnsibleJSONEncoder().default(u"abc") == "abc"
    assert AnsibleJSONEncoder().default([]) == []
    assert AnsibleJSONEncoder().default([1,2,3]) == [1,2,3]
    assert AnsibleJSONEncoder().default({}) == {}

# Generated at 2022-06-16 22:31:14.682806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:25.751779
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import Vault

# Generated at 2022-06-16 22:31:36.801286
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:46.701419
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    test_cases = [
        (vault_obj, {'__ansible_vault': vault_text}),
        (text_type(vault_obj), {'__ansible_vault': vault_text}),
        (vault_text, {'__ansible_vault': vault_text}),
        (text_type(vault_text), {'__ansible_vault': vault_text}),
    ]


# Generated at 2022-06-16 22:31:57.719455
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:32:09.333524
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    encoder = AnsibleJSONEncoder()
    assert encoder.default(object()) == '<object object at 0x7f8b8e8c8b90>'
    assert encoder.default(object()) == '<object object at 0x7f8b8e8c8b90>'
    assert encoder.default(object()) == '<object object at 0x7f8b8e8c8b90>'
    assert encoder.default(object()) == '<object object at 0x7f8b8e8c8b90>'
    assert encoder.default(object()) == '<object object at 0x7f8b8e8c8b90>'

# Generated at 2022-06-16 22:32:21.550231
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Create an instance of AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:32:31.823509
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Create a vault object
    vault_password_file = StringIO()
    vault_password_file.write('vault_password')
    vault_password_file.seek(0)
    vault_obj = VaultLib(vault_password_file)
    vault_text = vault_obj.encrypt('test')

    # Create a unsafe object
    unsafe_text = text_type('test')
    unsafe_text.__UNSAFE__ = True

   

# Generated at 2022-06-16 22:32:44.839634
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTS

# Generated at 2022-06-16 22:32:52.915857
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.datetime(2019, 1, 1, 12, 0, 0)) == '2019-01-01T12:00:00'
    assert encoder.default(datetime.date(2019, 1, 1)) == '2019-01-01'
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default(['a', 1]) == ['a', 1]
    assert encoder.default(1) == 1
    assert encoder.default('a') == 'a'

# Generated at 2022-06-16 22:32:59.307495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:33:14.035624
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'ansible'

# Generated at 2022-06-16 22:33:25.558032
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import text_type

    # test for vault object
    vault_password = 'password'
    vault = VaultLib([])
    vault.update(vault_password, 'test')
    vault_obj = vault.encrypt(to_bytes('test'))
    assert isinstance(vault_obj, text_type)
    assert vault_obj.startswith('$ANSIBLE_VAULT')
    assert vault_obj.endswith('\n')

    # test for unsafe object
    unsafe_obj = to_bytes('test')
    unsafe_obj.__UN

# Generated at 2022-06-16 22:33:37.173115
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:33:47.745806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:33:55.197258
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:34:04.525652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:34:17.413110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_secret = VaultSecret('test')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_text = text_type(vault_text)

    vault_obj = vault_lib.decrypt(vault_text)
    unsafe_obj = vault_obj.__UNSAFE__

    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder

# Generated at 2022-06-16 22:34:26.259700
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:34:36.396988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:34:48.202892
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-16 22:35:01.067586
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves import range

# Generated at 2022-06-16 22:35:13.012135
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_secret = VaultSecret(text_type('foo'))
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt(text_type('bar'))


# Generated at 2022-06-16 22:35:22.358190
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test vault object
    vault_password = 'secret'

# Generated at 2022-06-16 22:35:32.754091
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}
    assert encoder.default(vault_obj) != {'__ansible_vault': 'secret'}
    assert encoder.default(vault_obj) != {'__ansible_vault': vault_obj}

    encoder = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-16 22:35:39.269594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    unsafe_obj = text_type('secret')
    unsafe_obj.__UNSAFE__ = True
    assert Ansible

# Generated at 2022-06-16 22:35:50.028579
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test with vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:35:54.074808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-16 22:36:00.027110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-16 22:36:11.488901
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    # Test for VaultLib
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:36:22.242148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:36:35.049420
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'
    vault = VaultLib(vault_password)

    # Test for vault object
    encoder = AnsibleJSONEncoder(vault_to_text=False)
    encrypted_text = vault.encrypt('secret')
    encrypted_text_obj = text_type(encrypted_text)
    encrypted_text_obj.__ENCRYPTED__ = True
    encrypted_text_obj.__VAULT__ = vault
    assert encoder.default(encrypted_text_obj) == {'__ansible_vault': encrypted_text}

    # Test for vault object with vault_to_text=True
   

# Generated at 2022-06-16 22:36:43.726680
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    # test for vault object
    vault_password = 'test'
    vault_text = 'test'
    vault_obj = VaultLib(vault_password)
    vault_ciphertext = vault_obj.encrypt(vault_text)
    vault_obj = to_bytes(vault_ciphertext, errors='surrogate_or_strict')

    # test for unsafe object
    unsafe_text = 'test'
    unsafe_obj = to_text(unsafe_text, errors='surrogate_or_strict')

    # test for hostvars and other objects
    host

# Generated at 2022-06-16 22:36:55.488226
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for VaultLib
    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:37:04.068836
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_text, to_native
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_human
    from ansible.module_utils.common.text.formatters import to_nice_json_human
    from ansible.module_utils.common.text.formatters import to_nice_yaml_human
    from ansible.module_utils.common.text.formatters import to_nice_json_human_noindent

# Generated at 2022-06-16 22:37:14.845927
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:37:25.828072
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # test default
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}

    # test vault_to_text
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test mapping
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}

    # test mapping with vault

# Generated at 2022-06-16 22:37:37.181728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'test'