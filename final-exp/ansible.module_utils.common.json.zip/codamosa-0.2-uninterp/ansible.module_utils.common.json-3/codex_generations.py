

# Generated at 2022-06-16 22:27:43.277588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 22:27:55.058324
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import zip

    # Test for default
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default('test') == 'test'
    assert encoder.default(u'test') == u'test'
    assert encoder.default(b'test') == b'test'
   

# Generated at 2022-06-16 22:28:05.329874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib([])
    vault_obj.decrypt(to_bytes(vault_password))
    vault_text = vault_obj.encrypt(to_bytes('test'))
    vault_obj = to_text(vault_text, errors='surrogate_or_strict')

# Generated at 2022-06-16 22:28:17.895147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:30.184592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:28:42.828112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:28:49.806411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)
    assert vault_obj == 'test'
    assert isinstance(vault_obj, vault.VaultAccessor)
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test

# Generated at 2022-06-16 22:29:00.944859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:29:12.119271
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test for vault object
    vault_password = 'secret'
    vault_obj = VaultLib([VaultSecret(vault_password)])

# Generated at 2022-06-16 22:29:23.057201
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-16 22:29:35.855339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)
    vault_text = vault_obj.encrypt('secret')
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)
    vault_obj.__ENCRYPTED__ = True
    vault_obj.__VAULT_VERSION__ = 1
    vault_obj.__VAULT_ID__ = '$ANSIBLE_VAULT;1.1;AES256'
    vault_obj.__VAULT_PASSWORD_FILE__ = None
    vault_

# Generated at 2022-06-16 22:29:47.218103
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:29:58.180163
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-16 22:30:10.221107
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:30:20.158604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])

# Generated at 2022-06-16 22:30:32.670067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'hello')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}

    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_obj) == vault_text

    encoder = AnsibleJSONEncoder()
    assert encoder.default(text_type('hello')) == 'hello'

    encoder = AnsibleJSONEncoder()
   

# Generated at 2022-06-16 22:30:44.111981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'test'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:54.179362
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:31:05.249704
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object

# Generated at 2022-06-16 22:31:16.548093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.date(2019, 1, 1)) == '2019-01-01'
    assert encoder.default(datetime.datetime(2019, 1, 1, 1, 1, 1)) == '2019-01-01T01:01:01'
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default(1) == 1
    assert encoder.default('a') == 'a'
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None

# Generated at 2022-06-16 22:31:27.418511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:31:38.570382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # unsafe object
    assert AnsibleJSONEncoder().default(vault_text.__UNSAFE__) == {'__ansible_unsafe': text_type(vault_text.__UNSAFE__)}

# Generated at 2022-06-16 22:31:47.952487
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:31:58.847630
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import range

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:32:10.158575
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:32:22.323939
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:32:33.108802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test vault object

# Generated at 2022-06-16 22:32:46.049697
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:32:54.556539
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    # Test VaultLib
    vault_password = 'password'
    vault = VaultLib([vault_password])
    vault_text = vault.encrypt(to_bytes('test_vault'))
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': to_text(vault_text, errors='surrogate_or_strict', nonstring='strict')}
    assert AnsibleJSONEnc

# Generated at 2022-06-16 22:33:03.581134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 22:33:16.218442
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'hello')

    # Test for vault object
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'hello'
    assert getattr(vault_obj, '__ENCRYPTED__', False)

    # Test for unsafe object
    unsafe_obj = vault.decrypt(vault_text, unsafe=True)
    assert isinstance(unsafe_obj, text_type)
    assert unsafe_obj == 'hello'

# Generated at 2022-06-16 22:33:27.422181
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for default method of class AnsibleJSONEncoder
    # Create an instance of class AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()
    # Create an instance of class AnsibleUnsafe
    unsafe = AnsibleUnsafe('test')
    # Create an instance of class AnsibleVaultEncryptedUnicode
    vault = AnsibleVaultEncryptedUnicode('test')
    # Create an instance of class AnsibleVaultEncryptedFile
    vault_file = AnsibleVaultEncryptedFile('test')
    # Create an instance of class AnsibleVaultEncryptedYaml
    vault_yaml = AnsibleVaultEncryptedYaml('test')
    # Create an instance of class AnsibleVaultEncryptedJson
    vault_json = AnsibleVaultEncryptedJson('test')
    # Create an instance of class

# Generated at 2022-06-16 22:33:39.353235
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json

# Generated at 2022-06-16 22:33:49.198728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:34:00.734473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'ansible'

# Generated at 2022-06-16 22:34:13.198604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:34:23.841676
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types

    # test for vault object
    vault_password = 'password'
    vault_obj = VaultLib([])
    vault_obj.decrypt(to_bytes(vault_password))
    vault_text = vault_obj.encrypt(to_bytes('test_vault_text'))
    vault_obj.decrypt(to_bytes(vault_password))
    vault_obj._ciphertext = vault_text

# Generated at 2022-06-16 22:34:34.958390
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:47.357165
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    vault_obj = AnsibleJSONEncoder(vault_to_text=True).default(dict(__ENCRYPTED__=True, _ciphertext="test"))
    assert vault_obj == "test"

    # Test for unsafe object
    unsafe_obj = AnsibleJSONEncoder(vault_to_text=True).default(dict(__UNSAFE__=True))
    assert unsafe_obj == {'__ansible_unsafe': ''}

    # Test for date object
    date_obj = AnsibleJSONEncoder(vault_to_text=True).default(datetime.date(2018, 1, 1))
    assert date_obj == "2018-01-01"

    # Test for hostvars object

# Generated at 2022-06-16 22:34:56.770109
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTagNoIV

# Generated at 2022-06-16 22:35:12.457538
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # test vault object
    vault_secret = VaultSecret(VaultPassword(b'password'))
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt(b'encrypted_text')
    vault_object = vault_lib.decrypt(vault_text)
    assert isinstance(vault_object, binary_type)
    assert AnsibleJSONEncoder().default(vault_object) == {'__ansible_vault': vault_text}
    assert Ansible

# Generated at 2022-06-16 22:35:21.959452
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:35:29.652225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_secret = VaultSecret('password')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')
    vault_obj = vault_lib.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test unsafe object
    unsafe_obj = vault_lib

# Generated at 2022-06-16 22:35:37.334889
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.module_utils.common.text.converters import to_bytes

    # Test for vault object
    vault_obj = ansible.parsing.vault.VaultLib('test')

# Generated at 2022-06-16 22:35:48.852627
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    encoder = AnsibleJSONEncoder()
    assert encoder.default(text_type('foo')) == 'foo'
    assert encoder.default(VaultLib(b'foo')) == {'__ansible_vault': 'foo'}
    assert encoder.default(VaultLib(b'foo', b'bar')) == {'__ansible_vault': 'foo'}
    assert encoder.default(VaultLib(b'foo', b'bar', b'baz')) == {'__ansible_vault': 'foo'}

# Generated at 2022-06-16 22:35:56.542559
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)

    # Test for vault object with vault_to_text
    vault_obj_vault_to_text = Ansible

# Generated at 2022-06-16 22:36:09.167060
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:36:18.896987
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:36:30.551559
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:36:38.154049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'

# Generated at 2022-06-16 22:36:57.424866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:37:05.206653
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('vault_text')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for unsafe object
    unsafe_obj = text_type('unsafe_text')
    unsafe_obj.__UNSAFE__ = True

# Generated at 2022-06-16 22:37:15.520616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:37:26.188714
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag

# Generated at 2022-06-16 22:37:37.738220
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO as StringIO
    from ansible.parsing.vault import VaultLib

    # Test for vault object