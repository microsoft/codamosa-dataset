

# Generated at 2022-06-16 22:27:44.065197
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_text_unicode = text_type(vault_text)

    # test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text_unicode}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text_unicode

    # test unsafe object
    assert AnsibleJSONEncoder().default(vault_text.__UNSAFE__) == {'__ansible_unsafe': vault_text_unicode}
   

# Generated at 2022-06-16 22:27:55.829334
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:28:05.730564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
   

# Generated at 2022-06-16 22:28:18.138498
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20Poly1305NoIV
    from ansible.parsing.vault import VaultA

# Generated at 2022-06-16 22:28:24.933949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    # test for vault object
    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_obj = VaultLib(vault_secret)

# Generated at 2022-06-16 22:28:37.503589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes(u'vault_text'))
    vault_obj = vault.decrypt(vault_text)

    # test for vault object
    vault_json = to_nice_json(json.dumps(vault_obj, cls=AnsibleJSONEncoder, indent=4, sort_keys=True))

# Generated at 2022-06-16 22:28:47.235533
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:28:58.747310
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test unsafe object
    unsafe_obj = vault.unsafe_text(vault_text)

# Generated at 2022-06-16 22:29:09.901525
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'vault_password'

# Generated at 2022-06-16 22:29:20.140066
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.vault import VaultLib
    from ansible.module_utils.common.text.vars import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    # Test for AnsibleVaultEncryptedUnicode
    vault_password = 'test_password'
    vault_text = 'test_text'
    vault_obj = VaultLib(vault_password).encrypt(vault_text)

# Generated at 2022-06-16 22:29:33.491929
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:29:44.340777
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:29:53.347914
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    vault_obj = AnsibleJSONEncoder(vault_to_text=True).default(object())
    assert vault_obj == '<object object at 0x7f7f9d9d9d90>'

    # Test for unsafe object
    unsafe_obj = AnsibleJSONEncoder().default(object())
    assert unsafe_obj == '<object object at 0x7f7f9d9d9d90>'

    # Test for hostvars and other objects
    hostvars_obj = AnsibleJSONEncoder().default({'a': 'b'})
    assert hostvars_obj == {'a': 'b'}

    # Test for date object
    date_obj = AnsibleJSONEncoder().default(datetime.datetime(2019, 1, 1))

# Generated at 2022-06-16 22:30:04.985336
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.collections import ImmutableDict

    # test vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:11.215425
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six import b
    from ansible.module_utils.six import u
    from ansible.module_utils.six import unichr

# Generated at 2022-06-16 22:30:20.784078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_object = vault.decrypt(vault_text)

    # Test for vault object
    assert isinstance(vault_object, text_type)
    assert AnsibleJSONEncoder().default(vault_object) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_object) == vault_text

    # Test for unsafe object

# Generated at 2022-06-16 22:30:33.268075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:30:45.162485
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote

    # test vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:54.584496
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'

# Generated at 2022-06-16 22:31:05.517612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import Vault

# Generated at 2022-06-16 22:31:19.772455
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.common.unsafe_proxy import wrap_var

    # Test for AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText(u'\u2713')
    assert unsafe_text.__UNSAFE__
    assert not unsafe_text.__ENCRYPTED__
    assert unsafe_text == u'\u2713'
    assert unsafe_

# Generated at 2022-06-16 22:31:30.375678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:31:41.878100
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:31:53.678577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_text) == text_type(vault_text)

    # Test for unsafe object
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.default(vault_text) == {'__ansible_vault': text_type(vault_text._ciphertext)}

    # Test for hostv

# Generated at 2022-06-16 22:32:01.875845
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:32:13.090682
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:32:24.835670
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test vault object
    vault_password = 'test_password'
    vault_obj = VaultLib(vault_password)
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n35373735663465373534386566376537663733366537306635363935653734663635366537\n3635373735663465373534386566376537663733366537306635363935653734663635366537\n'
    vault_obj.decrypt(vault_text)
    assert isinstance

# Generated at 2022-06-16 22:32:37.229514
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url

    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == 'test'

    # Test for AnsibleVaultEncryptedUnicode
    vault_password = 'test'
    vault = VaultLib([])
    vault.read_vault_password_file(StringIO('%s\n' % vault_password))
    vault_

# Generated at 2022-06-16 22:32:43.422133
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'

# Generated at 2022-06-16 22:32:52.936386
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # test vault object

# Generated at 2022-06-16 22:33:13.058819
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:33:24.165416
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText('test')
    assert AnsibleJSONEncoder().default(unsafe_text) == {'__ansible_unsafe': 'test'}

    # Test for VaultLib
    vault_lib = VaultLib('test')
    assert AnsibleJSONEncoder().default(vault_lib) == {'__ansible_vault': 'test'}

    # Test for other types
    assert AnsibleJSONEncoder().default(text_type('test')) == 'test'
    assert AnsibleJSONEncoder().default(1) == 1
   

# Generated at 2022-06-16 22:33:36.182881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode, to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_human
    from ansible.module_utils.common.text.formatters import to_nice_csv
    from ansible.module_utils.common.text.formatters import to_nice_xml
    from ansible.module_utils.common.text.formatters import to_nice_tsv
    from ansible.module_utils.common.text.formatters import to_nice_table

# Generated at 2022-06-16 22:33:47.032959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO

    # Test vault object
    vault_password = 'test'

# Generated at 2022-06-16 22:33:58.498694
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = VaultPassword('password')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_object = vault_lib.decrypt(vault_text)
    assert isinstance(AnsibleJSONEncoder().default(vault_object), text_type)
    assert isinstance(AnsibleJSONEncoder(vault_to_text=True).default(vault_object), text_type)

# Generated at 2022-06-16 22:34:06.143799
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:34:18.559428
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(u'hello world')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == u'hello world'
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)



# Generated at 2022-06-16 22:34:31.589518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO

    # Test vault object
    vault_password = 'vault_password'
    vault_text = 'vault_text'
    vault_obj = VaultLib(vault_password)
    encrypted_text = vault_obj.encrypt(vault_text)
    vault_obj = VaultLib(vault_password)
    decrypted_text = vault_obj.decrypt(encrypted_text)
    assert decrypted_text == vault_text

    # Test unsafe object
    unsafe_text = 'unsafe_text'
    unsafe_obj = unsafe_text.encode('utf-8')

# Generated at 2022-06-16 22:34:44.031769
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'vault_password'
    vault_data = 'vault_data'
    vault_data_encoded = 'vault_data_encoded'

    vault = VaultLib(vault_password)
    vault_encoded = vault.encode(vault_data)

    # test vault object
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_encoded) == vault_data

    # test vault object
    encoder = AnsibleJSONEncoder(vault_to_text=False)

# Generated at 2022-06-16 22:34:51.986842
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'password'

# Generated at 2022-06-16 22:35:18.546691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    encoder = AnsibleJSONEncoder()
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(text_type('test')) == 'test'

# Generated at 2022-06-16 22:35:25.537871
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'encrypted_text')
    vault_text = binary_type(vault_text)

    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

# Generated at 2022-06-16 22:35:34.929316
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}
    assert encoder.default(vault_text) == vault_text
    assert encoder.default(text_type(vault_text)) == text_type(vault_text)

    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_obj) == vault_text


# Generated at 2022-06-16 22:35:46.736534
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:35:54.699216
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:36:06.945726
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:36:17.186079
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:36:29.299777
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import binary_type

    # test vault object
    vault_secret = VaultSecret(VaultPassword('password'))
    vault_lib = VaultLib([vault_secret])
    ciphertext = vault_lib.encrypt('test')
    assert isinstance(ciphertext, binary_type)
    assert ciphertext.startswith(b'$ANSIBLE_VAULT;')
    assert ciphertext.endswith(b'\n')
    assert ciphertext.count(b'\n') == 1
    assert ciphertext.count(b';') == 1

    # test unsafe object

# Generated at 2022-06-16 22:36:38.407942
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import Vault

# Generated at 2022-06-16 22:36:45.501742
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:37:12.939200
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:37:24.453233
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-16 22:37:32.222912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, string_types)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for datetime
    date_obj = datetime.datetime.now()