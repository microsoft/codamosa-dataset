

# Generated at 2022-06-16 22:27:44.849095
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # test vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:27:57.070861
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('vault_text')
    vault_obj = vault.decrypt(vault_text)

    # test for vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test for unsafe object
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    unsafe_obj = AnsibleUnsafeText('unsafe_text')
   

# Generated at 2022-06-16 22:28:06.273058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:18.503942
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type

    # Test for VaultLib
    vault_password = VaultPassword('test')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_lib.encrypt('test')
    assert isinstance(AnsibleJSONEncoder().default(vault_lib), dict)

# Generated at 2022-06-16 22:28:30.992892
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for unsafe object
    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj.__UNSAFE__) == {'__ansible_unsafe': text_type(vault_obj.__UNSAFE__)}

    # Test for hostvars and other objects
   

# Generated at 2022-06-16 22:28:43.585862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:28:55.323630
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import iterval

# Generated at 2022-06-16 22:29:03.638461
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:29:14.410262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-16 22:29:21.149387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('secret')
    vault_obj = vault.decrypt(ciphertext)
    assert isinstance(vault_obj, string_types)
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == 'secret'

# Generated at 2022-06-16 22:29:34.762381
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # Test for vault object
    vault_obj = VaultLib('test')
    vault_obj.decrypt('$ANSIBLE_VAULT;1.1;AES256\n3634356466373764356538646535656436333564373565643466653337353564356534646535\n3634356466373764356538646535656436333564373565643466653337353564356534646535\n')

# Generated at 2022-06-16 22:29:45.487215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:29:54.176350
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_data = 'secret'
    vault = VaultLib(vault_password)
    vault_encoded = vault.encode(vault_data)
    vault_obj = vault.decrypt(vault_encoded)
    assert isinstance(vault_obj, string_types)
    assert vault_obj == vault_data
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert getattr(vault_obj, '__UNSAFE__', False) is False

    # Test for unsafe object

# Generated at 2022-06-16 22:30:06.246073
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-16 22:30:17.362634
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:30:29.712553
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == text_type(vault_text)

    # Test for unsafe object
    assert AnsibleJSONEncoder().default(vault_text.__UNSAFE__) == {'__ansible_unsafe': text_type(vault_text.__UNSAFE__)}

    # Test for host

# Generated at 2022-06-16 22:30:39.744415
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    def _test_encoder(encoder, obj, expected):
        stream = StringIO()
        encoder.encode(obj, stream)
        assert stream.getvalue() == expected

    encoder = AnsibleJSONEncoder()
    _test_encoder(encoder, {'a': 'b'}, '{"a": "b"}')

# Generated at 2022-06-16 22:30:52.149645
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:31:03.466678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:31:15.465490
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test vault object

# Generated at 2022-06-16 22:31:27.241096
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import BytesIO

    # Test for VaultLib
    vault_password = 'test'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for AnsibleUnsafeText

# Generated at 2022-06-16 22:31:38.374017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:31:47.819338
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:31:58.729936
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n35376635373639386533373536653633373466353337333736393735346635333735363533373633\n3735376635373639386533373536653633373466353337333736393735346635333735363533373633\n3735376635373639386533373536653633373466353337333736393735346635333735363533373633\n'

# Generated at 2022-06-16 22:32:10.109883
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('test'))
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for ImmutableDict

# Generated at 2022-06-16 22:32:22.272457
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    class AnsibleUnsafe(text_type):
        __UNSAFE__ = True

    unsafe_obj = AnsibleUn

# Generated at 2022-06-16 22:32:30.689305
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(u'unicode_string')
    vault_bytes = vault.encrypt(b'bytes_string')

    # Test for vault object

# Generated at 2022-06-16 22:32:43.678355
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:32:48.188320
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:33:00.026410
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:33:15.503467
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import map

    import datetime
    import random
    import string
    import sys



# Generated at 2022-06-16 22:33:26.970170
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib([vault_password])

# Generated at 2022-06-16 22:33:38.792296
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for default method of class AnsibleJSONEncoder
    # Arrange
    ansible_json_encoder = AnsibleJSONEncoder()
    test_data = {
        'test_dict': {'test_key': 'test_value'},
        'test_list': ['test_value'],
        'test_str': 'test_value',
        'test_int': 1,
        'test_float': 1.0,
        'test_date': datetime.date(2019, 1, 1),
        'test_datetime': datetime.datetime(2019, 1, 1, 0, 0, 0),
        'test_unsafe': 'test_value',
        'test_vault': 'test_value',
    }

    # Act

# Generated at 2022-06-16 22:33:48.868573
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-16 22:34:00.440948
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:34:12.707935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:34:23.529150
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    vault_obj = AnsibleJSONEncoder(vault_to_text=True).default(object())
    assert vault_obj == '<object object at 0x7f6b9c6f3a70>'

    # Test for unsafe object
    unsafe_obj = AnsibleJSONEncoder(preprocess_unsafe=True).default(object())
    assert unsafe_obj == '<object object at 0x7f6b9c6f3a70>'

    # Test for hostvars and other objects
    hostvars_obj = AnsibleJSONEncoder().default({'a': 1, 'b': 2})
    assert hostvars_obj == {'a': 1, 'b': 2}

    # Test for date object

# Generated at 2022-06-16 22:34:34.697319
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.datetime(2018, 1, 1)) == '2018-01-01T00:00:00'
    assert encoder.default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert encoder.default(datetime.time(1, 2, 3)) == '01:02:03'
    assert encoder.default(datetime.timedelta(1, 2, 3)) == 86400.000003
    assert encoder.default(datetime.timezone(datetime.timedelta(1, 2, 3))) == '+01:02:03'
    assert encoder.default(datetime.timezone(datetime.timedelta(0, -3600))) == '-01:00:00'


# Generated at 2022-06-16 22:34:47.128656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:34:56.615133
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:35:13.447369
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    vault_password = 'test'
    vault = VaultLib(vault_password)

    # test for vault object
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, binary_type)
    assert isinstance(vault_obj, text_type)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test for unsafe object
   

# Generated at 2022-06-16 22:35:22.376218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    # test vault object
    vault_obj = VaultLib([])
    vault_obj.decrypt(b'$ANSIBLE_VAULT;1.1;AES256\n63316236633132366331623663313236633162366331323663316236633132366331623663313236\n63316236633132366331623663313236633162366331323663316236633132366331623663313236\n63316236633132366331623663313236633162366331323663316236633132366331623663313236\n')

# Generated at 2022-06-16 22:35:32.754392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:35:44.868015
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.basic import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3

    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'foo')) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(u'foo')) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEnc

# Generated at 2022-06-16 22:35:53.935075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n333635376638343866373539663733353539333037353064353338306537393435333530333637\n653536363865663739666433353037353064353338306537393435333530333637\n'
    vault_obj._ciphertext = vault_text
    vault_obj.__ENCRY

# Generated at 2022-06-16 22:36:05.227195
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256CBC

# Generated at 2022-06-16 22:36:15.758844
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, string_types)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    unsafe_obj = vault.decrypt(vault_text, output_as_text=True)

# Generated at 2022-06-16 22:36:23.258625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSh

# Generated at 2022-06-16 22:36:33.213930
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:36:42.216089
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_bytes = binary_type(vault_text)

    # Test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_bytes}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # Test unsafe object
    unsafe_text = 'unsafe'
    unsafe_bytes = binary_type(unsafe_text)

# Generated at 2022-06-16 22:36:59.640839
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object

# Generated at 2022-06-16 22:37:06.594644
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:37:16.065990
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_secret = VaultSecret('secret')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('password')

    vault_object = vault_lib.decrypt(vault_text)
    unsafe_object = vault_lib.decrypt(vault_text, unsafe=True)

    assert isinstance(vault_object, text_type)
    assert isinstance(unsafe_object, text_type)

    assert not getattr(vault_object, '__ENCRYPTED__', False)
    assert getattr(unsafe_object, '__UNSAFE__', False)

   

# Generated at 2022-06-16 22:37:26.483830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

# Generated at 2022-06-16 22:37:38.446612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'vault_password'
    vault_text = 'vault_text'
    vault_obj = VaultLib(vault_password)
    ciphertext = vault_obj.encrypt(vault_text)
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(ciphertext)
    assert isinstance(vault_obj, VaultLib)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == vault_text
    assert getattr(vault_obj, '__ENCRYPTED__', False)

    #