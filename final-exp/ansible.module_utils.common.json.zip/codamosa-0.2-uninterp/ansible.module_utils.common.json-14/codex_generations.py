

# Generated at 2022-06-16 22:27:42.348949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:27:54.202122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, text_type

    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEncoder
    # Test for default method of class AnsibleJSONEnc

# Generated at 2022-06-16 22:28:04.742142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:17.620877
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_text_obj = vault.decrypt(vault_text)

    json_encoder = AnsibleJSONEncoder()
    json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)

    assert json_encoder.default(vault_text_obj) == {'__ansible_vault': vault_text}
    assert json_encoder_vault_to_text.default(vault_text_obj) == vault_text

# Generated at 2022-06-16 22:28:26.204129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_password = VaultSecret('password')
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_text) == {'__ansible_vault': u'secret'}
    assert encoder.default(text_type('secret')) == u'secret'

# Generated at 2022-06-16 22:28:38.766552
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('vault_text')

    # test for vault object
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(vault_text) == {'__ansible_vault': vault_text._ciphertext}

    # test for unsafe object
    unsafe_text = text_type(vault_text)
    unsafe_text.__UNSAFE__ = True
    assert ansible_json_encoder.default(unsafe_text) == {'__ansible_unsafe': vault_text._ciphertext}

# Generated at 2022-06-16 22:28:47.905346
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:28:59.371191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_obj = VaultLib(vault_secret)
    encrypted_text = vault_obj.encrypt('secret')
    vault_text = text_type(encrypted_text)

    assert AnsibleJSONEncoder().default(encrypted_text) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(encrypted_text) == vault_text

    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-16 22:29:10.520596
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'password'
    vault = VaultLib([vault_password])
    vault_text = vault.encrypt(to_bytes('secret'))
    vault_text = to_text(vault_text)

    # test vault object
    vault_object = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_object) == 'secret'

# Generated at 2022-06-16 22:29:21.379894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # test vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:29:34.803883
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n'

# Generated at 2022-06-16 22:29:45.539734
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:29:54.448865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:30:06.443847
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    def _assert_encoded_value(value, expected):
        encoder = AnsibleJSONEncoder()
        encoded = encoder.default(value)
        assert encoded == expected

    # Test for vault object

# Generated at 2022-06-16 22:30:17.530766
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test vault object

# Generated at 2022-06-16 22:30:30.088968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # test for vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == text_type(vault_text)
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_text) == {'__ansible_vault': vault_text._ciphertext}

    # test for unsafe object
    unsafe_text = vault.encrypt('secret', unsafe=True)

# Generated at 2022-06-16 22:30:39.936783
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt(b'hello world')
    ciphertext_str = to_text(ciphertext)
    ciphertext_bytes = ciphertext.encode('utf-8')

    # test with string
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(ciphertext_str) == {'__ansible_vault': ciphertext_str}

    # test with bytes
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_enc

# Generated at 2022-06-16 22:30:52.189423
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:31:03.555711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.configparser import NoOptionError
    from ansible.module_utils.six.moves.configparser import NoSectionError
    from ansible.module_utils.six.moves.configparser import ParsingError

    # test for AnsibleUnsafe
    unsafe_str = 'unsafe_str'
    unsafe_str_obj = text_type(unsafe_str)
    unsafe_str_obj.__UNSAFE__ = True
    unsafe_str_obj.__ENCRYPTED__ = False

# Generated at 2022-06-16 22:31:15.560833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:26.837114
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:37.977572
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:31:47.541596
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:31:58.488466
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:32:10.010422
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib

    # Test for AnsibleMapping
    test_dict = {'a': 'b', 'c': 'd'}
    test_dict_obj = AnsibleMapping(test_dict)
    assert AnsibleJSONEncoder().default(test_dict_obj) == test_dict

    # Test for datetime.date
    test_date = datetime.date(2018, 1, 1)
    assert AnsibleJSONEncoder().default(test_date) == '2018-01-01'

    # Test for datetime.datetime

# Generated at 2022-06-16 22:32:22.168992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:32:30.632009
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('vault_text')
    unsafe_text = AnsibleUnsafe('unsafe_text')

    # Test vault object
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(vault_text) == {'__ansible_vault': vault_text._ciphertext}

    # Test unsafe object
    assert json_encoder.default(unsafe_text) == {'__ansible_unsafe': unsafe_text}

    # Test vault_to_text option

# Generated at 2022-06-16 22:32:43.560138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test vault object
    vault_obj = VaultLib([VaultSecret('foo')])
    vault_obj.__ENCRYPTED__ = True
    vault_obj._ciphertext = 'bar'
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': 'bar'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == 'bar'

    # Test unsafe object
    unsafe_obj = vault_obj.__UNSAFE__ = True
    assert AnsibleJSONEncoder().default(unsafe_obj) == {'__ansible_unsafe': 'bar'}

    # Test hostvars object

# Generated at 2022-06-16 22:32:53.002489
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'test'
    vault_obj = VaultLib([])
    vault_obj.password = vault_password

# Generated at 2022-06-16 22:33:02.810766
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTS

# Generated at 2022-06-16 22:33:15.994887
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:33:27.422400
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    # Test for vault object
    vault_secret = VaultSecret('test_secret')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test_text')
    vault_obj = vault_lib.decrypt(vault_text)
    assert isinstance(vault_obj, string_types)
    assert vault_obj == 'test_text'
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert getattr(vault_obj, '__UNSAFE__', False)

# Generated at 2022-06-16 22:33:39.353183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(u'unicode_string')
    vault_bytes = vault.encrypt(b'bytes_string')

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder().default(vault_bytes) == {'__ansible_vault': vault_bytes._ciphertext}

    # Test for unsafe object
    assert AnsibleJSONEncoder().default(u'unicode_string') == u'unicode_string'
    assert AnsibleJSON

# Generated at 2022-06-16 22:33:48.091814
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'

# Generated at 2022-06-16 22:33:55.447480
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:34:04.678129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'

# Generated at 2022-06-16 22:34:17.560800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common.collections import ImmutableDict

    # Test with vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:34:29.393318
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:34:37.915572
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:49.042122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault = VaultLib([])
    vault_text = vault.encrypt(b'password')
    vault_bytes = vault.encrypt(binary_type(b'password', 'utf-8'))

    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder().default(vault_bytes) == {'__ansible_vault': vault_bytes._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_bytes)

# Generated at 2022-06-16 22:35:02.296281
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote_plus

    # Create a vault object

# Generated at 2022-06-16 22:35:14.195510
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import string_types

    # Test for vault object
    vault_password = VaultPassword('test')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_obj = to_text(vault_text, errors='surrogate_or_strict')

# Generated at 2022-06-16 22:35:23.131460
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # Test for unsafe object
    unsafe_text = text_type('test')
    unsafe_text.__UNSAFE__ = True
    assert AnsibleJSONEncoder().default(unsafe_text) == {'__ansible_unsafe': 'test'}

    # Test

# Generated at 2022-06-16 22:35:33.413764
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:35:45.462059
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:35:54.451920
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.common.text.converters import to_bytes

    # Test for VaultLib
    vault_password = VaultPassword('password')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_obj = vault_lib.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'test'

# Generated at 2022-06-16 22:36:06.467440
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import wrap_var

    # Test for AnsibleUnsafe
    value = wrap_var('test')
    assert AnsibleJSONEncoder().default(value) == {'__ansible_unsafe': 'test'}

    # Test for vault object
    value = VaultLib('test')
    assert AnsibleJSONEncoder().default(value) == {'__ansible_vault': 'test'}

    # Test

# Generated at 2022-06-16 22:36:16.824418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:36:28.848403
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3

    # Test for VaultLib
    vault_password = 'test'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)
    vault_encoder = AnsibleJSONEncoder(vault_to_text=True)
    vault_encoder_default = vault_encoder.default(vault_obj)

# Generated at 2022-06-16 22:36:35.893407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import next

# Generated at 2022-06-16 22:36:56.000450
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 22:37:07.127806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    # test vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:37:16.619518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # test vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:37:26.640461
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.vault import VaultLib

    # test for vault object
    vault_password = 'password'
    vault = VaultLib([('default', vault_password)])

# Generated at 2022-06-16 22:37:33.454661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes