

# Generated at 2022-06-16 22:27:44.702065
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to

# Generated at 2022-06-16 22:27:56.911698
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:28:06.184959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:28:18.459731
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}
    assert encoder.default(vault_obj) != vault_text

    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_obj) == vault_text
    assert encoder.default(vault_obj) != {'__ansible_vault': vault_text}



# Generated at 2022-06-16 22:28:30.940864
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import itervalues
    from ansible.module_utils.six import iterkeys
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import xrange
    from ansible.module_utils.six.moves import zip

# Generated at 2022-06-16 22:28:43.544432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'

# Generated at 2022-06-16 22:28:55.278137
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test for vault object
    vault_password = 'vault_password'
    vault = VaultLib([])
    vault.password = vault_password
    vault_text = 'test_vault_text'
    vault_encrypted_text = vault.encrypt(vault_text)
    vault_object = vault.decrypt(vault_encrypted_text)

    # Test for unsafe object
    unsafe_text = 'test_unsafe_text'
    unsafe

# Generated at 2022-06-16 22:29:03.613928
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser

    vault_password_file = StringIO()
    vault_password_file.write('secret')
    vault_password_file.seek(0)

    vault_secrets = ConfigParser()
    vault_secrets.readfp(vault_password_file)

    vault = VaultLib(vault_secrets)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-16 22:29:14.372015
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

# Generated at 2022-06-16 22:29:21.119083
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:29:34.585597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO

    # test vault object

# Generated at 2022-06-16 22:29:45.223138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib

    # test vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:29:53.864429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    # test for vault object
    vault_password = 'password'
    vault = VaultLib([])
    vault_text

# Generated at 2022-06-16 22:30:06.047768
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url, ConnectionError, SSLValidationError, urllib_error
    from ansible.module_utils.urls import Connection
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.urls import url_argument_spec
    from ansible.module_utils.urls import url_to_dict
    from ansible.module_utils.urls import open

# Generated at 2022-06-16 22:30:17.185690
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_text = text_type(VaultLib([], None).encrypt('test'))
    vault_text_encoded = '{"__ansible_vault": "%s"}' % vault_text

    assert AnsibleJSONEncoder().default(VaultLib([], None).encrypt('test')) == vault_text_encoded
    assert AnsibleJSONEncoder(vault_to_text=True).default(VaultLib([], None).encrypt('test')) == vault_text
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 1, 1)) == '2017-01-01T00:00:00'

# Generated at 2022-06-16 22:30:29.455981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-16 22:30:39.549786
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:30:52.149419
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:31:03.465470
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:31:15.465060
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:31:26.799457
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('password')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')

    # test vault object

# Generated at 2022-06-16 22:31:37.976416
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote_plus

    def _test_encoder(encoder, obj, expected):
        stream = StringIO()
        encoder.encode(obj, stream)
        assert stream.getvalue() == expected

    # test vault object
    vault_password = 'test'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:31:47.541721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import integer_types
    from ansible.module_utils.six import PY3

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:31:58.488361
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # Test case for AnsibleUnsafeText
    ansible_unsafe_text = AnsibleUnsafeText(u'ansible_unsafe_text')
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder_result = ansible_json_encoder.default(ansible_unsafe_text)
    assert ansible_json_encoder_result == {'__ansible_unsafe': u'ansible_unsafe_text'}

   

# Generated at 2022-06-16 22:32:10.010495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip


# Generated at 2022-06-16 22:32:22.168555
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'secret'
    vault_obj = VaultLib(vault_password)
    vault_text = vault_obj.encrypt('secret')
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)
    vault_obj_encoded = AnsibleJSONEncoder().default(vault_obj)
    assert isinstance(vault_obj_encoded, dict)
    assert len(vault_obj_encoded) == 1
    assert '__ansible_vault' in vault_obj_encoded
    assert vault_obj_encoded

# Generated at 2022-06-16 22:32:32.847024
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:32:45.815819
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    encoder = AnsibleJSONEncoder()
    assert encoder.default(VaultLib('foo')) == {'__ansible_vault': 'foo'}
    assert encoder.default(text_type('foo')) == 'foo'
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'foo': 'bar'}) == {'foo': 'bar'}


# Generated at 2022-06-16 22:32:54.392561
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    unsafe_obj = vault.unprotect('secret')

# Generated at 2022-06-16 22:33:03.470348
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import Vault

# Generated at 2022-06-16 22:33:17.522756
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:33:27.744687
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:33:39.684154
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)
    assert not getattr(vault_obj, '__SAFE__', False)

    # Test for unsafe object


# Generated at 2022-06-16 22:33:49.435067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # Test vault object
    vault_password = VaultPassword('secret')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')
    vault_obj = vault_lib.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'

    # Test vault object with vault_to_text=True
    encoder = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-16 22:34:00.961365
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:34:13.148334
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:34:18.052691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC

    vault_secret = VaultSecret(VaultPassword([], None))
    vault_aes256 = VaultAES256(vault_secret)
    vault_aes256cbc = VaultAES256CBC(vault_aes256)
    vault_lib = VaultLib(vault_aes256cbc)

    # Test for vault object

# Generated at 2022-06-16 22:34:30.469620
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultChaCha20

# Generated at 2022-06-16 22:34:38.410051
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # Test vault object

# Generated at 2022-06-16 22:34:49.377340
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == text_type(vault_obj)
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # test unsafe object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}

    # test

# Generated at 2022-06-16 22:35:05.828209
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    vault = VaultLib([])
    vault.update(vault_password)

    # test for vault object

# Generated at 2022-06-16 22:35:17.408518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode('test')) == {'__ansible_vault': 'test'}

    # Test for AnsibleVaultEncryptedBytes
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedBytes(b'test')) == {'__ansible_vault': b'test'}

    # Test for dict
    assert AnsibleJSONEncoder().default({'test': 'test'}) == {'test': 'test'}

    # Test for date

# Generated at 2022-06-16 22:35:25.990287
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'hello')
    vault_bytes = vault.encrypt(b'hello')

    # Test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': to_text(vault_text._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == to_text(vault_text, errors='surrogate_or_strict')
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-16 22:35:35.016424
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:35:46.846058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:35:54.775619
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')
    vault_obj = VaultLib(vault_password, StringIO(vault_text))
    assert isinstance(AnsibleJSONEncoder().default(vault_obj), dict)
    assert isinstance(AnsibleJSONEncoder(vault_to_text=True).default(vault_obj), text_type)

    # Test for AnsibleUnsafeText
    from ansible.module_utils.common._collections_compat import AnsibleUnsafeText
   

# Generated at 2022-06-16 22:36:07.105553
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import zip

    # test vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:36:17.319577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:36:29.448927
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:36:38.555362
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:36:58.177225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    encrypted_text = vault.encrypt('test')
    ansible_vault_obj = vault.decrypt(encrypted_text)
    assert AnsibleJSONEncoder(vault_to_text=True).default(ansible_vault_obj) == 'test'
    assert AnsibleJSONEncoder(vault_to_text=False).default(ansible_vault_obj) == {'__ansible_vault': encrypted_text}

    # Test for AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    vault_password = 'password'

# Generated at 2022-06-16 22:37:09.577678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'secret'

# Generated at 2022-06-16 22:37:21.931866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test', vault=True)) == {'__ansible_vault': 'test'}

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-16 22:37:30.026823
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:37:40.941881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_secret = VaultSecret('foo')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('bar')
    vault_obj = vault_lib.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == 'bar'
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # test unsafe object