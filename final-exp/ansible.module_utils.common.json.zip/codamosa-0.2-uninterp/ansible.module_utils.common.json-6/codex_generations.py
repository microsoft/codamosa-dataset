

# Generated at 2022-06-16 22:27:44.446743
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.ansible_galaxy import GalaxyClient

    # Test for VaultLib
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:27:56.566135
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.configparser import NoOptionError

    # Create a vault object

# Generated at 2022-06-16 22:28:06.002035
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for VaultLib
    vault_password = 'password'

# Generated at 2022-06-16 22:28:18.319350
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert encoder.default(datetime.datetime(2018, 1, 1, 12, 0, 0)) == '2018-01-01T12:00:00'
    assert encoder.default(datetime.datetime(2018, 1, 1, 12, 0, 0, 123456)) == '2018-01-01T12:00:00.123456'
    assert encoder.default(datetime.datetime(2018, 1, 1, 12, 0, 0, 123456, datetime.timezone.utc)) == '2018-01-01T12:00:00.123456+00:00'

# Generated at 2022-06-16 22:28:30.890427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # test unsafe object
    unsafe_text = text_type(vault_text)
    unsafe_text.__UNSAFE__ = True
    assert AnsibleJSONEncoder().default(unsafe_text)

# Generated at 2022-06-16 22:28:43.453575
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'secret'

# Generated at 2022-06-16 22:28:55.186564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:29:03.558832
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}

    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    assert AnsibleJSONEnc

# Generated at 2022-06-16 22:29:14.331851
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test case 1: vault object
    vault_password = 'password'
    vault_obj = VaultLib([VaultSecret(vault_password)])

# Generated at 2022-06-16 22:29:25.213143
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:29:36.968691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:29:48.406628
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:29:59.961187
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # Test VaultLib object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # Test AnsibleUnsafeText object

# Generated at 2022-06-16 22:30:12.402253
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:30:21.285564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    encoder = AnsibleJSONEncoder(vault_to_text=False)

# Generated at 2022-06-16 22:30:33.752904
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:30:45.903422
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote


# Generated at 2022-06-16 22:30:54.924614
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:05.737637
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CTS

# Generated at 2022-06-16 22:31:17.039223
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:31:29.443222
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:31:40.830937
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    # Test for default method of class AnsibleJSONEncoder
    # Test for string_types
    for i in xrange(0, 256):
        assert AnsibleJSONEncoder().default(chr(i)) == chr(i)

    # Test for VaultLib
    assert AnsibleJSONEncoder().default(VaultLib()) == {'__ansible_vault': ''}

    # Test for Mapping
    assert AnsibleJSONEncoder().default({'a': 1}) == {'a': 1}

    # Test for datetime.date

# Generated at 2022-06-16 22:31:48.801595
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # Test for vault object
    vault_password = 'vault_password'

# Generated at 2022-06-16 22:31:59.404465
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Create a vault object
    vault_password = 'vault_password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:32:10.633071
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:32:22.782661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.basic import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.basic import AnsibleVaultEncryptedBytes
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    import datetime

    # Test for AnsibleUnsafe
    ansible_unsafe = AnsibleUnsafe('test')
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder_result = ansible_json_encoder.default(ansible_unsafe)
    assert ansible_json_encoder_result == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnicode


# Generated at 2022-06-16 22:32:33.875328
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.common.collections import ImmutableDict

    # test for vault object
    vault_secret = VaultSecret(VaultPassword('password'))
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('test')
    vault_object = vault_lib.decrypt(vault_text)
    assert isinstance(vault_object, text_type)
    assert vault_object == 'test'

# Generated at 2022-06-16 22:32:46.717250
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'ansible'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('ansible')
    vault_text_unicode = text_type(vault_text)

    # test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text_unicode}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text_unicode

    # test for unsafe object
    assert AnsibleJSONEncoder().default(vault_text_unicode) == vault_text_unicode

# Generated at 2022-06-16 22:32:58.880976
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256

# Generated at 2022-06-16 22:33:10.749709
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:33:20.071303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    o = AnsibleJSONEncoder(vault_to_text=True).default(object())
    assert o == '<object object at 0x7f6d0c0e5a40>'

    # Test for unsafe object
    o = AnsibleJSONEncoder(vault_to_text=True).default(object())
    assert o == '<object object at 0x7f6d0c0e5a40>'

    # Test for hostvars and other objects
    o = AnsibleJSONEncoder(vault_to_text=True).default(dict())
    assert o == {}

    # Test for date object
    o = AnsibleJSONEncoder(vault_to_text=True).default(datetime.datetime.now())
    assert o == datetime.datetime.now().iso

# Generated at 2022-06-16 22:33:29.815720
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:33:41.736268
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:33:52.109206
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 22:34:02.489039
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode('test')) == {'__ansible_vault': 'test'}

# Generated at 2022-06-16 22:34:15.242873
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    # Test for VaultLib
    vault_password = 'password'

# Generated at 2022-06-16 22:34:25.168171
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:35.624994
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:47.790142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:34:57.144412
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault_obj = VaultLib([vault_password])

# Generated at 2022-06-16 22:35:13.012441
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # Test for VaultLib
    vault_password = VaultPassword('password')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)
    vault_lib.update({'key': 'value'})
    vault_lib.update({'key2': 'value2'})
    vault_lib.update({'key3': 'value3'})
    vault_lib.update({'key4': 'value4'})
    vault_lib.update({'key5': 'value5'})

# Generated at 2022-06-16 22:35:22.138345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultAES128CBC

# Generated at 2022-06-16 22:35:32.494822
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:35:44.578516
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # test for vault object

# Generated at 2022-06-16 22:35:53.712178
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'vault_password'
    vault_text = 'vault_text'
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    unsafe_text = 'unsafe_text'


# Generated at 2022-06-16 22:36:05.115591
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes

    # Test for vault object
    from ansible.parsing.vault import VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('test'))
    vault_object = vault.decrypt(vault_text)
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(vault_object) == {'__ansible_vault': vault_text}

    # Test for unsafe object
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:36:11.605351
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}
    assert encoder.default(vault_text) == vault_text
    assert encoder.default(text_type(vault_text)) == text_type(vault_text)

# Generated at 2022-06-16 22:36:22.402644
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) == None
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default('str') == 'str'
    assert encoder.default(u'unicode') == u'unicode'
    assert encoder.default(['list']) == ['list']
    assert encoder.default(('tuple',)) == ('tuple',)
    assert encoder.default({'dict': 'dict'}) == {'dict': 'dict'}

# Generated at 2022-06-16 22:36:33.020815
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'

# Generated at 2022-06-16 22:36:42.042238
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote

    # Test for vault object
    vault_password = 'vault_password'
    vault_text = 'vault_text'
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # Test

# Generated at 2022-06-16 22:37:00.309188
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    # Test for VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)

# Generated at 2022-06-16 22:37:12.093664
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:37:23.841646
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:37:30.591091
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:37:41.306054
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    # Test for vault object
    vault_obj = VaultLib([])