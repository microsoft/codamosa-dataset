

# Generated at 2022-06-16 22:27:43.637432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError

    # vault object
    vault_password = 'secret'
    vault_obj = VaultLib(vault_password)
    vault_obj.encrypt_string('secret')
    vault_obj_encoded = AnsibleJSONEncoder().default(vault_obj)
    assert isinstance(vault_obj_encoded, dict)

# Generated at 2022-06-16 22:27:55.219829
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-16 22:28:05.442312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault_obj = VaultLib(vault_password)
    vault_text = vault_obj.encrypt('secret')
    vault_obj = vault_obj.decrypt(vault_text)

    # Test vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test unsafe object
    unsafe_obj = vault_obj.unlock('secret')

# Generated at 2022-06-16 22:28:17.947567
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_kilobytes
    from ansible.module_utils.common.text.formatters import kilobytes_to_human
    from ansible.module_utils.common.text.formatters import to_bytes as to_bytes_formatter

# Generated at 2022-06-16 22:28:30.241623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_text_bytes = vault_text.encode('utf-8')
    vault_text_unicode = vault_text.decode('utf-8')

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text_bytes}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text_unicode

    # Test for unsafe object
   

# Generated at 2022-06-16 22:28:42.875046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES

# Generated at 2022-06-16 22:28:49.849499
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import xrange

    # test vault object
    vault_password = 'ansible'
    vault_obj = VaultLib([])
    vault_obj.update(vault_password, 'test')
    vault_obj.update(vault_password, 'test2')
    vault_obj.update(vault_password, 'test3')

# Generated at 2022-06-16 22:29:00.986197
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:29:12.115542
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('secret')
    vault_secret = VaultSecret(ciphertext)
    json_encoder = AnsibleJSONEncoder()
    json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)
    assert json_encoder.default(vault_secret) == {'__ansible_vault': ciphertext}
    assert json_encoder_vault_to_text.default(vault_secret) == text_type(vault_secret)



# Generated at 2022-06-16 22:29:23.058364
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    # test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:29:36.076552
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    # Test vault object
    vault_password = 'password'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:29:47.455066
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:29:58.439862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:30:10.553670
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-16 22:30:20.366177
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import xrange

    # test vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:30:32.839214
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'secret'
    vault_obj = VaultLib(vault_password)

# Generated at 2022-06-16 22:30:44.565790
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:30:54.298275
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import AnsibleUnsafe

    # test vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:31:05.322520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_text}

    # test unsafe object
    unsafe_obj = text_type('unsafe')
    unsafe_obj.__UNSAFE

# Generated at 2022-06-16 22:31:16.912711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'

# Generated at 2022-06-16 22:31:27.774073
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote

    # Test for vault object
    vault_password = 'test'
    vault = VaultLib([])
    vault.update(vault_password, 'test')
    vault_text = vault.dump()

    # Test for unsafe object
    unsafe_text = 'test'
    unsafe = text_type(unsafe_text)
    unsafe.__UNSAFE__ = True

    # Test for hostvars and other objects
    hostvars = {'test': 'test'}

    # Test for date object

# Generated at 2022-06-16 22:31:38.973413
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.vars import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    # test default
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.1) == 1.1
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default(u'test') == u'test'


# Generated at 2022-06-16 22:31:45.852337
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text


# Generated at 2022-06-16 22:31:57.180071
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    # Test default
    assert json.dumps(dict(a=1), cls=AnsibleJSONEncoder) == '{"a": 1}'

    # Test datetime
    assert json.dumps(dict(a=datetime.datetime(2018, 1, 1, 1, 1, 1)), cls=AnsibleJSONEncoder) == '{"a": "2018-01-01T01:01:01"}'

    # Test vault
    vault_password = 'test'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('test')

# Generated at 2022-06-16 22:32:08.417341
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    vault_obj = vault.decrypt(vault_text)
    assert isinstance(vault_obj, text_type)
    assert vault_obj == 'secret'
    assert getattr(vault_obj, '__ENCRYPTED__', False)
    assert not getattr(vault_obj, '__UNSAFE__', False)

    vault_encoded = AnsibleJSONEncoder().default(vault_obj)
    assert isinstance(vault_encoded, dict)

# Generated at 2022-06-16 22:32:20.885242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:32:29.853184
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:32:42.395324
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:32:52.414738
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoPadding
    from ansible.parsing.vault import VaultAES256GCMNoPaddingV1
    from ansible.parsing.vault import VaultAES256GCMNoPaddingV2
    from ansible.parsing.vault import VaultAES256GCMNoPaddingV3

# Generated at 2022-06-16 22:33:02.676276
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:33:17.077569
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([VaultSecret('password')])

# Generated at 2022-06-16 22:33:24.218076
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO as StringIO

    # test vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:33:36.182880
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'vault_password'
    vault_text = 'vault_text'
    vault_ciphertext = VaultLib(vault_password).encrypt(vault_text)
    vault_obj = to_text(vault_ciphertext, errors='surrogate_or_strict')

    # test vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

# Generated at 2022-06-16 22:33:47.033013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    # Test for vault object

# Generated at 2022-06-16 22:33:58.498139
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import range

    # Test for unsafe object
    unsafe_obj = AnsibleUnsafe(u'unsafe')
    assert AnsibleJSONEncoder().default(unsafe_obj) == {'__ansible_unsafe': u'unsafe'}

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:34:06.143678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'encrypted text')

    # Test for vault object
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(vault_text) == {'__ansible_vault': vault_text._ciphertext}

    # Test for unsafe object
    unsafe_text = text_type(vault_text)
    unsafe_text.__UNSAFE__ = True
    assert ansible_json_encoder.default(unsafe_text) == {'__ansible_unsafe': unsafe_text}

    # Test for mapping object

# Generated at 2022-06-16 22:34:18.559428
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'password'
    vault_obj = VaultLib(vault_password)
    vault_text = vault_obj.encrypt(to_bytes('test'))
    vault_text = to_text(vault_text, errors='surrogate_or_strict')
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}

# Generated at 2022-06-16 22:34:31.594799
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:34:44.030520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # Test for vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == text_type(vault_text)
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_text) == {'__ansible_vault': vault_text}

    # Test for unsafe object
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(vault_text) == {'__ansible_unsafe': text_type(vault_text)}

    # Test for

# Generated at 2022-06-16 22:34:52.912716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:35:14.034957
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib

    # Test for AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test for AnsibleVault
    vault_password = 'test'
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt('test')
    assert AnsibleJSONEncoder().default(AnsibleVault(ciphertext)) == {'__ansible_vault': ciphertext}

    # Test for AnsibleMapping

# Generated at 2022-06-16 22:35:23.022953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test for vault object

# Generated at 2022-06-16 22:35:33.336126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    vault_password = 'password'

# Generated at 2022-06-16 22:35:45.383947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type

    # test for vault object
    vault_password = VaultPassword('test_password')
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:35:54.391996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    vault_secret = VaultSecret('secret')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('secret')

    # test for vault object
    ansible_json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-16 22:36:06.365767
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:36:16.690899
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import xrange

    # Test VaultLib
    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('text')
    vault_bytes = vault.encrypt(b'bytes')
    vault_int = vault.encrypt(1)
    vault_float = vault.encrypt(1.0)
    vault_list = vault.encrypt([1, 2, 3])
    vault_dict = vault.encrypt({'a': 1, 'b': 2})
    vault_tuple = vault.encrypt((1, 2, 3))

# Generated at 2022-06-16 22:36:28.647193
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type


# Generated at 2022-06-16 22:36:35.731987
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:36:42.899344
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-16 22:37:12.800828
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:37:24.368849
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-16 22:37:30.872097
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password = VaultSecret('password')
    vault_lib = VaultLib(vault_password)
    vault_text = vault_lib.encrypt('secret')

    # Test default method of class AnsibleJSONEncoder
    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

    # Test for unsafe object
    assert AnsibleJSONEncoder().default(vault_text.unsafe_proxy) == {'__ansible_unsafe': vault_text.unsafe_proxy}