

# Generated at 2022-06-16 22:27:45.039216
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    encrypted_text = vault.encrypt(b'foo')
    assert AnsibleJSONEncoder().default(encrypted_text) == {'__ansible_vault': encrypted_text._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(encrypted_text) == encrypted_text

    # Test for AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    unsafe_text = vault.unprotect_text(b'foo')
    assert AnsibleJSONEncoder().default(unsafe_text) == {'__ansible_unsafe': unsafe_text}

    # Test for dict


# Generated at 2022-06-16 22:27:57.280472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n6331623663316236633162366331623663316236633162366331623663316236\n6236633162366331623663316236633162366331623663316236633162366336\n3362366331623663316236633162366331623663316236633162366331623663\n6633162366331623663316236633162366331623663316236633162366331623\n3\n'
   

# Generated at 2022-06-16 22:28:06.389795
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20Poly1305

# Generated at 2022-06-16 22:28:18.502676
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:28:30.945072
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:28:43.544478
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    # Test for encrypted vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:28:55.277418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultAES256OFB

# Generated at 2022-06-16 22:29:03.613474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:29:14.372228
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO

    # Test for vault object
    vault_password = 'password'

# Generated at 2022-06-16 22:29:19.187585
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(to_bytes('secret'))

    # test vault object
    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': to_text(vault_text._ciphertext, errors='surrogate_or_strict', nonstring='strict')}

    # test vault object with vault_to_text
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == to_text

# Generated at 2022-06-16 22:29:32.342199
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib([(vault_password,)])
    vault_secret = VaultSecret(vault_password)

    # test for vault object

# Generated at 2022-06-16 22:29:39.368782
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(vault_obj) == {'__ansible_vault': vault_text}
    assert encoder.default(vault_obj) != vault_text

    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(vault_obj) == vault_text
    assert encoder.default(vault_obj) != {'__ansible_vault': vault_text}



# Generated at 2022-06-16 22:29:44.942919
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt(b'hello world')
    vault_bytes = vault.encrypt(binary_type(b'hello world', 'utf-8'))

    # test vault object

# Generated at 2022-06-16 22:29:53.695947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault = VaultLib(vault_secret)

    # vault object

# Generated at 2022-06-16 22:30:05.789414
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:30:16.962443
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # test vault object
    vault_obj = VaultLib('test')

# Generated at 2022-06-16 22:30:29.149890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultChaCha20
    from ansible.parsing.vault import VaultChaCha20Poly1305
    from ansible.parsing.vault import VaultChaCha20IETF


# Generated at 2022-06-16 22:30:39.310577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for vault object
    class Vault:
        __ENCRYPTED__ = True

# Generated at 2022-06-16 22:30:52.065442
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:31:03.375429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test vault object

# Generated at 2022-06-16 22:31:18.232748
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type

    # Test for vault object

# Generated at 2022-06-16 22:31:27.118868
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text

    # test vault object
    vault_password = 'password'
    vault_text = 'test'
    vault_obj = VaultLib(vault_password)
    vault_obj.decrypt(to_bytes(vault_text))
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder(vault_to_text=False).default(vault_obj) == {'__ansible_vault': vault_obj._ciphertext}

    # test unsafe object
    unsafe_text = 'test'

# Generated at 2022-06-16 22:31:38.278503
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256GCMNoIV
    from ansible.parsing.vault import VaultAES256GCMNoIVNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTag
    from ansible.parsing.vault import VaultAES256GCMNoTagNoIV

# Generated at 2022-06-16 22:31:47.785254
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(['test', 1, 1.0, True, False, None]) == ['test', 1, 1.0, True, False, None]

# Generated at 2022-06-16 22:31:58.730317
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # test vault object
    vault_password = 'password'
    vault_obj = VaultLib([vault_password])

# Generated at 2022-06-16 22:32:10.110085
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_obj = vault.decrypt(vault_text)

    # test vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # test unsafe object
    assert AnsibleJSONEncoder().default(vault_text) == vault_text
    assert AnsibleJSONEncoder().default(text_type(vault_text)) == vault_text

    # test date

# Generated at 2022-06-16 22:32:22.324018
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:32:30.717378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:32:43.678318
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault = VaultLib([])
    vault_text = vault.encrypt('foo')
    vault_obj = vault.decrypt(vault_text)

    # Test for vault object
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text

    # Test for unsafe object
    assert AnsibleJSONEncoder().default(vault_text) == vault_text
    assert AnsibleJSONEncoder().default(text_type(vault_text)) == text_type(vault_text)

    # Test for hostvars and other

# Generated at 2022-06-16 22:32:48.188511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')

    # test with vault object
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-16 22:33:04.023879
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:33:15.332043
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test for VaultLib
    vault_secret = VaultSecret('password')
    vault_lib = VaultLib(vault_secret)
    vault_text = vault_lib.encrypt('text')
    vault_obj = vault_lib.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}

    # Test for VaultSecret
    assert AnsibleJSONEncoder().default(vault_secret) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}

    # Test for datetime.date

# Generated at 2022-06-16 22:33:26.822194
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:33:38.616740
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_password = 'password'
    vault = VaultLib([vault_password])

# Generated at 2022-06-16 22:33:48.742473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256CFB1

# Generated at 2022-06-16 22:34:00.301985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('vault_password')

# Generated at 2022-06-16 22:34:12.440510
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:34:23.410898
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # test for vault object
    vault_obj = VaultLib([])
    vault_obj.password = 'test'

# Generated at 2022-06-16 22:34:34.565473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    # Test for vault object
    vault_obj = VaultLib('password')

# Generated at 2022-06-16 22:34:47.035089
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-16 22:35:14.461204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:35:23.918365
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test for VaultLib
    vault_password = 'password'
    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib(vault_secret)

# Generated at 2022-06-16 22:35:33.796413
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO


# Generated at 2022-06-16 22:35:45.827084
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.vars import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.vars import AnsibleVaultEncryptedBytes

    # test for AnsibleUnsafe
    unsafe_unicode = AnsibleUnsafe(to_unicode('test'))
    unsafe_bytes = AnsibleUnsafe(to_bytes('test'))
    assert AnsibleJSONEncoder().default(unsafe_unicode) == {'__ansible_unsafe': 'test'}

# Generated at 2022-06-16 22:35:54.536392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_password = 'password'
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt('secret')
    vault_bytes = vault.encrypt(b'secret')

    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': vault_text._ciphertext}
    assert AnsibleJSONEncoder().default(vault_bytes) == {'__ansible_vault': vault_bytes._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == vault_text

# Generated at 2022-06-16 22:36:06.687830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('test')
    vault_obj = vault.decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': vault_text}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == vault_text
    assert AnsibleJSONEncoder().default({'test': vault_obj}) == {'test': {'__ansible_vault': vault_text}}
    assert AnsibleJSONEncoder(vault_to_text=True).default({'test': vault_obj}) == {'test': vault_text}

# Generated at 2022-06-16 22:36:15.081065
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_password = 'password'
    vault = VaultLib(vault_password)

    # Test for encrypted vault
    encrypted_vault = vault.encrypt('test_vault')
    assert isinstance(encrypted_vault, text_type)
    assert encrypted_vault.startswith('$ANSIBLE_VAULT')

    # Test for decrypted vault
    decrypted_vault = vault.decrypt(encrypted_vault)
    assert isinstance(decrypted_vault, text_type)
    assert decrypted_vault == 'test_vault'

    # Test for encrypted vault with vault_to_text

# Generated at 2022-06-16 22:36:22.837597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES192

# Generated at 2022-06-16 22:36:33.054695
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256

# Generated at 2022-06-16 22:36:42.077249
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import SSLValidationError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import NoSSLError
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.urls import No

# Generated at 2022-06-16 22:37:09.576948
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultAES256CTR
    from ansible.parsing.vault import VaultAES256XTS
    from ansible.parsing.vault import VaultAES256OFB
    from ansible.parsing.vault import VaultAES256CFB
    from ansible.parsing.vault import VaultAES256EAX

# Generated at 2022-06-16 22:37:21.930237
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for vault object
    vault_obj = AnsibleJSONEncoder(vault_to_text=True).default(dict(__ENCRYPTED__=True, _ciphertext='test'))
    assert vault_obj == 'test'

    # test for unsafe object
    unsafe_obj = AnsibleJSONEncoder().default(dict(__UNSAFE__=True, _ciphertext='test'))
    assert unsafe_obj == {'__ansible_unsafe': 'test'}

    # test for hostvars and other objects
    hostvars_obj = AnsibleJSONEncoder().default(dict(a=1, b=2))
    assert hostvars_obj == {'a': 1, 'b': 2}

    # test for date object

# Generated at 2022-06-16 22:37:29.486124
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test vault object
    vault_obj = VaultLib([])

# Generated at 2022-06-16 22:37:40.477653
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO

    vault_password = 'vault_password'