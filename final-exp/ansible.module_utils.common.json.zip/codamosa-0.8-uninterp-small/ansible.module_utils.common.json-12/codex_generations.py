

# Generated at 2022-06-24 20:25:15.053914
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # AssertionError: assert False


# Generated at 2022-06-24 20:25:17.092714
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(o=0)



# Generated at 2022-06-24 20:25:25.108625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    json_encoder_0 = json.JSONEncoder()

    from ansible.parsing.vault import VaultSecret
    result_0_0 = ansible_j_s_o_n_encoder_1.default(VaultSecret("test"))
    result_0_1 = json_encoder_0.default(VaultSecret("test"))
    # assert result_0_0 == result_0_1

    from ansible.parsing.vault import VaultSecret
    # ansible_unsafe = ansible.parsing.vault.UnixTimestampValue()
    ansible_unsafe = VaultSecret("test")

# Generated at 2022-06-24 20:25:33.544549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
# src/ansible/module_utils/basic.py
# -*- coding: utf-8 -*-
# Copyright (c) 2018 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import base64
import collections
import errno
import getpass
import itertools
import json
import locale
import os
import random
import re
import shlex
import shutil
import socket
import stat
import string
import tempfile
import types
import warnings

from abc import ABCMeta
from collections import default

# Generated at 2022-06-24 20:25:37.538364
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value1 = AnsibleJSONEncoder()
    value2 = AnsibleJSONEncoder()

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:25:40.429686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    with pytest.raises(Exception):
        ansible_j_s_o_n_encoder_0.default('')



# Generated at 2022-06-24 20:25:42.377757
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    method_default_0 = ansible_j_s_o_n_encoder_0.default
    assert method_default_0 is not None


# Generated at 2022-06-24 20:25:45.332030
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder.default('Python is cool!')

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_0.default('Python is cool!')


# Generated at 2022-06-24 20:25:51.756373
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_date_0 = datetime.date.today()
    # Default state
    ansible_j_s_o_n_encoder_0.default(datetime_date_0)


# Generated at 2022-06-24 20:26:00.733036
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_text

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test the first case

    # Test the second case


# Generated at 2022-06-24 20:26:04.636762
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:08.889640
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = 'AnsibleVaultEncryptedUnicode'
    result = ansible_j_s_o_n_encoder_0.default(ansible_vault_0)
    assert result == ansible_vault_0


# Generated at 2022-06-24 20:26:12.041746
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default(ansible_j_s_o_n_encoder_0, {'ansible_facts': {'hostvars': {'host': {}}}})


# Generated at 2022-06-24 20:26:20.152493
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)


# Generated at 2022-06-24 20:26:21.573330
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:32.337602
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for case when UNSAFE Attribute exists
    unsafe_string_0 = to_text('something', errors='surrogate_or_strict')
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default(unsafe_string_0)
    # Test for case when UNSAFE Attribute not exists
    unsafe_string_1 = to_text('something', errors='surrogate_or_strict')
    ansible_json_encoder_1 = AnsibleJSONEncoder()
    ansible_json_encoder_1.default(unsafe_string_1)
    # Test for case when object inherits from Mapping
    mapping_object_0 = dict()
    ansible_json_encoder_2 = AnsibleJSONEncoder()
    ansible

# Generated at 2022-06-24 20:26:37.449686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(None) == json.JSONEncoder.default(ansible_j_s_o_n_encoder_0, None)


# Generated at 2022-06-24 20:26:45.260318
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value_0 = ansible_j_s_o_n_encoder_0.default(datetime.datetime(2020, 7, 8, 4, 58, 4))
    assert value_0 == '2020-07-08T04:58:04', "ansible_j_s_o_n_encoder_0.default(datetime.datetime(2020, 7, 8, 4, 58, 4)) == '2020-07-08T04:58:04'"
    assert isinstance(value_0, str), "assert isinstance(value_0, str)"
    value_1 = ansible_j_s_o_n_encoder_0.default(datetime.date(2020, 4, 1))
    assert value_

# Generated at 2022-06-24 20:26:55.648394
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    class MockClass:
        pass

    mock_object = MockClass()
    mock_object.__vault__ = None
    mock_object.__ansible_vault = None
    # Make sure an unhandled type causes a pass
    assert ansible_j_s_o_n_encoder_0.default(mock_object) == mock_object
    mock_object.__ansible_unsafe = 'test'
    # Make sure an unhandled type causes a pass
    assert ansible_j_s_o_n_encoder_0.default(mock_object) == mock_object
    mock_object.__ansible_vault = 'test'
    assert ansible_j_s_o_n_encoder

# Generated at 2022-06-24 20:27:00.358811
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(["unsafe object", "__ansible_unsafe", "\u2713"]) == ['unsafe object', '__ansible_unsafe', '\u2713']


# Generated at 2022-06-24 20:27:10.921949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:27:16.715499
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default([])
    assert ansible_j_s_o_n_encoder_0_default == []


# Generated at 2022-06-24 20:27:20.704862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_1.default("test_object_0")
    assert(result == "test_object_0")


# Generated at 2022-06-24 20:27:28.375446
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder_0.default('ansible_string_0') == 'ansible_string_0'
    assert ansible_j_s_o_n_encoder_0.default(0) == 0
    assert ansible_j_s_o_n_encoder_0.default(True) == True
    assert isinstance(ansible_j_s_o_n_encoder_0.default('ansible_string_1'), str)
    assert isinstance(ansible_j_s_o_n_encoder_0.default(1), int)
    assert isinstance(ansible_j_s_o_n_encoder_0.default(True), bool)

# Generated at 2022-06-24 20:27:29.423427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:32.086564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:27:34.140441
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:27:37.726766
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(o={}) == {}


# Generated at 2022-06-24 20:27:40.423463
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:42.109556
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:46.778334
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0_default = AnsibleJSONEncoder.default(ansible_j_s_o_n_encoder_0, 'foo')


# Generated at 2022-06-24 20:27:54.868322
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_0 = ansible_v_a_u_l_t(value='ansible-vault-value', cipher='ansible-vault-cipher', salt='ansible-vault-salt')
    ansible_u_n_s_a_f_e_0 = ansible_u_n_s_a_f_e(value='ansible-unsafe-value')

# Generated at 2022-06-24 20:28:02.744610
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True)
    assert ansible_j_s_o_n_encoder_0.default(False) == False
    assert ansible_j_s_o_n_encoder_0.default(0) == 0
    assert ansible_j_s_o_n_encoder_0.default(0.0) == 0.0


# Generated at 2022-06-24 20:28:04.990862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_0 = AnsibleUnsafe()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:28:16.355262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    # First parameter: test_case_0
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Second parameter: test_case_0
    o_0 = '__ansible_unsafe'
    ansible_json_encoder_default_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    # First parameter: test_case_1
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # Second parameter: test_case_1
    o_1 = '__ansible_vault'

# Generated at 2022-06-24 20:28:19.200797
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('foo')


# Generated at 2022-06-24 20:28:21.644203
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = {
    }
    result = ansible_j_s_o_n_encoder_1.default(o)


# Generated at 2022-06-24 20:28:24.288732
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # An error should be raised for an unexpected input
    try:
        ansible_j_s_o_n_encoder_1.default('Hello')
    except AttributeError:
        pass


# Generated at 2022-06-24 20:28:27.747279
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    if ansible_j_s_o_n_encoder_0.default(o) != value:
        raise AssertionError('AnsibleJSONEncoder.default should return instance of int')


# Generated at 2022-06-24 20:28:32.320729
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default({})
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:28:35.407189
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder.default(1)


# Generated at 2022-06-24 20:28:38.073209
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)


# Generated at 2022-06-24 20:28:42.226221
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('abc')


# Generated at 2022-06-24 20:28:44.818973
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:28:55.527588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:28:56.626443
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:29:04.142973
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Assigning a type to the variable 'o' (line 90)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 90, 4), 'o', remove_type_from_union(o_78898, types.NoneType))
    
    # Call to default(...): (line 90)
    # Processing the call arguments (line 90)
    # Getting the type of 'o' (line 90)
    o_78901 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 90, 21), 'o', False)
    # Processing the call keyword arguments (line 90)
    kwargs_789

# Generated at 2022-06-24 20:29:09.747161
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder()
    data = [
        # test_data, expected
        ('test-data', 'test-data'),
    ]

    for test_data, expected in data:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        result = o.default(ansible_j_s_o_n_encoder_0)
        assert result == expected


# Generated at 2022-06-24 20:29:17.129679
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default("str") == "str"
    assert ansible_j_s_o_n_encoder_0.default(1) == 1
    assert ansible_j_s_o_n_encoder_0.default(None) == None
    assert ansible_j_s_o_n_encoder_0.default({"d": 1, "a": "str"}) == {"d": 1, "a": "str"}
    assert ansible_j_s_o_n_encoder_0.default([1]) == [1]

# Generated at 2022-06-24 20:29:18.842316
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert ansible_j_s_o_n_encoder_0.default(1) == 1


# Generated at 2022-06-24 20:29:22.513211
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:31.669830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    
    # Test cases, always a "default" value for each field
    test_case = {}
    # test case
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default(test_case)
    # Test case
    test_case = []
    # test case
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default(test_case)
    
    


# Generated at 2022-06-24 20:29:34.564300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_dict = {"Ansible": "AWX"}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(test_dict) == {"Ansible": "AWX"}


# Generated at 2022-06-24 20:29:36.617891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_1.default(oa)


# Generated at 2022-06-24 20:29:43.389103
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(skipkeys=False, ensure_ascii=True, check_circular=True, allow_nan=True, indent=None, separators=None, default=None,
        sort_keys=False)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(skipkeys=False, ensure_ascii=True, check_circular=True, allow_nan=True, indent=None, separators=None, default=(),
        sort_keys=False)

# Generated at 2022-06-24 20:29:48.509979
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Instantiating test object with known values
    mock_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Creating instance of class AnsibleUnsafeText
    mock_1 = AnsibleUnsafeText()
    # Invoking method call 'default' of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(mock_1)

# Generated at 2022-06-24 20:29:52.139098
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_date_object_0 = datetime.date(1960, 1, 1)

    # call the method
    ansible_j_s_o_n_encoder_0.default(ansible_date_object_0)

# Generated at 2022-06-24 20:29:55.370694
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = dict()

    result = ansible_j_s_o_n_encoder_1.default(o)
    assert isinstance(result, dict)


# Generated at 2022-06-24 20:29:57.071435
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:05.602837
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    a_n_s_i_b_l_e_unsafe_0 = AnsibleUnsafe('test')
    a_n_s_i_b_l_e_unsafe_1 = AnsibleUnsafe(False)
    a_n_s_i_b_l_e_vault_0 = AnsibleVaultEncryptedUnicode(
        'test', b64encode('test'))
    a_n_s_i_b_l_e_vault_1 = AnsibleVaultEncryptedUnicode(
        False, b64encode('test'))


# Generated at 2022-06-24 20:30:15.873372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert not ansible_j_s_o_n_encoder_0.default({'a': 2})


# Generated at 2022-06-24 20:30:24.492978
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    result = ansible_j_s_o_n_encoder_0.default('test_value')
    assert result == 'test_value'
    # Test if default method returns a JSON dumpable list or dict
    o_dict_0 = dict(key1="value", key2=[1,2,3])
    result = ansible_j_s_o_n_encoder_0.default(o_dict_0)
    assert isinstance(result, dict) and result
    o_list_0 = [1,2,3, "value"]
    result = ansible_j_s_o_n_encoder_0.default(o_list_0)

# Generated at 2022-06-24 20:30:34.843027
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    u = ansible_json_encoder.default(None)
    assert u == "null"
    u = ansible_json_encoder.default(False)
    assert u == "false"
    u = ansible_json_encoder.default(True)
    assert u == "true"
    u = ansible_json_encoder.default(123)
    assert u == "123"
    u = ansible_json_encoder.default([1, 2, 3])
    assert u == "[1, 2, 3]"
    u = ansible_json_encoder.default({"a": "b"})
    assert u == '{"a": "b"}'

# Generated at 2022-06-24 20:30:38.722868
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Testing AnsibleJSONEncoder.default
    ansible_j_s_o_n_encoder_0.default


# Generated at 2022-06-24 20:30:49.302088
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import PY2
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    default_str = ansible_j_s_o_n_encoder_0.default('https://docs.ansible.com/ansible/latest/modules/')
    if PY2:
        assert type(default_str) is unicode
    else:
        assert type(default_str) is str

    default_list = ansible_j_s_o_n_encoder_0.default(['https://docs.ansible.com/ansible/latest/modules/'])
    assert type(default_list) is list
    if PY2:
        assert type(default_list[0]) is unicode

# Generated at 2022-06-24 20:30:59.863804
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_json = '{"__ansible_vault": "value", "__ansible_unsafe": "value"}'

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2

    from ansible.module_utils._text import to_bytes, to_native

    if PY2:
        data = [u'foo', (u'bar', u'baz')]
    else:
        data = ['foo', ('bar', 'baz')]

    password = to_bytes('abcd')
    vlt = VaultLib([])
    vlt.decrypt(to_bytes(to_native(test_json)))

# Generated at 2022-06-24 20:31:08.682609
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(skipkeys=False, ensure_ascii=True,
                                               check_circular=True, allow_nan=True, sort_keys=False,
                                               indent=None, separators=None, default=None,
                                               preprocess_unsafe=True, vault_to_text=False)
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default(o="o")
    assert ansible_j_s_o_n_encoder_0_default == "o"
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:31:10.960207
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Instantiate object
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # No test required as method default is overridden in the subclass.


# Generated at 2022-06-24 20:31:17.333065
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('unsafe_0')
    ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode('vault_0')
    datetime_d_a_t_e_0 = datetime.date(2019,1,1)
    datetime_d_a_t_e_t_i_m_e_0 = datetime.datetime(2019,1,1,0,0,0)
    ansible_h_o_s_t_v_a_r_s_0 = AnsibleHostVars({'hostvars_0':0})


# Generated at 2022-06-24 20:31:27.864887
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert_equal(ansible_json_encoder_0.default(''), '')
    assert_equal(ansible_json_encoder_0.default([1, 2, 3]), [1, 2, 3])
    assert_equal(ansible_json_encoder_0.default({'a': 'b', 'c': 'd'}), {'a': 'b', 'c': 'd'})
    assert_equal(ansible_json_encoder_0.default(u''), '')
    assert_equal(ansible_json_encoder_0.default(u'a'), 'a')
    assert_equal(ansible_json_encoder_0.default(1), 1)

# Generated at 2022-06-24 20:31:42.667191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('hello', 'world')
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == {'__ansible_unsafe': 'hello'}
    assert True


# Generated at 2022-06-24 20:31:45.469156
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder__0 = AnsibleJSONEncoder()
    o_0 = True
    ansible_j_s_o_n_encoder__0.default(o_0)


# Generated at 2022-06-24 20:31:53.607078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()

    v = ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_1)


# Generated at 2022-06-24 20:31:57.791961
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    date = 'date'
    unsafe = 'unsafe'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(date)
    ansible_j_s_o_n_encoder_1.default(unsafe)


# Generated at 2022-06-24 20:31:59.299474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:32:07.806368
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_class_0 = AnsibleVaultEncryptedUnicode()
    ansible_v_a_u_l_t_class_0.string = "abc"
    assert ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_class_0) == {'__ansible_vault': 'YWJj'}


# Generated at 2022-06-24 20:32:09.627691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:32:13.618755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:32:17.918681
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    ansible_j_s_o_n_encoder_0.default({})
    ansible_j_s_o_n_encoder_0.default({'id': '6'})


# Generated at 2022-06-24 20:32:20.975628
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = object()
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == ansible_unsafe_0


# Generated at 2022-06-24 20:32:46.744945
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Create a class
    class TestClass:
        def __init__(self):
            self.ansible_unsafe_0 = ''
            self.ansible_unsafe_1 = 'ABCDEFG'
            self.ansible_unsafe_2 = 'ABCDEFG\U0001F4A9'
            self.ansible_unsafe_3 = 'ABCDEFG\U0001F4A9\U0001F4A9\U0001F4A9\U0001F4A9\U0001F4A9\U0001F4A9'


# Generated at 2022-06-24 20:32:49.876975
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default({'key': 'value'})
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'


# Generated at 2022-06-24 20:32:53.460207
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = 'Mayur'

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_0.default(o)

    assert result == 'Mayur'


# Generated at 2022-06-24 20:33:01.507331
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejsonencoder = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultLib
    ansible_vault_obj = VaultLib('secret')
    ansible_vault_obj._ciphertext = 'this_is_cipher'

    assert ansiblejsonencoder.default(ansible_vault_obj) == {'__ansible_vault': to_text(ansible_vault_obj._ciphertext, errors='surrogate_or_strict', nonstring='strict')}


# Generated at 2022-06-24 20:33:11.311430
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test for conditional variable isinstance
    test_value_0 = 'Vault is encrypted'
    test_value_1 = ansible_j_s_o_n_encoder_0.default(test_value_0)

    # Test for conditional variable is_sequence
    test_value_2 = [test_value_0]
    test_value_3 = ansible_j_s_o_n_encoder_0.default(test_value_2)

    # Test for conditional variable isinstance
    test_value_4 = {}
    test_value_5 = ansible_j_s_o_n_encoder_0.default(test_value_4)

    # Test for conditional variable isinstance
    test_value

# Generated at 2022-06-24 20:33:17.695962
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Run default function
    # default function should be run with parameters :
    # default function should return 'unicode'
    # The following call to the default function of AnsibleJSONEncoder should not return an error
    ansible_j_s_o_n_encoder_0.default('o')


# Generated at 2022-06-24 20:33:23.893728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_1 = ansible_j_s_o_n_encoder_default_0.default(o=True)
    assert ansible_j_s_o_n_encoder_default_1 is True


# Generated at 2022-06-24 20:33:34.999127
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_string_0 = "str"
    ansible_unsafe_string_1 = to_text(ansible_unsafe_string_0, errors='surrogate_or_strict', nonstring='strict')
    ansible_unsafe_0 = "str"
    ansible_vault_0 = ansible_unsafe_0
    ansible_vault_object_0 = ansible_j_s_o_n_encoder_0.default(ansible_vault_0)

    # FIXME: check vault_object_0 is AnsibleUnsafe
    #ansible_vault_object_valid_0 = isinstance(ansible_vault_object_0, )
    ansible

# Generated at 2022-06-24 20:33:46.388300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_lib_0 = VaultLib([])

    _vault_password_0 = to_bytes('my_password')
    ansible_vault_lib_0.read_vault_password_file(_vault_password_0)

    _ciphertext_0 = to_bytes('AQCkY6PS2vJzOcW8xZrzBZOqE6KmUFTmhU6RnU6YQw==')
    _ciphertext_0 = ansible_vault_lib_0.decrypt(_ciphertext_0)



# Generated at 2022-06-24 20:33:53.367063
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(allow_nan=False, check_circular=True, cls=None,
                                                   indent=None, ensure_ascii=True, sort_keys=False,
                                                   allow_nan=False, check_circular=True, cls=None,
                                                   ensure_ascii=True, indent=None, separators=(',', ':'),
                                                   sort_keys=False, encoding='utf-8')
    o = None

    value = ansible_j_s_o_n_encoder_0.default(o)
    assert value is None

# # Unit test for method iterencode of class AnsibleJSONEncoder
# def test_AnsibleJSONEncoder_iterencode():
#     ansible

# Generated at 2022-06-24 20:34:42.195934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {
        'ansible_test': ansible_j_s_o_n_encoder_0.default,
    }
    assert dict_0['ansible_test'] == ansible_j_s_o_n_encoder_0.default, "dict_0['ansible_test'] != ansible_j_s_o_n_encoder_0.default"


# Generated at 2022-06-24 20:34:44.873002
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"a": "b" }
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:34:51.990427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test with not supported object
    assert ansible_j_s_o_n_encoder_0.default(object()) == '<object object at 0x7f506d98b8c0>'


# Generated at 2022-06-24 20:34:56.801132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_vault_0 = AnsibleVaultEncryptedUnicode('hello', version=1)
    ansible_unsafe_0 = AnsibleUnsafeText('hello')
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_vault_0)
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:35:02.497315
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    data = '{"hi": "hi"}'
    data = json.loads(data)
    ret_val = ansible_j_s_o_n_encoder_0.default(data)
    assert isinstance(ret_val, dict)
    assert ret_val == {"hi": "hi"}


# Generated at 2022-06-24 20:35:11.707992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test_case_1():
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        o = {}
        ansible_j_s_o_n_encoder_0.default(o)
    def test_case_2():
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        o = {}
        ansible_j_s_o_n_encoder_0.default(o)
    def test_case_3():
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        o = {}
        ansible_j_s_o_n_encoder_0.default(o)
    def test_case_4():
        ansible_j_s_o_