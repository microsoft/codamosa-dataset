

# Generated at 2022-06-24 20:25:21.088667
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict_0 = {}
    dict_0['test_dict'] = b'\xa3\xa3\xa3'
    dict_0['test_list'] = [b'\xa3\xa3\xa3']
    dict_0['test_str'] = b'\xa3\xa3\xa3'
    dict_0['test_int'] = 1023

    a_j_e = AnsibleJSONEncoder()
    out_dict = {}
    out_dict['test_dict'] = '«««'
    out_dict['test_list'] = ['«««']
    out_dict['test_str'] = '«««'
    out_dict['test_int'] = 1023
    assert out_dict == a_j_e.default(dict_0)


# Generated at 2022-06-24 20:25:23.061048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:25:27.034264
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'quux'
    ansible_j_s_o_n_encoder_0.default(dict_0)
    # assert the constructed dict is equal to dict_0


# Generated at 2022-06-24 20:25:28.295981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}

# Generated at 2022-06-24 20:25:37.669101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False)
    dict_0 = {}
    dict_1 = {"a": 1, "b": 2}
    dict_0.update(dict_1)
    ansible_j_s_o_n_encoder_0.default("test")
    ansible_j_s_o_n_encoder_0.default(dict_0)
    ansible_j_s_o_n_encoder_0.default("test")
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:25:40.506395
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    assert ansible_j_s_o_n_encoder_0.default(dict_0) == dict_0

# Generated at 2022-06-24 20:25:45.874967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict_0 = {'a': 'test'}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:25:52.331740
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = "abcdefghijklmnopqrstuvwxyz"
    expected_value_0 = {'__ansible_unsafe': str_0}
    #print(json.dumps(expected_value_0))
    unsafe_0 = {'__UNSAFE__': True, '__ENCRYPTED__': False}
    unsafe_str_0 = type('', (), {'__ENCRYPTED__': False, '__UNSAFE__': True})
    type_0 = type('', (), {'__UNSAFE__': True})
    x = type_0(unsafe_0)
    x.__UNSAFE__ = True

# Generated at 2022-06-24 20:25:54.705029
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    dict_0 = ansible_j_s_o_n_encoder_0.default(dict_0)

    assert type(dict_0) == dict


# Generated at 2022-06-24 20:25:55.350332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True == True


# Generated at 2022-06-24 20:26:01.593623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # No need to test this function, it is covered by test_case_0()
    pass


# Generated at 2022-06-24 20:26:05.130982
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default == json.JSONEncoder.default


# Generated at 2022-06-24 20:26:08.359049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    object_0 = ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:26:15.775245
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    list_0 = []
    dict_0 = {}
    date_0 = datetime.date(1979, 8, 1)
    # ansible_j_s_o_n_encoder_0.default(list_0)
    # ansible_j_s_o_n_encoder_0.default(dict_0)
    # ansible_j_s_o_n_encoder_0.default(date_0)

# Generated at 2022-06-24 20:26:17.247929
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:26:21.073023
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_0.default(), None.__class__) or ansible_j_s_o_n_encoder_0.default() is None


# Generated at 2022-06-24 20:26:26.567699
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    try:
        assert ansible_j_s_o_n_encoder_0.default(dict_0) == dict_0
    except (AssertionError, TypeError, NameError):
        pass


# Generated at 2022-06-24 20:26:28.728005
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict_0 = {}

# Generated at 2022-06-24 20:26:31.790910
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:26:35.612430
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:26:39.973703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    if test_case_0():
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        dict_0 = {}
        string_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
        assert string_0 == "{}", "Return value mismatch, should match"


# Generated at 2022-06-24 20:26:42.817610
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:26:44.932627
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}


# Generated at 2022-06-24 20:26:48.221582
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    assert ansible_j_s_o_n_encoder_0.default(dict_0) == dict_0

# Generated at 2022-06-24 20:26:58.698776
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = false
    ansible_j_s_o_n_encoder_0._vault_to_text = false
    ansible_j_s_o_n_encoder_0._default_decoder = ansible_j_s_o_n_encoder_0._default_decoder
    object_0 = object
    expected_output = {
        "__ansible_vault": 'abcdefg',
        "__ansible_unsafe": 'abcdefg',
        "__ansible_vars": "{}"
    }


# Generated at 2022-06-24 20:27:06.720321
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('Hello')
    assert json.dumps({'ansible_u_n_s_a_f_e_0': ansible_u_n_s_a_f_e_0}, cls=AnsibleJSONEncoder) == '{"ansible_u_n_s_a_f_e_0": {"__ansible_unsafe": "Hello"}}'


# Generated at 2022-06-24 20:27:11.378695
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_0 = datetime.date()
    try:
        assert ansible_j_s_o_n_encoder_0.default(datetime_0) == "0001-01-01"
    except AssertionError as error:
        print(error)


# Generated at 2022-06-24 20:27:22.466566
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_class_0 = AnsibleJSONEncoder()
    v_c_class_0 = ansible_unsafe_class_0.default(str_0)
    v_c_class_1 = ansible_unsafe_class_0.default(int_0)
    v_c_class_2 = ansible_unsafe_class_0.default(float_0)
    v_c_class_3 = ansible_unsafe_class_0.default(bool_0)
    v_c_class_4 = ansible_unsafe_class_0.default(set_0)
    v_c_class_5 = ansible_unsafe_class_0.default(frozenset_0)

# Generated at 2022-06-24 20:27:29.110906
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    dict_1 = dict_0
    dict_0 = dict_1
    dict_0 = dict_1
    assert ansible_j_s_o_n_encoder_0.default(dict_0) is dict_0


# Generated at 2022-06-24 20:27:36.934459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    dict_0['nested_dict_0'] = {}
    dict_0['nested_dict_0']['nested_list_0'] = []
    dict_0['nested_dict_0']['nested_list_0'].append({'key_0': 'value_0', 'key_1': 999})
    dict_0['nested_dict_0']['nested_list_0'].append({'key_0': 'value_1', 'key_1': 888})
    dict_0['nested_dict_0']['nested_list_0'].append({'key_0': 'value_2', 'key_1': 777})
    dict

# Generated at 2022-06-24 20:27:43.117670
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(str_0)


# Generated at 2022-06-24 20:27:45.894089
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print('\nDoing test for method default of class AnsibleJSONEncoder')
    #assert ansible_j_s_o_n_encoder_0.default() == None


# Generated at 2022-06-24 20:27:54.242210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    unsafe_str_0 = 'hello world'
    unsafe_str_1 = 'hello world'
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(unsafe_str_0)
    setattr(ansible_unsafe_0, '__UNSAFE__', True)
    ansible_unsafe_1 = ansible_j_s_o_n_encoder_0.default(unsafe_str_1)
    setattr(ansible_unsafe_1, '__UNSAFE__', True)
    ansible_unsafe_2 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_1)
   

# Generated at 2022-06-24 20:27:54.896913
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:28:02.508548
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Re-assign to prevent call to AnsibleJSONEncoder.__init__
    ansible_j_s_o_n_encoder_0.default = lambda o: object()
    ansible_j_s_o_n_encoder_0.default(object())


# Generated at 2022-06-24 20:28:04.557836
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = datetime.datetime.utcnow()
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:28:05.442881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:28:07.697781
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert ansible_j_s_o_n_encoder_0.default(ansible_json_encoder_0) == dict_0

# Generated at 2022-06-24 20:28:09.882053
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert True

# Generated at 2022-06-24 20:28:14.480675
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    json_0 = ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:28:25.497026
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    string_0 = ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:28:36.007859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    ansible_j_s_o_n_encoder_default = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert ansible_j_s_o_n_encoder_default == {}

    assert ansible_j_s_o_n_encoder_default == {}
    assert ansible_j_s_o_n_encoder_default == {}
    assert ansible_j_s_o_n_encoder_default == {}
    assert ansible_j_s_o_n_encoder_default == {}
    assert ansible_j_s_o_n_encoder_default == {}
    assert ansible_j_s

# Generated at 2022-06-24 20:28:39.187863
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    try:
        ansible_j_s_o_n_encoder_0.default(dict_0)
    except Exception:
        raise



# Generated at 2022-06-24 20:28:43.358062
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    # Calling default() with the given arguments
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:28:54.550385
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_un_safe_0 = AnsibleUnsafe('str_0')
    ansible_vault_0 = AnsibleVault('str_0', 'str_1')
    datetime_date_0 = datetime.date(1999, 8, 21)
    datetime_datetime_0 = datetime.datetime.now()

# Generated at 2022-06-24 20:29:02.962063
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default(int())
    ansible_json_encoder_0.default(long())
    ansible_json_encoder_0.default(float())
    ansible_json_encoder_0.default(complex())
    ansible_json_encoder_0.default(dict())
    ansible_json_encoder_0.default(list())
    ansible_json_encoder_0.default(tuple())
    ansible_json_encoder_0.default(bytearray())
    ansible_json_encoder_0.default(str())
    ans

# Generated at 2022-06-24 20:29:09.124934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    str_value_0 = 'vault_value'
    vault_object_0 = ansible_vault.VaultLib.VaultSecret(None, str_value_0)
    dict_1 = ansible_j_s_o_n_encoder_1.default(vault_object_0)
    assert dict_1 == {'__ansible_vault': 'vault_value'}



# Generated at 2022-06-24 20:29:14.519967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default('__UNSAFE__')
    ansible_vault_0 = ansible_j_s_o_n_encoder_0.default('__ENCRYPTED__')
    assert ansible_unsafe_0 != ansible_vault_0

# Generated at 2022-06-24 20:29:17.147535
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default([]) == []


# Generated at 2022-06-24 20:29:25.252487
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    from ansible.parsing.vault import VaultSecret
    vault_secret_0 = VaultSecret(b'\x02\x00\x00\x00$\x00\x00\x00', b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x03\xd0\xeb\x0d\xc1\x11\x92\x03\x00\x00\x00')

# Generated at 2022-06-24 20:29:41.159544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    dict_1 = {}


# Generated at 2022-06-24 20:29:49.662142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TEST CASE: ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # TEST CASE: dict_0 = {}
    dict_0 = {}
    # TEST CASE: TypeError: <lambda>() missing 1 required positional argument: 'o'
    # TEST CASE: TypeError: <lambda>() missing 1 required positional argument: 'o'
    # TEST CASE: lambda(): <lambda>() missing 1 required positional argument: 'o'
    # TEST CASE: lambda(): lambda(): <lambda>() missing 1 required positional argument: 'o'
    # TEST CASE: <lambda>() missing 1 required positional argument: 'o'
    # TEST CASE: <lambda>() missing 1 required positional argument: 'o'
    # TEST

# Generated at 2022-06-24 20:29:55.182733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.plugins.loader import callback_loader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    callback_0 = callback_loader.get('json')
    ansible_j_s_o_n_encoder_0 = callback_0.encoder
    o = AnsibleUnsafeText(['foo'])
    assert ansible_j_s_o_n_encoder_0.default(o) == o.__EUA__()


# Generated at 2022-06-24 20:29:57.753552
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        test_case_0()
    except Exception as exc:
        assert False, "Exception: {0}".format(exc)


# Generated at 2022-06-24 20:29:59.727629
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}


# Generated at 2022-06-24 20:30:07.873711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'ansible_host'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'ansible_host'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'ansible_host'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'ansible_host'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:11.328879
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe(u'ansible', unsafe=True)
    output_0 = json_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:30:19.729955
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of the class under test
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # If a data structure is passed to default() that is not
    # handled by the class, the return value should be the
    # result of calling super().default().
    # Assert that this is the case by comparing the return
    # value to the expected output.
    assert ansible_j_s_o_n_encoder_0.default({}) == super(AnsibleJSONEncoder, ansible_j_s_o_n_encoder_0).default({})


# Generated at 2022-06-24 20:30:23.553534
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    str_0 = ansible_j_s_o_n_encoder_0.default(dict_0)

# Generated at 2022-06-24 20:30:26.280121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_0 = datetime.date(2017, 10, 25)
    str_0 = ansible_j_s_o_n_encoder_0.default(date_0)

# Generated at 2022-06-24 20:30:58.880500
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialize test case
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = None
    # Call test method
    ret_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    # Check results
    pass


# Generated at 2022-06-24 20:31:00.633507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}

# Generated at 2022-06-24 20:31:03.973496
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    
    # Call default of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(None)


# Generated at 2022-06-24 20:31:07.318946
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    o_0 = ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:31:10.561204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:31:14.009965
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'foo'
    str_1 = ansible_j_s_o_n_encoder_0.default(str_0)
    assert str_1 == 'foo'

# Generated at 2022-06-24 20:31:15.437489
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert ansible_j_s_o_n_encoder_0.default(o=dict_0) == dict_0


# Generated at 2022-06-24 20:31:18.228048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    safety_0 = object
    ansible_j_s_o_n_encoder_0.default(safety_0)



# Generated at 2022-06-24 20:31:27.901406
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    values = [
        (0, 0),
        (1, 1),
        (0.0, 0.0),
        (1.0, 1.0),
        (0, "0"),
        (1, "1"),
        (0.0, "0.0"),
        (1.0, "1.0"),
        ("", ""),
        ("foo", "foo"),
        (u"foo", "foo"),
        ([], []),
        (['foo', 'bar'], ["foo", "bar"]),
        ({}, {}),
        ({'foo': 'bar'}, {'foo': 'bar'}),
        (None, None),
        (True, True),
        (False, False)
    ]
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder

# Generated at 2022-06-24 20:31:29.782719
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True == True


# Generated at 2022-06-24 20:32:32.852002
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # An instance of the AnsibleJSONEncoder class
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    object_0 = object
    dict_0 = ansible_j_s_o_n_encoder_0.default(object_0)
    assert dict_0['__ansible_unsafe'] == '{}'


# Generated at 2022-06-24 20:32:40.752435
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    set_0 = {'foo', 'bar'}
    list_0 = []
    dict_0 = {}
    ansible_j_s_o_n_encoder_0.default(list_0)
    ansible_j_s_o_n_encoder_0.default(set_0)
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:32:45.038612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {'{#ANSIBLE_VAR}': '{#ANSIBLE_VALUE}'}
    assert ansible_j_s_o_n_encoder_0.default(dict_0) == dict_0


# Generated at 2022-06-24 20:32:47.840057
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    print(str_0)


# Generated at 2022-06-24 20:32:54.525301
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    dict_1 = {'__ansible_unsafe': '{"a": "b"}'}
    dict_2 = {'__ansible_vault': '{"a": "b"}'}
    dict_3 = {'__ansible_unsafe': 'VHlwZSI6IFRleHQsImRhdGEiOiAiSGVsbG8gV29ybGQifQ=='}
    dict_4 = {'__ansible_vault': 'VHlwZSI6IFRleHQsImRhdGEiOiAiSGVsbG8gV29ybGQifQ=='}

# Generated at 2022-06-24 20:32:59.850374
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    str_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert(str_0 == '{}')



# Generated at 2022-06-24 20:33:04.218097
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default() == ansible_j_s_o_n_encoder_0.default()


# Generated at 2022-06-24 20:33:05.727507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:33:12.981451
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert _is_vault(True) is False
    assert _is_vault(0) is False
    assert _is_vault(1.11) is False
    assert _is_vault(None) is False
    assert _is_vault([]) is False
    assert _is_vault([True]) is False
    assert _is_vault([0]) is False
    assert _is_vault([1.11]) is False
    assert _is_vault(['0']) is False
    assert _is_vault([None]) is False
    assert _is_vault({}) is False
    assert _is_vault({'0': True}) is False
    assert _is_vault({'0': 0}) is False
    assert _is_vault({'0': 1.11}) is False

# Generated at 2022-06-24 20:33:20.128415
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an object
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Call method default of object ansible_j_s_o_n_encoder_0 with argument dict_0
    # Testing if a call to method default of class AnsibleJSONEncoder with argument {'__ansible_unsafe': 'VARCHAR'} returns a value of type dict
    ansible_j_s_o_n_encoder_0.default(dict_0)