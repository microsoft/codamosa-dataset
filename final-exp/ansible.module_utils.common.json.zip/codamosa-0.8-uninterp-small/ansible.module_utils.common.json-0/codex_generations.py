

# Generated at 2022-06-24 20:25:21.185013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    output = AnsibleJSONEncoder().default(None)
    assert output is None
    output = AnsibleJSONEncoder().default('AnSible')
    assert output == 'AnSible'
    output = AnsibleJSONEncoder().default(42)
    assert output == 42
    output = AnsibleJSONEncoder().default(3.14)
    assert output == 3.14
    output = AnsibleJSONEncoder().default(True)
    assert output is True
    output = AnsibleJSONEncoder().default(False)
    assert output is False
    output = AnsibleJSONEncoder().default({})
    assert output == {}
    output = AnsibleJSONEncoder().default([])
    assert output == []
    output = AnsibleJSONEncoder().default({}.fromkeys('a'))
    assert output == {'a': None}
   

# Generated at 2022-06-24 20:25:27.221374
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = lambda x: x * 2
    assert "lambda x: x * 2" == ansible_j_s_o_n_encoder_0.default(o_0), "AnsibleJSONEncoder.default method failed"


# Generated at 2022-06-24 20:25:30.813235
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_1.default(dict()), dict)
    assert isinstance(ansible_j_s_o_n_encoder_1.default(dict()), Mapping)


# Generated at 2022-06-24 20:25:31.688666
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  pass


# Generated at 2022-06-24 20:25:33.345966
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:25:37.316489
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    x_0 = 'abc'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    x_1 = ansible_j_s_o_n_encoder_0.default(x_0)
    assert x_1 == 'abc'


# Generated at 2022-06-24 20:25:39.892510
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:25:49.345895
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1_default_1 = ansible_j_s_o_n_encoder_1.default('')
    ansible_j_s_o_n_encoder_1_default_2 = ansible_j_s_o_n_encoder_1.default('')
    ansible_j_s_o_n_encoder_1_default_3 = ansible_j_s_o_n_encoder_1.default('')
    ansible_j_s_o_n_encoder_1_default_4 = ansible_j_s_o_n_encoder_1.default('')


# Generated at 2022-06-24 20:25:51.334485
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1 is not None


# Generated at 2022-06-24 20:25:54.133851
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default({'test_key': 'test_value'})


# Generated at 2022-06-24 20:26:06.322429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_7 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:26:08.111586
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:26:09.520869
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:12.707980
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default("Ansi")


# Generated at 2022-06-24 20:26:15.947231
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_j_s_o_n_encoder_0.default(o='foo')

# Generated at 2022-06-24 20:26:19.289968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {'date': 'today'}
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:26:29.935894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Create a localhost
    local_host = {}
    local_host['name'] = 'localhost'
    local_host['ansible_python_interpreter'] = '/usr/bin/python3'

    inventory_dict = {'localhost': local_host}

    inventory = '###\n# Inventory file for Ansible\n# Generated by Ansible\n###\n\n'
    inventory += ansible_j_s_o_n_encoder_0.encode(inventory_dict) + '\n'


# Generated at 2022-06-24 20:26:38.597544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    #
    # assert tests
    #
    # assert to_text(o, errors='surrogate_or_strict', nonstring='strict') == 'dummy_value_1'
    # assert to_text(o, errors='surrogate_or_strict', nonstring='strict') == 'dummy_value_2'
    # assert dict(o) == 'dummy_value_3'
    # assert o.isoformat() == 'dummy_value_4'
    # assert super(AnsibleJSONEncoder, self).default(o) == 'dummy_value_5'
    return


# Generated at 2022-06-24 20:26:42.563177
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_0.default('foo')
    ansible_j_s_o_n_encoder_1.default('foo')


# Generated at 2022-06-24 20:26:52.749995
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe(b'example_val')

# Generated at 2022-06-24 20:26:58.017632
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:04.462344
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    date_object = datetime.date(2000, 12, 31)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default(date_object) == '2000-12-31'


# Generated at 2022-06-24 20:27:10.023549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    print(ansible_j_s_o_n_encoder_0)
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    print(ansible_j_s_o_n_encoder_0)
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    print(ansible_j_s_o_n_encoder_0)
    m_a_p_p_i_n_g_0 = None
    datetime_d_a_t_e_0 = None

# Generated at 2022-06-24 20:27:12.944743
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default("a_string")
    assert value == "a_string"


# Generated at 2022-06-24 20:27:23.321300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = False # Assign protected property value
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = False # Assign protected property value
    maj_ver = sys.version_info.major
    minor_ver = sys.version_info.minor
    if maj_ver == 2 and minor_ver < 7:
        expected = ["'__ansible_vault'", "Ciphertext", "true"]
        assert expected == ansible_j_s_o_n_encoder_0.default(VaultLib).keys()
    else:
        assert ['__ansible_vault'] == ansible_j

# Generated at 2022-06-24 20:27:31.569112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    ansible_json_encoder_default = ansible_j_s_o_n_encoder_0.default((datetime.datetime(2019, 7, 31, 0, 0)))
    expected = '2019-07-31T00:00:00'
    assert ansible_json_encoder_default == expected


# Generated at 2022-06-24 20:27:34.863002
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default('frodo') == 'frodo'


# Generated at 2022-06-24 20:27:38.151901
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(0) is not None


# Generated at 2022-06-24 20:27:42.409297
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    data = ansible_j_s_o_n_encoder_1.default("hi")
    # assert
    assert(data == "hi")


# Generated at 2022-06-24 20:27:50.413782
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_0_0 = {'a': 1, 'b': 2, 'c': 3}
    ansible_j_s_o_n_encoder_1.default(o_0_0)
    ansible_j_s_o_n_encoder_1.default(ansible_j_s_o_n_encoder_1)
    ansible_j_s_o_n_encoder_1.default({'a': 1, 'b': 2, 'c': 3})
    ansible_j_s_o_n_encoder_1.default({'a': 1, 'b': 2, 'c': 3})

# Generated at 2022-06-24 20:28:02.792836
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder_0.default(AnsibleUnsafe('test', 'ascii')) == 'test'


# Generated at 2022-06-24 20:28:06.741146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_2 = date(2018, 11, 10)
    obj_str_1 = '2018-11-10'
    ansible_obj_str_1 = ansible_j_s_o_n_encoder_0.default(date_2)
    assert obj_str_1 == ansible_obj_str_1, 'AnsibleJSONEncoder.default()'


# Generated at 2022-06-24 20:28:11.181616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    arg_0 = {'a': 'b'}
    ansible_j_s_o_n_encoder_0.default(arg_0)


# Generated at 2022-06-24 20:28:12.850313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('that') == 'that'



# Generated at 2022-06-24 20:28:20.619731
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    class AnsibleUnsafe_0(object):
        __UNSAFE__ = False
        __ENCRYPTED__ = False
        _ciphertext = b'YXNzaWJsbGU=\n'

    ansible_u_n_safe_0 = AnsibleUnsafe_0()

    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_safe_0) == ansible_u_n_safe_0


# Generated at 2022-06-24 20:28:24.016706
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default('foo')



# Generated at 2022-06-24 20:28:35.149075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    #assert ansible_j_s_o_n_encoder_0.default('test_value_3') == 'test_value_3'
    #assert ansible_j_s_o_n_encoder_0.default(3) == 3
    #assert ansible_j_s_o_n_encoder_0.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert ansible_j_s_o_n_encoder_0.default(None) == None
    #assert ansible_j_s_o_n_encoder_0.default(True) == True
    #assert ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:28:42.804869
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_unsafe_0 = AnsibleUnsafe('test')

    ansible_vault_0 = AnsibleVaultEncryptedUnicode('test')

    test_var_0 = dict(one=1, two=2, three=3)

    test_var_1 = dict(four=4, five=5, six=6)

    test_var_2 = dict()

    test_var_3 = dict(test=test_var_0, test1=test_var_1, test2=test_var_2)

    test_var_4 = dict(test=test_var_0, test1=test_var_1, test2=test_var_2, test3=test_var_3)

   

# Generated at 2022-06-24 20:28:46.645233
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    ansible_j_s_o_n_encoder_0.default(o=None)

# Generated at 2022-06-24 20:28:57.206154
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = [1, "2", [3, 4]]
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert result == [1, "2", [3, 4]]
    o = {1: "1", "2": 2}
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert result == {1: "1", "2": 2}
    o = datetime.datetime(2009, 12, 25)
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert result == "2009-12-25T00:00:00"
    o = datetime.date

# Generated at 2022-06-24 20:29:23.575009
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_obj = AnsibleJSONEncoder()

    # Test with None
    assert test_obj.default(None) is None

    # Test with strings
    for test_input, expected in (
            ('string', 'string'),
            ('', ''),
            ('\x01', '\x01'),
            ('\xff', '\xff'),
            ('\u1234', '\u1234'),
            ('\U0001f34c', '\U0001f34c'),
    ):
        assert test_obj.default(to_text(test_input)) == expected

    # Test with bools
    for test_input, expected in (
            (True, True),
            (False, False),
    ):
        assert test_obj.default(test_input) == expected

    # Test with ints

# Generated at 2022-06-24 20:29:34.982458
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    obj = object()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


    # Call to default(...): (line 44)
    # Processing the call arguments (line 44)
    # Getting the type of 'obj' (line 44)
    obj_333760 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 44, 20), 'obj', False)
    # Processing the call keyword arguments (line 44)
    kwargs_333761 = {}
    # Getting the type of 'ansible_j_s_o_n_encoder_0' (line 44)

# Generated at 2022-06-24 20:29:41.626122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2.default("")
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:52.982597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('__ENCRYPTED__') == None
# assert AnsibleJSONEncoder().default('__UNSAFE__') == {'__ansible_unsafe': u''}
# assert AnsibleJSONEncoder().default('o') == {u'__ansible_vault': u''}
# assert AnsibleJSONEncoder().default('o') == {u'__ansible_vault': u''}
# assert AnsibleJSONEncoder().default('o') == {u'__ansible_vault': u''}
# assert AnsibleJSONEncoder().default('o') == {u'__ansible_vault': u''}
# assert AnsibleJSONEncoder().default('o') == {u'__ansible_vault': u''}
# assert AnsibleJSONEncoder().default('o') ==

# Generated at 2022-06-24 20:29:59.115211
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe('ansible')
    ansible_unsafe_1 = AnsibleUnsafe('ansible')
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == ansible_j_s_o_n_encoder_0.default(ansible_unsafe_1)


# Generated at 2022-06-24 20:30:10.014687
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_1 = AnsibleUnsafe('VGVzdA==')
    ansible_u_n_s_a_f_e_1.__ENCRYPTED__ = False
    ansible_u_n_s_a_f_e_1.__UNSAFE__ = True
    # If assertion fails, TypeError exception will be raised

# Generated at 2022-06-24 20:30:13.017590
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    s0 = 'HELLOWORLD'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(s0)


# Generated at 2022-06-24 20:30:18.656570
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = -125142722098866.0
    ret_val_0 = ansible_j_s_o_n_encoder_0.default(o)
    assert ret_val_0 == -125142722098866.0



# Generated at 2022-06-24 20:30:23.630074
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    o_2 = {"a": "b"}
    ansible_j_s_o_n_encoder_1.default(o_2)

    o_2 = {"a": {"b": "c"}}
    ansible_j_s_o_n_encoder_1.default(o_2)



# Generated at 2022-06-24 20:30:25.600056
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(1)


# Generated at 2022-06-24 20:31:02.527964
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default('test') == 'test'


# Generated at 2022-06-24 20:31:12.157928
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe("unsafe string")
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)
    ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode("vault string")
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_0)
    ansible_v_a_u_l_t_1 = AnsibleVaultEncryptedUnicode("vault string")
    ansible_j_s_o_n_enc

# Generated at 2022-06-24 20:31:16.997949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('r')


# Generated at 2022-06-24 20:31:24.639022
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def my_default_0():
        if True:
            ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

            o_0 = {'my_obj': ''}

            # Run the method to test
            ansible_j_s_o_n_encoder_0.default(o_0)

    # Call function method my_default_0
    my_default_0()



# Generated at 2022-06-24 20:31:30.259533
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = 0
    res = ansible_j_s_o_n_encoder_1.default(o)
    assert o == res


# Generated at 2022-06-24 20:31:31.163749
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:31:35.326501
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = {"__ansible_unsafe": "value"}
    # Check that the call AnsibleJSONEncoder.default(ansible_j_s_o_n_encoder_0, ansible_unsafe_0) returns the value of ansible_unsafe_0["__ansible_unsafe"]
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == ansible_unsafe_0["__ansible_unsafe"]

# Generated at 2022-06-24 20:31:37.949548
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'test_value'
    assert ansible_j_s_o_n_encoder_0.default(o) == o



# Generated at 2022-06-24 20:31:44.552873
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {'__ansible_unsafe': 'test'}
    default_return_value_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    if default_return_value_0 != 'test':
        raise AssertionError()


# Generated at 2022-06-24 20:31:48.799541
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    my_encoder = AnsibleJSONEncoder()
    my_date = datetime.datetime( 2016, 11, 8 )

    assert my_encoder.default( my_date ) == '2016-11-08T00:00:00'


# Generated at 2022-06-24 20:33:10.134120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_7 = AnsibleJSONEncoder()
    ansible_j_s

# Generated at 2022-06-24 20:33:13.451938
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    o = dict()
    o['test'] = 'test'
    assert ansible_j_s_o_n_encoder.default(o) == o


# Generated at 2022-06-24 20:33:22.782631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(21)
    ansible_j_s_o_n_encoder_0.default(55.55)
    ansible_j_s_o_n_encoder_0.default(set(['j', 'i', 'h', 'g', 'f', 'e', 'd', 'c', 'b', 'a']))
    ansible_j_s_o_n_encoder_0.default(['orange', 'red', 'green'])
    ansible_j_s_o_n_encoder_0.default(('grey',))

# Generated at 2022-06-24 20:33:26.576038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(None)


# Generated at 2022-06-24 20:33:32.590898
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe("ANSIBLE_SAFE_STRING")
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    ansible_vault_0 = AnsibleVaultEncryptedUnicode("ANSIBLE_SAFE_STRING")
    ansible_j_s_o_n_encoder_0.default(ansible_vault_0)
    dict_0 = dict()
    dict_0["key_0"] = "value_0"
    dict_0["key_1"] = "value_1"
    ansible_j_s_o_n_encoder_0.default(dict_0)
    dat

# Generated at 2022-06-24 20:33:44.071755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Setup
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    
    # Test with non-safe object
    o = datetime.datetime(2019, 1, 1, 1, 1, 1)
    # Verify
    assert ansible_j_s_o_n_encoder_0.default(o) == "2019-01-01T01:01:01"
    
    # Test with safe object
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six.moves import shlex_quote
    vault_0 = VaultLib([])
    secret_0 = vault_0.encrypt("my secret")
    # Verify
    assert ansible_j_s_o_n_encoder_0.default(secret_0)

# Generated at 2022-06-24 20:33:49.443405
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafeText()
    o = ansible_v_a_u_l_t_0
    ansible_j_s_o_n_encoder_0.default(o)
    o = ansible_u_n_s_a_f_e_0
    ansible_j_s_o_n_encoder_0.default(o)



# Generated at 2022-06-24 20:33:50.876273
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:53.582187
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o="abc")


# Generated at 2022-06-24 20:34:02.701896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    vault_password_file = '/tmp/ansible-vault.txt'

    ansible_vault_0 = VaultLib(vault_password_file)
    o = ansible_vault_0

    # test with vault object
    ansible_json_encoder_0_default_0 = ansible_j_s_o_n_encoder_0.default(o)

    # test with unsafe object
    ansible_json_encoder_0_default_1 = ansible_j_s_o_n_encoder_0.default('== Test ==')
