

# Generated at 2022-06-24 20:25:15.351931
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = str()
    try:
        ansible_j_s_o_n_encoder_0.default(o)
        assert True
    except:
        assert False


# Generated at 2022-06-24 20:25:20.102863
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()

    # test with a mapping
    with open('tests/fixtures/inventory/test_inventory_encode_all/host_vars.json') as f:
        host_vars = json.load(f)
    ansible_json_encoder_default_0 = ansible_json_encoder_0.default(host_vars)
    assert ansible_json_encoder_default_0 == host_vars


# Generated at 2022-06-24 20:25:20.584357
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-24 20:25:22.653932
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    obj.default(obj)


# Generated at 2022-06-24 20:25:26.796577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test string
    test_class_0 = """TEST"""
    test_class_1 = u"TEST"
    test_class_2 = b"TEST"
    ansible_j_s_o_n_encoder_0.default(test_class_0)


# Generated at 2022-06-24 20:25:29.894702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        assert_equal(ansible_j_s_o_n_encoder_0.default('ansible_host'), 'ansible_host')
    except AssertionError as err:
        raise AssertionError(str(err))


# Generated at 2022-06-24 20:25:33.018696
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = AnsibleUnsafeText('test')
    ansible_j_s_o_n_encoder_0.default(o_0)

# Generated at 2022-06-24 20:25:41.880536
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = b'\x00\x01'

    a_dict = {
        'a': a,
    }

    a_list = [
        a,
    ]

    test_cases = [
        {
            'input': dict(
                o=a,
            ),
            'expected_results': a_dict,
        },
        {
            'input': dict(
                o=a_dict,
            ),
            'expected_results': a_list,
        },
    ]

    for test_case in test_cases:
        ansible_json_encoder_obj = AnsibleJSONEncoder()

        results = ansible_json_encoder_obj.default(**test_case['input'])

        assert test_case['expected_results'] == results


# Generated at 2022-06-24 20:25:48.098412
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_default_0 = AnsibleJSONEncoder(False, True)
    ansible_json_encoder_default_1 = AnsibleJSONEncoder(False, True)

    ansible_json_encoder_default_0.default(ansible_json_encoder_default_1)


# Generated at 2022-06-24 20:25:49.551881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({"a": "b"}) == \
        {"a": "b"}


# Generated at 2022-06-24 20:25:56.641892
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:06.602066
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    # no exception raised
    ansible_json_encoder.default('test string')
    ansible_json_encoder.default(b'test bytes')
    ansible_json_encoder.default(u'test unicode')
    ansible_json_encoder.default(10.0)
    ansible_json_encoder.default(datetime.datetime(2020, 1, 1, 12, 30))
    ansible_json_encoder.default(datetime.date(2020, 1, 1))
    ansible_json_encoder.default(dict(a=1, b=2))
    ansible_json_encoder.default([dict(a=1), dict(a=2, b=2)])

# Generated at 2022-06-24 20:26:11.647411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2.default(o={})
    ansible_j_s_o_n_encoder_2.default(o={'__ansible_unsafe': 'secret'})


# Generated at 2022-06-24 20:26:17.391564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0_0 = AnsibleUnsafe('test_value', 123)
    ansible_u_n_s_a_f_e_1_0 = AnsibleUnsafe('test_value', 123)
    ansible_u_n_s_a_f_e_1_1 = AnsibleUnsafe('test_value', 123)
    ansible_u_n_s_a_f_e_0_0_unsafe_value = to_text(ansible_u_n_s_a_f_e_0_0, errors='surrogate_or_strict', nonstring='strict')
    ansible_u_n_s_a_f

# Generated at 2022-06-24 20:26:23.927048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 123
    value = ansible_j_s_o_n_encoder_0.default(o)
    assert isinstance(value, (int, long))
# Test case with assert statement(s)

# Generated at 2022-06-24 20:26:27.583622
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default(o = '3')
    except:
        pass


# Generated at 2022-06-24 20:26:29.747043
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    test_case_0()


# Generated at 2022-06-24 20:26:41.563300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    s_unsafe_text_0 = 'abcdefg'
    safe_text_0 = 'abcdefg'
    o_ansible_unsafe_0 = AnsibleUnsafe(to_text(s_unsafe_text_0))
    o_ansible_safe_text_0 = AnsibleSafeText(safe_text_0)

    ansible_j_s_o_n_encoder_0.default(o_ansible_unsafe_0)
    ansible_j_s_o_n_encoder_0.default(o_ansible_safe_text_0)

    # test vault object

# Generated at 2022-06-24 20:26:42.223814
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 1 == 1

# Generated at 2022-06-24 20:26:46.248568
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(indent=0)
    assert ansible_j_s_o_n_encoder_0.default(raises_ansible_unsafe()) == {'__ansible_unsafe': 'str'}



# Generated at 2022-06-24 20:26:54.898234
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  ansible_jsonencoder = AnsibleJSONEncoder()
  result_success = ansible_jsonencoder.default({'Red': 1, 'Green': 2, 'Blue': 3})
  assert result_success == {u'Red': 1, u'Green': 2, u'Blue': 3}


# Generated at 2022-06-24 20:27:03.752623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:27:07.652162
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    # AnsibleJSONEncoder._is_vault=0, AnsibleJSONEncoder._vault_to_text=0, AnsibleJSONEncoder._preprocess_unsafe=0
    ansible_j_s_o_n_encoder_2._vault_to_text = 0
    ansible_j_s_o_n_encoder_2._is_vault = 0
    ansible_j_s_o_n_encoder_2._preprocess_unsafe = 0


# Generated at 2022-06-24 20:27:14.626466
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    data = [datetime.date(2018, 7, 3), datetime.datetime(2018, 4, 20, 16, 57, 11, 482390)]
    data_json_1 = ansible_j_s_o_n_encoder_1.default(data)
    data_json_2 = ansible_j_s_o_n_encoder_1.default({'a': set([1, 2, 3]), 'b': 'c'})
    data_json_3 = ansible_j_s_o_n_encoder_1.default('unsafe')


# Generated at 2022-06-24 20:27:24.557813
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    o_1 = {}
    o_2 = {}
    o_3 = {}
    o_4 = {}
    o_5 = {}

# Generated at 2022-06-24 20:27:35.376947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('instance_0')
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default('instance_1')
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2.default('instance_2')
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3.default('instance_3')
    ansible_j_s

# Generated at 2022-06-24 20:27:41.560276
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    input_argument_0 = to_text('SOME STRING')
    expected_return_value_0 = json.JSONEncoder.default(ansible_j_s_o_n_encoder_0, input_argument_0)
    assert expected_return_value_0 == 'SOME STRING'



# Generated at 2022-06-24 20:27:44.197821
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = dict()
    v = ansible_j_s_o_n_encoder_0.default(o)
    assert v == dict()

# Generated at 2022-06-24 20:27:46.668895
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Arguments (positional)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = None

    # Call to default(...)
    assert ansible_j_s_o_n_encoder_0.default(o_0) == None

# Generated at 2022-06-24 20:27:48.107857
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:53.483129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:27:55.957138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Construct AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Call method default
    ansible_j_s_o_n_encoder_0.default('{ "some": "json" }')


# Generated at 2022-06-24 20:28:00.597498
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == {'__ansible_unsafe': u''}
  assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_1) == {'__ansible_unsafe': u'SECRET_PASSWORD'}


# Generated at 2022-06-24 20:28:06.000810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    v = datetime.date(2000, 1, 2)
    assert ansible_j_s_o_n_encoder_0.default(v) == '2000-01-02'
    v = datetime.datetime(2000, 1, 2, 3, 4, 5, 6, datetime.timezone.utc)
    assert ansible_j_s_o_n_encoder_0.default(v) == '2000-01-02T03:04:05.000006+00:00'


# Generated at 2022-06-24 20:28:10.434351
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # TODO: improve test for method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_1.default(None)


# Generated at 2022-06-24 20:28:14.683799
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    o = set()
    x = ansible_j_s_o_n_encoder.default(o)
    

# Generated at 2022-06-24 20:28:17.812891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default({}) == {}


# Generated at 2022-06-24 20:28:23.862706
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0_obj = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_obj.default('This is a test case for method default')


# Generated at 2022-06-24 20:28:31.922728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test with valid data
    v0, v1 = {}, "ab"
    v3 = ansible_j_s_o_n_encoder_0.default(v0)
    v4 = ansible_j_s_o_n_encoder_0.default(v1)

    # Test with invalid data
    v2 = ansible_j_s_o_n_encoder_0.default(v0)

# Generated at 2022-06-24 20:28:32.947861
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    assert True


# Generated at 2022-06-24 20:28:46.784336
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False)
    o = _is_sequence
    value = ansible_j_s_o_n_encoder_0.default(o)
    assert value == o


# Generated at 2022-06-24 20:28:57.343169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(check_circular=True, ensure_ascii=True,
                                                   indent=True, allow_nan=False,
                                                   separators=('', ':'), sort_keys=False)

    class AnsibleUnsafe_1(str):
        __UNSAFE__ = True

        def __init__(self, payload):
            self._payload = payload

    assert ansible_j_s_o_n_encoder_1.default(datetime.datetime(2018, 3, 1, 16, 43, 36, 376687)) == '2018-03-01T16:43:36.376687'

    assert ansible_j_s_o_n_encoder_1.default(None) is None

# Generated at 2022-06-24 20:29:00.200402
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = None
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:29:07.589162
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"ciphertext": "AQAAABAAAAA...", "vault_id": "507bebc9-e588-48c1-a718-6d71d6a84923"}
    assert ansible_j_s_o_n_encoder_0.default(o) == '{"ciphertext": "AQAAABAAAAA...", "vault_id": "507bebc9-e588-48c1-a718-6d71d6a84923"}'
# END of Unit test for method default of class AnsibleJSONEncoder


# Generated at 2022-06-24 20:29:12.101684
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(b'\x00') == b'\x00'


# Generated at 2022-06-24 20:29:21.579383
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(preprocess_unsafe=0)
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder(preprocess_unsafe=1)
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder(preprocess_unsafe=None)
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder(preprocess_unsafe='True')
    ansible_j_s

# Generated at 2022-06-24 20:29:28.561549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    s = '{"__ansible_vault": "VHFzdCBlbmQgaGVyZQo="}'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_vault_object_1 = {'__ENCRYPTED__': True, '_ciphertext': 'VGFzdCBlbmQgaGVyZQo='}
    ansible_vault_object_1_expected = '{"__ansible_vault": "VGFzdCBlbmQgaGVyZQo="}'
    res_list_1 = ansible_j_s_o_n_encoder_1.default(ansible_vault_object_1)
    s_1_first = json.dumps(res_list_1)
   

# Generated at 2022-06-24 20:29:38.414640
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    class MockExceptionToRaise(object):
        def __init__(self, error_message):
            self.error_message = error_message
        def __repr__(self):
            return self.error_message
    j_s_o_n_dumps_0 = {}
    with pytest.raises(MockExceptionToRaise) as e_info:
        ansible_j_s_o_n_encoder_0.default(j_s_o_n_dumps_0)
    assert e_info.match("type 'dict' is not JSON serializable")


# Generated at 2022-06-24 20:29:42.295742
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = 'dummy str'
    s = ansible_j_s_o_n_encoder_1.default(o)
    print(s)


# Generated at 2022-06-24 20:29:47.849589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(to_text(b'', encoding='utf-8'))


# Generated at 2022-06-24 20:30:10.658417
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-24 20:30:19.489018
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:30:24.709102
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # we are just testing that this doesn't blow up, see the actual unit tests in the unit/plugins/test_filter_plugins.py
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = ''
    o_0 = ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:30:31.007293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # used in tests
    test_module = 'testmodule'
    test_version = 1.0
    # used in tests
    test_dict = {'test_key': 'test_value'}
    result = ansible_j_s_o_n_encoder_0.default(test_dict)
    assert result == {'test_key': 'test_value'}
    result = ansible_j_s_o_n_encoder_0.default(test_module)
    assert result == 'testmodule'
    result = ansible_j_s_o_n_encoder_0.default(test_version)
    assert result == 1.0

# Generated at 2022-06-24 20:30:32.777870
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:39.677724
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Setting up test inputs
    o_0 = {}
    # Testing method default of class AnsibleJSONEncoder with above inputs
    assert_equal(ansible_j_s_o_n_encoder_0.default(o_0),{})


# Generated at 2022-06-24 20:30:44.872179
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Call method default of class AnsibleJSONEncoder with parameter o set to 0
    ansible_j_s_o_n_encoder_0_default_0 = ansible_j_s_o_n_encoder_0.default(0)
    # Assert method default return value equals 0
    assert ansible_j_s_o_n_encoder_0_default_0 == 0


# Generated at 2022-06-24 20:30:46.549623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  ansible_j_s_o_n_encoder_default = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:49.302217
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(str_1)



# Generated at 2022-06-24 20:30:52.592855
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:31:34.810600
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # FROM and TO are the same
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Instantiate class AnsibleUnsafe
    ansible_unsafe_0 = AnsibleUnsafe("yh.th=6/3u6w/0!@k&50o!0d0!m")
    # Assigning a type to the variable 'expected' (line 89)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 89, 8), 'expected', ansible_unsafe_0)
    # Getting the type of 'ansible_j_s_o_n_encoder_0' (line 90)

# Generated at 2022-06-24 20:31:35.723715
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:31:40.205508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    try:
        result = ansible_j_s_o_n_encoder.default()
        assert False
    except TypeError as ve:
        assert True
        # if TypeError is raised, then the default test passed
    except Exception as e:
        assert False


# Generated at 2022-06-24 20:31:47.725081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    _o = datetime.datetime(year=2015, month=11, day=4, hour=16, minute=10, second=1, microsecond=862000)
    _expected_0 = "2015-11-04T16:10:01.862000"
    _returned_0 = ansible_j_s_o_n_encoder_0.default(_o)
    #<class 'str'>
    assert(type(_returned_0) == type(_expected_0))



# Generated at 2022-06-24 20:31:56.301137
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe('password1')
    ansible_vault_0 = AnsibleVaultEncryptedUnicode('vault1')

# Generated at 2022-06-24 20:31:57.150541
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:31:59.062549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # pass


# Generated at 2022-06-24 20:32:03.246206
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    date_0 = datetime.date(2019, 4, 1)
    ansible_j_s_o_n_encoder_0.default(date_0)


# Generated at 2022-06-24 20:32:07.307828
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    i = 0
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default({'a': 0})


# Generated at 2022-06-24 20:32:11.231390
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'foo'
    value = ansible_j_s_o_n_encoder_0.default(o)
    assert value == 'foo'


# Generated at 2022-06-24 20:33:26.581239
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test with a map input
    ansible_j_s_o_n_encoder_0.default({"[hostname]": None})
    # Test with a date object
    ansible_j_s_o_n_encoder_0.default(datetime.datetime.now())
    # Test with an unsafe object
    class TestUnsafe(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False
    # Check that an unsafe object raises an exception

# Generated at 2022-06-24 20:33:32.372324
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_0 = datetime.date.today()
    #assert ansible_j_s_o_n_encoder_0.default(datetime_0) == datetime.date.today().isoformat()


# Generated at 2022-06-24 20:33:40.519083
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Tests for AnsibleJSONEncoder.default()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    return_value_0 = ansible_j_s_o_n_encoder_0.default(['1', '2', '3'])
    assert return_value_0 == ['1', '2', '3']

# Generated at 2022-06-24 20:33:50.758652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = dict({'ansible-safe': 'string_0', 'ansible-safe': 'string_1', 'ansible-safe': 'string_2', 'ansible-safe': 'string_3'})
    ansible_j_s_o_n_encoder_0.default(o_0)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_1 = dict({'ansible-safe': 'string_0', 'ansible-safe': 'string_1', 'ansible-safe': 'string_2', 'ansible-safe': 'string_3'})

# Generated at 2022-06-24 20:33:57.655511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    module = AnsibleModule(
        argument_spec = dict(
            param = dict(required=True),
        ),
        supports_check_mode=True,
    )
    module.params['param'] = 'hogehoge'
    result = ansible_j_s_o_n_encoder_0.default(module)
    assert result == '"hogehoge"'


# Generated at 2022-06-24 20:34:01.501435
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:34:07.539968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_default_obj_0 = ansible_j_s_o_n_encoder_1._default(
        ansible_j_s_o_n_encoder_0, ansible_j_s_o_n_encoder_1)
    assert ansible_json_encoder_default_obj_0 is not None



# Generated at 2022-06-24 20:34:15.539310
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_text
    from collections import Mapping
    import datetime
    from json import JSONEncoder
    from ansible.module_utils.common.collections import is_sequence
    import json
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1
    m_p_i_n_g_1 = Mapping()
    assert m_p_i_n_g_1
    t_e_x_t_1 = to_text('text text')
    assert t_e_x_t_1
    assert isinstance(t_e_x_t_1, str)

    v_a_u_l_t_t_e_x_t_1

# Generated at 2022-06-24 20:34:19.389495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_object_0 = AnsibleJSONEncoder()
    # Test using empty dict input as argument
    assert test_object_0.default(dict()) == {}


# Generated at 2022-06-24 20:34:22.890933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True
