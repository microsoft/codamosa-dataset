

# Generated at 2022-06-24 20:25:20.616465
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_password = "test"
    vault_text = VaultLib(vault_password).encrypt("test_string")

    for obj in [vault_text, AnsibleUnsafeText("test")]:
        json.dumps(obj, cls=AnsibleJSONEncoder, vault_to_text=True)
        with pytest.raises(TypeError):
            json.dumps(obj, cls=AnsibleJSONEncoder)


# Generated at 2022-06-24 20:25:21.066980
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:25:29.335271
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initializing the AnsibleJSONEncoder object;
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Testing the default method;
    ansible_j_s_o_n_encoder_0.default(complex())
    ansible_j_s_o_n_encoder_0.default(bool())
    ansible_j_s_o_n_encoder_0.default(str())
    ansible_j_s_o_n_encoder_0.default(dict())
    ansible_j_s_o_n_encoder_0.default(float())
    ansible_j_s_o_n_encoder_0.default(int())
    ansible_j_s_o_n_encoder_0.default(list())


# Generated at 2022-06-24 20:25:35.281035
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(None)
    ansible_j_s_o_n_encoder_0.default(None)
    ansible_j_s_o_n_encoder_0.default(None)



# Generated at 2022-06-24 20:25:43.441407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.dataloader
    import ansible.parsing.vault
    list_0 = ansible.parsing.dataloader.DataLoader()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_v_a_u_l_t_0 = ansible.parsing.vault.VaultSecret('12345')
    ansible_v_a_u_l_t_0.__UNSAFE__ = 1
    ansible_v_a_u_l_t_0.__ENCRYPTED__ = 1
    ansible_v_a_u_l_t_0.__UNSAFE__ = 0
    ansible_j_s_o_n_encoder_0

# Generated at 2022-06-24 20:25:45.511157
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(False)
    ansible_j_s_o_n_encoder_0.default(data_0)


# Generated at 2022-06-24 20:25:56.185358
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe_object = AnsibleUnsafe("test_unsafe")
    vaul_object = AnsibleVaultEncryptedUnicode("test_vault")
    test_object_1 = {"hello_key":"hello_value"}
    test_object_2 = [1,2,3]
    test_case_1 = datetime.date.today()
    test_case_2 = datetime.datetime.now()
    test_case_3 = "test_text"
    test_case_4 = 123
    data_set_1 = [unsafe_object, vaul_object, test_object_1, test_object_2, test_case_1, test_case_2, test_case_3, test_case_4]
    for data in data_set_1:
        test_1 = AnsibleJSONEncoder

# Generated at 2022-06-24 20:26:06.268677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    hostvars_0 = {
        'test_host': {
            'test_item': 'value',
            'test_item_2': 'value2',
            'test_hostvars_override': 'value_1',
        }
    }
    hostvars_1 = {
        'test_host': {
            'test_item': 'value',
            'test_item_2': 'value2',
            'test_hostvars_override': 'value_1',
        }
    }

# Generated at 2022-06-24 20:26:08.057302
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:26:09.048992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()
# END OF FILE

# Generated at 2022-06-24 20:26:13.396603
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    list_0 = None
    ansible_j_s_o_n_encoder_0.default(list_0)


# Generated at 2022-06-24 20:26:17.769865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = AnsibleJSONEncoder()
    # The parameter ``o`` of the method ``default`` is missing here
    with pytest.raises(TypeError) as e_info:
        ansible_j_s_o_n_encoder_1 = list_0.default()


# Generated at 2022-06-24 20:26:24.100751
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # define
    class AnsibleUnsafe(str):
        """
        Warning: This class is not fit for use in any other capacity than sending
        the value over RPC. It's not safe to use anywhere else.
        """
        def __init__(self):
            self.__UNSAFE__ = True

    obj_0 = AnsibleUnsafe()
    obj_1 = dict()

# Generated at 2022-06-24 20:26:29.516571
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
# Testing the update method of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:26:35.141143
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_1 = AnsibleJSONEncoder()
    test_json_encoder_0 = json.JSONEncoder()
    test_safe_unicode_0 = to_text('test', encoding='utf-8', errors='surrogate_or_strict', nonstring='strict')
    ansible_json_encoder_2 = ansible_json_encoder_1.default(test_safe_unicode_0)
    test_json_encoder_1 = test_json_encoder_0.default(test_safe_unicode_0)
    assert ansible_json_encoder_2 == test_json_encoder_1


# Generated at 2022-06-24 20:26:39.663800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    dict_0 = {"test": "test"}
    str_0 = to_text(dict_0)
    assert str_0 == str(ansible_j_s_o_n_encoder_0.default(dict_0))


# Generated at 2022-06-24 20:26:48.470019
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-24 20:26:58.918189
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    class AnsibleUnsafe:
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    from datetime import datetime

    # test with AnsibleUnsafe
    unsafe_obj_0 = AnsibleUnsafe()
    result = ansible_j_s_o_n_encoder_0.default(unsafe_obj_0)
    assert result == {'__ansible_unsafe': unsafe_obj_0}

    # test with vault_to_text=true and VaultSecret

# Generated at 2022-06-24 20:27:07.496052
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    ansible_j_s_o_n_encoder_0._check_circular = True
    ansible_j_s_o_n_encoder_0._allow_nan = True
    ansible_j_s_o_n_encoder_0._sort_keys = True
    ansible_j_s_o_n_encoder_0._skipkeys = True
    ansible_j_s_o_n_encoder_0._use_decimal

# Generated at 2022-06-24 20:27:11.415915
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_unsafe_0 = AnsibleUnsafe(list_0)
    o_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)

# Generated at 2022-06-24 20:27:23.475967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    # ! test for class AnsibleUnsafe
    class ansible_unsafe_0(object):
        __UNSAFE__ = True

    ansible_unsafe_0_instance_0 = ansible_unsafe_0()
    class json_0(object):
        @staticmethod
        def dumps(ansible_unsafe_0_instance_0):
            return json.dumps({'__ansible_unsafe': ansible_unsafe_0_instance_0})
    json_0_instance_0 = json_0()
    assert json_0_instance_0.dumps(ansible_unsafe_0_instance_0) == ansible_j_s_o_n

# Generated at 2022-06-24 20:27:31.640480
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    datetime_0 = datetime.datetime(2019, 7, 25, 4, 8, 4, 529031)
    str_0 = ansible_j_s_o_n_encoder_0.default(datetime_0)
    assert str_0 == "2019-07-25T04:08:04.529030"


# Generated at 2022-06-24 20:27:39.959148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

# Generated at 2022-06-24 20:27:44.009068
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = []
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(None)


# Generated at 2022-06-24 20:27:49.632785
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Instantiating an object class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(None)

    # Call method default
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default(1)

    # Check if value is equal as expected
    assert ansible_j_s_o_n_encoder_0_default == 1


# Generated at 2022-06-24 20:27:54.956335
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    list_1 = ['0', '1', '2']
    ansible_json_encoder_0.default(list_1)
    str_0 = AnsibleUnsafe('unsafe_object_0')
    ansible_json_encoder_0.default(str_0)


# Generated at 2022-06-24 20:28:00.975759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ret_val_0 = AnsibleJSONEncoder(False)
    ret_val_1 = ret_val_0.default(4)
    assert (ret_val_1 == 4)



# Generated at 2022-06-24 20:28:04.855360
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    o_0 = None
    value_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    print(value_0)
    print("ANSIBLE_ANSIBLEJSONENCODER_DEFAULT_0:PASS")


# Generated at 2022-06-24 20:28:08.587866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    default_str = "default_str"
    default_str_0 = AnsibleJSONEncoder(default_str)
    # AssertionError: AnsibleJSONEncoder(default_str) raised AssertionError not as expected


# Generated at 2022-06-24 20:28:15.241810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        text_0 = 'text'
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        # Capture the result of default

        result_default_0 = ansible_j_s_o_n_encoder_0.default(text_0)
        assert result_default_0 == 'text'
    except Exception as err:
        print(err)
        assert False



# Generated at 2022-06-24 20:28:25.847452
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert not _is_vault(ansible_j_s_o_n_encoder_0)
    assert not _is_unsafe(ansible_j_s_o_n_encoder_0)


# Generated at 2022-06-24 20:28:34.683202
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    list_1 = [0, 1, 2, 3]
    list_2 = [0, 1, 2, 3]
    list_3 = [0, 1, 2, 3]
    ansible_j_s_o_n_encoder_0.default(list_1)
    ansible_j_s_o_n_encoder_0.default(list_2)
    ansible_j_s_o_n_encoder_0.default(list_3)


# Generated at 2022-06-24 20:28:42.481509
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    list_1 = dict()
    list_2 = dict()
    list_3 = dict()
    list_4 = dict()
    ansible_v_a_u_l_t_0 = ansible_j_s_o_n_encoder_0.default(list_1)
    list_2["__ansible_vault"] = ansible_v_a_u_l_t_0
    ansible_u_n_s_a_f_e_0 = ansible_j_s_o_n_encoder_0.default(list_2)
    list_3["__ansible_unsafe"] = ansible_u_n_s_a_

# Generated at 2022-06-24 20:28:46.962632
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {'my': 'value'}
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(data)
    data_1 = ansible_j_s_o_n_encoder_1.default(data)


# Generated at 2022-06-24 20:28:48.277535
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:28:52.053740
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    bool_0 = True
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bool_0)
    ansible_j_s_o_n_encoder_0.default(list_0)


# Generated at 2022-06-24 20:28:57.609894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    o_0 = None
    # Call the method default from class AnsibleJSONEncoder with args: (o_0)
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:29:05.436678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    vault_text = '$ANSIBLE_VAULT;1.2;AES256;test\r\n333332343335333633373338333933303132333334353637383930313233343536\r\n383930313233343536373839303132333435363738393031323334353637383930\r\n313233343536373839303132333435363738393031323334353637383930313233\r\n343536373839303132333435363738393031323334353637383930313233343536\r\n373839303132'
    list_0 = None

# Generated at 2022-06-24 20:29:06.013881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:29:13.854779
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test case
    # This test case tests method default of AnsibleJSONEncoder

    unsafe_object_0 = None
    class Vault(object):
        __ENCRYPTED__ = None
    vault_object_0 = Vault()

    # Initialization
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(unsafe_object_0, vault_object_0)
    o = None
    o = unsafe_object_0
    # Testing method default of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(o)
    ansible_j_s_o_n_encoder_0.default(vault_object_0)

# Generated at 2022-06-24 20:29:22.931771
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

# Generated at 2022-06-24 20:29:26.993215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    return ansible_j_s_o_n_encoder_0.default(None)

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:30.719518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    item = 'abc'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(item)


# Generated at 2022-06-24 20:29:31.410169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:29:35.858703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default({'key': 'value'})



# Generated at 2022-06-24 20:29:44.671185
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_vault_0 = _is_vault(ansible_j_s_o_n_encoder_0)
    ansible_vault_1 = _is_vault(ansible_j_s_o_n_encoder_0)
    assert not ansible_vault_0
    assert ansible_vault_1
    ansible_unsafe_0 = _is_unsafe(ansible_j_s_o_n_encoder_0)
    assert not ansible_unsafe_0


# Generated at 2022-06-24 20:29:53.469833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
# Testing method default
# Input:
#     argument: 1
# Output:
#     value: {"__ansible_unsafe": "1"}
    list_0 = 1
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
# Testing method default
# Input:
#     argument: 1
# Output:
#     value: {"__ansible_unsafe": "1"}
    list_0 = 1
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
# Testing method default
# Input:
#     argument: 1
# Output:
#     value: {"

# Generated at 2022-06-24 20:30:02.839389
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    # __ENCRYPTED__
    vault_class_0 = ansible_j_s_o_n_encoder_0.vault_class
    getattr_0 = getattr(vault_class_0, '__ENCRYPTED__')
    assert getattr_0 == False
    # __ansible_vault
    getattr_1 = getattr(vault_class_0, '_ciphertext')
    text_0 = to_text(getattr_1, 'surrogate_or_strict')
    list_1 = ['__ansible_vault', text_0]

# Generated at 2022-06-24 20:30:08.599826
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    # Testing the default method of class AnsibleJSONEncoder
    # Creating object of class MyClass from module.
    # base class of ansible_j_s_o_n_encoder_0 is json.JSONEncoder
    # call the default method of class json.JSONEncoder
    date_0 = datetime.date(2000, 2, 1)
    ansible_j_s_o_n_encoder_0.default(date_0)



# Generated at 2022-06-24 20:30:15.074377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    datetime_0 = datetime.datetime
    str_0 = ansible_j_s_o_n_encoder_0.default(datetime_0)
    assert not isinstance(str_0, bool)
    assert not isinstance(str_0, list)
    assert not isinstance(str_0, dict)
    assert not isinstance(str_0, int)
    assert isinstance(str_0, str)


# Generated at 2022-06-24 20:30:30.104711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: implement
    pass


# Generated at 2022-06-24 20:30:33.744053
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(list_0)


# Generated at 2022-06-24 20:30:39.264748
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = copy.deepcopy(ansible_j_s_o_n_encoder)
    o = None

    # Invoke method
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert (result is None)


# Generated at 2022-06-24 20:30:42.671589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Input data
    obj = None

    # Invoke method
    ansible_json_encoder = AnsibleJSONEncoder()
    output = ansible_json_encoder.default(obj)

    # Assertion assertions
    assert isinstance(output, (type(None)))


# Generated at 2022-06-24 20:30:46.068830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    list_0 = None
    bool_0 = bool(list_0)
    bool_1 = bool(ansible_j_s_o_n_encoder_0)
    bool_2 = bool(bool_1)


# Generated at 2022-06-24 20:30:49.331349
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    date_0 = datetime.datetime.now()
    str_0 = ansible_j_s_o_n_encoder_0.default(date_0)
    assert(str_0 == date_0.isoformat())


# Generated at 2022-06-24 20:30:53.076931
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: Provide a proper test case for AnsibleJSONEncoder.default()
    cls = AnsibleJSONEncoder()
    # TODO: Add a proper test case for AnsibleJSONEncoder.default()
    assert True


# Generated at 2022-06-24 20:31:03.016190
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_unsafe_0 = AnsibleUnsafe('test_string')
    ansible_vault_0 = AnsibleVaultEncryptedUnicode(unicode('test_string'))
    ansible_vault_1 = AnsibleVaultEncryptedUnicode(unicode('test_string'))
    ansible_unsafe_1 = AnsibleUnsafe('test_string')
    ansible_vault_1.__ENCRYPTED__ = True
    ansible_vault_0.__ENCRYPTED__ = True
    #assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == {'

# Generated at 2022-06-24 20:31:06.354577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = None
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:31:10.392112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(time_0)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_1.default(time_0)

# Generated at 2022-06-24 20:31:38.581418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:31:45.310021
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    # Exception exc_0 raised during execution of default of AnsibleJSONEncoder
    # TypeError: string indices must be integers
    with pytest.raises(TypeError) as exc_0:
        ansible_j_s_o_n_encoder_0.default(list_0)
        # assert exc_0.type is TypeError
        # assert exc_0.value.args[0] == 'string indices must be integers'


# Generated at 2022-06-24 20:31:49.110184
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = AnsibleUnsafe(None, True)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default()



# Generated at 2022-06-24 20:31:58.014525
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # This is a test case for vault objects, AnsibleJSONEncoder.default
    #   should return a dict {'__ansible_vault': to_text(o._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    #    for vault objects

    # Tests for a object
    ansible_u_n_s_a_f_e_0 = '192.168.0.1'

    hostvars_0 = {'host': ansible_u_n_s_a_f_e_0}

    ansible_u_n_s_a_f_e_1 = hostvars_0

    ansible_u_n_s_a_f_e_

# Generated at 2022-06-24 20:31:59.482931
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:32:06.801537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    # Unit test for method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default('Hello, world!')
    # Unit test for method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(1)


# Generated at 2022-06-24 20:32:08.942592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    o = None
    result = obj.default(o)
    assert result is None


# Generated at 2022-06-24 20:32:12.850769
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    # TODO: INSERT test code for AnsibleJSONEncoder.default here
    # NOTE: This method is used by the iterencode method


# Generated at 2022-06-24 20:32:15.243242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)


# Generated at 2022-06-24 20:32:18.532384
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test default"""

    o = {'__ansible_unsafe': 1}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(o)
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:33:28.013165
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for method default(self, o) of class AnsibleJSONEncoder
    # This test does not have any assertions.
    test_case_0()


# Generated at 2022-06-24 20:33:37.573027
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'qux'
    dict_0['corge'] = None
    dict_0['waldo'] = 1
    dict_0['fred'] = 1.1
    dict_0['plugh'] = -1
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = False
    ansible_j_s_o_n_encoder_0._vault_to_text = False
    ansible_j_s_o_n_encoder_0.default(dict_0)


# Generated at 2022-06-24 20:33:38.944494
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 0 == 0



# Generated at 2022-06-24 20:33:42.809039
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a_j_s_o_n_encoder_0 = None
    ansible_json_encoder_0 = AnsibleJSONEncoder(a_j_s_o_n_encoder_0)
    value_0 = ansible_json_encoder_0.default(a_j_s_o_n_encoder_0)


# Generated at 2022-06-24 20:33:49.962055
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), None) is None
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), 1) == 1
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), 'string') == 'string'
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), True) == True
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), [1, 'string']) == [1, 'string']
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), {'dict': 'dict'}) == {'dict': 'dict'}


# Generated at 2022-06-24 20:33:53.431540
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test case #0
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    ansible_j_s_o_n_encoder_0.default(list_0)

# Generated at 2022-06-24 20:33:57.036444
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)
    ansible_j_s_o_n_encoder_0.default(list_0)
    pass

# Generated at 2022-06-24 20:34:00.341721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    list_0 = None
    str_0 = ansible_j_s_o_n_encoder_0.default(list_0)


# Generated at 2022-06-24 20:34:01.868685
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder('')


# Generated at 2022-06-24 20:34:05.424822
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialize the test case
    list_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(list_0)

    # Test the method
    ansible_j_s_o_n_encoder_0.default()
