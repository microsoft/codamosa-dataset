

# Generated at 2022-06-24 20:25:16.108175
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default == json.JSONEncoder.default



# Generated at 2022-06-24 20:25:22.174958
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of our class and give it some bogus input
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    o = 'blah'
    ret_val = ansible_j_s_o_n_encoder_0.default(o)

    # Now check if the return value equals what we expect
    assert ret_val == o

# Generated at 2022-06-24 20:25:29.435405
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    some_bytes = b"some bytes"
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(some_bytes)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(some_bytes)
    ansible_j_s_o_n_encoder_2.default(some_bytes)
    ansible_j_s_o_n_encoder_2.default(some_bytes)
    ansible_j_s_o_n_encoder_2.default(some_bytes)
    ansible_j_s_o_n_encoder_2.default(some_bytes)
    ansible_j_s_o_n_encoder_2.default(some_bytes)
    ansible_j_s_o_n_

# Generated at 2022-06-24 20:25:34.367765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    dict_0 = dict()
    dict_1 = dict()

# Generated at 2022-06-24 20:25:39.891924
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf8W\x19\xcd\x1a\x83\xcc\x0f\x93'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = AnsibleUnsafe(bytes_0)
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:25:44.885192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    bytes_1 = b'\xe0\x98\xcd\xa1\xd7\xb6\xef\x9f\x84\xa5\x8f\x93'
    ansible_j_s_o_n_encoder_0.default(bytes_1)


# Generated at 2022-06-24 20:25:52.189546
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = to_text(b'\xf82\xc5\x02\x99L\x8f\x80\xab', errors='surrogate_or_strict')
    
    ansible_json_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:25:59.529946
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    dict_0 = dict(__unsafe__='some string')
    str_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert isinstance(str_0, str)
    dict_1 = dict(vault_stuff='some string')
    str_1 = ansible_j_s_o_n_encoder_0.default(dict_1)
    assert isinstance(str_1, str)
    dict_2 = dict(__ansible_vault=bytes_0)
    str_2 = ansible_

# Generated at 2022-06-24 20:26:05.175751
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    print(ansible_j_s_o_n_encoder_0)
    ansible_j_s_o_n_encoder_0.default()
    print(ansible_j_s_o_n_encoder_0)



# Generated at 2022-06-24 20:26:05.777303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-24 20:26:12.996024
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    # ansible_j_s_o_n_encoder_0.default(bytes_0)
    assert True


# Generated at 2022-06-24 20:26:17.731123
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an object of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Call the default method of the object
    # assert(ansible_j_s_o_n_encoder_0.default()) == '__ansible_unsafe'



# Generated at 2022-06-24 20:26:21.203553
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\x0f\x06\x9f\x1b\xdc\x07\x08j\x0b\xaf\x8c\x82\x82\xa9\xd7\x8e\xba\x01\x1f\x1d\x08'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    int_0 = ansible_j_s_o_n_encoder_0.default(bytes_0)
    assert int_0 == None


# Generated at 2022-06-24 20:26:28.425370
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    o = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:26:31.561891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Default arguments for AnsibleJSONEncoder.default
    kwargs = {}
    f = AnsibleJSONEncoder.default

    # Call AnsibleJSONEncoder.default
    f()
    f(kwargs)


# Generated at 2022-06-24 20:26:35.674382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_default_0 = ansible_j_s_o_n_encoder_0.default("")


# Generated at 2022-06-24 20:26:42.899024
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    bytes_1 = b'\x00\x85\xc9'
    mapping_0 = {}

# Generated at 2022-06-24 20:26:46.769927
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)

    # If a data structure contains an unsafe object and it's not already in the encrypted format,
    # we need to do a preprocess on it to convert the unsafe object into it's json data

# Generated at 2022-06-24 20:26:57.364148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    object_0 = object()
    object_1 = object()
    object_2 = object()
    object_3 = object()
    object_4 = object()
    object_5 = object()
    object_6 = object()
    object_7 = object()
    object_8 = object()
    object_9 = object()
    object_10 = object()
    object_11 = object()
    object_12 = object()
    object_13 = object()
    bytes_1 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'

# Generated at 2022-06-24 20:27:08.841874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    # other object
    dict_0 = dict()
    dict_0['a'] = 'a string'
    dict_0['b'] = 'another string'
    dict_0['c'] = datetime.date(2017, 1, 1)
    dict_0['d'] = 'date string'
    dict_0['e'] = datetime.datetime(2017, 1, 2)
    dict_0['f'] = 'datetime string'
    dict_0['g'] = 'unsafe string'
    unsafe_text_0 = 'unsafe string'

# Generated at 2022-06-24 20:27:22.121104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    args = []
    vars = {}
    env = {}
    cmd = "json.dumps(args[0], cls=AnsibleJSONEncoder)"
    res = {}

    def test_0():
        a_j_o_e_0 = AnsibleJSONEncoder(**res)
        res['__ansible_vault'] = 'test'
        res['__ansible_unsafe'] = 'test'
        return ansible_j_s_o_n_encoder_0.default(res)

    def test_1():
        a_j_o_e_0 = AnsibleJSONEncoder(**res)
        res['__ansible_unsafe'] = 'test'
        res['__ansible_vault'] = 'test'
        return ansible_j_s_o_n_encoder

# Generated at 2022-06-24 20:27:29.671519
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = AnsibleUnsafe(bytes_0, True)
    value_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:27:31.900765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print("Testing AnsibleJSONEncoder.default")
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)


# Generated at 2022-06-24 20:27:39.030772
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    b''
    instance_0 = AnsibleJSONEncoder({"key_0": 0})
    ansible_u_n_s_a_f_e_0 = instance_0.default(
            b'\x85\xb2\xda\xad\x17\xfdgf\xbd\xab\xc6\xfb\xe4')
    ansible_u_n_s_a_f_e_1 = instance_0.default(
            b'\xf9\x9b\xf8\xcb\xd0\x1e\x8bF\x0b\x81\x9fl\x81')


# Generated at 2022-06-24 20:27:42.417858
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_0.default(bytes_0)


# Generated at 2022-06-24 20:27:45.474061
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert isinstance(AnsibleJSONEncoder.default, classmethod)


# Generated at 2022-06-24 20:27:49.721515
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    value_0 = ansible_j_s_o_n_encoder_0.default(value_0)
    assert False


# Generated at 2022-06-24 20:27:54.034146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # testcase_0
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default('default')


# Generated at 2022-06-24 20:27:58.044127
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xb9\x99\x11\xe1\xa1\xfb\x83\x81'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    object_0 = object()
    assert not ansible_j_s_o_n_encoder_0.default(object_0)


# Generated at 2022-06-24 20:28:00.320557
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:28:07.514157
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)

    b_s_o_n_s_t_r_i_n_g_0 = json.dumps({})

    # check the value of the variable b_s_o_n_s_t_r_i_n_g_0
    assert b_s_o_n_s_t_r_i_n_g_0 == '{}'

    str_0 = "MYt4&b4=DK]/8:dWG%w_S-iN;{-\"8B"
    ansible_unsafe_0 = str_0

   

# Generated at 2022-06-24 20:28:18.879664
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class AnsibleUnsafe(object):
        __UNSAFE__ = True

    obj_0 = AnsibleUnsafe()

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_j_s_o_n_encoder_0.default(obj_0)

    obj_1 = {'a': 'b'}

    ansible_j_s_o_n_encoder_0.default(obj_1)

    obj_2 = datetime.datetime(2016, 6, 7, 11, 44, 55, 744000)

    ansible_j_s_o_n_encoder_0.default(obj_2)

    class AnsibleVaultEncryptedUnicode(unicode):
        __ENCRYPTED__ = True

    obj_3

# Generated at 2022-06-24 20:28:25.533223
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    o = ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:28:36.047784
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_j_s_o_n

# Generated at 2022-06-24 20:28:43.418029
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_1 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_2 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_3 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'

# Generated at 2022-06-24 20:28:48.312866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default('\xef\xbe\xad\xde') == '\xef\xbe\xad\xde'
    assert AnsibleJSONEncoder.default(b'\xef\xbe\xad\xde') == '\xef\xbe\xad\xde'


# Generated at 2022-06-24 20:28:58.809850
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_test_AnsibleJSONEncoder_default_0()
    test_case_test_AnsibleJSONEncoder_default_1()
    test_case_test_AnsibleJSONEncoder_default_2()
    test_case_test_AnsibleJSONEncoder_default_3()
    test_case_test_AnsibleJSONEncoder_default_4()
    test_case_test_AnsibleJSONEncoder_default_5()
    test_case_test_AnsibleJSONEncoder_default_6()
    test_case_test_AnsibleJSONEncoder_default_7()
    test_case_test_AnsibleJSONEncoder_default_8()
    test_case_test_AnsibleJSONEncoder_default_9()
    test_case_test_Ans

# Generated at 2022-06-24 20:29:03.339575
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    b_o_0 = object()
    boolean_0 = ansible_j_s_o_n_encoder_0.default(b_o_0)
    assert not boolean_0


# Generated at 2022-06-24 20:29:09.585293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = 'N'
    ansible_vault_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_json_encoder_0 = AnsibleJSONEncoder(ansible_vault_0)
    # Default of class AnsibleJSONEncoder
    dict_0 = ansible_json_encoder_0.default(ansible_vault_0)
    assert dict_0 == {'__ansible_vault': 'N'}


# Generated at 2022-06-24 20:29:13.660916
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'mb\xfc<\xcd\xf7\x94\xe6'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    o = {}
    out = ansible_j_s_o_n_encoder_0.default(o)
    assert out == o


# Generated at 2022-06-24 20:29:26.651734
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o_1 = '\xc5\xf8\x99L\xae\x90\x8e\xca\x04\x02\x02\x08'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(o_1)
    s_1 = ansible_j_s_o_n_encoder_1.default(o_1)
    s_2 = ansible_j_s_o_n_encoder_1.default(o_1)
    s_3 = ansible_j_s_o_n_encoder_1.default(o_1)

    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(o_1)
    s_4 = ansible_j_s_o_n_

# Generated at 2022-06-24 20:29:37.818392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    bytes_1 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0.default(bytes_1)
    bytes_2 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0.default(bytes_2)

# Generated at 2022-06-24 20:29:43.222011
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with vars
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)

    # Test with args
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(bytes_0)

# Generated at 2022-06-24 20:29:53.138171
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    string_0 = '\u003c'
    string_1 = '\u003d'
    bytes_0 = b'\x0c\xd1\xa8\xf7\xdc\xb9\xca\xa6U\xdb\xa1\x86R\x90\xb1'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_1._vault_to_text = True
    ansible_j_s_o_n_encoder_2

# Generated at 2022-06-24 20:29:57.065549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = None
    a_j_s_o_n_encoder_0 = AnsibleJSONEncoder(indent = 2)
    # testing for ValueError
    try:
        a_j_s_o_n_encoder_0.default(o)
    except ValueError:
        pass


# Generated at 2022-06-24 20:30:02.246888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_json_encoder_0 = AnsibleJSONEncoder(bytes_0)
    # call method default
    str_0 = ansible_json_encoder_0.default(bytes_0)
    assert str_0 == '+H1xJhFg8yP5'


# Generated at 2022-06-24 20:30:08.005891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialize instance of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Initialize variable 'o_0' with value
    o_0 = ['AnsibleModule', 'AnsibleVaultEncryptedUnicode', 'AnsibleUnsafe', 'AnsibleUnsafeText', 'to_text', 'to_bytes', 'AnsibleUnicode', 'to_native', 'AnsibleUnsafeBytes']
    # Call method default of AnsibleJSONEncoder with parameters o_0
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:30:10.761406
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default()
    

# Generated at 2022-06-24 20:30:14.416655
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    fixture_0 = ['date', 'dict', 'init', 'json', 'mappingproxy', 'repr', 'str', 'tuple', 'type', 'unicode']
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(fixture_0)



# Generated at 2022-06-24 20:30:23.468074
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = AnsibleUnsafe('secret:p4ssw0rd')
    ansible_unsafe_1 = AnsibleUnsafe('secret_p4ssw0rd')
    vault_0 = VaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible;11341208142734093731;')
    vault_0._ciphertext = 'AES256$foobarbaz'
    class_0 = type('', (object,), dict(i_var='foo', j_var='bar'))


# Generated at 2022-06-24 20:30:39.113124
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:30:42.687725
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:47.134620
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0  = AnsibleJSONEncoder(bytes_0)
    str_0 = ansible_j_s_o_n_encoder_0.default
    assert callable(str_0)
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:30:48.516191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    pass


# Generated at 2022-06-24 20:30:59.234100
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:31:03.056825
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = None
    ansible_JSON_encoder_0 = AnsibleJSONEncoder()
    ansible_JSON_encoder_1 = AnsibleJSONEncoder()

    ansible_JSON_encoder_0.default(o)
    ansible_JSON_encoder_1.default(o)


# Generated at 2022-06-24 20:31:12.732218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    # Test error in case 0
    try:
        ansible_j_s_o_n_encoder_0.default()
        # Test error in case 1
        try:
            ansible_j_s_o_n_encoder_0.default(bytes_0)
            # Test error in case 2
            try:
                ansible_j_s_o_n_encoder_0.default(bytes_0, bytes_0)
            except:
                pass
        except:
            pass
    except:
        pass


# Generated at 2022-06-24 20:31:16.353107
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b''
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    int_0 = 1
    ansible_j_s_o_n_encoder_0.default(int_0)


# Generated at 2022-06-24 20:31:19.810367
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert False


# Generated at 2022-06-24 20:31:26.258384
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    s = u'bar'
    o = {u'foo': s}
    bytes_0 = b'\xf8\x02\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    value = ansible_j_s_o_n_encoder_0.default(s)
    value = ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:31:39.035243
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    datetime_0 = datetime.datetime(2018, 1, 31, 11, 42, 2, tzinfo=datetime.timezone.utc)
    ansible_jsonencoder_default_0 = ansible_j_s_o_n_encoder_0.default(datetime_0)
    assert(ansible_jsonencoder_default_0 == '2018-01-31T11:42:02+00:00')


# Generated at 2022-06-24 20:31:42.493474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o_0 = 'default'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(o_0)
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:31:50.721378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_1 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_2 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_3 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_4 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    bytes_5 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'

# Generated at 2022-06-24 20:31:55.172817
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(True)
    assert ansible_j_s_o_n_encoder_0.default(datetime.datetime.now()) == '\'' + datetime.datetime.now().isoformat() + '\''


# Generated at 2022-06-24 20:31:56.066441
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:32:03.107094
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    # should trigger exception

    class Class_0():
        def __init__(self, my_str):
            self._ciphertext = my_str
        def method_0(self):
            return 'method'

    class Class_1():
        def __init__(self, my_str):
            self.my_str = my_str
        def __len__(self):
            return len(self.my_str)
        def __repr__(self):
            return self.my_str

# Generated at 2022-06-24 20:32:08.598604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    generator_0 = AnsibleJSONEncoder()
    generator_0.default({})
    generator_0.default('\xf82\xc5\x02\x99L\x8f\x80\xab')
    generator_0.default(b'\xf82\xc5\x02\x99L\x8f\x80\xab')


# Generated at 2022-06-24 20:32:17.746431
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils
    from ansible.module_utils.common._collections_compat import Mapping

    # This is the encoding for
    #   ansible.module_utils.__file__
    string0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    # Create instance of class AnsibleJSONEncoder with argument 'mapping0'.

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(mapping0)

    # Assert that the value of attribute _encoding of instance
    #   ansible_j_s_o_n_encoder_0 equals string0
    assert (ansible_j_s_o_n_encoder_0._encoding == string0)

    # Assert that the value

# Generated at 2022-06-24 20:32:21.495916
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    datetime_0 = datetime.datetime(2018, 9, 15, 22, 20, 35, tzinfo=datetime.timezone(datetime.timedelta(0)))
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(datetime_0)


# Generated at 2022-06-24 20:32:24.446569
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_0.default(0)


# Generated at 2022-06-24 20:32:35.222896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafeSuper:

        def __init__(self, arg_0):
            self.__ansible_unsafe_val = arg_0

        def __str__(self):
            return self.__ansible_unsafe_val

        def __repr__(self):
            return self.__ansible_unsafe_val

        def __getattr__(self, arg_0):
            return self.__getattribute__(arg_0)

        def __setattr__(self, arg_0, arg_1):
            self.__dict__[arg_0] = arg_1

    class AnsibleUnsafe(AnsibleUnsafeSuper):

        def __init__(self, arg_0):
            super(AnsibleUnsafe, self).__init__(arg_0)
            self.__unsafe

# Generated at 2022-06-24 20:32:40.789864
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_0.default("hello")



# Generated at 2022-06-24 20:32:49.834884
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # AnsibleUnsafe object
    ansible_unsafe_object_0 = AnsibleUnsafe(b'foobar')
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_object_0)
    # Simple mapping object
    simple_mapping_object_0 = {'foobar': 'foobar'}
    ansible_j_s_o_n_encoder_0.default(simple_mapping_object_0)
    # Safe object
    safe_object_0 = Safe(b'foobar')
    ansible_j_s_o_n_encoder_0.default(safe_object_0)
    # AnsibleVaultEncryptedUnicode object


# Generated at 2022-06-24 20:32:50.599731
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:32:57.021252
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Constructor test
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    datetime_0 = datetime.datetime.now()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(False, False)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder.default(datetime_0)
    # Verify the type of the return value
    assert isinstance(ansible_j_s_o_n_encoder_2, str)


# Generated at 2022-06-24 20:33:04.218538
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\x1e\x88\x11\x8a\x0b\xeb'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    datetime_0 = datetime.datetime(2004, 2, 3, 2, 1, 2, 613678)
    ansible_j_s_o_n_encoder_0.default(datetime_0)


# Generated at 2022-06-24 20:33:12.606555
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default({'foo': 'bar'})
    # FIXME: This test is not passing due to inconsistencies in what
    # the default serializer does on different python versions
    # assert str_0 == json.dumps({'foo': 'bar'})

    class Custom(object):
        def __json__(self):
            return 'test'

    # FIXME: This test is not passing due to inconsistencies in what
    # the default serializer does on different python versions
    # str_1 = ansible_j_s_o_n_encoder_0.default(Custom())
    # assert str_1 == json.dumps('test')

# Generated at 2022-06-24 20:33:19.553790
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert None == AnsibleJSONEncoder().default(None)
    assert dict == AnsibleJSONEncoder().default(dict()).__class__
    assert list == AnsibleJSONEncoder().default(list()).__class__
    assert str == AnsibleJSONEncoder().default(str()).__class__
    assert bytes == AnsibleJSONEncoder().default(bytes()).__class__
    assert tuple == AnsibleJSONEncoder().default(tuple()).__class__


# Generated at 2022-06-24 20:33:20.425768
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # check if object is a json object
    assert True


# Generated at 2022-06-24 20:33:26.117428
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    datetime_0 = datetime.datetime(2018, 1, 30, 13, 59, 21, 840153)
    unicode_0 = u'\u043a\u0438\u0442\u0430\u0439'
    dict_0 = {unicode_0: datetime_0}

# Generated at 2022-06-24 20:33:34.468677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)


# Generated at 2022-06-24 20:33:41.112808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default(str(1))
    assert value == 1
    value = ansible_j_s_o_n_encoder_0.default(str(1.1))
    assert value == 1.1



# Generated at 2022-06-24 20:33:49.473906
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # mock_obj
    class Itf:
        def __init__(self):
            pass
        def __ENCRYPTED__(self):
            return '__ENCRYPTED__'
        def __UNSAFE__(self):
            return '__UNSAFE__'
        @property
        def _ciphertext(self):
            return '_ciphertext'
    mock_obj = Itf()
    ansible_json_encoder_obj = AnsibleJSONEncoder()
    assert ansible_json_encoder_obj.default(mock_obj) == {'__ansible_vault': '_ciphertext'}

# Generated at 2022-06-24 20:33:55.740811
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = AnsibleUnsafe('\x181\x03')
    ret = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    assert ret is not None
    assert _is_vault(ansible_unsafe_0) == False


# Generated at 2022-06-24 20:34:01.436994
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\x99\x0b\xce\xd2\x1b\xf6GC\xaf)G\x9b'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    primitive_type_0 = bytes_0
    primitive_type_1 = ansible_j_s_o_n_encoder_0.default(primitive_type_0)



# Generated at 2022-06-24 20:34:09.900433
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf8\x13\x03\xd2\x03$\x8a\x06\xbd\x14\xdf\x8c\x9a/\xda\x90\x8f\x92\xc3\x15N\x0b'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)

    bytes_2 = b'\x1c\x02\xee\xd2\xdd\xc4\xbe\x9f\x8f\x9a\x88\x14\xdf&vm\xc3\xab\x11\xfe'
    ansible_u_n_s_a_f_e_2 = AnsibleUnsafe(bytes_2)
    ansible

# Generated at 2022-06-24 20:34:12.956328
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)


# Generated at 2022-06-24 20:34:21.539735
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\x17\xe3\x8f\x03\x91\x80\x92R'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)

    decimal_0 = decimal.Decimal('-13.05')
    ansible_j_s_o_n_encoder_0.default(decimal_0)


# Generated at 2022-06-24 20:34:23.324165
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    expected = b'{"__ansible_unsafe": "Password"}'
    actual = AnsibleJSONEncoder().encode({'__ansible_unsafe': 'Password'})
    assert actual == expected


# Generated at 2022-06-24 20:34:29.773376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = os.urandom(8)
    bytes_1 = os.urandom(8)
    bytes_2 = os.urandom(8)
    bytes_3 = os.urandom(8)
    bytes_4 = os.urandom(8)
    a_j_e_0 = AnsibleJSONEncoder(bytes_0, bytes_1, bytes_2, bytes_3, bytes_4)
    with pytest.raises(TypeError):
        a_j_e_0.default(bytes_0)
    with pytest.raises(TypeError):
        a_j_e_0.default(bytes_1)
    with pytest.raises(TypeError):
        a_j_e_0.default(bytes_2)
    with pytest.raises(TypeError):
        a

# Generated at 2022-06-24 20:34:47.179099
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_unsafe_0 = 'Some'
    ansible_unsafe_0_instance_0 = ansible_unsafe_0.casefold()
    ansible_unsafe_0_instance_0.__UNSAFE__ = True
    # Call method default of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0_instance_0)


# Generated at 2022-06-24 20:34:56.044516
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_0.default("string_0"), str)
    assert ansible_j_s_o_n_encoder_0.default("string_0") == "string_0"
    assert isinstance(ansible_j_s_o_n_encoder_0.default(""), str)
    assert ansible_j_s_o_n_encoder_0.default("") == ""
    assert isinstance(ansible_j_s_o_n_encoder_0.default("string_0"), str)
    assert ansible_j_s_o_n_encoder_0.default("string_0") == "string_0"

# Generated at 2022-06-24 20:34:57.301180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:35:03.245630
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xca\xf1\xef\xde\x8b\x85_'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)
    # unit test for AnsibleJSONEncoder.default



# Generated at 2022-06-24 20:35:09.313512
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    #assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == ansible_u_n_s_a_f_e_0


# Generated at 2022-06-24 20:35:17.035126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    bytes_0 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(bytes_0)
    bytes_1 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(bytes_1)
    bytes_2 = b'\xf82\xc5\x02\x99L\x8f\x80\xab'
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(bytes_2)