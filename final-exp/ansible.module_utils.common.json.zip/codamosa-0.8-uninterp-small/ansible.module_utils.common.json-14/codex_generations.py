

# Generated at 2022-06-24 20:25:17.626874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Default values of arguments:
    #   o = None
    try:
        ansible_j_s_o_n_encoder_0.default()
    except TypeError as e:
        print(e)
        assert False


# Generated at 2022-06-24 20:25:18.936665
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:25:20.697075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_0, AnsibleJSONEncoder)

# Generated at 2022-06-24 20:25:26.209169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_default_AnsibleJSONEncoder_0()
    test_case_default_AnsibleJSONEncoder_1()
    test_case_default_AnsibleJSONEncoder_2()
    test_case_default_AnsibleJSONEncoder_3()
    test_case_default_AnsibleJSONEncoder_4()
    test_case_default_AnsibleJSONEncoder_5()



# Generated at 2022-06-24 20:25:30.075042
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'foo'
    AnsibleJSONEncoder.default(ansible_j_s_o_n_encoder_0, o)


# Generated at 2022-06-24 20:25:38.237255
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(None) == None
    # assert ansible_j_s_o_n_encoder_0.default(Unsafe('')) == {}
    # assert ansible_j_s_o_n_encoder_0.default(Vault('')) == {}
    # assert ansible_j_s_o_n_encoder_0.default({}) == {}
    # assert ansible_j_s_o_n_encoder_0.default(datetime.datetime.now()) == {}


# Generated at 2022-06-24 20:25:40.699912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_2 = ansible_j_s_o_n_encoder_1.default(3)


# Generated at 2022-06-24 20:25:43.177272
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"foo": "bar"}
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:25:52.472092
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default({}) == {}
    assert ansible_j_s_o_n_encoder_0.default(Date = datetime.date(1978,10,13)) == '1978-10-13'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default({Date : datetime.date(1978,10,13)}) == {'Date' : '1978-10-13'}



# Generated at 2022-06-24 20:25:53.835448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:01.309765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    param_0 = None
    result = ansible_j_s_o_n_encoder_0.default(param_0)
    assert result is None

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    param_0 = 0
    result = ansible_j_s_o_n_encoder_1.default(param_0)
    assert result == 0

    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    param_0 = 'hi'
    result = ansible_j_s_o_n_encoder_2.default(param_0)
    assert result == 'hi'

    ansible_j_

# Generated at 2022-06-24 20:26:06.550991
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_safe_0 = to_text(u'this is unsafe')
    o = ansible_u_n_safe_0
    v = ansible_j_s_o_n_encoder_0.default(o)
    assert v == 'this is unsafe'


# Generated at 2022-06-24 20:26:11.545599
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # str_arg_0 = ansible_j_s_o_n_encoder_0.default(Pass the value of the first argument to this function. )
    # assert isinstance(str_arg_0, str)
    pass

# Generated at 2022-06-24 20:26:13.526703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:16.947356
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    ansible_j_s_o_n_encoder_0.default(o_0)

# Generated at 2022-06-24 20:26:21.696940
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:26.198332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default('0')
    assert value == '0'


# Generated at 2022-06-24 20:26:28.979983
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO
    pass

# Generated at 2022-06-24 20:26:35.644959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    vault_0 = VaultLib({})
    ansible_v_a_u_l_t_0 = vault_0.encrypt(b'mysecret')
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_0)


# Generated at 2022-06-24 20:26:38.174981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=3)


# Generated at 2022-06-24 20:26:45.937942
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # TODO Use assertIsInstance(instance, cls, msg=None) instead of assertTrue(isinstance(instance, cls)), or check the types of the arguments passed to default
    # assertTrue(isinstance(ansible_j_s_o_n_encoder_0.default(''), str))


# Generated at 2022-06-24 20:26:51.091988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = AnsibleParserError("Test message")
    test_default_result_1 = ansible_j_s_o_n_encoder_1.default(o)
    assert test_default_result_1 == {"message": "Test message"}


# Generated at 2022-06-24 20:27:00.905380
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=False)
    assert 0 == len(ansible_j_s_o_n_encoder_0.default([]))
    assert '' == ansible_j_s_o_n_encoder_0.default('')
    assert 0 == ansible_j_s_o_n_encoder_0.default(0)
    assert '{' + '"' + 'foo' + '"' + ':' + '"' + 'bar' + '"' + '}' == ansible_j_s_o_n_encoder_0.default({'foo': 'bar'})

# Generated at 2022-06-24 20:27:02.359190
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert True

# Generated at 2022-06-24 20:27:06.537147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = "<ansible.parsing.vault.VaultSecret object at 0x7f19f67376a0>"
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(str_0)


# Generated at 2022-06-24 20:27:14.838070
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_str_0 = 'AnsibleUnsafe'
    o = set(['AnsibleVaultEncryptedUnsafe'])
    ansible_j_s_o_n_encoder_0.default(o)
    ansible_vault_enc_unsafe_0 = AnsibleVaultEncryptedUnsafe('AnsibleVaultEncryptedUnsafe')
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_str_0)
    ansible_vault_str_0 = 'AnsibleVault'
    o = [ansible_vault_str_0, ansible_vault_enc_unsafe_0]
    ansible_j

# Generated at 2022-06-24 20:27:22.963178
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e = AnsibleUnsafe('This is unsafe')
    ansible_v_a_u_l_t = AnsibleVaultEncryptedUnicode('Vault')
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e)
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t)



# Generated at 2022-06-24 20:27:34.067142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_1 = AnsibleJSONEncoder()
    ansible_json_encoder_2 = AnsibleJSONEncoder()
    ansible_json_encoder_3 = AnsibleJSONEncoder()
    ansible_json_encoder_4 = AnsibleJSONEncoder()
    ansible_json_encoder_5 = AnsibleJSONEncoder()
    ansible_json_encoder_6 = AnsibleJSONEncoder()
    ansible_json_encoder_7 = AnsibleJSONEncoder()
    ansible_json_encoder_8 = AnsibleJSONEncoder()
    ansible_json_encoder_9 = AnsibleJSONEncoder()
    ansible_json_encoder_10 = AnsibleJSONEncoder()
   

# Generated at 2022-06-24 20:27:38.601102
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # It's possible to pass in a variable that doesn't have a method '__ENCRYPTED__'
    ansible_j_s_o_n_encoder_0.default('ansible')


# Generated at 2022-06-24 20:27:44.413292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    o_1 = ansible_j_s_o_n_encoder_0.default(o_0)
    assert isinstance(o_1, dict)
    assert len(o_1) == 0

if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:27:53.015638
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default(o={'foo': 'bar'})


# Generated at 2022-06-24 20:27:55.700266
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class MockClass:
        pass

    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder.default(MockClass()) is not None


# Generated at 2022-06-24 20:28:04.418304
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default('') == ''
    assert ansible_j_s_o_n_encoder_0.default('test_value') == 'test_value'
    assert ansible_j_s_o_n_encoder_0.default(1) == 1
    assert ansible_j_s_o_n_encoder_0.default(1.0) == 1.0
    assert ansible_j_s_o_n_encoder_0.default(1) == 1
    assert ansible_j_s_o_n_encoder_0.default(1.0) == 1.0
    assert ansible_j_s_o_

# Generated at 2022-06-24 20:28:09.188901
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    o = datetime.date(2019, 1, 1)
    result = ansible_j_s_o_n_encoder_1.default(o)
    assert result == "2019-01-01"


# Generated at 2022-06-24 20:28:13.070210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = None
    val = ansible_j_s_o_n_encoder_1.default(o)
    return val



# Generated at 2022-06-24 20:28:14.930728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  c = AnsibleJSONEncoder()
  assert c.default is None


# Generated at 2022-06-24 20:28:23.201633
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        # Unit test to check the default behavior of method default of class AnsibleJSONEncoder
        ansible_j_s_o_n_encoder_0.default(o=dict())
    except Exception as exception_0:
        print(f"Exception in default of AnsibleJSONEncoder:{exception_0}")

    try:
        # Unit test to check the default behavior of method default of class AnsibleJSONEncoder
        ansible_j_s_o_n_encoder_0.default(o=datetime.datetime.now().date())
    except Exception as exception_1:
        print(f"Exception in default of AnsibleJSONEncoder:{exception_1}")


# Generated at 2022-06-24 20:28:33.698842
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    o_2 = VaultLib()
    o_3 = VaultLib()
    o_3._ciphertext = 'test_value'
    # Make sure that you are testing a known case and not just testing in whatever state the default is
    assert ansible_j_s_o_n_encoder_1.default(o_2) == {}
    assert ansible_j_s_o_n_encoder_1.default(o_3) == {'__ansible_vault': 'test_value'}


# Generated at 2022-06-24 20:28:34.981321
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None


# Generated at 2022-06-24 20:28:36.705148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:47.283142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    assert obj.default({}) == {}


# Generated at 2022-06-24 20:28:49.143296
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # call the function
    ansible_json_encoder = AnsibleJSONEncoder.default(None)


# Generated at 2022-06-24 20:28:58.557877
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of a class inheriting from AnsibleUnsafe
    class class_0(object):
        pass
    ansible_u_n_s_a_f_e_0 = class_0()
    ansible_u_n_s_a_f_e_0.__UNSAFE__ = True
    ansible_u_n_s_a_f_e_0.__ENCRYPTED__ = False
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)


# Generated at 2022-06-24 20:29:03.841606
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = ansible_j_s_o_n_encoder_0.default(None)
    ansible_u_n_s_a_f_e_1 = ansible_j_s_o_n_encoder_0.default(None)
    assert ansible_u_n_s_a_f_e_0 == ansible_u_n_s_a_f_e_1


# Generated at 2022-06-24 20:29:08.605008
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = None
    o_0 = ansible_u_n_s_a_f_e_0
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:29:13.518991
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_j_s_o_n_encoder_0.default(o=o_0)


if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:16.402051
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    json.JSONEncoder.default(ansible_j_s_o_n_encoder_0, o)


# Generated at 2022-06-24 20:29:16.946614
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-24 20:29:18.625344
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:25.997458
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0._vault_to_text = True
    ansible_json_encoder_0._preprocess_unsafe = True
    o = {"a": 3}
    assert ansible_json_encoder_0.default(o) == o
    o = "abcd"
    assert ansible_json_encoder_0.default(o) == o
    o = datetime.date(2019, 8, 14)
    assert ansible_json_encoder_0.default(o) == "2019-08-14"


# Generated at 2022-06-24 20:29:44.499849
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Check for expected argument values
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Not possible to test every possible combination of valid input
    # But this is a lot better than not testing anything
    o_0 = {'abc': 'abc'}
    result_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    assert(result_0 == {'abc': 'abc'})
    o_1 = ['abc', 'def']
    result_1 = ansible_j_s_o_n_encoder_0.default(o_1)
    assert(result_1 == ['abc', 'def'])
    o_2 = 'abc'
    result_2 = ansible_j_s_o_n_encoder_

# Generated at 2022-06-24 20:29:53.330980
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    string_0 = 'GQ#i\' \'Fy-EI(wF)IjK}O'
    boolean_0 = True
    string_1 = 'j-LWfu#\'$vw@'
    boolean_1 = False
    string_2 = 'j-LWfu#\'$vw@'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(string_0)
    boolean_2 = ansible_j_s_o_n_encoder_0.default(boolean_0)
    str_1 = ansible_j_s_o_n_encoder_0.default(string_1)
    boolean_3 = ansible_j_

# Generated at 2022-06-24 20:29:58.153783
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder
    o = 'foo'

    # If the argument is a string, return it
    # unchanged.
    assert ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0, o) == o


# Generated at 2022-06-24 20:30:00.841824
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:30:03.390376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o)



# Generated at 2022-06-24 20:30:05.600354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # ansible_j_s_o_n_encoder_1.default()
    pass


# Generated at 2022-06-24 20:30:10.048175
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o='')


# Generated at 2022-06-24 20:30:19.046384
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

try:
    load_entry_point(
        "_ansible_module_utils", "json_compat", "json.tool"
    )
except (ImportError, AttributeError):
    # Create a new module object with a name matching the import target
    import sys

    mod = types.ModuleType("_ansible_module_utils.json_compat.json.tool")
    # Add this module to the import cache
    sys.modules[mod.__name__] = mod

    # Set the module globals
    setattr(mod, "main", main)
    for name, value in globals().items():
        if name.startswith("_"):
            continue
        elif not hasattr(value, "__module__"):
            continue

# Generated at 2022-06-24 20:30:24.987146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    o = {'as': 'df', 'df': 'as'}
    # SAMPLE CODE STARTS HERE

    # The method can be invoked with the default values of all parameters
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_v_a_l_u_e_0 = ansible_j_s_o_n_encoder_0.default(o)

    # SAMPLE CODE ENDS HERE
    assert (o == o_v_a_l_u_e_0)



# Generated at 2022-06-24 20:30:27.189862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default()


# Generated at 2022-06-24 20:30:47.529667
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default({1:2})


# Generated at 2022-06-24 20:30:56.543594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    hostvars = {'inventory_hostname': 'localhost', 'ansible_hostname': 'localhost', 'ansible_fqdn': 'localhost', 'ansible_all_ipv4_addresses': ['127.0.0.1', '10.0.2.15'], 'ansible_default_ipv4': {'address': '127.0.0.1', 'alias': 'localhost', 'gateway': '10.0.2.2', 'interface': 'lo', 'macaddress': '00:00:00:00:00:00'}, 'ansible_default_ipv6': {}}
    ansible_json_encoder_0_fn = AnsibleJSONEncoder.default
    ansible_json_enc

# Generated at 2022-06-24 20:31:02.214262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = "An encrypted string"
    assert ansible_j_s_o_n_encoder_0.default(o) == "An encrypted string"

# Generated at 2022-06-24 20:31:07.399313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(datetime.date(2019, 12, 12))
    ansible_j_s_o_n_encoder_1.default(datetime.datetime(2011, 12, 12, 12, 12, 12, 120))
    ansible_j_s_o_n_encoder_1.default({'test': 'test'})


# Generated at 2022-06-24 20:31:16.808771
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(False, False)
    str_1 = to_text(ansible_j_s_o_n_encoder_0.default({'__ansible_vars': '', '__ansible_unsafe': ''}))
    str_2 = to_text(ansible_j_s_o_n_encoder_0.default({'__ansible_vars': '', '__ansible_unsafe': '', '__ansible_vault': ''}))

# Generated at 2022-06-24 20:31:20.553183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    my_json_obj = { "name": "John", "age": 30, "car": None }
    result = ansible_j_s_o_n_encoder.default(my_json_obj)
    assert result == { "name": "John", "age": 30, "car": None }


# Generated at 2022-06-24 20:31:28.857194
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    vault_editor_0 = VaultEditor(password="secret", filename="test.yml", vault_id=None)
    vault_editor_0._read_file()
    vault_editor_0._load_data_from_file()
    vault_editor_0._decrypt_data()
    vault_lib_0 = VaultLib("secret", filename="test.yml", vault_id=None)
    vault_lib_0._load_data_from_file()
    vault_lib_0._decrypt_data()
    vault_editor_0._decrypted_data = vault_lib_0._decrypted_

# Generated at 2022-06-24 20:31:33.703967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # This code will be executed only if this module is run as a script
    # and not imported as a module.
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    ansible_unsafe = ansible_j_s_o_n_encoder.default(o="ansible_unsafe")
    assert ansible_unsafe == "ansible_unsafe"

# Generated at 2022-06-24 20:31:36.647456
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert (ansible_j_s_o_n_encoder_0.default('test_value')) == 'test_value'


# Generated at 2022-06-24 20:31:38.813339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_default = ansible_j_s_o_n_encoder_0.default(o=42)
    assert ansible_json_encoder_default == 42


# Generated at 2022-06-24 20:32:19.094127
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=b'')


# Generated at 2022-06-24 20:32:21.988818
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'test'
    assert ansible_j_s_o_n_encoder_0.default(o) == 'test'


# Generated at 2022-06-24 20:32:22.820975
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(AnsibleJSONEncoder().default(5) == 5)


# Generated at 2022-06-24 20:32:24.861678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test with valid inputs
    ansible_j_s_o_n_encoder_0.default("hello")

# Generated at 2022-06-24 20:32:27.801798
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0_default_unnamed_var_0 = ansible_json_encoder_0.default("ansible_0")


# Generated at 2022-06-24 20:32:31.249323
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        ansible_j_s_o_n_encoder_0.default()


# Generated at 2022-06-24 20:32:37.646427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = datetime.date(2020, 7, 28)
    value_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    condition_0_0 = value_0 == "2020-07-28"
    assert condition_0_0

test_case_0()
test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:32:42.645761
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    instance_0 = AnsibleJSONEncoder()

    param_0=None

    # Test method default of class AnsibleJSONEncoder with arguments [param_0]
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = instance_0.default(param_0)


# Generated at 2022-06-24 20:32:46.135604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert False, "Test for method or function test_AnsibleJSONEncoder_default hasn't been implemented yet."


# Generated at 2022-06-24 20:32:53.249323
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Encoded string literal of the JSON string: '{"test": "test"}'
    _raw_J_S_O_N_00 = b'{"test": "test"}'
    _raw_J_S_O_N_01 = b'{"test": "test"}'

    # JSON string: '{"test": "test"}'
    _J_S_O_N_00 = b'{"test": "test"}'
    _J_S_O_N_01 = _J_S_O_N_00

    # Decoded object of the JSON string: '{"test": "test"}'
    _J_S_O_N_OBJ_00 = {'test': 'test'}
    _J_S

# Generated at 2022-06-24 20:34:13.839572
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import AnsibleUnsafe
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder().default(10)
    ansible_j_s_o_n_encoder_default_1 = AnsibleJSONEncoder().default("ansible")
    ansible_j_s_o_n_encoder_default_2 = AnsibleJSONEncoder().default(AnsibleUnsafe("ansible"))


# Generated at 2022-06-24 20:34:25.937912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    ansible_unsafe_0 = to_text('test')
    # 'test'
    ansible_vault_0 = ansible_unsafe_0.vault_encode('test')
    # '$ANSIBLE_VAULT;1.2;AES256;ansible\n63626664646639313331333131613239376435383338376338306535653362616130303635666564\n3864356639656566373139376431336439616532396162326330303939653166623939336631613136\n383664316338323462316564666

# Generated at 2022-06-24 20:34:31.653924
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = 'ansible_variable'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    print(ansible_j_s_o_n_encoder_0.default(value))


# Generated at 2022-06-24 20:34:38.717750
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_date_0 = datetime.date(2019, 1, 1)
    str_1 = ansible_j_s_o_n_encoder_0.default (datetime_date_0)
    assert str_1 == '2019-01-01'

# Generated at 2022-06-24 20:34:43.348396
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(1) == 1

# Generated at 2022-06-24 20:34:47.453056
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:34:49.840465
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_0.default(o='o_0')


# Generated at 2022-06-24 20:34:52.252377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:34:55.110156
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ''
    ansible_unsafe_0 = ansible_unsafe_0.__UNSAFE__
    ansible_unsafe_0 = ansible_unsafe_0.__ENCRYPTED__
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:34:59.730641
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    d = datetime.datetime.now()
    assert ansible_j_s_o_n_encoder_0.default(d) == d.isoformat()
