

# Generated at 2022-06-24 20:25:16.182933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert (AnsibleJSONEncoder().default({})) is not None


# Generated at 2022-06-24 20:25:21.145755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder1 = AnsibleJSONEncoder()
    o = None
    ansible_json_encoder1.default(o)


# Generated at 2022-06-24 20:25:23.061512
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:25:27.306044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    # TODO: Mock the classes AnsibleUnsafe and VaultSecret so we can test it
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = _Mock_AnsibleUnsafe()
    # TODO: Assert the result is what we expect
    ansible_j_s_o_n_encoder_0.default(o)
    """
    pass


# Generated at 2022-06-24 20:25:32.113549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default(None)
    except RuntimeError as e:
        print (str(e) + "\n")
        assert True



# Generated at 2022-06-24 20:25:35.828560
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"key": "value"}
    assert ansible_j_s_o_n_encoder_0.default(o) == o


# Generated at 2022-06-24 20:25:38.494992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('test_value')


# Generated at 2022-06-24 20:25:40.915940
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_1 = ansible_j_s_o_n_encoder_1.default('')


# Generated at 2022-06-24 20:25:46.974441
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert ansible_j_s_o_n_encoder_0.default('__cipher_key_unwrapped_by_ansible__') is not None
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ansible_j_s_o_n_encoder_1.default('__ansible_unsafe') is not None
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert ansible_j_s

# Generated at 2022-06-24 20:25:52.507254
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(datetime.datetime.now())


# Generated at 2022-06-24 20:25:57.401003
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:26:03.357129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_host = {}
    ansible_host['ansible_host'] = '10.255.0.1'
    ansible_host['ansible_ssh_auth_method'] = 'publickey'
    ansible_host['ansible_connection'] = 'ansible.netcommon.network_cli'
    ansible_host['ansible_network_os'] = 'nxos'
    ansible_host['ansible_network_os_version'] = '9.0(1)'
    ansible_host['ansible_python_interpreter'] = '/usr/bin/python'
    ansible_host['ansible_user_id'] = 'admin'
    ansible_host['nxos_sw_ver']

# Generated at 2022-06-24 20:26:06.389102
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = False
    ansible_j_s_o_n_encoder_1.default(o)


# Generated at 2022-06-24 20:26:09.943283
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert not ansible_j_s_o_n_encoder_0.default(None) is None


# Generated at 2022-06-24 20:26:19.712643
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    #test1
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = None
    ansible_vault_0 = None
    return_value_0 = ansible_j_s_o_n_encoder_0._default(ansible_unsafe_0)
    str_0 = return_value_0
    #test2
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_unsafe_1 = None
    ansible_vault_1 = None
    return_value_1 = ansible_j_s_o_n_encoder_1._default(ansible_vault_1)
    str_1 = return_value_1


# Generated at 2022-06-24 20:26:21.500579
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:26:32.268878
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    values_to_test_with = [
        {'a': 'ansible_variable'},
        {'a': ('a', 'list')},
        {'a': ('a', ['list', 'of', 'one item', ('a', ['list', 'of', 'items'])])},
        {'a': ['b', 'c', 'd']}
    ]
    ansible_j_s_o_n_encoder_0.default(values_to_test_with[0])
    ansible_j_s_o_n_encoder_0.default(values_to_test_with[1])

# Generated at 2022-06-24 20:26:41.913105
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, 1) == 1
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, 1.0) == 1.0
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, True) == True
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, "abc") == "abc"
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, []) == []
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder, {}) == {}

# Generated at 2022-06-24 20:26:43.654307
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # FIXME: Implement the test for AnsibleJSONEncoder.default
    pass


# Generated at 2022-06-24 20:26:46.855155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    json_str = ansible_j_s_o_n_encoder_0.default(o=None)


# Generated at 2022-06-24 20:26:51.807185
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:26:58.363852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = 'foo'
    s_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_1 = 'foo'
    s_1 = ansible_j_s_o_n_encoder_1.default(o_1)


# Generated at 2022-06-24 20:27:08.959816
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    # test_case_0
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # test_case_1
    o_0 = {}
    o_1 = ansible_j_s_o_n_encoder.default(o_0)
    assert isinstance(o_1, dict)

    # test_case_2
    o_0 = []
    o_1 = ansible_j_s_o_n_encoder.default(o_0)
    assert isinstance(o_1, list)

    # test_case_3
    o_0 = []

# Generated at 2022-06-24 20:27:13.721654
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejsonencoder_default_obj = AnsibleJSONEncoder()
    ansiblejsonencoder_default_obj._preprocess_unsafe = False
    ansiblejsonencoder_default_obj._vault_to_text = False
    o = 'test_string'
    ansible_j_s_o_n_encoder_default_return_value = ansiblejsonencoder_default_obj.default(o)
    assert ansible_j_s_o_n_encoder_default_return_value == 'test_string'


# Generated at 2022-06-24 20:27:23.930643
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class StubAnsibleUnsafe(object):

        __UNSAFE__ = True

    class StubAnsibleVault(object):

        __ENCRYPTED__ = True
        _ciphertext = b'ansible-vault-encoded-data'

    stub_date = datetime.date(2017, 5, 12)
    stub_date_time = datetime.datetime(2017, 5, 12, 11, 6, 9)

    stub_dict = {
        b'b_key': b'b_value',
        u'u_key': u'u_value'
    }

    stub_list = [
        b'b_value',
        u'u_value'
    ]

    stub_tuple = (
        b'b_value',
        u'u_value'
    )

   

# Generated at 2022-06-24 20:27:34.728656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = [1, 2]
    ansible_j_s_o_n_encoder_1.default(o)
    o = {1: 'a'}
    ansible_j_s_o_n_encoder_1.default(o)
    o = (1, 'a')
    ansible_j_s_o_n_encoder_1.default(o)
    o = 'I am o'
    ansible_j_s_o_n_encoder_1.default(o)
    o = [1, 'a']
    ansible_j_s_o_n_encoder_1.default(o)


# Generated at 2022-06-24 20:27:37.040535
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:41.598996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(datetime.datetime(year=2020, month=6, day=6, hour=8, minute=2, second=4))



# Generated at 2022-06-24 20:27:45.647284
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default('') == ''


# Generated at 2022-06-24 20:27:48.993132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default(['foo', 'baz'])
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 20:27:59.897378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    unknown_object = (1, 2, 3)
    assert ansible_j_s_o_n_encoder_0.default(unknown_object) == unknown_object


# Generated at 2022-06-24 20:28:02.865300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_out_0 = ansible_j_s_o_n_encoder_0.default('foo')
    assert str_out_0 == 'foo'


# Generated at 2022-06-24 20:28:04.365538
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('value_1')


# Generated at 2022-06-24 20:28:15.764839
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)

    ansible_j_s_o_n_encoder_0.default(o=to_bytes(value=False, encoding='ascii', errors='strict'))

    ansible_j_s_o_n_encoder_0.default(o=None)

    ansible_j_s_o_n_encoder_0.default(o=to_bytes(value='ansible', encoding='ascii', errors='strict'))


# Generated at 2022-06-24 20:28:19.311889
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    value_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    assert value_0 == {}

# Generated at 2022-06-24 20:28:27.429600
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default(None) == "None"
    assert ansible_j_s_o_n_encoder_1.default(1) == "1"
    assert ansible_j_s_o_n_encoder_1.default([1]) == "[1]"
    assert ansible_j_s_o_n_encoder_1.default({"a": 1}) == "{\"a\": 1}"
    assert ansible_j_s_o_n_encoder_1.default(True) == "True"
    assert ansible_j_s_o_n_encoder_1.default(False) == "False"
    assert ansible_j_

# Generated at 2022-06-24 20:28:37.847071
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test of default method from class AnsibleJSONEncoder

    # Test: Create class instance for testing
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    # Test: Call method default with parameter

    # Test: Call method default with parameter
    ansible_j_s_o_n_encoder_1.default('{}')

    # Test: Call method default with parameter
    ansible_j_s_o_n_encoder_1.default(b'{}')

    # Test: Call method default with parameter
    ansible_j_s_o_n_encoder_1.default([])

    # Test: Call method default with parameter
    ansible_j_s_o_n_encoder_1.default({})

    # Test: Call method default with parameter
   

# Generated at 2022-06-24 20:28:43.191514
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # value must be a json serializable object
    value = 'safe'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(value)


# Generated at 2022-06-24 20:28:47.557829
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default({'b': 'a', 'a': 'b', 'c': 'c'})


# Generated at 2022-06-24 20:28:51.735048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Just in case it's not a None
    assert ansible_j_s_o_n_encoder_0.default == type(ansible_j_s_o_n_encoder_0).default


# Generated at 2022-06-24 20:29:16.213997
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(False)
    ansible_j_s_o_n_encoder_0.default(True)

    vault_text = '$ANSIBLE_VAULT;1.1;AES256;otherhost\n34356635643237333762353036353634643834636138666132396565393064326538393331623561370a643037633266383734646434353364386638643762633230633634363265376464393036653039616435\n'
    o = vault_text

# Generated at 2022-06-24 20:29:25.373067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    # Test cases
    # Default test case
    result = ansible_j_s_o_n_encoder.default(None)
    assert result is None
    result = ansible_j_s_o_n_encoder.default(2)
    assert result == 2
    result = ansible_j_s_o_n_encoder.default('abc')
    assert result == 'abc'
    result = ansible_j_s_o_n_encoder.default(b'efg')
    assert result == 'efg'
    result = ansible_j_s_o_n_encoder.default(u'hij')
    assert result == 'hij'
    result = ansible_j_s_o_

# Generated at 2022-06-24 20:29:30.146371
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'test_value'
    value = ansible_j_s_o_n_encoder_0.default(o)
    assert value == 'test_value'


# Generated at 2022-06-24 20:29:32.312716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:33.624135
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:35.903563
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    checker_obj = AnsibleJSONEncoder()
    ret = checker_obj.default('o')
    assert ret == 'o'


# Generated at 2022-06-24 20:29:39.814104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_obj = AnsibleJSONEncoder()
    o = {}
    assert test_obj.default(o) == o
    o = datetime.datetime.utcnow()
    assert test_obj.default(o) == o.isoformat()


# Generated at 2022-06-24 20:29:42.699700
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0() == None


# Generated at 2022-06-24 20:29:48.149377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default('foo')
    assert type(str_0) == str


# Generated at 2022-06-24 20:29:53.292046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default_expect_0 = "foo"
    assert ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0_default_expect_0) == ansible_j_s_o_n_encoder_0_default_expect_0


# Generated at 2022-06-24 20:30:27.849105
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o_1 = dict(k1='v1')

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default(o_1) == o_1


# Generated at 2022-06-24 20:30:33.349351
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = datetime.timedelta(seconds=1)
    with pytest.raises(TypeError):
        ansible_j_s_o_n_encoder_0.default(o_0)
    o_1 = datetime.datetime(year=2019, month=12, day=11, hour=13, minute=59, second=41)
    # Check for return type, use assertEquals for more asserts
    assert isinstance(ansible_j_s_o_n_encoder_0.default(o_1), basestring)
    o_2 = datetime.date(year=2019, month=12, day=11)
    # Check for return type, use assertEquals for more asserts
   

# Generated at 2022-06-24 20:30:37.651723
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder.default()


# Generated at 2022-06-24 20:30:43.341015
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"a": 1}
    result_0 = ansible_j_s_o_n_encoder_0.default(o)
    assert not isinstance(o, str)
    assert isinstance(result_0, str)


# Generated at 2022-06-24 20:30:51.694756
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Verifying if the _preprocess_unsafe attribute is set correctly
    assert ansible_j_s_o_n_encoder_0._preprocess_unsafe == False
    # Verifying if the _vault_to_text attribute is set correctly
    assert ansible_j_s_o_n_encoder_0._vault_to_text == False
    # Testing if the default method returns the correct value

# Generated at 2022-06-24 20:30:57.639970
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    # Test with AnsibleUnsafe(__ENCRYPTED__ = False)
    test_value = {'__UNSAFE__': True}
    result = ansible_j_s_o_n_encoder.default(test_value)

    expected = {'__ansible_unsafe': True}

    assert result == expected


# Generated at 2022-06-24 20:31:03.310790
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
  o = None
  try:
    ansible_j_s_o_n_encoder_0.default(o)
  except TypeError:
    return True
  # TODO: expected exception TypeError not raised
  return False


# Generated at 2022-06-24 20:31:07.873817
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_AnsibleJSONEncoder_default_0()
    try:
        test_case_AnsibleJSONEncoder_default_1()
        assert False
    except TypeError:
        pass
    test_case_AnsibleJSONEncoder_default_2()
    test_case_AnsibleJSONEncoder_default_3()


# Generated at 2022-06-24 20:31:11.024155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    o = 'string_0'
    ansible_json_encoder_0.default(o)


# Generated at 2022-06-24 20:31:12.029198
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default in AnsibleJSONEncoder().default

# Generated at 2022-06-24 20:32:20.604749
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert_equals(AnsibleJSONEncoder().default(['a', 'b']), ['a', 'b'])


# Generated at 2022-06-24 20:32:31.740049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ****** PREPARATION ******
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    class AnsibleVault(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True
        __SENSITIVE__ = True

    class AnsibleUnsafe(AnsibleVault, str):
        pass

    ansible_vault_1 = AnsibleVault('foo')
    ansible_unsafe_1 = AnsibleUnsafe('bar')

    class AnsibleVaultObj(object):
        def __init__(self):
            self.__ENCRYPTED__ = True

    ansible_vault_obj_0 = AnsibleVaultObj()


# Generated at 2022-06-24 20:32:34.181780
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = AnsibleJSONEncoder.default('hello', 123)
    assert result == 'hello'


# Generated at 2022-06-24 20:32:40.326575
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Unit test for method default of class AnsibleJSONEncoder
    """
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    default_0 = ansible_j_s_o_n_encoder_1.default({})
    assert True

# Generated at 2022-06-24 20:32:50.343793
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe_0(str):
        __UNSAFE__ = True
    class AnsibleUnsafe_1(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True
    class AnsibleUnsafe_2(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False
    class AnsibleUnsafe_3(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = True
    class AnsibleUnsafe_4(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = False
    class AnsibleUnsafe_5(str):
        __UNSAFE__ = True
    class HostVars_6(dict):
        __UNSAFE__ = True

# Generated at 2022-06-24 20:32:53.735888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    sample_param = 'Hello World'
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder.default(sample_param) == 'Hello World'



# Generated at 2022-06-24 20:32:59.783712
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_vault_2 = type('',(str,tuple,),{'__ENCRYPTED__': True})
    ansible_vault_3 = type('',(str,tuple,),{'__ENCRYPTED__': False})
    ansible_unsafe_4 = type('',(str,tuple,),{'__UNSAFE__': True})
    ansible_unsafe_5 = type('',(str,tuple,),{'__UNSAFE__': False})
    ansible_j_s_o_n_encoder_1.default(ansible_vault_2)

# Generated at 2022-06-24 20:33:07.447955
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    dict_sample = {'theanswer': 42, 'thetruth': 'nothing'}
    dict_sample_result_0 = ansible_j_s_o_n_encoder_1.default(dict_sample)
    assert dict_sample_result_0 == dict_sample
    # Put your code here, like:
    # assert <your_expression> == result_you_want


# Generated at 2022-06-24 20:33:16.958910
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Creating instances of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Testing calling the method default of instances of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0_default_0 = ansible_j_s_o_n_encoder_0.default(2)

    ansible_j_s_o_n_encoder_0_default_1 = ansible_j_s_o_n_encoder_0.default(3.14)

    ansible_j_s_o_n_encoder_0_default_2 = ansible_j_s_o_n_encoder_0.default('123')

    ansible_j_s_o_n_encoder_0_default

# Generated at 2022-06-24 20:33:21.016474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # unit test for method default
    assert AnsibleJSONEncoder().default(42) == 42
    assert AnsibleJSONEncoder().default({"key": "value"}) == {"key": "value"}
    assert AnsibleJSONEncoder().default(["1", "2", "3"]) == ["1", "2", "3"]