

# Generated at 2022-06-24 20:25:15.485529
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: Add necessary test cases here
    pass


# Generated at 2022-06-24 20:25:23.234766
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'asdfg'
    float_0 = -3442.547573792542
    bool_0 = False
    float_1 = -0.9993545118590772
    str_1 = '{'
    int_0 = 33
    float_2 = -6.4
    float_3 = -0.0
    float_4 = -3442.547573792542
    list_0 = [bool_0, float_1, float_2, float_3]
    float_5 = -3442.547573792542
    float_6 = -0.9993545118590772
    float_7 = -0.0
    float_8 = -6.4
   

# Generated at 2022-06-24 20:25:26.943139
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -326547.5
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = 'test_value'

    # Call method default with required args
    result = ansible_j_s_o_n_encoder_0.default(str_0)
    assert result == str_0


# Generated at 2022-06-24 20:25:30.479377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Test cases for method default of AnsibleJSONEncoder class
    """
    # Test case 0
    ansible_j_s_o_n_encoder_0 = json.JSONEncoder()


# Generated at 2022-06-24 20:25:37.624829
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = dict()
    dict_0['__ansible_unsafe'] = 'AnsibleUnsafeString()'
    dict_0['__ansible_vault'] = 'AnsibleUnsafeString()'
    try:
        ansible_j_s_o_n_encoder_0.default(dict_0)
    except KeyError:
        raise AssertionError('KeyError Exception raised')
    else:
        raise AssertionError('Wrong Exception raised')


# Generated at 2022-06-24 20:25:44.938902
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()

# Generated at 2022-06-24 20:25:51.643387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    assert str_0 == float_0


# Generated at 2022-06-24 20:25:57.934442
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    default_0 = ansible_j_s_o_n_encoder_0.default(float_0)



# Generated at 2022-06-24 20:26:03.470111
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    res_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    assert res_0 == float_0


# Generated at 2022-06-24 20:26:05.860098
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:26:16.321518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -2666.753724494571
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # encode float
    ansible_j_s_o_n_encoder_0.default(float_0)
    # encode list
    ansible_j_s_o_n_encoder_0.default([1, [float_0, float_0], float_0])
    # encode dict
    ansible_j_s_o_n_encoder_0.default({'a': float_0})


# Generated at 2022-06-24 20:26:18.789189
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:21.496438
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    int_0 = ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:26:26.694555
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    float_1 = ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:26:37.673612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder(preprocess_unsafe=True)


# Generated at 2022-06-24 20:26:41.025194
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Assert
    assert ansible_j_s_o_n_encoder_0.default(float_0) == float_0

# Generated at 2022-06-24 20:26:46.946078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default(float_0)
    assert ansible_j_s_o_n_encoder_0_default == float_0


# Generated at 2022-06-24 20:26:57.510391
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for method default( self, o )
    # negative test case
    try:
        AnsibleJSONEncoder().default(None)
    except Exception as e:
        if isinstance(e, TypeError) and e.args[0] == 'Object of type NoneType is not JSON serializable':
            pass
        else:
            raise

    # negative test case
    try:
        value = AnsibleJSONEncoder().default(45)
    except:
        raise AssertionError()

    # positive test case
    # functional test
    # TODO: the below is not correct, it has no assertion
    value = AnsibleJSONEncoder().default(datetime.datetime(2016, 10, 10, 0, 21, 45, 687000))

    # positive test case
    # functional test
    # TODO: the below is not

# Generated at 2022-06-24 20:27:03.724625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:27:08.756204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe(u'')
    ansible_vault_0 = AnsibleVaultEncryptedUnicode(u'')
    ansible_unsafe_1 = AnsibleUnsafe(u'[[((}]]')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode(u'[[((}]]')


# Generated at 2022-06-24 20:27:16.768834
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault = ansible_j_s_o_n_encoder_0.default(float_0)
    assert ansible_vault == -3442.547573792542


# Generated at 2022-06-24 20:27:26.159574
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print('Testing method default of class AnsibleJSONEncoder')
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    print('Testing simple properties')
    print(ansible_j_s_o_n_encoder_0.preprocess_unsafe)
    print(ansible_j_s_o_n_encoder_0.vault_to_text)
    ansible_j_s_o_n_encoder_0.preprocess_unsafe = True
    print(ansible_j_s_o_n_encoder_0.preprocess_unsafe)
    ansible_j_s_o_n_encoder_0.vault_to_text = True

# Generated at 2022-06-24 20:27:28.457718
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:27:33.632874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 1, "Failed to find a test case for method default of class AnsibleJSONEncoder"
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # assert ansible_j_s_o_n_encoder_0.default(())


# Generated at 2022-06-24 20:27:36.602418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -128967.5345853016
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    unknown_0 = ansible_j_s_o_n_encoder_0.default(float_0)

# Generated at 2022-06-24 20:27:45.594784
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    assert ansible_unsafe_0 is not None, "AnsibleJSONEncoder.default returned None"
    # FIXME: the assert statement below is not the same as the above
    # assert ansible_unsafe_0 is not None, "AnsibleJSONEncoder.default returned None"

    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)

# Generated at 2022-06-24 20:27:47.726663
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
       a = AnsibleJSONEncoder
       float_0 = -3442.547573792542
       assert a.default(float_0)


# Generated at 2022-06-24 20:27:55.542312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # input arguments for the method AnsibleJSONEncoder.default
    o = 'f3hx8-v0bs4-b4j2d-25z42-dy5r5'

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # decode the results if needed
    try:
        # perform the action on the original inputs
        ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0._default(o)

    except Exception as e:
        # decode the exception message
        msg = json.loads(e.message)

        # perform any extra checking needed from the exception
        assert msg == 'Invalid input type', 'The returned message from the method is wrong'


# Generated at 2022-06-24 20:28:04.417225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    float_1 = float('inf')
    float_2 = float('nan')
    float_3 = float('infinity')
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(float_0)

    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2.default(float_3)

    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o

# Generated at 2022-06-24 20:28:08.447005
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:28:14.430492
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: Update test to actually assert
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:21.166802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_ns0.AnsibleUnsafe = getattr(ansible_ns0, 'AnsibleUnsafe')
    datetime_0 = datetime.datetime(1978, 12, 15, 17, 32, 54)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_0.default(datetime_0)
    assert isinstance(result, str)
    assert result == '1978-12-15T17:32:54'


# Generated at 2022-06-24 20:28:25.582303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert None is not ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:28:31.299119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_0.default(float_0)
    print(result)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 20:28:35.272652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(float_0) == -3442.547573792542

# Generated at 2022-06-24 20:28:37.652759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:45.783281
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Nothing being returned and I need to find a way to compare the result with what is being shown
    # ansible_j_s_o_n_encoder_0.default(float_0) # Need to figure out how to be able to test for a variable in python


# Generated at 2022-06-24 20:28:50.804101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    variant_type_0 = type(ansible_j_s_o_n_encoder_0)
    ansible_j_s_o_n_encoder_0.default(float_0)

# Generated at 2022-06-24 20:28:55.481192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_0.default(float_0), float) == True


# Generated at 2022-06-24 20:29:03.532228
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = \
        to_text(' -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  - ', errors='surrogate_or_strict',
               nonstring='strict')
    ansible_unsafe_1 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    print(ansible_unsafe_1)


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:08.151411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_1 = -4608.348890584779
    int_1 = -885
    str_0 = 'A1g2'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:12.686611
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_1 = -3442.547573792542
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    # Invoke method
    result = ansible_j_s_o_n_encoder_1.default(float_1)
    assert(result == -3442.547573792542)


# Generated at 2022-06-24 20:29:21.782279
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of class AnsibleJSONEncoder
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Create an instance of class AnsibleUnsafeText
    ansible_unsafe_text_0 = "%s" % "original_data"
    # Call method default of AnsibleJSONEncoder instance ansible_j_s_o_n_encoder_0
    ansible_j_s_o_n_encoder_0.default(o=ansible_unsafe_text_0)

    # Call method default of AnsibleJSONEncoder instance ansible_j_s_o_n_encoder_0
    ansible_j_s_o_n_encoder_0.default(o=float_0)

# Generated at 2022-06-24 20:29:24.211919
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:28.969770
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    assert isinstance(ansible_j_s_o_n_encoder_0.default(float_0), (float, int))


# Generated at 2022-06-24 20:29:33.907921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert type(ansible_j_s_o_n_encoder_0.default(float_0)) is float


# Generated at 2022-06-24 20:29:40.204562
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialization
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Method test
    default_call_result_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    test_result = default_call_result_0 == float_0
    assert test_result is True, "Test Failed"



# Generated at 2022-06-24 20:29:49.016614
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Case when the object has the attribute __ENCRYPTED__.
    ansible_j_s_o_n_encoder_0._vault_to_text = bool()
    assert ansible_j_s_o_n_encoder_0.default(float_0) == -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Case when the object has the attribute __UNSAFE__, the value of which is True.
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = bool()
    assert ansible_j_

# Generated at 2022-06-24 20:29:55.553472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleVaultEncryptedUnicode
    original_text = u"this is some vault text"
    vault_obj = AnsibleVaultEncryptedUnicode(original_text)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(vault_to_text=True)
    assert ansible_j_s_o_n_encoder_0.default(vault_obj) == original_text

if __name__ == "__main__":
    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:58.065816
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = 7968.659664659871
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:30:05.412156
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(float_0) == float_0


# Generated at 2022-06-24 20:30:12.489550
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o)
    #assert ansible_j_s_o_n_encoder_0.default(o) == "__ansible_vault"
    return ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:30:14.749168
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:30:22.058690
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # get value of header
    header_0 = None
    # set value of header
    header_0 = 'Accept: application/json'
    # get value of header
    header_1 = None
    # set value of header
    header_1 = 'Content-type: application/json'
    # get value of header
    header_2 = None
    # set value of header
    header_2 = 'Authorization: Basic YWRtaW46YWRtaW5AMTIz'
    # get value of header
    header_3 = None
    # set value of header
    header_3 = 'X-CSRF-Token: XXXX'
    # get value of header

# Generated at 2022-06-24 20:30:30.510852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    string_0 = "I'm a string!"
    non_strict_type_0 = "I'm a string!"
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)
    ansible_j_s_o_n_encoder_0.default(string_0)
    ansible_j_s_o_n_encoder_0.default(non_strict_type_0)


# Generated at 2022-06-24 20:30:34.804761
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -7848.365063674912
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default(float_0)
    except RuntimeError:
        pass


# Generated at 2022-06-24 20:30:39.520631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # AssertionError: -3442.547573792542 not in <class 'unittest.runner._WritelnDecorator'>
    pass

# Generated at 2022-06-24 20:30:42.819126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = float_0
    assert ansible_j_s_o_n_encoder_0.default(o) == float_0


# Generated at 2022-06-24 20:30:45.970013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe('xxxxxxxxxxxxxxxx')
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == 'xxxxxxxxxxxxxxxx'


# Generated at 2022-06-24 20:30:50.562273
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Setup data
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Call method under test
    ret_val_0 = ansible_j_s_o_n_encoder_0.default(float_0)

    assert(-3442.547573792542 == ret_val_0)



# Generated at 2022-06-24 20:30:58.993132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = 35
    o_0_r_0 = ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:31:07.465110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()

    # AnsibleUnsafe does not derive from string objects, need to encode them using default
    # directly
    assert json.dumps(obj.default(u'\x97\x00\x00\x00\x00\x00\x00')) == json.dumps(u'\x97\x00\x00\x00\x00\x00\x00')
    assert json.dumps(obj.default(u'\x97\x00\x00\x00\x00\x00\x00'.__UNSAFE__)) == json.dumps({'__ansible_unsafe': u'\x97\x00\x00\x00\x00\x00\x00'})

    # need to encode vault objects recursively to correctly add the __ansible

# Generated at 2022-06-24 20:31:16.878440
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    float_0 = -3442.547573792542
    bool_0 = False
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe(False)
    ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_j_s_o_n_encoder_0.default(float_0)
    ansible_j_s_o_n_encoder_0.default(bool_0)
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)
    ansible_j_s_o_n_enc

# Generated at 2022-06-24 20:31:19.849688
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:31:28.422971
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # test case 0
    dict_0 = {}
    dict_0['key_0'] = float_0
    dict_0['key_1'] = float_0
    dict_0['key_2'] = float_0
    dict_0['key_3'] = float_0
    dict_0['key_4'] = float_0
    dict_0['key_5'] = float_0
    dict_0['key_6'] = float_0
    dict_0['key_7'] = float_0
    dict_0['key_8'] = float_0
    dict_0['key_9'] = float_0

# Generated at 2022-06-24 20:31:33.749115
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default(float_0)

    # exception expected
    except TypeError as e:
        pass

# Generated at 2022-06-24 20:31:37.922508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(float_0) == (-3442.547573792542,)


# Generated at 2022-06-24 20:31:41.870875
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    print(str_0)


# Generated at 2022-06-24 20:31:50.505134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -5837.138144891086
    int_0 = -359599112
    int_1 = -779550256
    tuple_0 = (int_1,)
    float_1 = -8878.633809900808
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    int_2 = -520714960
    str_0 = ansible_j_s_o_n_encoder_0.default(tuple_0)
    str_1 = ansible_j_s_o_n_encoder_0.default(int_0)
    str_2 = ansible_j_s_o_n_encoder_0.default(float_1)
    str_3 = ansible_j_s_o_n

# Generated at 2022-06-24 20:31:54.239037
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = 2477.9310753102476
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:32:03.990575
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # float_1 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:32:08.383978
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:32:16.645195
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    unsafe_str = b'\xc3\xbc'  # UTF-8 encoded string representing unicode code point U+00FC (LATIN SMALL LETTER U WITH DIAERESIS)
    unsafe_str = unsafe_str.decode('utf-8')
    ansible_unsafe = AnsibleUnsafe(unsafe_str)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    res = ansible_j_s_o_n_encoder_0.default(ansible_unsafe)
    assert res == {'__ansible_unsafe': unsafe_str}


# Generated at 2022-06-24 20:32:22.236525
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    float_1 = float('NaN')
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Verify ansible_js_on_encoder_0.default() == float_0
    assert ansible_j_s_o_n_encoder_0.default(float_0) == float_0
    # Verify ansible_js_on_encoder_0.default() != float_1
    assert ansible_j_s_o_n_encoder_0.default(float_0) != float_1

# Generated at 2022-06-24 20:32:23.990844
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert all(ansible_j_s_o_n_encoder_0.default(float_0) == float_0 == -3442.547573792542)


# Generated at 2022-06-24 20:32:27.548036
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    int_0 = ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:32:30.686423
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # TODO: NotImplementedError
    assert False


# Generated at 2022-06-24 20:32:35.256300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('-3442.547573792542')


# Generated at 2022-06-24 20:32:37.763392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('o')


# Generated at 2022-06-24 20:32:42.767340
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_2 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(float_2)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(float_2)


# Generated at 2022-06-24 20:32:52.493143
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    i_i_v_c_0 = float_0
    if i_i_v_c_0 is None:
        return None
    else:
        for i_i_v_c_1 in i_i_v_c_0:
            ansible_j_s_o_n_encoder_0.default(i_i_v_c_1)


# Generated at 2022-06-24 20:32:54.613572
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    default_0 = AnsibleJSONEncoder.default()


# Generated at 2022-06-24 20:33:07.097926
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = 'test_value'
    ansible_vault_1 = ansible_vault_0
    ansible_vault_2 = ansible_vault_0
    # AnsibleVaultAES256.__init__
    ansible_vault_3 = None
    # AnsibleVaultAES256._init_cipher
    ansible_vault_4 = None
    ansible_vault_5 = ansible_vault_4
    ansible_vault_6 = ansible_vault_1
    # AnsibleVaultAES256.load_bytes
    ansible_vault_7 = ansible_

# Generated at 2022-06-24 20:33:16.775507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dict_0 = {}
    virsh_0 = dict_0
    dict_1 = {}
    # WARNING! CAN NOT BE IMPLEMENTED IN PY2!
    # dict_1[ansible_j_s_o_n_encoder_0] = float_0
    dict_1[ansible_j_s_o_n_encoder_0] = float_0
    dict_1[ansible_j_s_o_n_encoder_0] = dict_0
    dict_1[ansible_j_s_o_n_encoder_0] = virsh_0

# Generated at 2022-06-24 20:33:19.988368
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True, "Failed to find unit test at /Users/simeon/djangogirls/myvenv/lib/python3.5/site-packages/ansible/module_utils/json_utils.py"


# Generated at 2022-06-24 20:33:24.099248
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: Create an unsafe object and then assert that its converted to a dict with '__ansible_unsafe'
    # TODO: Create an vault object and then assert that its converted to a dict with '__ansible_vault'
    # TODO: Create a hostvars object and then assert that its converted to a dict
    # TODO: Create a date object and then assert that its converted to a string
    # TODO: Create a normal object and then assert that its converted to a string
    pass



# Generated at 2022-06-24 20:33:32.321869
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = 'l%VuQ5xq!7f&AtS$'
    # $ansible_vault is a vault object, this will never be reached
    ansible_vault_0 = ansible_j_s_o_n_encoder_0.default(ansible_vault_0)

# Generated at 2022-06-24 20:33:38.352707
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:40.360925
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:33:45.098778
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:53.188656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # float
    ansible_j_s_o_n_encoder_0.default(float_0)
    pass


# Generated at 2022-06-24 20:33:55.389580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:34:00.783533
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert(ansible_j_s_o_n_encoder_0.default(float_0) == -3442.547573792542)
    assert(ansible_j_s_o_n_encoder_0.default(float_0) == float_0)

# Generated at 2022-06-24 20:34:03.038256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:34:10.441250
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = 3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = str()

    # Call method default with args
    assert ansible_j_s_o_n_encoder_0.default(float_0) == str_0

    # Call method default with args
    assert ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0) == str_0

    # Call method default with args
    assert ansible_j_s_o_n_encoder_0.default(str_0) == str_0



# Generated at 2022-06-24 20:34:12.540808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(
        float_0)


# Generated at 2022-06-24 20:34:14.014976
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    with pytest.raises(AttributeError):
        obj.default()


# Generated at 2022-06-24 20:34:19.922955
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_1 = -3442.547573792542
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(float_1)


# Generated at 2022-06-24 20:34:25.625476
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(float_0)


# Generated at 2022-06-24 20:34:29.616674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_1 = -3442.547573792542
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1_default_0 = ansible_j_s_o_n_encoder_1.default(float_1)
    assert ansible_j_s_o_n_encoder_1_default_0 is not None


# Generated at 2022-06-24 20:34:41.788820
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # test 1, with float_0 = -3442.547573792542
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # call the method
    ansible_j_s_o_n_encoder_0.default(float_0)

    # test 2, with int_0 = -444444444444444444444444444444444444444444444444

# Generated at 2022-06-24 20:34:48.278495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # In these tests, the default json.JSONEncoder does not perform the same way
    # as the AnsibleJSONEncoder so we need to make sure that we are covering
    # the valid use cases.
    raw_json_encoder = json.JSONEncoder()

    # None
    assert AnsibleJSONEncoder().default(None) == json.JSONEncoder().default(None)

    # Boolean true
    assert AnsibleJSONEncoder().default(True) == json.JSONEncoder().default(True)

    # Boolean false
    assert AnsibleJSONEncoder().default(False) == json.JSONEncoder().default(False)

    # string
    assert AnsibleJSONEncoder().default(to_text('valid string')) == json.JSONEncoder().default(to_text('valid string'))

    # int
    assert AnsibleJSONEnc

# Generated at 2022-06-24 20:34:53.576733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(float_0)
    assert (str_0 == float_0)


# Generated at 2022-06-24 20:35:00.601524
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    float_0 = -3442.547573792542
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    vault = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    if (ansible_unsafe_0.encode() != vault.encode()):
        raise AssertionError(ansible_unsafe_0.encode() + ' != ' + vault.encode())


# Generated at 2022-06-24 20:35:05.070601
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_instance_0 = datetime.datetime.now()
    assert ansible_j_s_o_n_encoder_0.default(datetime_instance_0) == datetime_instance_0.isoformat()


# Generated at 2022-06-24 20:35:13.694982
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Test the default method of AnsibleJSONEncoder
    """
    # Setup
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    int_0 = -1070680967
    # AssertionError raised
    with pytest.raises(AssertionError):
        # Method Execution
        ansible_j_s_o_n_encoder_0.default(int_0)
    # Setup
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe()
    # AssertionError raised