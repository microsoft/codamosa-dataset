

# Generated at 2022-06-24 20:25:16.529559
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('foo')


# Generated at 2022-06-24 20:25:22.846119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    # Pass an object and ensure it encodes properly
    class MyObject():
        def __init__(self, my_attribute):
            self.my_attribute = my_attribute

    assert ansible_j_s_o_n_encoder.default(MyObject('my_attribute_value')) == {'__ansible_safe': {'my_attribute': 'my_attribute_value'}}


# Generated at 2022-06-24 20:25:24.194304
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:25:26.933225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the default method of class AnsibleJSONEncoder - it should return the expected value
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert ansible_json_encoder_0.default('value') == 'value'


# Generated at 2022-06-24 20:25:29.142836
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    value = ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:25:33.296800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(o) == o



# Generated at 2022-06-24 20:25:42.061003
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe('unsafe_text')
    ansible_vault_0 = AnsibleVaultEncryptedUnicode('encrypted_text')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode('encrypted_text')
    ansible_vault_1.vault_id = 'vault_id'
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == {'__ansible_unsafe': 'unsafe_text'}

# Generated at 2022-06-24 20:25:51.835013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = 'yMNeOy'
    s_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    assert (s_0 == o_0)
    o_1 = u'qwvnAU'
    s_1 = ansible_j_s_o_n_encoder_0.default(o_1)
    assert (s_1 == o_1)
    o_2 = 88.6
    s_2 = ansible_j_s_o_n_encoder_0.default(o_2)
    assert (s_2 == o_2)
    o_3 = False
    s_3 = ansible_j_s_

# Generated at 2022-06-24 20:25:57.555627
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default('test_value') == 'test_value'


# Generated at 2022-06-24 20:26:02.852934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    import datetime
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # pass in object, object of dict type
    dict_0 = dict()
    dict_0.update({'ansible': 'ansible'})
    dict_0.update({'ephemeral': 'ephemeral'})
    # pass in object, current date
    date_0 = datetime.datetime.now()
    json_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    json_1 = ansible_j_s_o_n_encoder_0.default(date_0)


# Generated at 2022-06-24 20:26:07.353129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=42)


# Generated at 2022-06-24 20:26:14.600134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_unsafe_2 = object()
    ansible_unsafe_2.__UNSAFE__ = True
    ansible_j_s_o_n_encoder_2.default(ansible_unsafe_2)
    ansible_unsafe_2.__ENCRYPTED__ = True
    ansible_j_s_o_n_encoder_2.default(ansible_unsafe_2)
    ansible_unsafe_2.__ENCRYPTED__ = False
    ansible_unsafe_2.__UNSAFE__ = False
    assert {} == ansible_j_s_o_n_encoder_2.default(ansible_unsafe_2)


# Unit test

# Generated at 2022-06-24 20:26:22.011178
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = ansible.parsing.vault.VaultLib(password='password')
    ansiballz_0 = ansible_vault_0.encrypt('QWxsIGVub3VnaCBpdCdzIHRoZSBzYW1lIHRvIG1lCnRoYXQgSSdtIG5vdCBpdHMgZ29vZCBmcmllbmQgbWUu')

# Generated at 2022-06-24 20:26:28.563939
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    o.__ENCRYPTED__ = False
    o.__UNSAFE__ = False
    expected_0 = {}
    actual_0 = ansible_j_s_o_n_encoder_0.default(o)
    #assert actual_0 == expected_0


# Generated at 2022-06-24 20:26:31.977890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    res_0 = ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:26:37.766766
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # ansible_j_s_o_n_encoder_0.default
    # Uncomment below line to test method default of class AnsibleJSONEncoder
    # ansible_j_s_o_n_encoder_0.default() 


# Generated at 2022-06-24 20:26:41.399711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Dummy variables
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Dummy variable for method call
    o = None
    # Call method
    ansible_j_s_o_n_encoder_0.default(o=o)


# Generated at 2022-06-24 20:26:51.789402
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import basic
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test for vault object
    ansible_vault_password_0 = basic.AnsibleVaultEncryptedUnicode('text')
    ansible_vault_password_0.__ENCRYPTED__ = True
    ansible_j_s_o_n_encoder_0._vault_to_text = False
    assert ansible_j_s_o_n_encoder_0.default(ansible_vault_password_0) == {'__ansible_vault': u'text'}
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    assert ansible_j_s_o_

# Generated at 2022-06-24 20:26:57.364049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_1 = {
        'foo': 'bar',
        'baz': [
            1,
            2,
            3
        ]
    }
    value_2 = ansible_j_s_o_n_encoder_0.default(o_1)


# Generated at 2022-06-24 20:27:02.615824
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder.default(None)


# Generated at 2022-06-24 20:27:08.261604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 'NOT_YET_IMPLEMENTED' == 'replace me'


# Generated at 2022-06-24 20:27:13.407755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Setup
    val_0 = object()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = None
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = None

    # Testing
    assert ansible_j_s_o_n_encoder_0.default(val_0) == val_0



# Generated at 2022-06-24 20:27:17.961497
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Init class data
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    # Init variable data
    o = {}

    ansible_j_s_o_n_encoder_1.default( o )

    # Tests
    assert True == True


# Generated at 2022-06-24 20:27:19.838580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:27.917604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # AnsibleJSONEncoder.default has no parameters
    # verify that ansible_j_s_o_n_encoder_1 is a instance of AnsibleJSONEncoder
    assert isinstance(ansible_j_s_o_n_encoder_1,AnsibleJSONEncoder)
    # verify that ansible_j_s_o_n_encoder_1 is a instance of json.JSONEncoder
    assert isinstance(ansible_j_s_o_n_encoder_1,json.JSONEncoder)
    assert hasattr(ansible_j_s_o_n_encoder_1, "default")
    # Call ansible_j_s_o_n_encoder_1.default()


# Generated at 2022-06-24 20:27:35.787017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # AnsibleUnsafe object
    ansible_u_n_s_a_f_e_0 = to_text(None, errors='strict')
    # Test object
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)

    # date object
    date_object_0 = datetime.date(2019, 2, 20)
    ansible_j_s_o_n_encoder_0.default(date_object_0)

    # AnsibleVault object
    ansible_v_a_u_l_t_0 = to_text(None, errors='strict')
    ansible_j_s_o

# Generated at 2022-06-24 20:27:45.501605
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Based on the provided example, we can predict the output of default().
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test with no parameter.
    ansible_j_s_o_n_encoder_0.default()

    # Test with an output_dict parameter.
    ansible_j_s_o_n_encoder_0.default({})

    # Test with a non-encrypted Vault object.
    # Not sure how to test this without breaking anything else
    from ansible.parsing.vault import VaultLib

    vault_lib_0 = VaultLib()
    ansible_j_s_o_n_encoder_0.default(vault_lib_0)

    # Test with a HostVars object
    # Not sure how to test this without breaking

# Generated at 2022-06-24 20:27:48.844957
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    s = "test_value"
    assert ansible_j_s_o_n_encoder_0.default(s) == "test_value", "Incorrect return value for default"


# Generated at 2022-06-24 20:27:50.821870
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:27:53.116448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # ansible_j_s_o_n_encoder_0.default(None)


# Generated at 2022-06-24 20:28:01.900038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = datetime.datetime(2018, 1, 1, 12, 12, 12)
    assert ansible_j_s_o_n_encoder_0.default(o) == '2018-01-01T12:12:12'

# Generated at 2022-06-24 20:28:02.857599
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:04.532414
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('o')


# Generated at 2022-06-24 20:28:15.895951
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    class AnsibleVault(object):
        def __init__(self, v_0, v_1):
            self.ciphertext = v_0
            self.content = v_1
    ansible_vault_0 = AnsibleVault('1', '2')
    ansible_vault_0.__ENCRYPTED__ = True
    ansible_vault_1 = AnsibleVault('e', 'f')
    ansible_vault_1.__ENCRYPTED__ = True
    ansible_vault_2 = AnsibleVault('3', '4')
    ansible_vault_2.__ENCRYPTED__ = True
    ansible_vault_3 = Ansible

# Generated at 2022-06-24 20:28:18.124960
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    test_case_0()


# Generated at 2022-06-24 20:28:29.278017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_var_0 = safe_text('abc')
    ansible_var_0.__UNSAFE__ = True
    ansible_var_1 = safe_text('abc')
    ansible_var_1.__ENCRYPTED__ = True
    ansible_var_1.__UNSAFE__ = True
    value = ansible_j_s_o_n_encoder_0.default(ansible_var_0)
    assert value == {'__ansible_unsafe':'abc'}
    value = ansible_j_s_o_n_encoder_0.default(ansible_var_1)
    assert value == {'__ansible_vault':'abc'}



# Generated at 2022-06-24 20:28:31.718606
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    test_case_1()


# Generated at 2022-06-24 20:28:34.239326
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    test_case_0()
    test_case_1()


# Generated at 2022-06-24 20:28:42.163385
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    str_2 = to_text(ansible_j_s_o_n_encoder_1.default(None))
    expected_regex_3 = (b'^null$')
    # Verifying expected regex 3
    assert re.search(expected_regex_3, str_2, re.DOTALL), str_2
    # Method default with arguments: 'abc'.
    # This test should pass.
    str_4 = to_text(ansible_j_s_o_n_encoder_1.default('abc'))
    expected_regex_5 = (b'^"abc"$')
    # Verifying expected regex 5

# Generated at 2022-06-24 20:28:50.416292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # Test with a datetime object
    ansible_j_s_o_n_encoder_1.default(datetime.datetime.now())

    # Test with a dict
    ansible_j_s_o_n_encoder_1.default({'1': 1})

    # Test with a tuple
    ansible_j_s_o_n_encoder_1.default(('1', 1))

    # Test with a list
    ansible_j_s_o_n_encoder_1.default([1, 2, 3])

    # Test with an int
    ansible_j_s_o_n_encoder_1.default(1)

    # Test with a boolean
    ansible_j

# Generated at 2022-06-24 20:29:04.579120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_o_b_j_0 = datetime.date(2017, 1, 1)
    retval_0 = ansible_j_s_o_n_encoder_0.default(date_o_b_j_0)
    assert retval_0 == "2017-01-01"
    vault_c_i_p_h_e_r_0 = 'test'
    ansible_unsafe_str_0 = to_text(vault_c_i_p_h_e_r_0, errors='surrogate_or_strict')
    retval_1 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_str_0)

# Generated at 2022-06-24 20:29:10.108942
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansibleunicode_0 = AnsibleUnicode(u'AnsibleUnicode')
    value_0 = ansible_j_s_o_n_encoder_0.default(ansibleunicode_0)
    assert value_0 == {u'__ansible_unsafe': u'AnsibleUnicode'}


# Generated at 2022-06-24 20:29:16.095724
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_1)



# Generated at 2022-06-24 20:29:17.042535
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:19.690625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default("foo") is "foo"

# Generated at 2022-06-24 20:29:22.972499
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = datetime.date(2005, 7, 14)
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:29:34.351121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = ansible.parsing.vault.VaultSecret(
        vault_id='VaultSecret_0',
        password='password_0'
    )
    ansible_vault_0.vault_id = 'VaultSecret_1'
    ansible_vault_0.password = 'password_1'
    ansible_vault_0._ciphertext = 'ciphertext_0'
    ansible_vault_0._create_timestamp = 1177646779
    ansible_vault_0._last_accessed_timestamp = 1177646780
    class AnsibleUnsafe:
        def __init__(self, data):
            self.data = data

# Generated at 2022-06-24 20:29:44.417785
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import PY3

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    if PY3:
        # The following prompts 'object of type \'bytearray\' has no len()' in Python 2.6
        o = bytearray(b'PYTHON')
    else:
        o = 'PYTHON'
    output = ansible_j_s_o_n_encoder_0.default(o)
    assert output == 'PYTHON'

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'PYTHON'
    output = ansible_j_s_o_n_encoder_0.default(o)

# Generated at 2022-06-24 20:29:48.165806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    o['vault_to_text'] = True
    o['preprocess_unsafe'] = False
    ansible_j_s_o_n_encoder_0.default(o)



# Generated at 2022-06-24 20:29:56.735052
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = '!vault |'
    ansible_u_n_s_a_f_e_0 = ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)

    ansible_u_n_s_a_f_e_0 = {'!vault |', '!vault |'}
    ansible_u_n_s_a_f_e_0 = ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)

    ansible_u_n_s

# Generated at 2022-06-24 20:30:12.574473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:18.846643
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    m = AnsibleModule({"name": "test"})
    dict_0 = m._module._task.args
    string_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert string_0 == '{"name": "test"}'


# Generated at 2022-06-24 20:30:24.887580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_date_time_0 = datetime.datetime(year=2019, month=11, day=25, hour=13, minute=18, second=56)
    ansible_json_string_0 = ansible_j_s_o_n_encoder_0.default(o=ansible_date_time_0)
    print('ansible_json_string_0: %s' % ansible_json_string_0)


# Generated at 2022-06-24 20:30:27.885232
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_obj_1 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_obj_1.default(o = 'ansible_default')
    assert result == 'ansible_default'


# Generated at 2022-06-24 20:30:31.867491
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default_0 = ansible_j_s_o_n_encoder_0.default('')



# Generated at 2022-06-24 20:30:39.600696
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    test_o_1 = None

    try:
        assert ansible_j_s_o_n_encoder_1.default(test_o_1) == test_o_1
    except AssertionError as e:
        print(e)
        raise


# Generated at 2022-06-24 20:30:43.892706
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = to_text(',', errors='surrogate_or_strict')
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)


# Generated at 2022-06-24 20:30:45.835484
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert False


# Generated at 2022-06-24 20:30:47.297037
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:56.399243
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_0 = datetime.date(2001, 11, 26)
    class K(object):
        def __init__(self):
            self._ciphertext = '$ANSIBLE_VAULT;1.1;AES256;'
            self.__ENCRYPTED__ = True
        def __repr__(self):
            return repr(self._ciphertext)
    vault_0 = K()
    class H(str):
        __UNSAFE__ = True
    class V(str):
        __ENCRYPTED__ = True

# Generated at 2022-06-24 20:31:30.199685
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {'foo': 'bar'}
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert result == o


# Generated at 2022-06-24 20:31:31.120376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True



# Generated at 2022-06-24 20:31:34.224674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(str())


# Generated at 2022-06-24 20:31:36.817082
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default({})


# Generated at 2022-06-24 20:31:39.600971
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('o')


# Generated at 2022-06-24 20:31:41.539991
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = object()


# Generated at 2022-06-24 20:31:48.846509
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_module_utils.basic.AnsibleUnsafe(to_text("AnsibleUnsafe"))
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_0._vault_to_text = False
    # TODO: Add tests for method default
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)



# Generated at 2022-06-24 20:31:53.887562
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert type(ansible_json_encoder_0.default(dict())) == dict


# Generated at 2022-06-24 20:31:59.378468
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    val_as_text = "[\"$ANSIBLE_VAULT;1.1;AES256\"]\n\n[Some B64 data here]\n"
    vault = to_text(val_as_text, errors='surrogate_or_strict')
    ret_val = ansible_j_s_o_n_encoder_1.default(vault)
    assert type(ret_val) == dict

# Generated at 2022-06-24 20:32:01.383192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:04.686656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    unsafe_4 = 'test_value'
    try:
        ansible_j_s_o_n_encoder_0.default(unsafe_4)
    except Exception:
        print("Error: type object 'AnsibleUnsafe' has no attribute '__ENCRYPTED__'")


# Generated at 2022-06-24 20:33:09.979758
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)
    ansible_j_s_o_n_encoder_0.default(o=None)
    ansible_j_s_o_n_encoder_0.default(o=None)
    ansible_j_s_o_n_encoder_0.default(o=None)


# Generated at 2022-06-24 20:33:12.876209
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o={})


# Generated at 2022-06-24 20:33:13.785600
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:33:22.980142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with default values
    ansible_j_s_o_n_encoder_0_default = AnsibleJSONEncoder()
    ansible_vault_0_default = AnsibleVault()
    ansible_unsafe_0_default = AnsibleUnsafe()
    m_0_default = Mapping()
    o_0_default = datetime.date()
    o_1_default = datetime.datetime()
    ansible_j_s_o_n_encoder_0_default.default(ansible_vault_0_default)
    ansible_j_s_o_n_encoder_0_default.default(ansible_unsafe_0_default)
    ansible_j_s_o_n_encoder_0_default.default(m_0_default)
    ans

# Generated at 2022-06-24 20:33:25.238690
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(AnsibleJSONEncoder()) == AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:28.455300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # FIXME: Execute test
    # assert <condition>, "<message>"



# Generated at 2022-06-24 20:33:32.568220
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)



# Generated at 2022-06-24 20:33:43.833701
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Create an instance of AnsibleJSONEncoder
    ansible_json_encoder0 = AnsibleJSONEncoder()

    # Create a vault object
    ansible_vault0 = AnsibleVaultEncryptedUnicode('AQECAHg8VvxDhIjw')

    # Call method, default, on class AnsibleJSONEncoder with the arguments (ansible_vault0)
    method_return = ansible_json_encoder0.default(ansible_vault0)

    # Assert that the return of the method, default, for class, AnsibleJSONEncoder, is equal to the expected return
    assert method_return == {'__ansible_vault': 'AQECAHg8VvxDhIjw'}


# Generated at 2022-06-24 20:33:49.438802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    a_n_s_i_b_l_e_u_n_s_a_f_e = 0
    o = a_n_s_i_b_l_e_u_n_s_a_f_e
    # Test method call
    ansible_j_s_o_n_encoder_0.default(o)
    # No exception raised

