

# Generated at 2022-06-24 20:25:19.426041
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_u_n_s_a_f_e_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    var_0 = ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)
    if (var_0):
        if (var_0.get('__ansible_unsafe')):
            pass


# Generated at 2022-06-24 20:25:27.710527
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(str_0)
    str_1 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_unsafe_0 = AnsibleUnsafe(str_1)
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    str_2 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_vault_0 = AnsibleVaultEncryptedUnicode(str_0)
    ansible_j

# Generated at 2022-06-24 20:25:38.279883
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    var_0 = ansible_j_s_o_n_encoder_0.default(str_0)
    var_1 = ansible_j_s_o_n_encoder_0.default('$ANSIBLE_VAULT;1.1;AES256;user1')
    var_2 = ansible_j_s_o_n_encoder_0.default(b'')
    var_3 = ansible_j_s_o_n_encoder_0.default(u'$ANSIBLE_VAULT;1.1;AES256;user1')
    var_4 = ansible_j

# Generated at 2022-06-24 20:25:39.143857
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # testing default method of method default of class AnsibleJSONEncoder
    test_case_0()


# Generated at 2022-06-24 20:25:42.619938
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    var_0 = ansible_j_s_o_n_encoder_0.default(str_0)


# Generated at 2022-06-24 20:25:47.560885
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    user_input = raw_input("Enter test case number (0-1): ")
    if user_input == '0':
        test_case_0()
    else:
        print("Invalid test case number!")



# Generated at 2022-06-24 20:25:53.135083
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    var_0 = ansible_j_s_o_n_encoder_0.default(str_0)

# Generated at 2022-06-24 20:25:55.295315
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '^?Suec5Tsa$Me,3E(N\\M'
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    var_0 = ansible_json_encoder_0.default(str_0)


# Generated at 2022-06-24 20:25:58.802286
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    str_0 = '&5ifl,|B~>c%'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    var_0 = ansible_j_s_o_n_encoder_0.default(str_0)

# Generated at 2022-06-24 20:25:59.637898
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Call subcase_0()
    test_case_0()


# Generated at 2022-06-24 20:26:07.086488
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_0 = ansible_v_a_u_l_t_0 = AnsibleVaultEncryptedUnicode('hello')
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_0)


# Generated at 2022-06-24 20:26:08.591189
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = json.dumps([1, 2, 3], cls=AnsibleJSONEncoder)


# Generated at 2022-06-24 20:26:18.714381
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = None
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == ansible_u_n_s_a_f_e_0
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('Lorem ipsum dolor sit amet')
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == dict(__ansible_unsafe='Lorem ipsum dolor sit amet')
    assert ansible_j

# Generated at 2022-06-24 20:26:24.521213
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Sample inputs
    ansible_j_s_o_n_encoder_0.default((1, 2, 3))
    # Sample inputs
    ansible_j_s_o_n_encoder_0.default((1, 2, 3))


# Generated at 2022-06-24 20:26:31.188498
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(bool()) == False, "AnsibleJSONEncoder default Failed"

# Generated at 2022-06-24 20:26:32.601631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:26:36.048870
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # obj = AnsibleJSONEncoder.default(self, o)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 20:26:41.867764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = [
        'test1',
        'test2',
        'test3',
        'test4',
        'test5',
        'test6',
        'test7'
    ]
    ansible_unsafe_1 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    assert ansible_unsafe_1 == ansible_unsafe_0

# Generated at 2022-06-24 20:26:48.189750
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_safe_0 = ansible_j_s_o_n_encoder_0.default('__ansible_unsafe__')
    if ansible_u_n_safe_0 is not None:
        if ansible_u_n_safe_0['__ansible_unsafe'] != '__ansible_unsafe__':
            assert False
    else:
        assert False


# Generated at 2022-06-24 20:26:50.638399
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False

# Generated at 2022-06-24 20:26:58.092730
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    
    # set default values
    o = None
    result = ansible_j_s_o_n_encoder_1.default(o)

    # assert return type
    assert isinstance(result, (str, unicode))
    assert result == 'null'


# Generated at 2022-06-24 20:27:04.112047
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default({'a': 'A'})
    ansible_j_s_o_n_encoder_0.default(1)


# Generated at 2022-06-24 20:27:13.606363
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsibleJSONEncoder default

    # Unit test for method default of class AnsibleJSONEncoder with parameters ansibleUnsafe, ansibleUnsafe2
    ansible_unsafe_0 = AnsibleUnsafe('safe')
    ansible_unsafe_1 = AnsibleUnsafe(ansible_unsafe_0)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_unsafe_1.__dict__.update({'__ansible_unsafe' : 'safe'})
    assert ansible_j_s_o_n_encoder_1.default(ansible_unsafe_0) == ansible_unsafe_1.__dict__
    #assert ansible_j_s_o_n_encoder_1.default(ansible_unsafe_0

# Generated at 2022-06-24 20:27:22.199633
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = dict(a = dict(b = dict(c = dict(d = dict(e = dict(f = dict(g = dict(h = "test"))))))))

    expected = {
        u'a': {
            u'b': {
                u'c': {
                    u'd': {
                        u'e': {
                            u'f': {
                                u'g': {
                                    u'h': u'test'
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    actual = AnsibleJSONEncoder().default(o)
    assert actual == expected


# Generated at 2022-06-24 20:27:28.693343
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    class A(str):
        __UNSAFE__ = True
    a = A()
    ansible_j_s_o_n_encoder.default(a)
    ansible_j_s_o_n_encoder.default('hello')


# Generated at 2022-06-24 20:27:36.763946
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_o_0 = ansible_j_s_o_n_encoder_0.default(o=ansible_j_s_o_n_encoder_0_o_0)
    ansible_j_s_o_n_encoder_0_o_1 = ansible_j_s_o_n_encoder_0.default({'a':1})
    ansible_j_s_o_n_encoder_0_o_2 = ansible_j_s_o_n_encoder_0.default([1,2])
    ansible_j_s_o_n_encoder_0_o_3 = ansible_

# Generated at 2022-06-24 20:27:45.700521
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Encoding of None
    ansible_j_s_o_n_encoder_None = AnsibleJSONEncoder().default(None)
    assert ansible_j_s_o_n_encoder_None == 'None'

    # Encoding of empty string
    ansible_j_s_o_n_encoder_empty_string = AnsibleJSONEncoder().default('')
    assert ansible_j_s_o_n_encoder_empty_string == '""'

    # Encoding of empty string with json null value
    ansible_j_s_o_n_encoder_json_null = AnsibleJSONEncoder(sort_keys=True, ensure_ascii=False,
                                                            indent=2, separators=(',', ': ')).default('')
    assert ansible_j

# Generated at 2022-06-24 20:27:54.091406
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_7 = AnsibleJSONEncoder()
    ansible_j_s

# Generated at 2022-06-24 20:27:57.301183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    o = 'abc'

    # Call method default with args
    r = ansible_j_s_o_n_encoder.default(o)

    assert isinstance(r, str)


# Generated at 2022-06-24 20:28:00.568821
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    value = json_encoder.default(Mapping)
    assert value == Mapping

# Generated at 2022-06-24 20:28:03.306947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test default method of AnsibleJSONEncoder class"""



# Generated at 2022-06-24 20:28:07.883265
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test case: __ENCRYPTED__, self._vault_to_text = True
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    o = "__ENCRYPTED__"
    try:
        ansible_j_s_o_n_encoder_0.default(o)
    except:
        pass
    # Test case: __ENCRYPTED__, self._vault_to_text = False
    ansible_j_s_o_n_encoder_0._vault_to_text = False
    o = "__ENCRYPTED__"

# Generated at 2022-06-24 20:28:11.133423
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    # TODO : Test whether the method is actually implemented
    #raise NotImplementedError()


# Generated at 2022-06-24 20:28:19.065059
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.module_utils.six.moves.urllib.parse import unquote
    assert unquote("%5B%22%3Cscript%3Ealert%28%2Fxss%2F%29%3C%2Fscript%3E%22%5D") == ansible_j_s_o_n_encoder_0.default("[\"<script>alert(/xss/)</script>\"]")


# Generated at 2022-06-24 20:28:23.148762
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'a string'
    ret_value = ansible_j_s_o_n_encoder_0.default(o)
    assert ret_value == 'a string', "AnsibleJSONEncoder.default() failed"


# Generated at 2022-06-24 20:28:26.560760
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.parsing import vault
    # TODO: test code here


# Generated at 2022-06-24 20:28:30.253103
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    # AnsibleJSONEncoder().default()
    # AnsibleJSONEncoder().default()
    pass


# Generated at 2022-06-24 20:28:37.496413
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_0.default()


# Generated at 2022-06-24 20:28:40.059923
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:28:46.956764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Unit test for method default of class AnsibleJSONEncoder with arguments
    # (o)
    # Expect that the test for type() fails, since the AnsibleUnsafe object encodes to a
    # dictionary
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafe
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    vault = VaultLib(b'PASSWORD')
    ansible_unsafe_0 = AnsibleUnsafe(b'value', vault)
    ansible_unsafe_1 = AnsibleUnsafe(b'value')
    ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:28:50.581163
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:52.137679
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default = AnsibleJSONEncoder.default


# Generated at 2022-06-24 20:28:54.260689
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'te' + 'st'
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:28:58.891552
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # need to set up the input value
    o = object()

    # expected output
    expected = NotImplemented

    # actual output
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    actual = ansible_j_s_o_n_encoder_0.default(o)

    assert expected == actual

# Generated at 2022-06-24 20:29:03.415063
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # ValueError: datetime.datetime(2019, 7, 14, 21, 35, 35, 31406) is not JSON serializable
    try:
        ansible_j_s_o_n_encoder_0.default(datetime.datetime(2019, 7, 14, 21, 35, 35, 31406))
    except Exception as e:
        print(e)


# Generated at 2022-06-24 20:29:05.171152
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj_0 = AnsibleJSONEncoder()
    o_0 = obj_0.default(1)


# Generated at 2022-06-24 20:29:12.063043
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    input_0 = dict(a='\u2713')
    input_0_dict = dict()
    input_0_dict['a'] = '\u2713'
    output_0 = ansible_j_s_o_n_encoder_0.default(input_0)
    assert output_0 == input_0_dict

if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:21.546643
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_0._current_indent_level = 0
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_1._current_indent_level = 0
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:29:23.617067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_obj = AnsibleJSONEncoder()
    data = 'ansible'
    result = test_obj.default(data)
    assert result == data

# Generated at 2022-06-24 20:29:29.612879
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_date_0 = datetime.date(2015, 7, 1)

    test_case_0_str = ansible_j_s_o_n_encoder_0.default(datetime_date_0)
    assert test_case_0_str == "2015-07-01"


# Generated at 2022-06-24 20:29:43.509810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_unsafe_1 = AnsibleUnsafe(u'ansible_unsafe')
    ansible_unsafe_2 = AnsibleUnsafe(u'ansible_unsafe')
    ansible_unsafe_3 = AnsibleUnsafe(u'ansible_unsafe')
    ansible_unsafe_4 = AnsibleUnsafe(u'ansible_unsafe')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode(u'ansible_vault')
    ansible_vault_2 = AnsibleVaultEncryptedUnicode(u'ansible_vault')
    ansible_vault_3 = AnsibleVaultEncryptedUnicode(u'ansible_vault')

# Generated at 2022-06-24 20:29:46.423492
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default('Hello World!') == 'Hello World!'


# Generated at 2022-06-24 20:29:54.506753
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 =  {'__ansible_unsafe': 'testValue'}

    test_data = {
            0: datetime.datetime.now(),
            1: datetime.datetime.now(),
            2: datetime.datetime.now(),
            3: datetime.datetime.now(),
            4: datetime.datetime.now(),
            5: datetime.datetime.now(),
            6: datetime.datetime.now(),
        }

    #example_list_call = ansible_j_s_o_n_encoder_0.default(test_data)
    example_call = ansible_j_s_o_n_

# Generated at 2022-06-24 20:29:58.153206
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    test_variable_0 = None
    assert ansible_j_s_o_n_encoder_0.default(test_variable_0) is None


# Generated at 2022-06-24 20:30:04.704098
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('abc')
    ansible_u_n_s_a_f_e_0.__UNSAFE__ = True
    try:
        assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == {'__ansible_unsafe': 'abc'}
    except AssertionError as e:
        raise e


# Generated at 2022-06-24 20:30:16.215978
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:30:26.457719
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = 'abc'
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == 'abc'

    ansible_unsafe_1 = b'abc'
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_1) == 'abc'

    ansible_unsafe_2 = u'abc'
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_2) == 'abc'

    ansible_unsafe_3 = b'abc\r\n'
    assert ansible_j_s_o_n_encoder_0

# Generated at 2022-06-24 20:30:29.348023
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    if not hasattr(ansible_j_s_o_n_encoder_0, 'default'):
        raise AssertionError("'default' method is not defined")


# Generated at 2022-06-24 20:30:30.896722
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:30:41.367580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Check the value returned by method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default({})

    # Check the value in the return of method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default({}) == {}

    ansible_j_s_o_n_encoder_0.default([])

    # Check the value in the return of method default of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0.default([]) == []

    ansible_j_s_o_n_encoder_0.default(1)

    # Check the value in the return of method

# Generated at 2022-06-24 20:30:49.731239
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:31:00.357438
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default('')
    assert ansible_unsafe_0 == ''
    o_1 = ''
    ansible_unsafe_1 = ansible_j_s_o_n_encoder_0.default(o_1)
    assert ansible_unsafe_1 == ''
    o_2 = {}
    ansible_unsafe_2 = ansible_j_s_o_n_encoder_0.default(o_2)
    assert ansible_unsafe_2 == {}
    o_3 = {'a': 1, 'b': 'b'}
    ansible_unsafe_3 = ansible_

# Generated at 2022-06-24 20:31:03.717858
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default


# Generated at 2022-06-24 20:31:06.446783
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_1.default(output) # <Result: result>


# Generated at 2022-06-24 20:31:11.799866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {'__UNSAFE__': True, '__ENCRYPTED__': False}
    assert(ansible_j_s_o_n_encoder_0.default(o) == {'__ansible_unsafe': ''})
    o = {'__UNSAFE__': False, '__ENCRYPTED__': True}
    assert(ansible_j_s_o_n_encoder_0.default(o) == {'__ansible_vault': ''})

# Generated at 2022-06-24 20:31:17.245635
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)


# Generated at 2022-06-24 20:31:21.857295
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default(o=object()) == '{}'


# Generated at 2022-06-24 20:31:24.856170
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)


# Generated at 2022-06-24 20:31:30.682518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 0
    ansible_j_s_o_n_encoder_0.default(o)



# Generated at 2022-06-24 20:31:33.178089
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:31:49.626361
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    for string in string_types:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

        # Note: AnsibleUnsafe is not an actual ansible type, but a part of the ansible code
        #       It is used to prevent ansible from accidentally printing secrets to stdout
        #       We encode it here because it inherits from string_types, which is not handled
        #       in the base encoder
        class AnsibleUnsafe(string):
            __UNSAFE__ = True
        a_n_safe_string_0

# Generated at 2022-06-24 20:31:54.160044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)
    assert value == "AnsibleJSONEncoder object at 0x7f8b7d0b79e8"


# Generated at 2022-06-24 20:32:01.992231
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Reading Date Values
    assert datetime.date == type(datetime.date.today())
    # Reading JSON Values
    assert AnsibleJSONEncoder in type(AnsibleJSONEncoder()).mro()
    assert json.JSONEncoder in type(AnsibleJSONEncoder()).mro()
    # Reading Object Values
    assert AnsibleJSONEncoder in type(AnsibleJSONEncoder()).mro()
    assert json.JSONEncoder in type(AnsibleJSONEncoder()).mro()
    # Reading String Values
    assert str == type("str")
    assert bool == type(True)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Reading "json.tests.ansible_test.AnsibleJSONEncoder" class values
    ansible_j

# Generated at 2022-06-24 20:32:04.285495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default = AnsibleJSONEncoder()._default()


# Generated at 2022-06-24 20:32:11.646476
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe_0(str):
        pass
    import json
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe_0('ansible_unsafe')
    ansible_unsafe_0.__UNSAFE__ = True
    ansible_unsafe_0.__ENCRYPTED__ = False
    ansible_json_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:32:13.080919
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:32:21.103253
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test 0: testing when object is a dict
    dict_to_encode = {'a': 1, 'b': 2}
    encoded = ansible_json_encoder.default(dict_to_encode)
    assert type(encoded) is dict
    assert encoded['a'] == 1
    assert encoded['b'] == 2

    # Test 1: testing when object is a list
    list_to_encode = [1, 2, 3]
    encoded = ansible_json_encoder.default(list_to_encode)
    assert type(encoded) is list
    assert encoded[0] == 1
    assert encoded[1] == 2
    assert encoded[2] == 3

    # Test 2: testing when object is a str
    str_to

# Generated at 2022-06-24 20:32:21.977841
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    assert AnsibleJSONEncoder().default('foo') == 'foo'


# Generated at 2022-06-24 20:32:22.843269
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_AnsibleJSONEncoder_default_0()


# Generated at 2022-06-24 20:32:32.694528
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    vault_lib_0 = VaultLib()
    from ansible.parsing.vault import VaultEditor
    vault_editor_0 = VaultEditor(vault_lib_0, b'1234')

# Generated at 2022-06-24 20:32:49.346236
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default()


# Generated at 2022-06-24 20:32:55.941631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    obj_0 = AnsibleUnsafe('8W`[')
    temp_0 = ansible_j_s_o_n_encoder_0.default(obj_0)

    assert temp_0 == {'__ansible_unsafe': u'8W`['}
    obj_1 = VaultLib()
    obj_1._ciphertext = u'8W`['
    obj_1.__ENCRYPTED__ = True
    temp_1 = ansible_j_s_o_n_encoder_0.default(obj_1)

    assert temp_1 == {'__ansible_vault': u'8W`['}

# Generated at 2022-06-24 20:33:00.868354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {"message": "Hello", "data": {"user": "Ansible"}}
    ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:33:11.056952
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = str()
    vars(ansible_u_n_s_a_f_e_0).setdefault('__UNSAFE__', True)
    ansible_v_a_u_l_t_0 = str()
    vars(ansible_v_a_u_l_t_0).setdefault('__ENCRYPTED__', True)
    ansible_v_a_u_l_t_0._ciphertext = 'ansible'

# Generated at 2022-06-24 20:33:17.042240
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = False
    ansible_j_s_o_n_encoder_0._vault_to_text = False
    ansible_j_s_o_n_encoder_0.indent = False

# Generated at 2022-06-24 20:33:24.310743
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_

# Generated at 2022-06-24 20:33:28.093666
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    assert ansible_j_s_o_n_encoder_0.default(o) == {}


# Generated at 2022-06-24 20:33:37.453209
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_vault_0 = object()
    ansible_unsafe_0 = object()
    # TODO: Add code to test the default method of the AnsibleJSONEncoder class
    # assert ansible_j_s_o_n_encoder_0.default(ansible_vault_0) == ansible_j_s_o_n_encoder_0.default(ansible_vault_0)
    # assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0) == ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:33:41.151298
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    ansible_j_s_o_n_encoder_0.default('foo')

# Generated at 2022-06-24 20:33:46.055215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    object_0 = ansible_j_s_o_n_encoder_0.default("qwerty")
    assert "qwerty" == object_0


# Generated at 2022-06-24 20:34:20.781528
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('test_value_1')


# Generated at 2022-06-24 20:34:28.854656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe:
        __UNSAFE__ = True
    obj = AnsibleUnsafe()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        ansible_j_s_o_n_encoder_0.default(obj)
    except Exception:
        pass
    else:
        raise Exception()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_1.default(obj)


# Generated at 2022-06-24 20:34:32.981968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:34:38.825890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(datetime.datetime.now()) is not None
    assert ansible_j_s_o_n_encoder_0.default({'k': 'v'}) is not None

# Generated at 2022-06-24 20:34:44.693338
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = datetime.datetime(2020, 3, 5, 9, 20, 15, 545434)
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:34:49.825729
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default()

# Generated at 2022-06-24 20:34:55.138628
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dump_data = {"one": 1, "two": 2}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    dump_data_0 = ansible_j_s_o_n_encoder_0.default(dump_data)
    assert(dump_data == dump_data_0)


# Generated at 2022-06-24 20:35:05.919366
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_0 = ansible_v_a_u_l_t_1 = ansible_v_a_u_l_t_2 = ansible_v_a_u_l_t_3 = ansible_v_a_u_l_t_4 = ansible_v_a_u_l_t_5 = ansible_v_a_u_l_t_6 = ansible_v_a_u_l_t_7 = ansible_v_a_u_l_t_8 = ansible_v_a_u_l_t_9 = ansible_v_a_u_l_t_10 = ansible_v_a_u_

# Generated at 2022-06-24 20:35:14.760354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('/etc/shadow')
    ansible_v_a_u_l_t_0 = VaultLib.new()
    generic_0 = ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0)
    generic_1 = ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_0)
    assert (generic_0 == '"/etc/shadow"')