

# Generated at 2022-06-24 20:25:17.390081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:25:25.429186
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(o='{{"__ansible_unsafe": "\\"foo\\""}}') == "{\"__ansible_unsafe\": \"foo\"}"
    assert ansible_j_s_o_n_encoder_0.default(o='{{"__ansible_vault": "\\"foo\\""}}') == "{\"__ansible_vault\": \"foo\"}"
    assert ansible_j_s_o_n_encoder_0.default(o='{{"__ansible_unsafe": "\\"foo\\""}}') == "{\"__ansible_unsafe\": \"foo\"}"
    assert ansible_j_s_o_n_

# Generated at 2022-06-24 20:25:30.014724
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 0
    result = ansible_j_s_o_n_encoder_0.default(o)
    # Verify the expected result
    assert result == 0


# Generated at 2022-06-24 20:25:39.255537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime.datetime_0 = datetime.datetime(2017, 8, 17, 9, 29, 19, 380537)
    ansible_e_p_o_c_0 = datetime.datetime.fromtimestamp(0)
    ansible_e_p_o_c_1 = datetime.datetime.fromtimestamp(0)
    assert ansible_j_s_o_n_encoder_0.default(datetime.datetime_0) == u'2017-08-17T09:29:19.380537'

# Generated at 2022-06-24 20:25:42.890192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for default method
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    test_data_json_dict_0 = {"test_data_json_0": "test_data_dict_0"}
    assert ansible_j_s_o_n_encoder_0.default(test_data_json_dict_0) == test_data_json_dict_0



# Generated at 2022-06-24 20:25:48.632614
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0_default = ansible_j_s_o_n_encoder_0.default
    ansible_j_s_o_n_encoder_0_default()
    pass


# Generated at 2022-06-24 20:25:49.550134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    assert True



# Generated at 2022-06-24 20:25:51.803727
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = None
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:25:57.338342
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)


# Generated at 2022-06-24 20:26:03.436046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    # Execute test
    ansible_j_s_o_n_encoder_default_0.default(o=None)
    # AssertionError[bool] reference_name: None # noqa


# Generated at 2022-06-24 20:26:07.352912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(None) == None


# Generated at 2022-06-24 20:26:08.611566
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(None)


# Generated at 2022-06-24 20:26:12.657678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # AnsibleJSONEncoder.default(object)
    ansible_j_s_o_n_encoder_1.default('')


# Generated at 2022-06-24 20:26:21.216703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_u_n_safe_str_0 = 'ansible_unsafe'
    ansible_u_n_safe_0 = AnsibleUnsafe(ansible_u_n_safe_str_0)
    ansible_v_a_u_l_t_s_tr_0 = 'ansible_vault'
    ansible_v_a_u_l_t_0 = AnsibleVault(ansible_v_a_u_l_t_s_tr_0)
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_0)
    ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:26:25.726609
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(o = '') is None


# Generated at 2022-06-24 20:26:32.001437
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_instance = AnsibleJSONEncoder()
    test_dict = {'test': 'test_value'}

    # Test case for key 'test' in test_dict
    assert ansible_json_encoder_instance.default(test_dict['test']) == 'test_value'


# Generated at 2022-06-24 20:26:41.773287
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.six import binary_type

    import textwrap
    import sys

    if sys.version_info[:2] == (2, 7):
        # ansible.parsing.vault.VaultEditor is not compatible with python 2.7
        return

    #
    # Pre-condition:
    #   Declare variable
    #
    #     ansible_j_s_o_n_encoder_0 - contains value of object AnsibleJSONEncoder
    #

    #
    # 1) Test with SafeText
    #
    #       AnsibleSafeText - inherits from six.text_type
    #       six.text_type - inherits

# Generated at 2022-06-24 20:26:46.529803
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Input parameters
    o = 'string'

    # Expected return value
    expected_result = 'string'

    # Call the method
    result = ansible_j_s_o_n_encoder_0.default(o)

    assert result == expected_result


# Generated at 2022-06-24 20:26:51.701257
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = ansible_j_s_o_n_encoder_0.default
    assert False, 'Failed to assert that test_AnsibleJSONEncoder_default is implemented'


# Generated at 2022-06-24 20:27:01.409261
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Testing the type of an if condition (line 31)
    if _is_unsafe('a'):
        pass
    else:
        pass
    # Testing the type of an if condition (line 32)
    if _is_vault('b'):
        pass
    # Testing the type of an if condition (line 33)
    if is_sequence('c'):
        pass
    # Testing the type of an if condition (line 34)
    if isinstance('d', Mapping):
        pass
    # Testing the type of an if condition (line 37)
    if getattr(1, '__UNSAFE__', False):
        pass
    # Testing the type of an if condition (line 38)
    if getattr(1, '__ENCRYPTED__', False):
        pass
    # Testing the type of an if condition

# Generated at 2022-06-24 20:27:05.065213
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:27:06.657733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    pass


# Generated at 2022-06-24 20:27:08.343803
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print("AnsibleJSONEncoder Class method default")
    pass


# Generated at 2022-06-24 20:27:10.920523
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_1.default(None)


# Generated at 2022-06-24 20:27:22.108899
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert not _is_unsafe(True)
    assert not _is_unsafe(1)
    assert not _is_unsafe(None)
    assert not _is_unsafe(dict())
    assert not _is_unsafe(list())
    assert _is_unsafe('AnsibleUnsafe')
    assert not _

# Generated at 2022-06-24 20:27:24.455048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = object()
    default = ansible_j_s_o_n_encoder_0.default(o)
    assert o == default

# Generated at 2022-06-24 20:27:28.741095
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:27:35.103475
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = datetime.datetime(2018, 6, 22, 23, 42, 56, 349813, tzinfo=datetime.timezone.utc)
    v_0 = ansible_j_s_o_n_encoder_0.default(o_0)


# Generated at 2022-06-24 20:27:44.969890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder_0.default('a') == 'a'
    assert ansible_j_s_o_n_encoder_0.default(1) == 1
    assert ansible_j_s_o_n_encoder_0.default(12.0) == 12.0
    assert ansible_j_s_o_n_encoder_0.default(True) == True
    assert ansible_j_s_o_n_encoder_0.default(False) == False
    assert ansible_j_s_o_n_encoder_0.default(None) == None
    assert ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:27:46.818429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == AnsibleJSONEncoder().default(None)


# Generated at 2022-06-24 20:27:53.272490
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default({}) is None


# Generated at 2022-06-24 20:27:56.582409
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    parameter_0 = {}
    parameter_0[1] = 1
    assert parameter_0 == ansible_j_s_o_n_encoder_0.default(parameter_0)


# Generated at 2022-06-24 20:28:04.452439
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # as seen in utils/unsafe_proxy.py
    class AnsibleUnsafeBytes(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

        def __deepcopy__(self, memo):
            return self

        def type(self):
            return 'basestring'

    class AnsibleVaultEncryptedUnicode(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True
        _ciphertext = 'test'

        def __deepcopy__(self, memo):
            return self

        def type(self):
            return 'basestring'

    ansible_unsafe_bytes_0 = AnsibleUnsafeBytes()
    ansible_

# Generated at 2022-06-24 20:28:05.941270
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:11.748426
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(datetime.datetime(2016, 12, 7, 0, 48, 58, 758772)) == u'2016-12-07T00:48:58.758772'


# Generated at 2022-06-24 20:28:15.896494
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = dict()
    assert isinstance(ansible_j_s_o_n_encoder_0.default(o), dict)



# Generated at 2022-06-24 20:28:20.698448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = __ansible_module__.ansible_json_encoder()
    
    __ansible_module__.exit_json(**{'msg': ansible_j_s_o_n_encoder_1.default(__ansible_module__.AnsibleUnsafe("{'unsafe_var': True}"))})



# Generated at 2022-06-24 20:28:24.142612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {'a': 1}
    # 'o' may not have been initialized


# Generated at 2022-06-24 20:28:27.971923
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_1.default(1) == '1'


# Generated at 2022-06-24 20:28:38.258604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import AnsibleVaultEncryptedUnicode
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import AnsibleUnsafeText
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Pass non-strict values to the AnsibleVaultEncryptedUnicode:
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(value=0)

    # Pass non-strict values to the AnsibleUnsafeText:
    ansible_unsafe_text_0 = AnsibleUnsafeText(value=0)

    # Pass good value for parameter 'o'
    ansible_j_s

# Generated at 2022-06-24 20:28:46.556423
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'UNSAFE STRING'
    ansible_j_s_o_n_encoder_0.default(o)

# Generated at 2022-06-24 20:28:48.222249
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:49.882044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:54.049078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    msg = 'AnsibleJSONEncoder.default(): Bad return type'
    assert isinstance(ansible_json_encoder.default({}), dict), msg


# Generated at 2022-06-24 20:28:59.174668
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    o = {"id": "def", "abc": "abc"}
    result = ansible_j_s_o_n_encoder.default(o)
    print(result)


if __name__ == '__main__':
    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:00.630455
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:10.054992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0.default()
    except TypeError:
        ansible_j_s_o_n_encoder_1.default(o=None)
    else:
        assert False, "Expected TypeError"
    try:
        ansible_j_s_o_n_encoder_2.default(1)
    except TypeError:
        assert True
    else:
        assert False, "Expected TypeError"


# END TEST CASES


# Generated at 2022-06-24 20:29:17.236221
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    data = {"hello":"world"}
    result = ansible_j_s_o_n_encoder_0.default(data)
    if isinstance(result, dict) and result == {"hello": "world"}\
            and result is not data:
        print("Test case 0 passed.")
    else:
        print("Test case 0 failed.")


# Generated at 2022-06-24 20:29:20.210016
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = str
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:29:23.937092
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)
    assert o_0 is not None


# Generated at 2022-06-24 20:29:34.161524
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

if __name__ == "__main__":
    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:29:36.489233
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ''
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(0) == 0

# Generated at 2022-06-24 20:29:46.182760
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    ansible_unsafe = AnsibleUnsafe('ansible', False)
    vault_text = "Hello World"
    vault_pwd = 'MY-SECRET-TEST-PASSWORD'

# Generated at 2022-06-24 20:29:49.419330
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_1 = AnsibleUnsafe('test')
    ansible_j_s_o_n_encoder_1.default(o_1)


# Generated at 2022-06-24 20:29:50.565458
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None


# Generated at 2022-06-24 20:29:52.174786
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:29:54.652354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0


# Generated at 2022-06-24 20:30:03.737244
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {
        '__ansible_unsafe': 'k3y',
        '__ansible_vault': 'b64( encrypted_data )',
        '__ansible_facts': 'k3y'
    }
    k_0 = '__ansible_unsafe'
    ansible_j_s_o_n_encoder_0.default(o_0[k_0])
    k_0 = '__ansible_vault'
    ansible_j_s_o_n_encoder_0.default(o_0[k_0])
    k_0 = '__ansible_facts'

# Generated at 2022-06-24 20:30:14.626046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_5 = AnsibleJSONEncoder()

    pass


# Generated at 2022-06-24 20:30:15.744957
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:30:43.549596
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    class AnsibleUnsafe(string_types[0]):
        pass
    o_1 = AnsibleUnsafe()
    o_2 = {'a': AnsibleUnsafe(),
           'b': AnsibleUnsafe()}
    o_3 = [AnsibleUnsafe(), AnsibleUnsafe()]
    o_4 = (AnsibleUnsafe(), AnsibleUnsafe())
    o_5 = {'a': {'b': AnsibleUnsafe()}}

    # check that the default method of AnsibleJSONEncoder returns an
    # AnsibleUnsafe object unchanged

# Generated at 2022-06-24 20:30:51.852884
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder_0.default([]) == []
    assert ansible_j_s_o_n_encoder_0.default({}) == {}
    assert ansible_j_s_o_n_encoder_0.default(None) is None
    assert ansible_j_s_o_n_encoder_0.default(True) is True
    assert ansible_j_s_o_n_encoder_0.default(False) is False
    assert ansible_j_s_o_n_encoder_0.default('0') == '0'

# Generated at 2022-06-24 20:30:57.829338
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Testing parameter 'o'
    k = AnsibleJSONEncoder()
    assert k.default(1) == 1
    assert k.default(2.2) == 2.2
    assert k.default('string') == 'string'
    assert k.default([1, 2, 'string']) == [1, 2, 'string']
    assert k.default({'key': 'value'}) == {'key': 'value'}



# Generated at 2022-06-24 20:31:06.696589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = {'hello': 'world'}
    assert '{"hello": "world"}' == AnsibleJSONEncoder().encode(d)
    d = {'hello': 'world', 'safe': '123'}
    assert '{"hello": "world", "safe": "123"}' == AnsibleJSONEncoder().encode(d)
    d = {'hello': 'world', 'safe': '123', 'unsafe': '456'}
    assert '{"hello": "world", "safe": "123", "unsafe": {"__ansible_unsafe": "456"}}' == AnsibleJSONEncoder().encode(d)
    d = {'hello': 'world', 'safe': '123', 'vault': '456'}

# Generated at 2022-06-24 20:31:16.314411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    expected_result_0 = '"__ansible_vault" object does not support indexing'
    expected_result_1 = '"__ansible_unsafe" object does not support indexing'
    expected_result_2 = '"__ansible_vault" object does not support indexing'
    expected_result_3 = '"__ansible_unsafe" object does not support indexing'
    expected_result_4 = '"__ansible_vault" object does not support indexing'
    expected_result_5 = '"__ansible_unsafe" object does not support indexing'
    expected_result_6 = '"__ansible_vault" object does not support indexing'

# Generated at 2022-06-24 20:31:18.189754
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
  test_case_0()

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:31:24.611099
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    # Example of a object that has an attribute that is set to a bolean
    ansible_vault = getattr('str', '__ENCRYPTED__', False)
    # We now call the default method of the class AnsibleJSONEncoder
    # Set the object the class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder.default(ansible_vault)
    # Example of a object that has an attribute that is set to a bolean
    ansible_unsafe = getattr('str', '__UNSAFE__', False)
    # Set the object the class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder.default(ansible_unsafe)
    # Example of

# Generated at 2022-06-24 20:31:30.480890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    # These methods have no relevant unit tests
    #def iterencode(self, o, _one_shot=False)
    #def encode(self, o, _one_shot=False)



# Generated at 2022-06-24 20:31:39.950741
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test 1, with empty case and good input
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    ansible_j_s_o_o_b_j_e_c_t_1 = {'__ansible_unsafe': 'hello'}

    str_var_1 = 'hello'
    ansible_unsafe_1 = str(str_var_1)

    ansible_j_s_o_n_encoder_1.encode_basestring(ansible_unsafe_1)

    ansible_j_s_o_n_encoder_1.encode_basestring_ascii(ansible_unsafe_1)

    json_unsafe_1 = ansible_j_s_o_n_encoder_1.iteren

# Generated at 2022-06-24 20:31:48.956155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_7 = AnsibleJSONEncoder()
    ansible_j_s

# Generated at 2022-06-24 20:32:24.716215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = 'o'
    result = ansible_j_s_o_n_encoder_1.default(o)
    assert result == 'o'


# Generated at 2022-06-24 20:32:30.580969
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe(b'1')
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


# Generated at 2022-06-24 20:32:37.000657
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_0 = datetime.datetime(2019, 1, 3)
    str_0 = ansible_j_s_o_n_encoder_0.default(datetime_0)
    assert str_0 == '2019-01-03T00:00:00'


# Generated at 2022-06-24 20:32:46.545986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_vault_0 = getattr(ansible_j_s_o_n_encoder_1, '__ENCRYPTED__', False)
    ansible_unsafe_1 = getattr(ansible_j_s_o_n_encoder_1, '__UNSAFE__', False)
    ansible_vault_1 = getattr(ansible_j_s_o_n_encoder_1, '__ENCRYPTED__', False)
    ansible_unsafe_2 = getattr(ansible_j_s_o_n_encoder_1, '__UNSAFE__', False)

# Generated at 2022-06-24 20:32:53.624676
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder.default(None)
    ansible_j_s_o_n_encoder.default(0)
#    ansible_j_s_o_n_encoder.default(1)
#    ansible_j_s_o_n_encoder.default(0.0)
#    ansible_j_s_o_n_encoder.default(1.0)
#    ansible_j_s_o_n_encoder.default(0.0+0.5j)
#    ansible_j_s_o_n_encoder.default(1.0+0.5j)
#    ansible_j_s_o_n_enc

# Generated at 2022-06-24 20:33:04.889256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    secret = VaultSecret('AES256', '1111111111111111', '1111111111111111')

# Generated at 2022-06-24 20:33:09.018780
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o=None)


# Generated at 2022-06-24 20:33:19.216913
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_7 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_8 = AnsibleJSONEncoder()
    ansible_j_s

# Generated at 2022-06-24 20:33:20.264776
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()



# Generated at 2022-06-24 20:33:24.653412
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
#    set_unsafe_object(ansible_j_s_o_n_encoder)
#    set_vault_object(ansible_j_s_o_n_encoder)
#    set_mapping(ansible_j_s_o_n_encoder)
#    set_date_object(ansible_j_s_o_n_encoder)
#    set_default_other(ansible_j_s_o_n_encoder)


# Generated at 2022-06-24 20:34:40.805320
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback
    def default(self, o):
        if getattr(o, '__ENCRYPTED__', False):
            # vault object
            if self._vault_to_text:
                value = to_text(o, errors='surrogate_or_strict')
            else:
                value = {'__ansible_vault': to_text(o._ciphertext, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-24 20:34:45.752385
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe("0")
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == ansible_u_n_s_a_f_e_0


# Generated at 2022-06-24 20:34:51.982157
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_obj_0 = datetime.date(2018,1,1)
    assert ansible_j_s_o_n_encoder_0.default(date_obj_0) == '2018-01-01'


# Generated at 2022-06-24 20:34:53.490896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(3)


# Generated at 2022-06-24 20:34:55.214176
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    t = AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = t()


# Generated at 2022-06-24 20:35:00.754251
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    datetime_date_0 = datetime.date(2018, 8, 23)
    assert_equal(ansible_j_s_o_n_encoder_1.default(datetime_date_0), '2018-08-23')


# Generated at 2022-06-24 20:35:07.674950
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Run test case 0
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Run test case 1
    ansible_vault_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # Run test case 2
    ansible_vault_j_s_o_n_encoder_1 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)


# Generated at 2022-06-24 20:35:11.103230
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(datetime.datetime(2010, 11, 19, 17, 42, 42))
