

# Generated at 2022-06-24 20:25:17.509755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    assert '{}', ansible_j_s_o_n_encoder_1.default({})

    assert '[]', ansible_j_s_o_n_encoder_1.default([])

    assert '', ansible_j_s_o_n_encoder_1.default(None)

    assert '2010-05-16', ansible_j_s_o_n_encoder_1.default(datetime.date(2010,5,16))


# Generated at 2022-06-24 20:25:20.614281
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(Mapping())
    ansible_j_s_o_n_encoder_0.default(datetime.datetime(2017, 7, 10, 2, 15, 2, 435616))


# Generated at 2022-06-24 20:25:29.001329
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Read in mock args, mock return value and expected output
    with open('tests/fixtures/module_utils/common/test_AnsibleJSONEncoder_default_mock_args') as f:
        mock_args = json.load(f)
    with open('tests/fixtures/module_utils/common/test_AnsibleJSONEncoder_default_mock_return') as f:
        mock_return = json.load(f)
    with open('tests/fixtures/module_utils/common/test_AnsibleJSONEncoder_default_expected_output') as f:
        expected_output = json.load(f)

    # Create a test instance of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Mock args for AnsibleJSON

# Generated at 2022-06-24 20:25:37.054639
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert isinstance(ansible_j_s_o_n_encoder_0.default(3), int) == True
    assert isinstance(ansible_j_s_o_n_encoder_0.default(u'fred'), unicode) == True
    assert isinstance(ansible_j_s_o_n_encoder_0.default(4.00), float) == True
    ansible_j_s_o_n_encoder_0.default(3+4.0j)


# Generated at 2022-06-24 20:25:43.441142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = {'a':'b','c':'d','e':'f','g':'h','i':'j','k':'l','m':'n','o':'p','q':'r','s':'t','u':'v','w':'x','y':'z'}
    o = AnsibleJSONEncoder._default(ansible_j_s_o_n_encoder_0,value)
    assert ansible_j_s_o_n_encoder_0._default == o


# Generated at 2022-06-24 20:25:44.453556
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:25:55.050967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # testing the body of the method
    test_object_0 = "test string"

    ansible_j_s_o_n_encoder_0.default(test_object_0)


# Generated at 2022-06-24 20:26:01.765251
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"a": "b"}
    ret_val_0 = ansible_j_s_o_n_encoder_0.default(o)
    assert ret_val_0 == {"a": "b"}

    o = "a"
    ret_val_1 = ansible_j_s_o_n_encoder_0.default(o)
    assert ret_val_1 == "a"

    o = [1,2,3]
    ret_val_2 = ansible_j_s_o_n_encoder_0.default(o)
    assert ret_val_2 == [1,2,3]

    # Test with non string items
    o = [1,2,3]
   

# Generated at 2022-06-24 20:26:03.170572
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:26:06.879730
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = dict()

    # Try to call the method
    result = ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:26:12.610473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder_0.default('')
    print(result)


# Generated at 2022-06-24 20:26:21.400035
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(allow_nan=True, preprocess_unsafe=True)
    test_obj = AnsibleJSONEncoder(allow_nan=True, preprocess_unsafe=True)
    str_var = 'foo'
    str_var_1 = 'bar'
    test_obj._preprocess_unsafe = True
    test_obj._vault_to_text = True
    test_obj._iterencode(str_var, str_var_1)
    str_var_2 = 'baz'
    str_var_3 = 'foo'
    test_obj._iterencode(str_var_2, str_var_3)
    str_var_4 = 'bar'
    str_var_5 = 'baz'


# Generated at 2022-06-24 20:26:26.607381
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe("This is my ansible string")
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)

# Generated at 2022-06-24 20:26:29.699508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default({})


# Generated at 2022-06-24 20:26:36.172622
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = None
    assert ansible_j_s_o_n_encoder_1.default(o) == None


# Generated at 2022-06-24 20:26:38.698927
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o = None)


# Generated at 2022-06-24 20:26:42.710823
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    default_return_value_2 = ansible_j_s_o_n_encoder_1.default(0)
    assert isinstance(default_return_value_2, int)
    assert default_return_value_2 == 0


# Generated at 2022-06-24 20:26:49.815985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    s_t_r_0 = "__ENCRYPTED__"

    # my_attr_0 contains: False
    my_attr_0 = not hasattr(ansible_j_s_o_n_encoder_0, s_t_r_0)

    # AssertionError: False != True : test_case_0.py:78: AssertionError
    assert my_attr_0, 'test_case_0.py:78: AssertionError'

# Generated at 2022-06-24 20:26:51.045418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True == False


# Generated at 2022-06-24 20:26:52.952369
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:00.984168
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    datetime_1 = datetime.date(year=2018, month=10, day=10)
    o = datetime_1
    ansible_j_s_o_n_encoder_0.default(o)
    assert '2018-10-10' == ansible_j_s_o_n_encoder_0.default(datetime_1)

# Generated at 2022-06-24 20:27:03.318859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default(object())


# Generated at 2022-06-24 20:27:04.344878
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:27:08.998011
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Instance creation
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(allow_nan=False,check_circular=True,ensure_ascii=True,indent=None,separators=None,sort_keys=False,default=None)
    # Invoke method
    ansible_j_s_o_n_encoder_0.default(o=None)



# Generated at 2022-06-24 20:27:11.319757
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # call method default
    result = ansible_j_s_o_n_encoder_0.default('test')
    assert result == 'test'


# Generated at 2022-06-24 20:27:22.423639
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default("")
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default("")
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default("")
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default("")
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default("")
    ansible_json_encoder_0.default(None)
    ansible_json_encoder_0.default("")

# Generated at 2022-06-24 20:27:25.659600
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = "ANSIBLE_JOB_ID"
    result = ansible_j_s_o_n_encoder_0.default(o)
    assert result == o

# Generated at 2022-06-24 20:27:35.524618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(None) is None
    assert ansible_j_s_o_n_encoder_0.default(1) == 1
    assert ansible_j_s_o_n_encoder_0.default(1.1) == 1.1
    assert ansible_j_s_o_n_encoder_0.default(1+1j) == "{'__complex__': True, 'real': 1.0, 'imag': 1.0}"
    assert ansible_j_s_o_n_encoder_0.default('a') == '"a"'
    assert ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:27:45.494625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:27:52.630313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = True

# Generated at 2022-06-24 20:28:00.003690
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = AnsibleJSONEncoder()  # dummy param
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:28:03.190169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = json.loads(to_text('{"some_key": "some_value"}'))
    ansible_j_s_o_n_encoder_1_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1_0.default(obj)


# Generated at 2022-06-24 20:28:04.250181
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = AnsibleJSONEncoder()
    b = a.default('foo')


# Generated at 2022-06-24 20:28:15.454925
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o_0 = {}
    o_1 = 'abc'
    o_2 = None
    o_3 = True
    o_4 = (1,)
    o_5 = {1: 'nu'}
    o_6 = datetime.datetime(2019, 1, 1, 0, 0)
    ansible_j_s_o_n_encoder_0.default(o_0)
    ansible_j_s_o_n_encoder_0.default(o_1)
    ansible_j_s_o_n_encoder_0.default(o_2)
    ansible_j_s_o_n_encoder_0.default(o_3)
    ansible_j

# Generated at 2022-06-24 20:28:24.032592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = ansible_j_s_o_n_encoder_0.default('test_value')
    assert value == 'test_value'
    value = ansible_j_s_o_n_encoder_0.default(datetime.datetime(1986, 11, 11, 0, 0))
    assert value == '1986-11-11T00:00:00'
    value = ansible_j_s_o_n_encoder_0.default(datetime.date(1986, 11, 11))
    assert value == '1986-11-11'
    value = ansible_j_s_o_n_encoder_0.default({'test_key': 'test_value'})

# Generated at 2022-06-24 20:28:27.840280
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = datetime.datetime.now()
    ansible_j_s_o_n_encoder_1.default(o)


# Generated at 2022-06-24 20:28:33.242919
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder = AnsibleJSONEncoder()
    o = {}

    try:
        output = ansible_json_encoder.default(o)
    except Exception as exception:
        return False

    assert output


# Generated at 2022-06-24 20:28:41.311710
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    my_unsafe = AnsibleUnsafeText('This is a test')

# Generated at 2022-06-24 20:28:50.324429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_json_encoder_unsafe_preprocess = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    ansible_json_encoder_unsafe_preprocess_vault_to_text = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    ansible_unsafe = '$ANSIBLE_VAULT;1.1\napiVersion: ansible.com/v1alpha1\nkind: Vault\nmetadata:\n  name: test_vault_file\ntype: string\nversion: 0.1\nstring: This is a test vault string\n'

# Generated at 2022-06-24 20:28:54.549796
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o = None
    # No exception should be raised.
    ansible_j_s_o_n_encoder_1.default(o)


# Generated at 2022-06-24 20:29:06.631874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'Test string'
    value = ansible_j_s_o_n_encoder_0.default(o)
    assert value == 'Test string'


# Generated at 2022-06-24 20:29:12.761914
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    for i in range(10):
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

        ansible_j_s_o_n_encoder_0.default((1,2,3))

        assert(ansible_j_s_o_n_encoder_0 == ansible_j_s_o_n_encoder_1)


# Generated at 2022-06-24 20:29:21.848663
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    default_ansible_unsafe_0 = AnsibleUnsafe('test')
    default_ansible_vault_0 = ansible_vault_encrypt_data('test')
    default_mapping_0 = dict(a=1, b=2)
    default_datetime_0 = datetime.datetime.now()
    # AnsibleUnsafe
    assert AnsibleJSONEncoder().default(default_ansible_unsafe_0) == dict(__ansible_unsafe='test')
    with pytest.raises(TypeError):
        assert AnsibleJSONEncoder(preprocess_unsafe=True).default(default_ansible_unsafe_0) == dict(__ansible_unsafe='test')
    # AnsibleVaultEncryptedData

# Generated at 2022-06-24 20:29:25.514658
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    i_t_e_r_a_b_l_e_0 = ansible_j_s_o_n_encoder_0.default([])


# Generated at 2022-06-24 20:29:29.881562
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default({'a': 'b'}) == {'a': 'b'}


# Generated at 2022-06-24 20:29:31.719110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:33.240646
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert isinstance(AnsibleJSONEncoder().default(None), None), "This method has not been implemented yet."


# Generated at 2022-06-24 20:29:36.390048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    with pytest.raises(TypeError) as excinfo:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        ansible_j_s_o_n_encoder_0.default(None)
    assert 'is not JSON serializable' in str(excinfo.value)


# Generated at 2022-06-24 20:29:37.877661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_data = AnsibleJSONEncoder()
    assert isinstance(json_data.default('1'), str)



# Generated at 2022-06-24 20:29:47.298792
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    assert ansible_json_encoder_0.default(Mapping()) == {}
    assert ansible_json_encoder_0.default(datetime.date(2019, 11, 26)) == '2019-11-26'
    assert ansible_json_encoder_0.default(datetime.datetime(2019, 11, 26, 16, 33, 53, 848388)) == '2019-11-26T16:33:53.848388'
    assert ansible_json_encoder_0.default(to_text(u'\u2019', nonstring='passthru')) == '\u2019'

# Generated at 2022-06-24 20:30:10.274401
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
        ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
        assert True == ansible_j_s_o_n_encoder_1.default('some_value')


# Generated at 2022-06-24 20:30:19.664382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Test with a str type
    result_0 = ansible_j_s_o_n_encoder_0.default("abc")
    assert result_0 == "abc"

    # Test with an int type
    result_1 = ansible_j_s_o_n_encoder_0.default(1)
    assert result_1 == 1

    # Test with a bool type
    result_2 = ansible_j_s_o_n_encoder_0.default(True)
    assert result_2 == True


# Generated at 2022-06-24 20:30:24.323134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Call AnsibleJSONEncoder.default with the parameters:
    #
    #   o = None
    #
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder.default("None") == "None"



# Generated at 2022-06-24 20:30:28.379765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # value_0 = ansible_j_s_o_n_encoder_0.default(o=o_0)
    pass


# Generated at 2022-06-24 20:30:39.701120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    assert hasattr(ansible_j_s_o_n_encoder, 'default')
    assert callable(ansible_j_s_o_n_encoder.default)

    # Test using parameter 'o'
    assert ansible_j_s_o_n_encoder.default(ansible_vault_object_0) == ansible_vault_dict_0
    assert ansible_j_s_o_n_encoder.default(ansible_unsafe_object_0) == ansible_unsafe_dict_0
    assert ansible_j_s_o_n_encoder.default(ansible_hostvars_object_0) == ansible_hostvars_dict_0
    assert ansible

# Generated at 2022-06-24 20:30:42.998090
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    with pytest.raises(TypeError):
        ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)


# Generated at 2022-06-24 20:30:46.830499
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_json_encoder_0.default(1)
    str_1 = ansible_json_encoder_0.default(str)

    assert str_0 == 1
    assert str_1 == '<class \'str\'>'


# Generated at 2022-06-24 20:30:47.337740
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  pass

# Generated at 2022-06-24 20:30:56.448651
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default('test')
    ansible_unsafe_1 = ansible_j_s_o_n_encoder_0.default({'foo': 'test'})
    ansible_unsafe_2 = ansible_j_s_o_n_encoder_0.default({})
    ansible_unsafe_3 = ansible_j_s_o_n_encoder_0.default((1, 2, 3))
    ansible_unsafe_4 = ansible_j_s_o_n_encoder_0.default(datetime.datetime.now())
    ansible_unsafe_5 = ansible

# Generated at 2022-06-24 20:31:05.993063
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_host_vars = {'first_var': {'second_var': {'third_var': 'foo'}}}
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    ansible_j_s_o_n_encoder_0.default(1)
    ansible_j_s_o_n_encoder_0.default('abc')
    ansible_j_s_o_n_encoder_0.default(b'def')
    ansible_j_s_o_n_encoder_0.default(test_host_vars)

# Generated at 2022-06-24 20:31:42.944589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default = AnsibleJSONEncoder.default(None, None)


# Generated at 2022-06-24 20:31:45.589911
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:31:49.804808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    o = 'aa'
    ret_value = ansible_j_s_o_n_encoder_1.default(o)

    assert(ret_value == 'aa')


# Generated at 2022-06-24 20:31:54.684168
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_vault_0 = ansible_j_s_o_n_encoder_0.default({'inputs_file': '/Users/gaunthier/Projects/ansible/awx/projects/tower_install/inputs.yml'})


# Generated at 2022-06-24 20:32:02.320411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_json_val = {'__ansible_unsafe': "}b@s=?T~`34P`_zp-)'}}Dn@H9X&'!^[aM"}
    ansible_vault_json_val = {'__ansible_vault': "9c17f9f8b16d12aeab50185f4e2aeb58d6f20b4245e9a"}
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    vault_object_0 = ansible_j_s_o_n_encoder_1.default(to_text(u"pass2", errors='surrogate_or_strict'))

# Generated at 2022-06-24 20:32:12.925147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = object()
    ansible_u_n_s_a_f_e_0.__UNSAFE__ = False
    ansible_u_n_s_a_f_e_0.__ENCRYPTED__ = False
    dict_0 = dict()
    dict_0['ansible_u_n_s_a_f_e_0'] = ansible_u_n_s_a_f_e_0
    ansible_v_a_u_l_t_0 = object()
    ansible_v_a_u_l_t_0.__UNSAFE__ = False
    ansible_v_a_u

# Generated at 2022-06-24 20:32:20.964414
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(object).default(AnsibleJSONEncoder(object)) == NotImplemented

    # test case for value __ansible_unsafe
    assert AnsibleJSONEncoder(object).default(AnsibleJSONEncoder(object)) == NotImplemented

    # test case for value __ansible_vault
    assert AnsibleJSONEncoder(object).default(AnsibleJSONEncoder(object)) == NotImplemented

    # test case for value __ansible_vault
    assert AnsibleJSONEncoder(object).default(AnsibleJSONEncoder(object)) == NotImplemented

    # test case for value __ansible_vault
    assert AnsibleJSONEncoder(object).default(AnsibleJSONEncoder(object)) == NotImplemented


# Generated at 2022-06-24 20:32:23.844188
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = datetime.date(1, 1, 1)
    answer = ansible_j_s_o_n_encoder_0.default(datetime.date(1, 1, 1))
    assert answer == o.isoformat()


# Generated at 2022-06-24 20:32:24.539107
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:32:34.086719
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_1 = AnsibleUnsafe('ind', 'safe', False)
    assert ansible_j_s_o_n_encoder_0.default(ansible_unsafe_1) == {'__ansible_unsafe': 'ind'}, 'Return value mismatch'
    assert ansible_j_s_o_n_encoder_0.default(AnsibleUnsafeBytes('ind')) == {'__ansible_unsafe': 'ind'}, 'Return value mismatch'
    ansible_unsafe_2 = AnsibleUnsafe('ind', 'safe', True)

# Generated at 2022-06-24 20:33:48.511480
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    o_0 = {"test": "case"}
    ansible_j_s_o_n_encoder_1.default(o_0)
    o_0 = datetime.datetime(2020, 1, 1, 0, 0, 0, 0)
    ansible_j_s_o_n_encoder_1.default(o_0)


# Generated at 2022-06-24 20:33:54.559122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_encoder_0.default('str')
    assert ansible_j_s_o_n_encoder_0.default('str', 'str') is None
    assert ansible_j_s_o_n_encoder_0.default(['str']) == ['str']
    assert ansible_j_s_o_n_encoder_0.default(['str'], []) == ['str']
    assert ansible_j_s_o_n_encoder_0.default({'str': 'str'}) == {'str': 'str'}
    assert ansible_j_s_o_n_

# Generated at 2022-06-24 20:33:57.741062
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default
    assert AnsibleJSONEncoder(vault_to_text=True).default


# Generated at 2022-06-24 20:34:02.985518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(None) == None


# Generated at 2022-06-24 20:34:05.819854
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    try:
        assert ansible_j_s_o_n_encoder_0.default({})
    except SystemExit:
        pass

# Generated at 2022-06-24 20:34:07.249495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:34:10.882365
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:34:17.883934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_2 = 'AnsibleUnsafe'
    ansible_unsafe_1 = 'AnsibleUnsafe'
    o = AnsibleUnsafe(ansible_unsafe_1)
    ansible_unsafe_0 = 'AnsibleUnsafe'
    o = AnsibleUnsafe(ansible_unsafe_0)
    assert ansible_j_s_o_n_encoder_0.default(o) == {'__ansible_unsafe': ansible_unsafe_0}
    n = 0
    o = {'ansible_unsafe': ('%s' % n)}
    assert ansible_j_s_o_n_encoder_0.default(o) == o


# Generated at 2022-06-24 20:34:23.734618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('\u2714', False, True)
    ansible_j_s_o_n_encoder_0._preprocess_unsafe = True
    ansible_j_s_o_n_encoder_0._vault_to_text = True
    # Test for default of method default of class AnsibleJSONEncoder with arguments [self, o = ansible_u_n_s_a_f_e_0]
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == '\u2714'


# Generated at 2022-06-24 20:34:25.466152
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    return ansible_j_s_o_n_encoder_0.default(o='')