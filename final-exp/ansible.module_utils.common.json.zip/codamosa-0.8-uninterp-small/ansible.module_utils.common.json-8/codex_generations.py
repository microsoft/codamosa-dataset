

# Generated at 2022-06-24 20:25:17.886894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # if _is_unsafe(value):
    #     value = {'__ansible_unsafe': to_text(value, errors='surrogate_or_strict', nonstring='strict')}
    # elif is_sequence(value):
    #     value = [_preprocess_unsafe_encode(v) for v in value]
    # elif isinstance(value, Mapping):
    #     value = dict((k, _preprocess_unsafe_encode(v)) for k, v in value.items())
    #
    # return value

    assert False # TODO: implement your test here


# Generated at 2022-06-24 20:25:21.119859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = 2
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    str_0 = 'test_value'
    input_0 = ansible_j_s_o_n_encoder_0.default(str_0)
    assert str_0 == input_0

# Generated at 2022-06-24 20:25:23.065654
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()


# Generated at 2022-06-24 20:25:23.717415
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:25:24.804507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:25:28.765935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value = {'unsafe_text': 'abc', 'safe_text': 'abc'}
    o = value['unsafe_text']
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:25:31.805952
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = test_case_0()
    set_1 = None
    set_0.default(set_1)


# Generated at 2022-06-24 20:25:35.488715
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialize input value
    o = None

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Execute function
    output = ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:25:39.174446
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    arg_0 = AnsibleUnsafe('string')
    ansible_j_s_o_n_encoder_0.default(arg_0)


# Generated at 2022-06-24 20:25:42.310643
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    o_0 = 'wpRiC'
    var_0 = ansible_j_s_o_n_encoder_0.default(o_0)
    assert var_0 == 'wpRiC'


# Generated at 2022-06-24 20:25:50.210093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    assert ansible_j_s_o_n_encoder_0.default(set_0) == set_0


# Generated at 2022-06-24 20:25:50.932671
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:25:58.462354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    digits = 14
    dict_0 = dict(a=1, b=2, c=3)

    # Test other types
    output = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert (output == dict_0)

    output = ansible_j_s_o_n_encoder_0.default(datetime.datetime.utcnow())
    assert (isinstance(output, str))

    output = ansible_j_s_o_n_encoder_0.default(datetime.date.today())
    assert (isinstance(output, str))

    # Test json.decoder.JSONDecoder
    output

# Generated at 2022-06-24 20:25:59.906616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # N/A
    pass

# main
if __name__ == '__main__':
    test_case_0()
    # test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:26:08.780700
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:26:12.475369
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Message list is not a sequence
    m = ['__ansible_vault']
    # Variable e is a AnsibleJSONEncoder object
    e = AnsibleJSONEncoder()
    # Convert the message to JSON String
    # with AnsibleJSONEncoder as default encoder
    json.dumps(m, cls=e)


# Generated at 2022-06-24 20:26:16.446696
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = False
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    o_0 = {}
    ansible_j_s_o_n_encoder_0.default(o_0)

# Generated at 2022-06-24 20:26:23.617134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = True
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    json_str_0 = ansible_j_s_o_n_encoder_0.encode({})


# Generated at 2022-06-24 20:26:27.013859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    ansible_j_s_o_n_encoder_0.default(set_0)


# Generated at 2022-06-24 20:26:28.611689
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert default(self, o) == default(self, o)


# Generated at 2022-06-24 20:26:34.239101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    int_0 = 0
    ansible_j_s_o_n_encoder_0.default(int_0)


# Generated at 2022-06-24 20:26:40.386238
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = 'AnsibleUnsafe'
    ansible_unsafe_0 = obj_0 = ansible_j_s_o_n_encoder_0.default(set_1)
    assert isinstance(obj_0, dict)
    assert obj_0 == {'__ansible_unsafe': 'AnsibleUnsafe'}


# Generated at 2022-06-24 20:26:43.435204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    default_args_0 = {'o': None}
    default_r_0 = AnsibleJSONEncoder.default(**default_args_0)


# Generated at 2022-06-24 20:26:47.056122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    o = None
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:26:51.045170
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    set_1 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)

    ansible_j_s_o_n_encoder_0.default(set_1)


# Generated at 2022-06-24 20:27:00.912652
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:27:09.193620
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = None
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_1)
    # Call method default of class AnsibleJSONEncoder with arguments set_0, ansible_j_s_o_n_encoder_0
    ansible_j_s_o_n_encoder_1.default(set_0)
    # Call method default of class AnsibleJSONEncoder with arguments set_1, ansible_j_s_o_n_encoder_1
    ansible_j_s_o_n_encoder_1.default(set_1)


# Generated at 2022-06-24 20:27:10.854436
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_1 = None
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_1)


# Generated at 2022-06-24 20:27:11.962276
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True == False


# Generated at 2022-06-24 20:27:15.125135
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder(False, True)
    test_obj = {}
    assert obj.default(test_obj) == test_obj


# Generated at 2022-06-24 20:27:20.046545
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:27:23.241310
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = AnsibleJSONEncoder()
    set_1 = AnsibleJSONEncoder()

    # assert call to default with parameter o equals my_return_value
    assert set_0.default(set_1) == None



# Generated at 2022-06-24 20:27:29.484496
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    one_0 = 1
    assert ansible_j_s_o_n_encoder_0.default(one_0) is not None


# Generated at 2022-06-24 20:27:32.995443
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default(ansible_j_s_o_n_encoder_0, None) == {}


# Generated at 2022-06-24 20:27:33.781775
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert False


# Generated at 2022-06-24 20:27:37.355346
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    dict_12 = dict()
    dict_12[set_0] = None
    ansible_j_s_o_n_encoder_0.default(dict_12)


# Generated at 2022-06-24 20:27:42.849748
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print('Testing default...')
    ansible_j_s_0 = AnsibleJSONEncoder(False)
    ansible_j_s_0_default_retval_0 = ansible_j_s_0.default(True)
    print('ansible_j_s_0.default(True) returned %s' % ansible_j_s_0_default_retval_0)


# Generated at 2022-06-24 20:27:51.082223
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = None
    dict_0 = dict()
    dict_0['__ENCRYPTED__'] = True
    dict_0['__ansible_vault'] = 'adfasdf'
    result_0 = ansible_j_s_o_n_encoder_0.default(dict_0)
    assert result_0['__ansible_vault'] == 'adfasdf'
    assert result_0['__ENCRYPTED__'] == True
    result_1 = ansible_j_s_o_n_encoder_0.default(set_1)
    assert result_1 == None


# Generated at 2022-06-24 20:27:51.873447
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 1 == 1


# Generated at 2022-06-24 20:27:55.866623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"test_key": "test_val"}

    # TODO: An error was raised in this call to default of AnsibleJSONEncoder.
    #        Output expected: {"test_key": "test_val"}
    #        Output received: None
    assert ansible_j_s_o_n_encoder_0.default(o) is None


# Generated at 2022-06-24 20:28:10.483423
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_1 = None
    set_2 = None
    set_3 = 'aws_secret_key'
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_1)
    assert ansible_j_s_o_n_encoder_1.default(set_2) is set_2
    assert ansible_j_s_o_n_encoder_1.default(set_3) is set_3


# Generated at 2022-06-24 20:28:15.413224
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    arg_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(False)
    answer_0 = ansible_j_s_o_n_encoder_0.default(arg_0)

    assert (answer_0 == None)


# Generated at 2022-06-24 20:28:19.156638
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    blob_0 = ansible_j_s_o_n_encoder_0.default(set_0)


# Generated at 2022-06-24 20:28:21.368631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:28:25.770057
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    o_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    assert ansible_j_s_o_n_encoder_0.default(o_0) == None


# Generated at 2022-06-24 20:28:36.249127
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_0 = ansible_j_s_o_n_encoder_0.default(1)
    str_1 = ansible_j_s_o_n_encoder_0.default(1.1)
    str_2 = ansible_j_s_o_n_encoder_0.default('a')
    str_3 = ansible_j_s_o_n_encoder_0.default(True)
    list_0 = ansible_j_s_o_n_encoder_0.default([1, 2])
    dict_0 = ansible_j_s_o_n_encoder_0.default({'a': 1})
    str_4 = ansible_j_s_

# Generated at 2022-06-24 20:28:42.075721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = True
    set_1 = False
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_1, set_0)


# Generated at 2022-06-24 20:28:46.615487
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_0 = ansible_j_s_o_n_encoder_0.default(set_0)


# Generated at 2022-06-24 20:28:47.907867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_AnsibleJSONEncoder_default_0()


# Generated at 2022-06-24 20:28:49.218990
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert 0 == AnsibleJSONEncoder().default(0)


# Generated at 2022-06-24 20:29:06.173038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    m_0 = Mapping()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(m_0)


# Generated at 2022-06-24 20:29:07.852798
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)


# Generated at 2022-06-24 20:29:15.258973
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    value = json.dumps(ansible_j_s_o_n_encoder_0)
    # value: '{"__ansible_vault": "_ciphertext", "__ansible_unsafe": "value"}'
    value = json.dumps(ansible_j_s_o_n_encoder_0, default=lambda x: x.__dict__)
    # value: '{"__ansible_vault": "_ciphertext", "__ansible_unsafe": "value"}'



# Generated at 2022-06-24 20:29:23.695080
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)

    class AnsibleModule_0():
        def __init__(self, set_0):
            self.set_0 = set_0
            self.CONSTANT_0 = ""
            self.CONSTANT_1 = None
            self.CONSTANT_2 = None
            self.CONSTANT_3 = None
            self.CONSTANT_4 = 4
            self.CONSTANT_5 = None
            self.CONSTANT_6 = None
        def get_bin_path(self, set_0, set_1, set_2):
            self.set_0 = set_0
            self.set_1 = set_1
            self.set_2 = set_

# Generated at 2022-06-24 20:29:35.109793
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import vault
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.six import ensure_str

    v = VaultLib([])
    ctext = v.encrypt(b'my secret')
    encrypted = vault.VaultSecret(ctext)

    # This is a VaultSecret object and should return a dict that contains the secret
    # NOTE: the vault_to_text option is not used in this test
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(False, False)
    ansible_j_s_o_n_encoder_0_default_0 = ansible_j_s_o_n_encoder_0.default(encrypted)
   

# Generated at 2022-06-24 20:29:39.433800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    o_0 = None
    assert ansible_j_s_o_n_encoder_0.default(o_0) is None


# Generated at 2022-06-24 20:29:40.828257
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default() == None


# Generated at 2022-06-24 20:29:49.463802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = object()
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_1)
    set_2 = object()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder(set_2)
    # Verify that the set_0 is the correct value
    assert ansible_j_s_o_n_encoder_0._preprocess_unsafe == False
    # Verify that the set_1 is the correct value
    assert ansible_j_s_o_n_encoder_1._preprocess_unsafe == True
    # Verify that the set_2 is the correct value
   

# Generated at 2022-06-24 20:29:51.946967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    ansible_j_s_o_n_encoder_0.default(set_0)


# Generated at 2022-06-24 20:29:55.719915
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    str_0 = "ansible_shell_executable"
    assert ansible_j_s_o_n_encoder_0.default(str_0) == "ansible_shell_executable"

# Generated at 2022-06-24 20:30:34.803865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    map_0 = {
        'seq_0': [
            True,
            False
        ],
        'datetime_0': datetime.datetime(2018, 1, 17),
        'seq_2': [
            True,
            False
        ],
        'map_1': {
            'seq_0': [
                True,
                False
            ],
            'seq_1': [
                True,
                False
            ],
            'seq_2': [
                True,
                False
            ]
        },
        'seq_1': [
            True,
            False
        ]
    }
    output_dict_0 = {}
    datetime_0 = None
    bool_0 = None
    seq_0 = []
    ansible_j_s_o_n_encoder_0 = Ansible

# Generated at 2022-06-24 20:30:42.025061
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = Mapping
    set_1 = Mapping
    set_2 = datetime.date
    set_3 = datetime.datetime
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    ansible_j_s_o_n_encoder_0.default(set_1)
    ansible_j_s_o_n_encoder_0.default(set_2)
    ansible_j_s_o_n_encoder_0.default(set_3)



# Generated at 2022-06-24 20:30:48.440801
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print('## Unit test for method default of class AnsibleJSONEncoder')
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    ansible_host_vars_2 = {'ansible_env': {'http_proxy': 'http://192.168.73.121:3128', 'https_proxy': 'https://192.168.73.121:3128'}, 'ansible_user': 'root', 'ansible_ssh_common_args': '-o StrictHostKeyChecking=no'}
    ansible_j_s_o_n_encoder_0.default(ansible_host_vars_2)


# Generated at 2022-06-24 20:30:51.516055
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = AnsibleJSONEncoder(False)
    ansible_j_s_o_n_encoder_0 = set_0.default(int)

# Generated at 2022-06-24 20:30:55.717554
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_1 = None
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_1)
    obj_0 = b''
    var_0 = ansible_j_s_o_n_encoder_1.default(obj_0)


# Generated at 2022-06-24 20:30:58.494434
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # creation of object
    # object creation fails as it is abstract class
    # ansible_json_enc_obj = AnsibleJSONEncoder()
    pass


# Generated at 2022-06-24 20:31:07.136753
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class AnsibleUnsafe(object):
        def __init__(self, value):
            self.value = to_text(value, errors='surrogate_or_strict', nonstring='strict')
            self.__UNSAFE__ = True

        def __str__(self):
            return self.value

    class AnsibleUnsafeVault(object):
        def __init__(self, ciphertext):
            self._ciphertext = to_text(ciphertext, errors='surrogate_or_strict', nonstring='strict')
            self.__ENCRYPTED__ = True

        def __str__(self):
            return self._ciphertext

    vault_password_0 = "pwd"

# Generated at 2022-06-24 20:31:08.292471
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:31:12.634757
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    ansible_vault_0 = ansible_j_s_o_n_encoder_0.default('9a8e0db3cd3f70a7d20e2815e1f6cef4')
    assert(ansible_vault_0 == ansible_vault_0)


# Generated at 2022-06-24 20:31:14.948906
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)


# Generated at 2022-06-24 20:32:17.902514
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = AnsibleJSONEncoder(False)

# Generated at 2022-06-24 20:32:23.114020
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_0 = {"args": [True]}
    set_0 = True
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    result_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)


#
# Run unit tests.
#

if __name__ == '__main__':

    test_case_0()
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:32:27.135946
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = [1]
    expected = "[1]"
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    actual = ansible_j_s_o_n_encoder_0.encode(data)
    assert actual == expected


# Generated at 2022-06-24 20:32:31.840570
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default('None') == 'None'
    assert AnsibleJSONEncoder().default('None') == 'None'
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default('None') == 'None'
    assert AnsibleJSONEncoder().default({}) == {}


# Generated at 2022-06-24 20:32:38.930241
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    exception_0 = False
    try:
        set_0 = False
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
        variable_0 = ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)
        variable_1 = ansible_j_s_o_n_encoder_0.default(set_0)
        variable_2 = ansible_j_s_o_n_encoder_0.default(ansible_j_s_o_n_encoder_0)
    except Exception as e:
        exception_0 = True
        assert False

    if not exception_0:
        assert False


# Generated at 2022-06-24 20:32:40.166874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('a') == 'a'


# Generated at 2022-06-24 20:32:44.793905
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)

    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder(set_0)
    ansible_j_s_o_n_encoder_1.default('abcd')


# Generated at 2022-06-24 20:32:47.357104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # assert
    # ansible_j_s_o_n_encoder_0.default(None)
    pass


# Generated at 2022-06-24 20:32:49.907710
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = {}
    ansible_j_s_o_n_encoder_0.default(set_1)


# Generated at 2022-06-24 20:32:54.873852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    set_1 = datetime.date(2018, 1, 20)
    assert ansible_j_s_o_n_encoder_0.default(set_1) == "2018-01-20"
    set_2 = datetime.datetime(2018, 1, 20, 20, 25)
    assert ansible_j_s_o_n_encoder_0.default(set_2) == "2018-01-20T20:25:00"


# Generated at 2022-06-24 20:34:58.109800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initialize the class
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    class TestClass:
        pass

    test_class_0 = TestClass()

    assert ansible_j_s_o_n_encoder_0.default(test_class_0) == {"__module__": "__main__", "__doc__": None}

    class TestClass:
        __ENCRYPTED__ = True

    test_class_0 = TestClass()

    assert ansible_j_s_o_n_encoder_0.default(test_class_0) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}

    class TestClass:
        __UNSAFE__ = True

    test_class_0

# Generated at 2022-06-24 20:35:03.922182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    set_0 = None
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(set_0)
    u_a_t_0 = AnsibleUnsafe()
    assert ansible_j_s_o_n_encoder_0.default(u_a_t_0) == {'__ansible_unsafe': u''}
    # Test for other error cases


# Generated at 2022-06-24 20:35:06.758416
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Set up test data
    o = None

    # Invoke method
    result = AnsibleJSONEncoder.default(o)

    # Check result
    assert result is None

