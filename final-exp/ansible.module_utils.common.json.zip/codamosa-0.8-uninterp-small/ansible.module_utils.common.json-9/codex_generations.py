

# Generated at 2022-06-24 20:25:22.828997
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_text_0 = ansible_j_s_o_n_encoder_0.default(b'V\x97aEd\x98\xbf\x95c\xb0')
    bytes_0 = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'



# Generated at 2022-06-24 20:25:32.584353
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    m_o_0_0 = {'a': 'b'}
    s_0_0 = 'a'
    s_0_1 = 'V'
    l_0_0 = [s_0_0, s_0_1]
    bytes_0 = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'
    d_0_0 = datetime.date(2000, 1, 1)
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    d_0_1 = datetime.datetime(2000, 1, 1)
    ansible_j_s_o_

# Generated at 2022-06-24 20:25:36.703267
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    if True:  # Just to have a conditional breakpoint.
        try:
            ansible_j_s_o_n_encoder_0.default(1)
        except:
            pass


# Generated at 2022-06-24 20:25:44.148351
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_s_s_h_result_0 = AnsibleSSHResult()
    ansible_s_s_h_result_0.stderr = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    byte_dict_0 = ansible_j_s_o_n_encoder_0.default(ansible_s_s_h_result_0)
    assert byte_dict_0 == b'{"stderr": "\\u91\\u82\\u82aj\\xb4V\\x97aEd\\x98\\xbf\\x95c\\xb0"}'

# Generated at 2022-06-24 20:25:50.716924
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    o = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'
    expected = '{\'__ansible_unsafe\': u\'\\x91\\xa2\\xe2aj\\xb4V\\x97aEd\\x98\\xbf\\x95c\\xb0\'}'
    actual = ansible_j_s_o_n_encoder_0.default(o)
    assert actual == expected


# Generated at 2022-06-24 20:25:53.179856
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    bytes_0 = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'


# Generated at 2022-06-24 20:26:00.314606
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text = True

# Generated at 2022-06-24 20:26:06.967943
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe(bytes_0)
    assert ansible_u_n_s_a_f_e_0.__ENCRYPTED__ is False
    assert ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_0) == {'__ansible_unsafe': bytes_0}


# Generated at 2022-06-24 20:26:09.177579
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    bytes_1 = b'\x91\xa2\xe2aj\xb4V\x97aEd\x98\xbf\x95c\xb0'
    output_1 = ansible_j_s_o_n_encoder_1.default(bytes_1)


# Generated at 2022-06-24 20:26:19.110038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import io

    # Copy stdout and stderr to be able to restore them later
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

    # Create a new stdout and stderr to capture printed output
    new_out = io.StringIO()
    new_err = io.StringIO()
    sys.stdout = new_out
    sys.stderr = new_err

    # Run the method to test, printed output should be captured
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    bytes_0 = b'\xf0\x9f\x98\x8d'
    ansible_j_s_o_n_encoder_0.default(bytes_0)

# Generated at 2022-06-24 20:26:32.195239
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Testing for expected exceptions using mocks
    ansible_j_s_o_n_encoder_0.default(mock_unsafe_0)
    # Testing for expected exceptions using mocks
    ansible_j_s_o_n_encoder_0.default(mock_vault_0)
    # Testing for expected exceptions using mocks
    ansible_j_s_o_n_encoder_0.default(mock_mapping_0)
    # Testing for expected exceptions using mocks
    ansible_j_s_o_n_encoder_0.default(mock_datetime_0)
    # Testing for expected exceptions using mocks
    ansible_j_s_o_n_enc

# Generated at 2022-06-24 20:26:41.855833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    # test with None
    assert ansible_j_s_o_n_encoder.default(None) == None
    # test with a dictionary
    assert ansible_j_s_o_n_encoder.default({}) == {}
    # test with a list
    assert ansible_j_s_o_n_encoder.default([]) == []
    # test with a string
    assert ansible_j_s_o_n_encoder.default("") == ""
    # test with a date
    assert ansible_j_s_o_n_encoder.default(datetime.date(2019, 8, 20)) == "2019-08-20"
    # test with a datetime
    assert ansible_j_s

# Generated at 2022-06-24 20:26:44.729176
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj_0 = AnsibleJSONEncoder()

    assert obj_0.default({'test_test': 'test_test_test'}) == {'test_test': 'test_test_test'}


# Generated at 2022-06-24 20:26:55.080775
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejsonencoder_default_0 = AnsibleJSONEncoder()
    #
    # Test for None
    #
    try:
        ansiblejsonencoder_default_1 = ansiblejsonencoder_default_0.default(None)
    except Exception as e:
        ansiblejsonencoder_default_1 = str(e)
    assert ansiblejsonencoder_default_1 == 'null'

    #
    # Test for True
    #
    try:
        ansiblejsonencoder_default_2 = ansiblejsonencoder_default_0.default(True)
    except Exception as e:
        ansiblejsonencoder_default_2 = str(e)
    assert ansiblejsonencoder_default_2 == 'true'

    #
    # Test for False
    #

# Generated at 2022-06-24 20:26:58.830659
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder.default("FooBar")
    ansible_j_s_o_n_encoder.default("FooBar")


# Generated at 2022-06-24 20:27:07.652033
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = AnsibleUnsafe('test', errors='surrogate_or_strict')
    ansible_u_n_s_a_f_e_1 = AnsibleUnsafeText('test', errors='surrogate_or_strict')
    ansible_u_n_s_a_f_e_2 = AnsibleUnsafeText(None, errors='surrogate_or_strict')
    ansible_u_n_s_a_f_e_3 = AnsibleUnsafeBytes('test', errors='surrogate_or_strict')

# Generated at 2022-06-24 20:27:13.808071
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    j_s_o_n_0 = json.JSONEncoder()
    for arg in [None, False, True]:
        ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
        j_s_o_n_0.default(arg)
        ansible_j_s_o_n_encoder_0.default(arg)

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-24 20:27:17.914178
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    o_0 = ansible_j_s_o_n_encoder_0.default(o)
    assert (o_0 is not None)


# Generated at 2022-06-24 20:27:26.785721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe)
    if ansible_unsafe_0 != {'__ansible_unsafe': 'hello'}:
        raise Exception(
            "Test Case 0 failed: def test_case_0(): ansible_unsafe_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe); ansible_unsafe_0 != {'__ansible_unsafe': 'hello'}"
            )

# Generated at 2022-06-24 20:27:30.056409
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    vault_lib_0 = VaultLib([])
    vault_secret_0 = VaultSecret(vault_lib_0.decrypt(''))
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default(vault_secret_0)

# Unit tests for class AnsibleJSONEncoder

# Generated at 2022-06-24 20:27:38.411984
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    some_object_0 = {}
    test_default_0 = ansible_j_s_o_n_encoder_0.default(some_object_0)
    assert(test_default_0 == {})

# Generated at 2022-06-24 20:27:45.098894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    module = AnsibleModule(
        argument_spec=dict(
            o=dict(type='int')
        )
    )
    o = module.params['o']

    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

    # Call method default with args
    result = ansible_j_s_o_n_encoder_0.default(o)
    
    # AnsibleUndefined is the return type of all methods if they are not defined
    assert(result != AnsibleUndefined)



# Generated at 2022-06-24 20:27:48.107495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert json.JSONEncoder.default == ansible_j_s_o_n_encoder_0.default


# Generated at 2022-06-24 20:27:53.170330
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = 'vault_string'
    assert ansible_j_s_o_n_encoder_0.default(o) == 'vault_string'


# Generated at 2022-06-24 20:27:56.757878
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

    other = 'a'
    ansible_j_s_o_n_encoder_1.default(other)

    other = 'b'
    ansible_j_s_o_n_encoder_1.default(other)



# Generated at 2022-06-24 20:27:58.822482
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    date_0 = datetime.date(2000, 10, 11)
    assert '2000-10-11' == ansible_j_s_o_n_encoder_0.default(date_0)

# Generated at 2022-06-24 20:28:04.596840
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_obj_0 = None
    ansible_j_s_o_n_encoder_0.default(ansible_u_n_s_a_f_e_obj_0)
    ansible_v_a_u_l_t_obj_0 = None
    ansible_j_s_o_n_encoder_0.default(ansible_v_a_u_l_t_obj_0)


# Generated at 2022-06-24 20:28:10.282986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('o')
    ansible_j_s_o_n_encoder_0.default(123)
    ansible_j_s_o_n_encoder_0.default(3.14159)


# Generated at 2022-06-24 20:28:12.264198
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:28:17.623056
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Unit test for method default of class AnsibleJSONEncoder
    '''
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    # TODO: Add unit test here...
    #assert ansible_j_s_o_n_encoder_default_0


# Generated at 2022-06-24 20:28:29.416075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible import constants
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    tempdir1 = tempfile.gettempdir()
    vault_password_file0 = os.path.join(tempdir1, u'ansible-test.vault')
    vault_password_file1 = os.path.join(tempdir1, u'ansible-test.vault')
    with open(vault_password_file1, u'w') as f:
        f.write(u'hello')
    constants.DEFAULT_VAULT_PASSWORD_FILE = vault_password_file0

# Generated at 2022-06-24 20:28:34.464162
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    pass



# Generated at 2022-06-24 20:28:37.848177
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_dict = {'hi': 'hi', 'there': 'there'}
    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()
    result = ansible_j_s_o_n_encoder.default(test_dict)


# Generated at 2022-06-24 20:28:40.065147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True == True

# Generated at 2022-06-24 20:28:43.980315
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = dict()
    ansible_u_n_s_a_f_e_1 = dict()
    ansible_u_n_s_a_f_e_2 = dict()
    ansible_u_n_s_a_f_e_3 = dict()
    ansible_u_n_s_a_f_e_4 = dict()
    ansible_u_n_s_a_f_e_5 = dict()
    ansible_u_n_s_a_f_e_5['__unsafe__'] = True

# Generated at 2022-06-24 20:28:54.745053
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default = AnsibleJSONEncoder()
    
    # creation of object 'ansible_unsafe_0'
    ansible_unsafe_0 = '{}'
    ansible_unsafe_0.__UNSAFE__ = True
    
    # creation of object 'ansible_vault_0'
    ansible_vault_0 = '{}'
    ansible_vault_0._ciphertext = '{}'
    ansible_vault_0.__ENCRYPTED__ = True
    
    # call of method 'default' of class 'AnsibleJSONEncoder'
    try:
        ansible_j_s_o_n_encoder_default.default(ansible_unsafe_0)
    except:
        pass

# Generated at 2022-06-24 20:29:03.054593
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_default_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_3 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_4 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_5 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_6 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_default_

# Generated at 2022-06-24 20:29:06.173881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = dict()
    ansible_j_s_o_n_encoder_2 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_2.default(o)


# Generated at 2022-06-24 20:29:07.365243
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:10.551896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    # BEGIN: Test tesing default
    # END: Test tesing default


# Generated at 2022-06-24 20:29:15.690793
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    str_1 = ansible_j_s_o_n_encoder_0.default(False)


# Generated at 2022-06-24 20:29:17.401040
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:29:20.388565
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    default = lambda self, o: 'default'
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default = default


# Generated at 2022-06-24 20:29:21.239459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-24 20:29:22.142542
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True


# Generated at 2022-06-24 20:29:24.931387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default(None) is not None


# Generated at 2022-06-24 20:29:28.923898
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Testing default method of class AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default({})


# Generated at 2022-06-24 20:29:32.799891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0_instance = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0_instance.default(o) == something_unexpected


# Generated at 2022-06-24 20:29:33.554657
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-24 20:29:37.560187
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    o = 'foo'
    ansible_json_encoder_0.default(o)
    o = {'foo': 'bar'}
    ansible_json_encoder_0.default(o)
    o = 'foo'
    ansible_json_encoder_0.default(o)


# Generated at 2022-06-24 20:29:48.666394
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0_instance = AnsibleJSONEncoder()
    try:
        ansible_j_s_o_n_encoder_0_instance.default('o')
    except AttributeError:
        pass
    else:
        assert False, "Expected AnsibleFailException"



# Generated at 2022-06-24 20:29:57.337510
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_u_n_s_a_f_e_0 = ansible_j_s_o_n_encoder_0.default(__UNSAFE__=True)
    assert ansible_u_n_s_a_f_e_0 == {'__ansible_unsafe': ''}

    ansible_v_a_u_l_t_0 = ansible_j_s_o_n_encoder_0.default(__ENCRYPTED__=True)
    assert ansible_v_a_u_l_t_0 == {'__ansible_vault': ''}

    ansible_collection_0 = ansible_j_s_o_n_encoder_0.default

# Generated at 2022-06-24 20:30:01.822870
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=True)
    defect = 'NC'
    func_0 = ansible_j_s_o_n_encoder_0.default
    result = func_0(defect)
    expected = {'__ansible_unsafe': 'NC'}


# Generated at 2022-06-24 20:30:05.978407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = ""
    r = ansible_j_s_o_n_encoder_0.default(o)
    assert r == o


# Generated at 2022-06-24 20:30:11.085608
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_s_s_h_0 = SSHConnection()
    ansible_path_0 = AnsiblePath()
    ansible_f_s_0 = AnsibleFS()
    # default(o)
    ansible_j_s_o_n_encoder_0.default(ansible_s_s_h_0)
    ansible_j_s_o_n_encoder_0.default(ansible_path_0)
    ansible_j_s_o_n_encoder_0.default(ansible_f_s_0)


# Generated at 2022-06-24 20:30:12.318096
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = Ansi

# Generated at 2022-06-24 20:30:19.175182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
#
# # Unit test for method iterencode of class AnsibleJSONEncoder
# def test_AnsibleJSONEncoder_iterencode():
#     ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
#
#
# # Unit test for method default of class AnsibleJSONEncoder
# def test_AnsibleJSONEncoder_default_0():
#     ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:30:23.122808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {"a": "b"}
    ansible_j_s_o_n_encoder_0.default(o)


# Generated at 2022-06-24 20:30:25.861764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    object_0 = 'This is a string'
    assert ansible_json_encoder_0.default(object_0) == 'This is a string', 'Incorrect output'


# Generated at 2022-06-24 20:30:31.995802
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # global function _is_unsafe()
    _is_unsafe(ansible_j_s_o_n_encoder_0)
    # global function _is_vault()
    _is_vault(ansible_j_s_o_n_encoder_0)
    # global function to_text()
    to_text(ansible_j_s_o_n_encoder_0, errors='surrogate_or_strict', nonstring='strict')
    to_text(ansible_j_s_o_n_encoder_0, errors='surrogate_or_strict', nonstring='strict')

# Generated at 2022-06-24 20:30:42.732294
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder.default(None) == None


# Generated at 2022-06-24 20:30:45.870417
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    vaultobj_0 = ansible_j_s_o_n_encoder_0.default(o)
    assert isinstance(vaultobj_0, vaultobj_0_type)


# Generated at 2022-06-24 20:30:48.526406
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = datetime.date(2019, 1, 1)
    res = ansible_j_s_o_n_encoder_0.default(o)
    assert res == '2019-01-01'

# Generated at 2022-06-24 20:30:51.606455
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)


# Generated at 2022-06-24 20:31:01.761153
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    SECRET = "Vault is an encrypted file"
    DATE_TIME = datetime.datetime(2020, 1, 22)
    DATE = datetime.date(2020, 1, 22)
    UNSAFE = "Happens when Tower or AWS consume this"
    MAP = {'a':'b'}

    ansible_j_s_o_n_encoder = AnsibleJSONEncoder()

    assert ansible_j_s_o_n_encoder.default(SECRET) == {'__ansible_vault': 'VmF1bHQgaXMgYW4gZW5jcnlwdGVkIGZpbGUK'}
    assert ansible_j_s_o_n_encoder.default(DATE_TIME) == '2020-01-22T00:00:00'
   

# Generated at 2022-06-24 20:31:11.301731
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # test with str
    str_0 = 'str_value'
    ansible_j_s_o_n_encoder_0.default(str_0)
    # test with int
    int_0 = 123
    ansible_j_s_o_n_encoder_0.default(int_0)
    # test with dict
    dict_0 = dict()
    ansible_j_s_o_n_encoder_0.default(dict_0)
    # test with list
    list_0 = list()
    ansible_j_s_o_n_encoder_0.default(list_0)
    # test with tuple
    tuple_0 = tuple()
    ansible_j_s

# Generated at 2022-06-24 20:31:18.512336
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    ansible_unsafe_text_0 = AnsibleUnsafeText('ansible unsafe text')
    ansible_j_s_o_n_encoder_0.default(ansible_unsafe_text_0)

# Generated at 2022-06-24 20:31:23.944947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    result_0 = ansible_j_s_o_n_encoder_0.default('str')
    assert(result_0 == 'str')
    result_1 = ansible_j_s_o_n_encoder_0.default(dict(a=1, b=2))
    assert(result_1 == dict(a=1, b=2))
    result_2 = ansible_j_s_o_n_encoder_0.default(dict(a=1, b=2))
    assert(result_2 == dict(a=1, b=2))
    result_3 = ansible_j_s_o_n_encoder_0.default(datetime.date(2019, 6, 22))

# Generated at 2022-06-24 20:31:30.672462
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_unsafe_0 = AnsibleUnsafe('test')
    ansible_unsafe_1 = AnsibleUnsafe('data')
    ansible_vault_0 = AnsibleVaultEncryptedUnicode('test')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode('data')
    default_0 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_0)
    default_1 = ansible_j_s_o_n_encoder_0.default(ansible_unsafe_1)
    default_2 = ansible_j_s_o_n_encoder_0.default(ansible_vault_0)
   

# Generated at 2022-06-24 20:31:32.040764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case_0()

# Generated at 2022-06-24 20:31:53.366787
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:31:57.871453
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_p_a_s_s_w_o_r_d_1 = ansible_j_s_o_n_encoder_0.default(None)
    assert (ansible_p_a_s_s_w_o_r_d_1 == None)



# Generated at 2022-06-24 20:32:04.219913
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # Test with valid inputs.
    # This method is not supposed to have return values.
    ansible_j_s_o_n_encoder_0.default('test_value_0')
    # Test with invalid inputs
    # str is not iterable
    with pytest.raises(TypeError) as excinfo:
        ansible_j_s_o_n_encoder_0.default('test_value_1')
    # Test with valid inputs.
    # This method is not supposed to have return values.
    ansible_j_s_o_n_encoder_0.default('test_value_2')
    # Test with invalid inputs
    # str is not iterable

# Generated at 2022-06-24 20:32:07.905750
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(o=None)


# Generated at 2022-06-24 20:32:11.808840
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    with pytest.raises(NotImplementedError):
        ansible_j_s_o_n_encoder_0.default('o')


# Generated at 2022-06-24 20:32:13.255856
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-24 20:32:15.779133
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder_0 = AnsibleJSONEncoder()
    ansible_json_encoder_0.default(o=object())


# Generated at 2022-06-24 20:32:18.112674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert ansible_j_s_o_n_encoder_0.default('') == ''


# Generated at 2022-06-24 20:32:19.541343
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:32:22.187291
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0._vault_to_text
    ansible_j_s_o_n_encoder_0._preprocess_unsafe


# Generated at 2022-06-24 20:33:03.246968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    object_0 = object()
    object_1 = object_0
    assert object_0 is object_1


# Generated at 2022-06-24 20:33:07.342786
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    assert (ansible_j_s_o_n_encoder_0.default({'__ansible_unsafe': 'hello'}) == {'__ansible_unsafe': 'hello'})

# Generated at 2022-06-24 20:33:13.801354
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # FIXME: Currently provides code coverage for getattr(o, '__ENCRYPTED__', False)
    # and getattr(o, '__UNSAFE__', False)
    test_obj = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0 = test_obj.default(AnsibleUnsafeText('foo'))


# Generated at 2022-06-24 20:33:16.624814
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()

# Generated at 2022-06-24 20:33:20.128182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    value_0 = 'str'
    assert ansible_j_s_o_n_encoder_0.default(value_0) == 'str'


# Generated at 2022-06-24 20:33:21.412445
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()


# Generated at 2022-06-24 20:33:27.820850
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_v_a_u_l_t_1 = AnsibleVaultEncryptedUnicode(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    ansible_v_a_u_l_t_1.__ENCRYPTED__ = True
    ansible_v_a_u_l_t_

# Generated at 2022-06-24 20:33:34.022045
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = {}
    o['__ansible_unsafe'] = to_text('', errors='surrogate_or_strict', nonstring='strict')
    assert ansible_j_s_o_n_encoder_0.default(o) == {'__ansible_unsafe': ''}

# Generated at 2022-06-24 20:33:40.666487
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    o = to_text(u'', errors='surrogate_or_strict')
    assert ansible_j_s_o_n_encoder_0.default(o) == to_text(u'', errors='surrogate_or_strict')


# Generated at 2022-06-24 20:33:45.440606
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_j_s_o_n_encoder_1 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_1.default(1)


# Generated at 2022-06-24 20:35:09.355047
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initializing some test variables
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    ansible_j_s_o_n_encoder_0.default('ansible_j_s_o_n_encoder_0_0')


# Generated at 2022-06-24 20:35:17.062755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # set up for testing defautl method of AnsibleJSONEncoder
    ansible_j_s_o_n_encoder_0 = AnsibleJSONEncoder()
    # testing
    from ansible.parsing.vault import VaultLib
    ansible_vault_0 = VaultLib('password', 1)