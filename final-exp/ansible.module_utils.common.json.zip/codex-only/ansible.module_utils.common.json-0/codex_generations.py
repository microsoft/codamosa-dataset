

# Generated at 2022-06-22 21:30:25.658497
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import six
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import wrap_var

    vault_secret = VaultLib().encrypt('secret')
    unsafe_secret = wrap_var('secret')

    for v in [vault_secret, unsafe_secret]:
        assert json.dumps(v, cls=AnsibleJSONEncoder) == '"secret"'

    assert json.dumps(wrap_var('{"value": "secret"}'), cls=AnsibleJSONEncoder) == '"{\\"value\\": \\"secret\\"}"'

    assert json.dumps({1: wrap_var('secret')}, cls=AnsibleJSONEncoder) == '{"1": "secret"}'

    # type(u'str') == type('str') == six.

# Generated at 2022-06-22 21:30:37.548565
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    # Test preprocess_unsafe
    unsafe_str = AnsibleUnsafe('unsafe is unsafe')
    unsafe_list = ['unsafe', 'is', 'unsafe', AnsibleUnsafe('unsafe is unsafe')]
    unsafe_dict = {'unsafe': 'is', 'unsafe': 'unsafe', 'unsafe': AnsibleUnsafe('unsafe is unsafe')}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    encoded = json.loads(encoder.encode(unsafe_str))
    assert encoded == {'__ansible_unsafe': 'unsafe is unsafe'}
    encoded = json.loads(encoder.encode(unsafe_list))

# Generated at 2022-06-22 21:30:43.607130
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert AnsibleJSONEncoder().default('something') == 'something'
    assert AnsibleJSONEncoder().default(False) is False
    assert AnsibleJSONEncoder().default(True) is True
    assert AnsibleJSONEncoder().default(None) is None

# Generated at 2022-06-22 21:30:54.268602
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()

    # test primitive types
    # check string
    assert encoder.default(u'hello') == 'hello'
    assert encoder.default('hello') == 'hello'
    assert encoder.default(r'hello') == 'hello'
    # check true / false
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    # check int
    assert encoder.default(1) == 1
    assert encoder.default(0) == 0
    assert encoder.default(-1) == -1
    # check float
    assert encoder.default(1.0) == 1.0
    assert encoder.default(0.0) == 0.0
    assert encoder.default(-1.0) == -1.0
    # check None

# Generated at 2022-06-22 21:30:59.661583
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class NotCustom(object):
        def __init__(self, val):
            self.val = val

    aje = AnsibleJSONEncoder()
    result = aje.default(NotCustom("magic"))
    if result != NotCustom("magic"):
        raise AssertionError("AnsibleJSONEncoder.default did not work with a non-custom class")


# Generated at 2022-06-22 21:31:06.006407
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    test case for constructor of class AnsibleJSONEncoder
    """
    encoder=AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert encoder._preprocess_unsafe==True
    assert encoder._vault_to_text==False
    assert encoder._kwargs=={}


# Generated at 2022-06-22 21:31:15.068589
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    def _test_iterencode(value, expected):
        """Test cases for iterencode

        :type value:
        :rtype:
        :type expected:
        :rtype:
        """
        actual = json.dumps(value, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
        assert actual == expected

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafeWithEncrypted(AnsibleUnsafe):
        __ENCRYPTED__ = True

    # Test strings
    _test_iterencode(AnsibleUnsafe('abc'), '"abc"')
    _test_iterencode(AnsibleUnsafe('abc"123\''), '"abc\\"123\'"')

# Generated at 2022-06-22 21:31:25.793122
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.ajson import AnsibleUnsafeText
    from ansible.module_utils.urls import urlparse
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeUrl
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE

    unsafe = AnsibleUnsafeText('test')
    assert not _is_unsafe(unsafe)
    assert not _is_vault(unsafe)
    assert _preprocess_unsafe_encode(unsafe) == {'__ansible_unsafe': u'test'}


# Generated at 2022-06-22 21:31:29.996829
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert None is encoder.default(None)


if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:31:32.686190
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_value = AnsibleJSONEncoder().encode({"test": "Object"})
    assert json_value == '{"test": "Object"}'


# Generated at 2022-06-22 21:31:43.939386
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    vault_password_file = 'test/unit/utils/vault_password'

    def do_test(value, expected):
        ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
        actual = ansible_json_encoder.iterencode(value)
        assert to_text(actual) == expected

    # Test with unsafe value
    unsafe_test = ansible.parsing.vault.AnsibleVaultEncryptedUnicode('test')
    do_test(unsafe_test, '{"__ansible_unsafe": "test"}')

    # Test with vault value
    ansible_vault = ansible.parsing.vault.VaultLib([vault_password_file])
    vaulted_test = ans

# Generated at 2022-06-22 21:31:54.764668
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    import sys

    # Create encrypted data
    cipher_text = b'$ANSIBLE_VAULT;1.2;AES256;default\n35633562326136613763366132336661353561636135646630373766316336663937356437316161310a393366326432366563363936653764653263343464653065373663346464373064383638643635320a3365636465353036643666306432346163616539323532653761326136613365336634616462323639\n'

    # Create Vault object

# Generated at 2022-06-22 21:32:03.788439
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import OrderedDict
    from datetime import datetime

    vault_pass = 'secret'
    vault = VaultLib(vault_pass)
    vaulted_string = vault.encrypt('thesecret')
    vaulted_dict = {'k1': vault.encrypt('v1'), 'k2': vault.encrypt('v2')}
    vaulted_list = [vault.encrypt('v1'), vault.encrypt('v2')]

    # creating vaulted objects with different constructors
    # this is intended to test that the object is detected
    # no matter how it is created
    vaulted_string_object = vaulted_string

# Generated at 2022-06-22 21:32:05.866630
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Initialize and test
    aje = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert aje

# Generated at 2022-06-22 21:32:15.411695
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactCollector
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgr
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.system.platform import Platform
    from ansible.module_utils.facts.system.system import SystemFactCollector
    from ansible.module_utils.facts.system.system import System

# Generated at 2022-06-22 21:32:26.758773
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    import datetime

    ansible_json_encoder = AnsibleJSONEncoder()

    # Test for __ENCRYPTED__
    ciphertext = VaultLib({'password': get_file_vault_secret(None), 'secrets': []}).encrypt(b'123456')
    value = VaultSecret(ciphertext)
    assert ansible_json_encoder.default(value) == {'__ansible_vault': to_text(ciphertext, errors='surrogate_or_strict', nonstring='strict')}


# Generated at 2022-06-22 21:32:28.075535
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aj = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert aj

# Generated at 2022-06-22 21:32:36.997413
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.parsing.vault import VaultLib

    vault_text = "foobar"
    vault_password = "vaultpassword"
    vault_obj = VaultLib(vault_password)

    encrypted_text = u"AnsibleVault encrypted text."
    encrypted_text_bytes = encrypted_text.encode('utf-8')
    encrypted_text_bytes = vault_obj._encrypt(encrypted_text_bytes)
    encrypted_obj = vault_obj.decrypt(encrypted_text_bytes)

    vault_json = {'__ansible_vault': encrypted_text_bytes}

# Generated at 2022-06-22 21:32:43.208883
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test cases for instances of ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode
    tests = [
        dict(
            obj=u'vaulted item',
            exp_json=dict(__ansible_vault='vaulted item'),
        ),
        dict(
            obj='vaulted item',
            exp_json=dict(__ansible_vault='vaulted item'),
        ),
        dict(
            obj=b'vaulted item',
            exp_json=dict(__ansible_vault='vaulted item'),
        ),
    ]

    for i, test in enumerate(tests):
        pytest.logger.debug("Test case %d: %r", i, test)

# Generated at 2022-06-22 21:32:50.841537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultLib
    import datetime
    import crypt

    datestr = "2017-02-24T21:47:02"
    dtdate = datetime.datetime.strptime(datestr, "%Y-%m-%dT%H:%M:%S")
    encoder = AnsibleJSONEncoder()

    unsafe_object = AnsibleUnsafeText(u"unsafe text")
    unsafe_object.__UNSAFE__ = True

# Generated at 2022-06-22 21:33:03.076699
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Ensure that AnsibleJSONEncoder can be created
    # And that the default behavior for __UNSAFE__ and __ENCRYPTED__ is to do nothing
    encoder = AnsibleJSONEncoder()
    # Ensure that string types are not modified for UNSAFE
    unsafe_thing = 'this is unsafe'
    unsafe_thing.__UNSAFE__ = True
    assert(encoder.default(unsafe_thing) == 'this is unsafe')
    # Ensure that dicts are not modified
    dict_thing = dict({'unsafe': 'this is unsafe'})
    dict_thing.__UNSAFE__ = True
    assert(encoder.default(dict_thing) == dict_thing)
    # Ensure that dicts are not modified but (unsafe) strings are

# Generated at 2022-06-22 21:33:14.664326
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o1 = {'a': 1}
    o2 = {'a': 'str'}
    o3 = {'a': u'unicode'}
    o4 = {'a': {'b': 'str'} }
    o5 = {'a': {'b': u'unicode'} }
    o6 = {'a': ['b', 'c', 3] }
    o7 = {'a': ['b', u'unicode', {'c': 'str'}] }
    o8 = {'a': ['b', u'unicode', {'c': u'unicode2'}] }
    o9 = {'a': datetime.date(2016, 8, 2) }

# Generated at 2022-06-22 21:33:16.846128
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    jsn = AnsibleJSONEncoder()
    assert jsn

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:33:26.109242
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # construct an instance with all non-default arguments
    encoder = AnsibleJSONEncoder(False, True, skipkeys=True, ensure_ascii=True, check_circular=True, allow_nan=True,
                                 sort_keys=True, indent=2, separators=("|", ":"), default=None)
    assert encoder.skipkeys == True
    assert encoder.ensure_ascii == True
    assert encoder.check_circular == True
    assert encoder.allow_nan == True
    assert encoder.sort_keys == True
    assert encoder.indent == 2
    assert encoder.separators == ("|", ":")
    assert encoder.default == None

    # construct an instance without any arguments
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:33:37.825689
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    o = {}
    o_unsafe_str = AnsibleUnsafe('abc')
    o['str'] = o_unsafe_str
    o_unsafe_int = AnsibleUnsafe(123)
    o['int'] = o_unsafe_int
    o_unsafe_list = [AnsibleUnsafe('123'), AnsibleUnsafe('abc'), 'def']
    o['list'] = o_unsafe_list
    o_unsafe_dict = {}
    o_unsafe_dict['123'] = AnsibleUnsafe(123)
    o_unsafe_dict['abc'] = AnsibleUnsafe('abc')
    o['dict'] = o_unsafe_dict

# Generated at 2022-06-22 21:33:44.139979
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import Mapping

    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder._vault_to_text = True
    assert ansible_json_encoder is not None
    #Test AnsibleUnsafe
    ansible_unsafe_obj = AnsibleModule.AnsibleUnsafe(u'foo')
    result = ansible_json_encoder.default(ansible_unsafe_obj)
    assert isinstance(result, Mapping)
    result_str = to_bytes(json.dumps(result))
    assert '"__ansible_unsafe": "foo"' in result_str
   

# Generated at 2022-06-22 21:33:54.676633
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.check_circular
    assert ansible_json_encoder.ensure_ascii
    assert not ansible_json_encoder.indent
    assert not ansible_json_encoder.separators
    assert ansible_json_encoder._preprocess_unsafe
    assert not ansible_json_encoder._vault_to_text

    ansible_json_encoder = AnsibleJSONEncoder(indent=4, separators=(',', ': '), preprocess_unsafe=True, vault_to_text=True)
    assert ansible_json_encoder.indent
    assert ansible_json_encoder.separators
    assert ansible_json_encoder._preprocess_unsafe
   

# Generated at 2022-06-22 21:34:05.617612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.module_utils.common.vault import VaultLib
    from ansible.parsing import vault

    assert AnsibleJSONEncoder().default(AnsibleUnsafeText('x')) == {'__ansible_unsafe': 'x'}
    assert AnsibleJSONEncoder().default(AnsibleUnsafeBytes('x')) == {'__ansible_unsafe': 'x'}

    vault_text = to_text(u'x')
    vault_encrypted = VaultLib(password=u'password').encrypt(vault_text)
    vault_obj = vault.VaultSecret(vault_encrypted)

# Generated at 2022-06-22 21:34:12.527240
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Make an instance of AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()
    # There should be no error if we run the encoder
    o = encoder.encode({'test': 'test'})
    # Get the class name of the encoder
    assert encoder.__class__.__name__ == 'AnsibleJSONEncoder'
    # The output object should be a string
    assert isinstance(o, str)
    # The output object should be formatted in JSON structure
    json.loads(o)
    # Another test, it should return a JSON string again
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    o = encoder.encode({'test': 'test'})
    assert isinstance(o, str)
    # The output object

# Generated at 2022-06-22 21:34:21.444402
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe = AnsibleJSONEncoder().encode({'unsafe': to_text('my_secret', errors='surrogate_or_strict', nonstring='strict')})
    vault = AnsibleJSONEncoder().encode({'vault': to_text('my_secret', errors='surrogate_or_strict', nonstring='strict')})
    vault_2 = AnsibleJSONEncoder(True, False).encode({'vault': to_text('my_secret', errors='surrogate_or_strict', nonstring='strict')})

    assert unsafe == '{"unsafe": "my_secret"}'
    assert vault == '{"vault": {"__ansible_vault": "my_secret"}}'
    # NOTE: This is the difference with the method iterencode

# Generated at 2022-06-22 21:34:32.791256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2
    import os

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    vault_password = os.environ.get('VAULT_PASSWORD')
    value = VaultLib(vault_password).encrypt('text')
    encoded_value = encoder.default(value)
    assert (isinstance(encoded_value, unicode) if PY2 else isinstance(encoded_value, str))



# Generated at 2022-06-22 21:34:41.627421
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # This is a empty dictionary
    test_dict = {}

    # This is a dict with a string
    test_dict2 = {'a': 'test1'}

    # This is a dict with string and int
    test_dict3 = {'a': 'test1', 'b': 1}

    # This is a dict with string and dict
    test_dict4 = {'a': 'test1', 'b': {'x': 1, 'y': 2}}

    # This is a dict with string and unsafe object
    test_dict5 = {'a': 'test1', 'b': '{{unsafe}}'}

    # This is a dict with string, int, dict and unsafe object

# Generated at 2022-06-22 21:34:46.708999
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejsonencoder = AnsibleJSONEncoder()
    assert ansiblejsonencoder.default(None) == None
    assert ansiblejsonencoder.default(False) == False
    assert ansiblejsonencoder.default(True) == True
    assert ansiblejsonencoder.default(["foo"]) == ["foo"]


# Generated at 2022-06-22 21:34:57.929683
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_lib = VaultLib()
    vault_value = vault_lib.encrypt(b'hello')
    vault_value.__ENCRYPTED__ = True
    vault_value.__UNSAFE__ = False


# Generated at 2022-06-22 21:35:08.134476
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # test unsafe and vault objects
    assert json.dumps({"unsafe": "{{ variable }}"}, cls=AnsibleJSONEncoder) == \
        '{"unsafe": {"__ansible_unsafe": "{{ variable }}"}}'
    assert json.dumps({"vault": "!vault |\n\n        test"}, cls=AnsibleJSONEncoder) == \
        '{"vault": {"__ansible_vault": "!vault |\\n\\n        test"}}'

    # date object
    date = datetime.datetime(2020, 1, 1, 0, 0, 0, 0)
    assert json.dumps({"date": date}, cls=AnsibleJSONEncoder) == \
        '{"date": "2020-01-01T00:00:00"}'

   

# Generated at 2022-06-22 21:35:11.312143
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        # use vault_to_text as a test
        ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    except:
        print("Failed to instantiate the AnsibleJSONEncoder class.")

# Generated at 2022-06-22 21:35:21.395675
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # It's important to test iterencode because it is harder to test
    # this functionality in the default method
    # Using the following command:
    # python -m json.tool
    # we can test the result of iterencode and see that the result is
    # valid JSON
    # The result is shown without whitespace, but I can't figure out how
    # to remove the whitespace using the default encoder
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    # The preprocess_unsafe flag should convert any unsafe data to
    # a JSON object with a "__ansible_unsafe" key
    obj = AnsibleUnsafeText('hello world')
    enc = AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True)

# Generated at 2022-06-22 21:35:23.867210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = encoder.default(None)
    assert o == None

    o = encoder.default(1)
    assert o == 1

    o = encoder.default('abc')
    assert o == 'abc'

# Generated at 2022-06-22 21:35:33.177515
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.dataloader
    import ansible.parsing.vault
    info = {'key': 'value'}
    info_encrypted = ansible.parsing.vault. VaultLib().encrypt('test', 'value')
    info['key2'] = info_encrypted
    info['key3'] = ansible.parsing.dataloader.DataLoader().load_from_file(__file__)
    info['key3'] = info['key3'] % (info,)
    info['data'] = [1, 2, 3]
    info['data2'] = {'key': 4}
    info['data2']['key1'] = ansible.parsing.dataloader.DataLoader().load_from_file(__file__)

# Generated at 2022-06-22 21:35:38.642800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    ansible_unsafe = AnsibleUnsafe('test')
    ansible_vault = VaultLib('password')
    test_data = {'AnsibleUnsafe': ansible_unsafe, 'AnsibleVault': ansible_vault}

    result = AnsibleJSONEncoder().default('test')
    assert result == 'test'

    result = AnsibleJSONEncoder().default(ansible_unsafe)
    assert result.get('__ansible_unsafe') == 'test'

    result = AnsibleJSONEncoder().default(ansible_vault)
    assert result.get('__ansible_vault')


# Generated at 2022-06-22 21:35:49.591413
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    ansiblelibencoder = AnsibleJSONEncoder()
    test_var1 = 'ansible'
    test_var2 = {'ansible': 'is', 'awesome': True, 'vault': VaultLib('test', 'test')}
    test_var3 = {'ansible': 'is', 'awesome': True, 'unsafe': 'test', 'vault': VaultLib('test', 'test')}
    test_var4 = [1, 2, 3, 4]
    test_var5 = ['ansible', VaultLib('test', 'test')]
    test_var6 = [1, 2, 3, 'ansible', VaultLib('test', 'test')]
    test_var7 = (1, 2, 3)

# Generated at 2022-06-22 21:35:58.780135
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # make sure the default is safe, VaultSecret is an example of an AnsibleUnsafe object
    encoder = AnsibleJSONEncoder()
    assert encoder.iterencode(VaultSecret('1234')) == u'["__ansible_unsafe__VaultSecret__value__"]'

    # make sure the iterencode works correctly with VaultSecret
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.iterencode(VaultSecret('1234')) == u'[{"__ansible_unsafe": "1234"}]'

    # make sure iterencode works with VaultLib

# Generated at 2022-06-22 21:36:06.722238
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import datetime

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert encoder.default({'test': 'default'}) == {'test': 'default'}
    assert encoder.default([0, 1, 2]) == [0, 1, 2]
    assert encoder.default(datetime.datetime(2019, 9, 5, 17, 0, 3, 578767)) == '2019-09-05T17:00:03.578767'

    import ansible.parsing.vault

# Generated at 2022-06-22 21:36:18.684788
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    vault_obj = VaultLib([])

    from ansible.parsing.vault import VaultSecret
    enc_va = vault_obj.encrypt('va')

    from ansible.parsing.vault import VaultPassword
    enc_va_pwd = vault_obj.encrypt(VaultPassword('va_pwd'))

    va = VaultSecret('va', enc_va, vault_obj.vault_version)
    va_pwd = VaultSecret('va_pwd', enc_va_pwd, vault_obj.vault_version)

    class AnswersUnsafe():
        __UNSAFE__ = True
        __ENCRYPTED__ = False
        def __repr__(self):
            return "AnswersUnsafe()"


# Generated at 2022-06-22 21:36:23.238494
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    time = '%Y-%m-%dT%H:%M:%S'
    date_str = '2019-04-11T16:30:00'
    date = datetime.datetime.strptime(date_str, time)
    assert ansible_json_encoder.default(date) == date_str


# Generated at 2022-06-22 21:36:33.597730
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.ansible_galaxy import AnsibleGalaxyEncoder
    from ansible.module_utils.urls import open_url, wrap_var

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # ansible_collections.ansible.builtin.ansible-modules-core.plugins.module_utils.common.text.converters.py:
    #    to_text(b'string', encoding='utf-8', errors='strict')

# Generated at 2022-06-22 21:36:44.096733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Testing AnsibleJSONEncoder.default()"""
    # The following tests are probably redundant with other tests
    # but the purpose of testing this method is to ensure that
    # the following types are still serializable:
    # bool, float, int, None, str, bytes

    c = AnsibleJSONEncoder()
    o = c.default(True)
    assert isinstance(o, bool)
    assert o is True

    o = c.default(False)
    assert isinstance(o, bool)
    assert o is False

    o = c.default(1)
    assert isinstance(o, int)
    assert o == 1

    o = c.default(1.1)
    assert isinstance(o, float)
    assert o == 1.1

    o = c.default(None)

# Generated at 2022-06-22 21:36:45.912720
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json.dumps(dict(foo='bar', baz=None), cls=AnsibleJSONEncoder)



# Generated at 2022-06-22 21:36:54.876286
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    result = '["first","second","third"]'
    assert result == AnsibleJSONEncoder().iterencode(["first", "second", "third"])

    result = '["__ansible_unsafe"]'
    assert result == AnsibleJSONEncoder().iterencode([AnsibleUnsafe("__ansible_unsafe")])

    result = '["first","__ansible_unsafe","third"]'
    assert result == AnsibleJSONEncoder().iterencode(["first", AnsibleUnsafe("__ansible_unsafe"), "third"])

    d = {'__ansible_unsafe': AnsibleUnsafe('__ansible_unsafe'), 'second': 'second'}
    result = '{"__ansible_unsafe":["__ansible_unsafe"],"second":"second"}'
    assert result == AnsibleJSONEncoder

# Generated at 2022-06-22 21:36:58.980703
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True, indent=2)
    assert test_unsafe

    test_vault = AnsibleJSONEncoder(preprocess_unsafe=True, indent=2)
    assert test_vault

    test_unsafe_vault = AnsibleJSONEncoder(preprocess_unsafe=True, indent=2)
    assert test_unsafe_vault

# Generated at 2022-06-22 21:37:09.069858
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafeEncrypted(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class AnsibleEncrypted(str):
        __ENCRYPTED__ = True

    class AnsibleObject(object):
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)

    class AnsibleMapping(Mapping):
        def __init__(self, **kwargs):
            self._mapping = dict(**kwargs)

        def __getitem__(self, key):
            return self._mapping[key]


# Generated at 2022-06-22 21:37:13.810869
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        o = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    except ImportError:
        print('Failed')
    else:
        print('Success')

# This is the standard boilerplate that calls the main() function.
if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:37:24.921916
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib                                                                                                                                  
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe
    vault = VaultLib([])
    secret = vault.encrypt('MySecret')
    password = AnsibleUnsafe('password')
    json_string = json.dumps({
        'secret': secret,
        'password': password
    }, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:37:35.140516
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-22 21:37:42.210411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_case = [
                (datetime.datetime(2017,3,22,4,4,4,4), "2017-03-22T04:04:04.000004"),
                (datetime.date(2017,3,22), "2017-03-22"),
                ([1,2,3], [1,2,3]),
                ({'a':'a'}, {'a':'a'}),
                ]
    for i, o in test_case:
        encoder = AnsibleJSONEncoder()
        assert encoder.default(i) == o


# Generated at 2022-06-22 21:37:51.479833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 21:38:01.520320
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import ansible.module_utils.common.json as json

    if not VaultLib.is_encrypted(b'$ANSIBLE_VAULT;1.1;AES256\nblahblahblah\nblahblahblah\n'):
        raise AssertionError('is_encrypted FAIL')
    if VaultLib.is_encrypted(b'$ANSIBLE_vault;1.1;AES256\nblahblahblah\nblahblahblah\n'):
        raise AssertionError('is_encrypted FAIL')
    if VaultLib.is_encrypted(b'blahblahblah\nblahblahblah\n'):
        raise AssertionError('is_encrypted FAIL')

# Generated at 2022-06-22 21:38:05.004728
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(enc, AnsibleJSONEncoder)


# Generated at 2022-06-22 21:38:16.709122
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.module_utils.six import StringIO

    # prep data
    # note that the ``AnsibleUnsafe`` values are not modified by
    # ``_preprocess_unsafe_encode``
    # since ``_preprocess_unsafe_encode`` looks for the special attribute
    # ``__UNSAFE__``, which is not created when the ``AnsibleUnsaafe`` values
    # are instantiated
    testdata = [
        {'foo': unsafe_proxy.AnsibleUnsafeText('bar')},
        {'foo': [unsafe_proxy.AnsibleUnsafeText('bar')]},
        {'foo': {'bar': unsafe_proxy.AnsibleUnsafeBytes('bar')}},
    ]

    # test

# Generated at 2022-06-22 21:38:24.394672
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(
        preprocess_unsafe=False,
        vault_to_text=False,
        ignore_nan=False,
        separators=(',', ':'),
        sort_keys=True,
        skipkeys=False,
        ensure_ascii=True,
        check_circular=True,
        allow_nan=True,
        indent=None,
        encoding='utf-8',
        default=None,
        cls=None)
    assert encoder

# Generated at 2022-06-22 21:38:34.267490
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import itertools
    # Use json.loads instead of json.JSONDecoder to validate the correctness of iterencode,
    # Because a string is not valid json in Py2 and json.JSONDecoder raises ValueError
    for preprocess_unsafe in (True, False):
        for indention in (None, 4):
            # Parameter ensure_ascii forces iterencode return a generator which yields bytes
            # This case is used for testing __ansible_unsafe, which is a unicode string
            for ensure_ascii in (True, False):
                input_ = b"\xc3\xa4"
                encoder = AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe, prefer='text', ensure_ascii=ensure_ascii)

# Generated at 2022-06-22 21:38:45.226291
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.formatters.format_encrypt import VaultEncrypted

    vault_passwd = 'vault_pwd'
    plain_text = 'plain_text'
    cipher_text = 'cipher_text'
    vault = VaultLib(vault_passwd)
    encrypted_value = vault.encrypt(plain_text)

    # test VaultEncrypted
    obj = vault.get_decrypted_obj(encrypted_value)
    json_obj = AnsibleJSONEncoder().default(obj)
    assert json_obj == {'__ansible_vault': to_text(cipher_text, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-22 21:38:48.449988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('string') == 'string'
    assert encoder.default(1) == 1


# Generated at 2022-06-22 21:38:54.894786
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({'x': 'y'}) == {'x': 'y'}
    assert encoder.default([{'x': 'y'}]) == [{'x': 'y'}]
    assert encoder.default(datetime.datetime(2017, 12, 7, 12, 14, 22, 712047)) == '2017-12-07T12:14:22.712047'

# Generated at 2022-06-22 21:39:01.105806
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    print (dir(AnsibleJSONEncoder))
    print (AnsibleJSONEncoder.__doc__)
    print (AnsibleJSONEncoder.__init__.__doc__)
    # print (AnsibleJSONEncoder.default.__doc__)
    # print (AnsibleJSONEncoder.iterencode.__doc__)


# Generated at 2022-06-22 21:39:12.280968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime

    data1 = datetime.datetime(2005, 12, 30, 15, 59)
    data2 = {u'foo': VaultLib('myvault', None).encrypt('mock_password', None, None)}
    data3 = {u'foo': VaultLib('myvault', None).encrypt('mock_password', None, None), u'bar': datetime.datetime(2005, 12, 30, 15, 59)}
    data4 = {u'foo': datetime.datetime(2005, 12, 30, 15, 59), u'bar': VaultLib('myvault', None).encrypt('mock_password', None, None)}

# Generated at 2022-06-22 21:39:24.039624
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unsafe_text
    import sys
    import io
    import json
    sys.stdout = io.StringIO()
    str1 = to_unsafe_text("\u001b[1;31mThis is a unicode string:\u001b[0m")
    json.dump(dict(a=str1), sys.stdout, cls=AnsibleJSONEncoder, preprocess_unsafe=True, indent=4)
    assert sys.stdout.getvalue() == '{\n    "a": {\n        "__ansible_unsafe": "\\u001b[1;31mThis is a unicode string:\\u001b[0m"\n    }\n}'
    sys.stdout.close()

# Generated at 2022-06-22 21:39:35.530105
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {
        "field1": AnsibleUnsafe("value1"),
        "field2": AnsibleUnsafe("value2"),
        "field3": [AnsibleUnsafe("value3")],
        "field4": {"field5": AnsibleUnsafe("value5")},
        "field6": [
            {"field7": AnsibleUnsafe("value7")}
        ]
    }

# Generated at 2022-06-22 21:39:46.765492
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText

    vault = VaultLib([('default', VaultSecret("$ANSIBLE_VAULT;1.1;AES256"))])
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:39:57.144043
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, is_unsafe_proxy
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import UnsafeText

    dt = datetime.datetime.now()
    date = datetime.date.today()

    def _test_method(data, expected_output):
        assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data)) == expected_output
        assert list(AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(data)) == expected_output

    # test string
    _test_method('abcd', ['"abcd"'])

    # test number
    _test_

# Generated at 2022-06-22 21:40:03.075028
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_data = {'ansible_date': datetime.datetime(2017, 12, 31)}
    json_str = '{"ansible_date": "2017-12-31T00:00:00"}'

    json_str2 = json.dumps({'ansible_date': datetime.datetime(2017, 12, 31)})

    json_encoder = AnsibleJSONEncoder()
    json_str3 = json_encoder.encode(json_data)
    json_encoder.iterencode(json_data)

    assert json_str == json_str2 == json_str3

# Generated at 2022-06-22 21:40:14.072249
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    test_obj = VaultLib({'password': 'stuff'}).encrypt('hunter2')

    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:40:17.284472
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)


# Generated at 2022-06-22 21:40:27.527214
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types

    class Safe(string_types[0]):
        pass

    class Unsafe(string_types[0]):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class Vault(string_types[0]):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class SafeList(list):
        pass

    class UnsafeList(list):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class VaultList(list):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class SafeDict(dict):
        pass

    class UnsafeDict(dict):
        __UNSAFE__ = True
        __ENCRY