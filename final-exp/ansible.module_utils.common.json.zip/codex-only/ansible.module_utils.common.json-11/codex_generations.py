

# Generated at 2022-06-22 21:30:37.835780
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    obj = dict(
        a = dict(
            b = dict(
                c = dict(
                    unsafe = 'asdf',
                )
            )
        )
    )
    obj = json.loads(json.dumps(obj, cls=AnsibleJSONEncoder, preprocess_unsafe=True))
    assert isinstance(obj, dict)
    assert isinstance(obj['a'], dict), "%s" % type(obj['a'])
    assert isinstance(obj['a']['b'], dict), "%s" % type(obj['a']['b'])

# Generated at 2022-06-22 21:30:48.552337
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False, '_preprocess_unsafe is not initialized to False in AnsibleJSONEncoder __init__'
    assert AnsibleJSONEncoder()._vault_to_text == False, '_vault_to_text is not initialized to False in AnsibleJSONEncoder __init__'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe == True, '_preprocess_unsafe is not initialized to True in AnsibleJSONEncoder __init__'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault_to_text == True, '_vault_to_text is not initialized to True in AnsibleJSONEncoder __init__'

# Generated at 2022-06-22 21:30:59.855464
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import ansible.parsing.vault as vault
    from ansible.module_utils.six import PY3

    from ansible.module_utils.common._collections_compat import OrderedDict

    # Create OrderedDict containing nested OrderedDict, lists, AnsibleUnsafe and AnsibleVault
    key1_value = "list_value"
    key2_value = "list_value2"
    key3_value = "unsafe"
    key4_value = "vault"
    key5_value = "vault"
    key6_value = "unsafe"
    key7_value = "vault"


# Generated at 2022-06-22 21:31:11.393341
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    test_value = {"a": 1, "b": "val", "c": [1, 2, 3], "d": datetime.datetime(1999, 12, 31, 23, 59, 59, 999999), "e": { "a": 1}, "f": VaultLib("ansible")}

    test_value["f"]._ciphertext = "dummy"

    # Without vault_to_text
    value = test_value
    json_encoded = AnsibleJSONEncoder(vault_to_text=False).default(value)

# Generated at 2022-06-22 21:31:17.918435
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    data = {"test": "{{ this_is_a_variable }}"}
    data_not_preprocessed = {"test": VaultLib().encrypt("{{ this_is_a_variable }}")}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data) == AnsibleJSONEncoder().iterencode(data_not_preprocessed)

# Generated at 2022-06-22 21:31:27.314430
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Testing method default of class AnsibleJSONEncoder
    # Make an instance of the class
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # Test a dict
    test_dict = {'a': 'b', 'c': 'd'}
    assert encoder.default(test_dict) == test_dict

    # Test a string
    test_string = 'this is a string'
    assert encoder.default(test_string) == test_string

    # Test a list
    test_list = ['this', 'is', 'a', 'list']
    assert encoder.default(test_list) == test_list

    # Test a tuple
    test_tuple = ('this', 'is', 'a', 'tuple')

# Generated at 2022-06-22 21:31:35.151872
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_string = 'Value is encrypted with Ansible Vault.'
    test_class = _create_test_class(test_string)
    test_class.__ENCRYPTED__ = True

    test_object = _create_test_class()
    test_object.test_class = test_class
    test_object.test_string = test_string

    encoded = AnsibleJSONEncoder().default(test_object)

    assert encoded['test_class']['__ansible_vault'] == test_string
    assert encoded['test_string'] == test_string


# Generated at 2022-06-22 21:31:45.944771
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    # check for normal string value
    encoder = AnsibleJSONEncoder()
    assert encoder.default('abc') == 'abc'

    # check for encrypted string value
    vault_password = 'abcd'
    encry_string = AnsibleVaultEncryptedUnicode('dGVzdA', vault_password)

    # check for the case where vault_to_text is set to False
    encoder = AnsibleJSONEncoder(vault_to_text=False)
    assert encoder.default(encry_string) == {'__ansible_vault': 'dGVzdA'}

    # check for the case where vault_to_text is set to True

# Generated at 2022-06-22 21:31:56.845019
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Unit test for method iterencode of class AnsibleJSONEncoder
    """
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])

    # Tests for _preprocess_unsafe_encode
    # Simple string
    o = vault.encrypt(b'Simple string')
    assert _preprocess_unsafe_encode(o) == {'__ansible_vault': o.vault_text}
    o = "Simple string"
    assert _preprocess_unsafe_encode(o) == o
    # Unsafe object
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-22 21:32:04.828203
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    if sys.version_info[0] >= 3:
        from ansible.module_utils.common._collections_compat import MutableMapping
        from ansible.module_utils.common.json_utils import AnsibleUnsafe, AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleVaultEncryptedUnsafeText
    else:
        from ansible.module_utils.common.json_utils import AnsibleUnsafe, AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleVaultEncryptedUnsafeText, MutableMapping

    # Create a dictionary with unsafe text, unsafe bytes and unsafe vault
    unsafe_text = AnsibleUnsafe('{"abc": "def"}')
    unsafe_bytes = AnsibleUnsafe(b'{"abc": "def"}')
    unsafe_vault = AnsibleVaultEncryptedUn

# Generated at 2022-06-22 21:32:14.860989
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultHeader


# Generated at 2022-06-22 21:32:26.292694
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.vars import AnsibleUnsafe
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    import datetime

    vault_password = 'secret'

    v = VaultLib(vault_password)


# Generated at 2022-06-22 21:32:36.189680
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    sequence = ['a', 'b', 'c']
    date = datetime.date(2018, 11, 10)
    datetime_obj = ['2018-11-10T01:02:03+00:00', '2018-11-10T04:05:06+00:00']
    mapping = {'a': 1, 'b': 2, 'c': 3}
    kwargs = {'indent': 2, 'separators': (',', ': ')}

    assert encoder.default(sequence) ==  sequence
    assert encoder.default(date) == '2018-11-10'
    assert encoder.default(datetime_obj) ==  datetime_obj
    assert encoder.default(mapping) == mapping


# Generated at 2022-06-22 21:32:47.156332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # This is just a stub. The original method returns a dict, this one returns a string
    # so it will detect errors. This is useful for testing.
    class AnsibleVault:
        pass

    ansible_vault = AnsibleVault()
    ansible_vault.__ENCRYPTED__ = True

    def try_default(o):
        return AnsibleJSONEncoder(vault_to_text=True).default(o)

    # Simple types, no conversion
    assert try_default(None) == None
    assert try_default(1) == 1
    assert try_default(1.0) == 1.0
    assert try_default("string") == "string"

    # AnsibleVault to string
    try_default(ansible_vault)

    # dict and list

# Generated at 2022-06-22 21:32:55.401059
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # test a hostvars object
    hostvars = {'ansible_facts': {'ansible_date_time': AnsibleUnsafeText('2019-06-24T04:59:37')}}
    encoded_hostvars = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(hostvars)
    assert next(encoded_hostvars) == '{'
    assert next(encoded_hostvars) == '"ansible_facts": {'
    assert next(encoded_hostvars) == '"ansible_date_time": {'
    assert next(encoded_hostvars) == '"__ansible_unsafe": '

# Generated at 2022-06-22 21:33:05.942049
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type
    import json

    import sys
    if sys.version_info.major == 2:
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-22 21:33:13.669199
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.collections import is_sequence

    default_encoder = AnsibleJSONEncoder()

    assert is_sequence(default_encoder.default({}))
    assert is_sequence(default_encoder.default([]))
    assert default_encoder.default({'key': 'value'}) == {'key': 'value'}
    assert default_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert default_encoder.default('string') == 'string'



# Generated at 2022-06-22 21:33:23.119501
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible.parsing.vault as vault

    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.module_utils.six import PY3

    import os
    import io
    import sys

    if PY3:
        from io import StringIO
        from base64 import b64encode

    after_json_text = b'{"a": "abcd", "b": "efgh", "c": {"d": "ijkl"}}'
    before_json_text = u'{"a": "abcd", "b": "efgh", "c": {"d": "ijkl"}}'

    # Test without encrypting
    writer = io.BytesIO()
    encoder = AnsibleJSONEncoder()
    encoder.encode(after_json_text).en

# Generated at 2022-06-22 21:33:29.536104
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    secret = VaultLib().encrypt("my secret")
    string = AnsibleUnsafe("unsafe string")

    data = dict(a=1, b=2, c=secret, d=string)

# Generated at 2022-06-22 21:33:39.518711
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnsafeText
    lst = [
        1,
        'UnsafeString',
        {'d1': {'d2': 'UnsafeString', 'd3': AnsibleVaultEncryptedUnsafeText('VaultString')},
         'd4': (1, AnsibleUnsafe('UnsafeTuple'), AnsibleVaultEncryptedUnsafeText('VaultTuple'))},
        [1, 'UnsafeList', AnsibleUnsafe('UnsafeList'), AnsibleVaultEncryptedUnsafeText('VaultList')]
    ]

# Generated at 2022-06-22 21:33:43.993170
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # This test is not necessary, however it is important to properly display the logs and
    # display the output on the console
    print("AnsibleJSONEncoder test started")
    print("AnsibleJSONEncoder test ended")



# Generated at 2022-06-22 21:33:54.542935
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    # Object for test
    class AnsibleText(object):

        def __init__(self, unsafe_text=''):
            self.__UNSAFE__ = boolean(unsafe_text)

    # Strings with non-ASCII characters
    unicode_string = u'unicode_string'
    byte_string = b'byte_string'
    # Strings with \n character
    unicode_string_with_newline = u'unicode_string\nwith_newline'
   

# Generated at 2022-06-22 21:34:05.497069
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import ansible.vars.unsafe_proxy as unsafe_proxy

    vault_pwd = 'pass'
    vault = VaultLib(vault_pwd)

    vault_text = '$ANSIBLE_VAULT;%s;' % vault_pwd
    unsafe_text = '$ANSIBLE_VAULT;%s;' % vault_pwd

    vault_decrypted = 'I have a secret'
    vault_encrypted = vault.encrypt(vault_decrypted)

    assert vault_text in vault_encrypted
    assert unsafe_text in vault_encrypted

    unsafe_value = unsafe_proxy.AnsibleUnsafeText(vault_encrypted)
    vault_value = unsafe_proxy.VaultSecret(vault_encrypted)

    json_encoder = Ans

# Generated at 2022-06-22 21:34:17.164218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict_test = dict(a=1, b=2, c=3)
    date_test = datetime.datetime(2019, 1, 1)
    unsafe_test = u"test_unsafe"
    vault_test = u"test_vault"

    encoder = AnsibleJSONEncoder()
    assert dict_test == encoder.default(dict_test)
    assert '2019-01-01T00:00:00' == encoder.default(date_test)

    encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)
    assert dict_test == encoder_vault_to_text.default(dict_test)
    assert '2019-01-01T00:00:00' == encoder_vault_to_text.default(date_test)

# Generated at 2022-06-22 21:34:24.048262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    assert encoder.default(datetime.date(2019, 2, 3)) == '2019-02-03'
    assert encoder.default(datetime.datetime(2019, 2, 3, 12, 10, 5)) == '2019-02-03T12:10:05'
    assert encoder.default({'test':'value'}) == {'test':'value'}


# Generated at 2022-06-22 21:34:34.451138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert encoder.default('abc') == 'abc'
    assert encoder.default(u'abc') == u'abc'
    assert encoder.default(None) == None
    assert encoder.default(1) == 1
    assert encoder.default(123.4) == 123.4
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(b'abc') == 'abc'
    assert encoder.default(set((1, 2, 3))) == [1, 2, 3]
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(set((1, 2, 3)))

# Generated at 2022-06-22 21:34:47.590108
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    enc = AnsibleJSONEncoder()
    assert enc.default(getattr({}, '__UNSAFE__', False)) == False
    assert enc.default(getattr({}, '__ENCRYPTED__', False)) == False
    assert enc.default(getattr({}, '__KEEP_UNSAFE__', False)) == False
    assert enc.default(getattr({}, '__KEEP_VAULT__', False)) == False
    assert enc.default(Mapping) == '{...}'
    assert enc.default(dict(a=1, b=2)) == {'a': 1, 'b': 2}
    assert enc.default(dict(a=1.1, b=2.2)) == {'a': 1.1, 'b': 2.2}

# Generated at 2022-06-22 21:34:49.765259
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert isinstance(unsafe_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-22 21:35:00.954095
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes
    import json

    ansible_string = string_types[0]
    ansible_bytes = string_types[1]

    # JSONEncoder(preprocess_unsafe=False)
    # input is a list contains one string object which is "AnsibleUnsafe" object
    # output should not be threw by Exception and it is a list contains one string object
    test_list = [ansible_string(u'Hello World!')]
    test_list[0].__UNSAFE__ = True

# Generated at 2022-06-22 21:35:10.623920
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from .common import AnsibleUnsafe
    from .common import AnsibleVaultEncryptedUnicode
    import datetime as dt
    import datetime

    my_dict = {'foo': (1, 2, 3)}
    my_list = [1, 2, 3, 4]
    sample_string = AnsibleUnsafe("ansible unsafe string")
    sample_vault = AnsibleVaultEncryptedUnicode("ansible vault string")
    date_object = datetime.datetime(2020, 7, 31)

    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(my_dict) == my_dict
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(my_list) == my_list
    assert Ans

# Generated at 2022-06-22 21:35:20.770537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import AnsibleUnsafeText
    from ansible.module_utils.six import string_types
    from datetime import datetime

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # AnsibleVaultEncryptedUnicode:
    string_sample = 'secret string'
    vault_sample = VaultLib(password='password').encode(string_sample)
    result = encoder.default(vault_sample)

# Generated at 2022-06-22 21:35:28.333788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default('str') == 'str'
    assert AnsibleJSONEncoder().default(123) == 123
    assert AnsibleJSONEncoder().default(123.456) == 123.456
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert AnsibleJSONEncoder().default(('a', 'b', 'c')) == ('a', 'b', 'c')
    assert AnsibleJSONEncoder().default({'a': 1, 'b': 2, 'c': 3}) == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-22 21:35:38.108742
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import copy
    from ansible.module_utils.common.text.converters import _to_text
    from ansible.module_utils.common.collections import OrderedDict
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    o = {
        'a': 'b',
        'c': 'd',
    }
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    stream = encoder.iterencode(o)
    stream = ''.join(stream)
    stream = _to_text(stream, errors='surrogate_or_strict')

# Generated at 2022-06-22 21:35:47.014557
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    test_o = {'test1': {'test2': [AnsibleUnsafeText('test_encrypt_unsafe_text')]}}

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_json_encoder.iterencode(test_o) == '[{"test1": {"test2": [{"__ansible_unsafe": "test_encrypt_unsafe_text"}]}}]'

# Generated at 2022-06-22 21:35:53.235371
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    expected_result = '["[AnsibleUnsafe: hello]"]'

    o = [AnsibleUnsafe('hello')]
    result = ''.join(AnsibleJSONEncoder(skipkeys=True, ensure_ascii=False, sort_keys=True,
                                        preprocess_unsafe=True).iterencode(o))
    assert result == expected_result

# Generated at 2022-06-22 21:36:01.830595
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    :return: None
    """
    from ansible.module_utils.common.text.converters import to_native

    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    # Vars for tests
    test_data = [
        "test text",
        10,
        {'key1': 10, 'key2': 20, 'key3': 'test text'},
        [10, 20, 30, 'test text', {'subkey1': 10}]
    ]

    # Add AnsiUnsafe values from test_data to test_data
    for index in range(len(test_data)):
        test_data.append(AnsibleUnsafe(test_data[index]))

# Generated at 2022-06-22 21:36:11.819362
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib

    # The VaultLib.dump function requires a password to encrypt the given data.
    # generate a random 32-bit password
    from os import urandom
    from struct import Struct
    from base64 import urlsafe_b64encode
    Int = Struct('I')
    r = urandom(Int.size)
    pwd = Int.unpack(r)[0]
    pwd = pwd % (1 << 32)
    pwd = urlsafe_b64encode(Int.pack(pwd)).rstrip(b'=')
    # set up

# Generated at 2022-06-22 21:36:20.924443
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

# Generated at 2022-06-22 21:36:23.218288
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(hasattr(AnsibleJSONEncoder, 'default'))
    assert(hasattr(AnsibleJSONEncoder, 'iterencode'))

# Generated at 2022-06-22 21:36:33.598419
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.six.moves.urllib.parse import urlparse

    # vault object
    vault_secret = VaultSecret('foo')
    vault_lib = VaultLib([vault_secret])
    vault_pass = 'password'
    text = 'This is a test'

    ciphertext = vault_lib.encrypt(text, vault_pass)
    assert ciphertext != text

    encoded_vault_text = '__ansible_vault|%s' % quote_plus(ciphertext)
    encoded_vault_

# Generated at 2022-06-22 21:36:42.491235
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.basic import AnsibleUnsafeText, AnsibleUnsafeBytes


# Generated at 2022-06-22 21:36:43.787816
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    js_encoder = AnsibleJSONEncoder()
    assert js_encoder is not None

# Generated at 2022-06-22 21:36:48.264128
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe_str = 'testAnsibleUnsafeString'
    AnsibleJSONEncoder(preprocess_unsafe=True)
    AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_str) == b'"testAnsibleUnsafeString"'

# Generated at 2022-06-22 21:36:56.705680
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # global used for performing the test
    test_AnsibleJSONEncoder_iterencode.test_data = [
        {'x': "a", 'y': "b"},
        {'x': 1, 'y': 2},
        [1, 2, "a"]
    ]

    def _test(value):
        assert json.dumps(value) == to_text(AnsibleJSONEncoder().iterencode(value)).strip()

    for data in test_AnsibleJSONEncoder_iterencode.test_data:
        _test(data)

    class UnsafeType:
        __UNSAFE__ = True

    def _test_unsafe(value):
        assert value != to_text(AnsibleJSONEncoder().iterencode(value)).strip()

# Generated at 2022-06-22 21:36:57.580345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print(json.dumps(AnsibleJSONEncoder))

# Generated at 2022-06-22 21:36:59.764391
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(ansible_json_encoder, json.JSONEncoder)

# Generated at 2022-06-22 21:37:06.780192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    # test AnsibleUnsafe object
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('world')) == {'__ansible_unsafe': 'world'}
    # test AnsibleUnsafe object which has __ENCRYPTED__ attribute
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('world', True)) == {'__ansible_unsafe': 'world'}
    # test default
    assert AnsibleJSONEncoder().default('hello') == 'hello'

# Generated at 2022-06-22 21:37:18.008689
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_passwd = 'core/test_AnsibleJSONEncoder_default_foo_bar'
    vault = VaultLib(vault_passwd)
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test') == 'test'
    assert encoder.default('test'.encode('utf-8')) == 'test'
    assert encoder.default(text_type('test')) == 'test'
    assert encoder.default(vault.encode('test'))['__ansible_vault'] == vault.encode('test')._ciphertext

# Generated at 2022-06-22 21:37:27.137805
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    encoder = AnsibleJSONEncoder(sort_keys=True, ensure_ascii=False, indent=4)
    o1 = {"example": "example"}
    o2 = ["example"]
    o3 = {"example": {"example": "example"}}
    assert list(encoder.iterencode(o1)) == ['{\n', '    "example": "example"\n', '}']
    assert list(encoder.iterencode(o2)) == ['[\n', '    "example"\n', ']']
    assert list(encoder.iterencode(o3)) == ['{\n', '    "example": {\n', '        "example": "example"\n', '    }\n', '}']

# Generated at 2022-06-22 21:37:34.925437
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert(encoder.check_circular == True)
    assert(encoder.ensure_ascii == True)
    assert(encoder.indent == None)
    assert(encoder.key_separator == ': ')
    assert(encoder.object_pairs_hook == None)
    assert(encoder.preprocess_unsafe == False)
    assert(encoder.sort_keys == False)
    assert(encoder.skipkeys == False)
    assert(encoder.vault_to_text == False)

# Generated at 2022-06-22 21:37:43.548337
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    from ansible.module_utils.six import PY3

    try:
        from __main__ import display
        display_available = True
    except ImportError:
        display_available = False

    def display(data):
        if display_available:
            display(data)
        else:
            print(json.dumps(data, indent=4, cls=AnsibleJSONEncoder, preprocess_unsafe=True))

    def main(args=None):
        """Main function"""
        from ansible.module_utils.six import binary_type

        encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

        # binary type

# Generated at 2022-06-22 21:37:48.338429
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_MAPPING
    from ansible.module_utils.basic import json_dict_unicode_to_bytes
    from ansible.module_utils.six import string_types

    class AnsibleUnsafe(unicode):
        """
        This is a wrapper class to indicate that a given value is unsafe to
        use, and should not be passed as-is to user-supplied code.
        """
        __UNSAFE__ = True
        __

# Generated at 2022-06-22 21:37:52.252539
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:37:58.468935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(b'bytes') == 'bytes'
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default({'a': 1}) == {'a': 1}
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert AnsibleJSONEncoder().default(u'unicode') == 'unicode'

# Generated at 2022-06-22 21:38:09.084423
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {
        'b': datetime.date(2014, 2, 3),
        'c': ['a', 'b', 'c'],
        'd': {'a': 'b'}
    }
    assert json.dumps(data, cls=AnsibleJSONEncoder) == '{"b": "2014-02-03", "c": ["a", "b", "c"], "d": {"a": "b"}}'
    assert json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"b": "2014-02-03", "c": ["a", "b", "c"], "d": {"a": "b"}}'



# Generated at 2022-06-22 21:38:17.912251
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # create a test class
    class Ansi(object):
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
        __repr__ = __str__
        __unicode__ = __str__

    # create the object to test
    test_object = {'class': Ansi('ansible')}

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    result = json.dumps(test_object, cls=ansible_json_encoder)
    expected = '{"class": "ansible"}'

    assert result == expected

# Generated at 2022-06-22 21:38:19.897678
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    o = 'test'
    assert AnsibleJSONEncoder(o)

# Generated at 2022-06-22 21:38:30.622811
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    # test for vault_to_text and preprocess_unsafe
    vault_to_text = True
    preprocess_unsafe = True

    # vault object
    v = VaultSecret([b'password'], b'asdf')
    assert json.dumps(v,
                      cls=AnsibleJSONEncoder,
                      vault_to_text=vault_to_text,
                      preprocess_unsafe=preprocess_unsafe) == "password"

    # unsafe object
    u = AnsibleUnsafe("password")

# Generated at 2022-06-22 21:38:34.694279
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json = AnsibleJSONEncoder()
    test_dict = {'name': 'ansible_json_encoder'}
    json_str = ansible_json.encode(test_dict)
    print(json_str)

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:38:45.440950
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test function
    def _encode(obj, preprocess_unsafe=False, **kwargs):
        return list(AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe, **kwargs).iterencode(obj))

    # Test data
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text, to_bytes
    for b in (True, 'yes', 'on', 'true', '1'):
        unsafe_true = boolean(b, strict=False)
        safe_true = boolean(b, strict=True)

# Generated at 2022-06-22 21:38:47.695231
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()
    assert isinstance(enc, json.JSONEncoder)



# Generated at 2022-06-22 21:38:57.891627
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    list1 = [1, 2, 3, 4]
    list2 = [1, 2, 3, AnsibleUnsafe(4)]

    dict1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    dict2 = {'a': 1, 'b': 2, 'c': 3, 'd': AnsibleUnsafe(4)}

    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    list1_encoded = json.dumps(list1, cls=json_encoder, sort_keys=True)
    list2_encoded = json.dumps(list2, cls=json_encoder, sort_keys=True)

    assert list1_encoded == '[1, 2, 3, 4]'

# Generated at 2022-06-22 21:39:09.659862
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import bytes_to_text
    from ansible.module_utils.common.text.converters import b_to_u, u_to_b
    from ansible.module_utils.common.text.converters import strip_bom
    from ansible.module_utils.common.text.converters import strip_control_chars
    from ansible.module_utils.common.text.converters import strip_internal_control_chars
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-22 21:39:17.471908
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=unused-variable
    # Reset import directories to ensure no influence from other tests (e.g. FileParser)
    import ansible.parsing.vault
    import ansible.parsing.vault as vault
    ansible.parsing.vault.__path__ = []
    import ansible.parsing.vault_init
    import ansible.parsing.vault_init as vault_init
    ansible.parsing.vault_init.__path__ = []
    from ansible.errors import AnsibleError
    def dummy_VaultLib(password):
        return vault.VaultLib(password)
    vault.VaultLib = dummy_VaultLib
    from ansible.parsing.vault_init import VaultLib

# Generated at 2022-06-22 21:39:21.865309
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleTest:
        def __init__(self, val):
            self.value = val
    data = {'key1': 'val1',
            'key2': AnsibleTest('val2'),
            'key3': 3,
            'key4': [1, 2, 3]}
    expected = '{"key1": "val1", "key2": {"value": "val2"}, "key3": 3, "key4": [1, 2, 3]}'
    actual = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True)
    assert(expected == actual)


# Generated at 2022-06-22 21:39:33.301794
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultAES256

    module = AnsibleModule(argument_spec=dict())
    results = dict(failed=False, changed=False, rc=0, stdout='', stderr='')
    input = dict(output=dict(a=1, b=2, c=3), results=results, module=module)

    encrypted = VaultLib([0], VaultAES256)

    # test vault object
    input['output']['vault'] = encrypted.encrypt('vault_secret')

# Generated at 2022-06-22 21:39:36.179833
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    arg1 = AnsibleJSONEncoder()
    assert arg1._preprocess_unsafe == False
    assert arg1._vault_to_text == False


# Generated at 2022-06-22 21:39:47.297037
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """ Run a test for method iterencode

    Create a simple unsafe object, run iterencode with preprocess_unsafe event.
    Assert the result is what we expect.

    :return: None
    """
    class BaseUnsafe(object):
        __UNSAFE__ = True

    class MyUnsafe(BaseUnsafe, str):
        pass

    my_unsafe = MyUnsafe('{{lookup("pipe", "echo hello")}}')
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    safe_my_unsafe = ansible_json_encoder.iterencode(my_unsafe)
    safe_my_unsafe = safe_my_unsafe.decode('utf-8')
    assert '__ansible_unsafe'

# Generated at 2022-06-22 21:39:54.224326
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret

    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert '{"__ansible_vault": "V2BsaW1lZCBiYXNlNjQ="}' == ''.join(enc.iterencode(VaultSecret('VaultSecret')))
    assert '{"__ansible_unsafe": "UnsafeString"}' == ''.join(enc.iterencode('UnsafeString'))

# Generated at 2022-06-22 21:40:02.671708
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import os
    import tempfile
    safe_encoder = AnsibleJSONEncoder()
    unsafe_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    vault_encoder = AnsibleJSONEncoder(vault_to_text=True)
    data = {'name': 'ansible', 'uname': b'\x00\x11\x99', 'vault': os.urandom(16)}
    safe_json = safe_encoder.encode(data)
    unsafe_json = unsafe_encoder.encode(data)
    vault_json = vault_encoder.encode(data)
    assert(safe_json == "{\"uname\": \"\\u0000\\u0011\\u0099\", \"name\": \"ansible\"}")

# Generated at 2022-06-22 21:40:13.762769
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import io
    import json

    data = {
        'foo': 1,
        'bar': {
            'bar_1': 'baz',
            'bar_2': 1,
            'bar_3': u'баз',
        },
        'bar_4': u'баз',
        'bar_5': True,
        'bar_6': False,
        'bar_7': 3.12,
        'bar_8': sys.maxsize,
        'bar_9': datetime.datetime(2012, 12, 31, 23, 59, 59, 999999),
        'bar_10': datetime.date(2012, 12, 31),
    }


# Generated at 2022-06-22 21:40:20.289278
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    import ansible
    #get ansible_version
    ansible_version = ansible.__version__.split('.')
    major_version = int(ansible_version[0])
    minor_version = int(ansible_version[1])

    #get ansible_version
    python_version = sys.version_info
    major_version = int(python_version[0])
    minor_version = int(python_version[1])

    #set up the ansible vault object
    vault_lib = VaultLib([])
    vault_version = 1
    if (major_version == 2 and minor_version >= 4) or (major_version >= 3):
       vault_version = 2
       vault_

# Generated at 2022-06-22 21:40:31.519589
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import OrderedDict

    vault = VaultLib(password='123456')
    vaulttext = vault.encrypt('abc')
    assert isinstance(vaulttext, str)
    odict = OrderedDict([('release', vaulttext), ('pool', 'rhel7')])
    result = json.dumps(odict, cls=AnsibleJSONEncoder)
    assert isinstance(result, str)

    # result should contain __ansible_vault if it is encrypted by VaultLib
    assert isinstance(result, str)
    assert '__ansible_vault' in result

