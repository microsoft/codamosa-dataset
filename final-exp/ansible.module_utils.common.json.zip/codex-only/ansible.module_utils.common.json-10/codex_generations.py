

# Generated at 2022-06-22 21:30:27.010069
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert str(type(AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False))) == "<class 'ansible.module_utils.basic.AnsibleJSONEncoder'>"


# Generated at 2022-06-22 21:30:38.754362
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    ansible_unsafe = """\x1b[1;31mERROR!\x1b[0m \x1b[1;31mUNSAFE_ECHO\x1b[0m is set! For safety reasons,
the value of the command will not be displayed back to the user. In order to see the command output,
you must explicitly add -vvvv, which will succeed to also show the command output.\n"""
    ansible_vault = VaultLib([], True)

# Generated at 2022-06-22 21:30:44.676380
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.six
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.urls import url_argument_spec, fetch_url

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    enc = encoder.iterencode({'data': 'pwd:{{ ansible_password }}'})
    data = '{' + ', '.join(list(enc)) + '}'
    assert data == '{"data": {"__ansible_unsafe": "pwd:{{ ansible_password }}"}}'

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:30:47.047294
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_value = 'test_value'
    test_instance = AnsibleJSONEncoder()
    assert test_instance.default(test_value) == test_value

# Generated at 2022-06-22 21:30:50.583691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    encoder = AnsibleJSONEncoder()

    import datetime
    result = encoder.default(datetime.datetime(2017, 1, 1, 0, 0, 0, 0))
    assert result == "2017-01-01T00:00:00"
    result = encoder.default(datetime.date(2017, 1, 1))
    assert result == "2017-01-01"

# Generated at 2022-06-22 21:30:58.561928
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(vault_to_text=False)
    assert AnsibleJSONEncoder(vault_to_text=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-22 21:31:10.041297
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # Loading the example test data
    import os
    import ast
    dirname = os.path.dirname(os.path.abspath(__file__))
    test_data = {}
    with open(os.path.join(dirname, 'test_encoder.json'), 'r') as f:
        test_data = json.loads(f.read())
    for k,v in test_data.items():
        test_data[k]=ast.literal_eval(v)

    # Defining the test scenarios

# Generated at 2022-06-22 21:31:17.335843
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    o = dict(
        string=u'foo',
        text=u'bar',
        bytes=u'baz',
        unsafe_text=AnsibleUnsafeText(u'κόσμε'),
        unsafe_bytes=AnsibleUnsafeBytes(b'\xce\xba\xcf\x8c\xcf\x83\xce\xbc\xce\xb5')
    )
    result = json.loads(''.join([a for a in AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o)]))

# Generated at 2022-06-22 21:31:19.898815
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_class = AnsibleJSONEncoder()

    assert ansible_class._preprocess_unsafe is False


# Generated at 2022-06-22 21:31:28.302339
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    ####################
    # Test 1: simple dict test
    ####################

    test1 = {'a':'b', 'c':'d'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(test1) == (b'{"a": "b", "c": "d"}')

    ####################
    # Test 2: all items of dict are string
    ####################

    test2 = {'a':'b', 'c':'d'}
    for k, v in test2.items():
        test2[k]

# Generated at 2022-06-22 21:31:39.351351
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json
    import base64

    # Test data
    data = {
        'array' : [1, 2, 3],
        'object' : {'a': 1, 'b': 2},
        'regular_text': 'text',
        'unicode': u'Unicode',
        'secure_text': AnsibleUnsafeText(base64.b64encode('mysecrettext'.encode('utf-8')))
    }

    # JSON encode the test data using default JSONEncoder
    default_encoder = json.dumps(data)

    # JSON encode the test data using AnsibleJSONEncoder
    ansible_encoder = json.dumps(data, cls=AnsibleJSONEncoder)

    # Compare the output of default

# Generated at 2022-06-22 21:31:48.952304
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    vault_password = "vault_password"
    vault = VaultLib(vault_password)

    # This is just some sample string for testing
    # it has no special meaning
    plaintext = '''This is some plaintext'''

    encrypted = vault.encrypt(plaintext)

    # The decrypt method returns a new instance of AnsibleUnsafe
    # this has __UNSAFE__ set to True
    # See ../ansible/parsing/vault/__init__.py:17
    decrypted = vault.decrypt(encrypted)

    # Create a simple dictionary
    # with one key:value pair
    d = {'key' : decrypted}

    # Create an encoder

# Generated at 2022-06-22 21:31:53.985428
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert(encoder.__init__)
    assert(encoder._preprocess_unsafe == False)
    assert(encoder._vault_to_text == False)
    assert(encoder != None)
    

# Generated at 2022-06-22 21:32:02.729586
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ans = AnsibleJSONEncoder()
    assert not hasattr(ans, '_preprocess_unsafe') and not hasattr(ans, '_vault_to_text')
    ans = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ans._preprocess_unsafe == True and ans._vault_to_text == False
    ans = AnsibleJSONEncoder(vault_to_text=True)
    assert ans._preprocess_unsafe == False and ans._vault_to_text == True
    ans = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ans._preprocess_unsafe == True and ans._vault_to_text == True


# Generated at 2022-06-22 21:32:13.864547
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import binary_type, text_type

    def _scan_for_unsafe(value):
        if is_sequence(value):
            for v in value:
                if _scan_for_unsafe(v):
                    return True
        elif isinstance(value, Mapping):
            for k, v in value.items():
                if _scan_for_unsafe(v):
                    return True
        return _is_unsafe(value)

    # setup the objects

# Generated at 2022-06-22 21:32:25.517000
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    content = {'ansible_facts': {'is_sequence': True, 'test_unsafe': 'test'}, 'test': 'test2'}
    content_str_json = AnsibleJSONEncoder().encode(content)
    content_str_json_preprocess = AnsibleJSONEncoder(preprocess_unsafe=True).encode(content)
    content_str_json_vault = AnsibleJSONEncoder(vault_to_text=True).encode(content)
    content_str_json_vault_preprocess = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode(content)
    assert content_str_json == content_str_json_preprocess
    assert content_str_json == content_str_json_vault
    assert content_str_json

# Generated at 2022-06-22 21:32:35.634558
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import re
    import os
    import crypt
    import random
    import string
    import tempfile
    import datetime
    test_val = [
        random.choice(string.ascii_letters),
        random.choice(string.digits),
        random.choice(string.punctuation),
    ]
    test_val = ''.join(test_val)
    # test_val = u'/home/user'
    # test_val = u'/home/user :D'
    # test_val = u'🦄'
    # test_val = u'\x72\x6F\x6D\x61\x6E'
    # test_val = u'roméo'
    # test_val = u'\u270e\ufe0f'
    # test_val = u

# Generated at 2022-06-22 21:32:37.822028
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder



# Generated at 2022-06-22 21:32:40.348057
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert(encoder)
    assert(isinstance(encoder, json.JSONEncoder))


# Generated at 2022-06-22 21:32:50.612319
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    class MyVaultLib(VaultLib):
        def __init__(self):
            self._vault_password = ''
            self._ciphertext = '$ANSIBLE_VAULT'
            self._secret = ''

    import datetime
    o = {'a': MyVaultLib(), 'b': 'c', 'd': [1, 2], 'e': {'a': 'b'}, 'f': datetime.datetime(2015, 6, 8, 15, 35, 26, 259342)}
    encoder = AnsibleJSONEncoder()

    although_in_vault_format_normally_we_want_to

# Generated at 2022-06-22 21:33:02.793852
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    contents = "secret"
    vault = VaultLib([])
    encrypted_string = vault.encrypt(contents)
    unsafe_string = vault.encrypt("ansible_unsafe")
    print("Encrypted String", encrypted_string.strip())
    print("Unsafe String", unsafe_string.strip())
    # Making sure that the string is not encrypted again
    encrypted_string = vault.encrypt(encrypted_string.strip())
    unsafe_string = vault.encrypt(unsafe_string.strip())
    print("Encrypted String Again", encrypted_string.strip())
    print("Unsafe String Again", unsafe_string.strip())

# Generated at 2022-06-22 21:33:14.414677
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # NOTE: Tests below can be removed once this module is called by Ansible proper
    #       as Ansible will handle unit tests in its own way
    from ansible.module_utils.common._collections_compat import Mapping, MutableMapping
    from ansible.module_utils.json_utils import AnsibleUnsafeText

    # Default constructor
    encoder = AnsibleJSONEncoder()
    assert encoder == json.JSONEncoder()

    # Constructor with keyword arguments
    encoder = AnsibleJSONEncoder(sort_keys=True, indent=4, separators=(',', ': '))
    assert encoder == json.JSONEncoder(sort_keys=True, indent=4, separators=(',', ': '))

    # Encoding a object that use default() method

# Generated at 2022-06-22 21:33:18.272023
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder().default("__UNSAFE__") == "__UNSAFE__"
    assert AnsibleJSONEncoder().default("__ENCRYPTED__") == "__ENCRYPTED__"
    assert AnsibleJSONEncoder().default({"key":"value"}) == {"key":"value"}

# Generated at 2022-06-22 21:33:27.076439
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import PY3
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin

    from ansible.plugins.vars.unsafe import AnsibleUnsafe

    import ansible

    # NOTE: order of the imports below matters, need to initialize vault first
    # This will initialize all plugins, making sure the vars plugins are initialized too
    add_all_plugin_dirs()
    # This will initialize vault
    find_plugin('vault')

    # data for testing
    unsafe_obj = AnsibleUnsafe('this is unsafe')

    test_data = {'unsafe_obj': unsafe_obj,
                 'safe_str': 'this is safe'}

    # initialize the encoder

# Generated at 2022-06-22 21:33:38.584447
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import binary_type
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # create a vault_password file
    f = open('/tmp/vault_password', 'w')
    f.write('password')
    f.close()

    # encrypted_vault
    encrypted_vault = VaultLib('/tmp/vault_password')
    encrypted_data = encrypted_vault.encrypt('encrypted data')
    assert isinstance(encrypted_data, binary_type)
    # assertBytesDecode  unit test for python2
    #

# Generated at 2022-06-22 21:33:44.591015
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.module_utils.common.unsafe_proxy import wrap_var

    plain_text = "this-is-plain-text"
    plain_bytes = b"this-is-plain-bytes"
    plain_dict_text = dict(plain_key=wrap_var(plain_text))
    plain_dict_bytes = dict(plain_key=wrap_var(plain_bytes))
    plain_list_text = [wrap_var(plain_text), wrap_var(plain_bytes)]
    plain_list_

# Generated at 2022-06-22 21:33:50.112611
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Arrange
    fake_data = 'abc'
    fake_encoder_iterable = [fake_data]
    class_instance = AnsibleJSONEncoder(preprocess_unsafe=False)
    # Act
    result = class_instance.iterencode(fake_encoder_iterable)
    # Assert
    assert result == ['"abc"']


# Generated at 2022-06-22 21:34:01.056831
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.encoding import ensure_bytes, ensure_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultUnlockError
    from ansible.parsing.vault import VaultSecretSpec
    from ansible.parsing.vault import VaultStr
    from ansible.parsing.vault import VaultUnicode

    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault_password = "ansible"
    vault_data = "some data"

    vault_lib = VaultLib(vault_password)
    vault_data_bytes = ensure_bytes(vault_data, errors='surrogate_or_strict')
    vault_secret_raw = vault_

# Generated at 2022-06-22 21:34:09.883298
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    text = AnsibleUnsafe('Europe/Berlin')
    dt = datetime.datetime.now()
    obj = {'a': text, 'b': dt, 'c': {'d': dt, 'e': text}, 'f': [text, dt, [{'g': text, 'h': dt}]]}
    encoded_text = '"Europe/Berlin"'
    encoded_dt = '"{}"'.format(dt.isoformat())

# Generated at 2022-06-22 21:34:20.061913
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    vault_password = "vaultpw"
    vault_lib = VaultLib([vault_password])

# Generated at 2022-06-22 21:34:29.600491
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    testclass = AnsibleJSONEncoder()

    # Test empty list, haing not tested in previous commits
    testobj = []
    assert (testclass.default(testobj) == [])

    # Test unicode string
    testobj = u'\u20ac'
    assert (testclass.default(testobj) == testobj)

    # Test class with __dict__
    class myClass():
        def __init__(self):
            self.key = 'value'
            self.key2 = 'value2'
            self.key3 = 'value3'
    testobj = myClass()
    assert (testclass.default(testobj) == {'key': 'value', 'key2': 'value2', 'key3': 'value3'})

    # Test list of strings

# Generated at 2022-06-22 21:34:37.636245
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # AnsibleVaultEncryptedUnicode
    d = to_text(VaultLib([b'$ANSIBLE_VAULT;1.1;AES256'], b'3').encrypt(b'ascii'), errors='surrogate_or_strict')
    assert AnsibleJSONEncoder().default(d) == {'__ansible_vault': d}
    assert AnsibleJSONEncoder(vault_to_text=True).default(d) == d
    d = to_text(VaultLib([b'$ANSIBLE_VAULT;2.0;AES256'], b'3').encrypt(b'ascii'), errors='surrogate_or_strict')

# Generated at 2022-06-22 21:34:49.832645
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Dict
    assert json.dumps({'a': 1, 'b': 2}, cls=AnsibleJSONEncoder) == '{"a": 1, "b": 2}'

    # Date
    now = datetime.datetime.utcnow()
    assert json.dumps(now, cls=AnsibleJSONEncoder) == '"{0}"'.format(now.isoformat())

    # Vault
    # vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;test\r\n63336333646333623739366432343139643936656431373131356136636335386630643739613063\r\n633963353730643338626264336139613661623036333635

# Generated at 2022-06-22 21:34:54.424012
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(vault_to_text=True)
    assert AnsibleJSONEncoder(vault_to_text=False)


# Generated at 2022-06-22 21:35:05.526087
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import unittest2 as unittest  # needed to overcome dependency issue with unittest2 on Travis

    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    class Test(unittest.TestCase):
        def test_encode_unsafe(self):
            # given
            class UnsafeClass(AnsibleUnsafe):
                def __str__(self):
                    return 'unsafe_str'

                # unicode to json = surrogate
                def __unicode__(self):
                    return u'unsafe_unicode'

                def __repr__(self):
                    return 'unsafe_repr'

            the_value = {"a": "b", "c": UnsafeClass()}

            # when test iterencode
            result = AnsibleJSONEncoder(preprocess_unsafe=True).it

# Generated at 2022-06-22 21:35:15.175276
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    obj1 = {'hello': 'world'}
    obj2 = {'hello': 'world', 'a': 1}
    obj3 = {'hello': 'world', 'a': 1, 'b': 2}
    obj4 = {'hello': 'world', 'a': {} }
    obj5 = {'hello': 'world', 'a': {}, 'b': []}
    obj6 = {'hello': 'world', 'a': {}, 'b': []}
    obj7 = {'hello': 'world', 'a': {}, 'b': []}
    obj8 = {'hello': 'world', 'a': {}, 'b': []}

# Generated at 2022-06-22 21:35:16.172879
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    v = AnsibleJSONEncoder()


# Generated at 2022-06-22 21:35:25.309060
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultSecret

    class TestClass:
        def __init__(self):
            self.run_command = {'stdout': [12345], 'stderr': [12345]}
            self.get_bin_path = {'somewhere' : [12345], 'over' : [12345], 'the' : [12345], 'rainbow' : [12345]}
            self.boolean1 = True
            self.string1 = 'string'
            self.string2 = [u'string']
            self.integer1 = 12345
            self.integer2 = [12345]
            self.float1 = 12.34
            self.float2 = [12.34]
            self.vault = VaultSecret

# Generated at 2022-06-22 21:35:28.099950
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # create object of class AnsibleJSONEncoder
    encoder_object = AnsibleJSONEncoder()
    # confirm that the object has been created
    assert encoder_object

# Generated at 2022-06-22 21:35:35.863958
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test no data
    o = "nodata"
    encoded_data = json.dumps(o, cls=AnsibleJSONEncoder)
    assert encoded_data == "\"nodata\""

    # Test normal data with simple string
    o = {
        "test": "spam"
    }
    encoded_data = json.dumps(o, cls=AnsibleJSONEncoder)
    assert encoded_data == "{\"test\": \"spam\"}"

    # Test normal data with AnsiBLEUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultSecret

    loader = Data

# Generated at 2022-06-22 21:35:47.324232
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().encode(dict(test1=dict(__ansible_vault='test'))) == '{"test1": {"__ansible_vault": "test"}}'
    assert AnsibleJSONEncoder().encode(dict(test1=dict(__ansible_unsafe='test'))) == '{"test1": {"__ansible_unsafe": "test"}}'
    assert AnsibleJSONEncoder().encode(dict(test1='test')) == '{"test1": "test"}'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode(dict(test1='test')) == '{"test1": "test"}'

# Generated at 2022-06-22 21:35:57.059935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Set up all four instances of the encoder that we use
    ansible_json_encoder_no_vault = AnsibleJSONEncoder()
    ansible_json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)
    ansible_json_encoder_preprocess_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_json_encoder_preprocess_unsafe_vault_to_text = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # Encoding of safe strings
    assert ansible_json_encoder_no_vault.default("foo") == "foo"

# Generated at 2022-06-22 21:36:05.418730
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type

    # helper to inspect JSON encoded string
    def test_encoding(json_str):
        # encoded string should only contain '__ansible_vault' or '__ansible_unsafe'
        has_vault = False
        has_unsafe = False
        for item in json_str.split(","):
            if '__ansible_vault' in item:
                has_vault = True
            elif '__ansible_unsafe' in item:
                has_unsafe = True
            else:
                return False
        return has_vault ^ has_uns

# Generated at 2022-06-22 21:36:12.072078
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import pytest
    from ansible.module_utils.basic import AnsibleUnsafe
    data = {'unsafe': AnsibleUnsafe('this is a secret')}

    json_an = AnsibleJSONEncoder()

    for chunk in json_an.iterencode(data):
        json_str = json_an.encode(data)

    assert(json_str == '{"unsafe": {"__ansible_unsafe": "this is a secret"}}')

test_AnsibleJSONEncoder_iterencode()

# Generated at 2022-06-22 21:36:20.515667
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(sort_keys=True, indent=4, separators=(',', ': '))
    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves import StringIO

# Generated at 2022-06-22 21:36:31.937220
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    import datetime

    ansible_json_encoder = AnsibleJSONEncoder()

    if hasattr(builtins, 'unicode'):
        # Test for VaultLib
        ciphertext = 'TheVaule'
        vault_password = 'ThePassword'
        vault_lib = VaultLib(vault_password)
        string_encrypt = vault_lib.encrypt(ciphertext)
        ansible_unsafe_encoder_default_value = ansible_json_encoder.default(string_encrypt)
        assert isinstance(ansible_unsafe_encoder_default_value, dict)
        assert ansible_uns

# Generated at 2022-06-22 21:36:40.922295
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible
    obj = AnsibleJSONEncoder(indent=6, skipkeys=False)

    assert obj.encode({'a': 'b'}) == b'{"a": "b"}'
    assert obj.encode({'a': ansible.parsing.utils.unsafe_proxy.AnsibleUnsafeText('b')}) == b'{"a": {"__ansible_unsafe": "b"}}'
    assert obj.encode({'a': ansible.parsing.vault.AnsibleVaultEncryptedUnicode('b')}) == b'{"a": {"__ansible_vault": "b"}}'
    assert obj.encode({'a': datetime.date(1991, 6, 7)}) == b'{"a": "1991-06-07"}'


# =========================================

# Generated at 2022-06-22 21:36:44.247626
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert encoder.__class__.__name__ == 'AnsibleJSONEncoder'


# Generated at 2022-06-22 21:36:53.199780
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from .unsafe_proxy import AnsibleUnsafeText

    vault = VaultLib()
    secret_text = u'secret unicode string 😂'
    secret_bytes = b'secret bytes string \x80\xff'
    ciphertext = vault.encrypt(secret_text)
    ciphertext_bytes = vault.encrypt(secret_bytes)
    # Make an AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText(secret_text)
    # Make a VaultText
    vault_obj_text = vault.decrypt(ciphertext)
    # Make a VaultBytes
    vault_obj_bytes = vault.decrypt(ciphertext_bytes)
    # Make a dictionary of value

# Generated at 2022-06-22 21:36:59.722123
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestObj(object):
        def __init__(self, name=None, age=None):
            # json_encoder cannot serialize object with a None data member
            self.name = name if name is not None else "michael"
            self.age = age if age is not None else 30

    obj = TestObj()

    json_str = AnsibleJSONEncoder().encode(obj)
    print(json_str)
    assert json_str == "{\"name\": \"michael\", \"age\": 30}", \
        "In class AnsibleJSONEncoder method 'default', function failed with error: {} does not equal {}" \
            .format(json_str, "{\"name\": \"michael\", \"age\": 30}")



# Generated at 2022-06-22 21:37:02.958512
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_object = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert test_object._preprocess_unsafe is False
    assert test_object._vault_to_text is False


# Generated at 2022-06-22 21:37:13.545939
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    dl = DataLoader()

# Generated at 2022-06-22 21:37:24.658753
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves.urllib.parse import quote

    vault_pwfile = 'fake_pw_file_for_testing_that_should_not_exist_lol'
    vault_encoder = VaultLib(password_file=vault_pwfile)
    test_vault_data = vault_encoder.encode(u'this is some vaulted data')
    test_unsafe_data = text_type(u'unsafe data')

    # Test Vault Data
    json_encoder = AnsibleJSONEncoder(vault_to_text=False)
    vault_data_quoted = quote(test_vault_data)
    vault_expected_

# Generated at 2022-06-22 21:37:29.109605
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    assert AnsibleJSONEncoder().default(AnsibleUnsafe('foo')) == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('foo')) == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(AnsibleUnsafe('foo')) == 'foo'
    assert AnsibleJSONEncoder(vault_to_text=True).default(AnsibleUnsafe('foo')) == 'foo'
    assert AnsibleJSONEncoder(vault_to_text=False).default(AnsibleUnsafe('foo')) == 'foo'

    dt = datetime.datetime(2018, 1, 1, 0, 0, 0)


# Generated at 2022-06-22 21:37:38.324685
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault_to_text == True

test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:37:49.795025
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class Foo(str):
        __UNSAFE__ = True

    # Test a list of objects
    o = [Foo("foo"), Foo("bar")]
    unsafe_encoded = AnsibleJSONEncoder(preprocess_unsafe=True).encode(o)
    assert isinstance(unsafe_encoded, str)
    assert json.loads(unsafe_encoded) == [{'__ansible_unsafe': 'foo'}, {'__ansible_unsafe': 'bar'}]

    # Test a dictionary of objects
    o = {Foo("foo"): Foo("bar")}
    unsafe_encoded = AnsibleJSONEncoder(preprocess_unsafe=True).encode(o)
    assert isinstance(unsafe_encoded, str)

# Generated at 2022-06-22 21:38:00.100385
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test_default_vault(obj):
        vault_str = json.dumps(obj, cls=AnsibleJSONEncoder)
        assert obj == json.loads(vault_str), 'test_default_vault: ' + vault_str

    class TestCls(object):
        ''' just a test class to make sure objects are handled '''
        def __init__(cself, name):
            cself.name = name
        def __str__(cself):
            return 'cself.name=%s' % cself.name
        def __repr__(cself):
            return 'cself.name=%s' % cself.name

    test_default_vault(17)
    test_default_vault(('a','b','c'))

# Generated at 2022-06-22 21:38:12.272548
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    "Unit test for AnsibleJSONEncoder class"
    from ansible.module_utils.parsing.convert_bool import boolean
    import datetime
    from ansible.module_utils.six import PY3
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    import json

    def _decode_vault_for_python3(o, **kwargs):
        "Private function that decodes vault for python3 and return the output in stringIO"
        if '__ansible_vault' in o:
            vault = VaultLib([])
            out_string = StringIO()

# Generated at 2022-06-22 21:38:24.082219
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Arrange
    encoder = AnsibleJSONEncoder(allow_nan=False)  # disable allow_nan to make more test cases pass

# Generated at 2022-06-22 21:38:27.988133
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {'str': b'\xef\xbb\xbfHello world\n'}
    assert json.dumps(data, cls=AnsibleJSONEncoder) == '{"str": "\\u003c66 6f 6f ff\\\\n"}'


# Generated at 2022-06-22 21:38:36.769153
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(VaultLib([b'password']).encrypt(b'foo')) == {'__ansible_vault': b'$ANSIBLE_VAULT;1.0;AES256\na2ltc3R1ZmY=\n29614370263335396439616532656535636439653464663536646665356439343331333430663303\n62333766303364346538646530383364383332633866393964663130313861396162316364373663\n6662306466\n'}

# Generated at 2022-06-22 21:38:40.428617
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    assert aje
    assert aje._preprocess_unsafe is False
    assert aje._vault_to_text is False

    assert isinstance(aje, json.JSONEncoder)

# Generated at 2022-06-22 21:38:43.516329
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    assert b'"{"__ansible_unsafe": "foo"}"' == AnsibleJSONEncoder().iterencode({'foo': AnsibleUnsafe('foo')})



# Generated at 2022-06-22 21:38:55.561155
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars import AnsibleUnsafe

    test_value_unsafe = AnsibleUnsafe('AnsibleUnsafe')
    test_value_not_unsafe = 'AnsibleUnsafeNot'
    test_value_list = [test_value_unsafe, test_value_not_unsafe]

    test_value_dict = {test_value_unsafe: test_value_unsafe, test_value_not_unsafe: test_value_not_unsafe}
    test_value_list_dict = [test_value_dict, test_value_dict]
    test_value_dict_dict = {test_value_unsafe: test_value_dict, test_value_not_unsafe: test_value_dict}


# Generated at 2022-06-22 21:39:02.214355
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    test_object = {'__ansible_unsafe': 'example_value'}
    out = json.dumps(test_object, sort_keys=True, indent=4, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert out == '{\n    "__ansible_unsafe": "example_value"\n}'


# Generated at 2022-06-22 21:39:12.970026
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.collections import AnsibleUnsafeText
    import datetime

    jenc = AnsibleJSONEncoder()
    assert jenc.default('test') == 'test'
    assert jenc.default(AnsibleUnsafeText('test')) == {'__ansible_unsafe': 'test'}
    assert jenc.default(AnsibleVaultEncryptedUnicode('test')) == {'__ansible_vault': 'test'}
    assert jenc.default(datetime.date(2019, 5, 17)) == '2019-05-17'

# Generated at 2022-06-22 21:39:24.798615
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import iteritems
    from ansible.parsing.vault import VaultLib
    vault_pass = 'some-password'
    vault = VaultLib(vault_pass)

# Generated at 2022-06-22 21:39:34.271074
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    test_dict = {
        'unsafe': AnsibleUnsafe('hello world'),
        'safe': 'goodbye world'
    }
    assert json.dumps(test_dict, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"safe": "goodbye world", "unsafe": {"__ansible_unsafe": "hello world"}}'
    assert json.dumps(test_dict, cls=AnsibleJSONEncoder, preprocess_unsafe=False) == '{"safe": "goodbye world", "unsafe": "hello world"}'

# Generated at 2022-06-22 21:39:45.774564
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert getattr(AnsibleJSONEncoder(), '_preprocess_unsafe') == False
    assert getattr(AnsibleJSONEncoder(), '_vault_to_text') == False
    assert getattr(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True), '_preprocess_unsafe') == True
    assert getattr(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True), '_vault_to_text') == True
    assert getattr(AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False), '_preprocess_unsafe') == False

# Generated at 2022-06-22 21:39:51.090537
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test for a string
    x = 'test'
    y = AnsibleJSONEncoder().default(x)
    assert(x == y)

    # test for a dictionary
    x = dict(a=1, b="abc", c=3.14, d=[1, 2, 3])
    y = AnsibleJSONEncoder().default(x)
    assert(x == y)

# Generated at 2022-06-22 21:40:00.521077
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    enc = AnsibleJSONEncoder()
    assert enc.default(u"foo") == "foo"
    assert enc.default(1) == 1
    assert enc.default(1.0) == 1.0
    assert enc.default(None) is None
    assert enc.default([1, 2, 3]) == [1, 2, 3]
    assert enc.default({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert enc.default(datetime.date.today()) == u'%s' % datetime.date.today().isoformat()
    assert enc.default(datetime.datetime.utcnow()) == u'%s' % datetime.datetime.utcnow().isoformat()

# Generated at 2022-06-22 21:40:12.855448
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import re
    import sys
    import hashlib
    import collections
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type, string_types
    from ansible.module_utils.six.moves import builtins

    # copy from ansible.module_utils.common.collections
    def recursively_convert_to_safe_strings(value):
        if _is_unsafe(value):
            ciphertext = hashlib.md5(to_text(value, errors='surrogate_or_strict', nonstring='strict').encode('utf-8')).hexdigest

# Generated at 2022-06-22 21:40:19.749405
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # Test AnsibleJSONEncoder

    # Test initialization of class
    encoder_1 = AnsibleJSONEncoder()
    encoder_2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    encoder_3 = AnsibleJSONEncoder(vault_to_text=True)
    encoder_4 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # Test encoding of class
    test_json_1 = json.dumps({
        'test': 'testing',
        'test_1': 'testing_1',
    }, cls=AnsibleJSONEncoder)

    assert test_json_1 is not None and type(test_json_1) is str

# Generated at 2022-06-22 21:40:20.620293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-22 21:40:32.435417
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
   json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
   from ansible.parsing.vault import VaultLib
   vault_lib = VaultLib([])
   vault_lib.decrypt(b'$ANSIBLE_VAULT;1.1;AES256\n6335373635303238316631313165323964663538646533306466623563623137333063356636310a363237383061383736613334636231383932616339356363623961643734366165383966350a3635373733316133316631333437396262376563373461373633383066313437373338666563\n')
   vault_data = vault_lib.vault.dec