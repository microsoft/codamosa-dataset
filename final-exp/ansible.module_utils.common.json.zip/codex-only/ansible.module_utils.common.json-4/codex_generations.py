

# Generated at 2022-06-22 21:30:37.159237
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types, PY3
    from ansible.module_utils.common._collections_compat import OrderedDict

    def _is_unsafe(value):
        # For the sake of unit testing
        return getattr(value, '__UNSAFE__', False)

    class FakeUnsafeString(string_types[0]):
        __UNSAFE__ = True

    unsafe_dict = {"key1": "value1", "key2": "value2", "key3": FakeUnsafeString("value3")}
    unsafe_ordered_dict = OrderedDict(unsafe_dict)

    unsafe_list = ["value1", "value2", FakeUnsafeString("value3")]


# Generated at 2022-06-22 21:30:48.469610
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_password = 'password'
    secret_v = VaultSecret(VaultPassword(vault_password))

# Generated at 2022-06-22 21:30:50.416191
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert unsafe.__init__

# Generated at 2022-06-22 21:30:57.527929
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean
    a = AnsibleUnsafe("unsafe")
    assert boolean(AnsibleJSONEncoder().encode(a) == '"__ansible_unsafe": "unsafe"')
    assert boolean(AnsibleJSONEncoder(preprocess_unsafe=True).encode(a) == '"unsafe"')


# Generated at 2022-06-22 21:30:59.371919
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    assert isinstance(aje, json.JSONEncoder)

# Generated at 2022-06-22 21:31:10.866800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test encrypted object
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    vault = AnsibleVaultEncryptedUnicode('foo')
    result = to_text(encoder.default(vault))
    assert result == u'foo'

    # Test unsafe object
    encoder = AnsibleJSONEncoder(vault_to_text=False)
    _unsafe = AnsibleUnsafeText(b'foo')
    result = to_text(encoder.default(_unsafe))
    assert isinstance(result, dict)
    assert result['__ansible_unsafe'] == u'foo'

    # Test normal string object
    encoder = AnsibleJSONEncoder(vault_to_text=False)
    res = to_text(encoder.default('test'))

# Generated at 2022-06-22 21:31:17.754749
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    # Setup
    unsafe1 = AnsibleUnsafe('unsafe value 1')
    unsafe2 = AnsibleUnsafe('unsafe value 2')
    dict_unsafe = dict(
        item1=unsafe1,
        item2=unsafe2,
        item3={
            unsafe1: unsafe2
        }
    )

    # Execute
    json_out = json.dumps(dict_unsafe, indent=2, cls=AnsibleJSONEncoder)

    # Verify
    # dict_unsafe == {
    #   "item1": __ansible_unsafe: "unsafe value 1",
    #   "item2": __ansible_unsafe: "unsafe value 2",
    #   "item3": {
    #    

# Generated at 2022-06-22 21:31:27.184101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = {
        'a': 1,
        'b': '2',
        'c': [3, 4, "a"],
        'd': {
            'd1': '1',
            'd2': '2',
        },
        'e': datetime.date(2010, 1, 1),
    }

# Generated at 2022-06-22 21:31:37.872491
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils

    ansible.module_utils.AnsibleUnsafeText = type('AnsibleUnsafeText', (str, object), {'__UNSAFE__': True, '__ENCRYPTED__': False})
    ansible.module_utils.AnsibleUnsafeBytes = type('AnsibleUnsafeBytes', (str, object), {'__UNSAFE__': True, '__ENCRYPTED__': False})
    ansible.module_utils.AnsibleUnsafeRaw = type('AnsibleUnsafeRaw', (str, object), {'__UNSAFE__': True, '__ENCRYPTED__': False})

# Generated at 2022-06-22 21:31:44.179075
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    string = "test"
    test = AnsibleUnsafe(string)
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder.default(test) == {"__ansible_unsafe": "test"}
    assert encoder.default(string) == "test"

# Generated at 2022-06-22 21:31:54.997968
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # This code is for unit test of module_utils/ansible/module_common.py
    # Method iterencode of class AnsibleJSONEncoder

    # Testcase:1
    output_data = '{"foo": "bar", "baz": ["qux", null, 2.0, false, true, {"__ansible_unsafe": "password_value"}, {"__ansible_unsafe": "username_value"}]}'
    encoder = AnsibleJSONEncoder()
    input_data = {"foo": "bar", "baz": ["qux", None, 2.0, False, True, "password_value", "username_value"]}
    assert output_data == ''.join(encoder.iterencode(input_data))

    # Testcase:2

# Generated at 2022-06-22 21:31:57.048896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps(1, cls=AnsibleJSONEncoder) == '1'


# Generated at 2022-06-22 21:32:04.968029
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import string_types, BytesIO

    class MyUnsafe(string_types[0]):
        __UNSAFE__ = True

    class MyVault(string_types[0]):
        __ENCRYPTED__ = True

    class MyMapping(Mapping):
        pass

    class MyMutableMapping(MutableMapping):
        pass

    # preprocess_unsafe = False
    # vault_to_text = False

# Generated at 2022-06-22 21:32:06.777084
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ret = AnsibleJSONEncoder()
    assert isinstance(ret, json.JSONEncoder)

# Generated at 2022-06-22 21:32:15.091387
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_dict = {'ansible_host': 'host1'}
    test_dict_json = '''{"ansible_host": "host1"}'''
    try:
        json.dumps(test_dict, cls=AnsibleJSONEncoder)
    except Exception as ex:
        assert False, " Failed to initialize AnsibleJSONEncoder"
        print(ex)

    # Test default encoder
    assert AnsibleJSONEncoder().encode(test_dict) == test_dict_json, "Failed to serialize dictionary using AnsibleJSONEncoder"

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:32:26.504205
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    try:
        from __main__ import AnsibleUnsafeText
    except ImportError:
        from ansible.parsing.vault import VaultLib
        class AnsibleUnsafeText(VaultLib.VaultText):
            __UNSAFE__ = True
        AnsibleUnsafeText.VaultFormat = VaultLib.VaultFormat.UNENC_TEXT

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # a test string
    test_string = u'foo€'
    # define a unsafe object
    unsafe_obj = AnsibleUnsafeText(test_string)
    # define a vault object

# Generated at 2022-06-22 21:32:32.135890
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test 1:
    # For a sequence type object
    # 1. Given the object is a list and there is a unsafe value in it.
    # 2. Given the object is a set and there is a unsafe value in it.
    # 3. Given the object is a frozenset and there is a unsafe value in it.
    # 4. Given the object is a dictionary and there is a unsafe value in it.
    # 5. Given the object is a tuple and there is a unsafe value in it.
    # 6. Given the object is a tuple and there is no unsafe value in it.

    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    ansible_unsafe = AnsibleUnsafe('testing unsafe object')
    visit_set = set()

   

# Generated at 2022-06-22 21:32:34.145991
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    test_encoder = AnsibleJSONEncoder()
    assert test_encoder is not None

# Generated at 2022-06-22 21:32:44.983789
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import datetime
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.vars.unsafe_proxy import (
        AnsibleVaultEncryptedUnicode,
        AnsibleUnsafeText,
        AnsibleUnsafeBytes,
    )
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.module_utils.parsing.convert_bool import boolean

    class TestObject(object):
        ''' TestObject is a class that does not belong to any Ansible internal types '''
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return 'TestObject({})'.format(self.value)


# Generated at 2022-06-22 21:32:53.857676
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.text.converters import to_bytes

    json_enc = AnsibleJSONEncoder(preprocess_unsafe=True)

    # Test default method
    decoded_json = json.loads(b'{"unsafe_string": "some string"}')
    assert decoded_json["unsafe_string"] == "some string"
    input_data = {'unsafe_string': AnsibleUnsafeText('some string')}
    encoded_json = json_enc.iterencode(input_data, ensure_ascii=False)

# Generated at 2022-06-22 21:32:58.385501
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_string = json.dumps({'a':'b'})
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.iterencode(json_string) == '"{\\"a\\": \\"b\\"}"'



# Generated at 2022-06-22 21:33:06.977445
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test case 1:
    # Test case when _preprocess_unsafe = False
    # See if ansible unsafe object is not encoded
    # See if ansible vault object is not encoded
    # See if Mapping object is not encoded
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        pass
    else:
        s = 'test_iterencode'
        vault_object = VaultLib('my_secret').encrypt(s)
        unsafe_object = 'foo={{ password }}'
        json_encode_string = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(unsafe_object)
        json_encode_object = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(vault_object)
        json_encode

# Generated at 2022-06-22 21:33:18.832647
# Unit test for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:33:20.415058
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert True == isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)


# Generated at 2022-06-22 21:33:26.631459
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # test default constructor
    j = AnsibleJSONEncoder()
    assert j.check_circular is False
    assert j.ensure_ascii is True
    assert j.indent is None
    assert j.separators is (',', ':')
    assert j.sort_keys is False

    # test customized constructor
    j2 = AnsibleJSONEncoder(sort_keys=True, separators=(',', '=', ':'))
    assert j2.sort_keys is True
    assert j2.separators == (',', '=', ':')



# Generated at 2022-06-22 21:33:38.424543
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import string_types

    # Create mocked AnsibleVaultEncryptedUnicode object
    vaultLib = VaultLib([VaultSecret('ansible')])
    vaulttext = vaultLib.encrypt('secret')
    ansibleVaultEncryptedUnicode = type('AnsibleVaultEncryptedUnicode', (binary_type,), dict(__ENCRYPTED__=True, _ciphertext=vaulttext))

    # Create mocked AnsibleUnsafeText object

# Generated at 2022-06-22 21:33:44.484856
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultSecret

    encoder = AnsibleJSONEncoder()

    # test AnsibleUnsafe
    from ansible.module_utils.common.collections import AnsibleUnsafe
    unsafe_text = 'Normal text + unsafe text'
    unsafe = AnsibleUnsafe(unsafe_text)
    result = json.loads(encoder.iterencode(unsafe))
    assert result == {'__ansible_unsafe': unsafe_text}

    # test AnsibleVaultSecret
    vault_secret = VaultSecret(b'<VAULT>')
    result = json.loads(encoder.iterencode(vault_secret))
    assert result == {'__ansible_vault': vault_secret._ciphertext.decode('utf-8')}

test_AnsibleJSONEnc

# Generated at 2022-06-22 21:33:46.220968
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import  types

    assert isinstance(AnsibleJSONEncoder, types.TypeType)

if __name__ == "__main__":
    import sys, traceback
    try:
        # run AnsibleJSONEncoder unit test
        test_AnsibleJSONEncoder()
    except AssertionError:
        traceback.print_exc()
        sys.exit(1)

# Generated at 2022-06-22 21:33:54.291798
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False
    assert a.skipkeys == False
    assert a.ensure_ascii == True
    assert a.check_circular == True
    assert a.allow_nan == True
    assert a.sort_keys == False
    assert a.indent == None
    assert a.separators == (',', ':')
    assert a.encoding == 'utf-8'
    assert a.default == a.default
    assert a.iterencode == a.iterencode

# Generated at 2022-06-22 21:34:05.292489
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.errors import AnsibleError, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.vars import VariableManager
    from ansible.vars.manager import FactCache
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    inventory = InventoryManager(loader=None, sources=[])
    options = Options()
    password = 'password'
    vault = VaultLib(password)
    ds = 'test'
    inventory.add_host(host=ds)
    inventory.add_host(host='test2')
    inventory_

# Generated at 2022-06-22 21:34:08.895277
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()

    if not isinstance(a, json.JSONEncoder):
        raise Exception('AnsibleJSONEncoder does not inherit from json.JSONEncoder')



# Generated at 2022-06-22 21:34:19.394306
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves.queue import Queue

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    q = Queue()
    q.put(('foo', 1))
    # see https://docs.python.org/2/library/json.html#encoders-and-decoders
    p = json.JSONEncoder(encoding='utf-8')

# Generated at 2022-06-22 21:34:27.262150
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_json_repr = '{"foo": "__ansible_unsafe"}'
    test_dict = {'foo': '#abc'}
    assert json.dumps(test_dict, cls=AnsibleJSONEncoder) == test_json_repr, "Unsafe string representation is not transformed correctly"
    assert json.dumps(test_dict, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == test_json_repr, "Unsafe string representation is not transformed correctly in preprocess mode"


# Generated at 2022-06-22 21:34:36.472686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO

    vault_pass = u'x'
    vault_text = u'hello'

    vault_obj = VaultLib([u'--vault-password-file', u'-'], stdin=u'x').encrypt(binary_type(vault_text))
    vault_bytes = to_text(vault_obj).encode('utf-8')
    vault_obj = VaultLib([u'--vault-password-file', u'-'], stdin=u'x').decrypt(StringIO(vault_bytes))

    datetime_obj = datetime.datetime.now()


# Generated at 2022-06-22 21:34:39.666513
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ajson = AnsibleJSONEncoder()
    assert_equal(ajson.__class__.__name__, 'AnsibleJSONEncoder')

# Generated at 2022-06-22 21:34:48.664094
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type

    assert AnsibleJSONEncoder().default(42) == 42
    assert AnsibleJSONEncoder().default(42.0) == 42.0
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default("foo") == "foo"

    # Check we are returning a binary type
    assert isinstance(AnsibleJSONEncoder().default("foo"), binary_type)

    # Check we are returning a string type
    assert isinstance(AnsibleJSONEncoder().default("foo"), binary_type)

# Generated at 2022-06-22 21:34:59.912063
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters.json import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters.json import AnsibleUnsafeText
    from ansible.module_utils.common.text.converters.json import to_unicode

    test_json_sample_1 = AnsibleJSONEncoder().default('test')
    assert test_json_sample_1 == 'test'

    test_json_sample_2 = AnsibleJSONEncoder(vault_to_text=True).default(to_unicode('test', nonstring='strict'))
    assert test_json_sample_2 == u'test'


# Generated at 2022-06-22 21:35:09.538272
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    assert json.loads(to_bytes(json.dumps(dict(a=VaultLib(password='pass'), b=1), cls=AnsibleJSONEncoder)), strict=False) == {"a": {"__ansible_vault": "AQAAAAEAACJYaW5nRXhwaXJlZE1lZGlhAA=="}, "b": 1}
    # assert json.loads(to_bytes(json.dumps(dict(a=to_text(VaultLib(password='pass'), errors='surrogate_or_strict'), b=1), cls=AnsibleJSONEncoder)), strict=False) == {"a": "!vault |\n          $ANSIBLE_VA

# Generated at 2022-06-22 21:35:19.662661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    ansible_safe = 'AnsibleSafe'
    ansible_unsafe = u'AnsibleUnsafe'
    unsafe = {'type': '__ansible_unsafe',
              'value': binary_type(ansible_unsafe.encode('utf-8')).decode('utf-8'),
              'encoding': 'utf-8'}
    safe = ansible_safe
    vault = {'type': '__ansible_vault',
             'value': binary_type(ansible_unsafe.encode('utf-8')).decode('utf-8'),
             'encoding': 'utf-8'}
    date_obj = datetime.datetime(2019, 11, 1, 13, 0, 0)

# Generated at 2022-06-22 21:35:20.299516
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    pass

# Generated at 2022-06-22 21:35:29.935887
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    # Start with a simple object
    test_object1 = {'key1': 'value1', 'key2': 'value2'}
    # We will receive a generator
    encoded_data1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).iterencode(test_object1)
    # We need to iterate the generator to get the encoded data.
    encoded_data1 = list(encoded_data1)
    assert len(encoded_data1) == 1
    # And finally inspect the data

# Generated at 2022-06-22 21:35:38.726829
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Tests for preprocess_unsafe=True
    import ansible.parsing.vault
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    ansible_unsafe = AnsibleUnsafe("ansible")
    ansible_vault = ansible.parsing.vault.VaultLib("123")
    ansible_vault.decrypt("ansible")
    sample_input_dict = {
        'ansible_unsafe': ansible_unsafe,
        'ansible_vault': ansible_vault,
        'some_other_text': "some_other_text",
    }
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:35:49.594305
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from collections import OrderedDict

    # test str
    assert json.loads(json.dumps('str')) == 'str'

    # test ansible_safe
    assert json.loads(json.dumps('str', cls=AnsibleJSONEncoder)) == 'str'

    # test vault
    vault_pass = "VaultPassword"
    vault = VaultLib([u'--vault-password-file=%s' % vault_pass])
    vault_text = vault.encrypt(to_bytes('str'))

# Generated at 2022-06-22 21:35:50.191969
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert 1 == 1

# Generated at 2022-06-22 21:35:59.302078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    # vault object
    obj = ansible.parsing.vault.VaultLib('secret')
    result = AnsibleJSONEncoder().default(obj)
    assert isinstance(result, dict)
    assert result == {'__ansible_vault': 'secret'}
    result = AnsibleJSONEncoder(vault_to_text=True).default(obj)
    assert isinstance(result, str)
    assert result == 'secret'

    # unsafe object
    obj = ansible.parsing.vault.AnsibleVaultEncryptedUnicode('secret')
    result = AnsibleJSONEncoder().default(obj)
    assert isinstance(result, dict)
    assert result == {'__ansible_vault': 'secret'}
    result = Ansible

# Generated at 2022-06-22 21:36:07.096604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from __main__ import AnsibleUnsafeText
    from __main__ import AnsibleUnsafeBytes
    from __main__ import AnsibleVaultEncryptedUnsafeText
    from __main__ import AnsibleVaultEncryptedUnsafeBytes


# Generated at 2022-06-22 21:36:18.910332
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    encoded_value = vault.encode(b'MyVaultPassword')
    encoded_string = to_text(encoded_value)
    # Check when VaultLib object is present in python dict
    dict_obj = dict(stuff = [encoded_string, 'normal_string'])
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    iter_encoder = json_encoder.iterencode(dict_obj)
    list_iter_encoder = list(iter_encoder)
    str_iter_encoder = "".join(list_iter_encoder)
    assert str_iter_encoder == '{"stuff": ["' + encoded_

# Generated at 2022-06-22 21:36:22.228851
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Set ansible_vault_to_text for unit testing
    s = AnsibleJSONEncoder(vault_to_text=True)
    assert s



# Generated at 2022-06-22 21:36:32.867706
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    try:
        from ansible.parsing.vault import VaultLib
    except ImportError:
        from ansible.utils.vault import VaultLib

    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-22 21:36:37.014290
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    expected_encoder_object_type = '<class \'ansible.parsing.yaml.objects.AnsibleJSONEncoder\'>'
    encoder_object = AnsibleJSONEncoder()
    assert type(encoder_object) == type(expected_encoder_object_type)

# Generated at 2022-06-22 21:36:46.623378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # This is a unit test for AnsibleJSONEncoder.default(),
    # which handles encoders for AnsibleUnsafe and the other types mentioned
    # in the doc string of AnsibleJSONEncoder.default
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode("Test")) == {'__ansible_vault': 'Test'}
    assert AnsibleJSONEncoder().default("Test") == "Test"
    assert AnsibleJSONEncoder().default({"Dict": "Value"}) == {"Dict": "Value"}
    assert AnsibleJSONEncoder().default(datetime.datetime(year=2018, month=7, day=26)) == "2018-07-26T00:00:00"

# Generated at 2022-06-22 21:36:54.401454
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()
    assert enc._preprocess_unsafe is False
    assert enc._vault_to_text is False

    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert enc._preprocess_unsafe is True
    assert enc._vault_to_text is False

    enc = AnsibleJSONEncoder(vault_to_text=True)
    assert enc._preprocess_unsafe is False
    assert enc._vault_to_text is True

    enc = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert enc._preprocess_unsafe is True
    assert enc._vault_to_text is True

# Generated at 2022-06-22 21:37:02.958951
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text
    json_data = {"test_data":to_text("test_data")}
    json_data_expected = {"test_data":"test_data"}
    json_data_encoded = json.dumps(json_data, cls=AnsibleJSONEncoder)
    assert json_data_encoded == json.dumps(json_data_expected, cls=AnsibleJSONEncoder)
    json_data = {"test_data":VaultLib(b'test_data')}
    json_data_expected = {"test_data":{"__ansible_vault": 'test_data'}}

# Generated at 2022-06-22 21:37:11.716058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEncryptedUnicode

# Generated at 2022-06-22 21:37:22.967926
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    import json
    import pytest
    from numbers import Number
    from datetime import datetime

    #Test sample

# Generated at 2022-06-22 21:37:34.079678
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import typing
    import time
    import datetime
    import re
    import yaml
    import copy
    import ansible.module_utils.pycompat24
    iterencode = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode

    def expect(obj, expected):
        text = b''.join(iterencode(obj))
        assert json.loads(text) == expected

# $ python -m pytest tests/unit/module_utils/aenc (Windows)
# $ pytest-3 tests/unit/module_utils/aenc (Linux)
# TODO temporarily disable this test because the unsafe string can not be decoded
#    def test_AnsibleJSONEncoder_iterencode_BASESTRING():
#        BASE_STR = ansible.module_utils.pycompat24.BAS

# Generated at 2022-06-22 21:37:43.528528
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    # NOTE: Ansible avoid using '', "", None
    vault = VaultLib([('default', 'password', 1)])

# Generated at 2022-06-22 21:37:52.516605
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()

    value = {'foo': AnsibleUnsafe('bar'), 'answer': 42}
    expected_value = {'foo': {'__ansible_unsafe': 'bar'}, 'answer': 42}
    assert encoder.default(value) == expected_value

    value = [AnsibleUnsafe('bar'), AnsibleUnsafe('bar'), 42]
    expected_value = [{'__ansible_unsafe': 'bar'}, {'__ansible_unsafe': 'bar'}, 42]
    assert encoder.default(value) == expected_value

    value = 42
    assert encoder.default(value) == 42

    value = 'foo'
    assert encoder.default(value) == 'foo'




# Generated at 2022-06-22 21:38:01.032488
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault = VaultLib([])
    data = {
        'test_unsafe' : {'test_string' : vault.encrypt('test_string')}
    }
    v = json.dumps(data, cls=AnsibleJSONEncoder, indent=2)
    print(v)
    data = json.loads(v)
    print(data)
    vault_string = data['test_unsafe']['test_string']
    vault_secret = VaultSecret(vault_string.encode('utf-8'))
    print(vault.decrypt(vault_secret))

# Generated at 2022-06-22 21:38:13.285570
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from numbers import Number
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves import builtins
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 21:38:21.634930
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import MutableSequence
    
    # 1. Test with list:
    data = [1, 2, MutableSequence(is_sequence=True, elements=[1, 2, 3])]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.iterencode(data) == '[[1,2],{"__ansible_seq": [[1,2,3]]}]', "List object encoding failed"
    
    # 2. Test with dictionary:
    data = {'a': '1', 'b': MutableSequence(is_sequence=True, elements=[1, 2, 3])}
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:38:29.674065
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.common.text.formatters import to_bytes, to_text
    from ansible.module_utils.common.text.converters import to_native, to_bytes
    from ansible.module_utils.common.text.encoders import to_bytes
    from ansible.module_utils.common.text.unicode import to_unicode, to_bytes


    # Test with preprocess_unsafe=True
    # We need to create a test object that mimics the AnsibleUnsafe
    class AnsibleUnsafe(object):
        __UNSAFE__ = True
        def __init__(self, value):
            self._value = value



# Generated at 2022-06-22 21:38:37.623304
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test1 = 'test1'
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_json_encoder._preprocess_unsafe = True
    print(ansible_json_encoder._preprocess_unsafe)
    ansible_json_encoder._vault_to_text = False
    print(ansible_json_encoder._vault_to_text)
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=test1)
    ansible_json_encoder._preprocess_unsafe = test1
    print(ansible_json_encoder._preprocess_unsafe)
    ansible_json_encoder._vault_to_text = test1

# Generated at 2022-06-22 21:38:46.558271
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.dataloader import DataLoader

    tmp_dl = DataLoader()
    tmp_json_data = tmp_dl._read_data_from_file('test/base/test_json_encoder_data.json')
    tmp_json_exp = tmp_dl._read_data_from_file('test/base/test_json_encoder_exp.json')

    tmp_exp_struct = AnsibleJSONEncoder(indent=2, sort_keys=True).encode(tmp_json_exp)
    tmp_exp_struct = json.loads(tmp_exp_struct)
    tmp_act_struct = AnsibleJSONEncoder(indent=2, sort_keys=True, preprocess_unsafe=True).encode(tmp_json_data)

# Generated at 2022-06-22 21:38:57.398760
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeString

    vault_password = VaultLib()._generate_password()
    vault_secret_value = "this is a secret"

    ansible_module_json_encoder = AnsibleJSONEncoder()

    # Convert a string to a text type
    bytes_type = b'{"hello": "world"}'
    assert bytes_type == ansible_module_json_encoder._encode_basestring(bytes_type)
    assert bytes_type == ansible_module_json_encoder._encode_basestring(str(bytes_type))

# Generated at 2022-06-22 21:39:09.217363
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test with ansible_unsafe
    class AnsibleUnsafe:
        __UNSAFE__ = True
        value = 'unsafe'
        def __repr__(self):
            return '<Ansible unsafe: %s>' % self.value
        def __str__(self):
            return self.value
    json_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True).encode(AnsibleUnsafe())
    assert json_unsafe == '{"__ansible_unsafe": "unsafe"}'
    unsafe_obj = json.loads(json_unsafe)
    assert isinstance(unsafe_obj, Mapping)

    json_unsafe = AnsibleJSONEncoder(preprocess_unsafe=False).encode(AnsibleUnsafe())

# Generated at 2022-06-22 21:39:17.239146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.connection import Connection
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping

    safe_str = 'safe_str is not a AnsibleUnsafe and not a AnsibleVault'
    unsafe_str = b'unsafe_str is not a AnsibleUnsafe and not a AnsibleVault'
    unsafe_str1 = u'unsafe_str is not a AnsibleUnsafe and not a AnsibleVault'
    ansible_unsafe = Connection(unsafe_str)
    ansible_unsafe1 = Connection(unsafe_str1)
    ansible_vault = VaultLib

# Generated at 2022-06-22 21:39:28.991861
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    unsafe_list = [
        wrap_var(1),
        wrap_var('test'),
        wrap_var(1),
    ]
    unsafe_dict = dict(
        number=wrap_var(2),
        string=wrap_var('test2'),
        number2=wrap_var(2),
        list=wrap_var(unsafe_list),
    )

    aje = AnsibleJSONEncoder(preprocess_unsafe=True)
    list_encode = aje.encode(unsafe_list)
    list_encode_decode = aje.decode(list_encode)

# Generated at 2022-06-22 21:39:40.463349
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    dict = {}
    dict["ansible_string"] = "Ansible string"
    dict["python_string"] = "python string"
    dict["unicode_safe"] = u"unicodeΩΩ"
    dict["object_unsafe_obj"] = "object_unsafe_obj"
    dict["object_unsafe"] = "object_unsafe"
    dict["object_vault"] = "object_vault"
    dict["object_vault_obj"] = "object_vault_obj"
    dict["dict"] = {"subdict_key": "subdict_value"}


# Generated at 2022-06-22 21:39:50.717728
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.connection import ConnectionError, Connection
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    def _is_unsafe(value):
        return getattr(value, '__UNSAFE__', False) and not getattr(value, '__ENCRYPTED__', False)

    def _is_vault(value):
        return getattr(value, '__ENCRYPTED__', False)

    def _preprocess_unsafe_encode(value):
        """Recursively preprocess a data structure converting instances of ``AnsibleUnsafe``
        into their JSON dict representations

        Used in ``JsonEncoder.iterencode``
        """

# Generated at 2022-06-22 21:40:00.178815
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib

    secret_data = VaultLib().encrypt('my secret data')

    def __unsafe__(value):
        return value

    def __encrypted__(value):
        return value

    unsafe_data = __unsafe__('my unsafe data')
    unsafe_encrypted_data = __unsafe__('my unsafe encrypted data')
    encrypted_data = __encrypted__('my encrypted data')


# Generated at 2022-06-22 21:40:12.502933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.collections import is_sequence

    TEST_VAR = 'TEST_VAR'
    TEST_USER = 'TEST_USER'
    TEST_PASSWORD = 'TEST_PASSWORD'

    vault = VaultLib(password_file=None)
    vault_text = vault.encode(TEST_VAR)

    dt = datetime.datetime(2019,12,19,21,20,34,789678)


# Generated at 2022-06-22 21:40:21.850078
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    data = encoder.default(b"foo")
    assert data == "foo"
    data = encoder.default(u"bar")
    assert data == "bar"
    data = encoder.default([1, 2])
    assert data == [1, 2]
    data = encoder.default({1: "baz"})
    assert data == {1: "baz"}
    data = encoder.default(datetime.date(2000, 1, 1))
    assert data == "2000-01-01"
    data = encoder.default(datetime.datetime(2000, 1, 1, 0, 0, 0))
    assert data == "2000-01-01T00:00:00"

# Generated at 2022-06-22 21:40:26.579892
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False
