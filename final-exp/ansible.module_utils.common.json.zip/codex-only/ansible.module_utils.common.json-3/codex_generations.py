

# Generated at 2022-06-22 21:30:27.253560
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_test = AnsibleJSONEncoder()
    assert ansible_test is not None


# Generated at 2022-06-22 21:30:28.214669
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # To be implemented
    pass



# Generated at 2022-06-22 21:30:35.959788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = {
        'a': 1,
        'b': '2',
        'c': {
            'd': '3',
            'e': 4,
            'f': datetime.date(2018, 4, 1),
            'g': datetime.datetime(2018, 4, 1, 7, 0, 1),
        },
    }

    json.dumps(value, cls=AnsibleJSONEncoder)



# Generated at 2022-06-22 21:30:43.379451
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansiblejson_encoder = AnsibleJSONEncoder()
    assert ansiblejson_encoder._preprocess_unsafe == False
    assert ansiblejson_encoder._vault_to_text == False
    ansiblejson_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansiblejson_encoder._preprocess_unsafe == True
    assert ansiblejson_encoder._vault_to_text == False
    ansiblejson_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert ansiblejson_encoder._preprocess_unsafe == False
    assert ansiblejson_encoder._vault_to_text == True
    ansiblejson_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
   

# Generated at 2022-06-22 21:30:53.945298
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_value1 = {
        'name': 'john doe',
        'age': 23
    }
    test_value2 = ['john doe', 23]
    test_value3 = 'john doe'
    test_value4 = 23
    test_value5 = datetime.datetime.now()

    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder.default(test_value1) == {'name': 'john doe', 'age': 23}
    assert ansible_encoder.default(test_value2) == ['john doe', 23]
    assert ansible_encoder.default(test_value3) == 'john doe'
    assert ansible_encoder.default(test_value4) == 23

# Generated at 2022-06-22 21:31:05.859313
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import binary_type

    # test normal encoding
    s = {'a': 'b', 'c': 'd'}
    ans_obj = AnsibleJSONEncoder(preprocess_unsafe=False)
    ret_list = list(ans_obj.iterencode(s))
    assert ret_list == ['{', '"a"', ':', '"b"', ',', '"c"', ':', '"d"', '}']

    # test encoding of single AnsibleUnsafe object
    from ansible.module_utils.common._collections_compat import AnsibleUnsafe
    s = {'a': 'b', 'c': AnsibleUnsafe('d')}
    ans_obj = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:31:11.217312
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder_default = AnsibleJSONEncoder()
    assert ansible_json_encoder_default.ensure_ascii is True
    assert ansible_json_encoder_default.indent is None
    assert ansible_json_encoder_default.separators is (',', ':')
    assert ansible_json_encoder_default.sort_keys is False
    assert ansible_json_encoder_default.skipkeys is False

# Generated at 2022-06-22 21:31:12.430255
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    print(AnsibleJSONEncoder())

# Generated at 2022-06-22 21:31:13.254424
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()


# Generated at 2022-06-22 21:31:24.235818
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vault_pass = "vault_pass"
    plain_text = "text"

    vault_secret = VaultSecret(vault_pass.encode())
    vault = VaultLib([(vault_secret, 1)])
    plain_text_b = to_bytes(plain_text, encoding='utf-8', nonstring='passthru')
    tokenized = vault.encrypt(plain_text_b)

    assert tokenized.__ENCRYPTED__ == True

    JSONEncoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:31:33.882203
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import wrap_var
    origin_o = {'key': 'value', 'key_safe': wrap_var('value_safe', __UNSAFE__=True)}
    o = origin_o.copy()
    expect_o = {'key': 'value', 'key_safe': {'__ansible_unsafe': 'value_safe'}}
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    encode_o = json_encoder.iterencode(o)
    assert o == origin_o
    assert expect_o == json.loads(encode_o)

# Generated at 2022-06-22 21:31:44.838430
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps(dict(a=1), cls=AnsibleJSONEncoder) == '{"a": 1}'
    assert json.dumps(dict(a=AnsibleUnsafe('example')), cls=AnsibleJSONEncoder) == '{"a": "example"}'
    assert json.dumps(dict(a=datetime.datetime(year=2019, month=2, day=3, hour=4, minute=5, second=6)), cls=AnsibleJSONEncoder) == \
        '{"a": "2019-02-03T04:05:06"}'
    assert json.dumps(dict(a=datetime.date(year=2019, month=2, day=3)), cls=AnsibleJSONEncoder) == '{"a": "2019-02-03"}'
   

# Generated at 2022-06-22 21:31:49.435033
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(vault_to_text=True)
    assert AnsibleJSONEncoder(vault_to_text=False)



# Generated at 2022-06-22 21:32:00.034523
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import datetime
    import os
    import sys


    # Prepare input data to be encoded

# Generated at 2022-06-22 21:32:12.333523
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    encoder = AnsibleJSONEncoder()

    # test string
    value = 'string'
    result = encoder.default(value)
    assert result == value
    assert isinstance(result, string_types)

    # test list
    value = ['string1', 'string2']
    result = encoder.default(value)
    assert result == value
    assert isinstance(result, list)
    assert isinstance(result[0], string_types)
    assert isinstance(result[1], string_types)

    # test dict
    value = {'key1': 'string1', 'key2': 'string2'}
    result = encoder.default(value)
    assert result == value
   

# Generated at 2022-06-22 21:32:24.455384
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    # Some test data in two forms
    #  (1) object with properties
    #  (2) object with properties and additional items

# Generated at 2022-06-22 21:32:34.803716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass:
        def __init__(self, a):
            self.a = a

    test_case = [
        # test_json, test_obj, test_result
        ('{"b": 2}', {'b': 2}, True),
        ('["an","array"]', ["an", "array"], True),
        ('{"a": "1"}', TestClass(1), True),
        ('{"a": "1"}', {'a': TestClass(1)}, True),
        ('{"a": "1"}', {'a': 1}, True),
        ('{"a": "1"}', AnsibleJSONEncoder(), False),
    ]


# Generated at 2022-06-22 21:32:45.649174
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib;
    try:
        # We will test the iterencode method of AnsibleJSONEncoder only
        # when there is a vault secret text file available
        v = VaultLib(filename='../../test/test.txt', password='test')
        isVaultSecret = True
        print("INFO: A vault secret file is present")
    except:
        isVaultSecret = False
        print("ERROR: No vault secret file present")
        print("Hint: create a test.txt file containing the vault password.")
        return

    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.six import text_type

# Generated at 2022-06-22 21:32:50.877921
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ''' test_AnsibleJSONEncoder()

    This unit test just verifies that the constructor for the AnsibleJSONEncoder
    class is working.
    '''
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert aje._preprocess_unsafe == False
    assert aje._vault_to_text == False


# Generated at 2022-06-22 21:33:03.176463
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    encoder = AnsibleJSONEncoder()
    cases = [
        ("test_str", "test_str"),
        (u"test_unicode", u"test_unicode"),
        (text_type(b"test_str_as_unicode", encoding='utf-8'), u"test_str_as_unicode"),
        (b"test_byte_type", u"test_byte_type"),
        ({"test_key": "test_value"}, {"test_key": "test_value"})
    ]

    # Vault
    vault = VaultLib({"ANSIBLE_VAULT_IDENTITY_LIST": [], "ANSIBLE_VAULT_PASSWORD_FILE": []})

# Generated at 2022-06-22 21:33:14.661395
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import json

    a = [[[{u"dict": AnsibleUnsafeText(u"a { 'test': '1'  call")}, 1, 2, 3], 4, 5, 6], 7, 8, 9]
    b = {"dict": AnsibleUnsafeText(u"a { 'test': '1'  call")}

    expected_output1 = " [[[{u'dict': {u'__ansible_unsafe': u'a { 'test': '1'  call'}}, 1, 2, 3], 4, 5, 6], 7, 8, 9]"
    expected_output2 = " {u'dict': {u'__ansible_unsafe': u'a { 'test': '1'  call'}}"

    json_encoder

# Generated at 2022-06-22 21:33:26.274474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default({}) == {}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default({}) == {}

    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(u'a') == 'a'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).default(u'a') == 'a'

    class crypto:
        _CIPHERTEXT = 'a'
        def __unicode__(self):
            return u'b'

        __ENCRYPTED = True


# Generated at 2022-06-22 21:33:31.986833
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=True,
                              vault_to_text=True,
                              sort_keys=False,
                              indent=4,
                              separators=(',', ': '),
                              ensure_ascii=True)

# Generated at 2022-06-22 21:33:40.736550
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def get_json_dump_with_default(obj, loader, dumper):
        return json.dumps(obj, cls=loader, indent=2, sort_keys=True, default=dumper.default)

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText

    encrypted_text = 'foo'
    vault = VaultLib([])
    vault_text = vault.encrypt(encrypted_text)
    vault_text_encrypted = vault.encrypted_data(encrypted_text)

    # Test encrypted_text
    assert encrypted_text == json.loads(get_json_dump_with_default(encrypted_text, AnsibleJSONEncoder, AnsibleJSONEncoder(vault_to_text=True)))

    # Test vault_text

# Generated at 2022-06-22 21:33:52.488107
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    j = '{"__ansible_vault": "__ansible_vault"}'
    s = '{"__ansible_unsafe": "unsafe"}'
    v = b'{"__ansible_vault": "__ansible_vault"}'
    u = b'{"__ansible_unsafe": "unsafe"}'

    assert json.loads(j) == AnsibleJSONEncoder().default(AnsibleJSONUnsafeVaultSecret(b'__ansible_vault'))
    assert json.loads(s) == AnsibleJSONEncoder().default(AnsibleJSONUnsafeText(b'unsafe'))

    assert json.loads(j) == AnsibleJSONEncoder(False).encode(AnsibleJSONUnsafeVaultSecret(b'__ansible_vault'))

# Generated at 2022-06-22 21:34:03.611959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Returns a JSON string representation of a Python data structure.
    """
    assert '"__ansible_vault"' in json.dumps(object(), cls=AnsibleJSONEncoder)
    assert '"__ansible_unsafe"' in json.dumps(object(), cls=AnsibleJSONEncoder)
    assert '"__ansible_vault"' in json.dumps(object(), cls=AnsibleJSONEncoder, vault_to_text=True)
    assert '"__ansible_unsafe"' in json.dumps(object(), cls=AnsibleJSONEncoder, vault_to_text=True)
    assert '"__ansible_vault"' not in json.dumps(object(), cls=AnsibleJSONEncoder, vault_to_text=False)

# Generated at 2022-06-22 21:34:11.419010
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    assert json.loads(json.dumps(1, cls=AnsibleJSONEncoder)) == 1
    assert json.loads(json.dumps(1, cls=AnsibleJSONEncoder, preprocess_unsafe=True)) == 1
    assert json.loads(json.dumps('normal string', cls=AnsibleJSONEncoder)) == 'normal string'
    assert json.loads(json.dumps('normal string', cls=AnsibleJSONEncoder, preprocess_unsafe=True)) == 'normal string'

    assert json.loads(json.dumps(AnsibleUnsafe('unsafe string'), cls=AnsibleJSONEncoder)) == 'unsafe string'

# Generated at 2022-06-22 21:34:20.563878
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # create an ansible unsafe object
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-22 21:34:29.714714
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    This is a unit test for constructor of class AnsibleJSONEncoder.
    It does not test the encoding of AnsibleUnsafe.
    """
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.collections import AnsibleMapping

    def _check_encode_vault(encode_func, vault_to_text):
        if vault_to_text:
            assert encode_func(VaultSecret('some secret')) == '"some secret"'
        else:
            assert encode_func(VaultSecret('some secret')) == '{"__ansible_vault": "some secret"}'

    def _check_encode_unsafe(encode_func, preprocess_unsafe):
        if preprocess_unsafe:
            assert encode_func('some secret')

# Generated at 2022-06-22 21:34:40.927827
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic

    #
    # test date and datetime
    #
    o = datetime.date(year=2018, month=7, day=28)
    value = AnsibleJSONEncoder().default(o)
    assert value == "2018-07-28"

    o = datetime.datetime(year=2018, month=7, day=28, hour=23, minute=49)
    value = AnsibleJSONEncoder().default(o)
    assert value == "2018-07-28T23:49:00"

    #
    # test mapping
    #
    o = ansible.module_utils.basic.AnsibleModule(argument_spec=dict(
        x=dict(type='int', default=1),
        y=dict(type='str', default='2')
    ))

# Generated at 2022-06-22 21:34:46.964234
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(dict(foo='bar'), cls=AnsibleJSONEncoder)) == dict(foo='bar')
    assert json.loads(json.dumps(dict(foo=['one', 'two']), cls=AnsibleJSONEncoder)) == dict(foo=['one', 'two'])
    assert json.loads(json.dumps(dict(foo=dict(one='two')), cls=AnsibleJSONEncoder)) == dict(foo=dict(one='two'))

# Generated at 2022-06-22 21:34:58.262740
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.basic import AnsibleUnsafeText
    import collections

    ansible_unsafe_obj = AnsibleUnsafeText('foo')

    assert '__ansible_vault' not in json.dumps(ansible_unsafe_obj, cls=AnsibleJSONEncoder)

    # json.JSONEncoder call super(AnsibleJSONEncoder, self).iterencode(o, **kwargs)
    # so get data like '[null]', '[true]', etc.
    json_encoder = json.JSONEncoder()
    assert '[' in json_encoder.iterencode(ansible_unsafe_obj, **dict())
    assert 'null' == json.dumps(None, cls=json.JSONEncoder)


# Generated at 2022-06-22 21:35:03.780062
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = AnsibleJSONEncoder()
    s = u'\u5317\u4eb0'
    assert a.default(s) == '北亰'
    assert a.default(u'foobar') == 'foobar'
    assert a.default(u"") == ""
    assert a.default({1:2}) == {1:2}


# Generated at 2022-06-22 21:35:14.021263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleUnsafe

    assert '"2017-07-13T13:41:03.056834"' == AnsibleJSONEncoder().default(datetime.datetime(2017, 7, 13, 13, 41, 3, 56384))
    assert '0' == AnsibleJSONEncoder().default(0)
    assert '"This is an unsafe string"' == json.dumps(AnsibleUnsafe('This is an unsafe string'), cls=AnsibleJSONEncoder)
    assert '{"key": "value", "key2": "value2"}' == json.dumps(ImmutableDict(key='value', key2='value2'), cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:35:17.239042
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    print(AnsibleJSONEncoder())
    print(AnsibleJSONEncoder(preprocess_unsafe=True))
    print(AnsibleJSONEncoder(vault_to_text=True))

# Generated at 2022-06-22 21:35:18.426282
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
	assert AnsibleJSONEncoder(False , False)

# Generated at 2022-06-22 21:35:24.493916
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ansible_json_encoder._preprocess_unsafe == True
    assert ansible_json_encoder._vault_to_text == True

# Generated at 2022-06-22 21:35:33.638164
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ans_json_encoder = AnsibleJSONEncoder()
    ans_json_encoder._vault_to_text = True
    date2 = datetime.date(9, 8, 18)

# Generated at 2022-06-22 21:35:44.613569
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # test vault object
    vault = VaultLib([])
    vault_secret = vault.encrypt(b"Hello world")
    assert vault_secret.__class__.__name__ == 'VaultSecret'

# Generated at 2022-06-22 21:35:56.544115
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText

    # Test for string
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode('abc')) == ['"abc"']

    # Test for AnsibleUnsafeText
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(AnsibleUnsafeText('abc'))) == ['{"__ansible_unsafe": "abc"}']

    # Test for dict
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(
        {'var': 'value',
         'abc': AnsibleUnsafeText('abc')})) == ['{"abc": {"__ansible_unsafe": "abc"}, "var": "value"}']

    # Test for list

# Generated at 2022-06-22 21:36:01.958488
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test init
    encoder = AnsibleJSONEncoder()
    encoder = AnsibleJSONEncoder(indent=2)
    encoder = AnsibleJSONEncoder(separators=(' ', ':'))
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    # Test the default() method
    date = json.loads(encoder.encode({"date": datetime.datetime(2019, 1, 1, 12, 0, 0)}))
    assert date.get('date') == "2019-01-01T12:00:00"

# Generated at 2022-06-22 21:36:11.178135
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    obj = {'foo': 'bar', 'baz': AnsibleUnsafeText('foobar')}
    result = list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(obj))
    assert result == [
        text_type('{'),
        text_type('"foo": "'), text_type('bar'), text_type('", '),
        text_type('"baz": '),
        text_type('{"__ansible_unsafe": '), text_type('"foobar"'), text_type('}'),
        text_type('}')
    ]

# Generated at 2022-06-22 21:36:13.307127
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Unit test for constructor of class AnsibleJSONEncoder
    AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-22 21:36:19.779237
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test_AnsibleJSONEncoder_init_noargs_default_values
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

    # test_AnsibleJSONEncoder_init_args_override_default_values
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-22 21:36:26.583635
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  from ansible.parsing.vault import VaultLib
  from ansible.parsing.vault import VaultSecret
  vault_secret = VaultSecret("MySecret", "myvaultid")
  vault_lib = VaultLib(vault_secret)
  encc = vault_lib.encode("test mytest")
  enc = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
  ret = enc.encode({"name": "ansible.parsing.vault.VaultSecret", "value": encc})

# Generated at 2022-06-22 21:36:37.290894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    vault_password = 'blah'
    vault_secrets = {
        'https://github.com/': VaultSecret('blah'),
        'https://username:blah@github.com/': VaultSecret('blah'),
        'https://username:blah:8080@github.com/': VaultSecret('blah'),
    }
    vault_lib = VaultLib(vault_secrets, vault_password, ['!vault'])

    o = {'key1': 'value1', 'key2': VaultUnsafeText(vault_lib)}

# Generated at 2022-06-22 21:36:40.251717
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False

# Generated at 2022-06-22 21:36:50.320285
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # AnsibleUnsafe
    import ansible.parsing.vault
    o = ansible.parsing.vault.VaultLib([])
    o.decrypt('$ANSIBLE_VAULT;1.1;AES256\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n')
    assert AnsibleJSONEncoder().default(o) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n'}

    # Mapping
    o = {'a': '1', 'b': '2'}
    assert AnsibleJSONEncoder().default(o)

# Generated at 2022-06-22 21:36:58.358415
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    def _make_obj():
        unsafe1 = AnsibleUnsafe('123')
        unsafe2 = AnsibleUnsafe('456')

        vault1 = AnsibleVault('123')
        vault2 = AnsibleVault('456')

        s = json.dumps([[[unsafe1, unsafe2], [vault1, vault2], 'test']])
        return json.loads(s)

    def _compare(obj):

        assert is_sequence(obj)
        assert is_sequence(obj[0])
        assert is_sequence(obj[0][0])

        assert isinstance(obj[0][0][0], Mapping)
        assert isinstance

# Generated at 2022-06-22 21:37:04.460485
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import textwrap

    a = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    b = {'key4': 'value4', 'key5': 'value5', 'key6': 'value6'}
    c = {'a': a, 'b': b}
    d = {'c': c, 'd': 'value7'}

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_string = json.dumps(d, cls=ansible_json_encoder)


# Generated at 2022-06-22 21:37:15.106906
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Tests ``iterencode`` method of ``AnsibleJSONEncoder``
    :returns: True if successful, else False
    """

    # import locally to ensure that method iterencode gets tested when this method is called
    try:
        from ansible.parsing import vault
    except ImportError:
        return False

# Generated at 2022-06-22 21:37:19.144335
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    assert json_encoder._preprocess_unsafe == True
    assert json_encoder._vault_to_text == True

# Generated at 2022-06-22 21:37:30.016367
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.module_utils.six import text_type

    import sys
    import json
    if sys.version_info[0] < 3:
        assert repr(list(AnsibleJSONEncoder().iterencode(None))) == "['null']"
    else:
        assert repr(list(AnsibleJSONEncoder().iterencode(None))) == "[b'null']"

    # check string
    assert repr(list(AnsibleJSONEncoder().iterencode(u'Hello'))) == "['Hello']"

# Generated at 2022-06-22 21:37:36.378762
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == True


# Generated at 2022-06-22 21:37:47.671372
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import json

    if (sys.version_info.major < 3) or ((sys.version_info.major == 3) and (sys.version_info.minor < 5)):
        from ansible.module_utils._text import to_native, to_bytes
    else:
        from ansible.module_utils._text import to_native

    from ansible.module_utils.common.text_utils import strip_internal_keys
    from collections import OrderedDict
    from ansible.vars import AnsibleUnsafeText


# Generated at 2022-06-22 21:37:58.920356
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    # Simulating input value
    o = [AnsibleUnsafeText(b'\xd2'), b'\xd2', AnsibleVaultEncryptedUnicode(b'\xd2'), OrderedDict([('b', {'c': [{'d': AnsibleUnsafeText(b'\xd2')}, b'\xd2']}), ('a', {'c': [{'d': AnsibleVaultEncryptedUnicode(b'\xd2')}, b'\xd2']})]), Sequence(b'\xd2')]

# Generated at 2022-06-22 21:38:00.525945
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  # Making sure the constructor of class AnsibleJSONEncoder is called
  # without any error
  assert AnsibleJSONEncoder()

# Generated at 2022-06-22 21:38:12.755530
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_dict = {"key1": "value1", "key2": "value2"}
    test_list = ["value1", "value2", "value3"]
    test_tuple = ("value1", "value2", "value3")
    test_set = {"value1", "value2", "value3"}
    test_date = datetime.date(year=2017, month=12, day=21)
    test_datetime = datetime.datetime(year=2017, month=12, day=21, hour=13, minute=45, second=21)

    encoder = AnsibleJSONEncoder()
    assert encoder.default(test_dict) == test_dict
    assert encoder.default(test_list) == test_list

# Generated at 2022-06-22 21:38:21.351180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json

    # test None
    assert None == json.loads(json.dumps(None, cls=AnsibleJSONEncoder))

    # test simple types
    assert True == json.loads(json.dumps(True, cls=AnsibleJSONEncoder))
    assert 1 == json.loads(json.dumps(1, cls=AnsibleJSONEncoder))
    assert 1.1 == json.loads(json.dumps(1.1, cls=AnsibleJSONEncoder))
    assert "test" == json.loads(json.dumps("test", cls=AnsibleJSONEncoder))

    # test list
    assert [1, 2, 3] == json.loads(json.dumps([1, 2, 3], cls=AnsibleJSONEncoder))

    # test dict with simple types

# Generated at 2022-06-22 21:38:24.306484
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # TODO: test only when ansible.module_utils.basic.AnsibleModule is available
    pass

# Generated at 2022-06-22 21:38:27.035096
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_str = 'test_str'
    encoder = AnsibleJSONEncoder()
    assert encoder.encode(test_str) == '"test_str"'

# Generated at 2022-06-22 21:38:34.462652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    obj = VaultLib([])
    # Some test cases
    obj_value = obj.encrypt('sekret')
    expected_value = '__ansible_unsafe'
    # Perform the test
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    actual_value = encoder.default(obj_value)
    assert expected_value in actual_value
    assert actual_value['__ansible_unsafe'] == "sekret"


# Generated at 2022-06-22 21:38:40.152980
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    util = AnsibleJSONEncoder()
    assert util.default(AnsibleUnsafe('{ "foo": "bar" }')) == {'__ansible_unsafe': u'{ "foo": "bar" }'}

# Generated at 2022-06-22 21:38:47.702582
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:38:57.893778
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class AnsibleUnsafe(object):
        """
        If a string has this special attribute set to true, then it is
        considered unsafe.
        """
        def __init__(self, data):
            self.data = data

        @property
        def __UNSAFE__(self):
            return True

    encoder = AnsibleJSONEncoder()

    # test for default
    assert encoder.default([]) == []
    assert encoder.default((1, 2, 3,)) == [1, 2, 3]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(1) == 1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(True) == True
    assert encoder.default(None) == None

    # test

# Generated at 2022-06-22 21:39:09.660602
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import sys
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError

    dl = DataLoader()
    try:
        vault_pass = dl.get_vault_password("", None, "", 0, 6, False)
    except AnsibleError as e:
        sys.stderr.write("Failed to get vault password: {}".format(e))
        sys.exit(1)

    vault = VaultLib(vault_pass)
    unsafe = AnsibleUnsafe('unsafe_string')
    encrypted = vault.encrypt(unsafe.encode('utf-8'))


# Generated at 2022-06-22 21:39:20.710108
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_text = to_text('{', errors='surrogate_or_strict')
    ansible_unsafe_text.__UNSAFE__ = True

    ansible_vault_text = to_text('{', errors='surrogate_or_strict')
    ansible_vault_text.__ENCRYPTED__ = True

    ansible_unsafe_bytes = to_text('{', errors='surrogate_or_strict')
    ansible_unsafe_bytes.__UNSAFE__ = True

    ansible_vault_bytes = to_text('{', errors='surrogate_or_strict')
    ansible_vault_bytes.__ENCRYPTED__ = True


# Generated at 2022-06-22 21:39:29.639260
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    r = []
    for k, v in [
        ('a', dict(a=1, b=2)),
        ('b', dict(b=1, a=2)),
        ('c', dict(c=1, d=2)),
        ('d', dict(c=1, a=2)),
    ]:
        r.append((k, v, json.dumps(v, cls=AnsibleJSONEncoder)))

    for x in r:
        print(x[0], x[1], x[2], r[0][2] == x[2])

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-22 21:39:41.133455
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

    # Unicode
    # The variable is converted to ansible_safe by the to_unicode method, and then converted to a normal string.
    json_str = json.dumps(to_unicode('some string'), cls=AnsibleJSONEncoder, sort_keys=True)
    json_str = json.loads(json_str)
    assert json_str == 'some string'

    # Bytes
    # The variable is converted to ansible_safe by the to_bytes method, and then converted to a normal string.

# Generated at 2022-06-22 21:39:51.161550
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import wrap_var_with_vault_secrets

    salt = VaultLib.generate_random_salt()
    passphrase = 'ansible'
    plaintext = 'value'
    encrypted_text = VaultLib.encrypt(to_text(plaintext, errors='surrogate_or_strict'), passphrase, salt=salt, cipher_name='aes256')
    unsafe_text = wrap_var(plaintext)

# Generated at 2022-06-22 21:39:58.673400
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    import base64
    a = VaultLib('secret_value')
    b64 = base64.b64encode('secret_value')
    ansible_vault_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    ansible_vault_json_encoder.default(a)
    ansible_vault_json_encoder.default(b64)
    if ansible_vault_json_encoder:
        assert True
    else:
        assert False

# Generated at 2022-06-22 21:40:05.739006
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    import ansible.parsing.yaml.objects as objects

    # Safe text
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert list(encoder.iterencode('test_text')) == ['test_text']

    # Safe number
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert list(encoder.iterencode(42)) == [42]

    # Safe dict
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert list(encoder.iterencode({'test_dict': 'foo'})) == [{'test_dict': 'foo'}]

    # Safe list

# Generated at 2022-06-22 21:40:17.010570
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.vault_util import VaultSecret

    # create a VaultSecret object with vault text

# Generated at 2022-06-22 21:40:22.406328
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # simple test
    a = b = {'foo': 1, 'bar': 2}
    assert a == b

    # complex test
    a = {
        'foo': {'foo': 1, 'bar': 2},
        'bar': {'foo': 1, 'bar': 2},
    }
    b = {
        'foo': {'foo': 1, 'bar': 2},
        'bar': {'foo': 1, 'bar': 2},
    }
    assert a == b

    # test value is sequence
    a = b = [{'foo': 1, 'bar': 2}, {'foo': 1, 'bar': 2}]
    assert a == b

    # test value is datetime object
    a = b = datetime.datetime(2019, 4, 1, 11, 30, 45, 544000)


# Generated at 2022-06-22 21:40:34.385178
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    import json

    encoder = AnsibleJSONEncoder()
    assert(json.dumps({"foo": "bar"}, cls=encoder) == '{"foo": "bar"}')
    assert(json.dumps([1, 2, 3], cls=encoder) == '[1, 2, 3]')
    assert(json.dumps([], cls=encoder) == '[]')
    assert(json.dumps({"foo": "Vault does not support mapping values"}, cls=encoder) == '{"foo": "Vault does not support mapping values"}')