

# Generated at 2022-06-22 21:30:25.328673
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test the constructor for AnsibleJSONEncoder
    # input 0
    preprocess_unsafe = False
    vault_to_text = False
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe, vault_to_text)
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False
    # input 1
    preprocess_unsafe = True
    vault_to_text = True
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe, vault_to_text)
    assert ansible_json_encoder._preprocess_unsafe == True
    assert ansible_json_encoder._vault_to_text == True


# Generated at 2022-06-22 21:30:37.291897
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    import sys

    # Only Python >= 3.6 will return a string when doing JSON encoding
    if sys.version_info.major >= 3 and sys.version_info.minor >= 6:
        encoder_returns_str = True
    else:
        encoder_returns_str = False

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

# Generated at 2022-06-22 21:30:44.385996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    res = AnsibleJSONEncoder().default({"name": "test", "secret": "test", "other": "test"})
    assert res == {"name": "test", "secret": "test", "other": "test"}
    assert json.loads(json.dumps(res, cls=AnsibleJSONEncoder)) == {"name": "test", "secret": "test", "other": "test"}



# Generated at 2022-06-22 21:30:51.588266
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.vars.unsafe_proxy import wrap_var, AnsibleUnsafeText, AnsibleUnsafeBytes
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True)
    json_bytes = b'{"a": {"__ansible_unsafe": "\\u03b1"}}'
    json_str = json_bytes.decode('ascii')

    result = encoder.iterencode(wrap_var({'a': wrap_var(u'\u03b1')}))
    assert is_sequence(result)
    assert next(result) == json_bytes
    assert next(result) == b''


# Generated at 2022-06-22 21:31:03.300536
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.safe_dump import safe_dump


# Generated at 2022-06-22 21:31:08.818132
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(
        False, False, skipkeys=True, ensure_ascii=True,
        check_circular=True, allow_nan=True, sort_keys=True,
        indent=4, separators=(',', ': '), encoding="utf-8",
        default=None, sort_keys=True)

# Generated at 2022-06-22 21:31:16.644403
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # test case 1
    # AnsibleUnsafe class
    class AnsibleUnsafe:
        __slots__ = ('_text', )

        def __init__(self, text):
            self._text = text

        def __UNSAFE__(self):
            return True

        def __bool__(self):
            return True

        def __nonzero__(self):
            return True

        def __repr__(self):
            return 'ansible_unsafe_wrapped:%s' % repr(self._text)

        def __str__(self):
            return str(self._text)

        def __getattr__(self, name):
            return getattr(self._text, name)


    # test case 2
    # inventory hostvars, inheritance of dict class

# Generated at 2022-06-22 21:31:26.539370
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    unsafe_str_src = '#!/usr/bin/env python\n'
    unsafe_str = AnsibleUnsafe(unsafe_str_src)
    unsafe_str_encoded = encoder.default(unsafe_str)
    assert unsafe_str_encoded == {'__ansible_unsafe': unsafe_str_src}


# Generated at 2022-06-22 21:31:35.195615
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()
    data = {
        'name' : 'value',
        'time' : datetime.datetime(2013, 6, 3, 12, 30),
        'time2' : datetime.date(2013, 6, 3),
        'isTrue': True,
    }
    result = json.dumps(data, cls=AnsibleJSONEncoder)
    expected = {"time": "2013-06-03T12:30:00", "time2": "2013-06-03", "isTrue": True, "name": "value"}
    assert json.loads(result) == expected

# Generated at 2022-06-22 21:31:42.660746
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test cases
    tests = [
        # data, expected
        ('hello, world', 'hello, world'),
        (b'hello, world', 'hello, world'),
        (u'hello, world', 'hello, world'),
        (123, 123),
        (True, True),
        (False, False),
        (None, None),
    ]

    encoder = AnsibleJSONEncoder()
    for data, expected in tests:
        assert encoder.default(data) == expected

# Generated at 2022-06-22 21:31:45.170249
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default('test') == 'test'


# Generated at 2022-06-22 21:31:47.508888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    assert e.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()

# Generated at 2022-06-22 21:31:49.531155
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = 'test'
    enc = AnsibleJSONEncoder()
    assert enc.default(data) == data

# Generated at 2022-06-22 21:32:00.124799
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    # test AnsibleUnsafe
    result1 = json.dumps(AnsibleUnsafe("I am unsafe"), cls=AnsibleJSONEncoder)
    assert result1 == '{"__ansible_unsafe": "I am unsafe"}'

    # test AnsibleVaultEncrypted
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    result2 = json.dumps(vault.encrypt("I am encrypted"), cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:32:03.098531
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    assert aje.__class__.__name__ == "AnsibleJSONEncoder"

# Generated at 2022-06-22 21:32:14.037810
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test string
    s = 'test'
    assert json.dumps(s, cls=AnsibleJSONEncoder, ensure_ascii=False) == '"test"'

    # Test dict with unsafe and safe values
    v = {'unsafe': 'unsafe', 'safe': 'safe'}
    r = json.dumps(v, cls=AnsibleJSONEncoder, ensure_ascii=False)
    assert r == '{"safe": "safe", "unsafe": "unsafe"}'
    # Test dict with all unsafe values
    v = {'unsafe': 'unsafe', 'unsafe1': 'unsafe1'}
    r = json.dumps(v, cls=AnsibleJSONEncoder, ensure_ascii=False)

# Generated at 2022-06-22 21:32:25.638937
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is False

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is True

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is True

    encoder = AnsibleJSON

# Generated at 2022-06-22 21:32:35.691091
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.encoding import to_bytes
    from collections import namedtuple
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import URLError, HTTPError
    from ansible.module_utils._text import to_native

    import collections
    import json
    import re

    # testcase_A
    # Object to be encoded

# Generated at 2022-06-22 21:32:46.590454
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json

    class AnsibleUnsafe(object):
        pass

    aus = AnsibleUnsafe()
    aus.__UNSAFE__ = True
    aus.__SAFE__ = True
    aus.__ENCRYPTED__ = True
    aus.__CIPHERTEXT__ = 'hjkl'
    aus.__PLAINTEXT__ = 'qwer'
    aus.__FOO__ = 'bar'

    data = [
        {'key': 'value'},
        {'key': 'value', 'key1': aus},
        aus,
        ['value'],
        ['value', aus],
        'value',
        aus,
        [aus]
    ]


# Generated at 2022-06-22 21:32:50.495691
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test constructor
    try:
        AnsibleJSONEncoder()
        AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-22 21:33:02.651067
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    password = 'vault'
    vault = VaultLib(password=password)

    class AnsibleUnsafe(object):
        __UNSAFE__ = True

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return to_text(self.value, errors='surrogate_or_strict')

        __repr__ = __str__

    class AnsibleVault(object):
        __ENCRYPTED__ = True
        __UNSAFE__ = True

        def __init__(self, value):
            self.value = value
            self.vault_password = password


# Generated at 2022-06-22 21:33:14.230202
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import getpass
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common._collections_compat import Mapping

    vault_password = getpass.getpass("Vault password: ")

    test_data1 = {
        "a": "{{ myvar|password }}",
        "b": {"c": {"d": ["1", "2", "3"]}},
        "e": "{{ myvar|password }}",
        "f": [{"g": ["4", "5", "6"]}],
    }


# Generated at 2022-06-22 21:33:17.529422
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    return encoder

if __name__ == "__main__":
    try:
        test_AnsibleJSONEncoder()
        print('OK')
    except Exception as e:
        print('NG: ' + str(e))

# Generated at 2022-06-22 21:33:20.316623
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default('test') == 'test'


# Generated at 2022-06-22 21:33:27.319927
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    mock_kwargs={}
    test_encoder = AnsibleJSONEncoder(**mock_kwargs)
    assert type(test_encoder) == AnsibleJSONEncoder
    assert test_encoder._preprocess_unsafe == False
    assert test_encoder._vault_to_text == False
    assert test_encoder.ensure_ascii == True
    assert test_encoder.check_circular == True
    assert test_encoder.allow_nan == True
    assert test_encoder.sort_keys == False
    assert test_encoder.indent == None
    assert test_encoder.separators == (',', ':')


# Generated at 2022-06-22 21:33:38.586163
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    import datetime
    class TestAnsibleJSONEncoder(unittest.TestCase):
        def test_constructor(self):
            self.assertEqual(json.loads(json.dumps({}, cls=AnsibleJSONEncoder)), {})
            self.assertEqual(json.loads(json.dumps({"key": "value"}, cls=AnsibleJSONEncoder)), {"key": "value"})
            self.assertEqual(json.loads(json.dumps({"key": "value"}, cls=AnsibleJSONEncoder, preprocess_unsafe=True)), {"key": "value"})
            self.assertEqual(json.loads(json.dumps({"key": 123}, cls=AnsibleJSONEncoder)), {"key": 123})
            self.assertE

# Generated at 2022-06-22 21:33:50.336833
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    vault = VaultLib([])
    unsafe = vault.encrypt("password")
    date = datetime.date.today()
    assert encoder.default(unsafe) == {'__ansible_vault': to_text(unsafe._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    assert encoder.default(date) == date.isoformat()
    assert encoder.default(dict()) == {}
    assert encoder.default(list()) == []
    assert encoder.default(tuple()) == []
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None

# Generated at 2022-06-22 21:34:00.353043
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """test AnsibleJSONEncoder constructor"""
    from ansible.module_utils.basic import AnsibleModule

    def json_output(data):
        return AnsibleModule(
            argument_spec={},
        ).jsonify(data)


# Generated at 2022-06-22 21:34:09.595588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""
    import pytest
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:34:19.893061
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    # Initialize VaultLib object
    vault_obj = VaultLib('12345')

    # Dictionary containing example hostvars
    inventory_hostvars = {
        'host1': {'ansible_host': 'host1.example.com', 'ansible_user': 'testuser'},
        'host2': {'ansible_host': 'host2.example.com', 'ansible_user': 'testuser'},
    }

    # Dictonary containing example inventory_hostnames

# Generated at 2022-06-22 21:34:29.550253
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # import necessary modules here
    # import variable module
    # import variable module
    # import variable module
    # import variable module
    # import variable module
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import iteritems

    # create class under test
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # create test case data
    unsafe = to_bytes(u'unsafe')
    vault = VaultLib(VaultSecret('secret'))

# Generated at 2022-06-22 21:34:40.835276
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test object initialization
    jenc = AnsibleJSONEncoder()
    assert jenc

    # Test default()
    jenc = AnsibleJSONEncoder()

    # test __ENCRYPTED__
    v = AnsibleVaultEncryptedUnicode(u'abc')
    v.__ENCRYPTED__ = True
    result = jenc.default(v)
    assert result == {'__ansible_vault': u'abc'}

    # test __UNSAFE__
    v = AnsibleUnsafeText(u'abc')
    v.__UNSAFE__ = True
    result = jenc.default(v)
    assert result == {'__ansible_unsafe': u'abc'}

    # test Mapping
    v = dict(name=u'abc')

# Generated at 2022-06-22 21:34:51.310649
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Ensure that json output is correct"""
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultAES256, VaultAES256CBC, VaultAES256CTR, VaultAES256GCM, VaultAES128CBC, VaultAES192CBC

    vault = ansible.parsing.vault
    vault.is_encrypted = lambda x: not x.startswith("$ANSIBLE_VAULT;")

    vault_secret = VaultSecret(_ciphertext='$ANSIBLE_VAULT;2.0;AES256;test0123456789')
    vault_obj = VaultLib(password='test0123456789')

# Generated at 2022-06-22 21:34:53.909292
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-22 21:35:05.088595
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.loader import AnsibleLoader

    from_yaml_unsafe_sequence = AnsibleLoader(
        '''
        - 1
        - 2
        - 3
        - ansible_unsafe
        - 4
        - 5
        - 6
        ''',
        unsafe=True
    ).get_single_data()

    from_yaml_unsafe_mapping = AnsibleLoader(
        '''
        key1: ansible_unsafe
        key2: ansible_unsafe
        key3: ansible_unsafe
        ''',
        unsafe=True
    ).get_single_data()

   

# Generated at 2022-06-22 21:35:08.936169
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json

    j = json.dumps(1, cls=AnsibleJSONEncoder)
    assert j == '1'

    j = json.dumps(1, cls=AnsibleJSONEncoder)
    assert j == '1'


# Generated at 2022-06-22 21:35:13.787979
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    s = ansible_json_encoder.default({"a": "aa"})
    assert(s == {"a": "aa"})
    s = ansible_json_encoder.default(datetime.datetime(2019, 2, 5, 10, 10, 10))
    assert(s == "2019-02-05T10:10:10")

# Generated at 2022-06-22 21:35:23.876932
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import Request
    from ansible.parsing.vault import VaultLib
    vault_lib = VaultLib()
    test_vault_text = vault_lib.encrypt(b'This is a test string')
    test_vault_object = test_vault_text.encode()
    test_request_object = Request('http://127.0.0.1:8181/')
    test_ansible_unsafe_object = ansible_unsafe_object(b'This is a test string')
    test_date_object = datetime.datetime.now()

    # Vault Object

# Generated at 2022-06-22 21:35:34.065671
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder()

    assert u'{}' == ansible_encoder.encode({})
    assert u'{}' == ansible_encoder.encode(json.loads(u'{}'))
    assert u'"value"' == ansible_encoder.encode(json.loads(u'"value"'))
    assert u'[1, 2, 3]' == ansible_encoder.encode(json.loads(u'[1, 2, 3]'))
    assert u'{"a": 1}' == ansible_encoder.encode(json.loads(u'{"a": 1}'))
    assert u'{"a": {"b": 1}}' == ansible_encoder.encode(json.loads(u'{"a": {"b": 1}}'))

# Generated at 2022-06-22 21:35:45.390497
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:35:56.664994
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe
    ANSIBLE_VAULT_PASSWORD_FILE = 'tests/ansible-vault-password-file'
    vault_password = 'test'
    vault_text = "vault text"
    vault = VaultLib(vault_password, vault_password_file=ANSIBLE_VAULT_PASSWORD_FILE)
    vault_encrypted = vault.encrypt(vault_text)
    vault_object = getattr(vault_encrypted, 'encode')('utf-16-le')
    text_vault_object = '{"__ansible_vault": "%s"}' % vault_encrypted.decode('utf-8')

# Generated at 2022-06-22 21:36:05.086530
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    tests _AnsibleJSONEncoder class method default using 'assertEqual'
    '''
    # Create an instance of AnsibleJSONEncoder with the arguments vault_to_text=True and preprocess_unsafe=True
    json_encoder = AnsibleJSONEncoder(vault_to_text=True, preprocess_unsafe=True)
    # Create new objects of type AnsibleUnsafe, AnsibleVaultText, dict, and datetime.date
    unsafe = '{"a": "A"}'
    vault = '{"b": "B"}'
    dictionary = {'foo': 'bar'}
    data = datetime.date(2019, 12, 18)
    # Define expected values
    expected_unsafe = unsafe
    expected_vault = vault

# Generated at 2022-06-22 21:36:10.437371
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test a simple python type
    class TestClass():
        pass

    t = TestClass()

    data = {'ansible': t}
    try:
        json.dumps(data, cls=AnsibleJSONEncoder)
    except TypeError as e:
        assert e.args[0] == "'TestClass' is not JSON serializable"
    else:
        assert False

    # Test an unsafe class
    class TestUnsafeClass(str):
        __UNSAFE__ = True

    t = TestUnsafeClass('unsafe')

    data = {'ansible': t}
    try:
        json.dumps(data, cls=AnsibleJSONEncoder)
    except TypeError as e:
        assert e.args[0] == "'TestUnsafeClass' is not JSON serializable"

# Generated at 2022-06-22 21:36:19.817576
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

        def __repr__(self):
            return u'safe'

    class AnsibleUnsafeUnicode(unicode):
        __UNSAFE__ = True

        def __repr__(self):
            return u'safe'

    class AnsibleUnsafeBytes(bytearray):
        __UNSAFE__ = True

        def __repr__(self):
            return u'safe'

    assert(json.loads(json.dumps({u'привет': 'мир'}, cls=AnsibleJSONEncoder)))
    assert(json.loads(json.dumps({'hello': 'world'}, cls=AnsibleJSONEncoder)))

# Generated at 2022-06-22 21:36:26.606368
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # When no option is provided, vault_to_text is set to False
    jsonEncoder1 = AnsibleJSONEncoder()
    assert not jsonEncoder1._vault_to_text
    # When preprocess_unsafe is set to False, preprocess_unsafe is set to False
    jsonEncoder2 = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert not jsonEncoder2._preprocess_unsafe
    # When preprocess_unsafe is set to True, preprocess_unsafe is set to True
    jsonEncoder3 = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert jsonEncoder3._preprocess_unsafe
    # When preprocess_unsafe and vault_to_text are set to True, preprocess_unsafe and vault_to_text are set to True
    jsonEnc

# Generated at 2022-06-22 21:36:37.328791
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.text import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.encodings import codecs
    from ansible.parsing.json_loader import AnsibleJSONEncoder
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.common._collections_compat import Mapping

    AssertionError = AssertionError

    #preprocess_unsafe is true
    def test_iterencode_with_preprocess_unsafe_is_true():
        to_bytes=to_bytes
        codecs=codecs
        AssertionError=AssertionError
        Mapping=Mapping

# Generated at 2022-06-22 21:36:48.435872
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    ee = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ee.encode(AnsibleUnsafe('password')) == to_text(AnsibleUnsafe('password'))

    vault = VaultLib('vaultpassword', self._cipher_name)
    assert ee.encode(vault.encrypt(AnsibleUnsafe('password'))) == {'__ansible_vault': to_text(vault.encrypt(AnsibleUnsafe('password'))._ciphertext)}

# Generated at 2022-06-22 21:36:56.845463
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    a = {'a': 15, 'b': 'foo'}
    b = {'a': 15, 'b': 'foo', 'c': [3, 5, 6]}
    c = {'a': 15, 'b': 'foo', 'c': {'d': 6}}
    d = {'a': 15, 'b': 'foo', 'c': [3, {'a': 'jj'}, 6]}
    e = {'a': 15, 'b': 'foo', 'c': [3, {'a': 'jj'}, 6, {'b': [1, 2, 3, 'foo']}]}

    assert json.loads(AnsibleJSONEncoder().iterencode(a)) == a
    assert json.loads(AnsibleJSONEncoder().iterencode(b)) == b

# Generated at 2022-06-22 21:37:02.812613
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {
        'a': True,
        'b': False,
        'c': None,
        'd': {'true': True, 'false': False, 'None': None}
    }
    my_json = json.dumps(data)
    my_AnsibleJSONEncoder = AnsibleJSONEncoder()
    ansible_json1 = my_AnsibleJSONEncoder.encode(data)
    ansible_json2 = json.dumps(data, cls=AnsibleJSONEncoder)
    assert my_json == ansible_json1
    assert my_json == ansible_json2

# Generated at 2022-06-22 21:37:13.544317
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test with vault, the case of preprocess_unsafe=True is covered in test_utils_vars.py
    vault_pwd = 'test_vault_pwd'
    vault_obj = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-22 21:37:24.659250
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # Array
    array = [
        1,
        [
          2,
          {
              '__ansible_unsafe': "plaintext data",
              '__ansible_vault': "ciphertext data"
          }
        ]
    ]
    array_json = [1, [2, {'__ansible_unsafe': "plaintext data", '__ansible_vault': "ciphertext data"}]]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, sort_keys=True)
    assert(list(encoder.iterencode(array)) == json.dumps(array_json, sort_keys=True))

    # Map

# Generated at 2022-06-22 21:37:31.443531
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    ansible_unsafe_a = AnsibleUnsafe('Hello')
    ansible_unsafe_b = AnsibleUnsafe(None)

    vault_a = {'__ansible_vault': 'ciphertext'}
    vault_b = 'string'

    result_a = json.dumps(ansible_unsafe_a, cls=AnsibleJSONEncoder)
    assert result_a == json.dumps(vault_a)

    result_b = json.dumps(ansible_unsafe_b, cls=AnsibleJSONEncoder)
    assert result_b == json.dumps(vault_b)

# Generated at 2022-06-22 21:37:42.337356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  # Test preprocess_unsafe==False
  ansible_json_encoder_obj = AnsibleJSONEncoder(preprocess_unsafe=False)
  # Test __UNSAFE__
  unsafe_str = 'this is unsafe string'
  unsafe_str.__UNSAFE__ = True
  unsafe_str.__ENCRYPTED__ = False
  assert ansible_json_encoder_obj.default(unsafe_str) == {'__ansible_unsafe': 'this is unsafe string'}
  # Test __ENCRYPTED__
  encrypted_str = 'this is encrypted string'
  encrypted_str.__UNSAFE__ = False
  encrypted_str.__ENCRYPTED__ = True

# Generated at 2022-06-22 21:37:51.589605
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._json_compat import AnsibleUnsafe
    from ansible.module_utils.common.collections import MutableMapping
    import json

    class AnsibleUnsafeMapping(AnsibleUnsafe, MutableMapping):
        pass


# Generated at 2022-06-22 21:37:59.156521
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    dict1 = dict(one="einz", two="zwei", unsafe=str("This is unsafe"))
    result1 = ansible_encoder.encode(dict1)
    print(result1)
    dict2 = dict(one="einz", two="zwei", unsafe=str("This is unsafe"))
    result2 = ansible_encoder.encode(dict2)
    print(result2)


# Generated at 2022-06-22 21:38:04.236239
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True

# Generated at 2022-06-22 21:38:06.386901
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-22 21:38:09.581158
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert "AnsibleJSONEncoder" == encoder.__class__.__name__


# Generated at 2022-06-22 21:38:19.476522
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    encoder = AnsibleJSONEncoder()

    # test with a regular string
    regular_string = "This is a regular string."
    assert encoder.default(regular_string) == "This is a regular string."

    # test with a module_utils.basic.AnsibleUnsafe instance
    unsafe_string = AnsibleUnsafe(regular_string)
    assert encoder.default(unsafe_string) == {'__ansible_unsafe': 'This is a regular string.'}

    # test with a dict
    dict_unsafe_string = {"first_key": unsafe_string}
    assert encoder.default(dict_unsafe_string) == {'first_key': {'__ansible_unsafe': 'This is a regular string.'}}

# Generated at 2022-06-22 21:38:29.843248
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    import datetime
    # 1. Case to test method default of class AnsibleJSONEncoder
    # 1.1 Input: o is AnsibleUnsafeText
    # 1.2 Execution: Execute method default
    # 1.3 Output: AnsibleUnsafeText is converted to dict
    # 1.4 Assert: Check result of method
    # 1.5 Assert: Check result type
    unsafe_text = AnsibleUnsafeText()
    ansible_json_encoder = AnsibleJSONEncoder()
    result = ansible_json_encoder.default(unsafe_text)
    assert(result == {'__ansible_unsafe': u''})

# Generated at 2022-06-22 21:38:42.481186
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.ansible_galaxy import AnsibleGalaxy
    from ansible.module_utils.six import string_types
    from ansible.module_utils.connection import Connection

    s = 'stest'
    b = b'btest'
    u = u'test'

    assert _is_unsafe(u) is False
    assert _is_vault(u) is False
    assert _is_unsafe(b) is False
    assert _is_vault(b) is False
    assert _is_unsafe(s) is False
    assert _is_vault(s) is False

    # test default
    aje = AnsibleJSONEncoder()
    assert aje.encode(s) == '"stest"'

# Generated at 2022-06-22 21:38:49.119096
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText

    # Test_01: Test case when 'AnsibleUnsafeText' is present in a JSON string
    o = OrderedDict()
    o["param1"] = AnsibleUnsafeText('Test')
    o["param2"] = 'true'
    o["param3"] = {'param3_key': AnsibleUnsafeText('Test2')}
    o["param4"] = [1, 2, 3, AnsibleUnsafeText('Four')]
    string = json.dumps(o, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:38:58.526495
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    result = vault.encrypt("foo")
    vault_obj = AnsibleVaultEncryptedUnicode(result)

# Generated at 2022-06-22 21:39:10.298238
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import ansible.module_utils.common.datetime

# Generated at 2022-06-22 21:39:21.642484
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import sys
    import copy


# Generated at 2022-06-22 21:39:33.156637
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleVaultUnsafeText
    from ansible.vars.hostvars import HostVars
    from ansible.parsing.yaml.heuristic import Heuristic

    heuristic = Heuristic()

# Generated at 2022-06-22 21:39:34.319635
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder()

# Generated at 2022-06-22 21:39:45.779538
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test case: use default encoding method.

    It demonstrates that if the preprocess_unsafe flag is False,
    the encoder will not handle AnsibleUnsafe and AnsibleUnsafeText.
    """
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    test_data = {
        'string_var': 'string',
        'unsafe_var': "%s" % 'unsafe',
        'unsafe_text_var': "%s" % 'unsafe_text',
    }
    it = json_encoder.iterencode(test_data)
    assert next(it) == '{\n'
    assert next(it) == ' "string_var": "string",\n'

# Generated at 2022-06-22 21:39:56.145548
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:40:03.906526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # basic type
    assert json.dumps(1, cls=AnsibleJSONEncoder) == '1'

    # not convert to string
    assert json.dumps({'ansible_managed': {}}, cls=AnsibleJSONEncoder) == '{"ansible_managed": {}}'

    # convert to string
    assert json.dumps({'ansible_managed': '{{ foo }}'}, cls=AnsibleJSONEncoder) == '{"ansible_managed": "{{ foo }}"}'

    # convert to string
    assert json.dumps({'ansible_managed': 'bar'}, cls=AnsibleJSONEncoder) == '{"ansible_managed": "bar"}'

    # convert to string

# Generated at 2022-06-22 21:40:14.855868
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils import _unsafe_proxy

    ai = _unsafe_proxy.AnsibleUnsafeText(text="{'a': 'a', 'b': 'b'}")
    aj = {'a': 'a', 'b': 'b'}

    json_str_1 = b'{"__ansible_unsafe": "{\\\'a\\\': \\\'a\\\', \\\'b\\\': \\\'b\\\'}"}'
    json_str_2 = b'{"a": "a", "b": "b"}'

    jsn = AnsibleJSONEncoder()
    result_1 = jsn.iterencode(ai)
    result_2 = jsn.iterencode(aj)

    assert next(result_1) == json_str_1
    assert next

# Generated at 2022-06-22 21:40:17.810586
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    obj = {'foo': 'bar'}
    assert encoder.encode(obj) == json.dumps(obj)

# Generated at 2022-06-22 21:40:18.622750
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-22 21:40:28.983227
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Instantiate a AnsibleJSONEncoder class object and pass it a argument
    test_obj = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # Check if the object is created by class AnsibleJSONEncoder
    assert isinstance(test_obj, AnsibleJSONEncoder)
    # Check if the object contains a variable self._preprocess_unsafe
    assert hasattr(test_obj, '_preprocess_unsafe')
    assert test_obj._preprocess_unsafe == False
    # Check if the object contains a variable self._vault_to_text
    assert hasattr(test_obj, '_vault_to_text')
    assert test_obj._vault_to_text == False
