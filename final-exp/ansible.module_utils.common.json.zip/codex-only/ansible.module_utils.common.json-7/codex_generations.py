

# Generated at 2022-06-22 21:30:37.028411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault_o = VaultLib([None])
    vault_o.encrypt(to_text("crypt"))
    vault_o.encrypt(to_text("crypt"))
    # vault object

# Generated at 2022-06-22 21:30:48.384082
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    sample_dict = {"dict": {"test3": "test3"}}

# Generated at 2022-06-22 21:30:59.665843
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    vl = VaultLib(['password'])
    encrypted_text = vl.encrypt("ecret_text")
    encrypted_text = string_types(encrypted_text)


# Generated at 2022-06-22 21:31:09.956586
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types

    json_obj = {'__ansible_unsafe': '{{ ansible_current_user }}'}
    j1 = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(json_obj)
    assert isinstance(j1, string_types) and j1 == json.dumps(json_obj)

    json_obj = {'__ansible_unsafe': '{{ ansible_current_user }}'}
    j2 = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(json_obj)
    assert isinstance(j2, string_types) and j2 == json.dumps(json_obj)

# Generated at 2022-06-22 21:31:15.578001
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    my_dict = {'a': 1}
    my_vault = '$ANSIBLE_VAULT;1.1;AES256'
    my_unsafe = '$ANSIBLE_VAULT;1.1;AES256'

    encoder = AnsibleJSONEncoder()
    json.dumps(my_dict, default=encoder.default)
    json.dumps(my_vault, default=encoder.default)
    json.dumps(my_unsafe, default=encoder.default)


# Generated at 2022-06-22 21:31:18.544578
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder_ = AnsibleJSONEncoder()
    if ansible_json_encoder_:
        print('Unit test pass.')

# Generated at 2022-06-22 21:31:27.690057
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    encrypted_vault = VaultLib(password='secret')
    unsafe_str = binary_type('test_binary')
    unsafe_str.__UNSAFE__ = True
    unsafe_str.__ENCRYPTED__ = True
    unsafe_unicode = text_type(u'test_unicode')
    unsafe_unicode.__UNSAFE__ = True
    unsafe_unicode.__ENCRYPTED__ = True
    unsafe_unicode_2 = text_type(u'test_unicode_2')
    unsafe_unicode_2.__UNSAFE__ = True
    unsafe_unicode_2.__EN

# Generated at 2022-06-22 21:31:29.382061
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)

# Generated at 2022-06-22 21:31:40.227692
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Variables used in test
    my_dict = {"key": AnsibleUnsafeText(u'A\u2026' + quote("&"))}
    expected_string = '{"key": {"__ansible_unsafe": "A\\u2026%26"}}'

    # Test that the iterencode method of AnsibleJSONEncoder returns the expected value
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(my_dict) == expected_string

    # Test that the iterencode method of AnsibleJSONEncoder works properly within Ansible
    loader = DataLoader

# Generated at 2022-06-22 21:31:49.392717
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText

    # test that iterencode correctly encodes instance of AnsibleUnsafeText
    value1 = AnsibleUnsafeText(u'unsafe value1')
    json_encoder = AnsibleJSONEncoder()
    json_encoded_value1 = json_encoder.iterencode(value1)
    assert next(json_encoded_value1) == json.dumps({'__ansible_unsafe': 'unsafe value1'}, sort_keys=True, indent=4)

    # test that iterencode correctly encodes instance of AnsibleUnsafeText in the list
    value2 = AnsibleUnsafeText(u'unsafe value2')
    json_encoded_value2 = json_encoder.iterencode([value1, value2])
    assert next

# Generated at 2022-06-22 21:32:00.033580
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test:
    #         iterencode,
    #         default,
    #         unsafe,
    #         vault,
    #         date

    # test objects
    test_unsafe = 'unsafe'
    test_unsafe_object = {"__UNSAFE__": True}
    test_vault = 'vault'
    test_vault_object = {"__ENCRYPTED__": True}
    test_dict_object = {"datetime": datetime.date.today()}

    # default constructor
    encoder = AnsibleJSONEncoder()

    # default test
    assert encoder.default(test_unsafe) == 'unsafe'
    assert encoder.default(test_unsafe_object) == test_unsafe_object
    assert encoder.default(test_vault) == 'vault'

# Generated at 2022-06-22 21:32:12.333304
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    import datetime
    data = {
        "date":datetime.datetime.now(),
        "string":"test_string",
        "number":1,
        "number_long":9999999999,
        "list":[1,2,3,4],
        "dict":{
            "key1":"value1",
            "key2":"value2",
        }
    }
    json_data = json.dumps(data,cls=AnsibleJSONEncoder)
    print (json_data)
    # now = datetime.datetime.now().isoformat()
    # json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    # print (json_data)

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:32:14.291904
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None

# Generated at 2022-06-22 21:32:17.404025
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    jsonEncoder = AnsibleJSONEncoder()
    assert jsonEncoder._preprocess_unsafe is False
    assert jsonEncoder._vault_to_text is False

# Generated at 2022-06-22 21:32:26.335257
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_string = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).encode({"value": "test_ansible_safe", "value2": "test_ansible_unsafe"})
    assert json_string == '{"value": "test_ansible_safe", "value2": "test_ansible_unsafe"}'

    json_string = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode({"value": "test_ansible_unsafe"})
    assert json_string == '{"value": "test_ansible_unsafe"}'

# Generated at 2022-06-22 21:32:31.953245
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultSecretParseError

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    vault_password = "foo"
    vault_text = 'This is a string that is vault encrypted.'
    vault = VaultLib([ vault_password ])
    vault_encrypted_text = vault.encrypt(vault_text)
    vault_encrypted_text_decrypted = vault.decrypt(vault_encrypted_text)

    print("Vault Password   : " + vault_password)
    print("Vault text       : " + vault_text)
    print("Vault encrypted  : " + vault_encrypted_text)

# Generated at 2022-06-22 21:32:43.195834
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, string_types
    from ansible.module_utils._text import to_bytes, to_native

    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @property
        def a(self):
            return self._a

        @a.setter
        def a(self, value):
            if not isinstance(value, string_types):
                raise TypeError("'a' must be a string.")
            self._a = value


# Generated at 2022-06-22 21:32:49.385532
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from datetime import datetime
    encoder = AnsibleJSONEncoder()
    assert encoder.default(AnsibleUnsafe(b'AnsibleUnsafe')) == {u'__ansible_unsafe': u'AnsibleUnsafe'}
    assert encoder.default(b'AnsibleUnsafe') == 'AnsibleUnsafe'
    assert encoder.default(datetime(2019,1,1,1,1,1)) == '2019-01-01T01:01:01'
    assert encoder.default([1,2,3]) == [1, 2, 3]

# Generated at 2022-06-22 21:33:01.665434
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.encoding import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.text.converters import to_text

    ENC = 'utf-8'
    unsafe_obj = b'unsafe'
    vault_obj = VaultLib(boolean(True), 'ansible')

# Generated at 2022-06-22 21:33:03.375305
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)


# Generated at 2022-06-22 21:33:14.662597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping


# Generated at 2022-06-22 21:33:24.240387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVars
    import datetime

    # FIXME: does not work in all cases, e.g. with VaultLib
    # assert getattr(VaultLib, '__JSONENCODER_SUPPORT__', False)

    # test class with __ENCRYPTED__
    t = "test unsafestring"
    unsafe_text = AnsibleUnsafeText(t)

# Generated at 2022-06-22 21:33:27.034055
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json_encoder._preprocess_unsafe == True


# Generated at 2022-06-22 21:33:38.544894
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.common.unsafe_proxy as unsafe_proxy
    class AnsibleUnsafe(unsafe_proxy.AnsibleUnsafeText, str):
        pass
    class AnsibleUnsafeBytes(unsafe_proxy.AnsibleUnsafeBytes, bytes):
        pass
    test_list = [{"key1": "value1", "key2": AnsibleUnsafe("value2"), "key3": {"key4": AnsibleUnsafe("value3")}, "key5": [{"key6": AnsibleUnsafe("value4")}], "key7": AnsibleUnsafe("value5")}, AnsibleUnsafe("value6"), AnsibleUnsafeBytes("value7")]

# Generated at 2022-06-22 21:33:44.544547
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, wrap_var
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-22 21:33:55.031182
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import PY3, text_type

    vault_object = '$ANSIBLE_VAULT;1.1;AES256\n3835356161326266616137336235623430633231636233326266323761633762316131373962376131\n3436386539396366656238656665636630623430613335613536316636613533353633346164393633\n382d623362343633393438663838353532393530373362\n'
    ansible_vault_object = {'__ansible_vault': vault_object}

# Generated at 2022-06-22 21:34:05.960634
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    a_dict = {'a': 1, 'b': '2', 'c': VaultLib('123')}
    encoder = AnsibleJSONEncoder(sort_keys=True)
    assert json.dumps(a_dict, cls=encoder, ensure_ascii=False) == '{"a": 1, "b": "2", "c": {"__ansible_vault": "123"}}'
    encoder = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-22 21:34:09.098762
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-22 21:34:13.158433
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    s = u'["\u20ac", "\u20ac"]'
    assert encoder.encode((u'€', u'€')) == s



# Generated at 2022-06-22 21:34:21.833426
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe is False
    assert AnsibleJSONEncoder()._vault_to_text is False

    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe is True
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._vault_to_text is False

    assert AnsibleJSONEncoder(vault_to_text=True)._preprocess_unsafe is False
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text is True

    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe is True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault

# Generated at 2022-06-22 21:34:33.988769
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pipeline_options = {'silent': True}
    pipeline_options_unsafe = {'silent': True, '__UNSAFE__': True}
    pipeline_options_vault = {'silent': True, '__ENCRYPTED__': True}
    aws_ec2_group_id = {'aws_ec2_group': 'sg-abcd12ef'}
    aws_ec2_group_id_unsafe = {'aws_ec2_group': 'sg-abcd12ef', '__UNSAFE__': True}
    aws_ec2_group_id_vault = {'aws_ec2_group': 'sg-abcd12ef', '__ENCRYPTED__': True}


# Generated at 2022-06-22 21:34:39.606407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    import ansible.module_utils.six
    j = json.dumps({'test': ansible.module_utils.basic.AnsibleUnsafeText('test')}, cls=AnsibleJSONEncoder)
    assert j == '{"test": {"__ansible_unsafe": "test"}}'



# Generated at 2022-06-22 21:34:47.590042
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Used with ansible/ansible config.
    # It takes 'ansible_json' as an argument and pass it onto
    # the '_json_encoder' method in ansible/ansible/module_utils/basic.py
    # Then the '_json_encoder' method pass the encoder's iterencode
    # method as an argument to json.dumps
    # See ansible/ansible/module_utils/basic.py and ansible/ansible/module_utils/json_utils.py
    pass

# Generated at 2022-06-22 21:34:58.439406
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class MyInput:
        pass

    # type check for class MyInput
    assert isinstance(MyInput(), Mapping)

    # type check for class MyInput
    assert not isinstance(MyInput(), (datetime.date, datetime.datetime))

    # type check for class MyInput
    assert not is_sequence(MyInput())

    from ansible.parsing.vault import VaultSecret

    # type check for class VaultSecret
    assert not isinstance(
        VaultSecret('hello'),
        Mapping
    )

    # type check for class VaultSecret
    assert not isinstance(
        VaultSecret('hello'),
        (datetime.date, datetime.datetime)
    )

    # type check for class VaultSecret
    assert not is_sequence(
        VaultSecret('hello')
    )

    # type check for class

# Generated at 2022-06-22 21:35:04.860543
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:35:06.118567
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert hasattr(AnsibleJSONEncoder, 'iterencode')


# Generated at 2022-06-22 21:35:15.929761
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    import json

    class Fake(AnsibleUnsafe, dict):
        pass

    # a class inherits both dict and AnsibleUnsafe
    test_obj = Fake(key=AnsibleUnsafe('value'), my_list=['A', AnsibleUnsafe('B')])
    ansible_json_encoder = AnsibleJSONEncoder()
    # should have key __ansible_unsafe in encoded string
    try:
        list(ansible_json_encoder.iterencode(test_obj))
    except ValueError as e:
        if "must be str, not AnsibleUnsafe" in str(e):
            raise AssertionError("AnsibleUnsafe was not properly handled by json.JSONEncoder iterencode method")

# Generated at 2022-06-22 21:35:23.148775
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.ansible_vault import AnsibleVaultEncryptedUnicode
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder.default(AnsibleUnsafe(b'unsafe')) == {'__ansible_unsafe': 'unsafe'}
    assert ansible_encoder.default(AnsibleVaultEncryptedUnicode(b'vault')) == {'__ansible_vault': 'vault'}


# Generated at 2022-06-22 21:35:32.656491
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.six import text_type

    from ansible.module_utils.urls import urlsplit

    from ansible.module_utils.common._collections_compat import Sequence

    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible.module_utils.common.text.converters import to_bytes, to_text

    from ansible.module_utils.common.text.converters import to_bytes, to_native, to_text

    from ansible.module_utils.common.json import from_json, to_json

    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    from ansible.parsing.yaml import from_yaml, to_yaml

    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-22 21:35:43.370828
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json

    import ansible.parsing.unsafe_proxy

    assert(json.loads(json.dumps({}, cls=AnsibleJSONEncoder)) == {})

    assert(json.loads(json.dumps("Hello World", cls=AnsibleJSONEncoder)) == "Hello World")
    assert(json.loads(json.dumps({u"Hello World": "Hello World"}, cls=AnsibleJSONEncoder)) == {u"Hello World": "Hello World"})

    assert(json.loads(json.dumps(ansible.parsing.unsafe_proxy.AnsibleUnsafeText("Hello World"), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': 'Hello World'})

# Generated at 2022-06-22 21:35:51.556950
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Vault object
    class TestVault:
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
    v = TestVault(ciphertext='abc123')
    obj = AnsibleJSONEncoder().default(v)
    assert isinstance(obj, dict)
    assert obj['__ansible_vault'] == 'abc123'

    # Unsafe object
    class TestUnsafeStr(str):
        __UNSAFE__ = True
    u = TestUnsafeStr('abc123')
    obj = AnsibleJSONEncoder().default(u)
    assert isinstance(obj, dict)
    assert obj['__ansible_unsafe'] == 'abc123'

    # Mapping object

# Generated at 2022-06-22 21:35:54.441697
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert(encoder._preprocess_unsafe == True)
    assert(encoder._vault_to_text == False)


# Generated at 2022-06-22 21:35:57.575436
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(encoder, json.JSONEncoder)
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

# Generated at 2022-06-22 21:36:05.948112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for AnsibleVaultEncryptedUnicode
    encoder = AnsibleJSONEncoder()
    # 'Vault(' followed by unicode-encoded string followed by ')'
    vault_object = u'Vault(\xa3)'
    vault_object.__ENCRYPTED__ = True
    assert encoder.default(vault_object) == {
        '__ansible_vault': u'\xa3'
    }

    # Test for AnsibleUnsafeText
    encoder = AnsibleJSONEncoder()
    # 'Unsafe(' followed by unicode-encoded string followed by ')'
    unsafe_object = u'Unsafe(\xc3)'
    unsafe_object.__UNSAFE__ = True

# Generated at 2022-06-22 21:36:10.813852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO

    # AnsibleUnsafe object
    test_unsafe = AnsibleUnsafe("!vault |")
    assert _is_unsafe(test_unsafe)
    assert to_text(AnsibleJSONEncoder().default(test_unsafe)) == '{"__ansible_unsafe": "!vault |"}'

    # vault object
    test_vault = VaultLib([])
    test_vault.load_vault_id('test-vault')

# Generated at 2022-06-22 21:36:20.155533
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import binascii
    import cryptography.fernet
    import base64

    class unsafe:
        __UNSAFE__ = True

    class vault:
        __ENCRYPTED__ = True
        _ciphertext = binascii.hexlify(cryptography.fernet.Fernet(base64.b64encode(base64.b64encode(b'random_key'))).encrypt(b'ansible_vault_data'))

    class my_dict(dict):
        pass

    assert json.dumps(unsafe(), cls=AnsibleJSONEncoder) == '{"__ansible_unsafe": ""}'

# Generated at 2022-06-22 21:36:26.844112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test if we get expected output with given input.
    enc = AnsibleJSONEncoder()
    assert enc.default(None) == None

    # test if we get expected output for normal python string
    s = "string"
    enc = AnsibleJSONEncoder()
    assert enc.default(s) == s

    # test if we get expected output for normal python list
    lst = [1, 2, 3]
    assert enc.default(lst) == lst

    # test if we get expected output for normal python dict
    dict = {"one":1, "two":2}
    assert enc.default(dict) == dict

    # test if we get expected output for datetime object
    now = datetime.datetime.now()
    assert enc.default(now).startswith(now.isoformat())

    # test if we

# Generated at 2022-06-22 21:36:37.674693
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Init args
    preprocess_unsafe=True
    vault_to_text=False
    indent=None
    separators=None
    sort_keys=True
    skipkeys=False
    ensure_ascii=True
    check_circular=True
    allow_nan=True
    cls=None
    indent=None
    separators=None
    encoding='utf-8'
    default=None
    use_decimal=True
    namedtuple_as_object=True
    tuple_as_array=False
    bigint_as_string=False
    item_sort_key=None
    for_json=False
    ignore_nan=False

    # Init ansible JSON encoder

# Generated at 2022-06-22 21:36:42.853401
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = json.dumps({"test_string": "Test String"}, cls=AnsibleJSONEncoder, indent=4)
    expected_output = '''{
    "test_string": "Test String"
}'''
    assert result == expected_output

# Generated at 2022-06-22 21:36:52.078096
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # test: vault object
    encoder = AnsibleJSONEncoder()
    assert encoder.default('$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n') == {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n'}

    # test: unsafe object
    encoder = AnsibleJSONEncoder()
    assert encoder.default('$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n') == {'__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n'}


# Generated at 2022-06-22 21:37:00.072056
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(to_unicode('あ')) == '"あ"'

    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(to_bytes('あ')) == '"\\xe3\\x81\\x82"'

    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(to_text('あ')) == '"あ"'


# Generated at 2022-06-22 21:37:10.541094
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    example_safe = u"A safe string"
    example_unsafe = u'{"A safe string", a_string.strip()}'
    example_vault_text = u'secret'
    example_vault_ciphertext = VaultLib({}).encrypt(example_vault_text)

    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import wrap_var

    data = {
        'safe': example_safe,
        'unsafe': wrap_var(example_unsafe),
        'vault': wrap_var(example_vault_ciphertext, vault_text=example_vault_text),
    }


# Generated at 2022-06-22 21:37:13.644919
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    # https://docs.python.org/3.6/library/json.html#json.JSONEncoder.iterencode
    #

# Generated at 2022-06-22 21:37:21.651868
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    obj = AnsibleJSONEncoder()
    obj.encode('test')
    obj.iterencode('test')
    obj.default(True)
    obj.default(0)
    obj.default(45.0)
    obj.default(None)
    obj.default('test')
    obj.default({'key': 'value'})
    obj.default(['first', 'second', 'third'])
    obj.default(datetime.datetime(2020, 7, 31, 13, 30, 30))


# Generated at 2022-06-22 21:37:24.659188
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    value = "test123"
    encoded_value = encoder.default(value)
    print(encoded_value)
    assert encoded_value == "test123"

# Generated at 2022-06-22 21:37:25.215119
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    pass

# Generated at 2022-06-22 21:37:35.385865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible_collections.ansible.community.plugins.module_utils.common._text import to_bytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeBytes, AnsibleUnsafeText, wrap_var

    def return_var_AnsibleUnsafe(x):
        return x

    def return_var_AnsibleUnsafeBytes(x):
        return AnsibleUnsafeBytes(x.encode('utf-8'))

    def return_var_AnsibleUnsafeText(x):
        return AnsibleUnsafeText(x)


# Generated at 2022-06-22 21:37:39.595997
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    test_obj = {
        'x': 1,
        'y': [1, 2, 3],
        'z': {'a': [1, 2, 3], 'b': True, 'c': False, 'd': 'some string'},
        'date': datetime.datetime.now(),
        'date2': datetime.date.today(),
    }

    encoder = AnsibleJSONEncoder()
    json_obj = encoder.encode(test_obj)
    json_obj = json.loads(json_obj)
    # basic test
    assert json_obj['x'] == test_obj['x']
    assert json_obj['y'] == test_obj['y']
    assert json_obj['z'] == test_obj['z']

    # dates

# Generated at 2022-06-22 21:37:43.951762
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible.module_utils.common.unsafe_proxy
    assert isinstance(AnsibleJSONEncoder(), ansible.module_utils.common.unsafe_proxy.AnsibleJSONEncoder)

# Generated at 2022-06-22 21:37:45.094433
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # just pass
    assert AnsibleJSONEncoder()

# Define the function being used, function_name must be unique

# Generated at 2022-06-22 21:37:47.748998
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert isinstance(ansible_json_encoder, json.JSONEncoder)

# Generated at 2022-06-22 21:37:56.141094
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default('2015-05-29') == '2015-05-29'

# Generated at 2022-06-22 21:38:06.389555
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    import datetime
    unsafestr = u"unsafe_string"
    obj = AnsibleUnsafe(unsafestr)
    data = {'a': 'b', 'c': obj}
    assert obj.__UNSAFE__ == True
    jsonstr = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True)
    assert '"__ansible_unsafe": "unsafe_string"' in jsonstr
    assert '"c": {' in jsonstr
    assert '"__ansible_unsafe"' in jsonstr

    # test with a datetime
    dt = datetime.datetime(2019, 1, 2, 12, 15)
    data = {'a': dt, 'c': obj}

# Generated at 2022-06-22 21:38:17.791321
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import os
    import sys
    import shutil
    import tempfile
    import inspect

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes

    parent_dir = os.path.dirname(os.path.dirname(inspect.getfile(inspect.currentframe())))
    data_json_file = 'data.json'
    data_json_vault_file = 'data_vault.json'
    data_path = os.path.join(parent_dir, data_json_file)
    data_vault_path = os.path.join(parent_dir, data_json_vault_file)

    tmp_dir = tempfile.mkdtemp()
    tmp_data_

# Generated at 2022-06-22 21:38:25.877344
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    text = 'this is plain text'
    unsafe_value = AnsibleUnsafe(text)
    vault_value = AnsibleVaultEncryptedUnicode(text)
    value_list = [unsafe_value, vault_value]

    encoder = AnsibleJSONEncoder()
    assert encoder.encode(text) == json.dumps(text)
    assert encoder.encode(unsafe_value) == json.dumps(unsafe_value)
    assert encoder.encode(vault_value) == json.dumps(vault_value)
    assert encoder.encode(value_list) == json.dumps(value_list)


# Generated at 2022-06-22 21:38:35.372144
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    '''
    Make sure __init__ of class AnsibleJSONEncoder is functioning correctly
    '''
    test_instance = AnsibleJSONEncoder(preprocess_unsafe=False,
                                       vault_to_text=False)
    assert test_instance._preprocess_unsafe == False
    assert test_instance._vault_to_text == False

    test_instance = AnsibleJSONEncoder(preprocess_unsafe=True,
                                       vault_to_text=True)
    assert test_instance._preprocess_unsafe == True
    assert test_instance._vault_to_text == True

    test_instance = AnsibleJSONEncoder(preprocess_unsafe=True,
                                       vault_to_text=False)
    assert test_instance._preprocess_unsafe == True
    assert test_instance._vault_

# Generated at 2022-06-22 21:38:45.510575
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_text
    from ansible.module_utils.urls import fetch_url
    # "unsafe" types that we want to encode as dict
    UNSAFE_TYPES = (fetch_url.Response, boolean)
    # "safe" types that we want to encode as string
    SAFE_TYPES = (string_types, Mapping)

    class TestUnsafe(object):
        __UNSAFE__ = True
        content = 'test'

# Generated at 2022-06-22 21:38:55.759579
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test for simple string
    assert json.dumps("Hi", cls=AnsibleJSONEncoder) == '"Hi"'
    # Test for complex string
    assert json.dumps("Hi\nThere!", cls=AnsibleJSONEncoder) == '"Hi\\nThere!"'
    # Test for dict
    assert json.dumps({"content": "Hi There!", "more_content": "Bye"}, cls=AnsibleJSONEncoder) == '{"content": "Hi There!", "more_content": "Bye"}'
    # Test for list
    assert json.dumps(["Hi There!", "Bye"], cls=AnsibleJSONEncoder) == '["Hi There!", "Bye"]'

# Generated at 2022-06-22 21:39:07.582192
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import PY3, binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence

    def _to_bytes(obj):
        """Convert input to bytes for Python 2 and 3"""
        if isinstance(obj, text_type):
            obj = to_bytes(obj, errors='surrogate_or_strict')
        elif isinstance(obj, Mapping):
            obj = dict((_to_bytes(k), _to_bytes(v)) for k, v in obj.items())
        elif is_sequence(obj):
            obj = list(_to_bytes(i) for i in obj)

# Generated at 2022-06-22 21:39:16.542394
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    class UnsafeClass(str):
        __UNSAFE__ = True

    class EncryptedClass(str):
        __ENCRYPTED__ = True

    # test for unsafe string encode
    unsafe_str = UnsafeClass('abc')
    exposed_str = 'abc'
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert next(encoder.iterencode(unsafe_str)) == json.dumps(exposed_str)

    # test for unsafe dictionary encode
    unsafe_dict = {'a': unsafe_str, 'b': {'c': unsafe_str}}
    exposed_dict = {'a': exposed_str, 'b': {'c': exposed_str}}

# Generated at 2022-06-22 21:39:23.555725
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == True


# Generated at 2022-06-22 21:39:33.301129
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret

    json_encoder = AnsibleJSONEncoder()
    vault = VaultSecret('secret')
    assert json_encoder.default(vault) == {'__ansible_vault': to_text(vault._ciphertext, errors='surrogate_or_strict', nonstring='strict')} or \
                                          json_encoder.default(vault) == {'__ansible_vault': to_text(vault._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    assert json_encoder.default("string") == "string"



# Generated at 2022-06-22 21:39:42.488615
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(AnsibleUnsafeText('hello')) == {'__ansible_unsafe': 'hello'}
    assert encoder.default(AnsibleUnsafeBytes(b'world')) == {'__ansible_unsafe': 'world'}
    assert encoder.default(AnsibleVaultEncryptedUnsafeBytes(b'world')) == {'__ansible_vault': 'world'}
    assert encoder.default(AnsibleVaultEncryptedUnsafeText('hello')) == {'__ansible_vault': 'hello'}



# Generated at 2022-06-22 21:39:52.830765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test cases with vault objects
    assert AnsibleJSONEncoder().default(vault.VaultObject('secret', '1')) == {'__ansible_vault': 'secret'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault.VaultObject('secret', '1')) == 'secret'

    # Test cases with unsafe objects
    assert AnsibleJSONEncoder().default(unsafe_proxy.AnsibleUnsafeText('unsafe')) == {'__ansible_unsafe': 'unsafe'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(unsafe_proxy.AnsibleUnsafeText('unsafe')) == {'__ansible_unsafe': 'unsafe'}

    # Test cases with mappings

# Generated at 2022-06-22 21:39:55.881791
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    json_ansible_encoder.default("Ansible")

# Generated at 2022-06-22 21:40:00.878759
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert (AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
            is not AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False))
    assert (AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
            is not AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True))


# Generated at 2022-06-22 21:40:13.193333
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.parameters import AnsibleUnsafe

    # This is a valid test case but the method is not expected to change
    # any more and therefore we are not testing it any further.
    #
    # ansible_unsafe = AnsibleUnsafe(b"J\xfcnger")
    # encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    # encoded = encoder.iterencode(ansible_unsafe)
    # assert b"J\xfcn" in encoded

    # Test that iterencode does not encode a string in a list
    ansible_unsafe = [AnsibleUnsafe(u"J\xfcn")]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:40:20.005803
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible.utils.unsafe_proxy
    import ansible.parsing.vault
    test_object = {'one': 1, 'two': 2, 'three': 1.5, 'four': ansible.utils.unsafe_proxy.AnsibleUnsafeText('encoded to dict'),
                   'five': ansible.parsing.vault.VaultLib().encrypt('encoded to dict') }

# Generated at 2022-06-22 21:40:31.930703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    class Example(object):
        def __init__(self):
            self.a = "A"
            self.b = "B"
        def __eq__(self, other):
            return self.a == other.a and self.b == other.b
        def __ne__(self, other):
            return not self == other

    v1 = Example()
    from ansible.module_utils.basic import AnsibleUnsafeText
    v2 = AnsibleUnsafeText("")
    from ansible.parsing.vault import VaultLib
    v3 = VaultLib("AES256")

    expected = "{'__ansible_unsafe': ''}"
    assert encoder.default(v2) == expected
