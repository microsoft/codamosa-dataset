

# Generated at 2022-06-22 21:30:38.032866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime
    # Testing with a VaultLib object
    o = VaultLib()
    o._ciphertext = 'String to put in ciphertext'
    o.__ENCRYPTED__ = True
    assert AnsibleJSONEncoder(vault_to_text=True).default(o) == 'String to put in ciphertext'
    assert AnsibleJSONEncoder(vault_to_text=False).default(o) == {'__ansible_vault': 'String to put in ciphertext'}
    # Testing with a datetime object
    o = datetime.datetime(2017, 12, 25)
    assert AnsibleJSONEncoder().default(o) == '2017-12-25T00:00:00'
    # Testing with a datetime object
   

# Generated at 2022-06-22 21:30:45.189375
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import datetime
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    from units.mock.vault import VaultLib
    vault_lib = VaultLib({})

    class MockClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    e = AnsibleJSONEncoder()
    assert e.default(1) == 1
    assert e.default('a') == 'a'
    assert e.default(u'a') == u'a'
    assert e.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert e.default(set(['a', 'b', 'c'])) == ['a', 'b', 'c']


# Generated at 2022-06-22 21:30:51.625533
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    assert to_text(json.dumps({'a': 42}, cls=AnsibleJSONEncoder, preprocess_unsafe=True)) == '{"a": 42}'
    assert to_text(json.dumps({'a': 42}, cls=AnsibleJSONEncoder, preprocess_unsafe=False)) == '{"a": 42}'
    assert to_text(json.dumps({'a': 42}, cls=AnsibleJSONEncoder, preprocess_unsafe=True, sort_keys=True)) == '{"a": 42}'
    assert to_text(json.dumps({'a': 42}, cls=AnsibleJSONEncoder, preprocess_unsafe=False, sort_keys=True)) == '{"a": 42}'


# Generated at 2022-06-22 21:31:02.965770
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing import vault

    vault = vault.VaultLib('1234')
    secret = vault.encrypt(u'password')
    secret_dict = {u'password': secret}
    vault_str = '{"__ansible_vault": "\\nBQBuAG0AcgBkAHMAaABlAGwAYQAvAHkAcABlAHIAYQBlAHMAZQAuAGwAcwBpAG4A\\nLgBKAEMAbwByAC4ALgBJAG4AdABpAHQAeQAgACAAKQAgACkA\\n"}'
    secret_json_str = json.dumps(secret_dict, cls=AnsibleJSONEncoder)
    assert secret_json_str == vault_str

# Generated at 2022-06-22 21:31:13.581021
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import textwrap
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    # Example: https://docs.python.org/2/library/json.html#encoders-and-decoders
    assert encoder.encode({"foo": "bar"}) == '{"foo": "bar"}'
    assert encoder.encode(dict(foo=42, bar=21, baz=2.7182)) == '{"bar": 21, "baz": 2.7182, "foo": 42}'

# Generated at 2022-06-22 21:31:24.585625
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    test_case = [
        ("AnsibleUnsafe", {'__ansible_unsafe': "'AnsibleUnsafe'"}),
        ("'AnsibleVault'", {'__ansible_vault': "'AnsibleVault'"}),
        (dict(a='a'), {'a': 'a'}),
        (datetime.date.today(), datetime.date.today().isoformat()),
    ]
    for i in range(len(test_case)):
        print("test default conversion on " + str(i) + "th test case")
        assert encoder.default(test_case[i][0]) == test_case[i][1]



# Generated at 2022-06-22 21:31:36.451322
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    vault_password = "vault_password"
    vault = VaultLib(vault_password)
    string_data = u'Väult'
    vault_data = vault.encrypt(string_data)
    assert _is_vault(vault_data)

    test_json_data = {u'föö': [1, 2, 'three'], u'väult_str': vault_data, u'väult_list': [1, vault_data, 'three']}

    ## Testing iterencode with preprocess_unsafe and vault_to_text is true

# Generated at 2022-06-22 21:31:47.534807
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    v = VaultLib('dummy')
    v_encoded = json.dumps(v, cls=AnsibleJSONEncoder, vault_to_text=True)
    v_decoded = json.loads(v_encoded)
    assert isinstance(v_decoded, str)
    assert v_decoded.startswith('$ANSIBLE_VAULT;')
    assert v_decoded.endswith('dummy')

    import datetime
    v_encoded = json.dumps(date(2000, 3, 2), cls=AnsibleJSONEncoder)
    v_decoded = json.loads(v_encoded)
    assert isinstance(v_decoded, str)
    assert v_decoded == '2000-03-02'

# Generated at 2022-06-22 21:31:49.983577
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder is not None


# Generated at 2022-06-22 21:31:59.535966
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    import datetime
    datetime_obj = datetime.datetime.strptime('2018-10-25 7:49:07.825265', '%Y-%m-%d %H:%M:%S.%f')
    assert encoder.default(datetime_obj) == datetime_obj.isoformat()

    not_datetime_obj = datetime.datetime.strptime('2018-10-25 7:49:07.825265', '%Y-%m-%d %H:%M:%S.%f').timetuple()
    assert encoder.default(not_datetime_obj) == not_datetime_obj

# Generated at 2022-06-22 21:32:08.124511
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # no vault, no unsafe
    enc = AnsibleJSONEncoder()
    assert enc
    # vault, no unsafe
    enc = AnsibleJSONEncoder(vault_to_text=True)
    assert enc
    # no vault, unsafe
    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert enc
    # vault, unsafe
    enc = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert enc


# Generated at 2022-06-22 21:32:16.199954
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test all values that are provided by AnsibleJSONEncoder.iterencode"""
    from ansible.module_utils.six import iteritems
    from ansible.parsing.vault import VaultLib

    def _enc(value):
        return AnsibleJSONEncoder().iterencode(value)

    class FauxVaultLib(VaultLib):

        def __init__(self, ciphertext):
            super(FauxVaultLib, self).__init__()
            self._ciphertext = ciphertext

        def _get_cipher(self):
            return None

        def load(self, value):
            return value

    for test_class in (str, list, dict):
        # safe object
        assert b'["safe"]' == next(_enc(test_class("safe")))


# Generated at 2022-06-22 21:32:28.018483
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # preprocess_unsafe = False
    # vault_to_text = False
    encoder = AnsibleJSONEncoder(preprocess_unsafe = False, vault_to_text = False)
    a = encoder.default("o")
    assert a == 'o'

    a = encoder.default(1)
    assert a == 1

    a = encoder.default(True)
    assert a == True

    a = encoder.default({'x': 'y'})
    assert a == {'x': 'y'}

    # preprocess_unsafe = True
    # vault_to_text = False
    encoder = AnsibleJSONEncoder(preprocess_unsafe = True, vault_to_text = False)
    a = encoder.default("o")
    assert a == 'o'

    a = enc

# Generated at 2022-06-22 21:32:30.653332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    o = {'foo': 'bar'}

    value = encoder.default(o)

    assert value == o



# Generated at 2022-06-22 21:32:39.461172
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    assert '__ansible_unsafe' in str(AnsibleJSONEncoder().default('unsafe'))
    assert '__ansible_vault' in str(AnsibleJSONEncoder().default('vault'))
    assert '__ansible_unsafe' in str(AnsibleJSONEncoder(vault_to_text=True).default('unsafe'))
    assert '__ansible_vault' not in str(AnsibleJSONEncoder(vault_to_text=True).default('vault'))
    assert '__ansible_unsafe' not in str(AnsibleJSONEncoder(preprocess_unsafe=True).default('unsafe'))

# Generated at 2022-06-22 21:32:49.947031
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import MutableSequence

    # These are the variables that are defined in the test env
    # used by the test suite.
    test_vars = {
        'str_var'       : 'hello world',
        'int_var'       : 123,
        'float_var'     : 123.456,
        'list_var'      : ['abc', 123, False],
        'dict_var'      : {'abc': 123, 'def': {'ghi': False}},
        'bool_true_var' : True,
        'bool_false_var': False,
        'none_var'      : None
    }

    # Create a vault object


# Generated at 2022-06-22 21:33:02.042259
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import ansible.parsing.vault as vault
    import ansible.module_utils.basic

    class TestVault(vault.VaultLib):
        def __init__(self, _vault_filename=None, _vault_password=None):
            self._vault_filename = _vault_filename
            self._vault_password = _vault_password
            self._cipher = vault.AESCipher(self.get_password())

    class TestUnsafe(ansible.module_utils.basic.AnsibleUnsafe):
        def __init__(self, value):
            self.__UNSAFE__ = True
            self.value = value

        def __str__(self):
            return self.value

        def __unicode__(self):
            return self.value


# Generated at 2022-06-22 21:33:14.022505
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import Mapping

    # Test with __ENCRYPTED__ parameter
    e = AnsibleJSONEncoder()
    o = b'ANSIBLE_VAULT'
    o.__ENCRYPTED__ = True

# Generated at 2022-06-22 21:33:25.457724
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Simple test to verify iterencode returns iterator over encoded items"""
    # Create an unsafe string
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    unsafe_str = AnsibleUnsafeText('exposed password')

    # Create expected output
    expected_output = [
        '"exposed password"',
        '"exposed password"',
        '"exposed password"'
    ]

    # Create a list for testing
    test_list = [
        unsafe_str,
        unsafe_str,
        unsafe_str
    ]

    # Create a generator object from AnsibleJSONEncoder
    testgen = AnsibleJSONEncoder().iterencode(test_list)

    # Combine them into tuple and verify
    actual_output = tuple(testgen)
    assert(actual_output == expected_output)

# Generated at 2022-06-22 21:33:31.638886
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    from textwrap import dedent

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def test__preprocess_unsafe_encode(self):
            from ansible.vars.unsafe_proxy import AnsibleUnsafe
            import json

            unsafe = AnsibleUnsafe('{ "a": "b" }')

            encoded = _preprocess_unsafe_encode(unsafe)
            decoded = json.loads(json.dumps(encoded))
            self.assertEqual(decoded, encoded)

        def test_encoding_some_objects(self):
            from ansible.vars.unsafe_proxy import AnsibleUnsafe
            from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 21:33:37.128317
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.utils.unsafe_proxy import wrap_var
    now = datetime.datetime.now()
    x = {
        'a': 1,
        'b': 'foo',
        'c': [1, 2, '3'],
        'd': now,
        'e': wrap_var('foo'),
    }

    # Check that a Vault key is created
    encrypted_value = AnsibleJSONEncoder().encode({'foo': wrap_var('bar')})
    encrypted_value = json.loads(encrypted_value)
    assert encrypted_value['foo']['__ansible_vault'] == to_text('bar')

    # Check that a Vault key is not created, and text is returned

# Generated at 2022-06-22 21:33:49.045119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    assert encoder.default(AnsibleUnsafe('abc')) == {'__ansible_unsafe': u'abc'}
    assert encoder.default(VaultLib(['']).encrypt('123')) == {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\n39353137383537633235633033386261316132623461663537636137633061313737663539306264\n396638626565343835333532373638373031643065346437393462396231\n'}

# Generated at 2022-06-22 21:33:52.144484
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ans_jsonencoder = AnsibleJSONEncoder()
    assert ans_jsonencoder._preprocess_unsafe == False
    assert ans_jsonencoder._vault_to_text == False

# Generated at 2022-06-22 21:33:53.992918
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None


# Generated at 2022-06-22 21:34:04.991459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.parsing.vault import VaultLib
    import datetime
    import hashlib
    # Test with "unsafe" objects
    v = VaultLib([])
    assert '{"__ansible_unsafe": "unsafe"}' == json.dumps({'unsafe': unsafe_proxy.AnsibleUnsafeText('unsafe')}, cls=AnsibleJSONEncoder)
    # Test with "vault" objects
    assert '{"__ansible_vault": "vault"}' == json.dumps({'vault': v.encrypt('vault')}, cls=AnsibleJSONEncoder)
    # Test with "hostvars" objects

# Generated at 2022-06-22 21:34:16.631759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Init the json encoder
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # Test if the default method works
    class Foo:
        def __init__(self):
            self.bar = "baz"

    class Baz:
        def __repr__(self):
            return '<baz>'

    class StdObjectEncoderTest(object):
        def __init__(self, name):
            self.name = name

    assert json_encoder.default(Foo()) == {"bar": "baz"}
    assert json_encoder.default(10) == 10
    assert json_encoder.default(None) is None
    assert json_encoder.default(Baz()) == '<baz>'
    assert json_encoder

# Generated at 2022-06-22 21:34:25.698048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    def assert_default(o, result):
        aje = AnsibleJSONEncoder()
        assert aje.default(o) == result

    class TestObj(object):
        def __init__(self, a):
            self.a = a

    assert_default(TestObj(1), {'a': 1})
    assert_default(TestObj({'a': 1}), {'a': {'a': 1}})
    assert_default(datetime.datetime(2011, 12, 21, 17, 31, 1), u'2011-12-21T17:31:01')
    assert_default(datetime.date(2011, 12, 21), u'2011-12-21')

# Generated at 2022-06-22 21:34:29.979406
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:34:37.895508
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import jmespath
    import itertools
    import collections
    import datetime
    import dateutil
    import textwrap
    import dateutil.parser

    # check that we can get the expected behavior without exception
    AnsibleJSONEncoder.default('hello')
    AnsibleJSONEncoder.default(u'hello')
    AnsibleJSONEncoder.default(b'hello')
    AnsibleJSONEncoder.default([])
    AnsibleJSONEncoder.default({})
    AnsibleJSONEncoder.default(())
    AnsibleJSONEncoder.default(set({1, 2, 3}))
    AnsibleJSONEncoder.default(set())
    AnsibleJSONEncoder.default(1)
    AnsibleJSONEncoder.default(1.1)
    AnsibleJSONEncoder.default({'a': 'b'})

   

# Generated at 2022-06-22 21:34:47.072729
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(vault_to_text=False)
    assert AnsibleJSONEncoder(vault_to_text=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-22 21:34:58.396338
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.ajson import AnsibleJSONEncoder

    unsafe_bytes = AnsibleUnsafeBytes(b"hello")
    unsafe_text = AnsibleUnsafeText(u"hello")
    data = {"hello" : [unsafe_bytes, unsafe_text]}

    json_str = json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True, ensure_ascii=False)
    to_unicode(json_str)
    json_str = to_unicode(json_str)

# Generated at 2022-06-22 21:35:08.522598
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    import textwrap
    from ansible.parsing.yaml.objects import AnsibleUnsafe


# Generated at 2022-06-22 21:35:18.426321
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import get_vault_secret

    def _assert_encoder_output(value, expected, **kwargs):
        assert json.loads(json.dumps(value, cls=AnsibleJSONEncoder, **kwargs)) == expected

    _assert_encoder_output('foo', 'foo')

    _assert_encoder_output('foo', u'foo', ensure_ascii=False)

    _assert_encoder_output(
        {'foo': 'bar'},
        {u'foo': u'bar'},
        ensure_ascii=False,
    )

    _assert_encoder_output(
        {'foo': 'bar'},
        {'foo': 'bar'},
        ensure_ascii=True,
    )

    _assert_

# Generated at 2022-06-22 21:35:27.146877
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Check when the constructor is called and no arguments are given
    # Check whether the arguments are initialized with their default values
    ansible_json_encoder_object = AnsibleJSONEncoder()
    assert ansible_json_encoder_object._preprocess_unsafe == False
    assert ansible_json_encoder_object._vault_to_text == False
    assert ansible_json_encoder_object._scan_once == None
    assert ansible_json_encoder_object._skipkeys == True
    assert ansible_json_encoder_object._ensure_ascii == True
    assert ansible_json_encoder_object._check_circular == True
    assert ansible_json_encoder_object._allow_nan == True
    assert ansible_json_encoder_object._sort_keys == False

# Generated at 2022-06-22 21:35:35.308557
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault

    # Input data
    input_data = {
        'simple_data_0': 'string',
        'simple_data_1': 0,
        'simple_data_2': 0.1,
        'simple_data_3': True,
        'simple_data_4': None,
    }

    # Vault object
    passwords = vault.VaultLib({})
    input_data.update({
        'vault_data': passwords.encrypt('VALUEOFVAULTDATA'),
    })

    # Unsafe object
    import ansible.parsing.yaml.objects as yaml

# Generated at 2022-06-22 21:35:46.738246
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # Test __ENCRYPTED__
    data = {
        '__vault__': {'password': '$ANSIBLE_VAULT;1.2;AES256;ansible\r\n6539336437373062386366306630653866396138373330346562653762363338353834626437\r\nsome comment\r\n'},
    }

# Generated at 2022-06-22 21:35:54.814138
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.basic import AnsibleUnsafeText

    x = [1, False, "a", [1,2,3], {'a': 'a', 'b': 'b'}, dict(a='a', b='b'), AnsibleUnsafeText('abcdef')]

    y = json.dumps(x, cls=AnsibleJSONEncoder)

    assert y == '[1, false, "a", [1, 2, 3], {"a": "a", "b": "b"}, {"a": "a", "b": "b"}, {"__ansible_unsafe": "abcdef"}]'

# Generated at 2022-06-22 21:36:03.308157
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create AnsibleJSONEncoder instance
    encoder = AnsibleJSONEncoder()
    assert not encoder._preprocess_unsafe
    assert not encoder._vault_to_text

    # Test date values
    date = datetime.date(2019, 6, 7)
    assert encoder.default(date) == '2019-06-07'
    datetime_ = datetime.datetime(2019, 6, 7, 11, 19, 47, 252578)
    assert encoder.default(datetime_) == '2019-06-07T11:19:47.252578'

    # Test vaults
    from ansible.parsing.vault import VaultLib
    vault_ = VaultLib(None).encrypt('secret')

# Generated at 2022-06-22 21:36:12.745643
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3

    vault = VaultLib([])
    vault_pass = 'test'
    vault_content = '$ANSIBLE_VAULT;1.2;AES256;test\n3335346633373139663763353135313762366639376162376731326262393838636361666264646164\n3935306634633639666535306664623761623762623539306366616636303966303564663731336634\n'
    vault_obj = vault.decrypt(vault_content, vault_pass)

# Generated at 2022-06-22 21:36:21.643666
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret

    assert list(AnsibleJSONEncoder().iterencode(VaultSecret(b'value'))) == list(json.JSONEncoder().iterencode({'__ansible_vault': b'value'}))
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(VaultSecret(b'value'))) == list(json.JSONEncoder().iterencode(VaultSecret(b'value')))
    assert list(AnsibleJSONEncoder(vault_to_text=True).iterencode(VaultSecret(b'value'))) == list(json.JSONEncoder().iterencode(VaultSecret(b'value')._plaintext))

# Generated at 2022-06-22 21:36:22.636510
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-22 21:36:33.182229
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import get_vault_secret

    ansible_unsafe = "secret_info"
    unsafe_str = text_type(ansible_unsafe)
    unsafe_str_encoded = {'__ansible_unsafe': 'secret_info'}

    ansible_vault = get_vault_secret(ansible_unsafe)

# Generated at 2022-06-22 21:36:39.661934
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    assert aje.check_circular == True
    assert aje.ensure_ascii == True
    assert aje.indent == None
    assert aje.key_separator == ':'
    assert aje.object_hook == None
    assert aje.sort_keys == False
    assert aje.separators == (',', ':')
    assert aje.skipkeys == False
    assert aje.allow_nan == True
    assert aje.encoding == 'utf-8'

# Generated at 2022-06-22 21:36:49.822521
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    data = {'a': ['A', True, 1, 2.0, None], 'b': 'B', 'c': {'c_1': 'C_1', 'c_2': 'C_2', 'c_3': 'C_3'}}
    # test for kwargs indent
    json_encoder = AnsibleJSONEncoder(indent = 4)

# Generated at 2022-06-22 21:36:53.073910
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    session = json.dumps({'a': 'b', 'c': 'd'}, cls=AnsibleJSONEncoder, indent=4)  
    assert session == '{\n    "a": "b", \n    "c": "d"\n}'

# Generated at 2022-06-22 21:37:00.375244
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # Example of what we want to test
    class MyClass(object):
        def __init__(self, foo, bar):
            self.__dict__ = dict(foo=foo, bar=bar)

    preprocess_unsafe = True
    vault_to_text = True
    json_data = ({
        'a': 1,
        'b': MyClass(b'My unsecure data', u'My secure data\x00'),
        'c': Sequence([MyClass(b'My unsecure data', u'My secure data\x00'), {'x': 1}]),
    },)


# Generated at 2022-06-22 21:37:10.935383
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from datetime import date, datetime
    from socket import socket

    encoder = AnsibleJSONEncoder()

    assert encoder.default(AnsibleUnsafe('foo')) == {'__ansible_unsafe': to_text('foo')}
    assert encoder.default(VaultLib([b'foo']).encrypt('bar')) == {'__ansible_vault': to_text('bar')}
    assert encoder.default(date(1991, 11, 22)) == '1991-11-22'

# Generated at 2022-06-22 21:37:22.238472
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unsafe_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Test data

# Generated at 2022-06-22 21:37:33.420907
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime, json
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    # preparing test data
    test_data = list()
    for i in range(5):
        value = list()
        for _ in range(5):
            _value = to_bytes(i) if (i % 2 == 0) else to_unicode(i)
            value.append(_value)
        test_data.append(value)

    # single list
    d1 = {'data': test_data[0][0]}
    d2 = {'data': json.dumps(d1['data'], cls=AnsibleJSONEncoder)}
    assert d1 == d2

    # nested lists


# Generated at 2022-06-22 21:37:43.452152
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # create inputs to the method
    data = [
        ({'__ansible_vault': b'vault_data'}, {'__ansible_vault': b'vault_data'}),
        ({'__ansible_vault': 'vault_data'}, {'__ansible_vault': 'vault_data'}),
        ({'__ansible_unsafe': b'unsafe_data'}, {'__ansible_unsafe': 'unsafe_data'}),
        ({'__ansible_unsafe': 'unsafe_data'}, {'__ansible_unsafe': 'unsafe_data'}),
        ('unsafe_data', 'unsafe_data')
    ]

    # Set up object

# Generated at 2022-06-22 21:37:44.163512
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    x = AnsibleJSONEncoder()
    assert x


# Generated at 2022-06-22 21:37:52.852765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import binary_type

    s = 'my string'
    t = AnsibleJSONEncoder().default(b'\x12\x34\x56\x78\x90')
    assert t == '\x12\x34\x56\x78\x90'
    t = AnsibleJSONEncoder().default(u'\x12\x34\x56\x78\x90')
    assert t == '\x12\x34\x56\x78\x90'
    t = AnsibleJSONEncoder().default(s)
    assert t == s

    secret = VaultSecret(b'\x12\x34\x56\x78\x90', vault_identity='my password')
    t = Ans

# Generated at 2022-06-22 21:38:02.542671
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # none
    assert AnsibleJSONEncoder().default(None) == None
    # int
    assert AnsibleJSONEncoder().default(0) == 0
    # str
    assert AnsibleJSONEncoder().default('str') == 'str'
    # bool
    assert AnsibleJSONEncoder().default(True) == True
    # dict
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}
    # date
    today = datetime.date.today()
    assert AnsibleJSONEncoder().default(today) == today.isoformat()
    # datetime
    now = datetime.datetime.now()
    assert AnsibleJSONEncoder().default(now) == now.isoformat()


# Generated at 2022-06-22 21:38:08.586471
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import os
    import sys
    import tempfile
    import textwrap
    import unittest

    # Redirect stderr to a temporary file for the 'import ansible.*' to avoid
    # printing a warning about AnsibleJSONEncoder usage in Python3.

# Generated at 2022-06-22 21:38:17.872554
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # __init__(self, preprocess_unsafe=False, vault_to_text=False, **kwargs):
    # default:
    a = AnsibleJSONEncoder()
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False
    # set preprocess_unsafe to True, verify _preprocess_unsafe
    b = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert b._preprocess_unsafe == True
    # set _vault_to_text to True, verify _vault_to_text
    c = AnsibleJSONEncoder(vault_to_text=True)
    assert c._vault_to_text == True

# Generated at 2022-06-22 21:38:26.962870
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3, text_type

    vault = VaultLib(password='fake')

    obj = {
        'vault': vault.encrypt('text'),
        'unsafe': to_text(vault.encrypt('text'), errors='surrogate_or_strict', nonstring='strict'),
        'unicode': u'\u2713',
        'some_bytes': b'\x80',
        'some_list': [b'\x80', 1, u'\u2713'],
    }

    if PY3:
        obj['unicode'] = obj['unicode'].encode('utf-8')

    # Encoding the object without pre-processing will encode the ``AnsibleUnsafe``

# Generated at 2022-06-22 21:38:31.198408
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils import basic
    x = ansiblejsonencoder.AnsibleJSONEncoder(basic.AnsibleModule())
    assert x._preprocess_unsafe == False
    assert x._vault_to_text == False
    assert x.indent == 4


# Generated at 2022-06-22 21:38:35.445874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Test case to unit test the default method of class AnsibleJSONEncoder
    '''
    ansible_json_encoder = AnsibleJSONEncoder()
    json_data = ansible_json_encoder.default({"a": "b", "c": "d"})
    assert json_data == {"a": "b", "c": "d"}



# Generated at 2022-06-22 21:38:45.510556
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text, to_bytes

    class FakeUnsafe(text_type):
        """Implements a object that acts like a string but has the attribute __UNSAFE__"""
        __UNSAFE__ = True

    class FakeVault(object):
        """Implements a object that acts like a string but has the attribute __ENCRYPTED__"""
        __ENCRYPTED__ = True
        def __init__(self, value):
            self._ciphertext = value


# Generated at 2022-06-22 21:38:56.692408
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansiblejsonencoder = AnsibleJSONEncoder()
    assert ansiblejsonencoder.check_circular is False
    assert ansiblejsonencoder.ensure_ascii is True
    assert ansiblejsonencoder.indent is None
    assert ansiblejsonencoder.key_separator == ':'
    assert ansiblejsonencoder.object_hook == None
    assert ansiblejsonencoder.preprocess_unsafe is False
    assert ansiblejsonencoder.sort_keys is False
    assert ansiblejsonencoder.vault_to_text is False


# Generated at 2022-06-22 21:39:08.325093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Instantiate class AnsibleJSONEncoder
    aje = AnsibleJSONEncoder()

    # Test dict
    assert aje.default({}) == {}
    assert aje.default({'a': 1}) == {'a': 1}
    assert aje.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test dict with non-string key
    assert aje.default({1: 'x'}) == {1: 'x'}
    assert aje.default({1: 'x', 2: 'y'}) == {1: 'x', 2: 'y'}
    assert aje.default({(1, 2): 'x'}) == {(1, 2): 'x'}

    # Test dict with non-string values

# Generated at 2022-06-22 21:39:16.925769
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    cached = AnsibleUnsafeText(b'value')
    test_list = [1, 2, 'a', 'b']
    # Add to the list, two items of class AnsibleUnsafeText
    test_list.append(cached)
    test_list.append(cached)
    # Add to the list, a dict with a key value pair with a key of class AnsibleUnsafeText
    test_dict = {'test': 'dict'}
    test_dict.update({cached: 'test'})
    test_list.append(test_dict)
    # Add to the list, a sublist with a single item of class AnsibleUnsafeText


# Generated at 2022-06-22 21:39:19.988146
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-22 21:39:31.523634
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Create a value that mirrors the structure of what stdout_callback looks like
    test_value = {}

# Generated at 2022-06-22 21:39:42.617466
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import six
    import textwrap

    class MockUnsafe(six.text_type):
        __UNSAFE__ = True

        def __str__(self):
            return 'test123'

    # Test for string and unsafe string
    test_str = '{"test_str": "test"}'
    test_unsafe = '{"test_unsafe": "test123"}'

    assert json.loads(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode({'test_str': 'test', 'test_unsafe': MockUnsafe()})) == \
        json.loads(textwrap.dedent('''\
            {
                "test_str": "test",
                "test_unsafe": {
                    "__ansible_unsafe": "test123"
                }
            }'''))



# Generated at 2022-06-22 21:39:52.931969
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_safe_text

    assert json.dumps('abc') == to_text(AnsibleJSONEncoder().iterencode('abc'))

    data = {'a': 'b'}
    assert json.dumps(data) == to_text(AnsibleJSONEncoder().iterencode(data))

    data = {'a': to_safe_text('b')}
    assert json.dumps(data) == to_text(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data))

    # Note: iterencode should not raise exception when ``o`` is not a string type
    assert json.dumps(123) == to_text(AnsibleJSONEncoder().iterencode(123))

# Generated at 2022-06-22 21:40:01.822877
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    import base64

    # test is_unsafe()
    assert not _is_unsafe(b'hi')
    assert _is_unsafe(AnsibleUnsafeBytes(b'hi'))
    assert _is_unsafe(AnsibleUnsafeText(b'hi'))

    # test _preprocess_unsafe_encode
    assert _preprocess_unsafe_encode(b'hi') == 'hi'

# Generated at 2022-06-22 21:40:06.729176
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    if aje:
        print("ansible_json_encoder.AnsibleJSONEncoder is OK")

test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:40:08.404270
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(AnsibleJSONEncoder() is not None)


# Generated at 2022-06-22 21:40:18.893705
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    ansible_unsafe_text = AnsibleUnsafeText(u"this is the secret: HamandEggs")
    ansible_unsafe_bytes = AnsibleUnsafeBytes(b"1234")

    json_text = u'{"__ansible_unsafe": "this is the secret: HamandEggs"}'
    json_bytes = u'{"__ansible_unsafe": "MTIzNA=="}'

    assert(''.join(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).iterencode(ansible_unsafe_text)) == json_text)

# Generated at 2022-06-22 21:40:29.826781
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    unsafe_text = AnsibleUnsafeText('wrong_password')
    # For python 2.6 and 2.7, dict.values() returns a list.
    # For python 3.x, dict.values() returns an iterable view object
    # In code below, 'o' is a dictionary and we're testing if all values are
    # converted to json-safe type by AnsibleJSONEncoder.iterencode().
    o = dict.fromkeys(['a', 'b'], unsafe_text)
    # If o is converted to a list, the result will be [{'__ansible_unsafe': 'wrong_password'}, {'__ansible_unsafe': 'wrong_password'}]
    # If