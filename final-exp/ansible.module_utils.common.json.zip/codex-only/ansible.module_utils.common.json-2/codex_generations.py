

# Generated at 2022-06-22 21:30:25.969885
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe, bytes_to_raw, raw_to_bytes
    from ansible.module_utils.common.text.converters import to_unicode


# Generated at 2022-06-22 21:30:37.836038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test_string')) == {'__ansible_unsafe': 'test_string'}
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test_string', True)) == {'__ansible_vault': 'test_string'}
    assert AnsibleJSONEncoder().default(VaultLib('test_string', True)) == {'__ansible_vault': 'test_string'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(VaultLib('test_string', True)) == 'test_string'

# Generated at 2022-06-22 21:30:48.552760
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class Vault(str):
        __ENCRYPTED__ = True

    class Custom(object):
        def __init__(self, value):
            self.value = value

    # ensure a simple json string is encoded properly
    # this is required to compare the output from object's json string with the one from object itself
    # json string representation exports the object in a single line, so if we don't encode the object
    # with ansible json encoder, the json string will have "newline" characters
    # during the comparison
    assert json.dumps("{}") == json.dumps("{}", cls=AnsibleJSONEncoder, ensure_ascii=True)

    # Test String

# Generated at 2022-06-22 21:30:57.677559
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(sort_keys=True, indent=2)
    assert encoder.default(b'ke') == 'ke'
    assert encoder.default('ke') == 'ke'
    assert encoder.default(1) == 1
    assert encoder.default({'k': 'e'}) == {'k': 'e'}
    assert encoder.default({'k': 'e', 'k1': 2}) == {'k': 'e', 'k1': 2}
    assert encoder.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()

# Generated at 2022-06-22 21:31:09.295286
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils._text import to_text
    import json

    class AnsibleUnsafe(str):
        __UNSAFE__ = True
        __metaclass__ = type

    class AnsibleVault(str):
        __ENCRYPTED__ = True
        __metaclass__ = type

    def _preprocess_unsafe_encode(value):
        '''
        Recursively preprocess a data structure converting instances of ``AnsibleUnsafe``
        into their JSON dict representations
        '''



# Generated at 2022-06-22 21:31:19.747716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def fake_unsafe_text(o):
        return {'__ansible_unsafe': to_text(o, errors='surrogate_or_strict', nonstring='strict')}

    def fake_vault_text(o):
        return {'__ansible_vault': to_text(o, errors='surrogate_or_strict', nonstring='strict')}

    def fake_vault_to_text(o):
        return to_text(o, errors='surrogate_or_strict')

    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(1) == 1
    assert json_encoder.default('test') == 'test'
    assert json_encoder.default(['test']) == ['test']
    assert json_encoder.default

# Generated at 2022-06-22 21:31:27.050160
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    input_value = {"a": "b", "c": [1, 2, 3, 4], "d": {"e": "f"} }
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(input_value)) == ['{', '"a"', ':', '"b"', ',', '"c"', ':', '[', '1', ',', '2', ',', '3', ',', '4', ']', ',', '"d"', ':', '{', '"e"', ':', '"f"', '}', '}']

__all__ = ('AnsibleJSONEncoder',)

# Generated at 2022-06-22 21:31:29.295543
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert isinstance(json_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-22 21:31:33.552588
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    obj = [AnsibleUnsafe('unexpected_value')]

    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True)
    json_encoder.iterencode(obj)

# Generated at 2022-06-22 21:31:40.703559
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Example for testing custom iterencode method
    # Set the _preprocess_unsafe to True
    #
    # >>> from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    # >>> encoder = AnsibleJSONEncoder(_preprocess_unsafe=True)
    # >>> json.dumps({'ansible_unsafe': 'This is unsafe'}, cls=encoder)
    # '{"ansible_unsafe": {"__ansible_unsafe": "This is unsafe"}}'
    pass

# Generated at 2022-06-22 21:31:49.617889
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.constants as C

    def clear_ansible_vars():
        '''Clear the ANSIBLE_CALLABLE_WHITELIST'''
        C.ANSIBLE_CALLABLE_WHITELIST = []

    class Unsafe(str):
        __UNSAFE__ = True

    class Vault(str):
        __ENCRYPTED__ = True

    class UnsafeAndVault(Unsafe, Vault):
        pass

    class UnsafeList(list):
        __UNSAFE__ = True

    class SafeList(list):
        __UNSAFE__ = False

    class UnsafeAndVaultList(UnsafeList, Vault):
        pass

    class UnsafeDict(dict):
        __UNSAFE__ = True


# Generated at 2022-06-22 21:32:00.194468
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test unsafe objects
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).encode(an_UNSAFE_string) == "{\"__ansible_unsafe\": \"this is a string\"}"
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).encode(an_UNSAFE_string) == "\"this is a string\""
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).encode(an_UNSAFE_string) == "{\"__ansible_unsafe\": \"this is a string\"}"

# Generated at 2022-06-22 21:32:12.493390
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    crypt = VaultLib(VaultSecret('mysecret'))
    vault_string = crypt.encrypt('some string')

    # Represents an AnsibleVaultEncryptedUnicode object
    vault_value_1 = vault_string.encode('utf-8')
    vault_value_2 = vault_string.encode('utf-8')

    # Mapping of values and expected result
    # Key: Value to be tested
    # Value: Expected result

# Generated at 2022-06-22 21:32:24.505425
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''Unit tests for AnsibleJSONEncoder.iterencode'''
    import ansible.parsing.vault as vault

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    plain_text = "Jinja2 is a modern and designer-friendly templating language for Python, \
    modelled after Django's templates. It is fast, widely used and secure with the optional \
    sandboxed template execution environment: {{ SECRET_PASSWORD }}"

    plain_text_vault = to_text(vault.encrypt(plain_text))

    # test plain text
    output = AnsibleJSONEncoder.iterencode(plain_text, ensure_ascii=False)
    assert plain_text == output

    # test unsafe text

# Generated at 2022-06-22 21:32:34.841164
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    # test_default_method
    # test_unsafe
    try:
        result = json.dumps(AnsibleUnsafe("test"), cls=encoder)
    except Exception as e:
        result = False
    assert result == False
    # test_vault
    value = VaultLib().encrypt("test")
    try:
        result = json.dumps(value, cls=encoder)
    except Exception as e:
        result = False
    assert result == False
    result = json.dumps(value, cls=encoder, vault_to_text=True)

# Generated at 2022-06-22 21:32:45.690634
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.ansible_release
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import StringIO

    encoder = AnsibleJSONEncoder()

    # Testing simple string
    buf = StringIO()
    json.dump("string", buf, cls=encoder)
    assert buf.getvalue() == '"string"'

    # Testing unicode string
    buf = StringIO()
    json.dump(u"string", buf, cls=encoder)
    assert buf.getvalue() == '"string"'

    # Testing list of strings
    buf = StringIO()
    json.dump(["string", "string2"], buf, cls=encoder)

# Generated at 2022-06-22 21:32:49.014124
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """This function is a unit test to test AnsibleJSONEncoder constructor"""
    test = AnsibleJSONEncoder()
    assert test._preprocess_unsafe == False
    assert test._vault_to_text == False

# Generated at 2022-06-22 21:32:53.210661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # No default method
    class CustomObject(object):
        pass

    o = CustomObject()
    o.test = 'test'

    ansible_encoder = AnsibleJSONEncoder()
    ansible_encoder.default(o)



# Generated at 2022-06-22 21:32:55.438575
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = ['123', 'ABC', '456']
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder, json.JSONEncoder)

# Generated at 2022-06-22 21:33:05.974984
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.six import string_types

    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    json_str = '{"a": "str", "b": [1,2,3], "c": {"a": 1, "b": "str"}, "d": [{"a": "nested"}, {"b": 1}], "e": "\\x0d"}'

    unsafe_value = AnsibleUnsafe("\\x0d")
    safe_value = "\\x0d"

    # Test values not used in example json_str

# Generated at 2022-06-22 21:33:16.888904
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class Vault(str):
        __ENCRYPTED__ = True

    raw = {
        'raw_str': 'raw_str',
        'unicode_str': u'unicode_str',
        'raw_unsafe': AnsibleUnsafe('raw_unsafe'),
        'raw_vault': Vault('raw_vault'),
    }

    ansible_encoder = AnsibleJSONEncoder()
    ansible_encoder._vault_to_text = True
    ansible_encoder._preprocess_unsafe = True

    assert ansible_encoder.default(raw['raw_str']) == raw['raw_str']

# Generated at 2022-06-22 21:33:27.069469
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test with preprocess_unsafe
    input = {'foo': AnsibleUnsafe(b'bar')}
    output = json.dumps(input, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert output == '{"foo": {"__ansible_unsafe": "bar"}}'

    # test with preprocess_unsafe and vault_to_text
    input = {'foo': AnsibleVaultEncryptedUnicode(u'barbaz')}
    output = json.dumps(input, cls=AnsibleJSONEncoder, preprocess_unsafe=True, vault_to_text=True)
    assert output == '{"foo": "barbaz"}'

# Generated at 2022-06-22 21:33:38.595404
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleUnsafe

    class CustomMapping(Mapping):
        def __iter__(self):
            pass
        def __len__(self):
            pass
        def __getitem__(self, key):
            pass
        def __setitem__(self, key, value):
            pass
    example1 = {'key1': CustomMapping()}
    example2 = {'key1': [AnsibleUnsafe('foo'), text_type('bar')]}
    example3 = [AnsibleUnsafe('foo'), text_type('bar')]
    example4 = AnsibleUnsafe('foo')

# Generated at 2022-06-22 21:33:50.336522
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_string = '{"key": "value"}'
    json_string_with_preprocess_unsafe = '{"key": "value", "__ansible_unsafe": "value"}'
    json_string_with_preprocess_vault = '{"key": "value", "__ansible_vault": "value"}'
    with_preprocess_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    with_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)
    assert to_text(with_preprocess_unsafe.encode(json.loads(json_string))) == json_string_with_preprocess_unsafe
    assert to_text(with_vault_to_text.encode(json.loads(json_string))) == json_string_

# Generated at 2022-06-22 21:34:00.353253
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    from ansible.parsing.vault import VaultSecret, VaultLib
    from ansible.module_utils.six import string_types

    encoder = AnsibleJSONEncoder()
    for cls in string_types:
        assert encoder.default(cls()) == str()

    # Test for VaultSecret
    _raw_vault = VaultSecret(VaultLib(password='password').dump('password'))
    _raw_vault_expected = {'__ansible_vault': _raw_vault._ciphertext}

# Generated at 2022-06-22 21:34:09.595263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Arrange
    # AnsibleUnsafe is a subclass of unicode and is a string
    my_string = u"hello world!"
    my_unsafe = AnsibleUnsafe(my_string)
    my_vault = AnsibleVaultEncryptedUnicode(my_string)
    my_dict = {'my_string': my_string, 'my_unsafe': my_unsafe, 'my_vault': my_vault}
    my_list = ['my_string', 'my_unsafe', 'my_vault']
    my_datetime = datetime.datetime.strptime("20180410", "%Y%m%d")

    # Act
    encoder = AnsibleJSONEncoder()
    result_string = encoder.default(my_string)
    result_unsafe = encoder.default

# Generated at 2022-06-22 21:34:19.893868
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    # Create input data as dict with list and other dicts
    data = {'key1': 'value1',
            'key2': 'value2',
            'key3': ['value3', 'value4'],
            'key4': ['value5', 'value6'],
            'key5': {'key5-1': 'value5-1', 'key5-2': 'value5-2'},
            'key6': {'key6-1': 'value6-1', 'key6-2': 'value6-2'}}
    # Create input data with dict as list value

# Generated at 2022-06-22 21:34:22.382006
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json.loads(json.dumps({"one": 1}, cls=AnsibleJSONEncoder))

# Generated at 2022-06-22 21:34:34.127344
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # The following code is to make sure AnsibleJSONEncoder can be imported on Python 2.6.
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch('ansible.module_utils.common._collections_compat', new=None):
        from ansible.module_utils.common.collections import is_sequence
        from ansible.module_utils.common.text.converters import to_text
        from ansible.module_utils.ansible_release import __version__ as ansible_version


# Generated at 2022-06-22 21:34:40.136112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Add the tests here if you need to test different instances of the object.
    # The function signature must be the default signature.
    import sys
    import unittest
    import datetime

    #from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    # test mappings
    testMapping = {'a':1, 'b':2, 'c': [1,2]}
    assert AnsibleJSONEncoder().default(testMapping) == {'a':1, 'b':2, 'c': [1,2]}

    # test dates
    testDate = datetime.datetime(year=2020, month=1, day=1)
    assert AnsibleJSONEncoder().default(testDate) == '2020-01-01T00:00:00'

    # test encrypted data
    testEncrypted

# Generated at 2022-06-22 21:34:50.908474
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Tests instantiation with preprocess_unsafe=False
    ansible_json_encoder1 = AnsibleJSONEncoder(preprocess_unsafe=False)
    # Test instantiation with preprocess_unsafe=True
    ansible_json_encoder2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    # Test instantiation with vault_to_text=True
    ansible_json_encoder3 = AnsibleJSONEncoder(vault_to_text=True)
    # Test instantiation with preprocess_unsafe=False, vault_to_text=False
    ansible_json_encoder4 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # Test instantiation with preprocess_unsafe=True, vault_to_text=True
    ansible_

# Generated at 2022-06-22 21:34:56.082532
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:35:05.875032
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    test_cases = [
        ("test_string", "test_string"),
        (123, 123),
        ({"test_dict": {"key": "value"}}, {"test_dict": {"key": "value"}}),
        (["test_list", {"key": "value"}], ["test_list", {"key": "value"}]),
        (datetime.datetime(2017, 1, 1, 0, 0, 0), "2017-01-01T00:00:00"),
        (datetime.date(2017, 1, 1), "2017-01-01"),
    ]
    for test_case in test_cases:
        assert encoder.default(test_case[0]) == test_case[1]

# Generated at 2022-06-22 21:35:15.598873
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    # int
    o = 1
    assert [o] == list(AnsibleJSONEncoder().iterencode(o))
    # str
    o = 'foo'
    assert [o] == list(AnsibleJSONEncoder().iterencode(o))
    # dict
    o = dict(foo='bar')
    assert [o] == list(AnsibleJSONEncoder().iterencode(o))
    # list
    o = ['foo', 'bar']
    assert [o] == list(AnsibleJSONEncoder().iterencode(o))
    # tuple
    o = ('foo', 'bar')

# Generated at 2022-06-22 21:35:25.546672
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    vault_password = 'V@ultPas5w0rd'
    vault = VaultLib([vault_password])
    encrypted_value = vault.encrypt(to_text('Secret Text'))

    data = u'\u2713'
    json_encoder = AnsibleJSONEncoder()

    # Test string data
    json_data = u''.join(json_encoder.iterencode(data))
    assert json_data == u'"\\u2713"'

    # Test unsafe object
    json_data = u''.join(json_encoder.iterencode(AnsibleUnsafe(data)))

# Generated at 2022-06-22 21:35:34.467947
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.common.unsafe_proxy as unsafe_proxy
    import ansible.module_utils.basic as basic
    import ansible.utils.vault as vault

    _unsafe = unsafe_proxy.AnsibleUnsafeBytes('Hi!')
    _vault = vault.VaultLib('vault_password')
    _vault.decrypt(b"vaulted_text")


# Generated at 2022-06-22 21:35:36.630754
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Default ctor
    encoder = AnsibleJSONEncoder()

    # Ctor with kwargs
    encoder = AnsibleJSONEncoder(indent=2)

# Generated at 2022-06-22 21:35:48.116593
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_object1 = {'a': 1, 'b': 2, 'c': 3}
    test_object2 = [1, 2, 3]
    test_object3 = {'a': datetime.datetime.now(), 'b': datetime.date.today()}
    test_object4 = {'a': 1, 'b': "unsafe string", 'c': 3}
    test_object5 = [1, 'unsafe string', datetime.datetime.now(), 3]
    test_object6 = {'a': 1, 'b': 'unsafe string', 'c': datetime.datetime.now(), 'd': 3, }

    for test_object in [test_object1, test_object2, test_object3, test_object4, test_object5, test_object6]:
        result = Ansible

# Generated at 2022-06-22 21:35:51.463966
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(ansible_json_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-22 21:36:00.546883
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.six as six

    class NotString(six.text_type):

        def __new__(cls):
            return super(NotString, cls).__new__(cls, "NotString")

    # python 2 and python 3 differ in how json.JSONEncoder actually handles the case where
    # an object from a custom class inheriting from a string type is referenced.
    # in python 2, it will call the .__str__ method of the class, in python 3 it will
    # call the .__str__ method of the base class, which is what we want.
    # This unittest is not strictly required for ansible proper, it's just a sanity check
    # to make sure the right thing works in the right version.

# Generated at 2022-06-22 21:36:11.010099
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.urls import _UnsafeURLOpener

    v = VaultLib(b'password', 1)
    plaintext = b'this is a secret'
    ciphertext = v.encrypt(plaintext)
    vault = AnsibleUnsafeText(ciphertext)

    unsafe = AnsibleUnsafeText(b'foo')

    assert AnsibleJSONEncoder().default(vault) == {'__ansible_vault': to_text(ciphertext, errors='surrogate_or_strict')}

# Generated at 2022-06-22 21:36:15.190480
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(sort_keys=True)
    assert AnsibleJSONEncoder(indent=4)
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-22 21:36:17.001471
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        a = AnsibleJSONEncoder()
    except TypeError:
        return False
    return True


# Generated at 2022-06-22 21:36:22.583459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import types

    # Import inside the function because this would be an external dependency
    # which we don't want to add to the requirements of the module.
    # This is only used in this unit test anyway.
    from ansible.parsing.vault import VaultLib

    vault_password = "test_vault_password"
    vault = VaultLib(vault_password)
    text = "test_text"
    encrypted_text = vault.encrypt(text)

    # test with encrypted value
    assert AnsibleJSONEncoder().default(encrypted_text) == {'__ansible_vault': encrypted_text.vaulted()}
    assert AnsibleJSONEncoder(vault_to_text=True).default(encrypted_text) == encrypted_text

    # test with string instance and __ENCRYPTED__ attribute

# Generated at 2022-06-22 21:36:33.146061
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text import json

    # Test with preprocess_unsafe=True
    # Preprocess unsafe string
    unsafe_string = to_bytes('unsafe string')
    unsafe_bytes = json.AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_string)
    unsafe_dict = json.AnsibleJSONEncoder(preprocess_unsafe=True).iterencode({'unsafe': unsafe_string})
    assert json.loads(unsafe_bytes) == {'__ansible_unsafe': 'unsafe string'}

# Generated at 2022-06-22 21:36:42.304192
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    from ansible.module_utils.six.moves import filter

    from ansible.module_utils.common._collections_compat import MutableMapping

    # For backwards compatibility, filter is a built-in in python2,
    # but a method of the itertools module in python3
    if filter == builtins.filter:
        assert 'filter' not in itertools.__dict__, "filter is a method of itertools in python3, but not in python2"
    else:
        assert 'filter' in itertools.__dict__, "filter is a built-in in python2, but a method of itertools in python3"


# Generated at 2022-06-22 21:36:45.991136
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(AnsibleJSONEncoder().encode(True) == json.JSONEncoder().encode(True))
    try:
        AnsibleJSONEncoder(preprocess_unsafe=True)
    except TypeError:
        raise AssertionError("Unexpected error in AnsibleJSONEncoder constructor")


# Generated at 2022-06-22 21:36:53.321629
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types

    # should not encode strings to strings
    test_cases = [
        ["a", "b", "c"],  # list
        ["a", "b", "c"],  # not a tuple (a subclass of tuple)
        ("a", "b", "c"),  # tuple
        "abc",  # string
        ("a", string_types),  # tuple
        string_types,  # class
    ]
    for test_case in test_cases:
        ret = list(AnsibleJSONEncoder().iterencode(test_case))
        assert ret == test_case

# Generated at 2022-06-22 21:36:55.023338
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder.encode({'foo': 'bar'}) == '{"foo": "bar"}'

# Generated at 2022-06-22 21:36:57.436623
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    content = {"a": 123, "b": "abc", "c": "123", "d": "xxx"}
    print(json.dumps(content, cls=AnsibleJSONEncoder))

# Generated at 2022-06-22 21:37:07.033387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars import BaseVarsPlugin
    from ansible.vars import VariableManager

    # class MockVariableManager(VariableManager):
    #     def get_vault_secrets(self, vault_ids=None, enable_vault=True):
    #         return [{'vault_id': 'vault_id', 'vault_password': 'vault_password'}]

    variable_manager = VariableManager()

    # variable_manager = MockVariableManager(loader=None, inventory=None, version_info=None, host_vars=None, group_vars=None)
    vault_id = 'vault_id'
    vault_password = 'vault_password'


# Generated at 2022-06-22 21:37:18.208977
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    text_in = "hello world"
    expected_text_out = '"hello world"'
    expected_json_out = '{"__ansible_unsafe": "hello world"}'
    json_encoder = AnsibleJSONEncoder()

    # If a string is passed in, do not use the default
    text_out = json_encoder.default(text_in)
    assert expected_text_out == text_out

    # If an object is passed in, use the default
    json_out = json_encoder.default(AnsibleUnsafeText(text_in))
    assert expected_json_out == json_out

AnsibleJSONEncoder.add_functions = lambda self, test_item: None
AnsibleJSONEncoder.add_module_functions = lambda self, test_item: None
Ansible

# Generated at 2022-06-22 21:37:27.866827
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    if sys.version_info[0] == 2:
        from ansible.module_utils.six import BytesIO as StringIO
        from ansible.module_utils.six import b
    else:
        from io import BytesIO as StringIO
        from builtins import bytes as b

    class MyVault(object):
        __ENCRYPTED__ = True

        def __init__(self):
            self._ciphertext = 'blahblah'

    class MyUnsafe(object):
        __UNSAFE__ = True

    def my_dict():
        return {}

    a_vault = MyVault()
    a_unsafe = MyUnsafe()
    a_date = datetime.date(2010, 1, 1)

# Generated at 2022-06-22 21:37:36.942488
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import StringIO


# Generated at 2022-06-22 21:37:43.896192
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.six import text_type

    class CustomUnsafeClass(AnsibleUnsafe):
        def __repr__(self):
            return 'CustomUnsafeClass'

    class CustomUnsafeDict(dict):
        def __getitem__(self, key):
            return CustomUnsafeClass()

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    unsafe_string = 'unsafe'
    unsafe_obj = CustomUnsafeClass()
    unsafe_mapping = CustomUnsafeDict()
    vault_obj = VaultLib('password').vault_encode('vault')

# Generated at 2022-06-22 21:37:47.228960
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder, json.JSONEncoder)
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False


# Generated at 2022-06-22 21:37:58.547693
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault_conf import VaultConfig

    # Test with preprocess_unsafe enabled
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    o = {'unsafe': Formatter().vformat("{0}", ('1' * 1000), None)}
    res = next(encoder.iterencode(o))
    assert res == '{"unsafe": {"__ansible_unsafe": "1111111111"'

    o = {'unsafe': Formatter().vformat("{0}", ('1' * 1000))}
    res = next(encoder.iterencode(o))

# Generated at 2022-06-22 21:38:09.581796
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    test_string = "hello\nworld"
    # test the case when preprocess_unsafe is True
    assert encoder.iterencode(test_string) == '"hello\\nworld"'
    assert encoder.iterencode(b'\xc0\x80') == '"\\u0080"'
    # test the case when preprocess_unsafe is False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert encoder.iterencode(test_string) == '"hello\\nworld"'
    assert encoder.iterencode(b'\xc0\x80') == '"\\u0080"'



# Generated at 2022-06-22 21:38:19.475372
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    value = {"foo": "bar", "baz": {"a": "b"}}
    a = AnsibleJSONEncoder()
    # Testing that it can encode a JSON, without raising a exception
    # A `json.JSONEncodeError` is raised, if the function fails
    a.encode(value)
    a.default(value)
    a.iterencode(value)
    # Creating an instance, to test with a custom preprocess_unsafe, which
    # is a boolean
    a_preprocess_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    a_preprocess_unsafe.encode(value)
    a_preprocess_unsafe.default(value)
    a_preprocess_unsafe.iterencode(value)
    # Creating an instance, to test with a custom vault_

# Generated at 2022-06-22 21:38:29.889745
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.types import AnsibleUnsafe
    from ansible.module_utils.six import u, b
    from ansible.module_utils.six.moves.urllib.request import pathname2url
    from ansible.module_utils.six.moves.urllib.parse import urlsplit

    # Testing with VaultSecret in the list
    secret_obj = VaultSecret(VaultSecret.AES256.name, b'secret', to_text(u'ad-hoc'))

# Generated at 2022-06-22 21:38:42.568686
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    test_vault_pw_file = '../../lib/ansible/test/test_vault.txt'
    test_json_file = '../../lib/ansible/test/test_json_encoder_iterencode.json'
    test_json_data = {
            "vault": "{{ 'this is the vault' | vault('secret', test_vault_pw_file, 'vault_pw_file') }}",
            "unsafe": "{{ 'this is the unsafe' | unsafe_proxy }}",
            "str": "this is the string"
            }

# Generated at 2022-06-22 21:38:45.115307
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder(False, False)
    assert(json_encoder._preprocess_unsafe == False)
    assert(json_encoder._vault_to_text == False)

# Generated at 2022-06-22 21:38:56.340965
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create a VaultLib object
    vault = VaultLib([])
    secret = VaultSecret(password='password')

    # Create some unsafe strings
    unsafe_unicode = u'\u2713'
    unsafe_unicode_encrypted = vault.encrypt(secret, unsafe_unicode)
    unsafe_bytes = b'\xe2\x9c\x93'
    unsafe_bytes_encrypted = vault.encrypt(secret, unsafe_bytes)

    # Create some unsafe strings with non-string types
    unsafe_int = 1

# Generated at 2022-06-22 21:39:02.214589
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    def __init__(self, *args, **kwargs):
        return

    assert hasattr(AnsibleJSONEncoder, '__init__')
    assert callable(AnsibleJSONEncoder.__init__)
    assert __init__.__code__ == AnsibleJSONEncoder.__init__.__code__



# Generated at 2022-06-22 21:39:10.351716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.json_utils import AnsibleUnsafeText, AnsibleUnsafe

    # Test bool type
    bool_true = 'true'
    bool_false = 'false'
    assert check_type_bool(bool_true), 'test failed for check_type_bool, it returned False for a boolean True'
    assert check_type_bool(bool_false), 'test failed for check_type_bool, it returned False for a boolean False'

    # Test str type


# Generated at 2022-06-22 21:39:13.154881
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    except Exception as e:
        print(e)
        return False
    return True

# Generated at 2022-06-22 21:39:24.999371
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Create a dictionary with different types of objects
    # which have to be serialized
    dict_test = dict()
    dict_test['string_key'] = 'string_value'
    dict_test['int_key'] = 123
    dict_test['float_key'] = 123.45
    dict_test['bool_key'] = True
    dict_test['list_key'] = [1,2,3]
    dict_test['dict_key'] = {'1':'1','2':'2','3':'3'}
    dict_test['datetime_key'] = datetime.datetime.now()
    dict_test['date_key'] = datetime.datetime.now().date()
    dict_test['unsafe_key'] = 'I am unsafe'
    dict_test['unsafe_key'].__

# Generated at 2022-06-22 21:39:36.567516
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.text.converters import to_unicode

    vault_pwd = [('vault_password', 'secret')]
    vault = VaultLib(password=vault_pwd)
    vault_str = vault.encode('secret')
    unsafe_str = to_unicode(AnsibleUnsafe(b'unsafe', vault_str))
    data = {'foo': 'bar', 'vault': vault, 'unsafe': unsafe_str, 'list': [vault, unsafe_str, 'yay']}

    from ansible.utils.unicode import to_bytes

# Generated at 2022-06-22 21:39:47.605054
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime
    cases = (
        (dict(p1="p1", p2="p2"), {"p1": "p1", "p2": "p2"}),
        ({"p1": "p1", "p2": "p2"}, {"p1": "p1", "p2": "p2"}),
        ("p1", "p1"),
        (1, 1),
        (None, None),
        (VaultLib("password"), {'__ansible_vault': 'vaulted_pw'}),
        (datetime.datetime(2017,4,1,14,30,45), '2017-04-01T14:30:45'),
        )
    aje = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:39:51.072577
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass:
        test_dict_value = {
            'private_key': "ssh-rsa aaa bbb ccc",
            'junk_value': "12345",
            'zabbix_password': "passwd",
            'second_pkey': "ssh-rsa ddd eee fff",
            'zabbix_user': "user",
        }


# Generated at 2022-06-22 21:40:00.485314
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Define a small class that inherited from AnsibleVault
    class SampleAnsibleVault(object):
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

        def __str__(self):
            return "Encrypted text"

    # Define a small class that inherited from AnsibleUnsafe
    class SampleAnsibleUnsafe(object):
        __UNSAFE__ = True

        def __init__(self, content):
            self._content = content

        def __str__(self):
            return "Encrypted text"

    # Define a small class that inherited from the class Mapping
    class SampleMapping(Mapping):
        def __init__(self, mapping):
            self._mapping = mapping


# Generated at 2022-06-22 21:40:12.810954
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Basic constructor test
    aje = AnsibleJSONEncoder()
    assert aje.ensure_ascii is True
    assert aje.indent is None
    assert aje.sort_keys is False
    assert aje.check_circular is True
    assert aje.allow_nan is True
    assert aje.preprocess_unsafe is False
    assert aje.vault_to_text is False

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import decrypt_text


# Generated at 2022-06-22 21:40:14.884727
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleUnsafe(u"")
    assert AnsibleJSONEncoder().default(o) == {'__ansible_unsafe': u""}



# Generated at 2022-06-22 21:40:25.153376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    import ansible.utils.unsafe_proxy

    assert AnsibleJSONEncoder().encode({'a': 1, 'b': '2'}) == json.dumps({'a': 1, 'b': '2'}, sort_keys=True)
    assert AnsibleJSONEncoder().encode([4, 5, 6]) == json.dumps([4, 5, 6], sort_keys=True)

    vaulted_text = ansible.parsing.vault.EncryptedText.create_or_update_encrypted_text('test_password', 'Foo!')
    assert AnsibleJSONEncoder().encode(vaulted_text) == u'{"__ansible_vault": "AQAAAAAAMU1TZm9vIQ==\\n"}'
    assert Ans