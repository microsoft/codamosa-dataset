

# Generated at 2022-06-22 21:30:34.954394
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2

    secret_value = 'secret password'
    encrypted_header = '$ANSIBLE_VAULT;1.1;AES256'

    try:
        from ansible.module_utils._text import to_bytes, to_text
    except ImportError:
        to_bytes = to_text = lambda x, *args, **kwargs: x

    # vault object
    o_vault_obj = VaultLib(None).encrypt(to_text(secret_value))
    json_o_vault_obj = AnsibleJSONEncoder().default(o_vault_obj)
    assert isinstance(json_o_vault_obj, Mapping)
    if PY2:
        assert json_o_

# Generated at 2022-06-22 21:30:41.967810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    vault_str = to_text(vault.encrypt('str'))
    json_str = '{"__ansible_vault": "%s"}' % vault_str

    assert AnsibleJSONEncoder(sort_keys=True).encode(vault) == json_str
    assert AnsibleJSONEncoder(sort_keys=True, vault_to_text=True).encode(vault) == '"%s"' % vault_str


# Generated at 2022-06-22 21:30:42.901833
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(indent=4)

# Generated at 2022-06-22 21:30:53.424198
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    assert AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True).iterencode(
        AnsibleUnsafe('safe text')
    ) == b'{"__ansible_unsafe": "safe text"}'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True).iterencode(
        AnsibleUnsafeText('safe text')
    ) == b'{"__ansible_unsafe": "safe text"}'

# Generated at 2022-06-22 21:31:05.325201
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import sys
    import random
    if sys.version_info < (3, 0):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.common._collections_compat import Mapping

    @unittest.skipIf(sys.version_info < (3, 0), 'python < 3.0 does not provide unittest.skip')
    class TestAnsibleJSONEncoder(unittest.TestCase):

        def setUp(self):
            self.count = 0

        def test_dict(self):
            self.count += 1
            a_dict = {'a': random.randint(1, 30), 'b': random.randint(1, 30)}

# Generated at 2022-06-22 21:31:07.048788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    print(aje.default('foo'))

# Generated at 2022-06-22 21:31:10.225150
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    testdate = datetime.datetime(2019, 1, 1, 12, 0, 0)
    assert '2019-01-01T12:00:00' == AnsibleJSONEncoder().default(testdate)

# Generated at 2022-06-22 21:31:17.435710
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert unsafe_encoder.default({}) == {}
    assert unsafe_encoder.default({"one": 1, "two": "2", "three": 3.0}) == {"one": 1, "two": "2", "three": 3.0}
    assert unsafe_encoder.default({"unsafe": "password"}) == {"unsafe": {"__ansible_unsafe": "password"}}
    assert unsafe_encoder.default(["password"]) == [{"__ansible_unsafe": "password"}]
    assert unsafe_encoder.default([{'unsafe': "password"}]) == [{'unsafe': {"__ansible_unsafe": "password"}}]

# Generated at 2022-06-22 21:31:25.948860
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_object = {'test_str': 'Test string',
                   'test_dict': {'test_dict_key': 'Test dict key'},
                   'test_list': ['test_list_item'],
                   'test_int': 5,
                   'test_float': 7.5}

    expected_result = '{"test_float": 7.5, "test_int": 5, "test_str": "Test string", "test_dict": {"test_dict_key": "Test dict key"}, "test_list": ["test_list_item"]}'
    result_encoder = AnsibleJSONEncoder().encode(test_object)
    assert result_encoder == expected_result

# Generated at 2022-06-22 21:31:37.071552
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.json_utils import AnsibleUnsafe
    from ansible.module_utils.six import text_type

    # simple string
    input = text_type('simple')
    output = text_type('"simple"')
    assert list(AnsibleJSONEncoder().iterencode(input)) == [output]

    # unicode string
    input = text_type('\u2764')
    output = text_type('"\\u2764"')
    assert list(AnsibleJSONEncoder().iterencode(input)) == [output]

    # AnsibleUnsafe string only
    input = AnsibleUnsafe(text_type('simple'))
    output = text_type('{"__ansible_unsafe": "simple"}')

# Generated at 2022-06-22 21:31:43.813261
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    d = {
            "int": 1,
            "float": 2.0,
            "string": "string",
            "unicode": u'\u2713',
            "list": [1, 2, 3],
            "dict": {'a': 1, 'b': 2, 'c': 3},
            "bool": True
        }

    assert AnsibleJSONEncoder().encode(d) == json.dumps(d)



# Generated at 2022-06-22 21:31:54.613262
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import json
    import textwrap
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # Tests data

# Generated at 2022-06-22 21:31:56.209854
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    val = AnsibleJSONEncoder()
    assert val


# Generated at 2022-06-22 21:32:00.548489
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder()
    s = [{'code': '123456', 'name': 'hello'}, 1, 2, 'str', u'unicode', [1, 2], {'key': 'value'}]
    for i in s:
        assert isinstance(o.default(i), type(i))



# Generated at 2022-06-22 21:32:12.774276
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO as BytesIO
    else:
        from cStringIO import StringIO as BytesIO

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import ansible.module_utils.basic

    vault_password = 'vault_password'

    vault_secret = VaultSecret(vault_password)
    vault_lib = VaultLib([vault_secret])

    encoder = AnsibleJSONEncoder(indent=4, sort_keys=True, preprocess_unsafe=True, vault_to_text=False)
    ansible_vault_ciphertext = vault_lib.encrypt(b"abc")
    result = ansible.module

# Generated at 2022-06-22 21:32:24.735988
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Case1: Test for Mapping objects
    hostvars = {
        'localhost': {
            'foo': 'bar'
        }
    }
    ansible_json_encoder = AnsibleJSONEncoder()
    asserts = [json.dumps(hostvars), ansible_json_encoder.encode(hostvars)]
    for item in asserts:
        assert item == '''{"localhost": {"foo": "bar"}}'''

    # Case2: Test for Sequence objects
    hostvars2 = [
        {
            'foo': 'bar'
        }
    ]
    ansible_json_encoder2 = AnsibleJSONEncoder()
    asserts2 = [json.dumps(hostvars2), ansible_json_encoder2.encode(hostvars2)]

# Generated at 2022-06-22 21:32:33.161401
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # This is the result we expect the json.dumps to return
    expected_json_str_output = '[{"name": "ansible", "id": 799},' \
                               ' {"name": "security", "id": 951}]'

    # 1. Input dictionary
    input_dict = {'name': 'ansible', 'id': 799}

    # Convert the input into JSON String
    json_str = json.dumps(input_dict, cls=AnsibleJSONEncoder)

    # If the JSON String matches with expected JSON String, then test case passes
    # else test case fails
    assert json_str == expected_json_str_output

# Generated at 2022-06-22 21:32:38.137774
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True

# Generated at 2022-06-22 21:32:48.974532
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe_obj = AnsibleUnsafe('this is unsafe', encode_as=to_text)
    test_cases = (
        (unsafe_obj, {'__ansible_unsafe': 'this is unsafe'}),
        (AnsibleVaultEncryptedUnsafeText('test'), {'__ansible_vault': 'test'}),
        (datetime.datetime(2014, 11, 22, 14, 12, 30, 200000), '2014-11-22T14:12:30.200000'),
        ({'a': 'test'}, {'a': 'test'}),
        (['test'], ['test']),
        ({}, {}),
        ("test", "test"),
        (1, 1),
        (1.0, 1),
        (True, True),
    )


# Generated at 2022-06-22 21:32:49.826968
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder().__init__()

# Generated at 2022-06-22 21:32:51.253467
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert isinstance(a, AnsibleJSONEncoder)



# Generated at 2022-06-22 21:32:56.167542
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type

    unsafe_text = u'\u2026'
    unsafe_obj = binary_type(unsafe_text, encoding='utf8')
    unsafe_obj.__UNSAFE__ = True

    json_str = json.dumps(
        unsafe_obj, cls=AnsibleJSONEncoder,
        sort_keys=True, indent=2, ensure_ascii=False)

    assert json_str == '{\n  "__ansible_unsafe": "\\u2026"\n}'

# Generated at 2022-06-22 21:33:06.461110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    import datetime


# Generated at 2022-06-22 21:33:18.142119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    __ENCRYPTED__ = True
    __UNSAFE__ = True
    __ENCRYPTED_STRING__ = True
    __UNSAFE_STRING__ = True
    __CERTIFICATE__ = True

    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 21:33:19.370597
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-22 21:33:27.601833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=protected-access
    # Force the JSON encoder to always use a string as a starting point
    encoder = AnsibleJSONEncoder(ensure_ascii=False, sort_keys=True)

    # Objects that define a default can be encoded directly
    class TestDefault(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

        def __json__(self):
            return self.value

    test_default_value = TestDefault('test_default_value')

    assert 'test_default_value' == encoder.default(test_default_value)

    # Types with a default must be wrapped for JSON

# Generated at 2022-06-22 21:33:33.399483
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create an AnsibleJSONEncoder instance
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # Test that it is a instance of AnsibleJSONEncoder
    assert isinstance(json_encoder, AnsibleJSONEncoder)


# Generated at 2022-06-22 21:33:38.504439
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class MyTest():

        def __init__(self, name):
            self._name = name

        def __repr__(self):
            return self._name

    assert AnsibleJSONEncoder().default(5) == 5
    assert AnsibleJSONEncoder().default('hi') == 'hi'
    assert AnsibleJSONEncoder().default(MyTest('test')) == {'_name': 'test'}


# Generated at 2022-06-22 21:33:45.464819
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test') == 'test'
    assert encoder.default(b'test') == 'test'
    assert encoder.default(123) == 123
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(dict(a=1, b=2)) == dict(a=1, b=2)

# Generated at 2022-06-22 21:33:54.813375
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible.module_utils.connection_loader

    a = ansible.module_utils.connection_loader.ConnectionBase()
    assert AnsibleJSONEncoder().default(a) == a
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, indent='4').default(a) == a
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, indent='4', sort_keys=True).default(a) == a
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, indent='4', sort_keys=True, separators=(', ', ': ')).default(a) == a

# Generated at 2022-06-22 21:34:01.162932
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    o = [{'key': 'value'}, {'key2': 'value2'}, {'key3': ['value3', 'value4']}, {'key4': ['value5', 'value6']}, {'key5': {'key6': 'value7', 'key7': 'value8'}}]
    assert _preprocess_unsafe_encode(o) == o


# Generated at 2022-06-22 21:34:02.180117
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder


# Generated at 2022-06-22 21:34:10.603873
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Setup some test classes
    class SemiSafe:
        pass

    class Safe:
        pass

    class Unsafe:
        pass

    Unsafe.__UNSAFE__ = True

    # Setup some test inputs
    inputs = (
        (SemiSafe, None),
        (Safe, None),
        (Unsafe, '{"__ansible_unsafe": "Unsafe"}'),
        (SemiSafe, None),
        (Safe, None),
        (Unsafe, '{"__ansible_unsafe": "Unsafe"}'),
    )

    # Setup the encoder
    enc = AnsibleJSONEncoder(preprocess_unsafe=True, indent=4)

    for input, expected in inputs:
        itr = enc.iterencode(input)
        actual = ''.join(itr)

# Generated at 2022-06-22 21:34:20.478289
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    try:
        from __main__ import AnsibleUnsafeText as AnsibleUnsafe
    except ImportError:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText as AnsibleUnsafe

    data = {
        'a': 1,
        'b': 'b',
        'c': AnsibleUnsafe("c"),
    }
    test_output = '[{"a":1},{},{"b":"b"},{},{"c":{"__ansible_unsafe":"\\"c\\""}}]'
    test_output = [x.encode("utf-8") for x in test_output.split(',')]
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    result = []
    for chunk in ansible_json_encoder.iterencode(data):
        result

# Generated at 2022-06-22 21:34:29.697534
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class TestData(object):
        pass

    test_data1 = TestData()
    test_data1.attr = 1
    test_data1.attrstr = 's'

    test_data2 = TestData()
    test_data2.attr = 1
    test_data2.attrstr = 's'

    test_data3 = TestData()
    test_data3.attr = 1
    test_data3.attrstr = VaultLib('123')

    test_data4 = TestData()
    test_data4.attr = 1
    test_data4.attrstr = VaultLib('123')

    ansiblejsonencoder1 = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:34:32.201799
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Creating an instance of AnsibleJSONEncoder
    encoder=AnsibleJSONEncoder()
    # Checking if the type is correct.
    assert isinstance(encoder, json.JSONEncoder) == True

# Generated at 2022-06-22 21:34:39.179360
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    # test object
    o = {
        'text': 'hello',
        'safe': 'world',
        'unsafe': ansible.parsing.vault.AnsibleUnsafeText('unsafe string')
    }
    assert json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=False) == "{\"text\": \"hello\", \"safe\": \"world\", \"unsafe\": \"__ansible_unsafe__:dW5zYWZlIHN0cmluZwo=\"}"

# Generated at 2022-06-22 21:34:50.521114
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    import datetime

    def test_equal(a, b):
        print(a, b)

        assert(a == b)

    data = {
        'timestamp': datetime.datetime.now(),
        'time': datetime.time(1, 2, 3),
        'date': datetime.date(2012, 12, 12),
        'complex': {
            'complex2': {
                'a': 1,
                'b': 2,
                'c': 3,
            },
            'b': 2,
            'c': 3,
        }
    }

    print(json.dumps(data, cls=AnsibleJSONEncoder))


# Generated at 2022-06-22 21:34:52.252620
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()
    assert obj._preprocess_unsafe == False


# Generated at 2022-06-22 21:35:03.917580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ''' Unit test for AnsibleJSONEncoder default method '''
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type


# Generated at 2022-06-22 21:35:13.661109
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True

    # test_cases are lists of inputs and expected outputs

# Generated at 2022-06-22 21:35:19.007226
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-22 21:35:28.729022
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Create a mocked object which is a instance of AnsibleUnsafe
    unsafe_obj = {'__ansible_unsafe': 'test'}
    # Create a mocked object which is a instance of AnsibleVaultEncryptedUnicode
    vault_obj = {'__ansible_vault': 'test'}

    # Test for inputing only one object of AnsibleUnsafe
    obj = iter([unsafe_obj])
    assert(list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(obj)) == [unsafe_obj])

    # Test for inputing an object which has a sub-object of AnsibleUnsafe
    obj = [unsafe_obj]
    assert(list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(obj)) == [unsafe_obj])



# Generated at 2022-06-22 21:35:38.144339
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    class AnsibleUnsafe(str):
        def __init__(self, unsafe_text, *args, **kwargs):
            self.__UNSAFE__ = True
            super(AnsibleUnsafe, self).__init__(unsafe_text, *args, **kwargs)

    # Notice:
    #   the class AnsibleJSONEncoder is not importable outside the ansible.module_utils.json_utils
    #   Hence we created a new class in order to test the behavior of iterencode.

# Generated at 2022-06-22 21:35:46.041831
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    Test AnsibleJSONEncoder when preprocess_unsafe is True
    """
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    json_data = json.dumps({'foo': AnsibleUnsafeText(b'bar')}, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert json_data == '{"foo": {"__ansible_unsafe": "bar"}}'

# Generated at 2022-06-22 21:35:56.704726
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Encoding when vault_to_text is False
    encoder = AnsibleJSONEncoder(vault_to_text=False)

    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    value = vault.encrypt("some_value")
    assertion = {'__ansible_vault': value}

    assert encoder.default(value) == assertion

    # Encoding when vault_to_text is True
    encoder = AnsibleJSONEncoder(vault_to_text=True)

    value = '$ANSIBLE_VAULT;1.1;AES256'
    assertion = value

    assert encoder.default(value) == assertion

    # test default
    from ansible.parsing.vault import VaultSecret
    value = VaultSecret('VaultSecret')
    assertion

# Generated at 2022-06-22 21:36:05.120777
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''
    Test AnsibleJSONEncoder.iterencode
    '''
    import ansible.parsing.vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    clear_text = "This is clear text string."
    vault_text = "This is vault text string."

    clear_password = AnsibleUnsafe(clear_text)
    vault_password = ansible.parsing.vault.VaultLib().encrypt(
        vault_text,
        keys=['foo'])

    test_password_list = [clear_password, vault_password]

    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    json_str = json_encoder.encode(test_password_list)


# Generated at 2022-06-22 21:36:15.244645
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    import datetime
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleUnsafe

    # default
    data = {'a': 'a', 'b': 2}
    json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    assert json_data == '{"a": "a", "b": 2}'

    # unsafe
    data = {'a': AnsibleUnsafe("a"), 'b': 2}
    json_data = json.dumps(data, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:36:23.074151
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    test_values = [
        [AnsibleUnsafeText(u'str'), AnsibleUnsafeBytes(b'bytes')], {AnsibleUnsafeText(u'key'): AnsibleUnsafeText(u'value')}
    ]

    for test_val in test_values:
        assert json.loads(json.dumps(test_val, cls=AnsibleJSONEncoder)) == test_val

    vault_password = AnsibleUnsafeText(u'password')
    test_val_vault = VaultLib(vault_password).encrypt(AnsibleUnsafeText(u'my-secret'))

# Generated at 2022-06-22 21:36:32.060464
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:36:40.982300
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    a = AnsibleUnsafeText(u"my string")
    b = AnsibleUnsafeBytes(b"my string")
    test_dict = {u"a": a, u"b": b, u"c": 1, u"d": "hi"}
    test_list = [a, b, 1, "hi"]

    # Preprocess will encode Unsafe into json dict
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    iter_list = encoder.iterencode(test_dict)
    iter_list = list(iter_list)

# Generated at 2022-06-22 21:36:50.651892
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # create a vault
    password = 'ansible'
    vault = VaultLib([(password,)])
    plaintext = 'secret'
    ciphertext = vault.encrypt(plaintext)
    vault_object = VaultSecret(ciphertext)

    # create a datetime object
    date_time_str = '2020-05-29T09:00:00.000'
    date_object = datetime.datetime.strptime(date_time_str, '%Y-%m-%dT%H:%M:%S.%f')

    # create a hostvars object
    hostvars_object = dict()

# Generated at 2022-06-22 21:36:58.597938
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    import base64
    import dateutil.parser
    import codecs
    from ansible.module_utils.six.moves import range

    # test case 1
    o = MutableMapping(a_key='a value')
    assert AnsibleJSONEncoder().default(o) == {u'a_key': u'a value'}

    # test case 2
    o = b'12345'
    assert AnsibleJSONEncoder().default(o) == '12345'

    # test case 3
    o = '12345'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(o) == '12345'

    # test case 4
   

# Generated at 2022-06-22 21:36:59.780427
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # is this same as test_AnsibleUnsafe?
    pass

# Generated at 2022-06-22 21:37:02.680182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass:
        test_field = 'test'

    obj = TestClass()
    print(AnsibleJSONEncoder().encode(obj))


# Generated at 2022-06-22 21:37:09.565210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = dict(a="b", b=dict(c=json.dumps(dict(e=dict(z=['one', 'two'])))))
    dumped = AnsibleJSONEncoder().default(d)
    assert d == dumped

    d = dict(a="b", b=dict(c=json.dumps(dict(e=dict(z=['one', 'two'])))))
    dumped = AnsibleJSONEncoder().default(d)
    assert d == json.loads(json.dumps(dumped))

# Generated at 2022-06-22 21:37:16.333992
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    value = "abcd"
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).encode(value) == '"abcd"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).encode(value) == '"abcd"'
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).encode(value) == '"abcd"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode(value) == '"abcd"'



# Generated at 2022-06-22 21:37:26.627172
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    def _json_round_trip(o):
        return json.loads(json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=True))

    vault = VaultLib(bytes(b'ansible'))
    assert json.loads(json.dumps(vault.encrypt(to_text(u'secret', errors='surrogate_or_strict')), cls=AnsibleJSONEncoder)) == json.loads(json.dumps(vault.encrypt(to_text(u'secret', errors='surrogate_or_strict')), cls=AnsibleJSONEncoder, preprocess_unsafe=True))
    assert _json_

# Generated at 2022-06-22 21:37:31.224171
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        e = AnsibleJSONEncoder()
        assert True
        print("AnsibleJSONEncoder - No exception raised")
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-22 21:37:42.074845
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import pytest

    def no_vault_and_no_encoded_unsafe(input):
        try:
            return not ('__ansible_vault' in input) and not ('__ansible_unsafe' in input)
        except TypeError:
            return False

    def vault_exists_and_no_encoded_unsafe(input):
        try:
            return ('__ansible_vault' in input) and not ('__ansible_unsafe' in input)
        except TypeError:
            return False

    def no_vault_but_encoded_unsafe(input):
        try:
            return not ('__ansible_vault' in input) and ('__ansible_unsafe' in input)
        except TypeError:
            return False


# Generated at 2022-06-22 21:37:51.401025
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    # setup vault and unsafe strings
    vault_text = "encrypted value"
    vault = VaultLib([])
    vault_pw = vault_text.encode('utf-8')
    vault_encoded = vault.encrypt(vault_pw)

    unsafe_text = "value"
    unsafe = AnsibleUnsafe(unsafe_text)

    # setup a nested data structure that should get completely stringified

# Generated at 2022-06-22 21:38:01.491981
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_datetime import from_datetime, to_datetime
    from ansible.module_utils.six import string_types

    def __PREPROCESS_UNSAFE_ENCODE(value):
        from ansible.module_utils.common.collections import is_sequence
        import json

        if _is_unsafe(value):
            value = {'__ansible_unsafe': to_text(value, errors='surrogate_or_strict', nonstring='strict')}
        elif is_sequence(value):
            value = [__PREPROCESS_UNSAFE_ENCODE(v) for v in value]

# Generated at 2022-06-22 21:38:05.420021
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a.item_separator == ', '
    assert a.key_separator == ': '
    assert a.sort_keys is False


# Generated at 2022-06-22 21:38:17.120256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO

    # Create encrypted file
    vault_file = StringIO()
    vault_pass = 'ansible'
    vault = VaultLib(vault_pass)
    vault_file.write(vault.encrypt(to_text(b'blackbox')))
    vault_file.flush()

    # Start test
    encoder = AnsibleJSONEncoder()
    result = encoder.default(get_file_content(vault_file.name))

    assert isinstance(result, dict)

# Generated at 2022-06-22 21:38:21.259040
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    e = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    o = {"foo": "bar"}
    assert e.iterencode(o) == '{"foo":"bar"}'

# Generated at 2022-06-22 21:38:32.586316
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-22 21:38:44.503747
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import Mapping
    import datetime

    # hostvars and other objects
    d = dict(a=1, b=2, c=3)
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(d) == dict(a=1, b=2, c=3)

    # date object
    import datetime
    dt = datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc)
    ansible_json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:38:49.710844
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert aje._preprocess_unsafe
    assert not aje._vault_to_text
    aje = AnsibleJSONEncoder(vault_to_text=True)
    assert aje._vault_to_text
    assert not aje._preprocess_unsafe

# Generated at 2022-06-22 21:38:55.271003
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    json_text = json.dumps("some string")
    # instantiate AnsibleJSONEncoder class with argument preprocess_unsafe as false and dumps the json_text
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(json_text)
    assert json_text == ''.join(json_encoder)


# Generated at 2022-06-22 21:39:07.289664
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # Test for __ENCRYPTED__
    value = encoder.default(object.__new__(str))
    assert value == ""
    value = encoder.default(type('VaultSecret', (str,), {'__ENCRYPTED__': True})("s3cr3t"))
    assert value == {'__ansible_vault': "s3cr3t"}
    value = encoder.default(type('VaultSecret', (str,), {'__ENCRYPTED__': True, '__VAULT_TO_TEXT__': True})("s3cr3t"))
    assert value == "s3cr3t"
    # Test for __UNSAFE__

# Generated at 2022-06-22 21:39:16.408934
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    iterable = encoder.iterencode('"foo"')
    json_output = [x for x in iterable]
    assert json_output == ['\"', 'f', 'o', 'o', '\"']

    iterable = encoder.iterencode('foo')
    json_output = [x for x in iterable]
    assert json_output == ['\"', 'f', 'o', 'o', '\"']

    iterable = encoder.iterencode([])
    json_output = [x for x in iterable]
    assert json_output == ['[', ']']

    iterable = encoder.iterencode((1, 2, 3))
    json_output = [x for x in iterable]

# Generated at 2022-06-22 21:39:23.405401
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    json_string = json.dumps("string",cls=AnsibleJSONEncoder, indent=4)
    assert json_string == '"string"'

    json_bool = json.dumps(True,cls=AnsibleJSONEncoder, indent=4)
    assert json_bool == "true"

    json_int = json.dumps(1,cls=AnsibleJSONEncoder, indent=4)
    assert json_int == "1"


# Generated at 2022-06-22 21:39:35.022646
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret, VaultAES256
    from ansible.vars.unsafe_proxy import wrap_var

    s = "test secret"
    w = wrap_var(s)  # AnsibleSafeText
    wu = w.__UNSAFE__() # AnsibleUnsafeText
    vs = VaultSecret(s)  # VaultSecret
    vu = VaultSecret.load(vs.encode('utf-8')).__UNSAFE__()  # VaultUnsafeSecret
    b = bytes(s, 'utf-8')  # bytes
    bwu =  bytes(wu, 'utf-8')  # bytes

    expected_unsafe_result = '{"__ansible_unsafe": "test secret"}'

# Generated at 2022-06-22 21:39:46.350162
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe
    import ansible.vars.unsafe_proxy as unsafe


# Generated at 2022-06-22 21:39:56.766500
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.hostvars import HostVarsVars
    import datetime

    # Test case: basic string
    data_str = 'basic_str'
    expect_str = '"basic_str"'
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    json_str = b''.join(encoder.iterencode(data_str))
    assert json_str == expect_str

    # Test case: unsafe string
    data_unsafe = AnsibleUnsafe('unsafe_str')
    expect_unsafe = '{"__ansible_unsafe": "unsafe_str"}'

# Generated at 2022-06-22 21:39:58.796207
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert(isinstance(json_encoder, AnsibleJSONEncoder))


# Generated at 2022-06-22 21:40:05.830501
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_unicode

    class TestItem:
        def __init__(self, *args, **kwargs):
            super(TestItem, self).__init__(*args, **kwargs)

        def __str__(self):
            return "TestItem"

    class TestItemUnsafe(to_unicode):
        def __init__(self, *args, **kwargs):
            super(TestItemUnsafe, self).__init__(*args, **kwargs)

        def __str__(self):
            return "TestItemUnsafe"


# Generated at 2022-06-22 21:40:17.060161
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    vault_json_data_py2 = u'{"__ansible_vault": "AQAAAAEAACtyMzI1NDY5MQAuAAAAbwAAAG8AAABjY2ExOGE4LTY4NDMtNGUzNC1hNTc0LTdkYzFjYjZhYmYxNmQAAAAALgAAAAIAAABEaWQAAAAIcG9zdGVjb25mb3JtYXRpb25fcGljdHVyZV9hbGxvdw=="}'

# Generated at 2022-06-22 21:40:18.805948
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansibleJSONEncoder = AnsibleJSONEncoder()
    assert ansibleJSONEncoder.__class__.__name__ == "AnsibleJSONEncoder"


# Generated at 2022-06-22 21:40:29.735586
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    class TestVault(text_type):
        __ENCRYPTED__ = True
        _ciphertext = "XXXXX"

    class TestUnsafe(text_type):
        __UNSAFE__ = True

    vault_password = "test"
    vault = VaultLib(vault_password)
    key = "secret password"
    value = "my secret is safe"
    encrypted = vault.encrypt(value)
    test_dict = {
        "vault_test": TestVault(encrypted),
        "unsafe_test": TestUnsafe(value),
        "normal_test": "test"
    }

    # test normal case
    json_str = json