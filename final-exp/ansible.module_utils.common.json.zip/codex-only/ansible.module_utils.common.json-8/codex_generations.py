

# Generated at 2022-06-22 21:30:30.900953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_obj = {'a': 1, 'b': 2}
    assert '"a": 1, "b": 2' in json.dumps(test_obj, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:30:41.224699
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import json
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    # objects
    v = VaultLib([])
    vault = v.encrypt("password")
    vau = VaultEditor(vault)
    unsafe = ImmutableDict({"key": "value"})
    unsafe.__UNSAFE__ = True
    ansible_unsafe = ImmutableDict({"key": "value"})
    ansible_unsafe.__UNSAFE__ = True
    ansible_unsafe.__ENCRYPTED__ = True
    pristine_unsafe = ImmutableDict({"key": unsafe})

    # strings

# Generated at 2022-06-22 21:30:50.967226
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # build unsafe object
    class AnsibleUnsafe(str):
        __UNSAFE__ = True
    unsafe_obj = AnsibleUnsafe(u'unsafe string')
    # build vault object
    class AnsibleVault(str):
        __ENCRYPTED__ = True
    vault_obj = AnsibleVault(u'vault string')

    test_data = {'safe': u'safe string', 'unsafe': unsafe_obj, 'vault': vault_obj}
    test_data_json_default_encoder = json.dumps(test_data)
    test_data_json_custom_encoder = json.dumps(test_data, cls=AnsibleJSONEncoder)
    assert(test_data_json_default_encoder == test_data_json_custom_encoder)

    test

# Generated at 2022-06-22 21:31:00.586591
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText as AUT
    o = [{'foo':AUT('bar'),'bax':AUT('baz')}]
    expected_o = [{'foo':{'__ansible_unsafe':'bar'},'bax':{'__ansible_unsafe':'baz'}}]
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o)) == expected_o
    # Make sure that we did not change the original data structure
    assert o == [{'foo':AUT('bar'),'bax':AUT('baz')}]


# Generated at 2022-06-22 21:31:10.441104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe = AnsibleJSONEncoder().encode("$ANSIBLE_VAULT;1.1;AES256\n123\n456\n")
    ansible_vault = AnsibleJSONEncoder().encode("$ANSIBLE_VAULT;1.1;AES256\n123\n456\n")
    ansible_date = AnsibleJSONEncoder().encode(datetime.date(2020, 1, 1))
    ansible_dict = AnsibleJSONEncoder().encode({'k': 'v'})
    assert ansible_unsafe == ansible_vault == ansible_date == ansible_dict == '{"k": "v"}'

# Generated at 2022-06-22 21:31:12.213768
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert isinstance(json_encoder, json.JSONEncoder)

# Generated at 2022-06-22 21:31:22.994260
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible
    test_input = {
        "__ansible_version__": ansible.__version__,
        "test_dict": {
            "test_value": True,
            "test_list": [
                "__ansible_unsafe_wrapper__",
                "test_item1",
                "test_item2"
            ]
        }
    }
    test_output = json.dumps(
        test_input,
        sort_keys=True,
        indent=4,
        separators=(',', ': '),
        cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:31:32.933459
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    # test preprocess_unsafe
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False
    b = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert b._preprocess_unsafe == True
    assert b._vault_to_text == False
    # test vault_to_text
    assert b._vault_to_text == False
    c = AnsibleJSONEncoder(vault_to_text=True)
    assert c._vault_to_text == True
    assert c._preprocess_unsafe == False

# Generated at 2022-06-22 21:31:44.134948
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.ansible_modlib.unsafe_proxy import AnsibleUnsafeText, wrap_var

    vault_secret_data = 'VaultEncodedValue'
    vault_password = 'VaultPassword'
    encrypted_data = VaultLib([], {}, None, None, make_autosign_file=False).encrypt(vault_secret_data, vault_password)


# Generated at 2022-06-22 21:31:54.947841
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for AnsibleVaultEncryptedUnicode
    ansible_vault_encrypted_unicode = AnsibleJSONEncoder.default(
        AnsibleJSONEncoder(), AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;nopassword\r\nansible'))
    assert ansible_vault_encrypted_unicode == {
        '__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;nopassword\r\nansible'}

    # test for AnsibleUnsafeText
    ansible_unsafe_text = AnsibleJSONEncoder.default(
        AnsibleJSONEncoder(), AnsibleUnsafeText('ansible'))

# Generated at 2022-06-22 21:31:59.666510
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    import datetime
    test_date = datetime.datetime(year=2016, month=1, day=1, hour=12, minute=12, second=12)
    assert encoder.default(test_date) == '2016-01-01T12:12:12'


# Generated at 2022-06-22 21:32:06.452556
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    v = VaultLib([])
    password = "password"
    data = {
        "secret": VaultSecret(v.encrypt(password)),
        "plain": "plain",
        "unsafe": {
            "__UNSAFE__": True,
            "plain": "plain"
        }
    }
    j = json.dumps(data, cls=AnsibleJSONEncoder, indent=4)

# Generated at 2022-06-22 21:32:15.120631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == json.JSONEncoder().default(None)
    assert AnsibleJSONEncoder().default(1) == json.JSONEncoder().default(1)
    assert AnsibleJSONEncoder().default(1.1) == json.JSONEncoder().default(1.1)
    assert AnsibleJSONEncoder().default('foobar') == json.JSONEncoder().default('foobar')
    assert AnsibleJSONEncoder().default(['foo', 'bar']) == json.JSONEncoder().default(['foo', 'bar'])
    assert AnsibleJSONEncoder().default({'foo': 'bar'}) == json.JSONEncoder().default({'foo': 'bar'})



# Generated at 2022-06-22 21:32:19.555186
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    class A:
        def __init__(self):
            self.a = 1
    assert list(AnsibleJSONEncoder().iterencode(A())[0]) == ['a', ':', 1, '}']

# Generated at 2022-06-22 21:32:26.377574
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    assert json.dumps({'a': 1}, cls=AnsibleJSONEncoder) == '{"a": 1}'
    assert json.dumps({'a': False}, cls=AnsibleJSONEncoder) == '{"a": false}'
    assert json.dumps({'a': True}, cls=AnsibleJSONEncoder) == '{"a": true}'
    assert json.dumps({'a': None}, cls=AnsibleJSONEncoder) == '{"a": null}'


# Generated at 2022-06-22 21:32:32.000504
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    test_data = {
        'safe_val': 'safe_val',
        'unsafe_val': AnsibleUnsafe('unsafe_val'),
        'vault_val': AnsibleUnsafe(VaultLib().encrypt('vault_val')),
        'safe_list': ['a', 'b', AnsibleUnsafe('c')],
        'safe_dict': {'a': 'b', 'c': AnsibleUnsafe('d')},
    }
    json_data = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(test_data)

# Generated at 2022-06-22 21:32:43.237929
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault_password = 'passw0rd'
    vault_encoder = VaultLib([vault_password])
    ansible_unsafe = AnsibleUnsafe('unsafe')
    secret = vault_encoder.encode('secret')
    data = {
        'ansible_unsafe': ansible_unsafe,
        'ansible_vault': secret,
        'non_encoded_unsafe': 'non_encoded_unsafe',
    }
    out = json.dumps(data, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:32:50.841329
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    import json
    from ansible.module_utils._text import to_bytes, to_text

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, **{})

    class TestClass:
        pass

    test_class = TestClass()
    test_class.__ENCRYPTED__ = True

# Generated at 2022-06-22 21:32:57.119356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert json.loads(json.dumps("string", cls=AnsibleJSONEncoder)) == "string"

    # test str subclasses
    json.loads(json.dumps("string", cls=AnsibleJSONEncoder)) == "string"

    class FakeString(str):
        def __init__(self, s):
            super(FakeString, self).__init__()
            self.s = s

    json.loads(json.dumps("string", cls=AnsibleJSONEncoder)) == "string"

    # test dict subclasses
    assert json.loads(json.dumps(dict(), cls=AnsibleJSONEncoder)) == {}
    assert json.loads(json.dumps(dict(a=1), cls=AnsibleJSONEncoder)) == {"a": 1}


# Generated at 2022-06-22 21:33:06.732220
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def testExpected(expected_value, input_data, kwargs):
        ansible_json_encoder = AnsibleJSONEncoder(**kwargs)
        ret = ansible_json_encoder.default(input_data)
        assert(ret == expected_value)

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import cStringIO
    import ansible.constants as C
    import os

    if C.DEFAULT_VAULT_ID_MATCH is not None:
        id_re = C.DEFAULT_VAULT_ID_MATCH
    else:
        id_re = '^$'

    fd = cStringIO()

# Generated at 2022-06-22 21:33:18.447591
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    vault_password_file = '../test/utils/vault_password'
    test_vault_phrase = VaultLib(vault_password_file).decrypt(b'$ANSIBLE_VAULT;1.1;AES256\r\n3533306465393963616234626535323766383632313961336533326564323966343835666434\r\n6138333866353439303364316261386431616166646532363361353238633163396537303937\r\n363037383566386237')

    # test dict with b'AnsibleUnsafe' and 'AnsibleUnsafe'

# Generated at 2022-06-22 21:33:27.163981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.six import PY3

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class VaultSecret(str):
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    def try_encoding(o, expected, cls=AnsibleJSONEncoder, preprocess_unsafe=False, vault_to_text=False, **kwargs):
        encoder = cls(preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text, **kwargs)

# Generated at 2022-06-22 21:33:38.584683
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type, u
    from ansible.module_utils.common.text.converters import to_bytes, to_native

    string_type = u('string')

# Generated at 2022-06-22 21:33:50.336318
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafeText

    class Hostvars(dict):
        # For testing AnsibleUnsafeText in a hostvars dict
        def __getitem__(self, item):
            if item == 'ansible_ssh_pass':
                # return AnsibleUnsafeText directly
                return AnsibleUnsafeText("my-password")
            else:
                return "1234"

    vault_password = "vaultpass"
    ciphertext = VaultLib(vault_password).encrypt("my_text".encode("utf-8"))
    encrypt1 = VaultLib(vault_password).encrypt("1111".encode("utf-8"))

# Generated at 2022-06-22 21:33:56.421371
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    e = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert e
    e = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert e
    e = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert e
    e = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert e

# Generated at 2022-06-22 21:34:02.736311
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()

    result = encoder.default(VaultLib('test'))
    assert result == {'__ansible_vault': 'test'}

    result = encoder.default({'foo': 'bar'})
    assert result == {'foo': 'bar'}


# Generated at 2022-06-22 21:34:10.959384
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret

    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-22 21:34:20.507366
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    from ansible.module_utils.common.validation import check_type_str
    from ansible.module_utils.six import PY3, text_type, binary_type

    def encode(content, **kwargs):
        for chunk in AnsibleJSONEncoder(**kwargs).iterencode(content):
            yield to_text(chunk, errors='surrogate_or_strict', nonstring='strict')

    if PY3:
        STRING_TYPES = (str, binary_type)
    else:
        STRING_TYPES = (str, text_type)

    # str type
    content = '{ "ansible_fact": "it should be a string" }'
    assert list(encode(content))

# Generated at 2022-06-22 21:34:22.180466
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, separators=(',', ':'))

# Generated at 2022-06-22 21:34:33.494385
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import re

    test_data = {
        'foo': 'bar',
        'nested': {
            'baz': 'qux',
            'password': 'changeme'
        },
        'list': [1, 2, 3]
    }

    encoder = AnsibleJSONEncoder()

    # Test default constructor
    result = encoder.encode(test_data)
    assert result

    # Test preprocess_unsafe constructor
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    result = encoder.encode(test_data)
    assert result

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:34:35.413924
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(AnsibleJSONEncoder)


# Generated at 2022-06-22 21:34:38.047038
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)


# Generated at 2022-06-22 21:34:48.551070
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    # test default method of AnsibleJSONEncoder
    # test unsafe object
    try:
        from ansible.parsing.vault import VaultSecret
        from ansible.parsing.vault import VaultLib
    except ImportError:
        pass
    else:
        x = VaultSecret(b'12345')
        encoder = AnsibleJSONEncoder()
        assert encoder.default(x) == {'__ansible_vault': x._ciphertext}

        encoder = AnsibleJSONEncoder(vault_to_text=True)
        assert encoder.default(x) == x._ciphertext

    x = datetime.datetime(2017, 12, 12, 20, 30, 30)
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:34:59.760548
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-22 21:35:01.689812
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder))


# Generated at 2022-06-22 21:35:06.319616
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_dict = {'a': 1, 'b': 2}
    test_json = {'a': 1, 'b': 2}

    result_json = json.dumps(ansible_dict, cls=AnsibleJSONEncoder)
    result_dict = json.loads(result_json)
    assert result_dict == test_json

# Generated at 2022-06-22 21:35:09.459472
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:35:11.073454
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    msg = "{0}".format(AnsibleJSONEncoder())
    assert msg == "[AnsibleJSONEncoder]"

# Generated at 2022-06-22 21:35:21.188750
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    d = loader.load_from_file(os.path.join(tempfile.gettempdir(), 'test.json'))
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

# Generated at 2022-06-22 21:35:29.520302
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    # Test unsafe values
    for unsafe_value in ("hello_world", u"ÀòÌòÉò", 2, True, False, {"key": "value"}):
        assert "[" not in list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_value))
        assert "[" not in list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(AnsibleUnsafe(unsafe_value)))

    # Test unsafe lists
    unsafe_list = ["hello", "world"]
    assert "[" not in list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_list))

# Generated at 2022-06-22 21:35:38.456011
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.dataloader
    from ansible.parsing.vault import VaultLib

    aue_encoder_without_preprocess = AnsibleJSONEncoder(preprocess_unsafe=False)
    aue_encoder_with_preprocess = AnsibleJSONEncoder(preprocess_unsafe=True)

    aue_encoder_with_preprocess_vault_to_text = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    aue_encoder_without_preprocess_vault_to_text = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)


# Generated at 2022-06-22 21:35:49.591334
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    import ansible.module_utils.basic

    class AnsibleUnsafe(text_type):
        __UNSAFE__ = True

        def __new__(cls, value, **kwargs):
            return text_type.__new__(cls, value)

    import json

    _json = json.dumps('value', cls=AnsibleJSONEncoder)
    assert 'value' == json.loads(_json)
    _json = json.dumps(['value'], cls=AnsibleJSONEncoder)
    assert ['value'] == json.loads(_json)
    _json = json.dumps([AnsibleUnsafe('value')], cls=AnsibleJSONEncoder)
    assert ['value'] == json.loads(_json)
    _

# Generated at 2022-06-22 21:35:59.744038
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils._text import to_text

    # Create data to encode with iterencode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    data = {
        '__ansible_unsafe': to_text(AnsibleUnsafeText('unsafe text')),
        '__ansible_vault': to_text(AnsibleUnsafeText('vault text')),
    }

    # Encode it
    import json
    text = ''.join(json.JSONEncoder().iterencode(data))

    # Check result of encoding
    assert text == json.dumps(data, default=lambda o: o.__dict__)

# Generated at 2022-06-22 21:36:05.500881
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Initialize a new AnsibleJSONEncoder with default parameters
    assert isinstance(AnsibleJSONEncoder(), json.JSONEncoder)

    # Initialize a new AnsibleJSONEncoder with preprocess_unsafe=True and vault_to_text=True
    assert isinstance(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True), json.JSONEncoder)



# Generated at 2022-06-22 21:36:09.106352
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert json_encoder._preprocess_unsafe == True
    assert json_encoder._vault_to_text == True


# Generated at 2022-06-22 21:36:18.732837
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils._text import to_bytes

    class test_class(object):
        def __init__(self):
            self.key = 'value'
            self.list_value = ['one', 'two']
            self.list_of_objects = [{'key1': 'value1', 'key2': 'value2'}, {'key3': 'value3', 'key4': 'value4'}]
            self.dict_of_objects = {'key1': 'value1', 'key2': 'value2'}
            self.dict_of_objects['inner'] = {'key11': 'value11', 'key12': 'value12'}


# Generated at 2022-06-22 21:36:25.879689
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_unsafe_string = '{"test_value": "{{test_value}}"}'
    unsafe_test_value = {'test_value': '{{test_value}}'}
    json_unsafe_string_dict = '[' + json_unsafe_string + ']'
    json_unsafe_string_list = json_unsafe_string
    vault_test_value = getattr('{{test_value}}', '__ENCRYPTED__', False)
    date_test_value = datetime.date(2014, 9, 25)
    dict_test_value = {'test_value': {'test_value': '{{test_value}}'}}


# Generated at 2022-06-22 21:36:34.493546
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import ensure_text
    from ansible.module_utils.common.text.converters import ensure_bytes
    from ansible.module_utils.common.text.converters import ensure_bytes_detect_encoding
    from ansible.module_utils.common.text.converters import is_numeric
    from ansible.module_utils.common.text.converters import is_binary
    from ansible.module_utils.common.text.converters import is_unicode
   

# Generated at 2022-06-22 21:36:37.093407
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Object of class AnsibleJSONEncoder
    obj = AnsibleJSONEncoder()
    obj2 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert obj != obj2

# Generated at 2022-06-22 21:36:40.383963
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  ansible_json_encoder = AnsibleJSONEncoder()
  assert ansible_json_encoder.default({'a': 1}) == {'a': 1}

# Generated at 2022-06-22 21:36:50.443148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # Encodes datetime.datetime
    value = encoder.default(datetime.datetime(2018, 1, 2, 3, 4, 5, 678000))
    assert value == '2018-01-02T03:04:05.678000'

    # Encodes datetime.date
    value = encoder.default(datetime.date(2018, 1, 2))
    assert value == '2018-01-02'

    # Uses default encoder
    value = encoder.default(5)
    assert value == 5

    # Encodes vault object as text

# Generated at 2022-06-22 21:36:55.389935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test default method
    # we don't support encoding arbitrary objects, so we just need to make sure
    # the default method doesn't die if it sees something it doesn't support
    class Foo(object):
        def __init__(self, value):
            self.value = value

    foo = Foo('bar')
    assert json.dumps(foo, cls=AnsibleJSONEncoder) == json.dumps(foo.value)

# Generated at 2022-06-22 21:37:01.806038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import AnsibleUnsafe
    from ansible.module_utils.urls import Url

    a = AnsibleUnsafe(u"$$$hi$$$")
    b = {u"h": u"hi", u"b": a}
    c = [u"h", a, b]
    d = {u"b": b, u"c": c}


# Generated at 2022-06-22 21:37:08.429629
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    # Test for encoding of AnsibleUnsafeText object
    # 'é' utf-8 encoded as 201
    ansible_unsafe_text = AnsibleUnsafeText('\xc3\xa9')
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.iterencode(ansible_unsafe_text) == "[{\"__ansible_unsafe\": \"\xc3\xa9\"}]"

    # Test for encoding of string
    # 'é' utf-8 encoded as 201
    assert ansible_json_encoder.iterencode('\xc3\xa9') == "\"\xc3\xa9\""

# Generated at 2022-06-22 21:37:19.924951
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import namedtuple

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    Person = namedtuple('Person', ['first_name', 'last_name', 'age'])

    p1 = Person("John", "Cleese", 79)
    p2 = Person("Eric", "Idle", 75)
    p3 = Person("Michael", "Palin", 75)
    p4 = Person("Terry", "Gilliam", 79)
    p5 = Person("Graham", "Chapman", 48)

    # python > 3.1 requires json module to be properly imported
    import json

    # create a list of persons
    persons = [p1, p2, p3, p4, p5]

# Generated at 2022-06-22 21:37:28.893242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == json.JSONEncoder().default(None)
    assert AnsibleJSONEncoder().default(1) == json.JSONEncoder().default(1)
    assert AnsibleJSONEncoder().default(1.0) == json.JSONEncoder().default(1.0)
    assert AnsibleJSONEncoder().default('hello') == json.JSONEncoder().default('hello')
    assert AnsibleJSONEncoder().default([1, 2, 3]) == json.JSONEncoder().default([1, 2, 3])
    assert AnsibleJSONEncoder().default({'hello': 'world'}) == json.JSONEncoder().default({'hello': 'world'})
    assert AnsibleJSONEncoder().default(datetime.date(2017, 5, 1)) == '2017-05-01'
    assert Ans

# Generated at 2022-06-22 21:37:35.667904
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_int
    from ansible.module_utils.common.text.converters import to_float
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bool


# Generated at 2022-06-22 21:37:37.037422
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()



# Generated at 2022-06-22 21:37:42.690560
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # check if AnsibleJSONEncoder can handle an object of class AnsibleUnsafe
    from ansible.module_utils.six import text_type
    from ansible.module_utils.parsing.convert_bool import boolean
    assert type(AnsibleJSONEncoder().default(boolean(True))) is text_type

# Generated at 2022-06-22 21:37:49.475983
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret

    a = VaultSecret('my-pass')
    b = 'my-pass'

    # set a and b to unsafe
    a.__UNSAFE__ = True
    setattr(b, '__UNSAFE__', True)

    # run iterencode and check result
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(a) == '"my-pass"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(b) == '"my-pass"'

# Generated at 2022-06-22 21:38:00.141275
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import collections
    import datetime

    # Crypto.Cipher.blockalgo.BlockAlgo
    class Cipher(object):
        def __init__(self, v):
            self._ciphertext = v

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(AnsibleUnsafe):
        __ENCRYPTED__ = True

    # date object is formatted as isoformat
    assert AnsibleJSONEncoder().default(datetime.date(1984, 12, 7)) == '1984-12-07'
    # datetime object is formatted as isoformat
    assert AnsibleJSONEncoder().default(datetime.datetime(1984, 12, 7, 23, 59, 59)) == '1984-12-07T23:59:59'
    # collections.Mapping objects are formatted as

# Generated at 2022-06-22 21:38:02.848747
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    encoded = encoder.encode(['hello'])
    assert encoded == '["hello"]'


# Generated at 2022-06-22 21:38:14.934033
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common._collections_compat import Mapping
    import six

    # Check vault object
    vault = VaultLib([])
    secret = VaultSecret('secret')
    vault_key = vault.encrypt(secret, 'whatever')
    out = AnsibleJSONEncoder().default(vault_key)
    assert out['__ansible_vault'] == to_text(vault_key._ciphertext)

    # Check unsafe string
    out = AnsibleJSONEncoder().default('abc')
    assert out == 'abc'
    if six.PY2:
        out = AnsibleJSONEncoder().default(unicode('abc')) # noqa: F821
       

# Generated at 2022-06-22 21:38:25.916954
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # pylint: disable=unused-variable,invalid-name,maybe-no-member
    from ansible.module_utils.basic import AnsibleUnsafeText, AnsibleUnsafeBytes

    import tempfile

# Generated at 2022-06-22 21:38:35.409890
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    from ansible.parsing.yaml.dumper import AnsibleUnsafeText

    # Test dict
    dict_key = ansible.parsing.vault._VaultSecret("key")
    dict_value = ansible.parsing.vault._VaultSecret("value")
    dict = {dict_key: dict_value}

    # Test list
    list = []
    for i in range(0, 3):
        list.append(ansible.parsing.vault._VaultSecret("list_value"))

    # Test tuple
    tuple = (list, dict)

    # Test string
    string = ansible.parsing.vault._VaultSecret("string")

    # Test unsafe string

# Generated at 2022-06-22 21:38:40.383410
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()

    assert isinstance(encoder.default(AnsibleUnsafe(u"1")), dict)
    assert isinstance(encoder.default(u"1"), str)



# Generated at 2022-06-22 21:38:47.819937
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six.moves import StringIO
    from base64 import b64encode

    assert hasattr(AnsibleJSONEncoder, 'iterencode')
    assert hasattr(AnsibleJSONEncoder, 'default')

    #
    # vault lib
    #

    # default
    assert json.dumps(VaultLib('foo'), cls=AnsibleJSONEncoder) == b'{"__ansible_vault": "UNSAFE ENCODED DATA"}'

    # vault_to_text
    assert json.dumps(VaultLib('foo'), cls=AnsibleJSONEncoder, vault_to_text=True) == b'"UNSAFE ENCODED DATA"'

    #
    # vault objects
    #

# Generated at 2022-06-22 21:38:57.951536
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import crypt
    from ansible.module_utils.common.vault import VaultLib
    from ansible.module_utils.common.vault import VaultSecret
    encrypted_content = '$ANSIBLE_VAULT;1.1;AES256'
    key = b'0' * 32
    vault = VaultLib(key)
    ciphertext = vault.encrypt(to_text(encrypted_content))
    vault_secret = VaultSecret(ciphertext)
    parameter = "vault_to_text"
    imp_AnsibleJSONEncoder = AnsibleJSONEncoder(getattr(bool, parameter))
    assert str(imp_AnsibleJSONEncoder._vault_to_text) == parameter
    ansible_json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:39:05.924542
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    import os
    import sys
    import io
    import json

    vault_text = "password"

    # iterencode function should be able to encode Python dict with AnsibleUnsafe object
    ansible_unsafe = AnsibleUnsafe('abc')
    test_dict = dict()
    test_dict['test'] = ansible_unsafe
    test_json_collection = '{"test": "abc"}'

    encoding_file = io.StringIO()
    json.dump(test_dict, encoding_file, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    encode_result = encoding_file.getvalue()

    assert test_json_collection == encode_result

# Generated at 2022-06-22 21:39:15.036686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, wrap_var

    vault_password = 'secret'
    my_secret_string = 'rabbit hole'
    my_secret_unicode = u'rabbit hole'
    vault_string = VaultLib(vault_password).encrypt(my_secret_string)
    vault_unicode = VaultLib(vault_password).encrypt(my_secret_unicode)
    # Create an unsafe string
    my_unsafe_string = wrap_var(my_secret_string)
    my_unsafe_unicode = wrap_var(my_secret_unicode)


# Generated at 2022-06-22 21:39:20.957108
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import EncryptedUnicode

    encoder = AnsibleJSONEncoder()
    assert encoder.default(u'foo') == u'foo'
    assert encoder.default(42) == 42
    assert encoder.default(EncryptedUnicode('foo')) == {'__ansible_vault': u'foo'}

# Generated at 2022-06-22 21:39:32.483408
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import tempfile
    import ansible.constants as C
    from ansible.parsing.vault import VaultLib

    TEST_KEY = 'test_key'
    TEST_KEY_DATA = 'test_key_data'

    # vault lib state
    if C.DEFAULT_VAULT_IDENTITY_LIST is None:
        C.initialize()

    # create tmp file
    file_path = os.path.join(tempfile.gettempdir(), 'test_file.yml')

    # create vault object
    vault = VaultLib([])
    vault.encrypt(TEST_KEY_DATA, 'test_key')

    # create vaultdict
    vaultdict = dict()
    vaultdict[TEST_KEY] = vault.encrypt(TEST_KEY_DATA)

    # create vaultlist


# Generated at 2022-06-22 21:39:33.160065
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-22 21:39:36.375345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    assert AnsibleJSONEncoder().default(AnsibleUnsafeText('foobar')) == 'foobar'



# Generated at 2022-06-22 21:39:47.452818
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    v = ansible.parsing.vault.VaultLib("password")
    e = AnsibleJSONEncoder()
    assert list(e.iterencode({"a": "A", "b": "B"})) == ['{\n', '"a": "A", \n', '"b": "B"\n', "}"]

# Generated at 2022-06-22 21:39:55.595634
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    data = {
        'host': 'localhost',
        'vars': {
            'var1': 'value1',
            'var2': {
                'hostvars': {'host': 'localhost'},
                'var3': 'value3',
                'var4': {
                    'var5': 'value5'
                }
            }
        }
    }
    result = ansible_json_encoder.default(data)
    assert result == data, "Assertion failure"

# Generated at 2022-06-22 21:39:58.755224
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()

    assert isinstance(encoder, AnsibleJSONEncoder)
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False


# Generated at 2022-06-22 21:40:00.257997
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert isinstance(a, json.JSONEncoder)

# Generated at 2022-06-22 21:40:07.587142
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.six import StringIO
    import ansible.plugins.loader as plugin_loader

    # test 1: test vault variable
    json_encoder = AnsibleJSONEncoder()
    vault_obj = AnsibleUnsafe("vault_obj")
    vault_obj.__ENCRYPTED__ = True
    actual_obj = json_encoder.default(vault_obj)
    expected_obj = {'__ansible_vault': 'vault_obj'}
    assert actual_obj == expected_obj

    # test 2: test unsafe variable
    json_encoder = AnsibleJSONEncoder()
    unsafe_

# Generated at 2022-06-22 21:40:18.238485
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test for AnsibleJSONEncoder.iterencode"""

# Generated at 2022-06-22 21:40:23.017382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_dict = {
        "ansible_facts": {
            "somevar": "somevalue",
            "somevar2": "somevalue2"
        },
        "ansible_play_hosts": [
            "localhost"
        ]
    }

    print(AnsibleJSONEncoder(indent=2).encode(ansible_dict))

# Generated at 2022-06-22 21:40:26.579356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    print("Successfully create an object of class AnsibleJSONEncoder")
    return ansible_json_encoder


# Generated at 2022-06-22 21:40:37.768114
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for default method of AnsibleJSONEncoder
    """
    # Simply test code path for each type
    import ansible.parsing.vault as vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    import datetime
    assert AnsibleJSONEncoder().default(vault.VaultSecret('test')) == {'__ansible_vault': 'test'}
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder().default({1: 2}) == {1: 2}
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()