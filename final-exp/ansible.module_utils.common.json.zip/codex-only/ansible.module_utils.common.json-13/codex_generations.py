

# Generated at 2022-06-22 21:30:36.457918
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText
    import json

    unsafe_text = AnsibleUnsafeText(u"my ünsafe text")

    assert isinstance(unsafe_text, str)

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder._preprocess_unsafe is True

    json_string = json.dumps(unsafe_text, cls=encoder)

    assert json_string == '{"__ansible_unsafe": "my \u00fcnsafe text"}'

# Generated at 2022-06-22 21:30:43.580384
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    encoder_string = AnsibleJSONEncoder(preprocess_unsafe=True)
    encoder_vault_string = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    assert encoder.default(AnsibleUnsafe('unsafe')) == {'__ansible_unsafe': 'unsafe'}
    assert encoder_string.default(AnsibleUnsafe('unsafe')) == 'unsafe'
    assert encoder_vault_string.default(AnsibleUnsafe('unsafe')) == 'unsafe'

    vault_object = VaultLib(password='password')
    vault_text

# Generated at 2022-06-22 21:30:46.468075
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(ansiblejsonencoder, AnsibleJSONEncoder)


# Generated at 2022-06-22 21:30:57.577956
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    # a string is a sequence, so need to wrap it into a container
    v = VaultLib({'vault_password_file': ["/tmp/vault_password"]})

# Generated at 2022-06-22 21:31:09.211848
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import AnsibleVaultEncryptedBytes

    password = 'mypassword'

# Generated at 2022-06-22 21:31:19.700823
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """Test case for AnsibleJSONEncoder constructor"""
    # Create object with normal call
    dump1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # Create object with a normal call but with an additional parameter
    # to avoid exception
    dump2 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, separators=(',', ':'))
    # Create object with a normal call but with an additional parameter
    # to avoid exception
    dump3 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True, separators=(',', ':'))
    # Create object with a normal call but with an additional parameter
    # to avoid exception

# Generated at 2022-06-22 21:31:28.226792
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Add test for constructor of class AnsibleJSONEncoder
    # Test for proper exception when no arguments provided
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe is False and encoder._vault_to_text is False

    # Test proper assignment of arguments
    encoder = AnsibleJSONEncoder(preprocess_unsafe = True, vault_to_text = True)
    assert encoder._preprocess_unsafe is True and encoder._vault_to_text is True

    # Test for proper exception for incorrect argument

# Generated at 2022-06-22 21:31:39.351531
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    from ansible.parsing.vault import VaultLib

    # Test with vault
    test_vault_text = '{"a": "Test vault"}'
    vault_key = VaultLib()._encrypt_text(password='password', text=test_vault_text)
    test_vault = VaultLib(vault_key, password='password').decrypt(vault_key)

    class TestClass(object):
        __ENCRYPTED__ = True
        def __init__(self, _ciphertext):
            self._ciphertext = _ciphertext

    if sys.version_info[0] < 3:
        result = AnsibleJSONEncoder().default(TestClass(vault_key))
        assert isinstance(result, unicode)

# Generated at 2022-06-22 21:31:41.804592
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import pytest
    ansible_json = AnsibleJSONEncoder()
    ansible_json.__dict__

# Generated at 2022-06-22 21:31:49.772973
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import text_type

    class AnsibleUnsafe(text_type):
        """
        AnsibleUnsafe is a subclass of the built-in Python ``str``
        and is used to denote that a string value is unsafe to be
        used without first being explicitly validated by the user.

        This is used by the ``template`` module to mark that variables
        within a template are not automatically trusted.
        """
        __UNSAFE__ = True

    class SampleVault(VaultSecret):
        """
        Class used to test vault encoding.
        """
        __ENCRYPTED__ = True


# Generated at 2022-06-22 21:32:00.314264
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.ansible.misc.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.ansible.misc.plugins.vars.unsafe_proxy import AnsibleUnsafe
    from ansible_collections.ansible.misc.plugins.vars.vault import VaultLib

    def default_mock(self, o):
        return 42


# Generated at 2022-06-22 21:32:12.696318
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.ansible_unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.hashivault import hashivault_argspec
    args = hashivault_argspec().args

    # Test unsafe_encode is True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    # Test unsafe_encode is False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    # Test vault_to_text True
    encoder = AnsibleJSONEncoder(vault_to_text=True)

    # Test vault_to_text False
    encoder = AnsibleJSONEncoder(vault_to_text=False)

    # Test iterencode
    check_unsafe = AnsibleUnsafeText('test')

# Generated at 2022-06-22 21:32:24.685880
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # check passing in AnsibleVaultEncryptedUnicode
    ansible_vault_enc_unicode = 'foo'
    ansible_vault_enc_unicode_string = '{0}'.format(ansible_vault_enc_unicode)
    ansible_vault_enc_unicode_obj = AnsibleVaultEncryptedUnicode(ansible_vault_enc_unicode_string)

    # assert default method would return the encrypted unicode as a dict
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder_default = ansible_json_encoder.default(ansible_vault_enc_unicode_obj)
    assert '__ansible_vault' in ansible_json_encoder_default
    assert ansible_vault_enc_

# Generated at 2022-06-22 21:32:34.952461
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.collections import Mapping

    assert(AnsibleJSONEncoder.__bases__ == (json.JSONEncoder,))

    # Test for default constructor
    encoder = AnsibleJSONEncoder()
    assert(encoder.item_separator == ', ')
    assert(encoder.key_separator == ': ')
    assert(encoder.sort_keys == False)
    assert(encoder._preprocess_unsafe == False)
    assert(encoder._vault_to_text == False)

    # Test for a custom constructor
    encoder = AnsibleJSONEncoder(item_separator = '-', key_separator = '+', sort_keys = True, preprocess_unsafe = True, vault_to_text = True)

# Generated at 2022-06-22 21:32:45.821875
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode

    class S(str):
        pass

    data = [1, 2, {'foo': 'bar'}, None, S('unsafe')]
    s = '[' + ','.join(map(lambda x: json.dumps(x, cls=AnsibleJSONEncoder), data)) + ']'

    json_s = json.dumps(data, cls=AnsibleJSONEncoder, indent=4)
    json_s = to_unicode(json_s)
    assert s == json_s

    json_s = json.dumps(data, cls=AnsibleJSONEncoder)
    json_s = to_unicode(json_s)
    assert s == json_s

# Generated at 2022-06-22 21:32:52.814508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("sampleString") == "sampleString"
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default([1,2,3]) == [1,2,3]
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert AnsibleJSONEncoder().default(datetime.datetime.utcnow()) == datetime.datetime.utcnow().isoformat()
    assert AnsibleJSONEncoder().default(datetime.date.today()) == datetime.date.today().isoformat()

# Generated at 2022-06-22 21:33:01.569805
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    not_safe_value = {'__ansible_unsafe': '123'}
    vault_value = {'__ansible_vault': '123'}
    date_value = {'__ansible_unsafe': '2019-09-19T14:48:26.218249+00:00'}
    obj = AnsibleJSONEncoder()
    assert _is_unsafe(obj.default(not_safe_value))
    assert not _is_vault(obj.default(vault_value))
    assert not _is_unsafe(obj.default(date_value))

# Generated at 2022-06-22 21:33:08.114256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils import basic
    from ansible.module_utils.common.removed import RemovedIn279Warning

    encoder = AnsibleJSONEncoder()

    # formerly 'removed' object (now a dict)
    obj = basic.AnsibleModule(argument_spec={})
    result = encoder.default(obj)
    assert isinstance(result, dict)
    assert result['argument_spec'] == {}

    # vault object
    obj = basic.AnsibleVaultEncryptedUnicode(b'ciphertext', b'encryption_key')
    # ensure it is set as both UNSAFE and ENCRYPTED
    assert _is_unsafe(obj)
    assert _is_vault(obj)
    result = encoder.default(obj)
    assert isinstance(result, dict)


# Generated at 2022-06-22 21:33:19.530059
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    class AnsibleUnsafe(ansible.module_utils.basic.AnsibleUnsafe):
        def __init__(self, value):
            ansible.module_utils.basic.AnsibleUnsafe.__init__(self, value)

    unsafe = AnsibleUnsafe("uncrypted")
    json_str = b'{"foo":"bar","baz":[1,2,3],"obj":{"user":"hailongz","age":12,"email":"hailongz@163.com"},"unsafe":' + to_text("uncrypted", encoding='utf-8').encode("utf-8") + b'}'

# Generated at 2022-06-22 21:33:27.711131
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    # test for date object
    date_object = datetime.datetime(2020, 1, 2, 12, 2, 4)
    date_object_expected = '2020-01-02T12:02:04'
    assert obj.default(date_object) == date_object_expected

    # test for vault object, to_text is not the same object in ansible and in test
    import ansible.parsing.vault

# Generated at 2022-06-22 21:33:38.625224
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
# Generate instance for AnsibleJSONEncoder
    ansibleEncoder = AnsibleJSONEncoder()

    # test encode for AnsibleUnsafe
    assert ansibleEncoder.default(object()) == None

    # test encode for Vault
    assert ansibleEncoder.default(object()) == None

    # test encode for AnsibleDict
    assert ansibleEncoder.default(object()) == None

    # test encode for AnsibleList
    assert ansibleEncoder.default(object()) == None

    # test encode for Mapping
    assert ansibleEncoder.default(object()) == None

    # test encode for date object
    assert ansibleEncoder.default(object()) == None

    # test encode for object not in the above cases
    assert ansibleEncoder.default(object()) == None

# Run unit test
test_AnsibleJSONEnc

# Generated at 2022-06-22 21:33:42.454166
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({'key': 'value'}) == "{'key': 'value'}"
    assert AnsibleJSONEncoder().default({'key': {'subkey': 'value'}}) == "{'key': {'subkey': 'value'}}"


# Generated at 2022-06-22 21:33:54.078658
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode('foo') == '"foo"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode('foo').encode('utf-8') == b'"foo"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(True) == 'true'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(False) == 'false'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(None) == 'null'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(1000) == '1000'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(1000.0) == '1000.0'
    assert Ansible

# Generated at 2022-06-22 21:34:02.202107
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    text_type = type(u'')

    # This class should be used with '__UNSAFE__' and '__ENCRYPTED__',
    # but we override __UNSAFE__ and __ENCRYPTED__ to test them.
    class AnsibleUnsafe(text_type):
        def __init__(self):
            self.__UNSAFE__ = True

    class AnsibleEncrypted(text_type):
        def __init__(self):
            self.__ENCRYPTED__ = True

    # Use preprocess_v

# Generated at 2022-06-22 21:34:10.603801
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the input - o is a string. This is the basic case.
    o = 'test'
    encoder = AnsibleJSONEncoder()
    encoder_output = encoder.default(o)
    assert encoder_output == o
    # Test the input - o is a datetime object.
    o = datetime.datetime.now()
    encoder = AnsibleJSONEncoder()
    encoder_output = encoder.default(o)
    assert encoder_output == o.isoformat()
    # Test the input - o is a dictionary.
    o = dict()
    encoder = AnsibleJSONEncoder()
    encoder_output = encoder.default(o)
    assert encoder_output == o
    # Test the input - o is a object inheriting from mapping.
    o = dict()
    enc

# Generated at 2022-06-22 21:34:20.491287
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test that iterencode works as expected, specifically that objects that are instances of ``AnsibleUnsafe`` get
    handled in the expected way.
    """
    class AnsibleUnsafe(object):
        """
        Custom unsafe class
        """
        __UNSAFE__ = True

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

    class AnsibleVault(object):
        """
        Custom vault class
        """
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

        def __str__(self):
            return self._ciphertext


# Generated at 2022-06-22 21:34:29.697437
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    def test_iterencode(json_o, json_expected):
        # Don't use 'ensure_ascii=False' as we want to see the actual error
        # print("json_o = ", json_o, "type = ", type(json_o))
        # print("json_expected = ", json_expected, "type = ", type(json_expected))
        json_o_encoded = json.dumps(json_o, cls=AnsibleJSONEncoder, sort_keys=True)
        json_expected_encoded = json.dumps(json_expected, sort_keys=True)
        # print("json_o_encoded = ", json_o_encoded, "type = ", type(json_o_encoded))
        # print("json_expected_encoded = ", json_expected_encoded,

# Generated at 2022-06-22 21:34:37.737787
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    # Create an object for testing
    # The object contains a vault object and an unsafe object
    j = json.dumps({'vault': AnsibleUnsafe('value', vault_secret='secret'),
                    'unsafe': AnsibleUnsafe('value'),
                    'plain': 'plain',
                    'list': [AnsibleUnsafe('value'), 'plain'],
                    'dict': {'dict_vault': AnsibleUnsafe('value', vault_secret='secret'),
                             'dict_unsafe': AnsibleUnsafe('value'),
                             'dict_plain': 'plain'}
                    }, cls=AnsibleJSONEncoder)

    result = json.loads(j)

    # Check the vault object

# Generated at 2022-06-22 21:34:49.871185
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test case #1: value = {'a': 1, 'b': b'value'}
    try:
        value = {'a': 1, 'b': b'value'}
        AnsibleJSONEncoder().encode(value)
    except ValueError:
        # ValueError is expected
        pass
    else:
        raise Exception("Unit test of test_AnsibleJSONEncoder() for constructor of class AnsibleJSONEncoder fails")

    # Test case #2: value = 'value'
    try:
        value = 'value'
        AnsibleJSONEncoder().encode(value)
    except ValueError:
        # ValueError is expected
        pass
    else:
        raise Exception("Unit test of test_AnsibleJSONEncoder() for constructor of class AnsibleJSONEncoder fails")

    # Test case #3:

# Generated at 2022-06-22 21:35:01.086651
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.vars import combine_vars
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import binary_type
    import datetime
    import time


# Generated at 2022-06-22 21:35:03.872965
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    data = {'key': {'key2': 'value'}}
    assert json.dumps(data, cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:35:13.618070
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.constants as ansible_constants
    import ansible.parsing.vault as vault

    # Explicitly use the global value from ansible.constants.DEFAULT_VAULT_ID_MATCH
    # ansible_constants.__file__ is "/usr/bin/../lib/ansible/constants.py"
    # and ansible.constants.DEFAULT_VAULT_ID_MATCH == '^[A-Za-z0-9!#$%^&\*\(\)]{8}-[A-Za-z0-9!#$%^&\*\(\)]{8}-[A-Za-z0-9!#$%^&\*\(\)]{8}-[A-Za-z0-9!#$%^&\*\(\)]{8}$'

# Generated at 2022-06-22 21:35:19.382273
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """ Unit test for the instance of ``AnsibleJSONEncoder``
    """
    ansible_instance = AnsibleJSONEncoder()
    ansible_instance.preprocess_unsafe = True
    ansible_instance.vault_to_text = False
    assert ansible_instance._preprocess_unsafe == True
    assert ansible_instance._vault_to_text == False


# Generated at 2022-06-22 21:35:27.293459
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    test_data1 = {'password': '123', 'password_unsafe': '123'}
    # test case 1: when _preprocess_unsafe=True, AnsibleUnsafe objects in the test_data1 will be converted to dict or list,
    # instead of converted to JSON string
    ansible_json_encoder1 = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_list1 = list(ansible_json_encoder1.iterencode(test_data1))
    assert json_list1[1] == ':'
    assert json_list1[3] == ':'
    assert json_list1[6] == '}'
    # test case 2: when _preprocess_unsafe=False, AnsibleUnsafe objects in the test_data1 will be converted to JSON string
    ansible_

# Generated at 2022-06-22 21:35:36.951741
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import tempfile
    from ansible.parsing.vault import VaultLib

    header_data = {
        'version': 1,
        'cipher': 'aes256',
        'hmac': 'x',
        'hmac_key': 'y'
    }

    vault_password = 'test'
    vault = VaultLib(vault_password)
    path = tempfile.mktemp(dir=None)

    f = open(path, 'w')
    f.write("""$ANSIBLE_VAULT;1.1;AES256
{}
""".format(vault.dump_header(header_data).decode('utf-8')))

    # Test with vault_to_text = True
    data = vault.dump(to_text(u"test_data"), fd=f)
    data

# Generated at 2022-06-22 21:35:48.520598
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # import AnsibleUnsafe class, which is defined in ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.text.encoders import to_bytes
    from ansible.module_utils.common.collections import Mapping, is_sequence
    import datetime

    # isinstance(object,type) -> bool, return True if the object is an instance of the type or of a subclass thereof
    # getattr(object, name[, default]) -> value, get a named attribute from an object; getattr(x, 'y') is equivalent to x.y
    # getattr(x, 'y', z) is equivalent to getattr(x, 'y') except that when x.y doesn't exist, z is returned instead of AttributeError
    # getattr(

# Generated at 2022-06-22 21:35:57.539003
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(5) == 5
    assert encoder.default(5.5) == 5.5
    assert encoder.default('string') == 'string'
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(None) == None
    assert encoder.default(u'unicode') == u'unicode'
    assert encoder.default(['list', 5]) == ['list', 5]
    assert encoder.default(set(['list', 5])) == ['list', 5]
    assert encoder.default(dict(a=5, b='2')) == {'a': 5, 'b': '2'}



# Generated at 2022-06-22 21:36:05.916923
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Vault(object):
        def __init__(self):
            self.__ENCRYPTED__ = True

    class Unsafe(object):
        def __init__(self):
            self.__UNSAFE__ = True

    class Crypt(object):
        def __init__(self):
            self.__ENCRYPTED__ = True
            self.__UNSAFE__ = True

    class Foo(object):
        def __init__(self, mydict):
            self.__dict__ = mydict

    encoded_vault = json.loads(json.dumps(Vault(), cls=AnsibleJSONEncoder))
    assert encoded_vault == {'__ansible_vault': ''}


# Generated at 2022-06-22 21:36:09.150838
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    j = json.dumps({"test": True}, cls=AnsibleJSONEncoder)
    assert j == '{"test": true}'

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:36:18.770472
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    assert json.dumps(
        AnsibleUnsafe("ansible"), cls=AnsibleJSONEncoder,
        indent=4, sort_keys=True
    ) == '"ansible"'

    assert json.dumps(
        AnsibleUnsafe("ansible"), cls=AnsibleJSONEncoder,
        indent=4, sort_keys=True, preprocess_unsafe=True
    ) == '{\n    "__ansible_unsafe": "ansible"\n}'


# Generated at 2022-06-22 21:36:30.789621
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultSecret, VaultAES256
    from ansible.parsing.vault import VaultEditor

    def _get_vaultobject(secret_value, password, create=False):
        vault_secret = VaultSecret(password=password)

        encrypted_text = ''
        if create:
            # Get the encrypted value
            myvault = VaultEditor(vault_secret, version='2')
            encrypted_text = to_text(myvault.dump(secret_value))

        vault_secret.set_encrypted_data(encrypted_text)

# Generated at 2022-06-22 21:36:34.775522
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert callable(AnsibleJSONEncoder) == True

ansible_encoder_class = AnsibleJSONEncoder
ansible_encoder = lambda o: ansible_encoder_class(preprocess_unsafe=True).encode(o)
ansible_sufficient_json_encoder = lambda o: ansible_encoder_class(preprocess_unsafe=True).iterencode(o)

# Generated at 2022-06-22 21:36:45.517613
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Test case to verify the method default of class AnsibleJSONEncoder
    '''
    test_obj = AnsibleJSONEncoder()
    class Test:
        def __init__(self, test):
            self.test = test

    class TestVault:
        def __init__(self, test_ciphertext, test_vault_id):
            self.__ENCRYPTED__ = True
            self._ciphertext = test_ciphertext
            self._vault_id = test_vault_id

        def __repr__(self):
            return self._ciphertext

    test_dict = {'test_dict': "dict"}
    test_hash = {'test_hash': Test("test_hash")}
    test_list = ['test_list', Test("test_list")]


# Generated at 2022-06-22 21:36:54.483517
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test for vault object
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    vault_password = VaultSecret('p@ssword')

# Generated at 2022-06-22 21:37:03.274716
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVault

    password = 'test'

# Generated at 2022-06-22 21:37:13.805879
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test vault object
    assert AnsibleJSONEncoder(vault_to_text=True).default(b'foo') == 'foo'
    assert AnsibleJSONEncoder().default(b'foo') == {'__ansible_vault': 'foo'}
    # test unsafe object
    assert AnsibleJSONEncoder().default(b'foo') == {'__ansible_unsafe': 'foo'}
    # test hostvars and other objects
    assert AnsibleJSONEncoder().default({'test': 'foo'}) == {'test': 'foo'}
    # test date object
    dateobj = datetime.date.today()
    datestring = dateobj.isoformat()
    assert AnsibleJSONEncoder().default(dateobj) == datestring
    # test string

# Generated at 2022-06-22 21:37:20.227341
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    o = [u'foo', u'bar', u'baz']
    encoder = AnsibleJSONEncoder()
    assert list(encoder.iterencode(o)) == [u'["foo", "bar", "baz"]']
    o.append(u'qux')
    assert list(encoder.iterencode(o)) == [u'["foo", "bar", "baz", "qux"]']

# Generated at 2022-06-22 21:37:25.397579
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    assert e.default(b'bytes') == 'bytes'
    assert e.default('string') == 'string'
    assert e.default([b'bytes', 'string']) == ['bytes', 'string']
    assert e.default({'bytes': b'bytes', 'string': 'string'}) == {'bytes': 'bytes', 'string': 'string'}



# Generated at 2022-06-22 21:37:35.520407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass(object):
        def __init__(self, content):
            self.content = content
        def __str__(self):
            return str(self.content)

    # Case 1: encrypted object
    obj = TestClass('test')
    obj.__ENCRYPTED__ = True
    obj._ciphertext = 'test2'

    expected = {'__ansible_vault': 'test2'}

    ansible_json_encoder = AnsibleJSONEncoder()
    result = ansible_json_encoder.default(obj)

    assert result == expected

    # Case 2: unsafe object
    obj = TestClass('test')
    obj.__UNSAFE__ = True

    expected = {'__ansible_unsafe': 'test'}

    ansible_json_encoder = AnsibleJSON

# Generated at 2022-06-22 21:37:45.999042
# Unit test for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:37:58.192892
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Unit test for method iterencode of AnsibleJSONEncoder

    """
    class AnsibleUnsafeProxy(str):
        """A proxy string type, it is unsafe but not encrypted,
        behave like test.AnsibleUnsafe, which cannot be imported
        in this test
        """

        __ENCRYPTED__ = False
        __UNSAFE__ = True

    unsafe_str = AnsibleUnsafeProxy(u"这是一个 Unicode string_1")
    unsafe_param = {
        "password": unsafe_str,
        "key": unsafe_str,
        "key2": unsafe_str,
        "key3": {
            "key4": unsafe_str
        }
    }
    # The result which `AnsibleJSONEncoder.iterencode` should return
    # after handle the unsafe_param

# Generated at 2022-06-22 21:38:01.215949
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # testing constructor
    a = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False

# Generated at 2022-06-22 21:38:13.479411
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleUnsafe

    ansible_json_encoder = AnsibleJSONEncoder()

    # test for AnsibleUnsafe
    assert ansible_json_encoder.default(AnsibleUnsafe('test_AnsibleJSONEncoder_default')) == {'__ansible_unsafe': 'test_AnsibleJSONEncoder_default'}
    assert ansible_json_encoder.default(AnsibleUnsafe(u'test_AnsibleJSONEncoder_default')) == {'__ansible_unsafe': u'test_AnsibleJSONEncoder_default'}

# Generated at 2022-06-22 21:38:21.735788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_obj = VaultLib(password=VaultSecret('test'))
    encoder = AnsibleJSONEncoder(vault_to_text=True)


# Generated at 2022-06-22 21:38:32.756987
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def _assert(obj, expected):
        assert AnsibleJSONEncoder().default(obj) == expected

    _assert(1, 1)
    _assert(datetime.datetime(2016, 1, 1), "2016-01-01T00:00:00")
    _assert(datetime.date(2016, 1, 1), "2016-01-01")
    _assert(object(), TypeError)
    _assert({}, {})
    _assert({'v': object()}, {'v': TypeError})
    _assert([], [])
    _assert([object()], [TypeError])
    class _ImplicitUnsafe:
        pass
    _assert(_ImplicitUnsafe(), {'__ansible_unsafe': "<class '__main__._ImplicitUnsafe'>"})


# Generated at 2022-06-22 21:38:44.581736
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe

    vl = VaultLib([])


# Generated at 2022-06-22 21:38:55.857865
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible
    from ansible.parsing.vault import VaultLib

    raw_string = 'secret string'
    raw_list = ['foo', 'bar', 'baz']
    raw_dict = {'1': 'foo', '2': 'bar', '3': 'baz'}

    ansible_safe = ansible.module_utils.common._AnsibleSafeText(raw_string)
    ansible_unsafe = ansible.module_utils.common._AnsibleUnsafeText(raw_string)
    ansible_vault = ansible.module_utils.common._AnsibleUnsafeText(VaultLib().encrypt(raw_string))

    ansible_safe_list = [ansible_safe, raw_string]

# Generated at 2022-06-22 21:39:02.977259
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    unsafe_text = 'unsafe'
    safe_text = 'safe'

    # encode an unsafe object
    for preprocess_unsafe in [True, False]:
        for vault_to_text in [True, False]:
            for chunk in AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text).iterencode(AnsibleUnsafe(unsafe_text)):
                assert AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text).encode({"__ansible_unsafe": unsafe_text}) in chunk
 
    # encode a safe object

# Generated at 2022-06-22 21:39:11.677026
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.common.vars import AnsibleVaultEncryptedUnicode

    assert json.dumps(AnsibleUnsafe('foo'), cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"__ansible_unsafe": "foo"}'
    assert json.dumps(AnsibleUnsafe('foo'), cls=AnsibleJSONEncoder, preprocess_unsafe=False) == '"foo"'
    assert json.dumps(['foo', AnsibleUnsafe('bar')], cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '["foo", {"__ansible_unsafe": "bar"}]'

# Generated at 2022-06-22 21:39:23.653235
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder._preprocess_unsafe == False
    assert ansible_encoder._vault_to_text == False
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_encoder._preprocess_unsafe == True
    assert ansible_encoder._vault_to_text == False
    ansible_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert ansible_encoder._preprocess_unsafe == False
    assert ansible_encoder._vault_to_text == True
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ansible_encoder._preprocess_

# Generated at 2022-06-22 21:39:26.722955
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder(pre=True, vault_to_text=True)
    assert aje._preprocess_unsafe == True
    assert aje._vault_to_text == True


# Generated at 2022-06-22 21:39:39.080007
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True

    class AnsibleVault(unicode):
        __UNSAFE__ = True
        __ENCRYPTED__ = True


    def test_vault():
        value = {'test': AnsibleVault('vault')}
        res = AnsibleJSONEncoder(vault_to_text=False).iterencode(value)
        assert list(res) == ['{"test": {"__ansible_vault": "vault"}}']

    def test_unsafe():
        value = {'test': AnsibleUnsafe('unsafe')}


# Generated at 2022-06-22 21:39:49.310479
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    test_vault_text = '$ANSIBLE_VAULT;1.1;AES256;test\ntest\n'
    test_vault_bytes = '$ANSIBLE_VAULT;1.1;AES256;test\ntest\n'.encode()
    test_vault = VaultLib([])
    test_vault.decrypt(test_vault_bytes)
    test_vault_unsafe = AnsibleUnsafeText(test_vault_text)
    test_vault_unsafe_bytes = AnsibleUnsafeText(test_vault_bytes)

# Generated at 2022-06-22 21:39:58.837260
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe, wrap_var

    # Test for strings, integers and null
    assert ['"test_String"', '10', 'null'] == [t for t in AnsibleJSONEncoder().iterencode('test_String', 10, None)]
    # Test for dictionaries
    assert ['{"k1": "v1", "k2": "v2"}'] == [t for t in AnsibleJSONEncoder().iterencode({'k1':'v1', 'k2':'v2'})]
    # Test for lists, tuples, sets

# Generated at 2022-06-22 21:40:03.552278
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().encode({}) == '{}'

    a = AnsibleJSONEncoder()
    assert a.encode({"key": {"value": "value"}}) == '{"key": {"value": "value"}}'



# Generated at 2022-06-22 21:40:05.318211
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder.__name__ == 'AnsibleJSONEncoder'

# Generated at 2022-06-22 21:40:11.016826
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    o = {"1":2, 3:"4"}
    json_str = json.dumps(o)
    # Create AnsibleJSONEncoder object
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_str = ansible_json_encoder.encode(o)
    # Test the object
    assert json_str == ansible_json_str

# Generated at 2022-06-22 21:40:20.794564
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # create a safe text object
    safe = AnsibleUnsafeText(u'12345')
    # create a unsafe text object
    unsafe = AnsibleUnsafeText(u'12345', unsafe=True)
    # create a vault text object
    vault = AnsibleUnsafeText(u'12345', unsafe=True, encrypted=True)
    # A class that has custom json encoder
    class Person(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age

        def default(self):
            raise TypeError

    # A class that has custom json encoder

# Generated at 2022-06-22 21:40:32.547202
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeDict
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    d = {'abc': 'abc', 'def': AnsibleUnsafeBytes('def'), 'ghi': [AnsibleUnsafeText('jkl'), 'mno', AnsibleUnsafeDict({'pqr': 'stu', 'vwx': [AnsibleUnsafeText('yza'), 'bcd']})]}