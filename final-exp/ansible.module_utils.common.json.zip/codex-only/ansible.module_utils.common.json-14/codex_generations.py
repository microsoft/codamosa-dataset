

# Generated at 2022-06-22 21:30:33.475491
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence

    # Arrange
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    text = "text"
    expected_result = b'"' + to_bytes(text) + b'"'

    # Act
    result = ansible_json_encoder.iterencode(ansible_unsafe_text)
    result = list(result)

    # Assert
    # The byte string is returned as a list of bytes. It must be converted to a simple string
    assert result == [expected_result]



# Generated at 2022-06-22 21:30:42.798093
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing import vault

    # Test with unsafe string
    unsafe = '{ "some": "value" }'
    unsafe_encoded = b'{"__ansible_unsafe": "{ \\"some\\": \\"value\\" }"}'
    encoder = AnsibleJSONEncoder()
    assert unsafe_encoded == b''.join(encoder.iterencode(unsafe))

    # Test with vault encrypted string
    vault_o = vault.VaultLib('secret')
    vault_str = vault_o.encrypt('{ "some": "value" }')
    vault_o.finalize()
    # TODO: vault_str contains the ciphertext in base64, need to test the non-base64 ciphertext
    # vault_str_encoded = b'{"__ansible_vault": "AQ

# Generated at 2022-06-22 21:30:44.529560
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-22 21:30:55.209282
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test AnsibleJSONEncoder().default(o)
    # where o is an object of class AnsibleVaultEncryptedUnicode
    value = AnsibleJSONEncoder().default(object())
    assert value is not None
    assert isinstance(value, object)

    # Test AnsibleJSONEncoder().default(o)
    # where o is an object of class AnsibleVaultEncryptedUnicode
    value = AnsibleJSONEncoder().default(object())
    assert value is not None
    assert isinstance(value, object)    

    # Test AnsibleJSONEncoder().default(o)
    # where o is an object of class AnsibleVaultEncryptedUnicode
    value = AnsibleJSONEncoder().default(object())
    assert value is not None
    assert isinstance(value, object)    

    # Test Ansible

# Generated at 2022-06-22 21:31:07.244840
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils._text import to_bytes

    class UnsafeObject(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class VaultObject(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = True

    class SafeObject(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = False

    class UnsafeDict(dict):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class VaultDict(dict):
        __UNSAFE__ = False
        __ENCRYPTED__ = True

    class SafeDict(dict):
        __UNSAFE__ = False
        __ENCRYPTED__ = False


# Generated at 2022-06-22 21:31:10.397270
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    result = ansible_json_encoder.default(datetime.datetime.fromtimestamp(1560319332))
    assert result == "2019-06-12T18:48:52"

# Generated at 2022-06-22 21:31:21.051414
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    import sys
    import re

    vault_password = 'vault-password'
    vault_text = """
$ANSIBLE_VAULT;1.1;AES256
36366433316433383639396237396366306435396335376563306532653337613035656436656133
38653064373436643335396665383762323239346432613765333935353433633437626330633436
38313134
"""

# Generated at 2022-06-22 21:31:29.563899
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    unsafe = AnsibleUnsafe('hello')
    assert _is_unsafe(unsafe) is True
    assert _is_vault(unsafe) is False
    assert hasattr(unsafe, '__UNSAFE__') is True
    assert hasattr(unsafe, '__ENCRYPTED__') is False

    assert json.dumps(unsafe, cls=AnsibleJSONEncoder) == '{"__ansible_unsafe": "hello"}'
    assert json.dumps(unsafe, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"__ansible_unsafe": "hello"}'
    assert json.dumps(unsafe, cls=AnsibleJSONEncoder, preprocess_unsafe=False)

# Generated at 2022-06-22 21:31:40.376405
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    b64_txt = 'c29tZXRoaW5n'
    encrypted_txt = '$ANSIBLE_VAULT;1.1;AES256\n{0}\n'.format(b64_txt)
    encrypted_obj = VaultLib([b64_txt])
    encrypted_obj.__ENCRYPTED__ = True

    json_enc = AnsibleJSONEncoder(
        preprocess_unsafe=True,
        vault_to_text=False,
    )

    json_enc_vault_to_text = AnsibleJSONEncoder(
        preprocess_unsafe=True,
        vault_to_text=True,
    )


# Generated at 2022-06-22 21:31:43.610456
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    res = json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder)
    assert res == '{"a": 1, "b": 2}'

# Generated at 2022-06-22 21:31:54.365130
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.safe_eval import unsafe_eval

    a_value = VaultLib([unsafe_eval('"hello"')]).encrypt('foo', '$ANSIBLE_VAULT;1.1;AES256', False)
    b_value = 'bar'
    it = AnsibleJSONEncoder().iterencode({'a':a_value,'b':b_value})
    equal = it.__next__() == '{'
    equal = equal and it.__next__() == '"a":'
    equal = equal and it.__next__() == '{"__ansible_vault": "' in it.__next__()
    equal = equal and it.__next__() == '",'
    equal = equal and it.__next

# Generated at 2022-06-22 21:32:03.506048
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest
    from ansible.parsing.vault import VaultLib

    plaintext = "test-plaintext"
    ciphertext = VaultLib().encrypt(plaintext)


# Generated at 2022-06-22 21:32:07.871041
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(preprocess_unsafe=False), AnsibleJSONEncoder)
    assert isinstance(AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True), AnsibleJSONEncoder)

# Generated at 2022-06-22 21:32:10.694918
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert not encoder.check_circular
    assert not encoder.ensure_ascii
    assert not encoder.indent
    assert encoder.sort_keys

# Generated at 2022-06-22 21:32:17.413156
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # Simple test to confirm vault object converts to strings automatically
    test_vault_string = 'This string is encrypted.'
    test_vault_object = AnsibleJSONEncoder().default(test_vault_string)
    assert test_vault_object == test_vault_string

    # Simple test to confirm datetime objects convert to strings automatically
    time_now = datetime.datetime.now()
    time_now_string = AnsibleJSONEncoder().default(time_now)
    assert time_now_string == time_now.isoformat()

    # Simple test to confirm unsafe object converts to string automatically
    test_unsafe = 'This is an unsafe string.'
    test_unsafe_object = AnsibleJSONEncoder().default(test_unsafe)
    assert test_unsafe_object == test_unsafe

    # Simple test

# Generated at 2022-06-22 21:32:29.030851
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test preprocess_unsafe true
    x = 'ansible_unsafe'
    unsafe_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    unsafe_encoder_string = unsafe_encoder.iterencode(x)
    # Check value to be string
    assert (type(unsafe_encoder_string) is str)
    # Check value to be equal to '"__ansible_unsafe":["ansible_unsafe"]'
    assert (unsafe_encoder_string == '"__ansible_unsafe":["ansible_unsafe"]')
    # Test preprocess_unsafe false
    y = 'ansible_unsafe'
    safe_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

# Generated at 2022-06-22 21:32:37.442119
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    a_list = [1, "a", AnsibleUnsafe("b")]
    a_dict = {
        "key1": 1,
        "key2": "a",
        "key3": [1, 2, 3],
        "key4": {"a": "b", "c": "d"},
        "key5": AnsibleUnsafe("key5 unsafe"),
        "key6": [AnsibleUnsafe("val6 unsafe")],
        "key7": {"a": AnsibleUnsafe("val7 unsafe"), "b": "val7"},
    }

# Generated at 2022-06-22 21:32:44.690958
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class Data(object):
        def __init__(self, value):
            self.value = value

    data = [Data('1'), Data('2'), Data('3')]
    data_new = _preprocess_unsafe_encode(data)
    assert data_new[0]['__ansible_unsafe'] == '1'
    assert data_new[1]['__ansible_unsafe'] == '2'
    assert data_new[2]['__ansible_unsafe'] == '3'



# Generated at 2022-06-22 21:32:46.675466
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    s = AnsibleJSONEncoder()
    t = s.default(5)
    s.iterencode(5)
    assert t == 5

# Generated at 2022-06-22 21:32:54.607230
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(foo=1)) == dict(foo=1)
    assert AnsibleJSONEncoder().default(dict(foo=1, bar=dict(bar=2))) == dict(foo=1, bar=dict(bar=2))
    assert AnsibleJSONEncoder().default(dict(foo=1, bar=dict(bar=2), unsafe='foo')) == dict(foo=1, bar=dict(bar=2), unsafe='foo')
    assert AnsibleJSONEncoder().default(dict(foo=1, bar=dict(bar=2), unsafe='foo', vault='ansible-vault')) == dict(foo=1, bar=dict(bar=2), unsafe='foo', vault='ansible-vault')

# Generated at 2022-06-22 21:32:56.322582
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)



# Generated at 2022-06-22 21:33:06.519992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Here we don't need to use the same class that Ansible uses, but we add it for test coverage.
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    # object test
    test_object = {
        "a": 100,
        "b": 200,
        "c": 300
    }
    test_result = {"a": 100, "b": 200, "c": 300}
    print(type(test_result))
    if not isinstance(test_result, dict):
        raise AssertionError("Expected type(test_result) to be dict")
    if not isinstance(test_object, dict):
        raise AssertionError("Expected type(test_object) to be dict")

# Generated at 2022-06-22 21:33:15.581729
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    password = "P@ssw0rd"
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    test_result1 = {'__ansible_vault': password}
    assert(ansible_json_encoder.default(password) == test_result1)
    test_result2 = {'__ansible_unsafe': password}
    assert(ansible_json_encoder.default(password) == test_result2)

# vim: set fileencoding=utf-8 ts=4 sw=4 tw=79 fdm=indent et :

# Generated at 2022-06-22 21:33:18.682271
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test') == 'test'


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 21:33:25.587226
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    '''
    Unit test for constructor of class AnsibleJSONEncoder
    '''

    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    data = [{'key': AnsibleUnsafe('value')}]
    data_encoded = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True, ensure_ascii=False)
    assert data_encoded == '[{"key": {"__ansible_unsafe": "value"}}]'

# Generated at 2022-06-22 21:33:33.126813
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {
        'a': 'b',
        'c': '1',
        'd': True,
        'e': False,
        'f': None,
        'g': {'h': 'i'},
        'j': ['k']
    }
    assert json.loads(json.dumps(data, cls=AnsibleJSONEncoder)) == data


# Generated at 2022-06-22 21:33:35.928838
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert 'test__ansible_vault' in json.dumps(dict(test__ansible_vault='testdata'.encode("utf-8")), cls=AnsibleJSONEncoder)

# Generated at 2022-06-22 21:33:39.034684
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    json_data='{"a": {"__ansible_unsafe": "unsafe data"}}'

    assert encoder.decode(json_data) == {"a": {"__ansible_unsafe": "unsafe data"}}



# Generated at 2022-06-22 21:33:44.812101
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C

    # Create vault object
    vault = VaultLib([], {})
    orig_vault_password = vault.password
    vault.password = 'testvaultpass'  # Cheap way to create vault object, no need to write to a file
    vault._bytes_encode = lambda s: s  # Avoid exception in python2.6 (when unit testing)
    vault.update(C.DEFAULT_VAULT_ID + ':vault text')

    # Create unsafe object
    from ansible.module_utils.urls import _AnsibleUnsafeText
    unsafe = _AnsibleUnsafeText('unsafe')

    # Create ansible json encoder

# Generated at 2022-06-22 21:33:47.897512
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default("AnsibleUnsafe") == {'__ansible_unsafe': 'AnsibleUnsafe'}



# Generated at 2022-06-22 21:33:58.036303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for safe object
    obj = AnsibleJSONEncoder().encode(1234)
    assert json.loads(obj) == 1234

    # Test for unsafe object
    from ansible.parsing.vault import VaultLib
    secret = VaultLib().encrypt('password')
    obj = AnsibleJSONEncoder().encode(secret)
    assert json.loads(obj) == {'__ansible_vault': secret.vault.encode('utf-8')}

    # Test for object that is a subclass of a string type
    class StringSubclass(str):
        __UNSAFE__ = True

    obj = AnsibleJSONEncoder().encode(StringSubclass('test'))
    assert json.loads(obj) == {'__ansible_unsafe': 'test'}

    # Test for hostvars


# Generated at 2022-06-22 21:34:08.551088
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.plugin_docs import read_docstring

    data = [{
        'bool': True,
        'int': 1,
        'long': 2,
        'float': 3.0,
        'list': ['a', 'b'],
        'dict': {'a': 'A'},
        'date': datetime.date(2016, 3, 18),
        'datetime': datetime.datetime(2016, 3, 18, 22, 39, 21),
        'none': None
    }]

    # We cannot reuse json.dumps as we need to encode ``VaultLib`` and
    # ``AnsibleUnsafe``

# Generated at 2022-06-22 21:34:19.139412
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Validate the AnsibleJSONEncoder.iterencode method through unit tests.
    """
    from ansible.module_utils.six import text_type

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib

    #setup the vault connection
    vault_password = 'vault-password-test'
    vault_password_file = 'vault-password-test-file'
    vault_connection = VaultLib([vault_password], vault_password_file)

    #setup the data structure to be json encoded

# Generated at 2022-06-22 21:34:29.315465
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    s = {'foo': 'bar', 'bar': b'baz', 'unsafe': AnsibleUnsafe('module_stdout: OK\nmodule_stderr: OK'),
         'list': [b'element1', AnsibleUnsafe(b'element2')], 'dict': {'something': b'else'}}
    expected = '{"foo": "bar", "bar": "baz", "unsafe": {"__ansible_unsafe": "module_stdout: OK\\nmodule_stderr: OK"}, ' \
               '"list": ["element1", {"__ansible_unsafe": "element2"}], "dict": {"something": "else"}}'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(s)

# Generated at 2022-06-22 21:34:38.981133
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common._text import to_text
    from ansible.parsing.vault import VaultLib, VaultSecret


# Generated at 2022-06-22 21:34:49.282439
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Set preprocess_unsafe to True, vault_to_text to False
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)

    assert ansiblejsonencoder._preprocess_unsafe == True
    assert ansiblejsonencoder._vault_to_text == False

    # Set preprocess_unsafe to False, vault_to_text to True
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)

    assert ansiblejsonencoder._preprocess_unsafe == False
    assert ansiblejsonencoder._vault_to_text == True

# Generated at 2022-06-22 21:34:55.648690
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # str
    assert encoder.default('123') == '123'
    # AnsibleUnsafe class
    v = encoder.default(encoder.encode(u'foo'))
    assert v == u'foo'
    # vault object
    v = encoder.default(encoder.encode(u'foo'))
    assert v == u'foo'


# Generated at 2022-06-22 21:34:56.815213
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()


# Generated at 2022-06-22 21:35:01.309818
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(
        preprocess_unsafe=False,
        vault_to_text=False
    )

    assert (ansible_json_encoder._preprocess_unsafe == False)
    assert (ansible_json_encoder._vault_to_text == False)

# Generated at 2022-06-22 21:35:03.571830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = {"a": "b"}
    b = AnsibleJSONEncoder().encode(a)
    assert b == '{"a": "b"}'

# Generated at 2022-06-22 21:35:13.810289
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars import unsafe_proxy
    var1 = {'a': unsafe_proxy({'a1': 'test'})}
    var2 = [unsafe_proxy({'a1': 'test'})]
    var3 = (unsafe_proxy({'a1': 'test'}), unsafe_proxy(['a2', 'b2']))
    var4 = unsafe_proxy('test')
    var5 = unsafe_proxy([unsafe_proxy('test1'), 'test2'][0])
    var6 = [unsafe_proxy('test1'), 'test2']
    var7 = {'a': unsafe_proxy(['a2']), "b": unsafe_proxy("b1")}

# Generated at 2022-06-22 21:35:23.877248
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    class AnsibleUnsafeProxy(AnsibleUnsafe, object):
        '''
        A subclass of ``AnsibleUnsafe`` that is not a subclass of string.
        '''
        def __init__(self, value):
            super(AnsibleUnsafeProxy, self).__init__(value)

    # The following Python objects are used
    # 1. string
    # 2. sequence of strings
    # 3. dict with string value
    # 4. dict with sequence of strings
    # 5. dict with dict as value
    # 6. dict with dict and sequence of dict as value
    # 7. dict with dict, dict with dict as value and dict with dict of dict as value
    # 8. dict with a function
    # 9. dict with

# Generated at 2022-06-22 21:35:34.065030
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    class _TestUnsafe(AnsibleUnsafe):
        pass

    test_unsafe_object = _TestUnsafe("unsafe object")
    test_vault_secret = VaultLib(VaultSecret("vault secret"))

    encoder = AnsibleJSONEncoder()
    assert json.loads("[%s]" % ''.join(encoder.iterencode(test_unsafe_object))) == [{'__ansible_unsafe': 'unsafe object'}]

# Generated at 2022-06-22 21:35:45.393968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # vault object
    assert AnsibleJSONEncoder().default(object().__new__(AnsibleUnsafe)) == {'__ansible_vault': u'{}'}

    # unsafe object, as we're testing __new__, it can't be a subclass of AnsibleUnsafe
    assert AnsibleJSONEncoder().default(object().__new__(AnsibleUnsafe)) == {'__ansible_unsafe': u'<class \'ansible_collections.ansible.community.plugins.module_utils.common.exceptions.AnsibleUnsafe\'>'}

    # hostvars and other objects

# Generated at 2022-06-22 21:35:56.338323
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import AnsibleUnsafe
    # TODO: Replace the AnsibleUnsafe object with json.JSONEncoder.default method call
    #       when the AnsibleUnsafe object is deprecated and removed
    ansible_unsafe = AnsibleUnsafe('********')

    assert not _is_vault(ansible_unsafe)
    assert _is_unsafe(ansible_unsafe)

    result = AnsibleJSONEncoder(preprocess_unsafe=True).default(ansible_unsafe)
    assert isinstance(result, dict)
    assert len(result) == 1
    assert '__ansible_unsafe' in result
    assert result['__ansible_unsafe'] == '********'

# Generated at 2022-06-22 21:35:59.177733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    _jsonEncoder = AnsibleJSONEncoder()
    o = AnsibleUnsafe("test")
    assert _jsonEncoder.default(o) == {'__ansible_unsafe': 'test'}



# Generated at 2022-06-22 21:36:07.012079
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import inspect
    import pprint
    import sys
    #from ansible.parsing import vault
    #from ansible.utils import encrypt
    import ansible.module_utils.ansible_unsafe

    #assert inspect.isclass(AnsibleJSONEncoder)
    print('AnsibleJSONEncoder:', AnsibleJSONEncoder)
    print('  docstring:', AnsibleJSONEncoder.__doc__)
    print()

    #assert dir(AnsibleJSONEncoder) == ['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__', '__hash__', '__init__', '__le__', '__lt__', '__module__', '__

# Generated at 2022-06-22 21:36:18.911941
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    # Initialize key values for test
    if PY3:
        key_values_normal = {'__ansible_unsafe': 'non-string object',
                             '__ansible_vault': 'encrypted object'}
        key_values_vault_to_text = {'__ansible_unsafe': 'non-string object',
                                    '__ansible_vault': 'encrypted object'}

# Generated at 2022-06-22 21:36:30.789630
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.module_utils.six import string_types

    safe_str = "vault-password"
    unsafe_obj = 'ansible-password'

    # ensure the given argument is an AnsibleUnsafe object.
    if isinstance(unsafe_obj, string_types):
        unsafe_obj = VaultLib.encrypt(safe_str, unsafe_obj)

    # encrypt safe_str with AnsibleUnsafe object.
    # This string object is required for test case when AnsibleJSONEncoder object.iterencode method is called.
    safe_str_encrypted = VaultLib.encrypt(safe_str, unsafe_obj)

    # Call AnsibleJSONEncoder.iterencode method to convert

# Generated at 2022-06-22 21:36:39.034513
# Unit test for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:36:49.783621
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import sys
    import io

# Generated at 2022-06-22 21:36:57.932547
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    json_data = AnsibleJSONEncoder(None, None).iterencode({"a": AnsibleUnsafeText("unsafe")})
    assert isinstance(next(json_data), str)
    assert b'"__ansible_unsafe": "unsafe"' in json_data.__self__.buffer

    json_data = AnsibleJSONEncoder(None, None).iterencode({"a": '{"a": "safe"}'})
    assert isinstance(next(json_data), str)
    assert b'"a": "safe"' in json_data.__self__.buffer

    json_data

# Generated at 2022-06-22 21:37:04.288367
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {
        'secret-vault': {'__ENCRYPTED__': True, '_ciphertext': '!vault |'},
        'secret-unsafe': {'__UNSAFE__': True},
        'secret-json': '!json "foo"',
    }
    encoder = AnsibleJSONEncoder()
    # Encoding of Ansible vault object
    r = encoder.default(data['secret-vault'])
    assert r['__ansible_vault'] == '!vault |'
    # Encoding of Ansible unsafe object
    r = encoder.default(data['secret-unsafe'])
    assert r == '{__unsafe__}'
    # Encoding of Ansible json object
    r = encoder.default(data['secret-json'])
    assert r

# Generated at 2022-06-22 21:37:14.959526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os

    import ansible.module_utils
    # Update module path with module_utils to pick up our ansible_types
    if ansible.module_utils.__path__[0] not in sys.path:
        sys.path.append(ansible.module_utils.__path__[0])

    # Get the class that is being tested
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    aje = AnsibleJSONEncoder()

    # Define object that will be encoded by method default
    class Test1(object):
        pass

    # Define object that will be encoded by method default
    class Test2(object):
        pass
        def __init__(self):
            self.a = 1

    # Define object that will not be encoded by method default

# Generated at 2022-06-22 21:37:16.893333
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert type(AnsibleJSONEncoder()) == AnsibleJSONEncoder

# Generated at 2022-06-22 21:37:26.902031
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import datetime
    import os

    vault_pass = os.environ.get('ANSIBLE_VAULT_PASS')
    vault_id = os.environ.get('ANSIBLE_VAULT_IDENTITY')

    if not vault_pass:
        vault_pass = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE')

    if not vault_pass:
        raise ValueError('Env variable ANSIBLE_VAULT_PASS or ANSIBLE_VAULT_PASSWORD_FILE or ANSIBLE_VAULT_IDENTITY is not set')

    vault = VaultLib()
    vault_encrypted_unsafe = vault.encrypt('Ansible Unsafe')
    vault_encrypted_string = vault.encrypt('Ansible String')


# Generated at 2022-06-22 21:37:31.961393
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Arrange
    ansible_json_encoder = AnsibleJSONEncoder()
    o = 'testing'

    # Act
    result = ansible_json_encoder.default(o)

    # Assert
    assert result == 'testing'



# Generated at 2022-06-22 21:37:42.541319
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleSequence

    # test 1, test AnsibleUnsafeText
    tests = {
        'test1': AnsibleUnsafeText(u'Not safe to display, {}, but can pass to the module'.format('something here'))
    }
    expected = json.dumps({"test1": {'__ansible_unsafe': u'Not safe to display, {}, but can pass to the module'.format('something here')}})
    jelly = json.dumps(tests, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert jelly == expected

    # test 2, test AnsibleUnsafeText include in a list

# Generated at 2022-06-22 21:37:51.701295
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encode = AnsibleJSONEncoder(preprocess_unsafe=True, check_circular=False, sort_keys=True, indent=4).encode
    data = {
        'key': 'value',
        'list': ['value1', 'value2', 'value3'],
        'unsafe_obj': 'hello',
    }
    # Simulate a Py2 string object
    data['unsafe_obj'] = data['unsafe_obj'].__class__(data['unsafe_obj'], 'utf-8', errors='replace')
    data['unsafe_obj'].__UNSAFE__ = True
    data['unsafe_obj'].__ENCRYPTED__ = False

# Generated at 2022-06-22 21:37:59.601118
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Construct AnsibleJSONEncoder with default values of arguments
    ans_encoder1 = AnsibleJSONEncoder()
    assert ans_encoder1._preprocess_unsafe is False
    assert ans_encoder1._vault_to_text is False

    # Test AnsibleJSONEncoder constructor with all arguments set to different values than default
    ans_encoder2 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ans_encoder2._preprocess_unsafe is True
    assert ans_encoder2._vault_to_text is True

# Generated at 2022-06-22 21:38:02.985860
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_string = json.dumps({'k': 'v'}, cls=AnsibleJSONEncoder)
    assert json_string == '{"k": "v"}'


# Generated at 2022-06-22 21:38:15.078841
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    a = VaultLib('test')
    a.decrypt('$ANSIBLE_VAULT;1.1;AES256\r\ndmlyZXR0ZQo2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2Ng==\r\n')
    b = {
        "a": a,
        "b": [a, a],
        "c": {"a": a},
    }


# Generated at 2022-06-22 21:38:24.160770
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({'foo': 1}) == {'foo': 1}
    assert AnsibleJSONEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}
    assert AnsibleJSONEncoder().default(('foo',)) == ['foo']
    # TODO: handle this case in the future to return datetime object
    # test_dict = {'foo': datetime.date(2017,1,1)}
    # assert AnsibleJSONEncoder().default(test_dict) == {'foo': '2017-01-01'}

# Generated at 2022-06-22 21:38:28.083454
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, indent=2)
    assert encoder.preprocess_unsafe is True
    assert encoder.vault_to_text is True
    assert encoder.indent is 2

# Generated at 2022-06-22 21:38:36.825516
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Setup
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.hostvars import HostVars
    import datetime
    TESTS = [
        (AnsibleUnsafe('unsafe'), {'__ansible_unsafe': 'unsafe'}),
        (HostVars(), {}),
        (datetime.datetime.utcnow(), '2019-01-30T08:23:19.120464'),
        ({'x': 1234}, {'x': 1234}),
        ('y', 'y'),
    ]

    encoder = AnsibleJSONEncoder()

    # Execute
    failures = []
    for t, expected in TESTS:
        result = encoder.default(t)

# Generated at 2022-06-22 21:38:46.070138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeObject

    def load_json(s):
        return json.loads(s, encoding="utf-8")

    def load_vault_json(kwargs):
        # Load raw vault, the result is not valid JSON
        vault_json = AnsibleJSONEncoder(**kwargs).encode(AnsibleUnsafeObject(vault))

        # Build a valid JSON document
        json_data = {
            "ansible_vault": json.loads(vault_json),
        }

        return json_data

    # Load data with encode
    vault = AnsibleVaultEncryptedUnicode(AnsibleUnsafeText(u"this is unsafe"))

# Generated at 2022-06-22 21:38:57.055460
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=unused-argument
    def assert_safe_json_encoding(obj, check_encrypted=True):
        actual_json = AnsibleJSONEncoder(check_circular=False, sort_keys=True, indent=2).encode(obj)
        actual_obj = json.loads(actual_json)
        # If obj is either an instance of AnsibleUnsafe() or inherits from the class
        # then actual_obj should be a dict and the key "__ansible_unsafe" should exist
        if isinstance(obj, AnsibleUnsafe) or isinstance(obj, str):
            assert isinstance(actual_obj, dict)
            assert "__ansible_unsafe" in actual_obj

# Generated at 2022-06-22 21:39:08.924425
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_pass = "password"
    vault = VaultLib([])
    vault_secret = vault._encrypt_bytes(vault_pass.encode('utf-8'))

    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(vault_secret)['__ansible_vault'] == to_text(vault_secret._ciphertext, errors='surrogate_or_strict', nonstring='strict')
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(vault_secret) == to_text(vault_secret, errors='surrogate_or_strict')


# Generated at 2022-06-22 21:39:12.666498
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    print("AnsibleJSONEncoder is :", ansible_json_encoder)

test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:39:13.272917
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-22 21:39:17.895396
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    encode_data = {"token": "dummy-token", "expires_at": datetime.datetime.utcnow().replace(tzinfo=datetime.timezone.utc), "expires_in": 600}
    encoder = Ansi

# Generated at 2022-06-22 21:39:18.660356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(_preprocess_unsafe=True)

# Generated at 2022-06-22 21:39:29.987022
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import sys
    if sys.version_info < (2, 7):
        # no assertRaises as context manager on python 2.6
        import nose
        raise nose.SkipTest()

    from ansible.parsing.vault import VaultLib

    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import cStringIO as StringIO

    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-22 21:39:41.412723
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import b

    vault_string_object = VaultLib([['secret']]).encrypt(b('value'))
    ansible_unsafe = vault_string_object
    data = [
        {'vault_string_object': vault_string_object},
        {'ansible_unsafe': ansible_unsafe},
        {'vault_list': [vault_string_object, ansible_unsafe]},
        'vault_string',
        vault_string_object,
        ansible_unsafe
    ]
    assert isinstance(data, (list, tuple))

    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data)

# Generated at 2022-06-22 21:39:45.610352
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True

    class AnsibleVault(unicode):
        __ENCRYPTED__ = True

    # Basic test
    str_test = 'hello world'
    str_test_ansible_safe = 'hello ansible safe'
    str_test_ansible_unsafe = AnsibleUnsafe('hello ansible unsafe')
    str_test_ansible_vault = AnsibleVault('hello ansible vault')
    int_test = 25
    float_test = 5.25
    list_test = [str_test_ansible_safe, str_test_ansible_unsafe, str_test_ansible_vault, int_test, float_test]

# Generated at 2022-06-22 21:39:49.673713
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    print(ansible_json_encoder)
    assert False, "Test unit is not available!"


# Generated at 2022-06-22 21:39:54.369982
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is True

# Generated at 2022-06-22 21:40:02.767237
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''
    Test method iterencode of class AnsibleJSONEncoder
    :return:
    '''
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean
    # TODO: Need to verify that the data is encoded properly
    data1 = "This is \u0074est\u0020data"
    data2 = AnsibleUnsafe('Unsafe data')
    data3 = boolean('yes')
    data4 = boolean('no')
    data5 = {'key1': 'value1', 'key2': data2}
    data6 = [data1, data5, data4]
    data7 = 5
    data8 = AnsibleUnsafe('Unsafe data')
    data9 = AnsibleUnsafe('Unsafe data')

# Generated at 2022-06-22 21:40:04.953633
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder, AnsibleJSONEncoder)

# Generated at 2022-06-22 21:40:06.409578
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json.dumps(None, cls=AnsibleJSONEncoder)
    assert True

# Generated at 2022-06-22 21:40:17.608237
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    class TestClass(object):
        def __init__(self, value):
            self.value = value
    import ansible.parsing.plugin_docs  # to get AnsibleUnsafe into global namespace
    assert AnsibleJSONEncoder(sort_keys=True).default('hello') == '"hello"'
    assert AnsibleJSONEncoder(sort_keys=True).default(123) == 123
    assert AnsibleJSONEncoder(sort_keys=True).default(1.23) == 1.23
    assert AnsibleJSONEncoder(sort_keys=True).default(TestClass('test')) == {'value': 'test'}
    assert AnsibleJSONEncoder(sort_keys=True).default(AnsibleUnsafe('123')) == {'__ansible_unsafe': '123'}

# Generated at 2022-06-22 21:40:28.105412
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import unittest
    from ansible.parsing.vault import VaultLib

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def setUp(self):
            from ansible.vars import AnsibleVars
            self.AV = AnsibleVars(use_unsafe_proxy=True)
            self.AV.set_unsafe_proxy('test_unsafe', AnsibleUnsafe('[$]}'))
            self.AV.set_vault_password('test_vault', 'test_password', AnsibleVault('[$]}'))
            self.encoder = AnsibleJSONEncoder()
