

# Generated at 2022-06-22 21:30:37.248131
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    class Test:
        pass

    test_obj = Test()
    test_obj.test_var = 'hello'

    _test_data = {
        'int': 5,
        'str': 'hello',
        'unicode': u'\u2019',
        'obj': test_obj
    }

    encoder = AnsibleJSONEncoder()

    for value in _test_data.values():
        assert encoder.default(value), "encoder.default failed on: %s" % repr(value)

    for value in _test_data.values():
        try:
            encoder.encode(value)
        except Exception:
            assert False, "encoder.encode failed on: %s" % repr(value)

# Generated at 2022-06-22 21:30:48.901007
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.vault import AnsibleVaultEncryptedUnicode

    ansible_json_encoder = AnsibleJSONEncoder()
    vault = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n'),
    data = ansible_json_encoder.default(vault)

    assert isinstance(data, text_type)
    assert data == '{"__ansible_vault": "$ANSIBLE_VAULT;1.1;AES256\\n"}'

    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    data = ansible_json

# Generated at 2022-06-22 21:31:00.232831
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    unsafe_str = AnsibleUnsafe('unsafe string')
    safe_str = str('safe string')

    vault_unsafe_str = VaultLib().encrypt('vault unsafe string')
    vault_safe_str = VaultLib().encrypt('vault safe string')

    unsafe_none = AnsibleUnsafe(None)
    safe_none = None

    assert list(encoder.iterencode(unsafe_str)) == ['{"__ansible_unsafe": "unsafe string"}']
    assert list(encoder.iterencode(safe_str)) == ['"safe string"']


# Generated at 2022-06-22 21:31:09.420615
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder1 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ansible_json_encoder1._preprocess_unsafe==True
    assert ansible_json_encoder1._vault_to_text==True

    ansible_json_encoder2 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert ansible_json_encoder2._preprocess_unsafe==False
    assert ansible_json_encoder2._vault_to_text==False


# Generated at 2022-06-22 21:31:19.950700
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # date object
    now = datetime.datetime.now()
    assert AnsibleJSONEncoder().default(now) == now.isoformat()

    # vault object

# Generated at 2022-06-22 21:31:28.698230
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    '''Unit test for AnsibleJSONEncoder class'''
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.collections import ImmutableDict
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    val_json = json.dumps({'foo': VaultSecret('bar'), 'value': 'some_value'}, cls=ansible_encoder)
    assert val_json == '{"foo": "bar", "value": "some_value"}'
    val_safe = json.dumps({'foo': VaultSecret('bar'), 'value': 'some_value'}, cls=ansible_encoder, sort_keys=True)

# Generated at 2022-06-22 21:31:39.543284
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.unsafe_proxy import wrap_var

    from io import StringIO
    from ansible.module_utils.six import text_type

    vault_passphrase = 'vault-passphrase'
    bin_vault_passphrase = to_text('vault-passphrase', encoding='utf-8', errors='surrogate_or_strict')
    vault_data1 = 'X\r\r\n/\x14\x0c\xbf\xa7\x03\x01\x9e\x0e\x80\x02.\x1b\x06\xe0?T'

# Generated at 2022-06-22 21:31:44.127067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    # test_mapping_support
    test_dict = {'id': 1, 'name': 'test_dict', 'sub_object': None}
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    result = ansible_json_encoder.default(test_dict)
    assert isinstance(result, dict)

    # test_datetime_support
    test_date = datetime.date(2018, 12, 15)
    result = ansible_json_encoder.default(test_date)
    assert isinstance(result, str)

    # test_vault_support
    from ansible.parsing.vault import VaultLib
    vault_password = 'test'
    vault

# Generated at 2022-06-22 21:31:54.946549
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.template import Templar
    from ansible.plugins.loader import lookup_loader


# Generated at 2022-06-22 21:32:02.837320
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    d = {'name': 'mock_name', 'password': 'mock_password'}
    s = json.dumps(d, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert s == '{"name": "mock_name", "password": "mock_password"}'
    d['password'] = 'mock_unsafe_password'
    s = json.dumps(d, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert s == '{"name": "mock_name", "password": {"__ansible_unsafe": "mock_unsafe_password"}}'

# Generated at 2022-06-22 21:32:13.897998
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeVaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    test_str = "test string"
    unsafe_str = AnsibleUnsafe(test_str)
    vault_str = UnsafeVaultSecret(test_str)
    vault = VaultLib([])
    vault_encrypted = vault.encrypt(test_str)

    assert AnsibleJSONEncoder().default(test_str) == test_str
    assert AnsibleJSONEncoder().default(unsafe_str) == {"__ansible_unsafe": test_str}
    assert AnsibleJSONEncoder().default(vault_str) == {"__ansible_vault": vault_encrypted}
    assert AnsibleJSONEncoder

# Generated at 2022-06-22 21:32:16.684120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = "Test"
    ansible_json_encoder = AnsibleJSONEncoder()
    val = ansible_json_encoder.default(obj)
    assert(val == obj)

# Generated at 2022-06-22 21:32:22.391390
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    Construct an AnsibleJSONEncoder with normal parameters and flags
    """

    json_encoder = AnsibleJSONEncoder(
        preprocess_unsafe=True,
        vault_to_text=False,
    )

    assert json_encoder._preprocess_unsafe is True
    assert json_encoder._vault_to_text is False

# Generated at 2022-06-22 21:32:27.526350
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible.parsing.vault

    password = 'test'
    vault_str = ansible.parsing.vault.VaultLib(password).encrypt(password)

    assert {'__ansible_vault': str(vault_str)} == json.loads(json.dumps(vault_str, cls=AnsibleJSONEncoder))

# Generated at 2022-06-22 21:32:36.783472
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.dataloader import AnsibleUnsafeText
    safe_text = "test123"
    unsafe_text_object = AnsibleUnsafeText(safe_text)
    unsafe_text_list = [safe_text, unsafe_text_object]
    unsafe_text_dict = {safe_text: unsafe_text_object}

    # Test safe text type
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.iterencode(safe_text) == safe_text

    # Test unsafe text object
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.iterencode(unsafe_text_object) == json.dumps({'__ansible_unsafe': safe_text})

    # Test unsafe text object with "preprocess_unsafe=True"

# Generated at 2022-06-22 21:32:48.370616
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.module_utils.six import text_type
    import base64
    def check_vault(text):
        assert is_sequence(text)
        assert all(isinstance(s, text_type) for s in text)

    # test a vault object
    secrets = [u'abc', u'def', u'ghi']
    data = VaultLib([VaultSecret(secrets)])
    assert data.__ENCRYPTED__
    buffer = b''
    base64_secret = text_type(base64.b64encode(b'\n'.join(secrets)), 'utf-8')

# Generated at 2022-06-22 21:32:55.739245
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type

    class MyString(text_type):
        pass

    class MyMapping(Mapping):
        def __init__(self, *args, **kwargs):
            self._data = dict(*args, **kwargs)

        def __getitem__(self, item):
            return self._data[item]

        def __len__(self):
            return len(self._data)

        def __iter__(self):
            return iter(self._data)

    test1 = MyString(u'val')
    test2 = MyMapping(key2='value2', key1='value1')

    test_data = [
        test1,
        test2
    ]

    enc

# Generated at 2022-06-22 21:33:01.055851
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_enc_test = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    json_str = json_enc_test.encode({'foo': 'bar'})
    assert json_str == json.dumps({'foo': 'bar'})

# Generated at 2022-06-22 21:33:07.943981
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import range
    import ansible.module_utils.parsing.convert_bool

    inst = AnsibleJSONEncoder(sort_keys=True)

    # test on basic types
    assert inst.default(bool(True)) == True
    assert inst.default(bool(1)) == True
    assert inst.default(bool('true')) == True
    assert inst.default(bool('True')) == True
    assert inst.default(bool('1')) == True

    assert inst.default(0) == 0
    assert inst.default(0.0) == 0.0
    assert inst.default(1) == 1
    assert inst.default(1.0) == 1.0
    assert inst

# Generated at 2022-06-22 21:33:19.488794
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.plugins.vars import vault as var_vault

    # use AnsibleModule to configure the vault class to be used
    am = AnsibleModule(vars_plugins=[var_vault.VaultLib()])

    # create an instance of AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # test for encoding of a custom class
    class Custom:
        pass
    custom_value = Custom()

# Generated at 2022-06-22 21:33:21.658391
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # check the class of the object is AnsibleJSONEncoder
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)

# Generated at 2022-06-22 21:33:28.815551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestObject(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

        def __eq__(self, other):
            return self.value == other.value

    class TestVault(object):
        __ENCRYPTED__ = True

        def __init__(self, value):
            self._ciphertext = value

        def __repr__(self):
            return "VAULT(%s)" % repr(self._ciphertext)

        def __str__(self):
            return "VAULT(%s)" % repr(self._ciphertext)

        def __html__(self):
            return "VAULT(%s)" % repr(self._ciphertext)


# Generated at 2022-06-22 21:33:29.460107
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  assert 1 == 1

# Generated at 2022-06-22 21:33:36.669498
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    expected_text = json.dumps(['foo', 'bar', 'baz'], ensure_ascii=False)

    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True

    ansible_unsafe_text = AnsibleUnsafe(u'foo bar baz')

    actual_text = ''.join(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode([ansible_unsafe_text]))

    assert expected_text == actual_text

# Generated at 2022-06-22 21:33:43.387132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Unit test for method default of class AnsibleJSONEncoder
    '''
    from ansible.parsing.vault import VaultLib

    vault_secret = 'test secret'
    vault_password = 'test password'
    vault_filename = '/tmp/test_vault.yml'
    vault_content = vault_secret

    vault_lib = VaultLib(vault_password)
    vault_lib.write(vault_filename, vault_content)

    ansible_vault = vault_lib.open_file(vault_filename)
    json_ansible_vault = {'__ansible_vault': vault_lib.encrypt(vault_content)}

    ansible_json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:33:54.205350
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    vault_secret = VaultLib(b"vault_key")

    with vault_secret.locked():
        plain_unsafe_text = vault_secret.encrypt(b"vault")
        plain_unsafe_binary = vault_secret.encrypt(b"\xff")
        plain_unsafe_non_ascii_text = vault_secret.encrypt(b"vault\xc3\xab")
        plain_unsafe_non_ascii_binary = vault_secret.encrypt(b"\xc3\xab\xff")
        plain_unsafe_utf8_text = vault_secret.encrypt(b"vault\xc3\xab".decode("utf-8"))
        plain_unsafe_utf8_binary = vault_secret

# Generated at 2022-06-22 21:34:05.208187
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    class TestUnsafe(object):
        __UNSAFE__ = True

    class TestVault(object):
        __ENCRYPTED__ = True

        def __init__(self):
            self._ciphertext = 'some-ciphertext'

    class TestEncoder(AnsibleJSONEncoder):
        def default(self, o):
            return o


# Generated at 2022-06-22 21:34:16.974474
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.types import AnsibleUnsafe, AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeDict
    from ansible.parsing.vault import VaultLib, VaultSecret
    import json
    import os
    import tempfile
    unsafe_string = 'This is an unsafe string'
    unsafe_wrapper = AnsibleUnsafe(unsafe_string)
    test_safe_string = 'This is a safe string'
    test_dict = {'key': unsafe_wrapper}
    test_list = ['item1', unsafe_wrapper]
    test_list_nested = ['item1', ['item2', unsafe_wrapper]]
    test_safe_dict = {'key': test_safe_string}
    test_

# Generated at 2022-06-22 21:34:28.141962
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    import datetime
    datetime_value = datetime.datetime(year=2019, month=12, day=30)
    vault_value = VaultSecret(VaultLib([])).encrypt(to_bytes('vault_value'))
    value = AnsibleJSONEncoder(vault_to_text=True).default(datetime_value)
    assert value == '2019-12-30T00:00:00'
    value = AnsibleJSONEncoder(vault_to_text=True).default(vault_value)

# Generated at 2022-06-22 21:34:36.918907
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # initialize vault
    vault_secret = VaultSecret('myvaultpassword', '')
    vault = VaultLib(vault_secret, json_only=True)

    # create sample objects
    secret = AnsibleUnsafe(vault.encrypt('secret'))
    hostvars = {'ansible_connection': 'local', 'ansible_ssh_host': 'localhost'}
    date = datetime.datetime.utcnow()

    # initialize encoder
    encoder = AnsibleJSONEncoder()

    # test if encoded values match expected values
    assert encoder.default({'__ansible_unsafe': 'secret'}) == secret

# Generated at 2022-06-22 21:34:49.435027
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing import vault
    from ansible.module_utils._text import to_text

    ENCODER = AnsibleJSONEncoder()

    # No changes if no vault and no unsafe
    assert to_text(ENCODER.iterencode({'key': 'value'})) == "{'key': 'value'}"

    # Vault object
    my_vault = vault.VaultLib('some vault passphrase')
    my_vault.update({'key': 'vault value'})
    _json = ENCODER.iterencode(my_vault).decode('utf-8')
    assert _json == '{"__ansible_vault": "vault value"}'

    # Unsafe object
    unsafe_string = "unsafe"

# Generated at 2022-06-22 21:34:57.930171
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_json_encoder._preprocess_unsafe == True

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ansible_json_encoder._vault_to_text == True

# Generated at 2022-06-22 21:34:59.089212
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False

# Generated at 2022-06-22 21:35:08.785769
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsiEncoder = AnsibleJSONEncoder(preprocess_unsafe=False, sort_keys=False, indent=4, separators=(',', ': '))
    TestStr = 'Test'
    TestResult = AnsiEncoder.encode(TestStr)
    TestResult = json.loads(TestResult)
    assert TestResult == TestStr

    import datetime
    TestDate = datetime.date(2019, 2, 14)
    TestResult = AnsiEncoder.encode(TestDate)
    TestResult = json.loads(TestResult)
    assert TestResult == TestDate.isoformat()
    TestDate = datetime.datetime(2019, 2, 14, 11, 00, 00)
    TestResult = AnsiEncoder.encode(TestDate)

# Generated at 2022-06-22 21:35:10.026358
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder=AnsibleJSONEncoder()
    return encoder

# Generated at 2022-06-22 21:35:20.164715
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import AnsibleUnsafeText
    a = dict(key1=dict(key3='str', key2=AnsibleUnsafeText(u'我爱你')))
    b = dict(key1=dict(key3='str', key2={'__ansible_unsafe': u'我爱你'}, key1={'__ansible_unsafe': u'我爱你'}))

    # unicode encode
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(a)) == list(json.JSONEncoder().iterencode(b))

    # str encode

# Generated at 2022-06-22 21:35:28.185554
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    | Unit test | Encoder |
    | --------: | :------ |
    | Description | Test iterencode method of AnsibleJSONEncoder |
    | Execution | python tests/unit/utils/json_encoder_test.py -v |
    """

    from ansible.module_utils.common.encoding import to_bytes

    assert to_bytes(AnsibleJSONEncoder().iterencode('')) == '""'
    assert to_bytes(AnsibleJSONEncoder().iterencode('test string')) == '"test string"'
    assert to_bytes(AnsibleJSONEncoder().iterencode(u'\u2713')) == '"\\u2713"'

# Generated at 2022-06-22 21:35:37.909617
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    vault = VaultLib([('default', get_file_vault_secret(None))])
    value = u'value'
    values = [value]
    vault_value = vault.encrypt(value.encode('utf-8'))
    vault_values = [vault_value]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    json_encoded = encoder.default(value)
    assert isinstance(json_encoded, text_type)
    json_encoded = encoder.default(values)

# Generated at 2022-06-22 21:35:40.482017
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a

# Generated at 2022-06-22 21:35:43.817493
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert a._preprocess_unsafe
    assert not a._vault_to_text


# Generated at 2022-06-22 21:35:51.927913
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing import vault
    from ansible.parsing.unsafe_string import to_unicode
    i = {
        'a': 1,
        'b': [2, 3],
        'c': {
            'd': 4,
            'e': 5,
        },
        'f': vault.VaultLib().encrypt('password'),
        'g': vault.VaultLib().encrypt('password2'),
        'h': to_unicode('This is a string'),
    }

# Generated at 2022-06-22 21:36:00.127170
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ret = AnsibleJSONEncoder()
    assert ret, "AnsibleJSONEncoder returns non-empty object"
    assert ret._preprocess_unsafe == False, "AnsibleJSONEncoder._preprocess_unsafe is default False"
    assert ret._vault_to_text == False, "AnsibleJSONEncoder._vault_to_text is default False"
    assert ret.sort_keys == False, "AnsibleJSONEncoder.sort_keys is default False"

# Generated at 2022-06-22 21:36:10.539576
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    result = vault.encrypt('value')
    value = dict(
        datetime_obj=datetime.datetime.now(),
        date_obj=datetime.date.today(),
        str_obj='value',
        bytes_obj=b'bytes',
        unsafe_obj=AnsibleUnsafeText('value'),
        vault_obj=result,
    )


# Generated at 2022-06-22 21:36:19.381733
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes

    class unsafe(str):
        __UNSAFE__ = True

    class vault(str):
        __ENCRYPTED__ = True

    class foo(object):
        def __init__(self):
            self.key = 'value'

        def __iter__(self):
            return iter(self.key)

        def __getitem__(self, item):
            if item == 'key':
                return 'value'

    # date object
    date = datetime.date.today()

    json_encoder = AnsibleJSONEncoder(indent=2)
    json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True, indent=2)

    # test for ansible unsafe object

# Generated at 2022-06-22 21:36:22.635145
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test that the constructor of class AnsibleJSONEncoder is empty,
    # as this type is a built-in type, as required by pytest-pylint
    assert AnsibleJSONEncoder()


# Generated at 2022-06-22 21:36:33.182324
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # All the cases, AnsibleJSONEncoder.default() can handle, are tested in this test
    # The cases ansible_vault and ansible_unsafe, will not be tested here.
    # They are tested in the test_AnsibleJSONEncoder_iterencode()

    # input data
    data = AnsibleUnsafe("Password")
    hostvars = {'ansible_ssh_password': data}

    # Test JSON Encoder
    expected_result = json.dumps({'ansible_ssh_password': 'Password'})
    # Enable the flag to pre-process unsafe data
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    actual_

# Generated at 2022-06-22 21:36:36.035792
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert encoder



# Generated at 2022-06-22 21:36:46.623415
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    vault = encoder.default(encoder)

# Generated at 2022-06-22 21:36:55.426944
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    test_cases = [
        # encoding of AnsibleUnsafe should be handled
        ([AnsibleUnsafe('abc'), 'bcd'], True, '[{"__ansible_unsafe": "abc"}, "bcd"]'),
        ([AnsibleUnsafe('abc'), 'bcd'], False, '["abc", "bcd"]'),
        # encoding of other things should be handled by default
        ({'a': 1, 'b': 2}, False, '{"a": 1, "b": 2}'),
    ]

    for test_case in test_cases:
        s = AnsibleJSONEncoder(preprocess_unsafe=test_case[1]).iterencode(test_case[0])
        e = test_case[2]


# Generated at 2022-06-22 21:36:57.301380
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)

# Generated at 2022-06-22 21:37:03.797509
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe_string = '{"a":1,"b":2,"c":3}'
    unsafe_bytes = b'{"a":1,"b":2,"c":3}'
    unsafe_dict = {"a":1,"b":2,"c":3}
    unsafe_list = [1,2,3,"4"]

    # Test encoding a dict, testing preprocessing and all
    assert isinstance(AnsibleJSONEncoder().encode(unsafe_dict), str)
    assert isinstance(AnsibleJSONEncoder(preprocess_unsafe=True).encode(unsafe_dict), str)

    # Test encoding a list, testing preprocessing and all
    assert isinstance(AnsibleJSONEncoder().encode(unsafe_list), str)

# Generated at 2022-06-22 21:37:14.337399
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    class TestVaultLib(VaultLib):
        def encrypt(self, value):
            return value

        def decrypt(self, ciphertext):
            return ciphertext

        def encrypt_bytes(self, value, output_encoding='utf-8'):
            return value

        def decrypt_bytes(self, ciphertext, input_encoding='utf-8', output_encoding='utf-8'):
            return ciphertext

    cipher_text = b"$ANSIBLE_VAULT;1.1;AES256;ciphertext\ntext"
    vault_obj = TestVaultLib(1).decrypt(cipher_text)
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    import uuid
    test_

# Generated at 2022-06-22 21:37:25.339767
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test class AnsibleJSONEncoder
    print("Testing method default of class AnsibleJSONEncoder")
    myobj = AnsibleJSONEncoder()
    # Test 1
    ansible_unsafe = {'__ansible_unsafe': 'my_unsafe_string'}
    ansible_vault = {'__ansible_vault': 'my_unsafe_string'}
    date = datetime.date(2018, 1, 1)
    date_str = '2018-01-01'
    test_item = {'ansible_unsafe': ansible_unsafe, 'ansible_vault': ansible_vault, 'date': date}
    tested_item = myobj.default(test_item)
    if tested_item == test_item:
        print("Test 1 passed")
    else:
        print

# Generated at 2022-06-22 21:37:35.487633
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    encoder = AnsibleJSONEncoder()

    assert encoder.default("foo") == "foo"
    assert encoder.default("foo".encode("utf-8")) == u"foo"
    assert encoder.default("foo".encode("utf-16")) == u"foo"
    assert encoder.default("foo".encode("utf-32")) == u"foo"
    assert encoder.default("foo".encode("ascii")) == u"foo"
    assert encoder.default("foo".encode("latin-1")) == u"foo"
    assert encoder.default("foo".encode("cp858")) == u"foo"

    # we should get the original byte string here
    assert encoder.default("foo".encode("cp850")) == "foo".encode("cp850")

    assert encoder

# Generated at 2022-06-22 21:37:40.464153
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {
        'dict': {
            'a': list('unsafe_list'),
            'b': {
                1: dict(name='unsafe_dict')
            }
        },
        'list': list(range(10))
    }
    # unsafe data
    data['unsafe'] = 'unsafe_str'

    # obj = AnsibleJSONEncoder()
    # assert obj.iterencode({}) == '{}'

    # data is safe
    obj = AnsibleJSONEncoder()
    assert obj.iterencode({'a':2}) == '{"a": 2}'

    # data is unsafe
    obj = AnsibleJSONEncoder(preprocess_unsafe=True)
    data = {'a': obj.encode({'b':'@@@'})}
    assert obj.iterencode

# Generated at 2022-06-22 21:37:50.360711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    import datetime

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    class NonSerializableClass(object):
        pass

    class SerializableClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __getstate__(self):
            return dict(a=self.a, b=self.b)


# Generated at 2022-06-22 21:37:55.721336
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-22 21:37:57.543523
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    value = AnsibleJSONEncoder()
    assert value._preprocess_unsafe == False and value._vault_to_text == False


# Generated at 2022-06-22 21:38:04.904159
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from .unsafe_proxy import AnsibleUnsafeText
    from .vault import VaultLib
    from .vault import VaultSecret
    # TODO: move json_dict to ansible/module_utils/common/collections.py
    json_dict = {
        'array': [1, 2, 3, 4],
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'object': [{'a': 1, 'b': 2, 'c': 3}, {'x': 'y'}],
        'string': 'Hello',
        'bytes': b'h\xe9llo',
        'unicode': u'h\xe9llo',
        'none': None,
        'bool': True,
        'int': 65,
        'float': 10.25
    }

    ansible

# Generated at 2022-06-22 21:38:16.608509
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    Tests the AnsibleJSONEncoder().iterencode() method
    """
    from ansible.parsing.vault import VaultLib
    import unittest

    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    import os

    #
    # mocking of VaultLib
    #

    class AnsibleVaultDummy():
        """
        Dummy class for replacing the VaultLib.encrypt() class
        """
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    # Mocks
    mock_vault_encrypt = mock.Mock(return_value=AnsibleVaultDummy('This is my encrypted value'))

# Generated at 2022-06-22 21:38:22.934603
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test default method of class AnsibleJSONEncoder
    inner_dict = {'hello': 'world'}
    outer_dict = {'inner':inner_dict}
    assert ansible_json_encoder.default(outer_dict) == outer_dict


# Generated at 2022-06-22 21:38:33.258294
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    V_TEXT = to_text(u'test')

# Generated at 2022-06-22 21:38:44.811056
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from ansible.parsing.vault import VaultLib

    vault = VaultLib()
    encrypted = vault.encrypt(b'$ecret')

    class Dummy(object):
        def __init__(self, a):
            self.a = a

    class DummyVault(object):
        def __init__(self, a):
            self.a = a

    dummy = Dummy('a')
    dummy_vault = DummyVault(encrypted)

    class TestEncoder(unittest.TestCase):

        def runTest(self):
            encoder = AnsibleJSONEncoder()
            self.assertEqual(encoder.default(dummy), {'a': 'a'})
           

# Generated at 2022-06-22 21:38:52.507327
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class AnsibleYAMLObject(AnsibleBaseYAMLObject):
        pass

    ansible_yaml_object = AnsibleYAMLObject()

    ansible_json_encoder = AnsibleJSONEncoder()
    encoded_object = ansible_json_encoder.default(ansible_yaml_object)
    assert encoded_object['__ansible_unsafe'] == ansible_yaml_object

# Generated at 2022-06-22 21:38:54.137799
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # constructor test
    my_obj = AnsibleJSONEncoder(indent=3)
    assert my_obj.indent == 3


# Generated at 2022-06-22 21:39:01.776393
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    test_json_data = {
        'key': 'value',
        'number': 1,
        'null': None,
        'list': [
            {
                'list_key': 'list_value'
            }
        ]
    }
    dumped_json = json.dumps(test_json_data, cls=AnsibleJSONEncoder)
    assert dumped_json == '{"key": "value", "number": 1, "null": null, "list": [{"list_key": "list_value"}]}'

# Generated at 2022-06-22 21:39:12.785283
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    data = {
        'foo': {
            'bar': ['baz', 'foobar'],
            'pass': VaultLib().encrypt('password'),
            'unsafe': {
                'normal': 'outbound',
                'secret': VaultSecret('ditto'),
                'cipher': VaultSecret('ciphertext'),
            }
        }
    }

    with tempfile.NamedTemporaryFile('w+') as tmp:
        # Encrypting with vault_to_text=True will encode AnsibleUnsafe to text
        json.dump(data, tmp, cls=AnsibleJSONEncoder, vault_to_text=True)
        tmp.flush()

# Generated at 2022-06-22 21:39:21.541724
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    # Passing string_types object
    data_input = AnsibleVaultEncryptedUnicode('test_ansible_vault')
    # Expecting type dictionary
    data_output = {'__ansible_vault': u'test_ansible_vault'}
    assert isinstance(AnsibleJSONEncoder().default(data_input), dict)
    assert AnsibleJSONEncoder().default(data_input) == data_output

# Generated at 2022-06-22 21:39:33.058273
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    assert obj.default(u'é') == u'é'
    assert obj.default(u'é'.encode('utf-8')) == u'é'
    assert obj.default(u'é'.encode('latin1')) == u'é'
    assert obj.default(u'é\u0301'.encode('utf-8')) == u'\u00e9'
    assert obj.default(u'é\u0301'.encode('latin1')) == u'\u00e9'
    assert obj.default(b'\xc3\xa9') == 'é'
    assert obj.default(b'\xc3\xa9\xcc\x81') == 'é́'
    assert obj.default(u'\u0301')

# Generated at 2022-06-22 21:39:44.730483
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Constructor of class AnsibleJSONEncoder
    json_encoder = AnsibleJSONEncoder()
    assert (getattr(json_encoder, '_preprocess_unsafe', False) == False)
    assert (getattr(json_encoder, '_vault_to_text', False) == False)

    # Constructor of class AnsibleJSONEncoder with preprocess_unsafe and vault_to_text as False
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe = False, vault_to_text = False)
    assert (getattr(json_encoder, '_preprocess_unsafe', False) == False)
    assert (getattr(json_encoder, '_vault_to_text', False) == False)

    # Constructor of class AnsibleJSONEncoder with preprocess_unsafe

# Generated at 2022-06-22 21:39:55.930001
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test class AnsibleJSONEncoder
    import datetime
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe

    class TestEncoder(AnsibleJSONEncoder):
        def default(self, o):
            if getattr(o, '__UNSAFE__', False):
                return to_text(o, errors='surrogate_or_strict', nonstring='strict')
            return super(TestEncoder, self).default(o)

    # test the function default
    assert AnsibleJSONEncoder().default(AnsibleUnsafeText(b'text')) == {'__ansible_unsafe': b'text'}

# Generated at 2022-06-22 21:40:01.184886
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Initialize the class
    ansible_json_encoder = AnsibleJSONEncoder()
    
    # Test init_method of the class
    try:
        assert(ansible_json_encoder.__init__(False, False))
        assert(True)
    except Exception as e:
        assert(False)

if __name__ == '__main__':
    test_AnsibleJSONEncoder()
    print("AnsibleJSONEncoder tests finished")

# Generated at 2022-06-22 21:40:13.401582
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault  # pylint: disable=import-outside-toplevel

    plain_text = 'plain'
    unsafe = vault.VaultLib.new_unsafe_text(plain_text)
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(unsafe) == {'__ansible_unsafe': plain_text}

    cipher_text = 'AES256$16$3$1$8c63ed83a9a23c543f9bfc5d5d862bcb$e5fbcde8b8c0d892c9eafaf50c1bca8a7e35f0e50f74b232a0bf8a40f89d9c22'
    vaulted

# Generated at 2022-06-22 21:40:20.149208
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unsafe
    from ansible.module_utils.common.text.converters import to_vault

    data = {
        'a': 'a',
        'b': to_unsafe('b'),
        'c': to_vault('c'),
        'd': ['e', to_unsafe('f'), to_vault('g')],
        'h': {
            'i': 'j',
            'k': to_unsafe('l'),
            'm': to_vault('n')
        }
    }

    def assert_elements_are_safe(d):
        assert d == {'a': 'a'}


# Generated at 2022-06-22 21:40:32.054907
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test if ciphertext of AnsibleUnsafe object is converted to the expected value
    # Since AnsibleUnsafe class is from ansible.module_utils.six import text_type, we can not create an instance of it.
    # So we make a fake class AnsibleUnsafe to serve as a substitute for test purpose
    class AnsibleUnsafe(object):
        def __init__(self, _instance=None, **kwargs):
            self._instance = _instance
            self.__UNSAFE__ = True

        def __str__(self):
            return 'test_ciphertex'

    # Test if ciphertext of AnsibleVault object is converted to the expected value
    # Since AnsibleVault class is from ansible.parsing.vault import AnsibleVaultEncryptedUnicode, we can not create
    # an instance of it