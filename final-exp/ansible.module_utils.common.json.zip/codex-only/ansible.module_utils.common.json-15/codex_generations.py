

# Generated at 2022-06-22 21:30:38.314688
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    # Create an AnsibleUnsafe
    unsafe = AnsibleUnsafe('{"no": ["quotes"]}')
    # Check that it is__UNSAFE__
    assert unsafe.__UNSAFE__ is True
    # Check that it does not have __ENCRYPTED__
    assert unsafe.__ENCRYPTED__ is False
    # Check that it does not have __ansible_vault
    assert not hasattr(unsafe, '__ansible_vault')
    # Make a JSON string with it
    unsafe_str = json.dumps(unsafe, cls=AnsibleJSONEncoder, preprocess_unsafe=True, ensure_ascii=False)
    # Check that it is a Unicode string

# Generated at 2022-06-22 21:30:48.550557
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    def _generate_unsafe_secret(secret):
        from ansible.parsing.unsafe_proxy import AnsibleUnsafeText
        from ansible.parsing.unsafe_proxy import wrap_var

        return wrap_var(AnsibleUnsafeText(secret))

    # Encoding of ansible.parsing.vault.vaultlib.VaultLib object
    vault_container = {'vault_item': VaultLib('secret_key', VaultSecret('ciphertext'))}

    encoded_vault_container = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(vault_container)


# Generated at 2022-06-22 21:30:59.085266
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder.default("foo")
    ansible_json_encoder.default(None)
    ansible_json_encoder.default(1)
    ansible_json_encoder.default(1.0)
    ansible_json_encoder.default(True)
    ansible_json_encoder.default([1])
    ansible_json_encoder.default({})
    ansible_json_encoder.default([1, {"a": 1}])
    ansible_json_encoder.default({"a": 1})
    ansible_json_encoder.default(datetime.datetime.now())


# Generated at 2022-06-22 21:31:10.580929
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib

    my_obj = object()

    my_vault = VaultLib([10, 2])
    my_vault.decrypt('')

    my_encrypted = my_vault.encrypt('str')

    my_unsafe = my_vault._get_unsafe_text('str')

    assert AnsibleJSONEncoder().default(my_obj) == my_obj

    assert AnsibleJSONEncoder(vault_to_text=True).default(my_encrypted) == 'str'


# Generated at 2022-06-22 21:31:11.911116
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test = AnsibleJSONEncoder()
    assert test is not None

# Generated at 2022-06-22 21:31:15.246467
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert not encoder._preprocess_unsafe
    assert not encoder._vault_to_text


# Generated at 2022-06-22 21:31:25.914722
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.ansible_unsafe import AnsibleUnsafe

    vault_password_file = 'ansible.test.vault'
    vault_password = 'test'

# Generated at 2022-06-22 21:31:37.039697
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:31:40.039779
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # this unit test case is not suitable for testing
    assert encoder is not None

# Generated at 2022-06-22 21:31:49.297612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableSet
    from ansible.parsing.vault import VaultLib

    # test base objects
    test = AnsibleJSONEncoder().encode({'hello': 'world'})
    assert test == '{"hello": "world"}'

    # test custom object
    test = AnsibleJSONEncoder().encode({'hello': 'world', 'custom': {'stuff': 'value'}})
    assert test == '{"hello": "world", "custom": {"stuff": "value"}}'

    # test custom object with object inside
    test = AnsibleJSONEncoder().encode({'hello': 'world', 'custom': {'stuff': {'value': 'value2'}}})

# Generated at 2022-06-22 21:31:59.280675
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test date object
    date_obj = datetime.date(2017, 11, 18)
    expected_json_string = json.dumps(date_obj.isoformat())
    actual_json_encoding = AnsibleJSONEncoder().encode(date_obj)

    assert expected_json_string == actual_json_encoding

    # Test default method for class 'datetime.datetime'
    datetime_obj = datetime.datetime(2017, 11, 18, 11, 23)
    expected_json_string = json.dumps(datetime_obj.isoformat())
    actual_json_encoding = AnsibleJSONEncoder().encode(datetime_obj)

    assert expected_json_string == actual_json_encoding

# Generated at 2022-06-22 21:32:01.681276
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(encoder, AnsibleJSONEncoder)


# Generated at 2022-06-22 21:32:13.054795
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    values = {'value1': 'foo',
              'value2': 'bar',
              'value3': [],
              'value4': {'mapping1': 'value'},
              'value5': datetime.datetime(2017, 4, 6, 3, 4, 5, 6),
              'value6': datetime.date(2017, 4, 6)}
    assert json.dumps(values, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"value1": "foo", "value2": "bar", "value3": [], "value4": {"mapping1": "value"}, "value5": "2017-04-06T03:04:05.000006", "value6": "2017-04-06"}'

# Generated at 2022-06-22 21:32:24.933628
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest

    class AnsibleJSONEncoderTestCase(unittest.TestCase):

        def test_encoding_safe(self):
            from ansible.parsing.vault import VaultLib
            sample_text = "sample text"
            vault_password = "vaultpassword"
            vault = VaultLib(vault_password)
            vault_encrypted = vault.encrypt(sample_text)
            encrypted_object = str(vault_encrypted)
            encoder = AnsibleJSONEncoder()
            result = encoder.encode(encrypted_object)

# Generated at 2022-06-22 21:32:33.328736
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    ansible.module_utils.common.json_utils - test_AnsibleJSONEncoder
    """
    encoder = AnsibleJSONEncoder()
    assert encoder.FLAGS == 0

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.FLAGS == 0
    assert encoder._preprocess_unsafe == True

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder.FLAGS == 0
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-22 21:32:42.669601
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars import AnsibleUnsafeText

    result = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).iterencode({
        'unencrypted': AnsibleUnsafeText('my super secret', 'AES256', 'win'),
        'vault': VaultLib('password', 'salt', '1', 'AES256').encrypt('my super secret vault')
    })

    assert json.loads(next(result)) == {'unencrypted': 'my super secret', 'vault': 'my super secret vault'}
    assert next(result) == '}'

# Generated at 2022-06-22 21:32:52.186579
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''Unit test for method iterencode of class AnsibleJSONEncoder'''
    import ansible.module_utils.basic as basic
    import ansible.module_utils.six as six
    import ansible.module_utils.unsafe_proxy as unsafe_proxy

    ansible_json_encoder = AnsibleJSONEncoder()

    array_object = [1, 2, 3]
    dict_object = {'one': 1, 'two': 2, 'three': 3}

    # Encode simple json object
    assert ansible_json_encoder.iterencode(array_object) == '[1, 2, 3]'
    assert ansible_json_encoder.iterencode(dict_object) == '{"three": 3, "two": 2, "one": 1}'

    # Encode an instance of class ansible.module

# Generated at 2022-06-22 21:33:03.910748
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    abc = u"abc"
    a_mapping = {abc: 123}
    a_json_encoder = AnsibleJSONEncoder()

    # test if the constructor set the correct attributes
    assert a_json_encoder._preprocess_unsafe == False
    assert a_json_encoder._vault_to_text == False

    # test if the default method return the correct values
    # test the value of default (Mapping)
    assert a_json_encoder.default(a_mapping) == a_mapping
    # test the value of default (AnsibleUnsafe)
    a_unsafe = u"abc"
    setattr(a_unsafe, '__UNSAFE__', True)

# Generated at 2022-06-22 21:33:14.933236
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import pytest

    # basic test
    enc = AnsibleJSONEncoder()
    assert enc.encode(["some", "values"]) == "[\"some\", \"values\"]"

    # test preprocess_unsafe=True
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafeText
    vault_text = VaultLib('password').encrypt(u'Söme text')
    vault_obj = AnsibleUnsafeText(vault_text)
    json_output = enc.encode([vault_obj, "vault_text"], vault_to_text=True)

# Generated at 2022-06-22 21:33:24.552881
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def check(value, is_vault=False, is_vault_to_text=False):
        encoder = AnsibleJSONEncoder(vault_to_text=is_vault_to_text)
        res = encoder.default(value)
        if is_vault:
            assert '__ansible_vault' in res and value._ciphertext == res['__ansible_vault']
        else:
            assert value == res

    check('test')
    check('test\n')

    class VaultV1(object):
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    class VaultV2(object):
        __ENCRYPTED__ = True


# Generated at 2022-06-22 21:33:31.355298
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib

    # This test is simply for the constructor at this point.
    # Other tests for VaultLib objects exist in test_vault.py.
    # We just want to test that the use of the vault object here
    # doesn't throw an exception.

# Generated at 2022-06-22 21:33:35.655707
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import pytest

    class TestClass:
        pass

    tclass = TestClass()
    encoder = AnsibleJSONEncoder()

    # test for Ansible encrypted data
    assert encoder.default(u"vault_password") == u"vault_password"
    assert encoder.default(u"ansible_password") == u"ansible_password"

    # test for non Ansible encrypted data
    assert encoder.default(u"foo") == u"foo"

    # test for other types
    assert encoder.default(tclass) == tclass
    assert encoder.default(5) == 5

# Generated at 2022-06-22 21:33:38.504471
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default([]) == []

    now = datetime.datetime.now()
    assert AnsibleJSONEncoder().default(now) == now.isoformat()

# Generated at 2022-06-22 21:33:44.525163
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-22 21:33:55.031056
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    o = {
            "a" : "a",
            "b" : ansible.module_utils.basic.AnsibleUnsafe("b"),
            "c" : {
                    "c1" : "c1", 
                    "c2" : ansible.module_utils.basic.AnsibleUnsafe("c2"),
                    "c3" : ["c31", ansible.module_utils.basic.AnsibleUnsafe("c32"), "c33"],
                }
        }
    s = []
    for i in AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o):
        s.append(i)

# Generated at 2022-06-22 21:34:02.753949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: why is 'load' parameter set to False in AnsibleRunner()?
    assert '{"__ansible_unsafe": "unsafe_object"}' == AnsibleJSONEncoder().default(
        AnsibleUnsafe('unsafe_object'))
    assert '"vault_object"' == AnsibleJSONEncoder(vault_to_text=True).default(
        AnsibleVault('vault_object'))
    assert '{"__ansible_vault": "vault_object"}' == AnsibleJSONEncoder().default(
        AnsibleVault('vault_object'))
    assert '{"__ansible_vault": "vault_object"}' == AnsibleJSONEncoder().default(
        AnsibleVaultEncryptedUnicode('vault_object'))

# Generated at 2022-06-22 21:34:13.058797
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Mapping converted to dict
    assert AnsibleJSONEncoder().default({'a': 1}) == {'a': 1}
    class TestDict(dict):
        __ENCRYPTED__ = False
        __UNSAFE__ = False
        _ciphertext = u'asd'
    assert AnsibleJSONEncoder().default(TestDict()) == {u'__ansible_vault': u'asd'}

    # datetime.date converted to ISO 8601 format
    # expected result is not a string but a unicode object for Python 2
    assert AnsibleJSONEncoder().default(datetime.date(2017, 4, 25)) == u'2017-04-25'
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 4, 25, 13, 15, 59, 906445)) == u

# Generated at 2022-06-22 21:34:16.881867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create instance of class AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder()
    # Test method default with a class instance object
    s = ansible_json_encoder.default("foo")

    assert(s == "foo")



# Generated at 2022-06-22 21:34:24.430855
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    test_data = {"a": 1, "b": {"c": "d"}, "e": {"__ansible_unsafe": "test"}, "f": {"__ansible_vault": "test"}}
    result = encoder.default(test_data)
    assert result == {"a": 1, "b": {"c": "d"}, "e": {"__ansible_unsafe": "test"}, "f": {"__ansible_vault": "test"}}

# Generated at 2022-06-22 21:34:31.298403
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_data = '{"name": "default"}'
    data = json.loads(json_data)
    ansible_encoder = AnsibleJSONEncoder()
    ansible_json_data = ansible_encoder.encode(data)
    assert json_data == ansible_json_data

# Generated at 2022-06-22 21:34:38.687312
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Object is not vault
    vault_1 = object
    assert AnsibleJSONEncoder(False, False).default(vault_1) == {}

    # Object is vault
    vault_2 = object
    vault_2.__ENCRYPTED__ = True
    vault_2._ciphertext = '$ANSIBLE_VAULT;1.1;AES256'
    assert AnsibleJSONEncoder(False, False).default(vault_2) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}

    # Object is not vault and is not unsafe
    vault_3 = object
    assert AnsibleJSONEncoder(True, True).default(vault_3) == {}

    # Object is vault and is not unsafe
    vault_4 = object

# Generated at 2022-06-22 21:34:42.293659
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_string = json.dumps({'a': 1}, cls=AnsibleJSONEncoder, sort_keys=True, indent=2)
    assert json_string == '{\n  "a": 1\n}'

# Generated at 2022-06-22 21:34:51.821093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.common.collections import ImmutableDict, MutableMapping
    from ansible.module_utils.six import text_type, binary_type

    class AnsibleUnsafeBytes(AnsibleUnsafe, binary_type):
        pass

    class AnsibleUnsafeText(AnsibleUnsafe, text_type):
        pass

    def assert_default(ansible_object, expected_default):
        j_obj = json.dumps(ansible_object, cls=AnsibleJSONEncoder)
        j_expected = json.dumps(expected_default)
        assert j_

# Generated at 2022-06-22 21:35:03.441877
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils import basic
    import types

    ansible_module = {}
    ansible_module['_ansible_diff'] = False
    ansible_module['_ansible_module'] = types.ModuleType('module', 'string module')
    ansible_module['_ansible_no_log'] = False
    ansible_module['_ansible_python_interpreter'] = '/usr/local/bin/python'
    ansible_module['_ansible_select_fallback_int'] = None
    ansible_module['_ansible_verbosity'] = 2
    ansible_module['_ansible_version'] = '2.7.12'
    ansible_module['_ansible_version_info'] = (2, 7, 12)


# Generated at 2022-06-22 21:35:09.340762
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test default behavior
    assert(AnsibleJSONEncoder())

    # Test specific behaviors via constructor
    assert(AnsibleJSONEncoder(preprocess_unsafe=True))
    assert(AnsibleJSONEncoder(vault_to_text=True))

    # Test unexpected behavior
    try:
        assert(AnsibleJSONEncoder(preprocess_unsafe=True, unexpected='parameter'))
    except TypeError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-22 21:35:19.430520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        import hashlib
    except ImportError:
        # The hashlib library isn't always present on all distros, so check before trying to use it
        hashlib = None

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    class AnsibleVaultSecret(VaultSecret):
        def __str__(self):
            return 'this is the __str__ of the AnsibleVaultSecret object'
    vault_secret = AnsibleVaultSecret('secure_string')

    class AnsibleVaultLib(VaultLib):
        def __init__(self, password, vault_id=None, try_auto_decrypt=False):
            super(AnsibleVaultLib, self).__init__(password, vault_id, try_auto_decrypt)

# Generated at 2022-06-22 21:35:29.122979
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_json import AnsibleUnsafeText
    from ansible.module_utils.parsing.convert_json import AnsibleUnsafeBytes


# Generated at 2022-06-22 21:35:38.141293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    value1 = {'__ansible_unsafe': to_text('example', errors='surrogate_or_strict', nonstring='strict')}
    value2 = {'__ansible_unsafe': 'example'}
    value3 = {'__ansible_unsafe': 'example'.encode('utf-8')}
    value4 = {'__ansible_vault': b'example'}
    value5 = {'__ansible_vault': 'example'}
    value6 = {'__ansible_vault': 'example'.encode('utf-8')}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    assert encoder.default(value1) == '{__ansible_unsafe:example}'

# Generated at 2022-06-22 21:35:49.376169
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.urls import _utf8_unquote
    from ansible.module_utils.six import text_type


# Generated at 2022-06-22 21:35:52.710964
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder
    assert issubclass(ansible_json_encoder.__class__, AnsibleJSONEncoder)


# Generated at 2022-06-22 21:36:02.376757
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-22 21:36:08.968284
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
  class AnsiUnsafeTest(str):
    def __init__(self):
      super(AnsiUnsafeTest, self).__init__("Hello")
      self.__UNSAFE__ = True

  class AnsiSafeTest():
    def __init__(self):
      self.__UNSAFE__ = False
      self.foo = 'bar'

  test_unsafe = AnsiUnsafeTest()
  test_safe = AnsiSafeTest()

  test_complex = [
    test_safe,
    test_unsafe,
    {
      'test_unsafe': test_unsafe
    }
  ]

  assert test_complex == json.loads(json.dumps(test_complex, cls=AnsibleJSONEncoder, sort_keys=True))


# Generated at 2022-06-22 21:36:18.614578
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.ajson import AnsibleUnsafeText
    encoder = AnsibleJSONEncoder()
    unsafe_text_obj = AnsibleUnsafeText("unsafe text")

    json_obj = {
        'str': 'str',
        'bytes': b'bytes',
        'unicode': to_text(b'unicode', errors='surrogate_or_strict', nonstring='strict'),
        'int': 10,
        'float': 10.00,
        'bool': True,
        'none': None,
        'unsafe_text': unsafe_text_obj,
    }


# Generated at 2022-06-22 21:36:24.952338
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    assert b'[{"path": "/etc/hosts", "mode": "0644"}]' == \
        b''.join(AnsibleJSONEncoder().iterencode([{'path': '/etc/hosts', 'mode': '0644'}]))

    assert b'[{"path": "/etc/hosts", "mode": "0644"}, {"__ansible_unsafe": "unsafe ssh key"}]' == \
        b''.join(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode([{'path': '/etc/hosts', 'mode': '0644'}, AnsibleUnsafe('unsafe ssh key')]))

# Generated at 2022-06-22 21:36:28.947091
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.datetime(2019, 1, 1)) == "2019-01-01T00:00:00"
    assert encoder.default(datetime.date(2019, 1, 1)) == "2019-01-01"



# Generated at 2022-06-22 21:36:39.834778
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib

    x = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert x._preprocess_unsafe == False
    assert x._vault_to_text == False

    x = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert x._preprocess_unsafe == True
    assert x._vault_to_text == False

    x = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert x._preprocess_unsafe == True
    assert x._vault_to_text == True

    x = AnsibleJSONEncoder()
    assert x._preprocess_unsafe == False

# Generated at 2022-06-22 21:36:49.904941
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''Unit test for AnsibleJSONEncoder.iterencode()'''
    import ansible.module_utils.common.json_utils
    import ansible.module_utils.basic
    # pylint: disable=too-few-public-methods

    class AnsibleUnsafe(str):
        '''Mock Ansible Unsafe class'''
        __UNSAFE__ = True

    class VaultUnsafe(str):
        '''Mock Vault Unsafe class'''
        __ENCRYPTED__ = True

    class Date:
        '''Mock Date class'''

        def __init__(self, year, month, day):
            self.year = year
            self.month = month
            self.day = day

    class DateTime:
        '''Mock DateTime class'''


# Generated at 2022-06-22 21:36:52.820325
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('test string') == 'test string'
    assert AnsibleJSONEncoder().default(123) == 123
    assert AnsibleJSONEncoder().default(['test string', 123]) == ['test string', 123]



# Generated at 2022-06-22 21:37:01.174188
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys

    from ansible.module_utils.six import text_type

    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.vault import VaultLib

    p = PlayContext()
    p.network_os = 'ios'

    v = VaultLib()

    value = AnsibleJSONEncoder().default(p)
    assert isinstance(value, Mapping)
    assert value['network_os'] == 'ios'

    value = AnsibleJSONEncoder().default(v.encrypt(to_text("Hello World")))
    assert isinstance(value, Mapping)
    assert value['__ansible_vault'] == v._ciphertext

    value = AnsibleJSONEncoder(vault_to_text=True).default(v.encrypt(to_text("Hello World")))

# Generated at 2022-06-22 21:37:04.272261
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Arrange
    # Act
    aje = AnsibleJSONEncoder()

    # Assert
    assert isinstance(aje, json.JSONEncoder)
    assert aje.indent is None



# Generated at 2022-06-22 21:37:14.906740
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    secret_bytes = VaultSecret(bytes=to_bytes(b"1234567890ABC"))
    secret_text = VaultSecret(bytes=to_bytes(u"1234567890ABC"))
    secret_unicode = VaultSecret(bytes=to_bytes(u"1234567890ABC"))
    # Key in this test is a text type (unicode)
    secret_unicode_key = VaultSecret(bytes=to_bytes(u"1234567890ABC"))


# Generated at 2022-06-22 21:37:25.705687
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var as unsafe
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    vault_password = 'ansible'
    vault = VaultLib(vault_password)

    assert encoder.iterencode(unsafe(u'I am unsafe')) == '[{"__ansible_unsafe": "I am unsafe"}]'
    assert encoder.iterencode({"foo": unsafe(u'I am unsafe')}) == '[{"foo": {"__ansible_unsafe": "I am unsafe"}}]'

# Generated at 2022-06-22 21:37:35.765633
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    j = AnsibleJSONEncoder()
    # AnsibleSafeText
    assert j.default(u'This is a test') == u'This is a test'
    assert j.default(u'\u00f1') == u'\u00f1'

    # AnsibleUnsafeText
    assert j.default(u'This is an unsafe test') == {u'__ansible_unsafe': u'This is an unsafe test'}
    assert j.default(u'\u00f1'.encode('utf-8')) == {u'__ansible_unsafe': u'\u00f1'}

    # VaultText
    test_data = u'$ANSIBLE_VAULT;1.2;AES256;foo;bar'

# Generated at 2022-06-22 21:37:46.557357
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-22 21:37:49.899345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    assert aje.encode(False) == 'false'
    assert aje.encode({}) == '{}'



# Generated at 2022-06-22 21:37:58.625560
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_dict = {'ansible_dict': {'1a': '1a'}}
    ansible_dict_copy = ansible_dict.copy()
    ansible_json_str = json.dumps(ansible_dict, cls=AnsibleJSONEncoder)
    ansible_json = json.loads(ansible_json_str)
    if ansible_dict_copy == ansible_json:
        print('AnsibleJSONEncoder constructor passed for ' + str(ansible_json_str))
    else:
        print('AnsibleJSONEncoder constructor failed for ' + str(ansible_json_str))

test_AnsibleJSONEncoder()

# Generated at 2022-06-22 21:38:06.021971
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # the init of AnsibleJSONEncoder should set the default to default_obj and default_kwargs
    obj = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    obj2 = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(obj) == obj2



# Generated at 2022-06-22 21:38:17.512000
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # True and False are kept by default.
    assert json.dumps(True, cls=AnsibleJSONEncoder) == 'true'
    assert json.dumps(False, cls=AnsibleJSONEncoder) == 'false'

    # datetime objects are dumped as strings
    obj = datetime.datetime(2016, 5, 6, 9, 30, 0)
    assert json.dumps(obj, cls=AnsibleJSONEncoder) == '"2016-05-06T09:30:00"'

    # dict
    obj = {'key': 'value'}
    assert json.dumps(obj, cls=AnsibleJSONEncoder) == '{"key": "value"}'

    # dict with a datetime

# Generated at 2022-06-22 21:38:24.185236
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_password = 'shhh'
    vault_enc = VaultLib([(vault_password,)])
    vault_secret = VaultSecret(vault_enc.encrypt('vault_secret'))
    seq = ['something', vault_secret]
    for i in AnsibleJSONEncoder().iterencode(seq):
        assert isinstance(i, str)

# Generated at 2022-06-22 21:38:34.111553
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.json_utils import to_json, from_json

    test_obj = ["123", u"123", VaultLib().encrypt("123"), VaultSecret("123")]
    result = list(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).iterencode(test_obj))

# Generated at 2022-06-22 21:38:42.481261
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default({'test': 'value'}) == {'test': 'value'}
    assert ansible_json_encoder.default([1, 2, 3]) == [1, 2, 3]
    assert ansible_json_encoder.default('string') == 'string'
    assert ansible_json_encoder.default(1) == 1
    assert ansible_json_encoder.default(0.1) == 0.1


# Generated at 2022-06-22 21:38:48.563339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for class AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('abc')) == {'__ansible_unsafe': 'abc'}
    # test for class AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode('content')) == {'__ansible_vault': 'content'}



# Generated at 2022-06-22 21:38:58.230806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.config.base
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    a = AnsibleUnsafe(u'123')
    a.__UNSAFE__ = True

    b = VaultLib('test')
    b.decrypt(a)
    b.__ENCRYPTED__ = True

    c = dict(a=u'123', b=b)
    d = dict(e=u'123')

    ansible_json = AnsibleJSONEncoder()
    assert {'a': u'123', 'b': {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256'}} == json.loads(ansible_json.encode(c))

# Generated at 2022-06-22 21:39:09.943674
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleModule

    json_data = '{"foo":"bar"}'
    json_data_u = '{"foo": "__ansible_unsafe"}'
    module = AnsibleModule(argument_spec={})

    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    json_encoder_u = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_encoder_v = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)

    assert json.loads(module.from_json(json_encoder.encode(json.loads(json_data)))) == json.loads(json_data)

# Generated at 2022-06-22 21:39:17.620363
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder()
    # test json dump vault
    vault = encrypt_vault(b'foo')
    vault_value = ansible_encoder.default(vault)

# Generated at 2022-06-22 21:39:19.958064
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True

# Generated at 2022-06-22 21:39:31.474502
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils import basic
    from ansible.module_utils.six import iteritems
    from ansible.parsing.vault import VaultLib

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert getattr(ansible_json_encoder, '_preprocess_unsafe', None) is True
    assert getattr(ansible_json_encoder, '_vault_to_text', None) is True

    unicode_string = u'\u0066\u006f\u006f'
    unsafe_string = basic.AnsibleUnsafe(unicode_string)
    assert getattr(unsafe_string, '__UNSAFE__', False) is True

    vault_string = u'vault'


# Generated at 2022-06-22 21:39:42.617562
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.builtin.logic
    import ansible.builtin.types
    import ansible.utils.vars
    import ansible.utils.unsafe_proxy
    import ansible.utils.unsafe_eval
    import ansible.vars.hostvars

    # Test for VaultObj instances
    assert AnsibleJSONEncoder().default(ansible.utils.vars.VaultSecret('123')) == {'__ansible_vault': '123'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(ansible.utils.vars.VaultSecret('123')) == '123'

    # Test for AnsibleUnsafeText instances

# Generated at 2022-06-22 21:39:52.935683
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # preprocess_unsafe enabled, unsafe and vault that is converted to text
    test_obj = {'ansible_unsafe': b'vault1', 'ansible_vault': b'vault2'}
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    expected_result = b'{"ansible_unsafe": "vault1", "ansible_vault": "vault2"}'
    actual_result = b''.join(encoder.iterencode(test_obj))
    assert actual_result == expected_result

    # preprocess_unsafe enabled, unsafe that left as dict
    test_obj = b'vault1'
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    expected

# Generated at 2022-06-22 21:40:01.719442
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText,AnsibleUnsafeBytes
    ansible_vault_obj = AnsibleVaultEncryptedUnicode('vault_password')
    unsafe_text_obj = AnsibleUnsafeText('unsafe_text_obj')
    unsafe_bytes_obj = AnsibleUnsafeBytes(b'unsafe_bytes_obj')
    default_encoder = AnsibleJSONEncoder()
    vault_to_text_encoder = AnsibleJSONEncoder(vault_to_text=True)
    unsafe_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-22 21:40:13.602985
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import types

    class Foo:
        def __iter__(self):
            yield 'foo'
            yield 'bar'

    class Bar:
        def __iter__(self):
            yield 'hello'
            yield 'world'

        def __len__(self):
            return 2

    class Test(AnsibleJSONEncoder):
        def __init__(self, *args):
            super(Test, self).__init__(sort_keys=True, indent=4,
                                       separators=(',', ': '), *args)

    t = Test()


# Generated at 2022-06-22 21:40:15.625176
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert isinstance(encoder, AnsibleJSONEncoder)

# Generated at 2022-06-22 21:40:25.956001
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafeText
    import os
    import tempfile

    # Setup vault secret
    vault_password = 'ansible'
    vault_contents = 'something unsafe'
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        f.write(vault_contents)
        vault_secret = f.name
    vault_secrets = [{vault_secret: vault_password}]
    vault = VaultLib(vault_secrets)

    # Unsafe text
    unsafe_text = AnsibleUnsafeText(vault.encrypt(vault_contents))

    # create yaml with unsafe text

# Generated at 2022-06-22 21:40:37.731913
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    d = datetime.datetime(1970, 1, 1, 0, 0, 1)
    assert AnsibleJSONEncoder().encode(d) == u'1970-01-01T00:00:01'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(d) == u'1970-01-01T00:00:01'
    assert AnsibleJSONEncoder(preprocess_unsafe=False).encode(d) == u'1970-01-01T00:00:01'

    # Test
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(dict(a='hello')) == u'{"a": "hello"}'