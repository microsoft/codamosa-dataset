

# Generated at 2022-06-20 15:44:14.642138
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    from ansible.module_utils.common.text.converters import to_bytes

    # Test 1:
    # Test dict contains unsafe items
    # Test dict contains vault items
    # Test dict contains non-encryptable items
    # Check if encoding returns a list of strings with expected content
    s = "example_safe_string"
    u = ansible.parsing.vault.VaultLib.create_unsafe_text(s)
    v = ansible.parsing.vault.VaultLib.encrypt(s, password="vault_password")

# Generated at 2022-06-20 15:44:21.526500
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest

    encoder = AnsibleJSONEncoder()
    unsafe = encoder._encode_unsafe(json)

    # We won't catch anything that gets slipped in
    # with a custom __implements__ check
    assert not hasattr(unsafe, '__implements__')
    # But we will catch it when it is accessed
    with pytest.raises(AttributeError):
        getattr(unsafe, '__implements__')

# Generated at 2022-06-20 15:44:30.632275
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import StringIO

    class MyUnsafeString(str):
        __UNSAFE__ = True

    data = {
        'unicode': u'\u3042',
        'safe_str': 'string',
        'unsafe': MyUnsafeString('unsafe'),
        'unsafe_list': [MyUnsafeString('list_unsafe'), 'list_safe', MyUnsafeString('list_unsafe2')],
        'unsafe_dict': {'dict_unsafe': MyUnsafeString('dict_unsafe')}
    }

    json_data = StringIO()

    json.dump(data, json_data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

    print(json_data.getvalue())

    json_data = StringIO

# Generated at 2022-06-20 15:44:41.889804
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    dt = datetime.datetime(2019, 10, 23, 10, 53, 43, 123456)
    date = datetime.date(2019, 10, 23)

    enc = AnsibleJSONEncoder().encode

    assert enc(None) == json.dumps(None)
    assert enc(False) == json.dumps(False)
    assert enc(True) == json.dumps(True)
    assert enc(1) == json.dumps(1)
    assert enc(1.2) == json.dumps

# Generated at 2022-06-20 15:44:49.039787
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    import base64
    import binascii
    from ansible.parsing.vault import VaultLib

    try:
        import vault
    except ImportError:
        pass

    data = {
        'foo': 'bar',
        'baz': {
            'spam': 'eggs',
        },
        'test': b'YmF6'
    }

    if 'vault' in globals():
        vault_password = 'secret'

        vault_lib = VaultLib(vault_password)
        vault_lib.load()

        vault_str = vault_lib.encrypt(json.dumps(data))

        data['test'] = vault.EncryptedData(vault_password, vault_str)

    else:
        vault_password = None


# Generated at 2022-06-20 15:44:55.221679
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    #def __init__(self, preprocess_unsafe=False, vault_to_text=False, **kwargs):
    a = AnsibleJSONEncoder()
    print("The default value of __preprocess_unsafe is: %s" % a._preprocess_unsafe)
    print("The default value of __vault_to_text is: %s" % a._vault_to_text)
    return



# Generated at 2022-06-20 15:45:04.593032
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import PY3, text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    from collections import namedtuple
    TestObj = namedtuple('TestObj', ['field1', 'field2'])

    # Test PY3
    assert PY3  # test assumption, PY3 is true

    # Test string
    s = 'a string'
    s_encoded = AnsibleJSONEncoder(sort_keys=True, ensure_ascii=True, indent=4).encode(s)
    assert s_encoded == '"a string"'

    # Test int
    i = 1
    i_encoded = AnsibleJSON

# Generated at 2022-06-20 15:45:13.805397
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types

    obj = {
        'foo': [
            5, 'bar', {
                'baz': 1,
                'quz': 'quux',
                'quux': string_types()
            }
        ]
    }

    # Test iterating over the result of iterencode
    iterator = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(obj)
    result = ''.join(item.decode('utf-8') for item in iterator)
    assert result == json.dumps(obj)

    # Test passing an iterator to another function
    result = json.loads(''.join(
        AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(obj)))
    assert result == obj

    # Test passing an iterator to json

# Generated at 2022-06-20 15:45:24.651576
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.formatters import AnsibleUnsafe

    input = AnsibleUnsafe(u'{"__ansible_unsafe": "Hello World"}')

    assert [u'{'] == list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(input))
    assert [u'{'] == list(AnsibleJSONEncoder().iterencode({'__ansible_unsafe': input}))
    assert [u'{'] == list(AnsibleJSONEncoder().iterencode({'__ansible_unsafe': {'__ansible_unsafe': input}}))
    assert [u'['] == list(AnsibleJSONEncoder().iterencode([input]))

# Generated at 2022-06-20 15:45:32.625118
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder()
    data = {'a': 1, 'b': 2}
    assert o.default(data) == data

    data = {'a': AnsibleUnsafe('abc')}
    assert o.default(data) == {'a': {'__ansible_unsafe': u'abc'}}

    data = {'a': AnsibleVaultEncryptedUnicode('abc')}
    assert o.default(data) == {'a': {'__ansible_vault': u'abc'}}
    assert o.default(data, vault_to_text=True) == {'a': u'abc'}

    data = {'a': AnsibleVaultEncryptedUnicode('abc'), 'b': "abc"}

# Generated at 2022-06-20 15:45:48.738127
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import datetime

    d = {
        "list": [
            "string",
            AnsibleUnsafeText("unsafe_1"),
            {
                "dict": {
                    "key": "value",
                    "key2": AnsibleUnsafeText("unsafe_2"),
                },
                "list": [
                    AnsibleUnsafeText("unsafe_3"),
                    "string",
                    {
                        "key": "value",
                        "key2": AnsibleUnsafeText("unsafe_4"),
                    },
                ],
            },
        ],
        "date": datetime.date(1999, 12, 31),
    }


# Generated at 2022-06-20 15:45:57.147003
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert '__ansible_unsafe' in json.loads(AnsibleJSONEncoder().encode('ansible'))
    assert '__ansible_unsafe' not in json.loads(AnsibleJSONEncoder().encode(bytearray('ansible', 'ascii')))
    assert '__ansible_unsafe' not in json.loads(AnsibleJSONEncoder().encode(['ansible']))
    assert '__ansible_unsafe' not in json.loads(AnsibleJSONEncoder().encode({'ansible': 'ansible'}))

# Generated at 2022-06-20 15:46:04.575537
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Sequence

    print('WARNING: Encryption key is not secure')
    vault_obj = VaultLib([], 'ansible', True)
    # Encrypt a regular string
    ciphertext = to_text(vault_obj.encrypt('string-with-no-unsafe'), errors='surrogate_or_strict')
    vault = {'__ansible_vault': ciphertext}
    assert json.dumps(vault, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "%s"}' % ciphertext
    # Encrypt an AnsibleUnsafeString
    from ansible.module_utils.basic import AnsibleUnsafeText

# Generated at 2022-06-20 15:46:14.222237
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class TestUnsafe(str):
        pass

    test_unsafe = TestUnsafe(u'žluťoučký kůň úpěl ďábelské ódy')
    test_unsafe.__UNSAFE__ = True
    print(type(test_unsafe))

    test_dict_unsafe = {'Password': test_unsafe}

    print(json.dumps(test_unsafe, cls=AnsibleJSONEncoder, indent=2, sort_keys=True))
    print(json.dumps(test_dict_unsafe, cls=AnsibleJSONEncoder, indent=2, sort_keys=True))

# Generated at 2022-06-20 15:46:25.763986
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    def test_processing(o, should_process):
        is_preprocessed = _preprocess_unsafe_encode(o)
        is_preprocessed = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o)
        is_not_preprocessed = AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(o)
        if should_process:
            assert is_preprocessed != is_not_preprocessed
        else:
            assert is_preprocessed == is_not_preprocessed

    # Primitive type: int
    test_processing(1, False)
    # Primitive type: str
    test_processing(u'abc', False)
    # Primitive type: bytes
    test_processing(b'abc', False)
    # Primitive type: bool

# Generated at 2022-06-20 15:46:35.873010
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    # A dict with string value, boolean value and an instance of `AnsibleUnsafe`
    payload = {'k1': 'v1', 'k2': True, 'k3': AnsibleUnsafe('abc')}

    # Test the dict with default value
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.iterencode(payload) == b'{"k1": "v1", "k2": true, "k3": "abc"}'

    # Test the dict with custom preprocessing
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-20 15:46:47.040823
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    import sys

    stdin_mock = text_type('{"a": "hi", "b": {"c": "bye", "unsafe": "__replace__", "encrypted": "__encrypted__"}, "d": ["hi", "bye"], "e": ["__replace__", "bye"]}')
    sys.stdin = stdin_mock

# Generated at 2022-06-20 15:46:54.078883
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Create an instance of AnsibleJSONEncoder
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    # Create an instance of AnsibleUnsafe
    unsafe = to_text('foo')
    unsafe.__UNSAFE__ = True
    # Encode the AnsibleUnsafe object
    encode_json = ansible_encoder.iterencode(unsafe).next().decode('utf-8')
    # Expect the output to be a escaped string
    assert encode_json == u'{"__ansible_unsafe": "foo"}'
    # Create a dictionary and a list
    test_dict = {'a': unsafe}
    test_list = [unsafe]
    # Encode the dictionary and the list

# Generated at 2022-06-20 15:47:03.155348
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with AnsibleUnsafe
    json_dict = {
        '__ansible_unsafe': '{#ANSIBLE_VAULT;...}',
    }
    assert json_dict == AnsibleJSONEncoder().default(AnsibleUnsafe('{#ANSIBLE_VAULT;...}'))

    # Test with AnsibleUnsafeText
    json_dict = {
        '__ansible_unsafe': '{#ANSIBLE_VAULT;...}',
    }
    assert json_dict == AnsibleJSONEncoder().default(AnsibleUnsafeText('{#ANSIBLE_VAULT;...}'))

    # Test with AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 15:47:15.407153
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test for method iterencode of class AnsibleJSONEncoder"""
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.compat import text_type
    vault_passwd = '$ANSIBLE_VAULT;1.1;AES256'
    encrypted_string = '[vault-encrypted-string]'

    # encoded_sample1 has vault-encrypted-string and ansible_unsafe object

# Generated at 2022-06-20 15:47:26.728191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # hostvars and other objects
    class A():
        pass

    a = A()
    a.f = A()
    a.f.g = True
    a.f.h = False

    assert json.loads(json.dumps(a, cls=AnsibleJSONEncoder)) == {'f': {'g': True, 'h': False}}

    # vault object
    b = json.loads(json.dumps(a, cls=AnsibleJSONEncoder, vault_to_text=True))
    assert b == {'f': {'g': True, 'h': False}}

# Generated at 2022-06-20 15:47:39.372973
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    jenc = AnsibleJSONEncoder()
    itr = jenc.iterencode(to_text('test_string'))
    assert itr.__next__() == to_bytes('"test_string"')
    o = {'__ansible_unsafe': to_text('this is unsafe')}
    itr = jenc.iterencode(o)
    result = to_text(itr.__next__())
    assert result.startswith('"{\\"__ansible_unsafe\\": \\"this is unsafe\\"}"')

# Generated at 2022-06-20 15:47:43.515690
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    #Test the constructor of the class AnsibleJSONEncoder
    inst = AnsibleJSONEncoder(preprocess_unsafe=False,vault_to_text=False)
    assert inst._preprocess_unsafe==False
    assert inst._vault_to_text==False


# Generated at 2022-06-20 15:47:52.976363
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    Ensuring that iterencode of AnsibleJSONEncoder class works as expected
    """

    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-20 15:48:05.030704
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, encrypt_text

    vault = VaultLib([C.DEFAULT_VAULT_IDENTITY_LIST])
    unsafe = AnsibleUnsafeText(encrypt_text('test', vault))
    vaulted_unsafe = AnsibleUnsafeText(encrypt_text('test2', vault))

    encoder = AnsibleJSONEncoder()
    result = encoder.default(unsafe)
    assert result == {'__ansible_unsafe': 'test'}
    result = encoder.default(vaulted_unsafe)

# Generated at 2022-06-20 15:48:08.762790
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # if default() is never called, it means that everything is encoded correctly.
    assert json.dumps(dict(key="value"), cls=AnsibleJSONEncoder) == '{"key": "value"}'


# Generated at 2022-06-20 15:48:19.434436
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder_preprocess_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)

    assert ansible_json_encoder.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert ansible_json_encoder_preprocess_unsafe.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert ansible_json_encoder_vault_to_text.default({'foo': 'bar'}) == {'foo': 'bar'}

    assert ansible_json_encoder.default({'foo': '{{bar}}'})

# Generated at 2022-06-20 15:48:28.862174
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    ansible_unsafe = AnsibleUnsafe("test")
    assert(ansible_unsafe.__UNSAFE__)
    assert(not hasattr(ansible_unsafe, '__ENCRYPTED__'))
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert(json_encoder._preprocess_unsafe == False)
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert(json_encoder._preprocess_unsafe == True)
    json_encoder = AnsibleJSONEncoder()
    assert(json_encoder._preprocess_unsafe == False)
    for unsafe_flag in [False, True]:
        json_encoder = Ans

# Generated at 2022-06-20 15:48:35.411808
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('salt')
    v._load_decryption_keys('salt')
    encoded_vault = {'__ansible_vault': v.encrypt('test')}
    if '__ansible_vault' not in json.dumps(encoded_vault, cls=AnsibleJSONEncoder, preprocess_unsafe=False):
        raise AssertionError('AnsibleJSONEncoder did not handle VaultLib correctly')

# Generated at 2022-06-20 15:48:47.333000
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Encoding of string (result of type 'str' in Python 2, 'unicode' in Python 3)
    assert("\"string\"" == AnsibleJSONEncoder().encode("string"))
    # Encoding of json-object (result of type 'dict' in Python 2/3)
    assert("{}" == AnsibleJSONEncoder().encode({}))
    # Encoding of ansible-encrypt-object (result of type 'str' in Python 2, 'unicode' in Python 3)
    assert("{\"__ansible_vault\": \"encrypted string\"}" == AnsibleJSONEncoder().encode("THIS STRING IS ENCRYPTED"))
    # Encoding of ansible-unsafe-object (result of type 'str' in Python 2, 'unicode' in Python 3)

# Generated at 2022-06-20 15:49:02.031922
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.5) == 1.5
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default('foo') == 'foo'
    assert AnsibleJSONEncoder().default(u'foo') == 'foo'
    assert AnsibleJSONEncoder().default(u'中文') == u'中文'
    assert AnsibleJSONEncoder().default(u'中文', ensure_ascii=False) == u'中文'
    assert AnsibleJSONEncoder().default(u'中文', ensure_ascii=True) == u'\u4e2d\u6587'

    # test class

# Generated at 2022-06-20 15:49:13.170050
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type, PY3
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText

    with open("test_AnsibleJSONEncoder_iterencode.data") as f:
        testdata = json.load(f)

    # Note, the reference values in the data file are Python2.7, so they need to be byte strings
    # Python3 will do the conversion from text to byte string internally but if you manually
    # instantiate a byte string (b'...') it will be unicode, so we can

# Generated at 2022-06-20 15:49:20.232038
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create a AnsibleJSONEncoder object
    encoder = AnsibleJSONEncoder()
    # Ensure that object is a AnsibleJSONEncoder object
    assert isinstance(encoder, AnsibleJSONEncoder)

    # Create a AnsibleJSONEncoder object
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    # Ensure that object is a AnsibleJSONEncoder object
    assert isinstance(encoder, AnsibleJSONEncoder)

    # Create a AnsibleJSONEncoder object
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    # Ensure that object is a AnsibleJSONEncoder object
    assert isinstance(encoder, AnsibleJSONEncoder)


# Generated at 2022-06-20 15:49:31.240539
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

    dummy_vault_password = 'ansible'
    vault_object = VaultLib(password=dummy_vault_password)
    vault_text = 'test1'
    vault_cypher = vault_object.encrypt(vault_text)

    vault_object_unsafe = VaultLib(password=dummy_vault_password)
    vault_text_unsafe = 'test2'
    vault_cypher_unsafe = vault_object_unsafe.encrypt(vault_text_unsafe)

    # Create a dict and list with non-string keys and values
    non_string_dict = {1:2, 3.0:[4.0,'test']}

    # Add vault text as dict key


# Generated at 2022-06-20 15:49:33.296423
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    module = AnsibleJSONEncoder()
    assert module


# Generated at 2022-06-20 15:49:44.543800
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_class = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultLib
    test_vault = VaultLib('password')
    test_object = test_vault.encrypt('test_string')
    test_object2 = test_vault.encrypt(json.dumps(['test1', 'test2', 'test3']))
    test_object3 = test_vault.encrypt(json.dumps(['test1', 'test2', 'test3']))

    assert test_class.default(test_object) == {"__ansible_vault": "test_string"}
    assert test_class.default(test_object2) == {"__ansible_vault": "[\"test1\", \"test2\", \"test3\"]"}

# Generated at 2022-06-20 15:49:54.753744
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    # This test is to ensure that iterencode works as expected so that code which
    # was not using preprocess_unsafe=True would not be broken with it, and vice versa.
    # TODO: Move to a unit test file once #60529 is resolved
    # Setup
    #
    # Ensure the BOOLEANS_TRUE object is a Mapping so that it is processed by the loop below:
    if not isinstance(BOOLEANS_TRUE, Mapping):
        BOOLEANS_TRUE = {v: v for v in BOOLEANS_TRUE}
    # Construct a data structure for processing

# Generated at 2022-06-20 15:50:05.313466
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # expected_output: value of the code
    expected_output1 = 'AnsibleJSONEncoder'
    expected_output2 = '{"__ansible_vault": "gAAAAABeVQdsQH-FnDnKz9E1AJHxzZnBoJZv_GjwWRIaSf-Gt-yRtT9Yrgf_zJ3Z4s4ZD16QQ2wM8zrENl1rNo3qCdJ-zQX_CZgnDjxFxofFT8nhNe1E=\\n"}'

# Generated at 2022-06-20 15:50:14.272939
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Set up a sample object to encode
    value = {'secret': 'password'}
    # Encode object with AnsibleJSONEncoder, then decode back to python format to compare results
    value_encoded = to_text(json.dumps(value, cls=AnsibleJSONEncoder))
    value_decoded = json.loads(value_encoded)
    assert value == value_decoded
    # Set up second sample object, containing the AnsibleUnsafe class
    value = [{'list_of_strings': ['test1', 'test2']}, 'ansible', {'unsafe': AnsibleUnsafe('my_password')}]
    # Encode object with AnsibleJSONEncoder, then decode back to python format to compare results

# Generated at 2022-06-20 15:50:22.287957
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) is None
    assert encoder.default(True) is True
    assert encoder.default(False) is False

    # dict
    assert encoder.default({}) == {}
    assert encoder.default({'a': 'b'}) == {'a': 'b'}

    # date
    date_test_1 = datetime.date(year=2018, month=4, day=4)
    date_test_2 = datetime.datetime(year=2018, month=4, day=4)
    assert encoder.default(date_test_1) == date_test_1.isoformat()
    assert encoder.default(date_test_2) == date_test_2.isoformat()

    # vault
    vault_test_1

# Generated at 2022-06-20 15:50:30.823552
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder

# Generated at 2022-06-20 15:50:42.793155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    assert AnsibleJSONEncoder().default("Hello") == "Hello"
    assert AnsibleJSONEncoder().default("Hello") == "Hello"
    assert AnsibleJSONEncoder(True).default("Hello") == "Hello"
    assert AnsibleJSONEncoder().default(AnsibleUnsafeText("Hello")) == {'__ansible_unsafe': u'Hello'}
    assert AnsibleJSONEncoder(True).default(AnsibleUnsafeText("Hello")) == {'__ansible_unsafe': u'Hello'}

# Generated at 2022-06-20 15:50:44.740888
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    custom_encoder = AnsibleJSONEncoder()
    assert custom_encoder



# Generated at 2022-06-20 15:50:48.598826
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert (issubclass(AnsibleJSONEncoder, json.JSONEncoder))
    assert (hasattr(AnsibleJSONEncoder, 'iterencode'))
    assert (hasattr(AnsibleJSONEncoder, 'default'))

# Generated at 2022-06-20 15:50:58.280116
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    assert not hasattr(encoder, '_preprocess_unsafe')
    assert not hasattr(encoder, '_vault_to_text')

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe
    assert encoder._vault_to_text

    # test default encoder
    assert encoder.default(object()) == '<object object at 0x1026c2400>'
    assert encoder.default(Mapping()) == {}
    assert enc

# Generated at 2022-06-20 15:51:10.722953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib

    class AnsibleUnsafe(text_type):
        __UNSAFE__ = True

    class AnsibleVault(text_type):
        __ENCRYPTED__ = True

    class OtherObj(object):
        def __init__(self):
            self.key = 'value'

    class MappingObj(dict):
        def __init__(self):
            super(MappingObj, self).__init__()
            self['key'] = 'value'

    plain_text = 'hello world'
    encoded_text = 'aGVsbG8gd29ybGQ='
    encrypted_text = '$ANSIBLE_VAULT;1.1;AES256\n' + encoded_text

# Generated at 2022-06-20 15:51:21.265256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = {}

    # Testing __ENCRYPTED__ attribute
    obj = u'hello'
    obj.__ENCRYPTED__ = True
    result['__ansible_vault'] = u'hello'
    assert AnsibleJSONEncoder().default(obj) == result

    # Testing __UNSAFE__ attribute
    obj.__UNSAFE__ = True
    result['__ansible_unsafe'] = u'hello'
    assert AnsibleJSONEncoder().default(obj) == result

    # Testing date object
    obj = datetime.datetime.now()
    result = obj.isoformat()
    assert AnsibleJSONEncoder().default(obj) == result

# Generated at 2022-06-20 15:51:23.161188
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.date(2020, 12, 10)) == "2020-12-10"

# Generated at 2022-06-20 15:51:24.522185
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder



# Generated at 2022-06-20 15:51:30.321178
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a_json_encoder = AnsibleJSONEncoder()
    assert a_json_encoder._preprocess_unsafe == False
    assert a_json_encoder._vault_to_text == False

    a_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert a_json_encoder._preprocess_unsafe == True
    assert a_json_encoder._vault_to_text == True

# Generated at 2022-06-20 15:51:39.896832
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert isinstance(json_encoder, json.JSONEncoder)


# Generated at 2022-06-20 15:51:47.181274
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
        import re
        from ansible.module_utils.common._collections_compat import Mapping

        test_str = "abcd"
        test_str_encoded = to_text('"abcd"')
        a = AnsibleJSONEncoder()

        s = a.iterencode(test_str)
        assert(re.match(test_str_encoded + '$', next(s)))
        try:
                next(s)
                assert(False)
        except StopIteration:
                pass

        test_dict = dict(a=1, b='two')
        test_dict_encoded = to_text('{"a": 1, "b": "two"}')
        d = a.iterencode(test_dict)

# Generated at 2022-06-20 15:51:55.896074
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import uuid
    from ansible.module_utils.common.collections import AnsibleSequence

    # Test with preprocess_unsafe
    x = uuid.uuid4()
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    print(ansible_json_encoder.encode(x))

    # test with unsafe sequence
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    ansible_sequence = AnsibleSequence([x, x, x])
    print(ansible_json_encoder.encode(ansible_sequence))

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:52:07.019034
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # test AnsibleUnsafeText
    unsafe_text = AnsibleUnsafeText('test')
    json_unsafe_text = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_text)
    assert '"__ansible_unsafe":"test"' in to_text(json_unsafe_text)

    # test other types
    data = {'a': 'aa', 'b': 'bb', 'c': 'cc'}
    json_data = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data)
    assert '{' in to_text(json_data)
    assert '"a": "aa"' in to_text(json_data)

# Generated at 2022-06-20 15:52:19.313743
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""
    import json
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode

    class TestAnsibleJSONEncoder(AnsibleJSONEncoder):
        pass

    class AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        pass

    class NestedObject(dict):
        def __init__(self):
            self['key1'] = 'value1'
            self['key2'] = 'value2'

    class TestObject(object):
        def __init__(self):
            self.name = 'Ansible'

    json_encoder = TestAnsibleJSONEncoder()
    # test for datetime

# Generated at 2022-06-20 15:52:30.156912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for single variable
    variable = AnsibleUnsafe("TESTING1")
    ansible_encoder = AnsibleJSONEncoder()
    json_variable = ansible_encoder.default(variable)
    assert json_variable == {'__ansible_unsafe': 'TESTING1'}

    # Test for list of variables
    variable_list = [AnsibleUnsafe('TESTING1'), AnsibleUnsafe('TEST2'), "TEST3"]
    json_variable_list = list(ansible_encoder.iterencode(variable_list))
    assert json_variable_list == [
            '["TESTING1", ',
            '{"__ansible_unsafe": "TEST2"}, ',
            '"TEST3"]'
        ]

    # Test for dictionary of variables
    variable_dict

# Generated at 2022-06-20 15:52:32.117102
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert isinstance(test_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-20 15:52:43.609638
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    assert json.dumps(
        {'a': AnsibleUnsafe('unsafe')},
        cls=AnsibleJSONEncoder,
        preprocess_unsafe=False,
        vault_to_text=False,
    ) == '{"a": {"__ansible_unsafe": "unsafe"}}'

    assert json.dumps(
        {'a': AnsibleVault('vault:')},
        cls=AnsibleJSONEncoder,
        preprocess_unsafe=False,
        vault_to_text=False,
    ) == '{"a": {"__ansible_vault": "vault:"}}'


# Generated at 2022-06-20 15:52:54.821130
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_unsafe = {'__ansible_unsafe': 'some string'}
    ansible_encrypted = {'__ansible_vault': 'encrypted string'}
    obj = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert obj.encode(ansible_unsafe) == u'{"__ansible_unsafe": "some string"}'
    assert obj._preprocess_unsafe == False
    assert obj.encode(ansible_encrypted) == u'{"__ansible_vault": "encrypted string"}'
    obj = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert obj._preprocess_unsafe == True



# Generated at 2022-06-20 15:53:07.229185
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault_to_text == True
    assert AnsibleJSONEncoder(vault_to_text=True)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True

# Generated at 2022-06-20 15:53:34.217244
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    def _check_encoding(o):
        if is_vault(o):
            return {'__ansible_vault': text_type(o)}
        elif is_sequence(o):
            return [_check_encoding(v) for v in o]
        elif isinstance(o, Mapping):
            return dict((k, _check_encoing(v)) for k, v in o.items())
        return o

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    vault = VaultLib([{'password':''}])

    o = virtual(vault_encrypt(vault, 'test'))

# Generated at 2022-06-20 15:53:43.853707
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import crypt
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([], None)
    secret = 'foo'
    encrypted_secret = vault.encrypt(secret)

    test_unsafe_string = AnsibleUnsafe('$ANSIBLE_VAULT;0.1;AES256;user\n' + encrypted_secret)
    test_unsafe_dict = AnsibleUnsafe({'hello': 'world'})

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert '"$ANSIBLE_VAULT;0.1;AES256;user\n' in encoder.encode(test_unsafe_string)
    assert '{"hello": "world"}' in encoder.encode(test_unsafe_dict)

    encoder = AnsibleJSONEncoder

# Generated at 2022-06-20 15:53:54.399524
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # test for encrypted vaults
    assert encoder.default(dict(__ENCRYPTED__=True, __CIPHERTEXT__=b'AES256:123:456:sometest')) == {'__ansible_vault': 'AES256:123:456:sometest'}

    # test for unsafe objects
    assert encoder.default(dict(__UNSAFE__=True, __BYTES__=b'foo')) == {'__ansible_unsafe': 'foo'}

    # test hosts in json form
    assert encoder.default(dict(name='test', group='test', port=123)) == {'name': 'test', 'group': 'test', 'port': 123}

    # test dates in json form

# Generated at 2022-06-20 15:53:58.155770
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys

# Generated at 2022-06-20 15:54:05.490746
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    test_value = {
        'string_type': {'string_key': 'string_value'},
        'unsafe_type': {'unsafe_key': AnsibleUnsafe('unsafe_value')},
        'mixed_type': [
            AnsibleUnsafe('unsafe_value'),
            'string_value',
        ],
    }
    test_result = dict()
    test_result['string_type'] = {'string_key': 'string_value'}
    test_result['unsafe_type'] = {'unsafe_key': {'__ansible_unsafe': to_text(AnsibleUnsafe('unsafe_value'))}}