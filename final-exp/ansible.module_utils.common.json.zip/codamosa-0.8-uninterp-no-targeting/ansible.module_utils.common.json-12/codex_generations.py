

# Generated at 2022-06-20 15:44:11.706561
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # noinspection PyUnresolvedReferences
    import ansible.utils.unsafe_proxy


# Generated at 2022-06-20 15:44:21.374961
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    value = '$ANSIBLE_VAULT;1.1;AES256;default\n3637643231393664313264396265636234313661356131633137396264366434656531346662396130\n3730333332306562616237623437363563323763623738666433313661333537336538343864626639\n6565666666306366\n'
    vaultobj = AnsibleJSONEncoder()
    jsondata = vaultobj.default(value)
    assert len(jsondata) == 1
    assert '__ansible_vault' in jsondata

# Generated at 2022-06-20 15:44:27.011943
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe is False
    assert AnsibleJSONEncoder()._vault_to_text is False
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe is True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault_to_text is True

# Generated at 2022-06-20 15:44:39.045515
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    def _check_AnsibleJSONEncoder(preprocess_unsafe, vault_to_text):
        assert json.dumps(u'bob', cls=AnsibleJSONEncoder, preprocess_unsafe=preprocess_unsafe,
                          vault_to_text=vault_to_text) == u'"bob"'

    _check_AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    _check_AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    _check_AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    _check_AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-20 15:44:47.402839
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    def x_iterencode(obj, *vargs, **kwargs):
        """Encodes an object by repeatedly calling an encoder."""
        if _is_vault(obj):
            return iter(['"{}"'.format(to_text(obj._ciphertext, errors='surrogate_or_strict', nonstring='strict'))])
        return iter(['"{}"'.format(to_text(obj, errors='surrogate_or_strict', nonstring='strict'))])

    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback

# Generated at 2022-06-20 15:44:59.955896
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test the case where self._preprocess_unsafe is true
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    o = {'a': [1, 2, 3], 'b': 'ansible_unsafe_value'}
    s = '[{"b": "ansible_unsafe_value", "a": [1, 2, 3]}]'
    assert json.dumps(o, cls=AnsibleJSONEncoder) == s

    # Test the case where self._preprocess_unsafe is false
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    o = {'a': [1, 2, 3], 'b': 'ansible_unsafe_value'}

# Generated at 2022-06-20 15:45:10.060141
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe


# Generated at 2022-06-20 15:45:11.558709
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)



# Generated at 2022-06-20 15:45:22.951372
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    kwargs = {'separators': (',', ':'), 'sort_keys': True}

    # Default arguments
    encoder = AnsibleJSONEncoder()
    assert encoder.encode(kwargs) == '{"sort_keys":true,"separators":[",",":"]}'
    assert encoder.encode(kwargs, **kwargs) == '{"separators":[",",":"],"sort_keys":true}'
    assert encoder.iterencode(kwargs) == '{"sort_keys":true,"separators":[",",":"]}'
    assert encoder.iterencode(kwargs, **kwargs) == '{"separators":[",",":"],"sort_keys":true}'

    # preprocess_unsafe = True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-20 15:45:25.491846
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert(encoder._preprocess_unsafe == False)
    assert(encoder._vault_to_text == False)


# Generated at 2022-06-20 15:45:35.726096
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence


# Generated at 2022-06-20 15:45:48.189093
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils.six import string_types
    import ansible.module_utils.six as six

    # Make sure we remain compatible with both Python 2 and Python 3
    if six.PY3:
        str_types = string_types
    else:
        str_types = (str, unicode)
    # Create an instance of ansible unsafe
    unsafe = vault.VaultLib().new_unsafe_text("Too-bad")
    # Create an instance of ansible vault
    dummy_vault_password = "dummy_password"
    ciphertext = vault.VaultLib().encrypt("hello", dummy_vault_password)
    vault_instance = vault.VaultLib().decrypt(ciphertext, dummy_vault_password)
    # Create

# Generated at 2022-06-20 15:45:58.814361
# Unit test for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:46:10.747008
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars import AnsibleVaultEncryptedUnicode
    import datetime
    # Set the date of time
    dt = datetime.datetime(year=2017, month=1, day=1, hour=1,
                           minute=1, second=1, microsecond=1)

    class sample():
        def __init__(self):
            self.a = 'b'
            self.c = 1
            self.dt = dt

    ae = AnsibleJSONEncoder()
    assert ae.default(AnsibleVaultEncryptedUnicode('bar')) == {'__ansible_vault': u'bar'}
    assert ae.default(dt) == '2017-01-01T01:01:01.000001'

# Generated at 2022-06-20 15:46:18.220497
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    my_string = "default"
    my_list = ["a", "b", "c"]
    my_dict = {1: "one", 2: "two", 3: "three"}
    my_obj = AnsibleJSONEncoder()
    my_result = AnsibleJSONEncoder().encode(my_string)
    assert my_result == '"default"'
    my_result = AnsibleJSONEncoder().encode(my_list)
    assert my_result == '["a", "b", "c"]'
    my_response = AnsibleJSONEncoder().encode(my_dict)
    assert my_response == '{"1": "one", "2": "two", "3": "three"}'


# Generated at 2022-06-20 15:46:27.535149
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.encoders import to_bytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    # Prepare data for test
    test_data = '{"json_key": {"foo": "bar", "ansible_unsafe": "123456"}, "ansible_unsafe_list": ["123456", {"ansible_unsafe": "123456"}, ["123456", {"ansible_unsafe": "123456"}]]}'
    unsafe_value = AnsibleUnsafe('123456')

# Generated at 2022-06-20 15:46:36.264784
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import textwrap
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    # Custom made class that inherited from AnsibleUnsafe
    class AnsibleUnsafeString(str):
        __UNSAFE__ = True
    # Create a dict that includes a list of AnsibleUnsafeStrings
    test_list = list()
    for i in range(5):
        new_str = AnsibleUnsafeString('AnsibleUnsafeString' + str(i))
        test_list.append(new_str)
    # Create a dict that includes a AnsibleUnsafeString
    test_unsafe_str = AnsibleUnsafeString('AnsibleUnsafeString')
    test_dict = dict()
    test_dict['list']

# Generated at 2022-06-20 15:46:42.277268
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_object = {"key1": "value1", "key2": "value2", "key3": "value3"}
    result_output = '{"key1": "value1", "key2": "value2", "key3": "value3"}'
    assert json.dumps(test_object, cls=AnsibleJSONEncoder) == result_output


# Generated at 2022-06-20 15:46:49.351541
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    A = None
    my_object = {'a': A,
                 'b': 'sample_string',
                 'c': datetime.datetime.now(),
                 'd': [1, 2, 3],
                 'e': ['a', 'b', 'c'],
                 'f': ['d', 'e', 'f'],
                 'g': 'sample_string'}
    ansible_json_encoder = AnsibleJSONEncoder()
    json_encoder = json.JSONEncoder()
    assert json.loads(ansible_json_encoder.encode(my_object)) == json.loads(json_encoder.encode(my_object))


# Generated at 2022-06-20 15:46:55.649882
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    if not hasattr(json.encoder, 'iterencode'):
        return

    def _test_AnsibleJSONEncoder_iterencode(o, expected, **kwargs):
        aje = AnsibleJSONEncoder(**kwargs)
        actual = list(it.value for it in aje.iterencode(o))
        assert actual == expected

    from ansible.parsing.vault import VaultLib, VaultSecret

# Generated at 2022-06-20 15:47:05.165692
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # The AnsibleJSONEncoder base class is json.JSONEncoder

    # Test: Instantiate the AnsibleJSONEncoder class with keyword arguments and then re-instantiate it with keyword arguments
    d = {}
    encoder_kwargs = {}
    encoder = AnsibleJSONEncoder(**encoder_kwargs)
    assert isinstance(encoder, json.JSONEncoder)
    encoder_kwargs = {'indent': 4, 'sort_keys': True}
    encoder = AnsibleJSONEncoder(**encoder_kwargs)
    assert isinstance(encoder, json.JSONEncoder)
    encoder_kwargs = {'separators': (',', ':')}
    encoder = AnsibleJSONEncoder(**encoder_kwargs)
    assert isinstance(encoder, json.JSONEncoder)

# Generated at 2022-06-20 15:47:07.777005
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = {}
    assert AnsibleJSONEncoder().default(result) == {}

# Generated at 2022-06-20 15:47:19.137062
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Unit test for method iterencode of class AnsibleJSONEncoder"""

    import six

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    data = {'hello': 'world'}
    result = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).iterencode(data)

    # check the result of type
    assert isinstance(result, six.Iterator)

    contents = b"".join(result)

    assert contents == b'{"hello": "world"}'

    data = {'hello': AnsibleUnsafeText('world')}
    result = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).iterencode(data)

    # check the result of type

# Generated at 2022-06-20 15:47:22.934645
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()

    assert encoder.default(VaultLib('test')) == {'__ansible_vault': 'test'}

# Generated at 2022-06-20 15:47:35.037736
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText, AnsibleVaultEncryptedUnicode
    from ansible.module_utils.urls import urllib_quote
    # When encoding an AnsibleUnsafeText instance, an AnsibleJSONEncoder instance
    # should encode the instance to a dict.
    actual = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode('£')
    expected = ''.join(('{"__ansible_unsafe": "', urllib_quote(u'£'), '"}'))
    assert actual == expected
    # When encoding an AnsibleVaultEncryptedUnicode instance, an AnsibleJSONEncoder instance
    # should encode the instance to a dict.

# Generated at 2022-06-20 15:47:39.146104
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = "test"
    print("testing with default values for constructor, object: ", data)
    encoder = AnsibleJSONEncoder()
    encoded_data = encoder.default(data)
    assert(encoded_data == data)

# Generated at 2022-06-20 15:47:47.824355
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Unit test for method iterencode of class AnsibleJSONEncoder

    Covers:
    - In case of preprocess_unsafe, iterencode of AnsibleJSONEncoder should return string '{"test": ["a", "b"]}'
    and not '["test", ["a", "b"]]'
    """
    input_dict = {'test': ['a', 'b']}
    json_ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    result = json_ansible_encoder.iterencode(input_dict)
    assert '{"test": ["a", "b"]}' in result
    assert '"[\\"test\\"",""\\"[\\\\\\"a\\\\\\",\\\\\\"b\\\\\\"]\\""]"' not in result

# Generated at 2022-06-20 15:47:56.762596
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Tests the behavior of AnsibleJSONEncoder.iterencode() """
    import sys
    import json

    try:
        from ansible.utils.unsafe_proxy import AnsibleUnsafeText
        CAN_IMPORT_AnsibleUnsafeText = True
    except ImportError:
        CAN_IMPORT_AnsibleUnsafeText = False

    # Test with a sequence containing a AnsibleUnsafeText
    test_sequence = ["bla", AnsibleUnsafeText("bla")]
    result = json.dumps(test_sequence, cls=AnsibleJSONEncoder)
    assert result == '[ "bla", { "__ansible_unsafe": "bla" } ]'

    # Test with a dict containing a AnsibleUnsafeText

# Generated at 2022-06-20 15:48:05.097840
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.ansible.community.plugins.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from datetime import date

    vault = VaultLib([(VaultSecret('secret', 'password'),)])
    ansible_unsafe_object = AnsibleUnsafeText(to_bytes(u'\u2713', errors='surrogate_or_strict'))

# Generated at 2022-06-20 15:48:16.423267
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafeText(b'unsafe text')) == {'__ansible_unsafe': 'unsafe text'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafeText(b'unsafe text', vault_text=b'encoded unsafe')) == {'__ansible_unsafe': 'encoded unsafe'}

# Generated at 2022-06-20 15:48:22.952838
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert(ansible_json_encoder.decode('"Hello World"') == 'Hello World')
    return

# Generated at 2022-06-20 15:48:25.226062
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False,indent=4) == json.JSONEncoder(preprocess_unsafe=False,indent=4)

# Generated at 2022-06-20 15:48:33.370877
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBoolean
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeDict
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeInteger
    from ansible_collections.my.my_module.plugins.module_utils.enc.encrypt import Encrypted


# Generated at 2022-06-20 15:48:44.924645
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import wrap_var

    vault = VaultLib([])

# Generated at 2022-06-20 15:48:48.356279
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'plaintext')) == 'plaintext'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'unsafe: {{ }}')) == 'unsafe: {{ }}'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'unsafe: {{ }}}}}}}}}}}}}}}}}}}')) == 'unsafe: {{ }}}}}}}}}}}}}}}}}}}'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe(b'plaintext')) == 'plaintext'

# Generated at 2022-06-20 15:48:59.790526
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_obj = {'test_text': 'This is a test string', 'test_list': [1, 2, 3], 'test_dict': {'key1': 'value1', 'key2': 'value2'}}
    json_ansible = AnsibleJSONEncoder()
    assert json_ansible.default(test_obj) == test_obj, 'default json encoder is not working'
    test_obj_json = json_ansible.encode(test_obj)
    assert json.loads(test_obj_json) == test_obj, 'default json object encoder is not working'
    test_obj_json_iter = json_ansible.iterencode(test_obj)

# Generated at 2022-06-20 15:49:09.406720
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils.six import binary_type, text_type

    if not hasattr(vault, 'VaultLib') or not hasattr(vault, 'AnsibleUnsafeText'):
        raise ImportError("ansible is too old")

    v = vault.VaultLib([])
    v.decrypt(v.encrypt("secret"))

    unsafe_text = vault.AnsibleUnsafeText("hello\nworld\n")
    unsafe_bytes = vault.AnsibleUnsafeBytes("hello\nworld\n")

    # test iterencode with unsafe strings
    s = json.dumps(unsafe_text, cls=AnsibleJSONEncoder, separators=(',', ':'), check_circular=False)

# Generated at 2022-06-20 15:49:13.208473
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json

    # precondition
    assert hasattr(json.JSONEncoder, 'iterencode')

    # constructor
    encoder = AnsibleJSONEncoder()

    # postcondition
    assert encoder
    assert hasattr(encoder, 'iterencode')

# Generated at 2022-06-20 15:49:14.447980
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:49:21.117261
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys

    # Import class AnsibleUnsafe here as it is defined in module ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleUnsafe

    # An AnsibleUnsafe object in a dict, then the dict is in a list,
    # and then the list is in a dict, and finally the dict is in a list
    value = [{'unsafe': AnsibleUnsafe("blah")}]

    # Run iterencode of AnsibleJSONEncoder to get an iterator
    json_iterator = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(value)

    # Get JSON string from json iterator
    json_str = ''.join(json_iterator)

    # Check if the JSON string is what we expected

# Generated at 2022-06-20 15:49:33.406295
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test vault_to_text=True
    a = AnsibleJSONEncoder(vault_to_text=True)
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update({'ansible': 'ansible'})
    b = json.dumps(vault, cls=a)
    assert b == '{"ansible": "ansible"}'

    # Test vault_to_text=False
    c = AnsibleJSONEncoder(vault_to_text=False)
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')
    vault.update({'ansible': 'ansible'})
    d = json.dumps(vault, cls=c)

# Generated at 2022-06-20 15:49:44.681197
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-20 15:49:54.874399
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    # Note: the value '{"some_field": "some_value"}' isn't a safe value
    # as it contains JSON because some_value can be an arbitrary string
    # and is not encoded as string using AnsibleUnsafe objects.
    # Hence this value cannot be be used to test the method
    # ``json.JSONEncoder.iterencode``

# Generated at 2022-06-20 15:49:57.822031
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder()
    value = o.default(444)
    assert value == 444

    class A():
        pass

    value = o.default(A())
    assert value == "{}"


# Generated at 2022-06-20 15:50:08.993496
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    unsafetext = 'unsafe'

    assert encoder.default(unsafetext) == 'unsafe'
    assert encoder.default(unsafetext + '|unsafe') == {'__ansible_unsafe': 'unsafe'}
    assert encoder.default({'a': unsafetext, 'b': {'c': unsafetext}}) == {'a': 'unsafe', 'b': {'c': 'unsafe'}}
    assert encoder.default([unsafetext]) == ['unsafe']
    assert encoder.default([unsafetext, unsafetext + '|unsafe']) == ['unsafe', {'__ansible_unsafe': 'unsafe'}]


# Generated at 2022-06-20 15:50:19.650210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(b'foo') == 'foo'
    assert AnsibleJSONEncoder().default(u'foo') == 'foo'
    assert AnsibleJSONEncoder().default(u'\u20ac') == '\xe2\x82\xac'
    assert AnsibleJSONEncoder().default(u'\ud83d\ude01') == '\xf0\x9f\x98\x81'
    assert AnsibleJSONEncoder().default(u'\ud83d\ude01'.encode('ascii', 'backslashreplace')) == '\\ud83d\\ude01'
    assert AnsibleJSONEncoder().default('foo') == 'foo'

# Generated at 2022-06-20 15:50:21.137144
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = AnsibleJSONEncoder().default(5)
    assert result == 5


# Generated at 2022-06-20 15:50:28.205216
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('baz')) == {'__ansible_unsafe': 'baz'}
    assert AnsibleJSONEncoder().default(dict(foo=AnsibleUnsafe('baz'))) == {'foo': {'__ansible_unsafe': 'baz'}}
    assert AnsibleJSONEncoder().default(dict(foo=datetime.datetime.utcnow())) == {'foo': datetime.datetime.utcnow().isoformat()}


# Generated at 2022-06-20 15:50:35.229415
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.loader import AnsibleUnsafeLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from io import BytesIO
    vault = VaultLib(password='ansible')
    vault_secret = vault.encrypt(b'abc')

    vault_json_dump = AnsibleJSONEncoder().iterencode(vault_secret).decode('utf-8')
    vault_json_load = json.loads(vault_json_dump)

    assert vault_json_load == {'__ansible_vault': vault_secret._ciphertext}


# Generated at 2022-06-20 15:50:39.125202
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansibleJSONEncoder = AnsibleJSONEncoder()
    assert ansibleJSONEncoder._preprocess_unsafe == False
    assert ansibleJSONEncoder._vault_to_text == False

# Generated at 2022-06-20 15:50:56.516043
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_bool
    from ansible.module_utils.common.text.converters import to_int
    from ansible.module_utils.common.text.converters import to_float
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode
    from ansible.module_utils.common.text.converters import to_naive_datetime

# Generated at 2022-06-20 15:51:09.418048
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(object) == '<object>'
    assert json.loads(json.dumps(set(), cls=AnsibleJSONEncoder)) == '<set>'
    assert json.loads(json.dumps(frozenset(), cls=AnsibleJSONEncoder)) == '<frozenset>'
    assert json.loads(json.dumps(list(), cls=AnsibleJSONEncoder)) == []
    assert json.loads(json.dumps(dict(), cls=AnsibleJSONEncoder)) == {}
    assert json.loads(json.dumps(1, cls=AnsibleJSONEncoder)) == 1
    assert json.loads(json.dumps(None, cls=AnsibleJSONEncoder)) is None

# Generated at 2022-06-20 15:51:22.017377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    default_encoder = AnsibleJSONEncoder.default
    # Check default encoder with a dict, a datetime and a vault object
    result = default_encoder(AnsibleJSONEncoder(), {'foo': 'bar'})
    assert result == {'foo': 'bar'}
    result = default_encoder(AnsibleJSONEncoder(), datetime.datetime(2018, 10, 17, 19, 52))
    assert result == '2018-10-17T19:52:00'

# Generated at 2022-06-20 15:51:30.470779
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    str_unsafe = "test"
    string_unsafe = AnsibleUnsafe(str_unsafe)
    unsafe_dict = {'unsafe_key': string_unsafe}
    unsafe_str_dict = {'unsafe_key': AnsibleUnsafe(str_unsafe)}
    input_dict = {
        'str_dict': {'key1': str_unsafe, 'key2': 'test2'},
        'str_unsafe': str_unsafe,
        'string_unsafe': string_unsafe,
        'unsafe_dict': unsafe_dict,
        'unsafe_str_dict': unsafe_str_dict,
        'list': [string_unsafe, str_unsafe, unsafe_dict]
    }
    output_

# Generated at 2022-06-20 15:51:41.985523
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2, b, u

    # Create AnsibleVaultEncryptedUnicode
    vault = VaultLib([])
    unicode_text = u('{}')
    unicode_vault = vault.encrypt(unicode_text)

    # Create AnsibleVaultEncryptedBytes
    bytes_text = b('{}')
    bytes_vault = vault.encrypt(bytes_text)

    # Create AnsibleUnsafeText
    text_unsafe = to_text(unicode_text)
    text_unsafe.__UNSAFE__ = True

    # Create AnsibleUnsafeBytes
    bytes_

# Generated at 2022-06-20 15:51:54.326436
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    if builtins.__name__.startswith('builtins'):
        string_types = (str, bytes)

    class MyStringType(string_types[0]):
        """MyStringType"""
        __UNSAFE__ = True

    # regular string type test
    # check string instance
    encoded_data = AnsibleJSONEncoder().iterencode(MyStringType())
    assert len(list(encoded_data)) == 1

    # check list of string instance
    encoded_data = AnsibleJSONEncoder().iterencode([MyStringType()])
    assert len(list(encoded_data)) == 3

    # check dict string instance

# Generated at 2022-06-20 15:52:05.835161
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # testing input
    test_input = {
        'ansible_unsafe_string': 'test',
        'ansible_unsafe_object': 'test',
        'ansible_unsafe_list': ['test1', 'test2'],
        'ansible_unsafe_dict': {'foo': {'bar': 'test'}},
    }
    ansible_unsafe_object = 'test'
    ansible_unsafe_object.__UNSAFE__ = True
    test_input['ansible_unsafe_object'] = ansible_unsafe_object
    ansible_unsafe_list = ['test1', 'test2']
    ansible_unsafe_list.__UNSAFE__ = True
    test_input['ansible_unsafe_list'] = ansible_unsafe_list
    ansible

# Generated at 2022-06-20 15:52:18.282709
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.encoding import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import gen_invocation_command

    a = [b'aa', b'bb', b'cc']
    # b = '\a\b\c'
    c = {'a': '\a\b\c'}

    x = AnsibleJSONEncoder()
    y = x.iterencode(a)
    print(y)

    # # json cannot encode b'\a\b\c'
    # y = x.iterencode(b)
    # print(y)
    #
   

# Generated at 2022-06-20 15:52:22.548087
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_obj = '{"x":"string"}'
    result = json.loads(json_obj)
    assert isinstance(result, Mapping)

    json_obj = '{"x":{"y":"string"}}'
    result = json.loads(json_obj)
    assert isinstance(result, Mapping)
    assert isinstance(result['x'], Mapping)

    json_obj = '{"x":"string", "y":"string"}'
    result = json.loads(json_obj)
    assert isinstance(result, Mapping)
    assert result['x'] == 'string'
    assert result['y'] == 'string'

    json_obj = '[{"x":"string"},{"x":"string"}]'
    result = json.loads(json_obj)
    assert isinstance(result, list)

# Generated at 2022-06-20 15:52:32.837916
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Encoding vault
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=False)

# Generated at 2022-06-20 15:52:56.485956
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    A test function to test function iterencode of class AnsibleJSONEncoder
    """
    # dict containing dict, list, string and int
    o = {'key1': 'val1',
         'key2': {'key3': 'val3',
                  'key4': ['val4', 'val5'],
                  'key6': 123},
         'key5': 'val6'}
    json_obj = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_str = json_obj.encode(o)
    assert json_str == '{"key1": "val1", "key2": {"key6": 123, "key4": ["val4", "val5"], "key3": "val3"}, "key5": "val6"}'

# Generated at 2022-06-20 15:52:58.177035
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None


# Generated at 2022-06-20 15:53:09.792372
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {'a':'b', 'c':'d'}

    # test for __init__
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

    # test for iterencode
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == False
    # test for for iterencode with preprocess_unsafe == True
    j = json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True, vault_to_text=False)
    assert j == '{"a": "b", "c": "d"}'



# Generated at 2022-06-20 15:53:10.335880
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-20 15:53:21.947405
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    test_data_dict = {'a': "123", 'b': [{'c': '456'}]}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    output_json_str = ''.join(encoder.iterencode(test_data_dict))
    assert output_json_str == '{"a": "123", "b": [{"c": "456"}]}'

    test_data_dict = {'a': 123, 'b': [{'c': '456'}]}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    output_json_str = ''.join(encoder.iterencode(test_data_dict))
    assert output_json_str == '{"a": 123, "b": [{"c": "456"}]}'

   

# Generated at 2022-06-20 15:53:25.734185
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {'foo': 'bar', 'a': 'b'}
    data_encoded = b'{"foo": "bar", "a": "b"}'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data) == data_encoded

# Generated at 2022-06-20 15:53:35.956765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    import datetime

    class AnsibleUnsafe(object):
        __UNSAFE__ = True

    unsafe_obj = AnsibleUnsafe()
    assert(AnsibleJSONEncoder().default(unsafe_obj) == {'__ansible_unsafe': ''})

    class AnsibleVault(object):
        __ENCRYPTED__ = True

    vault_obj = AnsibleVault()
    assert(AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': ''})

    class DummyObject(Mapping):
        def __init__(self):
            self._dict = dict(name='jon')

        def __getitem__(self, item):
            return self._dict[item]



# Generated at 2022-06-20 15:53:44.933782
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # The only real coverage is for the AnsibleUnsafe object,
    # the rest of them are tested via the iterencode method as
    # they are all JSONEncoder default encoders
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    test_obj = AnsibleJSONEncoder().default(AnsibleUnsafe("unsafe_str"))
    assert isinstance(test_obj, dict)
    assert test_obj.get('__ansible_unsafe', None) == "unsafe_str"

    # Test for other types
    curr_time = datetime.datetime.utcnow()
    test_obj = AnsibleJSONEncoder().default({"test_dic": curr_time})
    assert isinstance(test_obj, dict)
    assert test_obj['test_dic'] == cur

# Generated at 2022-06-20 15:53:54.654424
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import unittest
    import ansible.utils.unsafe_proxy
    ansible_unsafe_proxy_instance = ansible.utils.unsafe_proxy.AnsibleUnsafeText(u"This is a test string")

    # check methods return the right type
    assert(isinstance(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(ansible_unsafe_proxy_instance), type(iter(''))))
    assert(isinstance(AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(ansible_unsafe_proxy_instance), type(iter(''))))

    # check iterencode returns the right value

# Generated at 2022-06-20 15:54:01.775148
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    import ansible.utils.unsafe_proxy as unsafe
    test_dict = {'a': '2', 3: vault.VaultLib().encrypt('test'), 4: unsafe.AnsibleUnsafeText('unsafe')}
    assert json.loads(json.dumps(test_dict, sort_keys=True)) == test_dict
    assert json.loads(json.dumps(test_dict, sort_keys=True, cls=AnsibleJSONEncoder, preprocess_unsafe=False)) == test_dict
    assert json.loads(json.dumps(test_dict, sort_keys=True, cls=AnsibleJSONEncoder, preprocess_unsafe=True)) != test_dict