

# Generated at 2022-06-20 15:44:12.691858
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    # The class only extends json.JSONEncoder
    def test_json_encoder():
        assert issubclass(AnsibleJSONEncoder, json.JSONEncoder)


    # Test default(self, o)
    test_json_encoder()
    # the class has a default method
    assert hasattr(AnsibleJSONEncoder, 'default')
    # the default method is not defined in json.JSONEncoder
    assert not hasattr(json.JSONEncoder, 'default')
    # The default method is a classmethod
    assert isinstance(AnsibleJSONEncoder.default, classmethod)
    # the

# Generated at 2022-06-20 15:44:25.072926
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """Test to ensure constructor of class AnsibleJSONEncoder works as expected. """
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common._collections_compat import SafeDict
    import json

    # 1. Ensure custom encoders are registered as expected.

    # 1.1 Create a Custom Encoder instance and add it as a kwarg
    custom_encoder = json.JSONEncoder
    custom_encoder_kwargs = {"foo": "bar"}
    expected_custom_encoder_kwargs = custom_encoder_kwargs
    expected_custom_encoder_kwargs["cls"] = AnsibleJSONEncoder

    # 1.2 Create an AnsibleJSONEncoder instance and verify that all expected kwargs are there
    ansible_json_encoder = AnsibleJSON

# Generated at 2022-06-20 15:44:31.498215
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from six import BytesIO
    from ansible import module_utils
    data = [module_utils.AnsibleUnsafe('foo bar')]
    stream = BytesIO()

    json.dump(data, stream, cls=AnsibleJSONEncoder)
    assert stream.getvalue().decode('utf-8') == '[{"__ansible_unsafe": "foo bar"}]'

    stream.seek(0)
    cls = AnsibleJSONEncoder(preprocess_unsafe=True)
    cls.iterencode(data)
    assert stream.getvalue().decode('utf-8') == '[{"__ansible_unsafe": "foo bar"}]'

# Generated at 2022-06-20 15:44:40.830431
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    encoder = AnsibleJSONEncoder()

    assert encoder.default({"a": "b"}) == {"a": "b"}
    assert hasattr(encoder.default({"a": "b"}), 'items')
    assert encoder.default("a") == "a"
    assert not hasattr(encoder.default("a"), 'items')
    assert encoder.default(datetime.datetime(2018, 11, 18, 16, 17, 18)) == '2018-11-18T16:17:18'
    assert encoder.default(datetime.date(2018, 11, 18)) == '2018-11-18'


# Generated at 2022-06-20 15:44:50.024075
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    deleted_at = datetime.datetime(2020, 6, 24, 1, 1, 1, 918962)
    o = {
        'a': {
            'b': 'c',
            'd': deleted_at
        }
    }

    encoded_json = json.dumps(o, cls=AnsibleJSONEncoder)
    decoded_json = json.loads(encoded_json)
    assert isinstance(decoded_json['a']['d'], str)
    assert decoded_json['a']['d'] == '2020-06-24T01:01:01.918962'
    print("test_AnsibleJSONEncoder success")
    return True


# Generated at 2022-06-20 15:44:56.788592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Unit test for method default of class AnsibleJSONEncoder
    '''
    class Test(object):
        def __init__(self, value):
            self.value = value
    input_list = [
        {"key": "value"},
        {"key": 1},
        {"key": [1, 2, "3"]},
        {"key": [1, 2, {"a": {"b": "c"}}]},
        {"key": "{{lookup_value}}"},
        {"key": Test(1)},
    ]

# Generated at 2022-06-20 15:44:58.771887
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)

# Generated at 2022-06-20 15:45:09.447313
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils.common.collections import ImmutableDict as iDict

    obj = iDict({'text': 'hi hi'})
    my_json = json.dumps(obj, cls=AnsibleJSONEncoder)
    my_json_unsafe = json.dumps(obj, cls=AnsibleJSONEncoder(preprocess_unsafe=True))
    assert my_json == '{"text": "hi hi"}'
    assert my_json_unsafe == '{"text": "hi hi"}'

    obj = iDict({'text': 'hi hi', '__UNSAFE__': u'myStringToEncode'})
    # my_json = json.dumps(obj, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 15:45:16.383332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.urls import ConnectionInfo

    encoder = AnsibleJSONEncoder()

    assert encoder.default('test') == 'test'
    assert encoder.default(b'test') == b'test'
    assert encoder.default(['test', 123]) == ['test', 123]
    assert encoder.default(('test', 123)) == ('test', 123)
    assert encoder.default({"test": 123}) == {"test": 123}
    assert encoder.default(boolean(True)) == True
    assert encoder.default(boolean(False)) == False

    # NOTE: If a new type is added

# Generated at 2022-06-20 15:45:27.033111
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_unicode


# Generated at 2022-06-20 15:45:35.577651
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class _Vault(object):
        __ENCRYPTED__ = True
    class _Unsafe(object):
        __UNSAFE__ = True

    class _Safe(object):
        pass

    assert _preprocess_unsafe_encode(_Vault()) == {'__ansible_vault': u'__ANSIBLE_VAULT'}
    assert _preprocess_unsafe_encode(_Unsafe()) == {'__ansible_unsafe': u'__ANSIBLE_UNSAFE'}
    assert _preprocess_unsafe_encode(_Safe()) == {'__ansible_safe': u'__ANSIBLE_SAFE'}

# Generated at 2022-06-20 15:45:47.986522
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing import vault

    # secret param has the default value
    obj = AnsibleJSONEncoder()

    # date
    date = datetime.date.today()
    assert obj.default(date) == date.isoformat()

    # string
    s = 'str'
    assert obj.default(s) == s

    # dict
    d = {'a': 'b'}
    assert obj.default(d) == d

    # unsave
    save_path = tempfile.mkdtemp()
    vault.CLIARGS['vault_password_file'] = save_path
    v = VaultLib(save_path)


# Generated at 2022-06-20 15:45:58.453144
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class Dummy(object):
        pass

    class DummyUnsafe(Dummy):
        __UNSAFE__ = True

    class DummyVault(DummyUnsafe):
        __ENCRYPTED__ = True

    assert AnsibleJSONEncoder().default(Dummy()) == Dummy()
    assert AnsibleJSONEncoder().default(DummyVault()) == {'__ansible_vault': 'DummyVault()'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(DummyVault()) == 'DummyVault()'

    assert AnsibleJSONEncoder().default({'a': Dummy()}) == {'a': Dummy()}
    assert AnsibleJSONEncoder().default([Dummy()]) == [Dummy()]


# Generated at 2022-06-20 15:46:10.182944
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class TestUnsafe(unicode):
        """AnsibleUnsafe subclass of unicode which provides the
        ``__UNSAFE__`` and ``__ENCRYPTED__`` attributes required by
        ``_preprocess_unsafe_encode``
        """
        __UNSAFE__ = True

    class TestUnsafeEncrypted(unicode):
        """AnsibleVaultUnsafe subclass of unicode which provides the
        ``__UNSAFE__`` and ``__ENCRYPTED__`` attributes required by
        ``_preprocess_unsafe_encode``
        """
        __UNSAFE__ = True
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:46:18.365804
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.encodings.base64 import encode

    from ansible.parsing.vault import VaultLib

    # vault object
    ciphertext = VaultLib().encrypt(b'test')
    vault_obj = encode(ciphertext)
    assert isinstance(json.loads(AnsibleJSONEncoder().encode(vault_obj)), dict)
    assert isinstance(json.loads(AnsibleJSONEncoder(vault_to_text=True).encode(vault_obj)), str)

    # unsafe object
    unsafe_obj = "{{{this_is_dangerous}}}"
    assert isinstance(json.loads(AnsibleJSONEncoder().encode(unsafe_obj)), dict)

# Generated at 2022-06-20 15:46:20.069111
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: Need to add unit test for this
    pass

# Generated at 2022-06-20 15:46:29.886295
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class A:
        def __getitem__(self, key):
            return 'A'

    a = A()
    result = list(AnsibleJSONEncoder().iterencode(a))
    assert result == ['{', '"', '0', '"', ':', '"', 'A', '"', '}']

    class B:
        def __getitem__(self, key):
            return 'B'

    b = B()
    result = list(AnsibleJSONEncoder().iterencode(b))
    assert result == ['{', '"', '0', '"', ':', '"', 'B', '"', '}']

    result = list(AnsibleJSONEncoder().iterencode(a, b))

# Generated at 2022-06-20 15:46:37.321747
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder._preprocess_unsafe is False
    assert ansible_json_encoder._vault_to_text is False
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_json_encoder._preprocess_unsafe is True
    assert ansible_json_encoder._vault_to_text is False
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert ansible_json_encoder._preprocess_unsafe is False
    assert ansible_json_encoder._vault_to_text is True


# Generated at 2022-06-20 15:46:45.161103
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Unit test for method default of class AnsibleJSONEncoder'''
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.safe_eval import AnsibleUnsafe

    def _test_AnsibleJSONEncoder_default(value):
        return json.dumps(value, cls=AnsibleJSONEncoder)

    classes = [AnsibleUnsafe, VaultLib]
    for cls in classes:
        assert cls(u'unicode string').__repr__() in _test_AnsibleJSONEncoder_default(cls(u'unicode string'))

# Generated at 2022-06-20 15:46:52.989059
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    Test that passing UNICODE "u" strings in to iterencode works, as well as byte strings,
    and that vaulted bytes string as well as unicode strings are correctly encoded/decoded
    """

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    vault_id = '23456789012345678901234567890ABC'

    plaintext_unicode = u"unicode_string"
    plaintext_bytes = b"Unicode_bytes"
    vaulted_unicode = u"another_unicode_string"
    vaulted_bytes = b"another_unicode_bytes"
    vaulted_bytes_via_unicode = u"another_unicode_bytes"

    vault = VaultLib([])
    vault

# Generated at 2022-06-20 15:47:03.694991
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import AnsibleUnsafeText

    src = dict(var1=42, var2=dict(sub1=1, sub2=2), var3=[], var4=AnsibleUnsafeText(u'data'))
    expected = '{"var1": 42, "var2": {"sub1": 1, "sub2": 2}, "var3": [], "var4": {"__ansible_unsafe": "data"}}'

    assert next(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(src)) == expected

# Generated at 2022-06-20 15:47:15.759515
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleUnsafeBytes

    json_data = {
        'str_data': 'This is a string',
        'bytes_data': b'This is a byte string',
        'unsafe_str_data': AnsibleUnsafeText('This is an unsafe string'),
        'unsafe_bytes_data': AnsibleUnsafeBytes(b'This is an unsafe byte string'),
        'list_data': [
            1,
            'str_data',
            b'bytes_data',
            AnsibleUnsafeText('unsafe_str_data'),
            AnsibleUnsafeBytes(b'unsafe_bytes_data')
        ]
    }

# Generated at 2022-06-20 15:47:16.930561
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert {'__ansible_vault': 'value'} == AnsibleJSONEncoder().default(object())


# Generated at 2022-06-20 15:47:26.478087
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    from ansible.module_utils.six import binary_type
    # Create a dictionary with a string value and a ansible.module_utils.basic.AnsibleUnsafeText value
    data = {'foo': 'hello',
            'bar': ansible.module_utils.basic.AnsibleUnsafeText(u'hello')}
    # Encode the dictionary
    value = json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True, sort_keys=True, ensure_ascii=False)
    if isinstance(value, binary_type):
        value = value.decode('utf-8')
    # The generated JSON should be
    # {"__ansible_unsafe": "hello", "foo": "hello"}

# Generated at 2022-06-20 15:47:39.098224
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import strip_internal_keys

    def assert_json(o, j):
        assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode(o) == j
        assert json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=True, vault_to_text=True) == j

    # assert_json checks the output of AnsibleJSONEncoder
    # it checks if the json encoded value is equal to the expected json string
    # if the values are equal then it returns true
    # else it returns false


# Generated at 2022-06-20 15:47:48.029684
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    ansibleUnsafeText = AnsibleUnsafeText("test")
    ansibleUnsafeBytes = AnsibleUnsafeBytes("test")

    ansibleVault = VaultSecret("test")

    assert json.loads(json.dumps(ansibleUnsafeText, cls=AnsibleJSONEncoder)) == {"__ansible_unsafe": ansibleUnsafeText}
    assert json.loads(json.dumps(ansibleUnsafeBytes, cls=AnsibleJSONEncoder)) == {"__ansible_unsafe": ansibleUnsafeBytes}

# Generated at 2022-06-20 15:47:56.928825
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import b
    from ansible.module_utils.basic import AnsibleUnsafe

    vault_secret = VaultSecret('my_secret', 'my_passwd')
    vault_passwords = {'VAULT_PASSWORD_FILE': vault_secret.filename, 'ANSIBLE_VAULT_PASSWORD_FILE': vault_secret.filename}
    vault_ciphertext = b('\x00\x01\x02\x03')
    vault_secrets = {"key": "value"}
    vault_password = VaultLib(vault_passwords)

# Generated at 2022-06-20 15:47:58.578615
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create class object
    aje = AnsibleJSONEncoder()

    # Make sure it's of type AnsibleJSONEncoder
    assert isinstance(aje, AnsibleJSONEncoder)

# Generated at 2022-06-20 15:48:07.204813
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_str = u"héllo"

    # Test simple string
    assert AnsibleJSONEncoder().iterencode(test_str) == u'"héllo"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(test_str) == u'"héllo"'

    # Test class that inherits from str
    class TestStr(str):
        __UNSAFE__ = True
    assert AnsibleJSONEncoder().iterencode(TestStr(test_str)) == u'"héllo"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(TestStr(test_str)) == u'{"__ansible_unsafe": "héllo"}'

    # Test class that inherits from bytes
    class TestStr(bytes):
        __UNSAFE__ = True

# Generated at 2022-06-20 15:48:17.977522
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import base64

    class MyString(str):
        __ENCRYPTED__ = True
        __UNSAFE__ = False

        def __init__(self, string, ciphertext):
            super(MyString, self).__init__()
            self.__ciphertext = ciphertext

        @property
        def _ciphertext(self):
            return self.__ciphertext

    class MyUnsafeString(unicode):
        __ENCRYPTED__ = False
        __UNSAFE__ = True

    class MyUnsafeMapping(dict):
        __ENCRYPTED__ = False
        __UNSAFE__ = True

        def __init__(self, *args, **kwargs):
            super(MyUnsafeMapping, self).__init__()

# Generated at 2022-06-20 15:48:25.143164
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder(preprocess_unsafe = True, vault_to_text = True)
    assert a._preprocess_unsafe == True
    assert a._vault_to_text == True


# Generated at 2022-06-20 15:48:33.307312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    vault_password = to_bytes('vault_password')

    # vault object
    value = VaultLib(vault_password).encrypt('secret')
    assert AnsibleJSONEncoder().default(value) == {'__ansible_vault': value._ciphertext}
    assert AnsibleJSONEncoder(vault_to_text=True).default(value) == to_text(value, errors='surrogate_or_strict')

    # unsafe object
    value = to_bytes('unsafe')
    assert AnsibleJSONEncoder().default(value) == {'__ansible_unsafe': to_text(value, errors='surrogate_or_strict')}

# Generated at 2022-06-20 15:48:34.572903
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  aje = AnsibleJSONEncoder()
  assert aje

# Generated at 2022-06-20 15:48:43.222290
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({1, 2, 3}) == {1, 2, 3}
    assert AnsibleJSONEncoder().default({1: 2, 3: 4}) == {1: 2, 3: 4}
    assert AnsibleJSONEncoder().default(datetime.datetime(year=2000, month=1, day=1)) == '2000-01-01T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.date(year=2000, month=1, day=1)) == '2000-01-01'

# Generated at 2022-06-20 15:48:49.717622
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with datetime
    value = AnsibleJSONEncoder().default(datetime.datetime(2018, 8, 20))
    assert value == '2018-08-20T00:00:00'

    value = AnsibleJSONEncoder().default(datetime.date(2018, 8, 20))
    assert value == '2018-08-20'

    # Test with dict
    value = AnsibleJSONEncoder().default(dict(a=[1, 2, 3]))
    assert value == {'a': [1, 2, 3]}

# Generated at 2022-06-20 15:49:00.449467
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleMapping, AnsibleSequence, AnsibleUnsafeText
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # UnsafeProxy is subclass of AnsibleUnsafeText, AnsibleUnsafeText is subclass of str
    assert issubclass(UnsafeProxy, AnsibleUnsafeText)
    assert issubclass(AnsibleUnsafeText, string_types)

    # AnsibleUnsafeText will be treated as str
    value = AnsibleUnsafeText('some text')
    assert isinstance(value, string_types)
    assert isinstance(value, AnsibleUnsafeText)

    # Test AnsibleJSON

# Generated at 2022-06-20 15:49:09.691153
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:49:20.064233
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, string_types
    from ansible.module_utils.common._collections_compat import Mapping

    def _preprocess_unsafe_encode(value):
        """Recursively preprocess a data structure converting instances of ``AnsibleUnsafe``
        into their JSON dict representations

        Used in ``AnsibleJSONEncoder.iterencode``
        """
        if getattr(value, '__UNSAFE__', False) and not getattr(value, '__ENCRYPTED__', False):
            value = {'__ansible_unsafe': to_text(value, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-20 15:49:26.941003
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    assert aje.default("test") == "test"
    assert aje.default(["test"]) == ["test"]
    assert aje.default(("test", 0)) == ["test", 0]
    assert aje.default({"test": "dict"}) == {"test": "dict"}
    assert aje.default({0: "dict"}) == {0: "dict"}

# Generated at 2022-06-20 15:49:34.534742
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.json_utils import _AnsibleUnsafeText, _AnsibleUnsafeBytes
    from ansible.module_utils.common import json

    vault_pass = 'secret'
    password = 'hunter2'
    encoded = VaultLib(vault_pass).encode(password)
    vault_password = 'Vault(%s)' % encoded
    unsafe_text = _AnsibleUnsafeText(password)
    unsafe_bytes = _AnsibleUnsafeBytes(to_bytes(password, errors='surrogate_or_strict', nonstring='strict'))

    # test without unsafe

# Generated at 2022-06-20 15:49:45.380484
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(one=1,two=2)) == dict(one=1,two=2), 'Invalid encoded dict'
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat(), 'Invalid encoded datetime'
    assert AnsibleJSONEncoder().default(datetime.date.today()) == datetime.date.today().isoformat(), 'Invalid encoded date'

# Generated at 2022-06-20 15:49:55.644334
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._vault_to_text == False
    assert AnsibleJSONEncoder(vault_to_text=True)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault

# Generated at 2022-06-20 15:50:03.645256
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    # Assert that aje.default() returns a string
    assert isinstance(aje.default('test'), str)
    # ASSERT that aje.default() returns a dict
    assert isinstance(aje.default({'test': 'test'}), dict)
    # ASSERT that aje.default() returns a list
    assert isinstance(aje.default(['test', 'test']), list)
    # ASSERT that aje.default() returns an int
    assert isinstance(aje.default(0), int)


# Generated at 2022-06-20 15:50:08.073926
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    value = encoder.default(b'bytes_unsafe')

    assert isinstance(value, dict)
    assert value.has_key('__ansible_unsafe')
    assert value['__ansible_unsafe'].startswith(u'bytes_unsafe')

# Generated at 2022-06-20 15:50:08.965575
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None

# Generated at 2022-06-20 15:50:17.146560
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import b
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    import datetime
    import time
    test_str = 'test-str'
    test_bytes = b'test-bytes'
    test_dict = {'key1': 1, 'key2': 2}
    test_list = ['test-str', 1, 2]
    test_datetime = datetime.datetime.now()
    test_date = datetime.date.fromtimestamp(time.time())
    test_date_str = test_date.isoformat()
    test_datetime_str = test_datetime.isoformat()

# Generated at 2022-06-20 15:50:19.621160
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert(a)


# Generated at 2022-06-20 15:50:29.440840
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    # encoding a class AnsibleUnsafeText
    unsafe_text = "AAA+++"
    unsafe_type = AnsibleUnsafeText(unsafe_text)
    result = list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(unsafe_type))
    assert result[0] == json.dumps({"__ansible_unsafe": "AAA+++"})

    # encoding a class AnsibleUnsafeBytes
    unsafe_bytes = b"111---"
    unsafe_type = AnsibleUnsafeBytes(unsafe_bytes)

# Generated at 2022-06-20 15:50:40.796329
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault

    test_unsafe = 'AnsibleUnsafe'
    test_unsafe_crypt = ansible.parsing.vault.VaultLib(password='ansible').encrypt(test_unsafe)
    test_dict = {'a': test_unsafe, 'a1': test_unsafe_crypt}

    test_json_unsafe = '{"a": "AnsibleUnsafe", "a1": {"__ansible_vault": "Vault[8c4b65b0-2cf4-4094-8d8b-0cbf44f59ac1]"' \
                      '}}'

# Generated at 2022-06-20 15:50:45.300066
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    result = AnsibleJSONEncoder().encode(1)
    assert result == '1'
    assert AnsibleJSONEncoder().encode(True) == 'true'
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).encode(1) == '1'


# Generated at 2022-06-20 15:50:54.167107
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    impo

# Generated at 2022-06-20 15:51:06.078058
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafeText
    o = {'vault_test': VaultLib().encrypt('test_encrypt_value')}
    o['unsafe_text'] = AnsibleUnsafeText('test_unsafe_value')
    o['some_text'] = 'test_some_text'
    output_str = b'{"vault_test": {"__ansible_vault": "test_encrypt_value"}, "unsafe_text": {"__ansible_unsafe": "test_unsafe_value"}, "some_text": "test_some_text"}'
    # Print the json string and check manually
    # print(json.dumps(o, cls=AnsibleJSONEncoder, indent=4, sort_

# Generated at 2022-06-20 15:51:07.880188
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
        assert ansible_json_encoder._preprocess_unsafe is True
    except:
        ansible_json_encoder.__init__()

# Generated at 2022-06-20 15:51:20.611313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import ImmutableDict

    encoder = AnsibleJSONEncoder()
    assert '{"__ansible_unsafe": "value with unsafe"}' == json.dumps({'__ansible_unsafe': 'value with unsafe'}, cls=encoder.__class__)
    assert '{"__ansible_vault": "vault"}' == json.dumps({'__ansible_vault': 'vault'}, cls=encoder.__class__)

    assert '{"key": "value"}' == json.dumps({'key': 'value'}, cls=encoder.__class__)
    assert '["value"]' == json.dumps(['value'], cls=encoder.__class__)

# Generated at 2022-06-20 15:51:25.298796
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default({"foo": "bar"}) == {"foo": "bar"}
    assert ansible_json_encoder.default(VaultLib("test")) == {'__ansible_vault': 'test'}


# Generated at 2022-06-20 15:51:32.248301
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import binascii
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.unsafe_loader import AnsibleUnsafeText, AnsibleUnsafeBytes

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    # Testing string
    result = encoder.iterencode('hello')
    assert result == '"hello"'
    # Testing string object
    result = encoder.iterencode(AnsibleUnsafeText('hello'))
    assert result == '"hello"'
    # Testing binary object
    result = encoder.iterencode(AnsibleUnsafeBytes(b'\x80'))
    assert result == '"\\u0080"'
    # Testing binary object

# Generated at 2022-06-20 15:51:35.516135
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_encoder = AnsibleJSONEncoder()
    test_output = test_encoder.default({"encrypted": "test"})
    assert test_output == {"encrypted": "test"}

# Generated at 2022-06-20 15:51:44.297700
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    from ansible.parsing.vault import VaultLib

    ciphertext = '$ANSIBLE_VAULT;1.2;AES256;default\r\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\r\n'
    vault_content = VaultLib().decrypt(ciphertext)
    json_data = {
        'vault':VaultLib().decrypt(ciphertext),
        'vault_org': ciphertext,
        'timestamp': datetime.datetime.now()
    }
    print(json.dumps(json_data, cls=AnsibleJSONEncoder))
    print('\n\n')
    print(json.dumps(json_data, cls=AnsibleJSONEncoder, preprocess_unsafe=True))

# Generated at 2022-06-20 15:51:55.474359
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean

    data = {
        'unsafe_string': boolean('unsafe'),
        'unsafe_bytes': boolean(b'unsafe'),
        'unsafe_integer': boolean(1),
        'unsafe_sequence': boolean([1, 2, 3]),
        'unsafe_mapping': {
            'inner_unsafe_string': boolean('unsafe'),
            'inner_unsafe_bytes': boolean(b'unsafe'),
            'inner_unsafe_integer': boolean(1),
            'inner_unsafe_sequence': boolean([1, 2, 3]),
        }
    }

    expected = repr(data)

# Generated at 2022-06-20 15:52:06.299128
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(True) is True
    assert AnsibleJSONEncoder().default(False) is False
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(123) == 123
    assert AnsibleJSONEncoder().default({u'a': u'b'}) == {u'a': u'b'}
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    assert json.loads(json.dumps(AnsibleUnsafeText('a'), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': u'a'}



# Generated at 2022-06-20 15:52:25.412825
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert(encoder.encode([1,3]) == '[1,3]')

# Generated at 2022-06-20 15:52:34.644729
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test ansible_vault
    ansible_vault = AnsibleJSONEncoder()
    # create a vault object
    class AnsibleVault:
        __ENCRYPTED__ = True
        _ciphertext = u'fake_ciphertext'
    ansible_vault_obj = AnsibleVault()
    assert ansible_vault.default(ansible_vault_obj) == {'__ansible_vault': 'fake_ciphertext'}

    # test ansible_unsafe
    ansible_unsafe = AnsibleJSONEncoder()
    # create a unsafe object
    class AnsibleUnsafe:
        __UNSAFE__ = True
    ansible_unsafe_obj = AnsibleUnsafe()

# Generated at 2022-06-20 15:52:46.209645
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    import sys
    import io
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts.system.distribution import DistributionLegacyFact
    from ansible.module_utils.facts.system.distribution import DistributionMediumFact
    from ansible.module_utils.facts.system.distribution import DistributionNewFact
    # ios_system module won't work for testing, for now, since ios_system is calling ansible-playbook -i localhost,local -c local -e 'ansible_connection=local' -v os-setup-module unit_tests/setup-module-unit-tests.yml
    # from ansible.modules.network.ios.ios_system import System
    #

# Generated at 2022-06-20 15:52:47.265030
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder()

# Generated at 2022-06-20 15:52:57.493210
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleUnsafeText

    data = [
        AnsibleUnsafe('42'),
        AnsibleUnsafeText('42'),
    ]
    expected = [
        '"__ansible_unsafe": "42"',
        '"__ansible_unsafe": "42"',
    ]

    for element, expected_element in zip(data, expected):
        json_encoded_element = json.dumps(element, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
        assert expected_element in json_encoded_element
        # Python 2/3 compatibility:
        # Python 2's `json.loads` supports str or unicode as input without a custom cls
        # Python 3's `json.loads` *only*

# Generated at 2022-06-20 15:52:59.021634
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-20 15:53:10.018909
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    value = encoder.default({'foo' : 'bar', 'baz' : False})
    assert value['foo'] == 'bar'
    assert value['baz'] is False

    vaultlib = VaultLib(None)
    value = encoder.default(vaultlib.encrypt('vault_pwd', 'secret_value'))

# Generated at 2022-06-20 15:53:21.738903
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.utils.unsafe_proxy as unsafe_proxy
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder(vault_to_text=True)

    # test vault object

# Generated at 2022-06-20 15:53:32.959910
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe, AnsibleVaultEncryptedUnicode


# Generated at 2022-06-20 15:53:42.887099
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
