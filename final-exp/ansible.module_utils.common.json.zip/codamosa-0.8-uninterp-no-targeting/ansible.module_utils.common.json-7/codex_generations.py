

# Generated at 2022-06-20 15:44:11.972492
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    x = {"a": u"string", "b": 123, "c": {"d": 456}, "e": [u"f", AnsibleUnsafeText(u"g\nh\n")]}

    y = json.dumps(x, cls=AnsibleJSONEncoder, indent=4, separators=(',', ': '), ensure_ascii=False)
    # Result is compliant to RFC 7159
    # https://tools.ietf.org/html/rfc7159

# Generated at 2022-06-20 15:44:24.448265
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import collections
    o = collections.OrderedDict()
    o["a"] = "a"
    o["b"] = "b"
    import ansible.parsing.vault
    v = ansible.parsing.vault.VaultLib("vault_pass")
    d = v.encrypt("v")
    o["c"] = d
    d_output = json.dumps(o, indent=4, sort_keys=True, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 15:44:32.014544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create a sample ansible vault
    vault_obj = json.JSONEncoder({'ANSIBLE_VAULT': '$ANSIBLE_VAULT;1.1;AES256'}).default
    # Create a sample ansible unsafe
    unsafe_obj = json.JSONEncoder('').default
    # Create a sample date object
    date_obj = datetime.date(2018, 1, 1)

    # Create the encoder
    json_encoder = AnsibleJSONEncoder()
    # Test the default cases
    assert u'{}' == json_encoder.default(vault_obj)
    assert u'{}' == json_encoder.default(unsafe_obj)
    assert u'"2018-01-01"' == json_encoder.default(date_obj)

    # Create the encoder
    json_enc

# Generated at 2022-06-20 15:44:43.140257
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # instance of AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secret
    secret_text = b"my_vault_secret"
    vault = VaultLib([(VaultSecret('vault1', secret_text),)])
    encrypted_text = vault.encrypt("this is my secret")
    vault_obj = VaultSecret("vault1", secret_text)


# Generated at 2022-06-20 15:44:49.778612
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import contextlib
    import io

    def _assert_iterencode(value, expected, preprocess_unsafe=False, vault_to_text=False):
        """Helper tests to assert encoding values for AnsibleJSONEncoder.iterencode"""
        output = io.BytesIO()

        with contextlib.closing(output):
            json.dump(value, output, cls=AnsibleJSONEncoder, preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text)

        actual = output.getvalue()
        try:
            expected = expected.encode('utf-8')
        except (AttributeError, UnicodeDecodeError):
            pass

# Generated at 2022-06-20 15:44:51.483555
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False)


# Generated at 2022-06-20 15:45:02.449244
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import sys

    data = {
        'tests': [
            AnsibleUnsafeText(b'pas@sword'),
            [AnsibleUnsafeText(b'pas@sword')],
            {'key1': AnsibleUnsafeText(b'pas@sword'), 'key2': AnsibleUnsafeText(b'pas@sword')},
        ],
    }

    json_data = '[{"__ansible_unsafe": "pas@sword"}, [{"__ansible_unsafe": "pas@sword"}], {"key1": {"__ansible_unsafe": "pas@sword"}, "key2": {"__ansible_unsafe": "pas@sword"}}]'

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

   

# Generated at 2022-06-20 15:45:05.239185
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_obj = AnsibleJSONEncoder()
    assert(json_obj._preprocess_unsafe == False)
    assert(json_obj._vault_to_text == False)

# Generated at 2022-06-20 15:45:13.230423
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import sys
    import datetime
    if sys.version_info[0] >= 3:
        from ansible.parsing.vault import VaultLib
        from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes
    else:
        from ansible.vault import VaultLib
        from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    from ansible.module_utils.common.collections import ImmutableDict

    test_value = u'$ANSIBLE_VAULT;9.9;TEST'
    vault_obj = VaultLib([])
    vault_obj.decrypt(test_value)
    vault_text = str(vault_obj)
    vault_unsafe_bytes = AnsibleUnsafeBytes(test_value)
    vault_unsafe_

# Generated at 2022-06-20 15:45:25.188263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Example data is given with the assert statements as comments
    """
    encoder = AnsibleJSONEncoder()

    o = _is_unsafe # function
    assert encoder.default(o) is o

    o = _is_vault # function
    assert encoder.default(o) is o

    o = datetime.datetime(2015, 9, 14, 1, 50, 9)
    assert encoder.default(o) == '2015-09-14T01:50:09'

    o = datetime.date(2015, 9, 14)
    assert encoder.default(o) == '2015-09-14'

    o = u'unicode'
    assert encoder.default(o) == 'unicode'

    o = u'some_vault_string'.encode('utf-8')
    assert enc

# Generated at 2022-06-20 15:45:35.725822
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    safe_string = "test_string"
    unsafe_string = AnsibleUnsafe("test_string")
    vault_string = AnsibleVaultEncryptedUnicode("vault_string")
    date_test = datetime.datetime.today()
    list_test = [safe_string, unsafe_string, vault_string, date_test]
    dict_test = {
        "safe_string": safe_string,
        "unsafe_string": unsafe_string,
        "vault_string": vault_string,
        "date_test": date_test,
    }
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.encode(unsafe_string) == "\"%s\"" % safe_string

# Generated at 2022-06-20 15:45:48.188460
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import MutableMapping

    class MutableMappingWithAnsibleUnsafe(MutableMapping):
        pass

    class AnsibleUnsafe(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    # Test with preprocess_unsafe set to True, since iterencode is called with preprocess_unsafe set to True in modules module-utils
    test_AnsibleJSONEncoder_iterencode_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert test_AnsibleJSONEncoder_iterencode_encoder.iterencode(AnsibleUnsafe('ansible unsafe')) == '{"__ansible_unsafe": "ansible unsafe"}'
    assert test_AnsibleJSONEnc

# Generated at 2022-06-20 15:45:52.046020
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps('string', cls=AnsibleJSONEncoder) == '"string"'
    from ansible import __version__

    assert json.dumps({'version': __version__}, cls=AnsibleJSONEncoder) == '{"version": "' + __version__ + '"}'

# Generated at 2022-06-20 15:46:02.036860
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence, MutableSet
    from ansible.module_utils.common.text.converters import to_bytes

    # Test cases

# Generated at 2022-06-20 15:46:10.034752
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    class MyInstance(AnsibleUnsafeText):
        pass

    x = MyInstance('unsafe')
    y = MyInstance('unsafe')
    z = {'key1': x, 'key2': y}
    enc = AnsibleJSONEncoder()
    assert enc.iterencode(z) == u'{"key1": {"__ansible_unsafe": "unsafe"}, "key2": {"__ansible_unsafe": "unsafe"}}'

# Generated at 2022-06-20 15:46:18.280016
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from datetime import datetime

    encoder = AnsibleJSONEncoder()
    assert '"abc"' == encoder.encode('abc')
    assert '{"abc": "123"}' == encoder.encode({'abc': '123'})
    assert '["abc", "123", 123]' == encoder.encode(['abc', '123', 123])
    assert '{"__ansible_vault": "AES256:Zm9v"}' == encoder.encode(VaultLib('123').encrypt('foo'))

# Generated at 2022-06-20 15:46:20.718825
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    res = obj.default('test')
    assert res == 'test'


# Generated at 2022-06-20 15:46:30.498732
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(dict(foo='bar'), cls=AnsibleJSONEncoder, sort_keys=True)) == {'foo': 'bar'}
    assert json.loads(json.dumps(dict(foo=dict(bar='baz')), cls=AnsibleJSONEncoder, sort_keys=True)) == {'foo': {'bar': 'baz'}}
    assert json.loads(json.dumps(dict(foo=datetime.datetime(year=2016, month=7, day=4)), cls=AnsibleJSONEncoder, sort_keys=True)) == {'foo': '2016-07-04T00:00:00'}

# Generated at 2022-06-20 15:46:32.934774
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test if the parameter `indent` defaults to None
    encoder = AnsibleJSONEncoder()

    assert encoder.indent is None



# Generated at 2022-06-20 15:46:43.608409
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 15:46:46.703092
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()



# Generated at 2022-06-20 15:46:53.920317
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    # 1. String with __ENCRYPTED__ attribute
    ciphertext = b'$ANSIBLE_VAULT;1.1;AES256;test01\n393335303730396462363335653439333061646233396237383131633334636536333662396134310a32653835383064393565363466396466336262666331613566343733356135373932366661330a623437393536303561643966653863303263346265306632396437396564343538643834366430\n'

# Generated at 2022-06-20 15:47:03.050184
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    sdict = {'a': AnsibleUnsafeText(u'中文测试'.encode('utf-8', 'surrogateescape')),
             'b': AnsibleUnsafeBytes(b'bytes value\x00\x01\x02', errors='surrogateescape'),
             'c': u'中文测试'}
    encoded_sdict_iter = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(sdict)
    assert isinstance(encoded_sdict_iter, Sequence)

    encoded_s

# Generated at 2022-06-20 15:47:06.427595
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(sort_keys=True).encode(dict(a=1, b=2)) == b'{"a": 1, "b": 2}'



# Generated at 2022-06-20 15:47:12.588726
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    data = {'a': 'b'}
    assert encoder.default(data) == data

    data = {'a': b'b'}
    assert encoder.default(data) == {'a': 'b'}

    data = {'a': 5}
    assert encoder.default(data) == data



# Generated at 2022-06-20 15:47:22.763154
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test Unicode literal values
    json_encoder1 = AnsibleJSONEncoder()
    output = json_encoder1.encode([u'💩'])
    assert output == '[\n    "💩"\n]'

    # Test non-ascii Unicode values
    json_encoder2 = AnsibleJSONEncoder()
    output = json_encoder2.encode([u'דג סקרן שט בים מאוכזב ולפתע מצא חברה איך הקליטה'])

# Generated at 2022-06-20 15:47:34.833537
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import BytesIO
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.common.removed
    import ansible.module_utils.ec2
    from ansible.parsing.vault import VaultLib

    # NOTE: json.loads() cannot load unicode, this is only useful for testing
    def _load_unicode(stream):
        return json.load(to_text(stream))

    def _test_encode(data):
        for preprocess_unsafe in (True, False):
            for vault_to_text in (True, False):
                # NOTE: Ensure "False == False" is true
                assert False == False

                # Test data transformer
                stream = BytesIO()
                json.dump

# Generated at 2022-06-20 15:47:45.677401
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import jinja2
    from ansible.module_utils.six import text_type, PY3

    def _check_encoded_json(json_data, expected_json_data, preprocess_unsafe=False, vault_to_text=False):
        if not (isinstance(json_data, text_type) or isinstance(json_data, bytes)):
            json_data = json.dumps(json_data, cls=AnsibleJSONEncoder, preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text)
        if PY3:
            json_data = json_data.encode('utf-8')


# Generated at 2022-06-20 15:47:53.638225
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import PY3, b, u

    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder != None

    # Test datetime object
    dt = datetime.datetime.utcnow()
    assert ansible_json_encoder.default(dt) == dt.isoformat()

    assert ansible_json_encoder.default(b('foo')) == 'foo'

    if PY3:
        # Test text, which should now be converted to bytes
        assert ansible_json_encoder.default('foo') == u('foo')


# Generated at 2022-06-20 15:48:05.163353
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import pytest
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    assert AnsibleJSONEncoder().encode(AnsibleUnsafe('password')) == '"password"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).encode(AnsibleUnsafe('password')) == '{"__ansible_unsafe": "password"}'

    vault = VaultAES256('vault', 'password')
    vault_ciphertext = vault.encrypt('vault_password')

    if vault_ciphertext:
        assert AnsibleJSONEncoder().encode(vault_ciphertext) == '"vault_password"'
        assert AnsibleJSONEncoder

# Generated at 2022-06-20 15:48:19.866987
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """
    This function is used to test the iterencode function, a function
    of the AnsibleJSONEncoder class. This test is a reproduction of the unit
    test contained in the Ansible core.

    """
    import io
    import json

    class AnsibleUnsafeText(str):
        __UNSAFE__ = True

    class AnsibleUnsafeBytes(bytes):
        __UNSAFE__ = True

    class AnsibleVaultBytes(bytes):
        __ENCRYPTED__ = True

    class AnsibleVaultText(str):
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:48:29.065258
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.vars.hostvars import HostVars
    import datetime

    vault_password = 'fakepass'
    hostvars = HostVars(variable_manager=None, loader=None)
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    test = 'fake'

    # test string
    result = json.dumps(test)
    assert result == ansible_encoder.default(test)

    # test AnsibleUnsafe
    test = AnsibleUnsafe(test)
    result = json.dumps({'__ansible_unsafe': test})
    assert result == ansible_encoder.default(test)

    #

# Generated at 2022-06-20 15:48:40.607691
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder.check_circular is False
    assert encoder.ensure_ascii is True
    assert encoder.indent is None
    assert encoder.separators == (',', ':')
    assert encoder.sort_keys is False
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False

    encoder = AnsibleJSONEncoder()
    assert encoder.check_circular is False
    assert encoder.ensure_ascii is True
    assert encoder.indent == 2
    assert encoder.separators == (',', ':')
    assert encoder.sort_keys is True
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is True

# Generated at 2022-06-20 15:48:50.274860
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

    test_case = {
        "foo": "bar",
        "baz": [
            "foo",
            "bar"
        ],
        "boom" : {
            "foo": "bar"
        },
        "vault":VaultLib().encrypt('baz'),
        "unsafe":ansible.parsing.vault.AnsibleUnsafeString('baz')
    }

    encoded_json = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(test_case)

    assert encoded_json[0] == '{'
    assert '"__ansible_unsafe": "baz"' in encoded_json[1]

# Generated at 2022-06-20 15:49:01.197083
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import PY3, string_types
    from ansible.module_utils.urls import Url
    # FIXME: do not assume the module_utils package is already present in the
    # path.
    module_utils_path = "ansible/module_utils/six.py"
    with open(module_utils_path, "r") as f:
        contents = f.read()
    import ansible.module_utils
    assert ansible.module_utils.six.PY3 == PY3
    assert ansible.module_utils.six.string_types == string_types
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeUrl
    from ansible.module_utils.urls import ConnectionInfo
    import base

# Generated at 2022-06-20 15:49:12.151660
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils import basic

    if hasattr(basic.AnsibleModule, 'from_json'):
        # Moved to collections_loader in 2.10
        from ansible.module_utils.basic import AnsibleModule
    else:
        from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.text.converters import to_unicode
    import collections

    parts = collections.namedtuple('parts', ['app_type', 'module_args', 'aliases', 'supports_check_mode'])

    module_args = dict(test='test')

# Generated at 2022-06-20 15:49:20.025686
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    vault_secret = VaultLib([])

# Generated at 2022-06-20 15:49:31.239532
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import to_raw
    # Test the method iterencode of class AnsibleJSONEncoder
    value = [to_raw('VaultedPassword')]
    AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(value)
    # Test the method iterencode of class AnsibleJSONEncoder
    value = [to_raw('VaultedPassword')]
    AnsibleJSONEncoder(preprocess_unsafe=False).iterencode(value)
    # Test the method iterencode of class AnsibleJSONEncoder
    value = to_raw('VaultedPassword')
    AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(value)
    # Test the method iterencode of class AnsibleJSONEncoder
    value = to_raw

# Generated at 2022-06-20 15:49:42.089503
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    class DummyEncrypted(str):
        __ENCRYPTED__ = True

    class DummyUnsafe(str):
        __UNSAFE__ = True

    class Dummy:
        pass


# Generated at 2022-06-20 15:49:54.396488
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.basic import AnsibleUnsafe

    safe_str = "safe_str"
    unsafe_str = AnsibleUnsafe("unsafe_str")
    ansible_unsafe_dict = dict(test_unsafe_list = AnsibleUnsafe([safe_str, unsafe_str]))
    ansible_safe_dict = dict(test_unsafe_list = [safe_str])
    ansible_bool_dict = dict(test_bool_list = BOOLEANS)

    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    ansible_unsafe_dict_json = json.dumps(ansible_unsafe_dict, cls=json_encoder)
   

# Generated at 2022-06-20 15:50:12.175446
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Obj(object):
        def __init__(self, foo='bar'):
            self.foo = foo

    class Unsafe(str):
        __UNSAFE__ = True

    class Vault(str):
        __ENCRYPTED__ = True

    class Date(datetime.date):
        def __init__(self, foo='bar'):
            self.foo = foo

    class Datetime(datetime.datetime):
        def __init__(self, foo='bar'):
            self.foo = foo

    assert AnsibleJSONEncoder().default(Obj()) == {'foo': 'bar'}
    assert AnsibleJSONEncoder().default(Unsafe('test')) == {'__ansible_unsafe': 'test'}

# Generated at 2022-06-20 15:50:21.879216
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import io
    import sys
    import unittest
    from ansible.module_utils.common.safe_eval import ansible_safe_eval

    class TestAnsibleJSONEncoder(unittest.TestCase):

        def test_json_output(self):

            test_data = [
                b'{"test": "\\u0026"}'
            ]

            test_object = ansible_safe_eval(test_data[0])

            class Test(object):
                foo = 1

            test_object = {
                'test': Test,
                'test1': b'\x20',
                'test2': 1,
                'test3': [],
                'test4': {}
            }

            json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-20 15:50:24.670921
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    result = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert isinstance(result, json.JSONEncoder)


# Generated at 2022-06-20 15:50:33.302262
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''Unittest tests iterencode method of AnsibleJSONEncoder '''
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe, wrap_var
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder._preprocess_unsafe = True
    ansible_json_encoder._vault_to_text = False

    # Test with vault object
    vault_object = VaultLib('a test vault password')
    encrypted_password = vault_object.encrypt('my_password')
    encrypted_dictionary = {'password': encrypted_password}
    result = ansible_json_encoder.iterencode(encrypted_dictionary)
    result = list(result)  # Convert generator to list to make it compatible

# Generated at 2022-06-20 15:50:44.590567
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    import sys
    if sys.version_info < (2, 7):
        # Python 2.6 or less
        return False

# Generated at 2022-06-20 15:50:49.257390
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Using old-style classes for Python 2.6 compatibility.
    # pylint: disable=too-few-public-methods
    class Foo:
        def __init__(self, val):
            self.val = val

    assert '"value"' == AnsibleJSONEncoder().encode(Foo('value'))

# Generated at 2022-06-20 15:50:50.891529
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        AnsibleJSONEncoder()
    except Exception as e:
        raise AssertionError("AnsibleJSONEncoder() raised exception unexpectedly: %s" % repr(e))

# Generated at 2022-06-20 15:50:55.706835
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('abc') == 'abc'
    assert AnsibleJSONEncoder().default(b'abc') == 'abc'
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()

# Generated at 2022-06-20 15:51:07.551941
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    test method default of class AnsibleJSONEncoder
    '''
    from ansible.module_utils.six import string_types
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    test_data = [
        (u'uni', u'uni'),
        (b'bytestr', b'bytestr'),
        (AnsibleUnsafeText(u'Unsafe'), {'__ansible_unsafe': u'Unsafe'}),
        (AnsibleUnsafeText(u'Unsafe'), {'__ansible_unsafe': u'Unsafe'}),
        (datetime.datetime.now(), '2018-11-29T09:54:22.912295')
    ]

    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:51:11.987940
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert aje._preprocess_unsafe is True
    assert aje._vault_to_text is True


# Generated at 2022-06-20 15:51:39.642204
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.module_utils.six.moves import cStringIO as StringIO

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    data = [
        {'string': 'string'},
        {'text': AnsibleUnsafeText(u'abc')}
    ]
    assert list(encoder.iterencode(data)) == ['[{"string": "string"}, {"text": {"__ansible_unsafe": "abc"}}]']

    # test unicode

# Generated at 2022-06-20 15:51:47.078591
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    o = _preprocess_unsafe_encode({'a': [b'un', b'unsafe', 'safe'], 'b': {'c': b'unsafe'}})
    expected = (
        '{'
        '"a":'
            '['
                '{'
                    '"__ansible_unsafe": "un"'
                '},'
                '{'
                    '"__ansible_unsafe": "unsafe"'
                '},'
                '"safe"'
            '],'
        '"b":'
            '{'
                '"c":'
                    '{'
                        '"__ansible_unsafe": "unsafe"'
                    '}'
            '}'
        '}'
    )

# Generated at 2022-06-20 15:51:50.415478
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert enc._preprocess_unsafe is True
    assert enc._vault_to_text is True

# Generated at 2022-06-20 15:51:57.668713
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False

    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=False)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=False)._vault_to_text == False

    assert AnsibleJSONEncoder(vault_to_text=True)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(vault_to_text=False)._preprocess_unsafe == False

# Generated at 2022-06-20 15:52:00.126799
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    text_value = AnsibleJSONEncoder().default("some text")
    assert text_value == "some text"



# Generated at 2022-06-20 15:52:09.465178
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test that vault is of expected type
    # Initially, vault_to_text is false so __ansible_vault should be an object and not a string
    encoder_vault_false = AnsibleJSONEncoder(vault_to_text=False)
    vault_ciphertext = encoder_vault_false.default(AnsibleVaultEncryptedUnicode(u'vault test'))
    assert isinstance(vault_ciphertext, dict)
    assert isinstance(vault_ciphertext['__ansible_vault'], unicode)
    # Test that vault is of expected type, when vault_to_text is true it should return a string
    encoder_vault_true = AnsibleJSONEncoder(vault_to_text=True)
    vault_ciphertext = encoder_vault_

# Generated at 2022-06-20 15:52:20.942256
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import io
    import unittest
    import ansible.module_utils.basic

    class AnsibleUnsafe(ansible.module_utils.basic.AnsibleUnsafe):
        pass

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def test_AnsibleJSONEncoder_iterencode_unsafe(self):
            output = io.BytesIO()
            json_encoder = AnsibleJSONEncoder()
            plain_text = '[{"a": "1", "b": "2"}]'
            plain_text_json = json.loads(plain_text)
            unsafe_text = '[{"a": AnsibleUnsafe("1"), "b": AnsibleUnsafe("2")}]'
            unsafe_text_json = json.loads(unsafe_text)
            unsafe_text_

# Generated at 2022-06-20 15:52:23.516138
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, indent=2, separators=(',', ': '))
    return encoder

# Generated at 2022-06-20 15:52:33.656226
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test for constructor of class AnsibleJSONEncoder
    # we test the constructor by creating instance of the class with no parameter
    # and test that the value of the attributes is set correctly
    aj = AnsibleJSONEncoder()
    assert aj._preprocess_unsafe == False
    assert aj._vault_to_text == False
    assert aj.check_circular == True
    assert aj.ensure_ascii == True
    assert aj.indent == None
    assert aj.key_separator == ':'
    assert aj.sort_keys == False
    assert aj.skipkeys == False
    assert aj.allow_nan == True
    assert aj.__getstate__() == (None, None, None, None, None, None, None, None)
    # test that the code in the

# Generated at 2022-06-20 15:52:45.417401
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestDef(object):
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return self.name
        def __json__(self):
            return self.name

    test_dict = {
        'test_list': [1, 'string', None, True, None, False],
        'test_dict': {
            'a': 'test_string',
            'b': 1,
            'c': None,
            'd': True,
            'e': False,
            'f': TestDef('TestDef'),
        }
    }


# Generated at 2022-06-20 15:53:27.771594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from unittest import TestCase
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib

    class TestClass(object):
        def __init__(self, value):
            self.value = value

    class TestVault(object):
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

        def __repr__(self):
            return '<vault: %s>' % self._ciphertext

    class TestUnsafe(unicode):
        __UNSAFE__ = True

    class TestAnsibleUnsafe(unicode):
        __UNSAFE__ = True

    class TestAnsibleVault(unicode):
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:53:32.247171
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test constructor
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(vault_to_text=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)



# Generated at 2022-06-20 15:53:39.149493
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common._collections_compat import Sequence

    encoder = AnsibleJSONEncoder()

    input_data = {b'a': VaultSecret('$ANSIBLE_VAULT;1.1;AES256\nblahblahblah')}
    expected_data = {'a': {'__ansible_vault': b'$ANSIBLE_VAULT;1.1;AES256\nblahblahblah'}}
    output_data = json.loads(b''.join(encoder.iterencode(input_data)))
    assert expected_data == output_data, 'invalid encoding'

    input_data = {b'a': Sequence()}
   

# Generated at 2022-06-20 15:53:43.558752
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    cls = AnsibleJSONEncoder()
    assert cls._preprocess_unsafe == False
    assert cls._vault_to_text == False

    cls = AnsibleJSONEncoder(True, True)
    assert cls._preprocess_unsafe == True
    assert cls._vault_to_text == True


# Generated at 2022-06-20 15:53:44.882299
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder is not None


# Generated at 2022-06-20 15:53:48.885229
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.collections import ImmutableDict

    a = b'UnsafeValue'
    b = ImmutableDict({"param1": 1, "param2": 2})
    c = datetime.date(2019, 1, 1)

    data = [a, b, c]
    for item in data:
        encode_result = AnsibleJSONEncoder().default(item)
        assert isinstance(encode_result, object)

# Generated at 2022-06-20 15:53:56.121421
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    inputs = [
        {
            "string": "string",
            "int": 1,
            "list": [1, 2, 3, 4],
            "dict": {
                "key": "value"
            },
            "date": datetime.datetime(2018, 1, 1, 12, 0, 0, 0),
        }
    ]
    data = json.dumps(inputs, cls=AnsibleJSONEncoder)
    result = {
        "string": "string",
        "int": 1,
        "list": [1, 2, 3, 4],
        "dict": {
            "key": "value"
        },
        "date": "2018-01-01T12:00:00"
    }
    assert json.loads(data) == result

# Generated at 2022-06-20 15:54:04.671526
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.unsafe_proxy import wrap_var

    # Ensure iterencode method exists and correct class
    assert isinstance(AnsibleJSONEncoder.iterencode, object)

    # Check that basic string types are handled correctly
    # Bytes
    assert list(AnsibleJSONEncoder().iterencode(b'bString')) == [b'bString']
    # Text
    assert list(AnsibleJSONEncoder().iterencode(u'uString')) == [u'uString']