

# Generated at 2022-06-20 15:44:12.301386
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_data = { 'test': 'test' }
    ansible_json_encoder = AnsibleJSONEncoder()
    assert { 'test': 'test' } == ansible_json_encoder.default(json_data)
    assert { '__ansible_vault': 'vault' } == ansible_json_encoder.default(dict(__ENCRYPTED__=True, _ciphertext='vault'))
    assert '2019-04-27T14:54:59.011723' == ansible_json_encoder.default(datetime.datetime(2019, 4, 27, 14, 54, 59, 11723))

# Uncomment the below code to run the unit test.
# if __name__ == '__main__':
#     test_AnsibleJSONEncoder_default()

# Generated at 2022-06-20 15:44:13.415219
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder() is not None

# Generated at 2022-06-20 15:44:25.734927
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    E = AnsibleJSONEncoder
    e = E()

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeBytes

    s = E(preprocess_unsafe=True).encode(AnsibleUnsafeText(b'text'))
    assert s == b'{"__ansible_unsafe": "b\'text\'"}'

    s = E(preprocess_unsafe=True).encode(AnsibleUnsafeBytes(b'bytes'))
    assert s == b'{"__ansible_unsafe": "b\'bytes\'"}'

    v1 = VaultLib(b'password')
    s = E(vault_to_text=True).en

# Generated at 2022-06-20 15:44:35.738665
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    encoded_vars = {
        'normal_str': 'Foo',
        'unsafe_str': AnsibleUnsafe('Bar'),
        'normal_dict': {
            'k1': 'Value1',
            'k2': 'Value2',
            'k3': AnsibleUnsafe('Value3')
        }
    }

    # Set expected output after default processing
    expected_output = {
        'normal_str': 'Foo',
        'unsafe_str': AnsibleUnsafe('Bar'),
        'normal_dict': {
            'k1': 'Value1',
            'k2': 'Value2',
            'k3': {
                '__ansible_unsafe': 'Value3'
            }
        }
    }

# Generated at 2022-06-20 15:44:41.041382
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._text import to_native
    from ansible.module_utils.common.collections import (
        is_sequence,
    )
    from ansible.module_utils.common.text.converters import (
        to_bytes,
    )
    from ansible.parsing.vault import VaultLib
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import (
        to_list,
    )

    encoder = AnsibleJSONEncoder()

    ansible_str = '#secure password'
    encoded_str = next(encoder.iterencode(ansible_str))
    assert encoded_str == to_native(to_bytes(ansible_str))


# Generated at 2022-06-20 15:44:48.542942
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) == None
    assert encoder.default(1) == 1
    assert encoder.default(1.23) == 1.23
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert encoder.default('string') == 'string'

# Generated at 2022-06-20 15:45:00.397072
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.parsing.convert_bool import boolean
    import datetime
    import jinja2.runtime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText, AnsibleUnsafeBytes
    import ansible.utils.unsafe_proxy


# Generated at 2022-06-20 15:45:10.543214
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    # create a simple dict containing different type of string
    obj = {}
    obj['ansible_safe_text'] = 'ansible_safe_text'
    obj['ansible_unsafe_text'] = ansible.module_utils.basic.AnsibleUnsafeText('ansible_unsafe_text')
    obj['ansible_vault_text'] = ansible.module_utils.basic.AnsibleVaultEncryptedUnicode('ansible_vault_text')


# Generated at 2022-06-20 15:45:13.320174
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default('foo') == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default({'foo': 1}) == {'foo': 1}

# Generated at 2022-06-20 15:45:25.277664
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, to_unsafe_text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes, to_bytes

    a_str = 'abc'
    a_str_unsafe_text = to_unsafe_text(a_str)
    a_str_unsafe_bytes = to_bytes(a_str, encoding='utf-8')
    a_str_vault = AnsibleUnsafeText('abc', vault_secret='vault_secret')
    a_str_unsafe_text_vault = AnsibleUnsafeText('abc', vault_secret='vault_secret', unsafe=True)
    a_str_unsafe_bytes_vault = AnsibleUnsafeBytes('abc', vault_secret='vault_secret', unsafe=True)

# Generated at 2022-06-20 15:45:29.438442
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder is not None

# Generated at 2022-06-20 15:45:40.673542
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six.moves.queue import Queue
    from ansible.module_utils.six import b
    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import String
    from ansible.module_utils.urls import open_url, urlparse

    q = Queue()
    expected = '{"s": "a string"}'
    _AnsibleJSONEncoder = AnsibleJSONEncoder()
    _encode = _AnsibleJSONEncoder.iterencode({"s": "a string"}, **{"ensure_ascii":True, "indent": None})
    for v in _encode:
        q.put(v)
    result = q.get()
    assert result == expected


# Generated at 2022-06-20 15:45:51.243824
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils import basic
    import json
    import string
    import random

    n = 100  # number of elements to generate
    # generate a list of dictionaries
    l = [{''.join(random.choice(string.ascii_uppercase) for _ in range(10)):
        random.randint(0, 100)} for x in range(n)]

    # Attempt to encode the list
    try:
        json.dumps(l, cls=AnsibleJSONEncoder)
    except TypeError as e:
        assert(False and "Unexpected TypeError: {}".format(e))

    # Create some AnsibleUnsafe objects
    len_ansi, len_safe = 10, 20

# Generated at 2022-06-20 15:45:53.372058
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansiblejsonencoder = AnsibleJSONEncoder()
    assert isinstance(ansiblejsonencoder, AnsibleJSONEncoder)

# Generated at 2022-06-20 15:46:03.073004
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys

    # Encoding an AnsibleUnsafe value.
    # Expected: A dict with a single key and value pair ('__ansible_unsafe', String representation of the AnsibleUnsafe value).
    ansible_unsafe = 'super secure string'
    ansible_unsafe.__UNSAFE__ = True
    ansible_unsafe.__ENCRYPTED__ = False
    print(json.dumps(ansible_unsafe, cls=AnsibleJSONEncoder))
    assert json.loads(json.dumps(ansible_unsafe, cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': to_text(ansible_unsafe, errors='surrogate_or_strict', nonstring='strict')}

    # Encoding an AnsibleVault value.
    #

# Generated at 2022-06-20 15:46:06.155327
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    val_a = AnsibleJSONEncoder()
    val_b = AnsibleJSONEncoder(preprocess_unsafe=True)
    val_c = AnsibleJSONEncoder(vault_to_text=True)
    val_d = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    assert(val_d._preprocess_unsafe == True)
    assert(val_d._vault_to_text == True)

# Generated at 2022-06-20 15:46:16.143087
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Foo: pass
    f = Foo()
    f.bar = 'baz'

    ansible_encoder = AnsibleJSONEncoder()

    # test for dict
    dict1 = dict()
    dict2 = dict(foo='foo')
    dict3 = dict(bar=f)

    assert ansible_encoder.default(dict1) == dict1
    assert ansible_encoder.default(dict2) == dict2
    assert ansible_encoder.default(dict3) == dict(bar='baz')

    # test for datetime
    datetime1 = datetime.datetime.now()
    assert ansible_encoder.default(datetime1) == datetime1.isoformat()

    # test for normal object

# Generated at 2022-06-20 15:46:26.745176
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    ciphertext_input = '$ANSIBLE_VAULT;1.1;AES256\n63613162333435363837346532306533316666613733336565353735376539663063323661356365\n61313665623231616537303931643265343733303537626563300a66346332383862376136613833\n35613464336138343830633234633235346631366539663838616366663930623131663037313264\n613238623338323031373937320a'
    vault = VaultLib(VaultLib.AES256)
   

# Generated at 2022-06-20 15:46:34.109169
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''
    Tests that the optional arg preprocess_unsafe=True
    of AnsibleJSONEncoder is respected.
    '''
    # Test of type AnsibleUnsafe
    value = {'__ansible_unsafe': to_text('my_value', errors='surrogate_or_strict', nonstring='strict')}
    assert value == AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(u'!unsafe my_value')

    # Test of type basestring
    assert u'unsafe my_value' == AnsibleJSONEncoder().iterencode(u'unsafe my_value')

# Generated at 2022-06-20 15:46:36.137835
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    print("Test: construct an AnsibleJSONEncoder object")
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)



# Generated at 2022-06-20 15:46:48.276781
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.six import text_type


# Generated at 2022-06-20 15:46:50.355667
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_json_encoder._preprocess_unsafe

# Generated at 2022-06-20 15:47:00.541038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test the AnsibleJSONEncoder class"""
    import string
    import random

    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True

    class AnsibleVault(unicode):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    def randomstring(length):
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(length))

    obj_unsafe = AnsibleUnsafe(randomstring(10))
    obj_vault = AnsibleVault(randomstring(10))
    obj_mapping = {obj_unsafe: [obj_vault, obj_vault]}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert enc

# Generated at 2022-06-20 15:47:03.107603
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder._preprocess_unsafe is False
    assert ansible_json_encoder._vault_to_text is False



# Generated at 2022-06-20 15:47:15.406992
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    # Test initialisation
    assert encoder._preprocess_unsafe == True

    # Test string
    s = 'hello'
    assert list(encoder.iterencode(s)) == ['"hello"']

    # Test integer
    i = -1
    assert list(encoder.iterencode(i)) == ['-1']

    # Test long integer

# Generated at 2022-06-20 15:47:24.630476
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    myvault = VaultLib()
    password = 'secret'
    myvault.update(password=password)
    text = u'this is a test'
    ciphertext = myvault.encrypt(text)
    vault = myvault.decrypt(ciphertext)
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert to_text(json.dumps(vault, cls=encoder)) == text
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert to_text(json.dumps(vault, cls=encoder)) == '{"__ansible_vault": "' + ciphertext + '"}'

# Generated at 2022-06-20 15:47:36.566348
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()

    assert encoder.default({"foo":"bar"}) == {"foo":"bar"}
    assert encoder.default(["foo","bar"]) == ["foo","bar"]

    unsafe_str = AnsibleUnsafe("unsafe")
    assert encoder.default(unsafe_str) == {'__ansible_unsafe': 'unsafe'}

    # TODO: This seems to work now, but it's not tested in the base class
    vault = VaultLib([])

# Generated at 2022-06-20 15:47:40.472172
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.encode({'unknown_object': [1, 2, 3]}) == '{"unknown_object": [1, 2, 3]}'



# Generated at 2022-06-20 15:47:44.396309
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class A(str):
        __UNSAFE__ = True

    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode([A('test')])) == \
        ['[{"__ansible_unsafe": "test"}]']

# Generated at 2022-06-20 15:47:53.341694
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create instance of class AnsibleJSONEncoder with default values
    ansible_json_encoder_obj = AnsibleJSONEncoder()

    # Check if the class name is AnsibleJSONEncoder
    assert ansible_json_encoder_obj.__class__.__name__ == "AnsibleJSONEncoder"

    # Create instance of class AnsibleJSONEncoder with default values
    ansible_json_encoder_obj = AnsibleJSONEncoder(indent=4, separators=(',', ': '))

    # Check the values of arguments
    assert ansible_json_encoder_obj.indent == 4
    assert ansible_json_encoder_obj.separators == (',', ': ')


# Generated at 2022-06-20 15:48:05.449166
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.urls import UnsafeProxyString
    from ansible.module_utils.six import text_type
    import sys
    if sys.version_info > (3, 0):
        assert(list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode({'non-unsafe': 'value1',
                                                                           'unsafe': UnsafeProxyString('unsafe-value')})) ==
               [b'{"non-unsafe": "value1", "unsafe": {"__ansible_unsafe": "unsafe-value"}}'])

# Generated at 2022-06-20 15:48:16.715921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # empty string
    o = ""
    assert AnsibleJSONEncoder().default(o) == o

    # empty list
    o = []
    assert AnsibleJSONEncoder().default(o) == o

    # dict
    o = dict()
    assert AnsibleJSONEncoder().default(o) == o

    # empty set
    o = set()
    assert AnsibleJSONEncoder().default(o) == o

    # boolean
    o = True
    assert AnsibleJSONEncoder().default(o) == o

    # None
    o = None
    assert AnsibleJSONEncoder().default(o) == o

    # int
    o = 1
    assert AnsibleJSONEncoder().default(o) == o

    # float
    o = 1.0
    assert AnsibleJSONEncoder().default(o) == o



# Generated at 2022-06-20 15:48:28.264419
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Testing __ENCRYPTED__ functionality
    test_dict = {
        AnsibleUnsafeText('my_unsafe_secret'): 'my_secret',
        'my_safe_secret': AnsibleUnsafeText('my_safe_secret'),
        'my_vault': AnsibleUnsafeText('my_vault_secret', encrypt=True),
    }

    json_data_expect = {
        'my_unsafe_secret': {'__ansible_unsafe': 'my_secret'},
        'my_safe_secret': {'__ansible_unsafe': 'my_safe_secret'},
        'my_vault': {'__ansible_vault': 'my_vault_secret'},
    }

   

# Generated at 2022-06-20 15:48:39.254601
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultSecret
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    assert list(encoder.iterencode(AnsibleUnsafeText('{ "a": "b" }'))) == ['{ "a": "b" }']
    assert list(encoder.iterencode(AnsibleUnsafeBytes(b'{ "a": "b" }')))

# Generated at 2022-06-20 15:48:49.265448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert {'a' : 1} == json.loads(json.dumps({'a' : 1}, cls=AnsibleJSONEncoder))
    assert {'a' : '1'} == json.loads(json.dumps({'a' : '1'}, cls=AnsibleJSONEncoder))
    assert {'a' : '1'} == json.loads(json.dumps({'a' : 1.1}, cls=AnsibleJSONEncoder))
    assert {'a' : '1'} == json.loads(json.dumps({'a' : True}, cls=AnsibleJSONEncoder))
    assert {'a' : []} == json.loads(json.dumps({'a' : []}, cls=AnsibleJSONEncoder))
    assert {'a' : {}}

# Generated at 2022-06-20 15:48:53.003784
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_class = AnsibleJSONEncoder()
    assert test_class.default('a') == 'a'


# Generated at 2022-06-20 15:48:58.473717
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3, text_type, string_types
    from ansible.module_utils.six import iteritems

    encoded_dict_1 = b'{"a": 1, "b": 2, "c": 3}'
    encoded_dict_2 = b'{"a": 1, "b": 2, "c": {"e": 4, "f": 5, "g": 6, "h": {"j": 7, "k": 8, "l": 9}}}'

# Generated at 2022-06-20 15:49:08.415727
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # inputs
    class Unsafe:
        def __init__(self, value):
            self.value = value
        def __UNSAFE__(self):
            return True
        def __str__(self):
            return self.value

    class Encrypted:
        def __init__(self, value):
            self.value = value
        def __ENCRYPTED__(self):
            return True
        def __str__(self):
            return self.value

    class HostVars(dict):
        def __init__(self, **kwargs):
            super(HostVars, self).__init__(**kwargs)


# Generated at 2022-06-20 15:49:14.934193
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansibleJsonEncoder = AnsibleJSONEncoder()
    assert (ansibleJsonEncoder._preprocess_unsafe == False)
    assert (ansibleJsonEncoder._vault_to_text == False)
    ansibleJsonEncoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert (ansibleJsonEncoder._preprocess_unsafe == True)
    assert (ansibleJsonEncoder._vault_to_text == True)



# Generated at 2022-06-20 15:49:20.284430
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """test_AnsibleJSONEncoder_default
    Test for method default of class AnsibleJSONEncoder.
    """
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    aje = AnsibleJSONEncoder()
    assert aje.default(AnsibleUnsafe('unsafe_value')) == "'unsafe_value'"
    assert aje.default(AnsibleUnsafe(b'unsafe_value')) == '"unsafe_value"'
    assert aje.default(AnsibleUnsafe(u'unsafe_value')) == '"unsafe_value"'


# Generated at 2022-06-20 15:49:32.307659
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(0) == 0
    assert AnsibleJSONEncoder().default(199) == 199
    assert AnsibleJSONEncoder().default(-199) == -199
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(-1.0) == -1.0
    assert AnsibleJSONEncoder().default(1.7) == 1.7
    assert AnsibleJSONEncoder().default(-1.7) == -1.7
    assert AnsibleJSONEncoder().default(1e7) == 1e7

# Generated at 2022-06-20 15:49:41.703954
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    raw_value = "hello"
    result = AnsibleJSONEncoder().encode(raw_value)
    print("It is for {0}, and result is {1}".format(raw_value, result))
    assert(result == "\"hello\"")

    class AnsibleUnsafe:
        __UNSAFE__ = True

    raw_value = AnsibleUnsafe()
    result = AnsibleJSONEncoder().encode(raw_value)
    print("It is for {0}, and result is {1}".format(raw_value, result))
    assert(result == "\"\\\\u0000\"")

if __name__ == "__main__":
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:49:44.908475
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    o = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert o


# Generated at 2022-06-20 15:49:55.035258
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:50:02.112346
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # get a json object from AWS module
    from ansible.module_utils.ec2 import ec2_argument_spec, HAS_BOTO3, camel_dict_to_snake_dict
    try:
        from botocore.exceptions import ClientError
    except ImportError:
        pass   # will be captured by imported HAS_BOTO3

    argument_spec = ec2_argument_spec()
    # add in the state argument, NOTE: not valid for use in AWS
    argument_spec.update(dict(
        region=dict(),
        vpc_id=dict(),
        profile=dict(),
        debug_botocore_endpoint_logs=dict(type='bool', default=False)
    ))

    ansible_module_instance = MagicMock()
    ansible_module_instance.params = {}
    tb

# Generated at 2022-06-20 15:50:12.051203
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.ajson import AnsibleUnsafe
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-20 15:50:21.760433
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultSecret
    stdout = StringIO()
    vault_password = VaultSecret("vault_password")
    vault = VaultLib(vault_password)
    vault_text = vault.encrypt("foo")
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder.indent = 2
    json.dump(AnsibleUnsafeText("foo bar"), stdout, indent=2, sort_keys=True, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 15:50:31.415634
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type, binary_type

    try:
        # Python >= 2.6
        from json.encoder import JSONEncoder
        from json.decoder import JSONDecoder
        encoder = JSONEncoder(sort_keys=True, ensure_ascii=True)
        decoder = JSONDecoder()
    except ImportError:
        from simplejson import encoder as JSONEncoder
        from simplejson import decoder as JSONDecoder
        encoder = JSONEncoder(sort_keys=True, ensure_ascii=True, encoding='UTF-8')
        decoder = JSONDecoder()


# Generated at 2022-06-20 15:50:37.308341
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 10, 11, 6, 15, 58, 412000)) == '2017-10-11T06:15:58.412000'
    assert AnsibleJSONEncoder().default(datetime.date(2017, 10, 11)) == '2017-10-11'



# Generated at 2022-06-20 15:50:48.498168
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import json_loads, to_bytes

    encoder = AnsibleJSONEncoder(vault_to_text=False, preprocess_unsafe=False)
    result = encoder.default('test')
    assert result == 'test'

    result = encoder.default(to_bytes('test'))
    assert result == 'test'

    from ansible.module_utils.common.text.converters import to_unicode
    result = encoder.default(to_unicode('test'))
    assert result == 'test'

    dt = datetime.datetime.now()
    result = encoder.default(dt)
    assert result == dt.isoformat()

    result = encoder.default({'test': 'value'})

# Generated at 2022-06-20 15:51:02.687145
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """Test checks that method iterencode skips string types and encodes other objects.
    Also checks if preprocess_unsafe=True, it encodes unsafe objects as they were normal strings.
    """
    # Arrange
    encoder = AnsibleJSONEncoder()
    o = [1, 'abc', AnsibleUnsafe(u'Unsafe'), {'a': AnsibleUnsafe(u'Unsafe')}, {'a': 'b'}]
    # Act
    unsafe_result = [1, 'abc', {u'__ansible_unsafe': u'Unsafe'}, {u'a': {u'__ansible_unsafe': u'Unsafe'}}, {'a': 'b'}]
    result = list(encoder.iterencode(o))
    # Assert

# Generated at 2022-06-20 15:51:08.776691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = datetime.datetime.now()

# Generated at 2022-06-20 15:51:21.478751
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test empty dictionary
    assert {} == json.loads(json.dumps({}))

    # Test simple dict
    assert {'key': 'value'} == json.loads(json.dumps({'key': 'value'}))

    # Test encoded AnsibleUnsafe object
    assert {'__ansible_unsafe': 'value'} == json.loads(json.dumps({'key': 'value'}, cls=AnsibleJSONEncoder, preprocess_unsafe=True))

    # Test encoded ansible_vault object
    assert {'__ansible_vault': 'value'} == json.loads(json.dumps({'key': 'value'}, cls=AnsibleJSONEncoder, vault_to_text=True))

    # Test encoded ansible_vault object with option

# Generated at 2022-06-20 15:51:30.695595
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.common.safe_eval as safe_eval
    import ansible.parsing.unsafe_proxy as unsafe_proxy

    # Create a dictionary
    d = {'key1': 1, 'key2': 2, 'key3': 3}

    # convert a python object to ansible unsafe object
    ansible_unsafe = unsafe_proxy.AnsibleUnsafeText(d, unsafe_proxy.UnsafeEvalContext(locals=safe_eval.__dict__))

    # It will throw a JSON encode error
    try:
        json.dumps(ansible_unsafe)
    except json.JSONEncodeError:
        pass

    # With the method AnsibleJSONEncoder.iterencode of class AnsibleJSONEncoder we can encode ansible unsafe object
    ansible_json_encoder = Ans

# Generated at 2022-06-20 15:51:42.217444
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:51:52.949815
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = [
        {
            "hostvars": {
                "host_name": {
                    "vars": {}
                }
            },
            "children": []
        },
        {
            "host_name": {
                "vars": {}
            }
        },
        {
            "vars": {}
        },
        datetime.datetime.now(),
        datetime.date.today(),
        [
            "host1",
            "host2",
        ]
    ]

    for test_val in test_data:
        AnsibleJSONEncoder().default(test_val)

# Generated at 2022-06-20 15:52:04.199090
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    import datetime

    now = datetime.datetime.now()
    data = {
        'string': 'foo',
        'unsafe': AnsibleUnsafe('bar'),
        'list': [
            'baz',
            AnsibleUnsafe('qux')
        ],
        'mapping': {
            'num': 42,
            'unsafe': AnsibleUnsafe('string')
        },
        'date': now
    }


# Generated at 2022-06-20 15:52:11.638080
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # test unsafe object
    from ansible.module_utils.common.text.converters import to_unsafe
    unsafe_obj = to_unsafe('unsafe string')
    result = encoder.default(unsafe_obj)
    assert isinstance(result, dict)
    assert '__ansible_unsafe' in result
    assert result['__ansible_unsafe'] == 'unsafe string'

    # test vault object
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('ansible')
    vault_obj = vault.encrypt('vault string')
    result = encoder.default(vault_obj)
    assert isinstance(result, dict)
    assert '__ansible_vault' in result

# Generated at 2022-06-20 15:52:23.345820
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {
        'x': "abc",
        'y': ['def', 1, 2.0],
        'z': {'a': 'b', 'c': 3},
        'w': u'unicode',
        'v': object(),
        'u': {'__ansible_unsafe': 'test'},
    }

    # constructor with valid parameter: preprocess_unsafe
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder._preprocess_unsafe == True

    # constructor with valid parameter: vault_to_text
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder._vault_to_text == True

    # constructor with invalid parameter, but no failure
    encoder = AnsibleJSONEncoder(test=True)

# Generated at 2022-06-20 15:52:32.543906
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe_plain_json = '''{"unsafe": "value"}
    '''
    unsafe_json = '''{"unsafe": {"__ansible_unsafe": "value"}}
    '''
    json_dumps = json.dumps
    json_loads = json.loads
    try:
        json.dumps = json.JSONEncoder().encode
        json.loads = json.JSONDecoder().decode
        assert json.dumps(json.loads(unsafe_plain_json)) == unsafe_plain_json
        assert json.dumps(json.loads(unsafe_json)) == unsafe_json
    finally:
        json.dumps = json_dumps
        json.loads = json_loads

# Generated at 2022-06-20 15:52:50.701041
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    pass
    #for testing:
    #from ansible.parsing.vault import VaultLib
    #v = VaultLib('foo')
    #print(json.dumps('hello world'))
    #print(json.dumps(v))
    #print(json.dumps(v, cls=AnsibleJSONEncoder))
    #print(json.dumps(v, cls=AnsibleJSONEncoder, preprocess_unsafe=True))
    #print(json.dumps(v, cls=AnsibleJSONEncoder, preprocess_unsafe=True, vault_to_text=True))

if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:52:51.752754
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    pass



# Generated at 2022-06-20 15:52:55.335930
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()

    assert callable(obj.default)
    assert callable(obj.iterencode)

    assert obj._preprocess_unsafe == False
    assert obj._vault_to_text == False


# Generated at 2022-06-20 15:53:07.923370
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    def isequal(a, b):
        return a == b

    obj = AnsibleJSONEncoder()
    # test on a string
    ans1 = b'"test"'
    ans2 = obj.encode("test")
    assert isequal(ans1, ans2)
    # test on a list
    ans1 = b'[1, 2, 3]'
    ans2 = obj.encode([1, 2, 3])
    assert isequal(ans1, ans2)
    # test on a dictionary
    ans1 = b'{"a": 2, "b": 4}'
    ans2 = obj.encode({"a": 2, "b": 4})
    assert isequal(ans1, ans2)
    # test on an empty dictionary
    ans1 = b'{}'

# Generated at 2022-06-20 15:53:19.774687
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    from ansible.parsing.vault import VaultLib

    class DummyVault(VaultLib):
        def __init__(self, password=None, context=None):
            self._password = password
            self._context = context
            self._ciphertext = b'$ANSIBLE_VAULT;1.1;AES'

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleEncryptedUnsafe(str):
        """AnsibleUnsafe subclasses cannot be encrypted as they don't support the vault API"""
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class AnsibleEncryptedSafe(VaultLib):
        """Non AnsibleUnsafe subclasses can be encrypted as they do support the vault API"""
        __ENCR

# Generated at 2022-06-20 15:53:30.996617
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    import io
    import json
    import sys
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.encoder = AnsibleJSONEncoder(
                indent=4,
                separators=(',', ': '),
                preprocess_unsafe=True,
                vault_to_text=True,
            )
            self.json_str = ""


# Generated at 2022-06-20 15:53:41.872252
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import UnsafeProxy

    plain_text = """
plain text
..........
.....

"""
    plain_text_json = '''
"plain text
..........
....."
'''
    unsafe_text = UnsafeProxy(plain_text)
    unsafe_text_json = '''
{
  "__ansible_unsafe": "plain text
..........
....."
}
'''

    plain_text_vault = VaultLib().encrypt(plain_text)

# Generated at 2022-06-20 15:53:52.960009
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import b
    from ansible.module_utils.common._collections_compat import Mapping

    from datetime import datetime, date

    tests = []
    # test 1
    a = AnsibleJSONEncoder()
    tests.append((a.default(VaultSecret(b('abcd'))),
                  {'__ansible_vault': b'abcd'}))

    # test 2
    a = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-20 15:54:03.868323
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert json_encoder.default(None) == None
    assert json_encoder.default({}) == {}
    assert json_encoder.default('test') == 'test'
    assert json_encoder.default(datetime.datetime(2020, 9, 1, 4, 4, 2)) == '2020-09-01T04:04:02'
    assert json_encoder.default(datetime.date(2020, 9, 1)) == '2020-09-01'
    assert json_encoder.default({'k1':'v1', 'k2': 'v2'}) == {'k1':'v1', 'k2': 'v2'}

    # for __ansible_vault
    json_encoder = Ansible