

# Generated at 2022-06-20 15:44:12.786149
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    # Example vault string

# Generated at 2022-06-20 15:44:18.792613
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import PY3

    test_object = AnsibleJSONEncoder(test=True)
    assert isinstance(test_object,ansible.module_utils.json_utils.AnsibleJSONEncoder)
    if PY3:
        assert isinstance(test_object, json.JSONEncoder)



# Generated at 2022-06-20 15:44:28.891206
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest

    class TestSSLObject:
        def __init__(self, key):
            self.key = key
            self.__UNSAFE__ = True

    # Test 1: iterencode, o is a dictionary
    o = {'test_key': [{b'\xf1', TestSSLObject('test_value')}]}
    json_iter = list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o))
    # Only one element, [{'test_key': [{'__ansible_unsafe': '\xed\xb1\x8d', '__ansible_unsafe': 'test_value'}]}]
    assert len(json_iter) == 1

    # Test 2: iterencode, o is a tuple

# Generated at 2022-06-20 15:44:32.290035
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_class = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert test_class._preprocess_unsafe == False
    assert test_class._vault_to_text == False


# Generated at 2022-06-20 15:44:43.298890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.risky import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    # assert for AnsibleUnsafe object
    test_encoder = AnsibleJSONEncoder()
    assert test_encoder.default(AnsibleUnsafe(u'unicode')) == {'__ansible_unsafe': u'unicode'}
    assert test_encoder.default(AnsibleUnsafe(b'bytestring')) == {'__ansible_unsafe': u'bytestring'}

    # assert for boolean value
    for true_value in BOOLEANS_TRUE:
        assert test_encoder.default(true_value) is True
    assert test_encoder.default(False) is False

# Unit

# Generated at 2022-06-20 15:44:54.217462
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.collections import ImmutableDict
    import json
    import unittest

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def test_AnsibleJSONEncoder_encodes_UnsafeText_correctly(self):
            data = {'unsecure': AnsibleUnsafeText('unsafe'), 'secure': 'safe'}
            encoder = AnsibleJSONEncoder()
            buf = []
            json_data = ImmutableDict(json.loads(to_text(encoder.iterencode(data, callback=buf.append))))
            # check if unsafe_proxy was encoded to __ansible

# Generated at 2022-06-20 15:44:57.366990
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe is False
    assert encoder._vault_to_text is False

    encoder2 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder2._preprocess_unsafe is True
    assert encoder2._vault_to_text is True


# Generated at 2022-06-20 15:45:05.835412
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    vault_password = 'secret'
    vault = VaultLib([vault_password])

# Generated at 2022-06-20 15:45:14.509562
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    '''test_AnsibleJSONEncoder is used for test AnsibleJSONEncoder'''
    # test basic behavior
    test_one = AnsibleJSONEncoder()
    result_one = test_one.default("abcde")
    assert result_one == "abcde"
    # test datetime behavior
    test_two = AnsibleJSONEncoder()
    test_two_date = datetime.date(2019, 11, 25)
    result_two = test_two.default(test_two_date)
    assert result_two == "2019-11-25"
    # test mapping behavior
    test_three = AnsibleJSONEncoder()
    dictionary = {"name": "Dictionary"}
    result_three = test_three.default(dictionary)
    assert result_three == {'name': 'Dictionary'}

# Generated at 2022-06-20 15:45:18.292391
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create json string
    ansible_json_data = AnsibleJSONEncoder().default(u'this is a string')
    assert json.dumps(ansible_json_data) == '"this is a string"'

# Generated at 2022-06-20 15:45:21.200434
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-20 15:45:26.182455
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = [{'no': 1, 'data': 'A', 'datetime': datetime.datetime.now(), 'date': datetime.date.today()}]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    encoded_data = json.dumps(data, cls=encoder)
    assert encoded_data == json.dumps(data)

# Generated at 2022-06-20 15:45:34.830928
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # dict with nested AnsibleUnsafe
    value = {'a': AnsibleUnsafe(u'foo')}
    assert AnsibleJSONEncoder().default(value) == {'a': u'foo'}

    # list with nested AnsibleVault
    value = [AnsibleVault('blah')]
    assert AnsibleJSONEncoder().default(value) == [{'__ansible_vault': 'blah'}]

# Generated at 2022-06-20 15:45:47.063048
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.urls import urlparse

    assert AnsibleJSONEncoder().default(b'foo') == to_text(b'foo')
    assert AnsibleJSONEncoder().default('foo') == to_text('foo')

    assert AnsibleJSONEncoder().default(urlparse('http://localhost')) == to_text('http://localhost')

    assert AnsibleJSONEncoder().default(u'foo') == u'foo'
    assert type(AnsibleJSONEncoder().default(u'foo')) is text_type

    assert json.loads(AnsibleJSONEncoder().encode(u'foo')) == u'foo'
    assert type(json.loads(AnsibleJSONEncoder().encode(u'foo'))) is text_type

# Generated at 2022-06-20 15:45:51.838607
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    test = {'a': '1', 'b': 2}
    test_json = b'{"a": "1", "b": 2}'
    out_json = AnsibleJSONEncoder().encode(test)
    if test_json != out_json:
        assert False
        #assert test_json == out_json, out_json
    return True

# Generated at 2022-06-20 15:46:01.889657
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    This function is used to test AnsibleJSONEncoder.default and
    if date objects are formatted correctly.
    '''

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

        def __new__(cls, v):
            return super(AnsibleUnsafe, cls).__new__(cls, v)

    class AnsibleVault(str):
        __ENCRYPTED__ = True

        def __new__(cls, v):
            return super(AnsibleVault, cls).__new__(cls, v)

    c = AnsibleJSONEncoder()
    assert isinstance(c.default(AnsibleUnsafe("unsafe")), dict)

# Generated at 2022-06-20 15:46:03.490098
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert(a)

# Generated at 2022-06-20 15:46:14.421065
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    data = {
        'a': '#!/bin/sh',
        'b': 'a',
        'c': 10,
        'd': ['a', 'b', 'c'],
        'e': {'a': 'b', 'c': 'd'},
    }
    expected = {
        'a': {'__ansible_unsafe': '#!/bin/sh'},
        'b': 'a',
        'c': 10,
        'd': ['a', 'b', 'c'],
        'e': {'a': 'b', 'c': 'd'},
    }
    # convert to unsafe
    for k in data:
        data[k] = AnsibleUnsafe(data[k])
    # encrypt a
    vault

# Generated at 2022-06-20 15:46:25.764105
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.connection._winrm import WINRMEncrypted

    data = {'awake': True}
    # assert that a straight dict gets returned
    assert data == AnsibleJSONEncoder().default(data)

    # assert that a normal string gets returned
    assert "foo" == AnsibleJSONEncoder().default("foo")

    # assert that a windows encrypted password is returned
    win_pass = WINRMEncrypted('password')
    assert win_pass == AnsibleJSONEncoder().default(win_pass)

    # assert that a vault encrypted password is returned
    vault_pass = VaultLib('password')
    assert vault_pass == AnsibleJSONEncoder().default(vault_pass)

    # assert that a vault encrypted password is returned
    # into a string when

# Generated at 2022-06-20 15:46:30.256571
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()
    assert obj.check_circular == True
    assert obj.ensure_ascii == True
    assert obj.indent == None
    assert obj.separators == (',', ':')
    assert obj.sort_keys == False


# Generated at 2022-06-20 15:46:39.826481
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test class initialization with valid and invalid arguments
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)._vault_to_text == True
    assert AnsibleJSONEncoder(preprocess_unsafe="hello", vault_to_text="world")._preprocess_uns

# Generated at 2022-06-20 15:46:49.383997
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    vault_setup = VaultLib(password='vault_pass')
    vault_text = vault_setup.encrypt('secret')

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)


# Generated at 2022-06-20 15:46:50.737307
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert(encoder is not None)


# Generated at 2022-06-20 15:46:56.685356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansible_json(preprocess_unsafe=False)
    assert ansible_json(preprocess_unsafe=True)
    assert ansible_json(preprocess_unsafe=True, vault_to_text=True)


# Generated at 2022-06-20 15:47:04.770843
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder)) == dict(a=1, b=2)
    assert json.loads(json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder), strict=False) == dict(a=1, b=2)
    assert json.loads(json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder, for_json=True)) == dict(a=1, b=2)
    assert json.loads(json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder, for_query=True)) == dict(a=1, b=2)


# Generated at 2022-06-20 15:47:16.585484
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    assert aje.default('test') == 'test'
    assert aje.default(True) is True
    assert aje.default(None) is None
    assert aje.default(b'bytes') == 'bytes'
    assert aje.default('test'.encode()) == 'test'
    assert aje.default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert aje.default([1, '2', b'3']) == [1, '2', '3']
    assert aje.default(datetime.date(1970, 1, 1)) == '1970-01-01'

# Generated at 2022-06-20 15:47:25.325672
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    # VaultSecret has a __UNSAFE__ attribute, not a __ENCRYPTED attribute
    value = VaultSecret('test')

    # when __ENCRYPTED__ is False, and __UNSAFE__ is True
    result = AnsibleJSONEncoder(preprocess_unsafe=False).default(value)
    assert isinstance(result, dict) and result == {'__ansible_unsafe': 'test'}

    # when __ENCRYPTED__ is False, and __UNSAFE__ is False
    result = AnsibleJSONEncoder(preprocess_unsafe=False).default('test')
    assert result == 'test'

    # when __ENCRYPTED__ is True
    value = VaultSecret('test').encrypt()
    result = Ansible

# Generated at 2022-06-20 15:47:33.371966
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class ansible_unsafe(object):
        __UNSAFE__ = True

    class ansible_vault(object):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    assert AnsibleJSONEncoder().default(ansible_unsafe('unsafe')) == {'__ansible_unsafe': 'unsafe'}
    assert AnsibleJSONEncoder().default(ansible_vault('vault')) == {'__ansible_vault': 'vault'}

# Generated at 2022-06-20 15:47:44.693959
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.basic import AnsibleUnsafe

    a = u'{"a": "ä"}'
    j = json.loads(a)

    assert a == to_native(a)
    assert isinstance(to_text(a), unicode)
    assert a == to_native(to_text(a))
    assert to_text(a) == AnsibleUnsafe(a)

    # TODO: replace with a appropriate mock when we don't support python 2.6 anymore

# Generated at 2022-06-20 15:47:47.856520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    assert encoder.default({'a': 'a'}) == {'a': 'a'}
    assert encoder.default([1, 2]) == [1, 2]


# Generated at 2022-06-20 15:48:05.370276
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test the default method of AnsibleJSONEncoder"""

    # prepare test data
    json_str = '{"str": "str", "list": ["1", "2", "3"], "dict": {"key": "value"}}'
    dict_obj = {"str": "str", "list": ["1", "2", "3"], "dict": {"key": "value"}}
    datetime_obj = datetime.datetime.now()

    # init a AnsibleJSONEncoder instance
    ansible_json_encoder = AnsibleJSONEncoder()

    # test the encoding of JSON string
    json_str_encoded = ansible_json_encoder.default(json_str)
    assert(json_str_encoded == json_str)

    # test the encoding of dict object
    dict_obj_encoded = ansible_

# Generated at 2022-06-20 15:48:13.684652
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # json.JSONEncoder.__init__(self, skipkeys=False, ensure_ascii=True,
    #                           check_circular=True, allow_nan=True, sort_keys=False,
    #                           indent=None, separators=None, default=None)
    assert not AnsibleJSONEncoder().skipkeys
    assert AnsibleJSONEncoder().allow_nan
    assert AnsibleJSONEncoder().check_circular
    assert AnsibleJSONEncoder().ensure_ascii
    assert not AnsibleJSONEncoder().sort_keys



# Generated at 2022-06-20 15:48:23.475288
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    vault_secret = VaultSecret('hello123')
    vault_lib = VaultLib([vault_secret])
    vault_aes256 = VaultAES256(vault_lib)
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import builtins

    class AnsibleUnsafe(text_type):
        __UNSAFE__ = True

    ansible_unsafe = AnsibleUnsafe('h1234')

    json_str = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode((vault_secret, ansible_unsafe))
    expected_

# Generated at 2022-06-20 15:48:24.682915
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert(a)

# Generated at 2022-06-20 15:48:32.972366
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    def _is_Mapping(value):
        return isinstance(value, Mapping)

    def _is_sequence(value):
        return is_sequence(value)

    def _preprocess_unsafe_encode(value):
        """Recursively preprocess a data structure converting instances of ``AnsibleUnsafe``
        into their JSON dict representations

        Used in ``AnsibleJSONEncoder.iterencode``
        """
        if _is_unsafe(value):
            value = {'__ansible_unsafe': 'AnsibleUnsafe'}

# Generated at 2022-06-20 15:48:44.532638
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test default()
    encoder = AnsibleJSONEncoder()
    assert encoder.default(False) == False
    assert encoder.default(True) == True
    assert encoder.default(None) == None
    assert encoder.default('Hello \t "World"') == 'Hello \t "World"'
    assert encoder.default(u'Hello \t "World"') == u'Hello \t "World"'
    assert encoder.default(u'\u20ac') == u'\u20ac'
    assert encoder.default(u'\u20ac \u20ac'.encode('utf-8')) == u'\u20ac \u20ac'
    assert encoder.default(u'\u20ac'.encode('utf-8')) == u'\u20ac'
    assert encoder

# Generated at 2022-06-20 15:48:52.732200
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """Make sure AnsibleJSONEncoder is working properly
    """
    # test AnsibleJSONEncoder
    print("Test AnsibleJSONEncoder")
    from ansible.module_utils.six import binary_type
    from ansible.parsing.vault import VaultLib
    ansible_string = u'ansible_test_string'
    ansible_binary = binary_type(ansible_string, 'utf-8')

# Generated at 2022-06-20 15:48:58.269000
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    def _default(value):
        return AnsibleJSONEncoder().default(value)

    # ansible-vault objects

# Generated at 2022-06-20 15:49:02.548247
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert isinstance(a, json.JSONEncoder)
    assert getattr(a, '_preprocess_unsafe', False) == False
    assert getattr(a, '_vault_to_text', False) == False



# Generated at 2022-06-20 15:49:13.334574
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.common._collections_compat import Mapping

    vault_secret = "hello world"
    vault_secret_group = "hello group"
    vault_pass = "foo"
    vault_secret_bytes = to_text(vault_secret, errors='surrogate_or_strict', nonstring='strict')
    vault_secret_group_bytes = to_text(vault_secret_group, errors='surrogate_or_strict', nonstring='strict')
    vault_pass_bytes = to_text(vault_pass, errors='surrogate_or_strict', nonstring='strict')

# Generated at 2022-06-20 15:49:38.210589
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.basic import AnsibleUnsafe
    from collections import Iterator

    int_value = 1
    str_value = AnsibleUnsafe('test')
    list_value = (1, 2, 3, AnsibleUnsafe('test'), {'answer': 42, 'question': AnsibleUnsafe('test')})
    dict_value = {'some_int': 1, 'some_str': AnsibleUnsafe('string'),
            'some_list': [int_value, AnsibleUnsafe('test')],
            'some_dict': {'some_int': 0, 'some_str': AnsibleUnsafe('string')}}
    
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    
    list_encoded = enc

# Generated at 2022-06-20 15:49:49.522508
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleUnsafeText
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleUnsafeBytes

    u1 = AnsibleUnsafeText('abc')
    u2 = AnsibleUnsafeText(u'\u00C0')
    u3 = AnsibleUnsafeText(b'\xc3\x80')
    u4 = AnsibleUnsafeText(u'a\u00C0', errors='surrogateescape')
    u5 = AnsibleUnsafeText(b'a\xc3\x80', errors='surrogateescape')
    u6 = AnsibleUnsafeText(u'a\u00C0', errors='ignore')

# Generated at 2022-06-20 15:49:55.862950
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Initialize constructor with *args and **kwargs
    obj1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert str(obj1) == '<AnsibleJSONEncoder object at 0x7f178a6918d0>'
    # Assert default value of default() method
    assert obj1.default(False) == False
    # Assert default value of iterencode() method
    assert obj1.iterencode(False) == 'false'

# Generated at 2022-06-20 15:50:06.985169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.amazon.aws import AWSRetry
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six.moves.urllib.parse import parse_qs
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

# Generated at 2022-06-20 15:50:15.618667
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Support for AnsibleVaultEncryptedUnicode
    v = AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n33316561656538363465663065336638313336393035626232303964363838623563383162326562\n62393438393966343861366331613562333737653663386564363533643962643561633535336462\n64313136633632646664383536373033353638346364303735643266316538303935643766376439\n37\n'))

# Generated at 2022-06-20 15:50:24.713409
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    test_array = [AnsibleUnsafe("test1 \n"), AnsibleUnsafe("test2 \n")]
    assert('["{\\"__ansible_unsafe\\": \\"test1 \\\\\\n\\"}", "{\\"__ansible_unsafe\\": \\"test2 \\\\\\n\\"}"]' ==
           AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(test_array))

    test_dict = {AnsibleUnsafe("test1 \n"): AnsibleUnsafe("test2 \n")}

# Generated at 2022-06-20 15:50:32.302295
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text

    class AnUnsafeClass(str):
        __UNSAFE__ = True

    o = AnUnsafeClass('{"foo": "bar"}')
    assert o == '{"foo": "bar"}'
    assert isinstance(o, str)

    enc = AnsibleJSONEncoder(preprocess_unsafe=True)

    expected = '{"__ansible_unsafe": "\\"{\\\\\\"foo\\\\\\": \\\\\\"bar\\\\\\"}\\""}'
    json_str = to_text(enc.iterencode(o)[0]).strip()
    assert json_str == expected

# Generated at 2022-06-20 15:50:41.459125
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    result = encoder.default('test_unsafe')
    assert result == 'test_unsafe'

    result = encoder.default(['test_unsafe', 'test_unsafe2'])
    assert result == ['test_unsafe', 'test_unsafe2']

    result = encoder.default({'test': 'unsafe', 'test2': 'unsafe2'})
    assert result == {'test': 'unsafe', 'test2': 'unsafe2'}

    result = encoder.default(None)
    assert result == None


# Generated at 2022-06-20 15:50:53.338876
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe == False
    assert AnsibleJSONEncoder()._vault_to_text == False
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True)._vault_to_text == False
    assert AnsibleJSONEncoder(vault_to_text=True)._preprocess_unsafe == False
    assert AnsibleJSONEncoder(vault_to_text=True)._vault_to_text == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._preprocess_unsafe == True
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)._vault

# Generated at 2022-06-20 15:51:00.253027
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:51:39.554360
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test expected to fail in python 2.6 because of lack of support for iterencode
    # The condition is that the value of ``json_str`` is empty
    # See https://stackoverflow.com/questions/2612802/how-to-clone-or-copy-a-list

    # Test *_preprocess_unsafe options
    # 1. create a sample json object
    # 2. preprocess unsafe if flag is set on
    # 3. compare the length of iterable with the original json

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafe

# Generated at 2022-06-20 15:51:47.013199
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    # lets create a vault object for testing purposes
    secret = "test"
    vault = VaultLib('ansible', test='changeme')
    ciphertext = to_text(vault.encrypt(secret))

    # lets create an instance of AnsibleJSONEncoder
    # preprocess_unsafe will be True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)

    # lets create a data structure to iterate over

# Generated at 2022-06-20 15:51:54.889241
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create an instance of class AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()
    assert encoder is not None

    # Create an instance of class AnsibleJSONEncoder with preprocess_unsafe set to True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder is not None

    # Create an instance of class AnsibleJSONEncoder with vault_to_text set to True
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder is not None


if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:51:57.043759
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    actual_output = AnsibleJSONEncoder()
    expected_output = json.JSONEncoder()
    assert actual_output == expected_output

# Generated at 2022-06-20 15:52:08.004101
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

# Generated at 2022-06-20 15:52:16.442013
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe

    a = AnsibleUnsafe('my secret text')
    encoder = AnsibleJSONEncoder()
    assert json.loads(encoder.encode(a)) == {'__ansible_unsafe':'my secret text'}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json.loads(encoder.encode(a)) == {'__ansible_unsafe':'my secret text'}

# Generated at 2022-06-20 15:52:27.562101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(u'foo')) == u'foo'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'foo')) == u'foo'
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnsafe(b'foo')) == {'__ansible_vault': b'foo'}
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnsafe(b'foo', b'bar')) == {'__ansible_vault': to_text(b'bar', errors='surrogate_or_strict')}

# Generated at 2022-06-20 15:52:33.386122
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    json_encoder1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    json_encoder2 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert json_encoder == json_encoder1
    assert json_encoder != json_encoder2


# Generated at 2022-06-20 15:52:45.362262
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test case when _preprocess_unsafe= True, _vault_to_text= True
    encoder = AnsibleJSONEncoder(True, True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True
    assert encoder.default(True) == True
    assert encoder.default(1) == 1
    assert encoder.default(None) == None
    assert encoder.default([]) == []
    assert encoder.default(["a"]) == ["a"]
    assert encoder.default({}) == {}
    assert encoder.default({"a":"b"}) == {"a":"b"}


# Generated at 2022-06-20 15:52:49.960182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.date(2019, 1, 12)) == '2019-01-12'
    assert AnsibleJSONEncoder().default(datetime.datetime(2019, 1, 12, 0, 6, 17)) == '2019-01-12T00:06:17'


# Generated at 2022-06-20 15:53:54.339145
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    from ansible.module_utils.common.collections import AnsibleUnsafeText
    result = json.dumps([123, AnsibleUnsafeText('456')], cls=AnsibleJSONEncoder)
    assert result == '[123, {"__ansible_unsafe": "456"}]'
    result = json.dumps({'foo': AnsibleUnsafeText('456')}, cls=AnsibleJSONEncoder)
    assert result == '{"foo": {"__ansible_unsafe": "456"}}'
    result = json.dumps({'foo': {'bar': AnsibleUnsafeText('456')}}, cls=AnsibleJSONEncoder)
    assert result == '{"foo": {"bar": {"__ansible_unsafe": "456"}}}'

# Generated at 2022-06-20 15:54:04.189814
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import six
    import base64
    from ansible.parsing.vault import VaultSecret

    plaintext = 'test'