

# Generated at 2022-06-20 15:44:12.144263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import VaultLib

    vault_obj = VaultLib('test')
    safe_str = vault_obj.encrypt('mytext')
    encrypted_str = ansible.parsing.vault.VaultEditor._encrypt_text(safe_str, b'mytext', 'test')
    vault_str = vault.VaultSecret(b'mytext', encrypted_str)
    unsafe_str = ansible.parsing.vault.VaultLib.create_unsafe_text('mytext')

    # test for encrypted string
    assert AnsibleJSONEncoder(default=lambda x: None).default(vault_str) == {'__ansible_vault': encrypted_str}

    # test for unsafe string
    assert Ansible

# Generated at 2022-06-20 15:44:13.564955
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(test_AnsibleJSONEncoder, object)


# Generated at 2022-06-20 15:44:25.777961
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import pytest

    from ansible.module_utils.common._collections_compat import MutableMapping

    class AnsibleUnsafe(basestring):
        """Class used to indicate that the object should not be used for templating
        """
        __metaclass__ = type
        __UNSAFE__ = True

    class AnsibleSensitiveThing(AnsibleUnsafe):
        """A subclass of AnsibleUnsafe that should not be displayed in logs."""
        __metaclass__ = type
        __SENSITIVE__ = True

    class AnsibleEncryptedThing(AnsibleUnsafe):
        """A subclass of AnsibleUnsafe that has been encrypted."""
        __metaclass__ = type
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:44:35.738660
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    encoder = AnsibleJSONEncoder()

    vault_obj = VaultLib({'vault_secret':'mysecret'})
    vault_encoded_pw = vault_obj.encrypt('mysecretpassword')
    vault_obj.decrypt(vault_encoded_pw)

    unsafe_obj = AnsibleUnsafe('test')
    unsafe_obj.__UNSAFE__ = True
    unsafe_obj.__ENCRYPTED__ = False

    vault_obj.__UNSAFE__ = True


# Generated at 2022-06-20 15:44:45.725580
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {
        'a': b"\xe4\xbd\xa0\xe5\xa5\xbd",
        'b': to_text(b"\xe4\xbd\xa0\xe5\xa5\xbd", errors='surrogate_or_strict')
    }
    # These tests enforce that when we pass through a byte string,
    # it will be encoded as UTF-8.
    assert json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"a": "\\u4f60\\u597d", "b": "你好"}'

# Generated at 2022-06-20 15:44:51.982794
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test default encoding of Ansible types
    d = {
        AnsibleUnsafe: b'unicode',
        AnsibleVault: b'unicode',
        dict: {'key': 'value'},
    }
    for typ, val in d.items():
        ans_encoder = AnsibleJSONEncoder()
        ans_encoder.default(typ(val))



# Generated at 2022-06-20 15:45:02.802305
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(u'foo') == u'foo'
    assert AnsibleJSONEncoder().default('foo') == 'foo'
    assert AnsibleJSONEncoder().default(Mapping()) == {}
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 1, 1, 0, 0, 0)) == '2018-01-01T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert AnsibleJSONEncoder(vault_to_text=True).default(u'foo') == u'foo'
    assert AnsibleJSONEncoder(vault_to_text=True).default('foo') == 'foo'
    assert AnsibleJSONEncoder(vault_to_text=True).default

# Generated at 2022-06-20 15:45:12.729153
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {
        "output": u"\u20ac",
        "dict_key": "dict_value",
        "list_val": [1, 2, u'\u20ac', u'\u20ac'],
        "list_val2": [u'\u202a', 1, 2, u'\u20ac', u'\u20ac'],
    }

    data1 = {
        "output": u"\u20ac",
        "dict_key": "dict_value",
        "list_val": [3, 7, 11, u'\u20ac', u'\u20ac'],
        "list_val2": [u'\u202a', 9, 13, u'\u20ac', u'\u20ac'],
    }


# Generated at 2022-06-20 15:45:24.601018
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    import crypt
    class TestVault(VaultLib):
        vault_password = 'test-password'

        def load(self, data):
            return crypt.crypt(json.dumps(data), 'salt')

        def loads(self, string):
            return json.loads(crypt.crypt(string, 'salt'))

    class AnsibleUnsafeString(str):
        __UNSAFE__ = True

    class AnsibleEncryptedString(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:45:32.543599
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
        # Passing argument to constructor
        a = AnsibleJSONEncoder(preprocess_unsafe=True)
        assert a._preprocess_unsafe == True
        assert a._vault_to_text == False
        b = AnsibleJSONEncoder(vault_to_text=True)
        assert b._preprocess_unsafe == False
        assert b._vault_to_text == True
        c = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
        assert c._preprocess_unsafe == False
        assert c._vault_to_text == False
        d = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
        assert d._preprocess_unsafe == True
        assert d._vault_to_text == True

# Generated at 2022-06-20 15:45:40.018884
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        assert AnsibleJSONEncoder
    except AssertionError:
        print("FAILED: test_AnsibleJSONEncoder")


# Generated at 2022-06-20 15:45:42.143540
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    hostvars = dict(a=dict(b=dict(c='d')))

    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(hostvars) == hostvars



# Generated at 2022-06-20 15:45:51.872534
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type


# Generated at 2022-06-20 15:46:01.922714
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    v = VaultLib('password')
    encrypted_string = v.encrypt('some_text')
    print(encrypted_string, type(encrypted_string))
    result1 = AnsibleJSONEncoder().default(encrypted_string)

# Generated at 2022-06-20 15:46:03.057741
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder()

# Generated at 2022-06-20 15:46:14.101146
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    text = "This is a test"

    class MyUnsafe(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    j = json.dumps(text, cls=AnsibleJSONEncoder(preprocess_unsafe=True))
    assert j == '"This is a test"'

    j = json.dumps(MyUnsafe(text), cls=AnsibleJSONEncoder(preprocess_unsafe=True))
    j = json.loads(j)
    assert j['__ansible_unsafe'] == 'This is a test'

    j = json.dumps([text], cls=AnsibleJSONEncoder(preprocess_unsafe=True))
    assert j == '["This is a test"]'


# Generated at 2022-06-20 15:46:25.723241
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    assert aje.default(None) == None
    assert aje.default(1) == 1
    assert aje.default(1.4) == 1.4
    assert aje.default('v') == 'v'
    assert aje.default([1,2,3]) == [1,2,3]
    assert aje.default((1,2,3)) == (1,2,3)
    assert aje.default({1:'foo', 2:'bar'}) == {1:'foo', 2:'bar'}
    assert aje.default(datetime.date(2020, 1, 31)) == '2020-01-31'

# Generated at 2022-06-20 15:46:34.851362
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ast
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafeBytes(bytes):
        __UNSAFE__ = True

    class AnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        __ENCRYPTED__ = True
        __UNSAFE__ = True

    class TestClass(object):
        pass

    class HostVars(object):
        pass


# Generated at 2022-06-20 15:46:45.311121
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText
    import json


# Generated at 2022-06-20 15:46:53.072118
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    value_1 = [
        {'id': 1, 'username': u'foo', 'email': {'address': u'foo@bar.com'}, 'modules': [1, 2, 3]},
        {'id': 2, 'username': u'bar', 'email': {'address': u'bar@bar.com'}, 'modules': [4, 5, 6]},
        {'id': 3, 'username': u'foobar', 'email': {'address': u'foo@bar.com'}, 'modules': [7, 8, 9]}
    ]

# Generated at 2022-06-20 15:47:04.987224
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.common.text.converters import to_unicode


# Generated at 2022-06-20 15:47:16.584627
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    target = {
        "a1": True,
        "a2": False,
        "a3": 1,
        "a4": 3.14,
        "a5": "a5",
        "a6": u"a6",
        "a7": None,
        "a8": [1, 2, 3],
        "a9": (1, 2, 3),
        "a10": {
            "a10_1": 1,
            "a10_2": "2",
        },
        "a11": datetime.date(2018, 1, 1),
        "a12": datetime.datetime(2018, 1, 1, 1, 1, 1),
    }

# Generated at 2022-06-20 15:47:22.606598
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib([(VaultSecret('abcdef'))])
    vault_text = ''

    for i in AnsibleJSONEncoder(False, False).iterencode(vault):
        vault_text += i

    assert _is_vault(vault)
    assert '__ansible_vault' in vault_text

# Generated at 2022-06-20 15:47:26.959861
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False
    assert json.JSONEncoder.default == a.default
    assert json.JSONEncoder.iterencode == a.iterencode


# Generated at 2022-06-20 15:47:39.650627
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import transform_commands
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-20 15:47:48.318370
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    assert list(AnsibleJSONEncoder().iterencode(["hello"])) == ['["hello"]']
    assert list(AnsibleJSONEncoder().iterencode(["hello", "world"])) == ['["hello","world"]']
    assert list(AnsibleJSONEncoder().iterencode({"hello": "world"})) == ['{"hello":"world"}']
    assert list(AnsibleJSONEncoder(True).iterencode({"hello": "world"})) == ['{"hello":"world"}']

    import ansible.parsing.vault
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    vault = ansible.parsing.vault.VaultLib("password")
    assert list(AnsibleJSONEncoder(True).iterencode([vault.encrypt("hello")]))

# Generated at 2022-06-20 15:47:54.355255
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # testing the constructor
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

# Generated at 2022-06-20 15:48:05.290695
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # true
    ######################################################
    assert AnsibleJSONEncoder().default(True) == True

    # false
    ######################################################
    assert AnsibleJSONEncoder().default(False) == False

    # None
    ######################################################
    assert AnsibleJSONEncoder().default(None) == None

    # string
    ######################################################
    assert AnsibleJSONEncoder().default('a string') == 'a string'

    # float
    ######################################################
    assert AnsibleJSONEncoder().default(1.0) == 1.0

    # int
    ######################################################
    assert AnsibleJSONEncoder().default(1) == 1

    # list
    ######################################################
    assert AnsibleJSONEncoder().default([1,2,3]) == [1,2,3]

# Generated at 2022-06-20 15:48:16.579423
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Encoding unsafe object
    value = {"key1": "Hello", "key2": u"\u2603"}
    value["key1"] = AnsibleUnsafe(value["key1"])
    value["key2"] = AnsibleUnsafe(value["key2"])
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(value)) == [
        '{\n',
        ' "key1": ',
        '{\n',
        '  "__ansible_unsafe": ',
        ' "Hello"\n',
        ' },\n',
        ' "key2": ',
        '{\n',
        '  "__ansible_unsafe": ',
        ' "☃"\n',
        ' }\n',
        '}'
    ]

    # Enc

# Generated at 2022-06-20 15:48:24.374163
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    vault_password = 'type your password here'
    vault_data = 'I want to save this for later'
    vault = VaultLib([('default', vault_password)])
    encrypted = vault.encrypt(vault_data)
    result = AnsibleJSONEncoder().default(encrypted)
    assert encrypted._ciphertext == result['__ansible_vault']



# Generated at 2022-06-20 15:48:43.750030
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import base64
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import string_types, text_type
    from ansible.module_utils.common.text.converters import to_text

    # Test variables
    test_dict = {'test_dict': {'test_dict_dict': 'test_dict_dict_value', 'test_dict_str': 'test_dict_str_value'},
                 'test_str': 'test_str_value',
                 'test_list': ['test_list_value', 'test_list_value'],
                 'test_int': 1,
                 'test_float': 1.0,
                 'test_bool': True,
                 'test_unsafe': AnsibleUnsafe(b'test_unsafe')}

# Generated at 2022-06-20 15:48:46.200923
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.facts.hardware.base import Hardware
    assert(AnsibleJSONEncoder().default(Hardware()) == {})

# Generated at 2022-06-20 15:48:52.637367
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    test_case1 = {'test': AnsibleUnsafe('unsafe')}
    test_case2 = AnsibleUnsafe('unsafe')
    # json_data = json.dumps(test_case, cls=AnsibleJSONEncoder)
    # print(json_data)
    assert(AnsibleJSONEncoder().default(test_case1) == {'test': {'__ansible_unsafe': 'unsafe'}})
    assert(AnsibleJSONEncoder().default(test_case2) == {'__ansible_unsafe': 'unsafe'})


# Generated at 2022-06-20 15:48:56.819047
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """Creates an instance and check if the preprocess_unsafe is set to False and vault_to_text to False"""
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder._preprocess_unsafe is False
    assert json_encoder._vault_to_text is False

# Generated at 2022-06-20 15:49:06.845649
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from .unsafe_proxy import AnsibleUnsafeText, is_unsafe_text
    from .unsafe_proxy import AnsibleUnsafeProxy

    class AnsibleTestUnsafeText(AnsibleUnsafeText):
        pass

    class AnsibleTestUnsafeProxy(AnsibleUnsafeProxy):
        pass

    test_values = [
        "",
        "Text",
        AnsibleUnsafeText(b'\xff', encoding=None),
        AnsibleUnsafeText(b'Unsafe Bytes', encoding=None),
        AnsibleTestUnsafeText(b'Unsafe Test Bytes', encoding=None),
        AnsibleTestUnsafeProxy(b'Unsafe Test Proxy Bytes', encoding=None)
    ]


# Generated at 2022-06-20 15:49:08.055416
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert(isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder))

# Generated at 2022-06-20 15:49:17.342104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_bytes

    #test default and inherited default methods
    result = False
    t1 = ('t1', 't1')
    t2 = ('t2', 't2')
    t3 = ('t3', 't3')
    t4 = (('t4', 't4'), ('t4', 't4'))
    t5 = ('t5', 't5', 't5')
    t6 = (('t6', 't6'), ('t6', 't6'), ('t6', 't6'))

    #test default
    test1 = AnsibleJSONEncoder().default(t1)

# Generated at 2022-06-20 15:49:20.823181
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test Replacer
    class Replacer:
        def __init__(self, *args):
            self.args = args

        def __getattr__(self, key):
            return self

        def __call__(self):
            return self

        def __repr__(self):
            return 'type: %s' % self.__class__.__name__

    # Test Input
    test_input = {
        'dict': {
            '__ENCRYPTED__': True,
            '_ciphertext': 'Fake data'
        },
        'list': [Replacer(), Replacer(), Replacer()],
        'Replacer': Replacer(),
    }

    # Test Expectations

# Generated at 2022-06-20 15:49:31.627159
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # setup
    test_data = {
        'string': 'value',
        'bool': True,
        'integer': 55,
        'float': 5.5,
        'dict': {
            'key': 'value'
        },
        'list': [
            'value1',
            'value2'
        ],
        'date': datetime.date.today(),
        'datetime': datetime.datetime.now()
    }

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: kwargs

    # test when preprocess_unsafe=False

# Generated at 2022-06-20 15:49:42.783777
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.parsing.vault import AnsibleVaultError

    class AnsibleUnsafe(object):
        __UNSAFE__ = True

    class AnsibleUnsafeStr(str):
        __UNSAFE__ = True

    class AnsibleUnsafeUnicode(unicode):
        __UNSAFE__ = True

    class AnsibleVault(ansible.parsing.vault.AnsibleVaultEncryptedUnicode):
        __ENCRYPTED__ = True

    class AnsibleVaultStr(unicode):
        __ENCRYPTED__ = True

    class AnsibleVaultUnicode(unicode):
        __ENCRYPTED__ = True


# Generated at 2022-06-20 15:50:09.277330
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault

    # Test a vault object
    data = vault.VaultLib('password')
    data_encoded = json.dumps(data, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

# Generated at 2022-06-20 15:50:17.366019
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:50:24.965370
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # check for datetime.date
    assert encoder.default(datetime.date(2019, 1, 6)) == '2019-01-06'

    # check for datetime.datetime
    assert encoder.default(datetime.datetime(2019, 1, 6, 12, 0, 0)) == '2019-01-06T12:00:00'

    # check for dict
    assert encoder.default({'var': 'value'}) == {'var': 'value'}

    # check for string
    assert encoder.default('string') == 'string'

# Generated at 2022-06-20 15:50:33.425743
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.six import string_types

    vault_password = 'foo'
    vault = VaultLib([])

# Generated at 2022-06-20 15:50:34.946690
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aisk = AnsibleJSONEncoder()
    return aisk

# Generated at 2022-06-20 15:50:46.549725
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault

    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-20 15:50:57.024551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    tests = dict(
        dict_object={'key': 'value'},
        datetime_object=datetime.datetime(2010, 1, 1, 0, 0, 0),
        date_object=datetime.date(2010, 1, 1),
        bool_object=True,
        float_object=5.5,
        int_object=5,
        str_object='string',
        list_object=['v1', 'v2', 'v3'],
        tuple_object=('v1', 'v2', 'v3'),
        complex_object=[{'k': 'v'}, datetime.date(2010, 1, 1)],
    )
    for key in tests:
        ret = encoder.default(tests[key])

# Generated at 2022-06-20 15:51:08.951302
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import PY3, text_type
    # We are testing only Python 3 as Python 2's JSON module does not support iterable output
    if PY3:
        from io import BytesIO
        from ansible.module_utils.common.text.converters import to_bytes, to_text
        a = [
            {
                'val': True,
                'val2': False,
                'str': 'string',
                'int': 1,
                'lst': [
                    'lst_1',
                    'lst_2'
                ],
                'dct': {
                    'dct_1': 1,
                    'dct_2': 2
                }
            }
        ]

        a0 = a[0]

# Generated at 2022-06-20 15:51:21.604762
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    import datetime
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type, string_types

    ansible_json_encoder = AnsibleJSONEncoder()
    vault_pass = 'asdlkfejqwerasdf'
    vault = VaultLib(vault_pass)

# Generated at 2022-06-20 15:51:30.148019
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafeText
    from ansible.module_utils.common.collections import AnsibleUnsafeBytes
    from ansible.module_utils.common.collections import AnsibleUnsafe

    assert json.dumps(AnsibleUnsafeText('hello world'), cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"__ansible_unsafe": "hello world"}'
    assert json.dumps(AnsibleUnsafeBytes('hello world'), cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"__ansible_unsafe": "hello world"}'

# Generated at 2022-06-20 15:52:09.896214
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    from ansible.module_utils._text import to_bytes, to_text


# Generated at 2022-06-20 15:52:21.472718
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    vault_password = 'abcde12345'
    ansible_unsafe = "AnsibleUnsafe is a subclass of str"
    date_object = datetime.date(2012, 12, 12)
    dictionary = {'foo': 'bar'}

    # Most tests override the default method, so re-run the default tests here
    assert "Date object" == AnsibleJSONEncoder().default(date_object)
    assert "Dictionary object" == AnsibleJSONEncoder().default(dictionary)

    # Test the Ansible specific classes

# Generated at 2022-06-20 15:52:31.543817
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six.moves import StringIO
    import ansible.module_utils.basic

    class TestAnsibleUnsafe(ansible.module_utils.basic.AnsibleUnsafe):
        pass

    mylist = ['__ansible_unsafe', TestAnsibleUnsafe('test'), {'__ansible_unsafe': 'test'}, 123]
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    fd = StringIO()
    json.dump(mylist, fp=fd, cls=encoder)
    assert fd.getvalue() == '["__ansible_unsafe", {"__ansible_unsafe": "test"}, {"__ansible_unsafe": "test"}, 123]'

# Generated at 2022-06-20 15:52:34.851015
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert test_ansible_json_encoder._preprocess_unsafe == False
    assert test_ansible_json_encoder._vault_to_text == False

# Generated at 2022-06-20 15:52:46.210868
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Create an instance of the AnsibleJSONEncoder.
    ansible_json_encoder = AnsibleJSONEncoder()

    # Make sure the vault text is not displayed
    value = ansible_json_encoder.default(object())
    assert value is None
    value = ansible_json_encoder.default(object.__new__(object))
    assert value is None
    value = ansible_json_encoder.default(object.__new__(object, 1, 2, 3))
    assert value is None
    value = ansible_json_encoder.default(object.__new__(object, [(1, 2), (3, 4), (5, 6)]))
    assert value is None

    # Make sure the vault text is displayed, when JSONEncoder is initialized with preprocess_unsafe set to True
    ansible_

# Generated at 2022-06-20 15:52:56.882516
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils._text import to_bytes, to_text
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnsafeText
    # AnsibleUnsafe Text
    ansible_unsafe_text = AnsibleUnsafe(to_bytes(b"abc"))
    # AnsibleUnsafe plain password
    ansible_unsafe_plain_password = AnsibleUnsafe(to_bytes(b"abc"), unsafe_secret=True)
    # AnsibleUnsafe plain secret
    ansible_unsafe_plain_secret = AnsibleUnsafe(to_bytes(b"abc"), unsafe_secret=True, unsafe_use_plaintext=True)
    # AnsibleUnsafe plain secret with space
    ansible_unsafe_plain_secret_ws

# Generated at 2022-06-20 15:53:08.826891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test data
    data = [
        {
            'name': 'larry',
            'age': 88,
            'candy': [{
                'name': 'twix',
                'color': 'brown'
            }],
            'infinite_loop': None
        },
        {
            'name': 'tweety',
            'age': 2,
            'infinite_loop': None
        }
    ]

    # test ansible json encoder
    json_encoder = AnsibleJSONEncoder(indent=4)
    json_string = json_encoder.encode(data)
    json_object = json.loads(json_string)

    # assert object
    assert isinstance(json_object, list)
    assert len(json_object) == 2

    # assert 1st object

# Generated at 2022-06-20 15:53:20.783331
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:53:23.705278
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(datetime.datetime.now(), cls=AnsibleJSONEncoder))
    assert json.loads(json.dumps(datetime.date.today(), cls=AnsibleJSONEncoder))

# Generated at 2022-06-20 15:53:29.366313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default({}) == {}
    assert ansible_json_encoder.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
