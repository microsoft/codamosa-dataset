

# Generated at 2022-06-20 15:44:02.094440
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-20 15:44:12.043725
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    import pytest
    from ansible.module_utils._text import to_native, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.json_roles_encoder import (
        _preprocess_unsafe_encode,
        AnsibleJSONEncoder
    )

    test_string = "This is a test string"
    test_unsafe_text = AnsibleUnsafeText.from_native(test_string, encoding='utf-8')

    # test for AnsibleUnsafeText
    tmp_o = test_unsafe_text

# Generated at 2022-06-20 15:44:24.538393
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:44:32.055533
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    e = AnsibleJSONEncoder()
    assert isinstance(e, json.JSONEncoder)
    encoder_default = e.default
    assert callable(encoder_default)

    # test default() with AnsibleUnsafe
    class AnsibleUnsafe(object):
        __UNSAFE__ = True

    o = AnsibleUnsafe()
    o.__getstate__ = mock.MagicMock(return_value='ansible')
    default_return = encoder_default(o)
    assert isinstance(default_return, dict)
    assert default_return

# Generated at 2022-06-20 15:44:38.682667
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bool
    import ansible.module_utils.common.text.converters

# Generated at 2022-06-20 15:44:41.704556
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    temp = """{
            "__ansible_unsafe": "value"
        }"""
    assert json.dumps({'__ansible_unsafe': 'value'}, cls=AnsibleJSONEncoder) == temp

# Generated at 2022-06-20 15:44:48.903340
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:45:00.694731
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test default constructor
    encoder = AnsibleJSONEncoder()
    my_string = "my string"
    my_unicode = u'my string'
    assert encoder.default(my_string) == "my string"
    assert encoder.default(my_unicode) == "my string"

    # test constructor with preprocess_unsafe=True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    my_string = "my string"
    my_unicode = u'my string'
    assert encoder.default(my_string) == "my string"
    assert encoder.default(my_unicode) == "my string"

    # test constructor with vault_to_text=True
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    my_

# Generated at 2022-06-20 15:45:10.798257
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import range

    # default encoder
    aje = AnsibleJSONEncoder()
    # encoded string
    string = aje.default(text_type('Ansible'))

    assert string == 'Ansible'
    assert isinstance(string, text_type)

    # encrypted object
    vault = AnsibleJSONEncoder().default(VaultSecret('secret'))

    assert vault == {'__ansible_vault': 'secret'}
    assert isinstance(vault, dict)

    # unsafe object
    ansibleUnsafe = AnsibleJSONEncoder().default('AnsibleUnsafe')


# Generated at 2022-06-20 15:45:12.653876
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    Anson
    :return:
    """
    ansible_json_encoder = AnsibleJSONEncoder()
    print(ansible_json_encoder.default("test"))

# Generated at 2022-06-20 15:45:20.670142
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    json_output = ansible.module_utils.basic.json.dumps({'test': 'hello', 'test_int': 123.45, 'test_list': ['a', 'b', 'c'], 'test_dict': {'key': 'value'}}, cls=AnsibleJSONEncoder)
    print (json_output)

# Generated at 2022-06-20 15:45:30.678551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit tests for **_AnsibleJSONEncoder.default**"""
    # import module snippets
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.basic import AnsibleUnsafe

    from ansible.module_utils.common.parameters import ParameterError
    from ansible.parsing.vault import VaultLib
    from datetime import datetime
    from datetime import date
    import json

    import pytest
    from datetime import datetime
    from datetime import date

    # test_obj_with_unsafe_attribute is a Python hash with AnsibleUnsafe
    # attributes that should be encoded
    test_obj_with_unsafe_attribute = {'a': AnsibleUnsafe('a_unsafe')}
    # test_obj_list_with

# Generated at 2022-06-20 15:45:42.794982
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_secret_sources

    # Encoding str type
    str_json_encoder = AnsibleJSONEncoder()
    assert '{"asd": "asd"}' == str_json_encoder.encode({'asd': 'asd'})

    # Encoding bad type
    class BadType(object):
        pass
    bad_type_json_encoder = AnsibleJSONEncoder()
    assert '{}' == bad_type_json_encoder.encode(BadType)

    # Encoding VaultLib type
    secret_source = vault_secret_sources.VaultSecretSource('test_vault_secret_source')
    vault_lib = VaultLib(secret_source)
    vault_lib._cipher

# Generated at 2022-06-20 15:45:52.279421
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    import datetime

    # ensure that AnsibleUnsafe can be encoded to a string
    j = json.dumps({u'foo': to_text(u'\u00F8', errors='surrogate_or_strict')}, cls=AnsibleJSONEncoder)
    assert j == u'{"foo": "\\u00f8"}'

    # ensure that AnsibleVaultEncryptedUnicode can be encoded to a string

# Generated at 2022-06-20 15:46:02.212938
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types

    class Foo(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class Bar(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class Baz(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = False

    # simple string
    assert list(AnsibleJSONEncoder().iterencode('abc')) == ['abc']

    # unsafe string
    assert list(AnsibleJSONEncoder().iterencode(Foo('abc'))) == ['"__ansible_unsafe": "abc"']

    # unsafe string, preprocess_unsafe enabled

# Generated at 2022-06-20 15:46:13.489023
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE

    # build a data structure to encode
    data = {
        'a': 'b',
        'unsafe': boolean('yes'),
        'list': ['c']
    }

    # setup our encoder and encode
    # note: the encoder has to be setup to preprocess unsafe objects
    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    text = enc.encode(data)

    # ensure the data structure contains strings


# Generated at 2022-06-20 15:46:20.072250
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    json_data = {
        'first': 'hello',
        'second': 'world',
        'third': {
            'x': AnsibleUnsafe("!secret_this"),
        },
        'fourth': 'ok',
        'fifth': AnsibleUnsafe("!secret_that"),
    }

    ansible_json = AnsibleJSONEncoder(preprocess_unsafe=True).encode(json_data)
    assert 'hello' == json.loads(ansible_json)["first"]
    assert 'world' == json.loads(ansible_json)["second"]
    assert 'ok' == json.loads(ansible_json)["fourth"]

# Generated at 2022-06-20 15:46:24.847722
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common.text.converters import json_loads, json_dumps, to_text

    # Attempt to convert a "VaultAware" type to JSON

# Generated at 2022-06-20 15:46:30.557810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = AnsibleJSONEncoder()
    b = ansible_unsafe_proxy()
    c = ansible_vault_proxy()

    assert a.default(b) == {'__ansible_unsafe': 'unsafe'}
    assert a.default(c) == {'__ansible_vault': 'vault'}
    assert a.default({'a': 'b'}) == {'a': 'b'}



# Generated at 2022-06-20 15:46:38.137880
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Python 2.7 / 3.5
    assert AnsibleJSONEncoder().default(b'utf-8') == 'utf-8'
    assert AnsibleJSONEncoder().default(u'unicode') == 'unicode'

    # Python 2.7 / 3.5
    class Foo(object):
        def __repr__(self):
            return 'Foo'

    assert AnsibleJSONEncoder().default(Foo()) == 'Foo'

    # Python 2.7 / 3.5
    from ansible.module_utils.basic import AnsibleUnsafe

    assert AnsibleJSONEncoder().default(AnsibleUnsafe('unsafe')) == {'__ansible_unsafe': 'unsafe'}

    # Python 2.7 / 3.5

# Generated at 2022-06-20 15:46:49.383992
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import StringIO

    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves.mock import patch

    import json

    # test data

# Generated at 2022-06-20 15:46:59.620708
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars

    # Test for default function of AnsibleJSONEncoder
    # Test to check if a VaultLib object is encoded to a dict
    vault_lib = VaultLib('test')

# Generated at 2022-06-20 15:47:00.457755
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-20 15:47:04.473122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    ansible_unsafe = AnsibleJSONEncoder.default('test')
    assert ansible_unsafe == 'test'
    test_dict = {'test': 'test'}
    ansible_unsafe = AnsibleJSONEncoder.default(test_dict)
    assert ansible_unsafe == test_dict


# Generated at 2022-06-20 15:47:16.385321
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsibleJSONEncoder.default()
    # Create instance of AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test case 01
    o = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux'
        }
    }
    assert ansible_json_encoder.default(o) == o

    # Test case 02
    from ansible.parsing.vault import VaultLib
    vault_lib = VaultLib()
    vault_text = vault_lib.encrypt(to_text(b'foo'))

# Generated at 2022-06-20 15:47:25.187113
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test constructor with valid and invalid options
    valid_options = {
        "ensure_ascii": True,
        "check_circular": True,
        "allow_nan": True,
        "sort_keys": True,
        "indent": 2,
        "separators": (',', ':'),
        "preprocess_unsafe": True,
        "vault_to_text": True,
        "cls": AnsibleJSONEncoder,
        "encoding": "utf-8",
        "object_hook": None,
        "parse_float": None,
        "parse_int": None,
        "parse_constant": None,
        "object_pairs_hook": None
    }

# Generated at 2022-06-20 15:47:37.375251
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import text_type

    ansiblejsencoder = AnsibleJSONEncoder()

    vault_secrets = {'va_username': VaultSecret('username'),
                     'va_password': VaultSecret('password')}

# Generated at 2022-06-20 15:47:40.272496
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(True, False)._preprocess_unsafe is True
    assert AnsibleJSONEncoder(False, True)._vault_to_text is True

# Generated at 2022-06-20 15:47:44.258769
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, sort_keys=True)
    # assert ansible_json_encoder
    assert isinstance(ansible_json_encoder, json.JSONEncoder)

# Generated at 2022-06-20 15:47:50.786676
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    try:
        # for python2.x
        unicode
    except NameError:
        # for python3.x
        unicode = str
    for cls in (AnsibleUnsafe, unicode, str):
        assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(cls(u'ấ')) == b'"__ansible_unsafe":"\\u1ea5"'

# Generated at 2022-06-20 15:48:05.291380
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # check for a simpler object types
    jsonEncoder = AnsibleJSONEncoder()
    assert(jsonEncoder.default("abcd") == "abcd")
    assert(jsonEncoder.default(123) == 123)
    assert(jsonEncoder.default([1,2,3,4]) == [1,2,3,4])
    assert(jsonEncoder.default({1: "abcd", 2: "efgh"}) == {1: "abcd", 2: "efgh"})

    # check for a datetime object
    dt_obj = datetime.datetime.now()
    assert(jsonEncoder.default(dt_obj) == dt_obj.isoformat())

    # check for an instance of an object which has attribute
    # __ENCRYPTED__ set to True
    jsonEncoder = Ans

# Generated at 2022-06-20 15:48:16.573721
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        a = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False, separators=(',', ': '))
    except:
        print("Exception ERROR: class AnsibleJSONEncoder constructor error.")
        return False

    try:
        b = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, separators=(',', ': '))
    except:
        print("Exception ERROR: class AnsibleJSONEncoder constructor error.")
        return False

    try:
        c = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True, separators=(',', ': '))
    except:
        print("Exception ERROR: class AnsibleJSONEncoder constructor error.")
        return False


# Generated at 2022-06-20 15:48:27.932356
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    print("TEST: Started test_AnsibleJSONEncoder")
    user = {"name": "Sanjay", "age": 27, "cars": ["BMW", "Ford"]}
    json_output = AnsibleJSONEncoder().encode(user)
    json_output = json.loads(json_output)
    assert type(json_output) == dict

    assert json_output['name'] == "Sanjay"
    assert type(json_output['name']) == str

    assert json_output['age'] == 27
    assert type(json_output['age']) == int

    assert json_output['cars'] == ["BMW", "Ford"]
    assert type(json_output['cars']) == list
    print("TEST: test_AnsibleJSONEncoder Successful")

# Generated at 2022-06-20 15:48:33.141349
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.release as ansible_release
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves.urllib.parse import unquote_plus

    # Test that iterencode converts value of AnsibleUnsafe objects to JSON dict
    obj = ansible_release.__version__
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_string = text_type(''.join(ansible_encoder.iterencode(obj)))
    value_of_unsafe = json_string[json_string.index(':')+1:json_string.rindex('}')]
    assert unquote_plus(value_of_unsafe) == getattr(obj,'__UNSAFE__', False)

    #

# Generated at 2022-06-20 15:48:44.703905
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.plugins.vars import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    # test vault
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    o = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;my-vault-secret\n33386462326661393763323963386332356339663031626335386161343138613561613039356531\n66383932396361663666656162626332613135376231363133396433613763326239316138376137\n6665326138383630')

# Generated at 2022-06-20 15:48:52.847638
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert AnsibleJSONEncoder().default([{'key': 'value'}, 42]) == [{'key': 'value'}, 42]
    assert AnsibleJSONEncoder().default(datetime.datetime(2020, 1, 1, 12, 0, 0)) == '2020-01-01T12:00:00'
    assert AnsibleJSONEncoder().default(datetime.date(2020, 1, 1)) == '2020-01-01'

    class Unsafe(object):
        __UNSAFE__ = True
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return self.value
        def __repr__(self):
            return self.value


# Generated at 2022-06-20 15:48:58.374086
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.compat.ipaddress import ip_address
    from ansible.module_utils.common.compat.ipaddress import ip_network

# Generated at 2022-06-20 15:49:08.302217
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    # ansible vault object

# Generated at 2022-06-20 15:49:11.356860
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert a._preprocess_unsafe is False
    assert a._vault_to_text is False


# Generated at 2022-06-20 15:49:19.569968
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    data = {'foo': AnsibleUnsafe('bar')}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(data) == AnsibleJSONEncoder().iterencode(data)


if __name__ == '__main__':
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import UNSAFE_STRING
    from ansible.vars.unsafe_proxy import UNSAFE_BYTES

    data = {'foo': AnsibleUnsafe(UNSAFE_BYTES('bar')), 'baz': AnsibleUnsafe(UNSAFE_STRING('bar'))}

# Generated at 2022-06-20 15:49:34.172433
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    '''
    Unit test for constructor of class AnsibleJSONEncoder,
    by passing different parameters.
    '''

    # Default constructor, with default parameters
    default_encoder = AnsibleJSONEncoder()
    assert default_encoder._preprocess_unsafe is False
    assert default_encoder._vault_to_text is False

    # Preprocess_unsafe passes to True, others are False
    preprocess_unsafe_encoder = AnsibleJSONEncoder(True)
    assert preprocess_unsafe_encoder._preprocess_unsafe is True
    assert preprocess_unsafe_encoder._vault_to_text is False

    # Vault_to_text passes to True, others are False
    vault_to_text_encoder = AnsibleJSONEncoder(False, True)
    assert vault_to_text_

# Generated at 2022-06-20 15:49:38.972618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()

    # test for default behavior
    assert e.default([])                  == []
    assert e.default({"foo": "bar"})      == {"foo": "bar"}
    assert e.default("foo")               == "foo"
    assert e.default(1)                   == 1
    assert isinstance(e.default([]), list)
    assert isinstance(e.default({"foo": "bar"}), dict)
    assert isinstance(e.default("foo"), basestring)
    assert isinstance(e.default(1), int)

    # test for behavior on specific Ansible objects
    class test_vault:
        __ENCRYPTED__ = True
        _ciphertext = 'test'

    class test_unsafe:
        __UNSAFE__ = True


# Generated at 2022-06-20 15:49:50.519704
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    from ansible.parsing.vault import VaultLib

    ###################################################################
    # BEGIN: Test cases for method AnsibleJSONEncoder.iterencode
    if hasattr(builtins, 'unicode'):
        # python2 (python3 does not support unicode_literals in __future__)
        from ansible.module_utils.six import u
    else:
        # python3
        from ansible.module_utils.six import PY3, text_type as u


# Generated at 2022-06-20 15:49:59.249493
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleUnsafeBytes
    import json

    with open('/tmp/test_AnsibleJSONEncoder_iterencode.json', 'w') as f:
        f.write('[{"unicode": {"foo": "bar"}}]')

    transform_keys = dict()
    transform_keys['unicode'] = dict()
    transform_keys['unicode']['foo'] = AnsibleUnsafeText(b'1234')

    # With preprocess set to True, AnsibleUnsafeText should become a dict with
    # one key: '__ansible_unsafe'.
    aue_json = json.dumps(transform_keys, cls=AnsibleJSONEncoder, preprocess_unsafe=True)

# Generated at 2022-06-20 15:50:02.725333
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    if __name__ == "__main__":
        ansible_json_encoder_obj = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-20 15:50:04.932850
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder=AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert(encoder._preprocess_unsafe==True)
    assert(encoder._vault_to_text == False)

# Generated at 2022-06-20 15:50:05.769855
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    assert isinstance(aje, json.JSONEncoder)


# Generated at 2022-06-20 15:50:07.567559
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Must pass when no exception thrown
    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:50:16.116788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import ImmutableDict

    # test vault object
    test_vault = VaultLib(None)
    assert json.loads(json.dumps(test_vault, cls=AnsibleJSONEncoder, vault_to_text=True)) == 'Vault encrypted'
    assert json.loads(json.dumps(test_vault, cls=AnsibleJSONEncoder)) == {'__ansible_vault': u''}
    assert json.loads(json.dumps(test_vault, cls=AnsibleJSONEncoder, sort_keys=True)) == {'__ansible_vault': u''}

    # test hostvars object

# Generated at 2022-06-20 15:50:24.602029
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # import for testing
    from ansible.parsing.vault import VaultLib

    test_data = [
        'This is a plain string',
        {'a_key': 'a_value'},
        {'a_key': 'a_value', 'a_list': [1, 2, 3]},
        {'a_key': 'a_value', 'a_list': [1, 2, 3], 'a_dict': {'1': '2', 'a': 'b'}},
        VaultLib('a'),
    ]

    for item in test_data:
        result = AnsibleJSONEncoder().encode(item)
        json.loads(result)
        assert(result == json.dumps(item))



# Generated at 2022-06-20 15:50:48.701066
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:50:49.915311
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    o = json.dumps('test', cls=AnsibleJSONEncoder)
    assert o == '"test"'

# Generated at 2022-06-20 15:50:59.057104
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    vault_secret = 'VaultSecret'
    vault_password = 'VaultPassword'
    vault_vars = {'VaultVar': 'VaultValue'}

    # Initialize vault
    vault = VaultLib(vault_password)
    vault_content = vault.dump(vault_vars)

    # Create AnsibleVaultEncryptedUnicode instance

# Generated at 2022-06-20 15:51:11.031180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import json
    import datetime
    from ansible_collections.testns.testcoll.plugins.module_utils.internal import internal_data
    from ansible_collections.testns.testcoll.plugins.module_utils.internal import vault

    vault_password = 'ansible'

    # test normal string
    encoder = AnsibleJSONEncoder()
    s = 'TEXT'
    v = encoder.default(s)
    assert v == s

    # test vault string
    t = to_text(vault.VaultLib(vault_password).encrypt(s))
    v = encoder.default(t)
    assert v['__ansible_vault'] == t

    # test network_interface_spec
    s = internal_data.network_interface_spec
    v = encoder.default(s)


# Generated at 2022-06-20 15:51:22.975514
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass1:
        def __repr__(self):
            return 'TestClass1'

    class TestClass2(TestClass1):
        def __init__(self, value):
            self.value = value

    class TestClass3(TestClass1):
        def __repr__(self):
            return 'TestClass3'

    class TestClass4(TestClass1):
        def __init__(self, value):
            self.value = value

    class TestClass5(TestClass1):
        def __init__(self, value):
            self.value = value

    class TestClass6:
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return 'TestClass6'


# Generated at 2022-06-20 15:51:27.597762
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml import objects
    import json

    string = objects.AnsibleUnsafeText('string')
    data = {u'string': string}

    json_unsafe = json.dumps(data, cls=AnsibleJSONEncoder)

    assert(json_unsafe == '{"string": {"__ansible_unsafe": "string"}}')

# Generated at 2022-06-20 15:51:36.461542
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic

    value = {'key': ansible.module_utils.basic.AnsibleUnsafe('x@example.com')}
    result = json.dumps(value, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    result = json.loads(result)

    assert isinstance(result, dict)
    assert 'key' in result
    assert isinstance(result['key'], dict)
    assert '__ansible_unsafe' in result['key']
    assert result['key']['__ansible_unsafe'] == 'x@example.com'

# Generated at 2022-06-20 15:51:44.764265
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    data_unsafe = {
        's':'@unsafe',
        'i':[1,2,3],
        'f':{'@unsafe':'4'}
    }
    data_safe = {
        's':'@vault',
        'i':[1,2,3],
        'f':{'@vault':'4'}
    }
    data_unsafe_preprocessed = {
        's':{'__ansible_unsafe':'@unsafe'},
        'i':[1,2,3],
        'f':{'__ansible_unsafe':'4'}
    }

# Generated at 2022-06-20 15:51:55.508660
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class MyClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # basic test
    obj = {"k1": "v1",
           "k2": [1, "v1", "v2"],
           "k3": {"k3_1": "v3_1", "k3_2": ["v3_2_1", "v3_2_2"]},
           "k4": MyClass("v4_1", "v4_2")}

# Generated at 2022-06-20 15:52:06.646569
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(0) == 0
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default('0') == '0'
    assert AnsibleJSONEncoder().default('1') == '1'
    assert AnsibleJSONEncoder().default([None]) == [None]
    assert AnsibleJSONEncoder().default({'a': 'b'}) == {"a": "b"}
    assert AnsibleJSONEncoder().default(datetime.datetime.utcnow()) == datetime.datetime.utcnow().isoformat()

# Generated at 2022-06-20 15:52:45.361946
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    encoder = AnsibleJSONEncoder()

    # AnsibleUnsafe object
    ansible_unsafe = text_type('ansible_unsafe')
    ansible_unsafe.__UNSAFE__ = True
    ansible_unsafe.__ENCRYPTED__ = False
    assert(encoder.default(ansible_unsafe) == {'__ansible_unsafe': 'ansible_unsafe'})

    # AnsibleVault object
    ansible_vault = VaultLib('$ANSIBLE_VAULT;1.1;AES256', 'ansible_vault')
    ansible_vault.__UNSAFE__ = False
    ansible_vault.__ENCRY

# Generated at 2022-06-20 15:52:56.333914
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class Test:
        def __init__(self, safe, unsafe, encrypted):
            self.safe = safe
            self.unsafe = unsafe
            self.encrypted = encrypted
            return

    class safe_string(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = False

    class unsafe_string(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class encrypted_string(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = True

    safe_str = safe_string('safe')
    unsafe_str = unsafe_string('unsafe')
    encrypted_str = encrypted_string('vault')

    test_data = {'not dictionry': Test('safe', unsafe_str, encrypted_str)}

    # test for it

# Generated at 2022-06-20 15:53:08.306130
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.six import binary_type, text_type, string_types

    # _preprocess_unsafe=False
    o = binary_type(b'\x9e\xc2')
    assert isinstance(o, string_types)
    value = json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=False, check_circular=False)
    assert value == json.dumps(o, check_circular=False)

    o = text_type(u'\u6c49\u5b57')
    assert isinstance(o, string_types)

# Generated at 2022-06-20 15:53:20.204257
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password_file='test/test_vault_password.txt'
    vault = VaultLib(vault_password_file)
    vault_secret = VaultSecret('test_vault_data')

    test_unsafe_data = [
        vault.encrypt('test_text'),
        vault_secret.string,
        # [vault.encrypt('test_text')],
        # [vault_secret.string],
    ]

    for x in test_unsafe_data:
        assert not isinstance(x, str)
        assert json.dumps(x, cls=AnsibleJSONEncoder)

    # JSONEncoder takes care of string types itself unexpectedly.
    # test_uns

# Generated at 2022-06-20 15:53:24.355363
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)


# Generated at 2022-06-20 15:53:35.388218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert AnsibleJSONEncoder().default(datetime.date.today()) == datetime.date.today().isoformat()
    assert AnsibleJSONEncoder().default(['a', 'b']) == ['a', 'b']
    assert AnsibleJSONEncoder().default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}
    assert AnsibleJSONEncoder().default(object()) == NotImplemented
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(0)

# Generated at 2022-06-20 15:53:44.774250
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib  # pylint: disable=import-error

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import Mapping

    mock_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:53:54.528896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    encoder = AnsibleJSONEncoder()

    # test with None
    res = encoder.default(None)
    assert res is None

    # test with Encrypted Vault
    vault_pass = "vault_pass"
    vault_secret = "vault_secret"
    vault_obj = VaultLib([('default', vault_pass)])
    vault_obj.decrypt(vault_secret)
    res = encoder.default(vault_obj)
    assert res == "vault_secret"
    assert type(res) == type

# Generated at 2022-06-20 15:54:04.301551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime
    import random

    class A:
        pass

    # list of (object, encoded_object)