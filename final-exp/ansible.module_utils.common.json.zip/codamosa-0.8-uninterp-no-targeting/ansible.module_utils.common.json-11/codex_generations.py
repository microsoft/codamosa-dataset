

# Generated at 2022-06-20 15:44:09.905547
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, sort_keys=True)
    assert encoder._vault_to_text
    assert encoder._preprocess_unsafe
    assert encoder.sort_keys


# Generated at 2022-06-20 15:44:16.062204
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    va = VaultLib()

    b_unsafe = b'unsafe string'
    b_trans = to_text(b_unsafe, errors='surrogate_or_strict')
    s_trans = to_text(b_unsafe, errors='surrogate_or_strict')
    s_unsafe = s_trans
    s_vault = to_text(va.encrypt(b_unsafe), errors='surrogate_or_strict')
    s_vault_text = to_text(b_unsafe, errors='surrogate_or_strict')

    d_unsafe = {"key": AnsibleUnsafe(b_unsafe)}
    d_plain

# Generated at 2022-06-20 15:44:21.323067
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder()
    o = AnsibleJSONEncoder()
    aje1 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, **o)
    assert(aje1.preprocess_unsafe==True)
    assert(aje1.vault_to_text==True)

# Generated at 2022-06-20 15:44:30.498393
# Unit test for constructor of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:44:32.773985
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    actual_encoder = AnsibleJSONEncoder()
    assert isinstance(actual_encoder, AnsibleJSONEncoder)


# Generated at 2022-06-20 15:44:35.942810
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(True) == True
    assert ansible_json_encoder.default('True') == 'True'

# Generated at 2022-06-20 15:44:45.869106
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.parsing.convert_bool import boolean

    ustr = to_unicode(u"ansible\u0000unsafe")  # This is what unsafe strings look like
    ustr_latin1 = to_unicode(u"ansible\xe9unsafe")
    # We simulate an unsafe unicode string (unsafe strings are bytes not unicode)
    ustr_unicode = ustr.encode("utf-8").decode("unicode_escape")
    # We simulate an unsafe unicode string with a non ascii char (unsafe strings are bytes not unicode)

# Generated at 2022-06-20 15:44:47.057993
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), json.JSONEncoder)

# Generated at 2022-06-20 15:44:52.384958
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.text.converters import to_bytes
    # add isinstance of Safetext to the check
    if hasattr(to_bytes, '__UNSAFE__'):
        from ansible.module_utils.common.text.converters import to_safe

    def test_AnsibleJSONEncoder_default_instance(o):
        '''
        test default with objects o
        :param o: objects to test
        :return:
        '''
        res = AnsibleJSONEncoder().default(o)
        assert res == o

    def test_AnsibleJSONEncoder_default_dict(o):
        '''
        test default with dict o
        :param o: dict to test
        :return:
        '''
        dict_item = dict(o)

        res

# Generated at 2022-06-20 15:44:58.673269
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeObject
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeDict
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeUrl
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeLookup

    unsafe_text_object = AnsibleUnsafeText(b"unsafe_text")
    unsafe_bytes_object = AnsibleUnsafeBytes(b"unsafe_bytes")
    unsafe_object_object = AnsibleUnsafeObject(b"unsafe_object")
    unsafe

# Generated at 2022-06-20 15:45:11.532915
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe_text = 'core: (${core_value}/core_${core_value})'
    unsafe_text_encoded = 'core: (${{core_value}}/core_${{core_value}})'
    vault_text = 'core: ${core_value}'
    vault_text_encoded = 'core: ${{core_value}}'
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert encoder.default(json.JSONEncoder().encode({})) == {}
    assert encoder.default(json.JSONEncoder().encode([])) == []
    assert encoder.default(json.JSONEncoder().encode('')) == ''
    assert encoder.default(json.JSONEncoder().encode(1)) == 1

# Generated at 2022-06-20 15:45:22.897560
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import range
    import datetime
    import unittest

    # test custom_type, which implements __str__
    # and inherits from string type
    class custom_type(text_type):
        pass

    class TestAnsibleJSONEncoder(unittest.TestCase):
        """
        Unit test class for AnsibleJSONEncoder iterencode
        """

        # test simple string

# Generated at 2022-06-20 15:45:32.346765
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    origin_data = {'foo': 'bar',
                   'ansible_unsafe_data': 'unsafe data',
                   'ansible_safe_data': 'safe data',
                   'ansible_vault_data': 'vault data',
                   'ansible_vault_pw': 'vault pw'}

    vault = VaultLib([VaultSecret('ansible_vault_pw')])
    origin_data['ansible_vault_data'] = vault.encrypt(to_text(origin_data['ansible_vault_data']))

# Generated at 2022-06-20 15:45:43.830210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class FakeAnsibleVault():
        def __init__(self):
            self.ciphertext = 'foobar'

    class FakeAnsibleUnsafe():
        def __init__(self):
            self.unsafe = 'unsafe'

    class FakeAnsibleObject():
        def __init__(self):
            self.foo = 'bar'

    ansible_vault = FakeAnsibleVault()
    ansible_unsafe = FakeAnsibleUnsafe()
    ansible_object = FakeAnsibleObject()


# Generated at 2022-06-20 15:45:52.946251
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_obj = AnsibleJSONEncoder()
    assert(test_obj._preprocess_unsafe == False)
    assert(test_obj._vault_to_text == False)
    assert(isinstance(test_obj, json.JSONEncoder))

    test_obj = AnsibleJSONEncoder(True)
    assert(test_obj._preprocess_unsafe == True)
    assert(test_obj._vault_to_text == False)
    assert(isinstance(test_obj, json.JSONEncoder))

    test_obj = AnsibleJSONEncoder(False, True)
    assert(test_obj._preprocess_unsafe == False)
    assert(test_obj._vault_to_text == True)
    assert(isinstance(test_obj, json.JSONEncoder))

# Generated at 2022-06-20 15:46:02.801424
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys

    def _repr(o):
        """Helper to mimic the default behavior of ``json.JSONEncoder``
        """
        return o.__repr__()

    # test: str
    # default behavior
    assert json.JSONEncoder().iterencode('foo') == '"foo"'

    # test: AnsibleUnsafe
    # custom behavior
    assert list(AnsibleJSONEncoder().iterencode(AnsibleUnsafe('foo'))) == ['{', '"', '_', '_', 'a', 'n', 's', 'i', 'b', 'l', 'e', '_', 'u', 'n', 's', 'a', 'f', 'e', '"', ':', '"', 'f', 'o', 'o', '"', '}']

    # test: iterable


# Generated at 2022-06-20 15:46:04.644294
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    expected = json.dumps({"key": "value"})
    actual = json.dumps({"key": "value"}, default=encoder.default)
    assert expected == actual



# Generated at 2022-06-20 15:46:15.175291
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    import json

    regular_list = ["string", AnsibleUnsafeText("*secret_password*"), 123,
                    {"a_dict_with_unsafe": AnsibleUnsafeText("*secret_password*")},
                    {"another_dict_with_safe_entry_at_unsafe_key": "safe_value"}]

    expected_list = ["string", {"__ansible_unsafe": "*secret_password*"}, 123,
                     {"a_dict_with_unsafe": {"__ansible_unsafe": "*secret_password*"}},
                     {"another_dict_with_safe_entry_at_unsafe_key": "safe_value"}]


# Generated at 2022-06-20 15:46:26.119477
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test default encoding
    assert AnsibleJSONEncoder().default("a string") == "a string"
    assert AnsibleJSONEncoder().default(u"a string") == u"a string"

    # Test encoding of datetime
    expected_date = "1994-11-05"
    assert AnsibleJSONEncoder().default(datetime.date(1994, 11, 5)) == expected_date

    expected_datetime = "1994-11-05T13:15:30"
    assert AnsibleJSONEncoder().default(datetime.datetime(1994, 11, 5, 13, 15, 30)) == expected_datetime

    # Test encoding of mappings
    expected_dict = {'a': 'string'}
    assert AnsibleJSONEncoder().default({'a': 'string'}) == expected_dict

    # Test encoding of objects


# Generated at 2022-06-20 15:46:31.706745
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default(False) is False
    assert AnsibleJSONEncoder().default(1) == 1

    assert AnsibleJSONEncoder().default(datetime.date(2019, 8, 17)) == '2019-08-17'
    assert AnsibleJSONEncoder().default(datetime.datetime(2019, 8, 17, 1, 20)) == '2019-08-17T01:20:00'

# Generated at 2022-06-20 15:46:41.207374
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    # note: The secret is not encrypted. It is base64 encoded.

# Generated at 2022-06-20 15:46:46.593482
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    
    x = '{"a":{"b":{"c":{"d":"test", "e":"test"}, "test1":"test"}}}'
    ansibleJSONEncoder = AnsibleJSONEncoder()
    y = json.loads(x)
    z = json.dumps(y, cls=ansibleJSONEncoder)
    assert z == x
    

if __name__ == "__main__":
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:46:52.350239
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    data = {'foo': 'bar', 'baz': {'a': 1, 'b': 'secret', 'c': 2, 'd': AnsibleUnsafeText('useless')}}
    e = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json.loads(e.encode(data)) == {"foo": "bar", "baz": {"a": 1, "b": "secret", "c": 2,
                                                               "d": {"__ansible_unsafe": "useless"}}}

# Generated at 2022-06-20 15:46:58.760396
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    test_data1 = dict(a=u'\ue0a1')
    test_data2 = dict(a=u'\xe0a1')
    assert json_encoder.default(test_data1) == {'a': u'\ue0a1'}
    assert json_encoder.default(test_data2) == {'a': u'\xe0a1'}

# Generated at 2022-06-20 15:47:00.416910
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    encoder = AnsibleJSONEncoder()
    assert(isinstance(encoder, json.JSONEncoder))

# Generated at 2022-06-20 15:47:04.343889
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = [
        {'key1': 'val1', 'key2': ['arr1']},
        {'key1': 'val1', 'key2': {'arr1': 'arr_val1'}}
    ]

    for test_value in test_data:
        assert(json.loads(json.dumps(test_value, cls=AnsibleJSONEncoder)))



# Generated at 2022-06-20 15:47:16.243841
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    class TestAnsibleSafe(str):
        pass

    class TestAnsibleUnsafe(TestAnsibleSafe):
        __UNSAFE__ = True

    class TestAnsibleVault(TestAnsibleSafe):
        __ENCRYPTED__ = True

        def __init__(self, value, ciphertext):
            super(TestAnsibleVault, self).__init__(value)
            self._ciphertext = ciphertext

    assert encoder.default(TestAnsibleSafe('hello')) == 'hello'
    assert encoder.default(TestAnsibleUnsafe('hello')) == 'hello'
    assert encoder.default(TestAnsibleVault('hello', 'world')) == {'__ansible_vault': 'world'}




# Generated at 2022-06-20 15:47:17.593435
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder == encoder
    assert encoder != AnsibleJSONEncoder()


# Generated at 2022-06-20 15:47:25.869869
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test for method default of class AnsibleJSONEncoder
    #
    # Return an object in JSON format
    #
    # Return a JSON string representation of a Python data structure.

    # Some Ansible module return True/False and we want to dump it as a boolean (test #1)
    encoder = AnsibleJSONEncoder()
    result = encoder.encode(True)
    assert result == "true"
    result = encoder.encode(False)
    assert result == "false"

    # Test #2 : dict value with no special key
    encoder = AnsibleJSONEncoder()
    result = encoder.encode({'fqdn': 'test.example.org', 'ip': '192.168.1.1'})

# Generated at 2022-06-20 15:47:27.330224
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("test") == "test"


# Generated at 2022-06-20 15:47:42.193711
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_value = 'AnsibleUnsafe'
    json_string = json.dumps(test_value, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, separators=(',', ': '))
    assert json_string == '"AnsibleUnsafe"'

    json_string = json.dumps(test_value, cls=AnsibleJSONEncoder, sort_keys=True, indent=4, separators=(',', ': '), preprocess_unsafe=True)
    assert json_string == '{\n    "__ansible_unsafe": "AnsibleUnsafe"\n}'


# Generated at 2022-06-20 15:47:49.326834
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    value = 'test'
    vault = {'__ansible_vault': 'test'}
    unsafe = {'__ansible_unsafe': 'test'}
    module = {'test':'test'}
    assert AnsibleJSONEncoder(vault_to_text=False,preprocess_unsafe=False).default(value) == value
    assert AnsibleJSONEncoder(vault_to_text=False,preprocess_unsafe=False).default(vault) == vault
    assert AnsibleJSONEncoder(vault_to_text=False,preprocess_unsafe=False).default(unsafe) == unsafe
    assert AnsibleJSONEncoder(vault_to_text=False,preprocess_unsafe=False).default(module) == module

# Generated at 2022-06-20 15:47:51.248155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = AnsibleJSONEncoder()
    test = datetime.date(2011, 2, 5)
    expected = '2011-02-05'
    assert isinstance(a, AnsibleJSONEncoder)
    assert isinstance(a, json.JSONEncoder)
    assert a.default(test) == expected


# Generated at 2022-06-20 15:47:58.504064
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.json_utils import from_json, to_json
    from ansible.module_utils._text import to_bytes
    from tempfile import NamedTemporaryFile

    # Create vault file and safe it to disk
    v = VaultLib([])
    pw1 = VaultLib.gen_password(length=10, symbols=False)
    pw2 = VaultLib.gen_password(length=10, symbols=False)
    text = '{"a": "%s", "b": "%s"}' % (pw1, pw2)

    f = NamedTemporaryFile(delete=False)

# Generated at 2022-06-20 15:48:00.146321
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    v = "string to be encoded"
    assert AnsibleJSONEncoder().default(v) == v



# Generated at 2022-06-20 15:48:06.840231
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder._preprocess_unsafe == False
    assert json_encoder._vault_to_text == False
    assert json_encoder.check_circular == True
    assert json_encoder.allow_nan == True
    assert json_encoder.sort_keys == False
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert json_encoder._preprocess_unsafe == True
    assert json_encoder._vault_to_text == True

# Generated at 2022-06-20 15:48:14.811440
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.six as six
    from ansible.module_utils.basic import AnsibleUnsafe
    result = list(AnsibleJSONEncoder().iterencode(AnsibleUnsafe("$ANSIBLE_VAULT")))
    assert result == ['{',
                      '"__ansible_unsafe": "$ANSIBLE_VAULT"',
                      '}']
    if six.PY3:
        assert result[1] == '{"__ansible_unsafe": "$ANSIBLE_VAULT"}'



# Generated at 2022-06-20 15:48:24.299960
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {'with_sensitive_data': {'username': 'demouser', 'password': 'demopass'},
            'with_encrypted_data': {'username': 'demouser', 'password': 'demopass'},
            'with_plain_data': {'username': 'demouser', 'password': 'demopass'}}

    encoded_data = json.dumps(data,
                              cls=AnsibleJSONEncoder,
                              sort_keys=True,
                              indent=2,
                              ensure_ascii=False)

    # Check if the JSON is correctly encoded.
    assert encoded_data.startswith('{')
    assert encoded_data.endswith('}')

    # Check if the sensitive and encrypted data is correctly encoded.

# Generated at 2022-06-20 15:48:32.612469
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing import vault
    from ansible.module_utils.common._collections_compat import Mapping

    plaintext_vault_string = "test_password"
    vault_password = "vault_password"
    vault_object = vault.VaultLib(vault_password)
    ciphertext_vault_string = vault_object.encrypt(plaintext_vault_string).strip()
    plaintext_unsafe_string = "# Include the password as plain text"
    unsafe_object = vault.AnsibleUnsafeText(plaintext_unsafe_string)
    ansible_vars = {'vault_string': vault_object.encrypt(plaintext_vault_string), 'unsafe_string': unsafe_object}

    # Test that vault strings are correctly encoded as __ansible_vault

# Generated at 2022-06-20 15:48:33.797413
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    m = AnsibleJSONEncoder()
    assert m


# Generated at 2022-06-20 15:48:47.926395
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    # test iterencode() with AnsibleUnsafe
    unsafe = VaultLib(['password']).encrypt('xyz')
    assert list(encoder.iterencode(unsafe)) == ['{"__ansible_unsafe": "xyz"}']

    # test iterencode() with ansible_vault
    vaulted = VaultLib(['password']).encrypt('abc')
    assert list(encoder.iterencode(vaulted)) == ['{"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          21356435666...E=\n          "}']

    # test iterencode() with M

# Generated at 2022-06-20 15:48:50.301569
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)

# Generated at 2022-06-20 15:49:01.197453
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test for default constructor
    encoder_class = AnsibleJSONEncoder()
    assert encoder_class._preprocess_unsafe == False
    assert encoder_class._vault_to_text == False

    # Test for constructor with preprocess_unsafe=True
    encoder_class = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder_class._preprocess_unsafe == True
    assert encoder_class._vault_to_text == False

    # Test for constructor with vault_to_text=True
    encoder_class = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder_class._preprocess_unsafe == False
    assert encoder_class._vault_to_text == True

    # Test for constructor with preprocess_unsafe=True, vault

# Generated at 2022-06-20 15:49:08.702488
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    print(a.default('string'))
    print(a.default('string'))
    print(a.default('\u0412\u0438\u043a\u0442\u043e\u0440\u0438\u044f'))
    print(a.default(b'string'))
    print(a.default(u'\u0412\u0438\u043a\u0442\u043e\u0440\u0438\u044f'))


if __name__ == '__main__':
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:49:16.808171
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    cls = AnsibleJSONEncoder()
    assert cls._preprocess_unsafe is False
    assert cls._vault_to_text is False

    cls = AnsibleJSONEncoder(True)
    assert cls._preprocess_unsafe is True
    assert cls._vault_to_text is False

    cls = AnsibleJSONEncoder(vault_to_text=True)
    assert cls._preprocess_unsafe is False
    assert cls._vault_to_text is True

    cls = AnsibleJSONEncoder(True, True)
    assert cls._preprocess_unsafe is True
    assert cls._vault_to_text is True


# Generated at 2022-06-20 15:49:28.504509
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText
    from ansible.vars.hostvars import HostVars
    from io import StringIO
    from ansible.module_utils.six import PY3
    import base64

    a_str = '☃' if PY3 else b'\xe2\x98\x83'

    # with preprocess_unsafe and vault_to_text
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    # str
    s = StringIO()
    result = list(encoder.iterencode(a_str, s))
    assert not result
    assert json.loads(s.getvalue()) == a_str

    # bytes
    s = StringIO()
   

# Generated at 2022-06-20 15:49:29.863364
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    out = AnsibleJSONEncoder().default('test')
    assert out == 'test'



# Generated at 2022-06-20 15:49:30.660416
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder

# Generated at 2022-06-20 15:49:37.807340
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    sample = {'key': 'value', 'key2': datetime.datetime(2019, 1, 1), 'key3': ['value3', datetime.date(2019, 1, 1)]}
    assert json.dumps(sample, cls=AnsibleJSONEncoder) == '{"key": "value", "key2": "2019-01-01T00:00:00", "key3": ["value3", "2019-01-01"]}'



# Generated at 2022-06-20 15:49:38.764120
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
	value = AnsibleJSONEncoder()

# Generated at 2022-06-20 15:49:45.644750
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    unsafe_text = 'hello'
    assert isinstance(AnsibleJSONEncoder(False)(unsafe_text), str)
    assert isinstance(AnsibleJSONEncoder(True)(unsafe_text), str)


# Generated at 2022-06-20 15:49:55.904531
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import iteritems

    from ansible.module_utils import basic

    unsafe_data = "secret"
    vault_data = "$ANSIBLE_VAULT;1.1;AES256\n" + "actual vault data"

    unsafe_object = AnsibleUnsafe(unsafe_data)
    vault_object = AnsibleVaultEncryptedUnicode(vault_data)
    str_object = "my string"
    safe_object = {"my_list": ['item1', 'item2'], "my_dict": {"dict_key1": "value1", "dict_key2": "value2"}}


# Generated at 2022-06-20 15:49:57.140511
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder.__init__

# Generated at 2022-06-20 15:50:08.993222
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    class Foo(object):
        pass
    foo = Foo()
    foo.bar = 'baz'

    result = {}

# Generated at 2022-06-20 15:50:10.224556
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()

# Generated at 2022-06-20 15:50:17.948924
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:50:26.905212
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import time
    import datetime

    obj = VaultLib([('test', 'test')], 'test')
    secret = VaultSecret('test', '5')
    assert encoder.default(obj) == {'__ansible_vault': to_unicode(secret.encrypt(to_unicode('test')))}


# Generated at 2022-06-20 15:50:34.567687
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:50:46.049364
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import queue as Queue
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    inputs = [
        ['hello', 'world'],
        {
            'key1': ['hello', 'world'],
            'key2': {
                'key3': ['hello', 'world'],
                'key4': ['hello', 'world'],
                'key5': {
                    'key6': ['hello', 'world']
                },
            },
        },
    ]

# Generated at 2022-06-20 15:50:56.701864
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test Data
    test_data_dict = [{'test_key': 'test_value'}, {'test_key': 1}, {'test_key': None}, {'test_key': False}]
    expected_list = [{'test_key': 'test_value'}, {'test_key': 1}, {'test_key': None}, {'test_key': False}]

    test_data_list = [['test', 'value'], [1, 2], [None], [False]]
    expected_list.extend(test_data_list)

    test_data_list.append({'test_key': 'test_value'})
    expected_list.append({'test_key': 'test_value'})

    test_data_list.append(['test', 'value'])

# Generated at 2022-06-20 15:51:13.293017
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault

    # Create a dict with a value which is an instance of VaultSecret

# Generated at 2022-06-20 15:51:19.374806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(json.loads(json.dumps(dict(), cls=AnsibleJSONEncoder)) == {})
    assert(json.loads(json.dumps(dict(foo="bar"), cls=AnsibleJSONEncoder)) == {"foo": "bar"})


# Unit tests for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:51:28.655564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test __ENCRYPTED__
    assert json.loads(json.dumps(AnsibleUnsafe('ansible'), cls=AnsibleJSONEncoder)) == 'ansible'
    assert json.loads(json.dumps(AnsibleUnsafe('ansible'), cls=AnsibleJSONEncoder, vault_to_text=True)) == 'ansible'

    # test __UNSAFE__
    assert json.loads(json.dumps(AnsibleUnsafe('ansible'), cls=AnsibleJSONEncoder)) == 'ansible'
    assert json.loads(json.dumps(AnsibleUnsafe('ansible'), cls=AnsibleJSONEncoder, preprocess_unsafe=True)) == {'__ansible_unsafe': 'ansible'}


# Generated at 2022-06-20 15:51:40.571057
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins
    from collections import namedtuple

    # Create a string subclass to test iterencode
    class MyStr(string_types[0]):
        __UNSAFE__ = True

    # Provide a string to represent arg_spec for __call__ method of a module

# Generated at 2022-06-20 15:51:47.392146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import BytesIO, StringIO
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.urls import open_url
    import ansible.utils.unsafe_proxy as unsafe_proxy

    json_encoder = AnsibleJSONEncoder()

    # sort to guarantee ordering of keys in JSON string
    output = json_encoder.encode(dict(sorted(dict(
        vault=VaultLib(StringIO()),
        datetime=datetime.datetime.now(),
        date=datetime.date.today(),
        unsafe=unsafe_proxy.AnsibleUnsafeText('hello')
    ).items())))

    data = json.loads(output)

   

# Generated at 2022-06-20 15:51:51.148674
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
	# Create instance of class AnsibleJSONEncoder
	a = AnsibleJSONEncoder()
	# Check with method 'iterencode'
	assert a.iterencode() == None
	# Check with method 'default'
	assert a.default() == None

# Generated at 2022-06-20 15:51:57.949697
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    value = AnsibleVaultEncryptedUnicode(u'some_vault_encrypted_text')
    assert value.__ENCRYPTED__ is True
    assert json.dumps(value, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "some_vault_encrypted_text"}'
    assert json.dumps(value, cls=AnsibleJSONEncoder, vault_to_text=True) == '"some_vault_encrypted_text"'
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText
    value = AnsibleUnsafeText(u'some_unsafe_text')
    assert value.__UNSAFE__ is True
    assert json.dumps

# Generated at 2022-06-20 15:52:03.969797
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # create an instance of class AnsibleJSONEncoder with preprocess_unsafe=True
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    # test case 1: complex object
    test_obj = {
        'nested_attr': {
            'data1': 'hello'
        },
        'unsafe': 5,
        'vault': 'encrypted_data'
    }
    expected_output = '{"nested_attr": {"data1": "hello"}, "unsafe": {"__ansible_unsafe": "5"}, "vault": "encrypted_data"}'
    actual_output = ''.join(list(ansible_json_encoder.iterencode(test_obj)))
    assert actual_output == expected_output

    # test case 2: a list
    test_

# Generated at 2022-06-20 15:52:11.538632
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type
    import json
    import re

    type_mapping = [
        ('"{0}"', string_types),
        ('{0}', Mapping)
    ]

    safe = '{"unsafe": "value"}'
    vault = '{"ansible_vault": "vault:::value"}'
    unsafe = '{"ansible_vault": "unsafe:::value"}'

    # Bulk test
    for template, obj_type in type_mapping:

        data = obj_type[0](template.format('value'))
        json_data

# Generated at 2022-06-20 15:52:23.345745
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # first test with _preprocess_unsafe=True
    text = '[{"1": "1", "2": 2, "3": "3"}]'
    text_unsafe = "[{u'1': AnsibleUnsafe(u'1'), u'2': AnsibleUnsafe(2), u'3': AnsibleUnsafe(u'3')}]"
    json_obj = [{"1": "1", "2": 2, "3": "3"}]
    json_obj_unsafe = [{u'1': AnsibleUnsafe(u'1'), u'2': AnsibleUnsafe(2), u'3': AnsibleUnsafe(u'3')}]

# Generated at 2022-06-20 15:52:45.462943
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultSecret
    from ansible.plugins.loader import fragmented_load
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import unsafe_text
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.vars.unsafe_proxy import unsafe_bytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeShell
    from ansible.vars.unsafe_proxy import unsafe_shell

    import datetime
    import json
    import collections
    import pytest

    # test vault object
    secret = VaultSecret('abc123')
    assert isinstance(encoder.default(secret), collections.Mapping)


# Generated at 2022-06-20 15:52:56.410070
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text, to_native
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    # Passing a string to json.dumps()
    # Python3.5+:
    # >>> dumps("\ud800")
    # '"\\ud800"'
    # Python2:
    # >>> dumps("\ud800")
    # '"\\ud800"'
    assert json.dumps(u'\ud800') == u'"\\ud800"'

    # Passing a string to json.dump()
    # Python3.5+:
    # >>> json.dumps(u'\ud800')
    # '"\\ud800"'
    # Python2:

# Generated at 2022-06-20 15:53:05.056306
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()
    assert(obj._preprocess_unsafe is False)
    assert(obj._vault_to_text is False)
    obj2 = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert(obj2._preprocess_unsafe is True)
    assert(obj2._vault_to_text is True)

if __name__ == "__main__":
    test_AnsibleJSONEncoder()

# Generated at 2022-06-20 15:53:06.841303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps({}, cls=AnsibleJSONEncoder) == '{}'


# Generated at 2022-06-20 15:53:18.193362
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import collections

    class TestClass:
        def __init__(self):
            self._data={'key':'value'}
        def __getattr__(self,attr):
            return self._data[attr]
        def __getitem__(self,attr):
            return self._data[attr]

    assert json.dumps({'test':TestClass()}, cls=AnsibleJSONEncoder) == '{"test": {"key": "value"}}'
    assert json.dumps(TestClass(), cls=AnsibleJSONEncoder) == "{'key': 'value'}"
    assert json.dumps({'test': collections.deque(['value'])}, cls=AnsibleJSONEncoder) == '{"test": ["value"]}'

# Generated at 2022-06-20 15:53:25.409138
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    class Foo(object):
        pass

    foo = Foo()
    foo.a = 'a'
    foo.b = 2
    foo.c = [1, 2, 3]

    class Bar(object):
        pass
    bar = Bar()
    bar.a = 'a'
    bar.b = 2
    bar.c = [1, 2, 3]
    bar.d = foo

    encoder = AnsibleJSONEncoder()
    res = {'a': 'a', 'b': 2, 'c': [1, 2, 3], 'd': {'a': 'a', 'b': 2, 'c': [1, 2, 3]}}
    assert json.loads(list(encoder.iterencode(bar))[0]) == res

# Generated at 2022-06-20 15:53:35.782718
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import b

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    ## AnsibleUnsafe
    string_unsafe_object = AnsibleUnsafe('string_unsafe_object')
    assert AnsibleJSONEncoder().default(string_unsafe_object) == {'__ansible_unsafe': 'string_unsafe_object'}

    dict_unsafe_object = AnsibleUnsafe({'key': 'value'})
    assert AnsibleJSONEncoder().default(dict_unsafe_object) == {'__ansible_unsafe': '{\n    "key": "value"\n}'}

    list_unsafe_object = Ans

# Generated at 2022-06-20 15:53:44.866656
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-20 15:53:53.598391
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.utils.unsafe_proxy import wrap_var

    o = [wrap_var('secret'),{'password': wrap_var('secret')},'public']
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert list(encoder.iterencode(o)) == ['[',
                                           '{',
                                           '"__ansible_unsafe": "secret"',
                                           '},',
                                           '{',
                                           '"password": {"__ansible_unsafe": "secret"}',
                                           '},',
                                           '"public"',
                                           ']']

# Generated at 2022-06-20 15:53:56.190483
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    jsonEnc = AnsibleJSONEncoder()
    print(jsonEnc)
