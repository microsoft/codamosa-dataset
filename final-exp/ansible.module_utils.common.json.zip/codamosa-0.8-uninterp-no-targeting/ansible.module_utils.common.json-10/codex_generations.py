

# Generated at 2022-06-20 15:44:10.614554
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    import os
    import tempfile

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password = 'password'
    encrypted_vault_file = os.path.join(tempfile.gettempdir(), 'test_json_encoder.yml')
    plain_vault_file = os.path.join(tempfile.gettempdir(), 'test_json_encoder_plain.yml')


# Generated at 2022-06-20 15:44:22.231147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    testcase = [
        (dict(a=1, b=2, c=3), dict(a=1, b=2, c=3)),
        (dict(__ansible_unsafe='foo'), dict(__ansible_unsafe=u"foo")),
        (dict(__ansible_vault='foo'), dict(__ansible_vault='foo')),
        (dict(__ansible_unique_facts=dict(a="b")), dict(__ansible_unique_facts=dict(a="b"))),
        (dict(__ansible_fact_cacheable=dict(a="b")), dict(__ansible_fact_cacheable=dict(a="b"))),
    ]
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-20 15:44:31.119351
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    assert json.dumps( {'a': 2}, cls=AnsibleJSONEncoder ) == json.dumps( {'a': 2} )
    assert json.dumps( {'a': AnsibleUnsafe('c')}, cls=AnsibleJSONEncoder ) == json.dumps( {'a': AnsibleUnsafe('c')} )
    assert json.dumps( {'a': AnsibleUnsafe('c')}, cls=AnsibleJSONEncoder, preprocess_unsafe=False ) == json.dumps( {'a': {'__ansible_unsafe': 'c'}} )

# Generated at 2022-06-20 15:44:41.978747
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # _is_unsafe object
    assert AnsibleJSONEncoder().default(dict(__UNSAFE__=True)) == {'__UNSAFE__': True}

    # _is_vault object
    assert AnsibleJSONEncoder().default(dict(__ENCRYPTED__=True, _ciphertext='foo')) == {'__ansible_vault': 'foo'}

    # ansible collection
    assert AnsibleJSONEncoder().default(dict(__ansible_collections__=True)) == {'__ansible_collections__': True}

    # ansible collection
    assert AnsibleJSONEncoder().default(dict(__ansible_collection_key__='test')) == {'__ansible_collection_key__': 'test'}

# Generated at 2022-06-20 15:44:44.825185
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    unsafe_text = json_encoder.default('This is a test for AnsibleJSONEncoder')
    assert unsafe_text == 'This is a test for AnsibleJSONEncoder'

# Generated at 2022-06-20 15:44:49.234121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({'a': 1}) == {'a': 1}
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert AnsibleJSONEncoder().default(None) != None


# Generated at 2022-06-20 15:45:00.945187
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    import json
    import six

    # test for AnsibleUnsafe
    if six.PY2:
        # ansible_unsafe_test1: \n is encoded as \\n
        ansible_unsafe_test1 = AnsibleUnsafe(b'\n')
        aue1_json_str = ''.join(AnsibleJSONEncoder().iterencode(ansible_unsafe_test1))
        assert json.dumps('\n') == aue1_json_str

        # ansible_unsafe_test2: \r is encoded as \\r
        ansible_unsafe_test2 = AnsibleUnsafe(b'\r')

# Generated at 2022-06-20 15:45:03.667992
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is True

# Generated at 2022-06-20 15:45:13.140000
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert hasattr(enc, '_preprocess_unsafe')
    assert hasattr(enc, '_vault_to_text')
    assert enc._preprocess_unsafe is True
    assert enc._vault_to_text is False

    enc = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert enc._preprocess_unsafe is False
    assert enc._vault_to_text is True


# Unit tests for method default() of class AnsibleJSONEncoder
import sys
if sys.version_info[0] == 2:
    import __builtin__ as builtins
else:
    import builtins


# Generated at 2022-06-20 15:45:25.098106
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import from_json

    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean
    from ansible.module_utils.parsing.convert_datetime import to_datetime, to_iso8601_datetime, to_epoch_seconds
    from ansible.module_utils.six import string_types
    from datetime import datetime as dt

    def encode_and_decode(data, preprocess_unsafe=False, vault_to_text=False):
        return from_json(json.dumps(
            data, cls=AnsibleJSONEncoder, preprocess_unsafe=preprocess_unsafe,
            vault_to_text=vault_to_text
        ))


# Generated at 2022-06-20 15:45:28.180232
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
   jsonstr = AnsibleJSONEncoder()

# Generated at 2022-06-20 15:45:36.042533
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import queue
    from ansible.parsing.vault import VaultLib

    import sys
    if sys.version_info[0] < 3:
        PY2_UNICODE_STRING = unicode  # noqa: F821
        PY2_BYTES_STRING = str  # noqa: F821
    else:
        PY2_UNICODE_STRING = text_type
        PY2_BYTES_STRING = binary_type

    # ========== Test for AnsibleUnsafe ==========
    class AnsibleUnsafeTest(PY2_UNICODE_STRING):
        __UNSA

# Generated at 2022-06-20 15:45:48.490963
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test encrypt objects
    if __name__ == '__main__':
        from ansible.parsing.vault import VaultLib

        import sys

        vault_pass = 'foo'

        plain_value = 'bar'
        plain_text = u'{0}'.format(plain_value)


# Generated at 2022-06-20 15:45:59.319811
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text import ANSIBLE_LOCALHOST
    from ansible.module_utils.common.text import _AnsibleUnsafe
    import types


# Generated at 2022-06-20 15:46:11.031973
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    class MyEqual(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    class MyUnsafe(module.AnsibleUnsafeText):
        def __init__(self, value):
            self.__UNSAFE__ = True
            self.value = value

        def __eq__(self, other):
            return self.value == other.value


# Generated at 2022-06-20 15:46:14.613204
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_str = '{"a": "b"}'
    value = json.loads(json_str)
    ansible_json = json.dumps(value, cls=AnsibleJSONEncoder)
    assert json_str == ansible_json



# Generated at 2022-06-20 15:46:25.841522
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    import datetime
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestClass(object):
        def __init__(self):
            self.a = 1

    class TestUnsafeClass(AnsibleUnsafe):
        def __init__(self):
            self.a = 1

    class TestVaultClass(VaultLib):
        def __init__(self):
            self.a = 1
            super(TestVaultClass, self).__init__()

    class TestDateClass(datetime.date):
        def __init__(self):
            super(TestDateClass, self).__init__()


# Generated at 2022-06-20 15:46:33.653845
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(datetime.date(2019,12,10)) == "2019-12-10"
    unsafe_str = "hello"
    unsafe_str.__UNSAFE__ = True
    assert ansible_json_encoder.default(unsafe_str) == {'__ansible_unsafe': 'hello'}
    unsafe_str.__ENCRYPTED__ = True
    unsafe_str.__UNSAFE__ = False
    assert ansible_json_encoder.default(unsafe_str) == {'__ansible_vault': 'hello'}

# Generated at 2022-06-20 15:46:39.742855
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps({'a': 123, 'b': 'foo'}, cls=AnsibleJSONEncoder) == '{"a": 123, "b": "foo"}'
    assert json.dumps({'a': 123, 'b': u'foo'}, cls=AnsibleJSONEncoder) == '{"a": 123, "b": "foo"}'
    assert json.dumps({'a': 123, 'b': 'fóó'}, cls=AnsibleJSONEncoder) == '{"a": 123, "b": "fóó"}'

    assert json.dumps({'a': 123, 'b': 'fóó'}, ensure_ascii=False, cls=AnsibleJSONEncoder) == '{"a": 123, "b": "fóó"}'

# Generated at 2022-06-20 15:46:49.382761
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default("2") == "2"
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(AnsibleUnsafe("3")) == {'__ansible_unsafe': '3'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVaultEncryptedUnicode("3")) == "3"
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode("3")) == {'__ansible_vault': '3'}
    assert "__ansible_vault" in AnsibleJSON

# Generated at 2022-06-20 15:47:02.210961
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import sys
    import unittest

    class EncoderTest(object):
        pass

    class EncoderResult():
        def __init__(self, value):
            self.value = value

    class TestAnsibleJSONEncoder(unittest.TestCase):

        def setUp(self):
            self.encoder = AnsibleJSONEncoder()
            self.test_encoder_object = EncoderTest()
            self.test_encoder_object.__UNSAFE__ = True
            self.test_encoder_object.__ENCRYPTED__ = True
            self.test_encoder_object.test_string_attribute = '123'
            self.test_encoder_object.test_dict_attribute = {'key': 'value'}
            self.test_encoder_object.test

# Generated at 2022-06-20 15:47:02.720564
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    pass

# Generated at 2022-06-20 15:47:14.904004
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    class TestJSONEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, datetime.datetime):
                return obj.__str__()
            elif isinstance(obj, (datetime.date, datetime.datetime)):
                return obj.isoformat()
            else:
                return super(TestJSONEncoder, self).default(obj)

    json_encoder = TestJSONEncoder(sort_keys=True, indent=2)

    # test 1: test normal case
    json1 = json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=json_encoder)

# Generated at 2022-06-20 15:47:24.305195
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    ansible.parsing.vault.get_vault_secret = lambda: 'a'


# Generated at 2022-06-20 15:47:28.719752
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(indent=4, sort_keys=True, separators=(',', ': '))
    assert encoder.sort_keys is True
    assert encoder.indent == 4
    assert encoder.separators == (',', ': ')

# Generated at 2022-06-20 15:47:40.865503
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    loc = {
        '__ansible_vars': {
            'foo': 'bar',
            'baz': [1, 2, 3],
            'qux': {'quux': 'corge'},
            'grault': datetime.datetime.now()
        }
    }
    data = json.dumps(loc, cls=AnsibleJSONEncoder)
    assert data == '{"__ansible_vars": {"foo": "bar", "baz": [1, 2, 3], "qux": {"quux": "corge"}, "grault": "2019-04-12T18:42:44.908619"}}'

    loc = {'__ansible_unsafe': "unsafe"}
    data = json.dumps(loc, cls=AnsibleJSONEncoder)


# Generated at 2022-06-20 15:47:48.780961
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert '__ansible_unsafe' in AnsibleJSONEncoder().default(object())
    assert AnsibleJSONEncoder().default(object()).get('__ansible_unsafe') == 'unsafe'

    assert '__ansible_vault' in AnsibleJSONEncoder().default(object(__ENCRYPTED__=True))
    assert AnsibleJSONEncoder().default(object(__ENCRYPTED__=True)).get('__ansible_vault') == '__ANSIBLE_VAULT'

    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(object(__ENCRYPTED__=True)) == '__ANSIBLE_VAULT'

    # assert Encoder(vault_to_text=True).default(object(__ENCRYPTED__=True)) == '__ANSIBLE_VA

# Generated at 2022-06-20 15:47:57.384864
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import OrderedDict

    # Create a Vault object
    vault = VaultLib(vault_password_file='/tmp/vaultpass')

    obj = OrderedDict()
    obj['password'] = vault.encrypt('password')
    obj['hostname'] = 'hostname'


# Generated at 2022-06-20 15:48:06.359969
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    test_password = 'test_password'

    # create a vault string
    test_vault = ansible.parsing.vault.VaultLib([(test_password)])
    test_vault_obj = test_vault.encrypt(to_text(test_password, errors='surrogate_or_strict', nonstring='strict'))

    # create an unsafe string
    test_unsafe = ansible.parsing.vault.AnsibleUnsafe(to_text('test_unsafe', errors='surrogate_or_strict', nonstring='strict'))

    test_list = ['test1', test_unsafe, 'test2']
    test_dict = {'test1': 'test1', 'test2': test_unsafe}

# Generated at 2022-06-20 15:48:17.309194
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.common.text.converters import to_bytes

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    encoder = AnsibleJSONEncoder()

    assert encoder.default(AnsibleUnsafe('False')) == {'__ansible_unsafe': u'False'}
    assert encoder.default(AnsibleVault('False')) == {'__ansible_vault': u'False'}

    date_str = u'2019-11-28'
    date_obj = datetime.date(2019, 11, 28)
    assert encoder.default(date_str) == date_str

# Generated at 2022-06-20 15:48:28.797316
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    o = AnsibleUnsafe('value')
    it = AnsibleJSONEncoder().iterencode(o)

    assert next(it) == '{'
    assert next(it) == '"__ansible_unsafe": '
    assert next(it) == '"value"'
    assert next(it) == '}'

# Generated at 2022-06-20 15:48:40.471936
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_line = "test_line"
    with open("test_AnsibleJSONEncoder.json", "w") as f:
        json.dump(test_line, f, cls=AnsibleJSONEncoder)
    
    json.dumps(test_line, cls=AnsibleJSONEncoder)
    test_line = {"test_key": "test_value"}
    json.dumps(test_line, cls=AnsibleJSONEncoder)
    json.dumps("test_line", cls=AnsibleJSONEncoder)
    
    # Test is_unsafe
    assert _is_unsafe("") == False
    assert _is_unsafe("test_ansible_unsafe") == False
    test_line = {"__UNSAFE__": True}
    assert _is_unsafe

# Generated at 2022-06-20 15:48:50.163049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class UnsafeObj:
        __UNSAFE__ = True

    class VaultObj:
        __ENCRYPTED__ = True

    test_obj = [
        'foo',
        {'foo': 'bar', '__UNSAFE__': True},
        [UnsafeObj(), 'bar'],
        {'foo': UnsafeObj(), 'bar': 'baz'},
        VaultObj(),
        datetime.datetime(year=2018, month=1, day=1, hour=1, minute=1, second=1),
    ]

    for obj in test_obj:
        encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
        result = encoder.encode(obj)
        assert result == json.dumps(obj, cls=AnsibleJSONEncoder)



# Generated at 2022-06-20 15:49:01.093232
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.vars import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    def _check_encode_unsafe_text_as_dict(value):
        s = json.dumps(value, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
        rt = json.loads(s)
        assert rt.get("__ansible_unsafe") == 'strval'

    def _check_encode_unsafe_bytes_as_dict(value):
        s = json.dumps(value, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
        rt = json.loads(s)

# Generated at 2022-06-20 15:49:06.246890
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    test_string = 'this is a test string'
    unsafe_string = AnsibleUnsafe(test_string)
    encoded_string = AnsibleJSONEncoder().iterencode(unsafe_string)
    assert encoded_string == '[\n    {{{"__ansible_unsafe": "{}"}}}\n]'.format(json.dumps(test_string))

# Generated at 2022-06-20 15:49:16.138597
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    value = {'str': 'str', 'int': 1, 'list': [1, 2, 3], 'dict': {'str': 'str', 'int': 1}}
    value_encoded = json.dumps(value, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    value2 = value.copy()
    value2['unsafe'] = AnsibleUnsafeText('{')
    value2_encoded = json.dumps(value2, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert value_encoded == '{"str": "str", "int": 1, "list": [1, 2, 3], "dict": {"str": "str", "int": 1}}'
   

# Generated at 2022-06-20 15:49:28.188589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    test_vault_obj = VaultLib('test')
    test_vault_obj._ciphertext = "abcdefghijklmnopqrstuvwxyz"

    test_date = datetime.datetime.now()

    test_dict = {'k1': 'v1', 'k2': 'v2'}

    test_obj = {'int': 1, 'bool': True, 'vault_obj': test_vault_obj, 'date': test_date, 'dict': test_dict}

    from ansible.vars import AnsibleUnsafe
    test_obj['unsafe_bytes'] = AnsibleUnsafe(b'unsafe_bytes')
    test_obj['unsafe_string'] = AnsibleUnsafe('unsafe_string')


# Generated at 2022-06-20 15:49:34.009390
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.module_utils.basic
    unsafe = ansible.module_utils.basic.AnsibleUnsafe('unsafe')
    assert _is_unsafe(unsafe)
    assert len(list(_preprocess_unsafe_encode(unsafe))) == 1
    assert len(list(_preprocess_unsafe_encode([]))) == 0
    assert len(list(_preprocess_unsafe_encode({}))) == 0



# Generated at 2022-06-20 15:49:36.212847
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    # Using the AnsibleJSONEncoder class without any parameters
    assert AnsibleJSONEncoder() != None

    # Using the AnsibleJSONEncoder class with parameters
    assert AnsibleJSONEncoder(**{'preprocess_unsafe': False,
                                 'vault_to_text': False}) != None

# Generated at 2022-06-20 15:49:47.515809
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    test_data = dict(
        ansible_safe_string='ABCDEF',
        ansible_unsafe_string=AnsibleUnsafe('ABCDEF'),
        ansible_unsafe_list=['ABCDEF', AnsibleUnsafe('ABCDEF'), [AnsibleUnsafe('ABCDEF')]],
        ansible_unsafe_dict=dict(a=AnsibleUnsafe('ABCDEF'), b=['ABCDEF', AnsibleUnsafe('ABCDEF')]),
        ansible_unsafe_dict_with_unicode=dict(a=u'βžžΣΘ', b=AnsibleUnsafe(u'βžžΣΘ')),
    )

    # Iterencode with ansible_unsafe_string
    json_

# Generated at 2022-06-20 15:50:03.192732
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default({"a": "b"}) == {"a": "b"}



# Generated at 2022-06-20 15:50:12.904012
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    import re

    def repl(m):
        if m.group(1) == '"':
            return "'"
        return m.group(1)

    def escape_string(value):
        # Note: re.sub is required to handle strings with other python escape sequences
        value = re.sub(r'([\'\"\\])', repl, value)
        return "'{value}'".format(value=value)

    def assert_iterencode(value):
        expected_result = []
        expected_pattern = []

# Generated at 2022-06-20 15:50:16.466075
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Test constructor
    AnsibleJSONEncoder()

    test_import_path = "library.tests.unit.utils.json_utils"
    assert AnsibleJSONEncoder.__module__ == test_import_path

# Generated at 2022-06-20 15:50:21.295841
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-20 15:50:30.989700
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    class MyUnsafeText(AnsibleUnsafeText):
        pass

    text = MyUnsafeText('my text')
    vault = VaultLib(password='password')
    encrypted = vault.encrypt('my text')

    myUnsafeDict = dict(text=text, encrypted=encrypted)

    str_result = json.dumps(myUnsafeDict, cls=AnsibleJSONEncoder, preprocess_unsafe=False, vault_to_text=False)
    dict_result = json.loads(str_result)
    assert dict_result['text'] == '{__ansible_unsafe}my text'

# Generated at 2022-06-20 15:50:35.971340
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    result = AnsibleJSONEncoder(sort_keys=True, indent=2, preprocess_unsafe=True, vault_to_text=True)
    assert result is not None
    assert result._preprocess_unsafe == True
    assert result._vault_to_text == True


# Generated at 2022-06-20 15:50:47.412464
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import time
    import datetime
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    decrypted_vault = VaultLib("password")
    encrypted_vault = VaultLib("password", lambda x: x)

    class sample_date(object):
        def __init__(self, year, month, day):
            self.year = year
            self.month = month
            self.day = day

        def __getitem__(self, index):
            if index == 0:
                return self.year
            elif index == 1:
                return self.month
            elif index == 2:
                return self.day
            else:
                raise IndexError("index out of range")


# Generated at 2022-06-20 15:50:57.609876
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        from ansible.parsing.yaml import datetime_representer
        from ansible.parsing.yaml.objects import AnsibleUnsafe
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    except(ImportError, SyntaxError):
        pass
    else:

        encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

        input_datetime = datetime.datetime(2003, 5, 9, 12, 11, 10)
        output_datetime = {'__ansible_unsafe': '2003-05-09T12:11:10'}
        assert json.loads(encoder.encode(input_datetime)) == output_datetime

        input_ansible_vault_encrypted_unicode = AnsibleVaultEnc

# Generated at 2022-06-20 15:51:09.481377
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes

    # preprocess_unsafe
    data = {
        'value': u'text',
        'unsafe_value': u'\u041F\u0440\u0438\u0432\u0435\u0442'.encode('utf-8'),
        'list': [
            u'text',
            u'\u041F\u0440\u0438\u0432\u0435\u0442'.encode('utf-8'),
        ],
        'dict': {
            'value': u'text',
            'unsafe_value': u'\u041F\u0440\u0438\u0432\u0435\u0442'.encode('utf-8'),
        }
    }


# Generated at 2022-06-20 15:51:22.016413
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_native

    sample_json_string = '{"test_1": "test_2"}'
    sample_json_string_2 = '{"__ansible_unsafe": "test_2"}'
    sample_json_string_3 = '{"__ansible_vault": "test_2"}'
    sample_json_string_4 = '{"test_1": "test_2", "test_3": "test_4"}'
    sample_json_dict = {"test_1": "test_2"}

    # Test default constructor
    e = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:51:44.297313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # empty object
    default = AnsibleJSONEncoder().default({})
    assert type(default) is dict

    # date object
    date = datetime.date(2018, 1, 1)
    default = AnsibleJSONEncoder().default(date)
    assert default == date.isoformat()

    # json object
    class CustomJSONEncoder(json.JSONEncoder):
        def default(self, o):
            return 'this is a json object'
    json_obj = CustomJSONEncoder().encode({})
    default = AnsibleJSONEncoder().default(json_obj)
    assert default == 'this is a json object'

    # hostvars object
    class HostVars(dict):
        pass
    hostvars = HostVars({'test': 'test'})

# Generated at 2022-06-20 15:51:55.474723
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.module_utils.six import b
    from datetime import date
    from datetime import datetime

    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback

    # test encrypt vault
    vault = VaultAES256.new(b('test'))
    vault_str = to_text(vault, errors='surrogate_or_strict')

# Generated at 2022-06-20 15:52:02.926321
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()

    assert isinstance(encoder, json.JSONEncoder)
    assert encoder.check_circular == True
    assert encoder.ensure_ascii == True
    assert encoder.indent == None
    assert encoder.separators == (',', ':')
    assert encoder.sort_keys == False
    assert encoder.skipkeys == False
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False



# Generated at 2022-06-20 15:52:11.016526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert '"ansible"' == AnsibleJSONEncoder().encode("ansible")

# Generated at 2022-06-20 15:52:15.913268
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_class_instance = AnsibleJSONEncoder()
    expected_result = "abcd"
    test_string = u"abcd"
    assert expected_result == test_class_instance.default(test_string)


# Generated at 2022-06-20 15:52:27.085316
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.vars import AnsibleUnsafe

    vault_password = 'test'
    vault_text = 'This is a vault test'
    vault_vaulted = VaultLib(vault_password).encrypt(vault_text)


# Generated at 2022-06-20 15:52:31.212386
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    json_dumps = lambda obj: json.dumps(obj, cls=AnsibleJSONEncoder, sort_keys=True, indent=4)

    # Test work of default() method on unsafe object
    class AnsibleUnsafe:
        __UNSAFE__ = True

    assert json_dumps(AnsibleUnsafe()) == '{\n    "__ansible_unsafe": "<<ansible.parsing.utils.AnsibleUnsafe object at 0x7f3c6f8b0240>"\n}'

    # Test work of default() method on vault object
    vault = VaultLib('secret')

# Generated at 2022-06-20 15:52:32.837626
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    j = AnsibleJSONEncoder(indent=4)
    assert j


# Generated at 2022-06-20 15:52:42.970870
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    #With no arguments, a default parser and default unparser are created.
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    #With no arguments, a default parser and default unparser are created.
    assert json.loads(encoder.encode({"user_name":"zhaoshijie","password":"zsj"})) == {"user_name":"zhaoshijie","password":"zsj"}
    #By default, this encoder may not handle all possible types.
    try:
        json.loads(encoder.encode(datetime.datetime.now()))
    except TypeError as e:
        print(e)


# Generated at 2022-06-20 15:52:54.740674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # string
    o = u'str'
    value = encoder.default(o)
    assert value == 'str'

    # int
    o = 1
    value = encoder.default(o)
    assert value == 1

    # dict
    o = dict([('k1', u'v1'), ('k2', 2)])
    value = encoder.default(o)
    assert value == o

    # bool
    o = True
    value = encoder.default(o)
    assert value == True

    # datetime
    o = datetime.datetime(2018, 10, 10, 10, 10, 10)
    value = encoder.default(o)
    assert value == '2018-10-10T10:10:10'

    # date
    o

# Generated at 2022-06-20 15:53:19.948365
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    class TestAnsibleJSONEncoder(unittest.TestCase):
    
        def setUp(self):
            with open('moduletest/fixtures/test_AnsibleJSONEncoder_data.json','r') as testdata:
                self.testdata=testdata.read()
            
        def test_AnsibleJSONEncoder(self):
            self.assertTrue(self.testdata)
            
            import json
            from json import JSONEncoder
            from ansible.module_utils.common.text.encoders import AnsibleJSONEncoder
            from ansible.module_utils.common.text.encoders import AnsibleUnsafe
            
            # The json.dumps method does not work on AnsibleUnsafe objects.
            # The following statement is expected to raise TypeError
            self

# Generated at 2022-06-20 15:53:31.172382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.text.converters import to_unicode
    import datetime
    base_date = datetime.datetime(2001, 2, 3)
    data = {
        'date_object': datetime.datetime(2001, 2, 3, 4, 5, 6, 7),
        'int_object': 10,
        'str_object': 'string',
        'dict_object': {'a': 1},
        'unicode_object': to_unicode('string'),
        'unsafe_object': AnsibleUnsafe('string'),
    }

# Generated at 2022-06-20 15:53:34.337457
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert a._preprocess_unsafe == False
    assert a._vault_to_text == False
    assert a.default == a.default
    assert a.iterencode == a.iterencode
    assert a.encode == a.encode

# Generated at 2022-06-20 15:53:43.965217
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    import json
    import io

    data = {
        u'unicode': u'Ag\xeen\u0308cia \xc3\x8dndia',
        b'binary': u'Ag\xeen\u0308cia \xc3\x8dndia'.encode('utf-8'),
        u'unsafe': AnsibleUnsafe(u'Ag\u0308encia \xc3\x8dndia'),
    }

    with io.open('test_data', 'w', encoding='utf-8') as f:
        json.dump(data, f, cls=AnsibleJSONEncoder)


if __name__ == '__main__':
    test_AnsibleJSONEncoder_iterencode()

# Generated at 2022-06-20 15:53:54.400414
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # The test data is a list of lists.  The first element in each list is the
    # original data to be encoded.  The second element in each list is the
    # expected result after encoding the original data.

    from ansible.module_utils.common._text import AnsibleUnsafe


# Generated at 2022-06-20 15:54:04.218155
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test all possible values of ansible.module_utils.common.unsafe_proxy.UnsafeBytes
    # See:
    # * http://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html#unsafe-bytes-values
    # * http://docs.ansible.com/ansible/latest/dev_guide/developing_modules_general.html#vault-encrypted-values
    # * ansible/module_utils/common/unsafe_proxy.py
    from ansible.module_utils.common.unsafe_proxy import UnsafeBytes, UnsafeText
    import ansible.module_utils.basic