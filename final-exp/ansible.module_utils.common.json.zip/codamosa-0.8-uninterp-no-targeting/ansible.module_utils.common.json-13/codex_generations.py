

# Generated at 2022-06-20 15:44:11.857712
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    if sys.version_info.major == 2:
        assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)\
            .iterencode('\xe9') == (u'"\\u00e9"',)
        assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)\
            .iterencode('\xe9'.decode('utf-8')) == (u'"\\u00e9"',)
    elif sys.version_info.major == 3:
        assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).iterencode('\xe9') == (u'"\\u00e9"',)



# Generated at 2022-06-20 15:44:19.855181
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText

    test_str = AnsibleUnsafeText(u'\u2295')

    json_str = AnsibleJSONEncoder(preprocess_unsafe=True).encode(test_str)
    assert isinstance(json_str, str)
    decoded = json.loads(json_str)

    assert '__ansible_unsafe' in decoded
    assert decoded['__ansible_unsafe'] == u'\u2295'

# Generated at 2022-06-20 15:44:29.605843
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean

    myarg=boolean(True)
    myarg2=AnsibleUnsafe(True)

    test_data = [
        (1, '1'),
        (1.1, '1.1'),
        (None, 'null'),
        ([], '[]'),
        (['a'], '["a"]'),
        ({}, '{}'),
        ({'a': 'b'}, '{"a": "b"}'),
        (myarg, 'true'),
        (myarg2, '{"__ansible_unsafe": "true"}')
    ]


# Generated at 2022-06-20 15:44:40.830413
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode('vault', '$ANSIBLE_VAULT;1.1;AES256', b'encrypted_test')) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVaultEncryptedUnicode('vault', '$ANSIBLE_VAULT;1.1;AES256', b'encrypted_test')) == 'vault'
    assert AnsibleJSONEncoder().default({'test': 'value'}) == {'test': 'value'}
   

# Generated at 2022-06-20 15:44:51.139782
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    # Test a non-dict object that isn't an AnsibleUnsafe subclass
    assert json.loads(list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode("a string"))) == "a string"

    # Test a dict that contains an AnsibleUnsafe item
    test_dict = {
        "a_string": "a string",
        "an_unsafe_string": AnsibleUnsafe("AnsibleUnsafe")
    }

    result = json.loads(list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(test_dict)))

    assert result == {
        "a_string": "a string",
        "an_unsafe_string": {
            "__ansible_unsafe": "AnsibleUnsafe"
        }
    }

    # Test a

# Generated at 2022-06-20 15:45:02.192858
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafeText
    import json
    import six

    class UnsafeJSONEncoder(AnsibleJSONEncoder):
        def iterencode(self, o, **kwargs):
            o = super(UnsafeJSONEncoder, self).iterencode(o, **kwargs)
            if six.PY2:
                o = [x.encode('utf-8') for x in o]
            return o

    obj = [AnsibleUnsafeText(u'UnsafeText')]
    result = json.dumps(obj, cls=UnsafeJSONEncoder).strip('[]').split(',')[1][1:][:-1]
    print(result)

    assert result == "\"__ansible_unsafe\": \"UnsafeText\""



# Generated at 2022-06-20 15:45:03.703746
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)


# Generated at 2022-06-20 15:45:11.464911
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafeClass(str):
        __UNSAFE__ = True

        def __init__(self, value):
            self._value = value

        def __str__(self):
            return self._value

    class AnsibleUnsafeVaultClass(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

        def __init__(self, value):
            self._value = "vault(" + value + ")"
            self._ciphertext = value

        def __str__(self):
            return self._value

    class AnsibleClass(object):
        def __init__(self, value):
            self._value = value

        def __getitem__(self, name):
            return self._value

    json_encoder = AnsibleJSONEncoder()
    # test Ansible

# Generated at 2022-06-20 15:45:22.785997
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    import ansible.vars.unsafe_proxy

    secret_string = 'changeme'
    encrypted_secret = ansible.parsing.vault.VaultLib().encrypt(secret_string)
    unsafe_secret = ansible.vars.unsafe_proxy.AnsibleUnsafeText(secret_string)
    safe_secret = 'not_secret'

    # all should be converted to dict
    test_object = {
        'test1': encrypted_secret,
        'test2': unsafe_secret,
        'test3': safe_secret,
    }
    preprocessed_dict = _preprocess_unsafe_encode(test_object)
    assert '__ansible_vault' in preprocessed_dict['test1']

# Generated at 2022-06-20 15:45:32.269472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    b = AnsibleJSONEncoder()
    assert b.default('short') == 'short'
    assert b.default(u'short') == u'short'
    assert b.default([1, 2, 3]) == [1, 2, 3]
    assert b.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert b.default(['foo', {'bar': ('baz', None, 1.0, 2)}]) == ['foo', {'bar': ('baz', None, 1.0, 2)}]
    assert b.default({'foo': 'bar',
                      'foo': 'baz'}) == {'foo': 'baz'}

# Generated at 2022-06-20 15:45:42.844341
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    if json.JSONEncoder.__init__.__defaults__ is None:
        # This is a Python 2 compatible code path
        # json.JSONEncoder.__init__.__defaults__ is None if running against a Python 3
        e = AnsibleJSONEncoder()
    else:
        # This is a Python 3 compatible code path
        # json.JSONEncoder.__init__.__defaults__ is not None if running against a Python 2
        e = AnsibleJSONEncoder(sort_keys=True, indent=4)


# Generated at 2022-06-20 15:45:48.492632
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import u
    vault_secret_nonunicode = VaultSecret(u('testing@123').encode('ascii'))
    vault_secret_unicode = VaultSecret(u('testing@123'))

    assert isinstance(vault_secret_nonunicode, Sequence)
    assert isinstance(vault_secret_unicode, Sequence)


# Generated at 2022-06-20 15:45:51.569131
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder
    assert hasattr(json_encoder, 'default')
    assert hasattr(json_encoder, 'iterencode')


# Generated at 2022-06-20 15:46:01.662325
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json.dumps({'__ansible_unsafe': '{ "some": "json" }'}) == next(encoder.iterencode({'__ansible_unsafe': '{ "some": "json" }'}))
    assert json.dumps({'__ansible_unsafe': '{ "some": "json" }', 'unsafe_thing': {'__ansible_unsafe': '{ "some": "json" }'}}) == next(encoder.iterencode({'__ansible_unsafe': '{ "some": "json" }', 'unsafe_thing': {'__ansible_unsafe': '{ "some": "json" }'}}))

# Generated at 2022-06-20 15:46:12.914802
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible.parsing.vault
    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.six import text_type, PY2, binary_type, string_types

    def assert_type_str(str):
        if PY2:
            assert isinstance(str, string_types)
        else:
            assert isinstance(str, text_type)

    class AnsiJSONEnc(AnsibleJSONEncoder):
        """Custom JSONEncoder to test the custom iterencode() of AnsibleJSONEncoder"""

        def _encode_b(self, o):
            return o

        def _encode_s(self, o):
            return o

        def _encode_unsafe(self, o):
            return o


# Generated at 2022-06-20 15:46:19.838948
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe


# Generated at 2022-06-20 15:46:22.666346
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Arrange
    aje = AnsibleJSONEncoder()

    # Assert
    assert aje._preprocess_unsafe == False
    assert aje._vault_to_text == False


# Generated at 2022-06-20 15:46:32.751875
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    "Unit test for method iterencode of class AnsibleJSONEncoder"
    module_utils_path = os.path.abspath(__file__)
    base_path = os.path.dirname(os.path.dirname(os.path.dirname(module_utils_path)))
    ansible_unsafe_path = os.path.join(base_path, "lib/ansible/module_utils/_text.py")
    if os.path.exists(ansible_unsafe_path) is False:
        print("Cannot find ansible unsafe path at %s" % ansible_unsafe_path)
        return False
    sys.path.append(os.path.dirname(ansible_unsafe_path))
    from _text import AnsibleUnsafeBytes, AnsibleUnsafeText

    from json import dumps

# Generated at 2022-06-20 15:46:43.432529
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Super call
    assert AnsibleJSONEncoder(sort_keys=True, indent=2).default(None) == json.JSONEncoder(sort_keys=True, indent=2).default(None)

    # Safe strings
    assert AnsibleJSONEncoder(sort_keys=True, indent=2).default(to_text(u'foo')) == json.JSONEncoder(sort_keys=True, indent=2).default(u'foo')

    # Encrypted strings

# Generated at 2022-06-20 15:46:50.871963
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ae = AnsibleJSONEncoder()
    assert not ae._preprocess_unsafe
    assert not ae._vault_to_text

    ae = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ae._preprocess_unsafe
    assert not ae._vault_to_text

    ae = AnsibleJSONEncoder(vault_to_text=True)
    assert not ae._preprocess_unsafe
    assert ae._vault_to_text

    ae = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert ae._preprocess_unsafe
    assert ae._vault_to_text



# Generated at 2022-06-20 15:47:02.248392
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test the method default of class AnsibleJSONEncoder"""
    import ansible.parsing.vault as vault

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # Test unsafe
    unsafe = vault.VaultLib("password").update("__ansible_vault")
    unsafe = unsafe.encode("utf-8")
    result = json.dumps(unsafe, cls=encoder).encode("utf-8")
    assert result == b'{"__ansible_vault": "__ansible_vault"}'

    # Test vault
    vault = vault.VaultLib("password")
    vault_res = vault.encrypt(b"some text")

# Generated at 2022-06-20 15:47:05.537854
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder
    assert AnsibleJSONEncoder().__init__
    assert AnsibleJSONEncoder().default
    assert AnsibleJSONEncoder().iterencode

# Generated at 2022-06-20 15:47:15.472029
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    class Foo(object):
        def __init__(self, value):
            self.value = value

    # ansible types, safe and unsafe text
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('hello world')) == 'hello world'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('hello world')) == {'__ansible_unsafe': 'hello world'}

    # regular types
    assert AnsibleJSONEncoder().default(Foo('hello world')) == {'value': 'hello world'}



# Generated at 2022-06-20 15:47:21.445100
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test with preprocess_unsafe=False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False,
                                 vault_to_text=False)
    assert encoder is not None

    # test with preprocess_unsafe=True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True,
                                 vault_to_text=False)
    assert encoder is not None


# Generated at 2022-06-20 15:47:33.100133
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # simple test for unsafe
    unsafe_str = 'unsafe'
    assert (not _is_unsafe(unsafe_str))
    ansible_unsafe_str = AnsibleUnsafe(unsafe_str)
    assert (not _is_unsafe(ansible_unsafe_str))
    assert (bool(_is_unsafe(AnsibleUnsafe(unsafe_str))))
    assert (bool(_is_unsafe(AnsibleUnsafe(unsafe_str, True))))

    # test for vault
    vault_str = 'vault'
    assert (not _is_vault(vault_str))
    ansible_unsafe_str = AnsibleVaultEncryptedUnsafeText(vault_str)
    assert (bool(_is_vault(ansible_unsafe_str)))

    # test for default

# Generated at 2022-06-20 15:47:44.480431
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    if sys.version_info[0] == 2:
        from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
        from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeBytes
        from ansible.module_utils.common.vault import VaultLib
        from ansible.module_utils.six import BytesIO

        d = {
            's': u'abcde',
            'b': b'abcde',
            'u': AnsibleUnsafeText(u'abcde'),
            'u2': AnsibleUnsafeBytes(b'abcde'),
        }

# Generated at 2022-06-20 15:47:54.517193
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    # initialise vault object
    vault = VaultLib([])
    vault_id = vault.create_encryption_key("test")
    # encrypt a password
    password = vault.encrypt("test", vault_id)
    # encrypted password text

# Generated at 2022-06-20 15:48:05.290677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.module_utils import six

    encoder = AnsibleJSONEncoder()

    # Test for hostvars
    hostvars = {'var1': 'host1', 'var2': 'host2'}
    encoded = json.dumps(hostvars, cls=AnsibleJSONEncoder)
    assert encoded == '{"var1": "host1", "var2": "host2"}'

    # Test for date objects
    date_object = datetime.datetime(2018, 12, 1, 10, 45, 20)

# Generated at 2022-06-20 15:48:06.070380
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder()

# Generated at 2022-06-20 15:48:17.186965
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import json
    import datetime

    vault_password = VaultLib().encrypt('Vault Password')
    unsafe_dict = {'vault': AnsibleUnsafeText(vault_password),
                   'unsafe': AnsibleUnsafeText('Wrong Password'),
                   'date': datetime.datetime.now()}

    encoder = AnsibleJSONEncoder()
    encoded = encoder.encode(unsafe_dict)
    decoder = json.JSONDecoder()
    decoded = decoder.decode(encoded)
    assert decoded['vault']['__ansible_vault'] == vault_password

# Generated at 2022-06-20 15:48:22.689604
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), json.JSONEncoder)


# Generated at 2022-06-20 15:48:31.281947
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common import encrypt_text
    from ansible.module_utils.common._collections_compat import Mapping
    my_vault_password = encrypt_text('password_value', encrypt_vault_id='test_vault_id')
    my_unsafe = encrypt_text('password_value', encrypt_vault_id='test_vault_id', vaule_type='unsafe')
    my_dict = {'unsafe_key':my_unsafe, 'vault_key':my_vault_password, 'raw_value': 'raw_value'}

# Generated at 2022-06-20 15:48:33.262191
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder

# Generated at 2022-06-20 15:48:44.840970
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # import here to avoid cyclic dependencies
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    # AES256
    aes_password = b"ansible12345"
    aes_data = b"this is the secret data!"

    vault_aes = VaultLib(aes_password)
    vault_aes.write(aes_data)

    # Prepend the vault identifier
    vault_aes_data = b"$ANSIBLE_VAULT;1.1;AES256\n" + vault_aes.encode(aes_data).rstrip()
    unsafe_data = AnsibleUnsafeText(vault_aes_data)

    # Test iterencode of AnsibleJSONEncoder.
    ans

# Generated at 2022-06-20 15:48:46.472484
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json.dumps(None, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 15:48:58.306508
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    def _normalize(data):
        if isinstance(data, str):
            data = to_text(data, errors='surrogate_or_strict')
            if data.startswith(u'\ufeff'):
                data = data[1:]
        return data


# Generated at 2022-06-20 15:49:08.262760
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common._collections_compat import DeepSeq
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.encodings import to_unicode
    from ansible.module_utils.common.text.encodings import text_type


# Generated at 2022-06-20 15:49:13.862612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('abc') == 'abc'
    assert encoder.default(u'abc') == u'abc'
    assert encoder.default({'key': 'value'}) == {'key': 'value'}
    assert encoder.default(type('obj', (object,), {'key': 'value'})) == {'key': 'value'}



# Generated at 2022-06-20 15:49:18.105407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    from ansible.parsing.vault import VaultLib, VaultSecret
    test_vault_obj = VaultSecret(VaultLib(b'password'))
    test_str_encoder = encoder.default(test_vault_obj)
    assert isinstance(test_str_encoder['__ansible_vault'], string_types)


# Generated at 2022-06-20 15:49:29.391689
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultUnsafe
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes


# Generated at 2022-06-20 15:49:48.991875
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    class TestClass(object):
        def __init__(self, value):
            self.value = value

    enc = AnsibleJSONEncoder()
    assert enc.default(None) is None
    assert enc.default(True) is True
    assert enc.default(False) is False
    assert enc.default(1) == 1
    assert enc.default(1.1) == 1.1
    assert enc.default([1, 2]) == [1, 2]
    assert enc.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert enc.default(TestClass(1)) == TestClass(1)

# Generated at 2022-06-20 15:49:53.947420
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    testObject = {'key1': VaultLib.VaultEditor(12345), 'key2': VaultLib.VaultEditor('password')}
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    print(ansible_json_encoder.iterencode(testObject))

# Generated at 2022-06-20 15:50:01.694597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    jsonEncoder = AnsibleJSONEncoder(
        skipkeys=False,
        ensure_ascii=True,
        check_circular=True,
        allow_nan=True,
        sort_keys=False,
        indent=None,
        separators=None,
        encoding='utf-8',
        default=None,
        preprocess_unsafe=False,
        vault_to_text=False,
        **{'stream': None, 'bigint_as_string': False, 'item_sort_key': None}
    )
    class AnsibleUnsafeTest(str):
        __UNSAFE__ = True
    class AnsibleVaultTest(str):
        __ENCRYPTED__ = True
    class TestClass():
        var1 = 'var1'
        var2 = 'var2'
   

# Generated at 2022-06-20 15:50:11.673933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import base64
    from ansible.parsing.vault import VaultLib

    # encryption with the old vault format

# Generated at 2022-06-20 15:50:18.715031
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    if not getattr(AnsibleJSONEncoder, '_AnsibleJSONEncoder__test', False):
        return

    # FIXME: Remove this once ``__init__`` is available on Python 2.6
    # See: https://github.com/ansible/ansible/issues/57882
    class AnsibleUnsafe(unicode):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import text_type
    json_str = u'{"foo": "%s", "bar": "%s"}' % (AnsibleUnsafe(u'Insecure value'), AnsibleUnsafe(u'Insecure value'))
    dst = StringIO()

# Generated at 2022-06-20 15:50:27.384940
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:50:34.883311
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

# Generated at 2022-06-20 15:50:39.250436
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    a = AnsibleJSONEncoder()
    assert not a._preprocess_unsafe
    assert not a._vault_to_text
    assert a.ensure_ascii

# Generated at 2022-06-20 15:50:45.041341
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    test_json = {'test': 'a', 'test1': 'b', 'test2': 'c', 'test3': 'd'}
    expected_json = {'test': 'a', 'test1': 'b', 'test2': 'c', 'test3': 'd'}
    test_dict = {'test': 'a', 'test1': 'b', 'test2': vault.encrypt('c'), 'test3': 'd'}
    expected_dict = {'test': 'a', 'test1': 'b', 'test2': {'__ansible_vault': vault._ciphertext}, 'test3': 'd'}

# Generated at 2022-06-20 15:50:50.093716
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 12, 26, 7, 37, 47, 624000)) == '2017-12-26T07:37:47.624000'
    assert AnsibleJSONEncoder().default(datetime.date(2017, 12, 26)) == '2017-12-26'

# Generated at 2022-06-20 15:51:09.381636
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for default method of class AnsibleJSONEncoder
    assert AnsibleJSONEncoder().default(o={'abc': 123}) == {'abc': 123}


# Generated at 2022-06-20 15:51:21.976341
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    ansible_vault = ansible_encoder.default(b'$ANSIBLE_VAULT;')
    assert ansible_vault == {'__ansible_vault': '$ANSIBLE_VAULT;'}

    ansible_unsafe = ansible_encoder.default(b'$ANSIBLE_VAULT')
    assert ansible_unsafe == {'__ansible_unsafe': '$ANSIBLE_VAULT'}

    ansible_date = ansible_encoder.default(datetime.datetime(2016, 1, 1, 0, 0, 0))
    assert ansible_date == '2016-01-01T00:00:00'



# Generated at 2022-06-20 15:51:27.944547
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps(u'ascii', default=AnsibleJSONEncoder()) == '"ascii"'
    assert json.dumps(u'notascii', default=AnsibleJSONEncoder()) == '"notascii"'
    assert json.dumps(b'ascii', default=AnsibleJSONEncoder()) == '"ascii"'
    assert json.dumps(b'notascii', default=AnsibleJSONEncoder()) == '"notascii"'

# Generated at 2022-06-20 15:51:34.546631
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.parsing.convert_bool import boolean
    my_bool = boolean(True)

    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert json.loads(list(ansiblejsonencoder.iterencode({ "key" : my_bool }))[0]) == { "key" : {'__ansible_unsafe': "True"} }



# Generated at 2022-06-20 15:51:35.599096
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder


# Generated at 2022-06-20 15:51:37.586915
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert to_text(json.dumps(None, cls=AnsibleJSONEncoder)) == "null"

# Generated at 2022-06-20 15:51:45.448197
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Tests for types: datetime.date, datetime.datetime, string, unicode, bytes
    date_instance = datetime.date(2020, 1, 24)
    datetime_instance = datetime.datetime(2020, 1, 24, 23, 59, 59)
    str_instance = str('string')
    unicode_instance = to_text('unicode', errors='strict')
    bytes_instance = b'bytes'

    # Tests for classes: AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeString

    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib

    vault_pass = to_text('mypass', errors='strict')
    vault = VaultLib([DEFAULT_VAULT_ID_MATCH])


# Generated at 2022-06-20 15:51:48.843239
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    data = {"parameter_store_key": "stored-password", "key": "password"}
    assert data == json.loads(json.dumps(data, cls=AnsibleJSONEncoder))

# Generated at 2022-06-20 15:51:57.228608
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import random
    import sys
    import string
    import json
    import pytest
    import types
    import datetime
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    # This is the class we are testing
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder
    from ansible.module_utils.common.collections import is_sequence

    # Test data

# Generated at 2022-06-20 15:51:58.650430
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()

# Generated at 2022-06-20 15:52:37.959814
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class _AnsibleUnsafe(object):

        def __init__(self, value):
            self.__UNSAFE__ = True
            self.value = value

        def __str__(self):
            return self.value

        def __unicode__(self):
            return self.value

    vault_secret = VaultSecret('testsecret')
    vault_lib = VaultLib()
    ansible_vault_text = vault_lib.encrypt('testsecret', vault_secret)
    ansible_unsafe_text = to_text(_AnsibleUnsafe('testsecret'), errors='surrogate_or_strict', nonstring='strict')


# Generated at 2022-06-20 15:52:49.662648
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafe
    from ansible.parsing.vault import VaultLockError
    from ansible.parsing.vault import AnsibleVaultError
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretString
    from ansible.parsing.vault import VaultSecretBytes
    from ansible.parsing.vault import VaultSecretDict

    # ansible secret
    class AnsibleSecret(AnsibleUnsafe):
        def __init__(self, secret):
            AnsibleUnsafe.__init__(self, secret.encode('utf-8'))
            self.__UNSAFE__ = True

    value = Ansible

# Generated at 2022-06-20 15:52:51.901913
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-20 15:52:56.986068
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    unsafe_value = object()
    unsafe_value.__UNSAFE__ = True
    unsafe_value.__ENCRYPTED__ = False
    assert encoder.default(unsafe_value) == {'__ansible_unsafe': to_text(unsafe_value, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-20 15:53:08.027289
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    unsafe = AnsibleUnsafe(text_type('something'))
    json_encoder = AnsibleJSONEncoder()

    # Ensure dict encoding works as expected and retains ``__ansible_unsafe`` value
    assert json_encoder.iterencode({'name': unsafe}).next() == '{"name": {"__ansible_unsafe": "something"}}'

    # Ensure list encoding works as expected and retains ``__ansible_unsafe`` value
    assert json_encoder.iterencode({'name': [unsafe]})[0] == '{"name": [{"__ansible_unsafe": "something"}]}'

# Generated at 2022-06-20 15:53:10.788762
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()
    assert obj._preprocess_unsafe == False
    assert obj._vault_to_text == False


# Generated at 2022-06-20 15:53:21.988954
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.utils.unsafe_proxy

    class AnsibleJSONEncoderTest(json.JSONEncoder):
        def default(self, o):
            if getattr(o, '__ENCRYPTED__', False):
                # vault object
                return {'__ansible_vault': to_text(o._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
            elif getattr(o, '__UNSAFE__', False):
                # unsafe object
                return {'__ansible_unsafe': to_text(o, errors='surrogate_or_strict', nonstring='strict')}
            elif isinstance(o, Mapping):
                # hostvars and other objects
                return dict(o)

# Generated at 2022-06-20 15:53:23.541144
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    x = AnsibleJSONEncoder(True)
    assert x._preprocess_unsafe == True

# Generated at 2022-06-20 15:53:34.640866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # AnsibleVaultEncryptedUnicode
    av = AnsibleVaultEncryptedUnicode(u'hello')
    assert AnsibleJSONEncoder(vault_to_text=True).default(av) == 'hello'
    assert AnsibleJSONEncoder(vault_to_text=False).default(av) == {'__ansible_vault': 'hello'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(av) == {'__ansible_vault': 'hello'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(av) == {'__ansible_vault': 'hello'}

    # AnsibleVaultEncryptedUnicode
    au = AnsibleUnsafeText(u'hello')

# Generated at 2022-06-20 15:53:35.423457
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()
