

# Generated at 2022-06-20 15:44:12.760474
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import string
    import random
    import unittest
    from ansible.module_utils.basic import AnsibleUnsafeText
    from ansible.module_utils.six.moves import StringIO

    class MockWrite(object):
        def __init__(self):
            self.data = StringIO()
            self.empty = True
            self.wrote_dict = False

        def __call__(self, buf):
            self.data.write(buf)
            self.empty = False

        def __getattr__(self, name):
            return getattr(self.data, name)

    a_class = type('TestJSON', (object,), {'__module__': 'test_json', '__name__': 'TestJSON'})


# Generated at 2022-06-20 15:44:15.565300
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """Test constructor of class ``AnsibleJSONEncoder``"""
    assert AnsibleJSONEncoder()



# Generated at 2022-06-20 15:44:26.770723
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # The opt_level is set to 0 so the "if cls is None" will be bypassed,
    # which is the fix code for CVE-2019-16935.
    encoder = AnsibleJSONEncoder(sort_keys=True, indent=4, opt_level=0, separators=(',', ': '))

    assert 'null' == encoder.encode(None)
    assert '1' == encoder.encode(1)
    assert '"ansible"' == encoder.encode('ansible')
    assert '{"ansible": "galaxy"}' == encoder.encode({"ansible": "galaxy"})
    assert "[1, 2, 3]" == encoder.encode([1, 2, 3])

# Generated at 2022-06-20 15:44:37.849280
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import sys
    import io

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types, PY3

    # Test with string, int, float, datetime.date and datetime.datetime

# Generated at 2022-06-20 15:44:46.655510
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    class MyClass(object):
        def __init__(self, a):
            self.a = a

    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()
    my_obj = {
        'my_unsafe': AnsibleUnsafe("my_unsafe_string"),
        'my_vault': VaultLib(),
        'my_class': MyClass("my_class_string"),
        'my_class_list': [MyClass("my_class_string0"), MyClass("my_class_string1")],
        'my_class_dict': {'key1': MyClass("my_class_string2")},
    }

# Generated at 2022-06-20 15:44:50.495901
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        json.dumps({}, cls=AnsibleJSONEncoder)
    except TypeError:
        print("AnsibleJSONEncoder is not JSON serializable")



# Generated at 2022-06-20 15:45:01.738610
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    def _test_json(o, preprocess_unsafe=False, vault_to_text=False):
        return json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text,
                          sort_keys=True)

    def _test_round_trip(o, preprocess_unsafe=False, vault_to_text=False):
        j = _test_json(o, preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text)
        return json.loads(j)

    import ansible.parsing.vault
    from ansible.parsing.vault import VaultSecret

    assert _test_json(True) == 'true'
    assert _test_

# Generated at 2022-06-20 15:45:09.926760
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test stringified value
    data = [
        1,
        b'abc',
        {'abc': 'abc', 'abc1': [1, 2, 3], 'abc2': True},
        [{'abc': 'abc'}],
        {'abc': [1, 2, 3, {'abc': 'abc'}]},
        {'abc': {'abc': 'abc'}},
        datetime.datetime.now(),
        datetime.datetime.now().date(),
    ]
    for d in data:
        assert json.loads(json.dumps(d, cls=AnsibleJSONEncoder)) == d

# Generated at 2022-06-20 15:45:16.593293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six
    from copy import copy

    # import vault secret and encrypted text
    example_vault = vault.VaultLib('secret')
    example_secret = 'example secret text'
    example_vault_text = example_vault.encrypt(example_secret)
    example_ansible_unsafe_url = urls.AnsibleUnsafeUrl(example_secret)
    example_ansible_unsafe_text = urls.AnsibleUnsafeText(example_secret)
    example_ansible_unsafe_bytes = urls.AnsibleUnsafeBytes(example_secret)

    # import dict for recursive test

# Generated at 2022-06-20 15:45:27.137325
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import string_types


# Generated at 2022-06-20 15:45:31.375066
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    """
    Test constructor for class AnsibleJSONEncoder
    """
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

# Generated at 2022-06-20 15:45:42.999886
# Unit test for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:45:52.429013
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Create a test class
    class AnsibleUnsafe(str):
        __UNSAFE__ = True
    # Test 1: Encode the test class and verify it is converted correctly
    assert(next(AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True).iterencode(AnsibleUnsafe('unsafe_string'))) == '{"__ansible_unsafe": "unsafe_string"}')
    # Test 2: Encode a list of the test class and verify it is converted correctly
    assert(next(AnsibleJSONEncoder(preprocess_unsafe=True, sort_keys=True).iterencode([AnsibleUnsafe('unsafe_string')])) == '[{"__ansible_unsafe": "unsafe_string"}]')
    # Test 3: Encode a string and verify it is not

# Generated at 2022-06-20 15:45:58.725090
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder._preprocess_unsafe is False
    assert AnsibleJSONEncoder._vault_to_text is False
    assert AnsibleJSONEncoder.ensure_ascii() is True
    assert AnsibleJSONEncoder.indent() is None
    assert AnsibleJSONEncoder.separators() == (',', ':')
    assert AnsibleJSONEncoder.sort_keys() is False

# Generated at 2022-06-20 15:46:02.411665
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(dict(foo='bar')) == {'foo': 'bar'}
    assert encoder.default(False) == False


# Generated at 2022-06-20 15:46:13.649419
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_native, to_text
    from ansible.module_utils.common.text.converters import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec={},
    )

    def _check_iterencode(original_data, reference_data):
        result = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(original_data)
        result = to_text(b''.join(result), errors='surrogate_or_strict')
        result = json.loads(result)

# Generated at 2022-06-20 15:46:22.948343
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    maxint = 2 ** 31 - 1
    s = str(maxint)
    #
    # test default
    #
    json_str = encoder.encode(maxint)
    assert json_str == s
    #
    # test iter
    #
    json_iter = encoder.iterencode(maxint)
    assert next(json_iter) == '2147483647'
    try:
        next(json_iter)
        assert False
    except StopIteration:
        pass

# Generated at 2022-06-20 15:46:27.090399
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    def assert_is_iterator(iter):
        """Check if it is an iterator"""
        assert hasattr(iter, '__iter__'), 'iterencode function of class AnsibleJSONEncoder should return an iterator'

    ansible_json_encoder = AnsibleJSONEncoder()

    assert_is_iterator(ansible_json_encoder.iterencode({'a':1, 'b': 2, 'c': '3'}))

    assert_is_iterator(ansible_json_encoder.iterencode([1, 2, 3]))

    assert_is_iterator(ansible_json_encoder.iterencode(datetime.datetime.now().date()))

    assert_is_iterator(ansible_json_encoder.iterencode(datetime.datetime.now()))


# Generated at 2022-06-20 15:46:31.962693
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(
        ensure_ascii=False,
        preprocess_unsafe=False,
        vault_to_text=True
    )

    assert not ansible_json_encoder._preprocess_unsafe
    assert ansible_json_encoder._vault_to_text

    assert isinstance(ansible_json_encoder, json.JSONEncoder)

# Generated at 2022-06-20 15:46:38.844831
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._json_compat import AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    test_vault = VaultLib('ansible')
    plaintext = 'I AM THE VAULT'
    ciphertext = test_vault.encrypt(plaintext)
    vault = test_vault.decrypt(ciphertext)

    class TestObject():
        def __init__(self):
            self.some_attr = 'some attribute'
            self.some_list = ['example', 'list']
            self.some_dict = {'key': 'value'}

    test_object = TestObject()

    encoder = AnsibleJSONEncoder()

    assert encoder.default(ciphertext) == {'__ansible_vault': ciphertext}
    assert enc

# Generated at 2022-06-20 15:46:50.033559
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.ansible_unsafe_proxy import AnsibleUnsafeText

    text = """my secret data"""
    plaintext = AnsibleUnsafeText(text)
    encrypted = VaultLib(b'super_secret').encrypt(plaintext)
    assert encrypted.text == plaintext

    safe_vault = dict(__ansible_vault=to_text(encrypted._ciphertext, errors='surrogate_or_strict'))
    safe_unsafe = dict(__ansible_unsafe=to_text(plaintext, errors='surrogate_or_strict'))
    unsafe_obj = dict(param='value')
    unsafe_obj.__UNSAFE__ = True

    # "__ENCRYPTED__" is true

# Generated at 2022-06-20 15:47:00.127599
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.yaml.objects
    input_string = {
        'test1': 'value1',
        'test2': ['value2', 'value3'],
        'test3': {
            'test4': ansible.parsing.yaml.objects.AnsibleUnsafeText(b'\x01\x02\x03\x04'),
            'test5': ['value5', 'value6']
        }
    }
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    encoded_data = list(ansible_json_encoder.iterencode(input_string))
    assert len(encoded_data) == 3
    assert encoded_data[0].replace(' ', '') == '{"test1":"value1",'

# Generated at 2022-06-20 15:47:10.845115
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    import os
    import tempfile
    import uuid

    text = AnsibleUnsafe(u'ûnicode_text')
    vault = VaultLib([])
    ansible_vault_text = vault.encrypt(to_text(text))
    ansible_vault = AnsibleVaultEncryptedUnicode(to_bytes(ansible_vault_text))


# Generated at 2022-06-20 15:47:20.968702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    ansible_unsafe = AnsibleUnsafe('test')
    ansible_vault = AnsibleVaultEncryptedUnicode('test')
    safe_string = 'test'

    assert AnsibleJSONEncoder().default(ansible_unsafe) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder().default(ansible_vault) == {'__ansible_vault': 'test'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(ansible_vault) == 'test'
    assert AnsibleJSONEncoder().default(safe_string) == safe_string


# ----------------------------------------------------------------


# Generated at 2022-06-20 15:47:26.287739
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    from ansible.parsing.vault import VaultLib
    e = AnsibleJSONEncoder()
    assert e.default(VaultLib('test')) == {'__ansible_vault': 'test'}
    assert e.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert e.default(datetime.date.today()) == datetime.date.today().isoformat()
    assert e.default({1: 2}) == {1: 2}
    assert e.default([1, 2]) == [1, 2]

# Generated at 2022-06-20 15:47:38.894346
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    print("\nTestcase 1 iterencode of AnsibleJSONEncoder: Expected output is {'__ansible_unsafe': 'ansible'}")
    o = AnsibleUnsafeText('ansible')
    assert list(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(o)) == [b"{'__ansible_unsafe': 'ansible'}"]
    print("Pass\n")

    print("Testcase 2: Expected output is ['ansible', {'__ansible_unsafe': 'ansible'}]")
    o = ['ansible', AnsibleUnsafeText('ansible')]

# Generated at 2022-06-20 15:47:41.494537
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder


# Generated at 2022-06-20 15:47:45.941759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    v = {'a': AnsibleUnsafe('test'), 'b': 'test'}
    d = AnsibleJSONEncoder().default(v)
    r = {'a': {'__ansible_unsafe': 'test'}, 'b': 'test'}
    assert r == d



# Generated at 2022-06-20 15:47:47.773681
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    jsonencoder = AnsibleJSONEncoder()
    assert type(jsonencoder) == AnsibleJSONEncoder

# Generated at 2022-06-20 15:47:56.731847
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # set up test data
    vault_str = b'vault_secret'
    password = b'password'
    vault = VaultLib([password])
    vault_obj = vault.encrypt(vault_str)
    unsafe_obj = AnsibleUnsafeText('unsafe_obj')

    # test for encoding AnsibleVault
    jencoder = AnsibleJSONEncoder(vault_to_text=True)
    jstr = jencoder.iterencode(vault_obj)
    assert to_text(vault_str) == next(jstr)

    # test for encoding AnsibleUnsafeText

# Generated at 2022-06-20 15:48:11.030011
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import json
    a = AnsibleJSONEncoder()
    b = json.JSONEncoder()
    assert(a.escape_forward_slashes == b.escape_forward_slashes)
    assert(a.ensure_ascii == b.ensure_ascii)
    assert(a.indent == b.indent)
    assert(a.key_separator == b.key_separator)
    assert(a.item_separator == b.item_separator)
    assert(a.sort_keys == b.sort_keys)
    assert(a.skipkeys == b.skipkeys)
    assert(a.allow_nan == b.allow_nan)
    assert(a.encoding == b.encoding)
    assert(a.check_circular == b.check_circular)

# Generated at 2022-06-20 15:48:21.433646
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test datetime object
    test_date_time = datetime.datetime.utcnow()
    test_date_time_dict = {'__ansible_datetime': test_date_time.isoformat()}
    assert(test_date_time_dict == json.loads(json.dumps(test_date_time, cls=AnsibleJSONEncoder, indent=2)))

    # test other objects
    test_dict = {'testing': 'Hello Ansible'}
    assert(test_dict == json.loads(json.dumps(test_dict, cls=AnsibleJSONEncoder, indent=2)))

    # test vault object
    from ansible.parsing.vault import VaultLib
    test_vault = VaultLib('VaultTest')

# Generated at 2022-06-20 15:48:25.638865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.date(2019, 2, 10)) == "2019-02-10"
    assert encoder.default(datetime.datetime(2019, 2, 10, 10, 17)) == "2019-02-10T10:17:00"


# Generated at 2022-06-20 15:48:33.727989
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()


# Generated at 2022-06-20 15:48:45.625432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode

    # string data
    data = "test string"
    assert json.dumps(data, cls=AnsibleJSONEncoder) == json.dumps(data)

    # safe string
    data = AnsibleUnsafe(data)
    assert json.dumps(data, cls=AnsibleJSONEncoder) == json.dumps(data)

    # unsafe string
    data._mark_unsafe()
    assert json.dumps(data, cls=AnsibleJSONEncoder) == json.dumps(data)

    # vault string
    data = AnsibleVaultEncryptedUnicode(data)

# Generated at 2022-06-20 15:48:46.983827
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-20 15:48:58.391538
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    vault_secret = VaultSecret(_password='password', _id='1')
    vault_lib = VaultLib(vault_secret)

    class Safe:
        def __init__(self, sec):
            self.__ENCRYPTED__ = True
            self._ciphertext = vault_lib.encrypt(sec)

    class SafeMapping(Mapping):
        def __init__(self, secret):
            self.__my_sec = vault_lib.encrypt(secret)

        def __getitem__(self, key):
            return self.__

# Generated at 2022-06-20 15:49:08.340652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    expected = '{"__ansible_vault": "vault_string"}'
    o = 'vault_string'
    o.__ENCRYPTED__ = True
    actual = AnsibleJSONEncoder(default=o).encode(o)
    assert expected == actual

    expected = '"vault_string"'
    actual = AnsibleJSONEncoder(default=o, vault_to_text=True).encode(o)
    assert expected == actual

    expected = '{"__ansible_unsafe": "unsafe_string"}'
    o = 'unsafe_string'
    o.__UNSAFE__ = True
    actual = AnsibleJSONEncoder(default=o).encode(o)
    assert expected == actual


# Generated at 2022-06-20 15:49:17.411837
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an AnsibleJSONEncoder object
    ansible_json_encoder = AnsibleJSONEncoder()

    # Get the default method of class AnsibleJSONEncoder
    default = ansible_json_encoder.default

    # Create a AnsibleUnsafe object
    ansible_unsafe_object = AnsibleUnsafe('test', 'string')

    # Create a AnsibleVaultEncryptedUnicode object
    ansible_vault_encrypted_unicode_object = AnsibleVaultEncryptedUnicode('test', 'string')

    # Create a dict object
    dict_object = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}

    # Create a datetime object
    datetime_object = datetime.datetime.now()

    # Create an object which is not

# Generated at 2022-06-20 15:49:24.661598
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Set values
    input_value = {'city': 'dalian', 'country': 'china'}
    ansible_json_encoder = AnsibleJSONEncoder()

    # Get result
    ret = ansible_json_encoder.default(input_value)

    # Assertion
    assert ret == {'city': 'dalian', 'country': 'china'}

# Generated at 2022-06-20 15:49:38.404292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create a class with a ``default`` method
    class TestAnsibleJSONEncoder(AnsibleJSONEncoder):
        """
        This class is used for test purpose only
        """
        def default(self, o):
            return {"default": "json.encoder.default"}

    # Test a datetime
    date = datetime.datetime.now()
    res = json.loads(TestAnsibleJSONEncoder().encode(date))
    assert res == date.isoformat()

    # Test a AnsibleUnsafe
    unsafe = TestAnsibleJSONEncoder().encode({"default": TestAnsibleJSONEncoder().encode({"unsafe": "AnsibleUnsafe"})})
    res = json.loads(unsafe)

# Generated at 2022-06-20 15:49:49.830994
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_mock_object = mock_ansible_module.AnsibleModule({}, {})
    ansible_mock_object._ansible_no_log = False
    json_encoder = AnsibleJSONEncoder(sort_keys=True, indent=4)

    # test object None
    ansible_mock_object.assertEqual(json_encoder.default(None), None)

    # test object integer
    ansible_mock_object.assertEqual(json_encoder.default(123), 123)

    # test object float
    ansible_mock_object.assertEqual(json_encoder.default(1.23), 1.23)

    # test object boolean
    ansible_mock_object.assertEqual(json_encoder.default(True), True)

    # test object boolean

# Generated at 2022-06-20 15:49:58.859426
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.utils.unsafe_proxy import wrap_var
    _text = 'just-a-simple-string'
    _unsecure_value = wrap_var(_text)
    assert _unsecure_value.__UNSAFE__
    assert not _unsecure_value.__ENCRYPTED__
    assert json.loads(json.dumps(_unsecure_value, cls=AnsibleJSONEncoder)) == _text
    _unsecure_values = json.loads(json.dumps([_unsecure_value], cls=AnsibleJSONEncoder))
    assert _unsecure_values == [_text]
    _d = {"key1": _unsecure_value, "key2": _unsecure_value}

# Generated at 2022-06-20 15:50:09.874599
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(['vault', '--vault-id', '123'])
    vault_str = vault.encrypt('bar')

    unsafe = vault.decrypt(vault_str)

    # Unsafe and vault in a list
    test_object = [unsafe, vault_str]
    # Encode
    encoded = json.dumps(test_object, cls=AnsibleJSONEncoder)
    # Decode
    decoded = json.loads(encoded)
    # Assert
    assert decoded[0] == test_object[0]
    assert decoded[1]['__ansible_vault'] == to_text(test_object[1], errors='surrogate_or_strict', nonstring='strict')

    #

# Generated at 2022-06-20 15:50:17.739722
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    from ansible.module_utils.six import text_type

    text = u'{"a": "d", "b": "e"}'

# Generated at 2022-06-20 15:50:26.791938
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vault = VaultLib([])
    content = to_bytes('A random string', errors='surrogate_or_strict')
    o = vault.encrypt(content)
    o_o = o

# Generated at 2022-06-20 15:50:34.484045
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import ensure_binary
    from ansible.module_utils.six.moves.urllib.parse import quote

    test_vault_data = VaultLib([])

    secret = 'this is a secret'
    secret_encoded = '$ANSIBLE_VAULT;1.1;AES256\n' + quote(test_vault_data._encrypt(secret)) + '\n'
    secret_encoded_bytes = ensure_binary(secret_encoded, errors='surrogate_or_strict')


# Generated at 2022-06-20 15:50:46.049217
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """ test AnsibleJSONEncoder.iterencode
    """

    from ansible.parsing.vault import VaultLib, VaultSecret, VaultPasswordError

    json_sample = {'a': 'a',
                   'b': [1, 2, 'a'],
                   'c': [1, 2, ['a', 'b']],
                   'd': {'a': 1, 'b': 'c'},
                   'e': {'a': 1, 'b': {'x': 'y'}}
                   }

    vault_id = '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-20 15:50:47.512442
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()

    assert enc is not None

# Generated at 2022-06-20 15:50:50.101084
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Testing constructor
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == False

# Generated at 2022-06-20 15:51:01.792986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = {"test_data1": "test_value1", "test_data2": "test_value2"}
    x = AnsibleJSONEncoder()
    print(x.default(test_data))
    # print(x.default("test_value"))



# Generated at 2022-06-20 15:51:07.406938
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_obj = AnsibleJSONEncoder()
    assert test_obj._preprocess_unsafe == False
    assert test_obj._vault_to_text == False

    test_obj = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert test_obj._preprocess_unsafe == True
    assert test_obj._vault_to_text == True


# Generated at 2022-06-20 15:51:17.443360
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansiblejsonencoder = AnsibleJSONEncoder()
    assert ansiblejsonencoder
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert ansiblejsonencoder
    ansiblejsonencoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert ansiblejsonencoder
    ansiblejsonencoder = AnsibleJSONEncoder(vault_to_text=True)
    assert ansiblejsonencoder
    ansiblejsonencoder = AnsibleJSONEncoder(vault_to_text=False)
    assert ansiblejsonencoder



# Generated at 2022-06-20 15:51:21.265066
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert(encoder.preprocess_unsafe == False)
    assert(encoder.vault_to_text == False)

# Generated at 2022-06-20 15:51:29.899501
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.text.converters import to_bytes, to_text

    # Encoding a normal string, check there is not modification
    text = 'Hello world!'
    text_encoded = to_text(json.dumps({'coucou': text}, cls=AnsibleJSONEncoder))
    assert text_encoded == '{"coucou": "Hello world!"}'

    # Encoding a string which is an instance of AnsibleUnsafe
    text = AnsibleUnsafe('Hello world!')
    text_encoded = to_text(json.dumps({'coucou': text}, cls=AnsibleJSONEncoder))

# Generated at 2022-06-20 15:51:41.100350
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.urls import _AnsibleUnsafeURL
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six import string_types
    class _AnsibleUnsafeContent(string_types[0]):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    url = 'http://www.google.com'
    url_obj = _AnsibleUnsafeURL(url)
    url_obj_encoded = AnsibleJSONEncoder().iterencode(url_obj)
    assert not isinstance(url_obj_encoded, _AnsibleUnsafeURL)
    parsed_uri = urlparse(url_obj_encoded)
    #
    # Parsing above uri should yeild

# Generated at 2022-06-20 15:51:47.717647
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils._text import to_native
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_vault_secrets
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault_pass = get_vault_secrets(None, None,
                                   vault_password_files=[(99, 'fixtures/encrypted_data_files/vault_password')],
                                   ask_vault_pass=False,
                                   auto_reload=True)[0]
    # The py27 encrypted file uses the vault_password file, the py38 and py39
    # encrypted files uses an \x00 at the end of the vault_password file, the
    # py27 encrypted file uses the unencrypted vault_password file for
    # encry

# Generated at 2022-06-20 15:51:52.044060
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    class MyJSONEncoder(AnsibleJSONEncoder):
        def __init__(self, preprocess_unsafe=False, vault_to_text=False, **kwargs):
            self._preprocess_unsafe = preprocess_unsafe
            self._vault_to_text = vault_to_text
            super(MyJSONEncoder, self).__init__(**kwargs)
    assert MyJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

# Generated at 2022-06-20 15:51:57.303148
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert json_encoder.default(['foo']) == ['foo']
    assert json_encoder.default(('foo',)) == ('foo',)
    assert json_encoder.default(int(1)) == 1
    assert json_encoder.default(float(1.0)) == 1.0
    assert json_encoder.default(None) is None
    assert json_encoder.default(True)
    assert not json_encoder.default(False)
    assert json_encoder.default(dict(nested_one=1.0, nested_two=2)) == {'nested_one': 1.0, 'nested_two': 2}

# Generated at 2022-06-20 15:52:08.005580
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Make sure that iterencode() recognizes AnsibleUnsafe objects and converts them to JSON dicts.
    # The result object is an iterator and must be iterated over in order to obtain the value.
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_native, to_text
    from ansible.module_utils.common.text.formatters import strftime
    from ansible.module_utils.common.text.text_compat import StringIO
    from ansible.module_utils.common.text.tools import to_bytes, to_str
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils import six
    import json

    # Make sure that to_

# Generated at 2022-06-20 15:52:24.458949
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoded = json.dumps({'test': 'value'}, cls=AnsibleJSONEncoder)
    assert encoded == '{"test": "value"}'

# Generated at 2022-06-20 15:52:34.087241
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type

    for boolean_value in BOOLEANS_TRUE:
        boolean_value_repr = repr(boolean_value)

        unsafe_mock = boolean(boolean_value, strict=False)
        assert _is_unsafe(unsafe_mock)

        unsafe_mock_repr = to_unicode(unsafe_mock)
       

# Generated at 2022-06-20 15:52:41.535275
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleUnsafe

    # test custom encode
    j = AnsibleJSONEncoder()
    assert json.loads(j.encode(AnsibleUnsafe('example'))) == {'__ansible_unsafe': 'example'}
    j = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json.loads(j.encode([AnsibleUnsafe('example')])) == [{'__ansible_unsafe': 'example'}]

# Generated at 2022-06-20 15:52:44.948558
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = [
        (u'hello world', '"hello world"'),
        (42, '42'),
        (42.5, '42.5'),
        (True, 'true'),
        (False, 'false'),
        (None, 'null'),
        (datetime.datetime.isoformat(datetime.datetime.now()), '"' + datetime.datetime.isoformat(datetime.datetime.now()) + '"')
    ]
    for test_case, expected_output in test_data:
        actual_output = AnsibleJSONEncoder().default(test_case)
        assert json.dumps(actual_output) == expected_output

# Generated at 2022-06-20 15:52:54.825669
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    obj = AnsibleJSONEncoder()
    assert obj is not None, "Could not create object of class AnsibleJSONEncoder"
    assert obj.check_circular is True, "Ensure check_circular is True"
    assert obj.ensure_ascii is True, "Ensure ensure_ascii is True"
    assert obj.encoding == 'utf-8', "Ensure encoding is utf-8"
    assert obj.indent is None, "Ensure indent is None"
    assert obj.separators == (',', ':'), "Ensure separators are (',',':')"
    assert obj.sort_keys == False, "Ensure sort_keys is False"

# Generated at 2022-06-20 15:53:07.177152
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.encodings import decode_text
    from ansible.module_utils.common.text.encodings import encode_text

    raw_json = b'{"key": "value"}'
    encoded_json_obj = json.loads(raw_json)

    # Unsafe string test
    unsafe_string = decode_text(b'{"__ansible_unsafe": "value"}')
    unsafe_dict = {"key": unsafe_string}
    unsafe_json_obj = {"key": {"__ansible_unsafe": "value"}}
    encoded_unsafe_json = AnsibleJSONEncoder().iterencode(unsafe_dict)

# Generated at 2022-06-20 15:53:18.645362
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # UnsafeToText class
    class UnsafeToText(VaultLib):
        def __init__(self, unsafe):
            self.__dict__['_unsafe'] = unsafe

    # make sure it is not a VaultLib type
    assert not isinstance(UnsafeToText, type(VaultLib))

    class MyClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    encoder = AnsibleJSONEncoder()

    assert encoder.default(UnsafeToText('p@ssword')) == {'__ansible_unsafe': 'p@ssword'}, \
        "AnsibleJSONEncoder.default adds '__ansible_unsafe' to a AnsibleUnsafe object"



# Generated at 2022-06-20 15:53:29.826963
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_string = AnsibleUnsafe("test_string")
    ansible_dict = AnsibleUnsafe({"a": "test_string"})
    string_to_json = json.dumps("test_string")
    dict_to_json = json.dumps({"a": "test_string"})

    # check if we can convert ansible_string to JSON string
    try:
        json.dumps(ansible_string)
    except TypeError as e:
        pass
    if e.args[0] == 'Object of type AnsibleUnsafe is not JSON serializable':
        pass

    # check if we can convert ansible_dict to JSON string
    try:
        json.dumps(ansible_dict)
    except TypeError as e:
        pass

# Generated at 2022-06-20 15:53:37.713441
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # following tests use an AnsibleVaultEncryptedUnicode object to test method iterencode
    # An AnsibleVaultEncryptedUnicode object is used as base for all vault objects
    # and is where the method iterencode is applied to the vault object.

    # AnsibleVaultEncryptedUnicode object is defined in module ansible.parsing.vault
    # when __UNSAFE__ and __ENCRYPTED__ is None the object is treated as a string
    # this type is not processed by method iterencode and not part of this tests

    # when __UNSAFE__ is True and __ENCRYPTED__ is False or None the object is treated as any other
    # object and not

# Generated at 2022-06-20 15:53:46.868045
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    :return: True if the method default of class AnsibleJSONEncoder is ok. False otherwise
    """

    import datetime, time
    from ansible.module_utils.virt_lib import AnsibleVaultEncryptedUnicode

    obj = AnsibleJSONEncoder()
    result = obj.default(datetime.date(2018, 8, 13))
    if result != '2018-08-13':
        return False

    result = obj.default(datetime.datetime.fromtimestamp(time.time()))
    if type(result) != str:
        return False

    result = obj.default(AnsibleVaultEncryptedUnicode(u"johndoe:MyPassword!"))