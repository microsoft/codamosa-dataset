

# Generated at 2022-06-20 15:44:11.706813
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.text import to_text, AnsibleUnsafe
    from ansible.module_utils.common.text.converters import to_unicode, to_bytes

    def check_EncodingResult(result, length):
        assert isinstance(result, (string_types, bytes))
        assert len(result) == length
        return result

    encrypted_str = '$ANSIBLE_VAULT;123456;test;test'
    encrypt_str = to_unicode(encrypted_str)
    vault = VaultLib([to_bytes(u'123456')])
    encrypt_unsafe

# Generated at 2022-06-20 15:44:14.125080
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
	testkv = AnsibleJSONEncoder(False,True,"testkey")
	assert getattr(testkv, 'testkey', False)

# Generated at 2022-06-20 15:44:20.656342
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    test_list = ['test at 0 ', 'test at 1 ', AnsibleUnsafe('test at 2 ')]
    result = json.dumps(test_list, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    result_list = json.loads(result)
    assert result_list == test_list

# Generated at 2022-06-20 15:44:24.806423
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder['__preprocess_unsafe'] == False
    assert ansible_encoder['_vault_to_text'] == False


# Generated at 2022-06-20 15:44:32.210446
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Check if it can be serialized
    # This will give us a traceback if it is not possible
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    test_vault_text = "foo"
    vault_pw_file = "foobar"
    vault_object = VaultLib([vault_pw_file])
    test_vault_dict = {"vault_text": test_vault_text}
    test_vault_dict = vault_object.encrypt(json.dumps(test_vault_dict).encode('utf-8'))
    test_vault_dict = json.loads(test_vault_dict)

    test_unsafe_text = "unsafe_text"

# Generated at 2022-06-20 15:44:43.257634
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_text='test text'
    from ansible.module_utils.common.text.converters import to_bytes
    test_single_byte_str = to_bytes(test_text, encoding='ascii')
    test_multi_byte_str = to_bytes(test_text, encoding='utf-8')
    test_bytes = to_bytes(test_text)

    my_encode = AnsibleJSONEncoder(preprocess_unsafe=False)
    output1 = json.dumps(test_single_byte_str, cls=AnsibleJSONEncoder)
    assert output1 == '"test text"'
    output2 = json.dumps(test_multi_byte_str, cls=AnsibleJSONEncoder)
    assert output2 == u'"test text"'
    output3 = json.dumps

# Generated at 2022-06-20 15:44:54.218264
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText
    # Test VaultLib
    encrypted_text = '$ANSIBLE_VAULT;1.1;AES256\n33046233396664343837643330666437373362383930633234383334353630373934623365373435\n39373536663365373439373066353765656133376565633939363365343037363066396463376166\n34616239353338353437366264373562363939643737333839326237353830666438616662313730\n336534643233383546424048'
    decrypted_text

# Generated at 2022-06-20 15:45:04.067024
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    vault_obj_str = "obj_str"
    unsafe_obj_str = "obj_str"
    obj_str = "obj_str"
    hostvars_obj = dict()
    date_obj = datetime.date.today()

    ansible_vault_expected = {'__ansible_vault': 'b2JqX3N0cg=='}
    ansible_unsafe_expected = {'__ansible_unsafe': 'obj_str'}
    ansible_crypt_obj_expected = {'__ansible_vault': 'b2JqX3N0cg=='}
    ansible_unsafe_obj_expected = {'__ansible_unsafe': 'obj_str'}

    # Set vault object to be

# Generated at 2022-06-20 15:45:05.106170
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  assert(True)

# Generated at 2022-06-20 15:45:12.457162
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder(ensure_ascii=True, check_circular=True, allow_nan=True, sort_keys=True, indent=4)
    result = ansible_json_encoder.default(['test_data1', 'test_data2'])
    assert result == ['test_data1', 'test_data2']
    #test encoding with empty object
    result = ansible_json_encoder.iterencode({'test_key': 'test_value'})
    assert result == '{\n    "test_key": "test_value"\n}'

# Generated at 2022-06-20 15:45:22.225332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder(sort_keys=True)
    assert obj.default("A") == "A"
    obj = AnsibleJSONEncoder(sort_keys=True)
    assert obj.default("Test Test Test Test Test Test ") == "Test Test Test Test Test Test "
    obj = AnsibleJSONEncoder(sort_keys=True)
    assert obj.default("@./#@$_#@$") == "@./#@$_#@$"


# Generated at 2022-06-20 15:45:26.146760
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.ajson
    json_string = '{"__ansible_unsafe": "[u\'{{ lookup(\'file\', \'/etc/passwd\') | b64encode }}\']"}'
    ansible_dict = {"__ansible_unsafe": "[u'{{ lookup('file', '/etc/passwd') | b64encode }}']"}
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_dict == ansible.parsing.ajson._load_json_data(json_string)


# Generated at 2022-06-20 15:45:33.177885
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    json_str = json.dumps(
        {
            'str': 'strval',
            'int': 123,
            'list': [1, 2, 3],
            'dict': {
                'a': 1,
                'b': 2
            }
        },
        cls=AnsibleJSONEncoder,
        preprocess_unsafe=True,
        sort_keys=True
    )
    expect = '{"dict": {"a": 1, "b": 2}, "int": 123, "list": [1, 2, 3], "str": "strval"}'
    assert json_str == expect

# Generated at 2022-06-20 15:45:45.008763
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    from base64 import b64encode

    vault_string = b'ansible-vault-password'
    vault_password = b64encode(vault_string).decode('utf-8')
    v = VaultLib([1, 2, 3, vault_string], 0, vault_password)
    c = VaultAES256(vault_password, v.salt, v.hmac_key, v.hmac_key, vault_password).decrypt(v.vault.encode('utf-8')).decode('utf-8')


# Generated at 2022-06-20 15:45:53.429216
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder1 = AnsibleJSONEncoder()
    assert(AnsibleJSONEncoder1.check_circular is True)
    assert(AnsibleJSONEncoder1.ensure_ascii is True)
    assert(AnsibleJSONEncoder1.indent is None)
    assert(AnsibleJSONEncoder1.allow_nan is True)
    assert(AnsibleJSONEncoder1.sort_keys is False)
    assert(AnsibleJSONEncoder1.separators is None)

    AnsibleJSONEncoder2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert(AnsibleJSONEncoder2.preprocess_unsafe is True)

    AnsibleJSONEncoder3 = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-20 15:45:59.482529
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    """ Test case of AnsibleJSONEncoder.iterencode method """
    import ansible.module_utils.basic
    test_str = '中文 \u1234'
    result = json.dumps(test_str, cls=AnsibleJSONEncoder, sort_keys=True, ensure_ascii=False)
    assert result == '"中文 \u1234"'


# Generated at 2022-06-20 15:46:03.436363
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False


# Generated at 2022-06-20 15:46:14.381179
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert to_text(AnsibleJSONEncoder().encode({'a': u'value'})) == '{"a": "value"}'
    assert to_text(AnsibleJSONEncoder().encode({u'a': u'value'})) == '{"a": "value"}'
    # ensure py3 bytes/str objects are handled properly
    assert to_text(AnsibleJSONEncoder().encode({b'a': b'value'})) == '{"a": "value"}'
    assert to_text(AnsibleJSONEncoder().encode({'a': b'value'})) == '{"a": "value"}'
    assert to_text(AnsibleJSONEncoder().encode({b'a': 'value'})) == '{"a": "value"}'


# Generated at 2022-06-20 15:46:25.764973
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test normal objects
    test = 'ansible_test'
    assert(AnsibleJSONEncoder().encode(test) == json.dumps(test))

    # test datetime
    datetime_object = datetime.datetime.now()
    assert(AnsibleJSONEncoder().encode(datetime_object) == json.dumps(datetime_object.isoformat()))

    # test mappings
    test_mapping = {'a': 1}
    assert(AnsibleJSONEncoder().encode(test_mapping) == json.dumps(test_mapping))

    # test sequences
    test_sequence = [0, 1, 2, 3]
    assert(AnsibleJSONEncoder().encode(test_sequence) == json.dumps(test_sequence))

# Generated at 2022-06-20 15:46:35.872677
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import textwrap
    import vars.HostVarsVars
    import vars.UserVarsVars

    """Initialize a AnsibleJSONEncoder object"""
    encoder = AnsibleJSONEncoder()

    """Test default method of class"""
    value = encoder.default(vars.HostVarsVars.HostVarsVars())
    assert isinstance(value, dict), "Invalid value returned from AnsibleJSONEncoder.default"

    """Test iterencode with the sample data"""

# Generated at 2022-06-20 15:46:49.816375
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsibleSafeText, AnsibleUnsafeText, AnsibleUnsafeBytes instance
    for unsafe_obj in [b'hello', u'hello']:
        assert isinstance(unsafe_obj, str)
        assert getattr(unsafe_obj, '__UNSAFE__', False) is True
        # Need to add a __ENCRYPTED__ attribute to test the code branch of
        # ``getattr(o, '__ENCRYPTED__', False)``, otherwise all the code would
        # go into the else branch.
        setattr(unsafe_obj, '__ENCRYPTED__', False)
        assert isinstance(unsafe_obj, str)
        assert getattr(unsafe_obj, '__UNSAFE__', False) is True

# Generated at 2022-06-20 15:46:55.587123
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Example data with some specific types
    o = {
        'a': ['b', {'c': 'd'}],
        'b': ['e', {'f': 'g'}],
        'c': ['h', {'i': 'j'}],
    }

    # Test the method iterencode
    assert json.dumps(o) == AnsibleJSONEncoder(False, False).iterencode(o)

# Generated at 2022-06-20 15:47:04.193541
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # Test data structure to encode
    testData = [
        {
            '__ENCRYPTED__': True,
            '__UNSAFE__': True
        },
        {
            '__ENCRYPTED__': False,
            '__UNSAFE__': True
        },
        {
            '__ENCRYPTED__': True,
            '__UNSAFE__': False
        },
        {
            '__ENCRYPTED__': False,
            '__UNSAFE__': False
        },
    ]
    # Expected results for different flags

# Generated at 2022-06-20 15:47:16.068824
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleModule, AnsibleUnsafe
    import ast

    mod = AnsibleModule(argument_spec={})
    json_data = dict(ansible_unsafe_string=AnsibleUnsafe('ansible_unsafe_string'),
                     ansible_unsafe_string_with_safe_string=[AnsibleUnsafe('ansible_unsafe_string'), 'safe_string'],
                     ansible_unsafe_dict={'ansible_unsafe_string': AnsibleUnsafe('ansible_unsafe_string')},
                     ansible_unsafe_dict_with_safe_dict={'ansible_unsafe_string': AnsibleUnsafe('ansible_unsafe_string'),
                                                         'safe_string': 'safe_string'},
    )


# Generated at 2022-06-20 15:47:25.009428
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    date_object = datetime.datetime(2019, 1, 1, 12, 14, 0)
    date_object_str = date_object.isoformat()

    # Testing type mapping
    assert "10" == AnsibleJSONEncoder().default(10)
    assert "true" == AnsibleJSONEncoder().default(True)
    assert "false" == AnsibleJSONEncoder().default(False)
    assert "null" == AnsibleJSONEncoder().default(None)
    assert "[10, 20, 30]" == AnsibleJSONEncoder().default([10, 20, 30])
    assert '{"a": 10, "b": 20}' == AnsibleJSONEncoder().default({'a': 10, 'b': 20})
    assert '"abc"' == AnsibleJSONEncoder().default('abc')

# Generated at 2022-06-20 15:47:31.766565
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    aje = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert aje._preprocess_unsafe == True and aje._vault_to_text == False
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert aje._preprocess_unsafe == False and aje._vault_to_text == True

# Generated at 2022-06-20 15:47:43.595425
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert ansible_json_encoder._preprocess_unsafe == False
    assert ansible_json_encoder._vault_to_text == False
    assert ansible_json_encoder.check_circular == True
    assert ansible_json_encoder.allow_nan == True
    assert ansible_json_encoder.encoding == 'utf-8'
    assert ansible_json_encoder.ensure_ascii == True
    assert ansible_json_encoder.indent == None
    assert ansible_json_encoder.separators == (',', ':')
    assert ansible_json_encoder.sort_keys == False
    assert ansible_json_encoder.skipkeys == False

# Generated at 2022-06-20 15:47:44.381494
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert (AnsibleJSONEncoder() is not None)

# Generated at 2022-06-20 15:47:54.517694
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_vault = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    test_vault_2 = json.loads(test_vault.encode(test_vault))
    if '__ansible_vault' in test_vault_2:
        raise Exception('Encoding of AnsibleVault failed.')

    test_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)
    test_unsafe_2 = json.loads(test_unsafe.encode(test_unsafe))
    if '__ansible_unsafe' in test_unsafe_2:
        raise Exception('Encoding of AnsibleUnsafe failed.')


# Generated at 2022-06-20 15:48:05.765389
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class A(object):
        pass
    obj = A()
    obj.x = 'test1'
    obj.y = 2

    # test obj
    assert AnsibleJSONEncoder().default(obj) == {'x': 'test1', 'y': 2}

    # test datetime
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert AnsibleJSONEncoder().default(datetime.date.today()) == datetime.date.today().isoformat()

    # test vault
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    secret_text = 'secret text'
    encrypted_vault = vault.encrypt(secret_text)

# Generated at 2022-06-20 15:48:20.389002
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert AnsibleJSONEncoder()
    assert AnsibleJSONEncoder(True)


# Generated at 2022-06-20 15:48:29.337239
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    jencoder = AnsibleJSONEncoder()
    assert jencoder._preprocess_unsafe is False
    assert jencoder._vault_to_text is False

    jencoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert jencoder._preprocess_unsafe is True
    assert jencoder._vault_to_text is False

    jencoder = AnsibleJSONEncoder(vault_to_text=True)
    assert jencoder._preprocess_unsafe is False
    assert jencoder._vault_to_text is True

    jencoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert jencoder._preprocess_unsafe is True
    assert jencoder._vault_to_text is True



# Generated at 2022-06-20 15:48:35.792410
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import ansible.module_utils.basic

    safe_object_1 = ansible.module_utils.basic.AnsibleModule()
    safe_object_2 = ansible.module_utils.basic.AnsibleModule(argument_spec={'test_argument': dict(required=True)})
    unsafe_object_1 = ansible.module_utils.basic.AnsibleUnsafe('')
    unsafe_object_2 = ansible.module_utils.basic.AnsibleUnsafe('hello')
    safe_object_3 = dict({'safe_key_1': None})
    unsafe_object_3 = dict({'unsafe_key_1': ansible.module_utils.basic.AnsibleUnsafe('hello')})


# Generated at 2022-06-20 15:48:47.590164
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # For display.debug()
    display.verbosity = 4

    test_vault_file_name = './temp_test_encoder_vault.txt'

# Generated at 2022-06-20 15:48:59.184567
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe

    # test for AnsibleUnsafe object
    a = AnsibleUnsafe('abc')
    print(a)
    print(a.__dict__)
    print(a.__UNSAFE__)
    print(type(a))
    print(type(AnsibleUnsafe))
    print(isinstance(a, AnsibleUnsafe))
    print(isinstance(str, AnsibleUnsafe))
    print(isinstance(a, str))

    # test for vault object
    b = AnsibleUnsafe('abc')
    b.__ENCRYPTED__ = True
    b.__CIPHERTEXT__ = 'abc'
    print(json.dumps(b, cls=AnsibleJSONEncoder))



# Generated at 2022-06-20 15:49:08.886982
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import EncryptedUnicode
    from ansible.parsing.vault import VaultEditor

    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible import constants as C

    import base64
    import json
    import six

    enc = AnsibleJSONEncoder(preprocess_unsafe=True)

    # Create a vault password object
    vault_pass = VaultSecret([base64.b64encode(six.b('pass'))])
    # Create a vault object
    vault = VaultLib([vault_pass])
    # Create a vault editor object, used to initialize an EncryptedUnicode
    editor = Vault

# Generated at 2022-06-20 15:49:14.727889
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # test with default value
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False

    # test with preprocess_unsafe=True and vault_to_text=True
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-20 15:49:19.940702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    encoded = encoder.default(1234)
    assert encoded == 1234
    encoded = encoder.default("test")
    assert encoded == "test"
    encoded = encoder.default({'test':'value'})
    assert encoded == {'test':'value'}
    assert encoded != "test"
    #do not convert the datetime object to string
    encoded = encoder.default(datetime.datetime(2017, 8, 16, 8, 7, 0))
    assert encoded == '2017-08-16T08:07:00'

# Generated at 2022-06-20 15:49:31.160166
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault as vault
    import yaml

    class MyVault(vault.VaultLib):
        def __init__(self, password):
            pass

        def encrypt(self, data):
            return data

    class MyUnsafe(vault.VaultLib):
        __UNSAFE__ = True

        def __init__(self, unsafe_text):
            self._unsafe_text = unsafe_text

        def __str__(self):
            return self._unsafe_text

    def load_unsafe(self, secret):
        return MyUnsafe(secret)

    yaml.SafeLoader.add_constructor('!vault', load_unsafe)

    # Setup
    vault_pass = 'ansible'
    vault_ciphertext = 'ansible'  # Not encrypted.

# Generated at 2022-06-20 15:49:42.071376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Tests for method default of class AnsibleJSONEncoder"""
    # pylint: disable=redefined-builtin,unused-argument
    encoded = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, skipkeys=False,
                                 ensure_ascii=True, check_circular=True, allow_nan=True, sort_keys=False,
                                 indent=None, separators=(',', ':'), default=None)

    # Test for parameter o of type bool
    o = True  # noqa
    result = encoded.default(o)
    assert result == True  # noqa
    o = False  # noqa
    result = encoded.default(o)
    assert result == False  # noqa

    # Test for parameter o of type int
    o = 42
   

# Generated at 2022-06-20 15:50:09.494731
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    import ansible.module_utils.ansible_tower
    from ansible.module_utils.basic import AnsibleUnsafe
    test_password = 'testpassword'

    # Create a VaultPassword
    vault_password = VaultPassword(source=b'test', password=test_password.encode('utf-8'))

    # Create a VaultSecret
    vault_secret_data = {'password': vault_password}
    vault_secret = VaultSecret(vault_secret_data)

    # Create a VaultLib
    vault_lib = VaultLib(vault_secret)

    # Create an encrypted text

# Generated at 2022-06-20 15:50:17.514856
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultLib

    # test unsafe text conversion
    u = AnsibleUnsafeText(u'unsafe text')
    assert AnsibleJSONEncoder().default(u) == {'__ansible_unsafe': u.__str__()}

    # test unsafe bytes conversion
    u = AnsibleUnsafeBytes(b'unsafe bytes')
    assert AnsibleJSONEncoder().default(u) == {'__ansible_unsafe': u.__str__()}

    # test vault conversion
    v = VaultLib('unsafe text')

# Generated at 2022-06-20 15:50:20.023286
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert isinstance(ansible_json_encoder, AnsibleJSONEncoder)

# Generated at 2022-06-20 15:50:25.086415
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert encoder._preprocess_unsafe == False
    assert encoder._vault_to_text == False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe == True
    assert encoder._vault_to_text == True

# Generated at 2022-06-20 15:50:33.486635
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib

    vault_password = 'my-secret-password'
    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n324234242342sdfih34h234234hj23423423'

    # init VaultLib
    vault_lib = VaultLib(vault_password)

    # load vault text and load it back to get AnsibleUnsafeText object
    vault_obj = vault_lib.decrypt(vault_text)
    vault_obj_2 = ansible.parsing.vault.VaultSecret(vault_obj.data)

    # not encrypted, just a string
    not_encrypted = 'not_encrypted'

    # vault text object

# Generated at 2022-06-20 15:50:39.823806
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    # create unsafe object
    unsafe_obj = ansible.parsing.vault.VaultLib.encrypt("test", 'secret')
    # create a list object with unsafe object
    test_obj = [unsafe_obj]
    # convert this list object in to the JSON string
    test_json = AnsibleJSO

# Generated at 2022-06-20 15:50:40.383524
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json.dumps()

# Generated at 2022-06-20 15:50:51.385979
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.ansible_tower_module import AnsibleTowerModule
    module = AnsibleTowerModule()
    # create a vault password
    vault_id = module.get_vault_password()
    vault = VaultLib([vault_id])
    # create an encrypted string
    content = to_bytes('foo')
    encrypted_content = vault.encrypt(content)
    # create an unsafe string
    unsafe_string = module._unsafe_proxy('foo')

    # create a list contain all of above

# Generated at 2022-06-20 15:50:59.597661
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    import unittest

    class Foo(object):
        def __init__(self, value=None):
            self.value = value

    class MyDict(dict):
        pass

    class MyList(list):
        pass

    class MyTuple(tuple):
        pass

    class MySet(set):
        pass

    class MyObject(object):
        def __init__(self, value=None):
            self.value = value

    class MyObject2(MyObject):
        def __init__(self, value=None):
            super(MyObject2, self).__init__(value=value)


# Generated at 2022-06-20 15:51:11.941954
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    dict_var = dict(var1=1, var2={'var3': 'val3'}, var3=['val1', 'val2', 'val3'])
    assert(list(AnsibleJSONEncoder().iterencode(dict_var)) ==
        ['{', '"var1"', ':', '1', ',', '"var2"', ':', '{"var3": "val3"}', ',', '"var3"', ':', '[', '"val1"', ',',
         '"val2"', ',', '"val3"', ']', '}'])
    dict_var[b'var1'] = b'val1'

# Generated at 2022-06-20 15:51:55.473218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-20 15:52:06.645954
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    class InnerClass(object):
        """This is the class returned by AnsibleModule.inner_argspec
        """
        def __init__(self):
            self.type = "string"
            self.required = False
            self.choices = []

    class CustomModule(object):
        """A custom class representing a module, this is returned by AnsibleModule"""
        def __init__(self):
            self.argument_spec = {"x_var": InnerClass()}
            self.params = {
                "x_var": AnsibleUnsafe("hello")
            }

    # Init
    module_inst = CustomModule()
    my_json = AnsibleJSONEncoder(sort_keys=True).encode(module_inst)

    # Default

# Generated at 2022-06-20 15:52:11.165428
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    a = AnsibleJSONEncoder(preprocess_unsafe=True, ensure_ascii=False)
    assert(u'"./MyVault"' == next(a.iterencode('A' * 3)))
    assert(u'"åäö"' == next(a.iterencode('åäö')))



# Generated at 2022-06-20 15:52:17.642984
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data1 = {"a": 1, "b": 2, "c": 3}
    data2 = {"a": 1, "b": 2, "c": 3}
    data = [data1, data2]
    ansible_json_encoder = AnsibleJSONEncoder()
    assert(ansible_json_encoder == json.JSONEncoder())

# Generated at 2022-06-20 15:52:28.377438
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import datetime
    # Testing __init__
    x = AnsibleJSONEncoder()
    assert x._preprocess_unsafe == False
    assert x._vault_to_text == False
    assert x.__dict__ == {}
    x = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert x._preprocess_unsafe == False
    assert x._vault_to_text == False
    assert x.__dict__ == {}

    # Testing _is_vault
    assert _is_vault(None) == False
    assert _is_vault("AnsibleUnsafe") == False
    assert _is_vault("__ENCRYPTED__") == False

    # Testing _is_unsafe
    assert _is_unsafe(None) == False

# Generated at 2022-06-20 15:52:34.087522
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # construct
    _AnsibleJSONEncoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # if initialization is successful, then _AnsibleJSONEncoder is an instance of the class AnsibleJSONEncoder
    assert isinstance(_AnsibleJSONEncoder, AnsibleJSONEncoder)
    assert _AnsibleJSONEncoder._preprocess_unsafe == False
    assert _AnsibleJSONEncoder._vault_to_text == False


# Generated at 2022-06-20 15:52:38.584969
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    test_string = "ansible"
    ansible_json_envoder = AnsibleJSONEncoder()
    assert isinstance(ansible_json_envoder, AnsibleJSONEncoder)
    assert json.dumps(test_string, cls=AnsibleJSONEncoder) == '"ansible"'

# Generated at 2022-06-20 15:52:48.356569
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # class
    assert AnsibleJSONEncoder().default(AnsibleJSONEncoder()) == None

    # secret
    assert AnsibleJSONEncoder().default(object()) == None

    # bool
    assert AnsibleJSONEncoder().default(True) == True

    # int
    assert AnsibleJSONEncoder().default(1) == 1

    # float
    assert AnsibleJSONEncoder().default(1.1) == 1.1

    # string
    assert AnsibleJSONEncoder().default('string') == 'string'

    # dict
    assert AnsibleJSONEncoder().default({}) == {}

    # list
    assert AnsibleJSONEncoder().default([]) == []

# Generated at 2022-06-20 15:52:50.304269
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)


# Generated at 2022-06-20 15:52:57.021404
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe_str = 'hello'
    unsafe_str.__UNSAFE__ = True
    vault_str = 'test'
    vault_str.__ENCRYPTED__ = True

    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(unsafe_str) == {'__ansible_unsafe': 'hello'}
    assert ansible_json_encoder.default(vault_str) == {'__ansible_vault': 'test'}

# Generated at 2022-06-20 15:53:30.228325
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
  j = AnsibleJSONEncoder()
  return j

# Generated at 2022-06-20 15:53:41.620421
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafeDict
    import json

    unsafe_text = AnsibleUnsafeText(b'an unsafe text')
    unsafe_bytes = AnsibleUnsafeBytes(b'an unsafe bytes')
    unsafe_dict = AnsibleUnsafeDict({'key': unsafe_bytes})

    unsafe_text_encoded = json.dumps(unsafe_text, cls=AnsibleJSONEncoder, preprocess_unsafe=True)
    assert json.loads(unsafe_text_encoded, cls=AnsibleJSONEncoder) == {'__ansible_unsafe': 'an unsafe text'}


# Generated at 2022-06-20 15:53:52.158385
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import ansible.parsing.vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    test_string = 'test_string'
    test_unsafe_object = AnsibleUnsafeText(test_string)
    test_dict = {
        'k1': test_string,
        'k2': [1, 2.1, 3, test_unsafe_object],
        'k3': {
            'k31': test_string,
            'k32': {
                'k321': test_unsafe_object,
            },
        },
    }
    test_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    out_string = ''.join(test_encoder.iterencode(test_dict))
    assert 'test_string' in out_

# Generated at 2022-06-20 15:54:01.289529
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    test_data = [
        {
            "key": "value",
        },
        {
            "key": "value",
            "__ansible_unsafe": "value",
        },
        {
            "key": "value",
            "__ansible_unsafe": "value",
            "__ansible_vault": "value"
        }
    ]

    for test in test_data:
        assert json.loads(AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(test)) == test