

# Generated at 2022-06-20 15:44:12.660277
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    def _custom_obj_hook(dct):
        if '__ansible_vault' in dct:
            from ansible.parsing.vault import VaultSecret
            return VaultSecret(dct['__ansible_vault'])
        if '__ansible_unsafe' in dct:
            return to_text(dct['__ansible_unsafe'], errors='surrogate_or_strict')
        return dct

    import ansible.parsing.vault
    vault_secret = ansible.parsing.vault.VaultSecret(b'xxx')


# Generated at 2022-06-20 15:44:25.074982
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import PY3
    # Test without special handling of unsafe/vault
    aje = AnsibleJSONEncoder()
    a = dict(a=1, b=2)
    if PY3:
        result = aje.iterencode(a).decode()
    else:
        result = aje.encode(a)
    assert result == '{"a": 1, "b": 2}', "Expected {\"a\": 1, \"b\": 2}, but got %s" % result
    # Test with special handling
    aje = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-20 15:44:32.408741
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import b, text_type
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode, VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.module_utils.common.collections import ImmutableDict

    vault_pwd = b("ansible")
    vault = VaultLib(vault_pwd)
    unsafe_str = b("unsafe string")
    safe_str = text_type("safe string")
    encoded_unsafe_str = json.dumps({'__ansible_unsafe': unsafe_str}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-20 15:44:38.891834
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # 1. (ascii) > ansible_unsafe
    ansible_unsafe_obj = to_unicode('\u1e9b', encoding='utf-8')
    expected_result = '{"__ansible_unsafe": "\\\\u1e9b"}'

    result = AnsibleJSONEncoder(preprocess_unsafe=True).iterencode(ansible_unsafe_obj)
    assert next(result) == expected_result

    # 2. (utf-8) > ansible_

# Generated at 2022-06-20 15:44:47.307673
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-20 15:44:50.358689
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    enc = AnsibleJSONEncoder()
    assert(enc._preprocess_unsafe == False)
    assert(enc._vault_to_text == False)

# Generated at 2022-06-20 15:45:01.661153
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # test a VaultSecret instance
    vault_secret = VaultSecret('I am a vault secret')
    ansible_json_encoder = AnsibleJSONEncoder()
    json_dict = ansible_json_encoder.default(vault_secret)
    assert isinstance(json_dict, dict)
    assert '__ansible_vault' in json_dict
    assert json_dict['__ansible_vault'] == vault_secret.encode('utf-8')

    # test a VaultLib instance
    vault_lib = VaultLib('123')
    ansible_json_encoder = AnsibleJSONEncoder()
    json_dict = ansible_json_encoder.default(vault_lib)


# Generated at 2022-06-20 15:45:07.651190
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    ansible_json_encoder = AnsibleJSONEncoder()
    group = (1, 2, '3')
    assert json.loads(json.dumps(group, cls=ansible_json_encoder)) == group
    group = {'a': 1, 'b': 2, 'c': '3'}
    assert json.loads(json.dumps(group, cls=ansible_json_encoder)) == group

# Generated at 2022-06-20 15:45:15.412610
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test indirect object class __UNSAFE__
    ansible_unsafe = '__ansible_unsafe'
    assert getattr(ansible_unsafe, '__UNSAFE__', False) is True

    # Test indirect object class __ENCRYPTED__
    ansible_encrypted = '__ansible_vault'
    assert getattr(ansible_encrypted, '__ENCRYPTED__', False) is True

    # Test indirect object class Mapping
    ansible_mapping = {'key1':'value1', 'key2':'value2'}
    assert isinstance(ansible_mapping, Mapping)

    # Test indirect object class datetime
    ansible_date = datetime.datetime(2017, 1, 1)
    assert isinstance(ansible_date, datetime.datetime)



# Generated at 2022-06-20 15:45:26.500437
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    # Create a unicode test string
    test_unsafe_string = to_unicode(u"¥500")
    test_safe_string = to_unicode(u"¥500")

    # Create a sample dictionary.
    test_dict = dict()
    test_dict['unsafe'] = AnsibleUnsafe(test_unsafe_string)
    test_dict['safe'] = test_safe_string

    # Create a vault password and encrypt unsafe string
    vault_password = 'secret'
    vault_lib = VaultLib(vault_password)

# Generated at 2022-06-20 15:45:36.212464
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.facts.system.osx.version import DarwinVersion
    # class DarwinVersion(object):
    #     def __init__(self, version):
    #         self.version = version
    #     def __str__(self):
    #         return self.version
    #     def __repr__(self):
    #         return self.version

    osx_version = DarwinVersion("10.13.6")
    aje = AnsibleJSONEncoder()
    assert("10.13.6" == aje.default(osx_version))
    assert("10.13.6" == aje.iterencode("10.13.6"))

    from datetime import datetime
    dt = datetime(2016, 7, 18, 0, 0, 0)

# Generated at 2022-06-20 15:45:48.696690
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import ansible.module_utils.basic
    from ansible.parsing.vault import VaultLib
    ajm = ['AnsibleModule', 'AnsibleUnsafe', 'AnsibleVaultEncryptedUnicode', 'VaultSecret', 'VaultAES256']
    # make sure we have the current classes in ansible
    assert all(hasattr(ansible.module_utils.basic, name) for name in ajm)

    # try to encode a class
    myObject = VaultAES256
    try:
        result = AnsibleJSONEncoder().default(myObject)
        assert False, 'should have failed'
    except:
        pass

    # try to encode a builtin
    myObject = 1
    result = AnsibleJSONEncoder().default(myObject)
    assert result == 1

    #

# Generated at 2022-06-20 15:45:49.927065
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    result = AnsibleJSONEncoder(False)
    assert(result is not None)

# Generated at 2022-06-20 15:46:00.737483
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Test method default of class AnsibleJSONEncoder
    """
    # Test case 1:
    #   o = AnsibleUnsafe(value="", parseable=False, errors='surrogate_or_strict')
    #   Expected result:
    #       {'__ansible_unsafe': u'e30='}
    o = AnsibleUnsafe(value="", parseable=False, errors='surrogate_or_strict')
    e = AnsibleJSONEncoder(preprocess_unsafe=False)
    a = e.default(o)
    assert(a.get('__ansible_unsafe') == u'e30=')

    # Test case 2:
    #   o = AnsibleUnsafe(value="", parseable=False, errors='surrogate_or_strict')
    #

# Generated at 2022-06-20 15:46:12.129010
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText

    # initialize
    plain_dict = {'a': 1, 'b': 2}
    plain_list = [1, 2, 3]
    plain_str = "plain_str"
    unsafe_str = AnsibleUnsafeText("unsafe_str")
    vault_str = VaultLib().encrypt("vault_str")

    # test for iterencode within ansible code
    ansible_json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-20 15:46:19.370089
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import OrderedDict

    import re

    vaultfile = './.vault_pw'
    vault = VaultLib(vaultfile)
    vault.load()
    unsafe1 = vault.encrypt(b'abc')
    # verify the string is encrypted by vault
    assert re.search(b'^\$ANSIBLE_VAULT\!\w+\$', unsafe1)

    unsafe2 = vault.encrypt(u'xyz')
    # verify the unicode string is encrypted by vault
    assert re.search(u'^\$ANSIBLE_VAULT\!\w+\$', unsafe2)

    unsafe3 = vault.encrypt(u'你好')
    # verify the

# Generated at 2022-06-20 15:46:22.416441
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleUnsafe
    # TODO: use the 'unsafe' flag here so we can go back to passing a byte string
    test_string = AnsibleUnsafe(text_type('this is a test'))
    test_json = AnsibleJSONEncoder().encode(test_string)
    assert json.loads(test_json) == {"__ansible_unsafe": test_string}

# Generated at 2022-06-20 15:46:32.541828
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    json_str = b"{'a': 'b', 'c': 1, 'd': ['a', 'b', 'c'], 'e': {'aa': 'bb'}, 'f': '2016-07-01 12:15:28.976291', 'g': '2016-07-01'}"
    json_dict = json.loads(json_str)

    encoder = AnsibleJSONEncoder(sort_keys=True, indent=2)
    encoded_str = to_text(encoder.encode(json_dict))

    # Check if the string form of json_dict is the same

# Generated at 2022-06-20 15:46:39.152053
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils import basic
    from ansible.parsing.vault import VaultLib
    from ansible.vars import AnsibleVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    v = VaultLib(None, b'password')
    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    dec = json.JSONDecoder()

    # Test tuple
    test_data = (
        ('test_str', 'str'),
        ('test_int', 1),
        ('test_float', 1.1),
        ('test_vault', v.encrypt('test_vault')),
        ('test_unsafe', AnsibleUnsafe('test_unsafe')),
        ('test_none', None),
    )

    # Test tuple after iterencode


# Generated at 2022-06-20 15:46:49.016070
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six.moves import StringIO
    import simplejson
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    vault_key = '$ANSIBLE_VAULT;1.2;AES256;test'

    # Test when _preprocess_unsafe is False
    unsafe = AnsibleUnsafeText(u'unsafe')
    o = [{'__ansible_unsafe': 'unsafe'}, {'__ansible_unsafe': unsafe}]
    aje = AnsibleJSONEncoder(preprocess_unsafe=False)
    test_unsafe = simplejson.load(StringIO(aje.encode(o)))

# Generated at 2022-06-20 15:46:57.730016
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    data = [
        'ansible',
        123,
        {'user': 'bob', 'age': 79},
        datetime.datetime(2017, 7, 25, 15, 29, 14, 113960),
    ]
    for i in data:
        assert encoder.default(i) == i


# Generated at 2022-06-20 15:47:05.290787
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    '''Unit test for method iterencode of class AnsibleJSONEncoder
    '''
    import ansible.module_utils.common.unsafe_proxy
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Test for default case
    def test_default_case(encoding):
        ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
        expected = b'{"normal_dict": "normal_dict_value"}'
        test_dict = {'normal_dict': 'normal_dict_value'}

        assert expected == b''.join(ansible_encoder.iterencode(test_dict))

    # Test for basic case of safe proxy object
    def test_basic_safe_proxy_object(encoding):
        ansible_encoder = Ansible

# Generated at 2022-06-20 15:47:16.782187
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # Test for ansible.parsing.vault.VaultLib

# Generated at 2022-06-20 15:47:19.522778
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert(encoder.default(json.JSONEncoder) == '<class \'json.encoder.JSONEncoder\'>')



# Generated at 2022-06-20 15:47:29.981674
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    sample_text = "text to be encrypted"
    sample_vault_password = "ansible"
    sample_dict = {"password": AnsibleUnsafe(to_bytes(sample_text)) if PY2 else AnsibleUnsafe(sample_text)}

    if PY2:
        sample_text = to_bytes(sample_text)

    loader = DataLoader()
    vault_file = VaultLib(loader=loader)

# Generated at 2022-06-20 15:47:38.540894
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe

    value = [AnsibleUnsafe("This is a test"), {"key": AnsibleUnsafe("This is a test")}]

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    value = encoder.iterencode(value)
    value = json.loads(value)

    assert value == [{'__ansible_unsafe': 'This is a test'}, {'key': {'__ansible_unsafe': 'This is a test'}}]

# Generated at 2022-06-20 15:47:47.709649
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)
    AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, separators=(',', ':'))
    AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True, separators=(',', ':'))
    AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True, separators=(',', ':'))


# Generated at 2022-06-20 15:47:50.559279
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    data = {'name': 'user_name', 'age': 20}
    try:
        AnsibleJSONEncoder().encode(data)
    except Exception:
        assert False

# Generated at 2022-06-20 15:47:58.131830
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    import ansible.constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    c = C.DEFAULT_VAULT_ID_MATCH
    c.extend([r for r in C.DEFAULT_VAULT_ID_MATCH_REPLACE])
    vault_password_file = None
    loader = DataLoader()
    vault = VaultLib(c, vault_password_file, loader)
    encrypted_str = vault.encrypt(b'hello')
    encrypted_bytes = vault.encrypt(b'world')
    unsafe_str = AnsibleUnsafeText('hello')

# Generated at 2022-06-20 15:47:59.112016
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    # TODO
    pass

# Generated at 2022-06-20 15:48:05.570424
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps('abcd', cls=AnsibleJSONEncoder) == '"abcd"'

# Generated at 2022-06-20 15:48:16.805881
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.basic import AnsibleUnsafe

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    unsafe_obj = AnsibleUnsafe('{"secret_key": "super_secret_key"}')
    assert _is_unsafe(unsafe_obj) is True
    assert _is_vault(unsafe_obj) is False
    assert encoder.default(unsafe_obj) == {'__ansible_unsafe': '{"secret_key": "super_secret_key"}'}
    assert encoder.iterencode(unsafe_obj) == '{"__ansible_unsafe": "{\'secret_key\': \'super_secret_key\'}"}'

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.iterencode

# Generated at 2022-06-20 15:48:28.264352
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # simple string
    assert AnsibleJSONEncoder().default('ansible') == 'ansible'
    # simple integer
    assert AnsibleJSONEncoder().default(123) == 123
    # simple dictionary
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}
    # ansible vault object
    assert AnsibleJSONEncoder().default({'__ansible_vault': 'ansible'}) == {'__ansible_vault': 'ansible'}
    # ansible unsafe object
    assert AnsibleJSONEncoder().default({'__ansible_unsafe': 'ansible'}) == {'__ansible_unsafe': 'ansible'}
    # date object
    date = datetime.date(2016, 1, 1)

# Generated at 2022-06-20 15:48:33.361538
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib({"password": "secret"}, b"key")
    data = {
        u'name': u'foo',
        u'created': datetime.date(2015, 4, 30),
        u'password': u'password',
        u'password2': vault
    }

    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    json_data = json.loads(ansible_json_encoder.encode(data))


# Generated at 2022-06-20 15:48:44.926064
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.utils import py3compat
    import json

    # pylint: disable=unused-variable
    def _test_unsafe(unsafe, expected):
        r = StringIO()
        encoder = json.Encoder(r)
        encoder.encode(unsafe)
        assert r.getvalue() == expected

    unsafe_string = AnsibleUnsafe(u'\u2713')
    _test_unsafe(unsafe_string, '"\\u2713"')
    _test_unsafe(u'\x00', '"\\u0000"')
   

# Generated at 2022-06-20 15:48:52.982594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    unsafe_val = 'unsafe_val'
    unsafe_obj = mock_unsafe_class()
    unsafe_obj.__UNSAFE__ = True
    vault_val = 'vault_val'
    vault_obj = mock_vault_class()
    vault_obj.__ENCRYPTED__ = True
    date_obj = datetime.date.today()
    # default value of _vault_to_text is False
    assert ansible_json_encoder.default(unsafe_val) == unsafe_val
    assert ansible_json_encoder.default(unsafe_obj) == {
        '__ansible_unsafe': 'unsafe_val'
    }

# Generated at 2022-06-20 15:49:03.170758
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AnsibleUnsafe
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    import json

    # Initialize the vault
    vault_secret = VaultLib([])
    vault_secret.password = 'testpass'

# Generated at 2022-06-20 15:49:14.020147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib, VaultSecret
    vault_password = VaultSecret(b'password').value
    vault_lib = VaultLib(vault_password)
    unsafe_text = "user \n password"
    vault_text = vault_lib.encrypt(unsafe_text)
    value = AnsibleJSONEncoder().default(vault_text)
    assert isinstance(value, dict)
    assert '__ansible_vault' in value
    value = AnsibleJSONEncoder(vault_to_text=True).default(vault_text)
    assert isinstance(value, text_type)
    assert value == vault_text.strip()
    value = AnsibleJSONEncoder().default(unsafe_text)
    assert value == unsafe_text


# Generated at 2022-06-20 15:49:15.632026
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)


# Generated at 2022-06-20 15:49:27.622476
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    test_str = u'Hello world'
    test_str_bytes = to_bytes(test_str)

# Generated at 2022-06-20 15:49:44.452014
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    assert AnsibleJSONEncoder().default('test string') == 'test string'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test string')) == {'__ansible_unsafe': 'test string'}
    assert AnsibleJSONEncoder().default(42) == 42

    assert AnsibleJSONEncoder().default(['test string']) == ['test string']
    assert AnsibleJSONEncoder().default([AnsibleUnsafe('test string')]) == [{'__ansible_unsafe': 'test string'}]


# Generated at 2022-06-20 15:49:46.168455
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder, json.JSONEncoder)

# Generated at 2022-06-20 15:49:56.378886
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    from ansible.module_utils.common._collections_compat import Mapping

    from ansible.module_utils.six import PY3

    from io import BytesIO
    from io import TextIOWrapper

    vault_password = 'vault_password'

    v = VaultLib([])
    v._save_parsed_vault_id = False

    plain_text = b'''{"a": 123}'''

    text_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    text_encoder_preprocess_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)



# Generated at 2022-06-20 15:50:07.434013
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    import unittest
    import datetime
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    class TestJSONEncoder(AnsibleJSONEncoder):
        def __init__(self, foo, test=None, **kwargs):
            super(TestJSONEncoder, self).__init__(**kwargs)
            self._foo = foo
            self._test = test

    class TestSequence(list):
        def __init__(self, *args):
            super(TestSequence, self).__init__(*args)

        def __getattr__(self, name):
            if name == '__UNSAFE__':
                return True
            raise AttributeError(name)


# Generated at 2022-06-20 15:50:16.013404
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ''' Test AnsibleJSONEncoder.default '''
    import ansible.module_utils.six as six

    encoder = AnsibleJSONEncoder()

    # check all types of objects
    def check_default(obj):
        ''' wrapper for AnsibleJSONEncoder.default
        to check if the object should be handled in default '''
        default = encoder.default(obj)
        if getattr(obj, '__ENCRYPTED__', False) or getattr(obj, '__UNSAFE__', False):
            if isinstance(default, six.string_types):
                return True
            elif isinstance(default, dict) and '__ansible_vault' in default:
                return True
            elif isinstance(default, dict) and '__ansible_unsafe' in default:
                return True


# Generated at 2022-06-20 15:50:24.999674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type

    text_type_object = text_type('test')
    boolean_value = boolean(text_type_object)
    boolean_value.__UNSAFE__ = True
    boolean_value.__ENCRYPTED__ = False

    vault_lib = VaultLib([])
    vault_object = vault_lib.encrypt('test')
    vault_object._text = text_type('test')

# Generated at 2022-06-20 15:50:33.972297
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default(dict(key='value')) == {'key': 'value'}
    assert AnsibleJSONEncoder().default(datetime.date(day=1, month=1, year=2018)) == '2018-01-01'
    assert AnsibleJSONEncoder().default(datetime.datetime(day=1, month=1, year=2018)) == '2018-01-01T00:00:00'

    class A:
        def __init__(self, value):
            self.value = value
        def __UNSAFE__(self):
            return True

# Generated at 2022-06-20 15:50:45.396940
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    d = {'str': 'str', 'unsafe': 'unsafe', 'vault':'vault', 'dict': {'str2': 'str2', 'unsafe2': 'unsafe2', 'vault2':'vault2'}}
    d_encoded = {'str': 'str', 'unsafe': 'unsafe', 'vault':'vault', 'dict': {'str2': 'str2', 'unsafe2': 'unsafe2', 'vault2':'vault2'}}

# Generated at 2022-06-20 15:50:50.387861
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # assert that the AnsibleJSONEncoder is a subclass of json.JSONEncoder
    assert issubclass(AnsibleJSONEncoder, json.JSONEncoder)
    # assert that the constructor instantiates an object of class AnsibleJSONEncoder
    assert isinstance(AnsibleJSONEncoder(), AnsibleJSONEncoder)

# Generated at 2022-06-20 15:50:59.313886
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    assert ansible_json_encoder.default(None) is None
    assert ansible_json_encoder.default(False) is False
    assert ansible_json_encoder.default(True) is True
    assert ansible_json_encoder.default([]) == []
    assert ansible_json_encoder.default({}) == {}
    assert ansible_json_encoder.default('test') == 'test'
    assert ansible_json_encoder.default(u'\u2665') == u'\u2665'
    assert ansible_json_encoder.default(1.1) == 1.1
    assert ansible_json_encoder.default(2) == 2

# Generated at 2022-06-20 15:51:09.214405
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    json_encoder = AnsibleJSONEncoder()
    ret = json_encoder.default(5)
    print(ret)


# Generated at 2022-06-20 15:51:21.810819
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    decoder = json.JSONDecoder()

    # fake unsafe object
    unsafe_obj = 'unsafe'
    unsafe_obj.__UNSAFE__ = True
    unsafe_obj.__ENCRYPTED__ = False

    # fake vault object
    vault_obj = 'vault'
    vault_obj.__UNSAFE__ = False
    vault_obj.__ENCRYPTED__ = True

    # fake hostvars

# Generated at 2022-06-20 15:51:26.818384
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()._preprocess_unsafe is False
    assert AnsibleJSONEncoder()._vault_to_text is False

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder._preprocess_unsafe is True
    assert encoder._vault_to_text is True


# Test all the things

# Generated at 2022-06-20 15:51:33.103672
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():

    class Foo:
        def __getitem__(self, key):
            return str(key)

    class Bar(Foo):
        __UNSAFE__ = True

    class Baz(Foo):
        __ENCRYPTED__ = True

    class Qux(Foo):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    assert json.dumps(Qux()) == '{}'

    assert list(AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).iterencode(Qux())) == [
        '{',
        '"__ansible_unsafe": "{}"',
        '}',
    ]


# Generated at 2022-06-20 15:51:43.989215
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.module_utils.basic import AnsibleUnsafe
    test_input_object = {
        "test_key_1": "test_val_1",
        "test_key_2": "test_val_2",
        "test_key_3": AnsibleUnsafe("{'test_val_3': 'test-val-3'}"),
        "test_key_4": AnsibleUnsafe("{\"test_val_4\": \"test-val-4\"}")
    }


# Generated at 2022-06-20 15:51:55.436758
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnsafe, AnsibleSequence
    from ansible.vars import HostVars

    def _assert_no_unsafe_types(data):
        """Recursively check for ``AnsibleUnsafe`` instances"""
        if isinstance(data, AnsibleUnsafe):
            raise AssertionError("found unsafe type in {0}".format(data))
        elif isinstance(data, AnsibleBaseYAMLObject):
            try:
                data = data.data
            except AttributeError:
                pass
        elif isinstance(data, (list, tuple)):
            for item in data:
                _assert_no_unsafe_types(item)
       

# Generated at 2022-06-20 15:52:06.603972
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import json
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.encoding import to_bytes
    from ansible.module_utils.common.text.types import AnsibleUnsafe
    class Unsafe(AnsibleUnsafe):
        pass
    assert json.dumps('test', cls=AnsibleJSONEncoder) == '"test"'
    assert json.dumps(Unsafe('test'), cls=AnsibleJSONEncoder) == '{"__ansible_unsafe": "test"}'

# Generated at 2022-06-20 15:52:16.188817
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    now = datetime.datetime.now()
    now_str = now.isoformat()
    x = AnsibleUnsafeText("this is unsafe text")
    t = {'x':x, 'y':now}
    # Test AnsibleJSONEncoder.default
    t_out = AnsibleJSONEncoder().default(t)
    assert t_out['x'] == to_text(x), "Error on converting AnsibleUnsafeText to JSON"
    assert t_out['y'] == now_str, "Error on converting datetime to JSON"

# Generated at 2022-06-20 15:52:18.973873
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    # Make sure that it raises KeyError for unknown keyword argument
    with pytest.raises(KeyError):
        AnsibleJSONEncoder(foo='bar')


# Generated at 2022-06-20 15:52:19.863873
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    assert AnsibleJSONEncoder()


# Generated at 2022-06-20 15:52:36.005484
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict1 = dict({
        'a': 'b',
        'foo': {
            'c': 'd',
            'e': ['f', 'g', 'h', 'i']
        }
    })

    # Example 1: test for python string
    x = 'string'
    y = AnsibleJSONEncoder().default(x)
    assert(x == y)

    # Example 2: test for python number
    x = 10
    y = AnsibleJSONEncoder().default(x)
    assert(x == y)

    # Example 3: test for python dictionary
    str1 = AnsibleJSONEncoder().default(dict1)
    str2 = json.dumps(dict1)
    assert(str1 == str2)

    # Example 4: test for python list

# Generated at 2022-06-20 15:52:47.469373
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Temporary vault file
    temp_file = tempfile.NamedTemporaryFile()
    # Password for vault file
    temp_password = 'temp_password'
    # Text to be encrypted
    text = 'I am the captain now'
    # Encrypt the text
    vault = VaultLib([])
    vault.encrypt_string(text, temp_password, output_file=temp_file.name)
    # Read the ciphertext
    ciphertext = temp_file.read()

    # Verify that iterencode method handles the encrypted text
    # Create encrypted AnsibleUnsafe object
    vault_secret = VaultSecret(ciphertext)
    # Create AnsibleUnsafe object
    ansible_

# Generated at 2022-06-20 15:52:50.257458
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder, AnsibleJSONEncoder)
    assert isinstance(encoder, json.JSONEncoder)


# Generated at 2022-06-20 15:52:58.262334
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(22) == 22
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default({"__ENCRYPTED__": True, "__UNSAFE__": True,
                                         "_ciphertext": "test", "__VAULT__": True}) == {'__ansible_vault': 'test'}
    assert AnsibleJSONEncoder(vault_to_text=True).default({"__ENCRYPTED__": True, "__UNSAFE__": True,
                                                           "_ciphertext": "test", "__VAULT__": True}) == 'test'



# Generated at 2022-06-20 15:53:09.823881
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    class MyAnsibleUnsafe(unicode):
        """Simple class to provide a string like object"""
        __UNSAFE__ = True

    ansible_unsafe = MyAnsibleUnsafe(u"unsafe string")
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_encoder._exception_on_repr = False
    json_encoder._preprocess_unsafe = False
    assert json_encoder.encode(ansible_unsafe) == json.dumps({'__ansible_unsafe': u'unsafe string'})
    assert json_encoder.encode([ansible_unsafe]) == json.dumps([{'__ansible_unsafe': u'unsafe string'}])

# Generated at 2022-06-20 15:53:13.125201
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    ansible_json_encoder = AnsibleJSONEncoder()

    assert ansible_json_encoder.__class__ == AnsibleJSONEncoder

# Generated at 2022-06-20 15:53:23.418868
# Unit test for method iterencode of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_iterencode():
    from ansible.parsing.vault import VaultLib  # needed here to avoid circular imports
    from units.mock.loader import DictDataLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    vault_password = 'secret_password'
    vault_cipher = 'sha256'
    vault_lib = VaultLib(loader=DictDataLoader({}), password=vault_password, cipher=vault_cipher)
    value = vault_lib.encrypt('test_vault_string')

    expected_dict = {'__ansible_vault': vault_lib.encrypt('test_vault_string').encode('utf-8')}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-20 15:53:34.529138
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class SafeString(str):
        pass

    class UnsafeString(str):
        __UNSAFE__ = True

    class VaultString(str):
        __ENCRYPTED__ = True

    class SafeList(list):
        pass

    class UnsafeList(list):
        __UNSAFE__ = True

    class SafeDict(dict):
        pass

    class UnsafeDict(dict):
        __UNSAFE__ = True

    class UnsafeMap(Mapping):
        __UNSAFE__ = True

        def __iter__(self):
            return iter(())

        def __len__(self):
            return 0

        def __getitem__(self, key):
            pass


# Generated at 2022-06-20 15:53:44.072441
# Unit test for constructor of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder():
    from ansible.module_utils.urls import Request
    from ansible.module_utils.six import u
    import datetime

    ansible_dict = {
        'ascii': 'hi',
        'ascii_dict': {'hi': 'hi'},
        'ascii_list': ['hi', 'hi'],
        'unicode': u('你好'),
        'unicode_dict': {u('你好'): u('你好')},
        'instance': datetime.date(2017, 9, 1),
        'instance_dict': {u('你好'): datetime.date(2017, 9, 1)},
        'class': Request,
    }

    # test default options
    encoder = AnsibleJSONEncoder()
    ansible_encoded_

# Generated at 2022-06-20 15:53:54.399524
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    s = AnsibleJSONEncoder().default('"\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f')