

# Generated at 2022-06-11 00:58:20.034326
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 00:58:31.411617
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import b

    # case 1: try to encode a vault object
    json_dumps_default = json.dumps
    ansible_json_dumps_default = AnsibleJSONEncoder().encode
    vault_password = 'test_AnsibleJSONEncoder_default'
    vault_obj = VaultLib(vault_password)
    vault_encrypted_data = vault_obj.encrypt('string')
    ansible_json_dumps_default(vault_encrypted_data)
    json_dumps_default(vault_encrypted_data)
    assert (json_dumps_default(vault_encrypted_data) != ansible_json_dumps_default(vault_encrypted_data))

# Generated at 2022-06-11 00:58:37.299970
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, text_type

    encoder = AnsibleJSONEncoder()
    assert encoder.default(set()) == set()
    assert encoder.default(text_type()) == text_type()
    assert encoder.default(binary_type()) == binary_type()
    assert encoder.default(bytearray()) == bytearray()
    assert encoder.default(memoryview()) == memoryview()

# Generated at 2022-06-11 00:58:47.294894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    init_kwargs = dict(indent=2, separators=(',', ': '), sort_keys=True, ensure_ascii=False)

    encoder = AnsibleJSONEncoder(**init_kwargs)

    # test for vault
    o = u'$ANSIBLE_VAULT;1.1;AES256\n363261356163396663313736653938353666316237616237633766313261613362393930623365\n64353466316465333262363234363536313332326566386434613461323231303430653561633165\n34366363636462633664663630393765336262653165313232353739\n'

# Generated at 2022-06-11 00:58:51.408621
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    assert AnsibleJSONEncoder(indent=0).default(AnsibleUnsafeText('password')) == 'password'



# Generated at 2022-06-11 00:58:52.905719
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    assert AnsibleJSONEncoder().default(5.5) == 5.5

# Generated at 2022-06-11 00:59:03.056121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import u

    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default({"dummy": "value"}) == {"dummy": "value"}
    assert ansible_json_encoder.default("dummy") == "dummy"
    assert ansible_json_encoder.default(1) == 1
    assert ansible_json_encoder.default(u("dummy")) == "dummy"

    vault_secret = VaultSecret("hello world", "ansible-vault", 1, "AES256")
    vault = VaultLib([vault_secret])
    encrypted = vault.encrypt("secret")
   

# Generated at 2022-06-11 00:59:06.616053
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = 'test'
    json_test_data = json.dumps(test_data, cls=AnsibleJSONEncoder)
    encoded_test_data = json_test_data
    assert json_test_data == encoded_test_data

# Generated at 2022-06-11 00:59:09.337420
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    arg1 = {"test": "test"}
    value = AnsibleJSONEncoder().default(arg1)
    assert value == arg1


# Generated at 2022-06-11 00:59:13.250933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_text

    assert AnsibleJSONEncoder().encode({'a': to_text('test')}) == b'{"a": "test"}'


# Generated at 2022-06-11 00:59:23.715268
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    # Test for Mapping
    assert aje.default(dict(a='a')) == dict(a='a')
    # Test for datetime
    dt = datetime.datetime(1901, 1, 1, 1, 1, 1)
    assert aje.default(dt) == dt.isoformat()
    # Test for __ENCRYPTED__
    class A:
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
            self.__ENCRYPTED__ = True
    a = A('some_cipher_text')
    assert aje.default(a) == {'__ansible_vault': 'some_cipher_text'}
    assert aje.default(a) != a



# Generated at 2022-06-11 00:59:35.340986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""
    import ansible.parsing.vault as vault
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    a = {'a': '1', 'b': AnsibleUnsafeText('2'), 'c': AnsibleUnsafe('3'), 'd': {'e': '5'}, 'f': vault.VaultSecret('6')}
    encoder = AnsibleJSONEncoder()
    b = encoder.default(a)

# Generated at 2022-06-11 00:59:36.292292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-11 00:59:46.579290
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    encoder = AnsibleJSONEncoder()

    date_obj = datetime.date(2017, 1, 1)
    date_encoded = '"2017-01-01"'

    unsafe_obj = VaultSecret('foo')
    unsafe_encoded = '{"__ansible_unsafe": "foo"}'

    vault_obj = VaultLib('bar')
    vault_encoded = '{"__ansible_vault": "bar"}'

    dict_obj = dict(foo='var')
    dict_encoded = json.dumps(dict_obj)

    assert encoder.default(date_obj) == date_encoded

# Generated at 2022-06-11 00:59:58.156295
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    def check_defaults_for_value(value, expected_value):
        json_encoder = AnsibleJSONEncoder()
        actual_value = json_encoder.default(value)
        assert actual_value == expected_value

    check_defaults_for_value('test', 'test')
    check_defaults_for_value(True, True)
    check_defaults_for_value(set(), [])
    check_defaults_for_value({'a': 'test'}, {'a': 'test'})
    check_defaults_for_value({'a': b'invalid str'}, {'a': u'invalid str'})
    check_defaults_for_value({'a': b'invalid str'.decode('utf-8', 'ignore')}, {'a': u''})
   

# Generated at 2022-06-11 01:00:05.032943
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().encode(datetime.datetime(2019, 1, 1, 0, 0)) == '"2019-01-01T00:00:00"'
    assert AnsibleJSONEncoder().encode(datetime.date(2019, 1, 1)) == '"2019-01-01"'


if __name__ == '__main__':
    from pytest import main
    import ansible.module_utils.json_utils
    main([ansible.module_utils.json_utils.__file__])

# Generated at 2022-06-11 01:00:14.902740
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3, binary_type
    from datetime import date

    a = "1"
    toa = to_text(a)
    tobya = to_bytes(a)
    enc = AnsibleJSONEncoder()

    # test default handler of string types
    assert enc.default(a) == a
    if PY3:
        assert isinstance(enc.default(a), str)
    else:
        assert isinstance(enc.default(a), unicode)

    # test default handler of binary types

# Generated at 2022-06-11 01:00:26.451556
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert AnsibleJSONEncoder().default([1, {'a': 'b'}]) == [1, {'a': 'b'}]
    assert AnsibleJSONEncoder().default({'a': [1, {'a': 'b'}]}) == {'a': [1, {'a': 'b'}]}

    assert AnsibleJSONEncoder().default(datetime.date(year=2017, month=12, day=4)) == '2017-12-04'
    assert AnsibleJSONEncoder().default(datetime.datetime(year=2017, month=12, day=4, hour=1, minute=2, second=3)) == '2017-12-04T01:02:03'


# Generated at 2022-06-11 01:00:28.772891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.plugin_docs import AnsibleDocs

    x = AnsibleDocs('', b'{{"1": 2, "3": 4, "5": 6}}')
    y = AnsibleJSONEncoder().default(x)
    if y != {'1': 2, '3': 4, '5': 6}:
        raise AssertionError('Invalid value')

# Generated at 2022-06-11 01:00:37.296264
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder()
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.vars.secrets.vault import VaultSecret
    from ansible.vars.secrets.identity import IdentitySecret

    # Default encoder
    assert ansible_encoder.default(VaultLib()) == json.JSONEncoder.default(ansible_encoder, VaultLib())
    # Hostvars and other objects
    assert ansible_encoder.default({'a': 1}) == {'a': 1}
    # Date object
    assert ansible_encoder.default(datetime.date(2017, 5, 2)) == u'2017-05-02'
    # Unsafe object
    assert ansible_

# Generated at 2022-06-11 01:00:51.885332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()

    test_dict = {
        "test_dict_value": "success"
    }

    test_date = datetime.date.today()

    test_vault = VaultLib(None)

    value = encoder.default(test_dict)
    assert isinstance(value, dict)
    assert value == test_dict

    value = encoder.default(test_date)
    assert isinstance(value, str)
    assert value == test_date.isoformat()

    value = encoder.default(test_vault)
    assert isinstance(value, dict)
    assert value['__ansible_vault'] == test_vault._ciphertext

# Generated at 2022-06-11 01:00:59.965563
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default('a') == 'a'
    assert encoder.default(datetime.datetime(2018, 1, 16, 11, 0, 0, tzinfo=datetime.timezone.utc)) == '2018-01-16T11:00:00.000000+00:00'
    assert encoder.default(datetime.date(2018, 1, 16)) == '2018-01-16'
    from ansible.parsing.vault import VaultSecret
    assert encoder.default(VaultSecret(b'vault_secret')) == {'__ansible_vault': 'vault_secret'}

# Generated at 2022-06-11 01:01:11.015053
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import obfuscate_strings

    j = AnsibleJSONEncoder()

    # Simple strings
    assert to_text(j.encode('foo')) == u'"foo"'
    assert to_text(j.encode(to_text(u'bar'))) == u'"bar"'
    assert to_text(j.encode(to_text(u'bar', errors='strict'))) == u'"bar"'
    assert to_text(j.encode('foo')) == u'"foo"'
    assert to_text(j.encode(b'foo')) == u'"foo"'
    assert to_

# Generated at 2022-06-11 01:01:21.134902
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()

    #try normal string
    value = json_encoder.default("This is a sample string")
    assert isinstance(value, str)
    assert value == "This is a sample string"

    #try date object
    current_date = datetime.date.today()
    value = json_encoder.default(current_date)
    assert isinstance(value, str)
    assert value == current_date.isoformat()

    #try date object
    current_datetime = datetime.datetime.now()
    value = json_encoder.default(current_datetime)
    assert isinstance(value, str)
    assert value == current_datetime.isoformat()

    #try vault object
    from ansible.parsing.vault import VaultLib
    vault_string

# Generated at 2022-06-11 01:01:32.434656
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(True, cls=AnsibleJSONEncoder)) is True
    assert json.loads(json.dumps(False, cls=AnsibleJSONEncoder)) is False
    assert json.loads(json.dumps(1, cls=AnsibleJSONEncoder)) == 1
    assert json.loads(json.dumps(1.234, cls=AnsibleJSONEncoder)) == 1.234
    assert json.loads(json.dumps('text', cls=AnsibleJSONEncoder)) == 'text'
    assert json.loads(json.dumps((1, 2, 3), cls=AnsibleJSONEncoder)) == [1, 2, 3]

# Generated at 2022-06-11 01:01:42.687147
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    class FakeAnsibleUnsafeClass(str):
        """Fake class that inherits from str and has an __UNSAFE__ attribute"""
        __UNSAFE__ = True

    class FakeAnsibleVaultClass(str):
        """Fake class that inherits from str and has an __ENCRYPTED__ attribute"""
        __ENCRYPTED__ = True

    class FakeAnsibleVaultClass2(str):
        """Fake class that inherits from str and has an __ENCRYPTED__ attribute"""
        __ENCRYPTED__ = True

    # test

# Generated at 2022-06-11 01:01:53.129336
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves.urllib.parse import quote

    assert json.dumps(dict(key=123), cls=AnsibleJSONEncoder) == '{"key": 123}'
    assert json.dumps(dict(key='value'), cls=AnsibleJSONEncoder) == '{"key": "value"}'

    assert json.dumps(dict(key=u'value'), cls=AnsibleJSONEncoder) == '{"key": "value"}'
    assert json.dumps(dict(key=u'value\u20ac'), cls=AnsibleJSONEncoder) == '{"key": "value\u20ac"}'

    # non-string types

# Generated at 2022-06-11 01:02:02.389886
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = AnsibleJSONEncoder()
    assert d.default([1]) == [1]


# Generated at 2022-06-11 01:02:13.669017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret

    # some tests
    assert isinstance(AnsibleJSONEncoder().default({'foo': 'bar'}), dict)
    assert AnsibleJSONEncoder().default('foo') == 'foo'

    # make sure AnsibleUnsafe objects get encoded as dicts
    v = VaultLib([])
    vault_secret = v.encrypt('foo')
    unsafe_obj = vault_secret.unwrap()  # AnsibleVaultEncryptedUnsafeText
    assert isinstance(unsafe_obj, VaultSecret)
    assert AnsibleJSONEncoder().default(unsafe_obj) == {'__ansible_vault': vault_secret._ciphertext}



# Generated at 2022-06-11 01:02:24.456485
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib

    def _get_sample_obj(obj_type):
        obj_type_list = ['mapping', 'datetime', 'vault', 'unsafe']
        if obj_type == 'mapping':
            class SampleMapping(MutableMapping):
                def __init__(self):
                    self._data = dict()

                def __getitem__(self, key):
                    return self._data[key]

                def __setitem__(self, key, value):
                    self._data[key] = value

                def __iter__(self):
                    return iter(self._data)

                def __len__(self):
                    return len(self._data)


# Generated at 2022-06-11 01:02:33.937331
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import Ec2S3Url
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, **dict())
    test_data = [
        ('abc', 'abc'),
        (123, 123),
        (dict(), {}),
        (list(), []),
        (Ec2S3Url('ec2://eu-west-2/bucket/object'), {'__ansible_unsafe': u'ec2://eu-west-2/bucket/object'}),
        ({'a':Ec2S3Url('ec2://eu-west-2/bucket/object')}, {'a':{'__ansible_unsafe': u'ec2://eu-west-2/bucket/object'}})
    ]

# Generated at 2022-06-11 01:02:41.362813
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(a=1,b=2,c=3)) == {'a':1,'b':2,'c':3}
    assert AnsibleJSONEncoder().default(1.1) == 1.1
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(list(range(5))) == list(range(5))
    assert AnsibleJSONEncoder().default(('a', 'b', 'c')) == ('a', 'b', 'c')

# Unit tests for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:02:50.306504
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejson_encoder = AnsibleJSONEncoder
    o = datetime.datetime(2019, 11, 30, 13, 39, 10, 1234)

    # expected:
    # value = o.isoformat()
    # '2019-11-30T13:39:10.001234'

    # actual:
    value = ansiblejson_encoder.default(ansiblejson_encoder, o)
    assert isinstance(value, str)
    assert value == '2019-11-30T13:39:10.001234'


# Generated at 2022-06-11 01:03:00.324223
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert ansible_json_encoder.default(datetime.date.today()) == datetime.date.today().isoformat()
    assert ansible_json_encoder.default(['hello']) == ['hello']
    assert ansible_json_encoder.default({'a': 'b'}) == {'a': 'b'}
    assert ansible_json_encoder.default(set('hello')) == list('hello')
    assert ansible_json_encoder.default((1,2,3)) == [1,2,3]

# Generated at 2022-06-11 01:03:09.584987
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsibleJSONEncoder with and without vault_to_text
    def assert_strings(encoder, obj, expected_json):
        encoder.indent = 4
        json_out = encoder.encode(obj)
        if not json_out == expected_json:
            raise AssertionError("Expected %s, got %s" % (expected_json, json_out))


# Generated at 2022-06-11 01:03:21.645253
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    vault_encoding = 'ascii'

    # Test for pre-encrypted data
    vault = VaultLib([])

# Generated at 2022-06-11 01:03:31.127842
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert True == ansible_json_encoder.default(True)
    assert 1234 == ansible_json_encoder.default(1234)
    assert "test" == ansible_json_encoder.default("test")
    assert [1,2,3] == ansible_json_encoder.default([1,2,3])
    assert "test" == ansible_json_encoder.default("test")

    import datetime
    datetime_now = datetime.datetime.now()
    assert datetime_now.isoformat() == ansible_json_encoder.default(datetime_now)

    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    assert {"__ansible_unsafe": "test"} == ansible_json

# Generated at 2022-06-11 01:03:42.340507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict1 = {'test': 'test'}
    dict2 = {'test': 'test'}
    dict3 = {'test': 'test'}
    dict4 = {'test': 'test'}
    dict5 = {'test': 'test'}
    dict6 = {'test': 'test'}
    dict7 = {'test': 'test'}
    dict8 = {'test': 'test'}
    dict1_list = ["dict1"]
    dict2_list = [dict2]
    dict3_list = [dict3, dict3]
    dict4_list = [dict4, dict4, dict4]
    dict5_list = [dict5, dict5, dict5, dict5]
    dict6_list = [dict6, dict6, dict6, dict6, dict6]

# Generated at 2022-06-11 01:03:50.379257
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common._collections_compat import OrderedDict

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    from ansible.module_utils.ansible_galaxy import GalaxyCache
    from ansible.module_utils.ansible_galaxy.models import GalaxyRepository
    from ansible.module_utils.ansible_galaxy.models.collection_artifact import _CollectionArtifact

    from ansible.module_utils.common import date_time

    from ansible.module_utils.ansible_base._text import to_text
    from ansible.module_utils.ansible_base.module import MODULE_REQUIRED
    from ansible.module_utils.ansible_base.module import AnsibleModule

# Generated at 2022-06-11 01:03:53.558366
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = dict(a=1, b=2, c=3)
    result = encoder.default(o)
    assert result == o


# Generated at 2022-06-11 01:04:06.950146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    vault = VaultLib("password")
    ciphertext = vault.encrypt("password")
    test_dict = dict(
        b=binary_type("binary"),
        t=text_type("text"),
        l=["list"],
        d=dict(list="list"),
        bt=dict(binary=binary_type("binary"), text=text_type("text")),
        u=dict(__ansible_unsafe=u'abc'),
        v=dict(__ansible_vault=ciphertext),
    )
    # test ansibleJsonEncoder.default()
    result_dict = dict()

# Generated at 2022-06-11 01:04:17.752164
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleVault:
        __ENCRYPTED__ = True
        _ciphertext = 'this is a dummy Vault string'

    class AnsibleUnsafe:
        __UNSAFE__ = True

    class Foo:
        pass

    assert 'this is a dummy Vault string' == AnsibleJSONEncoder().default(AnsibleVault())
    assert 'this is an AnsibleUnsafe string' == AnsibleJSONEncoder().default(AnsibleUnsafe('this is an AnsibleUnsafe string'))
    assert 'this is an AnsibleUnsafe string' == AnsibleJSONEncoder().default(AnsibleUnsafe(u'this is an AnsibleUnsafe string'))
    assert 'insight_data' == AnsibleJSONEncoder().default(Foo())


# Generated at 2022-06-11 01:04:28.543372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Python3 unicode strings
    class TestObj1():
        def __init__(self, val):
            self.value = val

        def __repr__(self):
            return self.value

        def __str__(self):
            return self.value

    # Python2 unicode strings
    class TestObj2():
        def __init__(self, val):
            self.value = val

        def __repr__(self):
            return self.value

    class TestObj3():
        def __init__(self, val):
            self.value = val

        def __repr__(self):
            return self.value

        def __getitem__(self):
            return self.value


# Generated at 2022-06-11 01:04:36.655862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result_dict = {
        "__ansible_vault": "my_encrypted_data"
    }
    data = {
        "my_dict": {"my_secret": "my_data"}
    }
    # Check with vault_to_text=False
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=False)
    assert ansible_json_encoder.default(data["my_dict"]["my_secret"]) == result_dict
    # Check with vault_to_text=True
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert ansible_json_encoder.default(data["my_dict"]["my_secret"]) == data["my_dict"]["my_secret"]



# Generated at 2022-06-11 01:04:47.612660
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    import datetime

    # setup
    safe_dict = {"test_key": "test_value"}
    test_date = datetime.date(2010, 5, 31)
    test_datetime = datetime.datetime(2010, 5, 31, 19, 48, 58, 675114)
    test_dict = {"test_key": "test_value", "test_date": test_date, "test_datetime": test_datetime}
    test_list = ["test_1", "test_2", "test_3"]
    test_tuple = ("test_1", "test_2", "test_3")
    test_string = "test"
    test_integer = 3
    test_float = 3.14
    test_boolean = False
   

# Generated at 2022-06-11 01:04:57.426372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnsafeText
    from ansible.vars.unsafe_proxy import create_unsafe_proxy

    vault_password = 'asdf'
    vault_secrets = {'test': 'foo', 'test2': 'bar'}
    vault_secrets_encoded = {}

    vault = VaultLib(vault_password)
    for k, v in vault_secrets.items():
        vault_secrets_encoded[k] = vault.encode(v)

    # Test case for single unsafe items
    unsafe_text = create_unsafe_proxy(u'hello world')
    assert AnsibleJSONEncoder

# Generated at 2022-06-11 01:05:03.377449
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    assert encoder.default(datetime.datetime.now())
    assert encoder.default(datetime.date.today())

    # test with default
    assert encoder.default("default")

    # test with unknown type
    assert encoder.default(EncoderTestObject())



# Generated at 2022-06-11 01:05:13.498171
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    import json
    assert json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=AnsibleJSONEncoder) == '["foo", {"bar": ["baz", null, 1.0, 2]}]'
    assert json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=AnsibleJSONEncoder, skipkeys=True) == '["foo", {"bar": ["baz", null, 1.0, 2]}]'
    assert json.dumps(['foo', {'bar': ('baz', None, 1.0, 2)}], cls=AnsibleJSONEncoder, ensure_ascii=False) == '["foo", {"bar": ["baz", null, 1.0, 2]}]'


# Generated at 2022-06-11 01:05:21.097568
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types, binary_type
    import base64
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    enc_str = vault.encode('str')
    enc_bytes = vault.encode(b'str')
    enc_list = vault.encode([1, 2, 3])

    assert getattr(enc_str, '__ENCRYPTED__', False) is True
    assert getattr(enc_bytes, '__ENCRYPTED__', False) is True
    assert getattr(enc_list, '__ENCRYPTED__', False) is True

    for e in (enc_str, enc_bytes, enc_list):
        encoder = AnsibleJSON

# Generated at 2022-06-11 01:05:30.793012
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # String
    assert AnsibleJSONEncoder().default("test") == "test"

    # Datetime
    test_time = datetime.datetime(2005, 10, 15, 20, 50, 40)
    assert AnsibleJSONEncoder().default(test_time) == "2005-10-15T20:50:40"

    # Dict
    test_dict = dict(a=1, b=2, c=3)
    assert AnsibleJSONEncoder().default(test_dict) == test_dict

    # Mapping and not Dict
    test_mapping = {'a': 1, 'b': 2, 'c': 3}
    assert AnsibleJSONEncoder().default(test_mapping) == test_mapping

    # Not Mapping
    test_number = 1234
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-11 01:05:41.450439
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    non_default_encoded = AnsibleJSONEncoder().encode(dict(a=dict(b=['c', dict(d=1)])))
    default_encoded = json.dumps(dict(a=dict(b=['c', dict(d=1)])))
    assert non_default_encoded == default_encoded


# Generated at 2022-06-11 01:05:43.284058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = 1
    cls = AnsibleJSONEncoder()
    assert cls.default(data) == data

# Generated at 2022-06-11 01:05:53.886526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    my_unsafe = AnsibleUnsafe(b"my unsafe value")
    assert my_unsafe.__UNSAFE__ == True
    assert my_unsafe.__ENCRYPTED__ == False
    assert AnsibleJSONEncoder().default(my_unsafe) == {'__ansible_unsafe': 'my unsafe value'}

    my_vault = AnsibleUnsafe(b"my vault value")
    setattr(my_vault, '__ENCRYPTED__', True)
    assert my_vault.__UNSAFE__ == True
    assert my_vault.__ENCRYPTED__ == True

# Generated at 2022-06-11 01:06:03.504694
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleUnsafeText, AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedFile

    # ansible_unsafe
    a = AnsibleUnsafe('a')
    assert AnsibleJSONEncoder().default(a) == {'__ansible_unsafe': 'a'}

    a = AnsibleUnsafe('a')
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(a) == {'__ansible_unsafe': 'a'}

    a = AnsibleUnsafeText('a')
    assert AnsibleJSONEncoder().default(a) == {'__ansible_unsafe': 'a'}

    a = AnsibleUnsafeText('a')

# Generated at 2022-06-11 01:06:11.915891
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class Test_AnsibleJSONEncoder(AnsibleJSONEncoder):
        def __init__(self):
            super(Test_AnsibleJSONEncoder, self).__init__()

    ansible_encoder = Test_AnsibleJSONEncoder()

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    class Test_AnsibleUnsafeText(AnsibleUnsafeText):
        def __init__(self):
            super(AnsibleUnsafeText, self).__init__("Test text")

    unsafe_obj = Test_AnsibleUnsafeText()
    value = ansible_encoder.default(unsafe_obj)
    assert  value == {'__ansible_unsafe': u'Test text'}



# Generated at 2022-06-11 01:06:22.566832
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import re
    from ansible.parsing.vault import VaultLib

    ansible_vault_encoded = {'__ansible_vault': VaultLib().encrypt('password')}
    ansible_unsafe_encoded = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256'}

    # test all the other types that are, or are not, handled

# Generated at 2022-06-11 01:06:32.673801
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    safe_str = 'str'
    unsafe_str = b'unsafe_str'
    unsafe_str_ansibleunsafe = 'unsafe_str'

    class AnsibleSafe(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = False

    class AnsibleUnsafe(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class AnsibleVault(str):
        __UNSAFE__ = False
        __ENCRYPTED__ = True

    safe_obj = AnsibleSafe(safe_str)
    unsafe_obj = AnsibleUnsafe(unsafe_str)
    unsafe_obj_ansibleunsafe = {'__ansible_unsafe': unsafe_str_ansibleunsafe}

# Generated at 2022-06-11 01:06:41.888734
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:06:48.109796
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    assert encoder.default(Encrypted('encoded text', b'bWFjIGEga2V5')).decode('ascii') == '"__ansible_vault": "bWFjIGEga2V5"'
    assert encoder.default(UnsafeText('text')).decode('ascii') == '"__ansible_unsafe": "text"'
    assert encoder.default(dict(key='value')).decode('ascii') == '{"key": "value"}'
    assert encoder.default(datetime.date.today()).decode('ascii') == '"' + datetime.date.today().isoformat() + '"'

# Generated at 2022-06-11 01:06:58.295863
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default({'a': 'b'}) == {'a': 'b'}
    assert AnsibleJSONEncoder().default([]) == []
    assert AnsibleJSONEncoder().default(['a', 'b']) == ['a', 'b']
    assert AnsibleJSONEncoder().default('abc') == 'abc'
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(None) == None

# Generated at 2022-06-11 01:07:13.031253
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder."""
    class AnsibleUnsafe:
        __UNSAFE__ = True

        def __init__(self, text):
            self.text = text

        def __str__(self):
            return self.text

    class AnsibleVault:
        __ENCRYPTED__ = True

        def __init__(self, text):
            self._ciphertext = text

        def __str__(self):
            return self._ciphertext

    a_vault = AnsibleVault("abcde")
    a_vault_to_text = AnsibleJSONEncoder(vault_to_text=True).default(a_vault)
    assert a_vault_to_text == "abcde", "Unexpected non-dict output"
    a_v

# Generated at 2022-06-11 01:07:15.208132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(str) == str



# Generated at 2022-06-11 01:07:23.356868
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default([]) == []
    assert encoder.default(['a', 'b']) == ['a', 'b']
    assert encoder.default({}) == {}
    assert encoder.default({'a': 'b'}) == {'a': 'b'}

    class A(object):
        __ENCRYPTED__ = True
        _ciphertext = 'ciphertext'

    a = A()
    assert encoder.default(a) == {'__ansible_vault': 'ciphertext'}

    class B(object):
        __UNSAFE__ = True

    b = B()
    assert encoder.default(b) == {'__ansible_unsafe': 'e30K'}


# Generated at 2022-06-11 01:07:30.673305
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(password='password')
    encoded_json = json.dumps({'vault': vault.encrypt('hello')}, cls=AnsibleJSONEncoder)

    assert '__ansible_vault' in encoded_json

    encoded_json = json.dumps({'vault': vault.encrypt('hello')}, cls=AnsibleJSONEncoder, vault_to_text=True)
    assert not '__ansible_vault' in encoded_json



# Generated at 2022-06-11 01:07:41.102427
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import u
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret(VaultLib())

# Generated at 2022-06-11 01:07:50.866616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = [
        (1, 1),
        ('test', 'test'),
        (dict(a=1, b='test'), dict(a=1, b='test')),
        (False, False),
        (True, True),
        (None, None),
        ([1, 2, 3], [1, 2, 3]),
        (set([1, 2, 3]), [1, 2, 3]),
        (datetime.date(2017, 6, 5), '2017-06-05')
    ]

    for o, expected in data:
        assert AnsibleJSONEncoder().default(o) == expected

    # try to decode an unknown object
    class UnknownObject(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b


# Generated at 2022-06-11 01:07:52.524448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    values = [u'\u2713']
    result = AnsibleJSONEncoder().default(values)
    assert result == values

# Generated at 2022-06-11 01:08:00.778652
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default('Unsafe') == 'Unsafe'

# Generated at 2022-06-11 01:08:09.118678
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()

    assert json_encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # test default encoding datetime and date
    d = datetime.date(2018, 10, 1)
    dt = datetime.datetime(2018, 10, 1, 10, 20, 30)
    assert json_encoder.default(d) == '2018-10-01'
    assert json_encoder.default(dt) == '2018-10-01T10:20:30'

    # test default encoding unsafe object
    class TestUnsafeObj(str):
        __UNSAFE__ = True

    assert json_encoder.default(TestUnsafeObj('')) == {'__ansible_unsafe': ''}

    # test default