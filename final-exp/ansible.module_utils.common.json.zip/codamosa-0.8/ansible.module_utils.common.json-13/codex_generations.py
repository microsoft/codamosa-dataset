

# Generated at 2022-06-11 00:58:15.496206
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 00:58:24.880490
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    date = datetime.datetime(2018, 8, 24, 12, 10, 20, 123456)
    dict_o = {'name': 'test', 'date': date}
    assert encoder.default(dict_o) == dict_o
    assert encoder.default(date) == "2018-08-24T12:10:20.123456"
    assert encoder.default(dict_o, name='test') == dict_o
    assert encoder.default(date, name='test') == "2018-08-24T12:10:20.123456"

# Generated at 2022-06-11 00:58:27.340632
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    assert isinstance(AnsibleJSONEncoder().default(u'foo'), text_type)

# Generated at 2022-06-11 00:58:37.474126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import unittest
    import ansible.parsing.vault as vault

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def test_AnsibleJSONEncoder_default_1(self):
            encoder = AnsibleJSONEncoder()
            o = dict(key = 'value')
            value = encoder.default(o)
            # TODO: change to self.assertXXX
            assert value == o

        def test_AnsibleJSONEncoder_default_2(self):
            encoder = AnsibleJSONEncoder(vault_to_text=True)
            o = vault.VaultLib(password='password')
            value = encoder.default(o)
            # TODO: change to self.assertXXX

# Generated at 2022-06-11 00:58:47.548432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types

    encoder = AnsibleJSONEncoder()
    # no custom encoding if no ansible object/data structure are passed
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default(0) == 0
    assert encoder.default("") == ""
    assert encoder.default("test") == "test"
    assert isinstance(encoder.default("test"), string_types)
    assert encoder.default("unicode test") == "unicode test"
    assert encoder.default({"test": "dict"}) == {"test": "dict"}

# Generated at 2022-06-11 00:58:58.543055
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_var = 'value'
    test_date = datetime.datetime.now()
    test_dict = {'key1': 'value1', 'key2': 2}
    test_list = [1, 2, 3]
    bad_object = object()
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder.default(test_var) == test_var
    assert ansible_encoder.default(test_date) == test_date.isoformat()
    assert ansible_encoder.default(test_dict) == test_dict
    assert ansible_encoder.default(test_list) == test_list
    assert ansible_encoder.default(bad_object) == '{}'

# Generated at 2022-06-11 00:59:06.196145
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an AnsibleJSONEncoder object
    encoder = AnsibleJSONEncoder()

    # Test default encoding for object of type mapping
    object_type_mapping = {'key1': 'value1', 'key2': 'value2'}
    assert encoder.default(object_type_mapping) == object_type_mapping

    # Test default encoding for object of type datetime.date
    object_type_date = datetime.date(2020, 4, 1)
    assert encoder.default(object_type_date) == '2020-04-01'

    # Test default encoding for object of type datetime.datetime
    object_type_datetime = datetime.datetime(2020, 4, 1, 11, 21, 33)

# Generated at 2022-06-11 00:59:17.633703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with bool values
    bool_true_value = True
    bool_false_value = False

    json_encoder = AnsibleJSONEncoder()
    json_encoder_true_value = json_encoder.default(bool_true_value)
    json_encoder_false_value = json_encoder.default(bool_false_value)

    assert(json_encoder_true_value == True)
    assert(json_encoder_false_value == False)

    # Test with string
    str_value = "test_string"

    json_encoder = AnsibleJSONEncoder()
    json_encoder_str_value = json_encoder.default(str_value)

    assert(json_encoder_str_value == "test_string")

    # Test with list

# Generated at 2022-06-11 00:59:23.763042
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.datetime(2018, 11, 3, 17, 34, 6, 808934)) == '2018-11-03T17:34:06.808934'
    assert encoder.default(datetime.date(2018, 11, 3)) == '2018-11-03'
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({"name": "value"}) == {"name": "value"}

# Generated at 2022-06-11 00:59:27.142302
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('foo')) == {'__ansible_unsafe': 'foo'}

# Generated at 2022-06-11 00:59:35.391119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('this is a test') == 'this is a test'
    assert AnsibleJSONEncoder().default('this is a test'.encode('utf-8')) == 'this is a test'
    assert AnsibleJSONEncoder().default(u'this is a test') == 'this is a test'
    assert AnsibleJSONEncoder().default(b'this is a test') == 'this is a test'



# Generated at 2022-06-11 00:59:38.585780
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = datetime.datetime.now()
    assert(json.dumps(d, cls=AnsibleJSONEncoder) == '"{}"'.format(d.isoformat()))


# Generated at 2022-06-11 00:59:44.666186
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    my_dict = {'a': 1}
    my_date = datetime.date.today()

    ans_json_encoder_default = AnsibleJSONEncoder().default(my_dict)
    assert ans_json_encoder_default == my_dict

    ans_json_encoder_default = AnsibleJSONEncoder().default(my_date)
    assert ans_json_encoder_default == my_date.isoformat()

# Generated at 2022-06-11 00:59:45.966163
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder) == '{"foo": "bar"}'

# Generated at 2022-06-11 00:59:57.212867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime

    vault_password = 'vault_password'
    vault = VaultLib(vault_password)
    my_vault = vault.encrypt(b'vault_value')
    assert isinstance(my_vault, type(vault))

    data = {
        'param1': 1,
        'param2': 'string',
        'param3': my_vault
    }

    dump_data = json.dumps(data, cls=AnsibleJSONEncoder)
    load_data = json.loads(dump_data)
    assert load_data['param1'] == data['param1']
    assert load_data['param2'] == data['param2']
    assert isinstance(load_data['param3'], dict)


# Generated at 2022-06-11 01:00:07.468429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultLib
    assert AnsibleJSONEncoder().encode({'vault': VaultLib(None).encode('foo')}) == '{"vault": {"__ansible_vault": "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          33393734663835653038636466346533303936653562333832353638346163643966303962666265\n          65356530393836613836393331653562396330393536303331303934396331622d34643834306130\n          636264336539617d\n          "}}'


# Generated at 2022-06-11 01:00:19.107183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # class that implements __UNSAFE__, __ENCRYPTED__ and __str__
    class TestClass():
        __UNSAFE__ = True
        __ENCRYPTED__ = True
        def __str__(self):
            return 'test_class_string'

    # string type that implements __UNSAFE__ and __ENCRYPTED__
    class TestString(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    # string type that implements __UNSAFE__
    class TestUnsafeString(str):
        __UNSAFE__ = True

    # dict type
    class TestDict(dict):
        pass

    # class for datetime
    class TestDateTime(datetime.datetime):
        pass

    encoder = AnsibleJSONEncoder()

   

# Generated at 2022-06-11 01:00:30.106885
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    class TestClass:
        def __repr__(self):
            return '<TestClass>'

    import platform
    if platform.python_implementation() != 'PyPy':
        # py3.3 - pypy3.3 yield different outputs here, don't test them
        assert json.loads(json.dumps(TestClass())) == '<TestClass>'

    assert json.loads(json.dumps(datetime.date(year=2018,month=3,day=22))) == '2018-03-22'

# Generated at 2022-06-11 01:00:35.311344
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3
    assert 'yes' == json.loads(json.dumps(dict(results=dict(failed=False, msg='yes')), cls=AnsibleJSONEncoder, indent=4))['results']['msg']
    assert 'yes' == json.loads(json.dumps(dict(results=dict(failed=False, msg='yes')), cls=AnsibleJSONEncoder, indent=4))['results']['msg']

# Generated at 2022-06-11 01:00:47.264814
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib

    ### Safe objects
    # String
    assert json.dumps(u'string value', cls=AnsibleJSONEncoder, sort_keys=True) == u'"string value"'
    # Integer
    assert json.dumps(123, cls=AnsibleJSONEncoder, sort_keys=True) == u'123'
    # Both, a string and an integer
    assert json.dumps([u'string value', 123], cls=AnsibleJSONEncoder, sort_keys=True) == u'["string value", 123]'
    # List

# Generated at 2022-06-11 01:00:53.300681
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert '{"foo": "bar"}' == encoder.encode({"foo": "bar"})

# Generated at 2022-06-11 01:01:00.424191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault_jks import JKSVaultLib
    from ansible.parsing.vault_pkcs1 import Pkcs1VaultLib
    from ansible.parsing.vault_pkcs11 import Pkcs11VaultLib

    ansible_unsafe = AnsibleUnsafe('ansible_unsafe')
    ansible_vault = VaultLib(None).encrypt('ansible_vault')
    ansible_vault_jks = JKSVaultLib(None).encrypt('ansible_vault')

# Generated at 2022-06-11 01:01:01.051106
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-11 01:01:06.507638
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansibleJsonEncoder = AnsibleJSONEncoder()
    assert ansibleJsonEncoder.default(datetime.date(2020, 2, 3)) == "2020-02-03"
    assert ansibleJsonEncoder.default(datetime.datetime(2020, 2, 3, 9, 30)) == "2020-02-03T09:30:00"

# Generated at 2022-06-11 01:01:12.377770
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aj = AnsibleJSONEncoder()
    assert aj.default(datetime.datetime(2019, 12, 31, 12, 34, 56)) == "2019-12-31T12:34:56"
    assert aj.default(datetime.date(2019, 12, 31)) == "2019-12-31"
    assert aj.default({'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-11 01:01:22.136326
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # The class AnsibleJSONEncoder is not yet imported in the test module,
    # so we need to import it first
    from ansible.module_utils.common._collections_compat import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.dt_utils import DateTime

    # Test case 1: no match, default action
    a = 'test'
    b = AnsibleJSONEncoder().default(a)
    assert a == b

    # Test case 2: match class AnsibleUnsafe
    a = AnsibleUnsafe("test")
    b = AnsibleJSONEncoder().default(a)
    assert '__ansible_unsafe' in b
    assert a.__str__() == b['__ansible_unsafe']

    # Test case 3: match class AnsibleV

# Generated at 2022-06-11 01:01:33.731592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    if sys.version_info[0] >= 3:
        long = int

# Generated at 2022-06-11 01:01:43.434904
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for a AnsibleUnsafe object
    assert AnsibleJSONEncoder().default(json.dumps({'a': True, 'b': False, 'c': 0, 'd': '123'})) == \
        {'a': True, 'b': False, 'c': 0, 'd': '123'}
    # Test for a AnsibleVaultCiphertext object
    enc = AnsibleJSONEncoder(vault_to_text=True)
    assert enc.default('SOME_ANSIBLE_VAULT_TEXT') == 'SOME_ANSIBLE_VAULT_TEXT'
    # Test for a hostvars object

# Generated at 2022-06-11 01:01:53.984537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create test data
    test_objects = (
        # Vault objects
        {'__ENCRYPTED__': True, '_ciphertext': b'aaatest'},
        # Unsafe objects
        {'__UNSAFE__': True},
        # Mapping objects
        {'test': 'string', 'test2': 1},
        # Date objects
        datetime.datetime.now(),
        datetime.date.today(),
        # Default objects
        'string',
        b'string',
        1,
    )

    for obj in test_objects:
        # Create encoder
        encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
        # Dump data using the encoder
        data = encoder.default(obj)
        # Force the

# Generated at 2022-06-11 01:02:03.660020
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Tests AnsibleJSONEncoder.default method

    The AnsibleJSONEncoder class was not originally intended to be subclassed, see https://docs.python.org/2/library/json.html#json.JSONEncoder
    But, this class must inherit from AnsibleJSONEncoder for the default and iterencode methods to be overwritten.
    '''

    import datetime
    from collections import OrderedDict

    from ansible.utils.unsafe_proxy import AnsibleUnsafeProxy, AnsibleUnsafeText

    from ansible.utils.unsafe_proxy import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultError

    # create a VaultLib object
    vault_passphrase = 'Vault password'
   

# Generated at 2022-06-11 01:02:16.747916
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.common.json_utils
    TEST_CASES = [
        (1, 1),
        ('abc', u'abc'),
        ([1, 2, 3], [1, 2, 3]),
        ({'a': 1, 'b': 2}, {u'a': 1, u'b': 2}),
    ]

    for test_case in TEST_CASES:
        ansible_json = ansible.module_utils.common.json_utils.AnsibleJSONEncoder()
        assert ansible_json.default(test_case[0]) == test_case[1]

# Generated at 2022-06-11 01:02:26.670884
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import __builtin__
    unsafe_test_string = 'unsafe'
    unsafe_test_string.__UNSAFE__ = True
    assert AnsibleJSONEncoder().default(unsafe_test_string) == {'__ansible_unsafe': 'unsafe'}

    # Make sure the regular string behavior isn't messed up
    assert AnsibleJSONEncoder().default(u'regular_string') == u'regular_string'

    # Make sure a 'regular' list is handled correctly
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]

    # Make sure a dict is handled correctly
    assert AnsibleJSONEncoder().default({'foo': u'bar'}) == {'foo': u'bar'}

    # Verify that a datetime.date is handled correctly
    assert Ansible

# Generated at 2022-06-11 01:02:33.612833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class NonSerializable(object):
        pass

    import ansible.module_utils.basic
    testDict = {"test_str": ansible.module_utils.basic.AnsibleUnsafe("TEST")}
    testObject = NonSerializable()
    testList = [testDict, testObject]

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    result = encoder.default(testDict)
    assert isinstance(result, dict)
    assert result['test_str']['__ansible_unsafe'] == to_text(testDict['test_str'], errors='surrogate_or_strict', nonstring='strict')

    result = encoder.default(testList)
    assert isinstance(result, list)
    assert result[0] == result

    result

# Generated at 2022-06-11 01:02:42.829864
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # It should encode instances of ansible.module_utils._text.AnsibleUnsafeText
    assert json.loads(
        AnsibleJSONEncoder(preprocess_unsafe=False).encode(
            '\u2601'.encode('utf-8')
        )
    ) == {'__ansible_unsafe': '☁'}

    # It should encode instances of ansible.parsing.vault.AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 01:02:47.606835
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    seq = ['a', {'b': 'c'}, {'__ansible_unsafe': 'd'}, 1, 2, 3, 'test', {'test2': 'test3'}]
    j_encoder = AnsibleJSONEncoder()
    assert j_encoder.default(seq) == seq

# Generated at 2022-06-11 01:02:51.392272
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    json_string = encoder.encode({'foo': 'bar'})

    assert json.loads(json_string) == {'foo': 'bar'}


# Generated at 2022-06-11 01:02:57.964235
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    This is a unit test for method default of class AnsibleJSONEncoder
    '''
    values = [
        {'status': 'success'},
        datetime.date(2018, 1, 1),
    ]
    values = [json.dumps(x, cls=AnsibleJSONEncoder) for x in values]
    assert values == [
        '{"status": "success"}',
        '"2018-01-01"',
    ]



# Generated at 2022-06-11 01:03:05.721809
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    print(encoder.default(dict(json_object=dict(json_key='json_value'))))
    print(encoder.default(datetime.date(2012, 12, 12)))
    print(encoder.default(datetime.datetime(2012, 12, 12, 12, 12, 12)))
    # test for non-string types
    print(encoder.default(5))
    print(encoder.default(None))

if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-11 01:03:08.624590
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    result = ansible_json_encoder.default(3)
    assert result == 3


# Generated at 2022-06-11 01:03:15.669293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    j = AnsibleJSONEncoder()
    assert(j.default(1) == 1)
    assert(j.default("1") == "1")
    assert(j.default(None) is None)
    assert(j.default(dict(a=1)) == {"a": 1})
    assert(j.default(["a", 1]) == ["a", 1])
    assert(j.default([dict(a="b")]) == [{"a": "b"}])

# Generated at 2022-06-11 01:03:31.511691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert to_text(AnsibleJSONEncoder().default({'a': 'b'})) == '{"a": "b"}'
    assert to_text(AnsibleJSONEncoder().default({'a': 1})) == '{"a": 1}'
    assert to_text(AnsibleJSONEncoder().default({'a': 1.0})) == '{"a": 1.0}'
    assert to_text(AnsibleJSONEncoder().default({'a': 1.0})) == '{"a": 1.0}'
    assert to_text(AnsibleJSONEncoder().default({'a': None})) == '{"a": null}'
    assert to_text(AnsibleJSONEncoder().default(str)) == 'str'

# Generated at 2022-06-11 01:03:37.997707
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.strategies import Always
    from ansible.module_utils.six import text_type

    def is_unicode(o):
        return isinstance(o, text_type)

    assert not is_unicode(AnsibleJSONEncoder().default(Always("plaintext")))
    assert is_unicode(AnsibleJSONEncoder().default(Always("plaintext".encode("utf-8"))))



# Generated at 2022-06-11 01:03:47.677291
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps({'k1': 'v1'}, cls=AnsibleJSONEncoder)) == {'k1': 'v1'}
    assert json.loads(json.dumps([1, 2, 3], cls=AnsibleJSONEncoder)) == [1, 2, 3]
    assert json.loads(json.dumps(1234, cls=AnsibleJSONEncoder)) == 1234
    assert json.loads(json.dumps(1234.5, cls=AnsibleJSONEncoder)) == 1234.5
    assert json.loads(json.dumps(True, cls=AnsibleJSONEncoder)) is True
    assert json.loads(json.dumps(None, cls=AnsibleJSONEncoder)) is None



# Generated at 2022-06-11 01:03:58.192648
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # patch AnsibleJSONEncoder so it does not call super.default
    original_default = AnsibleJSONEncoder.default
    AnsibleJSONEncoder.default = lambda *args, **kwargs: None

    # test AnsibleJSONEncoder.default
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 01:04:08.121583
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    test_vars = {
        'integer': 1,
        'str': "str",
        'unicode_str': u"unicode_str",
        'dict': {'foo': 'bar'},
        'list': ['foo', 'bar'],
        'date': datetime.datetime.now(),
        'datetime': datetime.datetime.now(),
        'time': datetime.time(1, 2, 33),
        'unsafe': AnsibleUnsafe("unsafe"),
        'vault': VaultLib().encrypt("vault")
    }

    # using default encoder

# Generated at 2022-06-11 01:04:12.480661
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({'hi': 'hello'}) == {"hi": "hello"}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(None) is None



# Generated at 2022-06-11 01:04:23.610917
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class Om(object):
        def __init__(self, msg):
            self.msg = msg

    class OmUnsafe(object):
        def __init__(self, msg):
            self.msg = msg

    class OmVault(object):
        def __init__(self, msg):
            self.msg = msg

    data = {
        'datetime': datetime.datetime(2017, 1, 1, 0, 0, 0),
        'date'    : datetime.date(2017, 1, 1),
        'safe'    : Om('safe'),
        'unsafe'  : OmUnsafe('unsafe'),
        'vault'   : OmVault('vault'),
        'encryped': Om('encrypted'),
    }

# Generated at 2022-06-11 01:04:33.409169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default('foo') == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default('foo'.encode('utf-8')) == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(b'foo') == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default({'foo': 'bar'}) == {'foo': 'bar'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default([{'foo': 'bar'}]) == [{'foo': 'bar'}]


# Generated at 2022-06-11 01:04:35.298429
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    result = encoder.default('Hello world')
    assert isinstance(result, str)
    assert result == 'Hello world'


# Generated at 2022-06-11 01:04:46.963191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({'a': 1}) == {'a': 1}
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default(datetime.datetime(2010, 12, 9, 0, 0, 0)) == '2010-12-09T00:00:00'
    assert encoder.default({'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;myuser_mymachine_1537887578.361837'}) == {'__ansible_vault': '$ANSIBLE_VAULT;1.1;AES256;myuser_mymachine_1537887578.361837'}

# Generated at 2022-06-11 01:05:08.535249
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.collections import AnsibleVaultEncryptedBytes
    from ansible.module_utils.common.collections import AnsibleUnsafeBytes
    from ansible.module_utils.common.collections import AnsibleUnsafeText
    from datetime import date, datetime

    ansible_vault_encoded_unicode = AnsibleVaultEncryptedUnicode(u'Test with unicode')
    ansible_vault_encoded_bytes = AnsibleVaultEncryptedBytes(b'Test with bytes')

    ansible_unsafe_bytes = AnsibleUnsafeBytes(b'Test with bytes')
    ansible_unsafe_unicode = AnsibleUnsafeText(u'Test with unicode')

# Generated at 2022-06-11 01:05:18.634130
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode

    # Check Vault's __ENCRYPTED__
    origin = ansible.parsing.vault.VaultLib("test")
    origin._ciphertext = "test"
    encrypted = "{\"__ansible_vault\": \"test\"}"
    assert("__ansible_vault" in AnsibleJSONEncoder().default(origin))
    assert(AnsibleJSONEncoder(vault_to_text=True).default(origin) == to_unicode(origin))
    assert(AnsibleJSONEncoder().default(origin) == json.loads(to_text(encrypted)))

    # Check Mapping

# Generated at 2022-06-11 01:05:29.457977
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # Test VaultLib
    # The class is defined in test/unit/parsing/vault/test_loader.py
    # The file contains a list of test cases
    # In AnsibleJSONEncoder, if an object is instance of VaultLib, it will return a dict
    # whose key is __ansible_vault and value is that of object
    vault = VaultLib([], 'foo')
    vault._ciphertext = 'bar'
    value = {'__ansible_vault': 'bar'}
    assert AnsibleJSONEncoder().default(vault) == value
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault) == 'bar'



# Generated at 2022-06-11 01:05:36.161152
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test method default of class AnsibleJSONEncoder"""
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.plugins.filter.core import from_yaml
    from ansible.module_utils.six import StringIO
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    sample_unsafe_text = u"this is an unsafe value"
    sample_unsafe_bytes = b"this is another unsafe value"
    sample_date = datetime.date(2015, 5, 18)

    sample_list = [sample_date, sample_unsafe_text]
    sample_dict = dict(date=sample_date, unsafe=sample_unsafe_text)

# Generated at 2022-06-11 01:05:48.170049
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    me = AnsibleJSONEncoder()
    # noinspection PyProtectedMember
    assert me.default("test") == "test"
    # noinspection PyProtectedMember
    assert me.default(3) == 3
    # noinspection PyProtectedMember
    assert me.default(["test","This is a test"]) == ["test","This is a test"]
    # noinspection PyProtectedMember
    assert me.default({"test":"test","this is a test":"this is a test"}) == {"test":"test","this is a test":"this is a test"}

    # noinspection PyProtectedMember
    assert me.default(dict(__ansible_unsafe="test")) == {'__ansible_unsafe': 'test'}
    # noinspection PyProtectedMember

# Generated at 2022-06-11 01:05:56.189163
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:06:03.674013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import BytesIO

    vault = VaultLib([], None)
    vault_text = vault.encrypt(b'password')

    assert AnsibleJSONEncoder().default(vault_text) == {'__ansible_vault': to_text(vault_text.vault.encode('utf-8'), errors='surrogate_or_strict', nonstring='strict')}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_text) == to_text(vault_text)

# Generated at 2022-06-11 01:06:12.228516
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    enc = AnsibleJSONEncoder()

    assert enc.default(datetime.datetime.now()) is not None
    assert enc.default(datetime.date.today()) is not None

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    assert enc.default(Mapping()) is not None
    assert enc.default(is_sequence) is not None

    from ansible.module_utils.parsing.convert_bool import boolean

    assert enc.default(boolean(True)) is not None
    assert enc.default(boolean(False)) is not None

    # TODO
    # from ansible.module_utils.six import string_types
    # assert enc.default(string_types(["a

# Generated at 2022-06-11 01:06:18.789660
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.ansible_tower import AnsibleTowerModuleBase

    unsafe_text = 'I am an unsafe text'
    safe_text = 'I am a safe text'
    encoder = AnsibleJSONEncoder()
    assert '"I am a safe text"' == encoder.encode(safe_text)
    assert '"I am an unsafe text"' == encoder.encode(AnsibleTowerModuleBase.string_to_unsafe(unsafe_text))



# Generated at 2022-06-11 01:06:28.402665
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test with date object
    date_object = datetime.datetime(2019, 6, 18, 13, 30)
    result = ansible_json_encoder.default(date_object)
    assert result == "2019-06-18T13:30:00"

    # Test with safe object
    class Safe:
        __ANSIBLE_SAFE__ = True
        def __init__(self, value):
            self.value = value
    safe_object = Safe("test")
    result = ansible_json_encoder.default(safe_object)
    assert result == safe_object

    # Test with unsafe object
    class Unsafe:
        __UNSAFE__ = True
        def __init__(self, value):
            self.value = value
   

# Generated at 2022-06-11 01:07:07.162259
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # Test simple object
    o = encoder.default('abc')
    assert o == 'abc'
    # Test datetime object
    o = encoder.default(datetime.datetime.now())
    assert o == datetime.datetime.now().isoformat()
    # Test dict
    o = encoder.default({'abc': 'def'})
    assert o == {'abc': 'def'}
    # Test ansible unsafeblocks
    from ansible.parsing.vault import VaultLib
    vault_password = 'abc'
    vault = VaultLib(vault_password)
    # Test vault object
    o = encoder.default(vault.encrypt('abcdef'))

# Generated at 2022-06-11 01:07:14.661699
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with datetime.date object
    ansible_json_encoder_test = AnsibleJSONEncoder()
    test_date = datetime.date(2017,10,5)
    assert ansible_json_encoder_test.default(test_date) == "2017-10-05"
    # Test with datetime.datetime object
    test_datetime = datetime.datetime(2017,10,5)
    assert ansible_json_encoder_test.default(test_datetime) == "2017-10-05T00:00:00+00:00"
    # Test with _VaultEncryptedUnicode object
    from ansible.parsing.vault import VaultLib
    vault_test = VaultLib([])
    test_vault_obj = vault_test.encrypt(u'Test')


# Generated at 2022-06-11 01:07:18.341492
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'test')) == {'__ansible_unsafe': b'test'}
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode(b'test2')) == {'__ansible_vault': b'test2'}
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode(b'test3')) == {'__ansible_vault': b'test3'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVaultEncryptedUnicode(b'test3')) == b'test3'
    assert AnsibleJSON

# Generated at 2022-06-11 01:07:26.692685
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.six.moves.urllib.parse import unquote

    # for encrypted text
    from ansible.parsing.vault import VaultLib

    # for unsafe text
    from ansible.module_utils.basic import AnsibleUnsafeText

    # for hostvars and other objects
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleVaultUnsafe

    # for tests on datetime.date and datetime.datetime
    from datetime import date, time, datetime

# Generated at 2022-06-11 01:07:37.517830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    test_datetime = datetime.datetime(2016,1,1)
    test_obj = {
        'a': 'test',
        'b': test_datetime,
        'c': 'this is an unsafe object',
        'd': {'a': 'test', 'b': test_datetime, 'c': 'this is an unsafe object too'}
    }

    # Create an unsafe object
    class UnsafeObject(str):
        __UNSAFE__ = True

    test_obj['c'] = UnsafeObject(test_obj['c'])
    test_obj['d']['c'] = UnsafeObject(test_obj['d']['c'])

    enc = AnsibleJSONEncoder(indent=2, sort_keys=True)

# Generated at 2022-06-11 01:07:45.228953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # First case: value is a dict
    value = {u'a': u'x', u'__ansible_unsafe': 10, u'b': u'y'}
    result = AnsibleJSONEncoder().default(value)
    assert isinstance(result, dict)
    assert result == value

    # Second case: value is a list
    value = [u'a', u'__ansible_unsafe', u'b']
    result = AnsibleJSONEncoder().default(value)
    assert isinstance(result, list)
    assert result == value

    # Third case: value is a AnsibleVaultEncryptedUnicode object
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import AnsibleV

# Generated at 2022-06-11 01:07:54.249094
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    #test_AnsibleJSONEncoder_default_unsafe
    encoder = AnsibleJSONEncoder()
    import os
    test_obj = os
    encoded_test_obj = encoder.default(test_obj)
    assert "TestAnsibleUnsafe" not in encoded_test_obj
    #test_AnsibleJSONEncoder_default_vault
    import ansible.parsing.vault
    test_obj = ansible.parsing.vault.VaultLib('password')
    encoded_test_obj = encoder.default(test_obj)
    assert "TestAnsibleVault" not in encoded_test_obj
    #test_AnsibleJSONEncoder_default_unsafe_to_text
    encoder = AnsibleJSONEncoder(vault_to_text=True)
   

# Generated at 2022-06-11 01:08:01.625145
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class testObj:
        pass

    testObj.ATTRIBUTE1 = 'value1'
    testObj.ATTRIBUTE2 = ['value2a', 'value2b']
    testObj.__ATTRIBUTE3__ = 'value3'  # Private Attribute
    testObj.__ATTRIBUTE4__ = 'value4'  # Private Attribute
    testObj.__ATTRIBUTE4__.__ENCRYPTED__ = True

    testObj.__ATTRIBUTE5__ = 'value5'  # Private Attribute
    testObj.__ATTRIBUTE5__.__UNSAFE__ = True

    # Custom object

# Generated at 2022-06-11 01:08:09.513582
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import text_type

    fake_vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    test_str_unicode = u'test'
    test_str_str = 'test'
    test_bytes_str = b'test'
    test_int = 1
    test_float = 1.1
    test_date = datetime.datetime.now()