

# Generated at 2022-06-11 00:58:15.800494
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecretError, VaultError
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import xrange
    import datetime
    vault_password = text_type('pw')
    t = datetime.date.today()
    obj = object()
    non_ascii_str = text_type('ĀṭḥæŁĩć šŧřĩŋğ', encoding='utf-8')
    non_ascii_non_encodable_str = text_type(u'not encodable, should throw an error É', encoding='utf-8')

    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt(text_type("data"))

# Generated at 2022-06-11 00:58:26.005852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe  # noqa

    unsafe_obj = AnsibleUnsafe("secret")
    # check values
    assert AnsibleJSONEncoder(sort_keys=True, indent=4).encode({"a": unsafe_obj}) == '''{
    "a": {
        "__ansible_unsafe": "secret"
    }
}'''
    assert AnsibleJSONEncoder(sort_keys=True, indent=4, preprocess_unsafe=True).encode({"a": unsafe_obj}) == '''{
    "a": {
        "__ansible_unsafe": "secret"
    }
}'''

# Generated at 2022-06-11 00:58:28.368236
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default("string") == "string"



# Generated at 2022-06-11 00:58:33.130546
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(42) == 42
    assert AnsibleJSONEncoder().default("42") == "42"
    assert AnsibleJSONEncoder().default({'1': 2, '2': 3}) == {'1': 2, '2': 3}


# Generated at 2022-06-11 00:58:36.565356
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of AnsibleJSONEncoder and call its default method
    instance = AnsibleJSONEncoder()
    o = 'ServerType'

    # The result of default method is a string and the original object is a string
    assert(type(instance.default(o)) == type(o))


# Generated at 2022-06-11 00:58:38.457350
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = None
    encoder = AnsibleJSONEncoder()
    result = encoder.default(o)
    assert result is None


# Generated at 2022-06-11 00:58:49.324934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():      # pylint: disable=invalid-name
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type

    def _test_default(i, o, msg):
        encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
        v = encoder.default(i)
        assert v == o, msg

    # test AnsibleVault
    password = 'mysecret'
    vault = VaultLib(password)
    ciphertext = vault.encrypt

# Generated at 2022-06-11 00:59:00.613715
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    ansible_json_encoder = AnsibleJSONEncoder()

    # test for vault object

# Generated at 2022-06-11 00:59:10.474141
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    from ansible.parsing.vault import is_encrypted

    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n6363396363643366306233333237326361346533306639623034383335353261316165373466\n3666343939643336346239623434643339346430343564\n'

# Generated at 2022-06-11 00:59:20.561714
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Tests the default method of AnsibleJSONEncoder'''
    # Expected output from calling json.dumps(obj, cls=AnsibleJSONEncoder)
    # where obj is one of these objects:
    test_input = [{
        'obj': {1: 2, 3: 4},
        'expected': '{"1": 2, "3": 4}',
    }, {
        'obj': {'name': 'John Doe', 'dob': datetime.date(1953, 3, 15)},
        'expected': '{"dob": "1953-03-15", "name": "John Doe"}',
    }]

    # Iterate through our test input, if the expected output matches what
    # json.dumps outputs using our custom encoder class, we're good

# Generated at 2022-06-11 00:59:32.738765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultAES256
    encoder = AnsibleJSONEncoder()
    vault = VaultAES256()
    vault.load(password='password')
    initial_vault = to_text(vault, errors='surrogate_or_strict')
    loaded_vault = json.loads(json.dumps(initial_vault, cls=AnsibleJSONEncoder))
    assert loaded_vault == initial_vault
    initial_unsafe = 'foo'
    loaded_unsafe = json.loads(json.dumps(initial_unsafe, cls=AnsibleJSONEncoder))
    assert loaded_unsafe == initial_unsafe
    return True

# Generated at 2022-06-11 00:59:43.573636
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    json_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 00:59:50.531212
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.ajson import AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('foo')) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('foo')) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).default(AnsibleUnsafe('foo')) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEncoder().default('foo') == '"foo"'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default('foo') == '"foo"'

# Generated at 2022-06-11 01:00:02.348466
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    def test_default(o, expected_value):
        actual_value = ansible_json_encoder.default(o)
        assert actual_value == expected_value, 'actual: {}, expected: {}'.format(actual_value, expected_value)

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Default encoding
    test_default('test', 'test')
    test_default(b'test', 'test')
    test_default(1, 1)
    test_default(1.1, 1.1)
    test_default(True, True)
    test_default(None, None)
    test_default([], [])
    test_default(dict(), dict())


# Generated at 2022-06-11 01:00:11.081058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    actual = json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder)
    assert actual == '{"foo": "bar"}'
    actual = json.dumps({'foo': ['bar']}, cls=AnsibleJSONEncoder)
    assert actual == '{"foo": ["bar"]}'
    actual = json.dumps({'foo': {'bar': 'baz'}}, cls=AnsibleJSONEncoder)
    assert actual == '{"foo": {"bar": "baz"}}'
    actual = json.dumps({'foo': {'bar': ['baz', 'qux']}}, cls=AnsibleJSONEncoder)
    assert actual == '{"foo": {"bar": ["baz", "qux"]}}'
    # The code below is from the unit test for the

# Generated at 2022-06-11 01:00:15.790366
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.facts import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    # Try encoding an AnsibleUnsafe object
    assert encoder.default(AnsibleUnsafe('something unsafe')) == {'__ansible_unsafe': u'something unsafe'}



# Generated at 2022-06-11 01:00:27.415763
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps(dict(a=1, b=2), cls=AnsibleJSONEncoder) == '{"a": 1, "b": 2}'
    assert json.dumps(dict(a=1, b=u'abc'), cls=AnsibleJSONEncoder) == '{"a": 1, "b": "abc"}'

    import ansible.parsing.vault  # noqa
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])

# Generated at 2022-06-11 01:00:36.657768
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafeBytes(bytes):
        def __init__(self, *args):
            super(AnsibleUnsafeBytes, self).__init__(*args)
            self.__UNSAFE__ = True

    class AnsibleVaultBytes(bytes):
        def __init__(self, *args):
            super(AnsibleVaultBytes, self).__init__(*args)
            self.__ENCRYPTED__ = True

    class DummyClass1(object):
        def __init__(self, *args):
            _ = args
            self.answer = 42

    class DummyClass2(dict):
        def __init__(self, *args):
            _ = args
            self.answer = 42


# Generated at 2022-06-11 01:00:49.355106
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # str
    value = "str"
    assert isinstance(value, str) and not isinstance(value, AnsibleUnsafe)
    assert isinstance(json.dumps(value, cls=AnsibleJSONEncoder), str)
    assert isinstance(json.dumps(value, cls=AnsibleJSONEncoder, ensure_ascii=False), bytes)
    assert AnsibleJSONEncoder(ensure_ascii=False).encode(value) == b'str'
    assert AnsibleJSONEncoder().encode(value) == '"str"'

    # bytes
    value = b"bytes"

# Generated at 2022-06-11 01:00:50.842762
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('abc') == 'abc'

# Generated at 2022-06-11 01:00:59.510258
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encrypted = to_text(b'$ANSIBLE_VAULT;1.1;AES256\n38616339316332653736393031626635366164393736333463386535343932323166613237656\n323561623963316366323462613936363533316434643263383734313035663562313661363131\n326639353464376261306539345a\n')
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder.default(encrypted), Mapping)
    assert encoder.default(encrypted).get('__ansible_vault') == encrypted


# Generated at 2022-06-11 01:01:10.459387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # test for json.JSONEncoder.default
    assert encoder.default(None) is None
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(23) == 23
    assert encoder.default(2.3) == 2.3
    assert encoder.default("some_string") == "some_string"
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({1, 2, 3}) == {1, 2, 3}
    assert encoder.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert encoder.default((1, 2, 3)) == (1, 2, 3)

# Generated at 2022-06-11 01:01:20.725833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Ensure AnsibleUnsafe object is converted properly
    unsafe_str = 'testing'
    unsafe_obj = AnsibleUnsafe(unsafe_str)
    result = AnsibleJSONEncoder(preprocess_unsafe=True).default(unsafe_obj)
    assert result == {'__ansible_unsafe': unsafe_str}
    # Ensure AnsibleVault object is converted properly when ``AnsibleJSONEncoder.vault_to_text`` is ``True``
    vault_str = 'testing vault'
    vault_obj = AnsibleVaultEncryptedUnicode(vault_str.encode('utf-8'))
    result = AnsibleJSONEncoder(vault_to_text=True).default(vault_obj)
    assert result == vault_str
    # Ensure AnsibleVault object is converted properly when ``An

# Generated at 2022-06-11 01:01:32.146505
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    # Create a Vault object
    vault = VaultSecret('secret')
    assert _is_vault(vault)
    # Create an Unsafe object
    unsafe = AnsibleUnsafe('secret')
    assert _is_unsafe(unsafe)

    # our JSONEncoder
    encoder = AnsibleJSONEncoder()

    # Use safey encoder
    assert encoder.default(vault) == {'__ansible_vault': u'secret'}
    assert encoder.default(unsafe) == {'__ansible_unsafe': u'secret'}

    # Use unsafe encoder
    encoder = AnsibleJSONEncoder(vault_to_text=True)
   

# Generated at 2022-06-11 01:01:42.113945
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test encrypting object
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib
    from ansible.utils import vault
    from ansible.utils.encrypt import do_encrypt

    passwords = {'first': 'First', 'second': 'Second'}

    # Test Encrypted object
    for password, plaintext in passwords.items():
        editor = VaultEditor(VaultLib([password]))
        ciphertext = editor._process(plaintext)
        encrypted_object = vault.VaultSecret(ciphertext)
        # Test encoding of encrypted object
        json.dumps(encrypted_object, cls=AnsibleJSONEncoder, indent=4)
        # Test when self._vault_to_text is True

# Generated at 2022-06-11 01:01:49.196325
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib

    # VaultLib
    vaulttext = to_text("abc")
    vault = VaultLib(password='password')
    v = vault.encrypt(vaulttext)
    myvault = AnsibleJSONEncoder().default(v)
    assert isinstance(myvault, dict)

# Generated at 2022-06-11 01:01:55.640682
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime

    ansible_json_encoder = AnsibleJSONEncoder()
    my_vault = VaultLib('mypassword')
    my_unsafe = 'myunsafe'
    my_dict = {'key1': 'value1', 'key2': 'value2'}
    my_date = datetime.date.today()


# Generated at 2022-06-11 01:02:02.832779
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Unit test for method default of class AnsibleJSONEncoder
    """
    class TestAnsibleJSONEncoder(AnsibleJSONEncoder):
        def default(self, o):
            """
            Unit test for method default of class AnsibleJSONEncoder
            """
            assert False, "The default method shall not be called for instance of custom AnsibleJSONEncoder"
    json_string = json.dumps({"test": "test"}, cls=TestAnsibleJSONEncoder)
    assert json_string == '{"test": "test"}'



# Generated at 2022-06-11 01:02:15.082186
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ''' Tests the default method of class AnsibleJSONEncoder. This ensures that
    the Ansible internal types are correctly encoded.
    These tests do not cover all of the types as the original method is called
    for many of them. If the underlying method changes, these tests need to be
    updated as well.
    '''
    test_obj = {}
    test_obj['an_int'] = 918242
    test_obj['a_string'] = 'A string without any special characters'
    test_obj['a_unicode'] = u'¿Cómo está?'
    test_obj['a_float'] = 4.45

# Generated at 2022-06-11 01:02:25.508616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_unsafe_obj = 'not_a_secret'
    ansible_unsafe_obj.__UNSAFE__ = True

    ansible_vault_obj = 'my_vault_secret'
    ansible_vault_obj.__ENCRYPTED__ = True

    vault_to_text = True
    data = [ansible_unsafe_obj, ansible_vault_obj]
    data_expected = ['not_a_secret', 'my_vault_secret']
    assert AnsibleJSONEncoder(vault_to_text=vault_to_text).default(data) == data_expected

    vault_to_text = False
    data = {'en': [ansible_unsafe_obj, ansible_vault_obj]}

# Generated at 2022-06-11 01:02:35.156874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants
    constants.ANSIBLE_NOCOLOR = True

    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText
    json_enc = AnsibleJSONEncoder(preprocess_unsafe=False)
    ansible_unsafe = AnsibleUnsafeText('ANSIBLE_VAULT;1.1;AES256')
    assert json_enc.default(ansible_unsafe) == {'__ansible_vault': b'QU5TSUJMRV9WQVVMRDsxLjE7QUVTUjU1Ng=='}

    from ansible.module_utils.common.vault import VaultLib
    vault = VaultLib(password='password123')
    val = vault.encrypt(b'ansible-vault')
    encrypted_val = json

# Generated at 2022-06-11 01:02:43.556360
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(AnsibleJSONEncoder().default({"abc": "abc"}) == {"abc": "abc"})

    class VaultObject(object):
        __UNSAFE__ = True
        __ENCRYPTED__ = True
        _ciphertext = b"DECODED_TEXT"

    class UnsafeObject(object):
        __UNSAFE__ = True
        __ENCRYPTED__ = False
        def __init__(self, arg):
            self.arg = arg

    assert(AnsibleJSONEncoder().default(VaultObject()) == {'__ansible_vault': 'DECODED_TEXT'})
    assert(AnsibleJSONEncoder(vault_to_text=True).default(VaultObject()) == 'DECODED_TEXT')

# Generated at 2022-06-11 01:02:49.708857
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    test_obj_list = [
        AnsibleUnsafe('abc'),
    ]
    for test_obj in test_obj_list:
        jencoder = AnsibleJSONEncoder()
        ret = jencoder.default(test_obj)
        assert ret == {'__ansible_unsafe': 'abc'}


# Generated at 2022-06-11 01:03:00.985943
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class mydatetime(datetime.datetime):
        pass

    # python 2.6 does not have assertIsInstance, replace it with assertTrue
    # http://bugs.python.org/msg170215
    try:
        assertIsInstance = unittest.TestCase.assertIsInstance
    except AttributeError:
        assertIsInstance = unittest.TestCase.assertTrue

    # assertIsInstance cannot handle tuple parameter, convert it to list
    try:
        assertIsInstance({}, Mapping)
    except TypeError:
        Mapping = list(Mapping)

    encode_obj = AnsibleJSONEncoder()
    assertEqual(encode_obj.default("default"), u"default")
    assertIsInstance(encode_obj.default("default"), unicode)


# Generated at 2022-06-11 01:03:05.721202
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_str = AnsibleJSONEncoder().encode({"foo": "bar"})
    assert json_str == '{"foo": "bar"}'

    json_str = AnsibleJSONEncoder(sort_keys=True).encode({"foo": "bar"})
    assert json_str == '{"foo": "bar"}'


# Generated at 2022-06-11 01:03:17.564115
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Helper function to the test. Contains all the asserts of the tests.
    def f(o):
        # Base class
        assert isinstance(o, AnsibleJSONEncoder)

        assert json.dumps(dict(a=o)) == '{"a": "test_AnsibleJSONEncoder_default"}'
        assert json.dumps(list([o])) == '["test_AnsibleJSONEncoder_default"]'

    # Object to test
    obj = AnsibleJSONEncoder()

    # Test strings
    f(obj)
    f("test_AnsibleJSONEncoder_default")

    # Test unicode
    f(u("test_AnsibleJSONEncoder_default"))
    f(u("α"))

    # Test lists
    f(["test_AnsibleJSONEncoder_default"])


# Generated at 2022-06-11 01:03:25.861597
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Empty Dictionary
    example = {}
    assert AnsibleJSONEncoder().default(example) == {}

    # Vault object
    example = "test"
    assert isinstance(AnsibleJSONEncoder().default(example), basestring)

    # Date object
    example = datetime.datetime(year=2019, month=2, day=1, hour=1, minute=1, second=1)
    assert AnsibleJSONEncoder().default(example) == '2019-02-01T01:01:01'


# Generated at 2022-06-11 01:03:26.390343
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: implement
    pass


# Generated at 2022-06-11 01:03:36.649200
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from collections import OrderedDict
    from datetime import datetime

    # Test object which will be encoded as a mapping
    test_object = {
        'simple_value': True,
        'list_value': ['a', 1, 'b'],
        'dict_value': {'a': 0, 'b': 1}
    }
    expected = {
        'simple_value': True,
        'list_value': ['a', 1, 'b'],
        'dict_value': {'a': 0, 'b': 1}
    }

    # test ordered dict

# Generated at 2022-06-11 01:03:44.139691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert AnsibleJSONEncoder().default({'name': 'test'}) == {'name': 'test'}
    assert AnsibleJSONEncoder().default(datetime.date.today()) == datetime.date.today().isoformat()
    assert AnsibleJSONEncoder().default(datetime.datetime.today()) == datetime.datetime.today().isoformat()



# Generated at 2022-06-11 01:04:03.343250
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Test our sampling function'''


# Generated at 2022-06-11 01:04:14.584587
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(None) is None
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(True) is True
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(False) is False
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(0) == 0
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(0.0) == 0.0
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(0j) == 0j
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default('foo') == 'foo'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(datetime.datetime(2000, 1, 1))

# Generated at 2022-06-11 01:04:25.525432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock
    plaintext = u'plaintext'
    ciphertext = u'ciphertext'
    mock_vault = MagicMock()
    mock_vault.__ENCRYPTED__ = True
    mock_vault._ciphertext = ciphertext
    # Test case-default
    assert json.dumps(mock_vault, cls=AnsibleJSONEncoder) == u'{"__ansible_vault": "ciphertext"}'

    # Test case-1: with vault_to_text=True
    assert json.dumps(mock_vault, cls=AnsibleJSONEncoder, vault_to_text=True) == u'"ciphertext"'

    unsafe = u'plaintext'

# Generated at 2022-06-11 01:04:32.713442
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import six
    assert AnsibleJSONEncoder().default(six.u('unicode')) == 'unicode'
    assert AnsibleJSONEncoder().default(six.b('str')) == 'str'
    assert AnsibleJSONEncoder().default(six.u('💩')) == '💩'
    assert isinstance(AnsibleJSONEncoder().default(six.u('💩')), six.text_type)
    assert isinstance(AnsibleJSONEncoder().default(six.b('💩')), six.text_type)

# Generated at 2022-06-11 01:04:43.820134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule

    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=False, check_invalid_arguments=False)

    # json.JSONEncoder.default returns a string
    assert isinstance(ansible_json_encoder.default("test"), str)

    # json.JSONEncoder.default returns a integer
    assert isinstance(ansible_json_encoder.default(1), int)

    # json.JSONEncoder.default return a dict
    # if module class AnsibleModule is passed as an argument
    assert isinstance(ansible_json_encoder.default(ansible_module), dict)

    # json.JSONEncoder.default return a dict
    # if dict is

# Generated at 2022-06-11 01:04:48.280948
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value_expect = {'__ansible_unsafe': 'bar'}
    json_encoder = AnsibleJSONEncoder()
    value = json_encoder.default(u"bar")
    assert value == "bar"

    value = json_encoder.default(u'foo')
    assert value == 'foo'


# Generated at 2022-06-11 01:04:51.275333
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass:
        def __init__(self):
            self.name = 'duh'

    assert AnsibleJSONEncoder().default(TestClass()) == {'name': 'duh'}



# Generated at 2022-06-11 01:05:01.825872
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.markupsafe_encoders import text_type_safe

    encoder = AnsibleJSONEncoder()
    encrypted = encoder.default(text_type_safe('$ANSIBLE_VAULT;1.1;AES256;foo;bar\n393162386565666263303637656431'))
    non_encrypted = encoder.default(text_type_safe('$ANSIBLE_VAULT;1.1;AES256;foo;bar\n393162386565666263303637656431', encrypted=False))
    unsafe = encoder.default(text_type_safe('$ANSIBLE_VAULT;1.1;AES256;foo;bar\n393162386565666263303637656431', unsafe=True))
    vault_

# Generated at 2022-06-11 01:05:11.425549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    encoder = AnsibleJSONEncoder()

    # test for encrypted object
    result = encoder.default(VaultLib("password"))
    assert result == {'__ansible_vault': None}

    # test for unsafe object
    result = encoder.default(AnsibleUnsafeText("unsafe"))
    assert result == {'__ansible_unsafe': "unsafe"}

    # test for hostvars and other objects
    result = encoder.default({1: 2})
    assert result == {1 : 2}

    # test for date object
    result = encoder.default(datetime.date(2020, 12, 12))

# Generated at 2022-06-11 01:05:20.256366
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # This is how the method default of class AnsibleJSONEncoder is called
    obj = AnsibleJSONEncoder(preprocess_unsafe=True, ensure_ascii=True, indent=2)
    result = obj.default("This is the value to be returned")
    assert result == "This is the value to be returned"

    # This is how the method default of class AnsibleJSONEncoder is called
    obj = AnsibleJSONEncoder(preprocess_unsafe=True, ensure_ascii=True, indent=2)

# Generated at 2022-06-11 01:05:46.689710
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # basic checks
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default({'1': 2}) == {'1': 2}

    # datetime checks
    assert AnsibleJSONEncoder().default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 1, 1, 1, 1, 1)) == '2018-01-01T01:01:01'

    # vault checks

# Generated at 2022-06-11 01:05:52.765003
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.parsing.convert_bool import boolean

    e = AnsibleJSONEncoder()

    assert e.default(boolean(True)) == True
    assert e.default(boolean(False)) == False

    try:
        foo = boolean('foo')
    except Exception:
        pass
    else:
        raise AssertionError('Expecting foo to raise an exception.')

    assert e.default('bar') == 'bar'

# Generated at 2022-06-11 01:06:02.556324
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    def _assert_expected_output(case, obj, expected):
        message = 'method default of class AnsibleJSONEncoder does not handle {0} as expected'.format(case)
        output = AnsibleJSONEncoder().default(obj)
        assert output == expected, message

    # Vault object

# Generated at 2022-06-11 01:06:10.694548
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # param o of type AnsibleVaultEncryptedUnicode
    assert AnsibleJSONEncoder().default(VaultLib().encrypt("test")) == {'__ansible_vault': VaultLib().encrypt("test")._ciphertext}
    # param o of type str
    assert AnsibleJSONEncoder().default("test") == "test"
    assert AnsibleJSONEncoder().default({1: "test"}) == {1:"test"}
    assert AnsibleJSONEncoder().default({"test": 1}) == {"test": 1}
    assert AnsibleJSONEncoder().default(["test", 1]) == ["test", 1]


# Generated at 2022-06-11 01:06:12.275044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test') == 'test'

# Generated at 2022-06-11 01:06:22.965721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Primitive data types
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default('abc') == 'abc'
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(False) == False

    # Custom data types
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes

    assert AnsibleJSONEncoder().default(VaultLib()) == {'__ansible_vault': ''}

# Generated at 2022-06-11 01:06:32.952874
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    # Check if our encoder correctly handle default types
    assert encoder.default('a') == 'a'
    assert encoder.default('ab') == 'ab'
    assert encoder.default(u'a') == 'a'
    assert encoder.default(u'ab') == 'ab'

    # Check if our encoder correctly handle mapping types
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Check if our encoder correctly handle sequence types
    assert encoder.default([1, 2]) == [1, 2]

    # Check if our encoder correctly handle date types
    today = datetime.datetime.now()

# Generated at 2022-06-11 01:06:42.118764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.cache.jsonfile import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()

    # Test for vault object
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n39396337633930623136613261366236303237613232303335376630653534653939300a6139623335323161326266623938613232373635393833316634363033623834\n'
    vault = VaultLib(b'password')
    vault_obj = vault.decrypt(ciphertext)
    assert isinstance(vault_obj, AnsibleUnsafe)

# Generated at 2022-06-11 01:06:43.174132
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("abc") == "abc"


# Generated at 2022-06-11 01:06:52.795612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor

    ansible_vault_obj = VaultEditor(password='password')
    ansible_vault_ciphertext = ansible_vault_obj.encrypt('secret')

    ansible_unsafe_ciphertext = {'__ansible_unsafe': 'password'}
    ansible_vault_dict = {'__ansible_vault': ansible_vault_ciphertext}
    ansible_unsafe_dict = {'__ansible_unsafe': 'secret'}

    ansible_dict = {'ansible_vault': ansible_vault_obj, 'ansible_unsafe': ansible_unsafe_ciphertext}

    assert AnsibleJSONEncoder().default(ansible_vault_obj) == ansible_vault_

# Generated at 2022-06-11 01:07:26.746860
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import pytest
    test_passed = True
    d = {}
    d[u'foo_key'] = u'foo_val'
    d[u'foo_key2'] = u'foo_val2'
    try:
        json.dumps(d, cls=AnsibleJSONEncoder)
    except TypeError as e:
        test_passed = False

    assert test_passed is True

# Generated at 2022-06-11 01:07:37.558182
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    output_map = {
        "a": "b",
        "c": "d"
    }
    # hostvars and other objects
    assert(AnsibleJSONEncoder().default(output_map) == output_map)

    # dict with __ENCRYPTED__
    output_vault = {"ciphertext": "hoge", "SALT": "hoge", "H": "hoge", "hmac": "hoge", "randomsalt": "hoge"}
    output_vault.__ENCRYPTED__ = True
    assert(AnsibleJSONEncoder().default(output_vault) == {"__ansible_vault": "hoge"})

    # dict with __ENCRYPTED__ and vault_to_text

# Generated at 2022-06-11 01:07:45.252912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeVaultLib
    # test decorated classes
    test_safe_vault = VaultLib("my vault password")("$ANSIBLE_VAULT;1.1;AES256;myhostname\n323232323232323232323232323232323232323232323232323232323232323232323233232\n")

# Generated at 2022-06-11 01:07:53.353641
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('bar') == 'bar'
    assert AnsibleJSONEncoder().default(b'bar') == b'bar'

    # Test with non-ascii value
    non_ascii = u'\u274c'
    assert AnsibleJSONEncoder().default(non_ascii) == non_ascii
    assert AnsibleJSONEncoder().default(non_ascii.encode()) == non_ascii.encode()

    # Test with empty string
    assert AnsibleJSONEncoder().default('') == ''

    # Test with empty byte string
    assert AnsibleJSONEncoder().default(b'') == b''

# Generated at 2022-06-11 01:08:01.203588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import decrypt_text
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    # Tests for ciphertext
    failed = False
    try:
        json.dumps(True, cls=AnsibleJSONEncoder)
    except TypeError:
        failed = True
    assert not failed, 'json.dumps(True, cls=AnsibleJSONEncoder) should not raise TypeError'

    failed = False
    try:
        json.dumps([True, False], cls=AnsibleJSONEncoder)
    except TypeError:
        failed = True