

# Generated at 2022-06-11 00:58:17.411618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test different parameter types
    o = 'Hello World'
    test_encoder = AnsibleJSONEncoder()
    assert test_encoder.default(o) == o

    o = ['Hello', 'World']
    assert test_encoder.default(o) == o

    o = u'Hello World'
    assert test_encoder.default(o) == o

    # Test AnsibleUnsafe with and without vault object
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib
    vault = VaultLib()
    password = 'secrets!'

    o = vault.encrypt(u'Hello World', password)
    o.__UNSAFE__ = True
    o.__ENCRYPTED__ = True
    # Test the default vault representation

# Generated at 2022-06-11 00:58:29.693200
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    import ansible.vars.unsafe_proxy

    json_encoder = AnsibleJSONEncoder()

    assert json_encoder.default(datetime.datetime(2016, 12, 7, 14, 14, 40, 735000)) == "2016-12-07T14:14:40.735000"
    assert json_encoder.default(ansible.parsing.vault. VaultEditor("", "", "")) == {'__ansible_vault': ''}
    assert json_encoder.default(ansible.vars.unsafe_proxy.AnsibleVaultEncryptedUnsafeText("Vault")) == {"__ansible_vault": "Vault"}

# Generated at 2022-06-11 00:58:39.429332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = {'a': u'foo'}
    result = json.dumps(value, cls=AnsibleJSONEncoder).replace('"', '\'')
    assert result == '{"a": "foo"}', 'JSONEncoder does not work correctly.'
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.vault import VaultLib
    vault_password = 'return "foo"'
    vault = VaultLib(password_files=[vault_password])
    value = vault.encrypt('hello', DEFAULT_VAULT_ID_MATCH)
    result = json.dumps(value, cls=AnsibleJSONEncoder).replace('"', '\'')

# Generated at 2022-06-11 00:58:50.296371
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance of AnsibleJSONEncoder
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # Test if aje._preprocess_unsafe is set correctly
    assert isinstance(aje._preprocess_unsafe, bool)
    assert aje._preprocess_unsafe == False

    # Test if aje._vault_to_text is set correctly
    assert isinstance(aje._vault_to_text, bool)
    assert aje._vault_to_text == False

    # Test regular string
    assert aje.default('abc') == u'abc'

    # Test if default json.JSONEncoder is used when failed to find a custom encoder
    class Test:
        pass

    assert aje.default(Test()) == Test()

    #

# Generated at 2022-06-11 00:59:01.491565
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    class MyVault(VaultLib):
        def __init__(self, key, **kwargs):
            super(MyVault, self).__init__(key, **kwargs)

    o = MyVault('secret', b'value')
    o._ciphertext = 'encrypted'
    assert AnsibleJSONEncoder(vault_to_text=False).default(o) == {'__ansible_vault': 'encrypted'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(o) == 'value'

    o = {'a': 'b'}
    assert AnsibleJSONEncoder().default(o) == o

    o = datetime.date(2017, 7, 2)
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-11 00:59:05.721537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict()) == dict()
    assert AnsibleJSONEncoder().default(datetime.datetime(2020, 1, 1, 10, 20, 30)) == '2020-01-01T10:20:30'
    assert AnsibleJSONEncoder().default(datetime.date(2020, 1, 1)) == '2020-01-01'

# Generated at 2022-06-11 00:59:07.686896
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('foo') == 'foo'



# Generated at 2022-06-11 00:59:18.600531
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants as C

    failed = False
    failed_objs = []

    def _test_obj_json_encoding(obj, expected_result):
        if not isinstance(expected_result, list):
            expected_result = [expected_result]

        if not any(json_obj == json.dumps(obj, cls=AnsibleJSONEncoder) for json_obj in expected_result):
            failed_objs.append(obj)
            failed = True

    # test ``is_sequence``
    _test_obj_json_encoding(is_sequence, "true")

    # test ``C.DEFAULT_VAULT_ID_MATCH``
    _test_obj_json_encoding(C.DEFAULT_VAULT_ID_MATCH, '"^(.*)$"')

    #

# Generated at 2022-06-11 00:59:25.146175
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    import ansible.utils.unsafe_proxy
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    # Create a test object to test default method of class AnsibleJSONEncoder
    class TestAnsibleJSON():
        def __init__(self, data):
            self.data = data

    # Testcase 1 - object with __ENCRYPTED__ attribute
    o = TestAnsibleJSON(data=ansible.utils.unsafe_proxy.AnsibleUnsafeText('foo'))
    o.__ENCRYPTED__ = True
    result = encoder.default(o)

# Generated at 2022-06-11 00:59:36.530689
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(getattr('', '__UNSAFE__', False)) == 'False'
    assert AnsibleJSONEncoder().default(getattr('', '__ENCRYPTED__', False)) == 'False'
    assert AnsibleJSONEncoder().default(getattr('', '__UNSAFE__', False) + getattr('', '__ENCRYPTED__', False)) == 'False'
    assert AnsibleJSONEncoder().default(getattr('', '__UNSAFE__', False) - getattr('', '__ENCRYPTED__', False)) == 'False'
    assert AnsibleJSONEncoder().default(getattr('', '__UNSAFE__', False) * getattr('', '__ENCRYPTED__', False)) == 'False'
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-11 00:59:39.993377
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-11 00:59:48.929242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    class Foo(object):
        pass

    data = [
        (42, 42),
        (Foo(), {'__module__': '__main__', '__name__': 'Foo'}),
        (datetime.datetime(2019, 11, 16, 12, 0, 0, 141580), '2019-11-16T12:00:00.141580'),
        (AnsibleUnsafe('password'), {'__ansible_unsafe': 'password'}),
    ]

    if VaultLib._supports_encryption:
        vault_password = 'test'
        vault = VaultLib().encrypt('test', vault_password)

# Generated at 2022-06-11 01:00:01.197561
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    import ansible.module_utils.six

    # An instance of class AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()

    # An instance of class AnsibleUnsafeText
    test_value = ansible.module_utils.basic.AnsibleUnsafeText('test')
    assert encoder.default(test_value) == {'__ansible_unsafe': 'test'}

    # An instance of class AnsibleVaultEncryptedUnicode
    if ansible.module_utils.six.PY3:
        test_value = ansible.module_utils.basic.AnsibleVaultEncryptedUnicode(
            u'\u00dcbersicht')

# Generated at 2022-06-11 01:00:10.328121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.module_utils.six import text_type

    def default(self, o):
        return dict(vault_obj=o)

    class _JSONEncoder(ansible.module_utils.json_utils.AnsibleJSONEncoder):
        def default(self, obj):
            return default(self, obj)

    v = ansible.parsing.vault.VaultLib([])

# Generated at 2022-06-11 01:00:15.911529
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    enc_key = vault.encrypt('mykey')
    encrypted = vault.encrypt(b'hello')

    data = {
        'list': [1, 2, 3],
        'tuple': (1, 2, 3),
        'dict': {'a': 1, 'b': 2},
        'int': 1,
        'float': 3.14,
        'bool': True,
        'datetime': datetime.datetime.now(),
        'date': datetime.date.today(),
        'unsafe': '$password',
        'unsafe_obj': vault.VaultUnsafeText('$password'),
        'vault_obj': vault.VaultSecret(enc_key, encrypted),
    }
   

# Generated at 2022-06-11 01:00:27.618394
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    # Test vault object by creating a vault object
    test_1 = ansible.parsing.vault.VaultLib('test')
    output_test_1 = '{"__ansible_vault": "ZXhhbXBsZQ=="}'
    if AnsibleJSONEncoder().default(test_1) == json.loads(output_test_1):
        pass
    else:
        raise AssertionError('Unexpected value')

    # Test unsafe object
    from ansible.parsing.vault import VaultSecret
    test_2 = VaultSecret('secret')
    output_test_2 = '{"__ansible_unsafe": "secret"}'
    if AnsibleJSONEncoder().default(test_2) == json.loads(output_test_2):
        pass

# Generated at 2022-06-11 01:00:30.503804
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default('__test__') == '__test__'



# Generated at 2022-06-11 01:00:38.093167
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type

    # Check encryptd objects
    from ansible.parsing.vault import VaultEditor
    ve = VaultEditor(None)
    data_b = binary_type(ve.encrypt('"Hello"').decode("utf-8"))
    data = ve.decrypt(data_b)
    assert AnsibleJSONEncoder(vault_to_text=False).default(data) == {'__ansible_vault': data_b}
    assert AnsibleJSONEncoder(vault_to_text=True).default(data) == '"Hello"'

    # Check unsafe objects
    assert AnsibleJSONEncoder().default(ve.vault.encode('string')) == 'string'

# Generated at 2022-06-11 01:00:50.660450
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3, string_types


# Generated at 2022-06-11 01:00:52.767612
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().encode({'k': {}}) == '{"k": {}}'


# Generated at 2022-06-11 01:01:04.756598
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule, AnsibleUnsafeText
    ansiblejsonencoder = AnsibleJSONEncoder()
    hasher = basic.AnsibleModule(argument_spec=dict(data=dict(type='str', no_log=True)))
    hasher.params = {'data': AnsibleUnsafeText(b'testing data')}
    o = hasher.params['data']
    result = ansiblejsonencoder.default(o)

# Generated at 2022-06-11 01:01:15.601526
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:01:24.187808
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.text.formatters._json import dumps

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.formatters import join_url

    # Test isinstance(o, datetime.date)
    # datetime.date(year, month, day)
    o = datetime.date(2018,8,17)
    d = dumps(dict(o=o), cls=AnsibleJSONEncoder)
    assert '"o": "2018-08-17"' in d

    # Test isinstance(o, datetime.datetime)
    # datetime.datetime(year, month, day[, hour[, minute[, second[, microsecond[, tzinfo]]]]])

# Generated at 2022-06-11 01:01:35.797252
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_date = datetime.datetime(year=2020, month=1, day=1, hour=1, minute=1, second=1, microsecond=1)

    # Test Class Foo
    class Foo:
        def __init__(self, bar):
            self.bar = bar

    obj = Foo('testtext')
    testjson = AnsibleJSONEncoder().encode(obj)
    assert json.loads(testjson)['bar'] == obj.bar

    # Test Class FooVault
    class FooVault(Foo):
        __ENCRYPTED__ = True

    testobj = FooVault('testtext')
    testvaultjson = AnsibleJSONEncoder().encode(testobj)

# Generated at 2022-06-11 01:01:43.903830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default('a') == "a"
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(1) == 1
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(bool()) == False
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(u'a') == u'a'
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(u'a'.encode('utf-8')) == u'a'
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(u'a'.encode('latin1')) == u'a'

# Generated at 2022-06-11 01:01:50.150313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Imports needed by the unit test
    from ansible.parsing.vault import VaultLib
    from ansible.template import CryptoUnsafe, AnsibleUnsafe
    from ansible.module_utils.six import text_type, binary_type
    from ansible.module_utils.parsing.convert_bool import boolean

    # test unsafe_text to json
    unsafe_text = AnsibleUnsafe("this is a\ntest")
    assert to_text(AnsibleJSONEncoder(sort_keys=True).default(unsafe_text), errors='surrogate_or_strict') == '{"__ansible_unsafe": "this is a\\ntest"}'

# Generated at 2022-06-11 01:01:55.895806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import binascii

    vault = VaultLib([])
    # vault.bytes_to_b64gzip is a method of a class
    da = vault.bytes_to_b64gzip(b'test_data')
    # ensure the data is in base64 format
    try:
        da.decode('base64')
    except binascii.Error:
        assert False, 'data is not in base64 format'

    e = AnsibleJSONEncoder()
    value = e.default(da)
    assert value == {'__ansible_vault': u'test_data'}

# Generated at 2022-06-11 01:02:00.384180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(u'hi') == 'hi'

    d = datetime.datetime(2016, 9, 1, 12, 30)
    assert AnsibleJSONEncoder().default(d) == '2016-09-01T12:30:00'

# Generated at 2022-06-11 01:02:12.282826
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:02:23.511728
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import AnsibleMapping
    # Create the object for testing the method
    # TODO: need fill the variable in __init__ of the class
    obj = AnsibleJSONEncoder()

    # Test case 1
    o1 = "Hello"
    except1 = "Hello"

    # Test case 2
    o2 = {u'key': u'value'}
    except2 = {u'key': u'value'}

    # Test case 3
    o3 = {'key': 'value'}
    except3 = o3

    # Test case 4
    o4 = [{u'key': u'value'}, {u'key': u'value'}]

# Generated at 2022-06-11 01:02:34.486120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native

    from ansible.parsing.vault import VaultEditor
    # arbitrary data for unit tests

# Generated at 2022-06-11 01:02:39.562282
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """ Simple unit test for method default of class AnsibleJSONEncoder """
    o = {'__ansible_unsafe': 'This is an ansible unsafe string.'}
    assert json.dumps(o, cls=AnsibleJSONEncoder, sort_keys=True) == '{"__ansible_unsafe": "This is an ansible unsafe string."}'


# Generated at 2022-06-11 01:02:51.640887
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    encrypt_data = VaultLib().encrypt('test')
    ansible_json_encoder = AnsibleJSONEncoder()
    ansible_json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)

# Generated at 2022-06-11 01:03:02.594474
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 01:03:10.882830
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''This function tests the method default of class AnsibleJSONEncoder'''
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    # set method default of AnsibleJSONEncoder
    ansible_encoder = AnsibleJSONEncoder()
    # test_encrypting_vault_to_text
    if ansible_encoder.default({'__ansible_unsafe': 'AnsibleUnsafe'}) != {'__ansible_unsafe': 'AnsibleUnsafe'}:
        return False
    # test_unsafe_to_text
    if ansible_encoder.default(AnsibleUnsafe("AnsibleUnsafe")) != {'__ansible_unsafe': 'AnsibleUnsafe'}:
        return False
    # test_datetime_object

# Generated at 2022-06-11 01:03:23.347491
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Abort test if json.JSONEncoder has changed its interface
    if not hasattr(json.JSONEncoder, 'default'):
        raise RuntimeError('Unsupported interface for json.JSONEncoder, please fix test_AnsibleJSONEncoder_default')

    from ansible.parsing.vault import VaultLib  # pylint: disable=import-error,no-name-in-module
    from ansible.parsing.vault import VaultSecret  # pylint: disable=import-error,no-name-in-module

    # test default behavior
    o = object()
    o.foo = 'bar'
    assert AnsibleJSONEncoder().default(o) == {'foo': 'bar'}
    assert AnsibleJSONEncoder().iterencode(o) == '{"foo": "bar"}'

    #

# Generated at 2022-06-11 01:03:24.891459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None


# Generated at 2022-06-11 01:03:32.319205
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """ Unit test for method default of class AnsibleJSONEncoder
    """

    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # test vault object
    vault = VaultLib(["password"], "")

# Generated at 2022-06-11 01:03:43.653562
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.json_dict import AnsibleJSONEncoder, AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.module_utils.common.text.encrypt import encrypt


# Generated at 2022-06-11 01:03:44.305984
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder()



# Generated at 2022-06-11 01:04:04.873915
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_json_encoder = AnsibleJSONEncoder()
    # test str objects
    ansible_unsafe_key = "This is a str object"
    ansible_vault_key = "This is a str object"
    # test dict object
    ansible_unsafe_value = {"This is a dict object": "This is a dict object"}
    ansible_vault_value = {"This is a dict object": "This is a dict object"}
    # test tuple object
    ansible_unsafe_tuple = ("This is a tuple", "This is a tuple")
    ansible_vault_tuple = ("This is a tuple", "This is a tuple")

    # test date object
    date_value = datetime.date(2019, 2, 12)
    # test datetime object
    datetime_value = datetime

# Generated at 2022-06-11 01:04:16.644796
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Base Case
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    assert AnsibleJSONEncoder(
        module=module,
        preprocess_unsafe=False,
        vault_to_text=False,
    ).default("TestString") == "TestString"

    # Test that date objects return date in the correct format
    import datetime
    date = datetime.date(2018, 1, 1)
    assert AnsibleJSONEncoder(
        module=module,
        preprocess_unsafe=False,
        vault_to_text=False,
    ).default(date) == "2018-01-01"

    # Test that maps return dict

# Generated at 2022-06-11 01:04:21.042022
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(AnsibleUnsafe("test")) == {'__ansible_unsafe': "test"}
    assert AnsibleJSONEncoder().default(AnsibleUnsafe("test", True)) == {'__ansible_unsafe': "test"}

# Generated at 2022-06-11 01:04:31.305564
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    def p(obj):
        return json.dumps(obj, cls=AnsibleJSONEncoder)

    vl = VaultLib([])
    encrypted_text = vl.encrypt('password')


# Generated at 2022-06-11 01:04:41.444080
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor


    vault_password_file = "vault.passwd"
    vault_editor = VaultEditor(vault_password_file)
    vault_text = "This is the text to be encrypted in the vault file"
    encrypted_text = vault_editor.encrypt_text(vault_text)
    vault_obj = VaultLib([vault_password_file])
    decrypted_text = vault_obj.decrypt(encrypted_text)
    # vault_obj = VaultLib([VaultSecret("abc")])
    # decrypted_text = vault_obj.decrypt("Encryption key is abc")
    # vault_text = "This is the text to be encrypted

# Generated at 2022-06-11 01:04:44.210050
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()

    assert e.default(datetime.datetime(2018,1,1)) == '2018-01-01T00:00:00'
    assert e.default(datetime.date(2018,1,1)) == '2018-01-01'

    assert e.default('foo') == 'foo'
    assert e.default({'foo':'bar'}) == {'foo':'bar'}

# Generated at 2022-06-11 01:04:49.516971
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret

    assert json.loads(json.dumps(VaultSecret('SECRET'), cls=AnsibleJSONEncoder)) == {'__ansible_vault': 'SECRET'}
    assert json.loads(json.dumps(VaultSecret('SECRET'), cls=AnsibleJSONEncoder, vault_to_text=True)) == '$ANSIBLE_VAULT;SECRET'

# Generated at 2022-06-11 01:05:00.278002
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test data:
    #   Date:          now
    #   Hostvars:      dict
    #   Mapping:       dict
    #   Object:        dict
    #   String:        string
    #   String(Unsafe):string
    #   String(Vault): string
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import ANSIBLE_VAULT_STRING
    from ansible import module_utils

    def _create_unsafe(data):
        u = module_utils.unsafe_proxy.AnsibleUnsafeText(data)
        return module_utils.basic._AnsibleUnsafeBytes(data, errors='surrogate_or_strict')


# Generated at 2022-06-11 01:05:08.134702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleVault:
        __ENCRYPTED__ = True

        def __init__(self, *args):
            self._ciphertext = args[0]

    # test string type
    o = AnsibleVault("test")
    value = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(o)
    assert isinstance(value, dict)
    assert value == {'__ansible_vault': "test"}

    # test non-string type
    o = AnsibleVault(123)
    value = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(o)
    assert isinstance(value, dict)
    assert value == {'__ansible_vault': "123"}

    # test non-string

# Generated at 2022-06-11 01:05:18.352479
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 01:05:49.137306
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    j = AnsibleJSONEncoder()
    value = j.default(datetime.datetime(2020, 6, 26, 1, 16, 51, 77947))
    assert value == '2020-06-26T01:16:51.07947'

    # Hostvars
    class Hostvars:
        _hostname = "10.20.30.40"
        ansible_user = "root"
        ansible_ssh_pass = "password"
        facts = {'version': '0.1'}
    hostvars = Hostvars()
    value = j.default(hostvars)

# Generated at 2022-06-11 01:05:51.595425
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(b'ansible-vault') == 'ansible-vault'



# Generated at 2022-06-11 01:06:01.413146
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret

    # Use case #1: Pass an instance of a VaultSecret
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:06:06.200046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Test(object):
        def __init__(self, x):
            self.x = x
        def __str__(self):
            return 'Test(%s)' % self.x
    t = Test(3)

    s = json.dumps(t, cls=AnsibleJSONEncoder)
    assert s == '"Test(3)"'



# Generated at 2022-06-11 01:06:10.720503
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class SampleClass(object):
        def __init__(self, val):
            self.val = val

    import datetime
    from ansible.module_utils.six import u

    encoder = AnsibleJSONEncoder()
    assert encoder.default({u'sample': SampleClass(u'hello world')}) == {u'sample': {u'val': u'hello world'}}
    d = datetime.datetime.now()
    assert encoder.default(d) == d.isoformat()



# Generated at 2022-06-11 01:06:21.150658
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert(ansible_json_encoder.default('this is a string') == 'this is a string')
    assert(ansible_json_encoder.default(None) == None)
    assert(ansible_json_encoder.default(False) == False)
    assert(ansible_json_encoder.default(True) == True)
    assert(ansible_json_encoder.default(1) == 1)
    assert(ansible_json_encoder.default(0) == 0)
    assert(ansible_json_encoder.default(1.5) == 1.5)
    assert(ansible_json_encoder.default(0.0) == 0.0)

# Generated at 2022-06-11 01:06:26.496323
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(datetime.datetime(2017, 2, 8, 2, 40, 2, 85000)) == '2017-02-08T02:40:02.085000'
    assert ansible_json_encoder.default(datetime.date(2017, 2, 8)) == '2017-02-08'

# Generated at 2022-06-11 01:06:28.811691
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    print("testing AnsibleJSONEncoder default method")
    ae = AnsibleJSONEncoder()
    assert ae.default(ae)



# Generated at 2022-06-11 01:06:36.891362
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Any:
        pass

    # The dict is used to verify the function when the class of o has "__ENCRYPTED__" attribute
    encoder = AnsibleJSONEncoder()
    assert encoder.default({'__ENCRYPTED__': True, '_ciphertext': 'this'}) == {'__ansible_vault': 'this'}
    # The dict is used to verify the function when the class of o has "__UNSAFE__" attribute
    assert encoder.default({'__UNSAFE__': True}) == {'__ansible_unsafe': ''}
    # The dict is used to verify the function when o is an instance of Mapping
    assert encoder.default({'key': 'value'}) == {'key': 'value'}
    # The dict is used to verify the function when o is

# Generated at 2022-06-11 01:06:44.714592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test class AnsibleJSONEncoder.default() method.
    # if raw=True and _preprocess_unsafe=True then ansible_unsafe is set to text,
    # otherwise the the type accepts unsafe variable and it is converted to a dictionary
    # with __ansible_unsafe key
    for raw, preprocess_unsafe  in ((True, False), (False, True), (False, False)):
        for value in [True, 1, "ABC", [1, 2, "XYZ"], AnsibleUnsafe(1)]:
            ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe)
            expected_result = value
            if isinstance(value, AnsibleUnsafe) and not raw:
                expected_result = {'__ansible_unsafe': '1'}


# Generated at 2022-06-11 01:07:26.069233
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    key = "value"
    value = "test"
    obj = {key: value}
    enc = AnsibleJSONEncoder()
    obj_enc = enc.default(obj)
    assert obj_enc[key] == value

# Generated at 2022-06-11 01:07:36.578631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.convert_bool import boolean
    unsafe_object = AnsibleUnsafe('value')
    unsafe_None = AnsibleUnsafe(None)
    unsafe_bool = AnsibleUnsafe(boolean(True))
    unsafe_number = AnsibleUnsafe(1)
    unsafe_list = AnsibleUnsafe([1,2,3])
    unsafe_dict = AnsibleUnsafe({'k1': 'v1', 'k2': 'v2'})
    unsafe_dict_list = AnsibleUnsafe([{'k1': 'v1', 'k2': 'v2'}, {'k1': 'v1', 'k2': 'v2'}])
    a = AnsibleJSONEncoder()
    assert a

# Generated at 2022-06-11 01:07:44.782986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test vault object
    safe_object = 'test_object'
    vault_object = safe_object.__class__(safe_object)
    vault_object.__ENCRYPTED__ = True
    assert ansible_json_encoder.default(vault_object) == {'__ansible_vault': safe_object}

    # Test unsafe object
    unsafe_object = 'test_object'
    unsafe_object = unsafe_object.__class__(unsafe_object)
    unsafe_object.__UNSAFE__ = True
    assert ansible_json_encoder.default(unsafe_object) == {'__ansible_unsafe': unsafe_object}

    # Test mapping object

# Generated at 2022-06-11 01:07:54.096092
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    import ansible.constants
    import ansible.constants.display

    vault_password = 'myvaultpassword'
    vault_secret_file = './tests/utils/vault_secret_file'

    vault = VaultLib([(DEFAULT_VAULT_ID_MATCH, vault_password, vault_secret_file)])
    ciphertext = vault.encrypt('test')
    encrypted_passwd = ansible.constants.display.Display.vault.encrypt('mypassword', vault_password)


# Generated at 2022-06-11 01:08:00.518358
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dut = AnsibleJSONEncoder()
    # Test unsupported attribute with type str
    o = type("Mock", (str,), {"__ENCRYPTED__": True, "__ANSIBLE_FORMAT_INVENTORY__": True})
    assert dut.default(o) == o

    # Test unsupported attribute with type dict
    o = type("Mock", (dict,), {"__ENCRYPTED__": True, "__ANSIBLE_FORMAT_INVENTORY__": True})
    assert dut.default(o) == {"__ENCRYPTED__": True, "__ANSIBLE_FORMAT_INVENTORY__": True}

# Generated at 2022-06-11 01:08:08.895345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""
    import datetime

    # test __ENCRYPTED__
    from ansible.parsing.vault import VaultSecret
