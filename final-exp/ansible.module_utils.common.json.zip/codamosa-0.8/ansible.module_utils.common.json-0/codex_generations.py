

# Generated at 2022-06-11 00:58:15.960213
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('v') == 'v'
    assert AnsibleJSONEncoder().default('v') == AnsibleJSONEncoder(sort_keys=True).default('v')

    from ansible.parsing.vault import VaultAES256
    from ansible.module_utils.six import PY3
    if PY3:
        assert AnsibleJSONEncoder().default(VaultAES256('ansible', 'v')) == {'__ansible_vault': b'v'}
    else:
        assert AnsibleJSONEncoder().default(VaultAES256('ansible', 'v')) == {'__ansible_vault': 'v'}


# Generated at 2022-06-11 00:58:19.837685
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    o = {"key1": "value1", "key2": "value2"}
    value = json_encoder.default(o)
    assert value == o


# Generated at 2022-06-11 00:58:31.315061
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.text.converters import native_string_representation
    import datetime


# Generated at 2022-06-11 00:58:40.253279
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("data") == "data"
    assert AnsibleJSONEncoder().default(u"data") == u"data"
    assert AnsibleJSONEncoder().default("data".encode("utf-8")) == u"data"
    assert AnsibleJSONEncoder().default("data") == "data"

    # Test for JSONEncoder for json.JSONEncoder
    assert AnsibleJSONEncoder().default("data") == "data"

    # Test for date/time for json.JSONEncoder
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()

    # Test for set
    assert AnsibleJSONEncoder().default(set([1, 2, 3])) == set([1, 2, 3])

# Generated at 2022-06-11 00:58:51.969440
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # datetime and date objects are serialized to JSON as strings
    assert json.loads(json.dumps(datetime.datetime.fromtimestamp(1565837440), cls=AnsibleJSONEncoder)) == '2019-08-16T18:24:00'
    assert json.loads(json.dumps(datetime.date(2019, 8, 16), cls=AnsibleJSONEncoder)) == '2019-08-16'
    # dict and AnsibleVars are serialized to JSON as dicts
    assert json.loads('{"foo": "bar"}', cls=AnsibleJSONEncoder) == {"foo": "bar"}

# Generated at 2022-06-11 00:59:02.372992
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types

    def assert_object_json(o, expected_json):
        assert json.dumps(o, cls=AnsibleJSONEncoder) == expected_json

    assert_object_json({'a': 'A'}, '{"a": "A"}')

    class Dummy:
        pass

    assert_object_json(Dummy(), '{}')

    class Dummy2:
        __slots__ = ['a']

        def __init__(self):
            self.a = 'A'

    assert_object_json(Dummy2(), '{"a": "A"}')

    class Dummy3(string_types):
        __UNSAFE__ = True


# Generated at 2022-06-11 00:59:13.793123
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import AuthBasic
    from ansible.module_utils.six.moves import urllib

    # datetime.datetime
    o = datetime.datetime(2016, 2, 21, 2, 33, 58, tzinfo=datetime.timezone.utc)
    value = AnsibleJSONEncoder().default(o)
    assert value == '2016-02-21T02:33:58+00:00'

    # urllib.parse.ParseResult
    o = urllib.parse.urlparse('//a/b')
    value = AnsibleJSONEncoder().default(o)
    assert value == '//a/b'

    # AuthBasic.__dict__
    o = AuthBasic('user', 'pass')

# Generated at 2022-06-11 00:59:22.601047
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder(check_circular=False, allow_nan=False, sort_keys=True, separators=(',', ':'))
    assert o.default(datetime.datetime(year=2019, month=1, day=2, hour=15, minute=20)) == '2019-01-02T15:20:00'
    assert o.default(datetime.date(year=2019, month=1, day=2)) == '2019-01-02'
    assert o.default({"a": 1}) == {"a": 1}
    assert o.default({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert o.default({"a": {"b": 1}}) == {"a": {"b": 1}}

# Generated at 2022-06-11 00:59:34.196708
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    vault_pass = 'pass'

    assert(AnsibleJSONEncoder().default(AnsibleUnsafe('string'))) == 'string'
    assert(AnsibleJSONEncoder().default('string')) == 'string'

# Generated at 2022-06-11 00:59:44.838918
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    import datetime

    # vault

# Generated at 2022-06-11 00:59:59.062837
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(a=1,b=2)) == dict(a=1,b=2)
    assert AnsibleJSONEncoder().default(True) is True
    assert AnsibleJSONEncoder().default(2) == 2
    assert AnsibleJSONEncoder().default(2.0) == 2.0
    assert AnsibleJSONEncoder().default("Test String").encode('utf-8') == "Test String".encode('utf-8')
    assert AnsibleJSONEncoder().default(u"Test Unicode String").encode('utf-8') == u"Test Unicode String".encode('utf-8')
    assert AnsibleJSONEncoder().default(b"Test Byte String").encode('utf-8') == b"Test Byte String".encode('utf-8')
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-11 01:00:08.771069
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class s(object):
        def __init__(self, x):
            self.x = x

    class o(object):
        def __init__(self, d):
            self.d = d

    class v(str):
        pass
    v.__ENCRYPTED__ = True

    class u(str):
        pass
    u.__UNSAFE__ = True

    sample1 = {
        'y': [1, 2, {'z': s('t')}],
        'x': s('q'),
        'a': [1, 2, {'b': {'c': s('t')}}, 4, 5]
    }
    sample1['a'].append(sample1)


# Generated at 2022-06-11 01:00:13.558481
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Case conversion of datetime
    datetime_str = '2018-02-22 19:41:01'
    datetime_test = datetime.datetime.strptime(datetime_str, "%Y-%m-%d %H:%M:%S")
    assert AnsibleJSONEncoder().default(datetime_test) == datetime_str

# Generated at 2022-06-11 01:00:25.394589
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  ansible_unsafe = AnsibleUnsafe(u"ansible_unsafe_string", True)
  ansible_vault = AnsibleVaultEncryptedUnicode(u"ansible_vault_string", False)
  ansible_json_encoder = AnsibleJSONEncoder()
  ansible_json_encoder_vault_to_text = AnsibleJSONEncoder(vault_to_text=True)
  assert(ansible_json_encoder.default(ansible_unsafe) == {'__ansible_unsafe': u'ansible_unsafe_string'})
  assert(ansible_json_encoder_vault_to_text.default(ansible_vault) == u'ansible_vault_string')

# Generated at 2022-06-11 01:00:35.315500
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    my_str = 'foobar'
    my_obj = VaultSecret(my_str)
    result = AnsibleJSONEncoder().default(my_obj)
    assert result['__ansible_vault'] == my_str

    my_str = 'foobar'
    result = AnsibleJSONEncoder().default(my_str)
    assert result == my_str

    my_list = ['a', 'b', 'c']
    result = AnsibleJSONEncoder().default(my_list)
    assert result == my_list

    my_date = datetime.date.today()
    result = AnsibleJSONEncoder().default(my_date)
    assert result == my_date.isoformat()



# Generated at 2022-06-11 01:00:37.649711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = AnsibleJSONEncoder().default({'key':'value'})
    assert isinstance(value,dict)
    assert value == {'key':'value'}

# Generated at 2022-06-11 01:00:43.355485
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    o = {'a': {'b': 'c'}, 'd': 'e'}
    e.default(o)

    o = {'a': {'b': ['c', 'd']}, 'd': 'e'}
    e.default(o)



# Generated at 2022-06-11 01:00:54.892591
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib

    sample_text = 'The quick brown fox jumps over the lazy dog'
    sample_bytes = b'The quick brown fox jumps over the lazy dog'
    sample_date = datetime.date(2001, 2, 3)

    # Vaulted text:
    vaulted = VaultLib('TEST')
    vaulted_text = vaulted.encrypt(sample_text)
    assert isinstance(vaulted_text, bytes)
    assert vaulted_text != sample_bytes

    # Vaulted bytes:
    vaulted = VaultLib('TEST')
    vaulted_bytes = vaulted.encrypt(sample_bytes)
    assert isinstance(vaulted_bytes, bytes)
    assert vaulted_bytes != sample_bytes

    # Unsafe, with_bytes=True:


# Generated at 2022-06-11 01:01:04.353330
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test support for the vault object
    ansible_encoder = AnsibleJSONEncoder()
    test_vault = AnsibleUnsafeText('Vault(ciphertext)')
    test_vault.__ENCRYPTED__ = True
    test_vault.__VAULT__ = True
    test_vault._ciphertext = b'ciphertext'
    assert ansible_encoder.default(test_vault) == {'__ansible_vault': b'ciphertext'}

    # Test support for unsafe objects
    test_unsafe = AnsibleUnsafeText('test_unsafe')
    test_unsafe.__UNSAFE__ = True
    assert ansible_encoder.default(test_unsafe) == {'__ansible_unsafe': 'test_unsafe'}

    # Test

# Generated at 2022-06-11 01:01:07.850624
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoding_obj = AnsibleJSONEncoder()
    data = {'a': 1, 'b': 2, 'c': 3}
    data_dump = encoding_obj.default(data)
    assert data_dump == data


# Generated at 2022-06-11 01:01:21.762431
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultEditor
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    vault_e = VaultEditor('password')
    c = vault_e.encrypt('secret')


# Generated at 2022-06-11 01:01:33.345339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    def _test_encoding(value, **kwargs):
        '''Test encoding an arbitrary value with the default encoder'''
        return AnsibleJSONEncoder(**kwargs).default(value)

    def _test_unsafe_encoding(value, **kwargs):
        '''Test encoding an arbitrary value which contains unsafe data with the default encoder'''
        return AnsibleJSONEncoder(**kwargs).default(value)

    def _test_encryption(value, **kwargs):
        '''Test encoding an arbitrary value which contains vault encryption with the default encoder'''
        return AnsibleJSONEncoder(**kwargs).default(value)

    # Test encoding a dict

# Generated at 2022-06-11 01:01:43.167840
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('abc') == 'abc'
    assert encoder.default(True) is True
    assert encoder.default(None) is None
    assert encoder.default(1) == 1
    assert encoder.default(1.1) == 1.1
    assert encoder.default(1.0) == 1.0
    assert encoder.default(set()) == set()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default((1, 2, 3)) == (1, 2, 3)
    assert encoder.default(datetime.date(2019, 11, 22)) == '2019-11-22'

# Generated at 2022-06-11 01:01:53.705806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-11 01:02:01.325749
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    assert AnsibleJSONEncoder().default(datetime.datetime(year=2000, month=1, day=1, hour=0, minute=0, second=0)) == "2000-01-01T00:00:00"
    assert AnsibleJSONEncoder().default(datetime.date(year=2000, month=1, day=1)) == "2000-01-01"
    assert AnsibleJSONEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-11 01:02:13.120317
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == "null"  # None
    assert AnsibleJSONEncoder().default(True) == "true"  # True
    assert AnsibleJSONEncoder().default(False) == "false"  # False
    assert AnsibleJSONEncoder().default(1) == 1  # int
    assert AnsibleJSONEncoder().default(1.0) == 1.0  # float
    assert AnsibleJSONEncoder().default(1 + 2j) == "(1+2j)"  # complex
    assert AnsibleJSONEncoder().default(u"unicode") == "unicode"  # unicode
    assert AnsibleJSONEncoder().default(b"bytestring") == "bytestring"  # bytestring

# Generated at 2022-06-11 01:02:22.127544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    assert isinstance(AnsibleJSONEncoder().default(AnsibleUnsafe("unsafe")), dict)
    assert isinstance(AnsibleJSONEncoder().default(AnsibleJSONEncoder), json.JSONEncoder)
    assert isinstance(AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVault("vault")), text_type)
    assert isinstance(AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVault("vault")), text_type)


# Generated at 2022-06-11 01:02:29.644644
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    json_encoder = AnsibleJSONEncoder()
    # test default method with datetime objects
    date_obj = datetime.datetime(year=2017, month=6, day=19, hour=1, minute=0, second=0)
    date_json = json_encoder.default(date_obj)
    assert date_json == '2017-06-19T01:00:00'
    # test default method with mapping objects
    dict_obj = dict(a=1, b=2)
    dict_json = json_encoder.default(dict_obj)
    assert dict_json == dict_obj
    # test default method with AnsibleUnsafe objects
    unsafe_obj = ansible.module_utils.basic.AnsibleUnsafe('test')

# Generated at 2022-06-11 01:02:35.527772
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_cases_primitive_types = [1, 2.5, 'hello', None, True, False]
    test_cases_objects = [
        ('unsafe', 'unsafe', {'__ansible_unsafe': 'unsafe'}),
        ('vault', 'vault', {'__ansible_vault': 'vault'}),
        ('str', u'str', u'str'),
        ('date', datetime.date(2017, 7, 3), u'2017-07-03'),
        ('datetime', datetime.datetime(2017, 7, 3, 12, 30, 0), u'2017-07-03T12:30:00'),
    ]

    test_cases = test_cases_primitive_types + test_cases_objects


# Generated at 2022-06-11 01:02:43.724404
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_text = '$ANSIBLE_VAULT;1.1;AES256\n333161653566313739383062363263626235353163356139623664363238663935306634363865\n363935346162346331626335656639666339616137616530393566653239633537373635653365\n363734393066333132343234366137663934626663376537386563636532353238356365326532\n663230356637353363323731383730356539353466633463653434366465\n'


# Generated at 2022-06-11 01:03:02.900236
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: why do we need to import it here, can't we just import it at the top level,
    # or at least a module level?
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode
    from ansible.parsing.vault import VaultLib
    import string
    import random

    def _random_string(size):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(size))

    def _ensure_string(v, e):
        if isinstance(e, bytes):
            return to_bytes(v)
        elif isinstance(e, str):
            return to_text(v, errors='surrogate_or_strict')
        else:
            raise TypeError

# Generated at 2022-06-11 01:03:07.862213
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {'foo': 'bar', 'baz': ['one', 'two', 'three'], 'quux': {'quux1': 'quux1val', 'quux2': 'quux2val'}}
    expected = '{"foo": "bar", "baz": ["one", "two", "three"], "quux": {"quux1": "quux1val", "quux2": "quux2val"}}'
    actual = json.dumps(data, cls=AnsibleJSONEncoder)
    assert actual == expected

# Generated at 2022-06-11 01:03:13.769436
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    datetime_obj = datetime.datetime(year=2019, month=1, day=2, hour=3, minute=4, second=5, microsecond=0)
    result = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(datetime_obj)
    assert result == '2019-01-02T03:04:05'


# Generated at 2022-06-11 01:03:26.108107
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # __ENCRYPTED__ True
    object = object()
    object.__class__ = object
    setattr(object, '__ENCRYPTED__', True)
    assert AnsibleJSONEncoder(False).default(object)['__ansible_vault'] == ''

    # __UNSAFE__ True
    object = object()
    object.__class__ = object
    setattr(object, '__UNSAFE__', True)
    assert AnsibleJSONEncoder(False).default(object)['__ansible_unsafe'] == ''

    # isinstance(o, Mapping) True
    assert AnsibleJSONEncoder(False).default({}) == {}

    # isinstance(o, (datetime.date, datetime.datetime)) True

# Generated at 2022-06-11 01:03:33.073309
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    encoder = AnsibleJSONEncoder()
    test_dict = {'foo': 'bar', 'spam': 'eggs'}

    assert '__ansible_unsafe' not in encoder.encode(test_dict)
    assert '__ansible_vault' not in encoder.encode(test_dict)

    unsafe = 'foo'
    unsafe.__UNSAFE__ = True
    assert 'foo' not in encoder.encode(unsafe)
    assert '__ansible_unsafe' in encoder.encode(unsafe)

    vault = VaultLib('password')
    encrypted = vault.encrypt('foo')
    assert 'foo' not in encoder.encode(encrypted)
    assert '__ansible_vault' in encoder

# Generated at 2022-06-11 01:03:44.019907
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.basic import AnsibleUnsafe
    from datetime import date, datetime

    vault_pass_bytes = b'\xc2\xa3\xa7\u00c2'
    vault_pass = vault_pass_bytes.decode('utf-8')

    vault_secret = VaultSecret(b'$ANSIBLE_VAULT;1.1;AES256\n', vault_pass_bytes)
    vault_lib = VaultLib(vault_secret)

    encrypted_vault_text = vault_lib.encrypt(u'Ťěšť')
    encoded_vault_text = encrypted_

# Generated at 2022-06-11 01:03:53.057787
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # vault object
    encrypted = VaultLib().encrypt('my_password')
    assert getattr(encrypted, '__ENCRYPTED__', False)
    assert getattr(encrypted, '__UNSAFE__', False)

    # vault object converted to text
    o = AnsibleJSONEncoder(vault_to_text=True, preprocess_unsafe=False).encode(encrypted)
    assert o == encrypted
    assert json.loads(o) == encrypted

    # vault object as dict
    o = AnsibleJSONEncoder(vault_to_text=False, preprocess_unsafe=False).encode(encrypted)
    assert json.loads(o) == {'__ansible_vault': encrypted._ciphertext}

    # unsafe object

# Generated at 2022-06-11 01:04:04.497753
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime

    vault_data = VaultLib('vaultsecret')

# Generated at 2022-06-11 01:04:16.186976
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    obj = [1, 2, 3]
    obj.__ENCRYPTED__ = False
    obj.__UNSAFE__ = False

    result = AnsibleJSONEncoder().default(obj)

    assert result == obj  # Output should be equal to the input, since it is not a unsafe or encrypted object

    obj.__ENCRYPTED__ = True

    result = AnsibleJSONEncoder(True).default(obj)

    assert result == obj  # Output should be equal to the input, since it is not a unsafe object

    obj.__ENCRYPTED__ = False
    obj.__UNSAFE__ = True

    result = AnsibleJSONEncoder(True).default(obj)

    assert result == obj  # Output should be equal to the input, since vault_to_text is turned off

    obj.__ENCRYPT

# Generated at 2022-06-11 01:04:27.071571
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    encoder = AnsibleJSONEncoder()

    assert encoder.default(ansible.parsing.vault.VaultLib([], [], [], None)) == {'__ansible_vault': ''}
    assert encoder.default(ansible.parsing.vault.VaultLib.new()) == {'__ansible_vault': ''}
    assert encoder.default(datetime.datetime.now()) == '2018-05-22T16:39:02.689830'
    assert encoder.default(datetime.date.today()) == '2018-05-22'
    assert encoder.default(dict(key='value', key2='value2')) == {'key': 'value', 'key2': 'value2'}
    assert encoder

# Generated at 2022-06-11 01:04:50.631450
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert "test" == AnsibleJSONEncoder().default("test")
    assert "" == AnsibleJSONEncoder().default("")
    assert "abcd" == AnsibleJSONEncoder().default("abcd")
    assert "[]" == AnsibleJSONEncoder().default([])
    assert "[1,2]" == AnsibleJSONEncoder().default([1,2])
    assert "{}" == AnsibleJSONEncoder().default({})
    assert '{"a":1}' == AnsibleJSONEncoder().default({'a':1})
    assert '"2010-09-28T07:00:00"' == AnsibleJSONEncoder().default(datetime.datetime(2010, 9, 28, 7))
    assert '"2010-09-28"' == AnsibleJSONEncoder().default(datetime.date(2010, 9, 28))

# Unit

# Generated at 2022-06-11 01:04:57.071119
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader
    from __main__ import display

    vault_lib = VaultLib()

    secret = vault_lib.encrypt('foo')
    vault_secret = VaultSecret(secret)

    ansible_json_encoder = AnsibleJSONEncoder()

    display.display(ansible_json_encoder.default(vault_secret))

# Generated at 2022-06-11 01:05:06.779520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.text.converters import to_bytes, to_unicode, to_native
    from ansible.parsing.vault import VaultLib

    # test to_bytes

# Generated at 2022-06-11 01:05:12.062554
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = dict(abc = dict(top = '123'))
    assert encoder.default(o) == o
    o = dict(abc = dict(top = '123'))
    o_encoded = {'abc': {'top': '123'}}
    assert encoder.default(o) == o_encoded

# Generated at 2022-06-11 01:05:20.506210
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # test __ENCRYPTED__
    e = AnsibleJSONEncoder()
    secret = 'my secret string'
    password = 'my vault password'
    vault = VaultLib([password])
    secret_vaulted = vault.encrypt(secret)
    secret_vaulted_obj = VaultSecret(secret_vaulted)
    # vault_to_text = False

# Generated at 2022-06-11 01:05:30.507215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    # Test unsafe object
    class C(string_types[0]):
        __UNSAFE__ = True
    o1 = C('test')
    json_o1 = '{"__ansible_unsafe": "test"}'

    # Test vault object
    o2 = VaultLib('$ANSIBLE_VAULT;1.2;AES256;' + VaultLib.get_random_cipher())

# Generated at 2022-06-11 01:05:38.559960
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('foo').encode('utf-8') == b'"foo"'
    assert AnsibleJSONEncoder().default({'foo': 'bar'}).encode('utf-8') == b'{"foo": "bar"}'
    assert AnsibleJSONEncoder().default(datetime.datetime(2014, 1, 1)).encode('utf-8') == b'"2014-01-01T00:00:00"'
    assert AnsibleJSONEncoder().default(datetime.date(2014, 1, 1)).encode('utf-8') == b'"2014-01-01"'



# Generated at 2022-06-11 01:05:50.416379
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(indent=4).default(dict(a=1, b=2)) == '''{\n    "a": 1, \n    "b": 2\n}'''


# Generated at 2022-06-11 01:05:58.907876
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test unsafe object which needs to be converted to a dict
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(False, 'test_unsafe')) == {'__ansible_unsafe': 'test_unsafe'}
    # Test vault object which needs to be converted to a dict
    assert AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnsafe(False, 'test_unsafe')) == {'__ansible_vault': 'test_unsafe'}
    # Test AnsibleMapping object which needs to be converted to a dict
    s = AnsibleMapping({'a': '1', 'b': '2'})
    assert AnsibleJSONEncoder().default(s) == {'a': '1', 'b': '2'}



# Generated at 2022-06-11 01:06:08.510095
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test AnsibleJSONEncoder.default

    Should return a json serializable object containing the base64 encoded
    ciphertext for ``AnsibleVaultEncryptedUnicode`` objects.

    """
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 01:06:31.568150
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    test_input = dict(date1=datetime.date(2019,11,10), list1=[datetime.date(2019,11,20)], dict1=dict(field1=datetime.date(2019,11,30)))
    expected_output = dict(date1="2019-11-10", list1=["2019-11-20"], dict1=dict(field1="2019-11-30"))
    assert encoder.default(test_input) == expected_output


# Generated at 2022-06-11 01:06:37.539144
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # Standard types are encoded as expected
    assert encoder.default(42) == 42
    assert encoder.default(str(42)) == str(42)

    # Non standard types are encoded as expected
    assert encoder.default(datetime.datetime(2019, 5, 6, 3, 53, 55, tzinfo=datetime.timezone.utc)) == '2019-05-06T03:53:55+00:00'

# Generated at 2022-06-11 01:06:41.453503
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert (AnsibleJSONEncoder().encode({"key":{"key":"value"}}) ==
            '{"key": {"key": "value"}}')

    assert (AnsibleJSONEncoder().encode({"key":"value"}) ==
            '{"key": "value"}')

    assert (AnsibleJSONEncoder().encode(["list"]) ==
           '["list"]')


# Generated at 2022-06-11 01:06:48.452151
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()

    # Test AnsibleUnsafe
    assert encoder.default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}

    # Test VaultSecret
    assert encoder.default(VaultSecret('test')) == {'__ansible_unsafe': 'test'}
    v = VaultLib('secret')
    assert isinstance(encoder.default(v.encrypt('test')), dict)

    # Test datetime
    assert encoder.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert enc

# Generated at 2022-06-11 01:06:58.783069
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    from ansible.vars import AnsibleVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    # test for encrypting a vault object
    vault = VaultLib(b'password')
    my_var = vault.encrypt('my_var=1')

# Generated at 2022-06-11 01:07:08.975832
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create a mock VaultLib object
    class AnsibleVault(object):
        __ENCRYPTED__ = True

    vault_obj = AnsibleVault()

    # Create a mock AnsibleUnsafeText object
    class AnsibleUnsafeText(unicode):
        __UNSAFE__ = True

    unsafe_obj = AnsibleUnsafeText('abc')

    # Create a mock AnsibleUnsafeBytes object
    class AnsibleUnsafeBytes(str):
        __UNSAFE__ = True

    unsafe_bytes_obj = AnsibleUnsafeBytes('abc')

    # Create a mock AnsibleUnsafeText object
    class AnsibleUnsafeTextEncrypted(unicode):
        __UNSAFE__ = True
        __ENCRYPTED__ = True
    unsafe_encrypted_obj = AnsibleUnsafeTextEncrypted('abc')

# Generated at 2022-06-11 01:07:15.766765
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_cases = [
        (b'hi', b'"hi"'),
        (u'hi', b'"hi"'),
        (b'hi', b'"hi"'),
        (2, b'2'),
        (True, b'true'),
        (None, b'null'),
        ((), b'[]'),
        ([], b'[]'),
        ({}, b'{}'),
        (set(), b'[]'),
        ({'key': 'val'}, b'{"key": "val"}'),
        ]

    aje = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:07:23.718717
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.ansible_types import AnsibleUnsafe
    class Foo:
        def __init__(self, attr):
            self.attr = attr
    default_encoder = json.JSONEncoder().default
    ansible_encoder = AnsibleJSONEncoder().default
    assert default_encoder(Foo('bar')) == ansible_encoder(Foo('bar'))
    assert default_encoder(AnsibleUnsafe('foo')) != ansible_encoder(AnsibleUnsafe('foo'))
    assert default_encoder(AnsibleUnsafe('foo')) == ansible_encoder(str('foo'))

# Generated at 2022-06-11 01:07:33.772263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types
    assert string_types == (str, unicode)  # noqa

    from ansible.module_utils.six import PY3
    if not PY3:
        from ansible.module_utils.six.moves import builtins
        unicode_old = builtins.unicode
        builtins.unicode = str

    result = AnsibleJSONEncoder().default("dummy")
    assert result == "dummy"

    result = AnsibleJSONEncoder().default(b"dummy")
    assert result == "dummy"

    result = AnsibleJSONEncoder().default(u"dummy")
    assert result == u"dummy"

    if not PY3:
        builtins.unicode = unicode_old


# Generated at 2022-06-11 01:07:43.329702
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # testcase 1
    value1 = b'value1'
    o1 = AnsibleUnsafe(value1)
    ans1 = AnsibleJSONEncoder().default(o1)
    expect1 = {'__ansible_unsafe': 'value1'}
    assert ans1 == expect1

    # testcase 2
    value2 = b'value2'
    o2 = AnsibleVaultEncryptedUnsafe(value2)
    ans2 = AnsibleJSONEncoder(vault_to_text=True).default(o2)
    expect2 = {'__ansible_unsafe': 'value2'}
    assert ans2 == expect2

    # testcase 3
    value3 = {'__ansible_unsafe': 'value3'}
    o3 = AnsibleUnsafe(value3)