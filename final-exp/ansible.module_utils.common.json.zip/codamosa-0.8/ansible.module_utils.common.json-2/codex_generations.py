

# Generated at 2022-06-11 00:58:14.537339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # alias
    AnsibleJSONEncoder_default = AnsibleJSONEncoder().default

    # unsafe
    unsafe_o = AnsibleUnsafe('something unsafe')
    assert AnsibleJSONEncoder_default(unsafe_o) == {'__ansible_unsafe': 'something unsafe'}

    # vault
    vault_o = AnsibleVaultEncryptedUnicode('something vault')
    assert AnsibleJSONEncoder_default(vault_o) == {'__ansible_vault': 'something vault'}

    # date
    date_o = datetime.date(2011, 1, 1)
    assert AnsibleJSONEncoder_default(date_o) == "2011-01-01"

    # datetime

# Generated at 2022-06-11 00:58:25.821322
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.unsafe_proxy import AnsibleUnsafeText
    ansible_json_encoder = AnsibleJSONEncoder()

    # test AnsibleVaultEncryptedUnicode
    ciphertext = AnsibleVaultEncryptedUnicode(VaultLib('secret').encrypt('password'))._ciphertext
    assert ansible_json_encoder.default(AnsibleVaultEncryptedUnicode(ciphertext)) == {'__ansible_vault': ciphertext}

    # test AnsibleUnsafeText
    unsafe = AnsibleUnsafeText('password')

# Generated at 2022-06-11 00:58:36.291242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.ansible_release import __version__ as __version__
    from ansible.module_utils.parsing.convert_bool import boolean

    vault = VaultLib([])
    vault.update({'password': 'secret'})

    encoder = AnsibleJSONEncoder()
    assert json.dumps({'a': 'b'}, cls=AnsibleJSONEncoder) == '{"a": "b"}'

# Generated at 2022-06-11 00:58:46.244161
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the cases with and without the vault_to_text flag set
    for vault_to_text in (True, False):
        encoder = AnsibleJSONEncoder(vault_to_text=vault_to_text)

        # Test a vault object, should be encoded into {'__ansible_vault': '<contents of vault>'}
        vault = "hello world"
        vault = '!vault |\n' + vault
        vault = dict(__ENCRYPTED__=True, _ciphertext=vault)
        expected = {'__ansible_vault': 'hello world'}
        if vault_to_text:
            expected = to_text(expected, errors='surrogate_or_strict')
        assert encoder.default(vault) == expected

        # Test an unsafe object

# Generated at 2022-06-11 00:58:51.718936
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    value = {'a': {'b': 'c'}, 'd': datetime.date(2017, 12, 31)}

    assert json.dumps(value, cls=AnsibleJSONEncoder) == '{"a": {"b": "c"}, "d": "2017-12-31"}'

# Generated at 2022-06-11 00:59:00.770833
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class AnsibleVaultStub(VaultLib):
        def __init__(self, password=None, **kwargs):
            self._ciphertext = 'fake-ciphertext'
            super(AnsibleVaultStub, self).__init__(password=password, **kwargs)

    vault_obj = AnsibleVaultStub()
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': 'fake-ciphertext'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(vault_obj) == ''

# Generated at 2022-06-11 00:59:03.722371
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(sort_keys=True, indent=4).encode({'a': 1, 'b': 2, 'c': 3}) == '{\n    "a": 1,\n    "b": 2,\n    "c": 3\n}'


# Generated at 2022-06-11 00:59:15.285541
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import types
    import os

    # Test for default method without any special object
    test_encoder = AnsibleJSONEncoder()
    test_data = [{"key1": "value1"},
                 {"key2": "value2"}]
    encoded_json = test_encoder.encode(test_data)
    assert json.loads(encoded_json) == test_data

    # Test for default method with SafeText object
    test_encoder = AnsibleJSONEncoder()
    encoded_json = test_encoder.encode('test string')
    assert json.loads(encoded_json) == 'test string'

    # Test for default method with SafeBytes object
    test_encoder = AnsibleJSONEncoder()
    encoded_json = test_encoder.encode(b'test bytes')

# Generated at 2022-06-11 00:59:23.383090
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault_data = VaultLib().encrypt(b'unsafe_vault_data')
    unsafe_data = AnsibleUnsafe(b'unsafe_data')

    o_dict = {b'vault': vault_data, b'unsafe': unsafe_data}
    o_date = datetime.datetime(2019, 10, 10, 0, 0, 0)
    o = {b'dict': o_dict, b'date': o_date}

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    result = encoder.default(o)


# Generated at 2022-06-11 00:59:35.026877
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 00:59:48.337359
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleVault:
        __ENCRYPTED__ = True

        def __init__(self, _ciphertext):
            self._ciphertext = _ciphertext

    class AnsibleUnsafe:
        __UNSAFE__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    class AnsibleObject(object):
        pass

    class AnsibleMapping(Mapping):
        pass

    for obj in [AnsibleVault, AnsibleUnsafe, AnsibleObject, AnsibleMapping]:
        encoder = AnsibleJSONEncoder()
        assert obj.__name__ == encoder.default(obj)


# Generated at 2022-06-11 00:59:48.933581
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-11 01:00:01.197843
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    #All of these will pass through and return the default
    assert AnsibleJSONEncoder().default("TEST") == "TEST"
    assert AnsibleJSONEncoder().default(3) == 3
    assert AnsibleJSONEncoder().default(3.14159) == 3.14159
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 2, 17, 3, 53, 1, 82233)) == "2017-02-17T03:53:01.82233"
    #The vault object will be converted to the json equivalent
    assert AnsibleJSONEncoder().default("VAULT") == {"__ansible_vault":"VAULT"}
    assert AnsibleJSONEncoder(vault_to_text=True).default("VAULT") == "VAULT"
    #The unsafe object will be converted to the json equivalent


# Generated at 2022-06-11 01:00:07.503999
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six.moves import range

    from ansible.module_utils.common._collections_compat import MutableSet

    # initialize vault
    vault_password = 'test_ansible_vault'
    vault_bytes = VaultLib([True]).encrypt(vault_password, 'test_ansible_vault_data')

    # basic tests (test defaults)

# Generated at 2022-06-11 01:00:19.155200
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib

    # see also test_json_bytes_to_unicode
    def test_data(with_unsafe=False):
        data = [u'abc', {u'abc': [1, 2, 3], u'foo': u'bar'}]
        if with_unsafe:
            data.append(AnsibleUnsafe(u'abc'))

        return data

    def _dump(data):
        return json.dumps(data, cls=AnsibleJSONEncoder, ensure_ascii=False)

    for data in (test_data(), test_data(with_unsafe=True)):
        json_data = _dump(data)

# Generated at 2022-06-11 01:00:21.938906
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = {'a': 'b'}
    assert encoder.default(o) == o


# Generated at 2022-06-11 01:00:26.352443
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test') == "test"
    assert encoder.default(dict(test=True)) == dict(test=True)
    assert encoder.default(dict(test2=dict(test3=True))) == dict(test2=dict(test3=True))

# Generated at 2022-06-11 01:00:36.042127
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:00:48.228954
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common.collections import ImmutableDict

    assert AnsibleJSONEncoder().default(AnsibleUnsafeText(u'foo\u2028')) == 'foo\u2028'
    assert AnsibleJSONEncoder().default(AnsibleUnsafeBytes(b'foo\xe2\x80\xa8')) == {'__ansible_unsafe': 'foo\xe2\x80\xa8'}


# Generated at 2022-06-11 01:00:57.928127
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    plaintext = "test"
    vault_text = ansible.parsing.vault.VaultLib('').encrypt(plaintext)

    json_encoder = AnsibleJSONEncoder()

    assert json_encoder.default(ansible.parsing.vault.VaultSecret(vault_text)) == {'__ansible_vault': vault_text}
    assert json_encoder.default(ansible.parsing.vault.VaultSecret(vault_text, vault_text)) == {'__ansible_vault': vault_text}
    assert json_encoder.default(ansible.parsing.vault.VaultSecret(vault_text, plaintext)) == plaintext

# Generated at 2022-06-11 01:01:13.208935
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import datetime
    from collections import OrderedDict

    if sys.version_info.major < 3:
        import ansible.module_utils.unsafe_proxy as unsafe_proxy
        class TestUnsafe(unsafe_proxy.AnsibleUnsafeText):
            __ENCRYPTED__ = False
            __UNSAFE__ = True

        # https://github.com/ansible/ansible/issues/39008
        # TestUnsafe must be a subclass of str to be useful,
        # and so we cannot test with a user-defined class.
        # However, in Python 2.7, AnsibleUnsafeText is a subclass
        # of str, and so we cannot test with that either because
        # the method default will never get called.
        assert not issubclass(str, TestUnsafe)

# Generated at 2022-06-11 01:01:22.673299
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    test_string = 'hello world'
    encoder = AnsibleJSONEncoder()
    assert encoder.default(test_string) == test_string

    test_dict = VaultLib().encrypt({'foo': 'bar'})

# Generated at 2022-06-11 01:01:34.375418
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # o is a dict
    o = dict()
    ansible_json_encoder = AnsibleJSONEncoder(False, False)
    d = ansible_json_encoder.default(o)
    assert d == {}

    # o is a datetime.date
    o = datetime.date(2018, 1, 1)
    ansible_json_encoder = AnsibleJSONEncoder(False, False)
    d = ansible_json_encoder.default(o)
    assert d == '2018-01-01'

    # o is a datetime.datetime
    o = datetime.datetime(2018, 1, 1, 1, 1, 1)
    ansible_json_encoder = AnsibleJSONEncoder(False, False)
    d = ansible_json_encoder.default(o)

# Generated at 2022-06-11 01:01:44.674282
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 01:01:55.270956
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder_obj = AnsibleJSONEncoder()
    assert encoder_obj.default(None) == None
    assert encoder_obj.default(False) == False
    assert encoder_obj.default(True) == True
    assert encoder_obj.default(10) == 10
    assert encoder_obj.default(10.2) == 10.2
    assert encoder_obj.default('test') == 'test'
    assert encoder_obj.default('test'.encode('utf-8')) == 'test'
    assert encoder_obj.default(['test']) == ['test']
    assert encoder_obj.default(('test',)) == ['test']
    assert encoder_obj.default({'a': 'test'}) == {'a': 'test'}
    # assert encoder_obj.default({

# Generated at 2022-06-11 01:02:05.295313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('a') == 'a'

    # Test AnsibleUnsafe
    unsafe_str = to_text(u'Unsafe object')
    unsafe_str.__UNSAFE__ = True
    assert encoder.default(unsafe_str) == {'__ansible_unsafe': u'Unsafe object'}

    # Test AnsibleVault
    vault_str = to_text(u'Vault object')
    vault_str.__ENCRYPTED__ = True
    assert encoder.default(vault_str) == {'__ansible_vault': u'Vault object'}

    # Test AnsibleVault with vault_to_text=True
    vault_str = to_text(u'Vault object')
    vault_str.__

# Generated at 2022-06-11 01:02:17.668181
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test(value, expected):
        class MyEncoder(AnsibleJSONEncoder):
            def default(self, value):
                return value
        json_text = json.dumps(value, cls=MyEncoder)
        assert json_text == json.dumps(expected)

    # string type
    test('a', 'a')

    # bytes -> string
    test(b'a', 'a')

    # bytes -> string and JSON encoded
    test(b'{"a": "b"}', '{"a": "b"}')

    # AnsibleVault
    test(b'Vault(a)', '{"__ansible_vault": "Vault(a)"}')

    # AnsibleUnsafe

# Generated at 2022-06-11 01:02:27.260747
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit tests for AnsibleJSONEncoder: default()."""
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    # Simple Bool
    test_value = encoder.default(True)
    assert test_value == True

    # Simple List
    test_value = encoder.default(["one", "two", "three"])
    assert test_value == ["one", "two", "three"]

    # Expected Mapping
    test_value = encoder.default({'one': "two", 'three': "four"})
    assert test_value == {'one': "two", 'three': "four"}

    # Expect a list of objects

# Generated at 2022-06-11 01:02:34.388940
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # create mock object
    class Bar:
        __UNSAFE__ = True
    class Foo:
        bar = Bar()
        baz = Bar()
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    # check output of method default
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert json_encoder.default(Foo())=={'bar': '', 'baz': ''}
    # create mock object
    class Bar:
        __UNSAFE__ = True
    class Foo:
        bar = Bar()
        baz = Bar()
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    # check output of method default
    json_encoder = Ansible

# Generated at 2022-06-11 01:02:43.313590
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultEditor, VaultSecret, VaultAES256
    ansible_date = datetime.date(2016, 11, 20)
    ansible_unsafe = AnsibleUnsafe('string')
    ansible_vault = AnsibleVault('ansible_vault', 'VaultAES256', 1)
    ansible_dict = AnsibleDict({'name': 'ansible_dict'})
    ansible_list = AnsibleList([1, 2, 3])
    # Ensure AnsibleJSONEncoder works with a complex object

# Generated at 2022-06-11 01:03:02.082696
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import basic
    from ansible.module_utils.six import text_type

    ansible_json_encoder = AnsibleJSONEncoder()

    # test for class datetime.date
    date_obj = basic.AnsibleUnsafeDateTime(2015, 8, 18)
    date_obj_return = ansible_json_encoder.default(date_obj)
    assert isinstance(date_obj_return, text_type)
    assert date_obj_return == '2015-08-18'

    # test for class datetime.datetime
    datetime_obj = basic.AnsibleUnsafeDateTime(2015, 8, 18, 0, 18)
    datetime_obj_return = ansible_json_encoder.default(datetime_obj)

# Generated at 2022-06-11 01:03:10.657478
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Unit test to verify the default method of AnsibleJSONEncoder
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText

    vault_password = 'hello world'
    vault_obj = VaultLib([('default', vault_password)])
    with vault_obj.locked():
        vault_str = vault_obj.encrypt('hello world')
        vault_bytes = vault_obj.encrypt('hello world'.encode('utf-8'))

    unsafe_str = AnsibleUnsafe("password: '%s'" % vault_str)
    unsafe_bytes = AnsibleUnsafe("password: '%s'" % vault_bytes)

    assert isinstance(unsafe_str, AnsibleUnsafeText)

# Generated at 2022-06-11 01:03:21.596511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert json.loads(json.dumps(dict(test=str(datetime.datetime.now())), cls=encoder)) == dict(test='now')
    assert json.loads(json.dumps(dict(test=datetime.datetime.now()), cls=encoder))['test'] == 'now'
    assert json.loads(json.dumps(dict(test=str(datetime.date.today())), cls=encoder)) == dict(test='today')
    assert json.loads(json.dumps(dict(test=datetime.date.today()), cls=encoder))['test'] == 'today'


# Generated at 2022-06-11 01:03:31.128687
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    import unittest
    import ansible

    class SampleClass(object):
        pass

    class SampleClassWithVault(ansible.parsing.vault.VaultLib):
        """Simulate a class which is inherited from ansible.parsing.vault.VaultLib"""
        pass

    class SampleClassWithUnsafe(ansible.parsing.vault.VaultSecret):
        """Simulate a class which is inherited from ansible.parsing.vault.VaultSecret"""
        pass

    class SampleClassUnicode(object):
        def __unicode__(self):
            return u'Łódź'

    class SampleClassStr(object):
        def __str__(self):
            return u'Łódź'


# Generated at 2022-06-11 01:03:42.340775
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps({'__unsafe__': 'secret'}, cls=AnsibleJSONEncoder) == '{"__unsafe__": "secret"}'
    assert json.dumps({'__encrypt__': 'secret'}, cls=AnsibleJSONEncoder) == '{"__encrypt__": "secret"}'
    assert json.dumps({'__encrypt__': 'secret'}, cls=AnsibleJSONEncoder, vault_to_text=True) == '"secret"'
    assert json.dumps({'__date__': datetime.datetime(2019, 4, 28)}, cls=AnsibleJSONEncoder) == '{"__date__": "2019-04-28"}'

# Generated at 2022-06-11 01:03:50.123790
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default({'a': 'b'}) == {'a': 'b'}
    assert encoder.default(['a', 'b', 'c']) == ['a', 'b', 'c']
    assert encoder.default(['a', 'b', 'c', {'a': 'b'}]) == ['a', 'b', 'c', {'a': 'b'}]
    assert encoder.default({'a': 'b', 'c': 'd'}) == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-11 01:04:01.376852
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  
    json_str = json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder)
    assert json_str == '{"foo": "bar"}'

    json_str = json.dumps({'foo': ['bar',1]}, cls=AnsibleJSONEncoder)
    assert json_str == '{"foo": ["bar", 1]}'

    json_str = json.dumps({'foo': {"bar": 1}}, cls=AnsibleJSONEncoder)
    assert json_str == '{"foo": {"bar": 1}}'

    json_str = json.dumps(u'\u2713', cls=AnsibleJSONEncoder)
    assert json_str == '"\\u2713"'


# Generated at 2022-06-11 01:04:09.795446
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.module_utils.urls import open_url

    json_vault = AnsibleJSONEncoder().default(VaultLib(open_url=open_url).encrypt('my_text'))
    json_unsafe = AnsibleJSONEncoder().default(AnsibleUnsafe('my_text'))
    json_dict = AnsibleJSONEncoder().default({'key1': 'value1', 'key2': 'value2'})
    json_date = AnsibleJSONEncoder().default(datetime.datetime.now())
    json_text = AnsibleJSONEncoder().default("my_text")


# Generated at 2022-06-11 01:04:21.139686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    jsonEncoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    str_result = jsonEncoder.default('ansible')
    assert isinstance(str_result, (str, unicode))
    str_result = jsonEncoder.default('ansible'.encode('utf-8'))
    assert isinstance(str_result, (str, unicode))
    def obj_dict():
        o = Mapping()
        o['key1'] = 'value1'
        o['key2'] = 'value2'
        return o
    obj_dict_result = jsonEncoder.default(obj_dict())
    assert isinstance(obj_dict_result, (str, unicode)) # Should be a

# Generated at 2022-06-11 01:04:31.387984
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    ansible.module_utils.basic.AnsibleModule = None
    from ansible.module_utils.basic import AnsibleModule

    # dummy class
    class TestClass(object):
        pass

    obj = TestClass()
    obj.test = 'test'

    # datetime.date
    # datetime.datetime
    d = datetime.datetime.now()

# Generated at 2022-06-11 01:04:57.157025
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common._collections_compat import OrderedDict

    aje = AnsibleJSONEncoder()
    result = json.dumps(OrderedDict([('foo', 'bar'), ('baz', [1,2,3,4])]), cls=aje)
    assert isinstance(result, text_type)
    assert result == u'{"foo": "bar", "baz": [1, 2, 3, 4]}'

    result = json.dumps(OrderedDict([('foo', 'bar'), ('baz', datetime.date(2017, 7, 15))]), cls=aje)
    assert isinstance(result, text_type)
   

# Generated at 2022-06-11 01:05:06.850036
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    # vault_password is a unicode string
    vault_password = u'password'
    vault_password_bytes = b'password'
    vault_password_encoded = 'cGFzc3dvcmQ='

    # init a vault object
    vault = VaultLib([])
    vault_encrypted = vault.encrypt(vault_password)

    # test an instance of VaultPassword
    vault_password_object = VaultPassword(vault_password)
    result = AnsibleJSONEncoder.default(AnsibleJSONEncoder, vault_password_object)
    assert result == vault_password

    # test an instance of VaultSecret
    vault_

# Generated at 2022-06-11 01:05:15.826746
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).default(dict(a=None, b=True, c=1, d=1.1, e=[], f={}, g='string',
                              h=datetime.date(2020, 1, 1), i=datetime.datetime(2020, 1, 1, 1, 1)))
    assert value == {'a': None, 'b': True, 'c': 1, 'd': 1.1, 'e': [], 'f': {}, 'g': 'string',
                     'h': '2020-01-01', 'i': '2020-01-01T01:01:00'}

# Generated at 2022-06-11 01:05:26.299703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test(o, expected_result):
        result = AnsibleJSONEncoder().default(o)
        assert result == expected_result

    test(dict(a="b"), dict(a="b"))
    test(datetime.datetime(2019, 1, 1, 1, 2, 3), '2019-01-01T01:02:03')
    test(datetime.date(2019, 1, 1), '2019-01-01')
    test(u'dummy', 'dummy')
    test(3, 3)
    test(3.4, 3.4)
    test(['a', 'b'], ['a', 'b'])
    test(None, None)
    test(True, True)
    test(False, False)


# Generated at 2022-06-11 01:05:31.332437
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Given an object o with it's _raw attribute equal to '{"foo": "bar"}'
    o = object()
    o._raw = '{"foo": "bar"}'

    aje = AnsibleJSONEncoder()

    # When AnsibleJSONEncoder.default(aje, o) is called
    json_obj = aje.default(o)

    # Then the string {"foo": "bar"} should be returned
    assert json_obj == json.loads(o._raw)



# Generated at 2022-06-11 01:05:36.619726
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_class = AnsibleJSONEncoder()
    class Test(object):
        unsafe = True
        vault = True
        pass

    test_class.default(Test())
    test_class.default(datetime.datetime.now())
    test_class.default(datetime.date.today())
    test_class.default(datetime.datetime.utcnow().day)

# Generated at 2022-06-11 01:05:48.511180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.constants as C

    encoder = AnsibleJSONEncoder()
    assert encoder.default(C.ANSIBLE_UNSAFE_TEXT) == {'__ansible_unsafe': 'unsafe string'}
    assert encoder.default({'foo': 'test'}) == {'foo': 'test'}
    assert encoder.default('test') == 'test'
    assert encoder.default(5) == 5
    assert encoder.default(False) == False
    assert encoder.default(None) == None

    import ansible.parsing.vault as vault
    encoder = AnsibleJSONEncoder()
    vault_str = 'my vault string'

# Generated at 2022-06-11 01:05:56.325167
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(True) is True
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default({'key': 'value'}) == {'key': 'value'}
    assert AnsibleJSONEncoder().default(datetime.datetime(1990, 12, 25, 0, 0)) == '1990-12-25T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.date(1990, 12, 25)) == '1990-12-25'

# Generated at 2022-06-11 01:06:04.216447
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = [
        {
            'input': {'key': 'value'},
            'expected_result': {'key': 'value'},
        },
        {
            'input': datetime.date(2011, 2, 3),
            'expected_result': "2011-02-03",
        },
        {
            'input': datetime.datetime(2011, 2, 3, 21, 15, 0),
            'expected_result': "2011-02-03T21:15:00",
        },
    ]
    for data in test_data:
        encoder = AnsibleJSONEncoder()
        assert encoder.default(data['input']) == data['expected_result']

# Generated at 2022-06-11 01:06:11.687035
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common.collections import ImmutableDict

    assert json.dumps(AnsibleUnsafe("value"), cls=AnsibleJSONEncoder) == json.dumps({'__ansible_unsafe': to_text('value', errors='surrogate_or_strict', nonstring='strict')})
    assert json.dumps(ImmutableDict(dict(key='value')), cls=AnsibleJSONEncoder) == json.dumps({'key': 'value'})

    # Unit test for method iterencode of class AnsibleJSONEncoder


# Generated at 2022-06-11 01:06:52.089092
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.dataloader
    v = ansible.parsing.dataloader.DataLoader().load_from_file('./test/fixture/format/unsafe_mixed')
    assert json.dumps(v, cls=AnsibleJSONEncoder, sort_keys=True) == b'{"k1": "v1", "k2": "v2", "v": {"k1": "v1", "k2": "v2", "v": "v", "v_b": [true, false, true], "v_d": {"k1": "v1", "k2": "v2"}}}'


# Generated at 2022-06-11 01:06:59.326741
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the default method, because it will decide how the the object o will be encoded.
    # Here the default method will call json.JSONEncoder.default, so need to test the method default of class JSONEncoder
    test_data = dict(a=10, b=20, c=30)
    a = AnsibleJSONEncoder()
    a._preprocess_unsafe = False
    a._vault_to_text = True
    assert a.default(test_data) == dict(a=10, b=20, c=30)

# Generated at 2022-06-11 01:07:09.378454
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import base64
    from ansible.parsing.vault import VaultLib
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafe2(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    class AnsibleVault2(str):
        __ENCRYPTED__ = True

    class AnsibleVault3(str):
        __ENCRYPTED__ = True

    class AnsibleVault4(str):
        __ENCRYPTED__ = True


    assert AnsibleJSONEncoder().default(AnsibleUnsafe('hello world')) == \
        {'__ansible_unsafe': 'hello world'}


# Generated at 2022-06-11 01:07:15.019472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test when o is a datetime.datetime instance
    o = datetime.datetime.strptime("2019-06-12T20:41:20", "%Y-%m-%dT%H:%M:%S")
    aje = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert aje.default(o) == "2019-06-12T20:41:20"


# Generated at 2022-06-11 01:07:23.362847
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.urls import register_type, urllib_error
    from ansible.parsing.vault import VaultLib

    register_type('unsafe', AnsibleUnsafe)
    register_type('vault', VaultLib())

    assert AnsibleJSONEncoder().default(AnsibleUnsafe('test')) == {'__ansible_unsafe': 'test'}
    assert AnsibleJSONEncoder().default('test') == 'test'
    assert AnsibleJSONEncoder().default(urllib_error.URLError('test')) == {'reason': 'test', 'url': None}
    assert AnsibleJSONEncoder().default({'test': 'test'}) == {'test': 'test'}
    assert Ansible

# Generated at 2022-06-11 01:07:33.418360
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.basic import AnsibleUnsafe

    d = datetime.datetime(2018, 2, 17, 0, 0, 0)
    s = AnsibleUnsafe(u'foö')
    b = binary_type(s, 'utf-8')
    a = AnsibleUnsafe(b)
    o = {'foo': 'bar', 'a': a, 'b': b, 's': s, 'd': d}
    assert json.loads(json.dumps(o, cls=AnsibleJSONEncoder, preprocess_unsafe=True)) == o
    o['a'] = dict(a)
    o['b'] = dict(b)
    o['s'] = dict(s)

# Generated at 2022-06-11 01:07:43.110452
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.removed import RemovedModule

    encoded_vault = '{\"__ansible_vault\": \"$ANSIBLE_VAULT;1.1;AES256;foo\\r\\nbar\\r\\n\"}'
    encoded_unsafe = '{\"__ansible_unsafe\": \"foo\\r\\nbar\"}'

    json_encoded_vault = json.dumps('$ANSIBLE_VAULT;1.1;AES256;foo\r\nbar\r\n',
                                    cls=AnsibleJSONEncoder,
                                    sort_keys=True,
                                    ensure_ascii=False)

# Generated at 2022-06-11 01:07:52.737987
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import StringIO
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.hostvars import HostVars
    import json

    with_unsafe = {'one': AnsibleUnsafe(u'ß')}
    with_hostvars = {'one': HostVars()}
    with_date = {'one': datetime.date(2001, 1, 1)}
    with_datetime = {'one': datetime.datetime(2001, 1, 1)}

    out = StringIO()
    json.dump(with_unsafe, out, cls=AnsibleJSONEncoder, preprocess_unsafe=True)

# Generated at 2022-06-11 01:08:00.943472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    r = aje.encode(AnsibleUnsafe('{"foo": "bar"}'))
    assert r == '"{\\"foo\\": \\"bar\\"}"', r

    r = aje.encode(AnsibleUnsafe('{"foo": "bar"}', __ansible_vault=True))
    assert r == '"{\\"foo\\": \\"bar\\"}"', r

    r = aje.encode(AnsibleVaultSecret(b'aaaaaa'))
    assert r == '{"__ansible_vault": "YWFhYWFh"}', r

    r = aje.encode(datetime.datetime(2020, 6, 20, 10, 11, 12))

# Generated at 2022-06-11 01:08:09.244398
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = {
        'at_unsafe': 'test',
        'at_vault': 'test',
        'at_unsafe_vault': 'test',
        'dictkey_unsafe': {'key': 'test'},
        'listkey_unsafe': [{'key': 'test'}],
        'dictvalue_vault': {'key': 'test'},
        'listvalue_vault': ['test'],
        'dictboth_vault': {'key': 'test'},
        'listboth_vault': ['test'],
    }
    j = AnsibleJSONEncoder().encode(d)