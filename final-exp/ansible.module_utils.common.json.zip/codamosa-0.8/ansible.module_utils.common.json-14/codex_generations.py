

# Generated at 2022-06-11 00:58:06.505620
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import b
    from ansible.utils.unsafe_proxy import Ansi

# Generated at 2022-06-11 00:58:12.653072
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Test function for AnsibleJSONEncoder
    :return:
    '''

# Generated at 2022-06-11 00:58:23.063018
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import b, binary_type, text_type
    from ansible.module_utils.urls import ConnectionError, urlencode

    # int, float, bool, string and None are not tested,
    # as these are already tested in json module

# Generated at 2022-06-11 00:58:33.600465
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.six import string_types
    from ansible.parsing.vault import VaultLib

    test_datas = [
        (datetime.date(2019, 1, 2), '2019-01-02'),
        (datetime.datetime(2019, 1, 2, 3, 4, 5), '2019-01-02T03:04:05'),
        (VaultLib('test'), string_types),  # vault object
    ]

    for data, expect_type in test_datas:
        assert isinstance(json.dumps(data, cls=AnsibleJSONEncoder), expect_type)
        # io object
        io = BytesIO()

# Generated at 2022-06-11 00:58:40.733494
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import ANSIBALLZ_SUPPORTED
    if ANSIBALLZ_SUPPORTED:
        import ansible.archive.tar
        ansible_tar_class = ansible.archive.tar.AnsibleTarFile
    else:
        ansible_tar_class = None

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    # create a vault object
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([], None)
    vault_text = "vault test string"
    vault_obj = vault.encrypt(vault_text)

    # create a display object
    display_obj = display


# Generated at 2022-06-11 00:58:52.660134
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create a AnsibleJSONEncoder object
    aje = AnsibleJSONEncoder()

    # Test if the type is AnsibleVaultEncryptedUnicode or AnsibleVaultEncryptedBytes
    assert aje.default(type('123')) == '123'
    # Test if the type is AnsibleUnsafe
    assert aje.default(type('123'.encode())) == b'123'
    assert aje.default(type('123',)) == '123'
    # Test if the type is mapping
    assert aje.default(type({'123': 123})) == {'123': 123}
    # Test if the type is datetime.date
    assert aje.default(type(datetime.date(2019, 1, 1))) == '2019-01-01'
    # Test if the type is datetime.datetime

# Generated at 2022-06-11 00:59:02.835252
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    sentinel = object()

    # Test for vault
    vault_obj = sentinel
    vault_obj.__ENCRYPTED__ = True
    vault_obj._ciphertext = b'encrypted_content'

    # Test for unsafe text
    unsafe_obj = sentinel
    unsafe_obj.__UNSAFE__ = True

    # Test for dictionary
    dict_obj = {
        'foo': 'bar',
    }

    # Test for sequence
    seq_obj = [
        {
            'one': 'two',
        },
        {
            'three': 'four',
        }
    ]

    # Test for date
    date_obj = datetime.date(2018, 10, 9)

    json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert json_encoder

# Generated at 2022-06-11 00:59:14.494315
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # id(object) is unique for every object
    assert encoder.default(id) == id
    assert encoder.default(Exception()) == {u'traceback': u'<module \'traceback\' from \'/usr/lib/python2.7/traceback.pyc\'>\nTraceback (most recent call last):\n  File "<stdin>", line 1, in <module>\n',
                                           u'msg': u'Exception: '}
    assert encoder.default(to_text(u'\u2192', errors='surrogate_or_strict')) == u'\u2192'
    assert encoder.default(to_text(u'\u2192', errors='surrogate_or_strict', nonstring='simplerepr'))

# Generated at 2022-06-11 00:59:22.971226
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY3

    # Test class with custom ___repr__
    class MyClass:
        def __init__(self, name):
            self.name = name
        def __repr__(self):
            return 'MyClass("%s")' % self.name

    # Test class with custom __dict__
    class MyClass2:
        def __init__(self, name):
            self.name = name
        @property
        def __dict__(self):
            return {'name': self.name}

    # Test class with custom __getattribute__
    class MyClass3:
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-11 00:59:34.566471
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type, string_types

    class B(binary_type):
        pass

    class S(string_types[0]):
        pass

    assert json.loads(json.dumps(B(b'foo'))) == 'foo'
    assert json.loads(json.dumps(S('foo'))) == 'foo'

    # NOTE: there are no supported scenarios where we would encode a instance of ``AnsibleUnsafe``
    #       as the ``AnsibleUnsafe`` subclasses inherit from string types and ``json.JSONEncoder``
    #       does not support custom encoders for string types.  ``_preprocess_unsafe_encode``
    #       needs to be used upstream to handle encoding instances of ``AnsibleUnsafe``


# Generated at 2022-06-11 00:59:46.618081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # date object
    date_obj = datetime.date(year=2019, month=3, day=12)
    assert AnsibleJSONEncoder().default(date_obj) == "2019-03-12"

    # unsafe object
    unsafe_obj = "__ansible_unsafe__: was here"
    assert AnsibleJSONEncoder().default(unsafe_obj) == "__ansible_unsafe__: was here"

    # vault object
    vault_obj = "__ansible_vault__: was here"
    assert AnsibleJSONEncoder().default(vault_obj) == "__ansible_vault__: was here"


# Generated at 2022-06-11 00:59:58.204950
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Old style class, need to use old style instance method
    # pylint: disable=no-value-for-parameter
    output = AnsibleJSONEncoder.default(AnsibleJSONEncoder(), 'test')
    assert output == 'test'

    # Test AnsibleUnsafe
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret

    vault = VaultEditor(None, None)
    secret = VaultSecret(VaultSecret.AES256, b'0123456789abcdef', '$ANSIBLE_VAULT;1.2;AES256;ansible\n0123456789abcdef\n', vault)
    output = AnsibleJSONEncoder.default(AnsibleJSONEncoder(), secret)
    assert output['__ansible_vault']

# Generated at 2022-06-11 01:00:08.256386
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import _is_encrypted
    from ansible_collections.ansible.community.plugins.module_utils.basic import AnsibleUnsafe

    # data to test: AnsibleVaultEncryptedUnicode, AnsibleUnsafe, dict,
    # datetime.datetime, other

# Generated at 2022-06-11 01:00:20.337883
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:00:31.109530
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps("password", cls=AnsibleJSONEncoder)) == "password"
    assert json.loads(json.dumps({"a": "password"}, cls=AnsibleJSONEncoder)) == {"a": "password"}


# Generated at 2022-06-11 01:00:36.133036
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsibleBaseEncoder.default
    assert AnsibleJSONEncoder.default('foo') == 'foo'
    assert AnsibleJSONEncoder.default(u'foo') == 'foo'
    assert AnsibleJSONEncoder.default({}) == {}
    assert AnsibleJSONEncoder.default([]) == []
    assert AnsibleJSONEncoder.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert AnsibleJSONEncoder.default(['foo', 'bar']) == ['foo', 'bar']
    assert AnsibleJSONEncoder.default(dict(foo='bar')) == {'foo': 'bar'}
    assert AnsibleJSONEncoder.default(dict(foo=u'bar')) == {'foo': 'bar'}

# Generated at 2022-06-11 01:00:48.706448
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    a = 'ansible'
    assert AnsibleJSONEncoder().default(a) == 'ansible'
    assert AnsibleJSONEncoder(ensure_ascii=False).default(a) == 'ansible'
    b = {'ansible': {'ansible': 'ansible'}}
    assert AnsibleJSONEncoder().default(b) == {'ansible': {'ansible': 'ansible'}}
    assert AnsibleJSONEncoder(ensure_ascii=False).default(b) == {'ansible': {'ansible': 'ansible'}}
    c = datetime.datetime(2016, 10, 30, 12, 30)
    assert AnsibleJSONEncoder().default(c) == '2016-10-30T12:30:00'

# Generated at 2022-06-11 01:00:58.300959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    assert(json.dumps(VaultLib('test'), cls=AnsibleJSONEncoder) == '"VaultLib"')
    assert(json.dumps(VaultSecret('test'), cls=AnsibleJSONEncoder) == '"VaultSecret"')
    assert(json.dumps(AnsibleUnsafe('test'), cls=AnsibleJSONEncoder) == "{'__ansible_unsafe': 'test'}")

# Generated at 2022-06-11 01:01:04.608468
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('unsafe')) == u'unsafe'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(b'unsafe')) == u'unsafe'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe(u'unsafe')) == u'unsafe'


# Generated at 2022-06-11 01:01:13.404393
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault_mod

    d = dict(key='value', unsafe=vault_mod.AnsibleUnsafeText('unsafe'), safe=vault_mod.AnsibleVaultEncryptedUnicode('safe'))
    e = AnsibleJSONEncoder(preprocess_unsafe=True)
    json_str = e.encode(d)

    import json
    o = json.loads(json_str)

    assert o == dict(key='value', unsafe=dict(__ansible_unsafe='unsafe'), safe=dict(__ansible_vault=b'safe'))

# Generated at 2022-06-11 01:01:24.869604
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Test case for method default of class AnsibleJSONEncoder'''
    from ansible.parsing.vault import VaultLib

    # Initialize the VaultLib object, which also creates a random seed file
    ansible_vault = VaultLib(password='password')

    # Encrypt "password" using the random seed
    vault_password = ansible_vault.encrypt('password')

    # Specify the supported data types by Ansible
    data = {"vault_password": vault_password, "hostvars": {"hostA": {"ansible_host": 1}}, "date": datetime.datetime.now()}

    # Call method default of class AnsibleJSONEncoder
    data = AnsibleJSONEncoder(sort_keys=True, indent=2).default(data)

    # Assert the data type of the encrypted password,

# Generated at 2022-06-11 01:01:36.444064
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleJSONEncoder(unittest.TestCase):

        def setUp(self):
            self.vault_password = '$ANSIBLE_VAULT;1.1;AES256\n336536346266633633323731623566353036316137613261623136623361323963303966326233636\n39633938333837303534396365616639653666616333393562316262\n'
            self.plaintext_data = 'John Wayne'

# Generated at 2022-06-11 01:01:45.373947
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # test without __ENCRYPTED__
    assert encoder.default('test_string') == 'test_string'
    # test with __ENCRYPTED__ = true and vault_to_text = false
    encoder = AnsibleJSONEncoder(vault_to_text=False)
    test = AnsibleUnsafe('test_string')
    test.__ENCRYPTED__ = True
    assert encoder.default(test) == {'__ansible_vault': 'test_string'}
    # test with __ENCRYPTED__ = true and vault_to_text = true
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert encoder.default(test) == 'test_string'
    # test with __UN

# Generated at 2022-06-11 01:01:56.068865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # def __init__(self, preprocess_unsafe=False, vault_to_text=False, **kwargs):
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    assert json.dumps({'a': 'b'}, cls=encoder) == '{"a": "b"}'

    from ansible.parsing.vault.VaultLib import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256GCM
    from ansible.parsing.vault import VaultSecret

# Generated at 2022-06-11 01:02:06.631602
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # normal string as input
    normal_input = 'foobar'
    assert AnsibleJSONEncoder().default(normal_input) == 'foobar'

    # vault object as input
    vault_input = VaultAES256(b'some_cipher_text')
    # vault object is an instance of str, so default() is called
    assert AnsibleJSONEncoder().default(vault_input) == {'__ansible_vault': 'some_cipher_text'}

    # hostvars object as input
    hostvars_input = HostVars(host=MagicMock())
    assert AnsibleJSONEncoder().default(hostvars_input) == {}

    # date object as input
    date_input = datetime.date(1978, 10, 31)
    assert AnsibleJSONEncoder().default(date_input)

# Generated at 2022-06-11 01:02:18.960061
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().encode(None) == 'null'
    assert AnsibleJSONEncoder().encode(False) == 'false'
    assert AnsibleJSONEncoder().encode(True) == 'true'
    assert AnsibleJSONEncoder().encode([1, 2, 3]) == '[1, 2, 3]'
    assert AnsibleJSONEncoder().encode(['1', '2', '3']) == '["1", "2", "3"]'
    assert AnsibleJSONEncoder().encode({1: '2', 2: '3'}) == '{"1": "2", "2": "3"}'
    assert AnsibleJSONEncoder().encode({'1': 2, '2': 3}) == '{"1": 2, "2": 3}'

# Generated at 2022-06-11 01:02:27.975972
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_text, to_bytes
    from ansible import module_utils

    # store a value in vault
    vault_password = to_bytes(u'vmware')
    vault = VaultLib(vault_password)
    ciphertext = vault.encrypt(to_bytes(u'ansible'))

    # create an ansible vault object
    ansible_vault = module_utils.basic.AnsibleVaultEncryptedUnicode(ciphertext)
    # create an ansible unsafe object
    ansible_unsafe = module_utils.basic.AnsibleUnsafe(u'ansible')
    # create a date object
    date = datetime.date.today()
    # create a dict object
    dict = module

# Generated at 2022-06-11 01:02:34.410704
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    json_encoder = AnsibleJSONEncoder()

    # Test case: when o is a Mapping
    o = {'a': 1}
    ret = json_encoder.default(o)
    assert ret == {'a': 1}

    # Test case: when o is a datetime object
    o = datetime.datetime(2020, 2, 17, 9, 30)
    ret = json_encoder.default(o)
    assert ret == '2020-02-17T09:30:00'

    # Test case: when o is a date object
    o = datetime.date(2020, 2, 17)
    ret = json_encoder.default(o)
    assert ret == '2020-02-17'

    # Test case: when o is an int
    o = 1

# Generated at 2022-06-11 01:02:37.999748
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.hostvars import HostVars

    test_host_vars = HostVars({"foo": 1})
    assert AnsibleJSONEncoder().default(test_host_vars) == {"foo": 1}


# Generated at 2022-06-11 01:02:43.006066
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    with open("tests/unit/module_utils/json_encoder_unittest.json", 'rb') as f:
        data = f.read()

    json_data = json.loads(data)
    ansiblejson_data = json.loads(AnsibleJSONEncoder().encode(json_data))
    text_data = to_text(json.dumps(json_data))
    assert ansiblejson_data == json.loads(text_data)

# Generated at 2022-06-11 01:02:50.958292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    assert(str(json_encoder.default(None))) == "null"



# Generated at 2022-06-11 01:03:01.780060
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    #
    # Test case: standard use case: encode an instance of class AnsibleUnsafe
    #
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    unsafe = AnsibleUnsafe("AnsibleUnsafe")
    ansible_json_encoder = AnsibleJSONEncoder()
    json_str = ansible_json_encoder.encode(unsafe)
    if json_str != '{"__ansible_unsafe": "AnsibleUnsafe"}':
        raise AssertionError("Wrong JSON string for AnsibleUnsafe: {}".format(json_str))

    #
    # Test case: standard use case: encode a list that contains an instance of class AnsibleUnsafe
    #
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    unsafe = AnsibleUn

# Generated at 2022-06-11 01:03:10.503703
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for instances of AnsibleUnsafe
    result = AnsibleJSONEncoder(ensure_ascii=False, sort_keys=False).encode({
        'unsafe': AnsibleJSONEncoder.default(AnsibleJSONEncoder(''), '')}
    )
    assert '"__ansible_unsafe": ""' in result

    # test for instances of AnsibleVaultEncryptedUnicode
    result = AnsibleJSONEncoder(ensure_ascii=False, sort_keys=False).encode({
        'unsafe': AnsibleJSONEncoder.default(AnsibleJSONEncoder(''), '')}
    )
    assert '"__ansible_unsafe": ""' in result

    # test for instances of AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 01:03:22.980455
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o1 = 'ansible_safe_string'
    obj = AnsibleJSONEncoder()
    assert obj.default(o1) == o1

    class AnsibleUnsafe:
        def __init__(self, value):
            self._value = value

        def __str__(self):
            return self._value

        __UNSAFE__ = True
        __ENCRYPTED__ = False

    o2 = AnsibleUnsafe('unsafe_string')
    assert obj.default(o2) == {'__ansible_unsafe': u'unsafe_string'}

    class AnsibleVault:
        def __init__(self, value):
            self._value = value

        def __str__(self):
            return self._value

        __UNSAFE__ = False

# Generated at 2022-06-11 01:03:31.703258
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_secret = VaultSecret(b'123', VaultPassword('123'))
    vault_obj = VaultLib([vault_secret])


# Generated at 2022-06-11 01:03:42.930280
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # format:
    # (replacement_value, value_to_test)
    replacements = [
        ('{}', {}),
        ('[]', []),
        ('["a","b"]', ['a', 'b']),
        ('{"a":"b"}', {'a': 'b'}),
        ('10', 10),
        ('4.4', 4.4),
        ('true', True),
        ('false', False),
        ('null', None),
    ]

    # test non-ansible types
    for (result, value) in replacements:
        assert json.dumps(value, cls=AnsibleJSONEncoder) == result

    # test ansible types

# Generated at 2022-06-11 01:03:50.676921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''Test method default of class AnsibleJSONEncoder'''
    import datetime
    from ansible.parsing.vault import VaultLib

    input_vault = VaultLib('password', 'ansible-vault ', True)
    input_vault._ciphertext = 'abcdefghijklmnopqrstuvwxyz1234567890'

    input_unsafe = u'foo \u0CA0_\u0CA0 bar'
    input_unsafe = to_text(input_unsafe, errors='surrogate_or_strict')
    input_unsafe.__UNSAFE__ = True

    input_hostname = 'test.example.com'
    input_host_vars = {'ansible_hostname': input_hostname}


# Generated at 2022-06-11 01:04:02.363988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class MyEncoder(json.JSONEncoder):
        def default(self, o):
            if getattr(o, '__UNSAFE__', False):
                return {'__ansible_unsafe': o}
            return None

    # Test for AnsibleUnsafe
    cls = getattr(VaultLib(), '__class__')
    obj = cls()
    ansible_encoder = MyEncoder()
    assert ansible_encoder.default(obj) == {'__ansible_unsafe': obj}

    # Test for AnsibleUnsafeText
    obj = cls().encrypt('foo')
    assert ansible_encoder.default(obj) == {'__ansible_unsafe': obj}

    # Test for str

# Generated at 2022-06-11 01:04:13.838191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_json_dict = {'key': 'value', 'key2': 2, 'key3': '3'}

    # test for simple dict
    assert AnsibleJSONEncoder().default(test_json_dict) == test_json_dict

    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # test for vault object
    vault_text = '$ANSIBLE_VAULT;1.1;AES256'
    vault_decrypt_text = 'vault_decrypt_text'
    vault = VaultLib([], len(vault_decrypt_text), 1).decrypt(vault_text)
    assert AnsibleJSONEncoder().default(vault) == {'__ansible_vault': vault_text}
    assert Ansible

# Generated at 2022-06-11 01:04:21.702410
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('abc') == 'abc'
    assert AnsibleJSONEncoder().default(123) == 123
    assert AnsibleJSONEncoder().default(None) == 'null'
    assert AnsibleJSONEncoder().default(True) == 'true'
    assert AnsibleJSONEncoder().default(False) == 'false'

    with pytest.raises(TypeError):
        AnsibleJSONEncoder().default(set())

    with pytest.raises(TypeError):
        AnsibleJSONEncoder().default(dict)

# Generated at 2022-06-11 01:04:36.753979
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.common.collections import is_sequence

    class TestClass(object):
        '''
        An object that looks like a dict, but is not a dict.
        '''
        def __init__(self, d):
            self.d = d
        def __getitem__(self, k):
            return self.d[k]
        def __setitem__(self, k, v):
            self.d[k] = v
        def __contains__(self, k):
            return k in self.d
        def __iter__(self):
            return iter(self.d)
        def items(self):
            return self.d.items()

    test_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:04:47.651682
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test default value
    test_object = {}
    assert AnsibleJSONEncoder().default(test_object) == {}

    # Test __ENCRYPTED__
    test_object = AnsibleUnsafe('')
    assert AnsibleJSONEncoder().default(test_object) == {}

    test_object = AnsibleVault('')
    assert AnsibleJSONEncoder().default(test_object) == {}

    # Test non-string type
    test_object = 5
    assert AnsibleJSONEncoder().default(test_object) == 5

    test_object = 5.5
    assert AnsibleJSONEncoder().default(test_object) == 5.5

    test_object = [1, 2, 3]
    assert AnsibleJSONEncoder().default(test_object) == [1, 2, 3]

    test

# Generated at 2022-06-11 01:04:57.465491
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    vault_obj = VaultLib('pass1234')
    enc = AnsibleJSONEncoder(vault_to_text=False)

# Generated at 2022-06-11 01:05:07.034151
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ''' test AnsibleJSONEncoder default method '''

    from ansible import constants as C
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_manager
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    # create vault password
    password = 'password'

    # create vault object
    vault = VaultLib(password)
    ciphertext = vault.encrypt('Vault')

    # create json encoder
    json_encoder = AnsibleJSONEncoder()

    # test __ENCRYPTED__
    json_text = json.dumps(vault, default=json_encoder.default, sort_keys=True, indent=4)
    json_loaded = json.loads(json_text)

# Generated at 2022-06-11 01:05:17.444259
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test default() with an AnsibleUnsafeText object
    unsafe = 'this is an unsafe string'
    ansibleunsafetext = AnsibleUnsafeText(unsafe)
    # create an AnsibleJSONEncoder object with a custom vault_to_text option set to True
    ansiblejsonencoder = AnsibleJSONEncoder(vault_to_text=True)
    # test with AnsibleUnsafeText object
    assert isinstance(ansiblejsonencoder.default(ansibleunsafetext), str)
    assert ansiblejsonencoder.default(ansibleunsafetext) == 'this is an unsafe string'
    # test with string
    assert isinstance(ansiblejsonencoder.default('this is also an unsafe string'), str)

# Generated at 2022-06-11 01:05:28.484140
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    ansible_json_encoder = AnsibleJSONEncoder()
    # test for vault object of class VaultLib
    vault_lib = VaultLib([])

# Generated at 2022-06-11 01:05:35.560219
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import re
    import unittest

    class Test1(object):
        __ENCRYPTED__ = True
        def __init__(self, d):
            self._ciphertext = d['data']

    class Test2(object):
        __UNSAFE__ = True
        def __init__(self, d):
            self.data = d['data']

    class Test3(object):
        __ENCRYPTED__ = False
        __UNSAFE__ = True
        def __init__(self, d):
            self.data = d['data']

    class TestAnsibleJSONEncoder(unittest.TestCase):

        def test_encode_default_vault(self):
            o = Test1({'data': '123456789'})

# Generated at 2022-06-11 01:05:47.361093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dt = datetime.date(1970, 1, 1)

    # vault object
    assert AnsibleJSONEncoder().default(dict(a=1, __ENCRYPTED__=True)) == {'a': 1, '__ansible_vault': ''}
    assert AnsibleJSONEncoder(vault_to_text=True).default(dict(a=1, __ENCRYPTED__=True)) == {'a': 1}

    # unsafe object
    assert AnsibleJSONEncoder().default(dict(a=1, __UNSAFE__=True)) == {'a': 1, '__ansible_unsafe': ''}

    # hostvars object
    assert AnsibleJSONEncoder().default(dict(a=1, b=2)) == {'a': 1, 'b': 2}

    # date object

# Generated at 2022-06-11 01:05:54.968916
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Check for default string return for type data"""
    astr = "Hello world"
    aint = 5
    adict = {"bike": "yamaha", "car": "lamborgini"}
    alist = ["Hello", "World"]
    adate = datetime.date(2020, 9, 10)

    assert AnsibleJSONEncoder().default(astr) == astr
    assert AnsibleJSONEncoder().default(aint) == aint
    assert AnsibleJSONEncoder().default(adict) == adict
    assert AnsibleJSONEncoder().default(alist) == alist
    assert AnsibleJSONEncoder().default(adate) == adate.isoformat()

# Generated at 2022-06-11 01:06:04.129164
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:06:28.025303
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    import datetime

    # Test class
    class Test(object):
        def __init__(self, value):
            self.value = value

    # Test object to be encoded
    t = Test('value')
    d = {'key': 'value'}
    dt = datetime.datetime.utcnow()

    # Test cases

# Generated at 2022-06-11 01:06:31.772512
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # mock object
    o = {'__ansible_facts': {'some_fact': 'some_value'}}

    # create new object
    obj = AnsibleJSONEncoder()
    res = obj.default(o)

    # test result
    assert res == o



# Generated at 2022-06-11 01:06:41.139382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.constants as C
    from ansible.module_utils.six import string_types

    ansible_encoder = AnsibleJSONEncoder()

    value = {'a': ['string', 1, 'unicode', '\u00FF']}
    assert ansible_encoder.default(value) == value

    value = '\x00\x01\x02\x03\x04\x05'
    assert ansible_encoder.default(value) == '\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005'

    value = {'a': 'unsafe'}
    assert ansible_encoder.default(value) == value

    value = {'a': C.DEFAULT_VAULT_ID_MATCH}

# Generated at 2022-06-11 01:06:42.419334
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = AnsibleJSONEncoder().default(u"André Claß")
    assert data == 'André Claß'

# Generated at 2022-06-11 01:06:49.176067
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.common.text.encoders.safe_yaml import AnsibleUnsafe
    from ansible.module_utils.common.text.encoders.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test for vault object
    vault_lib = VaultLib(VaultSecret('hunter2', 'secret'))
    value_vault = AnsibleJSONEncoder().default(vault_lib)

# Generated at 2022-06-11 01:06:59.529560
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def _assert_klass_encode(klass, value):
        _json = json.dumps(klass(value), cls=AnsibleJSONEncoder)
        _value = json.loads(_json)
        assert _value['__ansible_unsafe'] == to_text(value, errors='surrogate_or_strict', nonstring='strict')

    # test for class AnsibleUnsafeText
    from ansible.module_utils.parsing.convert_bool import AnsibleUnsafeText
    _assert_klass_encode(AnsibleUnsafeText, "I'm ansible unsafe text.")

    # test for class AnsibleUnsafeBytes
    from ansible.module_utils.parsing.convert_bool import AnsibleUnsafeBytes

# Generated at 2022-06-11 01:07:02.129863
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.datetime.utcnow())
    assert AnsibleJSONEncoder().default(datetime.datetime.utcnow().date())

# Generated at 2022-06-11 01:07:11.561701
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test with datetime
    dt = datetime.datetime(year=2016, month=1, day=1, hour=0, minute=0, second=1)
    assert AnsibleJSONEncoder().default(dt) == '2016-01-01T00:00:01'

    # Test with mapping
    dt = datetime.datetime(year=2016, month=1, day=1, hour=0, minute=0, second=1)
    mapping = {'a': dt}
    result = AnsibleJSONEncoder().default(mapping)
    assert '2016-01-01T00:00:01' in result.values()

    # Test with AnsibleVault

# Generated at 2022-06-11 01:07:17.778070
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # Define a dict with datetime object to test the method default
    date_dict = {'DATE': datetime.datetime(2019, 6, 4, 17, 0)}
    # Define a dict with datetime object to test the method default
    date_dict_actual_result = {'DATE': '2019-06-04T17:00:00'}
    assert encoder.default(date_dict) == date_dict_actual_result



# Generated at 2022-06-11 01:07:26.217600
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class Foo(object):
        pass

    fooObject = Foo()
    fooObject.__UNSAFE__ = True
    fooObject.__ENCRYPTED__ = True

    fooObject.__ENCRYPTED__ = True
    fooObject._ciphertext = "ciphertext"
    assert AnsibleJSONEncoder().default(fooObject) == {'__ansible_vault': 'ciphertext'}

    fooObject.__UNSAFE__ = False
    assert AnsibleJSONEncoder().default(fooObject) == {'__ansible_vault': 'ciphertext'}

    fooObject.__ENCRYPTED__ = False
    assert AnsibleJSONEncoder().default(fooObject) == {}

    fooObject.__UNSAFE__ = True

# Generated at 2022-06-11 01:08:01.525798
# Unit test for method default of class AnsibleJSONEncoder