

# Generated at 2022-06-11 00:58:13.472157
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads(json.dumps(dict(a=3), cls=AnsibleJSONEncoder)) == {'a': 3}
    assert json.loads(json.dumps(datetime.datetime.now(), cls=AnsibleJSONEncoder))
    assert json.loads(json.dumps(datetime.date.today(), cls=AnsibleJSONEncoder))



# Generated at 2022-06-11 00:58:24.290229
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create AnsibleJSONEncoder object
    aje = AnsibleJSONEncoder()

    # Test with None type
    result = aje.default(None)
    assert result == None

    # Test with list
    result = aje.default([1, 2, 3])
    assert result == [1, 2, 3]

    # Test with dict
    result = aje.default({'a': 1, 'b': 2})
    assert result == {'a': 1, 'b': 2}

    # Test with datetime
    result = aje.default(datetime.datetime.now())
    assert result == datetime.datetime.now().isoformat()

    # Test with other types
    result = aje.default(10)
    assert result == 10

    result = aje.default('test_string')
    assert result

# Generated at 2022-06-11 00:58:34.851462
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an instance
    encoder = AnsibleJSONEncoder()

    # Verify that it does the right thing with a simple value
    assert encoder.default(True) == True

    # Verify that it does the right thing with a complex value
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import BorderVaultSecret
    ve = VaultEditor(VaultSecret(['password']), encrypt_vault=VaultLib([BorderVaultSecret('password')]), unlock_vault=VaultLib())

# Generated at 2022-06-11 00:58:40.949028
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils
    from ansible.parsing.vault import VaultLib

    e = AnsibleJSONEncoder()
    # test for __ENCRYPTED__
    c = VaultLib('mypass').encode('mysecret')
    assert '__ansible_vault' in e.default(c)
    # test for __UNSAFE__
    u = ansible.module_utils.basic.AnsibleUnsafe(None, None)
    assert '__ansible_unsafe' in e.default(u)
    # test for Mapping
    assert e.default({}) == {}
    # test for date object
    assert e.default(datetime.date.today()) == datetime.date.today().isoformat()



# Generated at 2022-06-11 00:58:52.906100
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import datetime
    test_unsafe = 'test_unsafe'
    test_encrypted = 'test_encrypted'
    test_vault = VaultLib.new_vault_password(VaultSecret(test_encrypted), '')
    test_dict = {'test_dict': 'test_dict'}
    test_date = datetime.datetime(2017, 1, 1, 9, 0, 0)
    test_int = 1
    test_str = 'test_str'

    assert AnsibleJSONEncoder().default(test_unsafe) == test_unsafe
    assert AnsibleJSONEncoder(vault_to_text=True).default(test_vault) == test_encrypted
    assert Ans

# Generated at 2022-06-11 00:59:03.057229
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test safe string
    try:
        json.dumps(u'safe', cls=AnsibleJSONEncoder)
        assert True
    except Exception:
        assert False

    # test unsafe string
    test_str = to_text(b'\x00\x01\x02', errors='surrogate_or_strict')
    test_str.__UNSAFE__ = True
    encoder = json.dumps(test_str, cls=AnsibleJSONEncoder)
    assert encoder == '{"__ansible_unsafe": "\\\\u0000\\\\u0001\\\\u0002"}'

    # test vault object
    from ansible.parsing.vault import VaultLib

    test_vault = VaultLib('TEST')

# Generated at 2022-06-11 00:59:14.697363
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    input_set = [
            {'complex_dict': {'<>': 'string', '<%1>': '1', '<%2>': '2'},
             'complex_str': 'hello<%3>',
             'complex_list': ['<%4>', '<%5>']},
            datetime.datetime(2017, 1, 31, 16, 19, 53, 0),
            None,
            {'unsafe_str': AnsibleUnsafe('string', True, False),
             'vault_str': AnsibleUnsafe('string', True, True),
             'vault_dict': {'__ansible_vault': 'string'},
             'unsafe_dict': {'__ansible_unsafe': 'string'}}
            ]


# Generated at 2022-06-11 00:59:23.087953
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Vault:
        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
            self.__ENCRYPTED__ = True

    class Unsafe:
        def __init__(self, text):
            self._text = text
            self.__UNSAFE__ = True

    # Test unsafe object
    unsafe = Unsafe("{ 'test': 'value' }")
    assert json.loads(json.dumps(unsafe, cls=AnsibleJSONEncoder)) == \
           {'__ansible_unsafe': "{ 'test': 'value' }"}

    # Test vault object
    vault = Vault("$ANSIBLE_VAULT|1.1|ABCDEFG")

# Generated at 2022-06-11 00:59:34.738893
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants as C
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.parsing.vault import VaultSecret

    if not C.DEFAULT_KEEP_REMOTE_FILES:
        raise AssertionError("Expected DEFAULT_KEEP_REMOTE_FILES to be True")

    enc = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True)


# Generated at 2022-06-11 00:59:45.251809
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    # __ENCRYPTED__
    v = AnsibleUnsafe(u"\u1234".encode('utf-8'), vault_protected=True)
    assert AnsibleJSONEncoder().default(v) == {u'__ansible_vault': u'\u1234'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(v) == u"\u1234"
    # __UNSAFE__
    v = AnsibleUnsafe("unsafe", vault_protected=False)
    assert AnsibleJSONEncoder().default(v) == {u'__ansible_unsafe': U'unsafe'}

    # isinstance(o, Mapping)

# Generated at 2022-06-11 01:00:01.447482
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import inspect
    import sys
    from units.mock.loader import DictDataLoader

    (args, _, _, defaults) = inspect.getargspec(AnsibleJSONEncoder.default)
    # NOTE: Ensure the method signature has not changed unexpectedly
    assert len(args) == 1 + len(defaults)
    str_types = (str, bytes) if sys.version_info[0] == 2 else (str,)

    for str_type in str_types:
        encoder = AnsibleJSONEncoder(sort_keys=True, ensure_ascii=True, indent=0)

        v = 'instance of AnsibleUnsafe'
        o = str_type(v)
        o.__UNSAFE__ = True  # pylint: disable=attribute-defined-outside-init

# Generated at 2022-06-11 01:00:10.543459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    my_dict = {'a': 1, 'b': 2}
    my_vault = VaultLib([], {}, 'test')
    my_vault.update({'foo': 'bar'})
    my_vault = my_vault.dump()

    # test no arg
    result = AnsibleJSONEncoder().default(my_dict)
    assert isinstance(result, Mapping)
    assert my_dict == result

    # test vault arg as default
    result = AnsibleJSONEncoder(vault_to_text=False).default(my_vault)

# Generated at 2022-06-11 01:00:22.429111
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default(['list']) == ['list']
    assert AnsibleJSONEncoder().default({'dict': 'dict'}) == {'dict': 'dict'}
    assert AnsibleJSONEncoder().default(dict(groupvars='groupvars')) == {'groupvars': 'groupvars'}
    assert AnsibleJSONEncoder().default(dict(hostvars='hostvars')) == {'hostvars': 'hostvars'}
    assert AnsibleJSONEncoder().default(datetime.datetime(2000, 1, 1, 0, 0)) == '2000-01-01T00:00:00'

# Generated at 2022-06-11 01:00:30.057541
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create the encoder
    encoder = AnsibleJSONEncoder()
    # Test default
    d = {
        'a' : 1,
        'b' : 2.3
    }
    assert encoder.default(d) == d

    # Test datetime
    d = datetime.datetime(2017, 6, 29, 12, 15, 59)
    assert encoder.default(d) == d.isoformat()
    d = datetime.date(2017, 6, 29)
    assert encoder.default(d) == d.isoformat()

# Generated at 2022-06-11 01:00:32.462087
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    json_str = json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder)
    assert json_str == json.dumps({'foo': 'bar'})

# Generated at 2022-06-11 01:00:35.216264
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # TODO: move more tests here
    # test regular case
    o = AnsibleJSONEncoder()
    test = o.default('test')
    assert test == 'test'


# Generated at 2022-06-11 01:00:47.212888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe

    # Test for VaultLib object
    v = VaultLib([])
    v.decrypt(None)
    v.load('vault')

    aje = AnsibleJSONEncoder()
    e1 = aje.default(v)

# Generated at 2022-06-11 01:00:57.629879
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.ansible_tower
    from ansible.module_utils.ansible_tower import TowerModule
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI_2_5
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI_3_0
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI_3_1
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI_3_2
    from ansible.module_utils.ansible_tower import HAS_TOWER_CLI_3_3
    from ansible.module_utils.ansible_tower import HAS_

# Generated at 2022-06-11 01:01:08.273192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleUnsafe
    from ansible.module_utils.common.crypto import VaultLib
    from ansible.parsing.vault import VaultSecret

    test_data1 = {'a': {'__ansible_unsafe': 'abcd'}, 'b': AnsibleUnsafe('abcd')}
    json.loads(json.dumps(test_data1, cls=AnsibleJSONEncoder, sort_keys=True))

    test_data2 = {'a': {'__ansible_vault': VaultLib(VaultSecret('test')).encrypt('abcd')}, 'b': AnsibleUnsafe(VaultLib(VaultSecret('test')).encrypt('abcd'))}

# Generated at 2022-06-11 01:01:19.028526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.facts.hardware.base import Hardware
    hardware = Hardware('dummy')
    hardware.system_uuid = '9770d3a4-2896-4e86-9f64-d0a1c8e2f66b'
    hardware.serial_number = 'CZ1234ABC'

    # NOTE: Ensure the below would come from one of the system/os fact collectors.
    # The implementation doesn't really matter, but ensure it's an instance of dict.
    # The key and value names don't matter either, only their types matter.
    os_info = {
        'distribution': 'Fedora',
        'major_release': '28',
        'minor_release': '20181024',
    }

    # NOTE: Ensure the below would come from one of the system/network fact collectors

# Generated at 2022-06-11 01:01:34.841674
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    v = VaultLib([])

# Generated at 2022-06-11 01:01:44.129921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    # Test case: has attributes __UNSAFE__ and __ENCRYPTED__ as False
    o = {'a': 1}
    enc = AnsibleJSONEncoder()
    assert enc.default(o) == o
    # Test case: has attribute __ENCRYPTED__ as True, but not __UNSAFE__
    o = AnsibleUnsafe(b'ansible')
    o.__ENCRYPTED__ = True
    enc = AnsibleJSONEncoder(vault_to_text=True)
    assert enc.default(o) == "ansible"
    # Test case: has attribute __UNSAFE__ as True, but not __ENCRYPTED__
    o = AnsibleUnsafe(b'ansible')

# Generated at 2022-06-11 01:01:50.268175
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for default() of AnsibleJSONEncoder
    import json
    import ansible.constants
    from ansible.parsing.vault import VaultLib
    assert '__ansible_vault' in json.dumps({'foo': VaultLib().encrypt('test string')},
                                           cls=AnsibleJSONEncoder)
    assert '__ansible_vault' in json.dumps({'foo': VaultLib().encrypt('test string')},
                                           cls=AnsibleJSONEncoder, vault_to_text=False)
    assert '__ansible_vault' not in json.dumps({'foo': VaultLib().encrypt('test string')},
                                               cls=AnsibleJSONEncoder, vault_to_text=True)

    assert '__ansible_unsafe'

# Generated at 2022-06-11 01:01:55.793001
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    value = 'foo'
    vault = ansible.parsing.vault.VaultLib(password='password', salt='salt')
    encrypted_val = vault.encode(value)
    assert value == AnsibleJSONEncoder().default(encrypted_val)

    ans = ansible.module_utils.basic.AnsibleModule({}, {}, {}, {}, True, False)
    obj = ansible.module_utils.basic.AnsibleUnsafe(value, True)
    assert {'__ansible_unsafe': value} == AnsibleJSONEncoder().default(obj)



# Generated at 2022-06-11 01:02:06.193918
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import sys

    import json
    import unittest2 as unittest

    import ansible.module_utils.basic
    import ansible.module_utils.facts.system.distribution
    import ansible.module_utils.facts.system.linux
    import ansible.module_utils.facts.system.packaging
    import ansible.module_utils.facts.system.platform
    from ansible.module_utils._text import to_bytes

    # We need these imports to succeed for the module to run under python 2.6,
    # but do not use them for any other reason.
    try:
        from collections import Counter
    except ImportError:
        Counter = None
    try:
        from collections import OrderedDict
    except ImportError:
        OrderedDict = None


# Generated at 2022-06-11 01:02:18.436099
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
	class Foo(object):
		def __init__(self, a, b):
			self.a = a
			self.b = b

		def getA(self):
			return self.a

		def getB(self):
			return self.b

		def __repr__(self):
			return "Foo(%s, %s)" % (self.a, self.b)

	now = datetime.datetime.now()

	data = [Foo(1, 2), Foo(3, 4), None, 1, 'foo', True,
			{"k1": "v1", "k2": "v2"}, now, datetime.date(now.year, now.month, now.day)]

	rst = []

# Generated at 2022-06-11 01:02:22.179767
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Setup
    s = 'test'
    encoder = AnsibleJSONEncoder()

    # Exercise
    result = encoder.default(s)
    expected_result = s

    # Verify
    assert result == expected_result

# Generated at 2022-06-11 01:02:26.474366
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_secret = 'mysecret'
    vault_password = 'mypassword'
    data = {'first': VaultLib(vault_password).encrypt(vault_secret)}
    output = json.dumps(data, cls=AnsibleJSONEncoder)
    assert {u'__ansible_vault': vault_secret} == json.loads(output)

# Generated at 2022-06-11 01:02:34.065254
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping
    from ansible.module_utils.six import string_types, binary_type
    from ansible.parsing.vault import VaultLib

    unsafe_test_string = "unsafe text"
    vault_test_string = "vault encrypted text"
    hostvars_test_string = "hostvars test"
    date_test_string = datetime.datetime(year=2018, month=10, day=30)

    class _unsafe(object):

        """Dummy class to create a custom object."""

        __UNSAFE__ = True

        def __init__(self, text):
            """Save the text into the object."""
            self.text = text


# Generated at 2022-06-11 01:02:43.126221
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(a=1, b=2)) == dict(a=1, b=2)
    assert not _is_unsafe(AnsibleJSONEncoder().default(dict(a=1, b=2)))
    assert not _is_vault(AnsibleJSONEncoder().default(dict(a=1, b=2)))
    assert AnsibleJSONEncoder().default(datetime.datetime(2001, 2, 3, 4, 5, 6)) == "2001-02-03T04:05:06"
    assert not _is_unsafe(AnsibleJSONEncoder().default(datetime.datetime(2001, 2, 3, 4, 5, 6)))

# Generated at 2022-06-11 01:03:01.412391
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Specify __UNSAFE__ and __ENCRYPTED__ to avoid output changes in Ansible 2.9
    class AnsibleUnsafe:
        __UNSAFE__ = True

    class AnsibleVault:
        __ENCRYPTED__ = True

# Generated at 2022-06-11 01:03:10.286239
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    test_str = u"testing"
    ciphertext = "ciphertext"
    safe_dict = AnsibleVaultEncryptedUnicode(ciphertext, "password", "vault_version")
    json_str = json.dumps(test_str, cls=AnsibleJSONEncoder)
    json_dict = json.dumps(safe_dict, cls=AnsibleJSONEncoder)
    assert u'testing' == to_text(json.loads(json_str))
    assert u"__ansible_vault" == to_text(json.loads(json_dict).keys()[0])

# Generated at 2022-06-11 01:03:22.737520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe

    # preparing test data
    string = "string"
    ansible_unsafe_object = AnsibleUnsafe('ptr_string_value')
    ansible_unsafe_object_dict = AnsibleUnsafe('ptr_dict_value')
    ansible_unsafe_object_list = AnsibleUnsafe('ptr_list_value')
    ansible_unsafe_object_tuple = AnsibleUnsafe('ptr_tuple_value')
    ansible_unsafe_object_set = AnsibleUnsafe('ptr_set_value')
    ansible_unsafe_object_frozenset = AnsibleUnsafe('ptr_frozenset_value')
    ansible_unsafe_mapping_list = [{'key': AnsibleUnsafe('value')}]

# Generated at 2022-06-11 01:03:31.595380
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()
    assert encoder.default(dict(hello='world')) == dict(hello='world')
    assert encoder.default('hello world') == 'hello world'

# Generated at 2022-06-11 01:03:42.833991
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    # test string
    assert '"test"' == json.dumps(u"test", cls=AnsibleJSONEncoder)
    # test integer
    assert '123' == json.dumps(123, cls=AnsibleJSONEncoder)
    # test integer as string
    assert '"123"' == json.dumps("123", cls=AnsibleJSONEncoder)
    # test NULL
    assert 'null' == json.dumps(None, cls=AnsibleJSONEncoder)
    # test bool
    assert 'true' == json.dumps(True, cls=AnsibleJSONEncoder)
    assert 'false' == json.dumps(False, cls=AnsibleJSONEncoder)
    # test date
    assert '"2019-05-14"' == json.d

# Generated at 2022-06-11 01:03:43.457928
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-11 01:03:50.910552
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(False)
    assert encoder.default("foo") == "foo"
    assert encoder.default(4) == 4
    assert encoder.default(None) is None
    assert encoder.default([1, 2, None]) == [1, 2, None]
    assert encoder.default({"a": 1}) == {"a": 1}
    assert encoder.default(ansible_unsafe_str) == {'__ansible_unsafe':  to_text(ansible_unsafe_str, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-11 01:04:02.626164
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import base64
    # AnsibleUnsafe
    assert '__ansible_unsafe' in AnsibleJSONEncoder().default('\n')
    assert '__ansible_unsafe' in AnsibleJSONEncoder(preprocess_unsafe=True).default('\n')

    # AnsibleVaultEncryptedUnicode
    assert '__ansible_vault' in AnsibleJSONEncoder().default(u'\n')
    assert '__ansible_vault' in AnsibleJSONEncoder().default(base64.b64encode(b'\n'))

    # default
    assert '__ansible_unsafe' not in AnsibleJSONEncoder().default(u'\n')
    assert '__ansible_vault' not in AnsibleJSONEncoder().default(u'\n')


# Generated at 2022-06-11 01:04:13.932530
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # ansible_unsafe
    ansible_unsafe = AnsibleJSONEncoder._AnsibleUnsafe('ansible_unsafe')
    default = AnsibleJSONEncoder().default(ansible_unsafe)
    assert isinstance(default, dict)
    assert default.get('__ansible_unsafe') == 'ansible_unsafe'
    # ansible_vault
    ansible_vault = AnsibleJSONEncoder._AnsibleVault('ansible_vault')
    default = AnsibleJSONEncoder().default(ansible_vault)
    assert isinstance(default, dict)
    assert default.get('__ansible_vault') == 'ansible_vault'
    # ansible_vault_to_text

# Generated at 2022-06-11 01:04:23.376308
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    vault_pwd = 'test_passw0rd'
    vault_data = ['test data']
    vault = VaultLib(vault_pwd)

    result = AnsibleJSONEncoder().default(vault_data)
    assert json.dumps(vault_data) == json.dumps(result)

    result = AnsibleJSONEncoder().default(vault.encrypt(vault_data))
    assert json.dumps(vault_data) != json.dumps(result)



# Generated at 2022-06-11 01:04:48.281958
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test __ENCRYPTED__
    o = AnsibleJSONEncoder()
    o.default(datetime.datetime(year=2020, month=1, day=1))
    assert '2020-01-01' == str(o)

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # NOTE: vault.decrypt is used with private (password/secret_key/...)
    def encrypt(data):
        ciphertext = VaultLib([VaultSecret('', '123')]).encrypt(data)
        assert '!vault' == ciphertext[:6]
        return ciphertext

    o = AnsibleJSONEncoder(vault_to_text=False)
    o.default(encrypt('data'))

# Generated at 2022-06-11 01:04:58.047594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test for AnsibleUnsafe
    old_json_dumps = json.dumps

# Generated at 2022-06-11 01:05:07.358985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import werkzeug.datastructures

    insecure_value = dict(a=1, b=2, c=3, d=4)
    insecure_value['x'] = insecure_value

    # test dict
    insecure_value_dict = AnsibleJSONEncoder().default(insecure_value)
    assert isinstance(insecure_value_dict, dict)
    assert len(list(insecure_value_dict.keys())) == 5
    assert 'x' in insecure_value_dict
    assert insecure_value_dict['x'] == insecure_value_dict

    # test list
    insecure_value_list = AnsibleJSONEncoder().default(list(insecure_value.values()))
    assert isinstance(insecure_value_list, list)
    assert len(insecure_value_list) == 4

    #

# Generated at 2022-06-11 01:05:17.728198
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib

    # Test for VaultLib type
    test = {'a': VaultLib("topsecret", "topsecret")}
    test2 = {'a': VaultLib("topsecret", "topsecret")}
    assert str(json.dumps(test, cls=AnsibleJSONEncoder)) == str(json.dumps(test2, cls=AnsibleJSONEncoder, vault_to_text=True))

    # Test for VaultLib type when vault_to_text is False
    test = {'a': VaultLib("topsecret", "topsecret")}
    assert str(json.dumps(test, cls=AnsibleJSONEncoder)) == str(json.dumps(test, cls=AnsibleJSONEncoder, vault_to_text=False))

   

# Generated at 2022-06-11 01:05:28.651224
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafe
    # Create an AnsibleJSONEncoder object
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    # Test encoder.default with base string type
    assert encoder.default("string") == "string"
    # Test with AnsibleUnsafe
    assert encoder.default(AnsibleUnsafe("string")) == {'__ansible_unsafe': to_bytes("string", errors='surrogate_or_strict', nonstring='strict')}
    # Test with date object

# Generated at 2022-06-11 01:05:35.617744
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestClass(object):
        def __init__(self, value):
            self.value = value
    # standard
    assert {'test_class': {'value': 1}} == json.loads(json.dumps({'test_class': TestClass(1)}, cls=AnsibleJSONEncoder))
    # vault
    vault_object = TestClass(1).__setattr__('__ENCRYPTED__', True)

# Generated at 2022-06-11 01:05:47.413316
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    ansible_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    vault_lib = VaultLib([])

    # This should not fail and get returned without any subclasses
    assert isinstance(ansible_encoder.default({}), Mapping)

    # This should not fail and get returned without any subclasses too
    assert ansible_encoder.default("str") == "str"
    assert ansible_encoder.default(vault_lib.encrypt("test"),) == {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256\n....==\n'}

    # This should

# Generated at 2022-06-11 01:05:52.813470
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    examples = {
        'str': 'str',
        'unicode': u'unicode',
        'int': 123,
        'list': [1, 2, 3],
        'dict': {'A': 1, 'B': 2}
    }
    for name, example in examples.items():
        assert encoder.default(example) == example

    assert encoder.default(True) == 'True'
    assert encoder.default(False) == 'False'
    assert encoder.default(None) == 'null'
    assert encoder.default(datetime.date(2017, 1, 1)) == '2017-01-01'
    assert encoder.default(datetime.date(2017, 1, 1)) == '2017-01-01'

# Generated at 2022-06-11 01:06:02.594159
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test vault object
    test_vault = AnsibleUnsafe('key')
    test_vault.__ENCRYPTED__ = True

    assert(AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(test_vault) == {'__ansible_vault': 'key'})
    assert(AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(test_vault) == 'key')

    # test unsafe object
    test_unsafe = AnsibleUnsafe('key')
    test_unsafe.__UNSAFE__ = True


# Generated at 2022-06-11 01:06:10.726017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_en = AnsibleJSONEncoder()
    assert ansible_en.default(None) == None
    assert ansible_en.default('1') == '1'
    assert ansible_en.default(0) == 0
    assert ansible_en.default(1) == 1
    assert ansible_en.default([]) == []
    assert ansible_en.default({}) == {}
    assert ansible_en.default({'a': 'b'}) == {'a': 'b'}

    def test_func():
        pass
    assert ansible_en.default(test_func) == '<function test_func at 0x7f98c8a825f0>'

# Generated at 2022-06-11 01:06:46.662709
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    enc = AnsibleJSONEncoder()
    data = {
        "some_key": "some_value",
        "some_other_key": VaultSecret("some_value"),
    }
    result = enc.default(data)
    assert result == {
        "some_key": "some_value",
        "some_other_key": {
            '__ansible_vault': VaultLib.encrypt("some_value", VaultLib()).vault.encode('utf8')
        }
    }

# Generated at 2022-06-11 01:06:53.091041
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default({'a': 1}) == {'a': 1}
    assert AnsibleJSONEncoder().default([1,2,3]) == [1,2,3]
    assert AnsibleJSONEncoder().default('1,2,3') == '1,2,3'
    assert AnsibleJSONEncoder().default(1.0) == 1.0


# Generated at 2022-06-11 01:07:03.522538
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=protected-access
    # This test is not a real test, it's just to show what ``AnsibleJSONEncoder.default`` returns.
    # More info: https://github.com/ansible/ansible/pull/53136#discussion_r277667591
    jd = AnsibleJSONEncoder()._iterencode

    assert jd({'a': 'aaa'}, True) == '{"a": "aaa"}'
    # issue #53130
    assert jd({'a': 'aaa'}, False) == '{"a": "aaa"}'
    # issue #53127, #53128
    assert jd({'a': u'aaa'}, False) == '{"a": "aaa"}'

# Generated at 2022-06-11 01:07:12.552465
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(Mapping()) == dict()
    assert AnsibleJSONEncoder().default(Mapping({'a': 1, 'b': 2})) == {'a': 1, 'b': 2}
    assert AnsibleJSONEncoder().default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 1, 1, 0, 0, 0)) == '2018-01-01T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 1, 1, 0, 0, 0, tzinfo=datetime.timezone.utc)) == '2018-01-01T00:00:00+00:00'


# Generated at 2022-06-11 01:07:18.093764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultUnsafeText
    encrypt_value = 'hello world'
    vault_test = VaultLib([])
    encrypted_data_str, _ = vault_test.encrypt(encrypt_value)
    encrypted_data_obj = VaultUnsafeText(encrypted_data_str, 'utf-8')
    assert encrypted_data_str != AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(encrypted_data_obj)
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(encrypted_data_obj) == encrypt_value

# Generated at 2022-06-11 01:07:22.961679
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test(*vargs, **kwargs):
        return kwargs

    b = AnsibleJSONEncoder()
    assert json.loads(b.encode({})) == {}
    assert json.loads(b.encode({'test':test})) == {'test':test}
    assert json.loads(b.encode({'test':{'testA':1}})) == {'test':{'testA':1}}


# Generated at 2022-06-11 01:07:33.137587
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Just check that basic datatypes all work as expected
    class AnsibleUnsafe:
        __UNSAFE__ = True
    class AnsibleVault:
        __ENCRYPTED__ = True
    class AnsibleVaultText:
        __ENCRYPTED__ = True

    test_data = [
        1,
        'string',
        False,
        None,
        [1, 'string', False, None, {'dict': ['value']}],
        {'dict': [1, 'string', False, None, {'dict': ['value']}]}]

# Generated at 2022-06-11 01:07:42.905062
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule

    m = AnsibleModule({})

    # Test for types that should not require special treatment:
    assert json.loads(json.dumps(None, cls=AnsibleJSONEncoder)) is None
    assert json.loads(json.dumps(True, cls=AnsibleJSONEncoder)) is True
    assert json.loads(json.dumps(False, cls=AnsibleJSONEncoder)) is False
    assert json.loads(json.dumps(0, cls=AnsibleJSONEncoder)) == 0
    assert json.loads(json.dumps(10, cls=AnsibleJSONEncoder)) == 10
    assert json.loads(json.dumps(42, cls=AnsibleJSONEncoder)) == 42

# Generated at 2022-06-11 01:07:52.561054
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafeText

    test_data = [
        'test123',
        {'a': 1, 'b': 2, 'c': 3},
        None,
        [{'a': 1, 'b': 2, 'c': 3}, {'a': 1, 'b': 2, 'c': 3}],
        datetime.datetime(2016, 7, 14, 0, 0, 0),
        datetime.date(2016, 7, 14),
        AnsibleUnsafeText('This is a test'),
    ]

    vault = VaultLib([b'AES256', b'AES256'])


# Generated at 2022-06-11 01:08:00.811722
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six.moves import cStringIO
    import copy
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test for object ansible.module_utils.six.string_types
    ansible_unsafe = 'ansible_unsafe'
    ansible_unsafe_encoded = '"ansible_unsafe"'
    ansible_unsafe_bytes = ansible_unsafe.encode('utf-8')
    ansible_unsafe_bytes_encoded = '"ansible_unsafe"'
    ansible_unsafe_unicode = ansible_unsafe_bytes.decode('utf-8')
    ansible_unsafe_unicode_encoded = '"ansible_unsafe"'
    ansible