

# Generated at 2022-06-11 00:58:15.733764
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type
    import datetime
    import base64
    ora_text = base64.b64decode('d3JvdXAgX19hbnNpYmxlOwppc3N1ZV9kYXRlID0gMjAxOS0xMi0yMg==')
    original_text = 'group ___ansible;\nissue_date = 2019-12-22'
    vault_object = VaultLib([1])
    vault_object.decrypt(ora_text)
    unsafe_object = vault_object.decrypt(ora_text)
    unsafe_object_str = AnsibleJSONEncoder()
    assert unsafe_object_str.default(unsafe_object) == original_text

# Generated at 2022-06-11 00:58:27.704675
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test different scenarios for the AnsibleJSONEncoder.default method, including when
    # we use the superclass JSONEncoder.default.

    # Construct a json.JSONEncoder instance
    encoder = json.JSONEncoder()

    # Construct an AnsibleJSONEncoder instance
    ansible_encoder = AnsibleJSONEncoder()

    # Test when json.JSONEncoder.default is called
    assert encoder.default('simple string') == 'simple string'
    assert encoder.default(1) == 1
    assert encoder.default({'key': 'value'}) == {'key': 'value'}
    assert encoder.default(['a', 'list']) == ['a', 'list']

    # Test when AnsibleJSONEncoder.default is called

# Generated at 2022-06-11 00:58:37.768894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('hello') == 'hello'
    assert encoder.default(to_text('hello')) == 'hello'
    assert encoder.default(unicode('hello')) == 'hello'
    assert encoder.default(u'hello') == 'hello'
    assert encoder.default(42) == 42
    assert encoder.default(3.14) == 3.14

    # Objects
    from ansible.parsing.dataloader import DataLoader
    assert encoder.default(DataLoader())['loader_type'] == 'dataloader'

    from ansible.vars.manager import VariableManager
    assert encoder.default(VariableManager())['_options'] is not None

    from ansible.inventory.manager import InventoryManager
    assert encoder.default

# Generated at 2022-06-11 00:58:47.911918
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.parsing.convert_bool import boolean

    test_ok = [
        'string',
        u'unicode string',
        to_text(b'string', encoding='utf-8', errors='surrogate_or_strict'),
        10,
        True,
        {'key': 'value'},
        [10, 'string', True],
        (1, 2, 3),
        set(['set1', 'set2']),
        boolean(True),
        datetime.datetime.now(),
        datetime.date.today(),
    ]


# Generated at 2022-06-11 00:58:51.515340
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default({'foo': 'bar'}) == {'foo': 'bar'}



# Generated at 2022-06-11 00:59:02.012211
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types

    # testing class AnsibleJSONEncoder
    encoder = AnsibleJSONEncoder()

    # testing unsafe object
    unsafe_obj = "!!ansible/unsafe 'foo:bar:baz'"
    unsafe_value = encoder.default(unsafe_obj)
    assert isinstance(unsafe_value, dict)
    assert isinstance(unsafe_obj, string_types)

    # testing vault secret
    vault_obj = VaultSecret('super secret stuff')
    vault_value = encoder.default(vault_obj)
    assert isinstance(vault_value, dict)

# Generated at 2022-06-11 00:59:12.726908
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(None) == 'null'
    assert ansible_json_encoder.default(True) == 'true'
    assert ansible_json_encoder.default(False) == 'false'
    assert ansible_json_encoder.default('normal string') == '"normal string"'
    assert ansible_json_encoder.default(datetime.datetime(2019, 6, 24, 10, 4, 15)) == '2019-06-24T10:04:15'
    assert ansible_json_encoder.default(2.71828) == 2.71828
    assert ansible_json_encoder.default(1) == 1


# Generated at 2022-06-11 00:59:17.592312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("test") == "test"
    assert AnsibleJSONEncoder().default(3) == 3
    assert AnsibleJSONEncoder().default(b"test") == "test"
    assert AnsibleJSONEncoder().default("test".encode("utf-8")) == "test"


# Generated at 2022-06-11 00:59:27.329231
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnsafeText

    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    # assert AnsibleUnsafeText objects

# Generated at 2022-06-11 00:59:38.684225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test default of class AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder()

    # test for different types without unsafe, encrypted and text obj
    assert ansible_json_encoder.default(1) == 1
    assert ansible_json_encoder.default(1.0) == 1.0
    assert ansible_json_encoder.default('test') == 'test'
    assert ansible_json_encoder.default(['test_list']) == ['test_list']
    assert ansible_json_encoder.default({'test_dict': 'test'}) == {'test_dict': 'test'}

# Generated at 2022-06-11 00:59:49.629885
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE, BOOLEANS_TRUE
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultLib

    # test the common cases, string and list of strings
    unf_str_1 = AnsibleUnsafeText(u'\u2603')
    unf_str_2 = AnsibleUnsafeText(u'☃')
    unf_bty_1 = AnsibleUnsafeBytes(b'\xe2\x98\x83')
    unf_bty_2 = AnsibleUnsafeBytes(b'\xe2\x98\x83')
    unf_str_

# Generated at 2022-06-11 01:00:01.796510
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:00:10.746997
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    j_e = AnsibleJSONEncoder(ensure_ascii=False)

    assert json.loads(j_e.encode({'foo': AnsibleUnsafe('bar')})) == {'foo': {'__ansible_unsafe': 'bar'}}
    assert json.loads(j_e.encode({AnsibleUnsafe('foo'): AnsibleUnsafe('bar')})) == {'foo': {'__ansible_unsafe': 'bar'}}
    assert json.loads(j_e.encode(AnsibleUnsafe('foo'))) == 'foo'
    assert json.loads(j_e.encode('caf\xe9')) == 'caf\\xc3\\xa9'

# Generated at 2022-06-11 01:00:22.840665
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class HostVars:
        def __init__(self):
            self.host = 'localhost'
    hostvars = HostVars()

    ansible_json_encoder_object = AnsibleJSONEncoder()

    class_name = ansible_json_encoder_object.__class__.__name__
    function_name = ansible_json_encoder_object.default.__name__
    print("Unit testing: %s.%s" % (class_name, function_name))

    # test dictionary
    assert ansible_json_encoder_object.default(dict(a=1, b=2)) == dict(a=1, b=2)
    # test date
    assert ansible_json_encoder_object.default(datetime.date(2018, 10, 1)) == '2018-10-01'

# Generated at 2022-06-11 01:00:26.739616
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps(['unsafe'], cls=AnsibleJSONEncoder) == '["unsafe"]'
    assert json.dumps(['vault'], cls=AnsibleJSONEncoder) == '["vault"]'


# Generated at 2022-06-11 01:00:33.001122
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default('1234') == '1234'
    assert ansible_json_encoder.default('1234') != 1234
    assert ansible_json_encoder.default('["a",2]') == ('["a",2]')
    assert ansible_json_encoder.default('["a",2]') != ['a',2]


# Generated at 2022-06-11 01:00:44.649842
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import unittest
    TEST_TEXT = b'TEST_TEXT'
    class TestJSONEncoder(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_encode_hostvars(self):
            # encode a hostvars object
            from ansible.vars.hostvars import HostVars
            hostvars = HostVars(hostname='test_hostname')
            hostvars['test_key'] = 'test_value'
            result = AnsibleJSONEncoder().encode(hostvars)
            if sys.version_info.major >= 3:
                self.assertEqual(result, '{"test_key": "test_value"}')

# Generated at 2022-06-11 01:00:55.847762
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(-1) == -1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(-1.0) == -1.0
    assert AnsibleJSONEncoder().default(1.1) == 1.1
    assert AnsibleJSONEncoder().default(-1.1) == -1.1
    assert AnsibleJSONEncoder().default('1.2') == '1.2'
    assert AnsibleJSONEncoder().default(1.2) == 1.2
    assert AnsibleJSONEncoder().default(False) == False
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSON

# Generated at 2022-06-11 01:01:05.830399
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = {'test1': 'test', 'test2': 1, 'test_unsafe': 'unsafe', 'test_vault': b'vault'}
    test_data['test_unsafe'] = ansible_unsafe(test_data['test_unsafe'])
    test_data['test_vault'] = ansible_vault(test_data['test_vault'])
    test_result = {'test1': 'test', 'test2': 1, 'test_unsafe': {"__ansible_unsafe": "'unsafe'"}, 'test_vault': {'__ansible_vault': "'vault'"}}
    result = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).default(test_data)
    assert result == test_result

#

# Generated at 2022-06-11 01:01:16.573144
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.basic
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 01:01:30.873731
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  import json
  import datetime
  from ansible.module_utils.hashivault import vault
  from ansible.module_utils.common._collections_compat import Mapping
  
  # vault object
  test_value = vault.VaultLib('123')
  test_value.__ENCRYPTED__ = True
  ansible_json_encoder = AnsibleJSONEncoder()
  value = ansible_json_encoder.default(test_value)
  assert(isinstance(value, dict) and value['__ansible_vault'] == '123')
  ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
  value = ansible_json_encoder.default(test_value)
  assert(isinstance(value, str) and value == '123')



# Generated at 2022-06-11 01:01:41.104592
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    # Method default should not encode AnsibleVault objects
    encoder = AnsibleJSONEncoder()

    # vault_1 is an AnsibleVault object
    vault_1 = VaultLib([])
    vault_1._ciphertext = '$ANSIBLE_VAULT;1.2;AES256;a_seed;0;0;my_vault1\ndecrypted_vault1'
    vault_obj_repr = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;a_seed;0;0;my_vault1\ndecrypted_vault1'
    }

    vault_2 = VaultLib([])

# Generated at 2022-06-11 01:01:51.271395
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    o = {'a': None, 'b': 1}
    rsp = ansible_json_encoder.default(o)
    assert rsp == {'a': None, 'b': 1}

    o = datetime.datetime(800, 1, 1)
    rsp = ansible_json_encoder.default(o)
    assert rsp == '0800-01-01T00:00:00'

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = VaultLib('foooooooooooooooooooooooooo')

# Generated at 2022-06-11 01:01:58.933865
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Example class with __UNSAFE__ and __ENCRYPTED__ attributes
    class unsafe:
        __UNSAFE__ = True
    class vault:
        __ENCRYPTED__ = True
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # Tests
    assert isinstance(ansible_json_encoder.default(unsafe()), dict)
    assert isinstance(ansible_json_encoder.default(vault()), dict)
    assert isinstance(ansible_json_encoder.default({"test": unsafe()}), dict)
    assert isinstance(ansible_json_encoder.default({"test": vault()}), dict)

# Generated at 2022-06-11 01:02:11.087598
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    value = 'value'
    assert AnsibleJSONEncoder().default(value) == 'value'
    assert AnsibleJSONEncoder(vault_to_text=True).default(value) == 'value'
    assert AnsibleJSONEncoder().default(value) == 'value'

# Generated at 2022-06-11 01:02:22.423247
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    secret_string = 'Hello World'
    vault_password = 'secret'
    vault = VaultLib([])
    encrypted_secret_string = vault.encrypt(secret_string, vault_password)
    unsafe_string = vault.class_vars.ANSIBLE_VAULT

    assert isinstance(encrypted_secret_string, unicode)
    assert isinstance(unsafe_string, unicode)
    unsafe_string_encrypted = unsafe_string.replace(secret_string, encrypted_secret_string)


# Generated at 2022-06-11 01:02:30.582511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils import basic

    def check_as_dict(o):
        if not isinstance(o, Mapping):
            o = basic.json_dict_unicode_to_bytes(o)

        return o

    # checked items must ALWAYS be convertible to a dictionary
    assert check_as_dict(AnsibleJSONEncoder(indent=2).encode({'failed': True})) == {b'failed': True}
    assert check_as_dict(AnsibleJSONEncoder(indent=2).encode({'changed': True})) == {b'changed': True}


# Generated at 2022-06-11 01:02:38.960611
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert_equal = lambda a, b: "assert %s == %s" % (a, b)
    assert_not_equal = lambda a, b: "assert %s != %s" % (a, b)

    datetime_now = datetime.datetime.now()
    today = datetime.date.today()
    assert_equal(True, isinstance(today, datetime.date))
    assert_equal(True, isinstance(datetime_now, datetime.datetime))

    assert_equal(today, AnsibleJSONEncoder().default(today))
    assert_equal(datetime_now.isoformat(), AnsibleJSONEncoder().default(datetime_now))

# Generated at 2022-06-11 01:02:47.203495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestEncoder(AnsibleJSONEncoder):
        def encode(self, o):
            return super(TestEncoder, self).encode(o)

        def iterencode(self, o):
            return super(TestEncoder, self).iterencode(o)

    test_class = [{'ansible': 'object'}, {'date': datetime.datetime(1969, 11, 22, 0, 0)}, {'dict': dict(a='b')}]
    assert TestEncoder().encode(test_class) == json.dumps(test_class)



# Generated at 2022-06-11 01:02:58.617272
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import namedtuple

    # ansible_vault
    from ansible.parsing.vault import VaultLib

    vault = VaultLib(['key'])
    encrypted_vault = vault.encrypt('password', 'data')
    assert {'__ansible_vault': encrypted_vault} == json.loads(json.dumps(encrypted_vault, cls=AnsibleJSONEncoder))

    # ansible_unsafe
    unsafed_data = 'security_data'
    unsafe_vault = vault.encrypt('password', unsafed_data)
    assert {'__ansible_unsafe': unsafed_data} == json.loads(json.dumps(unsafe_vault, cls=AnsibleJSONEncoder))



# Generated at 2022-06-11 01:03:14.312457
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    # test AnsibleUnsafe
    value = AnsibleUnsafe("xyz")
    value_result = {'__ansible_unsafe': 'xyz'}
    assert AnsibleJSONEncoder().default(value) == value_result

    # test AnsibleVault
    vault = VaultLib(password='xyz')
    # Note: we encode encrypted text as base64, so to compare the anonymous token we need to decode it again
    value = vault.encrypt('xyz')
    value_result = {'__ansible_vault': value._ciphertext}

# Generated at 2022-06-11 01:03:26.601388
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnsafe
    import datetime


# Generated at 2022-06-11 01:03:37.091106
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:03:47.130075
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import AnsibleVars

    # vault
    assert AnsibleJSONEncoder().default(VaultSecret('foobar')) == {'__ansible_vault': u'foobar'}
    assert AnsibleJSONEncoder().default(VaultSecret('foobar', 'dummy')) == {'__ansible_vault': u'foobar'}
    # unsafe proxy
    assert AnsibleJSONEncoder().default(AnsibleUnsafe('foobar')) == {'__ansible_unsafe': u'foobar'}
    # dict

# Generated at 2022-06-11 01:03:54.400215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Basic unit test for the AnsibleJSONEncoder.default() method.
    """
    import datetime

    encoder = AnsibleJSONEncoder()

    # test with a datetime value
    assert encoder.default(datetime.datetime(2015, 12, 30)) == '2015-12-30T00:00:00'

    # test with a mapping
    assert encoder.default({'test': 'value'}) == {'test': 'value'}

if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-11 01:04:05.487806
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # simple case
    assert AnsibleJSONEncoder().default('testing') == 'testing'

    # with vault object
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 01:04:12.482101
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()

    assert e.default(datetime.datetime(2020, 5, 1, 12, 0, 0)) == '2020-05-01T12:00:00'
    assert e.default(datetime.date(2020, 5, 1)) == '2020-05-01'
    assert e.default({'spam': 'eggs'}) == {'spam': 'eggs'}



# Generated at 2022-06-11 01:04:22.384240
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Make an instance of the AnsibleJSONEncoder class
    encoder = AnsibleJSONEncoder()

    # Test value of date
    date_now_1 = datetime.datetime.now()
    date_now_2 = date_now_1.isoformat()
    assert encoder.default(date_now_1) == date_now_2
    # Test value of dict
    dict_1 = {"key_1": "value_1"}
    assert encoder.default(dict_1) == {"key_1": "value_1"}
    # Test value of string
    string_1 = "string_1"
    assert encoder.default(string_1) == "string_1"



# Generated at 2022-06-11 01:04:32.074042
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    enc = AnsibleJSONEncoder()
    v = VaultLib(None)
    v._ciphertext = "sometext"
    assert isinstance(enc.default(v), dict)
    assert enc.default(v) == {'__ansible_vault': 'sometext'}
    assert isinstance(enc.default(text_type('abc')), text_type)
    assert enc.default(text_type('abc')) == 'abc'
    assert isinstance(enc.default({'a':'1'}), dict)
    assert enc.default({'a':'1'}) == {'a': '1'}


# Generated at 2022-06-11 01:04:43.032162
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes

    encoder = AnsibleJSONEncoder()

    edict = {
        'o': AnsibleUnsafe(b'test1'),
        'v': VaultLib([], '$MOCK-PASSPHRASE$').encrypt(b'test2'),
        'b': AnsibleUnsafeBytes(b'UnsafeBytes'),
        't': AnsibleUnsafeText(u'UnsafeText', errors='surrogate_or_strict'),
        'a': AnalyticsStatsCollector(),
    }


# Generated at 2022-06-11 01:04:58.129878
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleUnsafeText

    encoder = AnsibleJSONEncoder()

    assert encoder.default(VaultLib('mypassword')) == 'mypassword'
    assert encoder.default(AnsibleUnsafeText('mypassword')) == 'mypassword'



# Generated at 2022-06-11 01:05:07.385655
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test encrypte vault string
    result = AnsibleJSONEncoder().default(get_vault_str())
    assert result == {'__ansible_vault': to_text(get_vault_str()[1:], errors='surrogate_or_strict', nonstring='strict')}

    # test unsafe string
    result = AnsibleJSONEncoder().default(get_unsafe_str())
    assert result == {'__ansible_unsafe': to_text(get_unsafe_str(), errors='surrogate_or_strict', nonstring='strict')}

    # test a mapping
    result = AnsibleJSONEncoder().default(get_mapping())
    assert result == get_mapping()

    # test a date
    result = AnsibleJSONEncoder().default(get_date())

# Generated at 2022-06-11 01:05:11.424231
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {'a': AnsibleUnsafe('test'),
            'b': AnsibleUnsafe('test')}
    assert json.dumps(data, cls=AnsibleJSONEncoder) == '{"a": "test", "b": "test"}'


# Generated at 2022-06-11 01:05:15.435986
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def test_class(o):
        return 'test_class'

    class test_class(object):
        pass

    ansible_vault = AnsibleJSONEncoder(preprocess_unsafe=True).default(test_class())
    assert ansible_vault == 'test_class'

# Generated at 2022-06-11 01:05:26.052752
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class MyClass:
        def __init__(self, value):
            self.value = value


    class AnsibleUnsafe:
        def __init__(self, value):
            self.__UNSAFE__ = True
            if isinstance(value, (bytes, bytearray)):
                value = to_text(value, errors='surrogate_or_strict')
            self.value = value

        def __str__(self):
            return str(self.value)

        def __unicode__(self):
            return to_text(self.__str__(), errors='surrogate_or_strict')

    class AnsibleVault:
        def __init__(self, value):
            self.__ENCRYPTED__ = True


# Generated at 2022-06-11 01:05:32.683196
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import to_bytes
    from ansible.parsing.vault import VaultLib
    print('==> Running test for method default of class AnsibleJSONEncoder')
    vault = VaultLib([])
    vault.update({'test1': 'test1'})
    vault.update({'test2': 'test2'})
    vault.update({'test3': 'test3'})
    vault.update({'test4': 'test4'})
    vault_dict = {'__ansible_vault': vault.encrypt('test value')}

    # Test empty input
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) is None
    assert encoder.default('') == ''

    # Test AnsibleUnsafe type
    encoder

# Generated at 2022-06-11 01:05:39.274126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe:
        __UNSAFE__ = True

    unsafe_object = AnsibleUnsafe()

    ansible_encoder = AnsibleJSONEncoder()
    ae_encoded_data = ansible_encoder.default(unsafe_object)

    default_encoder = json.JSONEncoder()
    de_encoded_data = default_encoder.default(unsafe_object)

    assert ae_encoded_data != de_encoded_data

# Generated at 2022-06-11 01:05:42.156291
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # can not assert on same object (__eq__)
    obj = object()
    result = AnsibleJSONEncoder().default(obj)
    assert result is obj


# Generated at 2022-06-11 01:05:53.150453
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) == AnsibleJSONEncoder().default(u'none')
    assert AnsibleJSONEncoder().default(u'unicode') == AnsibleJSONEncoder().default('str')
    assert AnsibleJSONEncoder().default(True) == AnsibleJSONEncoder().default(0)
    assert AnsibleJSONEncoder().default([]) == AnsibleJSONEncoder().default({k: v for k, v in [('item1', 1), ('item2', 2)]})
    assert AnsibleJSONEncoder().default(datetime.date(year=2018, month=1, day=1)) == '2018-01-01'

# Generated at 2022-06-11 01:06:02.916092
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.basic import AnsibleUnsafe

    ansible_encoder = AnsibleJSONEncoder()
    test_mapping = Mapping()
    test_sequence = is_sequence()
    test_unsafe = AnsibleUnsafe('test_unsafe')

    assert json.dumps(test_unsafe) == '"test_unsafe"'
    ansible_encoder._preprocess_unsafe = False
    assert ansible_encoder.default(test_mapping) == {}
    assert ansible_encoder.default(test_sequence) == []

# Generated at 2022-06-11 01:06:16.405694
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    s = '{"a": "b"}'
    o = json.loads(s)
    assert encoder.default(o) == o

# Generated at 2022-06-11 01:06:26.689395
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test for __ENCRYPTED__
    class data_vault():
        def __init__(self, data):
            self.__ENCRYPTED__ = True
            self._ciphertext = data

    data = data_vault("ansiblesecret")
    assert(AnsibleJSONEncoder().default(data) == {'__ansible_vault': 'ansiblesecret'})

    # Test for __UNSAFE__
    class data_unsafe():
        def __init__(self, data):
            self.__UNSAFE__ = True
            self.data = data

    data = data_unsafe("ansiblesecret")
    assert(AnsibleJSONEncoder().default(data) == {'__ansible_unsafe': 'ansiblesecret'})

    # Test for __UNSA

# Generated at 2022-06-11 01:06:35.698300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import pytest
    from ansible.module_utils._text import to_text

    # Test with datetime.
    year, month, day, hour, minute, second, microsecond = 2020, 9, 1, 15, 41, 37, 773537
    dt = datetime.datetime(year, month, day, hour, minute, second, microsecond)
    json_str = AnsibleJSONEncoder().default(dt)
    assert isinstance(json_str, to_text)
    assert json_str == '2020-09-01T15:41:37.773537'

    # Test with __ENCRYPTED__.
    vault = to_text('hello, world', errors='surrogate_or_strict')
    vault.__ENCRYPTED__ = True
    json_str = AnsibleJSONEncoder

# Generated at 2022-06-11 01:06:44.029495
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    jsn = AnsibleJSONEncoder()
    assert(jsn.default(u'unicode_str') == 'unicode_str')
    assert(jsn.default('str') == 'str')
    assert(jsn.default(123) == 123)
    assert(jsn.default(123.12) == 123.12)
    assert(jsn.default(True) == True)
    assert(jsn.default(False) == False)
    assert(jsn.default(None) == None)
    assert(jsn.default([]) == [])
    assert(jsn.default({}) == {})
    assert(jsn.default(datetime.date(2014, 1, 1)) == '2014-01-01')

# Generated at 2022-06-11 01:06:50.277065
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert aje.default('test') == 'test'
    assert aje.default(u'test') == u'test'
    assert aje.default({'a': 'test'}) == {'a': 'test'}
    assert aje.default((1, 2, 3)) == [1, 2, 3]

# Unit tests for method iterencode of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:06:55.937779
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    Test the default method of class AnsibleJSONEncoder
    """
    ansible_json_encoder = AnsibleJSONEncoder()
    res = ansible_json_encoder.default({'a': 1})
    assert {'a': 1} == res

    res_o = ansible_json_encoder.default(json.JSONEncoder())
    assert 'JSONEncoder' == res_o



# Generated at 2022-06-11 01:07:06.688567
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    message = "hello world"
    object_without_special_properties = object()
    odict = dict(foo='bar', baz=dict(hey='you'))
    vault_password = 'secretpassword'
    vault_obj = VaultLib(vault_password).encrypt(message)
    vault_to_text_obj = VaultLib(vault_password).encrypt(message)
    vault_to_text_obj.__ENCRYPTED__ = False
    safe_obj = VaultLib(vault_password).encrypt(message)
    safe_obj.__UNSAFE__ = True
    date_obj = datetime.datetime.now()


# Generated at 2022-06-11 01:07:09.056711
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test encrypted vault object
    o = AnsibleJSONEncoder(vault_to_text=True)
    d = o.default(o)

# END of method default test

# Generated at 2022-06-11 01:07:11.705966
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # obj format is {'key':'val'}
    obj = AnsibleJSONEncoder().default({'key': 'val'})
    assert isinstance(obj, dict)
    assert obj == {'key': 'val'}



# Generated at 2022-06-11 01:07:17.517472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_native

    from ansible.module_utils.six import string_types, integer_types, binary_type
    from ansible.module_utils.six.moves import xrange

    from ansible.parsing.vault import VaultEncryptedUnicode

    from ansible.utils.unsafe_proxy import wrap_var

    # NOTE: ALWAYS inform AWS/Tower when new items get added as they consume them downstream via a callback

# Generated at 2022-06-11 01:07:46.013104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import crypt
    import sys
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import text_type

    VT = VaultLib([])
    VT.decrypt('$ANSIBLE_VAULT;1.1;AES256\nbXlzZWNyZXRrZXkAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAQAAAAAwAAAAC4AAAABQAAAAAAAAAAAAAAABAAAAAQAAAABAAAAAHwAAAAIAAAAAAAAAAAAAAAUAAAAAAAAAAAABAAAAAQAAAAAAAHdq\ndGVzdA==\n')
    ts = datetime.datetime.now()

# Generated at 2022-06-11 01:07:52.525803
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {'__unsafe': 'unsafe', '__encrypted': 'very secret', '__safe': 'safe'}
    output = json.dumps(data, cls=AnsibleJSONEncoder, indent=4)

    # Check that __unsafe is correctly removed
    assert '__unsafe' not in output
    # Check that __encrypted is transformed
    assert '__ansible_vault' in output
    # Check that __safe is kept
    assert '__safe' in output


# Generated at 2022-06-11 01:08:00.773669
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Tests for class JsonEncoder from AnsibleJSONEncoder class
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import AnsibleUnsafe
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnsafe

    # Tests for class AnsibleJSONEncoder
    preprocess_unsafe = False
    vault_to_text = False
    e = AnsibleJSONEncoder(preprocess_unsafe, vault_to_text)

    assert isinstance(e.default(AnsibleUnsafe(b'unsafe content')), dict)


# Generated at 2022-06-11 01:08:09.117985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from .vault import VaultLib
    from .unsafe_proxy import AnsibleUnsafeText

    # Test VaultLib
    value = VaultLib('vault', 'password').encode('ansible')