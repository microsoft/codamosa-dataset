

# Generated at 2022-06-11 00:58:16.022631
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.vars import AnsibleVaultEncryptedUnicode as encrypted

    # Test instance of class encrypted
    test_encrypted = encrypted(u'ansible', VaultEditor({'password': 'ansible'}))
    assert test_encrypted._ciphertext == u'ansible'

    # Test instance of class string
    test_string = "ansible"

    # Test instance of class dict
    test_dict = {1: "ansible"}

    # Test instance of class array
    test_arr = ["ansible"]

    # Test instance of date object
    test_date = datetime.date(2019, 1, 31)

    # Test instance of datetime object
    test_datetime = datetime.datetime(2019, 1, 31, 11, 1, 0)

# Generated at 2022-06-11 00:58:28.041120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), u'foo') == u'foo'
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), 'foo') == u'foo'
    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), b'foo') == u'foo'

    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), {'foo': 'bar'}) == {'foo': u'bar'}

    assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), datetime.date(2015, 1, 1)) == u'2015-01-01'

# Generated at 2022-06-11 00:58:33.306188
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 00:58:40.416432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    jenc = AnsibleJSONEncoder()
    assert jenc.default(None) is None
    # test for an extensible dictionary
    assert jenc.default({ 'bar': 'baz' }) == { 'bar': 'baz' }
    # test for an extensible list
    assert jenc.default(['foo', 'bar']) == ['foo', 'bar']
    # test for a datetime object
    assert jenc.default(datetime.datetime(year=2017, month=12, day=1, hour=1, minute=2, second=3)) == '2017-12-01T01:02:03'
    # test for a datetime object
    assert jenc.default(datetime.date(year=2017, month=12, day=1)) == '2017-12-01'


# Generated at 2022-06-11 00:58:52.212888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Arrange
    json_encoder = AnsibleJSONEncoder()

    # Act & Assert
    assert json_encoder.default(None) == 'null'
    assert json_encoder.default(True) == 'true'
    assert json_encoder.default(False) == 'false'

    # Act & Assert - default & sum are built-in function
    assert json_encoder.default(default) == '<built-in function default>'
    assert json_encoder.default(sum) == '<built-in function sum>'

    # Act & Assert - default for int & float
    assert json_encoder.default(1) == 1
    assert json_encoder.default(1.2) == 1.2

    # Act & Assert - default for strings

# Generated at 2022-06-11 00:58:53.233588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass


# Generated at 2022-06-11 00:58:59.435582
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    assert encoder.default(b'bytes') == 'bytes'
    assert encoder.default(b'bytes'.decode('utf-8')) == 'bytes'
    assert encoder.default(AnsibleUnsafe(b'bytes')) == {'__ansible_unsafe': 'bytes'}


# Generated at 2022-06-11 00:59:05.394831
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import base64

    class TestUnsafe:
        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

        __UNSAFE__ = True

    assert json.dumps(str("str"), cls=AnsibleJSONEncoder) == '"str"'
    assert json.dumps(TestUnsafe("str"), cls=AnsibleJSONEncoder) == '{"__ansible_unsafe": "str"}'
    assert json.dumps(TestUnsafe("str"), cls=AnsibleJSONEncoder(preprocess_unsafe=True)) == '"str"'

# Generated at 2022-06-11 00:59:17.105170
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    enc = AnsibleJSONEncoder()
    assert enc.default({}) == {}
    assert enc.default({'__ENCRYPTED__': True,
                        '_ciphertext': {'__ansible_vault': 3}}) == {'__ansible_vault': 3}
    assert enc.default({'__UNSAFE__': True,
                        '__ENCRYPTED__': True,
                        '_ciphertext': {'__ansible_vault': 3}}) == {'__ansible_vault': 3}

# Generated at 2022-06-11 00:59:26.551988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    d1 = {"a": "b", "c" : ["a", "b"], "d": {"a": "b"}, "e": VaultSecret("abc") }
    d2 = {"a": "b", "c" : ["a", "b"], "d": {"a": "b"}, "e": {"__ansible_vault" : "abc" } }
    d3 = {"a": "b", "c" : ["a", "b"], "d": {"a": "b"}, "e": {"__ansible_unsafe" : "abc" } }
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert encoder.encode(d1) == json.dumps(d2)
    assert encoder.encode(d2)

# Generated at 2022-06-11 00:59:39.704206
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()

    # date object
    date_object = datetime.date(1992, 3, 25)
    assert ansible_json_encoder.default(date_object) == '1992-03-25'

    # vault object
    class VaultObject:
        __ENCRYPTED__ = True
        _ciphertext = 'encrypted_data'

    assert ansible_json_encoder.default(VaultObject) == {'__ansible_vault': 'encrypted_data'}

    # unsafe object
    class UnsafeObject:
        __UNSAFE__ = True

    assert ansible_json_encoder.default(UnsafeObject) == {'__ansible_unsafe': ''}

    # mapping object

# Generated at 2022-06-11 00:59:44.568155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # class variable VaultEncryptedUnicode is missing in AnsibleVaultEncryptedUnicode class
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible.module_utils.six import PY2, text_type
    from ansible.module_utils._text import to_bytes, to_text

    class AnsibleVaultEncryptedUnicode(text_type):
        __ENCRYPTED__ = True

        def __new__(cls, data, encoding, errors):
            obj = text_type.__new__(cls, data, encoding, errors)
            if PY2:
                obj._ciphertext = unicode(data)
            else:
                obj._

# Generated at 2022-06-11 00:59:53.090310
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    assert e.default(None) == None
    assert e.default(False) == False
    assert e.default(1) == 1
    assert e.default(1.1) == 1.1
    assert e.default('abc') == 'abc'
    assert e.default([]) == []
    assert e.default({'a':1}) == {'a':1}
    assert e.default(datetime.date(1999,12,31)) == '1999-12-31'
    assert e.default(datetime.datetime(1999,12,31,23,59,59,123456)) == '1999-12-31T23:59:59.123456'


# Generated at 2022-06-11 01:00:04.325402
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # vault object
    o = AnsibleUnsafe('P@ssw0rd')
    o.__ENCRYPTED__ = True
    o = AnsibleJSONEncoder(vault_to_text=False).default(o)
    assert o['__ansible_vault'] == 'P@ssw0rd'

    # date, hostvars and other objects
    assert AnsibleJSONEncoder().default(datetime.date(2017, 10, 20)) == '2017-10-20'
    assert AnsibleJSONEncoder().default(dict(a=1, b=2)) == {"a": 1, "b": 2}

    # use default encoder
    assert AnsibleJSONEncoder().default(dict(a=1, b='2')) == {"a": 1, "b": '2'}



# Generated at 2022-06-11 01:00:12.347910
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import base64
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six.moves import zip

    def assert_equal(value, good):
        assert value == good, "%r != %r" % (value, good)

    def assert_encodes_to(value, good):
        assert_equal(json.dumps(value, cls=AnsibleJSONEncoder), good)

    # FIXME: not sure how to test this one
    # assert_equal(json.dumps({'a': object()}, cls=AnsibleJSONEncoder), '{}')

# Generated at 2022-06-11 01:00:22.230184
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    unsafe = 'abc'
    assert encoder.default(unsafe) == unsafe

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault = VaultLib([])
    secret = vault.encrypt(unsafe)
    vault_secret = VaultSecret(secret)

    assert encoder.default(vault_secret) == {'__ansible_vault': secret}

    import datetime
    date_time = datetime.datetime.now()
    assert encoder.default(date_time) == date_time.isoformat()

# Generated at 2022-06-11 01:00:29.034725
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()

    # VaultLib encrypted object
    assert '__ansible_vault' in encoder.default(VaultLib('mysecret'))

    # AnsibleUnsafe object
    assert '__ansible_unsafe' in encoder.default(AnsibleUnsafe('mysecret'))



# Generated at 2022-06-11 01:00:37.431265
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    vault_text = vault.encrypt('testvault')
    ansiblejsonencoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:00:50.258520
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import pytest
    from ansible.module_utils.six import PY3
    from datetime import datetime

    # test function AnsibleJSONEncoder.default(self, o)
    # condition 1: if getattr(o, '__ENCRYPTED__', False):

    # for isinstance(o, bytes) and PY3, which isTrue
    test1 = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(b'\x01\x02|\x04\x06\x07\x08\x09\x0b\x0c\x0e-\x10\x12\x13\x14\x15\x16\x17\x18')

# Generated at 2022-06-11 01:00:59.223241
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansiblejsonencoder = AnsibleJSONEncoder()
    # test for str
    assert(ansiblejsonencoder.default("a") == "a")
    # test for unicode
    assert(ansiblejsonencoder.default(u"a") == u"a")
    # test for list
    assert(ansiblejsonencoder.default([{"a": 1}]) == [{"a": 1}])
    # test for datetime
    assert(ansiblejsonencoder.default(datetime.date(2014, 7, 2)) == "2014-07-02")
    # test for vault
    assert(ansiblejsonencoder.default(
        {'__ENCRYPTED__': True, '__CIPHERTEXT__': "a"}
    ) == {"__ansible_vault": "a"})

# Generated at 2022-06-11 01:01:08.869358
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafeTest(str):
        __UNSAFE__ = True

    class AnsibleVaultTest(str):
        __ENCRYPTED__ = True

    assert AnsibleJSONEncoder().default(AnsibleUnsafeTest('**some string**')) == {'__ansible_unsafe': '**some string**'}
    assert AnsibleJSONEncoder().default(AnsibleVaultTest('**some string**')) == {'__ansible_vault': '**some string**'}



# Generated at 2022-06-11 01:01:19.536538
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.basic import AnsibleUnsafeText
    from datetime import datetime

    # Vault object
    vault_obj = 'Vault object'
    vault = VaultLib([], None, None)
    vault._ciphertext = vault_obj
    vault.__ENCRYPTED__ = True
    result = AnsibleJSONEncoder(vault_to_text=False).default(vault)
    assert result == {'__ansible_vault': 'Vault object'}

# Generated at 2022-06-11 01:01:30.918964
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_secret = VaultSecret('secret')
    vault_password = VaultPassword('password')
    vault_lib = VaultLib('password')

    test_cases = [
        (u'value', u'value'),
        ({'key': u'value'}, {'key': u'value'}),
    ]


# Generated at 2022-06-11 01:01:41.144149
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleFallbackNotFound
    js = AnsibleJSONEncoder(indent=2)

    # Test AnsibleFallbackNotFound
    assert js.default(AnsibleFallbackNotFound(['value'])) == "value"

    # Test AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    vault_secret = VaultSecret([('default', 'password')])
    vault = VaultLib(vault_secret)
    before_encrypt = VaultEditor(vault, '{"message": "hello world"}', indent=2).vault.encrypt()
    # Test normal Vault object

# Generated at 2022-06-11 01:01:48.575894
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import binary_type as bytes

    def _assert(obj, expected):
        assert(AnsibleJSONEncoder(indent=0).encode(obj) == expected)

    _assert('str', '"str"')
    _assert(u'unicode', '"unicode"')
    _assert(1, '1')
    _assert(-1, '-1')
    _assert(1.5, '1.5')
    _assert(u'日本語', '"\\u65e5\\u672c\\u8a9e"')

# Generated at 2022-06-11 01:01:58.173788
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # test __ENCRYPTED__
    class VaultText:
        __ENCRYPTED__ = True

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext

    assert encoder.default(VaultText(b'encrypted text')) == {'__ansible_vault': 'encrypted text'}

    # test __UNSAFE__
    class UnsafeText:
        __UNSAFE__ = True

    assert encoder.default(UnsafeText()) == {'__ansible_unsafe': ''}

    # test Mapping
    assert encoder.default({'1': 2}) == {'1': 2}

    # test date

# Generated at 2022-06-11 01:02:01.507382
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    testObject = {'key': 'value'}
    testClass = AnsibleJSONEncoder()
    test = testClass.default(testObject)
    assert(test == {'key': 'value'})

# Generated at 2022-06-11 01:02:13.257941
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # test code
    import datetime
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultLib

    class TestAnsibleVault(VaultLib):
        def __init__(self, password, rval):
            self._ciphertext = rval

    # input
    value_test_1 = dict()
    value_test_1['__ansible_vault'] = b'$ANSIBLE_VAULT;9.9;TESTING'
    value_test_1['key_1'] = u'value_1'
    value_test_1['key_2'] = 2
    value_test_2 = [u'value_1', 2]
    value_test_3 = 'value_1'
    value_test_4 = 2
    value

# Generated at 2022-06-11 01:02:20.457058
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert '__ansible_vault' in AnsibleJSONEncoder().default('secret')
    assert '__ansible_unsafe' in AnsibleJSONEncoder().default('unsafe')
    assert '__ansible_vault' in AnsibleJSONEncoder(vault_to_text=True).default('secret')
    assert '__ansible_unsafe' in AnsibleJSONEncoder(preprocess_unsafe=True).default({'unsafe': 'unsafe'})

# Generated at 2022-06-11 01:02:28.773839
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret

    # Test with AnsibleVaultEncryptedUnicode(bytes)
    result = AnsibleJSONEncoder().default(VaultSecret(b'$ANSIBLE_VAULT;1.1;AES256;test\n1234567890123456'))
    assert isinstance(result, dict)
    assert '__ansible_vault' in result
    assert result['__ansible_vault'] == b'$ANSIBLE_VAULT;1.1;AES256;test\n1234567890123456'

    # Test with AnsibleVaultEncryptedUnicode(unicode)

# Generated at 2022-06-11 01:02:40.947755
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(b'bytes') == u'bytes'
    assert AnsibleJSONEncoder().default(u'unicode') == u'unicode'
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(0) == 0
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default([]) == []
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default(datetime.datetime(2015, 2, 12, 12, 45, 2, 0)) == u'2015-02-12T12:45:02'

# Generated at 2022-06-11 01:02:53.387126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    if encoder.default(1) != 1:
        raise AssertionError('Unit Test Failed: AnsibleJSONEncoder_default')

    if encoder.default('') != '':
        raise AssertionError('Unit Test Failed: AnsibleJSONEncoder_default')

    if encoder.default(None) != None:
        raise AssertionError('Unit Test Failed: AnsibleJSONEncoder_default')

    if encoder.default([]) != []:
        raise AssertionError('Unit Test Failed: AnsibleJSONEncoder_default')

    if encoder.default(datetime.datetime.now()) != datetime.datetime.now().isoformat():
        raise AssertionError('Unit Test Failed: AnsibleJSONEncoder_default')


# Generated at 2022-06-11 01:03:04.318551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test for the AnsibleJSONEncoder.default method."""
    import copy
    import datetime

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_text

    from ansible.module_utils.parsing.convert_bool import convert_bool

    from ansible.parsing.yaml.objects import AnsibleUnsafe

    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_sequence

    encoder = AnsibleJSONEncoder()

    #########################################################################
    # vault singleton test
    #########################################################################

# Generated at 2022-06-11 01:03:11.036995
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    try:
        json_encoder.default(5)
        json_encoder.default("regular string")
        json_encoder.default([])
        json_encoder.default({})
        json_encoder.default(datetime.date(2018, 4, 4))
        json_encoder.default(datetime.datetime(2018, 4, 4, 22, 53, 14))
    except:
        raise AssertionError("test_AnsibleJSONEncoder_default failed")

# Generated at 2022-06-11 01:03:18.344013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    import datetime
    encoder = AnsibleJSONEncoder()
    date = datetime.date(1988, 7, 26)
    try:
        result = encoder.default(date)
        # date object
        assert result == "1988-07-26"
    except Exception as e:
        print("Test failed:", e)
    else:
        print("Test passed")

test_AnsibleJSONEncoder_default()

# Generated at 2022-06-11 01:03:29.088508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.text.formatters import VaultAwareFormatter
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    import datetime
    import pytest

    vault_password = 'vault_password'

# Generated at 2022-06-11 01:03:40.238280
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test __ENCRYPTED__
    o = type('', (), {'__ENCRYPTED__': True, '_ciphertext': 'ciphertext'})
    value = AnsibleJSONEncoder().default(o)
    assert value == {'__ansible_vault': 'ciphertext'}
    value = AnsibleJSONEncoder(vault_to_text=True).default(o)
    assert value == 'ciphertext'

    # test __UNSAFE__
    o = type('', (), {'__UNSAFE__': True})
    value = AnsibleJSONEncoder().default(o)
    assert value == {'__ansible_unsafe': ''}

    # test unknown type o
    o = type('', (), {})
    value = AnsibleJSONEncoder().default(o)
   

# Generated at 2022-06-11 01:03:45.089044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    data = {'a': 'b', 'c': 'd'}
    test = encoder.default(data)
    assert test == data
    class obj:
        def __init__(self):
            self.a = 'b'
            self.c = 'd'
    test = encoder.default(obj())
    assert test == data

# Generated at 2022-06-11 01:03:54.610046
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(123) == 123
    assert encoder.default(123.456) == 123.456
    assert encoder.default('foo') == 'foo'
    assert encoder.default({}) == {}
    assert encoder.default([]) == []
    assert encoder.default(datetime.date(2017, 10, 9)) == '2017-10-09'
    assert encoder.default(datetime.datetime(2017, 10, 9, 5, 3, 1)) == '2017-10-09T05:03:01'

# Generated at 2022-06-11 01:04:05.648124
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import OrderedDict, MutableMapping
    from ansible.parsing.vault import VaultLib

    # Test dict
    d = dict(id=1, name='Cat')
    e = AnsibleJSONEncoder()
    assert e.default(d) == d

    # Test OrderedDict
    od = OrderedDict(id=1, name='Cat')
    assert e.default(od) == dict(id=1, name='Cat')

    # Test MutableMapping
    md = MutableMapping()
    md['id'] = 1
    md['name'] = 'Cat'
    assert e.default(md) == dict(id=1, name='Cat')

    # Test VaultLib
    vault = VaultLib('password')
    cipher

# Generated at 2022-06-11 01:04:24.525584
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(b'\x00\x01\x02\xff')
    assert to_text(b'\x00\x01\x02\xff', errors='surrogate_or_strict') == result

    result = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(b'\x00\x01\x02\xff12345')
    assert to_text(b'\x00\x01\x02\xff12345', errors='surrogate_or_strict') == result

    result = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default('value')
    assert 'value' == result

    result = Ansible

# Generated at 2022-06-11 01:04:34.085817
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleSensitive(AnsibleJSONEncoder):
        __ENCRYPTED__ = True

    class AnsibleUnsafe(AnsibleJSONEncoder):
        __UNSAFE__ = True

    _a = AnsibleSensitive('__ansible_vault')
    _b = AnsibleUnsafe('__ansible_unsafe')
    _c = AnsibleJSONEncoder('ansible_string')

    _dict = {'a': _a, 'b': _b, 'c': _c}
    _a_default = {'__ansible_vault': b'__ansible_vault'}
    _b_default = {'__ansible_unsafe': '__ansible_unsafe'}

    assert AnsibleJSONEncoder(_dict)._preprocess_unsafe == False
    assert AnsibleJSON

# Generated at 2022-06-11 01:04:45.465759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    unsafe = AnsibleJSONEncoder()
    vault = AnsibleJSONEncoder()
    default_value = AnsibleJSONEncoder()
    hostvars_value = AnsibleJSONEncoder()
    date_value = AnsibleJSONEncoder()

    unsafe_obj = unsafe.default(AnsibleUnsafe('{"some": "value"}'))
    vault_obj = vault.default(AnsibleVaultEncryptedUnicode('{"some": "value"}'))
    default_obj = default_value.default(1)
    hostvars_obj = hostvars_value.default({"some": "value"})
    date_obj = date_value.default(datetime.datetime.now())

    assert unsafe_obj == {"__ansible_unsafe": u"{\"some\": \"value\"}"}
    assert vault_obj

# Generated at 2022-06-11 01:04:50.190630
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    # test for class datetime
    assert json_encoder.default(datetime.datetime(2019, 1, 2)) == '2019-01-02T00:00:00'
    # test for class dict
    assert json_encoder.default({'a': 'b'}) == {'a': 'b'}

# Generated at 2022-06-11 01:05:01.034104
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    stub_unsafe_string = b'password: stub_password'
    stub_unsafe_object = {'password': stub_unsafe_string}
    stub_vault_object = b'$ANSIBLE_VAULT;8.3;AES256;stub_data\nstub_ciphertext\n'
    stub_string = 'stub_value'
    stub_list = [stub_string]
    stub_dict = {'stub_key': stub_string}
    stub_datetime = datetime.datetime(2017, 1, 1, 12, 00, 00)

    ansible_json_encoder = AnsibleJSONEncoder()

    assert ansible_json_encoder.default(stub_unsafe_string) == 'password: stub_password'

# Generated at 2022-06-11 01:05:08.492054
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.urls
    import ansible.parsing.vault
    import ansible.utils.unsafe_proxy
    import datetime
    import pytz

    assert AnsibleJSONEncoder().default(ansible.module_utils.urls.Response(200, 'status', 'body', 'header')) == {'code': 200, 'msg': 'status', 'body': 'body', 'header': 'header'}
    assert AnsibleJSONEncoder().default(datetime.datetime(2016, 6, 30, 9, 30, 54, 54767, pytz.timezone('UTC'))) == '2016-06-30T09:30:54.054767+00:00'

# Generated at 2022-06-11 01:05:18.599306
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    # basic types
    assert e.default(None) is None
    assert e.default(True) is True
    assert e.default(False) is False
    assert e.default(0) == 0
    assert e.default(1.1) == 1.1
    assert e.default('foo') == 'foo'
    assert e.default(u'\u1234') == u'\u1234'
    assert e.default(['foo', u'\u1234']) == ['foo', u'\u1234']
    assert e.default({'foo': 'bar'}) == {'foo': 'bar'}
    # test datetime
    dt = datetime.datetime(2017, 1, 30, 13, 30, 30)

# Generated at 2022-06-11 01:05:29.429168
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    fake_vault = 'Vault()'
    fake_vault._ciphertext = 'this is the cipher'
    fake_vault.__ENCRYPTED__ = True
    fake_vault.__UNSAFE__ = False
    fake_vault.__encrypted__ = True
    fake_unsafe = 'Vault()'
    fake_unsafe.__ENCRYPTED__ = False
    fake_unsafe.__UNSAFE__ = True
    fake_unsafe.__encrypted__ = False
    fake_mapping = Mapping()
    fake_date = datetime.date(2016, 1, 13)
    cls = AnsibleJSONEncoder()

    # Testing Object
    result = cls.default(fake_vault)

# Generated at 2022-06-11 01:05:35.753378
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_encoder = AnsibleJSONEncoder()

    assert '{}' == json.dumps({}, cls=ansible_encoder)
    assert '{"a": 1}' == json.dumps({'a': 1}, cls=ansible_encoder)
    assert '{"a": "1"}' == json.dumps({'a': '1'}, cls=ansible_encoder)
    assert '[1, 2]' == json.dumps([1, 2], cls=ansible_encoder)
    assert '1' == json.dumps(1, cls=ansible_encoder)
    assert 'true' == json.dumps(True, cls=ansible_encoder)



# Generated at 2022-06-11 01:05:47.564264
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import sys
    import unittest

    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'lib'))
    import ansible_unittest as unittest

    class TestAnsibleJSONEncoder(unittest.TestCase):
        def setUp(self):
            self.ansible_json_encoder = AnsibleJSONEncoder()

        def test_default_ansible_vault_to_text_false(self):
            vault_string = AnsibleVaultEncryptedUnicode('test')

# Generated at 2022-06-11 01:06:11.998450
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.errors import AnsibleError
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    ansible_unsafe = AnsibleUnsafe('test')
    ansible_unsafe_encoded = '{"__ansible_unsafe": "test"}'
    ansible_vault = AnsibleUnsafe('test', vault=True)
    ansible_vault_encoded = '{"__ansible_vault": "test"}'
    ansible_error = AnsibleError("test")
    ansible_error_encoded = '"test"'

    # Test the return value of method default when _preprocess_unsafe is False
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert encoder.default(ansible_unsafe) == ansible_unsafe_encoded
   

# Generated at 2022-06-11 01:06:22.266776
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class CustomType(object):
        '''
        Test object class
        '''
        def __init__(self, value):
            self.value = value

    test_data = [
        (1, 1),                                                              # Integer
        (3.14, 3.14),                                                        # Float
        (CustomType(1), {'value': 1}),                                       # Custom object
        ('yaml', 'yaml'),                                                    # String
        (b'yaml', 'yaml'),                                                   # Bytes
    ]

    for (test_input, expected_output) in test_data:
        encoder = AnsibleJSONEncoder()
        actual_output = encoder.default(test_input)
        assert actual_output == expected_output

# Generated at 2022-06-11 01:06:32.469286
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Check nested dict
    input_dict = {'k1':'v1','k2':'v2','k3':{'k4':'v4','k5':'v5','k6':{'k7':'v7','k8':'v8','k9':'v9'}}}
    expected_res = {'k1':'v1','k2':'v2','k3':{'k4':'v4','k5':'v5','k6':{'k7':'v7','k8':'v8','k9':'v9'}}}
    res = json.dumps(input_dict, cls=AnsibleJSONEncoder)

# Generated at 2022-06-11 01:06:41.690202
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=bare-except
    # pylint: disable=import-error
    try:
        from ansible.parsing.vault import VaultLib
    except:
        print("SKIPPING: ansible.parsing.vault is not installed")
        return True

    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-11 01:06:48.718126
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_native
    from ansible.parsing.vault import VaultLib

    # http://docs.python.org/2/library/json.html#json-encoders-and-decoders
    # This method should return an object that is itself JSON-serializable,
    # or it should return None if the given object can't be serialized.

    # json-encoders-and-decoders.html#default-encoders-and-decoders have some examples

    # datetime.datetime -> string
    datetime_now = datetime.datetime.now()
    assert(json.dumps(datetime_now) == '"%s"' % datetime_now.isoformat())

    # datetime.date -> string

# Generated at 2022-06-11 01:06:51.290292
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    date = datetime.date(2019, 5, 13)
    assert encoder.default(date) == "2019-05-13"



# Generated at 2022-06-11 01:06:59.327477
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    j = AnsibleJSONEncoder()
    s = 'test string'
    assert j.default(s) == s
    assert json.dumps(s, cls=AnsibleJSONEncoder) == '"test string"'
    from ansible.module_utils.six import string_types
    assert isinstance(s, string_types) is True
    from ansible.module_utils.six import binary_type
    b = binary_type(s)
    assert j.default(b) == s
    assert json.dumps(b, cls=AnsibleJSONEncoder) == '"test string"'


# Generated at 2022-06-11 01:07:09.378389
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars import AnsibleUnsafe
    from ansible.vars import HostVars
    import datetime

    unsafe = AnsibleUnsafe('this is unsafe')
    vault_string = 'this is vault'
    vault = VaultLib([])
    vault.decrypt(vault_string.encode('utf-8'))
    hostvars = HostVars(dict(a=1, b=2))
    date = datetime.datetime(1999, 12, 31, 23, 59, 59)
    other = {"c": "d"}

    # Test default
    obj_list = [unsafe, vault, hostvars, date, other]
    for obj in obj_list:
        obj_default = AnsibleJSONEncoder().default(obj)


# Generated at 2022-06-11 01:07:19.030114
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:07:27.212586
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    # unsafe text as json object
    unsafe = 'abc'
    unsafe_obj = AnsibleUnsafeText(b'abc')
    a = encoder

# Generated at 2022-06-11 01:08:08.664020
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_password = 'secret'
    vault = VaultLib(vault_password)
    vault_bytes = vault.encrypt(to_text('my secret', errors='surrogate_or_strict'))
    encrypted_string = vault.decrypt(vault_bytes)

    data_type_1 = {'a': 'b', 'c': [encrypted_string]}
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert json.dumps(data_type_1, cls=ansible_json_encoder) == '{"a": "b", "c": ["my secret"]}'

    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=False)