

# Generated at 2022-06-11 00:58:15.774502
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # GIVEN a AnsibleJSONEncoder
    e = AnsibleJSONEncoder()
    # WHEN default method is called with unsafes, vault and hostvars
    unsafe = "Hello".__UNSAFE__
    vault = "Hello".__ENCRYPTED__
    hostvars = dict(a="Hello")
    # THEN a dict with the correct values is returned
    assert e.default(unsafe) == {'__ansible_unsafe': "Hello"}
    assert e.default(vault) == {'__ansible_vault': u'Hello'}
    assert e.default(hostvars) == hostvars
    # GIVEN a AnsibleJSONEncoder with option vault_to_text
    e = AnsibleJSONEncoder(vault_to_text=True)
    # THEN a dict with the correct

# Generated at 2022-06-11 00:58:27.766467
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultSecret, VaultAES256, VaultLib
    from ansible.module_utils.common._collections_compat import Mapping

    vault_secret = VaultSecret(
        encrypted_data=b'something_is_encrypted',
        algorithm='AES256',
        )

    vault_aes256 = VaultAES256(
        content=b'one:two',
        password=VaultLib.create_password(),
        )


# Generated at 2022-06-11 00:58:37.892283
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class AnsibleUnsafe:
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class AnsibleVault:
        __UNSAFE__ = False
        __ENCRYPTED__ = True
        _ciphertext = b'ciphertext'

    class AnsibleMapping(Mapping):
        def __init__(self, x):
            self.x = x

        def __getitem__(self, key):
            return self.x

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 0

    # standard types
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(0) == 0
    assert AnsibleJSONEncoder().default(0.0) == 0.0
   

# Generated at 2022-06-11 00:58:48.495602
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_text = '$ANSIBLE_VAULT;1.1;AES256'

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafeEncrypted(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    x = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    assert x.default(vault_text) == {'__ansible_vault': vault_text}
    assert x.default(AnsibleVault(vault_text)) == {'__ansible_vault': vault_text}

# Generated at 2022-06-11 00:58:59.883239
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.safe_eval import class_to_name
    import datetime

    def check_data(encoder, o, right_value):
        d = encoder.default(o)
        assert d == right_value
        d_json = json.dumps(d, cls=AnsibleJSONEncoder, sort_keys=True)
        assert d_json == right_value

    ansible_json_encoder = AnsibleJSONEncoder()

    # check datetime
    d = ansible_json_encoder.default(datetime.datetime(2114, 7, 4, 12, 0, 0))
    d_json = json.dumps(d, cls=AnsibleJSONEncoder, sort_keys=True)

# Generated at 2022-06-11 00:59:06.892922
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    text = to_text(u'hello world')
    b_text = to_bytes(text)

    unsafe = AnsibleModule._ansible_unsafe_proxy(text)
    vault = VaultLib(to_bytes(''), lambda: ('', ''))
    vault.decrypt(b_text)
    unsafe_vault = AnsibleModule._ansible_unsafe_proxy(vault)

    plain_data = {'foo': {'bar': [text]}}
    plain_data_nested = {'foo': {'bar': [unsafe]}}

# Generated at 2022-06-11 00:59:10.982527
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = {'key1':'value1', 'key2':'value2'}
    # do the test
    result = encoder.default(o)
    assert result == o



# Generated at 2022-06-11 00:59:20.937395
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # These are tests for the default method of AnsibleJSONEncoder
    # TODO: Add more tests for other types of input
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import string_types
    import datetime
    ansible_encoder = AnsibleJSONEncoder()
    test_date = datetime.date.today()
    test_vault_password = 'test_password'
    test_vault_secret = 'test'

# Generated at 2022-06-11 00:59:31.833511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
  from ansible.vars.unsafe_proxy import AnsibleUnsafe
  from ansible.parsing.vault import VaultSecret

  def _get_vault(clear_text):
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_password_file = os.path.join(os.path.dirname(__file__), '.vault_pass')
    with open(vault_password_file, 'rb') as f:
      vault_pass = f.read().strip()

    b_clear_text = clear_text.encode('utf-8')

    vault = VaultLib([])
    vault.secrets = VaultSecret(vault_pass, vault)
    return vault.encrypt(b_clear_text)



# Generated at 2022-06-11 00:59:42.916179
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import ConnectionInfo
    from ansible.module_utils.six import PY3

    encoder = AnsibleJSONEncoder()

    # Dict
    assert encoder.default({}) == {}
    assert encoder.default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # List
    assert encoder.default([]) == []
    assert encoder.default(['a', 'b']) == ['a', 'b']

    # String
    assert encoder.default('foo') == 'foo'
    assert encoder.default('/foo/bar') == '/foo/bar'

    # Default
    assert encoder.default(1) == 1
    assert encoder.default(0) == 0

# Generated at 2022-06-11 00:59:47.187105
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """
    :param value:
    :return:
    """
    encoder = AnsibleJSONEncoder()
    assert encoder.default([1]) == [1]
    assert encoder.default({}) == {}
    assert encoder.default('test') == 'test'

# Generated at 2022-06-11 00:59:59.162436
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Example of each item to be encoded
    test_data = [
        # (input, expected output)
        (
            u'123',
            u'123'
        ),
        (
            b'123',
            u'123'
        ),
        (
            datetime.date(2019, 11, 11),
            u'2019-11-11'
        ),
        (
            datetime.datetime(2019, 11, 11, 10, 20, 30),
            u'2019-11-11T10:20:30'
        ),
        (
            {'foo': 'bar'},
            {'foo': 'bar'}
        )
    ]
    # Run the test data through the default method of AnsibleJSONEncoder.
    # If the result is not the expected value, fail the test.

# Generated at 2022-06-11 01:00:08.533905
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class TestThing(object):
        __ENCRYPTED__ = True
        _ciphertext = b'foo'

        def __repr__(self):
            return 'foo'

    sample_date = datetime.date(2014, 1, 1)

    for test in [
        ({'foo': 'bar'}, {'foo': 'bar'}),
        (['foo', 'bar', 'baz'], ['foo', 'bar', 'baz']),
        (TestThing(), {'__ansible_vault': 'Zm9v'}),
        (sample_date, '2014-01-01'),
    ]:
        assert AnsibleJSONEncoder.default(AnsibleJSONEncoder(), test[0]) == test[1]


# Generated at 2022-06-11 01:00:20.619288
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    # Test encoder for dict
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    ret = encoder.default(test_dict)
    assert ret == {u'key1': u'value1', u'key2': u'value2'}

    # Test encoder for AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault_text = to_text(VaultLib.encrypt('', 'secret_password'))
    vault_obj = getattr(__builtins__, 'vault_' + vault_text)
    ret = encoder.default(vault_obj)

# Generated at 2022-06-11 01:00:31.406059
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestVault:
        __ENCRYPTED__ = True
        _ciphertext = 'ciphertext'

    class TestUnsafe:
        __ENCRYPTED__ = False
        __UNSAFE__ = True

    o = [
        ('a',), ['a'], ('b', 'c'), 'a', {'a': 'b'},
        TestVault(), TestUnsafe(),
        datetime.date(2019, 1, 11), datetime.datetime(2019, 1, 11, 18, 22, 51)
    ]
    j = json.dumps(o, cls=AnsibleJSONEncoder, sort_keys=True)

# Generated at 2022-06-11 01:00:42.355888
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleVault:
        __ENCRYPTED__ = True
        _ciphertext = "vault_test"

    class AnsibleUnsafe:
        __UNSAFE__ = True

    assert AnsibleJSONEncoder().default(AnsibleVault()) == {'__ansible_vault': 'vault_test'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVault()) == 'vault_test'
    assert AnsibleJSONEncoder().default(AnsibleUnsafe()) == {'__ansible_unsafe': ''}

# Generated at 2022-06-11 01:00:53.909608
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    # Case 1 : class AnsibleUnsafeText
    ansible_unsafe_text = 'password=an&weIrD@5tr1nG'
    ansible_unsafe_text_obj = AnsibleUnsafeText(ansible_unsafe_text)

    # json.dumps(ansible_unsafe_text_obj) will call method default
    assert encoder.default(ansible_unsafe_text_obj) == {'__ansible_unsafe': ansible_unsafe_text}

    # Case 2 : class Ans

# Generated at 2022-06-11 01:01:00.497223
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    assert (aje.default({"a": 1}) == {"a": 1})
    assert (aje.default({"a": AnsibleUnsafe()}) == {"a": {"__ansible_unsafe": u"UNSAFE PLACEHOLDER"}})
    assert (aje.default({"a": AnsibleVault()}) == {"a": {"__ansible_vault": u"VAULT PLACEHOLDER"}})
    assert (aje.default(datetime.date(2018, 1, 1)) == "2018-01-01")
    assert (aje.default(datetime.datetime(2018, 1, 1, 2, 3, 4)) == "2018-01-01T02:03:04")


# Generated at 2022-06-11 01:01:11.547093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import AnsibleUnsafeText
    import uuid

    # test a vault object
    vault_secret = str(uuid.uuid4())
    vault_obj = AnsibleVaultEncryptedUnicode(vault_secret)
    json_encoder = AnsibleJSONEncoder()
    actual_result = json_encoder.default(vault_obj)
    expected_result = '{"__ansible_vault": "%s"}' % vault_obj._ciphertext

    print('Test AnsibleJSONEncoder.default for a vault object: %s' % ['FAILED', 'PASSED'][actual_result == expected_result])

# Generated at 2022-06-11 01:01:21.530834
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # AnsibleUnsafe and AnsibleVault will be encoded as dicts
    # with data in encrypted form and with keys
    # __ansible_unsafe and __ansible_vault respectively
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True

    import datetime
    d = datetime.datetime.today()

    d = datetime.datetime.today()


# Generated at 2022-06-11 01:01:36.879300
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing import vault
    import sys, os, tempfile

    fd, sample_vault_text_file = tempfile.mkstemp()

# Generated at 2022-06-11 01:01:45.739349
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import shlex_quote

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleUnsafeVaulted(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    plain_text = 'some plain text'
    plain_unsafe = AnsibleUnsafe(plain_text)
    vault_text = 'some vault text'
    vault_unsafe = AnsibleUnsafeVaulted(vault_text)
    unsafe_dict = dict(key1=plain_text, key2=vault_unsafe)

# Generated at 2022-06-11 01:01:56.321161
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import binary_type

    module = AnsibleModule(safe=True)


# Generated at 2022-06-11 01:02:00.601574
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    json_output = encoder.default('test')
    if json_output:
        return {'test_json_encoder_default': json_output}
    else:
        return {'test_json_encoder_default': 'test'}



# Generated at 2022-06-11 01:02:12.518277
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for all combinations of default(o)
    # Create objects for __ENCRYPTED__, __UNSAFE__, Mapping, and all other datetime.date, datetime.datetime and default
    my_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    my_object_one = object()
    my_object_two = object()
    my_dict = {'key': 'value', 'key1': 'value1'}
    my_date = datetime.date(2017, 12, 18)
    my_datetime = datetime.datetime(2017, 12, 18, 00, 00, 00)

    # instances of __ENCRYPTED__
    my_object_three = object()
    my_object_three.__ENCRYPTED__

# Generated at 2022-06-11 01:02:23.728730
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import b, binary_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3

    # encrypts the text "This is a secret" and returns it in a AnsibleUnsafeText object
    plaintext = b'This is a secret'
    vault = VaultLib([])
    plaintext = vault.encrypt(plaintext)

    # encrypt a dictionary, we wrap it in a JSON string since we can't encrypt the entire thing
    plaintext_dict = """{{
        "contents": "{text_enc}"
    }}""".format(text_enc=vault.encrypt(b'This is a secret'))

# Generated at 2022-06-11 01:02:31.953904
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    ansible_json_encoder = AnsibleJSONEncoder()

    test_data = {
        'name_': 'Zack',
        'age': '20',
        'date': datetime.date(2017, 10, 24),
        'vault': VaultLib([b'$ANSIBLE_VAULT;1.2;AES256']).encrypt(to_bytes('test')),
        'test1': {
            'name': 'test1_name'
        },
        'test2': [1, 2, 3, 4]
    }

    new_data = ansible_json_encoder.default(test_data)


# Generated at 2022-06-11 01:02:41.474096
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    from ansible.utils.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText, AnsibleVaultEncryptedUnicode
    aje = AnsibleJSONEncoder()
    expected = "test"
    unsafe_text = AnsibleUnsafeText(expected)
    assert aje.default(unsafe_text) == expected
    assert aje.default(AnsibleUnsafe(expected)) == expected
    if PY3:
        # AnsibleUnsafeText is derived from str so the fallback to default() is the same in py2 vs py3
        # However AnsibleUnsafeText is derived from bytes so it is a different behavior
        expected = expected.encode('utf-8')
        assert aje

# Generated at 2022-06-11 01:02:53.441985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default([]) == []
    assert AnsibleJSONEncoder().default("") == ""
    assert AnsibleJSONEncoder().default(True) is True
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.1) == 1.1
    class Obj:
        def __init__(self, a, b):
            self.a = a
            self.b = b
    assert AnsibleJSONEncoder().default(Obj("a", "b")) == {"a": "a", "b": "b"}
    assert AnsibleJSONEncoder().default(datetime.date(2019,1,1)) == '2019-01-01'


# Generated at 2022-06-11 01:03:04.368746
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test by each subclass types of AnsibleUnsafe.
    # Test with vault_to_text=True and False
    ansible_unsafe_objects = [
        AnsibleUnsafeText(''),
        AnsibleUnsafeBytes(b''),
        AnsibleUnsafeTextWrapper(''),
        AnsibleUnsafeBytesWrapper(b''),
    ]
    for obj in ansible_unsafe_objects:
        for vault_to_text in [True, False]:
            assert isinstance(AnsibleJSONEncoder(
                vault_to_text=vault_to_text).default(obj), dict)
            assert isinstance(AnsibleJSONEncoder(
                vault_to_text=vault_to_text).default(
                AnsibleVaultEncryptedUnicode(obj)), dict)

    # Test by

# Generated at 2022-06-11 01:03:19.861263
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.parsing.convert_bool import boolean

    test_value = [
        ('12345', ('12345', 'int', False, False)),
        ('abcde', ('abcde', 'str', False, False)),
        ('True', ('True', 'str', False, False)),
        (True, (True, 'bool', False, False)),
        (1, (1, 'int', False, False)),
        (boolean(True), (True, 'bool', False, False)),
        (boolean('yes'), (True, 'bool', False, False)),
        (datetime.datetime.now(), ('datetime_obj', 'datetime_obj', False, False)),
    ]
    results = []
    obj = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:03:30.229859
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test 1: o=None
    o = None
    msg = 'AnsibleJSONEncoder.default() with o=None'
    encoder = AnsibleJSONEncoder()
    try:
        assert encoder.default(o) is None, msg
    except AssertionError as e:
        print('fail: %s: %s' % (msg, str(e)))
        raise
    except Exception as e:
        print('fail: %s: %s' % (msg, str(e)))
        raise
    else:
        pass
    finally:
        pass
    print('pass: %s' % msg)

    # Test 2: o=bool(True)
    o = True
    msg = 'AnsibleJSONEncoder.default() with o=bool(True)'
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:03:30.878267
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    pass

# Generated at 2022-06-11 01:03:42.094959
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.parsing.yaml.objects import AnsibleUnsafe

    unstr_orig = '\x00\x01'

    unstr = to_text(unstr_orig, encoding='utf-8', errors='surrogate_or_strict')
    ans_unsafe = AnsibleUnsafe(unstr)

    assert isinstance(ans_unsafe, AnsibleUnsafe)
    assert _is_unsafe(ans_unsafe)

    # Test default method of AnsibleJSONEncoder
    ans_encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:03:50.134964
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:04:01.378989
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.six import StringIO

    testdata = [
        {'mydata': [1, 2, 3]},
        {'mydata': {1: 'a', 2: 'b'}},
        {'mydata': 'a'},
        {'mydata': datetime.datetime.now()}
        ]
    encoder = AnsibleJSONEncoder()
    for d in testdata:
        result = encoder.default(d)
        # Check that the type has not changed
        assert isinstance(result, type(d))
        # Check that the value has not changed
        assert result == d

    # Test vault storage by default
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 01:04:09.794580
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test vars
    s = "string"
    b = b"bytes"
    b = b"bytes"
    i = 1
    f = 1.0
    t = True
    n = None
    l = [1,2,3]
    ll = [1,2,[3,4,5]]
    d = {'key':'value'}
    dd = {'key':{'key':'value'}}
    uu = AnsibleUnsafe(b'string')

    # Test output
    # string
    assert AnsibleJSONEncoder().default(s) == 'string'
    # bytes
    assert AnsibleJSONEncoder().default(b) == 'bytes'
    # number
    assert AnsibleJSONEncoder().default(i) == 1
    # float
    assert AnsibleJSONEncoder().default

# Generated at 2022-06-11 01:04:21.139952
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test types that AnsibleJSONEncoder can handle
    # this test is designed to cover the unhandled cases in
    # method default of class AnsibleJSONEncoder
    for obj in (True, False, None, 123, 3.4, "All Your Base Are Belong To Us"):
        assert AnsibleJSONEncoder().default(obj) == obj

    # test Mapping subclasses
    assert AnsibleJSONEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}
    assert AnsibleJSONEncoder().default({'foo': 'bar'}.items()) == {'foo': 'bar'}

    # test datetime.datetime subclasses
    assert AnsibleJSONEncoder().default(datetime.datetime(2002, 12, 25, 12, 30)) == '2002-12-25T12:30:00'


# Generated at 2022-06-11 01:04:31.388155
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.vault import VaultLib

    safe = "safe"
    vault_string = "dummy vault string"
    unsafe_string = "unsafe string"
    vault_obj = VaultLib(b'secret', StringIO(vault_string)).decrypt()
    unsafe_obj = MutableMapping.from_dict(
        {
            '__UNSAFE__': True,
            '__ansible_unsafe': binary_type(unsafe_string)
        }
    )

# Generated at 2022-06-11 01:04:34.012527
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(a=1)) == {'a': 1}
    assert AnsibleJSONEncoder().default(dict(a='a')) == {'a': 'a'}


# Generated at 2022-06-11 01:04:50.053719
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('PASSWORD', '')
    encrypted = vault.encrypt('secret')
    encoder = AnsibleJSONEncoder()
    obj = {}
    assert encoder.default(obj) == obj
    obj = encrypted

# Generated at 2022-06-11 01:04:56.952496
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Initalize variable
    expected_result = {
        "__ansible_unsafe": "unsafe test"
    }

    # create unsafe object
    unsafe_object = AnsibleUnsafe("unsafe test")

    # Create AnsibleJSONEncoder object
    ansible_json_encoder = AnsibleJSONEncoder()

    # call the default method of class AnsibleJSONEncoder
    actual_result = ansible_json_encoder.default(unsafe_object)

    # assert
    assert expected_result == actual_result



# Generated at 2022-06-11 01:05:06.672246
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault
    import ansible.module_utils.basic as basic

    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import UserDict

    class DictSubclass(UserDict.DictMixin, dict):
        pass

    class DictSubclass2(UserDict.DictMixin, DictSubclass):
        pass

    class DictSubclass3(UserDict.DictMixin, DictSubclass2):
        pass

    class VaultSecret(vault.AESVaultSecret):
        def decrypt(self, password=None):
            return 'foo'

    class VaultSecret2(VaultSecret):
        pass

    class UnsafeSecret(basic.AnsibleUnsafe):
        pass



# Generated at 2022-06-11 01:05:17.118192
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text

    # VaultLib
    val = {'foo': VaultLib('bar')}
    val2 = json.dumps(val, indent=4, cls=AnsibleJSONEncoder, vault_to_text=True)

# Generated at 2022-06-11 01:05:28.029996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert b'{"field":"\\u0026"}' == json.dumps({'field': '&'}, cls=AnsibleJSONEncoder).encode('utf-8')
    assert b'{"field":"\\u0026"}' == json.dumps({'field': u'\uff06'}, cls=AnsibleJSONEncoder).encode('utf-8')
    assert b'{"field":"\\uff06"}' == json.dumps({'field': u'\uff06'}, cls=AnsibleJSONEncoder, ensure_ascii=False).encode('utf-8')
    assert b'{"field":null}' == json.dumps({'field': None}, cls=AnsibleJSONEncoder).encode('utf-8')



# Generated at 2022-06-11 01:05:33.664309
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class test_class:
        def __init__(self):
            self._ciphertext = 'test'

        def __getattr__(self, attr):
            if attr == '__ENCRYPTED__':
                return True
            return None

    test = test_class()
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(test) == {'__ansible_vault': u'test'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(test) == u'test'

# Generated at 2022-06-11 01:05:43.283955
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # basic test for types that need special encoding
    encoder = AnsibleJSONEncoder()
    types_to_encoder = (
        (42, 42),
        ('a', 'a'),
        (b'a', 'a'),
        ([1, 2, 3], [1, 2, 3]),
        ({'a': 1, 'b': 2}, {'a': 1, 'b': 2}),
        (datetime.datetime.now(), '2018-11-09T15:25:43.424682'),
        (datetime.date.today(), '2018-11-09'),
    )
    for obj, expected in types_to_encoder:
        assert encoder.default(obj) == expected



# Generated at 2022-06-11 01:05:53.886936
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleUnsafeText


# Generated at 2022-06-11 01:06:03.469032
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    text = 'test'
    obj_json = AnsibleJSONEncoder()
    obj_json_unsafe = AnsibleJSONEncoder(preprocess_unsafe=True)

    # test unicode
    u = to_text(text)
    assert obj_json.default(u) == u
    assert obj_json_unsafe.default(u) == u

    try:
        # test bytes
        b = to_text(text).encode('utf-8')
    except NameError:
        b = text
    assert obj_json.default(b) == b
    assert obj_json_unsafe.default(b) == b

    # test str
    assert obj_json.default(text) == text
    assert obj_json_unsafe.default(text) == text

    # test unsafe object

# Generated at 2022-06-11 01:06:12.102255
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Class AnsibleUnsafe
    import ansible.utils.unsafe_proxy
    class TestClass(ansible.utils.unsafe_proxy.AnsibleUnsafe):
        __UNSAFE__ = True
        __ENCRYPTED__ = False
    # Class AnsibleVault
    import ansible.parsing.vault
    class TestClass2(ansible.parsing.vault.AnsibleVault):
        __UNSAFE__ = False
        __ENCRYPTED__ = True

    a = TestClass()
    b = TestClass2()
    encoder = AnsibleJSONEncoder()
    c = encoder.default(a)
    assert c == {'__ansible_unsafe': ''}
    d = encoder.default(b)

# Generated at 2022-06-11 01:06:35.036191
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    data = {
        'key1': AnsibleUnsafe('key1_value'),
        'key2': {
            'key2_subkey1': AnsibleUnsafe('key2_subkey1_value'),
            'key2_subkey2': {
                'key2_subkey2_subkey1': AnsibleUnsafe('key2_subkey2_subkey1_value'),
            },
        }
    }
    json_data = json.dumps(data, cls=AnsibleJSONEncoder)
    assert json.loads(json_data) == data


# Generated at 2022-06-11 01:06:43.531116
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # create simple objects to be encoded
    o1 = dict(a=1, b=2)
    o2 = dict(a=1, b=2, c=3)
    o3 = "Foo"

    # create vault object
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('password')
    vault_encrypted = vault.encrypt('my_secret')

    # create unsafe object
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    unsafe = AnsibleUnsafeText("Foo")

    # create date object
    date_obj = datetime.date(2017, 10, 31)

    # test with each object
    encoder = AnsibleJSONEncoder()
    assert "{" in encoder.default(o1)

# Generated at 2022-06-11 01:06:53.258878
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    import sys
    import unittest

    class TestAnsibleJSONEncoder_default(unittest.TestCase):
        def test_dict(self):
            dict_test = {'test1':'test2'}
            self.assertEqual(dict_test, AnsibleJSONEncoder().default(dict_test))

        def test_list(self):
            list_test = [1,2,3]
            self.assertEqual(list_test, AnsibleJSONEncoder().default(list_test))

        def test_datetime(self):
            datetime_test = datetime.datetime.now()
            self.assertEqual(datetime_test.isoformat(), AnsibleJSONEncoder().default(datetime_test))


# Generated at 2022-06-11 01:07:01.338450
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert '"__ansible_vault"' in json.dumps(dict(mydata='myvalue', myvaultdata=dict(__ansible_vault=dict(key='secret'))))
    assert '"__ansible_unsafe"' in json.dumps(dict(mydata='myvalue', myunsafedata=dict(__ansible_unsafe=dict(key='secret'))))
    assert '"__ansible_unsafe"' in json.dumps(dict(mydata='myvalue', myunsafedata=dict(__ansible_unsafe=u'\ud83d\ude00')))

# Generated at 2022-06-11 01:07:11.005704
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_password = 'password'
    encrypted_value = VaultLib(vault_password).encrypt('secret')
    encrypted_unlocked_value = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n' + encrypted_value + u'\n')
    assert encrypted_unlocked_value.__ENCRYPTED__ is True
    assert encrypted_unlocked_value.__UNSAFE__ is False


# Generated at 2022-06-11 01:07:20.329400
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class A:
        pass

    class B:
        pass

    class AnsibleExampleUnsafe:
        __UNSAFE__ = True

    class AnsibleExampleVault:
        __ENCRYPTED__ = True

    examples = [
        5,
        {'a': 5},
        set([1,2,3]),
        "raw_string",
        to_text(u"unicode_string", errors='surrogate_or_strict'),
        A(),
        B(),
        AnsibleExampleUnsafe(),
        AnsibleExampleVault(),
        42 + 42j
    ]


# Generated at 2022-06-11 01:07:26.545767
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = dict(
        list=["a", "b", "c"],
        dict=dict(
            a="b",
            c=10,
        )
    )
    assert json.dumps(data, cls=AnsibleJSONEncoder,
                      sort_keys=True, indent=4, separators=(',', ': ')) == '''{
    "dict": {
        "a": "b",
        "c": 10
    },
    "list": [
        "a",
        "b",
        "c"
    ]
}'''

# Generated at 2022-06-11 01:07:35.174889
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    encoder = AnsibleJSONEncoder()
    assert encoder.default('some string') == 'some string'
    assert encoder.default(123) == 123
    assert encoder.default(True) == True
    assert encoder.default(AnsibleUnsafe('this is unsafe')) == {'__ansible_unsafe': u'this is unsafe'}
    assert encoder.default(AnsibleVaultEncryptedUnicode('this is vault')) == {'__ansible_vault': u'this is vault'}

# Generated at 2022-06-11 01:07:40.657934
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def my_type():
        pass
    # Create a custom object
    myobj = my_type()
    myobj.__ENCRYPTED__ = True
    myobj._ciphertext = 'my_ciphertext'
    # Test the method default
    result = AnsibleJSONEncoder().default(myobj)
    assert result == {"__ansible_vault": "my_ciphertext"}

# Generated at 2022-06-11 01:07:50.323548
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText  # pylint: disable=import-error
    from ansible.parsing.vault import VaultLib  # pylint: disable=import-error
    from ansible.module_utils.six.moves import builtins  # pylint: disable=import-error,redefined-builtin

    v = VaultLib('foo')
    v.update('password', 'hello world')

    unsafe = AnsibleUnsafeText(u'a')
    unsafe1 = AnsibleUnsafeText(u'a')
