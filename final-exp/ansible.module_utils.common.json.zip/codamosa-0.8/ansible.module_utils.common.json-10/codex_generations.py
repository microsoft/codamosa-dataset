

# Generated at 2022-06-11 00:58:15.626435
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import _unvault_text_if_vaulted
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import binary_type, text_type
    import json

    def assert_json_text_equal(a, b):
        assert dict(json.loads(a)) == dict(json.loads(b))

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

    assert type(encoder.default(VaultLib('mypass'))) == dict

    assert type(encoder.default(
        dict(a=VaultLib('mypass'), b=VaultLib('mypass')))) == dict


# Generated at 2022-06-11 00:58:27.562866
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Note: __UNSAFE__ is a string, so it is not an AnsibleUnsafe object
    unsafe_text = "__UNSAFE__"
    json_unsafe_text = "__UNSAFE__"
    assert AnsibleJSONEncoder().default(unsafe_text) == json_unsafe_text

    from ansible.parsing.vault import VaultLib, VaultSecret
    # Note: VaultSecret is an AnsibleUnsafe object, but there is no to_text function
    #       so it is not an AnsibleVault object
    vault_secrets = VaultSecret('my_secret')
    # Note: VaultSecret is not a string, so it is not an AnsibleUnsafe object
    #       but json.JSONEncoder does not support custom encoders for string types
    #       however, it uses the default() method to

# Generated at 2022-06-11 00:58:32.295591
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(42) == 42
    assert AnsibleJSONEncoder().default('foo bar') == 'foo bar'
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == datetime.datetime.now().isoformat()


# Generated at 2022-06-11 00:58:40.926543
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 00:58:46.294143
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    o = {u'foo' : [u'bar', u'baz'], u'corge' : u'qux'}
    assert aje.default(o) == {u'foo' : [u'bar', u'baz'], u'corge' : u'qux'}


# Generated at 2022-06-11 00:58:53.043251
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(datetime.datetime(2015, 1, 2, 3, 4, 5, 6)) == '2015-01-02T03:04:05.000006'
    assert AnsibleJSONEncoder().default(datetime.date(2015, 1, 2)) == '2015-01-02'
    assert AnsibleJSONEncoder().default('{}') == '{}'

# Generated at 2022-06-11 00:59:03.126313
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.module_utils.six import text_type
    encoder = AnsibleJSONEncoder()
    assert encoder.default('string') == "string"
    assert encoder.default(u'decoded-unicode') == u'decoded-unicode'
    # the unicode character must be escaped
    assert encoder.default(u'\u2028') == u'\u2028'
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(100) == 100
    assert encoder.default(123.5) == 123.5
    assert encoder.default(None) == None
    date = datetime.date(2016, 4, 4)
    assert encoder

# Generated at 2022-06-11 00:59:14.819308
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    v = VaultLib(['AES256'], ['SHA256'])

    vault_str = v.encrypt('abc')
    vault_bytes = b'abc'
    vault_obj = v.decrypt(vault_str)
    unsafe_bytes = b'abc'
    unsafe_str = 'abc'
    vault_bytes_obj = VaultSecret(vault_bytes, b64encode=False)
    vault_str_obj = VaultSecret(vault_str, b64encode=True)
    unsafe_bytes_obj = VaultSecret(unsafe_bytes, b64encode=False, unsafe=True)

# Generated at 2022-06-11 00:59:23.144180
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import basic
    ansible_json_encoder = AnsibleJSONEncoder()
    obj_safe_string = basic.AnsibleModule(argument_spec={})
    obj_safe_string.exit_json(changed=False, meta="test")
    assert(ansible_json_encoder.default(obj_safe_string) == obj_safe_string)

    obj_encrypted_string = basic.AnsibleModule(argument_spec={})
    obj_encrypted_string.exit_json(changed=False, meta=obj_encrypted_string.no_log_values("test"))

# Generated at 2022-06-11 00:59:32.620962
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    vault_password = 'foo'
    vault = VaultLib(vault_password)
    vault_text = 'bar'
    encrypted_vault_text = vault.encrypt(vault_text)
    vault_obj = vault.decrypt(encrypted_vault_text)
    aje = AnsibleJSONEncoder()
    result = aje.default(vault_obj)
    assert len(result) == 1
    assert list(result.keys())[0] == '__ansible_vault'
    assert result['__ansible_vault'] == encrypted_vault_text

# Generated at 2022-06-11 00:59:37.811751
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('test') == 'test'

# Generated at 2022-06-11 00:59:46.268093
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('foo') == 'foo'
    assert AnsibleJSONEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(datetime.datetime.utcnow()) == datetime.datetime.utcnow().isoformat()
    assert AnsibleJSONEncoder().default(dict(foo=['bar'])) == {'foo': ['bar']}


# Generated at 2022-06-11 00:59:50.698578
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(Mapping(a=1, b=2)) == {'a': 1, 'b': 2}
    assert AnsibleJSONEncoder().default(datetime.date(2018, 1, 1)) == '2018-01-01'
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 1, 1, 0, 0)) == '2018-01-01T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.time(0, 0)) == '00:00:00'


# Generated at 2022-06-11 01:00:02.560141
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test data
    test_unsafe = ansible.module_utils.six.StringIO(b'foo')
    test_unsafe.__UNSAFE__ = True

    test_vault = ansible.module_utils.six.StringIO(b'bar')
    test_vault.__ENCRYPTED__ = True

    test_dict = dict(foo='bar')

    test_datetime = datetime.datetime.now()
    test_date = datetime.date.today()

    test_str = 'baz'

    test_list = [test_unsafe, test_vault, test_dict, test_datetime, test_date, test_str]

    # Test code
    encoder = AnsibleJSONEncoder()
    encoded_json = encoder.default(test_unsafe)

# Generated at 2022-06-11 01:00:06.561618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = object()
    assert AnsibleJSONEncoder().default(o) == o
    assert AnsibleJSONEncoder(vault_to_text=True).default(o) == o
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(o) == o


# Generated at 2022-06-11 01:00:13.731311
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.vars_plugins.vault import VaultLib

    # Should get a vault if decrypted
    json_response_1 = json.dumps(VaultLib.encrypt('plaintext', 'password'), cls=AnsibleJSONEncoder, preprocess_unsafe=True)

# Generated at 2022-06-11 01:00:21.335807
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(foo='bar')) == dict(foo='bar')
    assert AnsibleJSONEncoder().default(['foo', 'bar']) == ['foo', 'bar']
    assert AnsibleJSONEncoder().default(datetime.datetime(2017, 1, 1)) == '2017-01-01T00:00:00'
    assert AnsibleJSONEncoder().default(datetime.date(2017, 1, 1)) == '2017-01-01'

# Generated at 2022-06-11 01:00:25.768282
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # json.JSONEncoder.default
    # Called to encode the object o (the result is a Python object, not a JSON string).
    assert AnsibleJSONEncoder().default({'key1': {'key2': 'value2'}}) == {'key1': {'key2': 'value2'}}

# Generated at 2022-06-11 01:00:35.576483
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    encoder = AnsibleJSONEncoder()
    test_value = "test_value"
    test_dict = {'test_key': test_value}
    test_date = datetime.date.today()
    test_datetime = datetime.datetime.now()

    assert encoder.default(test_value) == test_value
    assert encoder.default(test_dict) == test_dict
    assert encoder.default(test_date) == test_date.isoformat()
    assert encoder.default(test_datetime) == test_datetime.isoformat()

    # vault object test
    test_vault_obj = VaultLib(None).encrypt(test_value)
    assert test_vault_obj.__ENCRYPTED__


# Generated at 2022-06-11 01:00:47.622463
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import copy
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types

    s = 'test vault'
    unsafe_str = 'test unsafe'
    dt = datetime.datetime(2018, 4, 1, 16, 50, 0)
    enum = ('a', 'b', 'c')
    vault_obj = VaultLib().encrypt(s)
    unsafe_obj = u'中文'.encode('utf-8')
    t = tuple(enum)
    l = list(enum)
    o = set()
    o.add('a')
    o.add('b')
    o.add('c')
    o = frozenset(o)
    unk = type('Unknown', (), {})()

# Generated at 2022-06-11 01:01:03.343271
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:01:14.190949
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils._text import to_bytes

    test_vault_password = VaultLib.get_vault_password('/tmp/vault_pass.txt')
    vault = VaultLib(password=test_vault_password)
    enc_text = vault.encrypt(to_bytes('foo bar', errors='surrogate_or_strict'))

    class Foo:
        def __init__(self, text):
            self._text = text

        def __str__(self):
            return self._text

        @property
        def __REPR__(self):
            return "Foo('%s')" % str(self)


# Generated at 2022-06-11 01:01:23.366570
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import basic

    # Test: check Vault object
    obj = basic.AnsibleVaultEncryptedUnicode('ansible')
    json_obj = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(obj)
    assert json_obj == {'__ansible_vault': to_text(obj._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    # Test: check Vault object with vault_to_text
    json_obj = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(obj)
    assert json_obj == to_text(obj, errors='surrogate_or_strict')

    # Test: check AnsibleUnsafeText

# Generated at 2022-06-11 01:01:31.776995
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    enc = AnsibleJSONEncoder()
    test_data = [
        {'test_int': 5},
        'test',
        5,
        VaultLib(b'foo')
    ]
    for test in test_data:
        assert isinstance(enc.default(test), type(test))

    # Test AnsibleUnsafeEncoder methods are not called
    enc.default(VaultLib(b'foo'))
    enc.iterencode(VaultLib(b'foo'))


# Generated at 2022-06-11 01:01:33.897709
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("123456") == "123456"


# Generated at 2022-06-11 01:01:39.309653
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.json_utils import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    assert AnsibleJSONEncoder().encode(AnsibleUnsafe('foo')) == '{"__ansible_unsafe": "foo"}'
    assert AnsibleJSONEncoder().encode(AnsibleVaultEncryptedUnicode('foo')) == '{"__ansible_vault": "foo"}'

# Generated at 2022-06-11 01:01:47.392028
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Test: AnsibleVaultEncryptedUnicode
    vault_obj = VaultLib([])
    vault_obj.password = 'secret'
    encrypted_o = vault_obj.encrypt('password')
    o = AnsibleJSONEncoder().default(encrypted_o)

# Generated at 2022-06-11 01:01:57.324352
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.common._collections_compat import Mapping

    class DummyVaultLib(VaultLib):
        def _encrypt_data(self, data):
            return data[::-1]
        def _decrypt_data(self, data):
            return data[::-1]

    password = 'hunter2'
    vault = DummyVaultLib()
    vault.password = password
    # Check that VaultLib object can be encoded, but not decoded by the encoder
    dummy_vault = vault.encrypt('hello world')
    assert(isinstance(dummy_vault, VaultSecret))
    encoder = AnsibleJSONEncoder()
    encoded = encoder

# Generated at 2022-06-11 01:02:08.381867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class TestAnsibleType():
        def __init__(self, val):
            self._val = val

        def __str__(self):
            return self._val

        def __repr__(self):
            return self._val

        def __getattr__(self, name):
            return 'test_val'

    my_encoder = AnsibleJSONEncoder()
    my_date = datetime.datetime.now()
    my_object = TestAnsibleType('test_value')
    my_dict = {'my_object': {'my_object': my_object}}

    assert my_encoder.default(my_object) == 'test_value'
    assert my_encoder.default(my_date).split('.')[0] ==  my_date.isoformat().split('.')[0]
   

# Generated at 2022-06-11 01:02:20.682506
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    import collections
    from ansible.module_utils.six import u, PY3


# Generated at 2022-06-11 01:02:34.532244
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    import datetime
    import os
    try:
        from mock import patch
    except ImportError:
        from unittest.mock import patch

    # patch VaultLib.get_file to return a VaultSecret
    vault_secret = VaultSecret('secret', 'password')
    with patch.object(VaultLib, 'get_file', return_value=vault_secret):
        vaultsecret = VaultLib().get_file()

    # patch VaultEditor.create_file to return an AnsibleVault
    temp_file = os.tmpfile()

# Generated at 2022-06-11 01:02:40.100070
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json

    assert json.loads(json.dumps(dict(a=1, b='2', c=[1]))) == dict(a=1, b='2', c=[1])
    assert json.loads(json.dumps(dict(a=1, b='2', c=[1]), indent=2)) == dict(a=1, b='2', c=[1])
    assert json.loads(json.dumps(dict(a=1, b='2', c=dict(aa=11, bb=22)))) == dict(a=1, b='2', c=dict(aa=11, bb=22))

# Generated at 2022-06-11 01:02:52.153097
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Testing encrypted tagged value
    input_value = '1'
    input_value.__ENCRYPTED__ = True
    input_value.__UNSAFE__ = False
    expected_value = {'__ansible_vault': 'MQ=='}
    output_value = AnsibleJSONEncoder().default(input_value)
    assert output_value == expected_value

    # Testing unsafe tagged value
    input_value = '1'
    input_value.__ENCRYPTED__ = False
    input_value.__UNSAFE__ = True
    expected_value = {'__ansible_unsafe': '1'}
    output_value = AnsibleJSONEncoder().default(input_value)
    assert output_value == expected_value

    # Testing mappings

# Generated at 2022-06-11 01:02:55.860887
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    value = AnsibleJSONEncoder().default('hoge')
    assert value == 'hoge'
    value = AnsibleJSONEncoder().default('hoge'.encode('utf-8'))
    assert value == 'hoge'


# Generated at 2022-06-11 01:02:58.138234
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(datetime.date(2018, 3, 15)) == '2018-03-15'

# Generated at 2022-06-11 01:03:08.106990
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # overrides here to make the tests pass, for the actual
    # behavior see the individual methods
    VaultLib.ENCRYPT_KEY = 'FAKE_KEY'
    VaultLib.DECRYPT_KEY = 'FAKE_KEY'

    assert {'__ansible_unsafe': 'test'} == AnsibleJSONEncoder().default(AnsibleUnsafeText('test'))
    assert 'test' == AnsibleJSONEncoder(vault_to_text=True).default(AnsibleVaultEncryptedUnicode('test'))
    assert {'__ansible_vault': 'test'} == AnsibleJSONEncoder().default(AnsibleVaultEncryptedUnicode('test'))

# Generated at 2022-06-11 01:03:12.796845
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("string") == 'string'
    assert AnsibleJSONEncoder().default(1) == 1
    assert set(AnsibleJSONEncoder().default([1, 2, 3]).items()) == set([(0, 1), (1, 2), (2, 3)])


# Generated at 2022-06-11 01:03:25.201006
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoded_value = json.dumps((1, 2, 3), cls=AnsibleJSONEncoder)
    assert encoded_value == '[1, 2, 3]'
    encoded_value = json.dumps({"one": 1, "two": "second"}, cls=AnsibleJSONEncoder)
    assert encoded_value == '{"one": 1, "two": "second"}'
    encoded_value = json.dumps({"one": 1, 2: "second"}, cls=AnsibleJSONEncoder)
    assert encoded_value == '{"1": "second", "one": 1}'
    encoded_value = json.dumps({"one": 1, "second": datetime.datetime(2020, 6, 4, 1, 2, 16, 828000)}, cls=AnsibleJSONEncoder)
    assert encoded

# Generated at 2022-06-11 01:03:32.656565
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # deliberately choosing a class that is not a subset of JSON data types, so that it would use the method default
    class Test():
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __eq__(self, other):
            if ((other == None) or (type(self) != type(other))):
                return False
            else:
                return self.__dict__ == other.__dict__

    ansi_json_encoder = AnsibleJSONEncoder()
    test_obj = Test('a', 2)
    expected_default_result = {'a': 'a', 'b': 2}
    default_result = ansi_json_encoder.default(test_obj)
    assert default_result == expected_default_result, "default method does not work properly"

# Generated at 2022-06-11 01:03:43.842478
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class TestVaultData:
        __ENCRYPTED__ = True

        def __init__(self, text):
            self._ciphertext = text

        def __repr__(self):
            return '<Ansible Vault (%s)>' % len(self._ciphertext)

    class TestUnsafeData:
        __UNSAFE__ = True

        def __init__(self, text):
            self._data = text

        def __repr__(self):
            return '<Ansible Unsafe (%s)>' % len(self._data)

    class TestUnsafeDataEncrypted(TestUnsafeData):
        __ENCRYPTED__ = True

        def __init__(self, text):
            self._ciphertext = text
            self._data = text


# Generated at 2022-06-11 01:04:07.545047
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.parsing.vault import VaultAES256

    # Test Vault
    v = VaultAES256('foo')
    assert AnsibleJSONEncoder().default(v) == {'__ansible_vault': v._ciphertext}

    # Test dict
    d = dict(a=1, b=2)
    assert AnsibleJSONEncoder().default(d) == d

    # Test dates
    now = datetime.datetime.now()
    dt = datetime.datetime(2011, 11, 11)
    date = datetime.date(2011, 11, 11)
    assert AnsibleJSONEncoder().default(now) == now
    assert AnsibleJSONEncoder().default(dt) == dt.iso

# Generated at 2022-06-11 01:04:18.622628
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.common.collections import is_sequence

    test_data = {
        '__ansible_unsafe': 'test_ansible_unsafe',
        '__ansible_vault': 'test_ansible_vault',
        'test_dict': {'test_key': 'test_value'},
        'test_binary': to_bytes('test_binary'),
        'test_text': to_native('test_text'),
        'test_list': ['list1', 'list2'],
    }


# Generated at 2022-06-11 01:04:29.395553
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import wrap_var, AnsibleUnsafe

    a_string = AnsibleUnsafe(u'a_string')
    a_dict = {'a_dict': AnsibleUnsafe('a_dict')}
    a_list = [AnsibleUnsafe('a_list')]

    out_string = AnsibleJSONEncoder().default(a_string)
    assert out_string == {'__ansible_unsafe': u'a_string'}
    out_dict = AnsibleJSONEncoder().default(a_dict)
    assert out_dict == {'a_dict': {'__ansible_unsafe': u'a_dict'}}
    out_list = AnsibleJSONEncoder().default(a_list)

# Generated at 2022-06-11 01:04:37.163242
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils._text import to_text

    pw = to_text("agentleadflute", errors='surrogate_or_strict')
    lib = VaultLib(password=pw)
    vault_str = lib.encrypt(to_text("foo"))
    vault = to_text(vault_str, errors='surrogate_or_strict')

    # Test vault
    assert AnsibleJSONEncoder().default(vault) == {'__ansible_vault': to_text(vault_str, errors='surrogate_or_strict', nonstring='strict')}

# Generated at 2022-06-11 01:04:47.823882
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """AnsibleJSONEncoder: Test encoding of Ansible internal types"""

    import ansible.parsing.yaml.objects

    encoder = AnsibleJSONEncoder()


# Generated at 2022-06-11 01:04:56.634309
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    e = AnsibleJSONEncoder()
    assert u'a string' == e.default(u'a string')
    assert 'a string' == e.default(u'a string')
    assert 'a string' == e.default('a string')
    assert 'a string' == e.default('a string')
    assert {'string1': 'a string', 'string2': 'a string'} == e.default({'string1': 'a string', 'string2': 'a string'})
    assert {'unicode1': u'a string', 'unicode2': u'a string'} == e.default({'unicode1': u'a string', 'unicode2': u'a string'})

# Generated at 2022-06-11 01:05:06.422672
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import AnsibleUnsafe, AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.module_utils.six import u

    assert json.loads(json.dumps(AnsibleUnsafeText(u('foo')), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': 'foo'}
    assert json.loads(json.dumps(AnsibleUnsafeBytes(b'foo'), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': 'foo'}
    assert json.loads(json.dumps(AnsibleUnsafe(b'foo'), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': 'foo'}

# Generated at 2022-06-11 01:05:16.901174
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import textwrap
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import PY2

    class MockVaultLib(VaultLib):
        '''
        This is a secret vault object.
        '''
        def __init__(self, cipher='AES256'):
            self.cipher = cipher
            self._ciphertext = '$MOCKDATA$'

    def assert_value(obj, value):
        encoder = AnsibleJSONEncoder()
        assert encoder.default(obj) == value

    # test case 1: __ENCRYPTED__ is True and vault_to_text is False
    vault = MockVaultLib()
    assert_value(vault, {'__ansible_vault': '$MOCKDATA$'})

# Generated at 2022-06-11 01:05:28.156125
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.json_utils import AnsibleUnsafe

    data_set = {
        "vault_object": VaultLib([])
    }

    data_set["vault_object"]._ciphertext = data_set["vault_object"]._ciphertext.decode('utf-8')

    data_set["unsafe_object"] = AnsibleUnsafe('this is a vault object')

    data_set["date_object"] = datetime.date.today()

    results = {}
    for k, v in data_set.items():
        results[k] = AnsibleJSONEncoder().default(v)


# Generated at 2022-06-11 01:05:31.645115
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    encrypted = vault.encrypt(b"hello")
    ansible_json_encoder = AnsibleJSONEncoder()
    encrypted_json = ansible_json_encoder.default(encrypted)
    assert type(encrypted_json) == dict



# Generated at 2022-06-11 01:06:05.458873
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test an AnsibleVaultEncryptedUnicode object,
    # should return a dict with key '__ansible_vault'
    ansible_vault_obj = json.dumps(AnsibleVaultEncryptedUnicode(), cls=AnsibleJSONEncoder)
    ansible_vault_obj = json.loads(ansible_vault_obj)
    assert isinstance(ansible_vault_obj, dict)
    assert '__ansible_vault' in ansible_vault_obj

    # Test a dict object,
    # should return dict with key 'key'
    dict_obj = json.dumps(dict(key='value'), cls=AnsibleJSONEncoder)
    dict_obj = json.loads(dict_obj)
    assert isinstance(dict_obj, dict)
   

# Generated at 2022-06-11 01:06:12.257193
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    dict_obj = {'foo': 'bar'}
    unsafe_obj = {'foo': 'bar', '__UNSAFE__': True}
    json_str = '{"foo": "bar"}'

    enc = AnsibleJSONEncoder(preprocess_unsafe=False)
    assert enc.default(dict_obj) == dict_obj
    assert enc.default(unsafe_obj) == json_str
    assert enc.default(json_str) == json_str

    enc = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert enc.default(dict_obj) == dict_obj
    assert enc.default(unsafe_obj) == dict_obj
    assert enc.default(json_str) == json_str



# Generated at 2022-06-11 01:06:22.963937
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test case for AnsibleJSONEncoder.default()
    """
    import datetime
    # create instance of class AnsibleJSONEncoder
    aje = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    # Test for dict type
    dict_result = aje.default({"a": 1, "b": "ansible"})
    assert isinstance(dict_result, dict), "It should be dict"
    assert dict_result == {"a": 1, "b": "ansible"}, "It should be equal to source dict"

    # Test for datetime type
    time_result = aje.default(datetime.datetime(2019, 5, 13, 10, 30, 30))
    assert isinstance(time_result, str), "It should be str"

# Generated at 2022-06-11 01:06:32.952517
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import mock
    import unittest

    class TestCase(unittest.TestCase):
        def test_datetime_should_be_encoded_to_json_format(self):
            # default should encode datetime to json format
            # default should encode timedelta as json string (exactly the same behavior as date time)
            data = [
                datetime.datetime.now(),
                datetime.datetime.max,
                datetime.datetime.min,
                datetime.datetime(2017, 11, 3),
                datetime.timedelta(),
                datetime.timedelta(days=1),
            ]
            self._assert_data_should_be_encoded(data)


# Generated at 2022-06-11 01:06:42.118980
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    from ansible.parsing.vault import VaultLib
    v = VaultLib('test_password')
    encoded_v = encoder.default(v.encrypt('test_text'))

# Generated at 2022-06-11 01:06:48.940459
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.vault import VaultSecret
    import datetime

    def _test(encoder, o, expected):
        """Informal test of whether the encoder yields a dict containing the
        expected result.

        Can't use a real test framework because a dict with the correct key
        but incorrect value will pass the test.
        """
        json_str = encoder.encode(o)
        result = json.loads(json_str)
        assert result['__ansible_vault'] == expected, json_str

    for default in (False, True):
        encoder = AnsibleJSONEncoder(default=default)
        assert encoder.default(None)

# Generated at 2022-06-11 01:06:59.281561
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test 1
    assert AnsibleJSONEncoder().default({'ansible': '2.8'}) == {'ansible': '2.8'}
    # test 2
    from ansible.parsing.vault import VaultLib
    vault_lib_o = VaultLib(password='password')

# Generated at 2022-06-11 01:07:07.993225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    # Test that object is instance of class dict
    obj = dict(a=1, b=2)
    assert isinstance(obj, dict)

    # Test that encoded output is instance of class str
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder.default(obj), dict)

    # Test that object is instance of class datetime.date
    obj = datetime.date(2020, 5, 12)
    assert isinstance(obj, datetime.date)

    # Test that encoded output is instance of class str
    encoder = AnsibleJSONEncoder()
    assert isinstance(encoder.default(obj), str)


# Generated at 2022-06-11 01:07:13.409552
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:07:17.246219
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    class _AnsibleUnsafe1(object):
        __UNSAFE__ = True

    class _AnsibleUnsafe2(object):
        __UNSAFE__ = False

    class _AnsibleVault(object):
        __ENCRYPTED__ = True
