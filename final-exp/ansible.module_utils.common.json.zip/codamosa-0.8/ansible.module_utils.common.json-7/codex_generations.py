

# Generated at 2022-06-11 00:58:15.916082
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=False)

    vault_obj = VaultLib('password')
    result = ansible_json_encoder.default(vault_obj.encode('password'))

    assert isinstance(result, Mapping)
    assert result.keys() == ['__ansible_vault']
    assert isinstance(result['__ansible_vault'], text_type)

    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    result = ansible_json_encoder.default(vault_obj.encode('password'))

    assert isinstance(result, text_type)

# Generated at 2022-06-11 00:58:27.942312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes, to_text, to_unicode

    # a vault instance
    vault = VaultLib([])
    vault_text = vault.encrypt(b'password')
    vault_bytes = to_bytes(vault_text, errors='surrogate_or_strict')
    vault_instance = VaultLib([], vault_text)

    # hostvars: string, bytes and text
    hostvars_string_instance = 'password'
    hostvars_bytes_instance = b'password'
    hostvars_text_instance = to_text(hostvars_bytes_instance, errors='surrogate_or_strict')



# Generated at 2022-06-11 00:58:37.975221
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class MyClass():
        pass

    a = "value"

    b = MyClass()

    c = datetime.datetime(2015, 10, 7, 8, 26, 33, 715922)

    d = [1, 2, 3]

    e = {'key': 'value'}

    f = {'key_1': 'value_1', 'key_2': {'key_3': 'value_3', 'key_4': [{'key_5': 'value_5'}]}}

    assert(json.dumps(a, cls=AnsibleJSONEncoder) == '"value"')
    assert(json.dumps(b, cls=AnsibleJSONEncoder) == "null")

# Generated at 2022-06-11 00:58:40.941373
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for method default of class AnsibleJSONEncoder
    en = AnsibleJSONEncoder()
    o = {'k':'v'}
    result = en.default(o)
    print(result)
    assert result == o


# Generated at 2022-06-11 00:58:52.906540
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # test for the default case
    json_encoder = AnsibleJSONEncoder()
    ansible_object = {
        'test_one': 'test_value_1',
        'test_two': 2,
    }
    assert json_encoder.default(ansible_object) == ansible_object

    # test for __ENCRYPTED__ case
    class TestVaultEncryptedObject:
        __ENCRYPTED__ = True

        def __init__(self, _ciphertext):
            self._ciphertext = _ciphertext

    o = TestVaultEncryptedObject('test_value')
    encrypted_object = {'__ansible_vault': to_text(o._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    assert json_encoder

# Generated at 2022-06-11 00:59:03.067477
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import VaultLib

    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

    aje = AnsibleJSONEncoder()

    assert '1' == aje.default(1)
    assert '"1"' == aje.default('1')
    assert 'true' == aje.default(True)
    assert 'false' == aje.default(False)
    assert 'null' == aje.default(None)
    assert [1, 2, 3] == aje.default([1, 2, 3])

# Generated at 2022-06-11 00:59:14.748920
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    f_list = [
        (datetime.datetime.utcnow(), True),
        (datetime.date.today(), True),
        (1, False),
        ("abc", False),
    ]

    json_encoder = AnsibleJSONEncoder()
    for f in f_list:
        res = json_encoder.default(f[0])
        if f[1]:
            assert isinstance(res, str)
        else:
            assert isinstance(res, type(f[0]))

    # Test for __ENCRYPTED__
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    password = 'password'
    vault.encrypt_string(password)
    res = json_encoder.default(vault)

# Generated at 2022-06-11 00:59:21.236985
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    raw = {'hello': 'world', 'package': 'ansible', 'version': 2}

    # test encoder
    encoder = AnsibleJSONEncoder(indent=2)
    assert encoder.encode(raw) == '{\n  "hello": "world", \n  "package": "ansible", \n  "version": 2\n}'

    # test encoder without indent
    encoder = AnsibleJSONEncoder()
    assert encoder.encode(raw) == '{"hello": "world", "package": "ansible", "version": 2}'

# Generated at 2022-06-11 00:59:32.468682
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # pylint: disable=too-many-statements
    from ansible.parsing.vault import VaultLib

    def test(data, expected, expected_decoded, vault_to_text=False):
        if not is_sequence(expected):
            expected = [expected]
        if not is_sequence(expected_decoded):
            expected_decoded = [expected_decoded]
        for e in expected:
            assert json.loads(e) == data

        # only check that the results can be decoded
        # by the AnsibleJSONEncoder when ``self._vault_to_text`` is False
        # as the results will differ based on ``self._vault_to_text``

# Generated at 2022-06-11 00:59:43.377228
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = json.loads(json.dumps("test", cls=AnsibleJSONEncoder))
    assert result == "test"

    result = json.loads(json.dumps("test", cls=AnsibleJSONEncoder, indent=4))
    assert result == "test"

    result = json.loads(json.dumps("test", cls=AnsibleJSONEncoder, indent=4, separators=':'))
    assert result == "test"

    result = json.loads(json.dumps("test", cls=AnsibleJSONEncoder, indent=4, separators=(':', ';')))
    assert result == "test"


# Generated at 2022-06-11 00:59:57.146839
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit test for method default of class AnsibleJSONEncoder"""

    import datetime
    from ansible.parsing.vault import VaultLib, VaultSecret

    data = {'hosts': 'localhost', 'vars': {'ansible_user': VaultSecret(VaultLib(password_file=None, password=None).encrypt('redhat'))}}
    json_data = json.dumps(data, cls=AnsibleJSONEncoder, preprocess_unsafe=True)


# Generated at 2022-06-11 01:00:07.383921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultLib

    vault_password = VaultLib.gen_password()
    vault = VaultLib(vault_password)
    secret = vault.encrypt(b'blah')

    a = AnsibleJSONEncoder()
    assert a.default('blah') == 'blah'
    assert a.default(b'blah') == 'blah'
    assert a.default(u'blah') == 'blah'
    assert a.default(u'blah'.encode('utf-16')) == 'blah'
    assert a.default(dict(a='b')) == dict(a='b')
    assert a.default(dict(a=b'b')) == dict(a='b')

# Generated at 2022-06-11 01:00:18.950514
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    var1 = 'some string'
    var2 = {}
    var3 = {'some': 'dict'}
    var4 = ['some', 'list']
    var5 = ['some', {}]
    var6 = {'some': ['list', 'of', {}]}
    var7 = ''
    var8 = b'some bytes'

    # Test the method default of AnsibleJSONEncoder
    # Test the object with base method
    assert AnsibleJSONEncoder().default(var1) == var1
    assert AnsibleJSONEncoder().default(var2) == var2
    assert AnsibleJSONEncoder().default(var3) == var3
    assert AnsibleJSONEncoder().default(var4) == var4
    assert AnsibleJSONEncoder().default(var5) == var5

# Generated at 2022-06-11 01:00:29.554526
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder(sort_keys=True)
    test_mapping = {"test_key":"test_value"}
    test_datetime = datetime.datetime(2020,3,10)
    test_unsafe = u"test_\u0001\u0002unsafe"
    # test for mapping
    ret = json_encoder.default(test_mapping)
    assert ret["test_key"] == "test_value"
    # test for datetime
    ret = json_encoder.default(test_datetime)
    assert ret == "2020-03-10T00:00:00"
    # test for unsafe
    ret = json_encoder.default(test_unsafe)
    assert str(type(ret)) == "<class 'str'>"

# Generated at 2022-06-11 01:00:36.778923
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansibleUnsafe = AnsibleUnsafeText(b'Ansible', b'Ansible')
    ansibleVault = AnsibleVaultEncryptedUnicode(b'Ansible', b'Ansible')
    dateObj = datetime.date.today()
    dateTimeObj = datetime.datetime.today()

    encoder = AnsibleJSONEncoder()

    assert isinstance(encoder.default(ansibleUnsafe), dict)

    assert isinstance(encoder.default(ansibleVault), dict)

    assert isinstance(encoder.default(dateObj), str)

    assert isinstance(encoder.default(dateTimeObj), str)

# Generated at 2022-06-11 01:00:41.968407
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Arrange
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    # Act
    result = ansible_json_encoder.default('AAAAA')
    # Assert
    assert result == 'AAAAA'


# Generated at 2022-06-11 01:00:53.597296
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.collections import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.collections import AnsibleUnsafeText
    from ansible.module_utils.common.collections import AnsibleUnsafeBytes

    a = AnsibleVaultEncryptedUnicode('my-vault-secret')
    aj = AnsibleJSONEncoder()
    assert aj.default(a) == {'__ansible_vault': 'my-vault-secret'}
    assert aj.default(a) == json.dumps(a, cls=AnsibleJSONEncoder, vault_to_text=True)

    b = AnsibleUnsafeText('my-unsafe-secret')
    bu = AnsibleUnsafeBytes('my-unsafe-secret')
    assert aj

# Generated at 2022-06-11 01:01:00.532560
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Passing non safe value to default method
    assert AnsibleJSONEncoder().default(1) == 1

    # Passing non safe value to default method
    non_safe_string = AnsibleJSONEncoder().default('I am non safe') == 'I am non safe'

    # Passing Non safe list to default method
    non_safe_list = AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]

    # Passing date object to default method
    class DummyDate(object):
        def __init__(self, date_string):
            self.date_string = date_string

        def isoformat(self):
            return self.date_string

    dummy_date = DummyDate('2020-05-27')

# Generated at 2022-06-11 01:01:11.603467
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert('__ansible_vault' in ansible_json_encoder.default({"__ENCRYPTED__": True, "_ciphertext": 42}))
    assert('__ansible_vault' not in ansible_json_encoder.default({"__ENCRYPTED__": False, "_ciphertext": 42}))
    assert('__ansible_unsafe' in ansible_json_encoder.default({"__UNSAFE__": True, "__ENCRYPTED__": False}))
    assert('__ansible_unsafe' not in ansible_json_encoder.default({"__UNSAFE__": False, "__ENCRYPTED__": False}))

# Generated at 2022-06-11 01:01:21.626588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    python_version = sys.version_info[0]
    my_json_encoder = AnsibleJSONEncoder(indent=2, sort_keys=True)

    def my_format(value):
        return to_text(json.dumps(value, ensure_ascii=False, cls=my_json_encoder))

    def assert_equal_formated_json(expected, actual):
        assert my_format(actual) == my_format(expected)

    assert_equal_formated_json({"a": "1"}, {"a": "1"})
    assert_equal_formated_json({"a": "2"}, {"a": "2"})
    assert_equal_formated_json({"a": "2"}, {"a": u"2"})
    assert_equal_formated_json

# Generated at 2022-06-11 01:01:38.005438
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib as Vault
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    vault = Vault('test', 'password')

# Generated at 2022-06-11 01:01:47.797202
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    assert "{\"__ansible_vault\": \"[vault_ciphertext]\"}" == json.dumps(object, cls=AnsibleJSONEncoder)
    assert "\"[vault_ciphertext]\"" == json.dumps(object, cls=AnsibleJSONEncoder, vault_to_text=True)
    object = {'__ansible_unsafe': 'b\'<console>\''}
    assert "{\"__ansible_unsafe\": \"b'<console>'\"}" == json.dumps(object, cls=AnsibleJSONEncoder)
    assert "\"b'<console>'\"" == json.dumps(object, cls=AnsibleJSONEncoder, preprocess_unsafe=True)

# Generated at 2022-06-11 01:01:53.509036
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # ansible_vault
    encoder._vault_to_text = False
    data1 = {'ansible_vault': """$ANSIBLE_VAULT;1.1;AES256;test
39356661613265336338383538333934663636323235633431623261653965323032363233316430
32303930626337316631366163633034383361373731326331666636633337343939626533373062
38
"""}

# Generated at 2022-06-11 01:02:03.030251
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.common.json_utils
    from ansible.module_utils.common.vault import VaultLib
    from ansible.module_utils.common.vault import VaultSecret
    from ansible.module_utils.common.unsafe_proxy import AnsibleUnsafeText

    ansible_unsafe_text = AnsibleUnsafeText(b'test123')
    dict_ = dict({'test': ansible_unsafe_text})
    list_ = [ansible_unsafe_text]
    hostvars = {'test123': {'hostvars': ansible_unsafe_text}}
    date = datetime.datetime.now().date()

    encoder = ansible.module_utils.common.json_utils.AnsibleJSONEncoder()

# Generated at 2022-06-11 01:02:12.134109
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Given
    obj = AnsibleJSONEncoder()
    ansible_vault = AnsibleJSONEncoder._ansible_vault
    test_vault = ansible_vault.VaultEncryptedUnicode('test_data')
    obj._vault_to_text = True

    # Assert
    assert obj.default(test_vault) == 'test_data'

    obj._vault_to_text = False

    assert obj.default(test_vault) == {'__ansible_vault': 'test_data'}



# Generated at 2022-06-11 01:02:23.334225
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    # Test from super-class
    data = [ 10, u'unicode', -3.1415 ]
    for d in data:
        assert d == json.loads(json.dumps(d, cls=AnsibleJSONEncoder)), "with bare data"
        assert json.loads(json.dumps({"value": d}, cls=AnsibleJSONEncoder)) == {"value": d}, "with dict"

    # Test-cases for method default
    #         * self._vault_to_text=False
    #         * self._vault_to_text=True
    data = [ (False, u'secret'), (True, u'this is secret') ]
    for d in data:
        vault_to_text, expected_result = d
        vault

# Generated at 2022-06-11 01:02:31.526511
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Instance of AnsibleJSONEncoder
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)

    class Dummy(object):
        def __init__(self, value):
            self.value = value

    # test for object
    assert ansible_json_encoder.default(Dummy(1)) == 1

    # test for datetime.datetime
    assert ansible_json_encoder.default(datetime.datetime(2017, 9, 1, 10, 27, 10, 172452)) == '2017-09-01T10:27:10.172452'

    # test for datetime.date
    assert ansible_json_encoder.default(datetime.date(2017, 9, 1)) == '2017-09-01'



# Generated at 2022-06-11 01:02:41.065508
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # type: () -> None
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import u
    from ansible.utils.unsafe_proxy import AnsibleUnsafe
    import datetime
    # Non-string type for AnsibleUnsafe
    obj1 = AnsibleUnsafe([{u'cipher': u'AES256', u'vault_id': u'1', u'secret': u'$ANSIBLE_VAULT;1.1;AES256;one\no[...]'}])

# Generated at 2022-06-11 01:02:53.386757
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import string_types
    from ansible.module_utils.common.text.converters import to_bytes
    # test None
    obj=None
    assert AnsibleJSONEncoder().default(obj) == obj
    # test int
    obj=1
    assert AnsibleJSONEncoder().default(obj) == obj
    # test float
    obj=1.1
    assert AnsibleJSONEncoder().default(obj) == obj
    # test list
    obj=[1,2,3]
    assert AnsibleJSONEncoder().default(obj) == obj
    # test set
    obj={'a','b','c'}
    assert AnsibleJSONEncoder().default(obj) == list(obj)
    # test dict
    obj={'a':1,'b':'1'}
   

# Generated at 2022-06-11 01:03:04.320967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.loads('["foo"]') == json.loads(str(AnsibleJSONEncoder().encode('foo')))
    assert json.loads('["foo", "bar"]') == json.loads(str(AnsibleJSONEncoder().encode(['foo', 'bar'])))
    assert json.loads('{"foo": "bar"}') == json.loads(str(AnsibleJSONEncoder().encode({'foo': 'bar'})))
    assert json.loads('{"__ansible_vault": "bar"}') == json.loads(str(AnsibleJSONEncoder(vault_to_text=False).encode('VARIABLE_STRING')))

# Generated at 2022-06-11 01:03:26.376017
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes, to_native
    from json import dumps

    from ansible.plugins.loader import find_plugin
    passwd = 'th3p4ssw0rd'
    vault = find_plugin("vault")()
    vault_secret = VaultSecret(passwd)
    vault_id = vault.create_identifier()
    vault.set_secret(vault_id, vault_secret)
    ciphertext = to_native(VaultLib.encrypt("hello", vault_secret, vault_id))
    vault_obj = VaultLib(vault_id, passwd)
    decrypted = vault_obj.decrypt(to_bytes(ciphertext))

# Generated at 2022-06-11 01:03:36.549887
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import AnsibleURL
    from ansible.parsing.vault import VaultLib

    vault_password = 'supersecret'
    vault = VaultLib([])
    vault.update(vault_password)

    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    class AnsibleVault(str):
        __ENCRYPTED__ = True


# Generated at 2022-06-11 01:03:40.857445
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # setup
    ansiblejsonencoder = AnsibleJSONEncoder()
    obj = dict(test1='Test1')
    obj_test = ansiblejsonencoder.default(obj)
    # assert
    assert isinstance(obj_test, dict)


# Generated at 2022-06-11 01:03:49.542169
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    o = {u'a': u'b'}
    assert json.dumps(o, cls=encoder) == "{\"a\": \"b\"}"
    o = [u'a', u'b']
    assert json.dumps(o, cls=encoder) == "[\"a\", \"b\"]"
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    o = AnsibleUnsafe(u'It is unsafe')
    assert json.dumps(o, cls=encoder) == "{\"__ansible_unsafe\": \"It is unsafe\"}"
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    o = AnsibleUnsafeText(u'It is unsafe')

# Generated at 2022-06-11 01:04:00.763735
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys

    class TestObj:
        def __init__(self, msg):
            self.msg = msg

        def __str__(self):
            return self.msg

    class TestUnsafe(str):
        __UNSAFE__ = True

    class TestVault(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    test_obj_1 = TestObj(msg='message 1')
    test_obj_2 = {'key': 'value'}
    test_obj_3 = [1, 2, 3, 4]
    test_obj_4 = {'a': 'b', 'c': 'd', 'e': 'f'}
    test_obj_5 = TestUnsafe(value='this is an unsafe test')

# Generated at 2022-06-11 01:04:09.555921
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert u'null' == json.dumps(None, cls=AnsibleJSONEncoder)
    assert u'true' == json.dumps(True, cls=AnsibleJSONEncoder)
    assert u'100' == json.dumps(100, cls=AnsibleJSONEncoder)
    assert u'"foo"' == json.dumps('foo', cls=AnsibleJSONEncoder)
    assert u'["foo"]' == json.dumps(['foo'], cls=AnsibleJSONEncoder)
    assert u'["foo","bar"]' == json.dumps(['foo', 'bar'], cls=AnsibleJSONEncoder)
    assert u'{"foo":"bar"}' == json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-11 01:04:20.796185
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import shutil
    # import the module as well because we need the class in it
    from ansible.module_utils.basic import AnsibleModule

    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(None) is None
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    assert json_encoder.default(None) is None
    json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert json_encoder.default(None) is None

    assert json_encoder.default(True) is True
    assert json_encoder.default(False) is False
    assert json_encoder.default(17) == 17
    assert json_encoder.default(6.7) == 6.7

# Generated at 2022-06-11 01:04:31.096815
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    import crypt
    import datetime

    def test_case(o):
        print("\nTest case:")
        print("\tclass name: %s" % type(o).__name__)
        print("\tvalue: %s" % o)
        print("\ttype: %s" % type(o))
        ans = AnsibleJSONEncoder()
        print("\tresult: %s" % ans.default(o))

    # Test case 1: class AnsibleUnsafeText
    from ansible.module_utils.basic import AnsibleUnsafeText
    obj = AnsibleUnsafeText("abc")
    test_case(obj)

    # Test case 2: class AnsibleVaultEncryptedUnicode
    obj = VaultLib("abc")
   

# Generated at 2022-06-11 01:04:41.379013
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword

    vault_file = VaultLib()
    vault_file.load([VaultSecret(VaultPassword('pass'))])

# Generated at 2022-06-11 01:04:50.053867
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    aje = AnsibleJSONEncoder()
    import ansible.parsing.vault
    vault = ansible.parsing.vault.VaultLib('test')
    a = vault.encrypt('test')

# Generated at 2022-06-11 01:05:19.555996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    data = dict(a=42, b="test", c=dict(a=1, b=2))
    assert data == encoder.default(data)

    class Foo(object):
        def __init__(self):
            self.a = 42
            self.b = 'test'
            self.c = dict(a=1, b=2)

    data = Foo()
    assert dict(a=42, b="test", c=dict(a=1, b=2)) == encoder.default(data)

    data = datetime.datetime(2018, 1, 1)
    assert '2018-01-01T00:00:00' == encoder.default(data)

    class Bar(object):
        def __init__(self):
            self.a = 42


# Generated at 2022-06-11 01:05:30.125543
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # define a string with non-ascii characters
    non_ascii = '\xe4\xbd\xa0\xe5\xa5\xbd'
    # create an AnsibleJSONEncoder instance
    aje = AnsibleJSONEncoder()
    # test default() with non-ascii
    assert aje.default(non_ascii) == non_ascii
    # test default() with non-ascii and ensure it is converted to utf-8
    assert aje.default(non_ascii) == '\xe4\xbd\xa0\xe5\xa5\xbd'
    import datetime
    # test default() with a date
    assert aje.default(datetime.date(year=2017, month=11, day=22)) == '2017-11-22'

# Generated at 2022-06-11 01:05:33.493602
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert dict(AnsibleJSONEncoder().default({})) == {}
    assert AnsibleJSONEncoder().default(datetime.datetime.now()) == AnsibleJSONEncoder().default(datetime.datetime.now().date())


# Generated at 2022-06-11 01:05:41.852605
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for no error when the input is a string.
    string_a = "Hello World!"
    string_b = AnsibleJSONEncoder().default(string_a)
    # Test for no error when the input is a dict.
    dict_a = {
        "a": 1,
        "b": 2,
        "c": 3
    }
    dict_b = AnsibleJSONEncoder().default(dict_a)
    # Test for no error when the input is a list.
    list_a = [1,2,3]
    list_b = AnsibleJSONEncoder().default(list_a)

# Generated at 2022-06-11 01:05:52.945120
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import PY3
    from datetime import date, datetime

    if not PY3:
        # these types are not supported in python 2.x
        return

    x = AnsibleJSONEncoder()
    assert x.default(b'foobar') == 'foobar'
    assert x.default(date(2018, 3, 13)) == '2018-03-13'
    assert x.default(datetime.now()) == datetime.now().isoformat()

# Generated at 2022-06-11 01:06:02.738043
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert json.dumps({'whoa': 'what'}, cls=AnsibleJSONEncoder) == '{"whoa": "what"}'
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-11 01:06:11.599376
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test with default values
    encoder = AnsibleJSONEncoder()

    # Test with vault object
    raw_vault_data = '4573fd2d0a1f62dd'.decode('hex')
    vault_data = u'VaultLib.Vault(' + to_text(raw_vault_data) + u')'
    vault_string_value = {'__ansible_vault': to_text(raw_vault_data, errors='surrogate_or_strict', nonstring='strict')}
    assert encoder.default(vault_data) == vault_string_value

    # Test with unsafe object
    raw_unsafe_data = "4573fd2d0a1f62dd".decode("hex")

# Generated at 2022-06-11 01:06:18.211261
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    arr = [10, 20, 30]
    brr = {'a': 10, 'b': 20, 'c': 30}
    crr = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    s = crr.encode(arr)
    t = crr.encode(brr)
    assert(s == '[10, 20, 30]')
    assert(t == '{"a": 10, "b": 20, "c": 30}')


# Generated at 2022-06-11 01:06:27.993551
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.basic import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.basic import AnsibleUnsafeText

    enc = AnsibleJSONEncoder()
    assert enc.default("test") == "test"
    assert enc.default("test\n") == "test\n"
    assert enc.default("test\r") == "test\r"
    assert enc.default("test\u0a0d") == "test\u0a0d"
    assert enc.default("test\u0a0d\r\n") == "test\u0a0d\r\n"
    assert enc.default("\u0a0d") == "\u0a0d"

# Generated at 2022-06-11 01:06:36.523618
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import b
    from datetime import datetime, timezone

    v = VaultSecret('$ANSIBLE_VAULT;1.1;AES256\ntest\n')
    d = datetime.now()

    # VaultSecret object
    assert AnsibleJSONEncoder(vault_to_text=True).encode(v) == b(to_text(v, errors='surrogate_or_strict'))
    assert json.loads(AnsibleJSONEncoder().encode(v)) == {'__ansible_vault': to_text(v._ciphertext, errors='surrogate_or_strict', nonstring='strict')}

    # string
    assert AnsibleJSONEncoder().encode('test')

# Generated at 2022-06-11 01:07:19.451473
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Test(object):
        def __init__(self, key="value"):
            self.key = key

    test_data = {"test": Test()}
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    encoded = encoder.default(test_data)
    assert encoded == {"test": {"key": "value"}}

# Generated at 2022-06-11 01:07:22.050076
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert isinstance(json.dumps({}, cls=AnsibleJSONEncoder), basestring)
    assert isinstance(json.dumps({1: 1}, cls=AnsibleJSONEncoder), basestring)

# Generated at 2022-06-11 01:07:32.262544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import binary_type
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedBytes
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.basic import _NoValue
    from ansible.module_utils.urls import _AnsibleUnsafeBytes, _AnsibleUnsafeText
    import datetime

    vault_password = 'somepassword'
    vaultlib = VaultLib(vault_password)

    vault_text = AnsibleVaultEncryptedUnicode(vaultlib.encrypt(u'somevalue'))

# Generated at 2022-06-11 01:07:36.748720
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    A unit test for method default of class AnsibleJSONEncoder.
    :return:
    '''
    encoder = AnsibleJSONEncoder()
    data = {'age': 27, 'name': 'Jenny'}
    assert(encoder.default(data) == data)


# Generated at 2022-06-11 01:07:43.448626
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).default(AnsibleUnsafe('unsafe')) == 'unsafe'
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(AnsibleUnsafe('unsafe')) == {'__ansible_unsafe': 'unsafe'}
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(AnsibleUnsafe('unsafe')) == {'__ansible_unsafe': 'unsafe'}



# Generated at 2022-06-11 01:07:52.195680
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(2) == 2
    assert AnsibleJSONEncoder().default('string') == 'string'
    assert AnsibleJSONEncoder().default([1, 2, 3]) == [1, 2, 3]
    assert AnsibleJSONEncoder().default({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert AnsibleJSONEncoder().default(datetime.date(2018, 10, 23)) == '2018-10-23'
    assert AnsibleJSONEncoder().default(datetime.datetime(2018, 10, 23, 12, 23, 34, 1234)) == '2018-10-23T12:23:34.001234'

# Generated at 2022-06-11 01:07:57.539355
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(False) is False
    assert encoder.default(True) is True
    assert encoder.default(1) == 1
    assert encoder.default('abc') == 'abc'
    assert encoder.default(u'abc') == u'abc'
    assert '__ansible_unsafe' in encoder.default(dict(__ansible_unsafe=b'abc'))


# Generated at 2022-06-11 01:08:05.726507
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(None) is None
    assert AnsibleJSONEncoder().default(1) == 1
    assert isinstance(AnsibleJSONEncoder().default(1), int)
    assert AnsibleJSONEncoder().default(1.5) == 1.5
    assert isinstance(AnsibleJSONEncoder().default(1.5), float)
    assert AnsibleJSONEncoder().default('one') == '"one"'
    assert AnsibleJSONEncoder().default(b'byte') == '"byte"'
    assert isinstance(AnsibleJSONEncoder().default(b'byte'), str)
    assert AnsibleJSONEncoder().default(u'unicode') == '"unicode"'
    assert isinstance(AnsibleJSONEncoder().default(u'unicode'), str)
    assert AnsibleJSONEncoder