

# Generated at 2022-06-11 00:58:15.193372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = AnsibleJSONEncoder()
    test_dict = dict(a=1, b=2)
    test_dict1 = dict(a=dict(c=3, d=4), b=dict(e=5, f=6))
    test_dict2 = dict(a=dict(c=[7, 8, 9], d=[10, 11, 12]), b=dict(e=[13, 14, 15], f=[16, 17, 18]))
    test_dict3 = dict(a=dict(c=[dict(g=19, h=20)], d=[dict(j=21, k=22)]), b=dict(e=[dict(l=23, m=24)], f=[dict(n=25, o=26)]))
    test_list = [1, 2, 3]

# Generated at 2022-06-11 00:58:26.946030
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.parsing.vault import VaultLib

    vault_obj = VaultLib([], None, None)
    vault_value = vault_obj.encrypt('testvalue')


# Generated at 2022-06-11 00:58:34.503536
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default({"key": "value"}) == {"key": "value"}
    assert encoder.default("value") == "value"
    assert encoder.default({"AnsibleUnsafe": b"value"}) == {"AnsibleUnsafe": "value"}
    assert encoder.default(datetime.datetime(2019, 1, 1)) == "2019-01-01T00:00:00"
    assert encoder.default(datetime.date(2019, 1, 1)) == "2019-01-01"

# Generated at 2022-06-11 00:58:40.874194
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-11 00:58:52.807824
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 00:59:02.946186
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import random
    from ansible.parsing.vault import VaultSecret, VaultAES256


# Generated at 2022-06-11 00:59:11.725488
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test Encoder class
    enc = AnsibleJSONEncoder()
    # Test with a datetime object
    dt = datetime.datetime.now()
    result = enc.default(dt)
    assert result == dt.isoformat()
    # Test with a dictionary object
    d = {"hi": 12, "hello": [1, 2, 3]}
    result = enc.default(d)
    assert result == d
    # Test with a date object
    now = datetime.datetime.now().date()
    result = enc.default(now)
    assert result == now.isoformat()


# Generated at 2022-06-11 00:59:21.459518
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    vault_key = 'V7Dh/rIQmfhXQZt0+VtE8w=='
    vault = VaultLib([vault_key], DEFAULT_VAULT_ID_MATCH)


# Generated at 2022-06-11 00:59:32.845336
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    from ansible_collections.community.general.plugins.module_utils.basic import AnsibleUnsafe

    import ansible.module_utils.common._collections_compat as collections_compat

    # Test with VaultLib and VaultSecret
    vault_secret = VaultSecret('awesome')
    assert isinstance(vault_secret, collections_compat.string_types)

    encoder = AnsibleJSONEncoder()
    encoder_text = AnsibleJSONEncoder(vault_to_text=True)

    vault = VaultLib([vault_secret])
    assert isinstance(vault, VaultLib)

    # Test with VaultLib
   

# Generated at 2022-06-11 00:59:43.726460
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('test_string') == 'test_string'
    assert encoder.default(['test_list']) == ['test_list']
    assert encoder.default({'test_dict': 'test_data'}) == {'test_dict': 'test_data'}
    assert encoder.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()
    assert encoder.default(datetime.date.today()) == datetime.date.today().isoformat()
    from ansible.parsing.vault import VaultLib
    assert encoder.default(VaultLib('test_password'))['__ansible_vault'] == VaultLib('test_password')._ciphertext
    from ansible.module_utils.six import text

# Generated at 2022-06-11 00:59:53.451677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(datetime.datetime(2018, 4, 1, 10, 12, 15)) == "2018-04-01T10:12:15"
    assert json_encoder.default(datetime.date(2018, 4, 1)) == "2018-04-01"
    assert json_encoder.default(["a", "b", "c"]) == ["a", "b", "c"]
    assert json_encoder.default({"a": "b"}) == {"a": "b"}



# Generated at 2022-06-11 01:00:04.671296
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 01:00:09.138374
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafeText
    json_encoder = AnsibleJSONEncoder()
    ansible_unsafe = AnsibleUnsafeText('AnsibleUnsafeText')
    assert json_encoder.default(ansible_unsafe) == {'__ansible_unsafe': 'AnsibleUnsafeText'}


# Generated at 2022-06-11 01:00:21.049478
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultEditor
    vault_pass = VaultEditor('mypassword')

    # test for __ENCRYPTED__
    value = vault_pass.encode('myvalue')
    assert AnsibleJSONEncoder(vault_to_text=True).default(value) == 'myvalue'
    assert AnsibleJSONEncoder(vault_to_text=False).default(value) == {'__ansible_vault': vault_pass.encode('myvalue')}

    # test for __UNSAFE__
    value = AnsibleUnsafeText('myvalue')
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(value) == 'myvalue'

# Generated at 2022-06-11 01:00:31.820996
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Unit test for method default of class AnsibleJSONEncoder
    '''
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    json_encoder = AnsibleJSONEncoder()


# Generated at 2022-06-11 01:00:39.224588
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.urls import AnsibleUnsafeUrl
    assert json.dumps(AnsibleUnsafeUrl('https://www.example.com'), cls=AnsibleJSONEncoder) == json.dumps({'__ansible_unsafe': u'https://www.example.com'})
    assert json.dumps(AnsibleUnsafeUrl('https://www.example.com'), cls=AnsibleJSONEncoder, ensure_ascii=False) == json.dumps({'__ansible_unsafe': u'https://www.example.com'})


# Generated at 2022-06-11 01:00:51.739064
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.vars.unsafe_proxy
    import dateutil.parser

    encoder = AnsibleJSONEncoder()

    # text
    assert encoder.default('Hello World!') == 'Hello World!'
    assert encoder.default('💩') == u'💩'

    # unsafe
    unsafe = ansible.vars.unsafe_proxy.AnsibleUnsafeText(u'Hello World!')
    assert encoder.default(unsafe) == {'__ansible_unsafe': 'Hello World!'}

    # vault
    vault = ansible.vars.unsafe_proxy.AnsibleVaultEncryptedUnicode(u'Hello World!')
    assert encoder.default(vault) == {'__ansible_vault': 'Hello World!'}

    # mapping
    test_dict

# Generated at 2022-06-11 01:00:59.900200
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    vault_password = 'default'

    unsafe_text = 'unsafe'
    ansible_unsafe = AnsibleUnsafe(unsafe_text)

    safe_text = 'safe'
    ansible_safe = AnsibleUnsafe(safe_text, unsafe=False)

    encrypted_text = VaultEditor.encrypt_text(unsafe_text, vault_password)
    ansible_encrypted_text = AnsibleUnsafe(encrypted_text, encrypted=True)

    not_unsafe_text = 'not unsafe'

    json_encoder = AnsibleJSONEncoder()
    assert json_encoder.default(ansible_unsafe) == {'__ansible_unsafe': unsafe_text}

# Generated at 2022-06-11 01:01:10.960591
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import datetime

    # Testing for VaultLib object
    ansible_json_encoder = AnsibleJSONEncoder(vault_to_text=False)
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n393335653864346231656430326165613463633035663964376637643566306436373565333561\n363263303234616231376535376364373563343831326362313765343935303362653335616139\n323162336439653530363861333135633066313063666132666262623161306133373635656562\n65663561\n'
    vault_obj = Vault

# Generated at 2022-06-11 01:01:21.092544
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.parsing.vault import VaultSecret
    # hostvars
    assert json.loads(json.dumps(HostVars({'k': 'v'}), cls=AnsibleJSONEncoder)) == {'k': 'v'}
    # unsafe
    assert json.loads(json.dumps(AnsibleUnsafe('v'), cls=AnsibleJSONEncoder)) == {'__ansible_unsafe': 'v'}
    # Encrypted vault secret
    assert json.loads(json.dumps(VaultSecret('v'), cls=AnsibleJSONEncoder)) == {'__ansible_vault': 'v'}
    # Encrypted

# Generated at 2022-06-11 01:01:26.577915
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import json
    json.JSONEncoder.default(None, None)

# Generated at 2022-06-11 01:01:37.956339
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    check_o = ['vault', 'unsafe']
    for o in check_o:
        class TestObj:
            def __init__(self, value):
                self.value = value
            def __getattr__(self, attr):
                if attr == '__ENCRYPTED__':
                    return True if self.value == 'vault' else False
                elif attr == '__UNSAFE__':
                    return True if self.value == 'unsafe' else False
            def __str__(self):
                return '{}_str'.format(self.value)
            def __unicode__(self):
                return u'{}_unicode'.format(self.value)

# Generated at 2022-06-11 01:01:46.457181
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    # testing ``AnsibleVaultEncryptedUnicode``
    encrypted = {'__ansible_vault': u'$ANSIBLE_VAULT;1.1;AES256;somesalt\n636335353638326633353065643134313237353034643835356238626262666162386338616363633863\n366137303865643334646434353562323966343262356638646631393664303631333539393530373634\n33373036373938\n'}

# Generated at 2022-06-11 01:01:53.080856
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    d1 = datetime.date(2014, 11, 22)
    d2 = datetime.datetime(2014, 11, 22, 12, 12, 12)

    assert encoder.default(d1) == "2014-11-22"  # type: ignore[attr-defined]
    assert encoder.default(d2) == "2014-11-22T12:12:12"  # type: ignore[attr-defined]

# Generated at 2022-06-11 01:02:00.666884
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import BytesIO
    from ansible.module_utils.common.datetime import _datetime_to_json
    import ansible.module_utils.common.removed as removed
    import ansible.module_utils.urls as urls
    import ansible.module_utils.redhat_subscription as redhat_subscription
    import ansible.module_utils.ec2 as ec2
    import ansible.module_utils.basic as basic

    class Useless(object):
        _spec = {'id': '1234'}

        def __getattribute__(self, *args, **kwargs):
            return "Useless"

    class DateObj:
        def __str__(self, *args, **kwargs):
            return "20201011"


# Generated at 2022-06-11 01:02:12.519112
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

# Generated at 2022-06-11 01:02:18.000094
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert AnsibleJSONEncoder().encode(dict(a='a', b=AnsibleUnsafeText('b'))) == json.dumps({'a': 'a', 'b': 'b'})
    assert AnsibleJSONEncoder().encode(dict(a=AnsibleUnsafeText('b'), b='b')) == json.dumps({'a': 'b', 'b': 'b'})

    vault_lib = VaultLib([])
    vault_pass = 'pass'
    encrypted_text = vault_lib.encrypt('text', vault_pass)
    assert isinstance(encrypted_text, AnsibleUnsafeText)

# Generated at 2022-06-11 01:02:25.751285
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.ansible_unsafe import AnsibleUnsafe
    unsafe_obj = AnsibleUnsafe("foo")
    result = AnsibleJSONEncoder().default(unsafe_obj)
    assert result == {'__ansible_unsafe': "foo"}
    result = AnsibleJSONEncoder().default(datetime.datetime(2017, 1, 1))
    assert result == "2017-01-01T00:00:00"
    result = AnsibleJSONEncoder().default(datetime.date(2017, 1, 1))
    assert result == "2017-01-01"

# Generated at 2022-06-11 01:02:33.660308
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Check default return
    o = AnsibleJSONEncoder()
    assert o.default(['test']) == ['test']

    # Check return for Vault objects
    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')

# Generated at 2022-06-11 01:02:42.841262
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)

    #Test a dictionary
    dictionary = {'result': {'_ansible_verbose_override': True, '_ansible_no_log': False,
                             'invocation': {'module_args': 'ping', 'module_name': 'ping',
                                            'module_complex_args': {'data': {'data': 'stuff'}}},
                             'changed': True, 'ping': 'pong'}}

# Generated at 2022-06-11 01:03:01.679372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault as vault

    # AnsibleVaultEncryptedUnicode object
    sk = vault.VaultLib([])
    o = vault.VaultSecret('secret', b'$ANSIBLE_VAULT;0.1;AES256', sk.decrypt)
    result = AnsibleJSONEncoder().default(o)
    assert {'__ansible_vault': '$ANSIBLE_VAULT;0.1;AES256'} == result

    # date object
    o = datetime.datetime(2018, 7, 12, 20, 34, 56, 345000)
    result = AnsibleJSONEncoder().default(o)
    assert '2018-07-12T20:34:56.345000' == result

    # dict object
    o = {'key': 'value'}


# Generated at 2022-06-11 01:03:09.105670
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    test_data = "us-east-1c"
    test_o = datetime.datetime.now()
    test_o_dict = dict(Foo=0, Bar=True, Baz="Baz")
    test_json = json.dumps(test_o.strftime("%Y-%m-%d %H:%M:%S"))
    test_json_dict = AnsibleJSONEncoder().default(test_o_dict)
    test_json_dumps = AnsibleJSONEncoder().default(test_data)
    assert test_json == test_json_dumps
    assert test_o_dict == test_json_dict

# Generated at 2022-06-11 01:03:21.174196
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import six
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.common.collections import is_sequence

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    json_encoder = json.JSONEncoder()

    stdout = sys.stdout
    sys.stdout = StringIO()
    # With types we care about, call through to the default JSON encoder

# Generated at 2022-06-11 01:03:30.885237
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.module_utils.six import PY3
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.six.moves.urllib.error import HTTPError, URLError
    import ansible.module_utils.urls
    import re

    class AnsibleUnsafe:
        __UNSAFE__ = True
        __ENCRYPTED__ = False

        def __init__(self, value):
            self.value = value

        def __str__(self):
            return self.value

        def __repr__(self):
            return '<%s value=%s>' % (type(self).__name__, repr(self.value))


# Generated at 2022-06-11 01:03:42.095172
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    Basic test of class AnsibleJSONEncoder as used in ansible/module_utils/__init__.py
    '''

    from ansible.module_utils import basic

    # test with basic.AnsibleModule
    module = basic.AnsibleModule(argument_spec=dict())
    test_examples = [
        {
            "name": "testdata",
            "args": {
                "test": module
            }
        },
    ]

    encoder = AnsibleJSONEncoder(preprocess_unsafe=False)

    try:
        encoder.iterencode(test_examples)
    except TypeError:
        assert False, "expected exception is not raised"

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True)

# Generated at 2022-06-11 01:03:45.610651
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Test basic functionality of method default"""
    ansible_obj = {"field": "value"}
    result = AnsibleJSONEncoder().default(ansible_obj)
    assert isinstance(result, dict)
    assert result == {"field": "value"}



# Generated at 2022-06-11 01:03:51.986686
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    assert json.dumps({"test": {"message": "AnsibleUnsafe(b'testunsafe')", "tee": "teststring"}}, cls=AnsibleJSONEncoder, preprocess_unsafe=True) == '{"test": {"message": {"__ansible_unsafe": "b\'testunsafe\'"}, "tee": "teststring"}}'

    # vault object
    vault_encoded = json.dumps(VaultLib({}).encrypt('testvault'), cls=AnsibleJSONEncoder)

# Generated at 2022-06-11 01:04:03.689998
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.module_utils.basic import AnsibleUnsafeText
    from ansible.module_utils.six import u
    from ansible.parsing.vault import VaultLib

    class TestClass(object):

        def __init__(self, value):
            self.value = value

        @property
        def __UNSAFE__(self):
            return True

    test_value = u('Žluťoučký koníček')
    test_vault = VaultLib()

    # Instance of AnsibleUnsafeText
    test_instance = AnsibleUnsafeText(test_value)

    # Assert with AnsibleUnsafeText
    #  test_value is an AnsibleUnsafeText
    #  instance of AnsibleUnsafeText
    #  call default method, it should return a list

# Generated at 2022-06-11 01:04:14.922644
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('foo') == 'foo'
    assert AnsibleJSONEncoder(sort_keys=True).default(['foo']) == ['foo']
    assert AnsibleJSONEncoder().default({'foo': 'bar'}) == {'foo': 'bar'}

    # python2 + python3 compatible datetime string
    url = 'https://pypi.python.org/pypi/python-dateutil#id8'
    iso8601_format = '%Y-%m-%dT%H:%M:%S.%fZ'
    ansible_json_now = AnsibleJSONEncoder().default(datetime.datetime.now())
    dateutil_now = datetime.datetime.now().strftime(iso8601_format).replace('+00:00', 'Z')
   

# Generated at 2022-06-11 01:04:18.476963
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(to_text(42, errors='surrogate_or_strict')) == to_text(42, errors='surrogate_or_strict')


# Generated at 2022-06-11 01:04:45.651038
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test for None
    o = None
    c = AnsibleJSONEncoder()
    assert c.default(o) is None

    # Test for list
    o = [None]
    c = AnsibleJSONEncoder()
    assert c.default(o) is [None]

    # Test for dict
    o = {'x': None}
    c = AnsibleJSONEncoder()
    assert c.default(o) == {'x': None}

    # Test for AnsibleUnsafe
    o = AnsibleUnsafe(u'\u20ac')
    c = AnsibleJSONEncoder()
    assert c.default(o) == {'__ansible_unsafe': u'\u20ac'}

    # Test for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 01:04:51.787761
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {
        'a': True,
        'b': 2.0,
        'c': [1, 2, 3],
        'd': 'abc',
        'e': {'e': 'abc', 'f': '1'}
    }
    ansible_json_encoder = AnsibleJSONEncoder()
    value = ansible_json_encoder.default(data)
    assert isinstance(value, dict)
    assert value == data



# Generated at 2022-06-11 01:05:02.308804
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.vault import VaultLib

    e = AnsibleJSONEncoder()

    fake_vault_text = '$ANSIBLE_VAULT;1.2;AES256\n61646d696e61737365727665724461746162617365206661766f7572652077617320\n697420746f2062652074686572652312e204974206973206120726f6d6f756e6365\n6f75746564206f6e2061737365727665722e0a0a'

    # Vault Lib
    vault_obj = VaultLib('test')

# Generated at 2022-06-11 01:05:12.170818
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import os
    import sys
    import json
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "lib"))
    from ansible.parsing.vault import VaultLib

    v = VaultLib([], None)
    v.update({'foo': 'bar'})
    v.decrypt_data({'foo': 'bar'})

    assert json.dumps(v, cls=AnsibleJSONEncoder) == '{"__ansible_vault": "AQDySl1ezY+3FiYuJUVBwCiFZRmRZOEpRZWJbMkE1IyFlcEpYb1dkdHlwWTgzNldZTg=="}'

# Generated at 2022-06-11 01:05:20.579594
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib

    class Test:
        pass

    test = Test()
    test.x = "test"

    test2 = Test()
    test2.y = "test2"

    class TestVaultLib(VaultLib):

        def __init__(self):
            pass

        @staticmethod
        def encrypt(string):
            return string

        @staticmethod
        def decrypt(string):
            return string

        def encrypt_vars(self, data, vault_password=None):
            return data

        def decrypt_vars(self, data, vault_password=None):
            return data

    vault_lib = TestVaultLib()


# Generated at 2022-06-11 01:05:30.562273
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test for hostvars or other objects
    with_items = {'name': 'happy', 'age': 18}
    want = b"""{"name": "happy", "age": 18}"""

    aje = AnsibleJSONEncoder()
    got = aje.encode(with_items)
    assert want == got

    # test for date object
    date = datetime.date(2019, 2, 18)
    want = b"""{"__ansible_date": "2019-02-18"}"""

    aje = AnsibleJSONEncoder()
    got = aje.encode(date)
    assert want == got

    # test for use default encoder
    ipaddress = '192.168.1.1'
    want = b"""192.168.1.1"""

    aje = AnsibleJSONEncoder()
   

# Generated at 2022-06-11 01:05:41.304404
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import string_types
    import types
    import datetime
    import tempfile

    vault_password_file = tempfile.NamedTemporaryFile()
    vault_password_file.write('secret_key')
    vault_password_file.flush()

    ansible_unsafe = AnsibleUnsafeText('abc')
    is_unsafe = ansible_unsafe.__UNSAFE__
    is_encrypted = ansible_unsafe.__ENCRYPTED__

    is_vault = (lambda o: getattr(o, '__ENCRYPTED__', False))
    vault = VaultLib([vault_password_file.name])


# Generated at 2022-06-11 01:05:52.537293
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    dt = datetime.datetime(2017, 7, 4, 4, 2)
    d = datetime.date(2017, 7, 4)
    ansible_json_encoder = AnsibleJSONEncoder()
    # test for safe_strings_with_kwargs
    data = {'foo': 'bar', 'x': [1, 2], 'y': {'a': 1, 'b': 2}, 'd': d, 'dt': dt}
    encoder = AnsibleJSONEncoder()
    result = encoder.default(data)
    assert(result == {'foo': 'bar', 'x': [1, 2], 'y': {'a': 1, 'b': 2}, 'd': '2017-07-04', 'dt': '2017-07-04T04:02:00'})
   

# Generated at 2022-06-11 01:06:02.402165
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import sys
    import datetime

    if sys.version_info < (2, 7):
        # Python 2
        import StringIO as StringIO
    else:
        # Python 3
        import io as StringIO

    # required, because during unserialization, the module is not executed in __main__,
    # but in a different module (which has it's own __name__) which can cause issues
    import ansible.module_utils.json_utils as json_utils

    # available, because json_utils was imported
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.common.collections import AnsibleSequence
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-11 01:06:11.361234
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    test_string1 = "hello world"
    test_string2 = AnsibleUnsafe(test_string1)

    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_unsafe_value = {'a': 1, 'b': AnsibleUnsafe(2), 'c': 3}
    test_dict_vault_value = {'a': 1, 'b': VaultLib(test_string1).encrypt(test_string1), 'c': 3}
    test_dict_nested = {'a': 1, 'b': 2, 'c': {'1': 1, '2': 2, '3': 3}}
    test_dict_

# Generated at 2022-06-11 01:06:53.500501
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils import basic
    e = AnsibleJSONEncoder()
    # literal object
    assert e.default('abc') == 'abc'
    # datetime object
    now = datetime.datetime.now()
    assert e.default(now).endswith(':%02d.%06d' % (now.second, now.microsecond))
    # dict object
    assert e.default({'a':1}) == {'a':1}
    # unsafe object
    assert e.default(basic.AnsibleUnsafe('abc')) == {'__ansible_unsafe': 'abc'}
    # vault object
    assert e.default(basic.AnsibleVaultEncryptedUnicode('abc')) == {'__ansible_vault': 'abc'}

# Generated at 2022-06-11 01:06:59.528912
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit tests for method default of class AnsibleJSONEncoder."""
    # Initialize object to be tested
    encoder = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    # This test is not really necessary:
    #   it is just a check if the object initilizes without an exception
    #   this is just a reminder that the function body is empty
    assert True


# Generated at 2022-06-11 01:07:04.516350
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert(encoder.default({1:2})) == {'1': 2}
    assert(encoder.default(datetime.datetime(2018,3,3))) == "2018-03-03T00:00:00"
    assert(encoder.default(datetime.date(2018,3,3))) == "2018-03-03"

# Generated at 2022-06-11 01:07:13.225810
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from .unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 01:07:22.038034
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encrypted = 'test_vault'
    encrypted_str = 'test_str'
    unsafe = 'test_unsafe'
    date = datetime.date(2019, 2, 28)
    custom = {
        'encrypted': encrypted,
        'encrypted_str': encrypted_str,
        'unsafe': unsafe,
        'date': date,
    }
    test_cases = [
        ('encrypted_str', encrypted_str),
        ('date', date),
        ('custom', custom),
    ]
    expected = [
        ('encrypted_str', encrypted_str),
        ('date', '2019-02-28'),
        ('custom', custom),
    ]

    # test not encrypted, unsafe, date, custom object

# Generated at 2022-06-11 01:07:29.150060
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default(1.0) == 1.0

    assert AnsibleJSONEncoder().default("test") == "test"
    assert AnsibleJSONEncoder().default("'''") == "'''"

    # it should remove the __ENCRYPTED__ attribute
    vault_obj = to_text("Test String")
    vault_obj.__ENCRYPTED__ = '42'
    assert AnsibleJSONEncoder().default(vault_obj) == {'__ansible_vault': 'NFRzImjNkvZg'}

    # it should remove the __UNSAFE__ attribute
    unsafe_obj = to_text("Test String")
    unsafe_obj.__UNSAFE__ = '42'
    assert AnsibleJSON

# Generated at 2022-06-11 01:07:39.951505
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.common.unsafe_proxy as unsafe_proxy

    class Test(object):
        def __repr__(self):
            return 'Test'

    assert json.dumps(["foo", "bar"], cls=AnsibleJSONEncoder) == '["foo", "bar"]'
    assert json.dumps({'foo': 'bar'}, cls=AnsibleJSONEncoder) == '{"foo": "bar"}'
    assert json.dumps(unsafe_proxy.AnsibleUnsafeText('AnsibleUnsafeText'), cls=AnsibleJSONEncoder) == '{"__ansible_unsafe": "AnsibleUnsafeText"}'

# Generated at 2022-06-11 01:07:42.119811
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default("test") == "test"
    assert AnsibleJSONEncoder().default('{"test":"test"}') == '{"test":"test"}'



# Generated at 2022-06-11 01:07:51.890360
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the default value of AnsibleJSONEncoder.__init__() with no params
    encoder = AnsibleJSONEncoder()

    # Test AnsibleJSONEncoder.default for AnsibleVault decrypt
    assert encoder.default("__ANSIBLE_VAULT!") == "__ANSIBLE_VAULT!"
    assert encoder.default("#!vault |\n$ANSIBLE_VAULT;1.1;AES256\n") == "#!vault |\n$ANSIBLE_VAULT;1.1;AES256\n"
    assert encoder.default("1.1;AES256\n") == "1.1;AES256\n"
    assert encoder.default("!vault/\n") == "!vault/\n"
    assert encoder.default("!vault |\n")

# Generated at 2022-06-11 01:08:00.183451
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # testing int and string
    int_data = AnsibleJSONEncoder().default(1)
    assert type(int_data) is int
    string_data = AnsibleJSONEncoder().default('test_string')
    assert type(string_data) is str
    # testing bool and list
    bool_data = AnsibleJSONEncoder().default(True)
    assert type(bool_data) is bool
    list_data = AnsibleJSONEncoder().default([1, 2, 3])
    assert type(list_data) is list
    # testing AnsibleUnsafe and vault object
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    vault_secret = Vault