

# Generated at 2022-06-11 00:58:15.195312
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import StringIO
    import tempfile

    # Make a password file and encrypt some content
    (fd, path) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w+')
    f.write('V!0l3tP4ssW0rd\n')
    f.close()


# Generated at 2022-06-11 00:58:26.946456
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-11 00:58:32.763034
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    class Foo:
        __UNSAFE__ = True
        def __init__(self, value):
            self.value = value
        def __repr__(self):
            return "unsafe: %s" % self.value
    assert encoder.default(Foo('test')) == {'__ansible_unsafe': u'test'}
    test_dict = {'test1': Foo('test2')}
    assert encoder.default(test_dict) == {'test1': {'__ansible_unsafe': u'test2'}}
    assert encoder.default({'test1': 'test2'}) == {'test1': 'test2'}

# Generated at 2022-06-11 00:58:39.645997
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.unsafe_proxy import wrap_var

    safe_var = "FOO"
    unsafe_var = wrap_var("BAR")
    vault_pass = "vault_pass"
    vault_var = "this is an encrypted string"
    vault_obj = VaultLib([vault_pass])
    vault_var = vault_obj.encrypt(vault_var)

    # assert default method return the right json
    assert AnsibleJSONEncoder().default(safe_var) == safe_var
    assert AnsibleJSONEncoder().default(unsafe_var) == {"__ansible_unsafe": "BAR"}

# Generated at 2022-06-11 00:58:49.373171
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    test_cases = [
        (u'abc', u'abc'),
        (123, 123),
        (dict(a=1), {"a": 1}),
        (datetime.datetime(2018, 1, 1), "2018-01-01T00:00:00"),
        (datetime.datetime(2018, 1, 1, 1, 1, 1), "2018-01-01T01:01:01")
    ]
    for src, expected in test_cases:
        assert ansible_json_encoder.default(src) == expected


if __name__ == '__main__':
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-11 00:58:56.606664
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default('value') == 'value'
    assert encoder.default(datetime.datetime(2019, 1, 1)) == '2019-01-01T00:00:00'
    assert encoder.default(datetime.date(2019, 1, 1)) == '2019-01-01'
    assert encoder.default(dict(a='1')) == {'a': '1'}


# Generated at 2022-06-11 00:59:05.150110
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    password = 'vaultpass'
    plaintext = 'plain'
    ciphertext = VaultLib(password).encrypt(plaintext)

    vault = AnsibleVaultEncryptedUnicode(ciphertext, password=password, vault_id=DEFAULT_VAULT_ID_MATCH)
    vault.__ENCRYPTED__ = True

    encoder = AnsibleJSONEncoder()

    assert encoder.default(vault) == {'__ansible_vault': ciphertext}

# Generated at 2022-06-11 00:59:10.621509
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # This fails with python-future
    # aje = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False)
    # o = dict(a=1, b=2)
    # print(aje.default(o))
    # json.dumps(o, cls=aje)
    pass

# Generated at 2022-06-11 00:59:20.073817
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()
    o = b'ansible'
    unsafe_o = AnsibleUnsafe(o)
    vault_o = AnsibleVaultEncryptedUnicode(o)

    assert json_encoder.default(o) == 'ansible'
    assert json_encoder.default(unsafe_o) == {'__ansible_unsafe': 'ansible'}
    assert json_encoder.default(vault_o) == {'__ansible_vault': 'ansible'}

    json_encoder = AnsibleJSONEncoder(vault_to_text=True)
    assert json_encoder.default(vault_o) == 'ansible'


# Generated at 2022-06-11 00:59:23.311485
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    result = ansible_json_encoder.default(datetime.datetime.now())
    assert result, "AnsibleJSONEncoder.default should have returned the result of encoder.default()"


# Generated at 2022-06-11 00:59:36.671882
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import pytest

    # Creates a vault object
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # Create an EncryptedText

# Generated at 2022-06-11 00:59:46.850724
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(AnsibleJSONEncoder().default({'a': 'b'}) == {'a': 'b'})
    from ansible.parsing.vault import VaultLib
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        from cryptography.hazmat.primitives.ciphers import AES, Cipher
        from cryptography.hazmat.primitives.ciphers.algorithms import AES
        from cryptography.hazmat.primitives.ciphers.modes import CTR
        from cryptography.hazmat.backends import default_backend
        backend = default_backend()
        key = os.urandom(32)
        cipher = Cipher(AES(key), CTR(b'\x00' * 16), backend=backend)


# Generated at 2022-06-11 00:59:58.601962
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default('test') == '"test"'
    assert AnsibleJSONEncoder().default('<str>') == '"<str>"'
    assert AnsibleJSONEncoder().default('<str>') == '"<str>"'
    assert AnsibleJSONEncoder().default(2) == 2
    assert AnsibleJSONEncoder().default(2.1) == 2.1
    assert AnsibleJSONEncoder().default(True) == True
    assert AnsibleJSONEncoder().default(None) == None
    assert AnsibleJSONEncoder().default(['val1', 'val2']) == '["val1", "val2"]'

# Generated at 2022-06-11 01:00:08.533875
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    class TestClass:
        pass
    test_dict = {'test_key': TestClass()}
    test_dict['test_key'].__ENCRYPTED__ = True
    test_dict['test_key']._ciphertext = 'Vault-test'
    assert encoder.default(test_dict['test_key']) == {'__ansible_vault': to_text(test_dict['test_key']._ciphertext, errors='surrogate_or_strict', nonstring='strict')}
    test_dict['test_key'].__ENCRYPTED__ = False
    test_dict['test_key'].__UNSAFE__ = True

# Generated at 2022-06-11 01:00:14.129345
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(AnsibleJSONEncoder().default(2) == 2)
    assert(AnsibleJSONEncoder().default(True) == True)
    assert(AnsibleJSONEncoder().default(None) == None)
    assert(AnsibleJSONEncoder().default("2") == "2")
    assert(AnsibleJSONEncoder().default(u"2") == u"2")

# Generated at 2022-06-11 01:00:16.371737
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert(json.dumps(dict(a=1), cls=AnsibleJSONEncoder) == '{"a": 1}')

# Generated at 2022-06-11 01:00:23.056064
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    from ansible.module_utils.six import text_type
    e = AnsibleJSONEncoder()
    assert e.default("string") == 'string'
    assert e.default(text_type("string")) == 'string'
    assert e.default(True) == True
    assert e.default(datetime.datetime.now()) == datetime.datetime.now().isoformat()


# Generated at 2022-06-11 01:00:33.457372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    """Unit tests for default method of AnsibleJSONEncoder"""

    class ClassA:
        """Class for unit test"""
        def __init__(self):
            self.a = 1
            self.b = 2

    class ClassB(datetime.datetime):
        """Class for unit test"""
        def __init__(self):
            datetime.datetime.__init__(self, 2016, 3, 8, 14, 0, 0)

    class ClassC:
        """Class for unit test"""
        __ENCRYPTED__ = True
        def __init__(self):
            self._ciphertext = "ansible"

    class ClassD:
        """Class for unit test"""
        __UNSAFE__ = True
        def __init__(self):
            self.__str__ = "ansible"


# Generated at 2022-06-11 01:00:45.138091
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    class Unsafe:
        __UNSAFE__ = True

        def __init__(self, value):
            self._value = value

        def __str__(self):
            return self._value

    class MockVaultSecret(VaultLib):
        def __init__(self, secret):
            super(MockVaultSecret, self).__init__()
            self._secret = secret

        def _decrypt_secret(self, secret):
            return secret

        def _encrypt_secret(self, secret):
            return secret


# Generated at 2022-06-11 01:00:56.253047
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    encoder = AnsibleJSONEncoder()
    assert '"test"' == encoder.encode("test")
    assert 'null' == encoder.encode(None)
    assert '"2017-12-15"' == encoder.encode(AnsibleUnsafe("2017-12-15"))

# Generated at 2022-06-11 01:01:07.951697
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    check = AnsibleJSONEncoder()
    # check.default(value): value must be: AnsibleUnsafe, AnsibleVaultEncryptedUnicode or dict
    #                       representation of value is returned in dict
    dt = datetime.datetime(2017, 12, 5, 17, 32, 46, 599342)
    assert check.default(dt) == '2017-12-05T17:32:46.599342'
    assert check.default({'a': 1}) == {'a': 1}
    assert check.default({"b": "c"}) == {"b": "c"}

# Generated at 2022-06-11 01:01:11.770294
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default([1, 2, 3]) == [1, 2, 3]
    assert encoder.default({'a': 'b'}) == {'a': 'b'}


# Generated at 2022-06-11 01:01:21.729477
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import binary_type

    def _assert_equals_expected(o, expected):
        assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(o) == expected
        assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=False).default(o) == expected
        assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=True).default(o) == expected
        assert AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True).default(o) == expected

    _assert_equals_expected('string', 'string')

# Generated at 2022-06-11 01:01:33.300218
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Unit tests to check encoding of Ansible internal data types
    # when AnsibleJSONEncoder.default is called.
    #
    # AnsibleJSONEncoder is not used directly. It is called only when
    # json.JSONEncoder.default is called.

    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleUnsafeBytes
    from datetime import datetime, date

    # Generate data for testing encoding

# Generated at 2022-06-11 01:01:43.127718
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create an AnsibleJSONEncoder object
    ansible_json_encoder = AnsibleJSONEncoder()

    # Test safe object
    relevant_data = {'a': 1, 'b': 2, 'c': 3}
    assert ansible_json_encoder.default(relevant_data) == relevant_data

    # Test vault object
    ciphertext = b'Some random byte string'
    vault_obj = type('VaultObjSubClass', (object,), {})()
    vault_obj._ciphertext = ciphertext
    vault_obj.__ENCRYPTED__ = True
    vault_obj.__UNSAFE__ = False
    expected_result = {'__ansible_vault': ciphertext.decode('utf-8')}

# Generated at 2022-06-11 01:01:53.659342
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # testing __ENCRYPTED__
    # _ciphertext is expected to be bytes
    encoder = AnsibleJSONEncoder()
    o = type(b'AnsibleVault', (), {'_ciphertext': b'abc', '__ENCRYPTED__': True})
    assert encoder.default(o) == {'__ansible_vault': 'abc'}
    # testing __ENCRYPTED__ with vault_to_text
    encoder = AnsibleJSONEncoder(vault_to_text=True)
    o = type(b'AnsibleVault', (), {'_ciphertext': b'abc', '__ENCRYPTED__': True})
    assert encoder.default(o) == b'abc'

    # testing __UNSAFE__

# Generated at 2022-06-11 01:02:03.273103
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    import base64
    import datetime
    import sys
    import six

    if six.PY3:
        unicode_string = str
    else:
        unicode_string = unicode

    e = AnsibleJSONEncoder()


# Generated at 2022-06-11 01:02:15.574167
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test of default() method
    # 1. Input a vault object
    # 2. Input a host_vars object
    # 3. Input a vm object
    # 4. Input a datetime object
    # 5. Input a simple type object

    # create a vault object
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 01:02:25.875333
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Run test for AnsibleJSONEncoder not in strict mode
    encoder = AnsibleJSONEncoder()
    assert encoder.default(True) is True
    assert encoder.default(False) is False
    assert encoder.default(None) is None
    assert encoder.default(1.1) == 1.1
    assert encoder.default(0xAF) == 175
    assert encoder.default(1e3) == 1000.0
    assert encoder.default(0.1) == 0.1
    assert encoder.default(0.0) == 0.0
    assert encoder.default(9223372036854775807) == 9223372036854775807
    assert encoder.default(-9223372036854775808) == -9223372036854775808

# Generated at 2022-06-11 01:02:32.807328
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Object of class type is not a Vault but is an instance of AnsibleUnsafe
    class TestClass(object):
        __unsafe__ = True

        def __init__(self, input_string):
            self.input_string = input_string

    test_string = "This is a test string"
    test_instance = TestClass(test_string)

    json_dump_string = json.dumps(test_instance, cls=AnsibleJSONEncoder, sort_keys=True)
    expected_json_dump_string = "{'__ansible_unsafe': u'This is a test string'}"
    assert json_dump_string == expected_json_dump_string

# Generated at 2022-06-11 01:02:45.008215
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe


    # Vault Text
    assert '__ansible_vault' in json.dumps(VaultLib('password'), cls=AnsibleJSONEncoder)
    # Vault Text
    assert '__ansible_vault' in json.dumps(VaultLib('password').encrypt('test'), cls=AnsibleJSONEncoder)
    # Encrypted object, object is an instance of a class
    assert '__ansible_vault' in json.dumps(VaultLib('password').encrypt(dict(key='value')), cls=AnsibleJSONEncoder)
    # Unsafe Text

# Generated at 2022-06-11 01:02:53.005322
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Foo(object):
        def __init__(self, bar):
            self.bar = bar

    assert {"bar": "baz"} == json.loads(AnsibleJSONEncoder().encode(Foo("baz")))

    class Foo(object):
        def __init__(self, bar):
            self.bar = bar

        def to_dict(self):
            return {"bar": self.bar}

    assert {"bar": "baz"} == json.loads(AnsibleJSONEncoder().encode(Foo("baz")))

# Generated at 2022-06-11 01:03:04.001970
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import text_type

    if not PY2:
        text = text_type('unicode_string')
        byte_string = b'bytes_string'
    else:
        text = text_type(b'unicode_string', 'utf-8')
        byte_string = b'bytes_string'

    safe_string = VaultSecret(text=text)
    unsafe_string = VaultSecret(text=byte_string)
    encoded_unsafe_string = VaultSecret(text=byte_string, encoding=b'utf-8')

# Generated at 2022-06-11 01:03:14.104188
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    v = VaultLib([])  # the arguments do not matter here
    v.decrypt(b'$ANSIBLE_VAULT;1.1;AES256\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', b'')

# Generated at 2022-06-11 01:03:26.440621
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import text_type

    def _it(value, expected_value, vault_to_text=False, preprocess_unsafe=False):
        assert AnsibleJSONEncoder(preprocess_unsafe=preprocess_unsafe, vault_to_text=vault_to_text).default(value) == expected_value

    # Vault
    vault_password = text_type(r'$ANSIBLE_VAULT;1.1;AES256')

# Generated at 2022-06-11 01:03:36.649043
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret

    # test __ENCRYPTED__ object
    test_vault = VaultLib([])
    test_vault.password = 'passwd'
    secret = 'secret'
    test_value = VaultSecret(secret, cipher_name='AES256', vault=test_vault).value
    test_unsafe_value = VaultSecret(secret, cipher_name='AES256', vault=test_vault, unsafe=True).value
    test_unsafe_value_vault_to_text = VaultSecret(secret, cipher_name='AES256', vault=test_vault, unsafe=True).value

    value = AnsibleJSONEncoder().default(test_value)

# Generated at 2022-06-11 01:03:40.953746
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(object()) == '<object object at 0x%x>' % id(object())


if __name__ == '__main__':
    # Unit test for method default of class AnsibleJSONEncoder
    test_AnsibleJSONEncoder_default()

# Generated at 2022-06-11 01:03:49.605590
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) == None
    assert encoder.default(True) == True
    assert encoder.default(False) == False
    assert encoder.default(b'0xdeadbeef') == '0xdeadbeef'
    assert encoder.default(b'{"foo": "bar"}') == {"foo": "bar"}

    assert encoder.default(['foo', 'bar']) == ['foo', 'bar']
    assert encoder.default({'foo': 'bar'}) == {'foo': 'bar'}
    assert encoder.default({'foo': [1, 2, 3]}) == {'foo': [1, 2, 3]}

    assert encoder.default(datetime.date(2020, 9, 10)) == '2020-09-10'


# Generated at 2022-06-11 01:03:59.275174
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = {'string': 'string', 'list': ['item 1', 'item 2'], 'dict': {'key': 'value'},
           'datetime': datetime.datetime(2020, 4, 16, 7, 43, 54, 238000),
           'date': datetime.date(2020, 4, 16)}
    json_obj = json.dumps(obj, cls=AnsibleJSONEncoder)
    assert json_obj == '{"string": "string", "list": ["item 1", "item 2"], "dict": {"key": "value"}, '\
                       '"datetime": "2020-04-16T07:43:54.238000", "date": "2020-04-16"}'



# Generated at 2022-06-11 01:04:08.803573
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    class TestObj(object):
        def __init__(self, value):
            self.value = value

        def __unicode__(self):
            return self.value

        def __str__(self):
            return self.value

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-11 01:04:27.755456
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe
    from ansible.module_utils.common._collections_compat import OrderedDict

    d = {'a': 'b', AnsibleUnsafe('c'): AnsibleUnsafe('d')}

# Generated at 2022-06-11 01:04:35.583472
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ansible_json_encoder = AnsibleJSONEncoder()
    assert ansible_json_encoder.default(None) == None
    assert ansible_json_encoder.default(True) == True
    assert ansible_json_encoder.default(False) == False
    assert ansible_json_encoder.default(123) == 123
    assert ansible_json_encoder.default("string") == "string"
    assert ansible_json_encoder.default({"key":"value"}) == {"key":"value"}
    assert ansible_json_encoder.default([True, False]) == [True, False]
    assert ansible_json_encoder.default(datetime.datetime.now()) != None


# Generated at 2022-06-11 01:04:45.947759
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    v = AnsibleVaultEncryptedUnicode("this is a test")
    u = AnsibleUnsafeText("this is a test")

    class A():
        def __init__(self):
            self.b = "c"

    j = AnsibleJSONEncoder()

    assert j.default(v) == {"__ansible_vault": "this is a test"}
    assert j.default(u) == {"__ansible_unsafe": "this is a test"}
    assert j.default(A()) == {"b": "c"}

# Generated at 2022-06-11 01:04:56.035505
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()

    assert encoder.default({'key': 'value'}) == {'key': 'value'}
    assert encoder.default({'key': {'value': 'key'}}) == {'key': {'value': 'key'}}
    assert encoder.default({'key': ['value']}) == {'key': ['value']}
    assert encoder.default('value') == 'value'
    assert encoder.default(0.01) == 0.01
    assert encoder.default(1) == 1
    assert encoder.default([0.01, 1]) == [0.01, 1]
    assert encoder.default(['value', {'key': 'value'}]) == ['value', {'key': 'value'}]

# Generated at 2022-06-11 01:05:05.803121
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    e = AnsibleJSONEncoder()

    class AnsibleVault:
        '''Simple ansible vault object'''

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
            self.__ENCRYPTED__ = True

    class AnsibleUnsafe:
        '''Simple unsafe object'''

        def __init__(self, ciphertext):
            self._ciphertext = ciphertext
            self.__UNSAFE__ = True

    assert {'__ansible_vault': 'ciphertext'} == e.default(AnsibleVault('ciphertext'))
    # this will never be triggered

# Generated at 2022-06-11 01:05:16.226684
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # A test object
    class TestObj(object):
        def __init__(self, val):
            self.val = val
        def __getattr__(self, name):
            return getattr(self.val, name)

    # Test with a datetime object
    dt = datetime.datetime.now()
    dt_json = AnsibleJSONEncoder().encode(dt)
    assert json.loads(dt_json) == dt.isoformat()

    # Test with a simple object
    o = TestObj('test_string')
    o_json = AnsibleJSONEncoder().encode(o)
    assert json.loads(o_json) == 'test_string'

    # Test with a dict
    d = dict(a=1, b=2)

# Generated at 2022-06-11 01:05:27.213840
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    STRING_VALUES = [u'a', '', 'കഴിയില്ല', 'b']
    MAPPING_VALUES = [{'a': 'b'}, {}]
    DATE_VALS = [datetime.datetime(2017, 1, 1, 12, 0),
                 datetime.date(2017, 1, 1),
                 datetime.datetime(17, 1, 1, 12, 0)]

    # Test encoding of various string types
    for val in STRING_VALUES:
        assert val == AnsibleJSONEncoder().encode(val)

    for val in DATE_VALS:
        assert '"%s"' % val.isoformat() == AnsibleJSONEncoder().encode(val)

    # Test encoding of mapping

# Generated at 2022-06-11 01:05:34.543568
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import PY2

    # test cases
    secret = VaultSecret('string password')
    vault = VaultLib(secret.get_payload())

# Generated at 2022-06-11 01:05:39.525530
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({"a":1}) == {"a":1}
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEncoder().default("1") == "1"
    assert AnsibleJSONEncoder().default(Mapping(a=1)) == {"a":1}


# Generated at 2022-06-11 01:05:49.381449
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    encoder = AnsibleJSONEncoder()

    assert encoder.default(AnsibleUnsafeText('my text')) == 'my text'
    assert encoder.default(VaultEditor('string')) == {'__ansible_vault': 'string'}
    assert encoder.default({'a': 2}) == {'a': 2}
    assert encoder.default(datetime.datetime(2020, 6, 4, 23)) == '2020-06-04T23:00:00'



# Generated at 2022-06-11 01:06:12.736951
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default('asdf') == 'asdf'
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(None) is None
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default({}) == {}
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(True) is True
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default(False) is False
    assert AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False).default([]) == []



# Generated at 2022-06-11 01:06:19.836675
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import os
    import copy
    import json
    import datetime
    from ansible.module_utils.six import string_types

    def test_default_helper(obj, json_expected, vault_to_text=False):
        """Test function for AnsibleJSONEncoder.default.

        :arg obj: object to encode,
        :arg json_expected: expected JSON,
        :arg bool vault_to_text: if True, do not encode vault objects,
        """
        # these vault objects have no access to internal values, so they must
        # be decrypted before we can check the expected_json
        if obj.__ENCRYPTED__:
            if isinstance(obj, string_types):
                obj = VaultLib().decrypt(obj)

# Generated at 2022-06-11 01:06:20.590187
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert True

# Generated at 2022-06-11 01:06:29.102681
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-11 01:06:37.062862
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    enc = AnsibleJSONEncoder(indent=2)
    assert enc.encode(None) == 'null'
    assert enc.encode('string') == '"string"'
    assert enc.encode(False) == 'false'
    assert enc.encode(True) == 'true'
    assert enc.encode(1) == '1'
    assert enc.encode(1.1) == '1.1'
    assert enc.encode(dict(a=1)) == '{\n  "a": 1\n}'
    assert enc.encode([1, 2, 3]) == '[\n  1,\n  2,\n  3\n]'
    assert enc.encode(datetime.date(2017, 1, 31)) == '"2017-01-31"'

# Generated at 2022-06-11 01:06:44.805537
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import base64
    import io
    assert json.loads(json.dumps(dict(foo='bar'), cls=AnsibleJSONEncoder)) == dict(foo='bar')
    assert json.loads(json.dumps(dict(foo='bar'), cls=AnsibleJSONEncoder, sort_keys=True)) == dict(foo='bar')
    assert json.loads(json.dumps(dict(foo=[1, 2, 'bar', 'baz']), cls=AnsibleJSONEncoder)) == dict(foo=[1, 2, 'bar', 'baz'])

# Generated at 2022-06-11 01:06:54.690372
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test method default with simple
    assert '"ansible_default"' == AnsibleJSONEncoder().default('ansible_default')
    # Test method default with datetime
    assert '"2016-01-01T00:00:00"' == AnsibleJSONEncoder().default(datetime.datetime(2016, 1, 1))
    # Test method default with AnsibleUnsafe
    assert '{"__ansible_unsafe": "ansible_unsafe"}' == AnsibleJSONEncoder().default(AnsibleUnsafe("ansible_unsafe"))
    # Test method default with AnsibleVault
    assert '{"__ansible_vault": "ansible_vault"}' == AnsibleJSONEncoder().default(AnsibleVault("ansible_vault"))
    # Test method default with Mapping

# Generated at 2022-06-11 01:07:05.228095
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test AnsiUnsafeEnv
    ajin = AnsibleJSONEncoder()
    assert ajin.default(AnsiUnsafeEnv("$HOME")) == {'__ansible_unsafe': '$HOME'}

    # Test AnsiUnsafe
    assert ajin.default(AnsiUnsafe("$HOME")) == {'__ansible_unsafe': '$HOME'}

    # Test AnsiUnsafeText
    assert ajin.default(AnsiUnsafeText("$HOME")) == {'__ansible_unsafe': '$HOME'}

    # Test AnsiUnsafeBytes
    assert ajin.default(AnsiUnsafeBytes("$HOME")) == {'__ansible_unsafe': '$HOME'}

    # Test bytes object
    assert ajin.default(b"$HOME") == '$HOME'



# Generated at 2022-06-11 01:07:13.378549
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default("") == ""
    assert encoder.default("a") == "a"
    assert encoder.default(b"b") == "b"
    assert encoder.default(0) == 0
    assert encoder.default(1) == 1
    assert encoder.default(None) is None
    from ansible.module_utils.six import integer_types
    assert any(encoder.default(t()) == t() for t in integer_types)
    assert encoder.default(dict(a="b")) == dict(a="b")
    assert encoder.default(["a"]) == ["a"]
    assert encoder.default(("a",)) == ("a",)


# Generated at 2022-06-11 01:07:22.136499
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    vault_password = get_file_vault_secret(None)

    vault = VaultLib(vault_password)

    def _json_dumps(value, **kwargs):
        kwargs.update(dict(cls=AnsibleJSONEncoder))
        return json.dumps(value, **kwargs)

    # a vault object
    value = _json_dumps(vault.encrypt('123456789'))

# Generated at 2022-06-11 01:08:01.076737
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Store data to be encoded
    data = (
            b'gAAAAABdV4H4jn6c5C6U5_Puu5m6rH9Xq3IjdrHCTYUZnFmZ2IYNxD1zw-JN'
            b'9XcjCtsWpY1ZV_eM_KQxSN0DwIDJy0nPzDstil9quKbsGpW1ZlJkFAN--6g5'
            b'yP5b6tnJUq9gqjKdOZQk-0J'
            )
    data = {'__ansible_vault': data}

    # Python 3 use different encoder for bytes

# Generated at 2022-06-11 01:08:09.314723
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import re
    import types

    class MySafeClass(object):

        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.__safe__ = True

        def get_list(self):
            return [self.a, self.b]

        def get_dict(self):
            return {'a': self.a, 'b': self.b}

        def get_set(self):
            return {self.a, self.b}

    class MyUnsafeClass(object):

        def __init__(self, a, b):
            self.a = a
            self.b = b
            self.__unsafe__ = True

        def get_list(self):
            return [self.a, self.b]
