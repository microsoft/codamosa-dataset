

# Generated at 2022-06-11 00:58:16.061504
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test the vault object
    ansible_encrypted_string = to_text(u'Vault(ciphertext): abcde12345')
    ansible_vault_object = ansible_encrypted_string
    ansible_vault_object.__ENCRYPTED__ = True
    ansible_encoder = AnsibleJSONEncoder()
    assert ansible_encoder.default(ansible_vault_object)['__ansible_vault'] == to_text(u'abcde12345', errors='surrogate_or_strict')

    # Test the Vault object with vault_to_text set to True
    ansible_encrypted_string = to_text(u'Vault(ciphertext): abcde12345')
    ansible_vault_object = ansible_encrypted_string
    ansible_v

# Generated at 2022-06-11 00:58:28.134783
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    b = json.dumps(True, cls=AnsibleJSONEncoder)
    assert b == 'true'

    i = json.dumps(123, cls=AnsibleJSONEncoder)
    assert i == '123'

    n = json.dumps(None, cls=AnsibleJSONEncoder)
    assert n == 'null'

    s = json.dumps('abc', cls=AnsibleJSONEncoder)
    assert s == '"abc"'

    s = json.dumps(u'abc', cls=AnsibleJSONEncoder)
    assert s == '"abc"'

    s = json.dumps('"', cls=AnsibleJSONEncoder)
    assert s == '"\\""'


# Generated at 2022-06-11 00:58:38.140070
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import re
    # Pattern used to identify a datetime
    datetime_pattern = r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}([+-]\d{2}:\d{2})?'

    # This is a dict used in unit test
    dict_test = {'test': 'value',
                 'test_1': 'value',
                 'test_2': [1, 2],
                 'test_3': {'test_4': {'test_5':[1, '1-2-3', 2, 3]}}}

    # This is a dict with a None value used in unit test

# Generated at 2022-06-11 00:58:48.890332
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    import pytz
    from ansible.parsing.vault import VaultLib

    today = datetime.datetime.today()

    bob = 'unsafe string'
    setattr(bob, '__UNSAFE__', True)

    bof = 'vault string'
    setattr(bof, '__ENCRYPTED__', True)

    bom = {'__UNSAFE__': True}

    bog = {'__ENCRYPTED__': True}

    boi = {'__UNSAFE__': True, '__ENCRYPTED__': True, '__CIPHERTEXT__': 'cipher'}
    boi['__ENCRYPTED__'] = True


# Generated at 2022-06-11 00:58:56.557433
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(u'foo') == 'foo'
    assert AnsibleJSONEncoder().default(u'foo') == u'foo'
    assert AnsibleJSONEncoder().default(u'\u00a3') == u'\u00a3'
    assert AnsibleJSONEncoder().default(u'\u20ac') == u'\u20ac'
    assert AnsibleJSONEncoder().default(u'\u20ac') == '\xe2\x82\xac'

# Generated at 2022-06-11 00:59:01.536721
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Preparing class and input
    my_encoder = AnsibleJSONEncoder()
    my_input = datetime.datetime.now()
    # Executing method
    output = my_encoder.default(my_input)
    # Representing output
    assert isinstance(output, (str))


# TODO(@nshadov) Remove below test

# Generated at 2022-06-11 00:59:12.035968
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test JSON encode vault
    vault_encoder = AnsibleJSONEncoder()
    vault = dict()

# Generated at 2022-06-11 00:59:21.676111
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_encoder = AnsibleJSONEncoder()

    # date object
    date_instance = datetime.datetime(2019, 3, 5)
    assert '2019-03-05T00:00:00' == json_encoder.default(date_instance)

    # hostvars and other objects

# Generated at 2022-06-11 00:59:33.094829
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafe

    # Test for default
    default = AnsibleJSONEncoder().default

    def test_type(obj, t):
        assert default(obj) == t

    test_type(None, None)
    test_type(bool(True), True)

    test_type(AnsibleUnsafe('string1'), {'__ansible_unsafe': 'string1'})
    test_type(['string1', AnsibleUnsafe('string2')], ['string1', {'__ansible_unsafe': 'string2'}])
    test_type({'key1': AnsibleUnsafe('string2')}, {'key1': {'__ansible_unsafe': 'string2'}})

    test

# Generated at 2022-06-11 00:59:43.920668
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.module_utils.six import text_type
    import datetime
    import json

    d = datetime.date(2017, 8, 1)
    assert AnsibleJSONEncoder(sort_keys=True).encode(d) == '"2017-08-01"'

    d = datetime.datetime(2017, 8, 1, 1, 2, 3)
    assert AnsibleJSONEncoder(sort_keys=True).encode(d) == '"2017-08-01T01:02:03"'

    x = AnsibleVaultEnc

# Generated at 2022-06-11 00:59:57.027317
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Create a valid 'o' to pass as one of the parameters to AnisbleJSONEncoder.default function
    o = {'test': 'test_value'}

    # Create an instance of AnsibleJSONEncoder
    ans_js_enc = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False, **{})

    result = ans_js_enc.default(o)

    # Assert that result of default function is same as the 'o'
    assert result == o


# Generated at 2022-06-11 01:00:07.299356
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    input_obj = {
        u"datetime_value": datetime.datetime.now(),
        u"dict_value": {u"a": u"b"},
        u"list_value": [u"c", u"d"],
        u"str_value": u"str_value",
        u"test": u"test"
    }
    e = AnsibleJSONEncoder()
    result = e.default(input_obj)
    assert result["test"] == "test"
    assert result["str_value"] == "str_value"
    assert result["list_value"] == ["c", "d"]
    assert result["dict_value"] == {"a": "b"}
    assert result["datetime_value"] == input_obj["datetime_value"].isoformat()


# Generated at 2022-06-11 01:00:18.845890
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import b, text_type


# Generated at 2022-06-11 01:00:21.289498
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default({}) == {}
    assert AnsibleJSONEncoder().default([]) == []


# Generated at 2022-06-11 01:00:32.039933
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # do not test the following
    # - o.__UNSAFE__ since unsafe is never fed to AnsibleJSONEncoder.default()
    # - o.__ENCRYPTED__ since we are never supposed to reach this code

    # test for Mapping Objects
    sample_mapping = { 'one': 1, 'two': 2, 'three': 3 }
    sample_mapping_json = json.dumps(sample_mapping)
    aje = AnsibleJSONEncoder()
    assert aje.default(sample_mapping) == sample_mapping
    assert repr(aje.default(sample_mapping)) == repr(sample_mapping)
    assert json.dumps(aje.default(sample_mapping)) == sample_mapping_json

# Generated at 2022-06-11 01:00:38.805212
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = ['True', 'False', 'None', 'Unsafe', 'Vault']
    # Expected data
    unsafe_data = u"{'__ansible_unsafe': 'Unsafe'}"
    vault_data = u"{'__ansible_vault': 'Vault'}"

    def _test_json_item(item, exp_safe_data, exp_unsafe_data, exp_vault_data):
        # Safe path
        safe_json = json.dumps(item, cls=AnsibleJSONEncoder, sort_keys=True)
        unsafe_json = json.dumps(item, cls=AnsibleJSONEncoder(preprocess_unsafe=True), sort_keys=True)

# Generated at 2022-06-11 01:00:51.326926
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    assert encoder.default(None) == None
    assert encoder.default(False) == False
    assert encoder.default(True) == True

    test_date = datetime.datetime(2018, 2, 12, 10, 0, 1)
    assert encoder.default(test_date) == '2018-02-12T10:00:01'

    test_hostvars = {"foo": "bar", "baz": {"a": "b"}}
    assert encoder.default(test_hostvars) == test_hostvars

    # Test vault handler
    test_unsafe = 'secret'
    test_vault = test_unsafe.__ANSIBLE_VAULT__

# Generated at 2022-06-11 01:00:59.721555
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib, VaultSecret

    def _assert_encoding(obj, expected):
        encoded_obj = AnsibleJSONEncoder(sort_keys=True).encode(obj)
        assert encoded_obj == expected

    # init vault
    vault = VaultLib([])
    vault.password = 'mysecret'
    vault.rekey()

    _assert_encoding({}, '{}')
    _assert_encoding([], '[]')

    # test_date_object
    date_obj = datetime.date(2018, 8, 15)
    _assert_encoding(date_obj, '"2018-08-15"')

    # test_vault_secret
    vault_secret_obj = VaultSecret(vault.encrypt('mysecretmessage'))
    _assert_enc

# Generated at 2022-06-11 01:01:02.399490
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    result = AnsibleJSONEncoder().default(object())
    assert isinstance(result, str)
    assert result.startswith(b"<object object at 0x")

# Generated at 2022-06-11 01:01:10.053044
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    d = datetime.datetime(2019, 1, 1)
    jsond = AnsibleJSONEncoder().default(d)
    assert jsond == '2019-01-01T00:00:00'

    o = object()
    jsono = AnsibleJSONEncoder().default(o)
    assert jsono == '<object object at 0x%x>' % (id(o))

    v = 'test'
    jsonv = AnsibleJSONEncoder().default(v)
    assert jsonv == 'test'



# Generated at 2022-06-11 01:01:18.768329
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    testcases = []
    exp_results = []

    encoder = AnsibleJSONEncoder()

    testcases.append( [
    {"key1" : "Hello World", "key2" : 3, "key3" : [1, 2, "test", {"key4" : "test"}]}
    ])
    exp_results.append( [
    '{"key1": "Hello World", "key2": 3, "key3": [1, 2, "test", {"key4": "test"}]}'
    ])

    count = 0
    while count < len(testcases):
        testcase = testcases[count]
        exp_result = exp_results[count]

        result = json.dumps(testcase, cls=encoder, sort_keys=True)
        assert result == exp_result
        #adding the output

# Generated at 2022-06-11 01:01:29.892029
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.basic import AnsibleUnsafe

    vault_secret = VaultSecret('vault_secret')
    ansible_json_encoder = AnsibleJSONEncoder(preprocess_unsafe=True)
    vault_lib = VaultLib(vault_secret)
    secret_text = u'{plain}{cipher}'
    ansible_unsafe = AnsibleUnsafe('parsed_str')
    ansible_vault_str = u'$ANSIBLE_VAULT;1.1;AES256;{plain}{cipher}'

# Generated at 2022-06-11 01:01:40.362375
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib

    payload_dict = {u'key1': u'value1', u'key2': u'value2'}
    payload_list = [u'value1', u'value2']
    ansible_unsafe_string = C.DEFAULT_UNSAFE_CACHE.get_str(u'ansible_unsafe_string')
    ansible_vault_string = VaultLib('secret', 'cipher').encrypt(u'ansible_vault_string')
    payload_unsafe_list = [u'value1', ansible_unsafe_string]

# Generated at 2022-06-11 01:01:41.875988
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json.dumps({}, cls=AnsibleJSONEncoder)

# Generated at 2022-06-11 01:01:43.383393
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    o = 'this is a string'
    assert AnsibleJSONEncoder().default(o) == o

# Generated at 2022-06-11 01:01:53.938028
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    '''
    ansible.plugins.loader.vars_plugins.vault.VaultSecret
    ansible.vars.unsafe_proxy.AnsibleUnsafe
    ansible.vars.unsafe_proxy.AnsibleUnsafeText
    ansible.vars.unsafe_proxy.AnsibleVaultEncryptedUnicode
    ansible.vars.unsafe_proxy.AnsibleVaultEncryptedUnsafeText
    '''
    from ansible.plugins.loader.vars_plugins.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 01:02:03.611432
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.urls import Url

    class MyDict(dict):
        def __init__(self):
            self['somekey'] = 'somevalue'

    assert AnsibleJSONEncoder().default(MyDict()) == {'somekey': 'somevalue'}
    assert AnsibleJSONEncoder().default(Url('https://www.ansible.com')) == 'https://www.ansible.com'

    vault_str = 'myvaultstring'
    vault_secret = VaultSecret(vault_str)
    vault_json_dict = AnsibleJSONEncoder().default(vault_secret)
    assert '__ansible_vault' in vault_json_dict
    assert vault_json_dict['__ansible_vault']

# Generated at 2022-06-11 01:02:15.942318
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.common.vault import VaultLib

    encoder = AnsibleJSONEncoder(preprocess_unsafe=True, vault_to_text=True)
    assert encoder.default('foo') == 'foo'
    assert encoder.default(u'foo') == u'foo'
    assert encoder.default(b'foo') == b'foo'
    assert encoder.default(u'\xc3\xa9') == u'\xc3\xa9'
    assert encoder.default(b'\xc3\xa9') == b'\xc3\xa9'
    assert encoder.default(u'\u2713') == u'\u2713'

# Generated at 2022-06-11 01:02:18.436858
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    json_obj = json.dumps('foo', cls=AnsibleJSONEncoder)
    assert json_obj == '"foo"'


# Generated at 2022-06-11 01:02:27.693183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test 1: test input o with AnsibleUnsafe object
    o = AnsibleUnsafe('{"foo": "bar"}')
    encoder = AnsibleJSONEncoder()
    assert {'__ansible_unsafe': '{"foo": "bar"}'} == encoder.default(o)

    # Test 2: test input o with dictionary
    o = {'foo': 'bar'}
    encoder = AnsibleJSONEncoder()
    assert {'foo': 'bar'} == encoder.default(o)

    # Test 3: test input o with datetime object
    o = datetime.datetime(2015, 1, 1, 0, 0, 0, 0)
    encoder = AnsibleJSONEncoder()
    assert '2015-01-01T00:00:00' == encoder.default(o)

    # Test

# Generated at 2022-06-11 01:02:38.972539
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.ajson import AnsibleUnsafe, AnsibleVaultEncryptedUnicode
    it = AnsibleJSONEncoder()
    assert it.default(AnsibleUnsafe('blahblah')) == {u'__ansible_unsafe': u'blahblah'}
    assert it.default(AnsibleVaultEncryptedUnicode('blahblah')) == {u'__ansible_vault': u'blahblah'}

# Generated at 2022-06-11 01:02:46.786185
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.vault import VaultLib
    unsafe_str = AnsibleUnsafeText('')
    unsafe_bytes = AnsibleUnsafeBytes(b'')
    vault = VaultLib([])
    assert AnsibleJSONEncoder().default(unsafe_str) == None
    assert AnsibleJSONEncoder().default(unsafe_bytes) == None
    assert AnsibleJSONEncoder().default(vault) == None


# Generated at 2022-06-11 01:02:58.197677
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.six import binary_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    import datetime
    import os

    # This is needed in order to get the correct vault password
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = '/home/jtanner/Projects/Test_Vault_Password.txt'

    # Create a vault object
    vault_obj = VaultLib([])
    # Create a vault secret
    secret = binary_type('my secret')
    secret_bytes = secret.encode('utf-8')
    vault_secret = VaultSecret(vault_obj.encrypt(secret_bytes))

    test_dict = {}
    test_dict['__ansible_unsafe'] = binary

# Generated at 2022-06-11 01:02:59.290605
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(123) == 123

# Generated at 2022-06-11 01:03:05.326442
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = {
        'dict': {'a': 'b'},
        'date': datetime.datetime.now(),
        'datetime': datetime.datetime.now(),
        'time': datetime.time(1, 2, 3),
        'timedelta': datetime.timedelta(seconds=2),
    }

    for value in data.values():
        assert AnsibleJSONEncoder().default(value)



# Generated at 2022-06-11 01:03:12.391055
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.module_utils.six as six
    assert(six.PY2)

    import base64
    assert(base64.b64encode("12") == "MTI=")
    assert(base64._bytes_to_long("MTI=") == 12)
    assert("{0}".format(12) == "12")

    # AnsibleVaultEncryptedUnicode
    # string is unicode
    # _ciphertext is a bytearray
    # base64.b64encode(bytearray) doesn't return the same as base64.b64encode(unicode)
    # json.dumps(string) doesn't roundtrip
    # json.dumps(unicode(bytearray)) doesn't roundtrip
    # json.dumps(unicode(base64.b64en

# Generated at 2022-06-11 01:03:24.674055
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    data = dict(a=1, b=2)
    data_type = AnsibleJSONEncoder.default(None, data)
    answer = dict(a=1, b=2)
    assert data_type == answer

    data = dict(a=dict(c=3, d=4))
    data_type = AnsibleJSONEncoder.default(None, data)
    answer = dict(a=dict(c=3, d=4))
    assert data_type == answer

    data = dict(a=None)
    data_type = AnsibleJSONEncoder.default(None, data)
    answer = dict(a=None)
    assert data_type == answer

    data = dict(a='blah')
    data_type = AnsibleJSONEncoder.default(None, data)

# Generated at 2022-06-11 01:03:32.511443
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class DummyUnsafe(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = False

    class DummyVault(str):
        __UNSAFE__ = True
        __ENCRYPTED__ = True

    class Dummy(dict):
        pass
    dummy_instance = Dummy()
    dummy_instance.key1 = 'value1'

    r = {}
    r['key1'] = 'value1'
    r['key2'] = DummyUnsafe('value2')
    r['key3'] = DummyVault('value3')
    r['key4'] = dummy_instance
    a = AnsibleJSONEncoder()
    r = a.default(r)

    assert 'key1' in r.keys()
    assert r['key1'] == 'value1'
   

# Generated at 2022-06-11 01:03:37.206952
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import datetime
    now = datetime.datetime.utcnow()
    assert now.isoformat() == AnsibleJSONEncoder().default(now)
    assert '"{}"'.format(now.isoformat()) == AnsibleJSONEncoder(indent=None).default(now)


# Generated at 2022-06-11 01:03:47.210088
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    empty = []
    assert AnsibleJSONEncoder().default(empty) == []

    # Test for default return of AnsibleJSONEncoder with object
    class testObject:
        def __init__(self, a=1, b=2):
            self.a = a
            self.b = b
        @property
        def __dict__(self):
            return {'a': self.a, 'b': self.b}
    obj = testObject()
    assert AnsibleJSONEncoder().default(obj) == {'a': 1, 'b': 2}

    # Test for default return of AnsibleJSONEncoder with Unicode object
    class testUnicode(object):
        def __init__(self, a=1, b=2):
            self.a = a
            self.b = b

# Generated at 2022-06-11 01:04:03.590805
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # data to be encoded
    data = {
        "test-string": "this is a test",
        "test-datetime": datetime.datetime(year=2020, month=1, day=1, hour=12, minute=20, second=5),
        "test-dict": {"key": "value"},
        "test-list": [1, 2, 3],
        "test-int": 10,
        "test-float": 3.14,
        "test-none": None,
    }

    # expected output

# Generated at 2022-06-11 01:04:14.780353
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj1 = json.dumps(dict(myvar='myvar', myval=10), cls=AnsibleJSONEncoder)
    assert 'myvar' in obj1 and 'myval' in obj1
    assert '"myvar": "myvar"' in obj1 and '"myval": 10' in obj1

    obj2 = json.dumps(dict(myvar='myvar', myval=10, mydict=dict(mydictvar='value')), cls=AnsibleJSONEncoder)
    assert 'myvar' in obj2 and 'myval' in obj2 and 'mydict' in obj2
    assert '"myvar": "myvar"' in obj2 and '"myval": 10' in obj2 and '"mydict": {"mydictvar": "value"}' in obj2

    obj3 = json.d

# Generated at 2022-06-11 01:04:23.038315
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    instance = AnsibleJSONEncoder(preprocess_unsafe=False, vault_to_text=False)
    o = 'simple string'
    assert isinstance(instance.default(o), str)
    assert instance.default(o) == o
    o = u'simple unicode'
    assert isinstance(instance.default(o), str)
    assert instance.default(o) == 'simple unicode'
    o = b'simple binary'
    assert isinstance(instance.default(o), str)
    assert instance.default(o) == 'simple binary'

# Generated at 2022-06-11 01:04:32.906779
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['tests/inventory'])

    task = {
        'action': {
            'module': 'debug',
            'args': {
                'msg': 'Hello World!'
            }
        }
    }

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[task]
    )


# Generated at 2022-06-11 01:04:43.962534
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    import ansible.parsing.vault
    import ansible.utils.unsafe_proxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars import HostVars

    # make simple test dictionary
    my_dict = {'key_1': 'string', 'key_2': 1, 'key_3': None}
    assert isinstance(my_dict, Mapping)

    # test for hostvars
    my_hostvars = HostVars({'key': 'value'}, vault_password=None)
    assert isinstance(my_hostvars, HostVars)

    # make test vault

# Generated at 2022-06-11 01:04:45.950401
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    obj = AnsibleJSONEncoder()
    data = {'first': 'foo'}
    assert obj.default(data) == data



# Generated at 2022-06-11 01:04:56.036183
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test using (Ansible) Vault
    encoder = AnsibleJSONEncoder()
    vault_data = {
        '__ansible_vault': '$ANSIBLE_VAULT;1.2;AES256;ansible;key1\ntest'
    }
    vault_instance = JSONVaultEncoder.decode(vault_data)
    assert encoder.default(vault_instance) == vault_data

    # Test using AnsibleUnsafe
    encoder = AnsibleJSONEncoder()
    unsafe_data = {
        '__ansible_unsafe': 'test'
    }
    unsafe_instance = JSONUnsafeEncoder.decode(unsafe_data)
    assert encoder.default(unsafe_instance) == unsafe_data

    # Test using datetime object
    encoder = AnsibleJSON

# Generated at 2022-06-11 01:05:05.801705
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:05:10.712875
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    encoder = AnsibleJSONEncoder()
    date = datetime.date.today()
    string = "test_AnsibleJSONEncoder_default"
    obj = {'key': 'value'}
    assert encoder.default(date) == date.isoformat()
    assert encoder.default(string) == string
    assert encoder.default(obj) == obj

# Generated at 2022-06-11 01:05:19.929079
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:05:36.140021
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.module_utils.basic import AnsibleUnsafe, AnsibleVaultEncryptedUnicode

    def assert_ansible_json_encoder_default(value, expected):
        # the assertion equality for the value and the expected
        assert json.dumps(value, cls=AnsibleJSONEncoder) == str(json.dumps(expected))

    assert_ansible_json_encoder_default(None, None)
    assert_ansible_json_encoder_default(1, 1)
    assert_ansible_json_encoder_default(10.0, 10.0)
    assert_ansible_json_encoder_default(True, True)
    assert_ansible_json_encoder_default(False, False)

# Generated at 2022-06-11 01:05:48.164505
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultNotFoundError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    vault_pass = 'test'
    j = AnsibleJSONEncoder()
    s = AnsibleUnsafeText('test')
    r = AnsibleUnsafeText('test', unsafe=True)
    unsafe_v = VaultEditor(vault_pass)
    safe_v = VaultEditor(vault_pass)
    v_input = '"1\n2\n3"'
    unsafe_v.encrypt_string(v_input)
    safe_v.encrypt_string(v_input, unsafe=False)

    # FIXME: Make this a not so hacky way

# Generated at 2022-06-11 01:05:54.371356
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Test_Vault:
        __ENCRYPTED__ = True
        _ciphertext = 'secret'

    class Test_Unsafe:
        __UNSAFE__ = True

    class Test_Nothing:
        pass

    # test the special cases
    assert AnsibleJSONEncoder().default(Test_Vault()) == {'__ansible_vault': 'secret'}
    assert AnsibleJSONEncoder(vault_to_text=True).default(Test_Vault()) == 'secret'
    assert AnsibleJSONEncoder().default(Test_Unsafe()) == {'__ansible_unsafe': ''}

    # make sure the normal behaviours don't change
    assert AnsibleJSONEncoder().default(Test_Nothing()) == {}
    assert AnsibleJSONEncoder().default(1) == 1
    assert AnsibleJSONEnc

# Generated at 2022-06-11 01:06:03.813445
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    def _assert_default_result(o, result):
        assert AnsibleJSONEncoder().default(o) == result

    assert AnsibleJSONEncoder().default(dict(foo=1)) == dict(foo=1)
    assert AnsibleJSONEncoder().default(('foo',)) == ('foo',)

    from ansible.parsing.yaml.objects import AnsibleSequence
    assert AnsibleJSONEncoder().default(AnsibleSequence(['foo'])) == ['foo']

    from ansible.parsing.vault import VaultLib
    assert AnsibleJSONEncoder().default(VaultLib()) == dict(__ansible_vault='')

    assert AnsibleJSONEncoder(vault_to_text=True).default(VaultLib()) == ''

    from ansible.vars.unsafe_proxy import Ans

# Generated at 2022-06-11 01:06:12.326937
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test 1:
    unsafe = AnsibleJSONEncoder()
    output1 = unsafe.default('test_unsafe')
    assert output1 == 'test_unsafe'

    # Test 2:
    unsafe2 = AnsibleJSONEncoder(preprocess_unsafe=True)
    output2 = unsafe2.default('test_unsafe')
    assert output2 == {'__ansible_unsafe': u'test_unsafe'}

    # Test 3:
    vault = AnsibleJSONEncoder()
    output3 = vault.default('test_vault')
    assert output3 == 'test_vault'

    # Test 4:
    vault2 = AnsibleJSONEncoder(vault_to_text=True)
    output4 = vault2.default('test_vault')

# Generated at 2022-06-11 01:06:17.817441
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # no error and output 'null'
    data = AnsibleJSONEncoder().default(None)
    assert(data == 'null')
    # no error and output '"text"'
    data = AnsibleJSONEncoder().default('text')
    assert(data == '"text"')
    # no error and output '2'
    data = AnsibleJSONEncoder().default(2)
    assert(data == '2')

# Generated at 2022-06-11 01:06:27.716388
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    ajc = AnsibleJSONEncoder()

    class TestClass(object):
        def __repr__(self):
            return '<test class object>'

        def to_json(self):
            return '{"somedata": "data"}'

    class Test(object):
        def __init__(self):
            self.a = 5
            self.b = "foobar"
            self.c = TestClass()
            self.d = {'foo': 'bar'}

        def to_json(self):
            return '{"a":1, "b":2, "c":3, "d":4}'

    test = Test()

# Generated at 2022-06-11 01:06:36.365291
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafeString(unicode):
        __UNSAFE__ = True

    class AnsibleUnsafeBytes(str):
        __UNSAFE__ = True

    class AnsibleVaultString(unicode):
        __ENCRYPTED__ = True

    class AnsibleVaultBytes(str):
        __ENCRYPTED__ = True

    # Test with unsafe string
    a = AnsibleUnsafeString('unsafe string')
    assert(isinstance(a, AnsibleUnsafeString))
    assert(AnsibleJSONEncoder(preprocess_unsafe=False).default(a) == {'__ansible_unsafe': 'unsafe string'})
    assert(AnsibleJSONEncoder(preprocess_unsafe=True).default(a) == {'__ansible_unsafe': 'unsafe string'})

# Generated at 2022-06-11 01:06:44.412720
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    import ansible.parsing.vault
    from ansible.parsing.yaml.objects import AnsibleUnsafe
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    # vault text with vault id
    plain_text = "my_secure_password"
    vault_id = "0042"
    vault_password = "my_vault_password"
    vault_text = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;"

# Generated at 2022-06-11 01:06:54.291081
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # test case for OrderedDict
    encoder = AnsibleJSONEncoder()
    from collections import OrderedDict
    test_dict = OrderedDict()
    test_dict['a'] = 1
    test_dict['b'] = '2'
    test_dict['c'] = [3, '4']
    test_dict['d'] = {"a": 1, "b": 2}
    test_dict['e'] = OrderedDict()
    test_dict['e']['a'] = 1
    test_dict['e']['b'] = 2
    test_dict['f'] = (1, 2, 3, 4)
    test_dict['g'] = {1, 2, 3, 4}
    test_dict['h'] = None
    test_dict['i'] = True
    test_dict

# Generated at 2022-06-11 01:07:05.556967
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    module = MockModule()
    assert AnsibleJSONEncoder().default(module) == module.__dict__


# Generated at 2022-06-11 01:07:08.265357
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    assert AnsibleJSONEncoder().default(dict(foo='foo')) == dict(foo='foo')
    assert AnsibleJSONEncoder().default(set(['bar'])) == ['bar']

# Generated at 2022-06-11 01:07:13.321875
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class AnsibleUnsafe(str):
        __UNSAFE__ = True

    obj = AnsibleUnsafe(u'foo')
    assert AnsibleJSONEncoder(preprocess_unsafe=False).default(obj) == {'__ansible_unsafe': 'foo'}
    assert AnsibleJSONEncoder(preprocess_unsafe=True).default(obj) == {'__ansible_unsafe': 'foo'}

# Generated at 2022-06-11 01:07:22.105304
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    # Test when o is AnsibleUnsafe
    o = 'test_value'
    o_AnsibleUnsafe = '$ANSIBLE_VAULT;1.1;AES256'
    o_AnsibleUnsafe.__UNSAFE__ = True
    expected = {'__ansible_unsafe': '$ANSIBLE_VAULT;1.1;AES256'}
    assert (AnsibleJSONEncoder().default(o_AnsibleUnsafe) == expected)

    # Test when o is a mapping
    test_dict = {'test_key': 'test_value'}
    assert (AnsibleJSONEncoder().default(test_dict) == test_dict)

    # Test when o is a date
    test_date = datetime.date(2020, 1, 1)

# Generated at 2022-06-11 01:07:29.159360
# Unit test for method default of class AnsibleJSONEncoder

# Generated at 2022-06-11 01:07:39.948815
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.vars.unsafe_proxy import AnsibleUnsafe

    # vault object
    e1 = AnsibleJSONEncoder().default(VaultSecret("test"))
    assert e1 == """{"__ansible_vault": "test"}"""

    # unsafe object
    e2 = AnsibleJSONEncoder().default(AnsibleUnsafe("test"))
    assert e2 == """{"__ansible_unsafe": "test"}"""

    # hostvars and other objects
    e3 = AnsibleJSONEncoder().default({'test': 'test'})
    assert e3 == """{"test": "test"}"""

    # date object
    d = datetime.datetime.now()
    e4

# Generated at 2022-06-11 01:07:49.361464
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    jsonEncoder = AnsibleJSONEncoder()
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.common._collections_compat import Mapping
    import datetime

    # Test for class str
    s = "TestStr"
    s_result = jsonEncoder.default(s)
    assert s_result == s

    # Test for class vault
    plaintext = "TestVault"
    key = VaultLib.get_default_password_file()
    password_bytes = VaultLib.read_password_file(key)

# Generated at 2022-06-11 01:07:55.920478
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    def test_recurse(o):
        assert isinstance(json.dumps(o, cls=AnsibleJSONEncoder, sort_keys=True), basestring)

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    v = VaultLib([])
    secrets = [
        "vault_id",
        VaultSecret("vault_id1", "vault_password"),
        {"k1": "v1", "k2": "v2"}
    ]

    for s in secrets:
        v.secrets[s] = ["vault1"]
        test_recurse(v)
        if isinstance(s, dict):
            for k in s:
                v.secrets[k] = s[k]
                test_recurse

# Generated at 2022-06-11 01:07:57.896230
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():

    # Test a known case
    date_test = datetime.date.today()
    result = AnsibleJSONEncoder().default(date_test)
    assert result == date_test.isoformat()



# Generated at 2022-06-11 01:08:00.641387
# Unit test for method default of class AnsibleJSONEncoder
def test_AnsibleJSONEncoder_default():
    class Test1(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3

    assert AnsibleJSONEncoder().default(Test1()) == json.loads('{"a":1,"b":2,"c":3}')
