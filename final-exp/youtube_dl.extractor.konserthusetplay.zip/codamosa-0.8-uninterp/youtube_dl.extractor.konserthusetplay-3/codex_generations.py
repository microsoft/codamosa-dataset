

# Generated at 2022-06-14 16:34:43.812568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-14 16:34:48.455594
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:34:52.038758
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"


# Generated at 2022-06-14 16:34:53.417621
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_name = 'KonserthusetPlayIE'

# Generated at 2022-06-14 16:34:55.182206
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp_ie = KonserthusetPlayIE()

test_KonserthusetPlayIE()

# Generated at 2022-06-14 16:34:56.263729
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-14 16:34:59.388501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie

# Generated at 2022-06-14 16:35:02.369607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the Page Load
    KonserthusetPlayIE.suite()


test_KonserthusetPlayIE()

# Generated at 2022-06-14 16:35:14.710825
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:35:18.816032
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._real_extract(url)


# Generated at 2022-06-14 16:35:35.488965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info = KonserthusetPlayIE()._real_extract(
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert info['title'] == 'Orkesterns instrument: Valthornen'
    assert info['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert info['duration'] == 398.76

# Generated at 2022-06-14 16:35:36.590924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay')

# Generated at 2022-06-14 16:35:37.773545
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-14 16:35:45.631045
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-14 16:35:48.605648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    obj.extract(url)

# Generated at 2022-06-14 16:35:59.903419
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-14 16:36:04.836836
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k_ie = KonserthusetPlayIE()
    assert k_ie._match_id(test_url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-14 16:36:07.917889
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Act
    KonserthusetPlayIE(url)

# Generated at 2022-06-14 16:36:08.843778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie=KonserthusetPlayIE("")

# Generated at 2022-06-14 16:36:09.878397
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-14 16:36:38.596949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('')
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:36:45.825642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE.ie_key()
    ie = KonserthusetPlayIE.suitable()
    ie = KonserthusetPlayIE._real_extract()
    ie = KonserthusetPlayIE._real_initialize()
    ie = KonserthusetPlayIE._real_extractor()

# Generated at 2022-06-14 16:36:48.092677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        print("Error on class construction")


# Generated at 2022-06-14 16:36:51.410536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extractor_key == 'KonserthusetPlay'
    assert ie.extractor_key == ie.ie_key()


# Generated at 2022-06-14 16:36:58.349967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:37:07.784305
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # pylint: disable=protected-access
    # Case 1: valid URL
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetplayIE = KonserthusetPlayIE()
    assert not konserthusetplayIE._match(url) is None
    assert konserthusetplayIE._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'
    # Case 2: invalid URL
    url = 'http://www.konserthusetplay.se/'
    assert konserthusetplayIE._match(url) is None
    # Case 3: incomplete URL

# Generated at 2022-06-14 16:37:12.495008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance.ie_key() == 'KonserthusetPlay'
    assert instance.ie_key() != 'KonserthusetPlay'
    assert instance.ie_key() != 'KonserthusetPlay'

# Generated at 2022-06-14 16:37:13.926826
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    return True


# Generated at 2022-06-14 16:37:23.868302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import datetime
    config = {'regex': r'https?://(www\.)?konserthusetplay\.se/\?.*\bm=(1|2)'}
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    title = 'Orkesterns instrument: Valthornen'
    description = '''Orkesterns Valthornar'''
    duration = 398.76
    thumbnail = 'http://video.play.rsp.se/i/d/h/CKDDnlCY-dhWAAqiMERd-A.jpg'
    timestamp = datetime.datetime(2014, 10, 22)
    # Testing constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE

# Generated at 2022-06-14 16:37:30.423395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    # Validate use of superclass
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.IE_NAME == 'KonserthusetPlay'
    # Test for video ID in URL
    assert ie._match_id("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == "CKDDnlCY-dhWAAqiMERd-A"
    # Test for second URL

# Generated at 2022-06-14 16:38:32.499834
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for creating an instance of this class
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-14 16:38:34.634369
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the not yet implmented exception
    try:
        raise NotImplementedError
    except NotImplementedError:
        assert(True)

# Generated at 2022-06-14 16:38:36.200788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor
    KonserthusetPlayIE('../lib/youtube_dl/extractor')


# Generated at 2022-06-14 16:38:36.965437
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-14 16:38:49.395633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert test_obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert test_obj._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert test_obj._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-14 16:38:52.986395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test for constructor of class KonserthusetPlayIE"""
    instanceKonserthusetPlayIE = KonserthusetPlayIE()
    assert isinstance(instanceKonserthusetPlayIE, KonserthusetPlayIE)


# Generated at 2022-06-14 16:38:55.535738
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = {
    }

    inf_extractor = KonserthusetPlayIE()

    assert(inf_extractor._match_id(test['url']) == test['id'])

# Generated at 2022-06-14 16:38:57.785821
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for KonserthusetPlayIE, constructor of class
    """
    instance = KonserthusetPlayIE()
    assert instance


# Generated at 2022-06-14 16:39:03.855491
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:39:09.625553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS

# The following code is for debugging
# For unit testing, see test_KonserthusetPlayIE()
if __name__ == "__main__":
    import pytest
    pytest.main('--capture=no')

# Generated at 2022-06-14 16:41:20.682040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create unit test for object KonserthusetPlayIE
    konserthuset_play_ie = KonserthusetPlayIE()
    # Test url property
    assert konserthuset_play_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    return

# Generated at 2022-06-14 16:41:21.488477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-14 16:41:25.030761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    m = ie._match_id('http://www.konserthusetplay.se/?m=A3d0nSYVZKg-Ri7VQXf6bQ')
    assert m == 'A3d0nSYVZKg-Ri7VQXf6bQ'

# Generated at 2022-06-14 16:41:28.849209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.options['ie_key'] == 'KonserthusetPlay'


# Generated at 2022-06-14 16:41:31.108950
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-14 16:41:34.682784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:41:36.166489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE._KonserthusetPlayIE(None, None)
    assert ie

# Generated at 2022-06-14 16:41:37.714640
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.initialize()
    assert ie != None

# Generated at 2022-06-14 16:41:40.214763
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-14 16:41:41.217713
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()