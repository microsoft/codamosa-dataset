

# Generated at 2022-06-18 14:14:36.436651
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:14:42.912870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:14:53.209610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:14:58.830882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
    assert ie

# Generated at 2022-06-18 14:15:10.897201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:15:21.006315
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.is_suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-18 14:15:28.146920
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:32.638334
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 14:15:42.610370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:48.738334
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:16:25.304425
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.SUCCESS == True


# Generated at 2022-06-18 14:16:34.698189
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://www.konserthusetplay.se/video/')

# Generated at 2022-06-18 14:16:44.043435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:16:50.010302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:17:00.660387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&a=b') == True

# Generated at 2022-06-18 14:17:11.690885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:18.028592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://www.konserthusetplay.se/konserthuset')

# Generated at 2022-06-18 14:17:28.395929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:36.786249
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:17:44.941401
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:18:53.133510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:18:55.166207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:05.459491
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:19:14.322828
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_categories() == []
    assert ie.supported_categories_re() == ['.*']
    assert ie.supported_categories_list() == []

# Generated at 2022-06-18 14:19:24.250727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_list() == ['.*']
    assert ie

# Generated at 2022-06-18 14:19:35.775078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:19:39.176421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:41.697457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:50.519257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_languages() == ['en']
    assert ie.supported_countries() == ['SE']

# Generated at 2022-06-18 14:19:53.744327
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:21:59.805841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:07.129186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == 'KonserthusetPlay'
    assert ie.supported_extractors_str_list() == ['KonserthusetPlay']
    assert ie.supported_extractors_str_

# Generated at 2022-06-18 14:22:15.988231
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:22:25.067037
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '1.0'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^(?:KonserthusetPlay|rspoplay)$']
    assert ie.supported_categories() == ['general']
    assert ie.supported_categories_re() == [r'^(?:general|)$']

# Generated at 2022-06-18 14:22:31.143735
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:22:40.164065
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-18 14:22:43.706283
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-18 14:22:50.216881
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:22:56.468244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:23:01.157456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')