

# Generated at 2022-06-18 14:14:33.714868
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_re() == '.*'

# Generated at 2022-06-18 14:14:35.804328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 14:14:46.631624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:14:55.309818
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_key_list() == ['KonserthusetPlay']
    assert ie.extractor_name_list() == ['KonserthusetPlay']

# Generated at 2022-06-18 14:15:06.905715
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_list() == ['KonserthusetPlay']

# Generated at 2022-06-18 14:15:17.946748
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:15:26.368943
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:29.551815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:15:33.348170
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:15:40.133832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:16:15.937283
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:16:25.525142
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:16:34.843586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:16:46.432276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
   

# Generated at 2022-06-18 14:16:57.765853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:04.500515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:14.758710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors(True) == ['KonserthusetPlay']
    assert ie.supported_extractors(False) == ['KonserthusetPlay']
    assert ie.supported_extractors(None) == ['KonserthusetPlay']

# Generated at 2022-06-18 14:17:25.251655
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:17:34.165122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^KonserthusetPlay$']
    assert ie.supported_categories() == ['general']
    assert ie.supported_categories_re() == [r'^general$']

# Generated at 2022-06-18 14:17:40.260902
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(ie.ie_key())
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 14:18:39.615068
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:18:48.961206
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:18:51.048706
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:18:53.774903
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:00.083248
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar')

# Generated at 2022-06-18 14:19:09.830501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:19:12.200173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:18.528098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar')

# Generated at 2022-06-18 14:19:30.295433
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0'

# Generated at 2022-06-18 14:19:40.376542
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/') == False

# Generated at 2022-06-18 14:21:40.849947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:21:45.027891
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:21:53.288314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:21:58.280271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:22:06.283411
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:10.710115
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:22:18.432524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:22:26.740156
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:33.261991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-18 14:22:38.344061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'