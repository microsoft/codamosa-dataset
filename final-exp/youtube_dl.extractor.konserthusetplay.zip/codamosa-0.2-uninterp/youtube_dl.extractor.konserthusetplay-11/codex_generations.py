

# Generated at 2022-06-18 14:14:35.837629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:14:46.680968
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:14:57.045006
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:08.382727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:19.011566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_list() == ['.*']
    assert ie

# Generated at 2022-06-18 14:15:21.806714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:15:26.701208
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:15:37.226835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:46.903729
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_key_list() == ['KonserthusetPlay']
    assert ie.extractor_name_list() == ['KonserthusetPlay']

# Generated at 2022-06-18 14:15:53.353400
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:16:32.586024
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']
    assert ie.extractor_duration() == 'long'
    assert ie.extractor_

# Generated at 2022-06-18 14:16:40.262005
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:16:49.925767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '1.0'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '1.0'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:00.587556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:11.690318
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:14.063984
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:17:24.599781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:17:33.531347
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://www.konserthusetplay.se/index.php')

# Generated at 2022-06-18 14:17:39.377936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:17:41.910232
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:18:49.302181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:18:56.432335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_re() == '.*'

# Generated at 2022-06-18 14:19:02.356058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:19:05.642324
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:08.738674
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:19:16.304439
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:26.853928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:38.268240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:47.979549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:19:58.184709
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^(?:KonserthusetPlay)$']
    assert ie.supported_extractors_re_str() == r'^(?:KonserthusetPlay)$'
    assert ie.supported_extractors_str() == 'KonserthusetPlay'
    assert ie.supported_extractors_str_list()

# Generated at 2022-06-18 14:22:02.673869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:06.708569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']

# Generated at 2022-06-18 14:22:13.699932
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-18 14:22:23.040452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:29.200564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:22:40.058335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:22:47.772577
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors(False) == ['KonserthusetPlay']
    assert ie.supported_extractors(True) == ['KonserthusetPlay']
    assert ie.supported_extractors(True, False) == ['KonserthusetPlay']
    assert ie.supported_extractors

# Generated at 2022-06-18 14:22:52.412282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:23:02.051882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 14:23:09.067127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'