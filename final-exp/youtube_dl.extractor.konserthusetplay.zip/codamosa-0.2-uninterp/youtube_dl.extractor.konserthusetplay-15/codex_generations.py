

# Generated at 2022-06-18 14:14:34.919758
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:14:43.260778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.SUFFIX == '?m=%s'
    assert ie.VIDEO_URL == 'http://www.konserthusetplay.se/?m=%s'

# Generated at 2022-06-18 14:14:50.911724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:14:57.900281
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable(url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable(url='http://www.konserthusetplay.se/')
    assert not ie.suitable(url='http://www.konserthusetplay.se/video/')

# Generated at 2022-06-18 14:15:09.383730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)']

# Generated at 2022-06-18 14:15:15.823006
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-18 14:15:22.075200
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'



# Generated at 2022-06-18 14:15:33.258833
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '1.0'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '1.0'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:15:43.215224
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:50.884499
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/') == False

# Generated at 2022-06-18 14:16:32.299240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:16:34.584857
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:16:46.174512
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:16:57.493781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:04.353127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:17:14.617835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:25.250031
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:29.519533
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 14:17:37.778661
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:45.904050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.is_suitable(None) == False
    assert ie.is_suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.is_

# Generated at 2022-06-18 14:18:22.278148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_key_list() == ['KonserthusetPlay']
    assert ie.extractor_name_list() == ['KonserthusetPlay']

# Generated at 2022-06-18 14:18:30.144801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('') == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True
    assert ie

# Generated at 2022-06-18 14:18:37.800332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:18:47.069050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&p=1') == True

# Generated at 2022-06-18 14:18:54.040929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar')

# Generated at 2022-06-18 14:19:00.318041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:19:10.071524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:19.911099
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors(False) == ['KonserthusetPlay']
    assert ie.supported_extractors(True) == ['KonserthusetPlay']
    assert ie.supported_extractors(None) == ['KonserthusetPlay']

# Generated at 2022-06-18 14:19:31.290375
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:34.974241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:20:41.034042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)']

# Generated at 2022-06-18 14:20:46.363704
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:20:50.545941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:20:56.340996
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:21:00.902302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:21:03.446948
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:21:05.632721
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:21:12.489196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-18 14:21:20.621432
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://www.konserthusetplay.se/index.php')

# Generated at 2022-06-18 14:21:26.347114
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:23:31.559074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-18 14:23:36.410637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:23:43.073824
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:23:44.774876
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:23:48.210390
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://www.konserthusetplay.se/konserthuset')

# Generated at 2022-06-18 14:23:51.887060
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.supported_extensions() == ['mp4']
    assert ie.supported_domains() == ['konserthusetplay.se', 'rspoplay.se']
    assert ie.get_url_re() == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:23:57.657319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)']

# Generated at 2022-06-18 14:24:03.952577
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:24:06.445866
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:24:14.417372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'