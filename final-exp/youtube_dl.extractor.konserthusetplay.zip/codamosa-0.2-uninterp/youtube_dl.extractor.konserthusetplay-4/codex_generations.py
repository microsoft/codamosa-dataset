

# Generated at 2022-06-18 14:14:34.224376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_list() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^(?:KonserthusetPlay|konserthusetplay)$']
    assert ie.supported_categories() == ['general']
    assert ie.supported_c

# Generated at 2022-06-18 14:14:42.781488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:14:44.685942
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:14:54.368205
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:14:58.667820
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:15:10.458878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:15:15.688945
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/') == False

# Generated at 2022-06-18 14:15:24.833540
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:15:35.875766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:15:43.349611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '1.0'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:16:18.541190
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:16:28.389529
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:16:35.852555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-18 14:16:47.438126
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:16:58.860618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:05.060063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)']

# Generated at 2022-06-18 14:17:14.855530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:25.249960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:17:29.943468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.extractor_genres() == ['classical']
    assert ie.extractor_countries() == ['SE']
    assert ie.extractor_languages() == ['sv']

# Generated at 2022-06-18 14:17:38.157696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_domains() == ['konserthusetplay.se', 'rspoplay.se']
    assert ie.supported_urls() == ['http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw']

# Generated at 2022-06-18 14:18:48.721264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-18 14:18:51.319138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-18 14:18:57.164522
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'
    assert ie.extractor_type() == 'playlist'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_list() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^(?:KonserthusetPlay|konserthusetplay)$']

# Generated at 2022-06-18 14:19:02.996333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:12.912571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_list() == ['.*']
    assert ie

# Generated at 2022-06-18 14:19:18.950414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:30.647615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == [r'^KonserthusetPlay$']
    assert ie.supported_categories() == ['general']
    assert ie.supported_categories_re() == [r'^general$']
    assert ie.supported_domains() == ['konserthusetplay.se', 'rspoplay.se']
    assert ie.supported_

# Generated at 2022-06-18 14:19:39.055039
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:19:48.352799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:19:58.616250
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:22:19.197259
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:27.160785
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:33.225017
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-18 14:22:41.922489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-18 14:22:47.256026
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:22:53.555048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-18 14:23:03.228311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.extractor_name() == 'KonserthusetPlay'
    assert ie.extractor_description() == 'KonserthusetPlay'
    assert ie.extractor_version() == '0.0.1'

# Generated at 2022-06-18 14:23:10.047436
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['KonserthusetPlay']
    assert ie.supported_extractors_re() == ['.*']
    assert ie.supported_extractors_re_str() == '.*'
    assert ie.supported_extractors_str() == '.*'
    assert ie.supported_extractors_str_list() == ['.*']
    assert ie

# Generated at 2022-06-18 14:23:18.293113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extractor_key() == 'KonserthusetPlay'

# Generated at 2022-06-18 14:23:23.589027
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')