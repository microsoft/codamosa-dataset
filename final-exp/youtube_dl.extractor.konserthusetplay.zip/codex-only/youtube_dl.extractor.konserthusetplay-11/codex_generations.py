

# Generated at 2022-06-24 12:47:35.904795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    e.extract("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:47:36.973105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:47:39.758754
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:47:41.948395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:47:45.228453
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    _ = KonserthusetPlayIE(KonserthusetPlayIE._downloader,
        KonserthusetPlayIE._VALID_URL, KonserthusetPlayIE._TESTS[0])

# Generated at 2022-06-24 12:47:48.541114
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
        assert ie != None

# Generated at 2022-06-24 12:47:52.136753
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Create an instance of class KonserthusetPlayIE and test its constructors.
    """

    konserthusetplayie = KonserthusetPlayIE()
    assert konserthusetplayie is not None

# Generated at 2022-06-24 12:47:53.486038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:55.173912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Just create a new instance of KonserthusetPlayIE and it should pass.
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:57.132382
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # KonserthusetPlayIE should inherit InfoExtractor
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:48:00.569021
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay.se, Royal Stockholm Philharmonic Orchestra'

# Generated at 2022-06-24 12:48:02.569676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:48:03.968928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert isinstance(KonserthusetPlayIE(), InfoExtractor)

# Generated at 2022-06-24 12:48:04.587911
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:08.079131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:17.241662
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	obj = KonserthusetPlayIE()
	assert(obj._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")
	assert(obj._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
	assert(obj._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967")
	assert(obj._TESTS[0]['info_dict']['id'] == "CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:48:18.289111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:24.504776
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test url:
    # http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A

    # Extract the information for this url:
    KonserthusetPlayIE().extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:26.146556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlayIE', 'konserthusetplay.se')

# Generated at 2022-06-24 12:48:28.184460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:38.543616
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert not ie.suitable("http://www.youtube.com/watch?v=baW_jenozKc")
# # Unit test for constructor of class KonserthusetPlayIE
# def test_KonserthusetPlayIE():
#     ie = KonserthusetPlayIE()
#     assert ie.ie_key() == 'konserthusetplay'
#     assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")


# Generated at 2022-06-24 12:48:39.708061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:42.055326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
     KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:46.193468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This unit test checks both that the constructor is defined on this class
    # and that it returns an object of the correct type.
    ie = KonserthusetPlayIE()
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:48:47.479908
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:48:55.368915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.m3u8_format_id == 'hls')
    assert(ie.rtmp_server_url == 'rtmps://cp131747.live.edgefcs.net:443')
    assert(ie.rtmp_tunnel_domain is None)
    assert(ie.rtmp_protocol == 'rtmps')

# Generated at 2022-06-24 12:48:57.144810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None


# Generated at 2022-06-24 12:49:01.506198
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlay = KonserthusetPlayIE()
    assert KonserthusetPlay._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:02.293711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:05.320511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=YKHmM8wzsFcA-Ls93dHk-A')


# Generated at 2022-06-24 12:49:07.500128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert not KonserthusetPlayIE(InfoExtractor())._downloader.params.get('noplaylist', None)



# Generated at 2022-06-24 12:49:16.356721
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:17.303794
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        assert KonserthusetPlayIE

# Generated at 2022-06-24 12:49:27.756178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    webpage = '<html>...</html>'
    e = 'CKDDnlCY-dhWAAqiMERd-A'
    rest = {'media': {'playerconfig': {'playlist': [{}, {}]}}}

    # Test extractor without error
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:29.081724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst

# Generated at 2022-06-24 12:49:32.590798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.name == 'konserthusetplay'
    assert k.IE_NAME == 'konserthusetplay'
    assert k.SUFFIX == 'konserthusetplay'
    assert k.IE_DESC == 'konserthusetplay.se'

# Generated at 2022-06-24 12:49:40.644167
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert ie._VALID_URL == "https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:49:51.908180
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    fetcher = KonserthusetPlayIE()
    assert(fetcher)
    assert(fetcher._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")
    assert(fetcher._TESTS) # Video url/id/md5 is loaded
    assert(fetcher._TESTS[0]['url'] == url)

    #test constructor
    video_id = fetcher._match_id(url)
    fetcher._download_webpage(url, video_id)

# Generated at 2022-06-24 12:49:56.742494
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert(ie.suitable(url))
    assert(ie.ie_key() == 'KonserthusetPlay')

# Generated at 2022-06-24 12:49:58.651364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    # This shouldn't raise any exception
    assert True

# Generated at 2022-06-24 12:50:04.238201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_inst = KonserthusetPlayIE()
    assert test_inst.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not test_inst.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&a=fdf')

# Generated at 2022-06-24 12:50:05.143119
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:15.454050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert ie.suitable("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert ie.suitable("http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert ie.suitable("https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True

# Generated at 2022-06-24 12:50:19.138182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test whether the constructor of KonserthusetPlayIE works """
    # Assert that the constructor for the KonserthusetPlayIE works
    assert isinstance(KonserthusetPlayIE(), KonserthusetPlayIE)

# Generated at 2022-06-24 12:50:30.569703
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    input_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    mp_url = 'http://www.konserthusetplay.se/templates/konserthuset/flash/mediaplayer5.5.swf'
    # Test player_config

# Generated at 2022-06-24 12:50:31.590020
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:34.436711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

    assert isinstance(ie, InfoExtractor)


# Unit tests for the _real_extract method of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:37.188199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_real_extract')
    assert callable(KonserthusetPlayIE._real_extract)

# Generated at 2022-06-24 12:50:38.529982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Exercise constructor
    assert(ie)

# Generated at 2022-06-24 12:50:40.116633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj.init()
    assert obj

# Generated at 2022-06-24 12:50:44.096946
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_KPIE = KonserthusetPlayIE()
    test_KPIE.test()
    print(test_KPIE._VALID_URL)
    #test_KPIE._match_id(url)

# Generated at 2022-06-24 12:50:52.510215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if ie._VALID_URL != r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)':
        raise Exception("Test of class KonserthusetPlayIE._VALID_URL failed")

# Generated at 2022-06-24 12:50:59.393146
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    output = ie.extract()
    assert output.get('id') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert output.get('title') == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:51:01.128244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_object = KonserthusetPlayIE()
    assert isinstance(ie_object, InfoExtractor)

# Generated at 2022-06-24 12:51:07.284808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    yt = KonserthusetPlayIE()
    assert yt.klass == KonserthusetPlayIE
    assert yt.ie_key() == 'KonserthusetPlay'
    assert 'www.konserthusetplay.se' in yt.url_re.pattern
    assert 'rspoplay.se' in yt.url_re.pattern
    assert '[^&]+' in yt.url_re.pattern

# Generated at 2022-06-24 12:51:08.400768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    ie.set_downloader(None);

# Generated at 2022-06-24 12:51:13.210756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tester = KonserthusetPlayIE()
    obj = tester._real_extract("http://www.konserthusetplay.se/?m=Hee7YhJg6jKzBQQfH_8k-Q")
    assert obj.get('id') is not None

# Generated at 2022-06-24 12:51:17.417335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_universals import test_IE

    vurl = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    test_IE(KonserthusetPlayIE, vurl, [])

# Generated at 2022-06-24 12:51:23.747360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    unit2 = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.extract(unit)
    ie.extract(unit2)

# Generated at 2022-06-24 12:51:29.538042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with empty URL
    assert KonserthusetPlayIE(None, None)
    # Test with valid URL
    konserthusetplay_ie = KonserthusetPlayIE(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', None)
    # Test with invalid URL
    konserthusetplay_ie = KonserthusetPlayIE('invalid_url', None)
    assert konserthusetplay_ie.media_id is None


# Generated at 2022-06-24 12:51:32.517586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(None)
    obj.suitable(None)
    obj.extract(None)

# Generated at 2022-06-24 12:51:37.052449
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?', 'CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://rspoplay.se/?', 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:38.810409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor for class KonserthusetPlayIE
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:41.536919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing KonserthusetPlayIE")
    # Tests return of object instance
    assert KonserthusetPlayIE(None) is not None
    print("Done testing KonserthusetPlayIE")

# Generated at 2022-06-24 12:51:42.963592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(), KonserthusetPlayIE)

# Generated at 2022-06-24 12:51:43.734414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:51:54.067462
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    dict1 = {'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'md5': 'e3fd47bf44e864bd23c08e487abe1967', 'info_dict': {'id': 'CKDDnlCY-dhWAAqiMERd-A', 'ext': 'mp4', 'title': 'Orkesterns instrument: Valthornen', 'description': 'md5:f10e1f0030202020396a4d712d2fa827', 'thumbnail': 're:^https?://.*$', 'duration': 398.76}}


# Generated at 2022-06-24 12:52:05.315059
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie.suitable('http://www.google.com/m=elWuEH34SMKvaO4wO_cHBw')
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar')

# Generated at 2022-06-24 12:52:06.079124
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:52:07.107597
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)


# Generated at 2022-06-24 12:52:08.990286
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiation
    KonserthusetPlayIE(InfoExtractor("KonserthusetPlayIE", True))


# Generated at 2022-06-24 12:52:12.799292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert isinstance(obj, InfoExtractor)
    obj._real_extract(url)


# Generated at 2022-06-24 12:52:17.246438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the constructor.
    ie = KonserthusetPlayIE()
    # Test the instance created.
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:27.792771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Create an instance of KonserthusetPlayIE
    k = KonserthusetPlayIE()
    k.url = url
    k._match_id(url)
    k._download_webpage(url=url, video_id='CKDDnlCY-dhWAAqiMERd-A')
    k._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'e')


# Generated at 2022-06-24 12:52:30.505543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:31.465266
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:52:32.397666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE



# Generated at 2022-06-24 12:52:39.987448
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:42.694343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'


if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:54.526736
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:52:57.223935
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	print(KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))

# Generated at 2022-06-24 12:53:02.239668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for a valid url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)
    # Test for a invalid url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A-Invalid'
    with pytest.raises(Exception):
        KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:53:03.448799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False

# Generated at 2022-06-24 12:53:07.956856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    KonserthusetPlayIE(None).suitable(url)
    try:
        KonserthusetPlayIE(None)._real_extract(url)
    except:
        assert False, "Unit test failed"
    assert True, "Unit test success"

# Generated at 2022-06-24 12:53:11.726670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:53:18.053441
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True

# Generated at 2022-06-24 12:53:21.673509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpie = KonserthusetPlayIE()
    assert kpie.get_url_regex() == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:53:25.842175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url == 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-24 12:53:28.853121
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:33.026035
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:34.973509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:35.797469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:38.058464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False, 'constructor of class KonserthusetPlayIE failed'
    assert True


# Generated at 2022-06-24 12:53:49.559041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test that works
    """
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Not now
    #assert 3 == 3 # get url
    #assert 4 == 4 # get video id
    #assert 5 == 5 # get webpage
    #assert 6 == 6 # get e
    #assert 7 == 7 # get rest
    #assert 8 == 8 # get media
    #assert 9 == 9 # get player_config
    #assert 10 == 10 # get playlist
    #assert 11 == 11 # get source
    #assert 12 == 12 # get m3u8_url
    #assert 13 == 13 # get fallback_url
    #assert 14 == 14 # get fallback_format_id
    #assert 15 == 15

# Generated at 2022-06-24 12:53:51.977924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert('KonserthusetPlayIE' == KonserthusetPlayIE().IE_NAME)


# Generated at 2022-06-24 12:53:55.641079
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:53:58.510530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    InfoExtractor.suite_tests({
        # test for no exception raised for new class
        'test_KonserthusetPlayIE': KonserthusetPlayIE
    })

# Generated at 2022-06-24 12:54:00.629098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:54:10.571071
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:54:13.581456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE() # instantiate instance of class KonserthusetPlayIE
    assert isinstance(ie, InfoExtractor) # ensure ie is instance of InfoExtractor

# Generated at 2022-06-24 12:54:23.997672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:26.931710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:54:28.691462
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    d = KonserthusetPlayIE()
    assert isinstance(d, KonserthusetPlayIE)

# Generated at 2022-06-24 12:54:29.649984
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print(KonserthusetPlayIE())

# Generated at 2022-06-24 12:54:30.913580
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:54:34.816808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:54:35.917975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:54:41.993586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    assert KonserthusetPlayIE._VALID_URL is not None
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._downloader is not None
    assert ie.suitable(ie._VALID_URL)
    assert ie._WORKING == True

# Generated at 2022-06-24 12:54:44.368925
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.ie_key() == 'Konserthuset'
    assert k.ie_name == 'konserthusetplay'

# Generated at 2022-06-24 12:54:45.266728
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:54:47.419884
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie=KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:52.328720
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie._download_info(url, True)

# Generated at 2022-06-24 12:54:59.425957
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.desc() == 'KonserthusetPlay'
    assert ie.host() == 'konserthusetplay.se'
    assert ie.valid('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:55:02.780878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('KonserthusetPlayIE')._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:06.139270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for KonserthusetPlayIE

    """
    KE = KonserthusetPlayIE()
    KE.extract(KE._TESTS[0]['url'])

# Generated at 2022-06-24 12:55:07.136051
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:55:13.381063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:16.067076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the constructor of class KonserthusetPlayIE
    obj = KonserthusetPlayIE()
    print(obj)
    assert(obj is not None)


# Generated at 2022-06-24 12:55:26.004255
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:55:29.225144
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUITABLE_UPLOAD_STATUSES == frozenset((403, ))
    assert ie.ANONYMOUS_URL_KEY == 'a'
    assert ie.ANONYMOUS_URL_EXPIRES == 1800

# Generated at 2022-06-24 12:55:30.851987
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:55:35.160749
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    # test KonserthusetPlayIE is a subclass of InfoExtractor
    assert issubclass(type(ie), InfoExtractor)


# test function for KonserthusetPlayIE._real_extract()

# Generated at 2022-06-24 12:55:37.039602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor should take a string as an argument
    str = ""
    p = KonserthusetPlayIE(str)

# Generated at 2022-06-24 12:55:41.307817
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    res = KonserthusetPlayIE()._real_extract(url)
    if 'KonserthusetPlayIE' not in res['title']:
        raise ValueError("KonserthusetPlayIE. ")


# Generated at 2022-06-24 12:55:44.638712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that it's an instance of InfoExtractor
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.__class__.__name__ == 'InfoExtractor'

# Generated at 2022-06-24 12:55:49.528436
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetplay_ie = KonserthusetPlayIE(url)
    assert konserthusetplay_ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:50.392770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    assert(True)

# Generated at 2022-06-24 12:55:51.542561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract()

# Generated at 2022-06-24 12:55:59.680497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:08.118754
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    input_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    input_videoID = "CKDDnlCY-dhWAAqiMERd-A"
    expected_output = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    ie = KonserthusetPlayIE(input_url)
    assert ie._VALID_URL == expected_output

    input_url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    input_videoID = "elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:56:15.149938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import KonserthusetPlayIE
    from . import Konser

# Generated at 2022-06-24 12:56:17.654543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:19.893826
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:56:26.409923
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('')

    object.__setattr__(ie, '_download_webpage', lambda *args: '{ "media": { "title": "title", "duration": "123.456789", "image": "thumbnail", "playerconfig": { "title": "title", "playlist": [{ "provider": "provider" }], "mediaInfo": { "description": "description" }, "plugins": { "bwcheck": { "netConnectionUrl": "connection_url" } }, "rtmp": { "netConnectionUrl": "connection_url" } } } }')

# Generated at 2022-06-24 12:56:38.858998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:40.242358
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None, None)
    except Exception as e:
        assert False, e

# Generated at 2022-06-24 12:56:43.694963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'konserthusetplay: '

# Generated at 2022-06-24 12:56:49.115406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not info_extractor.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:56:51.829157
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:56:52.850452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:54.236262
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:57:02.933078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for class 'KonserthusetPlayIE'
    test_extractor = KonserthusetPlayIE()
    assert test_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:12.037399
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    This method is to test constructor of class KonserthusetPlayIE.
    """

    # Calling constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

    # Checking if object created is instance of class KonserthusetPlayIE
    if isinstance(ie, KonserthusetPlayIE):
        print("The object created using KonserthusetPlayIE is instance of class KonserthusetPlayIE")
    else:
        print("The object created using KonserthusetPlayIE is not an instance of class KonserthusetPlayIE")



# Generated at 2022-06-24 12:57:17.421581
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    #url = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    x = ie.extract(url)
    assert(x is not None)

# Generated at 2022-06-24 12:57:20.291684
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert extractor.get_url() == "https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:57:27.294079
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with valid URL
    ie = KonserthusetPlayIE()
    valid_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(valid_url)
    # No extraction should be done because 'id' is not provided.
    no_id_url = 'http://www.konserthusetplay.se/?m='
    ie.extract(no_id_url)

# Generated at 2022-06-24 12:57:37.776694
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'