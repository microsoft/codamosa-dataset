

# Generated at 2022-06-24 12:47:29.397668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-24 12:47:35.611410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:38.097878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:49.055328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # a function to call when testing class
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, KonserthusetPlayIE)
    assert isinstance(ie, InfoExtractor)
    # tests if the url matches the regex
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == "elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:47:55.219382
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert (KonserthusetPlayIE._TESTS[0] == (
        InfoExtractor._TESTS[0])._replace(
            extractor_key=KonserthusetPlayIE.ie_key()) and \
        KonserthusetPlayIE._TESTS[1] == (
            InfoExtractor._TESTS[1])._replace(
                extractor_key=KonserthusetPlayIE.ie_key()))

# Generated at 2022-06-24 12:48:00.823273
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:03.228955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    

# Generated at 2022-06-24 12:48:07.823722
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:48:08.887819
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-24 12:48:17.725987
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert Callable(ie.suitable)
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'konserthusetplay.se and rspoplay.se'

# Generated at 2022-06-24 12:48:22.940016
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL.match("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert KonserthusetPlayIE._VALID_URL.match("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:48:25.778218
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key() in InfoExtractor._WORKING_IE_KEY

# Generated at 2022-06-24 12:48:32.224410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:33.532692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()



# Generated at 2022-06-24 12:48:41.934882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_LOGGER')
    assert hasattr(ie, '_VALID_URL')
    assert isinstance(ie._VALID_URL, type(re.compile('')))
    assert hasattr(ie, '_TESTS')
    assert isinstance(ie._TESTS, list)
    assert hasattr(ie, 'IE_DESC')
    assert isinstance(ie.IE_DESC, str)
    assert hasattr(ie, 'BR_DESC')
    assert isinstance(ie.BR_DESC, str)

# Generated at 2022-06-24 12:48:46.030845
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:48:49.368963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case = KonserthusetPlayIE('bing')
    assert test_case._VALID_URL is not None
    assert test_case._TESTS is not None

# Generated at 2022-06-24 12:48:51.483276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:56.653798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE()
    assert k.suitable(url)

    # KonserthusetPlayIE is able to handle the url
    assert k._VALID_URL == KonserthusetPlayIE._VALID_URL

    # KonserthusetPlayIE is able to extract the md5 hash
    assert k._TESTS[0]['md5'] == KonserthusetPlayIE._TESTS[0]['md5']

    # KonserthusetPlayIE is able to extract the id

# Generated at 2022-06-24 12:48:58.095735
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:59.085314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL is not None


# Generated at 2022-06-24 12:49:03.429663
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Create Object for test
    obj = KonserthusetPlayIE()

    # Test if the URL matches the pattern
    assert obj._VALID_URL == obj._match_id(url)

# Generated at 2022-06-24 12:49:04.602428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(object)

# Generated at 2022-06-24 12:49:14.255068
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:19.844685
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie.ie_id() == 'konserthusetplay'
    assert ie.supported_extractors() == ['KonserthusetPlay']

# Generated at 2022-06-24 12:49:22.813136
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    # Unit test for constructor
    info_extractor = KonserthusetPlayIE()
    assert info_extractor

# Generated at 2022-06-24 12:49:24.248421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    return ie.getSIE()

# Generated at 2022-06-24 12:49:27.287090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_konserthusetplay_ie = KonserthusetPlayIE()
    assert test_konserthusetplay_ie is not None


# Generated at 2022-06-24 12:49:29.741213
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        ie = KonserthusetPlayIE()
    except NameError as e:
        assert False, 'NameError: {0}'.format(e)


# Generated at 2022-06-24 12:49:31.613960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KpIE = KonserthusetPlayIE()
    return test_KpIE.suitable(test_KpIE._VALID_URL)

# Generated at 2022-06-24 12:49:35.234447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    IE._downloader = FakeDownloader()

    ie = IE(IE._downloader, url)

    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'



# Generated at 2022-06-24 12:49:36.107086
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:47.375029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
  #  assert ie.get_api_url() == 'https://www.konserthusetplay.se/api/player'
    assert ie.get_json_url() == 'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object'
    assert ie.get_title_regex() == r'(?:\s|<[^>]+>)*(?P<title>.*?)(?:\s|<[^>]+>)*'
    assert ie.get_playlist_regex() == r'playerconfig[\s\S]+?playlist'

# Generated at 2022-06-24 12:49:59.218364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.get_domain()[0]=="konserthusetplay") and (ie.get_domain()[1]=="rspoplay")
    assert(ie.get_domain_desc()[0]=="konserthusetplay.se") and (ie.get_domain_desc()[1]=="rspoplay.se")
    assert(ie.get_url_regex()=="https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")

# Generated at 2022-06-24 12:50:08.236477
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:09.673870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()


# Generated at 2022-06-24 12:50:21.779870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'

    # Test URL of class KonserthusetPlayIE
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Test video ID of class KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:24.273165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None

# Generated at 2022-06-24 12:50:25.661669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:50:31.227341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor for the KonserthusetPlayIE class
    ie1 = KonserthusetPlayIE()
    assert ie1.ie_key() == 'KonserthusetPlay'
    assert ie1.ie_name() == 'Konserthuset Play'
    assert ie1.ie_urls() == ['https://www.konserthusetplay.se/']

# Generated at 2022-06-24 12:50:39.615008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = (
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    konserthuset_play = KonserthusetPlayIE()
    konserthuset_play._match_id(url)
    konserthuset_play._real_extract(url)
    konserthuset_play._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:42.044221
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:50:47.092141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''Test for constructor of class KonserthusetPlayIE.'''
    from ..utils import determine_ext
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE
    assert(KonserthusetPlayIE.__bases__ == (InfoExtractor,)), "class KonserthusetPlayIE must inherit from InfoExtractor"



# Generated at 2022-06-24 12:50:47.990516
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:49.004732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:49.929700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:01.173884
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()
    validate = True

    if t.IE_NAME != 'konserthusetplay':
        print('Invalid IE_NAME')
        validate = False
    if t.MSG_DOMAIN != 'konserthusetplay':
        print('Invalid MSG_DOMAIN')
        validate = False
    if t._VALID_URL != r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)':
        print('Invalid _VALID_URL')
        validate = False
    if not validate:
        print('Constructor for KonserthusetPlayIE not valid')
        return False

    return True

# Generated at 2022-06-24 12:51:06.622430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")


# Generated at 2022-06-24 12:51:13.354693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test object creation
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert isinstance(ie, InfoExtractor)
    assert not hasattr(ie, "_downloader")
    assert not hasattr(ie, "_download_webpage")
    assert not hasattr(ie, "_download_json")
    assert not hasattr(ie, "_search_regex")
    assert not hasattr(ie, "_extract_m3u8_formats")
    assert not hasattr(ie, "_sort_formats")
    assert not hasattr(ie, "_match_id")
    ie._match_id("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:51:15.115139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE(None)
    assert(info_extractor.SUFFIXES)
    assert(info_extractor.ie_key())


# Generated at 2022-06-24 12:51:26.095415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:37.732924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'konserthusetplay'

    # test for method _real_extract
    ie_real_extract = ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # test for medie 'id'
    assert ie_real_extract['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    # test for media 'title'
    assert ie_real_extract['title'] == 'Orkesterns instrument: Valthornen'
    # test for media 'duration'


# Generated at 2022-06-24 12:51:38.709900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass



# Generated at 2022-06-24 12:51:41.098930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for a constructor of class KonserthusetPlayIE
    print("KonserthusetPlayIE is a constructor, no need to test")
    return True

# Generated at 2022-06-24 12:51:44.664026
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # 1. No arguments
    ie = KonserthusetPlayIE()

    # 2. One argument
    ie = KonserthusetPlayIE('my_id')
    
    # 3. All arguments
    ie = KonserthusetPlayIE('my_id', 'my_url', 'my_title')

    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_url() == 'http://www.konserthusetplay.se/'

# Generated at 2022-06-24 12:51:54.910379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:56.972995
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    "Tests class constructor and if the buildCommand works"
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:52:06.554444
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.params == {'m': 'CKDDnlCY-dhWAAqiMERd-A'}
    assert ie.query == 'm=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:13.791676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert ie.playlist_result["_type"] == 'playlist'
    assert ie.playlist_result["id"] == 'elWuEH34SMKvaO4wO_cHBw'
    assert ie.playlist_result["_info_dict"]["title"] == 'Konsert med Kungliga Filharmonikerna'

    ie = KonserthusetPlayIE("https://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert ie.playlist_result["_type"] == 'playlist'

# Generated at 2022-06-24 12:52:25.705818
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay.se'
    assert ie.IE_DESC == 'konserthusetplay.se'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._NETRC_MACHINE == 'konserthusetplay'

# Generated at 2022-06-24 12:52:31.856206
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert(i._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(i._TESTS[1] == {
        'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
        'only_matching': True,
    })


# Generated at 2022-06-24 12:52:32.445994
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	pass

# Generated at 2022-06-24 12:52:33.716564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:52:35.089303
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    return True



# Generated at 2022-06-24 12:52:38.156410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:39.168355
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:52:44.117993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:52:56.164354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:58.220732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE._create_instance()
    assert konserthusetplayIE.ie_key() == 'KonserthusetPlay'


# Test for valid_url function of class KonserthusetPlayIE

# Generated at 2022-06-24 12:52:58.986707
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:05.237846
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:53:07.769238
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    try:
        type(instance)
    except NameError:
        pass
    else:
        raise AssertionError("Not a constructor!")

# Generated at 2022-06-24 12:53:08.671496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:53:10.824125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()



# Generated at 2022-06-24 12:53:12.371371
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:53:16.786576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor)._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:17.590236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:26.675719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:37.129756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:39.548459
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = KonserthusetPlayIE._VALID_URL
	assert url.find(KonserthusetPlayIE._VALID_URL) == 0

# Generated at 2022-06-24 12:53:43.054597
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:52.602838
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    valid_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    invalid_url = "http://www.konserthusetplay.se/"
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert KonserthusetPlayIE._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:53:57.062325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    kp._real_extract(test_url)

# Generated at 2022-06-24 12:54:08.703384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """This is unit test for constructor of class KonserthusetPlayIE """
    config = {
        'extractor_key': 'KonserthusetPlayIE',
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'info_dict': {
            'id': 'CKDDnlCY-dhWAAqiMERd-A',
            'ext': 'mp4',
            'title': 'Orkesterns instrument: Valthornen',
            'description': 'md5:f10e1f0030202020396a4d712d2fa827',
            'thumbnail': 're:^https?://.*$',
            'duration': 398.76,
        },
    }

# Generated at 2022-06-24 12:54:10.068313
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:54:20.890989
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test for constructor
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # test for valid_url
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar')
    assert not KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-24 12:54:24.602655
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert(isinstance(KonserthusetPlayIE(), KonserthusetPlayIE))
    except AssertionError:
        print('AssertionError raised in test_KonserthusetPlayIE().')


# Generated at 2022-06-24 12:54:33.898105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:36.177897
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # assert(KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE')
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:39.319858
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('')
    if ie is None:
        raise AssertionError('Failed to initialize instance of class KonserthusetPlayIE.')

# Generated at 2022-06-24 12:54:40.739815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.ie_key

# Generated at 2022-06-24 12:54:49.219743
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie=KonserthusetPlayIE()
    print (ie.get_url_re()[0])
    print (ie.get_url_re()[1])
    print (ie.get_url_re()[2])
    print (ie.get_url_re()[3])
    print (ie.get_url_re()[4])
    print (ie.get_url_re()[5])
    print (ie.get_url_re()[6])
    print (ie.get_url_re()[7])
    print (ie.get_url_re()[8])
    print (ie.get_url_re()[9])
    print (ie.get_url_re()[10])
    print (ie.get_url_re()[11])

# Generated at 2022-06-24 12:54:54.609147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test1 = KonserthusetPlayIE(_VALID_URL)
    test2 = KonserthusetPlayIE(_TESTS)
    test3 = KonserthusetPlayIE(_real_extract)
    test4 = KonserthusetPlayIE(_match_id)
    test5 = KonserthusetPlayIE(_search_regex)
    test6 = KonserthusetPlayIE(_download_json)
    test7 = KonserthusetPlayIE(_sort_formats)
    test8 = KonserthusetPlayIE(_download_webpage)
    test9 = KonserthusetPlayIE(_extract_m3u8_formats)
    print("test1: ",test1)
    print("test2: ",test2)
    print("test3: ",test3)
   

# Generated at 2022-06-24 12:54:58.374190
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for constructor of class KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE.suitable(url)

# Generated at 2022-06-24 12:55:05.687230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert len(obj._TESTS) is 2
    assert obj._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:55:06.686489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("")

# Generated at 2022-06-24 12:55:07.750659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:18.489756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:19.887750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj

# Generated at 2022-06-24 12:55:25.172489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Act
    extractor = KonserthusetPlayIE(url)

    # Assert
    assert isinstance(extractor, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:27.216113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:55:33.201236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:55:40.283443
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with (KonserthusetPlayIE._downloader.cache_storage_writeonly()) as cache:
        ie = KonserthusetPlayIE()
        ie.to_screen('Initiating downloader');
        ie.to_screen('Setting cache to ' + repr(cache));
        ie.to_screen('Setting extra info to ' + repr(ie.IE_NAME));
        ie.initialize_downloader(None, {
            'outtmpl': '%(id)s.%(ext)s',
            'format': 'best',
        });
        ie.to_screen('Downloading ' + repr(ie._VALID_URL));
        ie.extract(ie._VALID_URL);


# Generated at 2022-06-24 12:55:41.977982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_test = KonserthusetPlayIE('playlist')
    assert ie_test, 'Error at creating test object'

# Generated at 2022-06-24 12:55:44.338310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # The unit test for constructor of class KonserthusetPlayIE
    # is not needed, since there is no initialization.
    return


# Generated at 2022-06-24 12:55:45.889856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the constructor of class KonserthusetPlayIE.
    oKonserthusetPlayIE = KonserthusetPlayIE()
    # The class constructor shall always return a new object reference
    assert oKonserthusetPlayIE != None


# Generated at 2022-06-24 12:55:54.185406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TES

# Generated at 2022-06-24 12:56:00.332610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # To check if the constructor for KonserthusetPlayIE actually works
    # by taking a sample URL and checking if it is of the right class.
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    ie = KonserthusetPlayIE(url)
    assert ie is not None
    assert ie.url == url

# Generated at 2022-06-24 12:56:00.886854
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:56:04.616517
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    kp._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', "Hello", 'e')


# Generated at 2022-06-24 12:56:12.685345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    ie._download_json(
            'http://csp.picsearch.com/rest?e=..........&containerId=mediaplayer&i=object',
            'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:24.079989
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

    e = ie._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')


# Generated at 2022-06-24 12:56:30.520534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(url)
    assert 'RSPOPLAY' in ie.url
    assert 'rspoplay' in ie.name
    assert ie.video_id == 'elWuEH34SMKvaO4wO_cHBw'
    assert ie.description is None

# Generated at 2022-06-24 12:56:35.861732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global KonserthusetPlayIE
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                       {}, {}).get_id()
    # returns the correct video_id
    assert KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                              {}, {}).get_id() == 'CKDDnlCY-dhWAAqiMERd-A'
    # returns the correct video_id
    assert KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                              {}, {}).ext

# Generated at 2022-06-24 12:56:38.357770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    valid_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    valid_obj = KonserthusetPlayIE()
    valid_obj.url = valid_url
    assert valid_obj.match()

# Generated at 2022-06-24 12:56:39.847814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #Tests the correct construction of the class KonserthusetPlayIE
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:56:46.339189
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True



# Generated at 2022-06-24 12:56:51.929276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._match_id('https://www.konserthusetplay.se/') is None
    assert obj._match_id('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:52.958293
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:58.477717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    import Youtube
    import YoutubeDL
    ydl = YoutubeDL.YoutubeDL({'verbose': True})
    # Act
    extractor = ydl.get_info_extractor('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Assert
    assert isinstance(extractor, KonserthusetPlayIE)

# Generated at 2022-06-24 12:57:05.577659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Initialize an KonserthusetPlayIE object.
    KonserthusetPlay = KonserthusetPlayIE._request_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE._entries(KonserthusetPlay, 'CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE._real_extract(url, KonserthusetPlay, 'CKDDnlCY-dhWAAqiMERd-A')
    # Initialize an KonserthusetPlayIE object.

# Generated at 2022-06-24 12:57:06.596151
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-24 12:57:08.242285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test(KonserthusetPlayIE, ['url', 'id'])

# Generated at 2022-06-24 12:57:08.950710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:18.269364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    
    # Url for unit test
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlay = KonserthusetPlayIE()
    
    # Test re_encode function
    encoded_url = KonserthusetPlay._search_regex(KonserthusetPlay._VALID_URL, url, 'id')
    assert(encoded_url == 'CKDDnlCY-dhWAAqiMERd-A')
    
    # Test _real_extract function
    info = KonserthusetPlay._real_extract(url)
    
    # Assertions
    assert(info['id'] == 'CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:57:21.431223
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play = KonserthusetPlayIE()
    assert(isinstance(konserthuset_play, KonserthusetPlayIE))


# Generated at 2022-06-24 12:57:22.441185
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:57:28.550545
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This url is the url used in KonserthusetPlayIE._TESTS[0]
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Create object of InfoExtractor
    ie = InfoExtractor()
    # find the class of the InfoExtractor
    ie_class = ie._get_IE(url)
    assert ie_class == KonserthusetPlayIE

# Generated at 2022-06-24 12:57:32.484187
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if not unittest:
        return

    assert isinstance(KonserthusetPlayIE, type)
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Unit tests for functions of class KonserthusetPlayIE