

# Generated at 2022-06-24 12:47:30.784554
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:32.783013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:47:44.063941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ke = KonserthusetPlayIE(url)
    assert ke.VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=([^&]+)'

# Generated at 2022-06-24 12:47:46.477469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
        Create instance of class KonserthusetPlayIE
    """
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:57.091458
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # KonserthusetPlayIE instantiation
    obj = KonserthusetPlayIE()
    # __init__
    assert hasattr(obj, '_VALID_URL')
    assert hasattr(obj, '_TESTS')
    assert hasattr(obj, '_downloader')
    assert hasattr(obj, '_match_id')
    assert hasattr(obj, '_real_initialize')
    assert hasattr(obj, '_real_extract')
    assert hasattr(obj, '_download_webpage_handle')
    assert hasattr(obj, '_search_regex')
    assert hasattr(obj, '_html_search_regex')
    assert hasattr(obj, '_download_json')
    assert hasattr(obj, '_extract_m3u8_formats')

# Generated at 2022-06-24 12:48:03.105745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == ' Play'
    # extended assertions
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:48:09.525636
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-24 12:48:11.297176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'

# Generated at 2022-06-24 12:48:16.924696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    # matching URL
    assert ie._match_id(r'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id(r'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'

    # non matching URL
    assert ie._match_id(r'http://www.konserthusetplay.se/?m=hello_world') is None

# Generated at 2022-06-24 12:48:18.790468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:20.305539
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie


# Generated at 2022-06-24 12:48:21.723975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:48:29.999264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] =='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:48:32.593900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = ie.ie_key()
    assert obj == 'KonserthusetPlay', 'ie_key() returns wrong value!'

# Generated at 2022-06-24 12:48:36.571587
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_key() != 'konserthusetPlayIE'
    assert ie.ie_key() != 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:48:38.328811
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None


# Generated at 2022-06-24 12:48:43.735990
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == url
    assert KonserthusetPlayIE._TESTS[0]['url'] == url
    # assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:48:47.428551
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:51.482942
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)";

# Generated at 2022-06-24 12:49:02.396606
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Set up the test
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = InfoExtractor.create_instance("KonserthusetPlayIE", "www.konserthusetplay.se")
    ie.set_downloader(downloader=object)
    ie.set_downloader(add_default_headers=False)
    ie.set_downloader(params={})
    ie.set_downloader(params={})
    ie.set_downloader(retries=1)
    ie.set_downloader(timeout=10.0)
    # Execute the code
    ie.extract(url)

# Generated at 2022-06-24 12:49:06.793727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE()
    info = k._real_extract(url)
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A', 'ID is %s' % info['id']

# Generated at 2022-06-24 12:49:09.829612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE('elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:49:14.097855
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("\nTesting KonserthusetPlayIE\n")
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    print(ie)
    print("done\n")


# Generated at 2022-06-24 12:49:21.257352
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with valid url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

    # Test with invalid url
    url = 'http://www.konserthusetplay.se/?m=abc'
    try:
        KonserthusetPlayIE(url)
        # Should except an error
        assert False
    except:
        assert True

# Generated at 2022-06-24 12:49:31.239237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:34.154097
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:49:39.683041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:40.791335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:46.772786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:49:52.648420
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.info_dict['id'] == 'CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-24 12:49:59.569156
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'
    assert ie.decryptor is None
    assert ie.domain == 'konserthusetplay.se'
    assert ie.host == 'http://www.konserthusetplay.se'
    assert ie.logo == 'http://www.konserthusetplay.se/Resources/Images/logo.jpg'

# Generated at 2022-06-24 12:50:01.360684
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:50:02.924575
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert(konserthusetPlayIE.ie_key() == "KonserthusetPlay")


# Generated at 2022-06-24 12:50:07.574354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Regular usecase
    ie = KonserthusetPlayIE()
    assert ie.get_url_re() == KonserthusetPlayIE._VALID_URL
    assert ie.get_host() == 'konserthusetplay'
    assert ie.get_ie_key() == 'KonserthusetPlay'
    assert ie.get_extractor_key() == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:50:16.500573
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._downloader.params['usenetrc'] == True
    assert ie._downloader.params['username'] == 'anonymous'
    assert ie._downloader.params['password'] == 'anonymous@domain.com'

# Generated at 2022-06-24 12:50:19.631729
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()

    # The constructor of the InfoExtractor class doesn't take any argument
    assert not konserthusetplay._VALID_URL

# Generated at 2022-06-24 12:50:23.603269
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('test')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:25.306986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k is not None

# Generated at 2022-06-24 12:50:27.583311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:50:37.258082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
  ie = KonserthusetPlayIE()

  # Check that the expected values are extracted
  data = ie.extract(url)
  assert data['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
  assert data['ext'] == 'mp4'
  assert data['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:50:39.546680
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test if the object constructor works"""

    # Testing an URL known to work
    ie = KonserthusetPlayIE()
    assert(ie is not None)


# Generated at 2022-06-24 12:50:48.713459
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:54.480566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") != None)
    assert(KonserthusetPlayIE("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") != None)

# Generated at 2022-06-24 12:50:56.974137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:58.985815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:50:59.963132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:04.395055
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.format_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Test function for _download_webpage
# Test _download_webpage

# Generated at 2022-06-24 12:51:13.044544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with a valid url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    actual_result = KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:51:19.769551
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:26.039021
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Dummy url for testing
    url = "http://konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    # Constructor of class KonserthusetPlayIE
    ins = KonserthusetPlayIE(url)
    print (ins.get_extractor_name())
    # Assertion of class
    assert ins.get_extractor_name() == 'konserthusetplay'

# Generated at 2022-06-24 12:51:31.059989
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    new_KonserthusetPlayIE = KonserthusetPlayIE()
    instance = KonserthusetPlayIE()
    assert(instance.__class__.__name__ == "KonserthusetPlayIE")
    assert(instance is not new_KonserthusetPlayIE)

# Generated at 2022-06-24 12:51:40.440440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    print("konserthusetplay: %s" % konserthusetplay)
    assert konserthusetplay.IE_NAME == 'konserthusetplay'
    assert KonserthusetPlayIE.IE_NAME == 'konserthusetplay'
    assert KonserthusetPlayIE.VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:42.084947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Class KonserthusetPlayIE constructor test"""
    ie = KonserthusetPlayIE()
    assert(ie.SUFFIX == ':konserthusetplay')

# Generated at 2022-06-24 12:51:52.724781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie_rspoplay = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert ie != ie_rspoplay
    assert ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:00.127696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_reference = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    ie_info = ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    for key in ie_reference.keys():
        assert ie_info[key] == ie_reference[key]

    ie_only_matching = ie._real_ext

# Generated at 2022-06-24 12:52:10.647885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_common import (
        assertIsInstance, assertIsNotNone,
        assertRegex, assertEqual,
        assertDictEqual,
        assertListEqual
    )
    from .common import InfoExtractor

    url = ""
    ie = KonserthusetPlayIE(InfoExtractor)

    assertIsInstance(ie, InfoExtractor)

    # Test if the _VALID_URL class pattern is a valid regex
    assertIsNotNone(ie._VALID_URL)
    assertRegex(ie, ie._VALID_URL, url)

    # Test if the extractor is working
    (extract_info, video) = ie.extract(url)
    assertIsNotNone(extract_info)

    # Test if fields are set

# Generated at 2022-06-24 12:52:12.248618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:52:24.447680
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(url)

    assert ie.url == url
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie.rest_url == "http://csp.picsearch.com/rest?e=TV5DnlCY-dhWAAqiMERd-A&containerId=mediaplayer&i=object"
    assert ie.connection_url == "rtmp://csp.picsearch.com:1935/streaming/"
    assert ie.url_pattern == "http://csp.picsearch.com/rest?e=(.+?)[&\"']"
    assert ie.connection_

# Generated at 2022-06-24 12:52:26.961233
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:52:35.906493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = dict()
    test['url'] = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    test['md5'] = "e3fd47bf44e864bd23c08e487abe1967"
    test['info_dict'] = {'title': 'Orkesterns instrument: Valthornen',
     'ext': 'mp4',
     'id': 'CKDDnlCY-dhWAAqiMERd-A',
     'thumbnail': 're:^https?://.*$',
     'duration': 398.76,
     'description': 'md5:f10e1f0030202020396a4d712d2fa827'}

    # class constructor
    konserthusetplay = Konserthus

# Generated at 2022-06-24 12:52:38.831598
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    The call to the KonserthusetPlayIE constructor shall produce a
    an instance of InfoExtractor.
    """
    ie = KonserthusetPlayIE(InfoExtractor)
    assert ie

# Generated at 2022-06-24 12:52:39.830070
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:52:42.724690
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance.ie_key() == "KonserthusetPlay"



# Generated at 2022-06-24 12:52:44.114687
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    _ = create_KonserthusetPlayIE()


# Generated at 2022-06-24 12:52:56.164843
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:56.804306
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:58.558087
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie is not None)


# Generated at 2022-06-24 12:52:59.847535
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst is not None

# Generated at 2022-06-24 12:53:01.367756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:02.331580
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:53:10.057076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:12.469892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')

# Generated at 2022-06-24 12:53:14.217098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False

# Generated at 2022-06-24 12:53:16.236300
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:53:25.320062
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:53:27.316418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:32.648893
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for the constructor of the class KonserthusetPlayIE
    """

    # When no arguments are passed
    try:
        KonserthusetPlayIE()
    except TypeError:
        pass

    # When no video id is passed
    try:
        KonserthusetPlayIE(None)
    except TypeError:
        pass


# Generated at 2022-06-24 12:53:35.195582
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    sampleUrl = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    match = instance._VALID_URL.match(sampleUrl)
    assert match
    result = instance._real_extract(sampleUrl)
    print(result)
    assert result

# Generated at 2022-06-24 12:53:36.295296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == type(KonserthusetPlayIE())


# Generated at 2022-06-24 12:53:38.055879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # To test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:49.556736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    info_dict = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    target = class_
    assert target.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:50.577933
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:58.098291
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    check_game = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # extract the orginal media link and title.
    info_dict = ie._real_extract(check_game)
    assert info_dict.get("id"), "video id is null"
    assert info_dict.get("title"), "video title is null"

# Generated at 2022-06-24 12:54:00.727591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False, "Constructor of KonserthusetPlayIE throws exception"

# Generated at 2022-06-24 12:54:03.407941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'



# Generated at 2022-06-24 12:54:09.851694
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konsert.org/konserthusetplay')
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Rspoplay.se, Konserthusetplay.se'


# Generated at 2022-06-24 12:54:10.885818
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:17.188160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    fixtures = [
        'http://csp.picsearch.com/rest?e=1433595506272&containerId=mediaplayer&i=object&n=0',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
    ]
    for url in fixtures:
        KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:54:19.981278
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE_obj = KonserthusetPlayIE()
    assert KonserthusetPlayIE_obj


# Generated at 2022-06-24 12:54:27.602065
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test valid url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthuset_play_ie = KonserthusetPlayIE()
    if not konserthuset_play_ie.suitable(url):
        print("Test 1: incorrect result for suitable")
    if konserthuset_play_ie.IE_NAME != "konserthusetplay":
        print("Test 2: incorrect result for IE_NAME")

# Generated at 2022-06-24 12:54:28.593457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:29.562513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:40.306160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    the_KonserthusetPlayIE = KonserthusetPlayIE()
    the_KonserthusetPlayIE._match_id(url)

    the_KonserthusetPlayIE._download_webpage(url, "CKDDnlCY-dhWAAqiMERd-A")

    the_KonserthusetPlayIE._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']',
        the_KonserthusetPlayIE, 'e')


# Generated at 2022-06-24 12:54:42.586033
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    assert isinstance(class_, type)
    assert issubclass(class_, InfoExtractor)

# Generated at 2022-06-24 12:54:46.218148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE.ie_key()
    ie = KonserthusetPlayIE.suitable()
    ie = KonserthusetPlayIE._html_get_attribute()
    ie = KonserthusetPlayIE._json_search()

# Generated at 2022-06-24 12:54:46.990307
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:48.478133
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL



# Generated at 2022-06-24 12:54:59.597654
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.name == "KonserthusetPlayIE"
    assert ie.ie_key() == "KonserthusetPlayIE"
    assert ie.url_name == "KonserthusetPlayIE"
    assert ie.working == True
    assert ie.parameters == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.format == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:55:00.907005
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:55:13.143723
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    video_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = ie._match_id(video_url)
    web_page = ie._download_webpage(video_url, video_id)
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', web_page, 'e')

# Generated at 2022-06-24 12:55:14.124510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:16.200928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test KonserthusetPlayIE.__init__
    try:
        assert KonserthusetPlayIE()
    except Exception as e:
        print(str(e))


# Generated at 2022-06-24 12:55:17.571705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-24 12:55:19.039448
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-24 12:55:22.977203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()

    assert kp._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert kp._TESTS == KonserthusetPlayIE._TESTS


# Generated at 2022-06-24 12:55:24.075727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:24.665677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:25.765147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download(ie._VALID_URL)

# Generated at 2022-06-24 12:55:27.455784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:30.985903
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError as e:
        assert "Can't instantiate abstract class KonserthusetPlayIE with abstract methods _download_json" == str(e)
    else:
        raise AssertionError("Constructor of abstract class KonserthusetPlayIE shouldn't work without abstract methods")

# Generated at 2022-06-24 12:55:36.533681
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&a=b')

# Generated at 2022-06-24 12:55:39.951394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tests = ['http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A']
    for url in tests:
        KonserthusetPlayIE(url)


# Generated at 2022-06-24 12:55:48.608814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Function to verify that the tests work
    def mytest(self, name, input_string, expected_result):
        self.assertEqual(name, expected_result, input_string)

    mytest("rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw","rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw","elWuEH34SMKvaO4wO_cHBw")
    mytest("konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A","konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A","CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:55:52.675848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:55:59.039710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == "konserthusetplay"
    assert ie.IE_NAME == "konserthusetplay.se"
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:56:04.115975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._real_extract(url)
    assert ie._match_id() == video_id

# Generated at 2022-06-24 12:56:14.844005
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Instantiation of class
    assert ie.get_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.get_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    # Test with URL that should not match
    assert ie.get_url('http://example.com') is None

# Generated at 2022-06-24 12:56:19.205753
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.IE_NAME == "konserthusetplay"
    assert ie.IE_DESC == "KonserthusetPlay"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:24.080576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS
    assert KonserthusetPlayIE()._real_extract == KonserthusetPlayIE._real_extract

# Generated at 2022-06-24 12:56:24.959852
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:56:27.347111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('www.konserthusetplay.se', 'dummy url')
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:56:29.686771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp

# Generated at 2022-06-24 12:56:30.794246
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:33.499193
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("").is_valid_url("")
    assert not KonserthusetPlayIE("").is_valid_url("notvalidurl")

# Generated at 2022-06-24 12:56:37.401553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # verify constructor works
    child = KonserthusetPlayIE()
    assert child is not None

    # verify class variable is set
    assert KonserthusetPlayIE._VALID_URL is not None

# Generated at 2022-06-24 12:56:43.545127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.valid_url("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.valid_url("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

    ie2 = KonserthusetPlayIE("http://wrongurl.com/")
    assert not ie2.valid_url("http://wrongurl.com/")

# Generated at 2022-06-24 12:56:54.188624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Constructor test
    """
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_name() == 'Konserthuset Play'
    assert obj.ie_urls() == ['konserthusetplay.se']
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:55.313080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:57.002860
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        assert False, 'Constructor of class KonserthusetPlayIE has changed'

# Generated at 2022-06-24 12:56:59.821520
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&h=-1&t=1"
    KonserhusetPlay = KonserthusetPlayIE()
    KonserhusetPlay._real_extract(url)

# Generated at 2022-06-24 12:57:07.697328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:57:09.301760
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:18.518686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = {
        'id': 'video_id',
        'title': 'video_title',
        'formats': [{'format_id': 'format_id', 'url': 'video_url'}],
        'thumbnail': 'video_thumbnail',
        'duration': 5,
        'description': 'video_description'
    }
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:29.115912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE()
    assert k._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'