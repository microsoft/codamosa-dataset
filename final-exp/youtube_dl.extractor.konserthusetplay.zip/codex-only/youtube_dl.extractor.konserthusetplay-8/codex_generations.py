

# Generated at 2022-06-24 12:47:42.244011
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ((KonserthusetPlayIE()._real_extract(url)['id']) == 'CKDDnlCY-dhWAAqiMERd-A')
    assert ((KonserthusetPlayIE()._real_extract(url)['title']) == 'Orkesterns instrument: Valthornen')

# Generated at 2022-06-24 12:47:45.871368
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    return obj._real_extract(url)

# Generated at 2022-06-24 12:47:46.839043
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:53.864208
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert obj.name == "KonserthusetPlayIE"
    assert obj.url == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert obj.video_id == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:48:01.122384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:04.703431
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:48:07.264678
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert(ie.ie_key() == 'konserthuset_play')

# Generated at 2022-06-24 12:48:12.774816
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._TESTS
    assert ie._VALID_URL
    assert ie._real_extract
    assert ie._search_regex
    assert ie._match_id
    assert ie._extract_m3u8_formats
    assert ie._download_webpage
    assert ie._download_json
    assert ie._sort_formats


# Generated at 2022-06-24 12:48:14.672120
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None

# Generated at 2022-06-24 12:48:17.550644
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:48:20.734074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False, "Unit test for constructor of class KonserthusetPlayIE failed"
        raise


# Generated at 2022-06-24 12:48:29.345908
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:48:31.244863
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:48:37.783344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    konserthusetplay_ie = ie('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'None')
    assert repr(konserthusetplay_ie) == '<KonserthusetPlayIE site=http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A>'

# Generated at 2022-06-24 12:48:42.287584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test public constructor from parent class
    try:
        KonserthusetPlayIE()
    except TypeError:
        print("Error during public constructor from parent class")
    # Test private constructor from parent class
    try:
        InfoExtractor._make_result_class()()
    except TypeError:
        print("Error during private constructor from parent class")

# Generated at 2022-06-24 12:48:44.708664
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """

    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:52.545394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie.suitable(url)
    assert ie.extract(url)

    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert ie.suitable(url)

# Generated at 2022-06-24 12:49:03.340362
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0]['url'] == \
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == \
        'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == \
        'CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:49:05.982516
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:49:10.166547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        url_or_none,
    )
    ie = InfoExtractor()
    ie.add_info_extractor(KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:14.333527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Create instance of KonserthusetPlayIE with test url """
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(KonserthusetPlayIE.suitable(test_url))

# Generated at 2022-06-24 12:49:17.270214
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay


# Generated at 2022-06-24 12:49:22.184447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert inst.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


# Generated at 2022-06-24 12:49:23.505614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test != None


# Generated at 2022-06-24 12:49:33.212625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset = KonserthusetPlayIE(url)

    assert konserthuset._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:33.896054
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:49:41.492663
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    inst_url = KonserthusetPlayIE._VALID_URL.__repr__()
    inst_id = KonserthusetPlayIE._VALID_URL.groupindex["id"].__repr__()

    KonsertHuset = KonserthusetPlayIE("konserthusetplay")

    assert inst_url in KonsertHuset.__repr__()
    assert "id" in inst_id
    assert inst_url in KonsertHuset._TESTS[0].__repr__()
    assert "md5" in KonsertHuset._TESTS[0].__repr__()
    assert Konsert

# Generated at 2022-06-24 12:49:47.862111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    args = {
        '_match_id': 'TESTINGURL',
        'url': 'TESTINGURL',
        'display_id': 'TESTINGID',
    }
    assert KonserthusetPlayIE(**args)._match_id(**args) == 'TESTINGID'


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:50.362812
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of class KonserthusetPlayIE,
    # which should not raise an exception
    parser = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:51.564257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_obj = KonserthusetPlayIE()
    assert test_obj is not None
    assert test_obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:54.953939
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
# End

# Generated at 2022-06-24 12:49:56.592569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == KonserthusetPlayIE

# Generated at 2022-06-24 12:50:06.650482
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:08.887328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

if __name__ == '__main__':
    test_KonserthusetPlayIE().test()

# Generated at 2022-06-24 12:50:10.373700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-24 12:50:11.487501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #TODO
    pass

# Generated at 2022-06-24 12:50:13.721633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE.test()

# Generated at 2022-06-24 12:50:16.332251
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'konserthusetplay')

# Generated at 2022-06-24 12:50:22.319869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE._TESTS
    assert KonserthusetPlayIE._download_json
    assert KonserthusetPlayIE._match_id
    assert KonserthusetPlayIE._real_extract
    assert KonserthusetPlayIE._search_regex
    assert KonserthusetPlayIE._sort_formats
    assert KonserthusetPlayIE._TYPE

# Generated at 2022-06-24 12:50:25.595331
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as e:
        raise Exception('Failed to initialize KonserthusetPlayIE object: ' + str(e))

# Generated at 2022-06-24 12:50:36.003801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE(None)
    assert IE.IE_NAME.startswith('KonserthusetPlay')
    assert IE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:37.580099
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay')

# Generated at 2022-06-24 12:50:46.309349
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_ie = KonserthusetPlayIE()
    _VALID_URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:47.586677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:51.194502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:50:52.926100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit = KonserthusetPlayIE()
    print(unit)

# Generated at 2022-06-24 12:50:57.274780
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:50:58.829643
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == ie



# Generated at 2022-06-24 12:51:06.054606
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie is not None
    assert hasattr(konserthusetplay_ie, '_ download_json')
    assert hasattr(konserthusetplay_ie, '_search_regex')
    assert hasattr(konserthusetplay_ie, '_download_webpage')
    assert hasattr(konserthusetplay_ie, '_match_id')
    assert hasattr(konserthusetplay_ie, '_real_extract')
    assert hasattr(konserthusetplay_ie, '_sort_formats')

# Generated at 2022-06-24 12:51:08.545637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable(ie._VALID_URL)
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:51:20.375077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE(url)
    url = 'http://www.konserthusetplay.se/?m=LQDdydb9qMN_gAqnBwH2Bw'
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:51:23.018846
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        k = KonserthusetPlayIE()
    except Exception as e:
        assert False, e
    assert k != None
    assert True


# Generated at 2022-06-24 12:51:26.342111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:51:31.472411
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    info = ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert info["id"] == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:51:35.832403
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    konserthuset = KonserthusetPlayIE()
    assert konserthuset.suitable(url)

# Generated at 2022-06-24 12:51:37.240416
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == ie.__class__

# Generated at 2022-06-24 12:51:40.747848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'md5:e3fd47bf44e864bd23c08e487abe1967')
    ie.test()

# Generated at 2022-06-24 12:51:45.130090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = ie(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(inst._match_id(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))
    print(inst._real_extract(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:46.784388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract()

# Generated at 2022-06-24 12:51:52.818646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert type(ie) == KonserthusetPlayIE
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:56.751010
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:52:07.733008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create Instance of KonserthusetPlayIE class
    ie = KonserthusetPlayIE()
    # Format URL string
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Extract video ID from URL
    video_id = ie._match_id(url)
    # Download webpage
    webpage = ie._download_webpage(url, video_id)
    # Extract 'e' parameter
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')
    # Determine URL of rest API

# Generated at 2022-06-24 12:52:10.897430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:17.733666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("\nTest KonserthusetPlayIE:")


# Generated at 2022-06-24 12:52:28.614793
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._VALID_URL = r'.*'
    # Test with wrong URL
    ie.url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    assert ie._real_extract(ie.url) is None, 'This URL is not a URL that could be matched in KonserthusetPlayIE'
    # Test with correct URL
    ie.url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Testing the return value of _real_extract(...) in a very unrealistic way, since it is randomly generated
    assert ie._real_extract(ie.url) != None
    assert ie._real_extract(ie.url)['id']

# Generated at 2022-06-24 12:52:29.822298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:33.980029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key() == 'rspoplay'

# Generated at 2022-06-24 12:52:43.517481
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:47.125949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    k_play_ie = KonserthusetPlayIE()
    assert k_play_ie != None


# Generated at 2022-06-24 12:52:50.594224
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()._extract_url("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:54.162776
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test KonserthusetPlayIE.constructor
    try:
        KonserthusetPlayIE()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-24 12:52:57.270474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj_KonserthusetPlayIE = KonserthusetPlayIE()
    assert obj_KonserthusetPlayIE.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-24 12:52:59.374135
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test that KonserthusetPlayIE() actually works """
    info_extractor = KonserthusetPlayIE()
    assert info_extractor

# Generated at 2022-06-24 12:53:00.599936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None

# Generated at 2022-06-24 12:53:04.060467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:53:12.679615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&b=s')
    assert not ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&b=s&a=d')

# Generated at 2022-06-24 12:53:17.073665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE.KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert video.name() == "KonserthusetPlayIE"

# Generated at 2022-06-24 12:53:18.981769
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	pIE= KonserthusetPlayIE()
	assert(pIE != None)
		

# Generated at 2022-06-24 12:53:27.042125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:28.034784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:31.003877
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = globals()['KonserthusetPlayIE']
    print(class_)
    a = class_()
    print(a)

# Generated at 2022-06-24 12:53:39.987471
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)' 

# Generated at 2022-06-24 12:53:42.246960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    print(IE)

# Generated at 2022-06-24 12:53:42.864326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:44.651900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:47.862899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests that the constructor of the class KonserthusetPlayIE returns a valid
    # object when given a valid url
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key()) is not None

# Generated at 2022-06-24 12:53:48.390605
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:50.215763
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&t=117.82")
    return True




# Generated at 2022-06-24 12:53:56.504647
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Given: The url of a video
    url_video = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # When: We create a KonserthusetPlayIE object with the previous url
    kp_object = KonserthusetPlayIE(url_video)


# Generated at 2022-06-24 12:54:02.499326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:04.473030
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor = KonserthusetPlayIE()


# Generated at 2022-06-24 12:54:07.236850
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:13.087160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.(?:se|com)/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:54:14.173946
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:19.801254
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance.SUFFIX = 'not-exist'
    assert (instance.SUFFIX == 'not-exist')
    instance.SUFFIX = '_real_extract'
    assert (instance.SUFFIX == '_real_extract')


test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:22.943982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:54:25.443738
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Creating instance of KonserthusetPlayIE...")
    KonserthusetPlayIE()
    print("Done.")


# Generated at 2022-06-24 12:54:31.239611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of class KonserthusetPlayIE
    test_ie = KonserthusetPlayIE()
    assert test_ie is not None
    # Check if it has the attribute of '_VALID_URL'
    assert test_ie._VALID_URL is not None
    # Check if it has the attribute of '_TESTS'
    assert test_ie._TESTS is not None

# Generated at 2022-06-24 12:54:36.391078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testInstance = KonserthusetPlayIE()
    # Test that the expected regex was created
    assert testInstance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Test for method _real_extract

# Generated at 2022-06-24 12:54:39.119669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:54:40.547128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:42.651936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.ie_key() == 'KonserthusetPlay'
    assert k.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:54:51.780914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from konserthusetplay import KonserthusetPlayIE # import class
    k = KonserthusetPlayIE()
    assert(k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:55:01.217343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:13.428234
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
   

# Generated at 2022-06-24 12:55:14.382841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:55:16.325736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instance should not be None
    assert KonserthusetPlayIE(None) is not None


# Generated at 2022-06-24 12:55:19.279373
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:29.416204
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .youtube import YoutubeIE

    # Testing normal input
    assert issubclass(KonserthusetPlayIE, InfoExtractor) == True
    assert issubclass(KonserthusetPlayIE, YoutubeIE) == False
    assert KonserthusetPlayIE._VALID_URL.find("www.konserthusetplay.se") > -1
    assert KonserthusetPlayIE._TESTS[0]["url"] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE._TESTS[0]["md5"] == "e3fd47bf44e864bd23c08e487abe1967"

# Generated at 2022-06-24 12:55:33.730839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # testing for correct initialization of class KonserthusetPlayIE
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE(url).url == url

# Generated at 2022-06-24 12:55:34.747859
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:36.178497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE([])
    assert ie is not None

# Generated at 2022-06-24 12:55:39.618586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('rspoplay.se/')

# Generated at 2022-06-24 12:55:46.434239
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test_konserthusetplay_URL = https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    test_konserthusetplay_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    video_id = r'CKDDnlCY-dhWAAqiMERd-A'
    assert(video_id == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:53.274149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    object_KonserthusetPlayIE = KonserthusetPlayIE()
    result_url = object_KonserthusetPlayIE._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert result_url['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result_url['title'] == 'Orkesterns instrument: Valthornen'
    assert result_url['duration'] == 398.76
    assert result_url['thumbnail'] == 're:^https?://.*$'

# Generated at 2022-06-24 12:55:54.297468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:55.903561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    entry = KonserthusetPlayIE({})
    print (entry)

# Generated at 2022-06-24 12:56:05.948902
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    assert ie.IE_DESC == 'konserthusetplay'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.can_handle_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.can_handle_url('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.can_handle_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:07.925050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = KonserthusetPlayIE()
	assert url is not None

# Generated at 2022-06-24 12:56:08.590635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:56:12.886716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:56:23.213829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.extract('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Test if the constructor is valid
    assert KonserthusetPlayIE._VALID_URL.search('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Test if the constructor is working on a non-existing url
    assert KonserthusetPlayIE._VALID_URL.search('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAq') is None

# Generated at 2022-06-24 12:56:24.616057
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.match_url('')

# Generated at 2022-06-24 12:56:36.320785
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_name = ie.ie_key()
    ie_config = ie.extract({'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'})

    assert ie_name == 'KonserthusetPlay'
    assert ie_config['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie_config['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie_config['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:56:38.304938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    o = KonserthusetPlayIE()
    assert KonserthusetPlayIE._VALID_URL == o._VALID_URL
    assert KonserthusetPlayIE._TESTS == o._TESTS

# Generated at 2022-06-24 12:56:39.240078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:56:40.036076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:47.429645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test with a valid URL
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    class_instance = KonserthusetPlayIE(url)
    assert class_instance.url == url

    # Test with an invalid URL
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY"
    class_instance = KonserthusetPlayIE(url)
    assert class_instance.url == None

# Generated at 2022-06-24 12:56:57.894372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:56:59.979402
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw').extract()

# Generated at 2022-06-24 12:57:04.335857
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download(ie._VALID_URL)
    ie.download('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:57:05.833255
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == KonserthusetPlayIE

# Generated at 2022-06-24 12:57:16.022612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that the constructor of class KonserthusetPlayIE works with
    # an url
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)

    # Test that it is an instance of InfoExtractor and has the correct id
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'KonserthusetPlay'

    # Test that it has the correct video id
    video_id = ie.extract_id(url)
    assert video_id == 'CKDDnlCY-dhWAAqiMERd-A'

    # Test whether it is a valid url
    match = ie.valid_url(url)
    assert match == video_id

   

# Generated at 2022-06-24 12:57:18.833474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        raise Exception('class KonserthusetPlayIE failed constructor unit test.')

# Generated at 2022-06-24 12:57:21.177925
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:57:22.182895
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:23.676118
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:57:25.531089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert isinstance(konserthusetplay_ie, InfoExtractor)

# Generated at 2022-06-24 12:57:28.236460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    IE = KonserthusetPlayIE(url)
    assert IE.getURL() == url

# Generated at 2022-06-24 12:57:38.450299
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_c = KonserthusetPlayIE()
    assert(test_c.ie_key() == 'KonserthusetPlay')
    assert(test_c.ie_name() == 'KonserthusetPlay')
    assert(test_c.ie_description() == 'Videos on konserthusetplay.se and rspoplay.se')
    assert(test_c.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'KonserthusetPlay'))
    assert(test_c.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', 'KonserthusetPlay'))