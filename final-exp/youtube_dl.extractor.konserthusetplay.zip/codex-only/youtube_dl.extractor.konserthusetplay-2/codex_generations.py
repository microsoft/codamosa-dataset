

# Generated at 2022-06-24 12:47:36.159865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:47:38.088109
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        return False
    return True

# Generated at 2022-06-24 12:47:40.779058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    parser = KonserthusetPlayIE()
    assert(parser is not None)
    print("Called constructor of class KonserthusetPlayIE")


# Generated at 2022-06-24 12:47:44.316425
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create object video
    video = KonserthusetPlayIE()
    # Print object created
    print(video)
    # Print object name
    print(video.__class__.__name__)

# Generated at 2022-06-24 12:47:48.780131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    try:
        KonserthusetPlayIE(url, None, None)
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-24 12:47:49.446414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:50.798020
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() # will work when constructor is implemented

# Generated at 2022-06-24 12:47:58.747750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test construction of KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    # Test result of calling _real_extract method
    result = ie._real_extract(ie._VALID_URL)
    assert 'id' in result
    assert 'formats' in result
    assert len(result['formats']) > 0
    assert 'url' in result['formats'][0]
    assert 'format_id' in result['formats'][0]
    assert 'rtmp' in result['formats'][0]['format_id']

# Generated at 2022-06-24 12:48:00.392126
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:02.711804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:48:03.264045
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-24 12:48:05.835363
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('dummy url')
    # Check that constructor doesn't crash
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:48:15.606886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    k._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A')
    k._match_id('https://www.konserthusetplay.se/?m=dX9Ut7pvZ-aLJcjKzf_EKw')

# Generated at 2022-06-24 12:48:25.098969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert kp._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert kp._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:48:26.924957
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:48:29.156166
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:30.602545
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:31.956314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:48:34.423466
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-24 12:48:43.911279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # dummy URL
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"

    # instantiate the class
    ie = KonserthusetPlayIE()

    # assert that the URL matches the video ID
    assert(ie._match_id(url) == "elWuEH34SMKvaO4wO_cHBw")

    # assert that the URL matches the video ID
    assert(ie._match_id(url) == "elWuEH34SMKvaO4wO_cHBw")

    # assert that the URL does not match the video ID
    assert(ie._match_id("http://www.konserthusetplay.se/?m=thisIsNotAVideoID") == None)

# Generated at 2022-06-24 12:48:48.930401
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_obj = KonserthusetPlayIE(None)
    assert test_obj._downloader is None
    assert test_obj._working_dir is None
    assert test_obj.smuggle_url is None
    assert test_obj._progress_hooks == [{}]


# Generated at 2022-06-24 12:48:56.650451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.get_url() == 'https://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert ie.get_name() == 'KonserthusetPlay'
    assert ie.get_video_id() == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:48:58.941042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import web_pdb; web_pdb.set_trace()
    pass
# EOF

# Generated at 2022-06-24 12:49:00.745500
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:49:02.478032
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert(inst is not None)

# Generated at 2022-06-24 12:49:12.528146
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with a URL with correct format
    url1 = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Test with an URL with correct format, but not correct location
    url2 = 'https://www.konserthusetplay.se/?m=CKDDnlCYdhWAAqiMERd-A'

    # Test with a URL without correct format
    url3 = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd'

    ext = KonserthusetPlayIE()

    # Test with a URL: url1
    m1 = ext._match_id(url1)

# Generated at 2022-06-24 12:49:13.582689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:49:14.831321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    init = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:19.514938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Dummy url and class instance
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(KonserthusetPlayIE.suitable(url))

# Generated at 2022-06-24 12:49:25.146709
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('http://konserthusetplay.se/')
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:49:27.537439
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # self.assertIsInstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:29.611018
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie.extract(ie._TESTS[0]['url']))

# Generated at 2022-06-24 12:49:30.875626
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    loader = KonserthusetPlayIE()
    print(loader)

# Generated at 2022-06-24 12:49:32.233041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE("https://konserthusetplay.se/")

# Generated at 2022-06-24 12:49:38.443467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL==r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:40.475268
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None
    return obj

# Unit test

# Generated at 2022-06-24 12:49:41.499255
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:42.753926
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:49:43.860192
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-24 12:49:48.365285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # ADD YOUR VALID_URL HERE
    URL = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie._real_extract(URL)

# Generated at 2022-06-24 12:49:52.223464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert isinstance(inst, InfoExtractor)
    assert inst.IE_NAME == 'KonserthusetPlay'
    assert inst.IE_DESC == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:56.591634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global KonserthusetPlayIE
    from utils import unit_test
    unit_test(KonserthusetPlayIE, [('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', {})] )

# Generated at 2022-06-24 12:49:59.048436
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    _, ie = KonserthusetPlayIE._extract_info(KonserthusetPlayIE(), test_url)
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:50:01.289862
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert ie._VALID_URL ==  KonserthusetPlayIE._VALID_URL, "Expected " + KonserthusetPlayIE._VALID_URL +" got "+ ie._VALID_URL +"!"

# Generated at 2022-06-24 12:50:09.558779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:16.181810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test for class constructor."""
    url = ("http://www.konserthusetplay.se/?m=8WK41J5v-A5WAA2fcAe8Wg")
    konserthusetplayie = KonserthusetPlayIE.new(url)
    konserthusetplayie._real_initialize()

# Generated at 2022-06-24 12:50:17.286676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, {})

# Generated at 2022-06-24 12:50:18.930883
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # assert KonserthusetPlayIE()._TESTS['url'] is not None
    assert KonserthusetPlayIE()._TESTS['url'] is not None

# Generated at 2022-06-24 12:50:23.959454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play = KonserthusetPlayIE()

    # Unit test for function _real_extract
    def test_real_extract():
        # with a given url
        url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
        konserthuset_play._real_extract(url)

# Generated at 2022-06-24 12:50:29.411914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for VideoDetail class"""
    ks = KonserthusetPlayIE({})
    assert ks._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:40.494648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for constructor of class KonserthusetPlayIE
    a = KonserthusetPlayIE('http://www.konserthusetplay.se/')
    assert a._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert a._TESTS[0]['url'] =='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert a._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:50:49.108190
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert obj['title'] == 'Orkesterns instrument: Valthornen'
    assert obj['ext'] == 'mp4'
    assert obj['duration'] == 398.76
    assert obj['thumbnail'] == 're:^https?://.*$'
    assert obj['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'


# Generated at 2022-06-24 12:50:50.378564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('<class KonserthusetPlayIE>')

# Generated at 2022-06-24 12:51:02.311757
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:13.358356
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('www.konserthusetplay.se/');
    assert ie.url_re == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:51:18.719107
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:21.353994
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test case to construct an instance of class KonserthusetPlayIE.
    """
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:22.402773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:23.642366
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None, 'constructor of class KonserthusetPlayIE not working'

# Generated at 2022-06-24 12:51:28.746407
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthuset_play import KonserthusetPlayIE
    ie = KonserthusetPlayIE(url="http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A",
                            extractor_key='KonserthusetPlay', ext=None, downloader=None,
                            download_mode=None, force_generic_extractor=False)
    assert ie != None

# Generated at 2022-06-24 12:51:39.955269
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert obj._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert obj._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert obj._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967"

# Generated at 2022-06-24 12:51:41.054915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:46.146203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()

    assert(e._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(e._TESTS)


# Generated at 2022-06-24 12:51:54.427755
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # create an instance of the class with the test cases
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie.title == 'Orkesterns instrument: Valthornen'
    assert ie.description == u'md5:f10e1f0030202020396a4d712d2fa827'
    assert ie.thumbnail == 're:^https?://.*$'
    assert ie.duration == 398.76

# Generated at 2022-06-24 12:51:56.573111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    print(a)
    return

# Unit test

# Generated at 2022-06-24 12:52:00.801643
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_KonserthusetPlayIE = KonserthusetPlayIE()
    ie_KonserthusetPlayIE._real_extract('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:07.281764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:14.421101
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from re import search
    from urlparse import urlparse
    from urllib import unquote
    ie = KonserthusetPlayIE(None)
    assert ie.get_content_url("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == "http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.get_content_url("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "other.se") == "http://www.other.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:52:18.273570
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-24 12:52:25.654773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.(?:se|com)/\?.*\bm=(?P<id>[^&]+)'

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:35.319376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

    e = ie._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')


# Generated at 2022-06-24 12:52:36.759603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL

# Generated at 2022-06-24 12:52:37.747543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:39.499125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        raise AssertionError


# Generated at 2022-06-24 12:52:43.020784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if __name__ == '__main__':
        url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
        ie = KonserthusetPlayIE()
        print(ie._real_extract(url))

# Generated at 2022-06-24 12:52:47.470376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:52:52.514492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE.suitable(url)
    yt = KonserthusetPlayIE(url)
    assert yt._VALID_URL == url

# Generated at 2022-06-24 12:53:02.244782
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.URL == url
    assert ie.name == 'KonserthusetPlay'
    assert ie.id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:05.462727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:06.423270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    print(obj.name)

# Generated at 2022-06-24 12:53:07.492699
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-24 12:53:09.550906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:14.217143
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:53:22.121682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(
        ie.ie_key(),
        ie.host(),
        ie.url_result(),
        ie.playlist_result(),
        ie.suitable(),
        ie.extract(),
        ie.add_ie(),
    )
    ie = KonserthusetPlayIE(
        ie.ie_key(),
        ie.host(),
        ie.url_result(),
        ie.playlist_result(),
        ie.suitable(),
        ie.extract(),
        ie.add_ie(),
    )
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:26.987097
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(test_url)
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:53:35.326132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_extract_m3u8_formats')
    assert hasattr(ie, '_sort_formats')

# Generated at 2022-06-24 12:53:42.193625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:52.064635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE()
	assert ie.IE_NAME == 'konserthusetplay:play'
	assert ie.IE_DESC == 'KonserthusetPlay'
	assert ie._VALID_URL == ie.VALID_URL
	assert ie.IE_VERSION == '0.1'
	assert hasattr(ie, 'SUCCESS_CODE')
	assert ie.SUCCESS_CODE == 0
	assert hasattr(ie, 'FFMPEG_DOWNLOAD_URL')
	assert ie.FFMPEG_DOWNLOAD_URL == 'http://ffmpeg.zeranoe.com/builds/win32/static/ffmpeg-latest-win32-static.zip'
	assert hasattr(ie, 'FFMPEG_DOWNLOAD_MD5_HASH')
	assert ie.FF

# Generated at 2022-06-24 12:53:56.551514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:57.732586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:09.103194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:10.885766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.domain == 'www.konserthusetplay.se'

# Generated at 2022-06-24 12:54:12.002446
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:14.174159
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-24 12:54:24.393714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    # test for matching regex
    assert extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # test for setting _TESTS
    assert isinstance(extractor._TESTS, list)
    # test for checking ID
    assert extractor._match_id(r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    # test for checking _download_webpage

# Generated at 2022-06-24 12:54:25.079692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:54:27.964611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:54:30.625661
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:32.494029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    rspoplay = KonserthusetPlayIE()
    assert rspoplay is not None



# Generated at 2022-06-24 12:54:38.443127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiating a KonserthusetPlayIE object
    ie = KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # Testing its methods
    assert ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:54:42.263106
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # A string, representing the url for the video
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # An object of class KonserthusetPlayIE
    ie = KonserthusetPlayIE(url)
    # Tested method, to ensure that the id of the video gets set properly
    assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:50.191665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    str_test = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:59.950145
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor generates an instance of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    # _VALID_URL regex matches an instance of class KonserthusetPlayIE
    # kind of useless test, but makes sure that
    # the regex matches an instance of class KonserthusetPlayIE
    match = ie._VALID_URL = re.match(KonserthusetPlayIE._VALID_URL,
                                     "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    # The remainig asserts tests that we get the expected results from
    # the extracted id from the URL
    assert match
    assert match.group('id') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:04.494848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie.get_domain() == 'konserthusetplay.se'
    assert konserthusetplay_ie.get_real_ext() == 'mp4'
    assert konserthusetplay_ie.get_real_ext() == 'mp4'
    assert konserthusetplay_ie.get_real_ext() == 'mp4'

# Generated at 2022-06-24 12:55:16.521153
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    # Strings and integers
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:55:18.271008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Test KonserthusetPlayIE()")
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:22.261410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-24 12:55:26.555165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetplayIE = KonserthusetPlayIE(url)
    konserthusetplayIE._real_extract(konserthusetplayIE)

# Generated at 2022-06-24 12:55:30.556463
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()
    assert result._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:34.065444
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that a KonserthusetPlayIE is created with a KonserthusetPlayIE object
    assert KonserthusetPlayIE(KonserthusetPlayIE)


# Generated at 2022-06-24 12:55:40.328804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:49.154615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    print('Starting unit test for class KonserthusetPlayIE')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    print('Passed ID match test')

    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:55:49.905699
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:51.433237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:56:02.994569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case = {
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'expected_id': 'CKDDnlCY-dhWAAqiMERd-A',
        'expected_ext': 'mp4',
        'expected_title': 'Orkesterns instrument: Valthornen',
        'expected_description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'expected_thumbnail': 're:^https?://.*$',
        'expected_duration': 398.76
    }

    ie = KonserthusetPlayIE()

    actual_result = ie._real_extract(test_case['url'])

# Generated at 2022-06-24 12:56:05.696140
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'

# Generated at 2022-06-24 12:56:14.563171
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage('', '')
    ie._download_json('', '')
    ie._search_regex('', '', '')
    ie._extract_m3u8_formats(
        '', '', 'mp4', entry_protocol='m3u8_native',
        m3u8_id='hls', fatal=False)
    ie._sort_formats([])

    # no test for _real_extract because this function relies on _download_json
    # which has a random response and is not deterministic

# Generated at 2022-06-24 12:56:17.233140
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:56:21.511217
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()
    kpIE.extract(url="http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:56:26.235289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	ie = KonserthusetPlayIE()
	assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'
	assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:38.679910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    id = ie._match_id(url)
    print(id)
    webpage = ie._download_webpage(url, id)

    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')
    print(e)

# Generated at 2022-06-24 12:56:42.308625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == "https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:56:48.957576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test for instantiation
    url = 'http://rspoplay.se/index.php?m=ckddnlcY-dhwaaQiMErd-a'
    kpi = KonserthusetPlayIE(url)
    assert(kpi.url == url)
    assert(kpi.valid_url == True)
    assert(kpi.video_id == 'CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:56:50.153821
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:52.423601
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global options
    options = {
        '--username': 'user',
        '--password': '1234'
    }
    ie = KonserthusetPlayIE()

    assert(ie != None)
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:54.954216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    testUrl = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    download = ie.download_webpage(testUrl, 'CKDDnlCY-dhWAAqiMERd-A')
    assert(download is not None)

# Generated at 2022-06-24 12:56:56.825618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE.__name__ == "KonserthusetPlayIE")

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:04.573349
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:08.705042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Basic test of constructor of class KonserthusetPlayIE
    '''
    konserthusetplay_ie = KonserthusetPlayIE()
    assert(konserthusetplay_ie != None)

# Generated at 2022-06-24 12:57:09.858632
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:57:14.788565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&jino=&lop=') == True

# Generated at 2022-06-24 12:57:17.699740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:57:18.736398
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:20.048925
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:22.545134
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        e = KonserthusetPlayIE
        assert e
    except:
        return -1
    return 0



# Generated at 2022-06-24 12:57:24.326852
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE == KonserthusetPlayIE)


# Generated at 2022-06-24 12:57:25.633506
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:57:29.158488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Basic test for KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:57:31.022823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testee = KonserthusetPlayIE()
    assert isinstance(testee, InfoExtractor)

# Generated at 2022-06-24 12:57:39.120866
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')