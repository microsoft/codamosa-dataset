

# Generated at 2022-06-24 12:47:28.643244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:47:31.641119
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Make sure the constructor got all neccessary attributes
    ie = KonserthusetPlayIE()
    ie.to_screen(ie._VALID_URL)

# Generated at 2022-06-24 12:47:43.142161
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance._download_webpage = lambda url: url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A' # 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    webpage = instance._download_webpage(url)
    e = instance._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')
    instance._download_json = lambda url: url

# Generated at 2022-06-24 12:47:44.640514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('testing KonserthusetPlayIE class')
    ie = KonserthusetPlayIE()
    print(ie)



# Generated at 2022-06-24 12:47:53.138396
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    # Test if valid url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    res = kp._is_valid_url(url)

# Generated at 2022-06-24 12:48:00.708748
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    # check _VALID_URL
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # check _TESTS
    assert instance._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert instance._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:48:11.249665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test constructor of class KonserthusetPlayIE
    """
    # Test url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    # Test instantiation
    ie = KonserthusetPlayIE()

    # Test id
    video_id = ie._match_id(url)
    assert(video_id == "CKDDnlCY-dhWAAqiMERd-A")

    # Test m3u8
    #m3u8_url = ie._get_m3u8_url(url)
    #assert(m3u8_url == 'http://media.konserthuset.se/hls/CKDDnlCY-dhWAAqiMERd-A.m3u

# Generated at 2022-06-24 12:48:19.084788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert IE.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert IE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not IE.suitable('https://www.google.com/')
    assert not IE.suitable('')
    assert not IE.suitable(False)
    assert not IE.suitable(True)
    assert not IE.suitable(None)
    assert not IE.suitable(0)


# Generated at 2022-06-24 12:48:20.491759
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor should not throw exception
    KonserthusetPlayIE

# Generated at 2022-06-24 12:48:26.386527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:29.383749
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("test_input")

# Generated at 2022-06-24 12:48:40.591573
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test case 1
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    webpage, md5 = ie.download_webpage(url, video_id), 'e3fd47bf44e864bd23c08e487abe1967'
    e = ie.search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

# Generated at 2022-06-24 12:48:42.436919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test construction of KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:48:44.499470
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:49.151635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_KonserthusetPlayIE import _test_KonserthusetPlayIE
    _test_KonserthusetPlayIE.__code__ = KonserthusetPlayIE.__code__
    _test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:58.095323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    # Run test to check if there is a proper object created from the given url
    # and the url is valid or not.
    # The url is valid if the object of this class is created
    konserthusetplay_ie = InfoExtractor.ie_key_map['KonserthusetPlay'](
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert isinstance(konserthusetplay_ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:00.312796
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:08.526779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test import get_testcases
    testcases = get_testcases(KonserthusetPlayIE, include_only=lambda test_id: test_id != 'test_KonserthusetPlayIE')

# Generated at 2022-06-24 12:49:09.930975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print(KonserthusetPlayIE)



# Generated at 2022-06-24 12:49:13.511764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_object = KonserthusetPlayIE();
    assert(ie_object._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:49:17.002922
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_konserthuset_play = KonserthusetPlayIE()
    #assert isinstance(ie_konserthuset_play, InfoExtractor)

# Generated at 2022-06-24 12:49:17.966876
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:49:20.850398
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:49:28.630921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test
    ie = KonserthusetPlayIE() 
    assert(ie.IE_NAME == 'konserthusetplay')
    # test _VALID_URL
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    # test _TITLE_RE
    assert(ie._TITLE_RE == None)
    # test _TITLE_RE
    assert(ie._TITLE_RE == None)

# Generated at 2022-06-24 12:49:35.747996
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create instance of KonserthusetPlayIE
    cls = KonserthusetPlayIE()
    assert cls.ie_key() == 'konserthusetplay'

    # Test for extract method
    # Create instance of YoutubeDL
    ydl = YoutubeDL()

    # Create instance of InfoExtractor
    ie = InfoExtractor(ydl)
    assert ie.ie_key() == 'YoutubeDL'

    # Call method with empty argument
    ie.extract(None)
    ie.extract('')

    # Call extract method with valid url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    info = ie.extract(url)

# Generated at 2022-06-24 12:49:41.306685
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None
    assert KonserthusetPlayIE._download_json is not None
    assert KonserthusetPlayIE._extract_m3u8_formats is not None
    assert KonserthusetPlayIE._match_id is not None
    assert KonserthusetPlayIE._real_extract is not None
    assert KonserthusetPlayIE._search_regex is not None
    assert KonserthusetPlayIE._sort_formats is not None

# Generated at 2022-06-24 12:49:43.860001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE("md5:e3fd47bf44e864bd23c08e487abe1967")
    assert inst

# Generated at 2022-06-24 12:49:47.567998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:49:48.751837
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:54.322212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.get_url(ie.get_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')) == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:49:58.971481
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    if ie.extractor == None:
        assert False, 'Problem initializing KonserthusetPlayIE'
    assert ie.extractor._VALID_URL == ie._VALID_URL, 'Test failed'

# Generated at 2022-06-24 12:50:08.096708
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'konserthusetplay.se'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.__name__ == 'KonserthusetPlayIE'
    assert ie.__doc__ == 'konserthusetplay.se'
    assert ie.BUILD_PYTHON_URL == 'https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/konserthusetplay.py'

# Generated at 2022-06-24 12:50:20.465067
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test for constructor of class KonserthusetPlayIE
    # will extract info from http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    konserthusetPlay_ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:24.226646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthuset import test_konserthuset
    konserthuset = KonserthusetPlayIE()
    test_konserthuset(konserthuset)


# Generated at 2022-06-24 12:50:28.874752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

test_KonserthusetPlayIE()


# Generated at 2022-06-24 12:50:38.132878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:39.059575
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:50:40.598919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie


# Generated at 2022-06-24 12:50:43.517417
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	"""
	Test for constructor of class KonserthusetPlayIE
	"""
	actual = KonserthusetPlayIE(InfoExtractor())
	assert actual is not None


# Generated at 2022-06-24 12:50:44.909021
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    return kp

# Generated at 2022-06-24 12:50:53.042800
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:54.541271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:50:58.372834
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie is not None)

# Generated at 2022-06-24 12:51:00.200105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:51:02.560890
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	Obj = KonserthusetPlayIE()
	assert Obj.ie_key() == 'KonserthusetPlay', "Check Object creation of KonserthusetPlayIE"

# Generated at 2022-06-24 12:51:09.152354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit tests for class KonserthusetPlayIE, using the constructor

    Attributes:
        - ie (InfoExtractor)
        - url (str)
        - video_id (str)
        - invalid_urls (list)
    """

    TEST_URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    TEST_VIDEO_ID = 'CKDDnlCY-dhWAAqiMERd-A'
    INVALID_URLS = [
        'http://www.konserthusetplay.se/',
    ]

    # Tests for non-existing URLs
    for url in INVALID_URLS:
        ie = KonserthusetPlayIE(url)

        assert ie.url is None
       

# Generated at 2022-06-24 12:51:21.051379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  ie = KonserthusetPlayIE()
  print("Unit test for class KonserthusetPlayIE")
  print("\tID: %s" % ie.IE_NAME)
  print("\tURL: %s" % ie.VALID_URL)
  print("\t_VALID_URL: %s" % ie._VALID_URL)
  print("\tIE_NAME: %s" % ie.IE_NAME)
  print("\t_TESTS: %s" % ie._TESTS)
  print("\tIE_DESC: %s" % ie.IE_DESC)
  print("\twebpage_url: %s" % ie.webpage_url)
  print("\t_download_webpage: %s" % ie._download_webpage)

# Generated at 2022-06-24 12:51:22.561237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Old test method called, unit test of the constructor is needed")

# Generated at 2022-06-24 12:51:24.220607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_konserthusetPlayIE = KonserthusetPlayIE()
    assert test_konserthusetPlayIE is not None
    assert isinstance(test_konserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:51:25.898716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        from .test_KonserthusetPlayIE import *
    except ImportError:
        pass


# Generated at 2022-06-24 12:51:32.353561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:36.088447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == "konserthusetplay"
    assert ie.IE_DESC == 'Konserthusetplay.se'

# Generated at 2022-06-24 12:51:37.920659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('url')
    assert ie is not None


# Generated at 2022-06-24 12:51:48.388470
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test case 1
    testURL = u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    actualInfo = KonserthusetPlayIE()._real_extract(testURL)


# Generated at 2022-06-24 12:51:53.889726
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# test url https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)

# Generated at 2022-06-24 12:51:59.348980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# instantiate class
	KonserthusetPlay = KonserthusetPlayIE()

	# test regex, because it is private the test is a valid url
	valid_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
	assert re.match(KonserthusetPlay._VALID_URL, valid_url) != None

	# get id from url
	id = re.findall(KonserthusetPlay._VALID_URL, valid_url)[0]
	assert id != None

# Generated at 2022-06-24 12:52:10.053176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=8XAoA6vCZbxoZ_osz8EESg'
    metadata = {
        'id': '8XAoA6vCZbxoZ_osz8EESg',
        'title': 'Orkesterns instrument: Kontrabas',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 399.0,
        'subtitles': {},
    }

# Generated at 2022-06-24 12:52:14.762493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_DESC == 'konserthusetplay.se'
    assert ie.__name__ == 'konserthusetplay:KonserthusetPlayIE'

# Generated at 2022-06-24 12:52:16.721419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'Konserthuset Play'

# Generated at 2022-06-24 12:52:23.948997
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_name() == 'KonserthusetPlay'
    assert obj.http_headers()['User-Agent'] == 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36'
    assert obj.working

# Generated at 2022-06-24 12:52:25.013412
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:28.997234
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    rspoplay_extractor = KonserthusetPlayIE("rspoplay")
    assert rspoplay_extractor._VALID_URL == KonserthusetPlayIE._VALID_URL


if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:52:31.238240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-24 12:52:39.025591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of KonserthusetPlayIE
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthusetplay._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplay._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:52:40.885972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == 'play'

# Generated at 2022-06-24 12:52:44.211715
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie is not None

# Generated at 2022-06-24 12:52:48.967675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kons = KonserthusetPlayIE(None)
    assert kons._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:59.152191
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import re
    m = re.match(KonserthusetPlayIE._VALID_URL, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert m

    m = re.match(KonserthusetPlayIE._VALID_URL, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&foo=bar')
    assert m

    m = re.match(KonserthusetPlayIE._VALID_URL, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&file=123&foo=bar')
    assert m

# Generated at 2022-06-24 12:53:01.210008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlay", "https://www.konserthusetplay.se/")
    assert ie is not None

# Generated at 2022-06-24 12:53:01.804897
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:03.285690
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Only tests if the class is constructed w/o error
    ie = KonserthusetPlayIE()


# Generated at 2022-06-24 12:53:04.130447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:53:05.028292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:09.404319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:53:20.640761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Example of url of website
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    expect = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    
    # Test with real url
    k = KonserthusetPlayIE()
    info = k._real_extract(url)
    assert info == expect

# Generated at 2022-06-24 12:53:26.460746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.initialize_supported == True)
    assert(ie.description == "Music & Performances by the Royal Stockholm Philharmonic Orchestra")
    assert(ie.extractor == "KonserthusetPlay")
    assert(ie.supported_domains == ['rspoplay.se', 'konserthusetplay.se'])
    assert(ie.supported_protocols == ['https'])
    assert(ie.valid_url == 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:28.799950
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('Konserthuset Play', True, 'http://www.konserthusetplay.se', 'faux123')

# Generated at 2022-06-24 12:53:30.455737
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kplay = KonserthusetPlayIE()
    assert kplay is not None

# Generated at 2022-06-24 12:53:39.652063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with open('./test_data/test_KonserthusetPlayIE.json', encoding='utf-8') as f:
        test_cases = eval(f.read())

# Generated at 2022-06-24 12:53:42.300948
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    k._real_extract(k._VALID_URL)

# Generated at 2022-06-24 12:53:52.131770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:02.948502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that KonserthusetPlayIE object is created with correct URL
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(test_url)

    assert ie.url == test_url
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert ie._downloader is not None
    assert ie._match_id("") is None
    assert ie._search_regex("", "", "") is None

# Generated at 2022-06-24 12:54:09.786913
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Success
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE().suitable(url)
    KonserthusetPlayIE()(url)

    # Fail
    url = 'http://www.youtube.com/'
    KonserthusetPlayIE().suitable(url)
    try:
        KonserthusetPlayIE()(url)
        assert False
    except:
        pass

# Generated at 2022-06-24 12:54:20.629031
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_result = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }

    ie = KonserthusetPlayIE()
    result = ie._real_extract(url)

    assert result == expected_result

# Generated at 2022-06-24 12:54:28.067783
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('Testing constructor of class KonserthusetPlayIE')
    print('url1')
    url1 = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    kp_ie = KonserthusetPlayIE()

    #Test for _VALID_URL
    match_object = kp_ie._VALID_URL_RE.match(url1)
    assert match_object is not None

    # Test for _real_extract
    # Test kp_ie.extract(url)
    info_dict = kp_ie.extract(url1)
    assert info_dict.get('id') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:35.321328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    result = KonserthusetPlayIE()._real_extract(url)
    assert result["id"] == "CKDDnlCY-dhWAAqiMERd-A"
    assert result["duration"] == 398.76
    assert result["title"] == "Orkesterns instrument: Valthornen"
    assert result["formats"][0]["url"] == "rtmp://csp.picsearch.com/00064/MediaPlayer/mp4:artist_CKDDnlCY-dhWAAqiMERd-A_2048kbps_h264m.mp4"

# Generated at 2022-06-24 12:54:37.228954
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  ie1 = KonserthusetPlayIE()
  assert ie1 != None

# Generated at 2022-06-24 12:54:46.807219
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    #The call to _real_extract calls a download site
    with open('test_KonserthusetPlayIE_response.json', 'r') as f:
        f = f.read()
    ie.downloader.to_screen = lambda *x: None #To avoid output from _download_webpage
    ie.downloader.cache = lambda *x: (None, f)
    info = ie._real_extract(ie.url)
    assert 'title' in info
    url = info['formats'][0]['url']
    assert url == 'rtmp://konsertliv.akamaized.net/stageLive_external_liv'

# Generated at 2022-06-24 12:54:58.230999
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of class KonserthusetPlayIE
    KonserthusetPlayIE_obj = KonserthusetPlayIE()
    # Assert m3u8_url
    assert 'm3u8_url' in KonserthusetPlayIE_obj.__dict__
    # Assert webp_url
    assert 'webp_url' in KonserthusetPlayIE_obj.__dict__
    # Assert ext
    assert 'ext' in KonserthusetPlayIE_obj.__dict__
    # Assert video_id
    assert 'video_id' in KonserthusetPlayIE_obj.__dict__
    # Assert title
    assert 'title' in KonserthusetPlayIE_obj.__dict__
    # Assert description
    assert 'description' in Kons

# Generated at 2022-06-24 12:54:58.752491
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:55:09.364071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:55:18.993701
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    class_name = 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:55:22.517554
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:31.273814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit_test = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(unit_test._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(unit_test._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(unit_test._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')

# Generated at 2022-06-24 12:55:34.650021
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:44.342093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    a = ie.IE_NAME
    b = ie.IE_DESC
    c = ie.get_info('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id']
    d = ie.get_info('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['ext']
    e = ie.get_info('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['title']

# Generated at 2022-06-24 12:55:46.467070
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    (ie,) = (
        ie for ie in InfoExtractor._ies
        if ie.IE_NAME == 'KonserthusetPlay'
    )
    # constructor should extract url and assign it to ie
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = ie(url)
    assert ie._url == url

# Generated at 2022-06-24 12:55:47.696870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:55:48.613274
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:55.769379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:02.285431
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    id = 'CKDDnlCY-dhWAAqiMERd-A'
    webpage = k._download_webpage(url, id)
    assert webpage is not None
    assert webpage.startswith('<!DOCTYPE')

# Generated at 2022-06-24 12:56:03.524838
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert('KonserthusetPlayIE' in globals())

# Generated at 2022-06-24 12:56:05.841340
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    print(ie)

# Generated at 2022-06-24 12:56:10.421067
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # This is the URL that current unit test is testing.
    if ie.working():
        ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:56:12.153924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie != None)

# Generated at 2022-06-24 12:56:13.579470
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)._real_extract(None);

# Generated at 2022-06-24 12:56:21.555409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    title = 'Orkesterns instrument: Valthornen'
    description = 'Orkesterns instrument: Valthornen'
    thumbnail = 'http://content.worldnow.com/images/17123033_AA_169_WEB.jpg'
    id = 'CKDDnlCY-dhWAAqiMERd-A'
    duration = 398.76

# Generated at 2022-06-24 12:56:22.142413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:56:30.344981
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    k = KonserthusetPlayIE(url)
    assert k._real_extract(url)['id'] == "CKDDnlCY-dhWAAqiMERd-A"
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    k = KonserthusetPlayIE(url)
    assert k._real_extract(url)['id'] == "elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:56:31.765659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:33.667676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id
    ie._real_extract

# Generated at 2022-06-24 12:56:38.680133
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)

    assert(ie.extract(url)["title"] == "Orkesterns instrument: Valthornen")

# Generated at 2022-06-24 12:56:41.374503
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    c = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert c.constructor == KonserthusetPlayIE

# Generated at 2022-06-24 12:56:43.743364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_instance = KonserthusetPlayIE()
    print("Test instance created: " + str(test_instance))

# Generated at 2022-06-24 12:56:54.381288
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert_equal(obj._VALID_URL, "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")

# Generated at 2022-06-24 12:56:56.220423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:57:02.257383
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    IE = KonserthusetPlayIE()
    IE.urls = [url]
    info_dict = IE.ie_key()
    assert info_dict == KonserthusetPlayIE._TESTS[0]['info_dict']

# Generated at 2022-06-24 12:57:03.793094
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:57:06.996050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Simple test for constructor of class KonserthusetPlayIE"""
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:57:17.003960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ test class KonserthusetPlayIE.__init__ """

    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    # Instanciate the class VideoInfoExtractor
    e = KonserthusetPlayIE(url)
    assert e.getTitle() == "Orkesterns instrument: Valthornen"
    assert e.getDescription().startswith("Valthornen spelar främst ofta pianissimo,")
    assert e.getThumbnail() == 'http://media.konserthuset.se/media/CKDDnlCY-dhWAAqiMERd-A/thumb/576_324.jpg'
    assert e.getDuration() == 398.76
    assert e.getId()

# Generated at 2022-06-24 12:57:23.810394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:57:24.593625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:26.655104
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-24 12:57:30.544434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    args = {'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'}
    test_obj = InfoExtractor(**args)
    assert test_obj.ie_key() == 'KonserthusetPlay'
    assert test_obj.ie_key() in InfoExtractor._ies