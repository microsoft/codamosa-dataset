

# Generated at 2022-06-24 12:47:34.351415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:45.659445
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)

    returned_ie = ie._real_extract("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

    assert returned_ie["id"] == "CKDDnlCY-dhWAAqiMERd-A"
    assert returned_ie["title"] == "Orkesterns instrument: Valthornen"

# Generated at 2022-06-24 12:47:48.566542
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:49.238181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:54.275701
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
# test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:55.928169
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:48:01.901391
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlay", False)
    print("URL: " + ie.url)
    print("Title: " + ie.title)
    print("ID: " + ie.id)
    print("Formats: " + str(ie.formats))
    print("Description: " + ie.description)
    print("Thumbail: " + ie.thumbnail)
    print("Subtitles: " + str(ie.subtitles))
    print("Duration: " + str(ie.duration))

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:05.639870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() == '0.0.1'

# Generated at 2022-06-24 12:48:07.264963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None


# Generated at 2022-06-24 12:48:09.063855
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE
    # Test case 1: Check creation of class KonserthusetPlayIE
    assert info_extractor is not None, 'Class KonserthusetPlayIE is not created'

# Generated at 2022-06-24 12:48:10.276991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:11.711381
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test extract_one
    url = ie._VALID_URL
    ie.extract_one(url)

# Generated at 2022-06-24 12:48:13.455825
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("", "", "", "")

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:17.136017
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:48:23.468894
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/se/video.php?id=1"
    ie = KonserthusetPlayIE(url)
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS
    assert determine_ext('http://www.konserthusetplay.se/se/video.php?id=1') == 'php'

# Generated at 2022-06-24 12:48:24.874088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.VALID_URL == ie._VALID_URL)
    assert(ie.TESTS == ie._TESTS)

# Generated at 2022-06-24 12:48:27.911779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:48:28.785241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print (ie._VALID_URL)

# Generated at 2022-06-24 12:48:39.762272
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test case for constructor of class KonserthusetPlayIE"""

    # Test case 1: constructor of KonserthusetPlayIE
    class Test1:
        def __init__(self):
            """Constructor for class Test1"""
            self.__test1_field1 = 5
            self.__test1_field2 = "hello"
            self.__test1_field3 = False
            self.__test1_field4 = [1, 3, 4, 6]
            self.__test1_field5 = None
            self.__test1_field6 = (5, 2)
            self.__test1_field7 = {}
            self.__test1_field8 = Test2()
            self.field9 = "world"
            self.field10 = 1.23

# Generated at 2022-06-24 12:48:41.769727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == InfoExtractor.choose_ie('KonserthusetPlay').CLASS


# Generated at 2022-06-24 12:48:44.503112
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME in ie.ie_key()
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-24 12:48:50.203495
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        print("Unit test for class KonserthusetPlayIE failed")
        raise
    else:
        print("Unit test for class KonserthusetPlayIE succeeded")

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:54.143859
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    try:
        instance = class_('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    except Exception as e:
        return False

    return True

# Generated at 2022-06-24 12:49:04.712560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:06.028712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE  # loads without exception


# Generated at 2022-06-24 12:49:07.844899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:49:12.388483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE(test)
    k._match_id(test)
    k._real_extract(test)

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:14.747733
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:26.070962
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:27.618136
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:49:36.151412
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')
    assert_equals(KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A'),
        {'title': 'Orkesterns instrument: Valthornen',
         'description': 'Valthornen är ett av de största instrumenten i orkestern. Lyssna till Bruno Steins egna tolkning av ”The Bluebells of Scotland” med valthorn i centrum.',
         'thumbnail': 're:^https?://.*$',
         'duration': 398800,
         'id': 'CKDDnlCY-dhWAAqiMERd-A',
         'ext': 'mp4'})

# Generated at 2022-06-24 12:49:40.893160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:49:42.130059
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:53.579306
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    kp = KonserthusetPlayIE()
    assert kp.suitable(url)
    assert not kp.suitable('http://www.google.com')
    assert kp._VALID_URL == kp.valid_url(url)
    assert kp._VALID_URL == kp.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not kp.valid_url('http://www.google.com')

# Generated at 2022-06-24 12:49:54.848705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:49:58.172474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print ("KonserthusetPlayIE.__init__: " + ie.__class__.__name__)

# Generated at 2022-06-24 12:50:03.501346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:05.145996
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    of = KonserthusetPlayIE()
    assert of.ie_key() == 'KonserthusetPlay'


if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:06.358324
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    

# Generated at 2022-06-24 12:50:09.292971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:50:10.328930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:10.938632
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-24 12:50:17.341072
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # To test KonserthusetPlayIE, the url should be provided
    url = 'https://www.konserthusetplay.se/?m=RHz7rU6QfU6-8UeWIFZvTg'
    _ = KonserthusetPlayIE()(url)

# Generated at 2022-06-24 12:50:23.437405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

    # ensure that the matching regex is correctly matching the URL
    assert k._VALID_URL is not None
    assert k._match_id('https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:26.487867
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .konserthusetplay import KonserthusetPlayIE
    assert isinstance(KonserthusetPlayIE(""), KonserthusetPlayIE)

# Generated at 2022-06-24 12:50:34.570364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._download_webpage("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE()._download_json("http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object", "CKDDnlCY-dhWAAqiMERd-A", "CKDDnlCY-dhWAAqiMERd-A")

    assert(True)

# Generated at 2022-06-24 12:50:36.799903
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:39.488204
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    expected_regex = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    KonserthusetPlayIE  # to avoid warning

# Generated at 2022-06-24 12:50:40.567294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:50:44.239723
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Check if it's been constructed right
    ie = KonserthusetPlayIE(url)
    assert ie == url

# Generated at 2022-06-24 12:50:45.247596
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:48.283980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'konserthusetplay'

# Generated at 2022-06-24 12:50:56.417379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_id() == 'KonserthusetPlay'
    assert ie.SUFFIX == 'mp4'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.WEBPAGE_URL == 'http://www.konserthusetplay.se/?m=%s'
    assert ie.EMBED_URL == 'http://www.konserthusetplay.se/embed.php?play=konserthusetplay&item=%s'

# Generated at 2022-06-24 12:50:58.513322
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ieOBj = KonserthusetPlayIE()
    assert(ieOBj._VALID_URL)

# Generated at 2022-06-24 12:51:00.295477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == type(KonserthusetPlayIE({}))

# Generated at 2022-06-24 12:51:06.527781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert isinstance(konserthusetplay, KonserthusetPlayIE)
    assert konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert isinstance(konserthusetplay._TESTS, list)
    for test in konserthusetplay._TESTS:
        assert isinstance(test, dict)


# Generated at 2022-06-24 12:51:09.536077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_instance = ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie_instance == 1)

# Generated at 2022-06-24 12:51:13.513103
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-24 12:51:14.806841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return


# Generated at 2022-06-24 12:51:15.851015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:17.757435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiate KonserthusetPlayIE object
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:22.407395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:51:26.320886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test of constructor of class KonserthusetPlayIE.
    """
    try:
        # Create object of class KonserthusetPlayIE
        ieObj = KonserthusetPlayIE()
        assert ieObj.ie_key() == 'KonserthusetPlay'
    except Exception as ex:
        print('*** ERROR in test_KonserthusetPlayIE(): %s' % ex)
        return False
    return True


# Generated at 2022-06-24 12:51:38.018012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    konserthusetPlayIE = KonserthusetPlayIE()
    assert konserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:48.484599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:50.082659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# Instantiate the class to be tested
	k = KonserthusetPlayIE()

	# Check that the attribute 'params' is not null
	assert k.params is not None

# Generated at 2022-06-24 12:51:52.596915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #assert not KonserthusetPlayIE("url")._VALID_URL
    assert KonserthusetPlayIE("url")._VALID_URL



# Generated at 2022-06-24 12:51:53.343685
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:58.244609
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL is not None)
    assert(KonserthusetPlayIE._TESTS is not None)
    ie = KonserthusetPlayIE()
    ie._extract_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:08.796660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_downloader import TestDownloader
    import unittest
    import sys
    import os
    import shutil
    from .common import expected_warnings

    # Initialisation of resources and mock tests
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    konserthusetplay_test = loader.loadTestsFromTestCase(TestDownloader)
    suite.addTest(konserthusetplay_test)
    runner = unittest.TextTestRunner()
    with expected_warnings(['Error in the certificate']):
        result = runner.run(suite)
    # End of tests

    # Evaluation of tests results
    f = open(os.devnull, 'w')
    old_stdout = sys.stdout

# Generated at 2022-06-24 12:52:10.646788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:52:11.530108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:52:12.136994
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:52:16.746354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:52:26.174056
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.videoid == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:52:30.817158
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    konserthusetplay = ie._VALID_URL
    assert 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)' == konserthusetplay

# Generated at 2022-06-24 12:52:34.123792
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
       k = KonserthusetPlayIE()
       assert k.expression == KonserthusetPlayIE._VALID_URL
       assert k.ie_key == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:37.555600
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

    # Test for constructor of class KonserthusetPlayIE
    assert(info_extractor.ie_key() == 'KonserthusetPlay')


# Generated at 2022-06-24 12:52:41.684251
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('test')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:52:44.874854
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:54.747053
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    example_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(example_url)
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay, RSO Play'
    assert ie.get_host() == 'www.konserthusetplay.se'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-24 12:52:55.860332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert not KonserthusetPlayIE({}, {})

# Generated at 2022-06-24 12:52:56.839233
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:00.872990
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:02.530961
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:53:05.774388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(repr(ie))
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True


# Generated at 2022-06-24 12:53:10.918449
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.supported_extractors() == ['konserthusetplay']
    assert ie.supported_domains() == ['konserthusetplay.se', 'rspoplay.se']
    assert ie.supported_protocols() == ['http']
    assert ie.supported_flavors() == ['http', 'rtmp']
    assert ie.supported_filetypes() == ['mp4']

# Generated at 2022-06-24 12:53:12.059127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert repr(KonserthusetPlayIE())

# Generated at 2022-06-24 12:53:13.545298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:53:15.096946
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:23.723524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.title() == 'KonserthusetPlay'
    assert ie.description() == 'Video on demand service for the Royal Swedish Concert Hall, Konserthuset'
    assert ie.extractor_key() == 'konserthusetplay'
    assert ie.suitable(None) == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True

# Test correct extraction of video_id and e-GET-parameter


# Generated at 2022-06-24 12:53:33.836317
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    KonserthusetPlayIE._VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:36.025618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:47.495574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:49.161703
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None


# Generated at 2022-06-24 12:53:55.813665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test an empty KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Test a filled KonserthusetPlayIE object
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE(url)


# Generated at 2022-06-24 12:54:00.169732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.host() == 'www.konserthusetplay.se'

# Generated at 2022-06-24 12:54:02.357765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE({})
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:54:07.409562
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	kp = KonserthusetPlayIE()
	assert kp is not None
	assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:18.605564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplay_ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:54:20.537672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-24 12:54:23.063523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__ == "KonserthusetPlayIE"


# Generated at 2022-06-24 12:54:25.704979
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import pytest
    IE = KonserthusetPlayIE
    IE.__name__ = 'KonserthusetPlayIE'
    IE.test()

# Generated at 2022-06-24 12:54:27.918173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._match_id('any') == None

# Generated at 2022-06-24 12:54:31.541934
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        abc=KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDLZlCY-dhWAAqqMRGd-A');
    except:
        print("Not a url.");
    return;

# Generated at 2022-06-24 12:54:32.693774
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:54:34.054508
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-24 12:54:35.457431
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(None), InfoExtractor)


# Generated at 2022-06-24 12:54:39.951634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:54:43.507848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp.IE_NAME == 'KonserthusetPlay'
    assert kp.IE_DESC == 'Konserthuset Play'
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:45.765924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_ie = KonserthusetPlayIE()
    assert(video_ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:54:46.516330
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:57.830913
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constuctor
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlay'
    assert KonserthusetPlayIE.__module__ == 'youtube_dl.extractor.konserthusetplay'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:59.765972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(instance, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:02.782768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    m = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    m._real_extract(url)

# Generated at 2022-06-24 12:55:14.841629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('test.se', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.format_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.valid_url == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:16.066029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:23.969089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # should return none when url is not correct
    url = 'https://www.youtube.com/watch?v=H8aWxo7fNpw'
    expected = None
    real = KonserthusetPlayIE()
    real2 = KonserthusetPlayIE._valid_url(url)
    real3 = KonserthusetPlayIE._real_extract(real, url)
    assert expected == real2, '_valid_url does not return expected result'
    assert expected == real3, '_real_extract does not return expected result'



# Generated at 2022-06-24 12:55:26.916200
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:55:36.786805
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test 1
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    module = "KonserthusetPlayIE"
    ie = KonserthusetPlayIE(url)

    assert ie.module == module, "Expected {} but found {}".format(module, ie.module)
    assert ie.url == url, "Expected URL {} but found {}".format(url, ie.url)
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A", "Expected ID CKDDnlCY-dhWAAqiMERd-A but found {}".format(ie.video_id)

# Generated at 2022-06-24 12:55:39.808859
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ins = KonserthusetPlayIE()
    print(ins.__class__.__name__)
    print(ins.__class__.__bases__)
    print(ins.__class__.__module__)

# Generated at 2022-06-24 12:55:43.283885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:45.411282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:55:48.248993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.suitable(ie.url) == True

# Generated at 2022-06-24 12:55:51.813414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit_test_instance = KonserthusetPlayIE()
    assert unit_test_instance._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:54.246201
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:55.366437
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:56:04.073438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == 'KonserthusetPlay'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.__name__ == 'KonserthusetPlayIE'
    assert ie.info()['id'] == 'konserthusetplay'
    assert ie.info()['extractor'] == 'konserthusetplay'
    assert ie._real_extract().get('id') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:05.796983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:56:12.317998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for constructor of class KonserthusetPlayIE.
    """
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:15.212346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
   # KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:56:18.010740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie.extract(url)
    assert True

# Generated at 2022-06-24 12:56:22.666900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetplay = KonserthusetPlayIE()
    print(konserthusetplay._real_extract(url))

# Generated at 2022-06-24 12:56:25.587249
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE('www.konserthusetplay.se', url, {'id': 'CKDDnlCY-dhWAAqiMERd-A'})

# Generated at 2022-06-24 12:56:28.610899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        success = True
    except BlockingIOError:
        success = False
    assert success

# Generated at 2022-06-24 12:56:39.922695
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Regex validator
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Tests

# Generated at 2022-06-24 12:56:50.992905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    xt = KonserthusetPlayIE()
    xt.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    xt.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    xt.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&m=CKDDnlCY-dhWAAqiMERd-A')
    xt.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:51.641906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-24 12:56:53.413491
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    print(test)
    assert test


# Generated at 2022-06-24 12:56:54.430209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:03.062511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests for class KonserthusetPlayIE.
    # Returns:
    #    An instance of KonserthusetPlayIE

    ie = KonserthusetPlayIE()
    # test .suitable()
    assert ie.suitable('https://www.konserthusetplay.se/?m=aMowfHtHWExiEKEzbBQQGQ')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # test .extract()
    assert ie.extract('https://www.konserthusetplay.se/?m=aMowfHtHWExiEKEzbBQQGQ')

# Generated at 2022-06-24 12:57:06.404404
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:16.527212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Tests the constructor of class KonserthusetPlayIE
    '''
    # Test with a valid url
    valid_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthuset = KonserthusetPlayIE(url=valid_url)

    assert konserthuset._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:20.297829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:57:21.630676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:24.893013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert 1 == 1

# Generated at 2022-06-24 12:57:25.673324
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('rspoplay')

# Generated at 2022-06-24 12:57:28.426105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Only a trivial test, in order to make sure that we can create an instance.
    # It does not test extraction of any metadata
    ie = KonserthusetPlayIE()