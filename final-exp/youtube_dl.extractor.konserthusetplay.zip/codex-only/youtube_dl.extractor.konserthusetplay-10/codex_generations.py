

# Generated at 2022-06-24 12:47:33.360139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL, "Invalid url"
    assert ie.IE_NAME, "Invalid ie name"

# Generated at 2022-06-24 12:47:37.809201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    UnitTest = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['url'] == UnitTest

# Generated at 2022-06-24 12:47:41.622736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    return k.test_result()

test_KonserthusetPlayIE()

"""
Checks the result of test_KonserthusetPlayIE()
Returns OK, FAIL, or UNKNOWN
"""

# Generated at 2022-06-24 12:47:53.038083
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test URL
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Test video_id extraction
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'
    # Test tests extraction


# Generated at 2022-06-24 12:47:54.643844
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for constructor of class KonserthusetPlayIE
    obj = KonserthusetPlayIE()
    print(obj)

# Generated at 2022-06-24 12:47:57.914235
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    class_.KonserthusetPlayIE = KonserthusetPlayIE
    KonserthusetPlayIE.__module__ = 'konserthusetplay'
    test_class_instance(class_)

# Generated at 2022-06-24 12:48:03.602059
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    yt = ie._download_json(
        'http://csp.picsearch.com/rest?e=24678965411&containerId=mediaplayer&i=object',
        'yt', transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])
    player_config = yt['media']['playerconfig']
    playlist = player_config['playlist']
    source = next(f for f in playlist if f.get('bitrates') or f.get('provider'))
    connection_url = (player_config.get('rtmp', {}).get(
        'netConnectionUrl') or player_config.get(
        'plugins', {}).get('bwcheck', {}).get('netConnectionUrl'))
   

# Generated at 2022-06-24 12:48:05.003216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie



# Generated at 2022-06-24 12:48:07.959069
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # When
    konserthusetplay = KonserthusetPlayIE()

    # Then
    assert unicode(konserthusetplay) == u'<class KonserthusetPlayIE>'

# Generated at 2022-06-24 12:48:11.957092
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL)
    assert(KonserthusetPlayIE._TESTS)
    assert(KonserthusetPlayIE._real_extract)
    assert(KonserthusetPlayIE.suitable)

# Generated at 2022-06-24 12:48:14.086008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   data = KonserthusetPlayIE()
   url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
   data.to_screen(url)

# Generated at 2022-06-24 12:48:15.326619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie)

# Generated at 2022-06-24 12:48:18.790668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:21.086074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Create an instance of KonserthusetPlayIE
    konserthuset_play_ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:25.856801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:48:26.843771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()



# Generated at 2022-06-24 12:48:27.473949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:48:31.641660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.to_str() == '<KonserthusetPlayIE http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A>'

# Generated at 2022-06-24 12:48:42.173924
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:48:46.669733
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    konserthuset_play_ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:48.272376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')

# Generated at 2022-06-24 12:48:50.963334
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    assert(konserthusetplayIE != None)

# Generated at 2022-06-24 12:48:55.848322
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()

    assert ie._match_id(url) == video_id

# Generated at 2022-06-24 12:49:04.275362
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract_id('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.extract_id('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:49:13.934002
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert konserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:17.495572
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")


# Generated at 2022-06-24 12:49:20.400675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()
    assert x.ie_key() == 'KonserthusetPlay'
    assert x.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:22.680884
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:26.829900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:49:30.425720
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test constructor of class KonserthusetPlayIE """
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.url == url

# Generated at 2022-06-24 12:49:33.649559
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    v = KonserthusetPlayIE()._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert v['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:49:41.336740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:53.014270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        url_or_none,
    )
    ke = KonserthusetPlayIE()
    assert ke._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:58.699400
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.get_url_from_video_id()
    ie.get_info_from_video_url()

# Generated at 2022-06-24 12:49:59.420082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:01.220214
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:50:07.699634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == type(konserthusetplay.KonserthusetPlayIE())
    assert KonserthusetPlayIE == type(konserthusetplay.KonserthusetPlayIE.KonserthusetPlayIE())
    assert KonserthusetPlayIE == type(konserthusetplay.KonserthusetPlayIE()(KonserthusetPlayIE))
    assert konserthusetplay.KonserthusetPlayIE == type(konserthusetplay.KonserthusetPlayIE)



# Generated at 2022-06-24 12:50:11.771089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url= "http://www.konserthusetplay.se/?m=9pZmEtZ-MzOioPYgG4gRxw"
    ie= KonserthusetPlayIE()
    ie._real_extract(url)

# Generated at 2022-06-24 12:50:14.012976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True


# Generated at 2022-06-24 12:50:24.723260
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:28.435515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie.PROTOCOL_MAP)
    assert ie.PROTOCOL_MAP['m3u8_native'] == 'm3u8'

# Generated at 2022-06-24 12:50:37.845580
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Succesfully create instance of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

    # Test #1
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

    # Test #2
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

    # Test #3

# Generated at 2022-06-24 12:50:38.800381
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:40.391404
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = InfoExtractor("KonserthusetPlayIE")
    assert ie is not None

# Generated at 2022-06-24 12:50:45.958827
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable(ie.IE_NAME, ie._VALID_URL)
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:51.121012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE.IE_NAME == 'KonserthusetPlay'
	assert KonserthusetPlayIE.IE_DESC == 'KonserthusetPlay.se'

	object = KonserthusetPlayIE('KonserthusetPlay')
	assert not object == None
	assert object.IE_NAME == 'KonserthusetPlay'
	assert object.IE_DESC == 'KonserthusetPlay.se'

# Generated at 2022-06-24 12:50:56.322746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay.get_url() == "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"


# Generated at 2022-06-24 12:51:05.691887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = Konserthus

# Generated at 2022-06-24 12:51:06.762614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:07.687456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:10.523672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert(k.ie_key() == 'KonserthusetPlay')
    assert(k.ie_name() == 'KonserthusetPlay')
    assert(k.info_extractors() == [KonserthusetPlayIE])


# Generated at 2022-06-24 12:51:17.997148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj1 = KonserthusetPlayIE._match_id
    obj1(KonserthusetPlayIE(), 'https://www.konserthusetplay.se?m=CKDDnlCY-dhWAAqiMERd-A')
    obj2 = KonserthusetPlayIE._real_extract
    obj2(KonserthusetPlayIE(), 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:21.776195
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None
    assert KonserthusetPlayIE._downloader is not None

# Generated at 2022-06-24 12:51:22.797454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_IE = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:32.198469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:51:36.761602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert obj._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:51:42.561955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    example_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(example_url)
    if not ie.suitable(example_url):
        print('URL %s is not suitable.' % example_url)
    else:
        video_info = ie.extract(example_url)
        print(video_info)


# Generated at 2022-06-24 12:51:43.729516
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:51:50.794492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A')
    ie._download_json('http://csp.picsearch.com/rest?e=.&containerId=mediaplayer&i=object', 'CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:51:58.776292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # first test: input a valid url
    test_url1 = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = KonserthusetPlayIE()._real_extract(test_url1)
    assert_equal(result,{'title': 'Orkesterns instrument: Valthornen', 'id': 'CKDDnlCY-dhWAAqiMERd-A', 
        'description': 'md5:f10e1f0030202020396a4d712d2fa827', 'thumbnail': 're:^https?://.*$', 
        'duration': 398.76, 'formats': [], 'subtitles': {}})



# Generated at 2022-06-24 12:52:09.356434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    ies = [
        KonserthusetPlayIE(),
    ]

    for ie in ies:
        assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:17.041346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.video_id = ie._match_id(ie.url)
    ie.webpage = ie._download_webpage(ie.url, ie.video_id)
    ie.e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', ie.webpage, 'e')

    assert ie.e == 'TnTsZ7Qb-dkKAQrOEgxY-A'


# Generated at 2022-06-24 12:52:27.973476
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'

    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:52:33.468082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'extract' in globals()
    extract = globals()['extract']
    assert 'url_or_none' in globals()
    url_or_none = globals()['url_or_none']
    KonserthusetPlayIE()._real_extract(
    extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))

# Generated at 2022-06-24 12:52:36.146428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert type(KonserthusetPlayIE) is type(InfoExtractor)
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')


# Generated at 2022-06-24 12:52:40.992233
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of KonserthusetPlayIE with KonserthusetPlayIE._VALID_URL
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

    # Test that the constructor of KonserthusetPlayIE class is working
    assert isinstance(ie, KonserthusetPlayIE)

    # Test that KonserthusetPlayIE._VALID_URL is valid for the instance ie
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:52:43.827885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, KonserthusetPlayIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:52:44.873447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:56.895975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert ie.IE_NAME == 'konserthusetplay'

    # Test the function _real_extract
    ie_test = KonserthusetPlayIE()
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    # Test download webpage
    webpage = ie_test._download_webpage(url, video_id)
    assert isinstance(webpage, str)

# Generated at 2022-06-24 12:52:57.706582
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:59.721147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import test_KonserthusetPlayIE
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:01.260152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie is not None


# Generated at 2022-06-24 12:53:02.382648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:03.899477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:05.499905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    print(konserthusetPlayIE)


# Generated at 2022-06-24 12:53:09.017737
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:53:12.113927
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Ensure that constructor works correctly
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:53:13.214124
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:18.228931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE."""
    IE = KonserthusetPlayIE()
    assert IE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:19.943167
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Make sure it initilizes
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:53:28.067424
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:30.196795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        return False
    return True

# Generated at 2022-06-24 12:53:31.551781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE is not None

# Generated at 2022-06-24 12:53:40.308955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    extractor = KonserthusetPlayIE()
    # Unit test for the `_download_webpage` function
    webpage = extractor._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    assert webpage is not None
    # Unit test for the `_match_id` function
    video_id = extractor._match_id(url)
    assert video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    # Unit test for the `_real_extract` function
    info_dict = extractor._real_extract(url)
    assert info_dict is not None
    assert info_

# Generated at 2022-06-24 12:53:49.427509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_obj = KonserthusetPlayIE()
    content = test_obj._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A')
    match = test_obj._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', content, 'e')
    assert match == 'UH3qJxTdT0-zPQOgDjZ0dQ'

# Generated at 2022-06-24 12:54:02.030189
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._downloader = DownloaderStub()
    ie._downloader.connection.side_effect = [
        MockResponse("<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE html><html><head></head><body></body></html>"),
        MockResponse("{}")]
    ie.extract("http://www.rspoplay.se/?m=c0HsA4e4bX9sKFAAQYdD2Q")
    assert ie._downloader.connection.call_count == 2

# Generated at 2022-06-24 12:54:03.600697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    print(obj.__class__)

# Generated at 2022-06-24 12:54:08.847881
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    # Test with 1 valid url
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Test with 1 broken url
    ie.extract('http://www.konserthusetplay.se/?m=broken')

# Generated at 2022-06-24 12:54:11.031973
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.__class__.__name__ == "KonserthusetPlayIE"

# Generated at 2022-06-24 12:54:12.806052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE != None)


# Generated at 2022-06-24 12:54:17.909838
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:54:19.182047
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:21.885517
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k_play = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert(k_play != None)

# Generated at 2022-06-24 12:54:23.697534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert re.match(ie._VALID_URL, ie._URL_EXTRACTOR.pattern)

# Generated at 2022-06-24 12:54:27.881183
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Unit test for constructor of class KonserthusetPlayIE\n")
    # Tests OK and NOK
    # TODO
    print("Unit test for constructor of class KonserthusetPlayIE [OK]\n")


# Generated at 2022-06-24 12:54:31.199079
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:32.166329
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:40.202493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    infoextractor = KonserthusetPlayIE()
    assert(infoextractor.get_url_regex().match(r'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))
    assert(infoextractor.get_url_regex().match(r'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'))

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:42.396155
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:54:50.284418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:54.006439
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()._match_id("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").__eq__("CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:54:57.052622
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:55:04.922048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:16.703525
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.is_allowed_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.is_allowed_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.is_allowed_url('http://konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.is_allowed_url('http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True

# Generated at 2022-06-24 12:55:27.385535
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:28.815861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key()) is not None

# Generated at 2022-06-24 12:55:29.953844
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:55:33.094853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    downloader = InfoExtractor()
    KonserthusetPlayIE_test = KonserthusetPlayIE(downloader)
    assert KonserthusetPlayIE_test is not None

# Generated at 2022-06-24 12:55:35.685516
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    my_ie = KonserthusetPlayIE()
    assert my_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:41.439053
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset = KonserthusetPlayIE()
    assert isinstance(konserthuset, InfoExtractor)
    # Unit tests for method _real_extract
    konserthuset._real_extract(url)
test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:50.484942
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

    # Unit test for method _real_extract
    kpIE = KonserthusetPlayIE()

    assert(kpIE._match_id(url) == 'elWuEH34SMKvaO4wO_cHBw')

    assert(kpIE._real_extract(url))

    # Unit test for method _download_webpage
    def test_download_webpage():
        import urllib
        def download_webpage(self, url_or_request, video_id, note='', errnote='', fatal=True, tries=1):
            return url_or_request.split('?')[1]
        kpIE.to_screen = lambda msg: None


# Generated at 2022-06-24 12:56:02.240940
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:56:05.540505
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except AssertionError:
        print("AssertionError raised when instantiating an object of class KonserthusetPlayIE.")

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:10.956163
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:14.562478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = ("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-24 12:56:15.524680
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:26.037358
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_app1 = KonserthusetPlayIE()
    ie_app2 = KonserthusetPlayIE()
    
    if ie_app1.delim == ie_app2.delim:
        print("ie_app1: " + ie_app1.delim)
        print("ie_app2: " + ie_app2.delim)
        print("ie_app1.delim is equal to ie_app2.delim")
    else:
        print("ie_app1: " + ie_app1.delim)
        print("ie_app2: " + ie_app2.delim)
        print("ie_app1.delim is not equal to ie_app2.delim")

# Generated at 2022-06-24 12:56:28.660341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-24 12:56:39.998057
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of KonserthusetPlayIE
    konserthusetplayIE = KonserthusetPlayIE()

    # Call the constructor of InfoExtractor
    infoExtractor = InfoExtractor()

    # Unit test for _match_id
    assert konserthusetplayIE._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplayIE._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'

    # Unit test for _download_webpage


# Generated at 2022-06-24 12:56:45.357668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Given an instance of the KonserthusetPlayIE class
    ie = KonserthusetPlayIE()
    # When calling _real_extract
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    # Then no error should be raised
    ie._real_extract(url)

# Generated at 2022-06-24 12:56:49.218222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract("KonserthusetPlayIE", url)

# Generated at 2022-06-24 12:56:50.352797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:51.051478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    example = KonserthusetPlayIE()
    assert example

# Generated at 2022-06-24 12:56:56.706269
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # The Konserthuset URL has a consistent pattern.
    _VALID_URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id(_VALID_URL) == 'CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-24 12:56:58.060906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie('')

# Generated at 2022-06-24 12:57:02.092584
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:57:03.994454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test if KonserthusetPlayIE can be instanciated.
    """
    assert KonserthusetPlayIE



# Generated at 2022-06-24 12:57:14.820182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #Test on an example video
    example_video = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    #Test if the example video matches our regex
    assert(ie._match_id(example_video) == 'CKDDnlCY-dhWAAqiMERd-A')
    #Test if the example video has the correct title
    assert(ie._real_extract(example_video)['title'] == 'Orkesterns instrument: Valthornen')
    #Test if the example video has the correct thumbnail
    assert(ie._real_extract(example_video)['thumbnail'] == 're:^https?://.*$')

# Generated at 2022-06-24 12:57:19.136285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        instance = KonserthusetPlayIE()
        print(instance)
    except Exception as e:
        print(e)
        assert False, "Failed to Execute Unit Test for KonserthusetPlayIE"


# Generated at 2022-06-24 12:57:20.248886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:25.024563
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        info_extractor = KonserthusetPlayIE()
    except:
        print("test_KonserthusetPlayIE FAILED")
    else:
        print("test_KonserthusetPlayIE PASSED")

if __name__ == '__main__':
    test_KonserthusetPlayIE();

# Generated at 2022-06-24 12:57:29.806797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_KonserthusetPlay = KonserthusetPlayIE()
    assert ie_KonserthusetPlay.__name__ == 'KonserthusetPlay'
    assert ie_KonserthusetPlay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'