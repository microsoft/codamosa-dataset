

# Generated at 2022-06-24 12:47:35.453592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('www.konserthusetplay.se')
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:47:41.807931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert "KonserthusetPlayIE" == KonserthusetPlayIE.ie_key()
    instance = KonserthusetPlayIE(None)
    assert "KonserthusetPlayIE" == instance.ie_key()
    # test class attribute _VALID_URL
    m = KonserthusetPlayIE._VALID_URL.match("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert m.group("id") == "CKDDnlCY-dhWAAqiMERd-A"
    # test class method _real_extract
    info_dict = instance._real_extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
   

# Generated at 2022-06-24 12:47:43.868054
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:44.993863
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:49.055951
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:51.224688
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:53.138361
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:48:00.708953
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    webpage = ie._download_webpage(url, ie._match_id(url))

    e = ie._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

    rest = ie._download_json(
        'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % e,
        ie._match_id(url), transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])

    media_dict

# Generated at 2022-06-24 12:48:01.967991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:03.320928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    


# Generated at 2022-06-24 12:48:05.102164
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlayIE")
    return ie

# Generated at 2022-06-24 12:48:06.561799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE() # object of class

    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:14.582756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert instance.expected_results == {
       'id': 'CKDDnlCY-dhWAAqiMERd-A',
       'ext': 'mp4',
       'title': 'Orkesterns instrument: Valthornen',
       'description': 'md5:f10e1f0030202020396a4d712d2fa827',
       'thumbnail': 're:^https?://.*$',
       'duration': 398.76,
    }

# Generated at 2022-06-24 12:48:18.695272
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # create an instance of KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    # assert that it is an instance of InfoExtractor
    assert ie is not None and isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:48:22.173407
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(KonserthusetPlayIE._downloader,
                             KonserthusetPlayIE._VALID_URL)

    assert(obj._downloader != None)
    assert(obj._VALID_URL != None)

# Generated at 2022-06-24 12:48:25.086361
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    id = 'CKDDnlCY-dhWAAqiMERd-A'
    extract = KonserthusetPlayIE().extract(url)
    assert(id in extract.keys())


# Generated at 2022-06-24 12:48:25.726669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:48:26.836645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE() # Should succeed
    assert extractor is not None

# Generated at 2022-06-24 12:48:28.127549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False, 'Failed to construct class KonserthusetPlayIE'

# Generated at 2022-06-24 12:48:29.240644
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Should be able to create object of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:33.001090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        print("Constructor for KonserthusetPlayIE works!")
    except TypeError:
        print("Error in constructor for KonserthusetPlayIE!")



# Generated at 2022-06-24 12:48:34.769111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL

# Generated at 2022-06-24 12:48:38.881987
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    example_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.download(example_url)

# Generated at 2022-06-24 12:48:44.439622
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    link = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_dict_with_keys = {'url': link, 'id': 'CKDDnlCY-dhWAAqiMERd-A'}
    url_matching_result = info_extractor._match_id(link)
    assert url_matching_result == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:48:48.114138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(
        KonserthusetPlayIE._VALID_URL, 'http://www.konserthusetplay.se')

# Test if the playlist is parsed correctly

# Generated at 2022-06-24 12:48:51.639221
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None, None)._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE(None, None)._TESTS == []

# Generated at 2022-06-24 12:48:57.255986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert(a.get_url() == 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:49:00.499967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A');

# Generated at 2022-06-24 12:49:02.902155
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as e: raise AssertionError ("class KonserthusetPlayIE() not constructed: " + str(e))
    return True



# Generated at 2022-06-24 12:49:04.388457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie



# Generated at 2022-06-24 12:49:05.484165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        KonserthusetPlayIE()

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:10.803527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_vid = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    test_url = KonserthusetPlayIE._VALID_URL
    assert test_vid.find(test_url) >= 0
    assert KonserthusetPlayIE.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-24 12:49:12.571612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:49:17.589241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:49:21.360347
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert (KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:49:30.982159
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Init
    result = {"url": "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "id": 'CKDDnlCY-dhWAAqiMERd-A', 'ext': 'mp4', "title": 'Orkesterns instrument: Valthornen'}
    print("Init: " + str(result))
    # Constructor
    ie = KonserthusetPlayIE()
    print("Constructor: " + str(ie))
    # Real Extract
    result = ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    print("Real Extract: " + str(result))


# Generated at 2022-06-24 12:49:34.678573
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract("http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:49:38.554519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplay_ie

    # check to see if the video is available
    found = konserthusetplay_ie._real_extract(url)
    assert found

# Generated at 2022-06-24 12:49:42.854033
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:49:54.584773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:05.186215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test with a URL
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    downloaded_webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    # Test with a webpage
    e = ie._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', downloaded_webpage, 'e')


# Generated at 2022-06-24 12:50:11.234148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert info_extractor.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:50:23.095139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url_example_1 = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    url_example_2 = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    url_example_3 = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&d=2013-08-01"
    url_example_4 = "http://www.rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    url_example_5 = "http://www.tvplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"


# Generated at 2022-06-24 12:50:27.691406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    ie = KonserthusetPlayIE()
    ie.ie_key() == "KonserthusetPlay"
    assert ie.suitable(ie.ie_key())
    assert ie.ie_key() in InfoExtractor._ALL_CLASSES

# Generated at 2022-06-24 12:50:31.279212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test creating instance of class
    KonserthusetPlayIE('KonserthusetPlay','www.konserthusetplay.se')
    KonserthusetPlayIE('KonserthusetPlay','rspoplay')


# Generated at 2022-06-24 12:50:32.670544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-24 12:50:37.408461
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:39.472794
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.__class__ == KonserthusetPlayIE)


# Generated at 2022-06-24 12:50:48.677661
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:00.200375
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import sys
    import os
    from os.path import dirname, join
    sys.path.append(dirname(dirname(dirname(os.path.realpath(__file__)))))
    from youtube_dl.extractor.konserthusetplay import KonserthusetPlayIE

    konserthuset_play_ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthuset_play_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:10.340385
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    file = KonserthusetPlayIE()

    assert file._VALID_URL == '^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)$'

# Generated at 2022-06-24 12:51:12.002687
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k != None

# Generated at 2022-06-24 12:51:16.354327
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract()['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:51:22.975983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.suitable("https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == True
    assert ie.suitable("https://www.youtube.com/watch?v=dQw4w9WgXcQ") == False

# Generated at 2022-06-24 12:51:25.950571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:51:30.906504
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    with pytest.raises(RegexNotFoundError):
        KonserthusetPlayIE("http://www.google.com/?m")

# Generated at 2022-06-24 12:51:38.106285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_cases = [
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ]
    for test_case in test_cases:
        ie = KonserthusetPlayIE()
        assert ie.suitable(test_case)
        assert ie.IE_NAME in ie.get_ie_key()

# Generated at 2022-06-24 12:51:39.078599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie

# Generated at 2022-06-24 12:51:49.603920
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Parameters of constructor of class KonserthusetPlayIE
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(url)
    assert ie.url == url

    # Method extract of class KonserthusetPlayIE
    # ie.extract()
    # ie.ie_key() # 'KonserthusetPlay'
    # ie.ie_downloads()

    # Method _real_extract of class KonserthusetPlayIE
    real_extract = ie._real_extract(url)
    assert('id' in real_extract)
    assert('title' in real_extract)
    assert('description' in real_extract)

# Generated at 2022-06-24 12:51:58.282339
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test
    try:
        KonserthusetPlayIE(None)
        print("FAIL Test: Test for constructor of KonserthusetPlayIE failed.")
        return False
    except:
        pass
    # Test
    try:
        KonserthusetPlayIE(None._download_webpage)
        print("FAIL Test: Test for constructor of KonserthusetPlayIE with _download_webpage as argument failed.")
        return False
    except:
        pass
    # Test
    try:
        KonserthusetPlayIE(None, None)
        print("FAIL Test: Test for constructor of KonserthusetPlayIE with both arguments failed.")
        return False
    except:
        pass
    print("Test for constructor of KonserthusetPlayIE passed.")
    return True


# Unit test

# Generated at 2022-06-24 12:52:06.045273
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.IE_NAME == KonserthusetPlayIE.IE_NAME
    assert ie.IE_DESC == KonserthusetPlayIE.IE_DESC
    assert ie.ie_key() == KonserthusetPlayIE.ie_key()

# Generated at 2022-06-24 12:52:06.795360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_json = KonserthusetPlayIE([])

# Generated at 2022-06-24 12:52:10.254165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    k.download('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:11.814466
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:14.567263
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._real_extract(url)

# Generated at 2022-06-24 12:52:15.560003
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:52:16.000488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:52:17.352869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:19.485408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:52:30.191138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE = KonserthusetPlayIE()

    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Test for "test.com"
    URL = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE._VALID_URL == KonserthusetPlayIE._match_id(URL)

    # Test for "test.com"
    URL = "http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"


# Generated at 2022-06-24 12:52:34.363328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert konserthuset_play.NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:52:37.370292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:40.424179
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
  KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:52:41.793579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:45.868746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.set_downloader(None)
    ie._real_extract(
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:47.471359
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    sut = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:50.041388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # The constructor of this class should not raise an exception,
    # otherwise something really bad happened.
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:56.593675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # Test constructor of class KonserthusetPlayIE
        tester_KonserthusetPlayIE = KonserthusetPlayIE()
        print('\n[+] KonserthaustPlayIE class was successfully tested.')
    except:
        print('\n[-] KonserthaustPlayIE class was not successfully tested.')
    return tester_KonserthusetPlayIE


# Generated at 2022-06-24 12:53:00.144361
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:53:05.593952
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    client_id = "konserthusetplay"
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    video_id = "CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(client_id)
    ie._match_id(url)
    video_info = ie.get_video_info(url)
    assert video_info["id"] == video_id

# Generated at 2022-06-24 12:53:07.968039
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    This is a unit test for the constructor of class KonserthusetPlayIE
    """

    # Class assignments
    konserthusetplay_ie = KonserthusetPlayIE(None)

    # Test whether the class assignments work
    assert konserthusetplay_ie

# Generated at 2022-06-24 12:53:19.293714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:22.267319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests constructor of KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    print(ie.IE_NAME)
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-24 12:53:26.617539
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.title == 'KonserthusetPlay'

# Generated at 2022-06-24 12:53:28.376298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print(KonserthusetPlayIE._TESTS[0])
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:31.716329
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    kplay = KonserthusetPlayIE()
    print(kplay)

# Generated at 2022-06-24 12:53:33.477661
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False

# Generated at 2022-06-24 12:53:34.465074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:37.509567
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert isinstance(ie.test_result, (str, bytes)) == True

# Generated at 2022-06-24 12:53:49.162417
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:01.976825
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Test construction of the class KonserthusetPlayIE
    
    Expected result: object of class KonserthusetPlayIE
    '''
    from ..utils import FakeYDL
    from ..extractor import IE_DESC
    # Create object of class FakeYDL for testing
    ydl = FakeYDL()
    # Create object of class KonserthusetPlayIE
    konserthuset = KonserthusetPlayIE(ydl)
    # Expect konserthuset to be an object of class KonserthusetPlayIE
    assert konserthuset.__class__.__name__ == 'KonserthusetPlayIE'
    # Expect konserthuset to be of kind 'generic'
    assert konserthuset.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:54:08.085779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    urls = [
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ]
    for url in urls:
        KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:54:10.167098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tmp_KonserthusetPlayIE = KonserthusetPlayIE()
    assert tmp_KonserthusetPlayIE is not None

# Generated at 2022-06-24 12:54:21.639543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()

    d = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
        'formats': 'formats',
        'subtitles': 'subtitles',
        }

# Generated at 2022-06-24 12:54:22.888534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:54:24.964910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'

# Generated at 2022-06-24 12:54:33.897195
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import inspect
    # Tests if the class KonserthusetPlayIE exists
    assert('KonserthusetPlayIE' in inspect.getmembers(KonserthusetPlayIE, inspect.isclass))
    # Check if _real_extract exists in the class
    assert('_real_extract' in inspect.getmembers(KonserthusetPlayIE, inspect.ismethod))
    # Check if _VALID_URL exists in the class
    assert('_VALID_URL' in inspect.getmembers(KonserthusetPlayIE, lambda x: type(x) is str))
    # Check if _TESTS exists in the class
    assert('_TESTS' in inspect.getmembers(KonserthusetPlayIE, lambda x: type(x) is list))

# Generated at 2022-06-24 12:54:40.740547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    from konserthuset_play import classKonserthusetPlayIE, _VALID_URL
    _VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    classKonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:54:43.045791
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError as e:
        assert '__init__() takes exactly 2 arguments' in str(e)
    else:
        raise Exception('TypeError expected!')

# Generated at 2022-06-24 12:54:44.374472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie is not None

# Generated at 2022-06-24 12:54:46.304671
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Constructor of class KonserthusetPlayIE with argument url
    KonserthusetPlayIE(url="https://www.konserthusetplay.se/", downloader=None)

# Generated at 2022-06-24 12:54:52.150590
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._downloader == ie.downloader
    assert ie._download_webpage == ie.download_webpage

# Generated at 2022-06-24 12:55:00.271584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test with the first test case from KonserthusetPlayIE._TESTS
    test_url = KonserthusetPlayIE._TESTS[0]['url']
    result = KonserthusetPlayIE()._real_extract(test_url)

    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['description'] == 'Orkesterns instrument: Valthornen\n'
    assert result['thumbnail'] is not None
    assert result['duration'] > 0
    assert len(result['formats']) > 0

# Generated at 2022-06-24 12:55:01.806847
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        assert True
    except:
        assert False


# Generated at 2022-06-24 12:55:02.925730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    return ie

# Generated at 2022-06-24 12:55:08.475039
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    
    a = KonserthusetPlayIE()
    assert a
    assert a._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Code for unit testing the constructor for class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:10.868598
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:15.569048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:19.251257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE({"url": url})
    assert ie.url == url # Check if attributes are set correctly
    assert ie.ext == "" # Check if attributes are set correctly
    assert ie.params == {} # Check if attributes are set correctly

# Generated at 2022-06-24 12:55:29.378843
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:31.167467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# Create Instance
	KonserthusetPlayIE_instance = KonserthusetPlayIE()


# Generated at 2022-06-24 12:55:35.829026
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:55:37.286510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(), KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:41.066732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:49.847137
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:54.605143
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:58.097770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:56:07.084633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE.expected_video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    test_KonserthusetPlayIE.expected_title = 'Orkesterns instrument: Valthornen'
    test_KonserthusetPlayIE.expected_description = 'md5:f10e1f0030202020396a4d712d2fa827'
    test_KonserthusetPlayIE.expected_thumbnail = 're:^https?://.*$'
    test_KonserthusetPlayIE.expected_duration = 398.76

    # Test constructor of KonserthusetPlayIE
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:11.117547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Unit test for KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:13.579576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor with no arguments
    try:
        KonserthusetPlayIE()
    except TypeError:
        print('Arguements missing')

# Generated at 2022-06-24 12:56:20.739106
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test of constructor of class KonserthusetPlayIE,
    to show how to use it, and check it's still working.
    """
    # @@: Need to update the input video ID here:
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(KonserthusetPlayIE.ie_key(), video_id)

# Generated at 2022-06-24 12:56:23.951320
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test for constructor of class KonserthusetPlayIE"""
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:56:27.052045
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('\nTesting class KonserthusetPlayIE\n')
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:39.283887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # URL for testing of extraction of information about video
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Expected information about video in JSON format

# Generated at 2022-06-24 12:56:40.814929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._download_json == ie._download_json

# Generated at 2022-06-24 12:56:45.899935
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE.KonserthusetPlayIE(url)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(url)

# Generated at 2022-06-24 12:56:47.830544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.ie_key()=='KonserthusetPlay'


# Generated at 2022-06-24 12:56:49.584137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:56:51.536343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:57:00.889267
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing constructor
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0].url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0].md5 == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0].info_dict.id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:57:08.618530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.suitable('http://www.konserthusetplay.se/') == False
    assert ie.suitable('http://www.konserthusetplay.se/?m=') == False
    assert ie.suitable('http://www.konserthusetplay.se/?m') == False

# Generated at 2022-06-24 12:57:10.074993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE_object = KonserthusetPlayIE()
    assert isinstance(KonserthusetPlayIE_object, InfoExtractor)

# Generated at 2022-06-24 12:57:11.040415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        return True

    return False

# Generated at 2022-06-24 12:57:12.131094
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:17.194521
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:19.595856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as e:
        assert False
    assert True

# Generated at 2022-06-24 12:57:21.279759
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()


# Generated at 2022-06-24 12:57:31.664472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'