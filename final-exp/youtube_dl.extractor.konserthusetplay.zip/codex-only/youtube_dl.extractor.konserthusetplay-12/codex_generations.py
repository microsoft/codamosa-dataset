

# Generated at 2022-06-24 12:47:34.352804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test basic constructor
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

    # Test valid URL
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    valid_url = ie._VALID_URL
    string_match = ie._match_id(test_url)
    match_object = ie._VALID_URL_RE.match(test_url)

    assert isinstance(valid_url, basestring)
    assert isinstance(string_match, basestring)
    assert isinstance(match_object,type(re.match('','string')))


# Generated at 2022-06-24 12:47:35.453344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:47:37.764833
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:47:43.238357
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    with pytest.raises(ExtractorError):
        KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:47:48.587781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    r"""
    Test for KonserthusetPlayIE
    """
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(KonserthusetPlayIE)
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:47:49.568176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert True


# Generated at 2022-06-24 12:47:51.425508
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:47:56.586611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    class_.working = True
    class_.ie_key = "KonserthusetPlay"
    class_.hosts = ["www.konserthusetplay.se","rspoplay.se"]
    from youtube_dl.extractor.youtube import YoutubeIE
    assert class_.ie_key != YoutubeIE.ie_key

# Generated at 2022-06-24 12:48:00.148602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE('No argument')
    except (AttributeError, NameError) as e:
        assert e.message == '__init__() takes at least 4 arguments (1 given)'
    except BaseException as e:
        assert e.message != '__init__() takes at least 4 arguments (1 given)'


# Generated at 2022-06-24 12:48:02.430674
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Test for KonserthusetPlayIE")
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:48:03.419411
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:04.033745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:08.208668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instantiation using simple url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    print(url)
    kp = KonserthusetPlayIE(url)
    assert kp.url == url

# Generated at 2022-06-24 12:48:16.775181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instances of class KonserthusetPlayIE
    kp_ie = KonserthusetPlayIE()

    assert(kp_ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

    # Create a new KonserthusetPlayIE instance
    kp_ie_new = KonserthusetPlayIE()

    assert(kp_ie_new._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')


# Generated at 2022-06-24 12:48:26.813732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    formats = ie._extract_m3u8_formats(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A', 'mp4',
        entry_protocol='m3u8_native', m3u8_id='hls', fatal=False)

# Generated at 2022-06-24 12:48:30.446628
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    e = KonserthusetPlayIE(url)
    assert type(e) == KonserthusetPlayIE
    assert e._match_id(url) == "CKDDnlCY-dhWAAqiMERd-A"


# Generated at 2022-06-24 12:48:38.276239
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:39.869807
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # check if class can be instantiated
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:41.171854
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_object = KonserthusetPlayIE()
    print (ie_object)

# Generated at 2022-06-24 12:48:41.971013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:46.083178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:49.425506
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:51.947086
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kPlay = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:54.335826
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test the constructor of KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_version() != ""

# Generated at 2022-06-24 12:49:00.500156
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = KonserthusetPlayIE._match_id(url)
    info = KonserthusetPlayIE._real_extract(KonserthusetPlayIE(), url)
    assert(video_id ==  info['id'])

# Generated at 2022-06-24 12:49:05.044730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:49:13.342830
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ test_KonserthusetPlayIE.py unit testing for class KonserthusetPlayIE """
    # Test valid url is picked up
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

    # Test invalid url is not picked up
    url = 'http://www.konserthusetplay.se/'
    ie = KonserthusetPlayIE(url)
    assert ie.video_id is None

# Generated at 2022-06-24 12:49:17.544288
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ''' Test of the Test the constructor for the class KonserthusetPlayIE.
    '''
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play = KonserthusetPlayIE()
    assert konserthuset_play

# Generated at 2022-06-24 12:49:19.319909
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for constructor of class KonserthusetPlayIE
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:49:29.700137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import os
    import youtube_dl
    ydl = youtube_dl.YoutubeDL(
        {'logger': YoutubeDLLogger(), 'outtmpl': '%(id)s.%(ext)s'})
    (entry1, entry2) = (
        YoutubeDL(ydl).extract_info(
            'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
            download=False
        ),
        YoutubeDL(ydl).extract_info(
            'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
            download=False
        )
    )

# Generated at 2022-06-24 12:49:31.577435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_video = KonserthusetPlayIE()
    assert isinstance(test_video, KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:37.992712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:41.499702
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:49:44.442442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor.__class__.__name__ == "KonserthusetPlayIE"


# Generated at 2022-06-24 12:49:45.666676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:47.078332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:52.587861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Tests whether the constructor raises an exception that is
    if the url is invalid.
    """
    ie = KonserthusetPlayIE();

    # Make sure the constructor raises an exception if the url is invalid
    not_valid_url = "http://www.google.com/"
    assert ie._real_extract(not_valid_url) == None


# Generated at 2022-06-24 12:49:54.689892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.ie_key() == 'konserthusetplay'

# Generated at 2022-06-24 12:49:56.278595
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #constructor should not raise any exceptions
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:06.447296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    INTERNET_EXPLORER_MOBILE_USER_AGENT = "Mozilla/5.0 (compatible; MSIE 10.0; Windows Phone 8.0; Trident/6.0; IEMobile/10.0; ARM; Touch; NOKIA; Lumia 620)"
    video_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    real_info = KonserthusetPlayIE()._real_extract(video_url)

    print('real_info:')
    print(real_info['formats'])
    print(real_info['subtitles'])
    print(real_info['title'])
    print(real_info['description'])
    print(real_info['thumbnail'])
    print

# Generated at 2022-06-24 12:50:11.035464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)
    assert type(KonserthusetPlayIE.__name__) is str
    assert len(KonserthusetPlayIE._VALID_URL) > 0
    assert len(KonserthusetPlayIE._TESTS) > 0


# Generated at 2022-06-24 12:50:12.173328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:14.496409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:16.500641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-24 12:50:19.584241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = "https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
  instance = InfoExtractor(url)
  print (instance)

# Generated at 2022-06-24 12:50:23.111366
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.ie_key() == 'KonserthusetPlay'
    assert KonserthusetPlayIE.ie_key() is KonserthusetPlayIE.ie_key()


# Generated at 2022-06-24 12:50:26.706720
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.get_url()

# Generated at 2022-06-24 12:50:30.929936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:35.074299
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert(isinstance(a, InfoExtractor))
    assert(repr(a) == '<KonserthusetPlayIE>')

# Generated at 2022-06-24 12:50:39.555502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:50:42.980095
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.media_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:51.754159
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:50:59.191225
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): #method needed to test
    # Arrange
    #x = 2
    y = 3
    ob = KonserthusetPlayIE() #instance of extractor class
    # Act
    #result = x + y
    ob.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") #call to method
    # Assert
    #assert result == 5

# Generated at 2022-06-24 12:51:01.253765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:51:02.191868
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:07.850795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert isinstance(konserthusetplay, KonserthusetPlayIE)
    assert isinstance(konserthusetplay.BASE_URL, unicode)
    assert isinstance(konserthusetplay.VALID_URL, unicode)
    assert isinstance(konserthusetplay.TEST, dict)

# Generated at 2022-06-24 12:51:09.212494
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_object = KonserthusetPlayIE()
    assert isinstance(ie_object, InfoExtractor)

# Generated at 2022-06-24 12:51:21.050519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:24.931292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE (KonserthusetPlayIE._VALID_URL)
    assert ie._match_id(KonserthusetPlayIE._VALID_URL)
    #assert ie._match_id(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-24 12:51:26.898250
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._downloader, KonserthusetPlayIE._VALID_URL)


# Generated at 2022-06-24 12:51:28.984760
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    k.KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:32.954100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:51:34.806933
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._TESTS.__len__() > 0

# Generated at 2022-06-24 12:51:36.277399
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global ie
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:39.590758
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert obj.title == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:51:41.578838
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # verify type of instance
    info_extractor = KonserthusetPlayIE()
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-24 12:51:45.912797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing constructor of class KonserthusetPlayIE")
    print("Running _real_extract")
    _real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:47.404915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-24 12:51:56.717194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

    assert(k._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:51:59.043830
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:09.552201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE

    k = KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-24 12:52:16.072200
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay:play'

# Generated at 2022-06-24 12:52:18.055251
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE().result()
    assert result is not None

# Generated at 2022-06-24 12:52:20.221848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:52:21.840092
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Generated at 2022-06-24 12:52:31.997497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE_mock = KonserthusetPlayIE(None)

    assert IE_mock._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:34.569806
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = ie.IE_NAME
    obj == ie.ie_key()
    ie = KonserthusetPlayIE(ie)
    obj == ie.ie_key()

# Generated at 2022-06-24 12:52:38.397578
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    match = KonserthusetPlayIE._VALID_URL
    validURL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert re.match(match, validURL)

# Generated at 2022-06-24 12:52:39.775806
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()


# Generated at 2022-06-24 12:52:40.840110
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:44.603131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case = KonserthusetPlayIE(InfoExtractor)
    # test_case.run()
    test_case.test('CKDDnlCY-dhWAAqiMERd-A')
    return test_case

# Generated at 2022-06-24 12:52:53.156944
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  from __main__ import KonserthusetPlayIE
  # test with example from _TESTS[0]
  test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
  konserhuset = KonserthusetPlayIE()
  
  # check expected output
  assert konserhuset._match_id(test_url) == 'CKDDnlCY-dhWAAqiMERd-A'



# Generated at 2022-06-24 12:52:56.011553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None)
    except NameError:
        pass
    else:
        raise AssertionError('Should raise NameError')


# Generated at 2022-06-24 12:53:03.695141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    
    # Create an instance of KonserthusetPlayIE
    ie = KonserthusetPlayIE() 
    
    # Test that the URL matches the pattern
    # The method will raise an error if no match is found
    match = ie._match_id(url)
    assert match == 'CKDDnlCY-dhWAAqiMERd-A'
    
    # Test the _real_extract method
    # The method will raise an error if no info_dict is returned
    info_dict = ie._real_extract(url)
    
    # Test for expected keys

# Generated at 2022-06-24 12:53:05.595769
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert type(info_extractor) == KonserthusetPlayIE


# Generated at 2022-06-24 12:53:08.810966
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Constructor
    ie = KonserthusetPlayIE(url)
    # run extractor
    ie.extract(url)

# Generated at 2022-06-24 12:53:17.288434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.name == 'konserthusetplay.se')
    assert(ie.ie_key() == 'konserthusetplay:play')
    assert(ie.supported_ie_key() == 'konserthusetplay:play')
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:53:25.360440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test unit for handling with KonserthusetPlayIE.
    """
    ##############################################################################################################

    # Case 1: test with playerconfig that does not have 'rtmp'.

# Generated at 2022-06-24 12:53:31.669637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'KonserthusetPlay and RadioSymphonyPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:53:32.677003
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/')

# Generated at 2022-06-24 12:53:40.882681
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:53:43.422763
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()
    assert e.name == 'Konserthuset'

# Generated at 2022-06-24 12:53:45.604501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE')


# Generated at 2022-06-24 12:53:53.810743
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Run tests on class KonserthusetPlayIE
    """
    kp = KonserthusetPlayIE()
    assert (kp.ie_key() == 'KonserthusetPlay')
    assert (kp.ie_desc() == 'KonserthusetPlay videos')
    assert (kp.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True)
    assert (kp.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True)
    assert (kp.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') == False)

# Generated at 2022-06-24 12:53:57.378275
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Checks if the url given to the constructor is the same url in the object created
    assert KonserthusetPlayIE(_VALID_URL)._VALID_URL == _VALID_URL


# Generated at 2022-06-24 12:54:02.075054
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # This function should just not throw any exception
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:54:09.339101
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KIE = KonserthusetPlayIE("")
    assert KIE.IE_NAME == "konserthusetplay"
    assert KIE.ie_key() == "KonserthusetPlay"
    assert KIE.host() == "konserthusetplay.se"
    assert KIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:54:10.303285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:12.214412
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(None), KonserthusetPlayIE)

# Generated at 2022-06-24 12:54:14.819591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testObj = KonserthusetPlayIE()
    assert testObj is not None

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:16.529513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-24 12:54:23.498866
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # taken from here: http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    # which is already in the test cases, below
    k = KonserthusetPlayIE()
    result = k._real_extract(
            'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# test for constructor of class KonserthusetPlayIE
test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:26.825928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    expected = "http://csp.picsearch.com/rest?containerId=mediaplayer&e=rQ2h1C-0ERmBAAOi_ZFd-w&i=object"
    actual = "https://www.konserthusetplay.se/?m=rQ2h1C-0ERmBAAOi_ZFd-w&t=2"
    t = KonserthusetPlayIE._real_extract(actual)
    assert t == expected
    print("Success")

# Generated at 2022-06-24 12:54:28.198667
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('', '')

# Generated at 2022-06-24 12:54:30.790889
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if not ie:
        raise Exception('Unit test for class KonserthusetPlayIE failed!')


# Generated at 2022-06-24 12:54:33.866601
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:37.430857
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """

    """
    unit_test_test = KonserthusetPlayIE()
    print("Unit test for constructor of class KonserthusetPlayIE has been implemented.")



# Generated at 2022-06-24 12:54:46.956481
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    q = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:54:52.241110
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False, "Check for class KonserthusetPlayIE instantiation with no parameters"
    else:
        assert True, "Check for class KonserthusetPlayIE instantiation with no parameters"


# Generated at 2022-06-24 12:54:53.612301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    player = KonserthusetPlayIE()
    assert player

# Generated at 2022-06-24 12:54:57.053028
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # URL for test case = http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw
    # ie = KonserthusetPlayIE({})
    # assert ie is not None
    pass

# Generated at 2022-06-24 12:54:57.728646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:58.585366
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Constructor test"""
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:00.042806
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert InfoExtractor.__name__ == 'InfoExtractor'


# Generated at 2022-06-24 12:55:01.574085
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:55:12.283411
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    IE._match_id('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    IE._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    IE._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    IE._match_id('http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:13.287048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(downloader = None)

# Generated at 2022-06-24 12:55:18.938803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = KonserthusetPlayIE._build_regex(ie._VALID_URL)
    assert obj.search('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    obj = KonserthusetPlayIE._build_regex(ie._VALID_URL)
    assert obj.search('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:55:19.568633
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:23.520809
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(url)


# Generated at 2022-06-24 12:55:31.810719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	u = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	download_url = 'https://play.konserthusetsj.se/api/stream/get?cspId=1&containerId=mediaplayer&e=oTCPldGk-dVZWgAad_7Vqg&id=CKDDnlCY-dhWAAqiMERd-A&provider=mp4&objectId=CKDDnlCY-dhWAAqiMERd-A&area=1&quality=high'
	source_url = 'https://play.konserthusetsj.se/api/media/get/m/CKDDnlCY-dhWAAqiMERd-A'
	constructor = Konserthus

# Generated at 2022-06-24 12:55:33.627432
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE()
	assert ie



# Generated at 2022-06-24 12:55:34.693510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert (True, "Testing constructor of class KonserthusetPlayIE")


# Generated at 2022-06-24 12:55:37.339089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Constructor of class KonserthusetPlayIE")
    konserthisetPlayIE = KonserthusetPlayIE()


test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:38.353521
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:47.361739
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:49.109300
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:56.050697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == "(?P<id>[^&]+)"
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:56:06.044747
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    def assert_equal(value1, value2, message=None):
        if value1 != value2:
            raise Exception('%s != %s' % (value1, value2))
    e = KonserthusetPlayIE()
    assert_equal(e._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert_equal(len(e._TESTS), 2)
    assert_equal(e._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'], 'CKDDnlCY-dhWAAqiMERd-A')
    assert_equal

# Generated at 2022-06-24 12:56:16.901397
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Constructor test of class KonserthusetPlayIE"""
    # Positive case
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable == staticmethod(
        lambda url: False if KonserthusetPlayIE._VALID_URL.match(url) is None else True)
    assert ie.url_re == KonserthusetPlayIE._VALID_URL
    assert ie.supported_domains == ['konserthusetplay.se']

    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_webpage_handle')
    assert hasattr(ie, '_download_json')
    assert has

# Generated at 2022-06-24 12:56:18.050640
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:56:20.081471
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:27.957946
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    test_urls = [
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
    ]
    for test_url in test_urls:
        print("Testing KonserthusetPlayIE with URL " + test_url)
        match = extractor._VALID_URL.match(test_url)
        if match:
            extractor._real_extract(test_url)
        else:
            print("URL did not match")
            assert(False)


# Generated at 2022-06-24 12:56:30.390736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:56:30.963289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:34.210677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:43.063767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_cases = {'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A': 'CKDDnlCY-dhWAAqiMERd-A',
                  'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw': 'elWuEH34SMKvaO4wO_cHBw',
                  'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw': 'elWuEH34SMKvaO4wO_cHBw'}

    kp = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:45.260705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test to verify that KonserthusetPlayIE is created
    """
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:56:46.288170
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('bristol')

# Generated at 2022-06-24 12:56:47.777745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie != None

# Generated at 2022-06-24 12:56:51.237490
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlayIE', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:52.662940
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, type)



# Generated at 2022-06-24 12:56:56.397956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:56:57.553777
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE(None)
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:56:59.630443
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:57:00.974321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Generated at 2022-06-24 12:57:04.448824
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(determine_ext('http://www.konserthusetplay.se/?m=mdU6QRU40hzlPwgATxhJnw') == 'flv')

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:08.243734
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiate KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Check if the instance is an instance of InfoExtractor class
    assert ie.__class__ == InfoExtractor

# Generated at 2022-06-24 12:57:08.950441
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:09.723558
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check for initialisation
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:13.560639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:57:17.310836
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    downloader = KonserthusetPlayIE(url)
    assert downloader != None, "Can't create object of class KonserthusetPlayIE"


# Generated at 2022-06-24 12:57:18.638899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:21.430705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for constructor of class KonserthusetPlayIE.
    """
    k = KonserthusetPlayIE()
    assert k

# Generated at 2022-06-24 12:57:23.676808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Checks if the class constructor is able to create an object of the class KonserthusetPlayIE
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:24.466118
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();

# Generated at 2022-06-24 12:57:26.283894
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import KonserthusetPlayIE
    assert(KonserthusetPlayIE.KonserthusetPlayIE)


# Generated at 2022-06-24 12:57:37.072247
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Example of url to be tested
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # object instantiation
    konserthusetplay = KonserthusetPlayIE()
    # We test if it's an instance of the right class
    assert isinstance(konserthusetplay, KonserthusetPlayIE)
    # check of type of object (returns a dictionary)
    extractor = konserthusetplay.extract(test_url)
    assert isinstance(extractor, dict)
    # Test of the return of a non-empty dictionary
    assert extractor != {}
    # test if the dictionary contains all the keys in the list below