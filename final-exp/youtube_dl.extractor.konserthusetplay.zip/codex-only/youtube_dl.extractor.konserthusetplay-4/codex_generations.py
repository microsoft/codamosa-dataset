

# Generated at 2022-06-24 12:47:28.426323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:29.503112
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:47:32.178620
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None

# Generated at 2022-06-24 12:47:34.469533
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Comment out for now due to flaky test
    # ie = KonserthusetPlayIE()
    assert(True)
    return

# Generated at 2022-06-24 12:47:38.546894
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.get_info_extractor() == ie
    assert ie.get_info_extractor().get_class() == ie.get_class()


# Generated at 2022-06-24 12:47:39.548254
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE)

# Generated at 2022-06-24 12:47:42.939023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for creation of instance of class KonserthusetPlayIE
    This should not throw any exception
    """
    KonserthusetPlayIE('test:test')

# Generated at 2022-06-24 12:47:50.511921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract(valid_url)
    # ie.extract(invalid_url)


valid_url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
invalid_url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&blabla'

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:59.981722
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:48:04.558215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # pylint: disable=unused-variable
    # pylint: disable=attribute-defined-outside-init
    # pylint: disable=attribute-defined-outside-init
    # pylint: disable=attribute-defined-outside-init

    # Initialize class object
    instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:06.375524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert KonserthusetPlayIE
    except NameError:
        assert False

# Generated at 2022-06-24 12:48:07.774983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()
    return


# Generated at 2022-06-24 12:48:12.184711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Test for constructor of class KonserthusetPlayIE")

    ke = KonserthusetPlayIE()
    print("test 1: ", ke._VALID_URL)
    print("test 2: ", ke._TESTS)
    print("test 3: ", ke._download_json)

# Generated at 2022-06-24 12:48:14.822711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check if we can construct a KonserthusetPlayIE

    # Arrange
    test_object = KonserthusetPlayIE(InfoExtractor())

    # Assert
    assert test_object is not None

# Generated at 2022-06-24 12:48:18.183183
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Test to make sure that tests is not empty

# Generated at 2022-06-24 12:48:27.700382
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(url, video_id)
    e = ie._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

# Generated at 2022-06-24 12:48:29.635679
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('https://www.konserthuset.se/')
    assert(k.ie_key() == 'KonserthusetPlay')


# Generated at 2022-06-24 12:48:40.775044
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:42.013739
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE();
    assert instance;

# Generated at 2022-06-24 12:48:45.657571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance.ie_key() == 'KonserthusetPlay'
    assert instance.ie_name() == 'konserthusetplay'
    assert instance.ie_version()

# Generated at 2022-06-24 12:48:50.595716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    instance.suitable('KonserthusetPlayIE')

# Generated at 2022-06-24 12:48:53.868765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(None)
    assert isinstance(obj, KonserthusetPlayIE)
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj._TESTS is not None

# Generated at 2022-06-24 12:48:56.810375
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key() == 'rspoplay'

# Generated at 2022-06-24 12:49:04.233870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #print "Testing_KonserthusetPlayIE"
    test_KonserthusetPlayIE = KonserthusetPlayIE()
    assert(test_KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")
    assert(test_KonserthusetPlayIE._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967")

# Generated at 2022-06-24 12:49:05.444746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:49:08.439509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE("KonserthusetPlay")
    assert konserthuset_play_ie.name == "KonserthusetPlay"

# Generated at 2022-06-24 12:49:15.353607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # # initialize an object to test
    ie = KonserthusetPlayIE("")
    # # check if the object is initialized correctly
    assert hasattr(ie, "url")
    assert hasattr(ie, "_VALID_URL")
    # # check if url is initialized correctly
    assert ie.url == ""
    assert ie._VALID_URL == ""
    # # check if test code is correct
    assert ie.test(url="") == {}
    assert ie.test(url="https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") is not None

# Generated at 2022-06-24 12:49:19.219131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(InfoExtractor('KonserthusetPlayIE', {}))
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-24 12:49:21.407992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:49:31.356853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # First test
    test1 = KonserthusetPlayIE()
    assert test1._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Second test
    test2 = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:32.232618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:38.719135
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    def _mocked_extract(self, url):
        return
    import sys
    import types
    KonserthusetPlayIE.extract = types.MethodType(_mocked_extract, KonserthusetPlayIE)
    # obj = KonserthusetPlayIE() # Should pass
    obj = KonserthusetPlayIE('') # Should pass
    obj = KonserthusetPlayIE(video_id) # Should pass

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:39.825520
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:42.752151
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    InfoExtractor.test('KonserthusetPlayIE', KonserthusetPlayIE)

# Unit tests for methods of class KonserthusetPlayIE

# Generated at 2022-06-24 12:49:46.877869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
# end of test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:48.920992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:50:00.536387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from KonserthusetPlayIE import KonserthusetPlayIE
    from test.test_utils import print_info
    from validator import Validator

    # Instantiate the class KonserthusetPlayIE
    kpi = KonserthusetPlayIE()
    # Set the video_id for the tests
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    # Set URL to validate
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Call the internal _real_extract method
    result = kpi._real_extract(url)
    # Validate result
    v = Validator()
    v.validate_video_info(result)

# Generated at 2022-06-24 12:50:09.100419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # The KonserthusetPlayIE object should have the following attributes
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'Konserthusetplay:play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.extract == KonserthusetPlayIE._real_extract

# Generated at 2022-06-24 12:50:10.602271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Generated at 2022-06-24 12:50:15.562669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:24.836801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if not KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").get_video().get('title') == 'Orkesterns instrument: Valthornen':
        raise Exception("KonserthusetPlayIE constructor failed")
        
    if not KonserthusetPlayIE("https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").get_video().get('title') == 'Orkesterns instrument: Valthornen':
        raise Exception("KonserthusetPlayIE constructor failed")

if __name__ == '__main__':
	test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:35.547594
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from ... import _download_json, _download_webpage, _extract_m3u8_formats, _match_id, _search_regex, _sort_formats, determine_ext, url_or_none
    ie = KonserthusetPlayIE()
    assert ie.get_url_re() == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.get_host() == 'www.konserthusetplay.se'
    assert ie.get_domain() == 'rspoplay.se'
    assert ie.get_module() == 'konserthusetplay'

# Generated at 2022-06-24 12:50:42.359581
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:45.376019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:48.833591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert type(KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')) == KonserthusetPlayIE



# Generated at 2022-06-24 12:51:00.764678
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Input url and expected values
    expected_values = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }

    # Check if the constructor instantiates correctly
    assert KonserthusetPlayIE(url), "KonserthusetPlayIE.__init__() was not called"

# Generated at 2022-06-24 12:51:06.342844
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE.
    """
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    kp = KonserthusetPlayIE(url)

    assert kp.title == 'Orkesterns instrument: Valthornen'
    assert kp.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert kp.url == url

# Generated at 2022-06-24 12:51:11.794064
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # Fails
    # ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(KonserthusetPlayIE.ie_key())
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:51:13.043528
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None

# Generated at 2022-06-24 12:51:18.434501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    try:
        assert ie.match_url(url)
    except:
        print("AssertionError in KonserthusetPlayIE")
        return False
    return True

# Generated at 2022-06-24 12:51:20.004836
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:21.459367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL is not None

# Generated at 2022-06-24 12:51:22.509752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:51:23.773662
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except BaseException as e:
        print(e.message)
        



# Generated at 2022-06-24 12:51:34.265912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Initialize KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Call _real_extract method
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Check for returned values
    assert ie.formats[0]['url'] == 'rtmp://playback.sap.picsearch.com/playback'
    assert ie.subtitles['sv'][0]['url'] == 'http://d3gqasl9vmjfd8.cloudfront.net/56a35fc6-f492-4a0e-8b5d-305c7a305056.vtt'

# Generated at 2022-06-24 12:51:38.891918
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('KonserthusetPlay', 'RSpoplay.se', 'KonserthusetPlay')
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.host() == 'RSpoplay.se'

# Generated at 2022-06-24 12:51:44.616353
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # First part of the test is to test the constructor of class KonserthusetPlayIE
    # In this part the information that is entered into the constructor of class
    # KonserthusetPlayIE should be checked.

    # The url that is going to be used during the tests
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Expected value of attribute ie_key (underscore will be appended)
    ie_key = 'KonserthusetPlay'

    # Expected value of attribute ie_id (underscore will be appended)
    ie_id = 'konserthusetplay'

    # Expected value of attribute _VALID_URL

# Generated at 2022-06-24 12:51:47.710651
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('className')
    assert isinstance(ie, KonserthusetPlayIE)
    print('Unit test passed')


# Generated at 2022-06-24 12:51:49.127082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:51:50.937841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:51:59.104032
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:02.684082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    # testing the get_type method
    assert konserthusetplay_ie.get_type() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:05.213518
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create instance of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    #print(repr(ie))

# Generated at 2022-06-24 12:52:06.895267
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(ie)

# Generated at 2022-06-24 12:52:14.097421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    obj_test = KonserthusetPlayIE()
    # Testing for get_id( url )
    url_test = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    id_test = "CKDDnlCY-dhWAAqiMERd-A"
    assert obj_test.get_id(url_test) == id_test

    # Testing for extract( url )
    url_test = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:52:15.467312
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    pass

# Generated at 2022-06-24 12:52:26.729178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:27.702058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:52:33.255089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest
    class KonserthusetPlayIETest(unittest.TestCase):

        def setUp(self):
            self.konserthusetplayIE = KonserthusetPlayIE()

        def test_class_instantiation(self):
            self.assertIsInstance(self.konserthusetplayIE, KonserthusetPlayIE)

    unittest.main(module=__name__)

# Generated at 2022-06-24 12:52:35.594071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:38.922543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)



# Generated at 2022-06-24 12:52:41.384152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.extract(url)
    # print(ie._TESTS)

# Generated at 2022-06-24 12:52:49.513119
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing for creating a new KonserthusetPlayIE
    ie = KonserthusetPlayIE('test')
    assert ie.name == 'test'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key_type() == 'url_transparent'
    assert ie.host() == 'rspoplay.se'
    assert ie.url_result(ie._VALID_URL, video_id=ie._VALID_URL.split('=')[1])


# Generated at 2022-06-24 12:52:50.648604
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-24 12:52:52.458585
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # Checks constructor works with KonserthusetPlayIE.
        KonserthusetPlayIE("")
    except:
        assert False
    assert True

# Generated at 2022-06-24 12:53:02.204660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:07.427233
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tester = KonserthusetPlayIE()
    url = tester.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert url, "URL is valid"
    url = tester.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-B")
    assert not url, "URL is invalid"

# Generated at 2022-06-24 12:53:18.758680
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS
    # Unit test for method _real_extract of class KonserthusetPlayIE
    url_test = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id_test = 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:53:21.046478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:28.459690
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # valid video id
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    # invalid video id
    bad_id = 'CKDDnlCY-dhWAAqiMERd-I'

    ie = KonserthusetPlayIE()
    
    assert ie._match_id(url) == video_id
    assert ie._match_id('') is None
    assert ie._match_id(url.replace(video_id, bad_id)) != bad_id


# Generated at 2022-06-24 12:53:34.465691
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:53:45.042487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = KonserthusetPlayIE()._real_extract(test_url)
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A', "id is not equal to its expected value: 'CKDDnlCY-dhWAAqiMERd-A'"
    assert result['title'] == 'Orkesterns instrument: Valthornen', "title is not equal to its expected value: 'Orkesterns instrument: Valthornen'"
    formats = result['formats']
    for f in formats:
        assert f['url'].startswith('rtmp://'), "formats url did not start with 'rtmp://'"



# Generated at 2022-06-24 12:53:47.495466
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance_KonserthusetPlayIE = KonserthusetPlayIE()
    instance_KonserthusetPlayIE._extract_url()

# Generated at 2022-06-24 12:53:53.266205
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:05.665000
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	kp_ie = KonserthusetPlayIE()
	
	with open('../test_data/konserthusetplay.json') as data_file:    
		json_data = json.load(data_file)
	
	kp_ie._download_json = lambda url, video_id, note='Downloading JSON metadata', errnote='Unable to download JSON metadata', transform_source=None, fatal=True: json_data

	page = kp_ie._download_webpage = lambda url, video_id: url

	info = kp_ie._real_extract(page)

	assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
	assert info['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:54:08.245592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k
    assert k._real_extract
    assert k._VALID_URL
    assert k._TESTS

# Generated at 2022-06-24 12:54:09.167378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:20.761512
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthuset_play'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.BR_VALID()
    assert ie._API_URL == 'http://csp.picsearch.com'
    assert ie._VALID_URL_RE == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:24.434883
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_object = InfoExtractor()
    assert test_object.get_info_extractor(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A').extract

# Generated at 2022-06-24 12:54:28.880312
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:54:31.073775
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for constructor of class KonserthusetPlayIE
    """
    info_extractor = KonserthusetPlayIE()
    assert info_extractor

# Generated at 2022-06-24 12:54:42.039427
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    # Check if class parameters have been initialized properly
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:50.032811
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:54:53.201991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert extractor.ie_key() == 'KonserthusetPlay'
    assert extractor.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert extractor.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') == False

# Generated at 2022-06-24 12:54:54.955900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:01.637610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for KonserthusetPlayIE.
    """
    import os, sys
    sys.path.append(os.path.join(os.path.dirname(__file__), "..", "..", ".."))
    from ytdl.extractor import KonserthusetPlayIE

    # KonserthusetPlayIE.__init__(self)
    instance = KonserthusetPlayIE()
    instance._real_initialize()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:13.904414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:15.140592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    unit test for constructor of class KonserthusetPlayIE
    """
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:16.110974
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:26.777116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test for instanciation of class
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:28.159307
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'

# Generated at 2022-06-24 12:55:29.582822
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:40.329682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Declare test sample
    sample = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Initialize KonserthusetPlayIE instance
    KonserthusetPlayIE()

    # Get video web page
    webpage = KonserthusetPlayIE()._download_webpage(sample, 'CKDDnlCY-dhWAAqiMERd-A')

    # Get "e" parameter
    e = KonserthusetPlayIE()._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

    # Get REST API call result

# Generated at 2022-06-24 12:55:41.296550
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE


# Generated at 2022-06-24 12:55:42.085129
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:43.657976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp_ie = KonserthusetPlayIE()
    assert kp_ie is not None

# Generated at 2022-06-24 12:55:46.192389
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Constructor should return an instance of KonserthusetPlayIE"""
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:55:53.634205
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, KonserthusetPlayIE._TESTS)
    assert ie._match_id(KonserthusetPlayIE._TESTS[0]['url']) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id(KonserthusetPlayIE._TESTS[1]['url']) == 'elWuEH34SMKvaO4wO_cHBw'
    assert ie._real_extract(KonserthusetPlayIE._TESTS[0]['url'])['title'] == 'Orkesterns instrument: Valthornen'
# End

# Generated at 2022-06-24 12:56:04.409802
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.suitable(None, url=None) is False
    assert obj.suitable(None, url='http://www.youtube.com/watch?v=BaW_jenozKc') is False
    assert obj.suitable(None, url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') is True
    assert obj.suitable(None, url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') is True
    assert obj.working() is True
    assert obj.extract(None, url=None) is None

# Generated at 2022-06-24 12:56:05.363232
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:13.087843
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    media_id = 'CKDDnlCY-dhWAAqiMERd-A'

    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie.video_id == media_id
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:15.212294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:26.509028
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:27.531604
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-24 12:56:29.323220
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    my_object_ie = KonserthusetPlayIE()
    assert my_object_ie.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-24 12:56:32.521397
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:35.475053
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None, None)
    except TypeError:
        return True
    return False

# Generated at 2022-06-24 12:56:43.439107
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Define a test case
    info_dict = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }

    # Instantiate objects with the test case
    konserthusetplayIE = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:45.213314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if constructor of class KonserthusetPlayIE exists
    test_ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:50.802798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    # test _VALID_URL
    assert(ie._VALID_URL)
    # test _TESTS
    assert(ie._TESTS)
    # test _real_extract
    # test _match_id
    assert(ie._match_id)

# Generated at 2022-06-24 12:56:54.139921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:56:58.184752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:57:01.797761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of KonserthusetPlayIE using the arguments of the test case
    kon = KonserthusetPlayIE()

    assert isinstance(kon, KonserthusetPlayIE), "kon is not an instance of class KonserthusetPlayIE"
    assert type(kon) == KonserthusetPlayIE, "kon is not an instance of class KonserthusetPlayIE"

# Generated at 2022-06-24 12:57:04.369780
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:11.467452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie.suitable(url)
    assert konserthusetplay_ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplay_ie._VALID_URL == "http://www.konserthusetplay.se/?m=(?P<id>[^&]+)".strip()
    dict = {'m': 'CKDDnlCY-dhWAAqiMERd-A'}

# Generated at 2022-06-24 12:57:12.854379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:57:13.426808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:20.970276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:57:21.981370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:23.058186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:25.427872
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor test
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:32.186451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(0)
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_extract_m3u8_formats')
    assert hasattr(ie, '_sort_formats')


# test url: https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
# test fields are:
# title
# description
# formats
# id
# duration
# duration (converted from ms to s)
# subtiles
# thumbnail