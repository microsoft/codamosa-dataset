

# Generated at 2022-06-24 12:47:30.488585
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of the class KonserthusetPlayIE
    obj = KonserthusetPlayIE()
    # Assert that class is of type InfoExtractor
    assert(isinstance(obj, InfoExtractor))

# Generated at 2022-06-24 12:47:35.200512
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    instance = KonserthusetPlayIE()
    instance._match_id(url)
    instance._real_extract(url)

# Generated at 2022-06-24 12:47:46.373106
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:48.965246
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Standard constructor for class
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-24 12:47:50.696470
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'

# Generated at 2022-06-24 12:47:53.138368
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUCCESS == ie.IE_NAME

# Generated at 2022-06-24 12:47:58.662966
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_cases = [
        {"url": "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"},
        {"url": "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"},
    ]

    for test_case in test_cases:
        assert KonserthusetPlayIE._VALID_URL == KonserthusetPlayIE._match_id(
            test_case["url"])

# Generated at 2022-06-24 12:48:08.696147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie=KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.ie_key() == 'KonserthusetPlay:play'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')



# Generated at 2022-06-24 12:48:10.757693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:48:13.966516
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().IE_NAME == 'konserthusetplay'
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Unit tests for the extractor

# Generated at 2022-06-24 12:48:15.214658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:48:16.471599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:17.821508
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:19.454856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-24 12:48:21.674733
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.server_is_up()
    ie.get_best_title()

# Generated at 2022-06-24 12:48:27.532519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:37.241199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Make the browser get the webpage
    ie._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                         'CKDDnlCY-dhWAAqiMERd-A')
    # Get the video id
    video_id = ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Assert that the video id is OK
    assert video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    # Get

# Generated at 2022-06-24 12:48:39.198434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:48:40.111739
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:41.040128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:48:46.134717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ test for constructor of class KonserthusetPlayIE """

    # This test checks if video can be downloaded with KonserthusetPlayIE
    from ..utils import fake_http_response_from_file
    from .common import ExpectTest

    with ExpectTest(expected=ValueError):
        KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, None)

# Generated at 2022-06-24 12:48:49.425496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:52.748906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(obj)

# Generated at 2022-06-24 12:48:55.583421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE()
	assert ie is not None
	assert ie._VALID_URL is not None
	assert ie._TESTS is not None


# Generated at 2022-06-24 12:48:57.925147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:49:06.927859
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert('KonserthusetPlay' in ie._downloader.IE_NAME)
    assert(ie.IE_NAME == 'KonserthusetPlay')
    assert(ie.IE_DESC == 'Konserthuset Play and Radiosymfonikernas Play')
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:49:15.969639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor
    obj = KonserthusetPlayIE()
    obj = KonserthusetPlayIE(obj)
    obj = KonserthusetPlayIE(KonserthusetPlayIE)
    # Verify that it is an instance of KonserthusetPlayIE
    from youtube_dl.extractor.konserthusetplay import KonserthusetPlayIE
    assert(isinstance(obj, KonserthusetPlayIE))
    # Verify that it inherits from InfoExtractor
    from youtube_dl.extractor import InfoExtractor
    assert(issubclass(KonserthusetPlayIE, InfoExtractor))
    # Verify that it is registered in InfoExtractor's registry

# Generated at 2022-06-24 12:49:19.120001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:49:20.442158
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj_test = KonserthusetPlayIE()
    print(obj_test)

# Generated at 2022-06-24 12:49:30.664955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:33.557707
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj._real_extract("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")


# Generated at 2022-06-24 12:49:38.683596
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # 1.
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie is not None

    # 2.
    # konserthuset_play_ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # assert konserthuset_play_ie is not None



# Generated at 2022-06-24 12:49:49.909798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    _, class_name, test_cases = ie._download_json(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A')
    assert class_name == 'KonserthusetPlayIE'
    assert len(test_cases) == 1
    assert test_cases[0]['url'] == url
    assert test_cases[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:49:52.328406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test that we can create an instance of KonserthusetPlayIE.
    """
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:59.686971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    (KonserthusetPlayIE._VALID_URL,
     KonserthusetPlayIE._TESTS) = (
        KonserthusetPlayIE._TESTS[0]['url'],
        KonserthusetPlayIE._TESTS[:1])
    for test in KonserthusetPlayIE._TESTS:
        yield(KonserthusetPlayIE._test_valid_url, test['url'], test['md5'])

# Generated at 2022-06-24 12:50:08.573602
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:14.994409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.set_downloader(None)
    if ie._VALID_URL == '':
        raise AssertionError('_VALID_URL cannot be empty at this point')
    if ie._downloader is not None:
        raise AssertionError('Did not expect a downloader at this point')

# Generated at 2022-06-24 12:50:16.269984
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:25.779335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:36.165384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:39.877325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'):
        print('It truly is!')

# Generated at 2022-06-24 12:50:43.299511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('','')
    assert ie != None
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.IE_DESC == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:48.974239
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:53.725752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for KonserthusetPlayIE

    To run the unit test for this class, run the following command:
        python -m unittest -v tests.extractors.konserthusetplay
    """

    assert KonserthusetPlayIE.__name__ == "KonserthusetPlayIE"

# Generated at 2022-06-24 12:50:59.963178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Unit testing of class KonserthusetPlayIE """
    test_obj = KonserthusetPlayIE()
    print(test_obj)
    # Test '_real_extract'
    print(test_obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))

# Generated at 2022-06-24 12:51:01.448125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test construction of class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:06.790235
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    string = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert r'^http://www.konserthusetplay.se/\?.*\bm=CKDDnlCY-dhWAAqiMERd-A$' == KonserthusetPlayIE._VALID_URL
    assert 'CKDDnlCY-dhWAAqiMERd-A' == KonserthusetPlayIE._match_id(string)


# Generated at 2022-06-24 12:51:10.390323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._VALID_URL == IE_DESC[1]['url']
    assert ie._TESTS == []

# Generated at 2022-06-24 12:51:19.209778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:51:20.423420
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:21.025038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL

# Generated at 2022-06-24 12:51:29.652342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)' # noqa
    assert ie.match_url(url) == 'elWuEH34SMKvaO4wO_cHBw'
    assert ie.SUBTITLE_FORMATS == []
    assert ie.SUFFIX_REGEX == '_(?P<asset_id>[^_]+)_h264m\.mp4'

# Generated at 2022-06-24 12:51:31.552426
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(type(KonserthusetPlayIE()) is KonserthusetPlayIE)

# Generated at 2022-06-24 12:51:37.150856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == "KonserthusetPlay"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:51:38.892563
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    Konserthus = KonserthusetPlayIE(None)
    assert Konserthus is not None

# Generated at 2022-06-24 12:51:44.590127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with a short video
    short_video_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    short_video_IE_obj = KonserthusetPlayIE()._real_extract(short_video_url)
    assert short_video_IE_obj['duration'] == 398.76
    assert short_video_IE_obj['subtitles'] == {}
    assert short_video_IE_obj['title'] == 'Orkesterns instrument: Valthornen'
    assert len(short_video_IE_obj['formats']) == 0

    # Test with a long video
    # Generated from http://www.konserthusetplay.se/?m=D9R6NnCY-dhWAAqg

# Generated at 2022-06-24 12:51:45.587938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-24 12:51:49.510207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:51:56.516428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #Checks if the class matches the given url and if it can be created
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    IE = KonserthusetPlayIE(url)
    assert "www.konserthusetplay.se" in IE.url
    assert "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A" in IE.url
    assert IE.url != ""
    assert IE.url != None


# Generated at 2022-06-24 12:52:07.485709
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    unit_test = KonserthusetPlayIE()

    assert unit_test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:52:08.358890
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:52:12.250446
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:13.261260
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();

# Generated at 2022-06-24 12:52:15.125475
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:16.276474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:19.770350
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:21.840388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie

# Generated at 2022-06-24 12:52:24.739359
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    info = ie.extract(url)
    print(info)

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:31.106867
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'konserthusetplay.se'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == False
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True

# Generated at 2022-06-24 12:52:38.919413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test.name == 'konserthusetplay'
    assert test.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert test.title == 'Orkesterns instrument: Valthornen'
    assert test.description == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert test.duration == 398.76
    assert test.id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert test.media_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert test.ext == 'mp4'

# Generated at 2022-06-24 12:52:42.519969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:47.859719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert KonserthusetPlayIE._TESTS[0]['url']
        assert KonserthusetPlayIE._TESTS[0]['md5']
        assert KonserthusetPlayIE._TESTS[0]['info_dict']
    except ValueError:
        return False
    return True


# Generated at 2022-06-24 12:52:49.835004
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from ..utils import TestCase
    TestCase.test_constructor(KonserthusetPlayIE)

# Generated at 2022-06-24 12:52:55.147400
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test the class KonserthusetPlayIE, which downloads videos on the
    website www.konserthusetplay.se and www.rspoplay.se
    """

    obj = KonserthusetPlayIE()
    # Test that the object is an instance of the class InfoExtractor
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 12:53:04.145423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    konserthuset_play_ie = KonserthusetPlayIE()
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Act
    result = konserthuset_play_ie.suitable(url)
    result = konserthuset_play_ie.extract(url)

    # Assert
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'

# Generated at 2022-06-24 12:53:06.004927
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    K = KonserthusetPlayIE()
    K._real_initialize()
    K._real_extract(url)

# Generated at 2022-06-24 12:53:08.500428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert True

# Generated at 2022-06-24 12:53:11.058323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.IE_NAME == 'konserthusetplay')

# Generated at 2022-06-24 12:53:12.165869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:22.084342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:22.954207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:27.111693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Constructor test
    """
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:53:29.848248
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Constructor unit test
if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:30.998384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-24 12:53:32.409965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE._TESTS[0]


# Generated at 2022-06-24 12:53:38.613947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    valid_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    invalid_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-B'
    assert KonserthusetPlayIE._VALID_URL == valid_url, 'Unit test failed!'
    assert KonserthusetPlayIE._VALID_URL != invalid_url, 'Unit test failed!'

# Generated at 2022-06-24 12:53:43.730312
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:53:52.960090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:55.758760
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert konserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:53:57.219011
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing constructor without any argument
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:54:04.983014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:08.000243
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:12.158252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    #
    # Constructing the regex to match the URL
    #
    try:
        ie._VALID_URL
    except AttributeError:
        assert False, 'The regexp to match URLs is not defined'
    else:
        assert True

    return

# Generated at 2022-06-24 12:54:20.133529
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.url =='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.extract_id() == 'CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-24 12:54:22.046482
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from . import konserthusetplay_klass
    k = konserthusetplay_klass.KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:32.632967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL(
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not KonserthusetPlayIE()._VALID_URL(
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        # TODO: remove this next line once this issue (
        # https://github.com/rg3/youtube-dl/issues/11304) is resolved
        # this line is needed to bypass the URL check that doesn't consider
        # the proper base URL
        ie='youtube')

# Generated at 2022-06-24 12:54:43.400875
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()

    assert ie.suitable(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:49.090536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('KonserthusetPlay', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A').suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert KonserthusetPlayIE('KonserthusetPlay', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A').suitable('http://www.fakenonserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == False

# Generated at 2022-06-24 12:54:59.748470
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=([^&]+)'
    # Test got regex match
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    id = ie._match_id(url)
    assert id == 'CKDDnlCY-dhWAAqiMERd-A'
    # Test can't got regex match
    url = 'https://example.com/media/CKDDnlCY-dhWAAqiMERd-A'
    id = ie._match_id(url)
    assert id is None

# Generated at 2022-06-24 12:55:06.391715
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = KonserthusetPlayIE()._real_extract(test_url)
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['thumbnail'] == 'https://static.picsearch.com/client/assets/img/default_thumbnail.png'
    assert result['duration'] == 398.76

# Generated at 2022-06-24 12:55:07.437711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:10.445560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:55:13.472237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:55:20.498116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if KonserthusetPlayIE(InfoExtractor) is constructed correctly.
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.__doc__ == KonserthusetPlayIE.__doc__
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.server == 'Picsearch'
    assert ie.headers == {
        'User-Agent': 'Wget/1.11.4'
    }
    assert ie._GEO_COUNTRIES == ['SE']
    assert ie._NETRC_MACHINE == 'konserthusetplay'

# Generated at 2022-06-24 12:55:25.377345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests the case when the video is available on rspoplay.se.
    url = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-24 12:55:34.161131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test cases for class KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    # Test Data
    test_data = {
        'id':'CKDDnlCY-dhWAAqiMERd-A', 
        'ext':'mp4', 
        'title':'Orkesterns instrument: Valthornen', 
        'description':'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail':'re:^https?://.*$', 
        'duration':398.76,
    }
    

# Generated at 2022-06-24 12:55:36.026265
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'


# Generated at 2022-06-24 12:55:45.393878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE()._real_extract({'url': 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'})

    # Tests if different video has same constructor
    video2 = KonserthusetPlayIE()._real_extract({'url': 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'})

    assert video["id"] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert video["title"] == 'Orkesterns instrument: Valthornen'
    assert video["description"] == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert video

# Generated at 2022-06-24 12:55:47.120261
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:55:50.088884
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_tests = ie.get_testcases() 
    print(ie_tests)

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:56.576763
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:06.291077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:11.985786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:13.038560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:14.004328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:56:15.694483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None, None)
    except:
        assert False
    assert True

# Generated at 2022-06-24 12:56:23.682412
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    obj._real_extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    print('Test success')

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:24.567529
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:25.796513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserhuset = KonserhusetPlayIE()

# Generated at 2022-06-24 12:56:30.055340
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of the class
    ie = KonserthusetPlayIE()
    # Check that it's an instance of the right class
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:56:32.894898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:34.102233
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:36.088368
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE())  # check if the class constructor works

# Generated at 2022-06-24 12:56:41.481541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable('CKDDnlCY-dhWAAqiMERd-A')
    assert not KonserthusetPlayIE.suitable('CKDDnlCY-dhWAAqiMERd-A', strict=True)
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:56:44.552750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw", {}, None)

# Generated at 2022-06-24 12:56:55.269372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_youtube_dl import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['youtube_include_dash_manifest'] = False

    # Extract a video without subtitles
    ie = ydl.extract_info('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie['id'] == 'CKDDnlCY-dhWAAqiMERd-A')
    assert(ie['title'] == 'Orkesterns instrument: Valthornen')
    # Check that the extracted formats are listed in order of preference
    assert(ie['formats'][0]['format_id'] == 'rtmp-standard')
    assert(ie['formats'][1]['format_id'] == 'http-standard')

# Generated at 2022-06-24 12:57:03.546407
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:10.104141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert KonserthusetPlayIE._VALID_URL == ie._VALID_URL
    assert KonserthusetPlayIE._TEST == ie._TESTS
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:57:13.286118
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

    ie = KonserthusetPlayIE("/media/mediaplayer/index.html")

    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

    ie = KonserthusetPlayIE("rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")


# Generated at 2022-06-24 12:57:14.683959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.konserthusetplay

# Generated at 2022-06-24 12:57:15.659888
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:16.567372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:19.391558
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE)

# Generated at 2022-06-24 12:57:21.629797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global KonserthusetPlayIE
    KonserthusetPlayIE


# Generated at 2022-06-24 12:57:23.488658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	kp = KonserthusetPlayIE()
	assert type(kp) == KonserthusetPlayIE

# Generated at 2022-06-24 12:57:26.148309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._VALID_URL = KonserthusetPlayIE._VALID_URL
    ie._TESTS = KonserthusetPlayIE._TESTS
    ie.test()

# Generated at 2022-06-24 12:57:29.817455
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE

    test_ie = KonserthusetPlayIE(InfoExtractor())
    assert test_ie.ie_key() == 'KonserthusetPlay'