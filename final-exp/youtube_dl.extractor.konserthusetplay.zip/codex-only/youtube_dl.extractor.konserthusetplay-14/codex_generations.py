

# Generated at 2022-06-24 12:47:31.611143
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:43.095606
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_obj = KonserthusetPlayIE()
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:47:44.294502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    return k.KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:45.804372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:49.103296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(url, {})

# Generated at 2022-06-24 12:47:51.316687
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE('KonserthusetPlay')
    except:
        assert False
    assert True

# Generated at 2022-06-24 12:47:55.799387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # URL for constructor of class Channel9IE.
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Constructor of class KonserthusetPlayIE.
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:48:00.600305
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_search_regex')

# Generated at 2022-06-24 12:48:03.372791
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key()).ie_key() == \
        KonserthusetPlayIE.ie_key()

# Generated at 2022-06-24 12:48:06.745916
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE._TESTS[0]['url']
    assert KonserthusetPlayIE._TESTS[0]['md5']

# Generated at 2022-06-24 12:48:08.115936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:48:16.458692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    expected = (
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'https://www.example.com/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    for url in expected:
        assert ie.suitable(url)
        assert ie.working()

# Generated at 2022-06-24 12:48:17.821205
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:21.428849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert i.get_url_re() == i._VALID_URL
    assert i.get_tests() == i._TESTS
    assert i.get_type() == i.IE_NAME

# Generated at 2022-06-24 12:48:22.047822
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:23.239016
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-24 12:48:25.422301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ksph_ie = KonserthusetPlayIE()
    assert ksph_ie.ie_key() == 'KonserthusetPlay'
    assert ksph_ie.ie_key() == 'rspoplay'

# Generated at 2022-06-24 12:48:29.433686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE.

    If this fails, we have definitely changed something in the class,
    and the unit test needs to be updated.
    """
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:39.352487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('https://www.konserthusetplay.se/')
    assert ie.suitable('https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:48:45.011878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for constructor of class KonserthusetPlayIE
    # This extractor uses the class method _match_id
    # Constructor of class InfoExtractor is called
    # as InfoExtractor(KonserthusetPlayIE._VALID_URL)._real_initialize()
    # and self has no attribute '_match_id'
    ies = KonserthusetPlayIE()
    ie = ies._real_initialize()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')



# Generated at 2022-06-24 12:48:50.751171
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:48:52.594720
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'KonserthusetPlayIE' == KonserthusetPlayIE('KonserthusetPlay').IE_NAME

# Generated at 2022-06-24 12:48:54.455241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()
    assert 'KonserthusetPlayIE' in str(type(x))

# Generated at 2022-06-24 12:48:57.749892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for class KonserthusetPlayIE
    test = KonserthusetPlayIE()
    assert isinstance(test, KonserthusetPlayIE)


# Generated at 2022-06-24 12:49:01.923705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   """ This function tests the constructor of class KonserthusetPlayIE """
   assert KonserthusetPlayIE()._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-24 12:49:04.473415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:49:08.140496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-24 12:49:16.710713
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

    assert k._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:17.570766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(not KonserthusetPlayIE(KonserthusetPlayIE))

# Generated at 2022-06-24 12:49:18.953614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None

# Generated at 2022-06-24 12:49:22.680289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import pytest
    # Test for constructor of class KonserthusetPlayIE
    with pytest.raises(TypeError) as excinfo:
        KonserthusetPlayIE()
    assert str(excinfo.value) == 'Can not instantiate base class'

# Generated at 2022-06-24 12:49:24.842391
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor
    # Should not throw any exception
    try:
        KonserthusetPlayIE()
    except:
        raise


# Generated at 2022-06-24 12:49:34.562486
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  ie = KonserthusetPlayIE( {}, {})
  assert ie.IE_NAME == 'konserthusetplay'
  assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
  assert ie.ie_key() == 'KonserthusetPlay'
  assert ie.suitable( {'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'} )
  assert ie.suitable( {'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'} )
  assert not ie.su

# Generated at 2022-06-24 12:49:35.156225
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:39.978451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie is not None
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._DOWNLOAD_WEBPAGE_HOOK is not None
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:49:47.667708
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://example.com', {})
    assert ie.suitable('http://example.com') is True
    ie = KonserthusetPlayIE('http://example.com', {'qualities': ['high']})
    assert ie.suitable('http://example.com') is True
    ie = KonserthusetPlayIE('http://example.com', {'qualities': ['low']})
    assert ie.suitable('http://example.com') is False

# Generated at 2022-06-24 12:49:51.961092
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthuset_play_ie is not None


# Generated at 2022-06-24 12:49:55.863048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(k, KonserthusetPlayIE)

# Generated at 2022-06-24 12:49:59.520998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Assert that instantiating a class KonserthusetPlayIE works and does not crash
    ie = KonserthusetPlayIE()
    assert type(ie) == KonserthusetPlayIE

# Generated at 2022-06-24 12:50:00.535744
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:02.298637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE('KonserthusetPlay'), InfoExtractor)

# Generated at 2022-06-24 12:50:05.699040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Tests if object is instance of class
    assert type(KonserthusetPlayIE(url)) == KonserthusetPlayIE

# Generated at 2022-06-24 12:50:12.151696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Unit test with a URL pointing to a video that must be supported
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    kp_ie = KonserthusetPlayIE(url)

    assert kp_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:18.100761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    dummy_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    check_variable = KonserthusetPlayIE(dummy_url)
    assert check_variable is not None

# Generated at 2022-06-24 12:50:19.089602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-24 12:50:25.595332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE(KonserthusetPlayIE._TESTS[1]['url'])
    assert(IE.url == KonserthusetPlayIE._TESTS[1]['url'])
    assert(IE._VALID_URL == KonserthusetPlayIE._VALID_URL)
    assert(IE._TESTS == KonserthusetPlayIE._TESTS)

# Generated at 2022-06-24 12:50:35.328342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test a normal video
    # test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # IE = KonserthusetPlayIE(test_url, 'http://www.rspoplay.se')
    # IE._real_initialize()
    # print("_real_extract: %s" % IE._real_extract(test_url))
    # print("_VALID_URL: %s" % IE._VALID_URL)
    # print("_TESTS: %s" % IE._TESTS)
    # print("__MODULE__: %s" % IE.__module__)
    pass

# Generated at 2022-06-24 12:50:37.626734
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Unit test
if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:40.058382
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    youtube_ie = KonserthusetPlayIE()
    assert youtube_ie.IE_NAME == "konserthusetplay"


# Generated at 2022-06-24 12:50:40.780970
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:42.204327
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    

# Generated at 2022-06-24 12:50:51.159132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:50:58.721956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:06.958380
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of the KonserthusetPlayIE
    ie = KonserthusetPlayIE()

    # Test the first test.
    # For simplicity, we only test the extractor part of the functionality.
    ie._download_webpage = lambda *args: 'pure html'
    ie._search_regex = lambda *args: 'e value'

# Generated at 2022-06-24 12:51:13.571257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # arrange
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    
    # act
    extractor = KonserthusetPlayIE()

    # assert
    assert extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert extractor._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert extractor._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:51:14.636697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.REQUEST_INTERVAL > 0

# Generated at 2022-06-24 12:51:25.633839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:51:27.168981
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract()


# Generated at 2022-06-24 12:51:28.632736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-24 12:51:30.958124
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:51:34.904918
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE()
    instance.match(url)


# Generated at 2022-06-24 12:51:37.587697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:51:38.891624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# TODO: Fill test code here.
	
	print("Implement me!")

# Generated at 2022-06-24 12:51:40.573091
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:51:44.058908
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.download([url])

# Generated at 2022-06-24 12:51:45.244331
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:48.125608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:51:57.220293
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	instance = KonserthusetPlayIE()
	assert instance._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
	assert instance._match_id('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:00.802469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:52:02.736510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:52:05.990642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE({})
    ie = KonserthusetPlayIE({'yt_cipher': 'true'})
    raise NotImplementedError

# Generated at 2022-06-24 12:52:13.262020
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_kp = KonserthusetPlayIE()
    assert ie_kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:25.474647
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:28.919960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_key() == ie.suitable([ie.ie_key()])[0]
    assert ie.suitable([]) == []

# Generated at 2022-06-24 12:52:31.870177
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL.match('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:37.656043
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie is not None
    assert isinstance(ie, KonserthusetPlayIE)
    return

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:39.062066
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	obj=KonserthusetPlayIE()
	print(obj)

# Generated at 2022-06-24 12:52:46.379736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE_obj = KonserthusetPlayIE()
    assert KonserthusetPlayIE_obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE_obj._TESTS
    assert KonserthusetPlayIE_obj._download_webpage
    assert KonserthusetPlayIE_obj._match_id
    assert KonserthusetPlayIE_obj._extract_m3u8_formats
    assert KonserthusetPlayIE_obj._search_regex
    assert KonserthusetPlayIE_obj._download_json
    assert KonserthusetPlayIE_obj._

# Generated at 2022-06-24 12:52:48.359829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None

# Generated at 2022-06-24 12:52:53.258219
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KPIE = KonserthusetPlayIE()
    assert(KPIE.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:54.367851
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:57.861985
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    print(ie)

# Generated at 2022-06-24 12:53:01.933092
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    URL = "http://konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    instance = KonserthusetPlayIE()
    assert instance.suitable(URL) == True
    assert instance.IE_NAME == "konserthusetplay.se"
    assert instance.IE_DESC == 'Video on demand from the Royal Stockholm Philharmonic Orchestra'

# Generated at 2022-06-24 12:53:05.461658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
test_KonserthusetPlayIE.test_video_id = 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:53:08.894948
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests for constructor of class KonserthusetPlayIE.
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:53:10.270456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-24 12:53:12.523495
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se', 'm')

# Generated at 2022-06-24 12:53:15.289522
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(None)
    assert isinstance(obj, KonserthusetPlayIE)
    

# Generated at 2022-06-24 12:53:17.152669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:53:18.803716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:53:26.862637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    m = KonserthusetPlayIE(url)
    assert m._TESTS[0]['url'] == m.url
    assert m._TESTS[0]['md5'] == m.md5
    assert m._TESTS[0]['info_dict']['title'] == m.title
    assert m._TESTS[0]['info_dict']['description'] == m.description
    assert m._TESTS[0]['info_dict']['id'] == m.id
    assert m._TESTS[0]['info_dict']['thumbnail'] == m.thumbnail

# Generated at 2022-06-24 12:53:36.614724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.IE_NAME == 'konserthusetplay')
    assert(ie.info_dict == None)
    assert(ie.ie == None)
    assert(ie.patterns == [
        r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'])
    assert(ie.re == re.compile(
        r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'))
    assert(ie.video_id == None)

# Generated at 2022-06-24 12:53:43.475155
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:53:47.863969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == ie._match_id(ie._VALID_URL)
    assert ie._VALID_URL == ie._match_id(ie._VALID_URL + "&foo=bar")



# Generated at 2022-06-24 12:53:48.929885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable(ie.ie_key())

# Generated at 2022-06-24 12:53:54.088537
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_class = KonserthusetPlayIE
    ie = ie_class()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable()

# Generated at 2022-06-24 12:54:06.560266
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        # Total number of tests to be run on the KonserthusetPlayIE class
    test_cnt = 0
    # Number of tests that have passed so far
    test_pass_cnt = 0
    # Number of tests that were skipped
    skipped_tests = 0

    def test_url(url, expected):
        # Increment the total number of tests to be run
        nonlocal test_cnt
        test_cnt += 1

        # Print out a statement to read in the terminal (optional)
        # print("Testing url: " + url)
        # Construct an object of the class KonserthusetPlayIE
        # to be used for testing purposes
        kpobj = KonserthusetPlayIE()
        # Test the _VALID_URL attribute of the KonserthusetPlayIE object
        # by comparing the pattern to

# Generated at 2022-06-24 12:54:07.989922
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:13.244649
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    try:
        KonserthusetPlayIE(url)
    except:
        assert False, 'The object could not be created'
    else:
        assert True, 'The object was created'


# Generated at 2022-06-24 12:54:17.134363
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie != None


# Generated at 2022-06-24 12:54:21.016308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konPlayExtract = KonserthusetPlayIE()

    assert konPlayExtract.suitable(KonserthusetPlayIE.ie_key())
    assert not konPlayExtract.suitable('someURL')


# Generated at 2022-06-24 12:54:28.366945
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()
    assert(x._VALID_URL==r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:54:31.278376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    return ie


# Generated at 2022-06-24 12:54:33.960933
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:37.538183
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie=KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    return

# Generated at 2022-06-24 12:54:39.422652
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor is not None

# Generated at 2022-06-24 12:54:44.976962
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:54:51.940344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Instantiation test
    assert(ie != None)
    # Test URL
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test ID
    video_id = ie._match_id(url)
    assert(video_id == 'CKDDnlCY-dhWAAqiMERd-A')
    # Instantiate this extractor again, but with a different URL
    ie = KonserthusetPlayIE(url)
    assert(ie != None)
    # Test URL again
    assert(ie._match_id(ie.url) == video_id)
    # Test title
    de = ie.extract()

# Generated at 2022-06-24 12:54:52.919895
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(object())

# Generated at 2022-06-24 12:54:58.897744
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.video_id == "CKDDnlCY-dhWAAqiMERd-A"
    assert ie.host == "www.konserthusetplay.se"
    assert ie.classes[0] == InfoExtractor
    assert ie.constructor == KonserthusetPlayIE

# Generated at 2022-06-24 12:55:00.149484
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:55:01.293088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None



# Generated at 2022-06-24 12:55:04.063385
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test for constructor of class KonserthusetPlayIE"""
    kp =KonserthusetPlayIE()
    assert isinstance(kp, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:16.155775
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:26.827696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:27.593556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:28.738040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:55:31.658530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:33.040797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:42.982337
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Make an instantiation of class KonserthusetPlayIE
    video_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_result = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    konserthuset_play_instantiation = KonserthusetPlayIE()
    actual_result = konserthuset_

# Generated at 2022-06-24 12:55:46.620427
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:47.833561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()._tests()


# Generated at 2022-06-24 12:55:52.948733
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay and RSOPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._downloader is not None

# Generated at 2022-06-24 12:55:54.552956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj

# Generated at 2022-06-24 12:55:55.754325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(0)

# Generated at 2022-06-24 12:56:05.851185
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE("KonserthusetPlay.se IE") == KonserthusetPlayIE("KonserthusetPlay.se IE"))
    assert(KonserthusetPlayIE("KonserthusetPlay.se IE")._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:56:16.105253
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_dict = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    extractor = KonserthusetPlayIE()
    assert extractor._real_extract(url) == info_dict

# Generated at 2022-06-24 12:56:17.555023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit_test = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:20.691526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert isinstance(k, KonserthusetPlayIE)
    return True



# Generated at 2022-06-24 12:56:29.027319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)";
    assert ie._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A";
    assert ie._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967";
    assert ie._TESTS[1]['url'] == "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw";

# Generated at 2022-06-24 12:56:30.162389
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:35.684720
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:37.653352
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None, None)._real_extract(None)


# Generated at 2022-06-24 12:56:40.557160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #This is a test for the constructor of KonserthusetPlayIE
    extractor = KonserthusetPlayIE()
    if extractor is None:
        raise Exception("Failed to create an KonserthusetPlayIE object")

# Generated at 2022-06-24 12:56:43.646977
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay.se', "Wrong name"

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:49.475532
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.supported_extractors == ['KonserthusetPlay']
    assert ie.matches('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:52.175819
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test case for constructor of KonserthusetPlayIE class
    """
    tst = KonserthusetPlayIE()
    assert tst is not None


# Generated at 2022-06-24 12:56:54.722015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # check whether the object is constructed properly or not
    if KonserthusetPlayIE._VALID_URL is None:
        assert False
    else:
        assert True


# Generated at 2022-06-24 12:56:57.244832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:58.479136
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:57:00.042495
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._real_extract is not None
    match = instance._match_id

# Generated at 2022-06-24 12:57:02.111639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download_webpage()
    ie.match_id()
    ie.extract()
    ie.real_extract()

# Generated at 2022-06-24 12:57:08.587898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'


# Generated at 2022-06-24 12:57:14.310173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE.
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:57:17.894291
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:57:19.959455
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:22.492175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    assert ie.ie_key()=='KonserthusetPlay'

# Generated at 2022-06-24 12:57:26.791495
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, "_download_webpage") and hasattr(ie, "url")
    assert ie.url == "https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/konserthusetplay.py"

# Generated at 2022-06-24 12:57:27.838096
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE('', '')
    assert test

# Generated at 2022-06-24 12:57:29.346123
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance is not None

# Generated at 2022-06-24 12:57:30.358026
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:36.284129
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url) # no exception
    url = 'unknown'
    try:
        KonserthusetPlayIE(url) # Exception, invalid URL
        assert False
    except:
        assert True