

# Generated at 2022-06-24 12:47:32.272545
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-24 12:47:35.052786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()
    assert isinstance(t, InfoExtractor)
    assert isinstance(t, KonserthusetPlayIE)


# Generated at 2022-06-24 12:47:38.536196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE."""
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Unit test of _real_extract method of class KonserthusetPlayIE

# Generated at 2022-06-24 12:47:39.730622
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create instance of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()

    assert ie is not None

# Generated at 2022-06-24 12:47:40.356365
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:41.714604
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()._call_api(1,2,3)

# Generated at 2022-06-24 12:47:43.094514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:44.567196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-24 12:47:45.555579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:52.002321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE("KonserthusetPlayIE", "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert(test.name == "KonserthusetPlayIE")
    assert(test.ie_key == "KonserthusetPlayIE")
    assert(test.urls_re == [r'https?:\/\/(?:www\.)?(?:konserthusetplay|rspoplay)\.se\/\?.*\bm=(?P<id>[^&]+)'])
    assert(test.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:47:53.132222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check for KonserthusetPlayIE class
    _ = KonserthusetPlayIE


# Generated at 2022-06-24 12:47:54.818418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay', 'konserthuset')


# Generated at 2022-06-24 12:47:58.699019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-24 12:48:09.773009
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''Unit test for constructor of class VideoSajtIE'''
    # Create IE object
    ie = KonserthusetPlayIE()
    sample_urls = ['http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A']
    for url in sample_urls:
        # Test extraction of title from url
        title = ie._match_id(url)
        assert title in url, 'Unable to extract title from url'
        # Test extraction of url from url
        url1 = ie._real_extract(url)['id']
        assert url1 in url, 'Unable to extract url from url'
        # Test extraction of title from metadata
        title = ie._real_extract(url)['title']

# Generated at 2022-06-24 12:48:10.807489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:13.571252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_name == 'KonserthusetPlay'
    assert ie.ie_key == 'KonserthusetPlay'



# Generated at 2022-06-24 12:48:20.591907
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructs a KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Extracts the information from URL
    title = ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")["title"]
    # Asserts that the title is equal to the correct title
    assert(title == "Orkesterns instrument: Valthornen")

# Generated at 2022-06-24 12:48:22.843378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance
    ie = KonserthusetPlayIE()

    # TODO: Add assert or other check


# Generated at 2022-06-24 12:48:25.849063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert (ie.IE_NAME == 'konserthusetplay:play')
    assert (ie.IE_DESC == 'KonserthusetPlay')
    assert (ie._VALID_URL == ie.VALID_URL)

## Unit tests for KonserthusetPlayIE

import unittest


# Generated at 2022-06-24 12:48:29.443901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE."""
    assert KonserthusetPlayIE._VALID_URL.match("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") is not None
    assert KonserthusetPlayIE._VALID_URL.match("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") is not None



# Generated at 2022-06-24 12:48:31.037778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:35.386332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_konserthusetplay = KonserthusetPlayIE()
    assert ie_konserthusetplay
    assert isinstance(ie_konserthusetplay, InfoExtractor)
    assert ie_konserthusetplay._VALID_URL
    assert ie_konserthusetplay._TESTS

# Generated at 2022-06-24 12:48:40.358767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE('', '', '', '')
    assert IE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:48:42.133293
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-24 12:48:45.393610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test using pytest.

    This is a constructor of class KonserthusetPlayIE class.
    """
    # konserthusetplay = KonserthusetPlayIE()
    return


# Generated at 2022-06-24 12:48:49.205321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset.se video'

# Generated at 2022-06-24 12:48:50.537930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:48:53.263683
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import test_KonserthusetPlayIE

    test_KonserthusetPlayIE('KonserthusetPlayIE')

# Generated at 2022-06-24 12:48:54.299924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:04.842603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    video._download_webpage("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "CKDDnlCY-dhWAAqiMERd-A")
    video._download_json("http://csp.picsearch.com/rest?e=CKDDnlCY-dhWAAqiMERd-A&containerId=mediaplayer&i=object", "CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:49:14.445699
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
	assert KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") != KonserthusetPlayIE("https://www.konserthusetplay.se/?m=fsdfsdf")
	assert KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == Konserthus

# Generated at 2022-06-24 12:49:19.270350
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:49:21.521424
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import KonserthusetPlayTestCase
    KonserthusetPlayTestCase().run()

# Generated at 2022-06-24 12:49:24.387322
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('file:///C:/Users/mikael/source/repos/python/extractor/test/testdata/url.js')

# Generated at 2022-06-24 12:49:26.965579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_DESC == ie.ie_key()
    ie_desc_split = ie.IE_DESC.split('-')
    ie_desc_join = '-'.join(ie_desc_split[:-1])
    assert ie_desc_join == ie.ie_key_id()



# Generated at 2022-06-24 12:49:33.129084
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import sys
    import unittest

    class KonserthusetPlayIETest(unittest.TestCase):
        def test_test(self):
            self.assertTrue(True)

    suite = unittest.TestLoader().loadTestsFromTestCase(KonserthusetPlayIETest)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if len(result.errors) > 0 or len(result.failures) > 0:
        sys.exit(1)

# Generated at 2022-06-24 12:49:40.297928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    data = KonserthusetPlayIE()._real_extract(url)
    assert(data['id'] == 'CKDDnlCY-dhWAAqiMERd-A')
    assert(data['title'] == 'Orkesterns instrument: Valthornen')
    assert(data['description'] == 'f10e1f0030202020396a4d712d2fa827')

# Generated at 2022-06-24 12:49:41.954419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pl = KonserthusetPlayIE()
    assert pl


# Generated at 2022-06-24 12:49:53.427583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor._VALID_URL is 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:57.734712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_constructor = getattr(KonserthusetPlayIE, '__init__')
    class_constructor(KonserthusetPlayIE)

# Generated at 2022-06-24 12:50:03.546442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_info_extractor = KonserthusetPlayIE()
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert konserthuset_play_info_extractor.suitable(test_url)
    assert konserthuset_play_info_extractor.extract(test_url)

# Generated at 2022-06-24 12:50:04.764751
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:05.700624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:50:17.798701
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:50:19.260280
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:50:21.896446
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE

# Generated at 2022-06-24 12:50:31.741832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create instance of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    ie._downloader.cache.delete()
    assert ie.url_result('http://qa.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A').get('title') == 'Orkesterns instrument: Valthornen'
    ie._downloader.cache.delete()
    assert ie._match_id('http://qa.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:43.028149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:44.050870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:45.051668
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:53.132728
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
   # The URL of a video on the KonserthusetPlay website
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # assert that the video has an id...
    assert 'video_id' in ie._real_extract(url)
    # a title...
    assert 'title' in ie._real_extract(url)
    # a description...
    assert 'description' in ie._real_extract(url)
    # a thumbnail in the form of a URL...
    assert 'thumbnail' in ie._real_extract(url)
    # a duration...
    assert 'duration' in ie._real_extract(url)
    # some formats...

# Generated at 2022-06-24 12:51:04.241824
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    webpage = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE.suitable(url)
    assert video_id == KonserthusetPlayIE._match_id(url)
    info_dict = KonserthusetPlayIE._real_extract(KonserthusetPlayIE(), url)
    assert info_dict['id'] == video_id
    assert info_dict['title'] == 'Orkesterns instrument: Valthornen'
    assert info_

# Generated at 2022-06-24 12:51:09.010665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:51:19.558214
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This is an extractor for a media-player site. The constructor
    # test is trivial:
    ie = KonserthusetPlayIE()
    return ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') and \
           ie.IE_NAME == 'konserthusetplay' and \
           ie.IE_DESC == 'Konserthuset Play' and \
           ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:51:28.902970
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:34.950993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    except Exception as e:
        # raise an exception if the constructor does not accept the URL
        assert False, "KonserthusetPlayIE class constructor does not accept URL as an argument"

# Generated at 2022-06-24 12:51:35.594700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert type(KonserthusetPlayIE) == type

# Generated at 2022-06-24 12:51:39.677453
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kplay_ie_obj = KonserthusetPlayIE('https://csp-picsearch.com/rest?e=1379341460017&containerId=mediaplayer&i=object')
    assert type(kplay_ie_obj).__name__ == "KonserthusetPlayIE"

# Generated at 2022-06-24 12:51:45.195278
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:46.836737
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_class = KonserthusetPlayIE()
    assert test_class

# Generated at 2022-06-24 12:51:53.576778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    eq_(ie._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    eq_(ie.SUFFIX, '.se')
    eq_(ie.IE_NAME, 'konserthusetplay')


# Generated at 2022-06-24 12:51:59.247819
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.url == 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert ie.id == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:52:01.094012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None, None, None)

# Generated at 2022-06-24 12:52:11.150061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest

    class TestKonserthusetPlayIE(unittest.TestCase):

        def test_get_video_id(self):
            ie = KonserthusetPlayIE()
            assert ie.get_video_id('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

        def test_constructor(self):
            konserthusetplay = KonserthusetPlayIE()
            assert konserthusetplay.name == 'KonserthusetPlay'
            assert konserthusetplay.description is not None

# Generated at 2022-06-24 12:52:13.641401
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:52:16.763541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Simple unit test for constructor of class KonserthusetPlayIE"""
    obj = KonserthusetPlayIE()
    print(obj)

# Generated at 2022-06-24 12:52:27.748075
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:31.864891
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)


if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:40.014536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(url)
    assert ie.url_result(url) == url
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert ie.suitable(url)
    assert ie.url_result(url) == url

# Generated at 2022-06-24 12:52:44.457331
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie.ie_key() == 'konserthusetplay'
    assert konserthusetplay_ie.ie_key() == 'rspoplay'

# Generated at 2022-06-24 12:52:47.357200
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor KonserthusetPlayIE().
    """
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:52:50.372682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:52:58.788544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	import KonserthusetPlay

# Generated at 2022-06-24 12:53:01.226364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:53:02.190240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that class is not abstract
    assert KonserthusetPlayIE is not InfoExtractor


# Generated at 2022-06-24 12:53:07.993754
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test one valid URL
    instance = KonserthusetPlayIE('konserthusetplay',
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert instance.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Test one invalid URL
    assert not instance.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:53:10.887028
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Tests that the constructor class KonserthusetPlayIE() will not cause exceptions.
    """
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:15.000689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").getId() == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:53:17.966292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing constructor of KonserthusetPlayIE
    # Expected to return instance of KonserthusetPlayIE
    assert type (KonserthusetPlayIE()) == KonserthusetPlayIE

# Generated at 2022-06-24 12:53:20.199387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert str(ie) == '<KonserthusetPlayIE info_extractor>'

# Generated at 2022-06-24 12:53:21.086927
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:25.319338
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.example.com')

# Generated at 2022-06-24 12:53:26.961301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-24 12:53:37.383555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url_test1 = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url_test2 = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert ie.match_url(url_test1) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.match_url(url_test2) == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:53:38.462560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:42.033052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extractor_key() == 'rspoplay'

# Generated at 2022-06-24 12:53:51.957603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:04.474268
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # test regular expression
    m = re.match(ie._VALID_URL, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert m.group(1) == 'CKDDnlCY-dhWAAqiMERd-A'
    m = re.match(ie._VALID_URL, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:54:06.559460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        return True
    except:
        return False

# Generated at 2022-06-24 12:54:18.333827
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE._VALID_URL == r'https?://(www\.|)konserthusetplay\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:24.760252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   testargs = {"url": "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"}
   testobj = KonserthusetPlayIE(**testargs)
   assert testobj.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "url: %s" % testobj.url

# Generated at 2022-06-24 12:54:32.303751
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    test = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert kp._real_extract(test)['title'] == 'Orkesterns instrument: Valthornen'
    test2 = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert kp._real_extract(test2)['title'] == 'Ligeti: Atmosphères'

# Generated at 2022-06-24 12:54:36.178006
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_obj = KonserthusetPlayIE()
    assert ie_obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:39.319263
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:43.127943
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:45.614566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url = KonserthusetPlayIE(URL)
    assert url.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:54:46.917418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:52.919367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    obj = KonserthusetPlayIE()
    res = obj._real_extract(url)
    assert res["id"] == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:55:02.128986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:03.483887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst is not None


# Generated at 2022-06-24 12:55:06.396803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(str(ie) == "KonserthusetPlayIE(konserthusetplay,rspoplay)")

# Generated at 2022-06-24 12:55:14.930696
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    verify_konserthusetplayie = KonserthusetPlayIE()
    assert verify_konserthusetplayie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert verify_konserthusetplayie._real_extract(url)

# Generated at 2022-06-24 12:55:15.877968
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert a is not None

# Generated at 2022-06-24 12:55:17.922975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Test class KonserthusetPlayIE constructor
    '''
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:55:19.420345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(test_KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:24.645938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    copy = KonserthusetPlayIE()._real_extract(url)
    assert copy[u"id"] == u"CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-24 12:55:26.052302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie =  KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:55:29.264928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with pytest.raises(RegexMatchError):
        # This string should not match regex.
        kp = KonserthusetPlayIE('https://www.youtube.com/foo?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:35.035093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.ie_key() == 'KonserthusetPlay'
    assert inst.suitable(expect_suitable=True, url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert inst.suitable(expect_suitable=True, url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:36.826600
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    KonserthusetPlayIE.suite()

# Generated at 2022-06-24 12:55:38.161657
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE(InfoExtractor())
    assert kp != None


# Generated at 2022-06-24 12:55:40.043374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:55:49.076414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest
    from . import KonserthusetPlayIE
    #
    # All these tests should be passed
    #
    test1_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test2_url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    #
    test1_id = 'CKDDnlCY-dhWAAqiMERd-A'
    test2_id = 'elWuEH34SMKvaO4wO_cHBw'

    class TestKonserthusetPlayIE(unittest.TestCase):

        def test_id1(self):
            test1_id_result = Kons

# Generated at 2022-06-24 12:55:49.846227
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:50.712310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:51.875438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:03.432801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """test_KonserthusetPlayIE"""
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:05.363197
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:56:09.014294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:10.098408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:19.421366
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:21.426477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:22.388302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:26.994612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(url)
    assert ie.id == "CKDDnlCY-dhWAAqiMERd-A", "the id should be extracted correctly"
    assert ie.url == url, "the url should be extracted correctly"

# Generated at 2022-06-24 12:56:39.284311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id = lambda url: "test"
    ie._search_regex = lambda r, e, k, d: "test"

# Generated at 2022-06-24 12:56:48.689951
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info = KonserthusetPlayIE()._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info['title'] == 'Orkesterns instrument: Valthornen'
    assert info['description'] == 'Konsertföreståndare Tomas Magnusson guidar runt bland orkesterns instrument.'
    assert info['thumbnail'] == 're:^https?://.*$'
    assert info['duration'] == 398.76
    assert info['subtitles'] == {}

# Generated at 2022-06-24 12:56:49.175599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE != None

# Generated at 2022-06-24 12:56:49.712363
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:56:51.236649
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:56:52.225351
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:53.027109
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL

# Generated at 2022-06-24 12:56:56.753008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit tests for the constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE('md5')
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key() is not None

# Generated at 2022-06-24 12:57:04.082199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay.se'
    assert ie.IE_DESC == 'KonserthusetPlay.se and RSPOPlay.se'

    # test constructor
    assert isinstance(ie, InfoExtractor)
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.valid_url('https://www.konserthusetplay.se/')

# Generated at 2022-06-24 12:57:09.254471
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None
    assert kp.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:57:12.220900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)


# Generated at 2022-06-24 12:57:15.615373
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'konserthusetplay.se')

# Generated at 2022-06-24 12:57:18.778215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE = KonserthusetPlayIE()
    assert isinstance(KonserthusetPlayIE, InfoExtractor)

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:57:22.337587
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE('rspoplay.se',url)

# Generated at 2022-06-24 12:57:23.766670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Generated at 2022-06-24 12:57:31.498975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"