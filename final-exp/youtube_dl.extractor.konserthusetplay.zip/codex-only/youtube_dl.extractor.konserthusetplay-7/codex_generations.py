

# Generated at 2022-06-24 12:47:33.923011
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

    ie = KonserthusetPlayIE(KonserthusetPlayIE.ie_key())
    assert ie


# Generated at 2022-06-24 12:47:37.020511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test constructor of class KonserthusetPlayIE."""
    kp = KonserthusetPlayIE()
    assert kp is not None
    return

# Generated at 2022-06-24 12:47:42.292212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE
    # Check that the lookup has a positive result
    assert(k.suitable('?m=CKDDnlCY-dhWAAqiMERd-A') == True)
    # Check that the lookup has a negative result
    assert(k.suitable('http://www.konserthusetplay.se/') == False)

# Generated at 2022-06-24 12:47:43.530100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:45.791790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        test_KonserthusetPlayIE.IE = KonserthusetPlayIE()
    except Exception:
        pass

# Generated at 2022-06-24 12:47:49.101804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.online == True

# Generated at 2022-06-24 12:47:50.089264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:55.488338
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
  kp_ie = KonserthusetPlayIE()
  kp_ie.suitable(url)
  kp_ie.extract(url)
  kp_ie.add_ie(url)

# Generated at 2022-06-24 12:48:01.220429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    return 1



# Generated at 2022-06-24 12:48:06.848981
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    k = KonserthusetPlayIE()

    m = k._VALID_URL

    if m.match(test_url):
        k._real_extract(test_url)
    else:
        print("Incorrect link test_url")
        assert False

# Generated at 2022-06-24 12:48:10.064763
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if not isinstance(ie, KonserthusetPlayIE):
        raise AssertionError('Unit test failed: KonserthusetPlayIE() not initialized')

# Generated at 2022-06-24 12:48:13.952965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()._real_extract(
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert result['id'] == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-24 12:48:15.505132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert str(ie) == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:48:17.412120
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:27.193128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # 1) KonserthusetPlayIE(KonserthusetPlayIE, KonserthusetPlayPlaylistBaseIE, YoutubeIE, NoIE)
    assert InfoExtractor.is_suitable(KonserthusetPlayIE, 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    # 2) KonserthusetPlayIE(KonserthusetPlayPlaylistBaseIE, KonserthusetPlayIE, YoutubeIE, NoIE)

# Generated at 2022-06-24 12:48:28.925452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    assert KonserthusetPlayIE, "Unit test for constructor of class KonserthusetPlayIE"



# Generated at 2022-06-24 12:48:31.817636
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:34.662144
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie =  KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie

# Generated at 2022-06-24 12:48:44.255209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:48.383404
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Not a real test to be executed,
       only a example of how to use the constructor.
    """
    try:
        extractor = KonserthusetPlayIE()
    except:
        extractor = None
        raise
    return extractor

# Generated at 2022-06-24 12:48:59.924600
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    test_urls = (
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
    )

    url = test_urls[0]
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'

    # calculate the regex match
    regex_match = konserthuset_play_ie._VALID_URL
    regex_match = regex_match.replace("CKDDnlCY-dhWAAqiMERd-A", '[^&]+')
    regex_match = re.compile

# Generated at 2022-06-24 12:49:00.936795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:49:06.886738
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert len(ie.IE_DESC) == 2
    assert ie.IE_DESC[1] == 'KonserthusetPlay'
    assert ie.IE_DESC[0] == 'konserthusetplay.se'
    assert ie.VALID_URL.__name__ == '_VALID_URL'
    assert ie.SUFFIX.__name__ == 'SUFFIX'

# Generated at 2022-06-24 12:49:09.536332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-24 12:49:13.913052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None
    assert obj.ie_key() == 'konserthusetplay'
    assert obj.ie_key() == obj.__class__.ie_key()
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:17.490509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE()
    assert isinstance(test_KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:49:19.269014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:22.953211
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie= KonserthusetPlayIE()
    # TODO: run test using this file, konserthusetplay_test.py
    # ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:49:32.756230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ins = KonserthusetPlayIE()

# Generated at 2022-06-24 12:49:40.766314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    assert ie.PROVIDER == 'konserthusetplay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:49:52.432264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:49:53.478402
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:04.449765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.suitable('CKDDnlCY-dhWAAqiMERd-A')
    assert not obj.suitable('elWuEH34SMKvaO4wO_cHBw')
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:50:05.700341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-24 12:50:07.092280
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, {})

# Generated at 2022-06-24 12:50:09.706592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:10.699898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:50:16.668975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:18.148659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_class_KonserthusetPlayIE()
    assert 1

# Generated at 2022-06-24 12:50:26.806960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:28.820172
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest
    unittest.TestCase(KonserthusetPlayIE._TESTS)

# Generated at 2022-06-24 12:50:32.337178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Checking the configuration of KonserthusetPlayIE.
    instance = KonserthusetPlayIE()
    assert instance.name == "KonserthusetPlay"
    assert instance.description == "The Royal Stockholm Philharmonic Orchestra"

# Generated at 2022-06-24 12:50:34.077188
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:37.578805
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.ie_key() == ie.IE_NAME

# Generated at 2022-06-24 12:50:38.529044
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, {})

# Generated at 2022-06-24 12:50:47.475638
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:50:59.583168
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    k = KonserthusetPlayIE._VALID_URL
    assert ie._VALID_URL == k

# Generated at 2022-06-24 12:51:03.431058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ieKonserthusetPlayIE = KonserthusetPlayIE()
    i = ieKonserthusetPlayIE
    i._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-24 12:51:09.748985
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that the class can be initialised with a url
    ie = KonserthusetPlayIE('https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Test that the class is an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # Test that the class is an instance of KonserthusetPlayIE
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:51:19.994144
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    # A url not accepted by the constructor
    url = 'http://www.youtube.com/user/rspoplay'
    assert KonserthusetPlayIE._valid_url(url, KonserthusetPlayIE._VALID_URL) == False
    # A valid url for the constructor
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._valid_url(url, KonserthusetPlayIE._VALID_URL) == True


# Generated at 2022-06-24 12:51:23.979816
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extractor.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-24 12:51:27.929022
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        test_url = KonserthusetPlayIE.VALID_URL
        ie = KonserthusetPlayIE()
        ie._get_token = lambda *a, **k: None
        ie._get_video_info = lambda *a, **k: []
        assert ie.VALID_URL == test_url

# Generated at 2022-06-24 12:51:32.146389
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE(KonserthusetPlayIE.IE_NAME)
    assert isinstance(instance, KonserthusetPlayIE)
    assert instance._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:51:34.598999
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract(None)
    assert ie.__class__ == KonserthusetPlayIE

# Generated at 2022-06-24 12:51:36.150814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-24 12:51:41.923714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_DESC == 'konserthusetplay.se and rspoplay.se'

# Generated at 2022-06-24 12:51:44.336133
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  print("Test constructor of class KonserthusetPlayIE")
  print("TODO: Write test for constructor of class KonserthusetPlayIE")

# Generated at 2022-06-24 12:51:47.813919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlayIE'
    assert ie.IE_DESC == 'konserthusetplay.se'

# Generated at 2022-06-24 12:51:48.545457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:56.675201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	print("Testing construction of class KonserthusetPlayIE")
	title = "Orkesterns instrument: Valthornen"
	description = "Ett valthorn går att dela upp i tre delar. Lär dig mer om hur det och andra instrument fungerar."
	thumb_image = "http://pic.cdn.picsearch.com/image/video/CKDDnlCY-dhWAAqiMERd-A-zoom-600x450.jpg"
	duration = 398.76
	ext = "mp4"

	inst = KonserthusetPlayIE()
	assert inst.IE_NAME == "KonserthusetPlay"


# Generated at 2022-06-24 12:52:06.933206
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    # Test regular expression.
    message = 'Regular expression does not work.'
    invalid_url = 'http://www.konserthusetplay.se/'
    m = re.match(KonserthusetPlayIE._VALID_URL, invalid_url)
    assert m is None, message
    valid_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    m = re.match(KonserthusetPlayIE._VALID_URL, valid_url)
    assert m is not None, message

# Generated at 2022-06-24 12:52:11.783848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    test_object = KonserthusetPlayIE()
    assert test_object.ie_key() == 'KonserthusetPlay'
    assert test_object.ie_desc() == 'KonserthusetPlay, rspoplay'
    assert hasattr(test_object, '_VALID_URL')
    assert report_info.__name__ == 'report_info'


# Generated at 2022-06-24 12:52:13.610139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        unit = KonserthusetPlayIE()
    except Exception:
        unit = None
    assert unit is not None


# Generated at 2022-06-24 12:52:18.542180
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing constructor of KonserthusetPlayIE")
    print(KonserthusetPlayIE)
    assert KonserthusetPlayIE is not None
    i = KonserthusetPlayIE()
    print(i)
    assert i is not None


# Generated at 2022-06-24 12:52:20.275153
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:22.333795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:27.792932
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_ie = KonserthusetPlayIE()
    konserthuset_play_ie._match_id(url)
    konserthuset_play_ie._real_extract(url)


# Generated at 2022-06-24 12:52:29.164409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.developer_test()

# Generated at 2022-06-24 12:52:34.160122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.url_re.match(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie.url_re.match(
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') is not None

# Generated at 2022-06-24 12:52:35.687704
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(len(KonserthusetPlayIE._TESTS) >= 1)

# Generated at 2022-06-24 12:52:37.088238
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert a

# Generated at 2022-06-24 12:52:38.493478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:46.080061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Instantiation of class KonserthusetPlayIE
    ie = KonserthusetPlayIE

    # Tests for method suit
    # Tests that the url is valid
    assert ie._match_id(
        'https://www.konserthusetplay.se/?m=zJjZ1S5k5SfH1A7_hNysNQ') == 'zJjZ1S5k5SfH1A7_hNysNQ'
    # Tests that the url is invalid
    assert ie._match_id(
        'https://www.konserthusetplay.se/?m=zJjZ1S5k5SfH1A7') == 'zJjZ1S5k5SfH1A7' is None

# Generated at 2022-06-24 12:52:49.513465
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	test = KonserthusetPlayIE()
	test.test_url()

if __name__ == '__main__':
	test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:50.649798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:51.872905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:54.006130
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:55.086541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:52:56.546793
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst is not None

# Generated at 2022-06-24 12:52:59.763490
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:53:01.629235
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)

# Generated at 2022-06-24 12:53:04.769878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._TESTS[0]['url'] == KonserthusetPlayIE._VALID_URL)
    assert(KonserthusetPlayIE._TESTS[1]['url'] == KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-24 12:53:07.348334
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL.startswith('https?')
    assert ie._TESTS[0]['url'].startswith('http')

# Generated at 2022-06-24 12:53:12.271015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    The following test checks whether the constructor of
    class KonserthusetPlayIE returns a initialized object
    correctly.
    """

    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:53:17.066968
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test for constructor of class KonserthusetPlayIE
    """
    url = "https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    KonserthusetPlayIE(url)
    

# Generated at 2022-06-24 12:53:21.748924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        url_or_none,
    )
    assert KonserthusetPlayIE
    assert InfoExtractor
    assert determine_ext
    assert float_or_none
    assert int_or_none
    assert url_or_none


# Generated at 2022-06-24 12:53:24.965385
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
	# test constructor
	KonserthusetPlayIE(IE_NAME, ie=InfoExtractor(url))


# Generated at 2022-06-24 12:53:26.107041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)



# Generated at 2022-06-24 12:53:27.132175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:53:29.491196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Unit tests for method _real_extract of class KonserthusetPlayIE

# Generated at 2022-06-24 12:53:31.481178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlay = KonserthusetPlayIE()
    assert konserthusetPlay != None

# Generated at 2022-06-24 12:53:40.280769
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:51.332559
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Initialize a unit test for class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    # Download webpage
    webpage = ie._download_webpage(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        video_id)
    # Get e
    e = ie._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']',
        webpage, 'e')
    # Get rest

# Generated at 2022-06-24 12:54:03.602184
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor).suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert KonserthusetPlayIE(InfoExtractor).suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert KonserthusetPlayIE(InfoExtractor).suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&param=value') == True

# Generated at 2022-06-24 12:54:07.580969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    objString = ie.__str__()
    assert objString == '<KonserthusetPlayIE>', '__str__ returned %s instead of <KonserthusetPlayIE>' % objString

# Generated at 2022-06-24 12:54:09.212221
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE is not None


# Generated at 2022-06-24 12:54:10.614840
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj

# Generated at 2022-06-24 12:54:12.756581
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:54:18.283870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE().download(url)

# Generated at 2022-06-24 12:54:21.684482
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    global test_KonserthusetPlayIE
    
    test_KonserthusetPlayIE = KonserthusetPlayIE();
    

# Generated at 2022-06-24 12:54:23.461303
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-24 12:54:24.966030
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:54:32.695666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    print(ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))
    print(ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"))

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:33.679416
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:54:44.369309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    temp_KonserthusetPlayIE = KonserthusetPlayIE("")
    temp_KonserthusetPlayIE._match_id("")
    temp_KonserthusetPlayIE._real_extract("")
    temp_KonserthusetPlayIE._download_subtitles("")
    temp_KonserthusetPlayIE.suitable("")
    temp_KonserthusetPlayIE.IE_NAME
    temp_KonserthusetPlayIE.IE_DESC
    temp_KonserthusetPlayIE._VALID_URL
    temp_KonserthusetPlayIE._TESTS
    temp_KonserthusetPlayIE.BRIGHTCOVE_URL_TEMPLATE
    temp_KonserthusetPlayIE._download_json("", "")

# Generated at 2022-06-24 12:54:47.540181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=oaplBmD0dIavk-zmYAsHPQ'
    # The class has to be instantiated with the url, otherwise the
    # exception will not be handled properly by the unit test framework
    KonserthusetPlayIE(url)

# Generated at 2022-06-24 12:54:58.985745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert (ie.SUITABLE == ['konserthusetplay', 'rspoplay'])
    assert (ie.IE_NAME == 'konserthusetplay')
    assert (ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert (ie.BRAND == 'konserthuset')
    assert (ie.IE_DESC == 'KonserthusetPlay')
    assert (ie.MAX_DOWNLOAD_BITRATE == 220000)

# Generated at 2022-06-24 12:55:03.072818
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:55:08.244904
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:55:18.715706
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    instance = KonserthusetPlayIE()
    assert instance.suitable(url)

    out = instance.extract({'url': url})
    assert out['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert out['title'] == 'Orkesterns instrument: Valthornen'
    assert out['description'] == 'Orkestern har funnits sedan tidig 1800-tal. I den här filmen får man lära sig lite om orkesterns olika instrument men också om hur en dirigent kan läsa en ljud-partitur.'

# Generated at 2022-06-24 12:55:20.472746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:30.351568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    # Test 1
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_md5 = 'e3fd47bf44e864bd23c08e487abe1967'
    info_dict = ie._real_extract(test_url)
    assert info_dict is not None
    assert info_dict.get('md5') == test_md5

    # Test 2
    test_url = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    info_dict = ie._real_extract(test_url)
    assert info_dict is not None

# Generated at 2022-06-24 12:55:33.478686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:55:39.007897
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(url), "%s is not suitable" % url
    assert ie.extract(url)['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:43.944949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:55:44.818440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:46.993029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Unit tests for _real_extract() in class KonserthusetPlayIE

# Generated at 2022-06-24 12:55:49.405603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:55:50.593425
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:54.275915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("\n Running test case for constructor of KonserthusetPlayIE")
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie
    print("\n Successfully passed test case for constructor of KonserthusetPlayIE")

test_KonserthusetPlayIE()


# Generated at 2022-06-24 12:56:00.576216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:04.449649
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-24 12:56:15.524553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check for class KonserthusetPlayIE
    test_ie = KonserthusetPlayIE()
    assert test_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:18.565085
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:25.322277
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.__class__ is KonserthusetPlayIE
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:26.196277
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:27.538648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("None","None")

# Generated at 2022-06-24 12:56:28.007085
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert [KonserthusetPlayIE] != None

# Generated at 2022-06-24 12:56:30.217967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:56:31.321537
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:32.117504
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:33.041247
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(isinstance(KonserthusetPlayIE, InfoExtractor))

# Generated at 2022-06-24 12:56:34.261869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    pass

# Generated at 2022-06-24 12:56:39.776473
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    wrapper_constructor = KonserthusetPlayIE

    assert_equal(wrapper_constructor._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-24 12:56:46.288429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.suitable(url=ie.valid_url)
    assert ie.suitable(url=ie.valid_url.replace(ie.ie_key(), 'rspoplay')) == False
    assert ie._parse_id_from_url(ie.valid_url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:56:47.375701
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:49.162915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This should not throw an exception
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:51.087433
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    #print(ie._VALID_URL)

# Generated at 2022-06-24 12:56:53.597456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .KonserthusetPlayIE import KonserthusetPlayIE
    import re

    assert InfoExtractor.make_valid_url

# Generated at 2022-06-24 12:56:56.530496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:57:00.539368
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    all_attributes = dir(obj)
    if not all(
            hasattr(obj, attribute)
            for attribute in [
                '_VALID_URL',
                '_TESTS',
                '_real_extract', ]):
        return False
    return True

# Generated at 2022-06-24 12:57:08.343808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    # Instantiate KonserthusetPlayIE object
    rspoplay_ie = KonserthusetPlayIE()
    # Extract information from the test url
    info_dict = rspoplay_ie._real_extract(url)

    # Assert some fields of the information dictionary
    assert info_dict is not None
    assert info_dict['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'Orkesterns instrument: Valthornen'
    assert info_dict['description'] is not None
    assert info_

# Generated at 2022-06-24 12:57:12.414509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:14.310982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:57:17.890564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:57:28.548675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    ie1 = ie._match_id(ie._VALID_URL)
    assert ie1 == 'CKDDnlCY-dhWAAqiMERd-A', '_match_id returned an incorrect id'

    ie2 = ie._match_id(ie._TESTS[0]['url'])
    assert ie2 == 'CKDDnlCY-dhWAAqiMERd-A', '_match_id returned an incorrect id'

    res = ie._real_extract(ie._TESTS[0]['url'])
    assert res['id'] == 'CKDDnlCY-dhWAAqiMERd-A', '_real_extract returned an incorrect id'

    # Test _real_extract()
    url_rspoplay = ie._T

# Generated at 2022-06-24 12:57:30.777485
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test KonserthusetPlayIE constructor"""
    assert KonserthusetPlayIE.ie_key() == 'konserthusetplay'