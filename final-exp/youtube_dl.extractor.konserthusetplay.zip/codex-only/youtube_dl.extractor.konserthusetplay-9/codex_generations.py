

# Generated at 2022-06-24 12:47:28.788080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)

    assert ie



# Generated at 2022-06-24 12:47:29.573148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:41.295518
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"==ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:47:43.577636
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert type(ie) is KonserthusetPlayIE

# Generated at 2022-06-24 12:47:44.710524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-24 12:47:55.445347
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play = KonserthusetPlayIE()
    assert konserthuset_play.ie_key() == 'konserthusetplay'
    assert konserthuset_play.ie_key() == 'konserthusetplay:play'
    assert konserthuset_play.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not konserthuset_play.suitable('https://www.konserthusetplay.se/')
    assert konserthuset_play.IE_NAME == 'konserthusetplay:play'
    assert konserthuset_play.ie_key() == 'konserthusetplay:play'
    assert konserthus

# Generated at 2022-06-24 12:48:02.773493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:12.997791
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:48:17.731013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert type(ie) == KonserthusetPlayIE
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:48:20.154487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE()
    assert test_KonserthusetPlayIE != None

# Generated at 2022-06-24 12:48:21.969773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(content_class='content_class', anvato='anvato') is not None

# Generated at 2022-06-24 12:48:30.119457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # _VALID_URL is correct
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    # _TESTS is correct

# Generated at 2022-06-24 12:48:40.819428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    v = KonserthusetPlayIE()
    assert v._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert v.IE_NAME == "konserthusetplay"
    assert v.IE_DESC == True

# Generated at 2022-06-24 12:48:41.733180
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    c = KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:42.615879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:48:46.042496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:48:49.893976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of KonserthusetPlayIE
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:48:53.549142
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    obj = ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj == True
    obj = ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert obj == True

# Generated at 2022-06-24 12:49:00.162152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    info = ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert info['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-24 12:49:07.547934
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert k.extractor.__class__.__name__ == 'KonserthusetPlayIE'
    assert k.name == 'rspoplay'



# Generated at 2022-06-24 12:49:08.252203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-24 12:49:11.242343
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:49:16.426986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    assert ie.suitable(None,url)
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-24 12:49:23.304237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert info_extractor.get_id() == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info_extractor.extract() == {'id': 'CKDDnlCY-dhWAAqiMERd-A', 'ext': 'mp4', 'title': 'Orkesterns instrument: Valthornen', 'description': 'md5:f10e1f0030202020396a4d712d2fa827', 'thumbnail': 're:^https?://.*$', 'duration': 398.76}

# Generated at 2022-06-24 12:49:27.571516
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of KonserthusetPlayIE
    """
    b = KonserthusetPlayIE()
    assert b.ie_key() == 'konserthusetplay'
    assert b.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:49:36.431467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:49:39.673616
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_key() in KonserthusetPlayIE.ie_key()

# Generated at 2022-06-24 12:49:51.420619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    # test for static class variables
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    # test for instance variables
    assert ie._VALID

# Generated at 2022-06-24 12:49:52.485515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:03.267289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Mock input arguments
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Create the KonserthusetPlayIE object
    ie = KonserthusetPlayIE()

    # Check the _VALID_URL is correct
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Check the _TESTS are correct
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:04.694775
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        assert False, "KonserthusetPlayIE() can't be initialised"
    assert True

# Generated at 2022-06-24 12:50:05.851525
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:50:06.674417
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-24 12:50:19.139131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable("") == False
    assert KonserthusetPlayIE.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert KonserthusetPlayIE.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == True
    assert KonserthusetPlayIE.suitable("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert KonserthusetPlayIE.suitable("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == True


# Generated at 2022-06-24 12:50:30.568603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:50:33.938362
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        assert(False) # Do not reach here
    except AssertionError:
        assert(True) # Correct
    except:
        assert(False) # Do not reach here


# Generated at 2022-06-24 12:50:38.202046
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_video = KonserthusetPlayIE()
    test_video._real_extract(test_url)


# Generated at 2022-06-24 12:50:39.799447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:50:48.753465
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')
    assert(ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:50:49.652914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:00.151117
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.construct_test(
            ie='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
            ret={
                'id': 'CKDDnlCY-dhWAAqiMERd-A',
                'ext': 'mp4',
                'title': 'Orkesterns instrument: Valthornen',
                'description': 'md5:f10e1f0030202020396a4d712d2fa827',
                'thumbnail': 're:^https?://.*$',
                'duration': 398.76,
            })

# Generated at 2022-06-24 12:51:02.518919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None, "Test of KonserthusetPlayIE failed because it returned None"


# Generated at 2022-06-24 12:51:05.285823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ''' 
    Creates an object for class KonserthusetPlayIE.
    '''
    if KonserthusetPlayIE() != None:
        print('Created object for class KonserthusetPlayIE.')


# Generated at 2022-06-24 12:51:09.634917
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE_obj = KonserthusetPlayIE()
    assert kpIE_obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:13.210618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """test class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:51:14.904346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE(None)
    assert kp is not None

# Generated at 2022-06-24 12:51:25.905756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()

    assert kp.name == "konserthusetplay"
    assert kp.supported_domains == [
        'konserthusetplay.se',
        'rspoplay.se',
    ]
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:28.337823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiation of a simple object from class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-24 12:51:31.552972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Checks that a valid video page can be parsed
    assert len(KonserthusetPlayIE._TESTS) > 0, 'No test specified'


# Generated at 2022-06-24 12:51:34.265488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-24 12:51:36.617285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL


# Generated at 2022-06-24 12:51:37.967680
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE(InfoExtractor)._tests

# Generated at 2022-06-24 12:51:48.441982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:51:49.839495
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_instance = KonserthusetPlayIE()
    assert test_instance

# Generated at 2022-06-24 12:51:52.724414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance( KonserthusetPlayIE( InfoExtractor() )._VALID_URL, str )
    assert isinstance( KonserthusetPlayIE( InfoExtractor() )._TESTS, list )

# Generated at 2022-06-24 12:51:54.591665
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE_instance = KonserthusetPlayIE()
    assert KonserthusetPlayIE_instance is not None


# Generated at 2022-06-24 12:52:01.737246
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0].get('url') == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:52:07.370231
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.ies_key == 'KonserthusetPlay'
    assert ie.name == 'KonserthusetPlay'

# Generated at 2022-06-24 12:52:10.909499
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_sort_formats')
    assert hasattr(ie, '_extract_m3u8_formats')
    assert hasattr(ie, '_search_regex')

# Generated at 2022-06-24 12:52:16.155543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test URL: http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = KonserthusetPlayIE._VALID_URL
    assert URL == result, "Unexpected result: '%s'. Expected: '%s'." % (result, URL)

test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:52:25.745608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test for empty url
    url = None
    ie = KonserthusetPlayIE()
    assert ie._match_id(url) == None
    assert ie._real_extract(url) == None
    # test for known url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._real_extract(url)["title"] == "Orkesterns instrument: Valthornen"

# Generated at 2022-06-24 12:52:27.000673
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # No exception
    KonserthusetPlayIE(None)

# Generated at 2022-06-24 12:52:35.904308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie.suitable(IE_DESC = 'Konserthuset Play')
    assert ie.suitable(IE_DESC = 'KonserthusetPlay')
    assert not ie.suitable(IE_DESC = 'Konserthuset')
    assert not ie.suitable(IE_DESC = 'Konserthuset Plays')
    assert not ie.suitable(IE_DESC = 'KonserthusetPlay.se')
    assert not ie.suitable(IE_DESC = 'konserthusetplay.se')

# Generated at 2022-06-24 12:52:44.620136
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test 1
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:52:47.066629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert i is not None


# Generated at 2022-06-24 12:52:58.010216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_cases_for_KonserthusetPlayIE = [{
        'url': 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
    }, {
        'url': 'http://rspoplay.se/sv/Aktuellt/RSS/RSS-fr%c3%a5n-RSPO-Play/RSS-fr%C3%A5n-RSPO-Play-1/?m=elWuEH34SMKvaO4wO_cHBw',
    }]
    for test_case in test_cases_for_KonserthusetPlayIE:
        KonserthusetPlayIE()._match_id(test_case['url'])

# Generated at 2022-06-24 12:53:03.368052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.get_id_from_url("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == "CKDDnlCY-dhWAAqiMERd-A"
    assert k.get_id_from_url("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == "elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-24 12:53:10.699203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:12.269717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert a is not None

# Generated at 2022-06-24 12:53:13.220856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert konserthusetPlayIE == 1

# Generated at 2022-06-24 12:53:17.517632
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:53:19.459187
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == ':konserthusetplay'

# Generated at 2022-06-24 12:53:20.950116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    KonserthusetPlayIE(object(), None, None)

# Generated at 2022-06-24 12:53:22.663012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extractor = "test"
    ie.test_urls_extractor_class()

# Generated at 2022-06-24 12:53:29.121678
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-24 12:53:30.301607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:53:31.717345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)



# Generated at 2022-06-24 12:53:33.423350
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-24 12:53:36.215445
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL, \
        'There is a problem with _VALID_URL in KonserthusetPlayIE'

# Generated at 2022-06-24 12:53:39.462050
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    info = KonserthusetPlayIE()._real_extract(video_id)

# Generated at 2022-06-24 12:53:41.067693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE(None)


# Generated at 2022-06-24 12:53:42.683208
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:53:44.170797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie)

# Generated at 2022-06-24 12:53:47.632139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    _KonserthusetPlay = KonserthusetPlayIE()
    # test if the class is created
    assert _KonserthusetPlay is not None, 'KonserthusetPlayIE should be created'

# Generated at 2022-06-24 12:53:49.295469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-24 12:53:57.062289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test the URL
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Test the _real_extract
    extractor = KonserthusetPlayIE(KonserthusetPlayIE)
    # The method _real_extract has been tested before in test.py

# Generated at 2022-06-24 12:53:58.166645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:54:03.269868
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()
    expected = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert result._VALID_URL == expected, "Didn't match URL to regex"


# Generated at 2022-06-24 12:54:05.237023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.info()

# Generated at 2022-06-24 12:54:10.113531
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:54:15.292556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    for url in ['https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw']:
        assert KonserthusetPlayIE(url) is not None

# Generated at 2022-06-24 12:54:25.111865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie.video_id is not None
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-24 12:54:27.205291
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert (isinstance(KonserthusetPlayIE, InfoExtractor))

# Generated at 2022-06-24 12:54:29.706108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:33.821259
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE_instance = KonserthusetPlayIE()
    assert KonserthusetPlayIE_instance.ie_key() == 'KonserthusetPlay'
    assert KonserthusetPlayIE_instance.ie_codec() == 'KonserthusetPlay'

# Generated at 2022-06-24 12:54:39.066666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    video_id = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE()
    return True

# Generated at 2022-06-24 12:54:40.497923
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test_basic(KonserthusetPlayIE)

# Generated at 2022-06-24 12:54:43.483267
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:54:50.999761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE
    assert konserthusetplayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:54:56.326593
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:55:04.494951
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Check if url is valid
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE._VALID_URL.match(url)
    # url of object id
    url2 = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    assert KonserthusetPlayIE._VALID_URL.match(url2)

    # Check if there exists extractor
    assert len(KonserthusetPlayIE._TESTS) > 0
    # Extractor at index = 0
    extractor = KonserthusetPlayIE._TESTS[0]
    # Test extractor with url
    ie = KonserthusetPlay

# Generated at 2022-06-24 12:55:12.232497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.match_url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.match_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-24 12:55:19.939558
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.extractor_key() == 'KonserthusetPlayIE'
    assert ie.extractor_name() == 'KonserthusetPlayIE'
    assert ie.valid_urls() == [r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=.*']
    assert ie.parse_url('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == {'id': 'CKDDnlCY-dhWAAqiMERd-A'}

# Generated at 2022-06-24 12:55:22.312909
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Verify that you can construct an instance
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:23.116607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:55:26.598461
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:55:28.544725
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	"""
	Constructor of class KonserthusetPlayIE.
	"""
	KonserthusetPlayIE_instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:39.049297
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiate class
    ie = KonserthusetPlayIE()
    assert ie

    # Name of parameter '_VALID_URL'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Name of parameter '_TESTS'

# Generated at 2022-06-24 12:55:41.529490
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    newObj = KonserthusetPlayIE()
    assert newObj is not None

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-24 12:55:44.553301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_obj = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie_obj.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-24 12:55:47.249064
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    >>> KonserthusetPlayIE()
    <class '__main__.KonserthusetPlayIE'>
    """
    assert(KonserthusetPlayIE)

# Generated at 2022-06-24 12:55:55.075517
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    # Should return the same result for both constructors.
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE.ie_key()



    # Should match the url
    assert(ie._match_id(url))

    web_page = ie._download_webpage(url, video_id = "CKDDnlCY-dhWAAqiMERd-A")
    assert(web_page)

    e = ie._search_regex(
    r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', web_page, 'e')
    assert(e)


# Generated at 2022-06-24 12:56:05.483093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert (ie.get_media_id('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-24 12:56:07.140325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    return k

# Generated at 2022-06-24 12:56:08.513438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_class = KonserthusetPlayIE
    test_instance = KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:18.350742
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test string extraction from webpage
    assert(KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')

# Generated at 2022-06-24 12:56:20.537719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert 'KonserthusetPlayIE' in ie.IE_NAME
    assert 'http://www.konserthusetplay.se/' in ie.VALID_URL

# Generated at 2022-06-24 12:56:23.363584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check the KonserthusetPlayIE constructor
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-24 12:56:30.341752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:31.839947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KE = KonserthusetPlayIE()
    assert KE

# Generated at 2022-06-24 12:56:32.883835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:38.350004
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj.__name__ == "KonserthusetPlay"

# Generated at 2022-06-24 12:56:40.503473
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-24 12:56:44.361970
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # NOTE: The following line is a test for the constructor of class KonserthusetPlayIE
        KonserthusetPlayIE()
    except Exception:
        # Raise AssertionError if the constructor raises an exception
        assert False

# Generated at 2022-06-24 12:56:48.427120
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({});
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-24 12:56:50.945158
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(
        {'_downloader': {'params': {}}}), InfoExtractor)

# Generated at 2022-06-24 12:56:51.980641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-24 12:56:54.102293
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with url, which has a video_id as argument
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url
    assert ie.video_id

# Generated at 2022-06-24 12:56:55.947165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test for constructor of KonserthusetPlayIE
    """
    assert KonserthusetPlayIE

# Generated at 2022-06-24 12:57:04.011610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthusetplay_ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplay_ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert k

# Generated at 2022-06-24 12:57:08.614083
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'Konserthuset Play'


# Generated at 2022-06-24 12:57:18.041432
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # When given a url pointing to konserthusetplay.se, and given a video id, test returns a video object.
    test_ie = KonserthusetPlayIE()
    test_ie._match_id = lambda x: 'CKDDnlCY-dhWAAqiMERd-A'
    test_ie._download_webpage = lambda x,y: '<html></html>'

# Generated at 2022-06-24 12:57:19.198710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-24 12:57:29.817484
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    id = 'CKDDnlCY-dhWAAqiMERd-A'
    ext = 'mp4'
    title = 'Orkesterns instrument: Valthornen'
    description = 'md5:f10e1f0030202020396a4d712d2fa827'
    thumbnail = 're:^https?://.*$'
    duration = 398.76

    url = 'http://www.konserthusetplay.se/?m=' + id
    filename = '%s-%s.%s' % (ie._search_regex(ie._VALID_URL, url, 'id'), title, ext)

    ie = KonserthusetPlayIE()

    ie.extract(url)
