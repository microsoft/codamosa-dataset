

# Generated at 2022-06-26 12:21:12.436837
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    konserthuset_play_i_e.suitable('asdf')


# Generated at 2022-06-26 12:21:18.703078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   # Test with url encoding is used
   url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
   konserthuset_play_i_e = KonserthusetPlayIE()
   konserthuset_play_i_e.url = url
   id = konserthuset_play_i_e._match_id(url)
   assert id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:21:20.049670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert test_case_0() == 'konserthuset_play'

# Generated at 2022-06-26 12:21:31.344814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    def check_output(instance, url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', query={}):
        instance.ie = InfoExtractor()
        instance.ie._downloader = FakeDownloader()
        instance.ie._downloader.params = query
        instance.ie._downloader._cache.clear()
        instance.ie._call_downloader('http://www.youtube.com/watch?v=BaW_jenozKc', 'http://unit.test', query)
        return instance.ie._downloader._cache
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    # assert_match(konserthuset_play_i_e_0._VALID_URL, url, match_type

# Generated at 2022-06-26 12:21:32.870893
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:33.450317
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:34.043301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:38.162505
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:39.246137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None

# Generated at 2022-06-26 12:21:48.358630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert konserthuset_play_i_e_0._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthuset_play_i_e_0._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthuset_play_i_e_0._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    # TODO

# Generated at 2022-06-26 12:22:02.040924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(), InfoExtractor)

# Generated at 2022-06-26 12:22:06.068185
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    k = KonserthusetPlayIE()
    k._real_extract(url)
    # Test the constructor of class KonserthusetPlayIE
    assert isinstance(k, InfoExtractor)

# Generated at 2022-06-26 12:22:07.497928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import KonserthusetPlayIE
    KonserthusetPlayIE.KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:13.817067
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test the KonserthusetPlayIE class.
    """
    ie = KonserthusetPlayIE()
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.download("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-26 12:22:15.860147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #This test produces no output.
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:22:26.240843
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test unit from line 61 to 99
    # Checking the functioning of constructor of class KonserthusetPlayIE
    # with valid urls and invalid urls
    # Test data with valid urls
    test_data_valid_urls = [
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A",
        "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    ]
    # Test data with invalid urls

# Generated at 2022-06-26 12:22:28.561049
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(downloader=None)
    ie = KonserthusetPlayIE(params=None)

# Generated at 2022-06-26 12:22:29.686172
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:38.767765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.IE_NAME == 'konserthusetplay'
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:41.332593
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-26 12:23:10.024360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-26 12:23:11.830637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert isinstance(inst, InfoExtractor)

# Generated at 2022-06-26 12:23:14.664063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:23:18.422512
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    ie = KonserthusetPlayIE()
    ie._real_extract(url)

# Generated at 2022-06-26 12:23:22.549810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE1 = KonserthusetPlayIE()
    kpIE2 = KonserthusetPlayIE()
    assert kpIE1 == kpIE1
    assert kpIE1 == kpIE2


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:24.034269
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Basic unit test for KonserthusetPlayIE
    """
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:25.654967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj

# Generated at 2022-06-26 12:23:28.015600
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._real_extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-26 12:23:39.287839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert KonserthusetPlayIE.ie_key() == 'KonserthusetPlay'
    assert KonserthusetPlayIE.ie_name() == 'KonserthusetPlay'
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:23:43.694644
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_id = 'CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    if ie._match_id(url) == test_id:
        return ie
    else:
        return None


# Generated at 2022-06-26 12:24:46.521236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of KonserthusetPlayIE
    # Input:
    #     valid_urls: A list which contains valid urls
    #     invalid_urls: A list which contains invalid urls
    # Assert:
    #     An object is created successfully.
    valid_urls = ['http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw']

# Generated at 2022-06-26 12:24:48.094854
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:24:56.959560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie.__name__ == 'konserthusetplay'
    assert ie.VALID_URL.__name__ == 'konserthusetplay'
    assert ie.VALID_URL('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.VALID_URL('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:25:00.758342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj.IE_NAME == 'KonserthusetPlay'



# Generated at 2022-06-26 12:25:08.781237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:25:11.268642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Testing for what is suggested in the docstring of InfoExtractor
    assert ie._NAME is not None
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-26 12:25:20.116310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=x0S87pJJSMKvaO4wO_cHBw')
    assert ie.metadata['id'] == 'x0S87pJJSMKvaO4wO_cHBw', ie.metadata['id']
    assert ie.metadata['title'] == 'Orkesterns instrument: Harpan', ie.metadata['title']
    assert ie.metadata['description'] == 'Harpan är ett världens äldsta instrument', ie.metadata['description']

# Generated at 2022-06-26 12:25:23.328121
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor) and ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True


# Generated at 2022-06-26 12:25:26.563275
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-26 12:25:27.006891
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:56.641226
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	
	# Test audio output is of type mp3
	def test_format_MP3(self):
		assert determine_ext('MP3') == 'mp3'

	# Create instance
	konserthuset_play = KonserthusetPlayIE()

	# Test extractor methods
	konserthuset_play.extract()
	konserthuset_play.extract_format()
	konserthuset_play.extract_formats()
	konserthuset_play.extract_flat()
	konserthuset_play.extract_flat_formats()
	
	# Test extract_playlist methods
	konserthuset_play.extract_playlist()
	konserthuset_play.extract_playlist_from_matches()
	kons

# Generated at 2022-06-26 12:27:57.604332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None, None)

# Generated at 2022-06-26 12:28:01.262809
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    
if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:28:03.030623
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # If module of class KonserthusetPlayIE is imported, a class will be constructed
    # and the constructor will be invoked
    KonserthusetPlayIE

# Generated at 2022-06-26 12:28:04.032534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # No exception should be thrown
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:28:08.366965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.name == 'Konserthuset Play'
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.info_url() == 'https://www.konserthusetplay.se/'
    assert obj.supported_domains() == ['konserthusetplay.se']

# Generated at 2022-06-26 12:28:14.390090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:28:17.370186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test for constructor for class KonserthusetPlayIE.
    """
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:28:18.524873
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie)

# Generated at 2022-06-26 12:28:20.408331
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert k