

# Generated at 2022-06-26 12:21:13.012456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    # assert_equals(expected, KonserthusetPlayIE.__init__(konserthuset_play_i_e_0))
    assert_true(konserthuset_play_i_e_0)

# Generated at 2022-06-26 12:21:20.012262
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # See https://github.com/rg3/youtube-dl/pull/8690#issuecomment-242895489
    # for why this tests runs in a separate function.
    #
    # Following test case is expected to be fixed.
    assert konserthuset_play_i_e_0.get_id_from_url('https://www.konserthusetplay.se/?m=kTjV7tw0eRt7a_tluH1W7w') == 'kTjV7tw0eRt7a_tluH1W7w'

# Generated at 2022-06-26 12:21:21.059949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-26 12:21:32.318406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    mocker = Mocker()
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    konserthuset_play_i_e_0._match_id = lambda x: 'url of type string'
    konserthuset_play_i_e_0.playlist = mock_object(konserthuset_play_i_e_0.playlist)
    konserthuset_play_i_e_0.video_id = 'url of type string'
    expected_value_1 = konserthuset_play_i_e_0._download_webpage(
        konserthuset_play_i_e_0.video_id,
        konserthuset_play_i_e_0.video_id
    )
    del k

# Generated at 2022-06-26 12:21:34.081906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:36.277648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert not KonserthusetPlayIE()
    assert KonserthusetPlayIE("url")


# Generated at 2022-06-26 12:21:46.243991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_i_e = KonserthusetPlayIE()._real_extract(url)
    assert konserthuset_play_i_e['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert konserthuset_play_i_e['ext'] == 'mp4'
    assert konserthuset_play_i_e['title'] == 'Orkesterns instrument: Valthornen'
    assert konserthuset_play_i_e['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'

# Generated at 2022-06-26 12:21:47.433776
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() != None


# Generated at 2022-06-26 12:21:51.196645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    konserthuset_play_i_e = KonserthusetPlayIE()
    x = konserthuset_play_i_e.extract(url)


# Generated at 2022-06-26 12:21:52.318147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() != None


# Generated at 2022-06-26 12:22:22.938440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')
    assert hasattr(KonserthusetPlayIE, '_TESTS')
    assert hasattr(KonserthusetPlayIE, '_download_webpage')
    assert hasattr(KonserthusetPlayIE, '_search_regex')
    assert hasattr(KonserthusetPlayIE, '_match_id')
    assert hasattr(KonserthusetPlayIE, '_extract_m3u8_formats')
    assert hasattr(KonserthusetPlayIE, '_sort_formats')
    assert hasattr(KonserthusetPlayIE, '_real_extract')

# Generated at 2022-06-26 12:22:23.941179
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

# Generated at 2022-06-26 12:22:25.850138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__doc__ == 'KonserthusetPlayIE(InfoExtractor)'


# Generated at 2022-06-26 12:22:26.709134
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

# Generated at 2022-06-26 12:22:34.772939
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # reset the imports
    KonserthusetPlayIE_globals = globals().copy()
    KonserthusetPlayIE_locals = locals().copy()
    globals().clear()
    locals().clear()
    # build the test case
    KonserthusetPlayIE_locals.update({'__name__': '__main__', '__file__': __file__, '__package__': None, '__cached__': None})
    globals().update(KonserthusetPlayIE_globals)
    locals().update(KonserthusetPlayIE_locals)
    # execute the test case
    test_case_0()

# Generated at 2022-06-26 12:22:36.697912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:37.901823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:42.111974
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_i_e = KonserthusetPlayIE()
    konserthuset_play_i_e.match_url(url)


# Generated at 2022-06-26 12:22:42.682562
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:22:45.354435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()
    assert True

# vim:ts=4:sw=4:et:syntax=python

# Generated at 2022-06-26 12:23:14.283341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_raises(Exception, KonserthusetPlayIE, "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:23:24.233440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

    # Test IE with 'http://' in url
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

# Generated at 2022-06-26 12:23:27.167717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:23:28.865311
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:23:35.143484
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Tests whether constructor of class KonserthusetPlayIE works properly."""
    konserthuset_play = KonserthusetPlayIE()
    # Test youtube-dl version
    youtube_dl_version = konserthuset_play._version()
    assert tuple(map(int, (youtube_dl_version.split(".")))) >= (2018, 2, 28)

# Generated at 2022-06-26 12:23:35.673841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-26 12:23:39.167517
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert InfoExtractor is not None
        assert KonserthusetPlayIE is not None
        return KonserthusetPlayIE()
    except Exception as e:
        print ('Failed to instantiate class KonserthusetPlayIE:' + str(e))
        raise e

# Generated at 2022-06-26 12:23:41.609384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    clazz = KonserthusetPlayIE

    attributes = ['_VALID_URL', '_TESTS']

    assert all(hasattr(clazz, attr) for attr in attributes)

# Generated at 2022-06-26 12:23:45.699783
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create object
    k = KonserthusetPlayIE()
    # Test return value of method '_real_extract'
    assert k._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    # Test return value of method '_real_extract'
    assert k._real_extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-26 12:23:48.862698
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:24:47.055935
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    kp_ie = KonserthusetPlayIE(url)
    assert kp_ie._match_id(url) == video_id

# Generated at 2022-06-26 12:24:56.267127
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.http_headers == {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:7.0.1) Gecko/20100101'
    }
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_DESC == 'KonserthusetPlay and RSOPlay'

# Generated at 2022-06-26 12:24:57.502916
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:25:05.800608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Tests for the KonserthusetPlayIE constructor."""
    info_extractor = KonserthusetPlayIE()
    assert info_extractor.ie_key() == 'KonserthusetPlay'
    assert info_extractor.ie_name() == 'KonserthusetPlay'
    assert info_extractor.ie_description() == 'KonserthusetPlay'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:25:11.203175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE."""
    # Assert that any url of youtube raises exception RegexNotFoundError
    with pytest.raises(RegexNotFoundError):
        KonserthusetPlayIE('https://www.youtube.com/watch?v=_oacRhKFWTA')

    # Assert that a valid URL in KonserthusetPlayIE returns an object
    assert type(KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')) == KonserthusetPlayIE

    # Assert that a non valid URL for KonserthusetPlayIE raises an exception

# Generated at 2022-06-26 12:25:20.021073
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE('may_be_anything_just_to_create_class')
    assert t._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:25:28.496078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    info_dict = ie._TESTS[0]['info_dict']
    assert info_dict['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:25:30.065497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay')

# Generated at 2022-06-26 12:25:34.234113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Make sure URL is valid
    assert ie._VALID_URL.match('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

    # Make sure constructor doesn't raise error
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:25:35.656643
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None

# Generated at 2022-06-26 12:27:46.103064
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset=KonserthusetPlayIE()
    print(konserthuset)

# Generated at 2022-06-26 12:27:49.753114
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:51.531168
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:27:58.458394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == ':konserthusetplay'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:59.580964
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:28:06.007790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    e = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    i = 'CKDDnlCY-dhWAAqiMERd-A'

    # test _VALID_URL
    assert ie._VALID_URL.findall(e)[0] == i

    # test _real_extract
    assert ie._real_extract(e)


# Generated at 2022-06-26 12:28:09.147435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:28:09.737511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:28:11.083073
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:28:17.833878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True)
    assert(ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == True)
    assert(ie.suitable("http://www.youtube.com/?m=CKDDnlCY-dhWAAqiMERd-A") == False)
    assert(ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&f=mp4") == False)