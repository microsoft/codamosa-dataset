

# Generated at 2022-06-26 12:21:09.012430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:10.653589
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:12.275154
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Test constructor KonserthusetPlayIE")
    assert test_case_0() == None


# Generated at 2022-06-26 12:21:14.729284
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e != None


# Generated at 2022-06-26 12:21:16.903055
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    konserthuset_play_ie = KonserthusetPlayIE(url)


# Generated at 2022-06-26 12:21:17.835991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:18.611941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert test_case_0() is None


# Generated at 2022-06-26 12:21:21.102789
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:21.885861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:23.502565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_1 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:44.952743
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:21:46.619276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:47.470678
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

# Generated at 2022-06-26 12:21:49.154565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

if __name__ == '__main__':
    test_case_0()
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:50.068332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True == (isinstance(KonserthusetPlayIE(), InfoExtractor))

# Generated at 2022-06-26 12:21:51.457509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:53.665607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert not konserthuset_play_i_e_0.error


# Generated at 2022-06-26 12:21:57.149259
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

if __name__ == '__main__':
    test_case_0()
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:59.805249
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

    assert konserthuset_play_i_e != None;


# Generated at 2022-06-26 12:22:01.187963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(0)

# Generated at 2022-06-26 12:22:27.950865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test case 1
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)', 'Incorrect VALID_URL'
    o = KonserthusetPlayIE()
    o.suitable(url) is True, 'Incorrect URL returned True'
    o.extract(url)['id'] == 'CKDDnlCY-dhWAAqiMERd-A', 'Incorrect id'
    o.extract(url)['thumbnail'] == 're:^https?://.*$',

# Generated at 2022-06-26 12:22:29.240845
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:32.445270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None)
    except:
        assert False, 'Failed to create KonserthusetPlayIE instance'
    assert True, 'Created KonserthusetPlayIE instance'


# Generated at 2022-06-26 12:22:33.739427
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:43.785397
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:52.674130
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .test_playlist_konserthusetplay_se import test_playlist_konserthusetplay_se
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        url_or_none,
    )
    from ..compat import (
        compat_str,
    )
    # Unit test for constructor of class KonserhusetPlayIE
    #
    # KonserthusetPlayIE._VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    #
    # _TESTS = [{
    # 'url': 'http://www.

# Generated at 2022-06-26 12:22:57.591008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for constructor of class KonserthusetPlayIE.
    """
    ie = KonserthusetPlayIE()
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_id = 'CKDDnlCY-dhWAAqiMERd-A'

    match = ie._VALID_URL.match(test_url)
    video_id = match.group("id")
    assert video_id == expected_id



# Generated at 2022-06-26 12:23:08.196978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test initial attributes of class KonserthusetPlayIE
    test_ie = KonserthusetPlayIE()
    assert test_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Test _real_extract method of class KonserthusetPlayIE
    KonserthusetPlayIE._real_extract(test_ie, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:23:09.223547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(isinstance(ie, KonserthusetPlayIE))

# Generated at 2022-06-26 12:23:11.406196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-26 12:23:53.869766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    return True

# Generated at 2022-06-26 12:23:56.252779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False, 'Failed to initialize instance of class KonserthusetPlayIE'

# Generated at 2022-06-26 12:24:01.640338
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Class constructor returns a video extractor object
    video_extractor_object = KonserthusetPlayIE()
    assert (
        video_extractor_object.__class__.__bases__[0].__name__ ==
        'InfoExtractor')
    assert (
        video_extractor_object.__class__.__name__ ==
        'KonserthusetPlayIE')

# Generated at 2022-06-26 12:24:06.896060
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A");

    assert konserthuset_play_ie._VALID_URL == r"https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Tests KonserthusetPlayIE._real_extract() method

# Generated at 2022-06-26 12:24:08.340133
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie._VALID_URL)
    print(ie._TESTS)




# Generated at 2022-06-26 12:24:11.716564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    obj._real_extract(url)

# Generated at 2022-06-26 12:24:19.482166
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # example 1
    assert ie._match_id(r'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # example 2
    assert ie._match_id(r'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'
    assert ie._VAL

# Generated at 2022-06-26 12:24:20.156178
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(1)

# Generated at 2022-06-26 12:24:29.312536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # First constructor call without any argument
    k = KonserthusetPlayIE()

    # Second constructor call with a video ID
    k = KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')

    # First constructor call without any argument
    k = KonserthusetPlayIE()

    # Second constructor call with a video URL
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Third constructor call with an invalid URL
    try:
        k = KonserthusetPlayIE('http://example.com/')
    except Exception as e:
        print(e)

    # Fourth constructor call with an invalid video ID

# Generated at 2022-06-26 12:24:30.384670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    p = KonserthusetPlayIE()
    assert(p)

# Generated at 2022-06-26 12:26:33.898912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:26:41.384976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    sut = KonserthusetPlayIE()
    assert sut._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:26:43.301409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE("KonserthusetPlay")
    assert k.ie_key() == "KonserthusetPlay"

# Generated at 2022-06-26 12:26:43.930132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:26:46.028992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlay", {}, {})
    log("Unit test for constructor of class KonserthusetPlayIE")
    assert ie.get_name() == "KonserthusetPlay"


# Generated at 2022-06-26 12:26:48.018866
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    kp._real_extract(r'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:26:49.983141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor without any argument
    instance = KonserthusetPlayIE()
    # test __basename__
    assert instance.IE_NAME == "konserthusetplay"
    # test IE_DESC
    assert instance.IE_DESC == "KonserthusetPlay"

# Generated at 2022-06-26 12:26:51.363526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE.ie_key())
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:26:54.135268
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie =KonserthusetPlayIE() 
    assert ie.REAL_TITLE == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)".replace("?", "\?")
    assert ie.REAL_ID == "[0-9a-zA-Z_-]+"

# Generated at 2022-06-26 12:26:56.970621
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test a valid url
    valid_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # create an instance of KonserthusetPlayIE
    inst = KonserthusetPlayIE()
    # check the 'id' of this instance
    assert(inst._match_id(valid_url) == 'CKDDnlCY-dhWAAqiMERd-A')