

# Generated at 2022-06-26 12:21:10.125265
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert type(konserthuset_play_i_e).__name__ == 'KonserthusetPlayIE'


# Generated at 2022-06-26 12:21:19.648525
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #assert_equal(KonserthusetPlayIE._VALID_URL,
                 #r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    konserthuset_play_i_e = KonserthusetPlayIE()
    #assert_equal(konserthuset_play_i_e._TESTS,
                 #[{
                     #'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                     #'md5': 'e3fd47bf44e864bd23c08e487abe1967',
                     #'info_dict': {
                         #'id': 'CKDDnl

# Generated at 2022-06-26 12:21:22.738326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert (KonserthusetPlayIE(InfoExtractor)._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')


# Generated at 2022-06-26 12:21:24.778882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:26.547014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_raises(TypeError, KonserthusetPlayIE) == None, 'Should be None'

# Generated at 2022-06-26 12:21:31.482501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e.suitable(
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-26 12:21:32.084286
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:33.957710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:37.277116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(_download_webpage=lambda a, b, c: None).__class__ == KonserthusetPlayIE


# Generated at 2022-06-26 12:21:39.884418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e is not None


# Generated at 2022-06-26 12:21:52.028209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:03.649135
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:22:05.658108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')  # download a video

# Generated at 2022-06-26 12:22:07.105972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserhusetplay = KonserhusetPlayIE()
    assert konserhusetplay is not None

# Generated at 2022-06-26 12:22:10.842967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    print("Testing KonserthusetPlayIE")
    print("Check if it is an instance of InfoExtractor")
    assert isinstance(test, InfoExtractor)
    print("check for the _VALID_URL")
    assert test._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:22.094184
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:22:23.702764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.name)
    assert(ie.description)
    assert(ie.age_limit)

# Generated at 2022-06-26 12:22:27.262537
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True



# Generated at 2022-06-26 12:22:27.948534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:31.108076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'

# Generated at 2022-06-26 12:22:55.147814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:22:56.903774
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'

# Generated at 2022-06-26 12:23:00.910057
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import KonserthusetPlayIE, kp_test
    return kp_test(KonserthusetPlayIE)

# Generated at 2022-06-26 12:23:01.803139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:03.012748
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-26 12:23:06.274189
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")


# Generated at 2022-06-26 12:23:07.353781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:23:09.073859
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:23:10.989526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:23:11.997485
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    return obj.initialize()

# Generated at 2022-06-26 12:23:59.342223
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.extract('invalid URL') == True


# Generated at 2022-06-26 12:24:02.062828
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from ytdl.extractor.common import InfoExtractor
    from ytdl.extractor.konserthusetplay import KonserthusetPlayIE

    InfoExtractor(KonserthusetPlayIE)

# Generated at 2022-06-26 12:24:03.532643
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test.IE_NAME == "KonserthusetPlay"

# Generated at 2022-06-26 12:24:09.830059
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Unit test for constructor of class KonserthusetPlayIE")
    # This Url should not match the class
    non_matching_url = "https://www.youtube.com/watch?v=a1Y73sPHKxw"
    matching_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(non_matching_url)
    assert ie.IE_NAME != "KonserthusetPlay", "Should not match"
    ie_kp = KonserthusetPlayIE(matching_url)
    assert ie_kp.IE_NAME == "KonserthusetPlay", "Should match"


# Generated at 2022-06-26 12:24:12.072259
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    y = KonserthusetPlayIE()
    y.extract(url)

# Generated at 2022-06-26 12:24:19.851888
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #
    # Setup environment
    #
    import os
    import unittest
    import sys

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    #
    # Load unittest and testcase
    #
    from test_utils import getTestCase
    from test_utils import getTestSuite
    from test_utils import setup_proxy

    setup_proxy()

    #
    # Add testcase to suite
    #
    testcase = getTestCase(KonserthusetPlayIE)
    suite = getTestSuite(testcase)

    #
    # Run test suite
    #
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-26 12:24:28.988581
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:24:34.945012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:24:37.806758
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:39.448252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    return a



# Generated at 2022-06-26 12:26:37.823423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == ('https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:26:40.345635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(KonserthusetPlayIE)
    except:
        assert False, "Unit test KonserthusetPlayIE has error"
    else:
        assert True, "Unit test KonserthusetPlayIE successfully"

# Generated at 2022-06-26 12:26:45.150370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.URL_REGEX == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.VIDEO_ID_REGEX == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.name == 'KonserthusetPlay'

# Generated at 2022-06-26 12:26:46.149959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:26:49.330459
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE,
           'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(KonserthusetPlayIE,
           'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:26:49.911790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:26:50.712175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie)



# Generated at 2022-06-26 12:26:53.434011
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE);

# Generated at 2022-06-26 12:26:54.607972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.test()
    assert ie.succeeded()

# Generated at 2022-06-26 12:26:57.240077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("url", "VideoID")
    assert ie is not None
    assert ie.ie_key() == "KonserthusetPlay"
    assert ie.ie_urls() == [("url", "VideoID")]
    assert ie.video_id() == "VideoID"