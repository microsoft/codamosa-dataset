

# Generated at 2022-06-26 12:21:10.827215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:21:12.507504
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:13.612741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0


# Generated at 2022-06-26 12:21:16.470626
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('Inside constructor of class KonserthusetPlayIE')
    konserthuset_play_i_e_1 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:17.380266
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass


# Generated at 2022-06-26 12:21:19.647621
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  obj = KonserthusetPlayIE() # KonserthusetPlayIE
  assert isinstance(obj, KonserthusetPlayIE)


# Generated at 2022-06-26 12:21:22.423122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Checks whether constructor of class KonserthusetPlayIE exists
    assert type(KonserthusetPlayIE()) == KonserthusetPlayIE
    assert type(test_case_0()) == KonserthusetPlayIE


# Generated at 2022-06-26 12:21:25.179414
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert "KonserthusetPlayIE" == KonserthusetPlayIE.__name__


# Generated at 2022-06-26 12:21:27.146419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0.provider() == 'konserthusetplay'

# Generated at 2022-06-26 12:21:34.136984
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_1 = KonserthusetPlayIE()
    # Tests whether variable '_VALID_URL' of class KonserthusetPlayIE has expected value.
    assert konserthuset_play_i_e_1._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:21:45.643392
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('', '')

# Generated at 2022-06-26 12:21:55.133188
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:56.458853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:58.579954
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k is not None and k.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-26 12:22:05.487538
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.can_handle_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:22:12.110959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    test_video = KonserthusetPlayIE()
    test_video.initialize(url)

    assert hasattr(test_video, '_real_initialize')
    assert hasattr(test_video, '_real_extract')
    assert hasattr(test_video, '_match_id')


# Generated at 2022-06-26 12:22:15.199018
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.get_ie_key() == ie.ie_key()
    assert ie.get_host() == ie.host()


# Generated at 2022-06-26 12:22:16.411995
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:26.553849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instance
    class_name = '_' + KonserthusetPlayIE.__name__
    test_instance = KonserthusetPlayIE(
        class_name, {}, {'name': class_name, 'test': True})

    assert test_instance.name == class_name
    assert test_instance._downloader.params['test']

    # Test expected exceptions for the case of empty or invalid url
    url = 'http://www.konserthusetplay.se'
    for invalid_url in ('', 'http://', url,
                        'http://www.konserthusetplay.se/?m='):
        with pytest.raises(Exception) as excinfo:
            KonserthusetPlayIE(class_name, {}, {'name': class_name, 'url': invalid_url})


# Generated at 2022-06-26 12:22:28.254653
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay.se'
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:22:51.827931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

    holder = KonserthusetPlayIE(url)
    holder._match_id(url)

# Generated at 2022-06-26 12:22:58.423862
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # For testing do not download the file but catch the exception if download fails.
    expect_404_error = False

# Generated at 2022-06-26 12:23:00.778318
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    sut = KonserthusetPlayIE()
    assert sut is not None

# Generated at 2022-06-26 12:23:01.710258
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    my_extractor = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:07.501942
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0].get('url') == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[1].get('url') == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-26 12:23:09.234347
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._extract_video_info_rest == ie._real_extract

# Generated at 2022-06-26 12:23:10.089823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:23:11.021477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:23:16.909481
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print("Testing KonserthusetPlayIE constructor with valid url")
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    print("Testing KonserthusetPlayIE constructor with invalid url")
    assert not ie.suitable("yotube.com")
    print("Testing KonserthusetPlayIE constructor with valid url")
    assert ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    print("Testing KonserthusetPlayIE constructor with invalid url")
    assert not ie.suitable("yotube.com")


# Generated at 2022-06-26 12:23:20.031135
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL is KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:24:06.181202
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # Create unit test instance
    test_KonserthusetPlayIE = KonserthusetPlayIE()

    # Test init
    assert test_KonserthusetPlayIE._VALID_URL is not None
    assert test_KonserthusetPlayIE._TESTS is not None
    assert len(test_KonserthusetPlayIE._TESTS) > 0


# Generated at 2022-06-26 12:24:06.929599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:24:12.338602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))
    assert(ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"))
    assert(not ie.suitable("http://www.konserthusetplay.se/video/pojke-vill-inte-dela-med-sig/"))

# Generated at 2022-06-26 12:24:15.947560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE(InfoExtractor())
    
    assert instance._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:21.785040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert ie._HTML_ENCODING == 'utf-8'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.thumbnail == ie._og_search_thumbnail
    assert ie.extract(ie.ie_key(), ie._VALID_URL)

# Generated at 2022-06-26 12:24:22.879737
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:23.812998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:29.835388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.report_lang()

# Generated at 2022-06-26 12:24:31.164819
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:41.539910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:26:43.714552
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-26 12:26:44.607570
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    

# Generated at 2022-06-26 12:26:45.198497
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:26:45.792316
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:26:47.970346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:26:48.741415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  
    assert KonserthusetPlayIE()


# Generated at 2022-06-26 12:26:49.566991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:26:53.927629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.name == 'KonserthusetPlayIE'
    assert inst.ie_key() == 'KonserthusetPlayIE'
    assert inst.thumbnail == 're:^https?://.*$'
    assert inst.description == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert inst.duration == 398.76
    assert inst.ext == 'mp4'
    assert inst.title == 'Orkesterns instrument: Valthornen'
    assert inst.id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:26:54.834676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-26 12:26:55.775273
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.register_ie()