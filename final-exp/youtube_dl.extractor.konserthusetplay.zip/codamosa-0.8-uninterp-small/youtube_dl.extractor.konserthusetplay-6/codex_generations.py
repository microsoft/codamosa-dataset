

# Generated at 2022-06-26 12:21:11.910084
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # works fine
        konserthuset_play_i_e = KonserthusetPlayIE()
    except Exception as e:
        assert False, "Error occurred: " + str(e)
    else:
        assert True, "Success!"

# Generated at 2022-06-26 12:21:13.340591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:22.511290
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0._downloader.params['http_chunk_size'] == 10485760
    assert konserthuset_play_i_e_0._downloader.params['noprogress'] == True
    assert konserthuset_play_i_e_0._downloader.params['prefer_insecure'] == False
    assert konserthuset_play_i_e_0._downloader.params['prefer_ffmpeg'] == False
    assert konserthuset_play_i_e_0._downloader.params['verbose'] == False
    assert konserthuset_play_i_e_0._match_id(None) == None
    assert konserthuset_play_i_e_0._match_id('') == None

# Generated at 2022-06-26 12:21:25.324132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:21:28.358281
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e is not None


# Generated at 2022-06-26 12:21:32.428154
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:21:33.400860
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equal(0,0)


# Generated at 2022-06-26 12:21:37.883974
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:40.860938
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Call the constructor of the class
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert konserthuset_play_i_e_0


# Generated at 2022-06-26 12:21:45.472794
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'KonserthusetPlayIE' == KonserthusetPlayIE.__name__
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert konserthuset_play_i_e_0._TESTS == KonserthusetPlayIE._TESTS


# Generated at 2022-06-26 12:22:11.975843
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None, 'Unit test for constructor of class KonserthusetPlayIE failed.'
    assert KonserthusetPlayIE() is not None, 'Unit test for constructor of class KonserthusetPlayIE failed.'


# Generated at 2022-06-26 12:22:15.155380
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'test_case_0' in globals(), 'test_case_0 is undefined'
    assert test_case_0
    assert test_case_0.__class__ == KonserthusetPlayIE

# Generated at 2022-06-26 12:22:24.671583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equal(konserthuset_play_i_e_0.ie_key(), 'KonserthusetPlay', 'Wrong ie_key() returns')
    # TODO: need to find a way to test this.
#     konserthuset_play_i_e_0.report_extraction(video_id, video_title, video_url, video_thumbnail, video_ext, duration, video_format)
    # TODO: need to find a way to test this.
#     konserthuset_play_i_e_0.report_download_webpage(video_id, video_title, video_url, video_thumbnail, video_ext, duration, video_format)

# Generated at 2022-06-26 12:22:30.964378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-26 12:22:32.673710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0._downloader is not None


# Generated at 2022-06-26 12:22:34.339674
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    m = KonserthusetPlayIE()
    m.update_formats()
    assert m


# Generated at 2022-06-26 12:22:35.556159
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:37.757531
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e is not None


# Generated at 2022-06-26 12:22:47.284992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # check if KonserthusetPlayIE constructor parses url string correctly
    assert KonserthusetPlayIE(url='https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A').url =='https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Testing of constructor of KonserthusetPlayIE class ends here.
# Testing of _real_extract method of KonserthusetPlayIE class starts here.
# KonserthusetPlayIE._real_extract takes 2 parameters, the first parameter being self, and the second parameter being url.
# We have provided a testing url in the code.

# Generated at 2022-06-26 12:22:48.178411
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:20.778247
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    return ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:23:22.146328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test instantiation
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:24.588779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().match_url(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-26 12:23:28.016945
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None, 'Could not instantiate class KonserthusetPlayIE'
		
if __name__ == '__main__':
	test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:30.616904
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert(k.ie_key() == 'KonserthusetPlay')
    

# Generated at 2022-06-26 12:23:31.777924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:33.630035
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:23:43.257124
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    info_extractor = KonserthusetPlayIE()
    assert (info_extractor._VALID_URL ==
            r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert info_extractor._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert info_extractor._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-26 12:23:45.756426
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(url)

# Generated at 2022-06-26 12:23:56.834648
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None
    assert KonserthusetPlayIE._downloader is not None
    assert KonserthusetPlayIE._download_webpage is not None
    assert KonserthusetPlayIE._match_id is not None
    assert KonserthusetPlayIE._extract_m3u8_formats is not None
    assert KonserthusetPlayIE._search_regex is not None
    assert KonserthusetPlayIE._download_json is not None
    assert KonserthusetPlayIE._sort_formats is not None
    assert (KonserthusetPlayIE._real_extract is not None) and callable(KonserthusetPlayIE._real_extract)

# Generated at 2022-06-26 12:25:00.010292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Constructor test
    """
    instance = KonserthusetPlayIE()
    assert(instance)



# Generated at 2022-06-26 12:25:03.015484
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthusetplay.tv'



# Generated at 2022-06-26 12:25:09.806779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_playlist import test_playlist
    from .test_playlists import test_playlists
    from .test_global_options import test_global_options

    # Test for KonserthusetPlayIE constructor
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie._VALID_URL == ie.valid_url()

    # Test for KonserthusetPlayIE.extractor

# Generated at 2022-06-26 12:25:13.014502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Test for constructor of class KonserthusetPlayIE.

    Assert creation of object for class
    '''
    obj = KonserthusetPlayIE("")
    assert obj is not None
    assert isinstance(obj, KonserthusetPlayIE)


# Generated at 2022-06-26 12:25:15.186019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    

# Generated at 2022-06-26 12:25:23.104963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:25:24.278748
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert_true(ie)

# Generated at 2022-06-26 12:25:26.219152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUCCESS

# Generated at 2022-06-26 12:25:28.181868
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract_url("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-26 12:25:32.276807
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = type(b'KonserthusetPlayIE', (KonserthusetPlayIE,), {b'ie_key': b'KonserthusetPlay'})
    ie = class_(None)
    assert ie.ie_key() == 'KonserthusetPlay', ie.ie_key()
    assert ie.ie_name() in ie.ie_key(), ie.ie_name()

# Generated at 2022-06-26 12:27:48.654577
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test #1 Check if class can be constructed
    #
    # Expected result: a instance of KonserthusetPlayIE is returned
    #
    # First test of pre-alpha version, should be better tests!
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE) == True

# Generated at 2022-06-26 12:27:49.923147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    Konserthuset_play = KonserthusetPlayIE()
    return Konserthuset_play

# Generated at 2022-06-26 12:27:50.556931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:54.349416
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'Konserthuset Play'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:56.062630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert type(ie) == KonserthusetPlayIE  # constructor test 1



# Generated at 2022-06-26 12:27:59.902256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A","CKDDnlCY-dhWAAqiMERd-A")
    ie._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:28:08.315557
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:28:14.359958
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	str = "http://konserthusetplay.se/?m=B1fRXHXlSMKvaO4wO_cHBw"
	regex_match = re.match(r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)', str)
	if regex_match:
		match_group = regex_match.groups()
		print(match_group)
		if len(match_group) == 1:
			print(match_group[0])
			assert(match_group[0] == "B1fRXHXlSMKvaO4wO_cHBw")
			return match_group[0]

# Generated at 2022-06-26 12:28:15.813419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that the class constructor succeeds
    x = KonserthusetPlayIE()
    # Check that it is an instance of VideoInfoExtractor
    assert(isinstance(x, InfoExtractor))

# Generated at 2022-06-26 12:28:23.280992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'