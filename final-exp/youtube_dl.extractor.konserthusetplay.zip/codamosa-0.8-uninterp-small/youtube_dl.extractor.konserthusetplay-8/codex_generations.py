

# Generated at 2022-06-26 12:21:18.399067
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:19.397768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

# Generated at 2022-06-26 12:21:25.818791
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest
    import sys
    import os
    import urllib
    from .common import InfoExtractor
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        url_or_none,
    )


# Generated at 2022-06-26 12:21:33.491442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    _VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # url =  'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # video_id = konserthuset_play_i_e_0._match_id(url)
    KonserthusetPlayIE()



# Generated at 2022-06-26 12:21:36.741119
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:21:43.114024
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an instance of the class KonserthusetPlayIE
    konserthuset_play_i_e_0 = KonserthusetPlayIE()

    # Run an unit test for method KonserthusetPlayIE._real_extract
    konserthuset_play_i_e_0._real_extract(str(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))


# Generated at 2022-06-26 12:21:45.132333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check if all variables are initialised properly
    assert konserthuset_play_i_e_0.url, "test_case_0"

# Generated at 2022-06-26 12:21:46.784596
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e=KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:47.913724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('Test case 0')
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:49.008373
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert bool(KonserthusetPlayIE()) is True


# Generated at 2022-06-26 12:22:04.304120
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

if __name__ == "__main__":
    # Unit test for constructor of class KonserthusetPlayIE
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:11.049955
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:22:14.042309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert callable(ie)
    return


# Generated at 2022-06-26 12:22:15.723973
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suite()

test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:18.279248
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert type(konserthusetPlayIE) is KonserthusetPlayIE

# Generated at 2022-06-26 12:22:23.331533
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    try:
        assert ie
        assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    except:
        pass

# Generated at 2022-06-26 12:22:25.134339
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:22:26.035243
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:27.184292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:28.047128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:22:52.403496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset = KonserthusetPlayIE()
    assert konserthuset is not None

# Generated at 2022-06-26 12:22:58.770001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.ie_name() == 'KonserthusetPlay')
    assert(ie.ie_urls() == ['Konserthuset, rspoplay'])
    assert(len(ie._TESTS) == 2)
    # Test case: valid url

# Generated at 2022-06-26 12:23:02.087483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert True

# Generated at 2022-06-26 12:23:07.841015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') is None

# Generated at 2022-06-26 12:23:10.494976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_url = 'http://www.konserthusetplay.se/mediaplayer/mediaplayer/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Check if the url can be recognized
    assert KonserthusetPlayIE._VALID_URL == KonserthusetPlayIE._match_id(video_url)

# Generated at 2022-06-26 12:23:12.480883
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie.ie_key() == 'KonserthusetPlay';

# Generated at 2022-06-26 12:23:15.282756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-26 12:23:20.738716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    # Unit test for method _real_extract from class KonserthusetPlayIE
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    print(KonserthusetPlayIE()._real_extract(test_url))



# Generated at 2022-06-26 12:23:28.229263
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=aPqZWFJU-hYcAtRUhuAEFQ')
    assert extractor._match_id('https://www.konserthusetplay.se/?m=aPqZWFJU-hYcAtRUhuAEFQ') == 'aPqZWFJU-hYcAtRUhuAEFQ'
    assert extractor._real_extract('https://www.konserthusetplay.se/?m=aPqZWFJU-hYcAtRUhuAEFQ') != 0

# Generated at 2022-06-26 12:23:30.125154
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie


# Generated at 2022-06-26 12:24:19.727481
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    k = KonserthusetPlayIE()
    assert k.match_id == 'KonserthusetPlay'
    assert k.match_url == KonserthusetPlayIE._VALID_URL
    assert k.match_url == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:24:28.833980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """

    # Test raises error if wrong url is given
    url = 'https://www.konserthusetplay.se/'
    assert KonserthusetPlayIE._match_id(url) is None

    url = 'https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert KonserthusetPlayIE._match_id(url) is not None

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._match_id(url) is not None


# Generated at 2022-06-26 12:24:33.906904
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor())._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:42.282634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert info_extractor._TESTS[0]["url"] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert info_extractor._TESTS[0]["md5"] == "e3fd47bf44e864bd23c08e487abe1967"

# Generated at 2022-06-26 12:24:51.219978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:54.130329
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:55.390254
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:24:57.758424
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #Create object
    if KonserthusetPlayIE():
    #if l.extract():
        print("KonserthusetPlayIE object - OK")
    else:
        print("KonserthusetPlayIE object - ERROR")

# Generated at 2022-06-26 12:24:59.037530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:25:00.426420
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:27:10.210337
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k is not None

# Generated at 2022-06-26 12:27:17.286991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:19.212076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Class KonserthusetPlayIE should inherit from class InfoExtractor
    ie = KonserthusetPlayIE()
    assert issubclass(KonserthusetPlayIE, InfoExtractor)


# Generated at 2022-06-26 12:27:20.845603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_instance = KonserthusetPlayIE();
    succeeded = isinstance(ie_instance, KonserthusetPlayIE);
    assert succeeded;

# Generated at 2022-06-26 12:27:28.640658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.IE_NAME == 'KonserthusetPlay'
    assert inst.ie_key() == 'KonserthusetPlay'

    # those tests should fail:
    try:
        KonserthusetPlayIE(None, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    except Exception as e:
        assert isinstance(e, TypeError)

    try:
        KonserthusetPlayIE('KonserthusetPlay', None)
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-26 12:27:30.017017
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:31.002930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:27:34.609044
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:27:37.458410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test class instantiation
    instance = KonserthusetPlayIE()
    # test for existence of member variables
    assert hasattr(instance, '_VALID_URL')
    assert hasattr(instance, '_TESTS')
    assert hasattr(instance, '_real_extract')


# Generated at 2022-06-26 12:27:45.096607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.format_ids == ['rtmp-lo', 'http-lo', 'hls-lo']