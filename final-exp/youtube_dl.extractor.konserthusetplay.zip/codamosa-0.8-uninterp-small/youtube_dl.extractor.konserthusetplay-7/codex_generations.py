

# Generated at 2022-06-26 12:21:11.421765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None


# Generated at 2022-06-26 12:21:12.949767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Declare variable konserthuset_play_i_e_0 of type KonserthusetPlayIE
    konserthuset_play_i_e_0 = None

    assert konserthuset_play_i_e_0 is None


# Generated at 2022-06-26 12:21:18.615602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    # Check instance created properly
    assert konserthuset_play_i_e_0.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not konserthuset_play_i_e_0.suitable('foo')


# Generated at 2022-06-26 12:21:29.598342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    URL = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    assert konserthuset_play_i_e._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert konserthuset_play_i_e._downloader.cache.__

# Generated at 2022-06-26 12:21:30.702902
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    #except TypeError:
    except:
        #assert False
        raise
    else:
        #assert True
        pass


# Generated at 2022-06-26 12:21:32.953762
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
# testing attribute '_VALID_URL'

# Generated at 2022-06-26 12:21:33.900279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:35.206766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:36.284181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass # TODO

# Generated at 2022-06-26 12:21:41.442232
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    pafy_0 = konserthuset_play_i_e_0._real_extract(url)


# Generated at 2022-06-26 12:21:57.978961
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-26 12:21:59.102487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:22:06.721175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    r = KonserthusetPlayIE()
    r = KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    r = KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    r = KonserthusetPlayIE.suitable('http://rspoplay.se/')
    r = KonserthusetPlayIE.IE_NAME
    r = KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:22:09.385063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert a.ie_key() == "KonserthusetPlay"

# Generated at 2022-06-26 12:22:14.130429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie.ie_description() == 'Videos on www.konserthusetplay.se'

# Generated at 2022-06-26 12:22:24.662370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract(
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # Test if constructor works when no URL is provided
    ie = KonserthusetPlayIE(None)
    ie.extract(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract(
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
# Unit test

# Generated at 2022-06-26 12:22:25.539689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True == True

# Generated at 2022-06-26 12:22:28.047341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-26 12:22:29.278898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:38.435256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:07.602901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()
    assert e._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert e._TESTS[0]["url"] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert e._TESTS[0]["md5"] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert e._TESTS[0]["info_dict"]["id"] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:23:11.060217
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_common import test_template, __test_template__, __test_template_py__
    __test_template__('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'konserthusetplay.py', KonserthusetPlayIE)

# Generated at 2022-06-26 12:23:11.797321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:14.164029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:24.114364
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    konserthuset_play_ie = KonserthusetPlayIE()
    assert konserthuset_play_ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:26.412710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    assert(KonserthusetPlayIE() != '')

# Generated at 2022-06-26 12:23:31.421525
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:23:33.223385
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    importer_test = globals()['KonserthusetPlayIE']()


# Generated at 2022-06-26 12:23:37.159266
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # KonserthusetPlayIE is abstract, so create object from children class
    object = KonserthusetPlayIE(KonserthusetPlayIE.ie_key())
    assert object



# Generated at 2022-06-26 12:23:38.127408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:24:29.694365
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'

# Generated at 2022-06-26 12:24:31.346019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    myInstance = KonserthusetPlayIE()
    assert myInstance != None

# Generated at 2022-06-26 12:24:41.659336
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:44.419104
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert "KonserthusetPlayIE constructor"
        KonserthusetPlayIE()
    except Exception:
        print("Failed to create the KonserthusetPlayIE object")


# Generated at 2022-06-26 12:24:45.292457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:46.235589
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:51.285692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    # Check if it's the right class
    assert isinstance(instance, KonserthusetPlayIE)

    # Check if url can be used
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert len(instance._match_id(url)) != 0

# Generated at 2022-06-26 12:24:52.275760
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:24:54.168162
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:24:58.900770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None
    assert KonserthusetPlayIE._download_webpage is not None
    assert KonserthusetPlayIE._search_regex is not None
    assert KonserthusetPlayIE._download_json is not None
    assert KonserthusetPlayIE._real_extract is not None

# Generated at 2022-06-26 12:27:10.622405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_md5 = 'e3fd47bf44e864bd23c08e487abe1967'
    result = info_extractor.extract(test_url)
    assert result == {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$'
    }

# Generated at 2022-06-26 12:27:12.013076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.working


# Generated at 2022-06-26 12:27:16.046467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with open('test_KonserthusetPlayIE.html', 'r') as test_file:
        webpage = test_file.read()
    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda x, y: webpage
    info_dict = ie._real_extract(ie._VALID_URL)
    assert info_dict['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:18.420123
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:27:24.825480
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Checks if the constructor of the class KonserthusetPlayIE is correct
    if ie.url is not 'konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A':
        print("Error: Constructor of class KonserthusetPlayIE is not correct")
        return None
    else:
        print("Success: Constructor of class KonserthusetPlayIE is correct")
        return None
# End of unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:27:25.663891
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:27.530479
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from youtube_dl.utils import ExtractorError
    try:
        KonserthusetPlayIE()
    except ExtractorError as err:
        assert type(err) == ExtractorError

# Generated at 2022-06-26 12:27:28.210839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:31.242034
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:31.972679
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()