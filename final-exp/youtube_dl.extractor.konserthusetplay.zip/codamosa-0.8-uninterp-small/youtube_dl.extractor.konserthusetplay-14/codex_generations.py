

# Generated at 2022-06-26 12:21:08.705847
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:18.097829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:20.910679
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__ == 'KonserthusetPlayIE(InfoExtractor)'


# Generated at 2022-06-26 12:21:22.284993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'konserthuset_play_i_e_0 = KonserthusetPlayIE()'

# Generated at 2022-06-26 12:21:25.036809
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:28.454392
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0.konserthuset_play_i_e_0.konserthuset_play_i_e_0.IE_DESC


# Generated at 2022-06-26 12:21:38.253476
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test case 0
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    konserthuset_play_i_e_0.suitable(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    konserthuset_play_i_e_0.suitable(u'https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    konserthuset_play_i_e_0.suitable(u'http://www.konserthusetplay.se/')


# Generated at 2022-06-26 12:21:47.657971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check if constructor exists
    try:
        KonserthusetPlayIE()
    except NameError:
        assert False, 'KonserthusetPlayIE constructor not found.'
        return
    # Check if instance constructor exists
    try:
        konserthuset_play_i_e = KonserthusetPlayIE()
    except NameError:
        assert False, 'KonserthusetPlayIE instance constructor not found.'
        return
    # Check if instance could be created
    if not isinstance(konserthuset_play_i_e, KonserthusetPlayIE):
        assert False, 'KonserthusetPlayIE instance could not be created.'
        return
    # Check if instance could be created with url

# Generated at 2022-06-26 12:21:50.255783
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        test_case_0()
    except AssertionError as inst:
        print(inst)
    else:
        print('passed')

if __name__ == '__main__': test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:51.952518
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    

# Generated at 2022-06-26 12:22:07.829726
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', {})
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay.se'

# Generated at 2022-06-26 12:22:18.732095
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:22.717288
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)

# Generated at 2022-06-26 12:22:24.619874
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-26 12:22:27.787777
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    try:
        KonserthusetPlayIE(url)
    except Exception as e:
        return False

    return True

# Generated at 2022-06-26 12:22:29.463956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 12:22:30.144418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:22:32.896429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:22:37.513367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    This test tests the KonserthusetPlayIE constructor
    """
    ie = KonserthusetPlayIE('http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # Asserts that the file is a KonserthusetPlayIE instance
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:22:39.953383
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE._VALID_URL, str)
    assert type(KonserthusetPlayIE._TESTS) == list

# Generated at 2022-06-26 12:23:14.927802
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test for constructor of class KonserthusetPlayIE"""
    # Create a new KonserthusetPlayIE instance
    url_konserthusetplay = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url_rspoplay = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie_konserthusetplay = KonserthusetPlayIE(
        downloader=None,
        downloader_options={},
        ie_key=None,
        params=None
    )

# Generated at 2022-06-26 12:23:24.792950
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlayIE", "http://www.konserthusetplay.se/")
    assert ie.params["_VALID_URL"] == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.params["_TESTS"][0]["url"] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.params["_TESTS"][1]["url"] == "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-26 12:23:26.079251
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:23:37.456400
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:39.389244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-26 12:23:41.220942
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-26 12:23:42.126080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:23:47.349541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-26 12:23:59.168343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthusetplay_ie.ie_key() == 'KonserthusetPlay'
    assert konserthusetplay_ie.ie_key() == konserthusetplay_ie.IE_NAME
    assert konserthusetplay_ie.ie_key() == konserthusetplay_ie._VALID_URL
    assert konserthusetplay_ie._VALID_URL == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:24:00.905521
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_common import test_IE_constructor
    test_IE_constructor(KonserthusetPlayIE)

# Generated at 2022-06-26 12:25:04.164372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.name() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:25:08.891906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    id = 'CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.suitable(url)
    ie.extract(url)
    assert ie.url == url
    assert ie._match_id(url) == id
    assert ie._real_extract(url)

# Generated at 2022-06-26 12:25:16.596451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test if the constructor of KonserthusetPlayIE works
    valid_url = KonserthusetPlayIE._VALID_URL
    assert isinstance(re.fullmatch(valid_url, url), re.Match)
    # Test if the constructor of KonserthusetPlayIE extracts the video ID from the URL
    assert KonserthusetPlayIE._match_id(url) == video_id



# Generated at 2022-06-26 12:25:22.267513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj_real_extract = obj._real_extract
    obj_match_id = obj._match_id
    obj_search_regex = obj._search_regex
    assert isinstance(obj, InfoExtractor)
    assert isinstance(obj_real_extract, KonserthusetPlayIE._real_extract)
    assert isinstance(obj_match_id, KonserthusetPlayIE._match_id)
    assert isinstance(obj_search_regex, KonserthusetPlayIE._search_regex)


# Generated at 2022-06-26 12:25:23.838898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that KonserthusetPlayIE can be initialized
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:25:25.072007
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None, None)

# Generated at 2022-06-26 12:25:27.622176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:25:28.523832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None, None)

# Generated at 2022-06-26 12:25:36.032848
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp_ie = KonserthusetPlayIE()
    assert callable(kp_ie)
    assert KonserthusetPlayIE().IE_NAME == 'konserthusetplay'
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE().IE_DESC == 'KonserthusetPlay'

# Generated at 2022-06-26 12:25:38.702556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert "KonserthusetPlayIE" == k.ie_key()
    assert "KonserthusetPlay" == k.ie_key(True)



# Generated at 2022-06-26 12:27:46.259930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE.test();

# Generated at 2022-06-26 12:27:47.433061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:27:48.140344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert unicode_literals

# Generated at 2022-06-26 12:27:48.758047
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE();

# Generated at 2022-06-26 12:27:50.031807
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().ie_key() == 'KonserthusetPlay'
#

# Generated at 2022-06-26 12:27:54.757388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&variant=h264-large"
    extractor = KonserthusetPlayIE()
    assert extractor.IE_NAME == 'konserthusetplay'

    # TODO(mwilander): Make this test pass
    # assert extractor.IE_DESC == 'Rikskonserter'
    assert extractor._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:27:57.604378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_obj = KonserthusetPlayIE()
    c = test_obj.__class__
    assert c.__name__ == "KonserthusetPlayIE"
    assert c.ie_key() == "KonserthusetPlay"
    assert c.ie_key() in c.supported_ie_keys()

# Generated at 2022-06-26 12:28:03.558311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_urls = [
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
    ]

# Generated at 2022-06-26 12:28:09.147206
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.SUFFIX == 'konserthusetplay.se'
    assert ie.VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Unit tests for extracted video data from class KonserthusetPlayIE

# Generated at 2022-06-26 12:28:09.986223
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('','','','');
