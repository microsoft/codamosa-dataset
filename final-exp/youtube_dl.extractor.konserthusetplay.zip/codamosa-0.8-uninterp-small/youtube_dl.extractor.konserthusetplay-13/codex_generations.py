

# Generated at 2022-06-26 12:21:09.702751
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:21:10.202280
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:11.649303
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_true(KonserthusetPlayIE())


# Generated at 2022-06-26 12:21:20.865861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Extract info from test case 0
    extract_info = konserthuset_play_i_e_0.extract(u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Check that the test case 0 pass
    assert(extract_info['id'] == u'CKDDnlCY-dhWAAqiMERd-A')
    assert(extract_info['ext'] == u'mp4')
    assert(extract_info['title'] == u'Orkesterns instrument: Valthornen')

# Generated at 2022-06-26 12:21:32.034741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:33.536317
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass # TODO: construct object and perform assertions


# Generated at 2022-06-26 12:21:34.482016
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:45.044626
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global sha1_hash_of_KonserthusetPlayIE
    global content_of_KonserthusetPlayIE
    sha1_hash_of_KonserthusetPlayIE = hashlib.sha1(open('./test_cve_2017_1000117.py', 'r').read()).hexdigest()

# Generated at 2022-06-26 12:21:45.647857
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:47.239132
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:00.501198
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check if we can construct a KonserthusetPlayIE()
    ie = KonserthusetPlayIE();

# Generated at 2022-06-26 12:22:08.944093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:09.835179
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-26 12:22:17.492815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Given an URL for KonserthusetPlayIE and a valid video ID should return a valid video"""

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    result = instance._real_extract(url, video_id)

    assert(result)

# Generated at 2022-06-26 12:22:18.956686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("test", "test")._real_extract("test")

# Generated at 2022-06-26 12:22:21.485425
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k._VALID_URL is not None

# Generated at 2022-06-26 12:22:22.759135
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    result = instance._real_extract("")
    assert(result is not None)

# Generated at 2022-06-26 12:22:29.649038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:30.633228
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:39.670905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:06.196561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('')


# Generated at 2022-06-26 12:23:13.347736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test_cases = [
        {
            'url' : 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
            'obj_type' : KonserthusetPlayIE,
            'id' : 'elWuEH34SMKvaO4wO_cHBw',
        },
        {
            'url' : 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
            'obj_type' : KonserthusetPlayIE,
            'id' : 'CKDDnlCY-dhWAAqiMERd-A',
        },
    ]


# Generated at 2022-06-26 12:23:16.605519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:23:18.330887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    pass

# Generated at 2022-06-26 12:23:19.264308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:23:28.441641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.url_re == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')['id'] == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-26 12:23:31.645507
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:32.670523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:35.540799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-26 12:23:42.232975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE()
    assert video.ie_key() == "konserthusetplay"
    assert video.extract_id("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == "CKDDnlCY-dhWAAqiMERd-A"
    assert video.extract_id("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") == "elWuEH34SMKvaO4wO_cHBw"

# Generated at 2022-06-26 12:24:36.834901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import konserthusetplay
    assert konserthusetplay is not None

# Generated at 2022-06-26 12:24:40.608307
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_name = ie.ie_key()
    ie_type = ie.ie_key()
    ie_info = ie.ie_key()

    assert ie.suitable(ie_name)
    assert ie.suitable(ie_type)
    assert ie.suitable(ie_info)

# Generated at 2022-06-26 12:24:46.182095
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test for KonserthusetPlayIE
    """
    # Unit test for constructor of class KonserthusetPlayIE
    youtube_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE.KONSERTHUSETPLAY_URL = youtube_url
    ie = KonserthusetPlayIE(youtube_url)

    # Unit test for _match_id method
    assert ie._match_id(youtube_url) == "CKDDnlCY-dhWAAqiMERd-A", \
        "Unit test for _match_id method failed"

    # Unit test for _real_extract method

# Generated at 2022-06-26 12:24:50.984147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE()
    if test_KonserthusetPlayIE.__class__ == KonserthusetPlayIE:
        print("Success: Constructor of class KonserthusetPlayIE")
    else:
        print("Failure: Constructor of class KonserthusetPlayIE")


# Generated at 2022-06-26 12:24:59.000201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:25:00.386961
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-26 12:25:08.540245
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    from youtube_dl.extractor.konserthusetplay import KonserthusetPlayIE
    konserthusetplay = KonserthusetPlayIE()
    title = "Orkesterns instrument: Valthornen"
    video_id = "CKDDnlCY-dhWAAqiMERd-A"
    description = "Här berättar valthornisten Pär Lindgren om sitt instrument. Har du några frågor till valthornisten? Skriv till oss på Facebook.com/rspoplay.se\r\n\r\nFilm av Frida Klingspor / Foto av Peter Cederin / Färgläggning av Robin Ramstedt\r\nProducerat av Konserthuset Play"

# Generated at 2022-06-26 12:25:09.050787
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:25:09.907871
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE


# Generated at 2022-06-26 12:25:10.958267
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-26 12:27:28.787561
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:27:30.676527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #Check if instance is created
    assert isinstance(KonserthusetPlayIE(), InfoExtractor)

# Generated at 2022-06-26 12:27:37.705189
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    video = ie._extract_video('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert video.get('id') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert video.get('title') == 'Orkesterns instrument: Valthornen'
    assert video.get('description') == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert video.get('thumbnail') == 're:^https?://.*$'
    assert video.get('duration') == 398.76
    assert video.get('subtitles') == {}

    assert video.get('formats')  # it is a list

# Generated at 2022-06-26 12:27:39.100071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE(downloader=None)
    assert test_KonserthusetPlayIE

# Generated at 2022-06-26 12:27:42.232416
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp.ie_key() == 'KonserthusetPlay'
    assert kp.ie_key() == KonserthusetPlayIE.ie_key()
    assert kp.SUCCESS

# Generated at 2022-06-26 12:27:49.727358
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test if _VALID_URL is set correctly
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Test if _TESTS is set correctly

# Generated at 2022-06-26 12:27:52.404983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    result = KonserthusetPlayIE()._real_extract(url)
    assert result['id'] == result['id']

# Generated at 2022-06-26 12:27:59.286595
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'

    # Test extractor
    KonserthusetPlayIE().extract(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Test constructor
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS

    # Test regex
    assert KonserthusetPlayIE._match_id(KonserthusetPlayIE._VALID_URL, video_id) == video_id
    assert K

# Generated at 2022-06-26 12:28:07.458062
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    URL = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    tt = KonserthusetPlayIE()
    assert tt._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert tt._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert tt._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967"
    assert tt._TESTS[1]['url'] == URL


# Generated at 2022-06-26 12:28:09.100892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('KonserthusetPlayIE')
    assert isinstance(ie, KonserthusetPlayIE)