

# Generated at 2022-06-26 12:21:11.310074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equal(konserthuset_play_i_e_0.__class__.__name__, "KonserthusetPlayIE")


# Generated at 2022-06-26 12:21:12.938355
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_mock = Mock()
    assert_equal(class_mock._download_xml, None)

# Generated at 2022-06-26 12:21:14.151207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass
# Test methods of class KonserthusetPlayIE

# Generated at 2022-06-26 12:21:16.428586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'


# Generated at 2022-06-26 12:21:17.689784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE != None


# Generated at 2022-06-26 12:21:18.615623
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:19.667378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:30.839345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert konserthuset_play_i_e_0._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthuset_play_i_e_0._WORKING == True
    assert konserthuset_play_i_e_0.IE_DESC == 'konserthusetplay.se and rspoplay.se'
    assert konserthuset_play_i_e_0.ie_key() == 'KonserthusetPlay'
    assert konserthuset_play_i_e_0.ie_key

# Generated at 2022-06-26 12:21:41.585583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:42.506555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE


# Generated at 2022-06-26 12:22:04.585216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test a working konserthusetplay.se video
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    info_dict = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }

    konserthuset_play_ie = KonserthusetPlayIE()
    video_info = konserthuset_play_ie.ext

# Generated at 2022-06-26 12:22:05.217608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:22:05.816063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE();

# Generated at 2022-06-26 12:22:06.868295
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:22:18.507130
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:24.870149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert callable(ie._real_extract)


# Generated at 2022-06-26 12:22:26.191947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    c = KonserthusetPlayIE()
    c._match_id('')

# Generated at 2022-06-26 12:22:30.976786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	#Arrange
	expected_class_name='KonserthusetPlayIE'
	#Act
	obj=KonserthusetPlayIE()
	actual_class_name=obj.__class__.__name__
	#Assert
	assert actual_class_name==expected_class_name,"class for KonserthusetPlayIE is not as expected"

# Generated at 2022-06-26 12:22:36.720478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Create a test case
    test_creator = InfoExtractor(KonserthusetPlayIE)
    # Get the expected output
    expected_result = KonserthusetPlayIE.suitable()
    # Get the actual output
    actual_result = test_creator.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    # Assert that the expected and actual results are the same
    assert actual_result == expected_result

    # Create a test case
    test_creator = InfoExtractor(KonserthusetPlayIE)
    # Get the expected output
    expected_result = KonserthusetPlayIE.suitable()
    # Get the actual output

# Generated at 2022-06-26 12:22:39.831608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)


# Generated at 2022-06-26 12:23:08.194016
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""

    # Test for proper initialization of KonserthusetPlayIE
    info_extractor = KonserthusetPlayIE(None)
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert info_extractor._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:23:12.892799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE(KonserthusetPlayIE.ie_key())
    ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&lang=sv')
    assert ie.SUITABLE == True


# Test calling KonserthusetPlayIE.suitable

# Generated at 2022-06-26 12:23:18.835120
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.video_id == 'CKDDnlCY'

# Generated at 2022-06-26 12:23:20.468565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-26 12:23:21.859725
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE()
    video.test()

# Generated at 2022-06-26 12:23:25.699782
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = KonserthusetPlayIE()._match_id(
        'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert video_id == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-26 12:23:35.144566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test the constructor of class KonserthusetPlayIE
    konserthuset_play = KonserthusetPlayIE('konserthuset_play', 'konserthusetplay')
    assert (konserthuset_play.extractor_key >= 0)
    assert (konserthuset_play.extractor_key == konserthuset_play.ie_key())
    # test the value of instance field
    assert (konserthuset_play._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:23:39.540370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'm=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE()
    try:
        k._real_extract(url)
    except Exception as e:
        print ("test_KonserthusetPlayIE error: {}".format(e))

    assert (True) == True

# Generated at 2022-06-26 12:23:40.745524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:44.313065
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    #url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw" # only_matching
    KonserthusetPlayIE()._real_initialize(url)

# Generated at 2022-06-26 12:24:36.543292
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:43.839570
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(www\.)?(konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:44.707243
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:53.230710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, type)
    assert issubclass(KonserthusetPlayIE, InfoExtractor)
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:54.334008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie

# Generated at 2022-06-26 12:24:57.250746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Instantiate object
    k = KonserthusetPlayIE()

    # Check if object is an InfoExtractor object
    if not isinstance(k, InfoExtractor):
        raise AssertionError('Object is not an instance of InfoExtractor')

# Generated at 2022-06-26 12:24:59.303325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()

# Generated at 2022-06-26 12:25:02.106669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:25:05.135860
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract('CKDDnlCY-dhWAAqiMERd-A')



# Generated at 2022-06-26 12:25:07.798793
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert extractor_for_url(url).IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-26 12:27:20.168004
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    #assert KonserthusetPlayIE.suitable(url)
    KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-26 12:27:21.091234
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:24.472296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test of KonserthusetPlayIE constructor
    """
    ie = KonserthusetPlayIE(None)
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:27:25.895454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import KonserthusetPlayIE
    inst = KonserthusetPlayIE()
    assert inst != None

# Generated at 2022-06-26 12:27:27.766833
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert len(ie.IE_DESC) > 0
    assert ie.name.lower().find('konserthuset') >= 0

# Generated at 2022-06-26 12:27:30.113131
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # If a parameter is not present, an AssertionError is raised
    assert KonserthusetPlayIE(None)


# Generated at 2022-06-26 12:27:33.216913
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.get_url() == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:34.496451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    r = KonserthusetPlayIE()
    r.suite()

# Generated at 2022-06-26 12:27:35.769518
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the content of a function
    assert int_or_none(3.3) == 3

# Generated at 2022-06-26 12:27:42.898904
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.SUCCESS == 'SUCCESS'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'