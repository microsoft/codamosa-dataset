

# Generated at 2022-06-26 12:21:12.167100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

# Unit tests for methods of class KonserthusetPlayIE

# Generated at 2022-06-26 12:21:13.613468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()
# Unit test constructor of class InfoExtractor with parameter

# Generated at 2022-06-26 12:21:21.217672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Unit test for constructor of class KonserthusetPlayIE")

    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    print(konserthuset_play_i_e_0)
    # assert konserthuset_play_i_e_0.__class__.__name__ == 
    assert konserthuset_play_i_e_0._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-26 12:21:23.398919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE(), '_VALID_URL')
    assert hasattr(KonserthusetPlayIE(), '_TESTS')



# Generated at 2022-06-26 12:21:28.850501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == \
        'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:21:29.723571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL



# Generated at 2022-06-26 12:21:40.503115
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert konserthuset_play_i_e.ie_key() == 'KonserthusetPlay'
    assert konserthuset_play_i_e.ie_key() == 'KonserthusetPlay'
    assert konserthuset_play_i_e.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-26 12:21:43.320815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    assert isinstance(konserthuset_play_i_e, KonserthusetPlayIE)
    

# Generated at 2022-06-26 12:21:44.953051
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:45.510069
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:10.875490
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert(konserthuset_play_i_e_0 == konserthuset_play_i_e)
    except:
        raise AssertionError()


# Generated at 2022-06-26 12:22:13.043023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:22:17.045980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:22.628575
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert konserthuset_play_i_e_0._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:22:24.870081
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()

# Integration test for class KonserthusetPlayIE

# Generated at 2022-06-26 12:22:26.117422
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None, None) is not None

# Generated at 2022-06-26 12:22:27.076093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # this test passes if the constructor does not raise any exception
    assert test_case_0()

# Generated at 2022-06-26 12:22:36.454143
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:22:46.737714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    konserthuset_play_i_e = KonserthusetPlayIE()

    assert konserthuset_play_i_e._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:22:47.938998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-26 12:23:19.832493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert bool(ie._VALID_URL)
    assert bool(ie._TEST)
    assert bool(ie._download_json)
    assert bool(ie._search_regex)
    assert bool(ie._match_id)
    assert bool(ie._extract_m3u8_formats)
    assert bool(ie._sort_formats)
    assert bool(ie._download_webpage)
    assert bool(ie._real_extract)

# Generated at 2022-06-26 12:23:28.398965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie_info = ie.extract()
    # Check if all fields are filled
    if not ie_info["id"]:
        assert False
    if not ie_info["title"]:
        assert False
    if not ie_info["description"]:
        assert False
    if not ie_info["thumbnail"]:
        assert False
    if not ie_info["duration"]:
        assert False
    if not ie_info["formats"]:
        assert False
    if not ie_info["subtitles"]:
        assert False
    assert True

# Generated at 2022-06-26 12:23:39.654549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("=================%s=====================" % __name__)
    obj = KonserthusetPlayIE()
    assert(obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:23:40.825893
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE('id')
    assert kp is not None

# Generated at 2022-06-26 12:23:44.130300
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:23:55.022834
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    # Unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:57.939271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Use the latest constructors of the class KonserthusetPlayIE
    KonserthusetPlayIE()
    return True


# Generated at 2022-06-26 12:23:59.633390
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
#
# Returns a dictionary with the information about the video
#

# Generated at 2022-06-26 12:24:02.966540
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE
    assert ie.__name__ == 'KonserthusetPlay'
    ie = ie(None)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_types() == ['url']

# Generated at 2022-06-26 12:24:07.954692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    This function tests the constructor of class KonserthusetPlayIE.
    '''

    konserthuset_play_ie = KonserthusetPlayIE()

    assert konserthuset_play_ie.ie_key() == 'KonserthusetPlay'
    assert konserthuset_play_ie.ie_name() == 'Konserthuset Play'
    assert konserthuset_play_ie.ie_url() == 'http://www.konserthusetplay.se/'

# Generated at 2022-06-26 12:25:09.635500
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:25:17.563359
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url.endswith('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.url.endswith('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
# End of unit test

# Generated at 2022-06-26 12:25:18.332154
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    KonserthusetPlayIE(None)

# Generated at 2022-06-26 12:25:19.174387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    pass

# Generated at 2022-06-26 12:25:23.172118
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE(url)
    assert ie

    # test constructor of class InfoExtractor
    ie = InfoExtractor(url)
    assert ie

# Generated at 2022-06-26 12:25:24.665750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import sys
    a = KonserthusetPlayIE()
    assert a



# Generated at 2022-06-26 12:25:30.963625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # OK
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable(url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # FAIL
    assert not ie.suitable(url='http://rspoplay.se/')

# Generated at 2022-06-26 12:25:32.472955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with pytest.raises(TypeError):
        KonserthusetPlayIE() # pylint:disable=no-value-for-parameter

# Generated at 2022-06-26 12:25:35.568676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    constructor of class KonserthusetPlayIE
    """
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-26 12:25:36.448787
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-26 12:27:39.406752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:47.613010
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert obj._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:48.708185
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE();


# Generated at 2022-06-26 12:27:51.567799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        print("Unit test of KonserthusetPlayIE successful")
    except:
        print("Unit test of KonserthusetPlayIE failed!")
    return

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:54.410124
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:27:55.548090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # TODO: Test class KonserthusetPlayIE
    pass

# Generated at 2022-06-26 12:27:57.584987
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:28:05.255908
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    expected = [{
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'only_matching': True,
    }, {
        'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
        'only_matching': True,
    }]
    url_tests = list(map(lambda x: (x[0], x[1]), expected))
    # Test existence of regular expression
    assert KonserthusetPlayIE._VALID_URL

    # Test extractor creation
    ie = KonserthusetPlayIE(expected[0])
    assert ie.__name__ == 'KonserthusetPlay'

    # Test for expected instance attributes

# Generated at 2022-06-26 12:28:12.660823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from ..compat import compat_str

    # Constructor should be OK
    InfoExtractor(KonserthusetPlayIE.name)

    # Exercise extract method. Note that we can't check the actual
    # values since they may change by themselves.
    extractor = InfoExtractor(KonserthusetPlayIE.name)
    result = extractor.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Assert that IExtractor.extract yields a dictionary with
    # certain keys.
    assert isinstance(result, dict)
    for key in ['id', 'uploader', 'title', 'description']:
        assert key in result

# Generated at 2022-06-26 12:28:13.999049
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError as e:
        assert e.message == "__init__() takes at least 2 arguments (1 given)"