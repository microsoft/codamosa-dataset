

# Generated at 2022-06-26 12:21:16.171500
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equals(KonserthusetPlayIE._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:21:24.012709
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__dict__["_VALID_URL"] == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:21:26.272588
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:28.695814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:29.844671
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:40.635850
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equal(KonserthusetPlayIE()._VALID_URL, 'http://www.konserthusetplay.se/')

# Generated at 2022-06-26 12:21:42.638360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:44.009530
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0.run()


# Generated at 2022-06-26 12:21:45.842517
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert isinstance(konserthuset_play_i_e_0 , KonserthusetPlayIE)


# Generated at 2022-06-26 12:21:48.539759
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_1 = KonserthusetPlayIE()
    assert konserthuset_play_i_e_1.suitable, 'Suitable is a False expression'


# Generated at 2022-06-26 12:22:03.291443
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:04.545437
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-26 12:22:06.913536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:22:11.210633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)

# Unit test method KonserthusetPlayIE._real_extract

# Generated at 2022-06-26 12:22:14.220619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False, "Constructor of class KonserthusetPlayIE fails."


# Generated at 2022-06-26 12:22:17.720040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)

# Generated at 2022-06-26 12:22:23.287220
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    except:
        print("Unit test for constructor of class KonserthusetPlayIE failed")
        return
    print("Unit test for constructor of class KonserthusetPlayIE passed")


# Generated at 2022-06-26 12:22:26.524344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the constructor of class KonserthusetPlayIE
    try:
        instance = KonserthusetPlayIE()
    except Exception as ex:
        print("Failed to create an instance of KonserthusetPlayIE.")
        print("Error: " + str(ex))

# Generated at 2022-06-26 12:22:35.943330
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:22:36.824309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:01.586016
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(InfoExtractor)
    assert ie == InfoExtractor

# Generated at 2022-06-26 12:23:10.647547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    s = KonserthusetPlayIE('test')
    if s is not None:
        print("KonserthusetPlayIE succesfully initialized")
    else:
        raise ValueError("KonserthusetPlayIE did not initialize")

    # Create test videos
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url2 = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

    s._download_webpage(url, "CKDDnlCY-dhWAAqiMERd-A")
    webpage = s._download_webpage(url, "CKDDnlCY-dhWAAqiMERd-A")

    e

# Generated at 2022-06-26 12:23:12.068835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE.suite()


# Generated at 2022-06-26 12:23:15.900383
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'
    assert ie._VALID_URL ==  r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:18.239676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-26 12:23:19.832188
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-26 12:23:20.778554
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:22.187898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj_KonserthusetPlayIE = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:32.320465
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:23:34.390490
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Make sure the constructor runs and does not crash.
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:18.385080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    input_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    input_data = None
    input_headers = None
    ext = determine_ext(input_url)
    ie = KonserthusetPlayIE()
    r = ie.suitable(input_url)
    assert r == True

# Generated at 2022-06-26 12:24:19.573669
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable(ie._VALID_URL)

# Generated at 2022-06-26 12:24:24.613646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE.__doc__ == 'KonserthusetPlay and RSPOPlay.se'


# Generated at 2022-06-26 12:24:31.334675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == "KonserthusetPlay"
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.IE_DESC == 'Rikskonserter och Sveriges Radios P2 samlar konserter och program i en digital spelare'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Test conversion of milliseconds to seconds (float)

# Generated at 2022-06-26 12:24:41.659203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    expected_result_1 = KonserthusetPlayIE(None)._VALID_URL
    assert expected_result_1 == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    expected_result_2 = KonserthusetPlayIE(None)._TESTS
    assert expected_result_2[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert expected_result_2[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert expected_result_2[0]['info_dict']
    assert expected_

# Generated at 2022-06-26 12:24:44.707298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)

# Generated at 2022-06-26 12:24:45.802125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-26 12:24:47.255457
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('https://url.com')

    # Check that it's an instance of the correct type
    assert isinstance(instance, KonserthusetPlayIE)


# Generated at 2022-06-26 12:24:56.096956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play and RS Play'
    assert ie.URL_PATTERN == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:24:57.087515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if __name__ == "__main__":
        KonserthusetPlayIE()

# Generated at 2022-06-26 12:26:50.208116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-26 12:26:51.734527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance.suite()

# Generated at 2022-06-26 12:26:53.729644
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.__init__()
    ie.suitable(None)
    ie.add_ie(None)
    ie.ie_key()
    ie.geo_verification_headers()
    ie.geo_bypass_header()

# Generated at 2022-06-26 12:26:59.936629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()

    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:02.627068
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract()['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-26 12:27:05.343478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-26 12:27:13.720391
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:27:19.184576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:27.075538
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test KonserthusetPlayIE constructor
    instance = KonserthusetPlayIE()

    # Test KonserthusetPlayIE._match_id method
    assert instance._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert instance._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-26 12:27:32.022022
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    for obj in ie._TESTS:
        url = obj['url']
        video_id = obj['info_dict']['id']
        assert obj['url'] == ie._VALID_URL % video_id
        assert ie.suitable(url)
        assert 'http://www.konserthusetplay.se/?m=' + video_id == ie._real_extract(obj['url'])['id']