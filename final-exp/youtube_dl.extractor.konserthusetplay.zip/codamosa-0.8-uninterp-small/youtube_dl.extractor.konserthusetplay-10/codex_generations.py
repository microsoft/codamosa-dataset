

# Generated at 2022-06-26 12:21:15.216814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    # Check if the value of member variable _VALID_URL is correct
    assert konserthuset_play_i_e._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Check if the value of member variable _TESTS is correct

# Generated at 2022-06-26 12:21:16.366338
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:19.495910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    konserthuset_play_i_e_0.match(url)
    return konserthuset_play_i_e_0


# Generated at 2022-06-26 12:21:20.983526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:22.357794
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:22.868125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:25.313164
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    TestClass = KonserthusetPlayIE()


# Generated at 2022-06-26 12:21:27.944943
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

if __name__ == '__main__':
    test_KonserthusetPlayIE()
    test_case_0()

# Generated at 2022-06-26 12:21:33.219073
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play_i_e_1 = KonserthusetPlayIE()
    match_id = konserthuset_play_i_e_1._match_id(url)


# Generated at 2022-06-26 12:21:38.071752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e = KonserthusetPlayIE()
    konserthuset_play_i_e._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-26 12:21:53.410335
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that a debug message is printed when the constructor is called.
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_getenv
    from io import StringIO
    import sys
    import os

    if not os.path.exists('test.log'):
        open('test.log', 'w').close()

    saved_stdout = sys.stdout
    log_output_file = open('test.log', 'r+')
    new_stdout = StringIO()
    sys.stdout = new_stdout

    konserthuset_play_ie = KonserthusetPlayIE()
    FileDownloader({}, {})
    sys.stdout = saved_stdout

    new_stdout_text = new_stdout.getvalue()
    log_

# Generated at 2022-06-26 12:21:57.808056
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:07.298957
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing constructor of class KonserthusetPlayIE...")
    expected_valid_urls = [
        "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A",
        "https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw",
        "http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw",
        "https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw",
        "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    ]
    expected_

# Generated at 2022-06-26 12:22:09.957328
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()
    assert kpIE.extractor.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-26 12:22:15.455841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == '.se'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-26 12:22:21.076389
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test just the constructor of the class
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-26 12:22:21.948647
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        pass

# Generated at 2022-06-26 12:22:23.824556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'

# Unit tests for class KonserthusetPlayIE

# Generated at 2022-06-26 12:22:25.369814
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        extractor = KonserthusetPlayIE()
    except Exception:
        return

# Generated at 2022-06-26 12:22:26.286427
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:56.434811
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:23:04.192827
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://example.com/video.mp4')


# Generated at 2022-06-26 12:23:08.461014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    cfg = {
        'youtube_ie': 'YoutubeIE',
        'add_ie': ['GenericIE']
    }
    ie_obj = InfoExtractor.construct_instance(KonserthusetPlayIE, cfg, 'KonserthusetPlayIE')
    assert isinstance(ie_obj, KonserthusetPlayIE)

# Generated at 2022-06-26 12:23:11.796803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    return ie.url_result("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-26 12:23:14.841023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.VIDEO_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:19.942583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # TODO: Add unit test for constructor of class KonserthusetPlayIE
    # This should test that the constructor is working properly
    # See https://github.com/rg3/youtube-dl/blob/master/youtube_dl/YoutubeDL.py#L137-L312
    # for example
    pass



# Generated at 2022-06-26 12:23:21.580141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-26 12:23:28.651689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.extract(test_url)
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract(test_url)
    assert ie.extract(test_url)['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:23:30.931565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Make sure the class constructor works
    assert ie

# Generated at 2022-06-26 12:23:31.956658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-26 12:24:18.826289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as inst:
        assert False, type(inst)

# Generated at 2022-06-26 12:24:25.550619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Find information on a webpage using KonserthusetPlayIE

    This webpage is extracted from a webpage
    and the information is checked if they are
    the same as the information given in the webpage.

    Args:
        url: a url which gives information about a video on the site
    Returns:
        Information about the video
    """
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(None, None)._real_extract(url)

# Generated at 2022-06-26 12:24:35.724806
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:24:36.676522
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:42.528405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda url, video_id: ''
    ie._extract_m3u8_formats = lambda url, video_id, ext, entry_protocol, m3u8_id, fatal: []
    ie._match_id = lambda url: None
    ie._sort_formats = lambda formats: None
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie is not None

# Generated at 2022-06-26 12:24:51.412713
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test constructor of class KonserthusetPlayIE"""
    # Call constructor, create KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Check type of instance
    assert isinstance(ie, KonserthusetPlayIE)
    # Check value of `_VALID_URL`
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # Test _real_extract for one URL from _TESTS
    test = ie._TESTS[1]
    url = test['url']
    video_id = test['only_matching']['id']

# Generated at 2022-06-26 12:24:54.324182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-26 12:24:59.354549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE("mock")
    assert "konserthusetplay" in k._VALID_URL
    assert "rspoplay" in k._VALID_URL
    assert isinstance(k.url, unicode)
    assert isinstance(k.ie_key(), unicode)
    assert isinstance(k._real_initialize(), bool)
    assert isinstance(k._real_extract(""), dict)
    return True

# Generated at 2022-06-26 12:25:00.233672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)

# Generated at 2022-06-26 12:25:08.392602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test: Valid URL
    input_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    input_expected = 'CKDDnlCY-dhWAAqiMERd-A'
    input_actual = KonserthusetPlayIE._match_id(input_url)
    assert input_actual == input_expected

    # Test: Invalid URL
    input_url = 'http://www.konserthusetplay.se/?m='
    input_expected = None
    input_actual = KonserthusetPlayIE._match_id(input_url)
    assert input_actual == input_expected

    # Test: Invalid URL
    input_url = 'http://www.konserthusetplay.se/?m=1234'

# Generated at 2022-06-26 12:27:18.661758
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:19.906563
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert(instance.ie_key() == 'KonserthusetPlay')

# Generated at 2022-06-26 12:27:22.435420
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()
    instance = isinstance(result, KonserthusetPlayIE)
    assert (instance)


# Generated at 2022-06-26 12:27:25.955006
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(len(KonserthusetPlayIE._TESTS) > 0)
    assert(KonserthusetPlayIE._VALID_URL is not None)
    assert(KonserthusetPlayIE._TESTS[0]['url'] is not None)
    assert(KonserthusetPlayIE._TESTS[0]['url'].startswith("http"))

# Generated at 2022-06-26 12:27:26.902091
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:27.808798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-26 12:27:31.506941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS
    assert KonserthusetPlayIE()._real_extract is not None

# Generated at 2022-06-26 12:27:38.432144
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert instance._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert instance._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert instance._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:46.638895
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == "https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)"

# Generated at 2022-06-26 12:27:53.274176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
	assert KonserthusetPlayIE()._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	assert KonserthusetPlayIE()._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
	assert KonserthusetPlayIE()._TESTS[1]['only_matching'] == True
