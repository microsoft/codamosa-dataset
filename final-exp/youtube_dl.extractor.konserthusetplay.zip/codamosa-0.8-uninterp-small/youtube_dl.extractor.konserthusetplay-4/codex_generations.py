

# Generated at 2022-06-26 12:21:17.165612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'


# Generated at 2022-06-26 12:21:20.421181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    log_text = "Extractor 'KonserthusetPlayIE' is deprecated; use 'ThePlatform' instead."
    assert log_text in KonserthusetPlayIE.test()
    konserthuset_play_i_e_1 = KonserthusetPlayIE()

# Generated at 2022-06-26 12:21:21.733547
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert callable(KonserthusetPlayIE)


# Generated at 2022-06-26 12:21:26.226100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equal(str(KonserthusetPlayIE()._VALID_URL), "^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)$")

# Generated at 2022-06-26 12:21:36.959413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # TODO: test for get_id
    video_id = konserthuset_play_i_e_0._get_id(url)
    video_id_expect = 'CKDDnlCY-dhWAAqiMERd-A'
    assert type(video_id) == unicode
    assert type(video_id_expect) == unicode
    assert video_id == video_id_expect
    # TODO: test for _real_extract
    konserthuset_play_i_e_0._real_extract(url)
    return


# Generated at 2022-06-26 12:21:38.838705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()



# Generated at 2022-06-26 12:21:48.039548
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert_equals(KonserthusetPlayIE._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:21:48.826532
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE


# Generated at 2022-06-26 12:21:51.731054
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None

if __name__ == '__main__':
    import sys

    if sys.argv is not None:
        sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-26 12:21:53.928739
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 12:22:05.452877
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    return extractor

# Generated at 2022-06-26 12:22:11.775839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-26 12:22:15.674987
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    u = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE.suitable(u)
    assert KonserthusetPlayIE().suitable(u)

# Generated at 2022-06-26 12:22:23.417804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ckp = KonserthusetPlayIE()
    assert ckp
    assert ckp._match_id('this is a useless string') == None
    assert ckp._match_id(test_url) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ckp._real_extract(test_url) != None


# Generated at 2022-06-26 12:22:30.010098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:22:31.978342
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-26 12:22:35.027338
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:36.120678
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-26 12:22:44.558635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('test')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-26 12:22:46.005916
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("test", "test", "test", "test")

# Generated at 2022-06-26 12:23:12.525288
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor

# Generated at 2022-06-26 12:23:18.791098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se/')

# Generated at 2022-06-26 12:23:28.356462
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert i.IE_NAME == 'KonserthusetPlay'
    assert i._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:34.587250
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE.__name__ = 'test_constructor'
    ie = KonserthusetPlayIE()
    ie.__class__ = 'testing'
    test_KonserthusetPlayIE.__name__ = 'test_real_extract'
    assert ie.__class__ == 'testing'



# Unit tests for the KonserthusetPlayIE class

# Generated at 2022-06-26 12:23:36.630147
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:23:41.311740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:51.315854
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kons = KonserthusetPlayIE()
    assert kons._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:55.688925
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.KONSERTHUSET_URL == 'http://www.konserthusetplay.se/'
    assert ie.RSPOPLAY_URL == 'http://rspoplay.se/'

# Generated at 2022-06-26 12:23:56.788249
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:58.456467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    loadit = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:56.561808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable('http://www.google.se/') == False



# Generated at 2022-06-26 12:24:57.283804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:57.982526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:58.999078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kP = KonserthusetPlayIE()

# Generated at 2022-06-26 12:25:01.494986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-26 12:25:09.229986
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:25:13.757244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    assert ie.VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.IE_DESC == KonserthusetPlayIE._IE_DESC
    assert ie.IE_NAME == KonserthusetPlayIE._IE_NAME
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-26 12:25:15.626435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:25:17.353920
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._downloader, KonserthusetPlayIE._VALID_URL)


# Generated at 2022-06-26 12:25:19.344083
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-26 12:27:35.619746
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    # Check that the constructor received valid arguments
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert k._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:36.490173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:27:37.399549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:38.517230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    construct_object = KonserthusetPlayIE()
    assert construct_object


# Generated at 2022-06-26 12:27:39.221058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:39.899786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:42.011412
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserhuset = KonserthusetPlayIE()
    assert isinstance(konserhuset, InfoExtractor)


# Generated at 2022-06-26 12:27:46.791568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Prepare a dummy url
    url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

    # Instantiate the unit test class
    unit_test_instance = KonserthusetPlayIE(url)

    # Assert that the unit test instance is an instance of the actual class
    assert isinstance(unit_test_instance, KonserthusetPlayIE)

# Generated at 2022-06-26 12:27:53.424577
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&aa=abbb')
    assert not ie.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw&aa=abbb&ff')

# Generated at 2022-06-26 12:27:54.995226
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        assert(True)
    except(TypeError):
        assert(False)