

# Generated at 2022-06-26 12:21:12.724832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert konserthuset_play_i_e_0.suitable( "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthuset_play_i_e_0.suitable( "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert not konserthuset_play_i_e_0.suitable( "http://www.google.com")


# Generated at 2022-06-26 12:21:15.066922
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL


# Generated at 2022-06-26 12:21:17.051695
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_i_e_0 = KonserthusetPlayIE()
    assert isinstance(konserthuset_play_i_e_0, KonserthusetPlayIE)


# Generated at 2022-06-26 12:21:17.649899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-26 12:21:22.358000
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        instance = KonserthusetPlayIE()
        print('\n[SUCCESS] Test instantiation of KonserthusetPlayIE class: \
            \n\t{} \n'.format(instance))
    except Exception as err:
        print('\n[FAIL] Test instantiation of KonserthusetPlayIE class: \
            \n\t{}'.format(err))


# Generated at 2022-06-26 12:21:22.922460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  pass

# Generated at 2022-06-26 12:21:34.662723
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  konserthuset_play_i_e = KonserthusetPlayIE()
  konserthuset_play_i_e.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
  konserthuset_play_i_e.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
  konserthuset_play_i_e.suitable('http://www.konserthusetplay.se/?m=nYTevhUbZxzkls-YYuhZAw')

# Generated at 2022-06-26 12:21:39.290587
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')


# Generated at 2022-06-26 12:21:42.111238
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # tests for method _real_extract
    # test for
    #  KonserthusetPlayIE._real_extract(self,url)
    result = test_case_0()
    assert(result == 0)

# Generated at 2022-06-26 12:21:43.521613
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None


# Generated at 2022-06-26 12:21:55.252782
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:22:01.736061
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('KonserthusetPlay', 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'KonserthusetPlay'
    assert ie.url == 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:22:03.162434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-26 12:22:07.794471
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert e._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:22:13.502661
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE("www.konserthusetplay.se", "?m=CKDDnlCY-dhWAAqiMERd-A")
    assert test._real_extract(test._match_id(test.url))["id"] == "CKDDnlCY-dhWAAqiMERd-A"



# Generated at 2022-06-26 12:22:15.546500
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, KonserthusetPlayIE._TESTS)

# Generated at 2022-06-26 12:22:18.096560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE('4'*32)
    except Exception as e:
        assert str(e)

# Generated at 2022-06-26 12:22:19.542810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-26 12:22:29.473978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'http://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:22:31.890596
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.server_url() is None


# Generated at 2022-06-26 12:22:55.218689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(True)

# Generated at 2022-06-26 12:22:58.490479
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay:media'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.thumbnail() is None
    assert ie.upload_date() is None
    assert ie.uploader() is None

# Generated at 2022-06-26 12:23:00.527492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:07.675729
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test 1
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.download(url)

    # Test 2
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.download(url)

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:14.064150
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert(ie._download_json('http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % 'test', 'test') is None)
    assert(ie._download_json('https://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % 'test', 'test') is None)
    assert(ie._download_json('http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % 'testtest', 'testtest') is None)

# Generated at 2022-06-26 12:23:24.034398
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("www.konserthusetplay.se", "")
    assert(ie.__class__.__name__ == "KonserthusetPlayIE")
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._downloader is None)
    assert(ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&playlistId=CKDDnlCY-dhWAAqiMERd-A") == True)

# Generated at 2022-06-26 12:23:27.288740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj._VALID_URL
    assert obj._TESTS

# Generated at 2022-06-26 12:23:38.741989
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:23:39.293980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()

# Generated at 2022-06-26 12:23:41.566786
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    raise Exception('Unit test done!')

# Generated at 2022-06-26 12:24:26.485980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-26 12:24:28.218230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:24:30.384885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for KonserthusetPlayIE | constructor
    """
    konplay = KonserthusetPlayIE()
    konplay = KonserthusetPlayIE(params=None)

# Generated at 2022-06-26 12:24:31.958126
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie != None

# Generated at 2022-06-26 12:24:38.470815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst._TYPE == 'konserthusetplay'
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Test for the method _real_extract from class KonserthusetPlayIE

# Generated at 2022-06-26 12:24:40.072051
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_common import test_factory
    assert test_factory('KonserthusetPlayIE', 'url')

# Generated at 2022-06-26 12:24:41.857608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test(KonserthusetPlayIE, [('http://konserthusetplay.se/', )])


# Generated at 2022-06-26 12:24:43.764596
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    _ = KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-26 12:24:47.055863
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.__class__ == KonserthusetPlayIE
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_desc() == "konserthusetplay.se and rspoplay.se"

# Generated at 2022-06-26 12:24:48.126732
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-26 12:26:58.362884
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-26 12:27:00.961458
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    assert video_id == KonserthusetPlayIE._match_id(url)

# Generated at 2022-06-26 12:27:02.048842
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-26 12:27:05.977184
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw');
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A');

# Generated at 2022-06-26 12:27:14.195976
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-26 12:27:15.597124
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-26 12:27:17.662038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-26 12:27:18.337060
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE

# Generated at 2022-06-26 12:27:22.661500
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test a url of KonserthusetPlayIE
    url_test= 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(KonserthusetPlayIE.suitable(url_test)).download(url_test)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-26 12:27:23.427607
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()