

# Generated at 2022-06-22 07:58:00.829784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:58:02.702954
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:58:05.511954
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    

# Generated at 2022-06-22 07:58:14.671312
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable(url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
    assert ie.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
    assert ie.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&foo=bar') == True

# Generated at 2022-06-22 07:58:17.435392
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    pass

# Generated at 2022-06-22 07:58:23.819781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserhuset_play = KonserthusetPlayIE()
    assert konserhuset_play._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserhuset_play._TEST == []

# Generated at 2022-06-22 07:58:33.526817
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_test import __test__
    try:
        __test__[1]('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')('url')
        __test__[1]('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')('url')
    except:
        print("An exception was caught while creating the object of class KonserthusetPlayIE")

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:34.951388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    print(obj)

# Generated at 2022-06-22 07:58:37.690552
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing KonserthusetPlayIE")
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:41.190936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        raise TypeError('__init__ takes exactly 3 arguments (1 given)')


# Generated at 2022-06-22 07:59:13.805176
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE()._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE()._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE()._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:59:22.749867
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .KonserthusetPlayIE import KonserthusetPlayIE
    from .KonserthusetPlayIE import _search_regex, _VALID_URL
    from .KonserthusetPlayIE import _download_webpage, _download_json
    from .KonserthusetPlayIE import _match_id
    assert(KonserthusetPlayIE)
    assert(_search_regex)
    assert(_VALID_URL)
    assert(_download_webpage)
    assert(_download_json)
    assert(_match_id)

# Generated at 2022-06-22 07:59:28.166856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 07:59:38.456736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_KonserthusetPlayIE = KonserthusetPlayIE()

    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    webpage = test_KonserthusetPlayIE._download_webpage(url, 'video id')

    e = test_KonserthusetPlayIE._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')


# Generated at 2022-06-22 07:59:50.648599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:51.327537
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-22 07:59:52.382917
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:59:55.904660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Initializing a instance of class KonserthusetPlayIE
    youtube_instance = KonserthusetPlayIE()
    # Testing if instance creation was successfull
    assert youtube_instance

# Generated at 2022-06-22 08:00:00.013413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Instantiates
    """
    # Attempt to create an object of class KonserthusetPlayIE
    try:
        KonserthusetPlayIE()
    except Exception as e:
        # print if any exception raised
        print(e)
        print(sys.exc_info())

# Generated at 2022-06-22 08:00:01.365559
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-22 08:00:27.410910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().IE_NAME == 'konserthusetplay'

# Generated at 2022-06-22 08:00:30.210603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 08:00:32.736869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'



# Generated at 2022-06-22 08:00:35.966638
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
    print("Unit test of class KonserthusetPlayIE has finished.")


# Generated at 2022-06-22 08:00:36.958501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:00:37.939752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:38.934528
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:40.057203
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:43.317431
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download(KonserthusetPlayIE._TESTS[0]['url'])
    ie.download(KonserthusetPlayIE._TESTS[1]['url'])

# Generated at 2022-06-22 08:00:53.784828
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for valid URL
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url = url.encode('utf-8')
    ie = KonserthusetPlayIE()
    ie.extractor = extractor
    ie.extract(url) # Doesn't throw an exception

    # Test for invalid URL
    url = 'http://www.konserthusetplay.se/m=CKDDnlCY-dhWAAqiMERd-A'
    url = url.encode('utf-8')
    ie = KonserthusetPlayIE()
    ie.extractor = extractor
    ie.extract(url) # Does throw an exception

# Generated at 2022-06-22 08:02:02.291692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_utils import mock_http_requests_engine
    from .test_utils import mock_http_download_json
    from .test_utils import mock_http_download_webpage
    from .test_utils import mock_interrupt_http_downloads
    from .test_utils import mock_http_download_m3u8
    import requests
    import io
    import os
    import six

    engine = mock_http_requests_engine()

    PLAYLIST_FILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'playlist.m3u8')
    PLAYLIST_M3U8 = open(PLAYLIST_FILE_PATH, 'rb').read()

    class FakeResponse(object):
        def __init__(self, text):
            self

# Generated at 2022-06-22 08:02:13.564674
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 08:02:16.781492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.name == 'konserthusetplay')

# Generated at 2022-06-22 08:02:20.473296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie._download_json('http://csp.picsearch.com/rest?e=.&containerId=mediaplayer&i=object')

# Generated at 2022-06-22 08:02:22.061524
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:27.950186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Just test constructor, download and extract methods are tested in other tests
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE.suitable('http://www.rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') is False

# Generated at 2022-06-22 08:02:30.257847
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test case for KonserthusetPlayIE (constructor) """
    assert KonserthusetPlayIE


# Generated at 2022-06-22 08:02:32.693556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        pass


# Generated at 2022-06-22 08:02:35.150472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test KonserthusetPlayIE() constructor.
    """
    obj = KonserthusetPlayIE()
    assert obj is not None


# Generated at 2022-06-22 08:02:36.734685
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:53.128630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 08:04:55.375573
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-22 08:04:58.717469
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create a KonserthusetPlayIE instance
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-22 08:05:00.483740
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:05:01.774823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None

# Generated at 2022-06-22 08:05:02.655936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:06.824701
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:05:08.878861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:13.894629
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:05:22.176503
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj.url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj.video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    obj.webpage = '<html><body></body></html>'
    obj.e = 'a'
    obj.rest = {'media': 'a'}
    obj.player_config = 'a'
    obj.playlist = ['a', 'b']
    obj.source = 'a'
    obj.connection_url = 'a'
    obj.fallback_url = 'a'
    obj.m3u8_url = 'a'
    obj.title = 'a'
    obj.description