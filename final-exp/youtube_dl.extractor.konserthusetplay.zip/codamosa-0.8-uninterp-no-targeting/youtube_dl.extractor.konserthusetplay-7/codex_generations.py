

# Generated at 2022-06-22 07:57:59.769071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from KonserthusetPlayIE import KonserthusetPlayIE
    assert callable(KonserthusetPlayIE)

# Generated at 2022-06-22 07:58:03.010611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()
    ie._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'test')

# Generated at 2022-06-22 07:58:07.663974
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._VALID_URL == r"https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 07:58:10.839941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.SUFFIX == ':konserthusetplay')
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.VIDEO_NAME_STRIP_REGEX == None)

# Generated at 2022-06-22 07:58:16.188767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    result = KonserthusetPlayIE()._real_extract(video_url)
    assert 'http://csp.picsearch.com/rest?e=' in result['formats'][0]['url']
    return result

# Generated at 2022-06-22 07:58:18.679234
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 07:58:24.452377
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE.constructor(url)
    assert instance is not None and instance['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:58:36.541071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:37.998442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-22 07:58:43.861013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    video_id = ie._match_id(ie._VALID_URL)
    assert video_id == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-22 07:59:00.111808
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test that all arguments are handled
    k = KonserthusetPlayIE()

    assert k.IE_NAME == "KonserthusetPlayIE"
    assert k.ie_key() == 'KonserthusetPlay'

    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:03.618256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:06.300333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # When using the constructor of class KonserthusetPlayIE.
    instance = KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # Then an instance of class KonserthusetPlayIE is returned.
    assert isinstance(instance, KonserthusetPlayIE)


# Generated at 2022-06-22 07:59:10.357551
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?:\/\/(?:www\.)?(?:konserthusetplay|rspoplay)\.se\/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:11.863835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('')

# Generated at 2022-06-22 07:59:14.677065
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except ValueError as e:
        assert False
        assert str(e)

# Generated at 2022-06-22 07:59:19.609326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test case
    - Construct an instance of the KonserthusetPlayIE object
    - Using the sample url
    """
    KonserthusetPlayIE(KonserthusetPlayIE._downloader, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:20.959480
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE


# Generated at 2022-06-22 07:59:23.770932
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert i.name == 'konserthusetplay'

# Generated at 2022-06-22 07:59:33.997985
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 07:59:49.080308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 07:59:52.147329
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE._VALID_URL, KonserthusetPlayIE.regex)



# Generated at 2022-06-22 07:59:56.101815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.extract(url)

    return

# Generated at 2022-06-22 07:59:57.506318
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-22 08:00:04.348133
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    post = KonserthusetPlayIE._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')
    rest = KonserthusetPlayIE._download_json(
        'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % e,
        video_id, transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])

# Generated at 2022-06-22 08:00:09.543395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:00:20.469595
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:30.920360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import re
    import unittest
    KE = KonserthusetPlayIE(None)
    class TestKonserthusetPlayIE(unittest.TestCase):
        def test_class_constructor(self):
            self.assertEqual(KE._VALID_URL, re.compile(r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'))

# Generated at 2022-06-22 08:00:32.586244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE({})
    assert result



# Generated at 2022-06-22 08:00:35.008877
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert extractor



# Generated at 2022-06-22 08:01:05.217398
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    info = ie.extract(url)
    assert info['title'] == u'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:01:07.821449
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')


# Generated at 2022-06-22 08:01:12.461622
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset = KonserthusetPlayIE()

test = KonserthusetPlayIE()
test.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:01:14.096216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:18.875693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    if ie:
        print("Unit test for KonserthusetPlayIE has been completed")
    else:
        print("Unit test for KonserthusetPlayIE has been failed")

# Generated at 2022-06-22 08:01:20.552047
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test creating instance of the class KonserthusetPlayIE
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:01:29.801820
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:39.708578
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
  video_id = 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:47.568767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()

    assert(konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(konserthusetplay._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(konserthusetplay._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')

# Generated at 2022-06-22 08:01:49.844077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False, 'Unit test "KonserthusetPlayIE" failed!'

# Generated at 2022-06-22 08:02:50.882736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .youtube import YoutubeIE

    # First create a mock object to make the code snippet "usable"
    class mock_YoutubeIE(YoutubeIE):
        def __init__(self, url, params=None):
            self.url = url
            if params is None:
                params = {}
            
            self.params = params
            
            # Mock the codes that are not available in this context
            self._download_webpage = lambda url, video_id: 'webpage'
            self._search_regex = lambda pattern, string, name, default: 'search_regex'
            self._download_json = lambda url, video_id: 'download_json'
            self._download_xml = lambda url, video_id: 'download_xml'

# Generated at 2022-06-22 08:02:52.799320
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .konserthusetplay import KonserthusetPlayIE
    KonserthusetPlayIE(None)

# Generated at 2022-06-22 08:02:56.126576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS


# Generated at 2022-06-22 08:03:01.420115
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance.load_webpage("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert instance.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-22 08:03:09.944254
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:03:12.764377
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Just a unit test for constructor of KonserthusetPlayIE.
    """
    # Just a unit test for constructor of KonserthusetPlayIE
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:03:24.724188
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'konserthusetplay.se'
    assert ie.http_headers() == {'User-Agent': ie.user_agent()}
    assert ie.suitable(ie.ie_key()) == True
    assert ie.suitable(ie.ie_key() + 'x') == False
    assert ie.working() == True
    assert ie.version() == '0.1'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:03:29.463477
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie.thumbnail() == 're:^https?://.*$'

# Generated at 2022-06-22 08:03:33.200043
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # FIXME: the test fails, but it's a good start anyhow ;-)
    # KonserthusetPlayIE()._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    return

# Generated at 2022-06-22 08:03:40.339705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://konserthusetplay.se/?m=Asd')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:05:55.666672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit_test = KonserthusetPlayIE()
    assert unit_test._VALID_URL is not None
    assert unit_test._TESTS is not None

# Generated at 2022-06-22 08:05:56.373651
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:06:00.013525
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        info_extractor = InfoExtractor()
        assert(isinstance(info_extractor, InfoExtractor))
        return info_extractor
    except:
        return -1

# Generated at 2022-06-22 08:06:02.316230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE();
    except:
        assert False;
    finally:
        assert True;


# Generated at 2022-06-22 08:06:05.571505
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:06:06.617692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:06:10.554911
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE
    InfoExtractor._instantiate_classes(KonserthusetPlayIE)
    assert hasattr(KonserthusetPlayIE, '_WORKING')

# Generated at 2022-06-22 08:06:11.617819
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)._real_extract(None)

# Generated at 2022-06-22 08:06:19.333533
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    expected = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
    assert KonserthusetPlayIE._match_id(KonserthusetPlayIE,url) == expected


# Generated at 2022-06-22 08:06:26.312093
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test public methods
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'