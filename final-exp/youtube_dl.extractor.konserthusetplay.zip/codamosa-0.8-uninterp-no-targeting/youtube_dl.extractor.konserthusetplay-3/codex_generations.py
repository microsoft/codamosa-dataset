

# Generated at 2022-06-22 07:58:01.287924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(0)


# Generated at 2022-06-22 07:58:06.366229
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._download_json('http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object', '12345')

# Generated at 2022-06-22 07:58:09.306271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(InfoExtractor(None)).url_result(test_url)

# Generated at 2022-06-22 07:58:11.075725
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        YouTubePlaylistIE()
    except:
        assert False, 'Cannot test the ctor of YouTubePlaylistIE'
    assert True

# Generated at 2022-06-22 07:58:13.124405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-22 07:58:19.678002
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test empty the constructor of the class
    obj = KonserthusetPlayIE()
    assert obj != None

    #
    # test for Valid URL
    #
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()._real_initialize(url)
    assets = obj._real_extract(url)

    # check all required assets
    assert assets['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    #assert assets['title'] == 'Orkesterns instrument: Valthornen'
    assert assets['thumbnail'] == 're:^https?://.*$'
    assert assets['duration'] == 398.76

# Generated at 2022-06-22 07:58:23.814496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 07:58:25.167973
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:29.689574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie1 = KonserthusetPlayIE()
    ie2 = KonserthusetPlayIE()
    assert ie1.IE_NAME is not None
    assert ie1.IE_NAME == ie2.IE_NAME

# Generated at 2022-06-22 07:58:30.738949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:58:43.617405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance._real_extract("", "")

# Generated at 2022-06-22 07:58:44.643244
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:58:46.362101
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-22 07:58:47.361395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:59.406380
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_VALID_URL'), "class KonserthusetPlayIE doesn't have _VALID_URL attribute"
    assert hasattr(KonserthusetPlayIE, '_TESTS'), "class KonserthusetPlayIE doesn't have _TESTS attribute"
    assert hasattr(KonserthusetPlayIE, '_download_webpage'), "class KonserthusetPlayIE doesn't have _download_webpage attribute"
    assert hasattr(KonserthusetPlayIE, '_match_id'), "class KonserthusetPlayIE doesn't have _match_id attribute"
    assert hasattr(KonserthusetPlayIE, '_real_extract'), "class KonserthusetPlayIE doesn't have _real_extract attribute"
    assert has

# Generated at 2022-06-22 07:59:03.299697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None

# Generated at 2022-06-22 07:59:05.715162
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:59:14.155113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  # positive tests
  assert KonserthusetPlayIE.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
  assert KonserthusetPlayIE.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

  # negative tests
  assert not KonserthusetPlayIE.suitable('https://www.konserthusetplay.se/')
  assert not KonserthusetPlayIE.suitable('https://rspoplay.se/')

# Generated at 2022-06-22 07:59:16.488832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.IE_NAME == 'konserthusetplay'


# Generated at 2022-06-22 07:59:28.829162
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # TOGGLE: True to run test
    if True:
        test_vids = [
            'https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
            #'https://www.konserthusetplay.se/?m=1MTOA5S5_tCmAVt0GF9g4Q',
            #'https://www.konserthusetplay.se/?m=h1pKbxphxRXCXNlPOd3qrw',
            #'https://www.konserthusetplay.se/?m=RxSYcGxnJKOAYCZBpzY1lg'
        ]

        for test_vid in test_vids:
            ie = Konserthuset

# Generated at 2022-06-22 07:59:51.044349
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None


# Generated at 2022-06-22 07:59:57.457352
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    objKonserthusetPlayIE = KonserthusetPlayIE()
    assert type(KonserthusetPlayIE) == type(objKonserthusetPlayIE)
    assert objKonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)".encode("utf-8")

# Generated at 2022-06-22 08:00:02.038630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None, \
        "KonserthusetPlayIE._VALID_URL cannot be None"
    assert KonserthusetPlayIE._TESTS is not None, \
        "KonserthusetPlayIE._TESTS cannot be None"

# Generated at 2022-06-22 08:00:12.098764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for class KonserthusetPlayIE.
    """
    from .common import InfoExtractor
    from .test_konserthuset_play import KonserthusetPlayIE

    ie = InfoExtractor()
    ie.set_info_extractors(
        {
            'rspoplay': KonserthusetPlayIE,
            'konserthusetplay': KonserthusetPlayIE,
        }
    )

    KonserthusetPlayIE._VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rs(?:poplay))\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:14.505586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        print("Could not create object of class KonserthusetPlayIE")

# Generated at 2022-06-22 08:00:19.982656
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.title() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:00:30.657123
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:32.077155
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:00:38.695986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = KonserthusetPlayIE._VALID_URL
    # Test if the regex matches the url
    match = KonserthusetPlayIE._VALID_URL_RE.search(url)
    # Test that url extraction works
    video_id = KonserthusetPlayIE._match_id(url)
    # Test that the video_id matches the extracted video_id
    assert match.group('id') == video_id




# Generated at 2022-06-22 08:00:40.962431
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import KonserthusetPlayIE
    kpIE = KonserthusetPlayIE(None)

# Generated at 2022-06-22 08:01:37.493310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-22 08:01:45.846030
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:47.090990
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	kp = KonserthusetPlayIE()


# Generated at 2022-06-22 08:01:48.525635
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:55.424867
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 08:01:57.035960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None


# Generated at 2022-06-22 08:02:09.440969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    regex = r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']'
    video_id = "CKDDnlCY-dhWAAqiMERd-A"
    webpage = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    e = "1475367f51d2ce892dad9d9aac0efa6b"

# Generated at 2022-06-22 08:02:11.772020
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp != None

# Generated at 2022-06-22 08:02:12.676473
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:16.833071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        assert False, "Instantiation of KonserthusetPlayIE failed"
    else:
        assert True

# Generated at 2022-06-22 08:04:23.721918
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:25.788451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("KonserthusetPlayIE")

# Generated at 2022-06-22 08:04:28.297750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:30.661906
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of KonserthusetPlayIE class
    refKonserthusetPlayIE = KonserthusetPlayIE(InfoExtractor)


# Generated at 2022-06-22 08:04:33.366970
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Check KonserthusetPlayIE constructor
    """
    # Arrange
    kp = KonserthusetPlayIE()

    # Act
    # nothing to do

    # Assert
    assert isinstance(kp, KonserthusetPlayIE)


# Generated at 2022-06-22 08:04:42.943418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'

    konserthusetplay = KonserthusetPlayIE()
    konserthusetplay._download_webpage = lambda *args, **kwargs: 'e=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:04:51.814173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE('KonserthusetPlayIE', 'http://example.com')

    assert x.name == 'KonserthusetPlayIE'
    assert x._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:52.929590
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:54.528184
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 08:04:57.637373
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")