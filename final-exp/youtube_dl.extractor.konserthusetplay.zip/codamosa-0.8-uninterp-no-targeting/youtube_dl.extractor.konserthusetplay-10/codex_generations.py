

# Generated at 2022-06-22 07:58:02.651901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    instance = KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:07.944360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthuset_play = KonserthusetPlayIE()
    assert konserthuset_play._VALID_URL == KonserthusetPlayIE._VALID_URL


# Unit tests for method _real_extract of class KonserthusetPlayIE

# Generated at 2022-06-22 07:58:13.568820
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.name == 'konserthusetplay'
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.host == 'www.konserthusetplay.se'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:17.753279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE
    except NameError:
        assert False
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:58:23.202025
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    expected = "http://www.konserthusetplay.se/?"
    actual = ie.url_result("http://www.konserthusetplay.se/?")
    print(actual)
    assert actual.url == expected

# Unit tests for _extract_m3u8_formats

# Generated at 2022-06-22 07:58:24.398962
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("")
    pass


# Generated at 2022-06-22 07:58:36.456801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Class should not raise Exception, if given invalid input
    KonserthusetPlayIE('Invalid URL')
    KonserthusetPlayIE(None)
    KonserthusetPlayIE('')
    # Unit test for function _real_extract() of class KonserthusetPlayIE
    KonserthusetPlayIE._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Unit test for function _match_id() of class KonserthusetPlayIE

# Generated at 2022-06-22 07:58:37.574051
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:58:44.300281
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.name == 'KonserthusetPlayIE'
    assert ie.supported_extractors == ['KonserthusetPlayIE']
    assert ie.extractor.name == 'KonserthusetPlayIE'


# Generated at 2022-06-22 07:58:48.137845
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 07:59:01.089448
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie is not None

# Generated at 2022-06-22 07:59:04.498568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'KonserthusetPlay'

# Generated at 2022-06-22 07:59:13.616803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE()
	assert ie.ie_key() == 'konserthusetplay'
	assert ie.suitable(None) == False
	assert ie.suitable('') == False
	assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == True
	assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == True
	assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&t=abc&id=efg') == True

# Generated at 2022-06-22 07:59:15.173677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:21.080719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.IE_NAME)
    assert(ie.IE_DESC)
    assert(ie._VALID_URL)
    assert(ie._TESTS)

# unit test for _real_extract of class KonserthusetPlayIE

# Generated at 2022-06-22 07:59:21.893488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:24.172318
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # when
    test = KonserthusetPlayIE()

    # then
    assert test != None

# Generated at 2022-06-22 07:59:28.575948
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(instance, KonserthusetPlayIE)


# Generated at 2022-06-22 07:59:36.456813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    if(ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").get("title") != "Orkesterns instrument: Valthornen"):
        raise("Fails on: http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

    if(ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw").get("title") != "Eric Saade (RSO)"):
        raise("Fails on: http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")


# Generated at 2022-06-22 07:59:45.778033
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL is not None
    assert KonserthusetPlayIE._TESTS is not None
    assert KonserthusetPlayIE._download_webpage is not None
    assert KonserthusetPlayIE._match_id is not None
    assert KonserthusetPlayIE._real_extract is not None
    assert KonserthusetPlayIE._search_regex is not None
    assert KonserthusetPlayIE._sort_formats is not None
    assert KonserthusetPlayIE._extract_m3u8_formats is not None


# Generated at 2022-06-22 08:00:09.231434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	try:
		KonserthusetPlayIE()
	except Exception as error:
		print(error)

# Generated at 2022-06-22 08:00:12.374321
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    
    # Pass class to method
    ie._real_extract(ie._VALID_URL)

# Generated at 2022-06-22 08:00:16.393686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    file = KonserthusetPlayIE(
        InfoExtractor(
            youtube_dl=None,
            params={},
            cache=None,
            fake_urls=None
        )
    )
    assert hasattr(file, '_download_webpage')



# Generated at 2022-06-22 08:00:20.153437
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("TEST_START: %s" % "KonserthusetPlayIE")
    _ = KonserthusetPlayIE("KonserthusetPlayIE")
    print("TEST_END: %s" % "KonserthusetPlayIE")

# Generated at 2022-06-22 08:00:21.199275
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:23.265572
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj=KonserthusetPlayIE()


# Generated at 2022-06-22 08:00:25.352207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-22 08:00:26.484419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:00:31.614441
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    konserthusetpl

# Generated at 2022-06-22 08:00:37.850624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.get_param('id') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.get_param('m') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:39.945125
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 08:01:46.764816
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE(url)
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:52.223449
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', {})
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:55.944781
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)";

# Generated at 2022-06-22 08:01:59.640435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    ie.download()

# Generated at 2022-06-22 08:02:11.534191
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test first constructor
    KonserthusetPlayIE._VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:19.728152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    # Test invalid URL
    invalid_url = "https://www.konserthusetplay.se/"
    assert test.suitable(invalid_url) is False
    # Test valid URL
    valid_url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert test.suitable(valid_url) is True
    # Test extraction of ID from valid URL
    assert test._match_id(valid_url) == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-22 08:02:23.980799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
	ie = KonserthusetPlayIE()
	assert ie.suitable(url)

# Generated at 2022-06-22 08:02:24.923631
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:28.854831
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    IEs = InfoExtractor._ies
    IEs.update({'KonserthusetPlayIE': ie})
    assert ie.__module__ == 'KonserthusetPlayIE'
    assert ie.__doc__ == KonserthusetPlayIE.__doc__

# Generated at 2022-06-22 08:04:42.411719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:46.576209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthusetplayIE is not None


# Generated at 2022-06-22 08:04:57.432501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    extractor = KonserthusetPlayIE()
    assert extractor._match_id(url) == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-22 08:05:08.432008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == '^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)$'
    with open('test_konserthuset_play.html', 'r') as f:
        webpage = f.read()
    rest = ie._download_json(ie._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e'),
            video_id='CKDDnlCY-dhWAAqiMERd-A', transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])


# Generated at 2022-06-22 08:05:16.978579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
	assert KonserthusetPlayIE()._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	assert KonserthusetPlayIE()._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Test for _real_extract method of KonserthusetPlayIE

# Generated at 2022-06-22 08:05:22.290739
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:05:31.857978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert IE.name == 'KonserthusetPlay'
    assert IE.ie_key() == 'KonserthusetPlay'
    assert IE.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not IE.valid_url('http://riaspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 08:05:35.923662
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('dummy')
    # Test property VALID_URL
    ie.VALID_URL
    # Test property _VALID_URL
    ie._VALID_URL
    # Test method _real_extract
    ie._real_extract('dummy')

# Generated at 2022-06-22 08:05:46.114377
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  inst = KonserthusetPlayIE()
  test_id = 'CKDDnlCY-dhWAAqiMERd-A'
  assert inst.ie_key() == 'KonserthusetPlay'
  assert inst.suitable(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
  assert inst._match_id(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == test_id
  assert inst._match_id(url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'
 

# Generated at 2022-06-22 08:05:48.112464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor.working == True
    assert info_extractor.IE_NAME == 'KonserthusetPlay'