

# Generated at 2022-06-22 07:58:00.774829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-22 07:58:10.627015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Tests for KonserthusetPlayIE"""
    from .test_downloader import FakeYDL
    from .test_downloader import FakeHttpDl

    def fake_downloader(ydl, params):
        return FakeHttpDl(ydl, params)

    class FakeYDL:
        def __init__(self, params):
            self.params = params

    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-22 07:58:12.038280
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:15.398645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUITABLE_GENERIC.match('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:58:23.541432
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

    # Testing for constructor of class KonserthusetPlayIE
    # Testing without passing in argument
    assert info_extractor is not None

    # Testing with passing in argument
    global IE_DESC, IE_NAME
    IE_DESC = "Konserthuset.se"
    IE_NAME = KonserthusetPlayIE.ie_key()
    assert IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:28.725912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 07:58:31.335617
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False,'Unable to instantiate KonserthusetPlayIE'
    assert True

# Generated at 2022-06-22 07:58:36.612423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(ie.ie_key())
    assert ie.suitable(ie.ie_key() + '#' + ie._VALID_URL)
    assert not ie.suitable('http://www.youtube.com/123')

# Generated at 2022-06-22 07:58:37.617991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        k = KonserthusetPlayIE()
    except Exception as e:
        print(e)

# Generated at 2022-06-22 07:58:43.519554
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.suitable(ie._VALID_URL)
    assert ie.suitable(ie._TESTS[0]['url'])

# Generated at 2022-06-22 07:59:08.057970
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.__class__  == KonserthusetPlayIE


# Generated at 2022-06-22 07:59:09.919561
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	k = KonserthusetPlayIE()


	assert k.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 07:59:22.016849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A')
    ie._download_json('http://csp.picsearch.com/rest?e=d3d3LmtvbnNlcmh1c3Rlc3BsYXkuc2U%3D&containerId=mediaplayer&i=object', 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:29.289046
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda x, y: '{}'
    ie._download_json = lambda x, y, transform_source=lambda x: x: '{}'
    ie.extract(url)
    assert True

# Generated at 2022-06-22 07:59:32.475633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # 1. test is just to create an instance of KonserthusetPlayIE
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:34.609225
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-22 07:59:36.243724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:38.577935
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert isinstance(konserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-22 07:59:39.422023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:41.651589
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert extractor.suitable(extractor._VALID_URL.__str__()) == True

# Generated at 2022-06-22 08:00:26.444575
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:38.324196
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:39.337496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:41.579941
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    print('test_KonserthusetPlayIE is being called...')

# Generated at 2022-06-22 08:00:49.171838
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert instance._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:00:58.388879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.name == "konserthusetplay"
    assert inst.IE_NAME == "konserthusetplay"
    assert inst.IE_DESC == "konserthusetplay.se"
    assert inst._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert inst._downloader.params["usenetrc"] == False
    assert inst._downloader.params["nocheckcertificate"] == False
    assert inst._downloader.params["verbose"] == True
    assert inst._downloader.params["forceurl"] == False
    assert inst._downloader.params["forcetitle"] == False

# Generated at 2022-06-22 08:01:01.859550
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE)


# Generated at 2022-06-22 08:01:05.813493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:09.507891
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A');
    assert ie.VIDEO_ID == 'CKDDnlCY-dhWAAqiMERd-A';

# Generated at 2022-06-22 08:01:10.824787
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:03:05.695088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        # Testing the constructor
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:03:07.839993
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE(KonserthusetPlayIE.__name__)
    assert konserthusetplay.working == True

# Generated at 2022-06-22 08:03:08.686199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Without any test cases
    return

# Generated at 2022-06-22 08:03:10.231192
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 08:03:12.988095
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This is a constructor test for KonserthusetPlayIE,
    #       to make sure it doesn't crash by getting on
    #       a specific page. It is intended to catch
    #       errors in the constructor of the class.
    _ = KonserthusetPlayIE()

# Generated at 2022-06-22 08:03:24.579576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE

    """
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE

    konserthusetplay = KonserthusetPlayIE('KonserthusetPlay')
    assert konserthusetplay.name == 'KonserthusetPlay'
    assert konserthusetplay.ie_key() == 'KonserthusetPlay'
    assert konserthusetplay.info_url() is None
    assert konserthusetplay.description() == 'konserthusetplay.se'
    assert konserthusetplay.working() is True
    assert InfoExtractor.working(konserthusetplay) is True

# Generated at 2022-06-22 08:03:28.932827
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ins = KonserthusetPlayIE(None)
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__ == 'KonserthusetPlay extractor'

# Generated at 2022-06-22 08:03:29.956042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:03:30.669861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    assert True

# Generated at 2022-06-22 08:03:31.709644
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	pass


# Generated at 2022-06-22 08:05:44.834049
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:52.100523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:05:53.407243
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:06:05.717914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:06:15.405290
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_class = 'KonserthusetPlayIE'

# Generated at 2022-06-22 08:06:17.832914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    "Test constructor"
    unit = KonserthusetPlayIE()
    assert unit is not None

# Generated at 2022-06-22 08:06:18.761775
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-22 08:06:25.647405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda url, video_id, note='Downloading webpage': ''
    ie._download_json = lambda url, video_id, transform_source, fatal: {}
    ie._search_regex = lambda pattern, string, name, fatal, flags: 'CKDDnlCY-dhWAAqiMERd-A'
    ie._real_extract('')
    return ie

# Generated at 2022-06-22 08:06:29.000307
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None);
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-22 08:06:34.018468
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    example_url = KonserthusetPlayIE._VALID_URL.format(**{'id': 'CKDDnlCY-dhWAAqiMERd-A'})

    # This call should work and return a KonserthusetPlayIE object
    return KonserthusetPlayIE(example_url)