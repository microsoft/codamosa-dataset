

# Generated at 2022-06-22 07:57:59.555117
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp

# Generated at 2022-06-22 07:58:08.289641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Dummy class instance
    kp = KonserthusetPlayIE()

    # Test method _real_extract()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = kp._real_extract(url)
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['duration'] == 398.76
    assert 'Orkesterns instrument: Valthornen.mp4' in [result['formats'][i]['url'] for i in range(3)]

# Generated at 2022-06-22 07:58:19.315024
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == ':konserthusetplay'
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.E == 'e'
    assert ie.REST_URL == 'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object'
    assert ie.FORMAT_ID_REGEX == '_([^_]+)_h264m\\.mp4'

# Generated at 2022-06-22 07:58:27.800483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_input = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_instance = KonserthusetPlayIE()
    assert(test_instance._VALID_URL == KonserthusetPlayIE._VALID_URL)
    assert(test_instance._downloader is None)
    assert(test_instance._match_id(test_input) ==
           KonserthusetPlayIE._match_id(test_input, test_instance))

# Generated at 2022-06-22 07:58:29.498761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-22 07:58:30.536082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    check_KonserthusetPlayIE()


# Generated at 2022-06-22 07:58:32.813108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp_ie = KonserthusetPlayIE()
    assert isinstance(kp_ie, InfoExtractor)

# Generated at 2022-06-22 07:58:34.951630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE(None, None)
        assert False
    except:
        assert True


# Generated at 2022-06-22 07:58:45.930865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    webpage = ie._download_webpage(url, "CKDDnlCY-dhWAAqiMERd-A")
    e = ie._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')

# Generated at 2022-06-22 07:58:51.462861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    class Player(KonserthusetPlayIE):
        def __init__(self):
            KonserthusetPlayIE.__init__(self)
            self.test_url = url

    player = Player()

    assert 'id' in player._real_extract(url)

# Generated at 2022-06-22 07:59:05.585839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extraction_of_class = [InfoExtractor]
    assert KonserthusetPlayIE in extraction_of_class

# Generated at 2022-06-22 07:59:07.329443
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    with pytest.raises(AttributeError):
        KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:08.746536
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(lambda x: x) # test constructor

# Generated at 2022-06-22 07:59:09.807603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:21.860341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_dict = {
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'md5': 'e3fd47bf44e864bd23c08e487abe1967',
        'info_dict': {
            'id': 'CKDDnlCY-dhWAAqiMERd-A',
            'ext': 'mp4',
            'title': 'Orkesterns instrument: Valthornen',
            'description': 'md5:f10e1f0030202020396a4d712d2fa827',
            'thumbnail': 're:^https?://.*$',
            'duration': 398.76,
        },
    }

    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:32.857112
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Constructor for KonserthusetPlayIE"""
    assert hasattr(KonserthusetPlayIE, '_VALID_URL'), 'KonserthusetPlayIE._VALID_URL is not defined'
    assert hasattr(KonserthusetPlayIE, '_TESTS'), 'KonserthusetPlayIE._TESTS is not defined'
    assert hasattr(KonserthusetPlayIE, '_real_extract'), 'KonserthusetPlayIE._real_extract is not defined'
    assert hasattr(KonserthusetPlayIE, 'IE_DESC'), 'KonserthusetPlayIE.IE_DESC is not defined'
    assert hasattr(KonserthusetPlayIE, 'IE_NAME'), 'KonserthusetPlayIE.IE_NAME is not defined'
   

# Generated at 2022-06-22 07:59:43.064637
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .test import (
        assertRegexpMatches,
        assertStartsWith,
        assertTrue,
        check_json,
        mock,
    )

    # Create mocks to test constructor

    mock_match = mock()
    mock_match.group.return_value = 'm-id'

    mock_webpagetest = mock()
    mock_webpagetest.search.return_value = 'e-id'

    # Actual test of constructor

    konserthuset_ie = KonserthusetPlayIE(
        InfoExtractor('test', 'test'))

    assertStartsWith(konserthuset_ie._download_webpage.__name__, 'real_')

# Generated at 2022-06-22 07:59:48.754813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    URL = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    obj = KonserthusetPlayIE()
    obj.suitable(URL)
    assert KonserthusetPlayIE.suitable(URL) == True
    obj.extract(URL)

# Generated at 2022-06-22 07:59:50.362034
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    instance.suite()

# Generated at 2022-06-22 07:59:54.083007
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE().url_result(url)

# Generated at 2022-06-22 08:00:15.699098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	try:
		KonserthusetPlayIE()
	except:
		pass

# Generated at 2022-06-22 08:00:18.748487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test case for  constructor of class KonserthusetPlayIE """
    konserthusetplay_ie = KonserthusetPlayIE()
    assert konserthusetplay_ie

# Generated at 2022-06-22 08:00:29.782886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testing_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    my_object = KonserthusetPlayIE(testing_url, {})
    assert my_object._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:30.758287
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'KonserthusetPlayIE' == KonserthusetPlayIE().ie_key()

# Generated at 2022-06-22 08:00:33.671137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert isinstance(obj, InfoExtractor)
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-22 08:00:39.406045
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not KonserthusetPlayIE.suitable('http://www.google.com')

# Generated at 2022-06-22 08:00:44.992597
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of KonserthusetPlayIE class
    ie = KonserthusetPlayIE()

    # No test implemented here
    assert ie is not None

# Generated at 2022-06-22 08:00:55.556882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.__name__ == 'konserthusetplay'

# Generated at 2022-06-22 08:00:56.430346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:00.846649
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:04.488469
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 08:02:14.395023
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_video_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE._download_webpage = \
    lambda KonserthusetPlayIE, url, video_id: 'SOME HTML'
    KonserthusetPlayIE._search_regex = \
    lambda KonserthusetPlayIE, pattern, webpage, name, default: \
    '12345'

# Generated at 2022-06-22 08:02:18.559160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:21.168882
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert(KonserthusetPlayIE is not None)


# Generated at 2022-06-22 08:02:25.582256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserhuset_play_ie = KonserthusetPlayIE()
    assert konserhuset_play_ie == KonserthusetPlayIE(
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:02:27.847311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:02:32.401316
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:34.288642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.k_prefer_download

# Generated at 2022-06-22 08:02:43.224837
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.title == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:02:54.674237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_title = 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:03:59.235319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-22 08:04:01.800565
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as e:
        print("Exception %s raised in KonserthusetPlayIE" % repr(e))
        return False
    return True

# Generated at 2022-06-22 08:04:09.715717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    if ie._VALID_URL != r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)':
        raise AssertionError('Bad class attribute: "{}", expected "{}"'.format(ie._VALID_URL, r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'))

# Generated at 2022-06-22 08:04:12.881087
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-22 08:04:20.117252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS

# Generated at 2022-06-22 08:04:29.303840
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:31.208475
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None, 'No KonserthusetPlayIE object created.'
    

# Generated at 2022-06-22 08:04:37.209756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie.extract(url)
    return "OK"


# Generated at 2022-06-22 08:04:38.745719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:41.606398
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Runs a simple test case for the KonserthusetPlayIE constructor
    """

    infoExtractor = KonserthusetPlayIE()
    assert infoExtractor is not None



# Generated at 2022-06-22 08:06:53.904745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-22 08:06:55.604659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE() is not None

# Generated at 2022-06-22 08:07:03.617837
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:07:11.914152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if an instance with a defined URL is constructed correctly
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:07:15.061679
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE()
    assert video.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-22 08:07:18.305910
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie_args = ie._extract_urls(url)
    ie._real_extract(ie_args)



# Generated at 2022-06-22 08:07:28.850306
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:07:35.046975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # element name is 'konserthusetplay'
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, {}, True)
    print(ie)
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, {}, False)
    print(ie)

# Generated at 2022-06-22 08:07:35.845409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:07:45.554369
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Guess the wrong URL
    # eg: konserthusetplay://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    wrongURL = "konserthusetplay://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Instantiate the KonserthusetPlayIE class
    KonserthusetPlayIE(wrongURL)

    # Guess the correct URL
    # eg: https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    correctURL = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    # Instantiate