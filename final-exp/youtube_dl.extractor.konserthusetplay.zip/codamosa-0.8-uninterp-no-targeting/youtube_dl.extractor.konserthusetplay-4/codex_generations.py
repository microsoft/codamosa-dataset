

# Generated at 2022-06-22 07:58:08.163460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert(ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.video_url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.title == 'Orkesterns instrument: Valthornen')
    assert(ie.thumbnail == 'http://pictures.svtstatic.com/CSM-CKDDnlCY-dhWAAqiMERd-A/767x431.jpg')
    assert(ie.duration == 398.76)

# Generated at 2022-06-22 07:58:19.911750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   e = KonserthusetPlayIE()
   video_id = e._match_id("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
   assert video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:58:21.539442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:22.299086
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-22 07:58:26.647211
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test KonserthusetPlayIE constructor"""
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:36.426108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:40.149757
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import KonserthusetPlayIE
    konserthuset_play_ie = KonserthusetPlayIE.KonserthusetPlayIE()
    konserthuset_play_ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 07:58:46.076690
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test for object KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    ie.extract(url)


# Generated at 2022-06-22 07:58:53.682182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:59:02.790311
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = KonserthusetPlayIE()._real_extract(url)

    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['url'] == 'http://csp.picsearch.com/rest?e=CKDDnlCY-dhWAAqiMERd-A&containerId=mediaplayer&i=object'
    assert result['thumbnail'] == 're:^https?://.*$'

# Generated at 2022-06-22 07:59:16.177270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test constructor
    assert(isinstance(KonserthusetPlayIE(), InfoExtractor))



# Generated at 2022-06-22 07:59:19.362207
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('test_KonserthusetPlayIE', 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 07:59:25.920461
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    testobj = KonserthusetPlayIE()


# Generated at 2022-06-22 07:59:36.346620
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:48.203901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert 'default_extractor' in instance
    assert 'default_protocol' in instance
    assert 'default_suitable' in instance
    assert 'default_video_id_re' in instance
    assert 'downloader' in instance
    assert 'groups' in instance
    assert 'ie_key' in instance
    assert 'ie_key_re' in instance
    assert 'js_to_json' in instance
    assert 'suitable' in instance
    assert 'video_id_re' in instance
    assert '_download' in instance
    assert '_download_json' in instance
    assert '_download_json_handle' in instance
    assert '_download_json_handle2' in instance
    assert '_download_json_handle_no_embed' in instance

# Generated at 2022-06-22 07:59:49.943121
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:00:00.778699
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   ie = KonserthusetPlayIE()
   assert ie.name == 'konserthusetplay'
   assert ie.ie_key() == 'KonserthusetPlay'
   assert ie.host == 'konserthusetplay.se'
   assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:07.536541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    
    class KonserthusetPlayIE_Test(KonserthusetPlayIE):
        def __init__(self, url):
            self.url = url
            self.info_dict = self._real_extract(url)
    
    info_extractor = KonserthusetPlayIE_Test("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert info_extractor.info_dict['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info_extractor.info_dict['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:00:08.725749
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-22 08:00:19.718125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Python 2.x
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:53.017123
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-22 08:00:58.578632
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))
    assert(KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"))
    assert(not KonserthusetPlayIE("http://www.youtube.com/?m=CKDDnlCY-dhWAAqiMERd-A"))

# Generated at 2022-06-22 08:00:59.360897
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:01:01.196367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-22 08:01:02.042804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:01:04.477241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    _KonserthusetPlayIE = KonserthusetPlayIE()
    pass

# Generated at 2022-06-22 08:01:08.545453
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(ie)
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    print(ie)


# Generated at 2022-06-22 08:01:11.003779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(InfoExtractor())._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-22 08:01:14.853946
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst.name == 'konserthusetplay'
    assert inst.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:01:15.892892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-22 08:02:08.783771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=t4A4t4cLQjs5wHZr0rAKNQ')
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


# Generated at 2022-06-22 08:02:09.798456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:12.205998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'konserthusetplay')

# Generated at 2022-06-22 08:02:16.582519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test constructor of KonserthusetPlayIE"""
    from .common import Options
    ie = KonserthusetPlayIE(Options())
    assert ie.provider == 'konserthusetplay'

# Generated at 2022-06-22 08:02:24.360202
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test constructor of class KonserthusetPlayIE
    #
    # The constructor uses regex to test whether the url is valid.
    #
    # Args:
    #     url (str): url of video to download
    #
    # Returns:
    #     (object): object of class KonserthusetPlayIE
    #
    
    # Create
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Test

# Generated at 2022-06-22 08:02:26.198958
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None

# Generated at 2022-06-22 08:02:37.229859
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:39.205818
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# Test the constructor konserthusetplay_ie.
	test_obj = KonserthusetPlayIE()
	assert test_obj != None

# Generated at 2022-06-22 08:02:41.072241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert isinstance(inst, KonserthusetPlayIE)
    return inst

# Generated at 2022-06-22 08:02:44.005041
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if not ie:
        raise AssertionError("Unit test for class KonserthusetPlayIE failed")

# Generated at 2022-06-22 08:04:53.167831
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Basic Instantiation
    KonserthusetPlayIE()
    # Tests for method _real_extract
    KonserthusetPlayIE._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE._real_extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 08:04:56.024788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test KonserthusetPlayIE() constructor.
    """
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:04:59.368813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    player = KonserthusetPlayIE()
    assert(player.IE_NAME == 'konserthusetplay:play')

# Generated at 2022-06-22 08:05:03.388839
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie == KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:05:08.431584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()

    # Assert
    assert isinstance(ie._VALID_URL, str)
    assert isinstance(ie._TESTS, list)

# Generated at 2022-06-22 08:05:12.149678
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert 'KonserthusetPlay' == ie.IE_NAME
    assert 'konserthusetplay' == ie.ie_key() #ie_key = key = ie_name.split(' ')[0].lower()


# Generated at 2022-06-22 08:05:13.688001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-22 08:05:14.581182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-22 08:05:15.982242
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._entries()

# Generated at 2022-06-22 08:05:20.937917
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    return True