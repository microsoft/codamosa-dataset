

# Generated at 2022-06-22 07:58:00.775706
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.match(ie._VALID_URL)
    for test in ie._TESTS:
        ie.match(test['url'])

# Generated at 2022-06-22 07:58:05.898963
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('KonserthusetPlayIE', 'konserthusetplay.se') is not None

# Generated at 2022-06-22 07:58:09.191608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    

# Generated at 2022-06-22 07:58:10.405641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-22 07:58:11.837343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:13.466419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import test_KonserthusetPlayIE
    test_KonserthusetPlayIE().runTests()

# Generated at 2022-06-22 07:58:14.269076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-22 07:58:17.542773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-22 07:58:27.039159
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_cases = [
        ('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'CKDDnlCY-dhWAAqiMERd-A'),
        ('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', 'elWuEH34SMKvaO4wO_cHBw'),
    ]
    for url, id in test_cases:
        assert KonserthusetPlayIE()._match_id(url) == id, 'URL: %s does not match id %s' % (url, id)

# Generated at 2022-06-22 07:58:28.932711
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.NAME == "KonserthusetPlay"
#

# Generated at 2022-06-22 07:58:47.248489
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  url = KonserthusetPlayIE()._VALID_URL
  ie = KonserthusetPlayIE(KonserthusetPlayIE._create_fake_head(url))
  assert ie.suitable(url)
  assert ie._VALID_URL == url
  assert ie.IE_NAME == 'konserthusetplay:play'
  assert ie._TEST == KonserthusetPlayIE._TESTS[0]
  assert ie._downloader == None

# Generated at 2022-06-22 07:58:53.182256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:03.369326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    from ..jsinterp import JSInterpreter
    from ..compat import compat_http_client
    from ..utils import (
        compat_urllib_error,
        compat_urllib_parse_urlencode,
        compat_urllib_request,
    )
    try:
        from ..compat import compat_urlparse
    except ImportError:
        from ..compat import urlparse as compat_urlparse
    try:
        from ..compat import compat_urlopen
    except ImportError:
        from ..compat import urlopen as compat_urlopen

# Generated at 2022-06-22 07:59:06.611809
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE """
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:59:17.881598
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:59:22.667288
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:33.308740
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 07:59:37.838279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie.extract(video_url)

# Generated at 2022-06-22 07:59:39.506447
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE is not None

# Generated at 2022-06-22 07:59:40.575142
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test(KonserthusetPlayIE)

# Generated at 2022-06-22 08:00:02.171381
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:10.992876
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_name = 'KonserthusetPlayIE'
    IE = globals()[class_name]
    # create an instance of the class to test, should not raise
    instance = IE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # verify variable types
    assert isinstance(instance._VALID_URL, type(re.compile('hello, world')))
    #TODO test to verify that the expected data is returned,
    # e.g. by matching md5 of resulting file, or by matching
    # expected values in the result's JSON.


# Generated at 2022-06-22 08:00:16.970723
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    info = ie.extract()
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:00:18.016820
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-22 08:00:24.792833
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test cases for constructor of the class KonserthusetPlayIE"""

# Generated at 2022-06-22 08:00:30.784378
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.NAME == "KonserthusetPlay"
    assert ie.IE_NAME == "KonserthusetPlay"
    assert ie.NAME == ie.IE_NAME
    assert ie.VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 08:00:32.539224
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Just test if an instance can be created
    KonserthusetPlayIE("")

# Generated at 2022-06-22 08:00:36.534149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    
    # Test 1
    ie = KonserthusetPlayIE()

    # Test 2
    ie = KonserthusetPlayIE(params=None, downloader=None, age_limit=None)

# Generated at 2022-06-22 08:00:37.526807
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:49.040813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL ==
           r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-22 08:01:40.169199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:47.667167
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    webpage = instance._download_webpage(url, 'id')
    e = instance._search_regex(
            r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')
    rest = instance._download_json(
            'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % e,
            'id', transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])
    print(rest)

# Generated at 2022-06-22 08:01:49.545783
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor of class
    ie = KonserthusetPlayIE()
    print(ie)

# Generated at 2022-06-22 08:01:55.799886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:56.347163
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:01:58.280527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert hasattr(i, '_download_json')
    assert hasattr(i, '_match_id')
    assert hasattr(i, '_real_extract')

# Generated at 2022-06-22 08:02:00.189506
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    return ie


# Generated at 2022-06-22 08:02:01.404323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:02:02.530901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:05.589474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == KonserthusetPlayIE()


# Generated at 2022-06-22 08:03:59.106659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extractor_key == 'KonserthusetPlay'

# Generated at 2022-06-22 08:04:03.438493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	infoExtractor = KonserthusetPlayIE()

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:04.456797
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)

# Generated at 2022-06-22 08:04:14.857444
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor exception handling
    ie = KonserthusetPlayIE(None)
    assert ie._downloader is not None
    ie = KonserthusetPlayIE(None, downloader=None)
    assert ie._downloader is None
    # Test constructor correct
    kp = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=zJ5UQCU6KjhJxCYCwjKDew')
    assert kp._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:17.558383
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if KonserthusetPlayIE is not None :
        KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:21.061822
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    print(ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'))

# Generated at 2022-06-22 08:04:23.172823
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('KonserthusetPlayIE')

# Generated at 2022-06-22 08:04:24.185651
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE({})

# Generated at 2022-06-22 08:04:32.293864
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test is_IE of this IE class
    ie = KonserthusetPlayIE()
    assert ie.is_IE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.is_IE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    # Test to_screen method
    ie._to_screen('Test to_screen')

test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:37.134601
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME in ie.suitable
    assert ie.ie_key() in ie.suitable
    assert ie.IE_KEY in ie.suitable
    assert ie._VALID_URL in ie.suitable