

# Generated at 2022-06-22 07:58:03.743168
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	obj = KonserthusetPlayIE()
	return obj

# Generated at 2022-06-22 07:58:07.747245
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'konserthusetplay'

# Generated at 2022-06-22 07:58:13.089681
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Constructor test
    """
    ie = KonserthusetPlayIE()
    # Test IE
    assert ie.ie_key() == 'KonserthusetPlay'
    # Test IE extras
    assert ie.md5 == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:58:17.600104
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    assert ie.IE_NAME == "konserthusetplay:playlist"
    assert ie.IE_DESC == "Konserthusetplay Playlist"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 07:58:19.866499
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthusetplay import test_KonserthusetPlayIE
    return test_KonserthusetPlayIE

# Generated at 2022-06-22 07:58:21.163344
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE("")
    assert not obj == None

# Generated at 2022-06-22 07:58:25.168274
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:58:33.859314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 07:58:35.854042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that KonserthusetPlayIE is instance of InfoExtractor
    assert issubclass(KonserthusetPlayIE, InfoExtractor)

# Generated at 2022-06-22 07:58:38.872187
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    print(type(obj))
    print(type(obj._VALID_URL))
    print(type(obj._TESTS[0]))

test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:56.058885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.IE_NAME == 'konserthusetplay'
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-22 07:59:00.737791
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Make a new YoutubeIE instance and check that
    # its _VALID_URL class attribute has been properly set.
    ie = KonserthusetPlayIE()

    # Check that __init__ has set _VALID_URL attribute to the correct value
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-22 07:59:06.611670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        # This will never be triggered since KonserthusetPlayIE lacks arguments
        raise AssertionError()
    except TypeError as e:
        assert str(e) == 'arguments needed: url, display_id'

# Generated at 2022-06-22 07:59:09.409483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie == KonserthusetPlayIE(ie.extractor_key)

# Generated at 2022-06-22 07:59:15.527051
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_utils import stub_response
    from .konserthusetplay import KonserthusetPlayIE
    i = KonserthusetPlayIE()
    assert i is not None
    try:
        i.get_download_formats
        i.get_download_url
        i.get_json_url
    except AttributeError:
        raise AssertionError("Unit test failed.")

# Generated at 2022-06-22 07:59:17.551672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the constructor
    # Does not take any arguments
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:29.752216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:30.328996
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:38.843089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(b'KonserthusetPlay')
    assert ie.suitable(b'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable(b'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


# Generated at 2022-06-22 07:59:40.727163
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test correct construction of KonserthusetPlayIE
    KonserthusetPlayIE(InfoExtractor)._downloader

# Generated at 2022-06-22 08:00:08.380675
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    instance = KonserthusetPlayIE()
    instance.initialize()
    instance.extract(url)

# Generated at 2022-06-22 08:00:10.341164
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-22 08:00:16.871795
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 08:00:19.272141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-22 08:00:21.574718
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    d = dict()
    k = KonserthusetPlayIE(d)
    assert isinstance(k, InfoExtractor)

# Generated at 2022-06-22 08:00:24.988074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        _ = KonserthusetPlayIE()
    except Exception as e:
        print(e)
        assert(False)


# Generated at 2022-06-22 08:00:29.824052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    b = KonserthusetPlayIE(None)
    assert b._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:33.705316
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("CKDDnlCY-dhWAAqiMERd-A")
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:00:41.401160
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:00:43.137881
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:01:45.844374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-22 08:01:49.090438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test_constructor creates an instance of class KonserthusetPlayIE
    # and asserts that it is not None
    def test_constructor():
        assert KonserthusetPlayIE() is not None
    test_constructor()

# Unit tests for method _real_extract of class KonserthusetPlayIE

# Generated at 2022-06-22 08:01:55.575405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:59.158376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'Konserthuset Play'

# Generated at 2022-06-22 08:02:02.390566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.extractor_key() == 'KonserthusetPlay'
    assert ie.ie_key() == 'KonserthusetPlay'



# Generated at 2022-06-22 08:02:05.492592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-22 08:02:08.835770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert (ie.name == 'konserthusetplay')
    assert (ie.host == 'www.konserthusetplay.se')

# Generated at 2022-06-22 08:02:11.369224
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:02:17.763285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # When: I instanciate KonserthusetPlayIE
    kp = KonserthusetPlayIE()

    # Then: I should see that it works for a known video id
    assert kp._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:23.931836
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetPlayIE = KonserthusetPlayIE()
    konserthusetPlayIE._real_extract(konserthusetPlayIE._VALID_URL,url)

# Generated at 2022-06-22 08:04:49.331803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:50.446983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:57.612617
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('www.konserthusetplay.se')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.IE_DESC == 'KonserthusetPlay.se, RSpoplay.se'

# Generated at 2022-06-22 08:04:58.807771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE != None

# Generated at 2022-06-22 08:05:01.461562
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_key() == obj.ie_key_()

# Generated at 2022-06-22 08:05:09.171716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('http://youtube.com/watch?v=SCtz0BKjCyw')

# Generated at 2022-06-22 08:05:10.259257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:10.829172
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-22 08:05:19.149556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    expected_title = 'Orkesterns instrument: Valthornen'
    expected_description = ('Valthornen har en viktig roll för brassgruppen. '
        'Det är huvudinstrument inom sektionen och har en distinkt klang, '
        'som karakteriserar konsertorkestern.')
    expected_duration = 399.0
    expected_thumbnail = 're:^https?://.*$'
    expected_e = 'J-MgQSV7O45HBAOuKEJX-A'

# Generated at 2022-06-22 08:05:21.679584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.attributes == {}
    assert ie.headers == {}