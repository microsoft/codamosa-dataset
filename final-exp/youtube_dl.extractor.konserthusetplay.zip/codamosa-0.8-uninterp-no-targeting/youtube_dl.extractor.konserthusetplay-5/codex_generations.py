

# Generated at 2022-06-22 07:58:09.817959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    ie = KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]

# Generated at 2022-06-22 07:58:12.687528
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj

# Generated at 2022-06-22 07:58:21.576560
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    info = KonserthusetPlayIE()._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    # retrieve the video_id from this URL
    assert info["id"] == "CKDDnlCY-dhWAAqiMERd-A"
    # check if the downloadable formats are right
    assert "formats" in info
    # check if the subtitles exist in the subtitles
    assert "subtitles" in info
    # check if the correct duration is returned
    assert info["duration"] == 398.76
    # check if the correct title is returned
    assert info["title"] == "Orkesterns instrument: Valthornen"

# Generated at 2022-06-22 07:58:26.025329
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(url)

test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:32.857472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("")
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-22 07:58:35.379507
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except NameError:
        assert False, 'Failed to instantiate KonserthusetPlayIE'


# Generated at 2022-06-22 07:58:36.672408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(dict())
    assert ie

# Generated at 2022-06-22 07:58:38.090409
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-22 07:58:41.243359
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-22 07:58:52.879271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:26.170323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True
    assert ie.suitable("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") == True

    assert ie.suitable("https://www.konserthusetplay.se/?m=CKDDnlCY-dh") == False
    assert ie.suitable("https://www.konserthusetplay.se") == False

# Generated at 2022-06-22 07:59:36.528429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with a nonexisting URL
    nonexisting_url = "http://www.konserthusetplay.se/?m=BAD-ID"
    assert(KonserthusetPlayIE().suitable(nonexisting_url) is False)

    # Test with an existing URL
    existing_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert(KonserthusetPlayIE().suitable(existing_url) is True)

    # Test that the constructor raises an exception with a non-compatible URL
    wrong_url = "http://www.youtube.com/"
    try:
        KonserthusetPlayIE().suitable(wrong_url)
        assert(False)
    except Exception:
        assert(True)



# Generated at 2022-06-22 07:59:38.044215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-22 07:59:45.169917
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.url == url
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:53.354702
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not KonserthusetPlayIE.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-22 08:00:02.853951
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 08:00:03.719717
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('')

# Generated at 2022-06-22 08:00:05.117484
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie

# Generated at 2022-06-22 08:00:17.070052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert 'KonserthusetPlayIE' == instance.IE_NAME
    assert 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A' == instance._VALID_URL
    assert 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A' == instance._TESTS[0]['url']
    assert 'Orkesterns instrument: Valthornen' == instance._TESTS[0]['info_dict']['title']


# Generated at 2022-06-22 08:00:17.736594
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-22 08:00:45.522713
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unit = KonserthusetPlayIE()
    unit.match("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:00:47.105646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # The constructor of class KonserthusetPlayIE should not throw an error when invoked
    KonserthusetPlayIE('test')


# Generated at 2022-06-22 08:00:52.772094
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.ie_key() != 'KonserthusetIE')

# Test for KonserthusetPlayIE.extract()
# Test with a trusted source, that we have a test of in _TESTS
# We trust that the test is properly written but we want to test
# the code of extract()

# Generated at 2022-06-22 08:00:54.237007
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('www.konserthusetplay.se')
    assert k is not None

# Generated at 2022-06-22 08:00:57.189460
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-22 08:01:00.230405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE.__new__(KonserthusetPlayIE)

# Generated at 2022-06-22 08:01:08.247471
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test extractor with one url
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie1 = KonserthusetPlayIE()
    _ = ie1.extract(url)
    # test extractor with two urls
    param = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://' + ie1.ie_key() + '/?' + 'm=' + param
    assert ie1.suitable(url)
    assert ie1.IE_NAME == 'KonserthusetPlay'
    _ = ie1.extract(url)

# Generated at 2022-06-22 08:01:09.230186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:20.476422
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an object to test methods of class KonserthusetPlayIE.
    k = KonserthusetPlayIE()
    # Test method _extract_urls().

# Generated at 2022-06-22 08:01:24.594591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k_play = KonserthusetPlayIE()
    result = k_play.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(result == True)

# Generated at 2022-06-22 08:02:12.896768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE(), KonserthusetPlayIE)

# Generated at 2022-06-22 08:02:16.146403
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        obj = KonserthusetPlayIE()
    except:
        assert False
    assert True

# Generated at 2022-06-22 08:02:19.613423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 08:02:31.908237
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	konserthusetplay = KonserthusetPlayIE(0)
	assert konserthusetplay is not None
	assert konserthusetplay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:40.382568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.SUFFIX == '%s:%s' % (ie.ie_key(), ie._VALID_URL)

# Generated at 2022-06-22 08:02:44.093515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("a", "b", "c")
    assert ie._downloader.params['noplaylist']



# Generated at 2022-06-22 08:02:47.159141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") is not None

# Generated at 2022-06-22 08:02:58.436712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    this_file_path = os.path.abspath(os.path.dirname(__file__))
    # Constructor of class KonserthusetPlayIE takes two arguments, ie and url
    # Example of url is 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(youtube_dl.YoutubeDL(),
                            'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test method _real_initialize of class YoutubeDL
    ie._real

# Generated at 2022-06-22 08:03:08.652428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test if KonserthusetPlayIE() constructor works.
    """
    # Test of incorrect constructor
    assert_raises(AssertionError, KonserthusetPlayIE, None)
    assert_raises(AssertionError, KonserthusetPlayIE, "")
    assert_raises(AssertionError, KonserthusetPlayIE, "some-wrong-url")

    # Test of correct constructor
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert_true(isinstance(KonserthusetPlayIE(url), InfoExtractor))
    url = "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"
   

# Generated at 2022-06-22 08:03:13.018374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
                             'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(obj.test())


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:28.882341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert k.get_url() == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'



# Generated at 2022-06-22 08:05:30.422014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:37.652152
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = InfoExtractor(KonserthusetPlayIE)
    ie.register_namespace('csp', 'http://csp.picsearch.com/rest')
    ie.register_namespace('media', 'http://search.yahoo.com/mrss/')
    ie.register_namespace('jwplayer', 'http://developer.longtailvideo.com/')
    ie.register_namespace('p', 'http://www.viddler.com/author')
    ie.register_namespace('p', 'http://www.viddler.com/author')

# Generated at 2022-06-22 08:05:39.323359
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    mplay = KonserthusetPlayIE()
    mplay.extract()

# Generated at 2022-06-22 08:05:44.551337
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.get_id() == 'CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.get_name() == 'KonserthusetPlay')

# Generated at 2022-06-22 08:05:46.548439
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('www.konserthusetplay.se')

# Generated at 2022-06-22 08:05:48.442692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# test for function _real_extract()

# Generated at 2022-06-22 08:05:49.326969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:55.392957
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
#    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
#    ie = KonserthusetPlayIE()
#    print(ie)
#    exit()
    return True

# Generated at 2022-06-22 08:06:05.933633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Arrange
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(create_ie=True, ie_key='KonserthusetPlay')

    # Act
    result = ie.extract(url=test_url)

    # Assert
    assert result is not None
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['title'] == 'Orkesterns instrument: Valthornen'
    assert result['thumbnail'] is not None
    assert result['duration'] > 0
    