

# Generated at 2022-06-22 07:58:08.784976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:18.493883
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 07:58:22.545542
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    k = KonserthusetPlayIE()
    print(k.extract(url))

# Generated at 2022-06-22 07:58:23.984826
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:58:25.326674
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:27.684298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Add a test function to properly test a custom constructor
    # (that is, a constructor with an argument, see #2503)
    assert True

# Generated at 2022-06-22 07:58:28.725697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:38.368348
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    mp4_url = 'rtmp://csp.picsearch.com/p/fms/eh34SMKvaO4wO_cHBw_01_h264m.mp4'
    # mp4_url = 'https://konserthusetplay.akamaized.net/files/eh34SMKvaO4wO_cHBw/eh34SMKvaO4wO_cHBw_01_h264m.mp4'

    # url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video = KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-22 07:58:44.251393
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Succeeds with good URL
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Fails with bad URL
    assert KonserthusetPlayIE('https://www.konserthusetplay.se/') is None

# Generated at 2022-06-22 07:58:47.179545
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    new_instance = KonserthusetPlayIE()
    assert(hasattr(new_instance, "suitable"))
    assert(hasattr(new_instance, "_real_extract"))
    

# Generated at 2022-06-22 07:59:01.537569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # Test the case when the constructor of KonserthusetPlayIE is called
        # with incorrect arguments
        test_KonserthusetPlayIE = KonserthusetPlayIE("", "")
    except TypeError as e:
        assert e.args[0] == 'Expected url'

# Generated at 2022-06-22 07:59:08.074574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test bring up
    instance = KonserthusetPlayIE()
    # Unit test run
    instance.suite()
    # Unit test tear down
    instance.dispose()

if __name__ == '__main__':
    # Unit test main
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:13.224881
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.ie_key() == 'konserthusetplay'
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 07:59:16.900741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:29.229318
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.module == "konserthusetplay"
    assert ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.VALID_URL == "http?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 07:59:33.371064
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor take one parameter and return a KonserthusetPlayIE object
    test_KonserthusetPlayIE = KonserthusetPlayIE(InfoExtractor)
    assert isinstance(test_KonserthusetPlayIE, KonserthusetPlayIE)

# Generated at 2022-06-22 07:59:37.610448
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("KonserthusetPlayIE", "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 07:59:39.294222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)



# Generated at 2022-06-22 07:59:40.370799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 07:59:43.230228
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if ie.__class__ == KonserthusetPlayIE:
        assert True
    else:
        assert False


# Generated at 2022-06-22 08:00:12.701405
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None, None, None)
    # Test for extracting sub_key for dict access
    dictVal = dict(test={'t': 'test value'})
    assert ie._search_regex(r't=\s*"(.+)"', dictVal['test'], 't') == 'test value'
    # Test for extracting sub_key for list access
    listVal = ['test', 'test2']
    assert ie._search_regex(r'test', listVal[0], flags=0) == 'test'
    # Test for not extracting sub_key for list access
    listVal = ['test', 'test2']
    assert ie._search_regex(r'not', listVal[0], flags=0, default=None) == None
    # Test for extracting sub_key for str access


# Generated at 2022-06-22 08:00:14.298764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie


# Generated at 2022-06-22 08:00:24.600780
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    from ..utils.unittest import TestCase
    from ..utils import compat_urllib_parse
    from ..extractor.common import InfoExtractor
    class MockIE(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': compat_urllib_parse.parse_qs(url)['m'][0],
                'url': url,
            }
    ie = MockIE()

# Generated at 2022-06-22 08:00:27.243788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == "KonserthusetPlayIE"
    assert KonserthusetPlayIE.__doc__ is not None
    assert KonserthusetPlayIE._VERSION is not None


# Generated at 2022-06-22 08:00:31.260109
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('unit test for constructor of class KonserthusetPlayIE')

# Generated at 2022-06-22 08:00:38.130181
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # If a file is given as argument, exit program after testing
    if not sys.argv[1:]:
        print('Usage: python -m unittest %s <url>' % sys.argv[0])
        sys.exit(1)
    video_id = sys.argv[1]
    k = KonserthusetPlayIE()
    info = k._real_extract(video_id)
    print(info)

# Generated at 2022-06-22 08:00:39.179760
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-22 08:00:40.836105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        assert(KonserthusetPlayIE)
        return True
    except NameError:
        print("Failed to create class KonserthusetPlayIE")
        return False


# Generated at 2022-06-22 08:00:42.568140
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:00:43.886773
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj != None


# Generated at 2022-06-22 08:01:47.287539
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:49.206025
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._real_initialize()

# Generated at 2022-06-22 08:01:51.185222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple test for constructor of class KonserthusetPlayIE
    """
    kp = KonserthusetPlayIE()
    assert isinstance(kp, InfoExtractor)

# Generated at 2022-06-22 08:01:54.703082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print('Unit test for KonserthusetPlayIE:', end=' ')
    assert(KonserthusetPlayIE('str'))
    print('ok')

# Generated at 2022-06-22 08:01:56.133429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie  = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-22 08:01:57.628085
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiate the class
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:58.886432
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-22 08:02:01.300308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE()
    assert t._VALID_URL == 'r' + t._VALID_URL

# Generated at 2022-06-22 08:02:12.768569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    webpage = "<html><body><div id='mediaplayer'></div></body></html>"
    e = "ebzw6ddgrVnJqTALhZrpUg"

# Generated at 2022-06-22 08:02:22.921083
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 08:04:28.667919
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None


# Generated at 2022-06-22 08:04:37.055594
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:40.681442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-22 08:04:43.508912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE('KonserthusetPlayIE', None)

# Generated at 2022-06-22 08:04:44.444514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:45.421872
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:46.450888
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-22 08:04:55.919915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-22 08:04:59.678965
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create object KonserthusetPlayIE
    object = KonserthusetPlayIE()
    # Test isinstance
    assert isinstance(object, InfoExtractor)

# Generated at 2022-06-22 08:05:02.344444
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        assert False, "Constructor of class KonserthusetPlayIE depends on parameters"
    else:
        assert True