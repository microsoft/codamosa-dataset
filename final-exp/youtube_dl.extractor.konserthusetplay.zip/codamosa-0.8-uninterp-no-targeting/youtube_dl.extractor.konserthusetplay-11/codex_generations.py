

# Generated at 2022-06-22 07:58:06.565830
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[-1] == {'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', 'only_matching': True}
    assert KonserthusetPlayIE._TESTS[-2]["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-22 07:58:07.497957
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 07:58:10.641543
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:13.872310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

# Generated at 2022-06-22 07:58:19.221789
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:24.359382
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Test with a valid URL
    # Returns an instance of the appropriate class.
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Test with an empty string
    # Returns None as the URL is invalid.
    KonserthusetPlayIE('')

# Generated at 2022-06-22 07:58:29.405959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'KonserthusetPlay.se'

# Generated at 2022-06-22 07:58:34.828105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IEKonserthusetPlay = KonserthusetPlayIE()
    assert IEKonserthusetPlay._download_json
    assert IEKonserthusetPlay._download_webpage
    assert IEKonserthusetPlay._match_id
    assert IEKonserthusetPlay._real_extract
    assert IEKonserthusetPlay._search_regex

# Generated at 2022-06-22 07:58:36.424052
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE('KonserthusetPlay')
    assert class_.ie_key() == 'KonserthusetPlay'
    assert class_.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:39.348595
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	from KonserthusetPlayIE import KonserthusetPlayIE
	
	ie = KonserthusetPlayIE()
	assert isinstance(ie, InfoExtractor)
	assert ie.IE_NAME == 'KonserthusetPlayIE'

# Generated at 2022-06-22 07:58:51.690636
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except TypeError:
        pass
    except Exception as e:
        raise ValueError(str(e))

# Generated at 2022-06-22 07:59:02.307853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:04.340088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:07.335210
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Run tests
# test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:09.810691
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, InfoExtractor)

### Unit tests for the '_real_extract' method of class KonserthusetPlayIE

# Generated at 2022-06-22 07:59:15.136591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.TEST == KonserthusetPlayIE._TESTS

# Generated at 2022-06-22 07:59:27.589242
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert konserthuset_play_ie
    assert konserthuset_play_ie._VALID_URL == "https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 07:59:28.528602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:29.560201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:31.630865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:54.027381
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:57.430856
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-22 08:00:00.598434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # TODO: this should really be a test
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:00:02.259177
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-22 08:00:10.350352
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # KonserthusetPlayIE (KonserthusetPlayInfoExtractor)
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

    # KonserthusetPlayIE (KonserthusetPlayInfoExtractor)
    ie = KonserthusetPlayIE()
    ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-22 08:00:14.456182
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.get_domain()
    ie.get_hostname()
    ie.get_uploader()
    ie.get_uploader_id()
    ie.get_uploader_url()

# Generated at 2022-06-22 08:00:17.922738
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.extract(url)

# Generated at 2022-06-22 08:00:19.376360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    khp_ie = KonserthusetPlayIE()
    assert khp_ie

# Generated at 2022-06-22 08:00:24.989582
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for constructor of class KonserthusetPlayIE with creating an object,
    for testing if this object was created correctly.
    """
    konserthuset_play_ie_object = KonserthusetPlayIE()

    assert isinstance(konserthuset_play_ie_object, InfoExtractor)

# Generated at 2022-06-22 08:00:27.332801
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-22 08:01:16.877376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:18.118044
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE
    assert info_extractor

# Generated at 2022-06-22 08:01:21.263601
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-22 08:01:24.187879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie.extract()

# Generated at 2022-06-22 08:01:26.106583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:33.366019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    # Check if the URL is valid
    assert ie._VALID_URL == ie._real_extract.__func__.__code__.co_varnames[1]
    # Check if the required regex matches the URL
    assert re.match(ie._VALID_URL, url)
    # Check if the specific extractor for the URL works
    assert ie._real_extract(url)

# Generated at 2022-06-22 08:01:35.027841
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-22 08:01:39.931555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie_name = ie.ie_key()
    ie_type = ie.suitable('')
    # Test the ie_name
    assert ie_name == 'KonserthusetPlay'
    # Test the suitable function
    assert ie_type is True

# Generated at 2022-06-22 08:01:40.773079
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:42.218204
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE(0, 0, 0) != None


# Generated at 2022-06-22 08:03:22.217726
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie.extract(url)

# Generated at 2022-06-22 08:03:31.685408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:03:37.626262
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable(ie.IE_NAME, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable(ie.IE_NAME, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable(ie.IE_NAME, 'http://www.konserthusetplay.se/')

# Generated at 2022-06-22 08:03:39.499285
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:03:48.613508
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    This test case checks the constructor of class KonserthusetPlayIE.
    """
    # Here we invoke the constructor of the KonserthusetPlayIE class
    video_ie_kp = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # Now let's check that the object is of the appropriate class
    assert(isinstance(video_ie_kp, KonserthusetPlayIE))


# Generated at 2022-06-22 08:03:49.727091
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:03:51.870959
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor

# Generated at 2022-06-22 08:03:54.427418
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Unit test for constructor of class KonserthusetPlayIE """
    KonserthusetPlayIE(None, None, None)

# Generated at 2022-06-22 08:03:58.886464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == "KonserthusetPlay"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:09.044694
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	ie = KonserthusetPlayIE()
	assert(ie.IE_NAME == "KonserthusetPlay")
	assert(ie.IE_DESC == "Konserthuset Play")
	assert(ie._VALID_URL == r"https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)")
	assert(ie._NETRC_MACHINE == "konserthusetplay")