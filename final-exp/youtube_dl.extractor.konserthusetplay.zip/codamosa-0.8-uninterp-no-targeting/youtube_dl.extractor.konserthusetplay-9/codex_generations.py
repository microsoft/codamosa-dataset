

# Generated at 2022-06-22 07:58:04.089835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    new_ie = KonserthusetPlayIE()
    assert new_ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:05.677151
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:06.570264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:18.060167
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import sys
    import re
    import unittest
    import doctest
    import logging

    class TestFormatter(logging.Formatter):
        def __init__(self, *args, **kwargs):
            super(TestFormatter, self).__init__(*args, **kwargs)
            self.TEST_LOG_REGEX = re.compile(r'-- ([^ ]+)\((.*)\) ([^ ]+):\s(.*)\n')

        def format(self, record):
            header, code, test, msg = self.TEST_LOG_REGEX.fullmatch(record.msg).groups()

            return "-- {} {} {}: {}\n".format(code, header, test, msg)


# Generated at 2022-06-22 07:58:20.184367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Description: test that konserthusetplay class is constructed properly
    """
    KonserthusetPlayIE(None)

# Generated at 2022-06-22 07:58:28.426273
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    m = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    id = 'CKDDnlCY-dhWAAqiMERd-A'

    KonserthusetPlayIE(url, m, id)

# Generated at 2022-06-22 07:58:38.090978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing class KonserthusetPlayIE")
    # Load source code of webpage 
    webpage = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    webpage_source = fetchPage(webpage)
    # Create instance of class KonserthusetPlayIE
    KonserthusetPlayIE = KonserthusetPlayIE()
    # Download webpage using download_webpage method
    downloaded_page = KonserthusetPlayIE._download_webpage(webpage, 'CKDDnlCY-dhWAAqiMERd-A')
    # Check if downloaded page is as expected
    if downloaded_page == webpage_source:
        print("SUCCESS")
    else:
        print("FAILURE")

# Generated at 2022-06-22 07:58:49.668611
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    content = '0x90xE8x03'
    ie = KonserthusetPlayIE()
    assert ie.suitable(url)
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', content, 'e')
    assert e == '0x90xE8x03'

# Generated at 2022-06-22 07:58:53.787333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract(
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 07:59:01.908571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[1] == {
        'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
        'only_matching': True,
    }

# Generated at 2022-06-22 07:59:27.835793
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.get_method_name() == '_real_extract'
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:31.602308
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:34.005442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-22 07:59:36.618646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-22 07:59:37.693583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:49.639798
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # Test constructor with valid url
    url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthusetplay = KonserthusetPlayIE(url = url)

    # Test valid url
    assert konserthusetplay._VALID_URL == r"https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

    # Test valid url
    valid_url = konserthusetplay._match_id(url)
    assert valid_url == "CKDDnlCY-dhWAAqiMERd-A"

    # Test _

# Generated at 2022-06-22 07:59:55.118928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return type("KonserthusetPlayIE", (object,),
                dict(InfoExtractor=KonserthusetPlayIE,
                     _VALID_URL=KonserthusetPlayIE._VALID_URL,
                     _TESTS=KonserthusetPlayIE._TESTS,
                     __file__=__file__))

# Generated at 2022-06-22 08:00:04.150621
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:12.708540
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpIE = KonserthusetPlayIE()
    kpIE = KonserthusetPlayIE({})
    kpIE = KonserthusetPlayIE({'extractor'})
    kpIE = KonserthusetPlayIE(extractor = 'KonserthusetPlay')
    #kpIE_dict = KonserthusetPlayIE({'extractor': 'KonserthusetPlay'})
    #KonserthusetPlayIE(kpIE_dict)


# Generated at 2022-06-22 08:00:17.579853
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  info_extractor = KonserthusetPlayIE()
  assert info_extractor._VALID_URL is not None, "_VALID_URL is not set for class KonserthusetPlayIE"
  assert info_extractor._TESTS is not None, "_TESTS is not set for class KonserthusetPlayIE"

# Generated at 2022-06-22 08:00:45.523453
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == "KonserthusetPlay"
    assert ie.ie_name() == "KonserthusetPlay"

# Generated at 2022-06-22 08:00:51.682787
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == url
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-22 08:00:52.852767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj



# Generated at 2022-06-22 08:00:54.654404
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-22 08:01:01.834531
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Constructor of class KonserthusetPlayIE: Input: valid URL
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'


# Generated at 2022-06-22 08:01:04.527639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)

# Generated at 2022-06-22 08:01:07.044151
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-22 08:01:09.229694
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-22 08:01:12.908666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:17.353184
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    string = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    konserthusetPlayIE._real_extract(string)

# Generated at 2022-06-22 08:02:09.798803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extract('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:02:12.529031
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        print("Constructor of class KonserthusetPlayIE not working properly.")

# Generated at 2022-06-22 08:02:22.708847
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()
    assert x._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:23.834768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 08:02:25.998640
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie


# Unit test to check if KonserthusetPlayIE is compliant with its test cases

# Generated at 2022-06-22 08:02:27.950255
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-22 08:02:33.599149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:02:42.489705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:02:44.310574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# Create object
	konserthusetPlayIE = KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:47.394619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	try:
		konserthuset_play_ie = KonserthusetPlayIE()
	except:
		print("Test failed")


# Generated at 2022-06-22 08:04:57.777586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    ie = KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw", "http://csp.picsearch.com/rest?e=.&containerId=mediaplayer&i=object")

# Generated at 2022-06-22 08:05:04.005857
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0]['url'] == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE._TESTS[0]['md5'] == KonserthusetPlayIE._TESTS[0]['info_dict']['md5']
    assert KonserthusetPlayIE._TESTS[0]['url'] == KonserthusetPlayIE._TESTS[0]['info_dict']['url']

# Generated at 2022-06-22 08:05:14.699700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    k = KonserthusetPlayIE(url)
    assert k._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:05:16.021461
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:17.748541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:20.492336
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS



# Generated at 2022-06-22 08:05:21.260574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-22 08:05:23.006642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-22 08:05:26.715753
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ unittest for constructor of the class KonserthusetPlayIE """
    ie = KonserthusetPlayIE()
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert not ie.suitable("http://www.youtube.com/watch?v=BaW_jenozKc")

# Generated at 2022-06-22 08:05:28.124593
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, None)