

# Generated at 2022-06-22 07:57:58.527282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 07:58:08.498940
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie != None
    assert ie.get_info('ext') == 'mp4'
    assert ie.get_info('id') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.get_info('title') == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 07:58:14.139452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.ie_key() == 'KonserthusetPlay')
    assert(ie.ie_name() == 'konserthusetplay.se / rspoplay.se')

# Generated at 2022-06-22 07:58:18.587015
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .youtube import YoutubeIE
    assert KonserthusetPlayIE().ie_key() == 'KonserthusetPlay'
    assert YoutubeIE().ie_key() == 'Youtube'

# Generated at 2022-06-22 07:58:21.655803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj.id, 'CKDDnlCY-dhWAAqiMERd-A'
    assert obj.ext, 'mp4'

# Generated at 2022-06-22 07:58:24.039961
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-22 07:58:26.307931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.ipv6_enabled == False
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:28.614165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert (KonserthusetPlayIE)

# Generated at 2022-06-22 07:58:30.387194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   ie = KonserthusetPlayIE()
   ie.extract(ie._TESTS[0]['url'])

# Generated at 2022-06-22 07:58:40.651330
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:55.361388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-22 07:58:59.689753
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Check it can make the id by itself
    assert ie._match_id(ie._VALID_URL) == 'CKDDnlCY-dhWAAqiMERd-A'

# Unit test to test the constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 07:59:04.694296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if not KonserthusetPlayIE.working():
        pytest.skip('cannot download video')
    test = KonserthusetPlayIE()._real_extract(
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert 'description' in test
    assert 'title' in test
    assert 'duration' in test
    assert 'video' in test

# Generated at 2022-06-22 07:59:07.481441
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print(repr(KonserthusetPlayIE()))
    print(str(KonserthusetPlayIE()))

# Generated at 2022-06-22 07:59:10.896315
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-22 07:59:13.686183
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	info_extractor = KonserthusetPlayIE()
	try:
		info_extractor.extract(None)
	except:
		pass

# Generated at 2022-06-22 07:59:16.178256
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # instantiate class KonserthusetPlayIE
    KonserthusetPlayIE()


# Generated at 2022-06-22 07:59:20.560930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	""" Unit test for constructor of class KonserthusetPlayIE """
	KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:24.724689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:59:34.870976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    title = 'Orkesterns instrument: Valthornen'
    description = 'md5:f10e1f0030202020396a4d712d2fa827'
    duration = 398.76
    thumbnail = 're:^https?://.*$'
    format_id = 'CKDDnlCY-dhWAAqiMERd-A'

    extractor = KonserthusetPlayIE()
    res = extractor.extract(url)

    assert res.get('id') == format_id
    assert res.get('title') == title
    assert res.get('description') == description
    assert res.get('duration') == duration

# Generated at 2022-06-22 07:59:58.096047
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
#     ie.real_extract(ie.video_id)

# Generated at 2022-06-22 07:59:59.333903
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE, type)

# Generated at 2022-06-22 08:00:07.562624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that correct name was inserted
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'https://www.konserthusetplay.se/?m=' + video_id
    assert KonserthusetPlayIE._match_id(url) == video_id 
    # Check that false url returns a None object
    assert KonserthusetPlayIE._match_id(url[:-2]) is None
    # Check that constructor extracts info correctly
    konser_play = KonserthusetPlayIE(url)
    assert konser_play
    info = konser_play._real_extract(url)
    assert info['id'] == video_id
    assert info['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:00:09.545682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(_VALID_URL, _TESTS)
    assert obj


# Generated at 2022-06-22 08:00:20.048402
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not KonserthusetPlayIE.suitable('http://www.rspoplay.se/')
    assert not KonserthusetPlayIE.suitable('http://www.konserthusetplay.se/')
    assert not KonserthusetPlayIE.suitable('https://www.konserthusetplay.se/')

# Generated at 2022-06-22 08:00:22.521579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:00:23.851710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:24.673013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:28.980750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.server_url == 'https://www.konserthusetplay.se'
    assert ie.logo_url == 'http://www.konserthusetplay.se/images/logo.png'

# Generated at 2022-06-22 08:00:30.468522
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instantiation with a KonserthusetPlayIE.
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:35.483851
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:38.719257
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that the constructor of KonserthusetPlayIE doesn't raise an error
    # when provided with a valid URL.
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-22 08:01:44.008116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert(test._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-22 08:01:50.877401
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    v = KonserthusetPlayIE()
    assert v._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:54.027102
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL, KonserthusetPlayIE._TESTS)



# Generated at 2022-06-22 08:02:02.340638
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test constructor of class KonserthusetPlayIE.
    """
    instance = KonserthusetPlayIE('konserthusetplay', 'http')

    assert instance.ie_key() == 'konserthusetplay'
    assert instance.ie_url() == 'http://www.konserthusetplay.se/'
    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 08:02:05.851971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    # Asserts that inst is not None
    assert inst is not None



# Generated at 2022-06-22 08:02:08.387976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    m = KonserthusetPlayIE()

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:11.274905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    fixture = KonserthusetPlayIE()
    assert fixture.IE_NAME == 'konserthusetplay'
    assert fixture.IE_DESC == 'KonserthusetPlay'


# Generated at 2022-06-22 08:02:12.205849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:17.411337
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL

# Generated at 2022-06-22 08:04:25.018705
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=wOpq1q0FOJqzahk-8Ky7Vg'
    obj = KonserthusetPlayIE(url)
    assert str(type(obj)) == "<class 'youtube_dl.extractor.konserthuset.KonserthusetPlayIE'>"
    assert obj.url == url
    assert obj.media_id == 'wOpq1q0FOJqzahk-8Ky7Vg'

# Generated at 2022-06-22 08:04:31.379953
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    html = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url = ie._real_extract(html)
    assert 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A' == url.get('id')

# Generated at 2022-06-22 08:04:34.263138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:40.547714
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:04:50.301119
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    videoIE = KonserthusetPlayIE()
    # Testing the method _real_extract
    # Testing the format of the video 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    result = videoIE._real_extract(url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Validating the existence of the fields in the returned dictionary
    assert result.has_key('formats')
    assert result.has_key('subtitles')
    assert result.has_key('title')
    assert result.has_key('description')
    assert result.has_key('thumbnail')
    assert result.has_key('duration')

# Generated at 2022-06-22 08:04:53.650925
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert isinstance(k, KonserthusetPlayIE)


# Generated at 2022-06-22 08:04:59.870603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    import youtube_dl.extractor.konserthusetplay as konserthusetplay_ie
    ie = konserthusetplay_ie

    video_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-22 08:05:03.511542
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(url=url)
    assert ie._real_extract(url=url)

# Generated at 2022-06-22 08:05:14.377230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(None) is False
    assert ie.extract_id(None) is None
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.extract_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')