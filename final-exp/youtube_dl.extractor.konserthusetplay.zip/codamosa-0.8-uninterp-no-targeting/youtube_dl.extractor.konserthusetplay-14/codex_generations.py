

# Generated at 2022-06-22 07:58:02.859962
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.name == 'konserthusetplay' or ie.name == 'rspoplay')

# Generated at 2022-06-22 07:58:05.165473
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("url", "id")

# Generated at 2022-06-22 07:58:09.152109
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert ('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', {}) == KonserthusetPlayIE._build_url_result(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 07:58:13.124892
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        instance = KonserthusetPlayIE("url")
        if(isinstance(instance, InfoExtractor)):
            print("instance of KonserthusetPlayIE created")
    except Exception:
        print("failed to instanciate KonserthusetPlayIE")


# Generated at 2022-06-22 07:58:18.152194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-22 07:58:21.200898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Tests that KonserthusetPlayIE has the correct ID
    assert KonserthusetPlayIE.ie_key() == 'konserthusetplay'

# Generated at 2022-06-22 07:58:22.369645
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test(KonserthusetPlayIE)

# Generated at 2022-06-22 07:58:24.952538
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE();
    assert obj.get_domain() == 'rspoplay.se';

# Generated at 2022-06-22 07:58:32.892779
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test two cases:
    #
    # 1. Video URL starting with 'www'
    # 2. Video URL starting with 'rspoplay'
    test_url1 = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_url2 = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    ie.match_entry(test_url1)
    ie.match_entry(test_url2)

# Generated at 2022-06-22 07:58:41.981980
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    obj._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    obj._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    obj._match_id('http://www.rspoplay.se/?m=T166aHR0cHMlM0ElMkYlMkZ3d3cucmVzcG9wbGF5LnNlJTJGJTJGJTNGbSUzRA%3D%3D')

# Generated at 2022-06-22 07:59:07.556429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import inspect
    import os
    import unittest2

    def _create_test(input_string, method):
        def _test(self):
            self.assertTrue(method(input_string),
                            "Failed to parse input '%s'" % input_string)

        return _test

    KIE = KonserthusetPlayIE

    class _Tester(unittest2.TestCase):
        pass

    for name, method in inspect.getmembers(KIE):
        if name.startswith('_VALID_URL'):
            _Tester.addTest(_Tester(
                'test_' + name.strip('_VALID_URL'),
                _create_test(name, method)))

    runner = unittest2.TextTestRunner()
    runner.run(_Tester())



# Generated at 2022-06-22 07:59:11.863971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor._match_id('https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 07:59:16.386117
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:17.444036
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True # TODO: implement your test here

# Generated at 2022-06-22 07:59:22.635718
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-22 07:59:33.307748
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for class KonserthusetPlayIE"""
    assert KonserthusetPlayIE == KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != KonserthusetPlayIE()
    assert KonserthusetPlayIE != Konser

# Generated at 2022-06-22 07:59:43.272572
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # test for _VALID_URL
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable('http://www.konserthusetplay.se')
    # test for _TESTS
    assert 'Orkesterns instrument: Valthornen' == ie._TESTS[0]['info_dict']['title']

# Generated at 2022-06-22 07:59:44.552056
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor
    assert KonserthusetPlayIE

# Generated at 2022-06-22 07:59:45.722309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:51.376623
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://www.rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


# Generated at 2022-06-22 08:00:13.387343
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test of KonserthusetPlayIE.__init__
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:18.783582
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-22 08:00:20.715923
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert isinstance(obj, KonserthusetPlayIE)

# Generated at 2022-06-22 08:00:22.331137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:23.675709
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:00:25.902810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE.
    """
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:00:31.680964
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:37.148880
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie != None)
    assert callable(ie.__call__)
    assert(ie.IE_NAME != None)
    assert(ie.IE_NAME == 'konserthusetplay')
    assert(ie.IE_DESC != None)
    assert(ie.VERSION != None)

# Generated at 2022-06-22 08:00:48.629283
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:00:52.359626
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'konserthusetplay'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 08:01:43.071059
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:44.843790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE(None)
    assert obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:01:45.945019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE

# Generated at 2022-06-22 08:01:47.863150
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:01:55.071480
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:56.619466
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    return

# Generated at 2022-06-22 08:01:58.739376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL is not None


# Generated at 2022-06-22 08:02:03.512605
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    v_id = 'CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:09.794216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = url_of_some_KonserthusetPlayIE
    ie = KonserthusetPlayIE(url)
    assert ie.url == url
    assert ie.video_id == id_of_some_KonserthusetPlayIE
    assert ie._VALID_URL == regex_of_some_KonserthusetPlayIE
    assert ie._TESTS[0]['url'] == url
    assert ie._TESTS[0]['md5'] == md5_of_some_KonserthusetPlayIE
    assert ie._TESTS[1]['url'] == url
    assert ie._TESTS[1]['only_matching'] == True


# Generated at 2022-06-22 08:02:12.519817
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    if __name__ == "__main__":
        print("Constructor class")
        print("Constructor")
        ksp_IE = KonserthusetPlayIE()
        print("Constructor ends")

# Generated at 2022-06-22 08:04:16.908687
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:21.242977
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._TESTS[0]['md5'] == obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['md5']

# Generated at 2022-06-22 08:04:32.469472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:38.813576
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthusetplay_ie = KonserthusetPlayIE()
    konserthusetplay_ie.match(url)
    konserthusetplay_ie.extract(url)


# Generated at 2022-06-22 08:04:44.165698
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .KonserthusetPlayIE import KonserthusetPlayIE
    kp = KonserthusetPlayIE(object)
    assert kp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:04:46.318003
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(KonserthusetPlayIE._downloader, KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-22 08:04:48.472591
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-22 08:04:54.797634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
	assert KonserthusetPlayIE(url).url == url and KonserthusetPlayIE(url).url == KonserthusetPlayIE(url).url

# Generated at 2022-06-22 08:04:59.193603
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == "konserthusetplay"
    assert ie.IE_DESC == "Konserthusetplay.se"
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie._TESTS[0]['md5'] == "e3fd47bf44e864bd23c08e487abe1967"

# Generated at 2022-06-22 08:05:05.410039
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    assert 'http://www.konserthusetplay.se' in extractor.IE_DESC
    assert 'KonserthusetPlay' in extractor.IE_DESC
    assert extractor._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'