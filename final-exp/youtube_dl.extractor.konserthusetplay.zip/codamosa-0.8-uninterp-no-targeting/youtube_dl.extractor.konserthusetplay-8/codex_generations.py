

# Generated at 2022-06-22 07:58:05.767351
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('konserthusetplay')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-22 07:58:08.074397
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  instance = KonserthusetPlayIE()

  # Tests that the instance is correct
  assert instance.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-22 07:58:09.602606
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """

    # Run main test
    main()

# Generated at 2022-06-22 07:58:20.247766
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("test")

    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:23.622878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test: Constructor of class KonserthusetPlayIE
    obj_konserthusetplay_ie = KonserthusetPlayIE()
    assert obj_konserthusetplay_ie


# Generated at 2022-06-22 07:58:35.578199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_name() == 'KonserthusetPlay'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:58:42.740038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    obj2 = KonserthusetPlayIE()
    assert obj2._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 07:58:51.069245
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._TESTS[0]['info_dict'] == {'id': 'CKDDnlCY-dhWAAqiMERd-A',
                                         'ext': 'mp4',
                                         'title': 'Orkesterns instrument: Valthornen',
                                         'description': 'md5:f10e1f0030202020396a4d712d2fa827',
                                         'thumbnail': 're:^https?://.*$',
                                         'duration': 398.76}


# Generated at 2022-06-22 07:59:01.856865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE("_VALID_URL", "_VALID_URL")
    # Call the constructor of InfoExtractor
    infoExtractor = InfoExtractor("_VALID_URL", "_VALID_URL")
    # Compare values of instance variables of two instances
    assert konserthusetPlayIE.report_downloads == infoExtractor.report_downloads
    assert konserthusetPlayIE.age_limit == infoExtractor.age_limit
    assert konserthusetPlayIE.params == infoExtractor.params
    assert konserthusetPlayIE.js_to_json == infoExtractor.js_to_json
    assert konserthusetPlayIE.extractor_key == infoExtractor.extractor_key
    assert konserthusetPlayIE.suitable

# Generated at 2022-06-22 07:59:06.906901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an object of the class KonserthusetPlayIE
    KonserthusetPlayIE_object = KonserthusetPlayIE()
    # Make sure that the object has been created
    assert KonserthusetPlayIE_object

# Generated at 2022-06-22 07:59:31.672700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert(instance is not None)

# Generated at 2022-06-22 07:59:34.961236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k is not None

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 07:59:37.064294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie != None

# Generated at 2022-06-22 07:59:49.025652
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 07:59:52.552291
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if the constructor works, which is a prerequisite for every test to run
    yt1 = KonserthusetPlayIE()
    # Make sure there are no errors
    assert yt1 != None



# Generated at 2022-06-22 07:59:56.455507
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ext = KonserthusetPlayIE()
    ext.extract(url)

# Generated at 2022-06-22 08:00:06.064430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
        Purpose: This unit test is designed to check whether the constructor of
                 class KonserthusetPlayIE manages to parse an url correctly.
        Input  : http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
        Output : 1 if the Parser is able to parse the url correctly, else -1.
    """
    
    konserthusetplay = KonserthusetPlayIE()
    
    # Should return 1 if the Parser is able to parse the url correctly
    assert konserthusetplay._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")['id'] == "CKDDnlCY-dhWAAqiMERd-A"


# Generated at 2022-06-22 08:00:11.961408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    UnitTest(
        module="konserthuset_play",
        name="KonserthusetPlayIE.init",
        function="__init__",
        expected=[{'expected': 'konserthuset_play.py', 'actual': 'konserthuset_play.py'}]
    ).run()

# Generated at 2022-06-22 08:00:17.274887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    return ie

# Generated at 2022-06-22 08:00:18.656003
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import KonserthusetPlayIE
    assert KonserthusetPlayIE

# Generated at 2022-06-22 08:00:57.717082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Dictionary with information to assert
    unit_test = {
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'info_dict': {
            'id': 'CKDDnlCY-dhWAAqiMERd-A',
            'ext': 'mp4',
            'title': 'Orkesterns instrument: Valthornen',
            'description': 'md5:f10e1f0030202020396a4d712d2fa827',
            'thumbnail': 're:^https?://.*$',
            'duration': 398.76,
        },
    }
    # Create and assert KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    result = ie._

# Generated at 2022-06-22 08:01:00.275485
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-22 08:01:02.027014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-22 08:01:02.957846
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
     KonserthusetPlayIE(None, None)

# Generated at 2022-06-22 08:01:06.112700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.NAME == 'konserthusetplay'



# Generated at 2022-06-22 08:01:17.700473
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-22 08:01:22.732341
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")


# Generated at 2022-06-22 08:01:26.185368
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-22 08:01:35.881515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(ie)
    assert ie._match_id('https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)') == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:01:37.081960
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    yt = KonserthusetPlayIE()
    assert yt is not None

# Generated at 2022-06-22 08:02:26.612509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-22 08:02:29.389487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiate the class
    KonserthusetPlayIE()

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:32.695599
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test that class constructor can be called with 'KonserthusetPlayIE'
    """
    KonserthusetPlayIE(extractor='test_extractor')

# Generated at 2022-06-22 08:02:36.357114
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.ie_description() == 'KonserthusetPlay'

# Generated at 2022-06-22 08:02:39.291502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case = KonserthusetPlayIE(None)
    assert u'konserthusetplay' in test_case._VALID_URL
    assert u'rspoplay' in test_case._VALID_URL

# Generated at 2022-06-22 08:02:40.817727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert True

# Generated at 2022-06-22 08:02:45.670845
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	""" Unit test for testing constructor of class KonserthusetPlayIE """
	assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 08:02:46.780140
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:02:49.798566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    # test the constructor
    assert isinstance(k, KonserthusetPlayIE)


# Generated at 2022-06-22 08:02:59.553820
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import unittest
    from .common import KonserthusetPlayIE

    class TestKonserthusetPlayIE(unittest.TestCase):
        def setUp(self):
            self.config = {
                'info_dict': {
                    'id': 'CKDDnlCY-dhWAAqiMERd-A',
                    'ext': 'mp4',
                    'title': 'Orkesterns instrument: Valthornen',
                    'description': 'md5:f10e1f0030202020396a4d712d2fa827',
                    'thumbnail': 're:^https?://.*$',
                    'duration': 398.76,
                },
            }
            self.unit_test_obj = KonserthusetPlayIE()


# Generated at 2022-06-22 08:05:13.939298
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	y = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
	assert y.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
	assert y._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-22 08:05:22.343548
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.suitable(url) == True
    assert ie.extract(url)['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.extract(url)['duration'] == 398.76
    assert ie.extract(url)['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-22 08:05:34.311170
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert str(ie) == '<KonserthusetPlayIE: http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A>'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:05:37.069803
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-22 08:05:41.932507
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE = KonserthusetPlayIE()
    print(konserthusetplayIE)
    assert konserthusetplayIE.__class__.__name__ == 'KonserthusetPlayIE'
    print(KonserthusetPlayIE._TESTS)

# Generated at 2022-06-22 08:05:50.851267
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Simple unit test for KonserthusetPlayIE."""
    test_cases = [
        {
            'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
            'info_dict': {
                'id': 'CKDDnlCY-dhWAAqiMERd-A',
                'ext': 'mp4',
                'title': 'Orkesterns instrument: Valthornen',
                'description': 'md5:f10e1f0030202020396a4d712d2fa827',
                'thumbnail': 're:^https?://.*$',
                'duration': 398.76,
            }
        },
    ]
    ie = KonserthusetPlayIE()

# Generated at 2022-06-22 08:05:52.722971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-22 08:06:05.020372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
#   Testing for valid URL and returns the KonserthusetPlayIE object
    test_object = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert test_object._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert test_object._TESTS[0]['url'] == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-22 08:06:09.164656
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', True)
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.debug == True

# Generated at 2022-06-22 08:06:10.894750
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None)._VALID_URL == KonserthusetPlayIE._VALID_URL