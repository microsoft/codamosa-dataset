

# Generated at 2022-06-12 17:46:17.346526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
# #Unit test for _real_extract of class KonserthusetPlayIE
# def test_real_extract():
#     KonserthusetPlayIE("_real_extract", "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
# #Unit test for _real_extract of class KonserthusetPlayIE
# def test_real_extract2():
#     KonserthusetPlayIE("_real_extract", "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:46:18.233029
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:19.161908
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-12 17:46:31.085516
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:36.701247
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.IE_DESC == 'konserthusetplay.se'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:40.356354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert i._TESTS[0]['url'] == 'http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:46:48.879141
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'Konserthuset Play'
    assert ie.description == 'Konserthuset Plays klassiska musikvideor'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay:play'

# Generated at 2022-06-12 17:46:52.522403
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_uri = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.extract(test_uri)


# Generated at 2022-06-12 17:47:02.685169
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayIE_object = KonserthusetPlayIE("")
    assert konserthusetplayIE_object._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:03.664179
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-12 17:47:25.103387
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()



# Generated at 2022-06-12 17:47:31.356317
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # Test case with string
        url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
        KonserthusetPlayIE(url)
        assert 1 == 1

    except AssertionError:
        assert 1 == 0
    try:
        #Test case with string
        url = ""
        KonserthusetPlayIE(url)
        assert 1 == 1

    except AssertionError:
        assert 1 == 0  # To indicate this test failed
    try:
        #Test case with string
        url = 1
        KonserthusetPlayIE(url)
        assert 1 == 1

    except AssertionError:
        assert 1 == 0


# Generated at 2022-06-12 17:47:32.077088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("RegexTest")

# Generated at 2022-06-12 17:47:32.689128
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:47:41.484454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie_obj = KonserthusetPlayIE()
    assert konserthuset_play_ie_obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:50.619072
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing konserthusetplay.se video with an RTMP URL
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    k = KonserthusetPlayIE()
    assert k.suitable(url)
    assert k.IE_NAME[0] == "konserthusetplay.se"
    assert k.IE_NAME[1] == "rspoplay.se"
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:57.849464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:04.063684
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_key() != 'konserthusetplay_test'
    #assert ie.host() == 'www.konserthusetplay.se'
    #assert ie.host() != ''
    assert ie.name() == 'konserthusetplay'
    assert ie.name() != ''

# Generated at 2022-06-12 17:48:08.212875
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test constructor of class KonserthusetPlayIE."""
    # Test with valid URL
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert isinstance(ie, InfoExtractor)
    # Test with invalid URL
    ie = KonserthusetPlayIE('http://example.com/')
    assert ie is None

# Generated at 2022-06-12 17:48:10.845282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None


# Generated at 2022-06-12 17:48:35.071439
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    result = ie.suitable('https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert (result == True), "constructor does not seems to be working as expected"


# Generated at 2022-06-12 17:48:36.851219
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    assert ie.IE_NAME == 'konserthusetplay'



# Generated at 2022-06-12 17:48:41.855682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'KonserthusetPlay'
    assert ie.suitable(ie.IE_NAME, 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.suitable(ie.IE_NAME, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert not ie.suitable(ie.IE_NAME, 'http://www.konserthusetplay.se/')

# Generated at 2022-06-12 17:48:43.077138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-12 17:48:52.354788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_template import assert_template_ok
    from .konserthusetplay import KonserthusetPlayIE
    # Initialize the test instance
    inst = KonserthusetPlayIE(None)
    # Make sure the object is initialized
    assert (inst is not None)
    # Make sure the object is of the right type
    assert(isinstance(inst, KonserthusetPlayIE))
    # Run the test
    assert_template_ok('konserthusetplay')

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:52.823722
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:59.754671
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:06.202190
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-12 17:49:07.208730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(object())

# Generated at 2022-06-12 17:49:09.086013
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None, None, None)

# Generated at 2022-06-12 17:49:51.730370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # No exception thrown if we instantiate this class
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:53.779757
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    check_KonserthusetPlayIE = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    return check_KonserthusetPlayIE

# Generated at 2022-06-12 17:49:58.607095
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    K = KonserthusetPlayIE(None)
    assert K._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)', 'url'

# Generated at 2022-06-12 17:50:02.560731
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with a URL that has not yet been implemented
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE(url)


# Generated at 2022-06-12 17:50:05.781829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    class_ = KonserthusetPlayIE(url)
    assert class_


# Generated at 2022-06-12 17:50:08.533969
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert konserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:50:17.452482
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test URL
    # test if the method _match_id gets the video id from the URL given
    assert ie._match_id(ie._TESTS[0]['url']) == ie._TESTS[0]['info_dict']['id']

    # Test connection URL
    # test if the method _real_extract gets the connection url from the JSON file
    # and if it matches the one given
    # this test also test the URL argument given to the method _download_json

# Generated at 2022-06-12 17:50:20.996185
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert KonserthusetPlayIE()._TESTS == KonserthusetPlayIE._TESTS

# Generated at 2022-06-12 17:50:22.058172
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:28.151677
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    # assert class attribute KonserthusetPlayIE._VALID_URL matches url
    assert instance._VALID_URL.match('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') != None
    assert instance._VALID_URL.match('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') != None

# Generated at 2022-06-12 17:52:32.894802
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = ie._match_id(url)

    webpage = ie._download_webpage(url, video_id)

    e = ie._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage, 'e')


# Generated at 2022-06-12 17:52:33.932283
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:35.308416
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(InfoExtractor)

# Generated at 2022-06-12 17:52:36.525330
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()


# Generated at 2022-06-12 17:52:38.433297
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert isinstance(info_extractor, KonserthusetPlayIE)

# Generated at 2022-06-12 17:52:44.445831
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj.IE_NAME == 'KonserthusetPlay'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:45.255552
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:52.297610
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unsupported webpage
    webpage_bad = 'http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE()
    assert ie._extract_urls(webpage_bad) == [], \
        'Failure to detect unsupported webpage'

    # Supported webpage with a video
    webpage = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:01.236672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test 1
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Expected result: KonserthusetPlayIE
    infoExtractor = KonserthusetPlayIE()
    assert(type(infoExtractor) == KonserthusetPlayIE)
    # Test 2
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    # Expected result: KonserthusetPlayIE
    infoExtractor = KonserthusetPlayIE()
    assert(type(infoExtractor) == KonserthusetPlayIE)

# Generated at 2022-06-12 17:53:08.924650
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing some URLs from http://www.konserthusetplay.se/
    KonserthusetPlayIE(InfoExtractor).working = True
    assert KonserthusetPlayIE.working
    #these are all different URLs to the same video
    test_KonserthusetPlayIE.video_ids = ("uV7SXoFcXV90AAui4204",
                                         "4iH-51V6U1cAAbikBTsB",
                                         "CKDDnlCY-dhWAAqiMERd-A")
    assert all(KonserthusetPlayIE.suitable(i) for i in test_KonserthusetPlayIE.video_ids)