

# Generated at 2022-06-12 17:46:08.672322
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()     # Create object of the class
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:14.824724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # instantiate class and set global variable
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:18.414070
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, KonserthusetPlayIE)


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:30.740374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-12 17:46:32.178179
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL



# Generated at 2022-06-12 17:46:34.672087
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .konserthusetplay import KonserthusetPlayIE
    ie = KonserthusetPlayIE(0)
    assert ie.name == 'konserthusetplay'
    assert ie.ie_key() == 'konserthusetplay'



# Generated at 2022-06-12 17:46:38.739671
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:43.964423
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == "konserthusetplay"
    assert ie.title == "Orkesterns instrument: Valthornen"
    assert ie.duration == 398.76

# Generated at 2022-06-12 17:46:44.399366
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:51.972710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for video that might throw exception
    # https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw
    url = 'https://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    obj = KonserthusetPlayIE()
    result = obj.url_result(url)
    obj.extract(result.url)
    assert(result.id == 'elWuEH34SMKvaO4wO_cHBw')
    assert(result.title == 'Den svenska kammarorkestern spelar Mozarts sista symfoni')

# Generated at 2022-06-12 17:47:12.572622
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    script = '''<script>
        var s = document.location.search;
        var qs = new Object();
        if (s != "") {
            var re = /[?|&]([^=]+)(?:=([^&]*))?/g;
            while (m = re.exec(s))
            qs[decodeURIComponent(m[1])] = decodeURIComponent(m[2]);
        }
        window.location.replace("http://konserthusetplay.se/?m=" + qs.m);
    </script>'''
    parser = KonserthusetPlayIE()
    res = parser.extract(script)
    print(res)

# Generated at 2022-06-12 17:47:15.970985
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_test = KonserthusetPlayIE()
    assert ie_test

# Generated at 2022-06-12 17:47:25.020442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.is_suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    changes = {'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'}
    ie.extract(changes)
    assert changes['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:27.789199
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video = KonserthusetPlayIE()
    video._real_extract('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
# End of unit test

# Generated at 2022-06-12 17:47:32.068902
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = (KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"))
    ie.download("")

# Generated at 2022-06-12 17:47:36.838828
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:47:47.845279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:49.207116
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:47:52.776743
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_name = KonserthusetPlayIE.__name__
    instance_of_class = KonserthusetPlayIE()
    assert class_name == "KonserthusetPlayIE"
    assert isinstance(instance_of_class, KonserthusetPlayIE)

# Generated at 2022-06-12 17:47:56.266752
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:28.056986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing KonserthusetPlayIE")
    video = KonserthusetPlayIE()
    video._download_webpage("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A","CKDDnlCY-dhWAAqiMERd-A")
    video._download_json("","CKDDnlCY-dhWAAqiMERd-A")
    video._real_extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A","CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:48:28.574453
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:30.692498
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    obj = KonserthusetPlayIE('KonserthusetPlayIE')
    assert isinstance(obj, KonserthusetPlayIE)

# Generated at 2022-06-12 17:48:31.731862
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:48:35.378265
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_class = KonserthusetPlayIE
    test_class.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')



# Generated at 2022-06-12 17:48:41.922579
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    extractor = KonserthusetPlayIE()
    video_url = extractor.extract(test_url)
    assert video_url['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert video_url['title'] == 'Orkesterns instrument: Valthornen'
    assert video_url['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert video_url['thumbnail'] == 're:^https?://.*$'
    assert video_url['duration'] == 398.76

# Generated at 2022-06-12 17:48:53.584227
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    konserthusetplayIEInstance = KonserthusetPlayIE()

    # check
    assert konserthusetplayIEInstance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:57.008496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    x = KonserthusetPlayIE()
    assert x.IE_NAME == 'konserthusetplay'


# Generated at 2022-06-12 17:49:01.791777
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert(ie.url == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# extracts information from the KonserthusetPlayIE object

# Generated at 2022-06-12 17:49:04.182831
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE('test')
    assert(IE.name == 'KonserthusetPlay')
    assert(IE.ie_key() == 'KonserthusetPlay')

# Generated at 2022-06-12 17:49:47.758929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:48.588813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:53.096415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance.info_urls == {'konserthusetplay': 'www.konserthusetplay.se', 'rspoplay': 'rspoplay.se'}
    assert instance.playlist_mincount == 1
    assert instance.playlist_result_fetcher == instance._playlist_result_fetcher
    assert instance.ie_key() == 'KonserthusetPlay'
    assert instance.video_id == 'id'


# Generated at 2022-06-12 17:49:57.691529
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:50:05.633130
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the URL is regular and uses the constructor correctly
    video_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE()._match_id(video_url) is not None
    # Test that the URL fails if no match is found
    video_url = "http://www.konserthusetplay.se/?m=cpe94j3209"
    assert KonserthusetPlayIE()._match_id(video_url) is None


# Generated at 2022-06-12 17:50:09.093100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test the constructor of class KonserthusetPlayIE"""
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:50:18.044294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:50:19.876513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.KonserthusetPlayIE() == KonserthusetPlayIE

# Generated at 2022-06-12 17:50:29.902751
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    result = instance._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # check id
    expected_result = 'CKDDnlCY-dhWAAqiMERd-A'
    assert result['id'] == expected_result

    # check url
    expected_result = 'http://rtmp.konserthuset.se/vod/mp4:konserthuset_20150716_01c_Orkesterns_instrument_Valthornen.mp4'
    assert result['formats'][0]['url'] == expected_result

    # check format_id
    expected_result = 'rtmp-high'

# Generated at 2022-06-12 17:50:31.197053
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None


# Generated at 2022-06-12 17:52:43.103078
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Parse video_url and instantiate class
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)

    # Extract video fields
    video = ie._real_extract(ie._VALID_URL)

    # Test video id, url, title and description
    assert(video['id'] == 'CKDDnlCY-dhWAAqiMERd-A')
    assert(video['title'] == 'Orkesterns instrument: Valthornen')

# Generated at 2022-06-12 17:52:44.455697
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # we get a subclass of InfoExtractor instead of InfoExtractor
    asser

# Generated at 2022-06-12 17:52:51.691586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	print("Unit test for constructor of class KonserthusetPlayIE")
	# Test for case where the string in invalid
	url = "invalidURL.se"
	expected_return = ""
	IE = KonserthusetPlayIE()
	assert expected_return == IE._match_id(url), "Incorrect url return."

	# Test for case where the string is an empty string
	url = ""
	expected_return = ""
	IE = KonserthusetPlayIE()
	assert expected_return == IE._match_id(url), "Incorrect url return."

	# Test for case where the string is a valid string
	url = "https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-12 17:52:52.377215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:52:57.774566
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_DESC == 'KonserthusetPlay and RSPOPlay streams for Swedish Concert Hall and Stockholm Philharmonic Orchestra'

# Generated at 2022-06-12 17:53:03.680148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.url = url
    webpage = ie._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')
    # this should fail without a valid match
    match = ie._match_id(url)
    assert match == None

# Generated at 2022-06-12 17:53:08.233104
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    object_KonserthusetPlayIE = KonserthusetPlayIE()
    match_id_result = object_KonserthusetPlayIE._match_id(
        "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert match_id_result == "elWuEH34SMKvaO4wO_cHBw"



# Generated at 2022-06-12 17:53:10.861741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    fixture_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    loader = KonserthusetPlayIE()
    assert loader.suitable(fixture_url) == True
    assert loader.IE_NAME == "konserthusetplay"

# Generated at 2022-06-12 17:53:19.713601
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ext = KonserthusetPlayIE()

    assert ext._match_id(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ext._match_id(
        'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

    assert ext._real_extract(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # This leads to blank result because of no fallback_url
    # assert ext._real_extract(
    #    'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:53:22.107968
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')
    assert 'md5:' in ie._TESTS[0]['info_dict']['description']