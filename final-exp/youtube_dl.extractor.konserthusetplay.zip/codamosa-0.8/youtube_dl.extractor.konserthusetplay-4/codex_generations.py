

# Generated at 2022-06-12 17:46:08.672301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlay'
    assert KonserthusetPlayIE.__doc__ != None
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:14.260077
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from . import (
        KonserthusetPlayIE,
        InfoExtractor,
        KalturaIE,
        YoutubeIE,
        extract_format,
        float_or_none,
        int_or_none,
        js_to_json,
        remove_end,
        unified_strdate,
    )
    assert(KonserthusetPlayIE is not None)

# Generated at 2022-06-12 17:46:17.827071
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	try:
		KonserthusetPlayIE(None)
	except TypeError as e:
		assert e.args[0] == "argument 1 must be an InfoExtractor instance, not 'NoneType'"

# Generated at 2022-06-12 17:46:20.038772
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    print(ie._VALID_URL)
    print(ie._TESTS)

# Generated at 2022-06-12 17:46:23.529652
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:46:26.267149
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("test_KonserthusetPlayIE: constructor of class KonserthusetPlayIE")
    assert KonserthusetPlayIE()


# Generated at 2022-06-12 17:46:28.528702
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:46:30.069730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:46:32.886340
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-12 17:46:36.475673
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://konserthusetplay.se/?m=videoID')
    KonserthusetPlayIE('http://rspoplay.se/?m=videoID')


# Generated at 2022-06-12 17:46:49.466354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    if ie is None:
        assert False
    return

# Generated at 2022-06-12 17:46:57.050631
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable("") == False
    assert ie.suitable("http://www.konserthusetplay.se").find("class=") == -1
    assert ie.suitable("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A") > 0
    assert ie.suitable("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw") > 0
    assert ie._real_extract("") == False

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:03.389537
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    r = ie.extract(url)
    assert r is not None
    assert r['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert r['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-12 17:47:05.890643
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    KonserthusetPlayIE(InfoExtractor())

# Generated at 2022-06-12 17:47:07.313213
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    p = KonserthusetPlayIE();
    assert(True)

# Generated at 2022-06-12 17:47:08.199505
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:16.767534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:21.941951
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(url)

if __name__ == '__main__':
    from . import main
    main(KonserthusetPlayIE, __file__)

# Generated at 2022-06-12 17:47:22.865979
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:26.210138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.__class__.__name__ == "KonserthusetPlayIE"

# Generated at 2022-06-12 17:47:51.435200
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None).suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE(None).suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:47:52.294845
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:58.938615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for constructor of class KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    ie_result = ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie_result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie_result['title'] == 'Orkesterns instrument: Valthornen'
    assert ie_result['description'] == 'Valthornen kommer i flera olika storlekar och spelas på ett annorlunda sätt än andra instrument. Valthornisten Ingemar Roos och konsertmästare Henrik Schaefer...'

# Generated at 2022-06-12 17:48:01.289472
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert type(test) == KonserthusetPlayIE


# Generated at 2022-06-12 17:48:02.336594
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # If you change this test, make sure to also change the filename
    assert "test_KonserthusetPlayIE" in KonserthusetPlayIE.__name__

# Generated at 2022-06-12 17:48:04.951805
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.APP_URL == 'https://konserthusetplay.se'
    assert ie.SITE == 'konserthusetplay'

# Generated at 2022-06-12 17:48:08.614544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .konserthusetplay import KonserthusetPlayIE
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:48:10.634379
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-12 17:48:14.300394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL.findall('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')[0] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:48:18.414880
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    KonserthusetPlayIE('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:49:03.465156
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    try:
        if ie.suitable(KonserthusetPlayIE._VALID_URL):
            print("Unit test: OK, suitable URL")
        else:
            print("Unit test: FAILED, unsuitable URL")
    except:
        print("Unit test: FAILED, suitable URL")

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:07.686413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    extractor = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:49:16.589777
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.IE_DESC == 'KonserthusetPlay videos'
    assert ie.VALID_URL == '^(?:https?://)?(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)(?:&.*)?$'
    assert ie.TITLE_RE == '<title>(.*?)</title>'
    assert ie.BR_DESC_RE == '^.*<br/?>(.*)$'
    assert ie.EMBED_URL == 'embed.konserthusetplay.se'
    assert ie

# Generated at 2022-06-12 17:49:21.503227
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Example URL
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # Instantiation of class
    ie = KonserthusetPlayIE()

    # Match function, should return True in this case
    print(ie._match_id(url))

    # Extract information for the URL
    print(ie._extract_info_dict(url))

# Generated at 2022-06-12 17:49:32.216360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert determine_ext('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'html'
    assert determine_ext('https://csp.picsearch.com/rest?e=elWuEH34SMKvaO4wO_cHBw&containerId=mediaplayer&i=object') == 'json'

    # The following test may take long time
    # assert KonserthusetPlayIE()._real_extract('https://rspoplay.se/?m=elWuEH34SMKvaO4

# Generated at 2022-06-12 17:49:33.328102
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:36.832523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:49:37.983458
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:38.953666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    c = KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:40.209406
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:51:39.118395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_obj = KonserthusetPlayIE()
    if not ie_obj:
        raise Exception('unit test failed')


# Generated at 2022-06-12 17:51:48.741526
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:51:52.511004
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE()
    response = instance._download_webpage(url, 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:51:58.493790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    check_KonserthusetPlayIE = KonserthusetPlayIE()
    assert check_KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:00.999829
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instantiation of KonserthusetPlayIE
    obj = KonserthusetPlayIE()
    assert obj is not None


# Generated at 2022-06-12 17:52:05.955887
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_IE = KonserthusetPlayIE();
    assert konserthusetplay_IE is not None;
    assert isinstance(konserthusetplay_IE, InfoExtractor);


if __name__ == '__main__':
    test_KonserthusetPlayIE();

# Generated at 2022-06-12 17:52:10.686553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == '.se'
    assert ie.IE_DESC == 'RSPOPlay.se and KonserthusetPlay.se'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'KonserthusetPlay') == {'id': 'CKDDnlCY-dhWAAqiMERd-A'}
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', 'KonserthusetPlay') == {'id': 'elWuEH34SMKvaO4wO_cHBw'}

# Generated at 2022-06-12 17:52:12.323574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:52:16.078483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create a test video
    try:
        test_video = KonserthusetPlayIE()
        print ("KonserthusetPlayIE Created Successfully")
    except:
        print ("Error While Creating KonserthusetPlayIE")


# Generated at 2022-06-12 17:52:23.196522
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    info = ie.extract()
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Orkesterns instrument: Valthornen'
    assert info['description'] == 'Valthornets tonomfång är  mellan två oktaver, från Es1 till Es3. En valthornist kräver ' \
                                  'högljudda toner som kan höras igenom hela orkestern. Valthornen är en av de mest '