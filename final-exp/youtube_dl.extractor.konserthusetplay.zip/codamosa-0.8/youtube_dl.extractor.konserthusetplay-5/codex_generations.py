

# Generated at 2022-06-12 17:46:17.239991
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:29.316232
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(url)
    # Test attributes of class
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-12 17:46:41.601028
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
	#url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&utm_source=skrapan&utm_medium=5&utm_campaign=skrapan"
	#url = "http://www.konserthusetplay.se/?m=Ww_zliZl_bZW9wbvn8bHFg"
	video = KonserthusetPlayIE()._real_extract(url)

# Generated at 2022-06-12 17:46:43.920569
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(InfoExtractor())
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:44.774636
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:47.640618
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:49.829684
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract(KonserthusetPlayIE._TESTS[0]['url'])

# Generated at 2022-06-12 17:46:50.664519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:46:51.551438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-12 17:46:54.917089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # make sure it does not crash
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:47:16.455912
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'http://(?:www\\.)?(?:konserthusetplay|rspoplay)\.se/\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:18.506165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    print(ie)

# Generated at 2022-06-12 17:47:24.837552
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.suitable("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.suitable("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    assert not ie.suitable("http://www.konserthusetplay.se/")

# Generated at 2022-06-12 17:47:31.402907
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Make sure it's a valid IE """
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.name == 'konserthusetplay'
    assert ie.valid_url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.valid_url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:32.649138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:36.496300
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # instantiate class
        KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
        assert True
    except:
        assert False

# Generated at 2022-06-12 17:47:37.710222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()


# Generated at 2022-06-12 17:47:42.374999
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    if k != None:
        print('Successfully created instance of class KonserthusetPlayIE')
    else:
        print('Unable to create instance of class KonserthusetPlayIE')


# Generated at 2022-06-12 17:47:45.628459
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(url)
    ie.extract()

# Generated at 2022-06-12 17:47:47.335445
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None


# Generated at 2022-06-12 17:48:14.575281
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    orgUrl = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    newUrl = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    if orgUrl == newUrl:
        print("Unit test passed")
    else:
        print("Unit test failed")


# Generated at 2022-06-12 17:48:16.542289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-12 17:48:17.478186
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlayIE')

# Generated at 2022-06-12 17:48:24.641491
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = type('obj', (object,), {'_match_id': lambda self, x: x})()
    obj.IE_NAME = 'KonserthusetPlay'
    obj.IE_DESC = 'Video extractor for KonserthusetPlay'
    obj._VALID_URL = KonserthusetPlayIE._VALID_URL
    obj._TESTS = KonserthusetPlayIE._TESTS
    ie = KonserthusetPlayIE(obj)
    for test in KonserthusetPlayIE._TESTS:
        ie.suitable(test['url'])

# Generated at 2022-06-12 17:48:28.395385
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._real_extract(test_url)

# Generated at 2022-06-12 17:48:30.731826
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    media_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://www.konserthusetplay.se/?m=%s' % media_id
    k.extract(url)

# Generated at 2022-06-12 17:48:35.753886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:37.960413
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # If a constructor test fails, an exception is raised.
    # If a constructor test succeeds, nothing is returned.
    assert ie is not None

# Generated at 2022-06-12 17:48:42.573704
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:48:43.603927
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-12 17:49:29.950230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert isinstance(IE, KonserthusetPlayIE)

# Generated at 2022-06-12 17:49:32.898312
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:49:43.433270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._TESTS[0]['url'] == ie._VALID_URL
    assert ie._TESTS[1]['url'] == ie._VALID_URL

# Generated at 2022-06-12 17:49:51.324201
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(None is not KonserthusetPlayIE._VALID_URL)
    assert(None is not KonserthusetPlayIE._TESTS)
    assert(None is not ie._match_id(None))

    # test download
    info_dict = ie._real_extract(KonserthusetPlayIE._TESTS[0]['url'])
    assert('id' == info_dict.keys()[0])
    assert('title' == info_dict.keys()[1])
    assert('description' == info_dict.keys()[2])
    assert('thumbnail' == info_dict.keys()[3])
    assert('duration' == info_dict.keys()[4])
    assert('formats' == info_dict.keys()[5])

# Generated at 2022-06-12 17:49:52.775139
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'KonserthusetPlayIE' == KonserthusetPlayIE().ie_key()

# Generated at 2022-06-12 17:49:55.272929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().IE_NAME == 'konserthusetplay'

# Generated at 2022-06-12 17:50:06.685796
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&other=extra')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    assert not ie.suitable('http://rspoplay.se/')
    assert not ie.suitable('http://konserthusetplay.se')
    assert not ie.suitable

# Generated at 2022-06-12 17:50:09.778712
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.to_screen('%s' % ie)
    return

# Generated at 2022-06-12 17:50:12.510252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Check that the class constructor raises TypeError when it's used without parameters
    try:
        KonserthusetPlayIE()
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 17:50:17.531002
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlayIE'
    assert ie.valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.valid_url('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:52:33.568121
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:35.435788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay', True)

# Generated at 2022-06-12 17:52:42.879031
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-12 17:52:44.286535
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test first unit test in file
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:51.541646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__ == 'KonserthusetPlay extractor: Extracts video urls from a KonserthusetPlay page\n'
    assert KonserthusetPlayIE._VALID_URL == '(?xi)https?://(?:(?:www\\.)?konserthusetplay\\.se/?|rspoplay\\.se/?)\\?.*\\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:55.892496
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset = KonserthusetPlayIE()

    assert konserthuset._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthuset._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthuset._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-12 17:53:03.755756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.url_result('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == {
        'id': 'elWuEH34SMKvaO4wO_cHBw',
        'ext': 'mp4',
        'title': 'Välkommen till RSO Play',
        'description': 'md5:e05e2bf7d2428d2e253791ef45bbb9e9',
        'thumbnail': 're:^https?://.*$',
        'duration': 1080.0,
    }

# Generated at 2022-06-12 17:53:05.034505
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'

# Generated at 2022-06-12 17:53:08.447361
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie.download('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
# Unit test end

# Generated at 2022-06-12 17:53:11.733019
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance.ie_key() == 'KonserthusetPlay'
    assert instance.ie_name() == 'konserthusetplay'