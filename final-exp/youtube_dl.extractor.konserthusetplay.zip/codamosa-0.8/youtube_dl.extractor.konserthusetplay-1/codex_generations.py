

# Generated at 2022-06-12 17:46:03.392384
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:46:05.621263
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'

# Generated at 2022-06-12 17:46:12.691014
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # INITIALIZE Values to use in initialization of the class
    init_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    init_expected_id = 'CKDDnlCY-dhWAAqiMERd-A'

    ie = KonserthusetPlayIE()

    # Validate that the class initialized correctly by comparing the
    # values of the variables to the expected values set above.
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:18.100001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    m = ie._VALID_URL
    assert m == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:46:26.079294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import re
    import unittest
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE._VALID_URL == re.compile(r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-12 17:46:27.542759
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:32.991215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, KonserthusetPlayIE)
    assert hasattr(ie, "IE_NAME")
    assert hasattr(ie, "_VALID_URL")
    assert hasattr(ie, "IE_DESC")

# Generated at 2022-06-12 17:46:34.240161
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:38.953488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'KonserthusetPlay'
    assert ie.description == 'Protected videos from konserthusetplay.se.'
    assert ie.ie_key == 'KonserthusetPlay'


# Generated at 2022-06-12 17:46:48.045860
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:03.707612
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    m = ie._VALID_URL
    ie_match = ie._match_id(m)
    assert ie_match == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:07.145700
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__dict__
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__


# Generated at 2022-06-12 17:47:16.038043
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)

# Generated at 2022-06-12 17:47:20.426467
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Unit test for constructor of class KonserthusetPlayIE """

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    KonserthusetPlayIE(url)

# Generated at 2022-06-12 17:47:22.774212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(submodule='submodule',
        space='space', time='time', slc='slc', rt='rt')

# Generated at 2022-06-12 17:47:23.696614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:24.616008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:29.180548
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	test_KonserthusetPlayIE = KonserthusetPlayIE.suitable('http://vk.com/video_ext.php?oid=-1&id=165599562&hash=938a31041d5f5b2f')
	if (test_KonserthusetPlayIE):
		print ("Unit test for KonserthusetPlayIE passed")
	else:
		print ("Unit test for KonserthusetPlayIE failed")


# Generated at 2022-06-12 17:47:32.762240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.get_domain() == 'konserthusetplay.se'


# Generated at 2022-06-12 17:47:34.211202
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:47:56.059790
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:03.662026
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Setup KonserthusetPlayIE object
    ie = KonserthusetPlayIE()
    # Try to extract info from a valid url
    # Should return a dictionary with relevant information
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Try to extract info from an invalid url
    # Should return None
    ie.extract('http://www.konserthusetplay.se/?m=invalid')

# Generated at 2022-06-12 17:48:10.722794
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""

    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    config = {
        # Instance of class KonserthusetPlayIE
        'instance': KonserthusetPlayIE(),
        # URL to test
        'url': url,
        # List of expected values in expected order of appearance
        'expected': [url, 'CKDDnlCY-dhWAAqiMERd-A']
    }
    assert config['instance']._match_id(config['url']) == config['expected'][1]


# Generated at 2022-06-12 17:48:12.276204
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tester = KonserthusetPlayIE()
    assert isinstance(tester, InfoExtractor)

# Generated at 2022-06-12 17:48:16.302345
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test constructor
    ie = KonserthusetPlayIE()
    assert ie.__class__ is KonserthusetPlayIE
    # Test member variables
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:17.000842
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:18.531262
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE()._VALID_URL

# Generated at 2022-06-12 17:48:28.686916
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
   ie = KonserthusetPlayIE()
   ie.downloader.http._request_webpage = lambda url: {'url': url}
   ie.downloader.http._download_webpage = ie.downloader.http._request_webpage
   def _download_json(json_url, *args, **kwargs):
       if json_url.startswith('http'):
           json_url = json_url[(json_url.index('?') + 1):]
           return {
               'media': {
                   'playerconfig': {
                       'playlist': [{
                           'url': 'http://some.url',
                           'fallbackUrl': 'http://some.url'
                       }]
                   }
               }
           }
       else:
           raise ValueError(json_url)

# Generated at 2022-06-12 17:48:29.821792
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:48:33.711630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    u = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    print(KonserthusetPlayIE._VALID_URL)
    print(u)
    assert KonserthusetPlayIE._VALID_URL.match(u) is not None
    assert KonserthusetPlayIE._VALID_URL.match(u).groups()[0] == 'elWuEH34SMKvaO4wO_cHBw'

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:15.979360
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    actualResult = KonserthusetPlayIE(None)
    assert actualResult is not None

# Generated at 2022-06-12 17:49:16.942074
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-12 17:49:19.168832
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    'Unit test for constructor of class KonserthusetPlayIE'
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'


# Generated at 2022-06-12 17:49:20.371784
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL

# Generated at 2022-06-12 17:49:21.299223
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:24.282487
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:49:33.811326
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUITABLE_YOUTUBE_URL.match("http://youtube.com/watch?v=abc")
    assert ie.SUITABLE_YOUTUBE_URL.match("http://youtu.be/abc")
    assert ie.SUITABLE_YOUTUBE_URL.match("https://www.youtube-nocookie.com/watch?v=abc")
    assert ie.SUITABLE_YOUTUBE_URL.match("https://www.youtube-nocookie.com/v/abc")
    assert ie.SUITABLE_YOUTUBE_URL.match("https://www.youtube.com/embed/abc")

# Generated at 2022-06-12 17:49:38.791296
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-12 17:49:47.714407
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    konserthusetplayIE_test = KonserthusetPlayIE()
    assert konserthusetplayIE_test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthusetplayIE_test._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert konserthusetplayIE_test._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-12 17:49:54.422721
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:51:54.025419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    test_uri = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    result = KonserthusetPlayIE()._real_extract(test_uri)

    assert isinstance(result, dict)

# Generated at 2022-06-12 17:51:59.699265
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Flask app needs to be created outside of a request context
    # Starting a Flask app inside the test class breaks - No module named 'konserthusetplay'
    # Starting the Flask app outside of the test class breaks - RuntimeError: Working outside of request context.
    # This function is supposed to get called during the setUpClass() function of the test class
    # It is supposed to return a mock Flask app with a working response to a GET request
    def init_mock_flask():
        # Imports are here to prevent errors in Travis-CI
        # https://github.com/ytdl-org/youtube-dl/issues/16133
        from flask import Flask, jsonify
        import json
        import os

        # Initialize Flask app
        flask_app = Flask('flask_test_app')

        # Create response
        # This response needs

# Generated at 2022-06-12 17:52:01.866045
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()


# Generated at 2022-06-12 17:52:09.852804
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=AjkhdSKBzCWa7OYwMYEeew')
    assert ie._match_id('https://www.konserthusetplay.se/?m=AjkhdSKBzCWa7OYwMYEeew') == 'AjkhdSKBzCWa7OYwMYEeew'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'



# Generated at 2022-06-12 17:52:15.324971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.load_webpage = lambda *_, **__: "Webpage"
    ie.extract_info = lambda *_, **__: None
    # Should not raise any exception
    KonserthusetPlayIE._real_initialize(ie, "I am URL")

# Generated at 2022-06-12 17:52:16.909768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.get_formats is not None

# Generated at 2022-06-12 17:52:17.997878
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert 'KonserthusetPlayIE' in globals()


# Generated at 2022-06-12 17:52:24.663353
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=y8V4oJhG0Y4MAAnJ6zZU6A"
    download_urls = ["http://rspoplsl.fplive.net/rspop/_definst_/mp4:temp/C/RS_POP/B/B85B3B/BA/BA3A6E/BA3A6E09FE9C.mp4/playlist.m3u8"]
    # if you don't pass in the right values, it will error out at the end
    obj = KonserthusetPlayIE(url, download_urls)
    # does it return the right type?
    assert(isinstance(obj, KonserthusetPlayIE))
    # does it fail with the wrong url?
    url

# Generated at 2022-06-12 17:52:29.360650
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == "konserthusetplay"
    assert ie.IE_DESC == "KonserthusetPlay"
    assert ie._VALID_URL == r"https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"; # noqa


# Generated at 2022-06-12 17:52:30.612388
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)