

# Generated at 2022-06-12 17:46:18.160333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.get_url_regex() == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.get_example_url() == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:46:20.279725
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
        Unit test for constructor of class KonserthusetPlayIE.
    """

    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:21.461501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:33.402268
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None, 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    info = ie._real_extract(ie.url)
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:46:35.515476
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('rspoplay.se/')
    assert ie.suitable('konserthusetplay.se/')
    assert not ie.suitable('konserthusetplay.se/')

# Generated at 2022-06-12 17:46:43.414265
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.IE_NAME == "konserthusetplay"
    assert obj.TEST_URL == "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert obj._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"


# Generated at 2022-06-12 17:46:44.925698
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Basic test:

    __init__
    Real extraction
    """
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:46:46.557745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("KonserthusetPlay", "_match_id")

# Unit tests for class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:47.266346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:49.110625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie)


# Generated at 2022-06-12 17:47:18.530870
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:20.201282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:47:23.995370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Tests if class constructor works properly
    """
    ie = KonserthusetPlayIE()
    # Tests if class name is KonserthusetPlayIE
    assert ie._get_IE_name() == "KonserthusetPlayIE"


# Generated at 2022-06-12 17:47:25.283163
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception:
        assert False

# Generated at 2022-06-12 17:47:37.609168
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test the constructor of class KonserthusetPlayIE"""
    # Test initialization
    ie = KonserthusetPlayIE()
    assert ie.server == "RestfulPicsearchCom"
    assert ie.g == "RestfulPicsearchCom"
    assert ie.e == ""
    assert ie.patterns == [r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)']

# Generated at 2022-06-12 17:47:48.807258
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test a normal video.
    assert KonserthusetPlayIE({})._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    # Test another normal video.
    assert KonserthusetPlayIE({})._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'
    # Test an invalid url.
    assert KonserthusetPlayIE({})._match_id('http://www.konserthusetplay.se/?m=XXYYZZ') == None

# Generated at 2022-06-12 17:47:50.787229
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:47:51.440278
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-12 17:48:02.825923
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("test_KonserthusetPlayIE")
    konserthuset_extractor = KonserthusetPlayIE()

    assert konserthuset_extractor._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert konserthuset_extractor.IE_NAME == 'konserthusetplay:play'

# Generated at 2022-06-12 17:48:08.276386
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None
    assert obj.ie_key() == 'konserthusetplay:video'
    assert obj.ie_type() == 'web'
    assert obj.ie_name() == 'konserthusetplay.se'
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:37.131143
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert obj.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-12 17:48:38.738702
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie is not None)

# Generated at 2022-06-12 17:48:44.415195
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert obj.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:48:49.129526
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
#     KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:48:59.870175
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test case #1.1
    ie = KonserthusetPlayIE()
    # try:
    #     ie.download(ie._VALID_URL)
    # except:
    #     pass
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Test case #1.2
    ie = KonserthusetPlayIE()
    # try:
    #     ie.download(ie._TESTS)
    # except:
    #     pass

# Generated at 2022-06-12 17:49:02.073756
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:49:05.031921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    obj = KonserthusetPlayIE()
    obj.suitable(url)
    obj.extract(url)


# Generated at 2022-06-12 17:49:06.874778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    VideoInstance(url)
    assert True

# Generated at 2022-06-12 17:49:08.943519
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:49:10.184514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-12 17:50:00.395873
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ob_KonserthusetPlayIE = KonserthusetPlayIE()
    assert ob_KonserthusetPlayIE

# Generated at 2022-06-12 17:50:04.614172
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        test_url = KonserthusetPlayIE._TESTS[0]['url']

        ie = KonserthusetPlayIE()

        assert ie._VALID_URL == ie._TESTS[0]['url']
        assert ie._TESTS[0]['id'] in ie._VALID_URL

# Generated at 2022-06-12 17:50:07.890103
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == "konserthusetplay"
    assert ie.description == "Konserthuset Play"
    assert ie.ie_key == "konserthusetplay"
    assert ie.domain == "konserthusetplay.se"


# Generated at 2022-06-12 17:50:11.268722
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from extern import KonserthusetPlayIE
    ie = KonserthusetPlayIE

# Generated at 2022-06-12 17:50:12.850874
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Instantiating KonserthusetPlayIE() raises no error
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:14.614446
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert a.SUFFIX == 'konserthusetplay.se'


# Generated at 2022-06-12 17:50:16.489774
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test that KonserthusetPlayIE has been instantiated
    assert KonserthusetPlayIE(KonserthusetPlayIE.ie_key())

# Generated at 2022-06-12 17:50:19.002630
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:50:19.839012
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:24.116922
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL ==  r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:52:34.553976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        return False
    return True


# Generated at 2022-06-12 17:52:35.644043
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:52:39.412426
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.list_supported_ie()
    ie.list_supported_url()
    ie.extract(ie.construct_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))

# Generated at 2022-06-12 17:52:44.446914
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:45.570072
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._download_json_handle("Not really a JSON string")

# Generated at 2022-06-12 17:52:49.883210
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kPlayIE = KonserthusetPlayIE()
    res = kPlayIE.suitable('https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert(res == True)
    res = kPlayIE.suitable('https://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(res == True)

# Generated at 2022-06-12 17:52:51.740927
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:52:54.978950
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:56.475410
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  try:
    KonserthusetPlayIE()
    assert True
  except:
    assert False


# Generated at 2022-06-12 17:53:01.893886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.get_info({
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A' })
    assert ie.get_info({
        'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw' })