

# Generated at 2022-06-12 17:46:10.943126
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()
    e._match_id("https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:46:21.333584
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_name = 'KonserthusetPlayIE'
    arg1 = 'KonserthusetPlay'
    arg2 = None
    expected_output = class_name
    actual_output = KonserthusetPlayIE.__name__
    assert expected_output == actual_output, 'The name of the returned instance object of "%s" should be equal to the name of the class "%s"' % (class_name, expected_output)
    expected_output = type('InfoExtractor', (object,), {})
    actual_output = KonserthusetPlayIE.__bases__[0]
    assert expected_output == actual_output, 'The base class of "%s" should be equal to "%s"' % (class_name, expected_output)
    obj = KonserthusetPlayIE(arg1, arg2)
   

# Generated at 2022-06-12 17:46:22.603165
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:46:24.381454
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Constructor: KonserthusetPlayIE")
    kpIE = KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:27.098745
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except NameError:
        return False
    else:
        return True

# Generated at 2022-06-12 17:46:28.733452
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ins = KonserthusetPlayIE()
    print(ins)


# Generated at 2022-06-12 17:46:29.874415
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:41.972374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(url, video_id)
    e = ie._search_regex(r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']', webpage,'e')
    rest = ie._download_json(
        'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' % e,
        video_id, transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1])

   

# Generated at 2022-06-12 17:46:42.604223
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  ie = KonserthusetPlayIE()
  assert ie

# Generated at 2022-06-12 17:46:49.994615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('test')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:04.959283
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay_ie = KonserthusetPlayIE("url", "context")
    assert konserthusetplay_ie.get_url() == "url"
    assert konserthusetplay_ie.get_context() == "context"

# Generated at 2022-06-12 17:47:07.501598
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"


# Generated at 2022-06-12 17:47:11.291294
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        ie = KonserthusetPlayIE()
    except Exception:
        raise AssertionError("Could not initialize class KonserthusetPlayIE")

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:12.958924
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test the KonserthusetPlayIE constructor.
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-12 17:47:25.326939
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_name = 'KonserthusetPlayIE'
    _VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:37.606738
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:38.996918
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:47:42.841976
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-12 17:47:43.926896
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:47:45.131511
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:48:11.110367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    #url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    x = ie.extract(url)
    #print(x)
    assert(x['id'] == 'elWuEH34SMKvaO4wO_cHBw')
    assert(x['ext'] == 'mp4')

# Generated at 2022-06-12 17:48:11.783048
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:19.461332
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-12 17:48:23.394683
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
# test_KonserthusetPlayIE()



# Generated at 2022-06-12 17:48:28.469554
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie.test_test_test() == 1)



# Generated at 2022-06-12 17:48:30.292137
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    try:
        assert ie
    except:
        raise AssertionError("Constructor for class KonserthusetPlayIE failed")


# Generated at 2022-06-12 17:48:39.131961
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Expect to fail when creating without an URL or String
    try:
        KonserthusetPlayIE()
    except Exception as e:
        assert isinstance(e, TypeError)

    # Expect to fail when creating with a String
    try:
        KonserthusetPlayIE('helpme')
    except Exception as e:
        assert isinstance(e, TypeError)

    konserthuset_play_ies = list()

    konserthuset_play_ies.append(KonserthusetPlayIE(url='http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))

# Generated at 2022-06-12 17:48:46.438770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test with an existing video
    konserthusetplay = KonserthusetPlayIE().download(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

    # test with a non existing video
    # konserthusetplay = KonserthusetPlayIE().download(
    #     'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A-NONEXISTING')

    assert konserthusetplay is not None

# Generated at 2022-06-12 17:48:47.813248
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:48.917429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:35.718430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE.
    Case 1:
    Extracts info from https://www.konserthusetplay.se/?m=ol6UdroJ6SJhSsYYZ8XffA
    Case 2:
    Extracts info from https://www.konserthusetplay.se/?m=tsGjfZmS0mS8Pm4wO_cHBw
    """
    print("Unit testing class KonserthusetPlayIE...")
    print("==========================================================================")
    print("Testing class constructor...")
    print("==========================================================================")
    print("Case 1:")

# Generated at 2022-06-12 17:49:41.423105
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE._VALID_URL = 'https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie._match_id(KonserthusetPlayIE._VALID_URL) == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:49:42.724608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE

# Generated at 2022-06-12 17:49:45.736220
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'
    assert KonserthusetPlayIE.__doc__ == InfoExtractor.__doc__
    assert hasattr(a, '_downloader')

# Generated at 2022-06-12 17:49:46.691479
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-12 17:49:48.995350
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_obj = KonserthusetPlayIE()
    print(ie_obj.__class__)
    assert ie_obj.__class__ == KonserthusetPlayIE


# Generated at 2022-06-12 17:49:50.607107
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_obj = KonserthusetPlayIE
    obj = class_obj(class_obj.ie_key())
    print(obj.ie_key())
    assert obj.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:49:52.607681
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    test_obj = KonserthusetPlayIE()
    test_obj.suitable(test_url)
    test_obj.extract(test_url)

# Generated at 2022-06-12 17:49:54.370108
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = KonserthusetPlayIE()
    assert url.ie_key() == 'KonserthusetPlay'
    assert url.ie_key() in url._ies



# Generated at 2022-06-12 17:49:58.225595
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # TODO: Unit test for constructor of class KonserthusetPlayIE
    assert True is not False
    pass

# Generated at 2022-06-12 17:51:58.338193
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.VIDEO_ID == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:52:06.448676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # To run unit test for KonserthusetPlayIE, run "python -m unittest -v 2"
    # in examples\test folder.
    # Change attributes of class KonserthusetPlayIE as you need.
    ie = KonserthusetPlayIE(url='')

# Generated at 2022-06-12 17:52:08.805982
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        metaclass = type
        class KonserthusetPlayIE(metaclass):
            _VALID_URL = ""
            _TESTS = []

        KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:11.595394
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        ie = KonserthusetPlayIE()
    except:
        print("Error: Unknown test")

# Generated at 2022-06-12 17:52:12.560940
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:15.394879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:52:18.921155
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._TESTS)


# Generated at 2022-06-12 17:52:23.498485
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:26.083493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # Run unit test for constructor of class KonserthusetPlayIE
    # assert <condition>



# Generated at 2022-06-12 17:52:28.378710
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # pylint: disable=invalid-name
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)