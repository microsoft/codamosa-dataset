

# Generated at 2022-06-12 17:46:11.815567
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.get_id() == 'CKDDnlCY-dhWAAqiMERd-A'

    # test regexp

# Generated at 2022-06-12 17:46:15.288324
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE()
    assert inst
    assert inst.IE_NAME == "konserthusetplay"

# Generated at 2022-06-12 17:46:18.899638
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    ie = KonserthusetPlayIE()
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:26.572702
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'konserthusetplay.se'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:32.696333
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:44.254140
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	# Given
	info_extractor = KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:46.380300
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    assert IE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')



# Generated at 2022-06-12 17:46:55.806849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    obj = KonserthusetPlayIE()
    obj2 = InfoExtractor()
    assert hasattr(obj, '_VALID_URL') == hasattr(obj2, '_VALID_URL') # Checks that _VALID_URL is inherited from InfoExtractor
    assert hasattr(obj, '_TEST') == hasattr(obj2, '_TEST')  # Checks that _TEST is inherited from InfoExtractor
    assert hasattr(obj, '_download_webpage') == hasattr(obj2, '_download_webpage')  # Checks that _download_webpage is inherited from InfoExtractor

# Generated at 2022-06-12 17:47:02.048876
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k

if __name__ == '__main__':
    #begin test code
    #create ie object
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:03.106150
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        assert False


# Generated at 2022-06-12 17:47:26.144534
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.SUIT() == True

# Generated at 2022-06-12 17:47:27.049647
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:34.165544
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE().suitable(url)
    result = KonserthusetPlayIE().extract(url)
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert len(result['subtitles']) == 0

# Generated at 2022-06-12 17:47:42.427515
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    for url, output in [("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"),
                        ("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw", "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")]:
        KonserthusetPlayIE(url, output)

# Generated at 2022-06-12 17:47:47.511122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=lfxPZoW7l8NvjYca1yMUew")
    assert ie.url == "http://www.konserthusetplay.se/?m=lfxPZoW7l8NvjYca1yMUew"

# Generated at 2022-06-12 17:47:51.068846
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert (ie.ie_key() == 'KonserthusetPlay')
    assert (ie.ie_name() == 'KonserthusetPlay')

# Generated at 2022-06-12 17:47:58.139614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    try:
        assert(instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    except AssertionError:
        print("Incorrect _VALID_URL. Expected " + r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)' + " but got " + instance._VALID_URL)


# Generated at 2022-06-12 17:48:03.868058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Unit tests for _real_extract
    ie._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    ie._real_extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:48:08.583564
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.url == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:48:15.935972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE.IE(None)
    assert ie is not None
    assert ie.possible_ie is not None
    assert ie.possible_ie[0].ie_key() == 'Generic'
    assert ie.possible_ie[1].ie_key() == 'M3U8'
    assert ie.possible_ie[0].ie is None
    assert ie.possible_ie[1].ie is not None
    assert ie.possible_ie[1].ie.__class__.__name__ == 'M3U8'

# Generated at 2022-06-12 17:49:07.412438
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_downloader import FakeYDL
    class TestKonserthusetPlayIE(KonserthusetPlayIE):
        def __init__(self, ydl):
            self.ydl = ydl

        def _download_webpage(self, *args, **kwargs):
            return self.ydl.extract_info(*args, download=False)['webpage_type']

        def _download_json(self, *args, **kwargs):
            return self.ydl.extract_info(*args, download=False)

    ydl = FakeYDL()
    ie = TestKonserthusetPlayIE(ydl)


# Generated at 2022-06-12 17:49:11.748633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE(test_KonserthusetPlayIE)

# Generated at 2022-06-12 17:49:14.044221
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A");
    return;

# Generated at 2022-06-12 17:49:19.676911
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE()
    # Test the constructor
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.supported_extensions() == ['mp4']
    assert ie.supported_domains() == ['www.konserthusetplay.se']

# Generated at 2022-06-12 17:49:21.296658
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name() == 'konserthuset.se'

# Generated at 2022-06-12 17:49:30.154977
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test if URL can be handled
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Test if URL is valid
    assert ie.suitable(url)
    # Test extraction from URL
    info = ie.extract(url)
    # Test if title is correct
    assert info['title'] == 'Orkesterns instrument: Valthornen'
    # Test if video id is correct
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:49:32.215227
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except:
        print('class KonserthusetPlayIE could not be constructed')

# Generated at 2022-06-12 17:49:38.690287
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    khp = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert khp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:49:40.294571
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ret = KonserthusetPlayIE(None, None)          # Pass in these args
    assert ret

# Generated at 2022-06-12 17:49:42.184812
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:51:51.232540
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:51:52.579895
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-12 17:51:56.021741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Make sure that the class can be constructed
    # with an arbitrary string
    class_name = 'KonserthusetPlayIE'
    class_object = globals()[class_name]

    ie = class_object('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.name == 'KonserthusetPlay'

# Generated at 2022-06-12 17:51:59.321271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    info_extractor = KonserthusetPlayIE()
    assert info_extractor.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:52:04.451263
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""

    konserthuset_play_ie_inst = KonserthusetPlayIE()

    from .common import InfoExtractor

    assert isinstance(konserthuset_play_ie_inst, InfoExtractor)



# Generated at 2022-06-12 17:52:05.955194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:06.869672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:10.848971
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test that creating an instance of the KonserthusetPlayIE class is successful and doesn't throw an exception
    try:
        KonserthusetPlayIE()
        # if no exception was thrown while creating an instance of the KonserthusetPlayIE class, the test is successful
        test_successful = True
    except:
        # an exception was thrown while creating an instance of the KonserthusetPlayIE class, the test is unsuccessful
        test_successful = False
    assert test_successful

# Generated at 2022-06-12 17:52:12.073523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:52:15.066541
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.IE_NAME == 'konserthusetplay.se')
    assert(ie.__class__.__name__ == 'KonserthusetPlayIE')