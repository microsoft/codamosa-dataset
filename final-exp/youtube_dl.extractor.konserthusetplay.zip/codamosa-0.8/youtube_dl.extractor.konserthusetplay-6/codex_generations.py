

# Generated at 2022-06-12 17:46:09.313531
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
        ie = KonserthusetPlayIE()
        assert(ie != None)


# Generated at 2022-06-12 17:46:10.595442
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KPH = KonserthusetPlayIE()
    assert KPH.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:14.870789
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    yt = KonserthusetPlayIE()
    assert yt is not None
    assert yt._VALID_URL is not None
    assert yt._TESTS is not None
    assert yt._real_extract is not None
    assert yt._search_regex is not None
    assert yt._match_id is not None
    assert yt._download_webpage is not None
    assert yt._download_json is not None
    assert yt._extract_m3u8_formats is not None
    assert yt._sort_formats is not None

# Generated at 2022-06-12 17:46:15.812271
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:17.239686
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE == type(KonserthusetPlayIE({}))


# Generated at 2022-06-12 17:46:20.629314
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  assert(KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-12 17:46:21.765004
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
     KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:24.604514
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-12 17:46:27.237046
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()

    # Get instance of class InfoExtractor
    info_extractor = IE.ie

# Generated at 2022-06-12 17:46:30.121929
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'KonserthusetPlay'
    assert ie.site_id == 'konserthusetplay'

# Generated at 2022-06-12 17:46:43.456835
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    tmp_class = KonserthusetPlayIE(None)
    assert tmp_class.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:45.067435
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:47.334252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:49.145805
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:46:50.404875
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	info = KonserthusetPlayIE()
	print(info)

# Generated at 2022-06-12 17:46:52.728947
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)



# Generated at 2022-06-12 17:46:53.317219
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert True

# Generated at 2022-06-12 17:46:56.254119
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('KonserthusetPlay', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'KonserthusetPlay')

# Generated at 2022-06-12 17:47:00.319689
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplayie = KonserthusetPlayIE()
    assert konserthusetplayie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:11.250917
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    from pprint import pprint
    pprint(__name__)
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:33.740216
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()
    assert kp is not None

# Generated at 2022-06-12 17:47:35.619205
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)
    assert ie



# Generated at 2022-06-12 17:47:36.685222
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:47.640154
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:53.022356
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"), KonserthusetPlayIE)
    assert isinstance(KonserthusetPlayIE("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw"), KonserthusetPlayIE)

# Generated at 2022-06-12 17:47:55.724276
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

    assert obj.name == 'KonserthusetPlay'
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.description == 'Description of the KonserthusetPlay extractor.'

# Generated at 2022-06-12 17:48:06.348370
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Constructor test 1
    ie = KonserthusetPlayIE('KonserthusetPlay', 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Constructor test 2
    ie2 = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:48:08.419949
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	konserthusetplay_ie = KonserthusetPlayIE(None, None)
	assert konserthusetplay_ie is not None

# Generated at 2022-06-12 17:48:11.566724
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Test KonserthusetPlayIE class constructor can be invoked successfully
    """
    assert KonserthusetPlayIE is not None

# Generated at 2022-06-12 17:48:19.177113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for constructor without any argument
    try:
        ie = KonserthusetPlayIE()
    except Exception:
        assert False, 'Unit test failed : constructor without any argument'
    else:
        assert True, 'Unit test passed : constructor without any argument'

    # Test for constructor with a url
    try:
        ie_with_url = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    except Exception:
        assert False, 'Unit test failed : constructor with a url'
    else:
        assert True, 'Unit test passed : constructor with a url'

    # Test for real_extract method

# Generated at 2022-06-12 17:49:09.556404
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # This is a KonserthusetPlayIE testcase.
    ie = KonserthusetPlayIE()
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    video_id = 'elWuEH34SMKvaO4wO_cHBw'
    # should display short help
    ie.download(url)
    ie.download(url, video_id)

# Generated at 2022-06-12 17:49:17.214421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing for url of type 
    # http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A
    # from extractor.common.py file. 
    # First, we create a KonserthusetPlayIE object, passing the url as parameter. 
    # Then, we check if KonserthusetPlayIE object is initialized correctly. 
    # Finally, we check if _VALID_URL contain the pattern that match the url used in KonserthusetPlayIE object initialization.
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthusetplayIE = KonserthusetPlayIE(url)
    # check for presence of attributes of class TestInfo

# Generated at 2022-06-12 17:49:27.429498
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie.video_id = ie.url[len("http://www.konserthusetplay.se/?m="):]
    ie.webpage = ie._download_webpage(ie.url, ie.video_id)
    ie.e = "qx58RaIo-IUTQzF7bmRi-A"
    ie.rest = ie._download_json(
        "http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object" % ie.e,
        ie.video_id)
    ie.media = ie.rest['media']
   

# Generated at 2022-06-12 17:49:29.303583
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testobj = KonserthusetPlayIE()
    testobj.constructor()


# Generated at 2022-06-12 17:49:30.197741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE)

# Generated at 2022-06-12 17:49:33.365236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:49:34.248069
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None)

# Generated at 2022-06-12 17:49:44.595555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert str(instance) == '<KonserthusetPlayIE>'
    assert repr(instance) == '<KonserthusetPlayIE(http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A)>'
    assert instance.module_name == 'GetInfo'
    assert instance.IE_NAME == 'konserthusetplay'
    assert instance.ie_key() == 'KonserthusetPlayIE'
    assert instance.ie_key() in InfoExtractor._ies

# Generated at 2022-06-12 17:49:46.348634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download = lambda arg: arg
    assert ie.download('foo') == 'foo'

# Generated at 2022-06-12 17:49:47.263624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:42.597264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie
    assert ie.IE_NAME == 'KonserthusetPlayIE'

# Generated at 2022-06-12 17:51:43.978118
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    

# Generated at 2022-06-12 17:51:44.877905
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    global KonserthusetPlayIE
    xt = KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:46.409555
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie is not None
    

# Generated at 2022-06-12 17:51:52.918280
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE(None, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    KonserthusetPlayIE(None, 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    KonserthusetPlayIE(None, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&ss=2')

# Generated at 2022-06-12 17:51:54.110212
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instantiation of class KonserthusetPlayIE
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:03.277323
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test for KonserthusetPlayIE"""
    konserthusetplayIE = KonserthusetPlayIE()
    assert konserthusetplayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:11.327761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(isinstance(ie, InfoExtractor))
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')

# Generated at 2022-06-12 17:52:15.803869
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUITABLE_NAMES == ['vimeo']
    assert ie.IE_NAME == 'vimeo'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/%(account_id)s/%(embed_id)s_default/index.html?videoId=%(video_id)s'
    assert ie.IE_DESC == 'Vimeo'
    assert ie.VALID_URL == r'^https?://player\.vimeo\.com/video/(?P<id>\d+)'
    asse

# Generated at 2022-06-12 17:52:16.727419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kp = KonserthusetPlayIE()