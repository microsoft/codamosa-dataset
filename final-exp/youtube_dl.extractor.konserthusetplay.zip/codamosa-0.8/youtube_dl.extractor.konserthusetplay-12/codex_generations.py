

# Generated at 2022-06-12 17:46:09.414042
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-12 17:46:15.354539
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE('http://www.konserthusetplay.se', 'KonserthusetPlayIE')._VALID_URL == KonserthusetPlayIE._VALID_URL)
    assert(KonserthusetPlayIE('http://rspoplay.se', 'KonserthusetPlayIE')._VALID_URL == KonserthusetPlayIE._VALID_URL)


# Generated at 2022-06-12 17:46:24.976654
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.set_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    info = ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert info['id'] == 'CKDDnlCY-dhWAAqiMERd-A'
    assert info['title'] == 'Orkesterns instrument: Valthornen'
    assert info['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'
    assert info['thumbnail'] == 're:^https?://.*$'
    assert info['duration'] == 398.76

# Generated at 2022-06-12 17:46:37.068771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Search for "Orkesterns instrument: Valthornen"
    KonserthusetPlayIE._search_regex(
        r'https?://csp\.picsearch\.com/rest\?.*\be=(.+?)[&"\']',
        'https://csp.picsearch.com/rest?e=151e9eade06434a058931ebf7c5f5d5ab0f954435aad079c26a2f0d3b0c31b13&containerId=mediaplayer&i=object',
        'epakke'
    )

    # Test that this method throws the right error when called with the wrong arguments

# Generated at 2022-06-12 17:46:40.694900
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj != None

# Generated at 2022-06-12 17:46:44.217727
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .YoutubeIE import YoutubeIE
    ie = YoutubeIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:45.679492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:47.046528
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert isinstance(
        KonserthusetPlayIE(),
        KonserthusetPlayIE
    )

# Generated at 2022-06-12 17:46:47.547395
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-12 17:46:52.890067
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:06.156978
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    unittest.TestLoader().loadTestsFromTestCase(KonserthusetPlayIE)

# Generated at 2022-06-12 17:47:07.107260
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-12 17:47:07.990527
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE

# Generated at 2022-06-12 17:47:16.658062
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie.is_valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'))
    assert(ie.is_valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&offset=3'))
    assert(ie.is_valid_url('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A&offset=3&w=true'))
    assert(not ie.is_valid_url('http://www.konserthusetplay.se/'))

# Generated at 2022-06-12 17:47:24.040754
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'
    ie._match_id('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == 'elWuEH34SMKvaO4wO_cHBw'


# Generated at 2022-06-12 17:47:28.082352
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    k = KonserthusetPlayIE(url)
    assert k._TESTS[1] == k._TESTS[0]
    assert k._TESTS[1]['url'] == url

# Generated at 2022-06-12 17:47:30.185297
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()
# Test for method _real_extract of class KonserthusetPlayIE

# Generated at 2022-06-12 17:47:36.979076
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL.search('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert KonserthusetPlayIE._VALID_URL.search('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')


# Generated at 2022-06-12 17:47:37.885769
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:49.393100
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # general tests
    assert ie.IE_NAME == 'konserthusetplay'
    assert ie.IE_DESC == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:16.895899
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:24.149956
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_extractor = KonserthusetPlayIE()._download_webpage(
            "http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw", "elWuEH34SMKvaO4wO_cHBw")
    assert konserthuset_play_extractor
    assert konserthuset_play_extractor == "http://csp.picsearch.com/rest?e=domd_smv_&containerId=mediaplayer&i=object"

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:29.093310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    #KonserthusetPlayIE("http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-12 17:48:29.822113
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:48:33.637998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    result = KonserthusetPlayIE().extract(url)
    assert result['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:48:34.526562
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Generated at 2022-06-12 17:48:35.417975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:42.993659
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    expected = {
        'id': 'CKDDnlCY-dhWAAqiMERd-A',
        'ext': 'mp4',
        'title': 'Orkesterns instrument: Valthornen',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    info = ie._real_extract(url)
    assert info == expected

# Generated at 2022-06-12 17:48:45.780122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Unit tests for KonserthusetPlayIE class """
    extractor = KonserthusetPlayIE(None)

    assert hasattr(extractor, '_download_webpage')

# Generated at 2022-06-12 17:48:53.462831
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # m3u8 test case
    # video_url = 'http://www.konserthusetplay.se/?m=ckddnlcy-&play=1'
    video_url = 'http://www.konserthusetplay.se/?m=F1dLWn34YuyOAAqzMERd-Q'
    konserthusetplay = KonserthusetPlayIE()
    konserthusetplay.extract(video_url)


# Generated at 2022-06-12 17:49:36.782089
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Error: unit test is not implemented")
    assert False

# Generated at 2022-06-12 17:49:38.690148
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    kpl = KonserthusetPlayIE()
    assert kpl is not None


# Generated at 2022-06-12 17:49:39.620988
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    result = KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:40.531367
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:46.348915
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test constructor with valid url
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthusetPlayIE = KonserthusetPlayIE()
    assert (konserthusetPlayIE.ie_key() == 'KonserthusetPlay')
    assert (konserthusetPlayIE.suitable(url))

# Function test_download_konserthusetplay_url

# Generated at 2022-06-12 17:49:47.089488
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.test()

# Generated at 2022-06-12 17:49:47.883895
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:51.290890
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    KonserthusetPlayIE("http://rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:49:52.763282
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE('http://www.example.com')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-12 17:49:55.973850
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test instance is created
    assert(KonserthusetPlayIE(None) is not None)

# Generated at 2022-06-12 17:51:56.435614
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:52:00.544157
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	#asserts that KonserthusetPlayIE is a subclass of InfoExtractor

	assert issubclass(KonserthusetPlayIE, InfoExtractor)

	#checks if the object is an instance of KonserthusetPlayIE

	assert isinstance(KonserthusetPlayIE, KonserthusetPlayIE)

# Generated at 2022-06-12 17:52:10.051473
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:12.291787
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE


# Generated at 2022-06-12 17:52:20.802126
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # pylint: disable=protected-access
    # sanity check for constructor of class KonserthusetPlayIE
    assert isinstance(KonserthusetPlayIE._build_br(), dict)
    assert isinstance(KonserthusetPlayIE._build_fr(), dict)
    assert isinstance(KonserthusetPlayIE._calc_time(), bool)
    assert isinstance(KonserthusetPlayIE._download_json(), dict)
    assert isinstance(KonserthusetPlayIE._download_webpage(), str)
    assert isinstance(KonserthusetPlayIE._extract_m3u8_formats(), list)
    assert isinstance(KonserthusetPlayIE._extract_mpd_formats(), list)
    # couldn't figure out how to test _extract_mpd_form

# Generated at 2022-06-12 17:52:25.211060
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert KonserthusetPlayIE._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert KonserthusetPlayIE._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:52:32.173309
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_download import _FakeTempFile
    from .test_generic import fake_urlopen
    if not hasattr(KonserthusetPlayIE, '_download_json'):
        KonserthusetPlayIE._download_json = KonserthusetPlayIE._download_webpage
    if not hasattr(KonserthusetPlayIE, '_download_webpage'):
        KonserthusetPlayIE._download_webpage = lambda *args, **kargs: None
        KonserthusetPlayIE._download_webpage.return_code = None
        KonserthusetPlayIE._download_webpage.webpage = None
        KonserthusetPlayIE._download_webpage.headers = None

# Generated at 2022-06-12 17:52:36.255287
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:52:38.783923
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 
        'test_vid')

# Generated at 2022-06-12 17:52:41.313945
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetPlayIE = KonserthusetPlayIE()
    assert konserthusetPlayIE.__class__.__name__ == 'KonserthusetPlayIE'