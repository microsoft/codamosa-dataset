

# Generated at 2022-06-12 17:46:13.897930
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'Konserthuset Play'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:24.067241
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('')
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:25.244706
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:27.473354
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    i = KonserthusetPlayIE()
    assert isinstance(i, InfoExtractor)

# Generated at 2022-06-12 17:46:39.767351
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:41.692392
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'

# Generated at 2022-06-12 17:46:49.646319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    k = KonserthusetPlayIE()

    KonserthusetPlayIE.REGEX = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    KonserthusetPlayIE.VALID_URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:46:58.570719
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Basic test:
    >>> ie = KonserthusetPlayIE()
    >>> ie
    <KonserthusetPlayIE>
    >>> ie.IE_NAME
    'KonserthusetPlay'
    >>> ie.IE_DESC
    'KonserthusetPlay'
    >>> ie.VALID_URL
    'https?://(?:www\\.)?(?:konserthusetplay|rspoplay)\\.se/\\?.*\\bm=(?P<id>[^&]+)'
    """

if __name__ == '__main__':
    # Since we have code outside of class functions, test_KonserthusetPlayIE()
    # doesn't work
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 17:47:02.787587
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE("test")._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-12 17:47:06.025523
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Create a KonserthusetPlayIE object"""
    konserthusetplay_ie = KonserthusetPlayIE()
    assert(konserthusetplay_ie is not None)


# Generated at 2022-06-12 17:47:18.554429
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:21.009865
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Test to ensure that the constructor of class KonserthusetPlayIE has no
    problem working."""
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:26.413111
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    from .common import InfoExtractor
    from .generic import YoutubeIE

    assert isinstance(KonserthusetPlayIE.ie_key(), type(InfoExtractor))
    assert isinstance(KonserthusetPlayIE.ie_key(), type(YoutubeIE))
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')
    assert hasattr(KonserthusetPlayIE, '_TESTS')

# Generated at 2022-06-12 17:47:27.352992
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:31.480602
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:47:32.706374
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:35.723633
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:47:36.807871
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    return KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:37.709898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-12 17:47:40.029822
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:47:52.699337
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE is not None


# Generated at 2022-06-12 17:47:59.243080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')
    assert(ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967')
    assert(ie._TESTS[0]['info_dict']['id'] == 'CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:48:08.313389
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ins_KonserthusetPlayIE = KonserthusetPlayIE()
    # Test to assert that declaration of KonserthusetPlayIE is correct
    assert ins_KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:14.047088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.extractor._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.extractor._TESTS == KonserthusetPlayIE._TESTS
    assert ie.extractor._match_id == KonserthusetPlayIE._match_id


# Generated at 2022-06-12 17:48:14.970082
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE

# Generated at 2022-06-12 17:48:15.998973
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-12 17:48:18.820649
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE();
    # The following URL is not a valid URL for the KonserthusetPlayIE, but it is a valid URL for the InfoExtractor.
    ie.url = 'https://www.youtube.com/watch?v=oGcEYnZsU6k'
    print(ie)

# Generated at 2022-06-12 17:48:20.219692
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.SUFFIX == 'play'

# Generated at 2022-06-12 17:48:24.029531
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthusetplay'
    assert ie.description == 'Konserthuset Play'
    assert ie.ie_key == 'KonserthusetPlay'

# Generated at 2022-06-12 17:48:27.829501
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('id_test')
    assert ie._FORMATS == 'id_test'
    assert ie._VALID_URL == 'id_test'
    assert ie._TESTS == 'id_test'


# Generated at 2022-06-12 17:48:54.518504
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    errorMessage = 'Could not instantiate KonserthusetPlayIE'
    try:
        KonserthusetPlayIE()
    except Exception as exc:
        assert False, '%s: %s' % (errorMessage, repr(exc))


# Generated at 2022-06-12 17:48:58.965369
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.download("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:49:08.992916
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert type(KonserthusetPlayIE()._VALID_URL) == str
    assert KonserthusetPlayIE()._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert type(KonserthusetPlayIE().IE_NAME) == str
    assert KonserthusetPlayIE().IE_NAME == 'konserthusetplay'
    assert type(KonserthusetPlayIE()._TESTS) == list
    assert len(KonserthusetPlayIE()._TESTS) == 2

# Generated at 2022-06-12 17:49:10.269684
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 17:49:10.684040
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	pass

# Generated at 2022-06-12 17:49:12.085972
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    get_KonserthusetPlayIE()


# Generated at 2022-06-12 17:49:12.997046
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:22.618660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert (k.ie_key() == 'KonserthusetPlay')
    assert (k.ie_key() != 'Konserthusetplay')
    assert (k.ie_key() != 'konserthusetplay')
    assert (k.ie_key() != 'konserthusetplay')
    assert (k.ie_key() != 'KonserthusetPlayIE')
    assert (k.ie_key() != 'konserthusetplayie')
    assert (k.ie_key() != 'KonserthusetPlayIE')
    assert (k.ie_key() != 'konserthuset_play')
    assert (k.ie_key() != 'konserthuset-play')

# Generated at 2022-06-12 17:49:31.842346
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    if ie._type != "generic":
        raise ValueError("Wrong value for _type: %s" % ie._type)
    if ie._TEST != ie._TESTS[0]:
        raise ValueError("Wrong value for _TEST: %s" % ie._TEST)
    if ie._VALID_URL != 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)':
        raise ValueError("Wrong value for _VALID_URL: %s" % ie._VALID_URL)


# Generated at 2022-06-12 17:49:34.924691
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "https://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE()
    ie._match_id(url)

# Generated at 2022-06-12 17:50:36.544220
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Note: create unit test using the following konserthuset_play_ie instance
    # so that the tests are independent of other extractor classes
    konserthuset_play_ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:38.780676
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:46.450426
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE("https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:50:48.469639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    _ = KonserthusetPlayIE("https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-12 17:50:55.887682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Note: subclasses of InfoExtractor must be instantiated explicitly, so that
    # their tests will be run as well
    ie = KonserthusetPlayIE(None)

    # Below is a test url from KonserthusetPlayIE.
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    # Pass the url to _real_extract function to test the extraction of
    # information.
    ie._real_extract(url)

# Generated at 2022-06-12 17:50:58.501666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert('KonserthusetPlay' in ie.IE_NAME)
    assert(ie.IE_NAME.count('KonserthusetPlay') == 1)


# Generated at 2022-06-12 17:51:00.299660
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj is not None

# Generated at 2022-06-12 17:51:07.067325
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_NAME == 'konserthusetplay:play'
    assert ie.IE_DESC == 'KonserthusetPlay, RSPOPlay'

# Generated at 2022-06-12 17:51:17.247986
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE._VALID_URL = r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda url: '' # dummy function
    ie._download_json = lambda url, video_id, transform_source: ''
    ie._extract_m3u8_formats = lambda url, video_id, ext, entry_protocol, m3u8_id, fatal=True: []
    ie._sort_formats = lambda formats: []

    import urllib

# Generated at 2022-06-12 17:51:19.531227
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ KonserthusetPlayIE can be constructed """
    temp = KonserthusetPlayIE('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert temp != None

# Generated at 2022-06-12 17:53:35.608813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:53:45.321173
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for a correct initialization for KonserthusetPlayIE
    ie = KonserthusetPlayIE()
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')[0]['formats'][0]['format_id'] == 'http-h264m'
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')[0]['formats'][0]['url'] == 'http://videocdn-fra.picsearch.com/play/201508/CKDDnlCY-dhWAAqiMERd-A_h264m_1_0_0.mp4'
    assert ie.extract

# Generated at 2022-06-12 17:53:46.748639
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .konserthusetplay import KonserthusetPlayIE
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-12 17:53:56.891851
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:53:58.155931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:54:01.100715
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    s = KonserthusetPlayIE()
    assert s.suitable(url)


# Generated at 2022-06-12 17:54:02.499921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.__name__ == 'KonserthusetPlay'

# Generated at 2022-06-12 17:54:06.117955
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    ie = KonserthusetPlayIE(url)
    assert isinstance(ie, KonserthusetPlayIE)

# Generated at 2022-06-12 17:54:08.456240
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:54:10.910486
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    def test_url(url):
        k = KonserthusetPlayIE(KonserthusetPlayIE._create_getinfo_extractor(url))
        assert k._VALID_URL == url