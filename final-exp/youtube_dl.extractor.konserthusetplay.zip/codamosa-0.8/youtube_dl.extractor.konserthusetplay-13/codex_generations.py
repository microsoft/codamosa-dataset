

# Generated at 2022-06-12 17:46:09.259792
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:11.586688
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.download(url)

# Generated at 2022-06-12 17:46:12.285764
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:14.649821
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert(KonserthusetPlayIE() is not None)



# Generated at 2022-06-12 17:46:18.589799
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(url)

# Generated at 2022-06-12 17:46:21.757282
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:33.925861
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if exceptions are thrown when both arguments are None
    try:
        K = KonserthusetPlayIE()
        assert False, 'Should not allow instantiation of KonserthusetPlayIE without args'
    except:
        assert True
    # Test if exception is thrown when url is None
    try:
        K = KonserthusetPlayIE(url=None)
        assert False, 'Should not allow instantiation of KonserthusetPlayIE without url'
    except:
        assert True
    # Test if exception is thrown when url is empty string
    try:
        K = KonserthusetPlayIE(url='')
        assert False, 'Should not allow instantiation of KonserthusetPlayIE with empty url'
    except:
        assert True


if __name__ == '__main__':
    test

# Generated at 2022-06-12 17:46:40.695898
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    Klass = KonserthusetPlayIE
    test_urls = [
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ]
    list_of_ie_instances = [Klass(url) for url in test_urls]
    assert all(isinstance(obj, InfoExtractor) for obj in list_of_ie_instances)

# Generated at 2022-06-12 17:46:41.199777
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:42.183353
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:07.787553
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:47:11.584592
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:14.798073
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:17.929953
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert(instance._VALID_URL == KonserthusetPlayIE._VALID_URL)

# Generated at 2022-06-12 17:47:20.728693
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_play_ie = KonserthusetPlayIE()
    assert isinstance(konserthuset_play_ie, InfoExtractor)

# Generated at 2022-06-12 17:47:23.781730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:47:30.810243
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.SUITABLE is not None

    assert ie.IE_NAME is not None

    assert ie.IE_DESC is not None

    assert ie._VALID_URL is not None

    assert hasattr(ie, '_download_webpage')

    assert hasattr(ie, '_extract_m3u8_formats')

    assert hasattr(ie, '_search_regex')

    assert hasattr(ie, '_sort_formats')

    assert hasattr(ie, '_match_id')

    assert hasattr(ie, '_real_extract')

    assert ie.SUITABLE is not None

    assert ie.IE_NAME is not None

    assert ie.IE_DESC is not None

    assert ie._VALID_URL is not None



# Generated at 2022-06-12 17:47:40.819513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
  video_id = 'CKDDnlCY-dhWAAqiMERd-A'
  url      = 'http://www.konserthusetplay.se/?m=' + video_id

# Generated at 2022-06-12 17:47:51.336666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Testing the KonserthusetPlayIE by instantiating it with a valid url
    myKonserthusetPlay = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert isinstance(myKonserthusetPlay, KonserthusetPlayIE)
    assert myKonserthusetPlay._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # assert myKonserthusetPlay._downloader == YoutubeDL()

# Generated at 2022-06-12 17:48:02.776246
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:48:57.167909
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie.suitable('http://www.konserthusetplay.se/')
    # test _VALID_URL
    assert ie._VALID_URL(
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert not ie._VALID_URL('http://www.konserthusetplay.se/?CKDDnlCY-dhWAAqiMERd-A')


# Generated at 2022-06-12 17:49:05.561334
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.KonserthusetPlayIE._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    ie = KonserthusetPlayIE(url='http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', ie='KonserthusetPlayIE')
    ie.extract()
    assert ie.url == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    assert ie.id == 'elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-12 17:49:15.607620
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test for constructor of class KonserthusetPlayIE"""
    # Normal use
    instance = KonserthusetPlayIE()

    assert instance._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Mockup test
    instance._VALID_URL = r'https?://(?:www\.)?mockup\.se/\?.*\bm=(?P<id>[^&]+)'
    match = instance._match_id(
        'http://www.mockup.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert match == 'CKDDnlCY-dhWAAqiMERd-A'


# Generated at 2022-06-12 17:49:20.627448
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.extractor_key == 'KonserthusetPlay'
    # Test that the ie is DASH
    assert ie._is_live is False
    assert ie._is_native_hls(ie._is_live) is False
    assert ie._is_native_dash(ie._is_live) is True

# Generated at 2022-06-12 17:49:24.708333
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(None, {})._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:49:29.385615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie.suitable(url)
    assert ie.IE_NAME == ie._VALID_URL

# Generated at 2022-06-12 17:49:33.805009
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert 'KonserthusetPlay' in ie.IE_NAME
    assert ie.IE_NAME == "KonserthusetPlay"
    assert ie.VALID_URL("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert ie.VALID_URL("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-12 17:49:34.717190
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:36.141236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:40.776260
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    except:
        print("test_KonserthusetPlayIE failed")


# Unit testing for real_extract method of class KonserthusetPlayIE

# Generated at 2022-06-12 17:51:55.730698
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-12 17:51:57.058968
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:07.920767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'DzekTk-Z834AkZrt-hNJ_Q'
    url = 'http://www.konserthusetplay.se/?m=' + video_id
    info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': 'Den nya tiden. Musikaliskt litet urval',
        'description': 'md5:f10e1f0030202020396a4d712d2fa827',
        'thumbnail': 're:^https?://.*$',
        'duration': 398.76,
    }
    ie = KonserthusetPlayIE()
    url_result = ie.extract(url)
    print("url_result = ")
    print(url_result)
    assert url_

# Generated at 2022-06-12 17:52:18.200236
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #### Test case 1:
    # m = CKDDnlCY-dhWAAqiMERd-A
    ie = KonserthusetPlayIE()
    ie.download('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._match_id('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:52:20.459219
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == ie.IE_DESC
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-12 17:52:21.176428
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:26.540788
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    test_object = KonserthusetPlayIE()
    result = test_object._real_extract(url)
    assert result['id'] == 'elWuEH34SMKvaO4wO_cHBw'
    assert result['title'] == 'RSPO spelar Mozart'
    assert result['description'] == 'md5:baa0c4f4e4e8c9296923c4d4e7fbf96a'
    assert result['thumbnail'] == 're:^https?://.*$'
    assert result['duration'] == 222.92

# Generated at 2022-06-12 17:52:27.423998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:30.117102
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    obj = KonserthusetPlayIE()
    assert obj.suitable(url)

test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:32.949559
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')