

# Generated at 2022-06-12 17:46:08.966209
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Create an object to test
    ie = KonserthusetPlayIE()

    # Test the constructor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:46:12.315104
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._downloader.http.add_processor('https?://csp\.picsearch\.com/', lambda x: (x, x))
    # TODO: assert something here
    ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:23.606615
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    n = KonserthusetPlayIE()
    n.IE_NAME
    n.IE_DESC
    n.valid_urls
    p = r'(?P<protocol>https?)://(?P<host>.*?)(?::(?P<port>[0-9]+))?(?P<path>.*?)'
    n.VALID_URL
    n.VALID_URL.findall("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    n.VALID_URL.findall("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")

# Generated at 2022-06-12 17:46:28.888642
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """ Test for constructor of class KonserthusetPlayIE """
    # Test for input parameters
    assert KonserthusetPlayIE._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"


# Generated at 2022-06-12 17:46:35.320302
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    fail_url = 'https://www.konserthusetplay.se/?m=4kqFOgKjhvRLiWLiNFWWSg'
    # Have to use a _download_webpage function that doesn't actually download
    # the webpage
    def _download_webpage(
            url_or_request, video_id, note=None, errnote=None, fatal=True,
            encoding=None, headers=None, data=None, query={}, expected_status=None):
        return(
            '<html><title>The title of the page</title></html>',
            {'url': 'The URL of the page'}
        )

    # Have to use a _search_regex function that always returns the passed-in
    # default value

# Generated at 2022-06-12 17:46:37.449025
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().IE_NAME == 'konserthuset:play'

# Generated at 2022-06-12 17:46:47.299851
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.__name__ == 'konserthusetplay.se'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:46:52.604193
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # should return video title, video id, video description, video extension and video duration
    video_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    kp = KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:53.850833
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('random_url', None)
 

# Generated at 2022-06-12 17:47:04.310768
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    f = {
        'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'md5': 'e3fd47bf44e864bd23c08e487abe1967',
        'info_dict': {
            'id': 'CKDDnlCY-dhWAAqiMERd-A',
            'ext': 'mp4',
            'title': 'Orkesterns instrument: Valthornen',
            'description': 'md5:f10e1f0030202020396a4d712d2fa827',
            'thumbnail': 're:^https?://.*$',
            'duration': 398.76,
        },
    }

    from json import load
    from requests import get


# Generated at 2022-06-12 17:47:37.607730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:42.228502
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Test the constructor of class KonserthusetPlayIE.
    '''
    global konserthuset_play
    konserthuset_play = KonserthusetPlayIE('http://www.konserthusetplay.se/')



# Generated at 2022-06-12 17:47:46.265568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'KonserthusetPlay'
    assert obj.ie_name() == 'KonserthusetPlay'
    assert obj.ie_description() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:47:51.309670
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthusetplay = KonserthusetPlayIE()
    assert konserthusetplay.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:52.246174
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:54.451393
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=elWuEH34SMKvaO4wO_cHBw')

# Generated at 2022-06-12 17:48:00.347246
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test invalid inputs
    invalid_urls = (
        'http://www.konserthusetplay.se',
        'http://www.konserthusetplay.se/?',
        'http://www.konserthusetplay.se/?m=',
    )
    for url in invalid_urls:
        assert not KonserthusetPlayIE._VALID_URL.search(url)

    valid_urls = (
        'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
    )
    for url in valid_urls:
        assert KonserthusetPlayIE._VALID_

# Generated at 2022-06-12 17:48:09.106716
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE
    """
    ie = KonserthusetPlayIE('CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert ie.IE_NAME == "konserthusetplay"
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Unit test

# Generated at 2022-06-12 17:48:12.689904
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    entry = KonserthusetPlayIE()
    entry.extract_video({'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'})

# Generated at 2022-06-12 17:48:14.629646
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()
    ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-12 17:48:40.261083
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("\nRunning test_KonserthusetPlayIE...")
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'konserthusetplay:play'
    ie = KonserthusetPlayIE('konserthusetplay')
    assert ie.IE_NAME == 'konserthusetplay:play'

# Generated at 2022-06-12 17:48:44.374123
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE()
    assert k._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert k._downloader is None

# Generated at 2022-06-12 17:48:49.128106
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.__name__ == 'KonserthusetPlay'

# Generated at 2022-06-12 17:48:54.017780
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:48:56.564063
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test object construction
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:59.560863
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    k = KonserthusetPlayIE(KonserthusetPlayIE, {}).new_extractor()
    k.extract(KonserthusetPlayIE._TESTS[0]['url'])

# Generated at 2022-06-12 17:49:06.529608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # ID is a part of the URL and therefore should be found in the constructor
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert(ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A')
    # Correct ID should be found from the input URL
    ie = KonserthusetPlayIE(ie._VALID_URL, ie.nie)
    assert(ie.video_id == 'CKDDnlCY-dhWAAqiMERd-A')
    return 1

# Test to see if the unit test actually works

# Generated at 2022-06-12 17:49:11.037163
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.RATING_REGEX_BAD_MATCH

# Generated at 2022-06-12 17:49:17.718770
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    # Asserts to test URL validation
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

    # Asserts to test extract information from response
    assert ie.IE_NAME == 'konserthuset-play'
    assert ie.IE_DESC == 'Konserthuset Play'
    assert ie.IE_VERSION == '0.0.1'

    # Asserts to test the response
    assert sorted(ie.ie_keywords) == sorted([
        'determine_ext', 'exit', 'float_or_none', 'int_or_none', 'url_or_none'])


# Generated at 2022-06-12 17:49:26.789817
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    class_ = KonserthusetPlayIE
    # TODO: is there an easier way to test this?
    # The problem is that we can't use utils.url_or_none, because it would access the internet
    assert class_._URL_RE_TEMPLATE.pattern == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert class_._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:50:22.521478
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Testing constructor of class KonserthusetPlayIE")
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'



# Generated at 2022-06-12 17:50:31.428080
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    #assert ie._match_id(url) == KonserthusetPlayIE._match_id(url)



if __name__ == '__main__':

    #test_KonserthusetPlayIE()

    import sys


# Generated at 2022-06-12 17:50:33.189492
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    t = KonserthusetPlayIE({})
    assert t != None


# Generated at 2022-06-12 17:50:35.407713
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert hasattr(KonserthusetPlayIE, '_VALID_URL')
    assert hasattr(KonserthusetPlayIE, '_TESTS')
    assert hasattr(KonserthusetPlayIE, '_real_extract')

# Generated at 2022-06-12 17:50:36.764875
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie._real_extract("")

# Generated at 2022-06-12 17:50:40.091038
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie_KonserthusetPlay = KonserthusetPlayIE()

    # Constructor test
    assert ie_KonserthusetPlay

# Test for class KonserthusetPlayIE

# Generated at 2022-06-12 17:50:46.316088
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .. import KonserthusetPlayIE
    with open('./test/data/KonserthusetPlayIE_test.txt') as f:
            webpage = f.read()
            KonserthusetPlayIE._real_extract(KonserthusetPlayIE(), webpage)
    #print(KonserthusetPlayIE()._VALID_URL)

# Generated at 2022-06-12 17:50:47.500466
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:50:55.434785
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert obj.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    assert obj._real_extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['title'] == 'Orkesterns instrument: Valthornen'

# Generated at 2022-06-12 17:50:58.153008
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    ie = KonserthusetPlayIE(dict())
    assert ie.suitable(url) is True

# Generated at 2022-06-12 17:53:08.894055
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    KonserthusetPlayIE()._download_json(
        'http://csp.picsearch.com/rest?e=%s&containerId=mediaplayer&i=object' %
        'KDDDnlCX-c_WAAqiMERd-A',
        'CKDDnlCY-dhWAAqiMERd-A',
        transform_source=lambda s: s[s.index('{'):s.rindex('}') + 1]
    )

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:10.453879
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:53:13.237506
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:15.297130
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
    except Exception as e:
        return False
    return True

# Generated at 2022-06-12 17:53:16.901849
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    #KonserthusetPlayIE(ExtractorError, 'C')
    assert True

# Generated at 2022-06-12 17:53:22.746372
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    '''
    Unit test for constructor of class KonserthusetPlayIE
    '''
    obj = KonserthusetPlayIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:53:29.937778
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_case = KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:31.766034
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print(repr(KonserthusetPlayIE()))

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:37.558193
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:53:39.124509
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    success_flag = True
    try:
        KonserthusetPlayIE
    except NameError:
        success_flag = False
    assert success_flag

