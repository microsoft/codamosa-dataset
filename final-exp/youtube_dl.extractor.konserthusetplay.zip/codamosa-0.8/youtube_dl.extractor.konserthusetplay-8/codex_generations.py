

# Generated at 2022-06-12 17:46:04.883741
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
	assert KonserthusetPlayIE()._VALID_URL == 'http://www.konserthusetplay.se/?m={video_id}'

# Generated at 2022-06-12 17:46:08.047567
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:12.222339
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Test KonserthusetPlayIE.__init__()
    ie = KonserthusetPlayIE()
    ie = KonserthusetPlayIE(private_constructor=True)
    # Test KonserthusetPlayIE._real_extract()
    ie._real_extract(url='https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:20.590625
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE()

    assert instance._match_id(url) == 'CKDDnlCY-dhWAAqiMERd-A'
    assert instance._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:46:22.803816
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.initialize()
    ie.get_info()

# Generated at 2022-06-12 17:46:26.005556
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie.ie_key() == KonserthusetPlayIE.ie_key()
    assert ie._VALID_URL == KonserthusetPlayIE._VALID_URL
    assert ie.BRAND == 'KonserthusetPlay'
    assert ie.SUFFIX == 'KonserthusetPlay:download'

# Generated at 2022-06-12 17:46:36.893440
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # The purpose of the unit test is to verify the correctness of the class name, module name and the name of the function that implements the functionality to be tested.
    # Currently, it is not possible to write a test that uses the constructor of a class from a different module.
    # Instead, we check that the class name matches the file name, the module name matches the file name and the function name matches the variable (object) name.
    assert KonserthusetPlayIE.__name__ == "KonserthusetPlayIE"
    assert KonserthusetPlayIE.__module__ == "youtube_dl.extractor.konserthusetplay"
    assert KonserthusetPlayIE._real_extract.__name__ == "_real_extract"

# Generated at 2022-06-12 17:46:40.139871
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")

# Generated at 2022-06-12 17:46:43.074783
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        kpIE = KonserthusetPlayIE()
    except Exception:
        assert False, "Failed to instantiate class KonserthusetPlayIE"
    assert True

# Generated at 2022-06-12 17:46:45.517744
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:47:00.025765
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ydl = KonserthusetPlayIE()
    assert(ydl._real_extract(url)['title'] == "Orkesterns instrument: Valthornen")



# Generated at 2022-06-12 17:47:02.472921
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    khp = KonserthusetPlayIE()
    # Basic testing of constructor
    assert khp

# Generated at 2022-06-12 17:47:12.572667
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    khp = KonserthusetPlayIE()
    assert khp._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:24.883304
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testcases = {
        'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A': {
            'video_id': 'CKDDnlCY-dhWAAqiMERd-A',
            'title': 'Orkesterns instrument: Valthornen',
            'description': 'md5:f10e1f0030202020396a4d712d2fa827',
            'thumbnail': 're:^https?://.*$',
            'duration': 398.76,
        }
    }
    ie = KonserthusetPlayIE()
    for url, info in testcases.items():
        ie._real_extract(url)
        assert ie.get_info(url) == info

# Generated at 2022-06-12 17:47:27.956767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.ie_key() == 'KonserthusetPlay'


# Generated at 2022-06-12 17:47:32.347483
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert 'http://www.konserthusetplay.se' in ie._VALID_URL
    assert ie.name == 'Konserthuset Play'

# Generated at 2022-06-12 17:47:37.395072
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE('www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A') != None
    assert KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw') == None

# Generated at 2022-06-12 17:47:39.641886
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test instantiation of this class
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:40.666588
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:50.261401
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE = KonserthusetPlayIE()
    TestKonserthusetPlayIE = IE.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    TestKonserthusetPlayIE = IE.suitable('http://www.konserthusetplay.se/?m=asdf')
    TestKonserthusetPlayIE = IE.suitable('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    TestKonserthusetPlayIE = IE.suitable('http://www.konserthusetplay.se/asdf/?m=asdf')

# Generated at 2022-06-12 17:48:14.941085
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie._TESTS[1]['url'] == 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'

# Generated at 2022-06-12 17:48:16.204301
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-12 17:48:16.879586
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:18.389036
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)  # check __init__ constructor


# Generated at 2022-06-12 17:48:19.659813
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        s = KonserthusetPlayIE(None)
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-12 17:48:22.011574
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:26.605419
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:27.826608
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    # Assert that constructor without parameters does not fail
    assert KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:33.368053
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Some examples of valid URL's
    # http://www.konserthusetplay.se/?m=u0-6ddb716d-4d4a-4eb2-826e-614adf73b3a7
    # http://www.konserthusetplay.se/?m=u0-b2640f42-bb13-4a3e-8f98-9dee5da5e5d5
    # http://www.konserthusetplay.se/?m=u0-f6ddbbd6-4b4d-44c8-b384-a2c9743e0dcd
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:39.886616
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    try:
        assert ie
        assert ie.IE_NAME == 'konserthusetplay'
        assert ie.IE_DESC == 'KonserthusetPlay'
        assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
        assert ie._TESTS
        assert ie._real_extract
        assert ie.IE_NAME == ie.ie_key()
    except:
        assert False, 'Unit test failed !'

# Generated at 2022-06-12 17:49:18.494122
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie



# Generated at 2022-06-12 17:49:26.536493
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay:play'
    assert ie.ie_key() != 'rspoplay:play'
    assert ie.ie_key() != 'konserthusetplay'
    assert ie.ie_key() != 'rspoplay'
    assert ie.ie_key() != 'KonserthusetPlayIE'
    assert ie.ie_key() != 'KonserthusetPlayIE()'
    assert ie.ie_key() != 'download'
    assert ie.ie_key() != 'download:'

# Generated at 2022-06-12 17:49:34.210666
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    d = KonserthusetPlayIE()
    assert d._VALID_URL == "^https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=([^&]+)$"
    assert d._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'
    assert d._TESTS[0]['info_dict']['title'] == 'Orkesterns instrument: Valthornen'
    assert d._TESTS[0]['info_dict']['description'] == 'md5:f10e1f0030202020396a4d712d2fa827'

# Generated at 2022-06-12 17:49:42.182542
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.suitable('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    # Test _TESTS from above (all _TESTS)
    for _TEST in ie._TESTS:
        url = _TEST['url']
        assert ie.suitable(url), "%s not suitable" % url
        try:
            ie.extract(_TEST['url'])
        except Exception:
            assert False, "%s throws exception!" % url

# Generated at 2022-06-12 17:49:43.510434
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


# Generated at 2022-06-12 17:49:46.692081
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie.download(url)
    ie.extract(url)

# Generated at 2022-06-12 17:49:48.734075
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None
    assert ie.ie_key() == 'KonserthusetPlay'

# Generated at 2022-06-12 17:49:49.530664
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:51.909664
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert ie.suitable(url)

# Generated at 2022-06-12 17:49:52.593058
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:52.593007
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:51:55.893486
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    constructor_test(KonserthusetPlayIE, [
        {
            'url': 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
            'only_matching': True,
        },
        {
            'url': 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw',
            'only_matching': True,
        },
    ])

# Generated at 2022-06-12 17:51:56.725060
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert instance

# Generated at 2022-06-12 17:51:57.535380
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.extract()

# Generated at 2022-06-12 17:51:59.170634
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'Konserthuset Play'

# Generated at 2022-06-12 17:52:03.691462
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Unit test for private function _real_extract of class KonserthusetPlayIE
    def test__real_extract(self, url):
        def _download_webpage(url, video_id):
            webpage = ""


# Generated at 2022-06-12 17:52:04.612464
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:52:07.885682
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', {'skip_download': True})


# Generated at 2022-06-12 17:52:14.759540
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    instance = KonserthusetPlayIE(url)
    if video_id == instance._match_id(url):
        print('Successfully created KonserthusetPlayIE instance')


# Generated at 2022-06-12 17:52:16.616672
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()