

# Generated at 2022-06-12 17:46:08.772913
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie._downloader is not None

# Generated at 2022-06-12 17:46:10.835715
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        # Import error if not installed
        from ..extractors import KonserthusetPlayIE
    except ImportError:
        pass
    # Should not throw exception
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:21.245674
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    sample_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    print("Testing KonserthusetPlayIE.__init__(%s)" % sample_url)
    test_object = KonserthusetPlayIE(sample_url)

    # test url property
    print("  KonserthusetPlayIE.url == %s" % sample_url)
    assert test_object.url == sample_url

    # test _VALID_URL
    print("  KonserthusetPlayIE._VALID_URL == %s" % test_object._VALID_URL)
    assert test_object._VALID_URL == KonserthusetPlayIE._VALID_URL

    # test _TESTS

# Generated at 2022-06-12 17:46:22.902125
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert(obj)

# Generated at 2022-06-12 17:46:23.788690
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:36.015600
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    test_url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    info = ie.extract(test_url)
    #print(info)

    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie._TESTS[0]['url'] == test_url
    assert ie._TESTS[0]['md5'] == 'e3fd47bf44e864bd23c08e487abe1967'

# Generated at 2022-06-12 17:46:39.715619
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw')
    ie._real_extract()

# Generated at 2022-06-12 17:46:42.676098
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("Inside test_KonserthusetPlayIE")
    KonserthusetPlayIE()

# Unit test function for class KonserthusetPlayIE

# Generated at 2022-06-12 17:46:43.699007
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'

# Generated at 2022-06-12 17:46:52.202936
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)')

# Generated at 2022-06-12 17:47:16.919068
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:26.895587
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE()
    ie._download_webpage = lambda url, video_id, note=None, errnote=None, fatal=True, data=None, headers=None, query=None: '<html></html>'
    ie._download_json = lambda url, video_id, transform_source=None: {}
    ie._search_regex = lambda regex, html, name, default=None, fatal=True: ''
    ie._match_id = lambda url: video_id

# Generated at 2022-06-12 17:47:29.367279
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    konserthuset_ie = KonserthusetPlayIE()
    if not konserthuset_ie:
        raise Exception('Failed to construct KonserthusetPlayIE')

# Generated at 2022-06-12 17:47:32.013268
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie

# Generated at 2022-06-12 17:47:36.791305
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.extract_info(
        "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A").get('id') == "CKDDnlCY-dhWAAqiMERd-A"

# Generated at 2022-06-12 17:47:40.571310
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert('KonserthusetPlayIE' in globals())
    assert(KonserthusetPlayIE)
    assert(KonserthusetPlayIE.__name__ == 'KonserthusetPlayIE')

# Generated at 2022-06-12 17:47:42.734749
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test if the class constructor works as expected
    KonserthusetPlayIE()




# Generated at 2022-06-12 17:47:46.708726
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test = KonserthusetPlayIE()
    assert test._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:47:51.503327
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Sample URL for direct download
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url)
    assert ie.url == url
    assert ie.__class__.__name__ in ie.class_name


# Generated at 2022-06-12 17:47:53.042376
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE().get_domain() == 'www.konserthusetplay.se'

# Generated at 2022-06-12 17:48:42.241585
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert KonserthusetPlayIE._VALID_URL == KonserthusetPlayIE._TESTS[0]['url']       # Test _VALID_URL
    ie = KonserthusetPlayIE(url)
    assert ie._VALID_URL == KonserthusetPlayIE._TESTS[0]['url']                       # Test _VALID_URL
    assert ie._VALID_URL == 'http://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'


# Generated at 2022-06-12 17:48:53.218138
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    testurl = u'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE().get_info(testurl)
    assert ie.get('id') == u'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.get('title') == u'Orkesterns instrument: Valthornen'
    assert ie.get('duration') == 398.76
    assert ie.get('description') == u'md5:f10e1f0030202020396a4d712d2fa827'
    assert ie.get('thumbnail') is not None
    assert ie.get('subtitles') == {}

# Generated at 2022-06-12 17:49:02.481215
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # To test this class an instance of the class must be created.
    # As the _real_extract method uses the _match_id to create the video_id, this must be created.
    # To have a valid url, a url has been reused from another class.
    url = 'https://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    expected = {
        'valid': True,
        'id': 'elWuEH34SMKvaO4wO_cHBw'
    }
    kpIE = KonserthusetPlayIE()
    assert kpIE._match_id(url) == expected['id']


# Generated at 2022-06-12 17:49:03.605931
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert(ie)

# Generated at 2022-06-12 17:49:06.404421
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert instance.video_id=='CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:49:07.079901
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:49:12.472044
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'konserthusetplay'
    assert ie.ie_name() == 'konserthusetplay'
    assert ie.ie_description() == 'konserthusetplay.se'
    assert ie.ie_version() != None


# Generated at 2022-06-12 17:49:14.044090
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-12 17:49:17.062001
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    inst = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert inst is not None


# Generated at 2022-06-12 17:49:27.296932
# Unit test for constructor of class KonserthusetPlayIE

# Generated at 2022-06-12 17:51:22.927810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE.__name__ == "KonserthusetPlayIE"

# Generated at 2022-06-12 17:51:32.667730
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('www.konserthusetplay.se', '?m=CKDDnlCY-dhWAAqiMERd-A')
    #Testing if url is extracted
    url = ie._search_regex(ie._VALID_URL, 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A', 'url')
    assert url == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:51:35.022194
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    I = KonserthusetPlayIE("konserthusetplay", "KonserthusetPlayIE")

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:36.494230
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:40.146815
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    video_id = 'CKDDnlCY-dhWAAqiMERd-A'
    k = {'url': url, 'video_id': video_id}
    assert KonserthusetPlayIE(k).video_id == video_id

# Generated at 2022-06-12 17:51:41.639286
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:42.156331
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-12 17:51:44.904627
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None


# Generated at 2022-06-12 17:51:45.733307
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()

# Generated at 2022-06-12 17:51:48.356988
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    a = KonserthusetPlayIE()
    assert isinstance(a, InfoExtractor)

# Generated at 2022-06-12 17:54:00.973757
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    input = (
        r'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        r'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        r'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
        r'https://www.rspoplay.se/?m=CKDDnlCY-dhWAAqiMERd-A',
    )
    expected_return = KonserthusetPlayIE(input)
    assert isinstance(expected_return, type(KonserthusetPlayIE))

# Generated at 2022-06-12 17:54:05.430967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Tests of constructor of class KonserthusetPlayIE"""
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:54:05.920225
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    pass

# Generated at 2022-06-12 17:54:08.240816
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    import doctest
    doctest.testmod(
        module='__main__',
        extraglobs={'KonserthusetPlayIE': KonserthusetPlayIE})

# Generated at 2022-06-12 17:54:10.982430
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.name == 'konserthuset-play'
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.available == False



# Generated at 2022-06-12 17:54:12.532767
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE()
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-12 17:54:16.921252
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    print("test_KonserthusetPlayIE")
    ie = KonserthusetPlayIE()
    ie.extract("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    ie.extract("http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw")
    return

if __name__ == "__main__":
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:54:18.601295
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    # Need to check if the object is of type (class) InfoExtractor
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:54:20.751028
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    test_url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    k = KonserthusetPlayIE()
    k._match_id(test_url)


# Generated at 2022-06-12 17:54:23.067146
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    assert ie.IE_NAME == 'konserthuset_play'
    assert ie.IE_DESC == 'Konserthuset Play'