

# Generated at 2022-06-12 17:46:07.310568
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.__class__.__name__ == 'KonserthusetPlayIE'

# Generated at 2022-06-12 17:46:10.191513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()
    assert obj.ie_key() == 'konserthusetplay'
    assert obj.ie_name() == 'konserthusetplay'
    assert obj.valid()
    assert not obj.suitable()

# Generated at 2022-06-12 17:46:12.626549
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # The only reason for testing the constructor is to see if it instantiates
    # without raising any exception
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:46:18.095066
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    r = KonserthusetPlayIE('http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw', '0')
    assert r.id == 'elWuEH34SMKvaO4wO_cHBw'



# Generated at 2022-06-12 17:46:23.739513
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    assert KonserthusetPlayIE(KonserthusetPlayIE._VALID_URL)._VALID_URL == "https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)"

# Generated at 2022-06-12 17:46:28.629653
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    IE = KonserthusetPlayIE()
    test_KonserhusetPlayIE = True
    assert test_KonserhusetPlayIE == True

# Generated at 2022-06-12 17:46:40.810782
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test for 'https://www.konserthusetplay.se/'
    _test_konserthusetplayie_url_1 = 'https://www.konserthusetplay.se/'
    _test_konserthusetplayie_id_1 = 'KonserthusetPlayIE'
    _test_konserthusetplayie_class_1 = KonserthusetPlayIE
    _test_konserthusetplayie_intance_1 = _test_konserthusetplayie_class_1(_test_konserthusetplayie_id_1)
    assert _test_konserthusetplayie_intance_1.ie_key() == _test_konserthusetplayie_id_1
    assert _test_konserthusetplayie

# Generated at 2022-06-12 17:46:42.936723
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://rspoplay.se/?m=elWuEH34SMKvaO4wO_cHBw'
    KonserthusetPlayIE(KonserthusetPlayIE._create_ie(), {'url': url}, {})._real_extract(url)

# Generated at 2022-06-12 17:46:45.133810
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:46:47.200451
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.SUCCESS
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-12 17:47:15.372671
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .common import InfoExtractor
    from .konserthusetplay import KonserthusetPlayIE
    kpIE = KonserthusetPlayIE("csp.picsearch.com", "https://example.com")
    assert isinstance(kpIE, type(InfoExtractor("csp.picsearch.com", "https://example.com")))
    assert kpIE.ie_key() == "KonserthusetPlay"


# Generated at 2022-06-12 17:47:26.165950
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    from .test_konserthuset_play_ie import test_konserthusetPlayIE
    from .test_konserthuset_play_ie import test_konserthusetPlayIEExtraction
    from .test_konserthuset_play_ie import test_suite
    from .common import TestIE
    from .common import unittest
    from .common import unittest_main
    import sys
    import os
    import unittest

    # https://docs.python.org/3/library/unittest.html#organizing-test-code
    # loadTestsFromName() (and all the other methods for loading tests) will
    # search through the named module and load tests according to the
    # test discovery criteria.

# Generated at 2022-06-12 17:47:28.129510
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:39.798944
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    before_regex='https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    _VALID_URL = r'%s' % before_regex

# Generated at 2022-06-12 17:47:50.515885
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():

    ie = KonserthusetPlayIE()

    ie._VALID_URL = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:47:51.711456
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Example: Create an extractor class
    return KonserthusetPlayIE()

# Generated at 2022-06-12 17:47:55.746807
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:06.010474
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    konserthuset_play_ie = KonserthusetPlayIE()

    # Test creation of object
    assert isinstance(konserthuset_play_ie, InfoExtractor), "Object creation failed"

    # Test that URL works
    assert konserthuset_play_ie._match_id(url) == "CKDDnlCY-dhWAAqiMERd-A", "Failed to match URL"

    # Test that URL works
    assert konserthuset_play_ie._real_extract(url)['title'] == 'Orkesterns instrument: Valthornen', "Failed to download video"

# Generated at 2022-06-12 17:48:11.895036
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.VIDEO_URL == ie._VALID_URL
    ie._real_extract(url)

# Generated at 2022-06-12 17:48:13.051581
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    assert str(instance) == '<KonserthusetPlayIE>'

# Generated at 2022-06-12 17:48:38.784653
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:48:44.464624
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')
    print(ie._match_id(ie._VALID_URL))
    assert ie._match_id(ie._VALID_URL) == 'CKDDnlCY-dhWAAqiMERd-A'

test_KonserthusetPlayIE()



# Generated at 2022-06-12 17:48:54.448967
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    instance = KonserthusetPlayIE()
    expected_id = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert instance._VALID_URL == expected_id
    expected_url = 'http://csp.picsearch.com/rest?e=1560001077.0159&containerId=mediaplayer&i=object'
    assert instance._download_json(expected_url) == True
    # How to test _real_extract?
    #assert instance._real_extract(expected_url) == ''

if __name__ == '__main__':
    test_KonserthusetPlayIE()

# Generated at 2022-06-12 17:48:58.922313
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    try:
        KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A", 1)
    except Exception:
        pass

# Generated at 2022-06-12 17:49:02.242998
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE(): 
    obj_KonserthusetPlayIE = KonserthusetPlayIE("http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A")
    assert obj_KonserthusetPlayIE != None

# Generated at 2022-06-12 17:49:12.721650
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # test a valid URL
    valid_url = "http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A"
    assert KonserthusetPlayIE(valid_url)._VALID_URL == \
        r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    # test an invalid URL
    invalid_url = "http://www.youtube.com"
    assert KonserthusetPlayIE(invalid_url)._VALID_URL is None

# Generated at 2022-06-12 17:49:15.233518
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # testing of class
    info = KonserthusetPlayIE()
    print('Test: ' + info)
    assert info is not None
# end Unit test for constructor of class KonserthusetPlayIE



# Generated at 2022-06-12 17:49:16.530771
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie is not None

# Generated at 2022-06-12 17:49:21.807988
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # Test with both URLs that work with this IE
    for test_url in (KonserthusetPlayIE._TESTS[0]['url'], KonserthusetPlayIE._TESTS[1]['url']):
        # Test if constructor creates instance of class KonserthusetPlayIE
        try:
            KonserthusetPlayIE(test_url)
        except TypeError:
            # If TypeError is raised, instance is not created
            assert False

# Generated at 2022-06-12 17:49:27.297336
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """Unit test to make sure constructor of class KonserthusetPlayIE works"""
    # The constructor for KonserthusetPlayIE does not need any arguments and does not return any value
    # So we just confirm that the class KonserthusetPlayIE is defined without any error
    assert "KonserthusetPlayIE" in globals()


# Generated at 2022-06-12 17:50:26.988761
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.test(ie.IE_NAME, ie._VALID_URL)
    assert ie.test(ie.IE_NAME, ie._TESTS[0]['url'])

# Generated at 2022-06-12 17:50:28.827289
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)
    return True


# Generated at 2022-06-12 17:50:29.937270
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    e = KonserthusetPlayIE()
    assert e

# Generated at 2022-06-12 17:50:32.418928
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie != None

# Generated at 2022-06-12 17:50:35.769952
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    obj = KonserthusetPlayIE()

# Generated at 2022-06-12 17:50:44.901441
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:50:52.128275
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.ie_name() == 'KonserthusetPlay'
    assert ie.description() == "The Swedish Concert Hall's online video service"
    assert ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')['id'] == 'CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:50:53.665476
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:50:58.117641
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    extractor = KonserthusetPlayIE()
    seen_urls = set()
    for url in extractor._TESTS.keys():
        url_dict =  extractor.url_result(url)
        assert url_dict['id'] != None
        assert url_dict['url'] not in seen_urls
        seen_urls.add(url_dict['url'])

# Generated at 2022-06-12 17:50:59.753736
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    # basic constructor test
    KonserthusetPlayIE(None, None)

# Generated at 2022-06-12 17:53:09.832922
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    IE_object = KonserthusetPlayIE()

    # These are valid URLs
    assert IE_object._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert IE_object._TESTS[0]['url'] == 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

    # These are invalid URLs
    assert IE_object._TESTS[1]['only_matching'] == True

# Generated at 2022-06-12 17:53:11.616975
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    KonserthusetPlayIE()


# Unit tests for KonserthusetPlayIE._real_extract()

# Generated at 2022-06-12 17:53:14.961995
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    ie.extract('http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A')

# Generated at 2022-06-12 17:53:21.616250
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Unit test for constructor of class KonserthusetPlayIE.
    See https://github.com/rg3/youtube-dl/issues/9085
    """
    konserthusetIE = KonserthusetPlayIE()
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'

# Generated at 2022-06-12 17:53:28.710983
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    url = 'http://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    ie = KonserthusetPlayIE(url = url)
    assert ie.konserthuset_play_url == 'https://www.konserthusetplay.se/?m=CKDDnlCY-dhWAAqiMERd-A'
    assert ie.konserthuset_play_video_id == 'CKDDnlCY-dhWAAqiMERd-A'
    assert ie.konserthuset_play_url_regex == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'

# Generated at 2022-06-12 17:53:30.660408
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.ie_key() == 'KonserthusetPlay'
    assert ie.video_id
    assert ie.formats

# Generated at 2022-06-12 17:53:31.425264
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()

# Generated at 2022-06-12 17:53:33.969246
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    """
    Simple unit test for constructor of class KonserthusetPlayIE
    """
    k = KonserthusetPlayIE()
    assert k._VALID_URL == KonserthusetPlayIE._VALID_URL

# Generated at 2022-06-12 17:53:36.758319
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert isinstance(ie, KonserthusetPlayIE)


# Generated at 2022-06-12 17:53:44.782999
# Unit test for constructor of class KonserthusetPlayIE
def test_KonserthusetPlayIE():
    ie = KonserthusetPlayIE()
    assert ie.IE_NAME == 'KonserthusetPlay'
    assert ie.IE_DESC == 'konserthusetplay.se Mediacloud'
    assert ie._VALID_URL == r'https?://(?:www\.)?(?:konserthusetplay|rspoplay)\.se/\?.*\bm=(?P<id>[^&]+)'
    assert ie.IE_DESC == 'konserthusetplay.se Mediacloud'

if __name__ == '__main__':
    test_KonserthusetPlayIE()