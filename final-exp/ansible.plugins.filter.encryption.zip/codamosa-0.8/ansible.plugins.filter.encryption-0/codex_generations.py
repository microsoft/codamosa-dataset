

# Generated at 2022-06-22 14:11:54.601536
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:03.167939
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:12.671829
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:25.273156
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    ''' Unit test for function do_vault
    :return:
    '''

# Generated at 2022-06-22 14:12:29.784750
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert isinstance(do_vault('test_string', 'password'), AnsibleVaultEncryptedUnicode)
    assert isinstance(do_vault('test_string', 'password', wrap_object=False), str)


# Generated at 2022-06-22 14:12:41.100621
# Unit test for function do_unvault
def test_do_unvault():
    data = "this is not a secret"
    secret = "vault_secret"
    encrypted_data = do_vault(data, secret)
    decrypted_data = do_unvault(encrypted_data, secret)
    assert decrypted_data == data
    data = "this is secret without vaultid"
    encrypted_data = do_vault(data, secret)
    decrypted_data = do_unvault(encrypted_data, secret, vaultid="vault_secret")
    assert decrypted_data == data
    data = "this is another secret"
    secret = "different_vault_secret"
    encrypted_data = do_vault(data, secret)
    decrypted_data = do_unvault(encrypted_data, secret, vaultid="different_vault_secret")
    assert decrypted_data

# Generated at 2022-06-22 14:12:54.088327
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import (is_encrypted)

    # vault_data is encrypted with the password "MySecretPassword"
    vault_data = b'$ANSIBLE_VAULT;1.1;AES256\n'
    vault_data += b'356638393361633531353265313363376531356564366630633039343135356334626466393232366\n'
    vault_data += b'3336623634346336316662366564393834626434373566343261666233313036613162326431306231\n'
    vault_data += b'6632623762323731326132323061313437616238346366646366310a61633239653860333165333531\n'


# Generated at 2022-06-22 14:13:00.117851
# Unit test for function do_vault
def test_do_vault():
    filter_name = filter_func.__name__
    filter_func = globals().get(filter_name)
    filter_func = filter_func.__get__(object)
    filter_value = filter_func(None, "password", salt=None, wrap_object=False)
    assert filter_value
    assert not isinstance(filter_value, Undefined)
    pdb.set_trace()


# Generated at 2022-06-22 14:13:04.990894
# Unit test for function do_vault
def test_do_vault():
    vaulted = do_vault('data', 'secret', salt='salt', wrap_object=False)
    assert vaulted.startswith('$ANSIBLE_VAULT')
    assert not isinstance(vaulted, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-22 14:13:17.861243
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:31.704103
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.module_utils.crypto import constant_time_compare
    from ansible.parsing.vault import VaultLib
    import base64

    vault = '$ANSIBLE_VAULT;1.1;AES256'
    secret = 'insecure'

# Generated at 2022-06-22 14:13:32.710758
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-22 14:13:36.650911
# Unit test for function do_vault
def test_do_vault():
    data = "Test string 123"
    secret = "secret"

    vault = do_vault(data, secret)
    assert len(vault) > 0
    assert vault != data


# Generated at 2022-06-22 14:13:47.315346
# Unit test for function do_unvault
def test_do_unvault():
    t_secret = '$ANSIBLE_VAULT;1.1;AES256\n353038663964366636303962333863383762353733313537393432303537376533346137633739\n333764373666393637666434353334336332346465353464366134353865326439306330346432\n3637663535653330343131363335393461633666626538353339306466363435663830360a3266\n65323331633637343931306535303336383738666463340a\n'.encode('utf-8')
    t_vaultid = 'filter_default'
    t_data = '12345'

# Generated at 2022-06-22 14:14:00.272333
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.compat import is_py3

    vault_secret = 'x' * 30
    vault_data = b'test string'
    vault_result = '$ANSIBLE_VAULT;1.1;AES256\n' \
                   '61346539366139376231383537343062373262333666653331333965613866366533303464363134\n' \
                   '39633961623739326238633166623133663539303366303864656233343534306538333830356430\n' \
                   '32626464656538663835336365616232646435333964373530613730313231346266343738373864\n' \
                   '3433\n'

# Generated at 2022-06-22 14:14:10.254754
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import is_encrypted

    assert(isinstance(do_vault('I am plain text', 'secret'), string_types))
    assert(isinstance(do_vault('I am plain text', VaultSecret(to_bytes('secret'))), string_types))
    assert(is_encrypted(do_vault('I am plain text', VaultSecret(to_bytes('secret')),
                                 wrap_object=True)))


# Generated at 2022-06-22 14:14:13.551180
# Unit test for function do_unvault
def test_do_unvault():
    try:
        c = FilterModule().filters()
        print(c['unvault'](None, "1234"))
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-22 14:14:18.711934
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    vaultid = "$ANSIBLE_VAULT;1.1;AES256"
    assert do_unvault(secret, vaultid) == secret

# Generated at 2022-06-22 14:14:29.555082
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;default3522185074779413921\n", "test") == "test"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;default\n", "test") == "test"
    assert do_unvault("$ANSIBLE_VAULT;1.0;AES256;default\n", "test") == "test"
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;default;3522185074779413921\n", "test") == "test"

# Generated at 2022-06-22 14:14:38.929440
# Unit test for function do_vault
def test_do_vault():
    import warnings
    warnings.filterwarnings("ignore", category=ResourceWarning)
    secret = 'test_secret'

# Generated at 2022-06-22 14:14:44.185931
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;1.2;AES256' in do_vault('mystring', 'mysecret')



# Generated at 2022-06-22 14:14:45.432046
# Unit test for function do_vault
def test_do_vault():
    pass



# Generated at 2022-06-22 14:14:56.904413
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import MagicMock
    from ansible.parsing.vault import VaultLib
    import os

    class MockRegexMatch(object):
        start = 0
        end = 0

        def group(self, num):
            return mock_regexOutput

        def groups(self):
            return mock_regexOutput

    class MockRegex(object):
        def match(input_string, regex_string):
            if input_string == vault_password and regex_string == VaultLib.vault_password_regex:
                return MockRegexMatch()
            else:
                return False

    mock_regexOutput = "vault:vault_password"

    vault_data1 = "vault:vault_password"

# Generated at 2022-06-22 14:15:08.970018
# Unit test for function do_unvault
def test_do_unvault():
    ''' This function checks whether the encrypted data is decrypted properly '''
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          353563366536366326162313736336163656338613239626132653134346161306566353736386430\n          34646365633862383539396232396133393266626539313662303065393634656538326462313938\n          65393533353763613235663539633462376161373839383132613434666163396233346234313366\n          65326532353163326637346134393737633135\n"
    secret = "password"

# Generated at 2022-06-22 14:15:18.036588
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = '123456'
    vl = VaultLib()
    vs = VaultSecret(to_bytes(secret))
    vault_str = vl.encrypt(u'password', vs, vaultid)

    # Test unvault function with valid secret
    data = do_unvault(vault_str, secret, vaultid)
    assert data == 'password'

    # Test unvault function with invalid secret
    try:
        do_unvault(vault_str, 'invalid', vaultid)
    except AnsibleFilterError as e:
        assert "Unable to decrypt: Decryption failed" in to_native(e)

# Generated at 2022-06-22 14:15:21.434117
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib

    vault_secret = VaultLib().encrypt('foo', VaultSecret('bar'))
    result = do_vault('baz', 'bar')
    assert vault_secret == result



# Generated at 2022-06-22 14:15:33.996169
# Unit test for function do_vault
def test_do_vault():
    # Testing for correct functionality
    secret = "sudo is for cowards"
    data = "hello world"
    vault = do_vault(data, secret)

    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    if to_native(vl.decrypt(vault)) != data:
        raise AssertionError("Encryption failed: %s" % to_native(vl.decrypt(vault)))

    # Testing for incorrect parameter types
    try:
        do_vault(True, secret)
        raise AssertionError("do_vault didn't throw an exception when it was supposed to")
    except AnsibleFilterTypeError as e:
        print(str(e))


# Generated at 2022-06-22 14:15:43.728717
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:48.748453
# Unit test for function do_unvault
def test_do_unvault():
    data = 'test'
    secret = 'secret'
    vaultid = 'filter_default'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)


# Generated at 2022-06-22 14:15:56.144611
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault("$ANSIBLE_VAULT;1.1;AES256\n31633139323230397b3934633337343764386562356237653936666532373737393464663836323566\nb24d9f0e7ab29b9a9b91fde29f50d7d8a6a\n", "secret123")
    assert result == "abcd1234"


# Generated at 2022-06-22 14:16:07.582305
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Template
    import os

    secret = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    if not secret:
        secret = os.environ.get('ANSIBLE_VAULT_PASSWORD', None)

    assert(secret)

    filter = FilterModule()
    assert(filter.filters()['unvault'](None, secret))
    assert(not filter.filters()['unvault'](None, None))

# Generated at 2022-06-22 14:16:12.183358
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;filter_default\n353661663736303638663737386639336364653639343538343833346531636537366465656634\n663363306664363465323263616632643763356336353664653430643966346436383564623361\n626565623263386335393763666465653231333139653839366239613234316166393330663362\n3738353837632d0a", "password", "filter_default") == "Hello"

# Generated at 2022-06-22 14:16:23.953404
# Unit test for function do_unvault
def test_do_unvault():
    data = "this is my secret"

    # Set up vault password file
    tellus_vault_file = open(".tellus_vault_file", "w")
    tellus_vault_file.write("vault_password_file=.tellus_vault_file\n")
    tellus_vault_file.write("vault_password = \"password\"")
    tellus_vault_file.close

    # Encrypt data
    data_vault = do_vault(data, "password", vaultid="tellus_vault_file", wrap_object=True)

    # Decrypt data
    if is_encrypted(data_vault):
        data_unvault = do_unvault(data_vault, "password", vaultid="tellus_vault_file")

# Generated at 2022-06-22 14:16:36.721020
# Unit test for function do_unvault
def test_do_unvault():

    text_1 = "This is a test"
    encrypted_text_1 = b"$ANSIBLE_VAULT;1.2;AES256;junk\n650835852e3f3caf3f47dfc4eb4e4b4c733de4f769d2c354a8d7a3c1fca21a02\n"

    assert do_unvault(encrypted_text_1, "junk") == text_1

    text_1 = "This is a test"

# Generated at 2022-06-22 14:16:47.527013
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:56.973121
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import subprocess
    import json

    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_secret = 'my-secret-password'
    test_vaultid = 'test'
    test_password_file = '/tmp/vault-password-file.txt'

    with open(os.path.join(os.path.dirname(test_dir), 'vault-data.json'), 'r') as f:
        vault_data = json.load(f)

    with open(os.path.join(os.path.dirname(test_dir), 'vault-data-with-salt.json'), 'r') as f:
        vault_data_with_salt = json.load(f)


# Generated at 2022-06-22 14:17:10.029691
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, 'secret_key') == None
    assert do_unvault('test_string', 'secret_key') == 'test_string'

# Generated at 2022-06-22 14:17:17.964058
# Unit test for function do_vault

# Generated at 2022-06-22 14:17:27.707887
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    vs1 = VaultSecret(to_bytes('the answer'))
    vl1 = VaultLib()
    test_str = vl1.encrypt(b'42', vs1, "filter_default", b'f7rkrwbsrz9gjkk')

# Generated at 2022-06-22 14:17:39.185013
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:48.992957
# Unit test for function do_unvault
def test_do_unvault():
    # Unencrypted String
    test_string = 'This is an unencrypted String'
    assert do_unvault(test_string, 'my_secret') == 'This is an unencrypted String'

    # Encrypted String
    secret = 'my_secret'
    salt = 'thisismysalt'
    vaultid = 'vaultid'
    vault = do_vault(test_string, secret, salt, vaultid)
    assert do_unvault(vault, secret, vaultid) == 'This is an unencrypted String'



# Generated at 2022-06-22 14:18:00.674567
# Unit test for function do_unvault
def test_do_unvault():
    import yaml

# Generated at 2022-06-22 14:18:13.921720
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:27.046673
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:31.974733
# Unit test for function do_vault
def test_do_vault():

    secret = 'changeme'
    vault = do_vault("mysecret", secret, vaultid='test_vault', wrap_object=False)
    if vault == '':
        assert False
    return vault


# Generated at 2022-06-22 14:18:39.489952
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import yaml

    with open(os.path.join(os.path.dirname(__file__), 'vault.yaml')) as vault_yaml:
        secrets = yaml.safe_load(vault_yaml)

    for secret, vault_string in secrets.items():
        for vault_id in ("default", "filter_default"):
            assert vault_string == do_vault(do_unvault(vault_string, secret, vaultid=vault_id), secret, vaultid=vault_id)

# Generated at 2022-06-22 14:18:46.199218
# Unit test for function do_vault
def test_do_vault():
    # Tests for properly defined data
    data = "Ansible"
    secret = "Ansible_2020"
    vaultid = "test_vault"
    salt = "test_salt"

# Generated at 2022-06-22 14:18:55.047551
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault('value_to_encrypt', 'secret') == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n35363262386365383831663933306533626636613734313532633661323237663531313230623534\n39646637306439353531623232653962626162333761316665663834396337623735396666613166\n37336162336636373435616362393539336634313139663533386661323238666462386566')


# Generated at 2022-06-22 14:19:01.440219
# Unit test for function do_vault
def test_do_vault():
    test_key = 'secret'
    test_salt = 'salt'
    test_vaultid = 'id'
    test_data = 'data'

    test_vault = do_vault(test_data, test_key, test_salt, test_vaultid)
    test_data2 = do_unvault(test_vault, test_key, test_vaultid)

    assert test_data == test_data2



# Generated at 2022-06-22 14:19:12.015572
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:27.000032
# Unit test for function do_vault
def test_do_vault():
    # set up a VaultLib object with a mock KeyringAccessor object which provides secrets
    vl = VaultLib()
    vl.keyring_accessor = MockKeyringAccessor()

    # create a vault
    key = 'secret'
    vault_id = 'salt'
    data = 'password'
    vault = do_vault(data, key, vaultid=vault_id)

    # make sure the vault is created correctly

# Generated at 2022-06-22 14:19:32.850900
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("passw0rd", "ansible", "AQAAAAEAACcQAAAAEIf9X/JvHMA5o/ueYxeAaZzjVrymh1mSfV7Un0jK9uPQx4a0b4YnVGwPaPZK7CfLlw==")


# Generated at 2022-06-22 14:19:44.574419
# Unit test for function do_unvault
def test_do_unvault():
    print("Testing function do_unvault()")
    print("Success: True")

    # Test with a vault string
    vault = "$ANSIBLE_VAULT;1.1;AES256;ansible_test11334444444444444444444444444444$dHJ5ICAgICAgICAgICAgICAgICAgc3RyaW5n$W3e1Zup2QkdCtPZcvLSncBR0V8Rwf83GcVLAywkloMo="
    result = do_unvault(vault, 'ansible_test11334444444444444444444444444444')
    assert result == "try string"
    print("Testing: Given vault is a string")
    print("Expected: try string")

# Generated at 2022-06-22 14:19:53.447082
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = "test_secret"
    test_vaultid = "test_vaultid"
    test_data = "test_data"

    test_vault = do_vault(test_data, test_secret, vaultid=test_vaultid, wrap_object=True)
    test_unvault = do_unvault(test_vault, test_secret, vaultid=test_vaultid)

    assert test_data == test_unvault

# Generated at 2022-06-22 14:20:05.652365
# Unit test for function do_vault
def test_do_vault():

    data = "abcd"
    secret = "secret"
    salt = "salt"
    vaultid = "test"

    # Test valid encryption

# Generated at 2022-06-22 14:20:17.951811
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:21.072388
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)
    assert vault.startswith(b'$ANSIBLE_VAULT')


# Generated at 2022-06-22 14:20:33.648056
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "myplaybook"
    vaule_sample = "$ANSIBLE_VAULT;1.1;AES256;myplaybook\n35656630383135386563396139656233623839653166363837383735386134663239393738353866\n65616162663261623334316238363035363465396132333761313439376466303539616363376364\n3866383864383761646265343262633731333436636236633862666433636326262623030643534\n33333762333835366636346533383638663036376335633065"
    decrypted_str = "my_password"
    assert do_unvault

# Generated at 2022-06-22 14:20:44.702704
# Unit test for function do_vault
def test_do_vault():
    secret = 'SAfePassword'
    data = 'secret password'
    vault = '$ANSIBLE_VAULT;1.1;AES256;filter_default\n635361383435336138303366383665653237613164633831623262633465393063643536663339\n393536623339616666653939643830633264383232666535393630373433633862366264393866\n383437316161336565313439626437663239343039653539616233663566363762626461646430\n6439363833383734626330626338\n'
    salt = 'D6/b_a7^FwB3q0=='
    assert do_vault(data, secret)

# Generated at 2022-06-22 14:20:48.599789
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'Unvaulted'
    salt = None
    vaultid = 'test_vault'
    wrap_object = True

    result = do_vault(data, secret, salt=salt, vaultid=vaultid, wrap_object=wrap_object)

    assert (type(result)) == AnsibleVaultEncryptedUnicode
    assert result != data


# Generated at 2022-06-22 14:20:55.057643
# Unit test for function do_unvault
def test_do_unvault():
    secret = "testkey123"
    vaultid = "test_vault"
    data = "testdata123"

    assert do_unvault(do_vault(data, secret, vaultid), secret, vaultid) == data

# Generated at 2022-06-22 14:21:06.636993
# Unit test for function do_vault
def test_do_vault():
    ''' Test do_vault function '''
    secret = "test"
    data = "test"
    result = do_vault(data, secret)

# Generated at 2022-06-22 14:21:19.569110
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib, VaultSecret

    # Test all possible combinations of unicode, byte strings and objects
    # for secret, vault and data
    #
    # If any of the values is not an instance of unicode/byte string, then
    # decrypt will throw an error
    secret_string = u"secret_string"
    vault_string = u"vault_string"
    data_string = u"data_string"

    vl = VaultLib()
    secret = to_bytes(secret_string)
    vs = VaultSecret(secret)
    vault = vl.encrypt(to_bytes(data_string), vs, 'vault_id')
    data = vl.decrypt(vault)
    assert secret_string == to_native(secret)
    assert vault_string == to_

# Generated at 2022-06-22 14:21:27.834749
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret

    secret = 'mysecret'
    vaultid = 'filter_default'
    test_data = 'test_data'

    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    result = to_native(vl.encrypt(test_data, vs, vaultid))
    test_result = do_unvault(result, secret, vaultid)
    assert test_result == test_data

# Generated at 2022-06-22 14:21:41.198342
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_vault_string', 'test_password') == '$ANSIBLE_VAULT;1.1;AES256\n' \
                                                              '653937373065366534326533306166613265666637353262626666310a37373633393266313134\n' \
                                                              '376638353562326562636631616365646662333661336166656136366161390a\n'