

# Generated at 2022-06-22 14:11:55.644846
# Unit test for function do_unvault
def test_do_unvault():
	secret = '$ANSIBLE_VAULT;1.1;AES256\n3231333936653839623631626535396335313532333261383562333138666538643961323131623\n639366466313536353766323337613537626261353961636566613939336536643038376263636262\n336664346166653239653532626236645d0a'

	# When we pass a regular string, it should return the same string

# Generated at 2022-06-22 14:11:58.823078
# Unit test for function do_unvault
def test_do_unvault():
    key = 'test'
    data = 'this is a secret'
    vault = do_vault(data, key)
    res = do_unvault(vault, key)
    assert res == data


# Generated at 2022-06-22 14:12:11.164904
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from jinja2.sandbox import SandboxedEnvironment

    result = None
    secret = to_bytes('some_secret')
    vaultid = 'filter_default'

# Generated at 2022-06-22 14:12:23.057558
# Unit test for function do_unvault
def test_do_unvault():
    display.warning("============================================================")
    display.warning("RUNNING UNIT TEST FOR FUNCTION do_unvault()")
    display.warning("============================================================")
    display.warning("ENVIRONMENT VARIABLES TO SET:")
    display.warning("ANSIBLE_VAULT_PASSWORD_FILE =/etc/ansible/vaultpasswords")
    display.warning("ANSIBLE_STDIN_CALLBACK = yaml")
    display.warning("ANSIBLE_STDOUT_CALLBACK = yaml")
    display.warning("ANSIBLE_IGNORE_ERRORS = True")
    display.warning("ANSIBLE_DISPLAY_SKIPPED_HOSTS = False")
    display.warning("ANSIBLE_ROLES_PATH =/etc/ansible/roles")

# Generated at 2022-06-22 14:12:29.054262
# Unit test for function do_vault
def test_do_vault():
    import unittest.mock
    assert do_vault('', '') is ''
    assert do_vault('', '', 'unittest_default', True) is ''
    assert do_vault('this is the secret', '', 'unittest_default', True) == 'this is the secret'
    with unittest.mock.patch('ansible.module_utils.basic._load_params') as _load_params_mock:
        _load_params_mock.return_value = {
            'ANSIBLE_CONFIG': 'unittest',
            'ANSIBLE_VAULT_PASSWORD_FILE': 'password_file',
        }

# Generated at 2022-06-22 14:12:35.745861
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'mysecret'
    test_string = 'mystring'

    result = do_vault(test_string, test_secret)

    # assert that result is AnsibleVaultEncryptedUnicode object
    assert(type(result) is AnsibleVaultEncryptedUnicode)
    # assert that result is properly encrypted
    assert(do_unvault(result, test_secret) == test_string)


# Generated at 2022-06-22 14:12:43.585958
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('hunter2')
    vault_lib = VaultLib()
    data = 'hello world'

    encrypted_data = vault_lib.encrypt(data)
    decrypted_data = do_unvault(encrypted_data, vault_secret)

    assert decrypted_data == 'hello world'

# Generated at 2022-06-22 14:12:56.839719
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:05.708675
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    clear_text = "clear_text"
    # '$ANSIBLE_VAULT;1.1;AES256' is always part of the encrypted text
    encrypted_vault = "$ANSIBLE_VAULT;1.1;AES256\n"
    try:
        encrypted_text = do_vault(clear_text, secret)
        # Encrypted text should start with encrypted_vault
        assert encrypted_text[:len(encrypted_vault)] == encrypted_vault
    except AnsibleFilterError as e:
        display.error(e)
        assert False


# Generated at 2022-06-22 14:13:18.465140
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:28.381538
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = do_vault('test_string', 'test_secret', wrap_object=True)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data.vault is not None
    assert data.data == 'test_string'
    assert data.data != 'test_secret'
    assert data.vault.is_encrypted(data)


# Generated at 2022-06-22 14:13:35.340572
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:46.556602
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:55.855225
# Unit test for function do_vault
def test_do_vault():

    # Test filter for valid data
    input_data = 'test'
    secret = 'secret'
    salt = 'test'

# Generated at 2022-06-22 14:14:04.917981
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play


# Generated at 2022-06-22 14:14:14.730536
# Unit test for function do_unvault
def test_do_unvault():
    # supply data and secret as bytes
    assert do_unvault(b'$ANSIBLE_VAULT;1.1;AES256;admin\n594e6b58565a624c6b424d5846476644205657455a576b5667596d364c49345a6e566d4c4e\n4e55595533453955565549595071566d4c4e4e55595533453955565549595071', b'password') == 'sample text \n'

    # supply data and secret as str

# Generated at 2022-06-22 14:14:27.223043
# Unit test for function do_unvault
def test_do_unvault():
    def assert_do_unvault(vault, secret, expected):
        result = do_unvault(vault, secret)
        assert result == expected

    secret = "mysecret"
    plaintext = "myplaintext"
    ciphertext = "$ANSIBLE_VAULT;1.2;AES256;filter_default\n62316431343735343632623263303064393166323633393064363965383261393166383731396535\n65623763623634306431616265643935353264613362396662326362373635643435336461666264\n39333834303564396638633461633839613164326335306261\n"

    assert_do_unvault(ciphertext, secret, plaintext)

# Generated at 2022-06-22 14:14:37.227411
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:44.713799
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:56.523601
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six.moves.builtins import xrange
    from tempfile import mkstemp
    from ansible.parsing.vault import VaultEditor
    import os
    import jinja2
    import sys

    template = '''
secret: {{ secret|vault }}
salted: {{ salted|vault(secret) }}
wrapped: {{ wrapped|vault(secret, salt='salt') }}
      '''

    secret = 'secret'
    data = 'data'
    salted = 'salted'

    tmpfd, j2_path = mkstemp(dir='/tmp')
    with VaultEditor(secret, j2_path) as v:
        v.write(template)

    with open(j2_path, 'r') as j2_file:
        template = j

# Generated at 2022-06-22 14:15:10.179309
# Unit test for function do_vault
def test_do_vault():
    from ansible.plugins.filter.vault import FilterModule
    from ansible.module_utils.six import binary_type

    # Test for valid string input
    assert isinstance(FilterModule().filters()['vault']('string of text', 'password'), AnsibleVaultEncryptedUnicode)

    # Test for valid binary input
    assert isinstance(FilterModule().filters()['vault'](binary_type('string of text', 'utf-8'), 'password'),
                      AnsibleVaultEncryptedUnicode)

    # Test for valid string input with salt
    assert isinstance(FilterModule().filters()['vault']('string of text', 'password', 'salt'),
                      AnsibleVaultEncryptedUnicode)

    # Test for valid binary input with salt

# Generated at 2022-06-22 14:15:13.114810
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'test'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)


# Generated at 2022-06-22 14:15:16.414270
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert do_unvault(vault, secret) == data

# Generated at 2022-06-22 14:15:27.120152
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret_pass'
    data = 'test'
    salt = 'salt'
    vaultid = 'test_default'
    filter_do_vault = do_vault(data, secret, salt, vaultid=vaultid)

# Generated at 2022-06-22 14:15:39.170179
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:51.388922
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:03.087238
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    assert f.filters()['vault']('test', 'foo') == '$ANSIBLE_VAULT;1.1;AES256\n6132333531376465633534393063326239356632373239313762643634326330663637346161650a66373635373031393435373632353631313761666537366230373735303666363738663730650a363838316639333731376439353533613235393865626436333566303431366164306663390a3432643939353630386231333538353865363165333863616463653130363666613734376463\n'

# Generated at 2022-06-22 14:16:10.324032
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:20.677068
# Unit test for function do_unvault
def test_do_unvault():
    # Test unvaulting a string
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;filter_default\n39656637643637646133356232306566386437356564333362333830653166643738656435613236\n34333137623365326531653635636337636430336233613765646639313832323530346633386438\n64653333\n", "dummy") == "hello!\n"

    # Test unvaulting a encrypted string
    assert do_unvault("Vaulted data", "dummy") == "Vaulted data"

# Generated at 2022-06-22 14:16:26.000138
# Unit test for function do_vault
def test_do_vault():
    import os
    import json
    import pytest
    from ansible.errors import AnsibleFilterTypeError, AnsibleFilterError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Instantiate display object
    display = Display()

    # Test vault with a plain string
    secret = os.environ.get('ANSIBLE_VAULT_SECRET_1')
    assert secret is not None
    data = 'ANSIBLE IS AWESOME'
    vault_str = do_vault(data, secret)
    assert vault_str is not None
    data_str = do_unvault(vault_str, secret)
    assert data_str == data

    # Test vault with a string in a .yaml/.json file

# Generated at 2022-06-22 14:16:36.771153
# Unit test for function do_vault
def test_do_vault():
    import base64
    secret = "secret"
    data = "secret_data"
    vaultid = "filter_default"
    salt = base64.b64encode(os.urandom(16))
    salt = salt.decode('utf-8')

    print(salt)

    vault = do_vault(data, secret, salt, vaultid)
    print(vault)
    assert type(vault) == str
    assert len(vault) > 0

    data = do_unvault(vault, secret, vaultid)
    assert data == "secret_data"

# Generated at 2022-06-22 14:16:38.676035
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('secret string', 'mypassword')



# Generated at 2022-06-22 14:16:48.442530
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:57.478349
# Unit test for function do_vault
def test_do_vault():
    # Test for encryption with valid input
    assert do_vault('dummy_value', 'SECRET', vaultid='filter_default') == '$ANSIBLE_VAULT;1.1;AES256\n336664336234623430656638336262636135313532373435643039386534666562623663343939\n323937386335613666343531623338636631323535363766653334663534376331663633613932\n35333764613862\n'
    # Test for encryption with invalid input
    try:
        assert do_vault('dummy_value', 'SECRET', vaultid='filter_default') == 'dummy_value'
    except Exception as e:
        assert 'unable' in str(e).lower

# Generated at 2022-06-22 14:17:10.513385
# Unit test for function do_unvault
def test_do_unvault():
    # Test for successful unvaulting

    # Set up values for testing unvaulting
    vault_secret = "correct_vault_secret"

    # Set up real vaulted string
    vault_string = "$ANSIBLE_VAULT;1.2;AES256;ansible\n6361356661383738663062633238643534633236383439616331373766653537396565616238636166\n6565643963643536306436323165613661316236333839356630643134313632353830643339626666\n3236343037613335333137643630656438313631373834376231376533646562\n"

    # Set up AnsibleVaultEncryptedUnicode
    ansible_vault

# Generated at 2022-06-22 14:17:22.225141
# Unit test for function do_vault
def test_do_vault():
    data = "foo"
    secret = "bar"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 14:17:30.530127
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.vault import VaultLib

    module = AnsibleModule(
        argument_spec=dict(
            data=dict(required=True, type='str'),
            vault_secret=dict(required=True, type='str', no_log=True),
            vault_salt=dict(required=False, type='str'),
            vault_id=dict(required=False, type='str'),
            wrap_object=dict(required=False, type='bool'),
        )
    )

    display.verbosity = 3
    display.deprecated('This is a deprecated test')
    data = module.params.get('data')
    vault_secret = module.params.get('vault_secret')

# Generated at 2022-06-22 14:17:40.539786
# Unit test for function do_vault
def test_do_vault():
    g = globals()
    g["__ansible_vault"] = do_vault
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultEditor
    import json

    plain_text = "foo"
    secret = "bar"

    # Test options
    #
    # * wrap_object: False - Return string
    # * wrap_object: True  - Return AnsibleVaultEncryptedUnicode
    # * salt: None - The vault will be encrypted.
    # * salt: '01' - The vault will be encrypted using a salt value.
    # * salt: '01' - The vault will be encrypted using a salt value.
    # * salt: '01' - The vault will be encrypted using a salt value.
    # * salt: 10 - The vault will not

# Generated at 2022-06-22 14:17:51.866564
# Unit test for function do_vault
def test_do_vault():

    def _test_do_vault(secret, data, salt=None, vaultid='filter_default', wrap_object=False, expected_result=None, expected_exception=False, expected_regexp="", expected_msg="UNKNOWN"):

        if expected_exception:
            if expected_regexp:
                try:
                    do_vault(data, secret, salt, vaultid, wrap_object)
                except AnsibleFilterError as e:
                    assert re.match(expected_regexp, str(e)), 'Expected exception message "%s" with regexp "%s", got "%s"' % (expected_msg, expected_regexp, str(e))
            else:
                try:
                    do_vault(data, secret, salt, vaultid, wrap_object)
                except Exception:
                    pass
               

# Generated at 2022-06-22 14:18:00.291279
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'foobar') == '$ANSIBLE_VAULT;1.1;AES256\n363633373439356135653538363261353534646135336639383561316363643265653436646139340a306665303261343963346331623932383239643130343432643161613331323932353366653137346630350a66656337636465623162623432623039363836333937336163653637336437633365306634376466383538663032656431\n'



# Generated at 2022-06-22 14:18:16.308879
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:28.779708
# Unit test for function do_vault
def test_do_vault():
    # Test that we can encrypt data
    assert do_vault("foo", "asdfasdf", wrap_object=True).data == "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  363865356464626662383736633535346537643632363432626361613733653864373436643561\n  33306133366337373966323962366162626563376265663064643166\n  \n"

    # Test that we fail gracefully if we dont have input data
    try:
        do_vault(None, "asdfasdf", wrap_object=True)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False

    # Test that we fail gracefully if we dont have

# Generated at 2022-06-22 14:18:39.402482
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.common._collections_compat import Mapping

# Generated at 2022-06-22 14:18:51.428176
# Unit test for function do_unvault
def test_do_unvault():
    secret = b"test123"
    vault = "$ANSIBLE_VAULT;1.2;AES256;test_user\n34643931626366616265396665636465353364363430643031343130313265336362323066626264\n6636353462373165306464363732613937333764633038643931626366616265396665636465353364\n3634306430313431303132653363623230666262646638393538626331633662393539663563316361\n336561383936382d62\n"
    assert do_unvault(vault, secret) is b"welcome to ansible vault"


if __name__ == '__main__':
    test_do_

# Generated at 2022-06-22 14:19:03.357808
# Unit test for function do_unvault
def test_do_unvault():
    secret  = 'foo '
    vaultid = 'default'

    # test valid input
    value   = '$ANSIBLE_VAULT;1.1;AES256;'+vaultid+'\n'
    value  += '37326336623164613861666564353737623434623533333934306637336236633138343762383733\n'
    value  += '36363164373834353037336630316338663938653037633762363034666365633931666137613535\n'
    value  += '663439356665376233356266330a6164646165623632363838613262623139623661623632346462\n'

# Generated at 2022-06-22 14:19:10.227443
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultEditor
    test_vault = VaultEditor(None, None)
    # Test with default vaultid
    assert do_unvault(test_vault.encrypt('test'), 'test') == 'test'
    # Test with specified vaultid
    assert do_unvault(test_vault.encrypt('test'), 'test', vaultid='test_vaultid') == 'test'

# Generated at 2022-06-22 14:19:19.341396
# Unit test for function do_unvault
def test_do_unvault():
    try:
        secret="1234"
        vault="$ANSIBLE_VAULT;1.1;AES256\r\n313765626465356337366461633565303135613332396332313730613235373866383333613861\r\n3837383564323039333932386236666533663393631663364326333366632346533646530386432\r\n35\r\n"
        unvault = do_unvault(vault, secret)
        assert unvault == 'abcdef'
    except:
        assert False



# Generated at 2022-06-22 14:19:26.691306
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'MySecret'
    vaultid = 'filter_default'
    secret_data = 'MySecretData'
    vault = do_vault(secret_data, secret, vaultid="filter_default")
    print(vault)
    data = do_unvault(vault, secret, vaultid="filter_default")
    print(data)
    assert data == secret_data


# Generated at 2022-06-22 14:19:39.326785
# Unit test for function do_vault
def test_do_vault():
    data = 'this is a secret'
    secret = 'mysecret'
    result = '$ANSIBLE_VAULT;1.2;AES256;filter_default\n353739386162613137653336663134313461356237626261666366313638666162393637316265\n316236323665363565633161343135373531326263663531356438616234343231306363363736\n633335353336663134313463306238376262626336633134386162376666636661396237613362\n32653964363662316234376333373439336432623565326533623634393761636536336234\n'

# Generated at 2022-06-22 14:19:51.782818
# Unit test for function do_vault
def test_do_vault():
    # Test with a string secret
    vault_data = do_vault(
        'test',
        'secret',
        wrap_object=False,
    )

# Generated at 2022-06-22 14:20:02.196131
# Unit test for function do_vault
def test_do_vault():
    vault_id = "do_vault-test"
    secret = "secret"
    salt = "salt"
    data = "data"
    vault = do_vault(data, secret, salt, vault_id)
    assert vault.startswith(b'$ANSIBLE_VAULT;')
    assert vault.endswith(b';')
    assert vault.find(b'\n') > 0
    assert vault.find(b'\n') != len(vault) - 1


# Generated at 2022-06-22 14:20:14.885514
# Unit test for function do_unvault
def test_do_unvault():
    wrapper = "Unable to decrypt: %s"

    secret = "secret"
    encrypted_string = "$ANSIBLE_VAULT;1.2;AES256;ansible-vault-filter\n6363353635656532633765653735343062626335376535666133316537376338336337333538340a32363039366433376231666261323539393464303335646462316662363962396266320a363931666234633965656137653039393963346162653034306665373766333834663735"

# Generated at 2022-06-22 14:20:23.230979
# Unit test for function do_vault
def test_do_vault():
    from six import PY3

    # test for encrypting one line
    test_data = "this is a test"
    test_secret = "password"
    test_salt = "salt"
    expected_vault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;default\n          643530346637613831313839656433326631643930633666613839313236373766653465663762\n          33323139313761346332626364633233373737366334303433380a"
    result = do_vault(test_data, test_secret, test_salt)
    assert result == expected_vault

    # encrypting a multi-line string

# Generated at 2022-06-22 14:20:35.230703
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n3633316434316562383163666537326531366332636438363430663433336239623933343533\n3639323539616434373330383962623232666563323662386330646530326564356539393335\n3732306230356536326232616664353762356239646264333630383638393461313537623963\n3437306437663564326432333366363530366434356130666636353330613861396238633133\n646430336438356664623836396532333865\n', 'test') == 'test'

# Generated at 2022-06-22 14:20:47.041433
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    from jinja2.runtime import StrictUndefined

    text = 'test'
    secret = 'supersecret'

# Generated at 2022-06-22 14:20:54.899952
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:06.491270
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    lc = FilterModule()
    lf = lc.filters()
    rsp = lf['vault'](data, secret)
    assert rsp == '$ANSIBLE_VAULT;1.1;AES256\n3536303262616663323033323831383036333061316562616638393533303465313564663738646133\n65663335386336393861356132386262333531636365316532335a6636626339373961646231356437\n6437363637323038643637373633306439326562636436326663336533616232336134\n'

# Generated at 2022-06-22 14:21:12.809398
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:18.534329
# Unit test for function do_vault
def test_do_vault():
    secret = "foo"
    salt = "bar"
    data = "baz"

    data_vault = do_vault(data, secret, salt=salt)
    data_unvault = do_unvault(data_vault, secret)
    assert data == data_unvault, "Unable to do unvault on data"



# Generated at 2022-06-22 14:21:31.403896
# Unit test for function do_vault
def test_do_vault():
    _vault = do_vault('123456', 'ansible')