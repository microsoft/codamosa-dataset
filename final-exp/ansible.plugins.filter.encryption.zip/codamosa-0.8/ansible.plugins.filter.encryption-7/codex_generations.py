

# Generated at 2022-06-22 14:11:58.597349
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:11.092474
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:15.661026
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'encrypteddata'
    wrapped_data = do_vault(data, secret, wrap_object=True)
    assert isinstance(wrapped_data, AnsibleVaultEncryptedUnicode)
    assert wrapped_data.data == data


# Generated at 2022-06-22 14:12:27.947117
# Unit test for function do_unvault
def test_do_unvault():
    f = FilterModule()
    filters = f.filters()

# Generated at 2022-06-22 14:12:38.185364
# Unit test for function do_unvault
def test_do_unvault():
    import unittest
    import os
    import sys

    # Test standalone unvault filter
    class TestVault(unittest.TestCase):
        def test_unvault(self):
            secret = '$ANSIBLE_VAULT;1.1;AES256'
            vault_str = '636865636b5f7374617274'
            self.assertEqual(do_unvault(vault_str, secret), 'check_start')

    # Run the unit test
    unittest.main(argv=[sys.argv[0], '-v'])

    # Test unvault filter with AnsibleVaultEncryptedUnicode object
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    from ansible import constants

# Generated at 2022-06-22 14:12:46.603896
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    import os
    vault_secret = os.environ['ANSIBLE_VAULT_PASSWORD_FILE']
    with open(vault_secret) as f:
        secret = f.read().strip('\n')
    env = jinja2.Environment()
    env.filters['vault'] = do_vault
    data = 'test'
    vault = env.from_string('{{ data|vault(secret) }}').render(data=data, secret=secret)
    assert vault


# Generated at 2022-06-22 14:12:59.237539
# Unit test for function do_unvault
def test_do_unvault():

    import unittest

    class TestDoUnVault(unittest.TestCase):
        def setUp(self):
            self.secret = 'VaultSecret'

        def test_plaintext(self):
            self.assertEqual(do_unvault('This is plaintext', self.secret),
                             'This is plaintext')

        def test_vaulttext(self):
            self.assertEqual(do_unvault(do_vault('This is plaintext', self.secret), self.secret),
                             'This is plaintext')

        def test_no_secret(self):
            self.assertRaises(AnsibleFilterError, do_unvault('This is plaintext', None))


# Generated at 2022-06-22 14:13:04.565084
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault(
        'my test text',
        'abcdefghijklmnop',
        salt=b'abcdefghijklmnop',
        wrap_object=True
    )

    assert isinstance(vault, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-22 14:13:17.455242
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:29.744980
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 14:13:43.596336
# Unit test for function do_unvault
def test_do_unvault():
    secret = '123456'

# Generated at 2022-06-22 14:13:51.659066
# Unit test for function do_unvault
def test_do_unvault():
    secret = "testsecret"

# Generated at 2022-06-22 14:13:58.906955
# Unit test for function do_unvault
def test_do_unvault():
    args = {
        'vault_id': 'test',
        'vault_password': 'test',
        'secret': 'test',
    }
    plaintext = 'data'
    filters = FilterModule()
    filters.filters().get('unvault')

    # test that the unvault function decrypts a string encrypted with AnsibleVaultEncryptedUnicode
    # This function was renamed and we need to test that AnsibleVaultEncryptedUnicode is compatable with the new name
    vault = AnsibleVaultEncryptedUnicode(do_vault(args.get('secret'), args.get('vault_password'), vaultid=args.get('vault_id')))
    assert filters.filters().get('unvault')(vault, args.get('vault_password')) == plaintext




# Generated at 2022-06-22 14:14:07.520584
# Unit test for function do_unvault
def test_do_unvault():
    test_input_data = 'This is an encrypted string'
    test_input_secret = 'password'
    test_input_vaultid = 'filter_default'
    expected_result = test_input_data

    result = do_unvault(do_vault(test_input_data, test_input_secret, vaultid=test_input_vaultid), test_input_secret,
                        vaultid=test_input_vaultid)

    assert result == expected_result

# Generated at 2022-06-22 14:14:11.650547
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    data = "Hello"
    vault = do_vault(data, secret)
    if vault == "" or vault == None:
        raise Exception("Vault filter failed to encrypt: " + str(vault))
    display.display("Vault filter test passed", color='green')


# Generated at 2022-06-22 14:14:17.840680
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import tempfile

    fd, test_secret_file = tempfile.mkstemp(text=True)
    os.close(fd)


# Generated at 2022-06-22 14:14:28.934010
# Unit test for function do_vault
def test_do_vault():

    secret = u'password'
    data = u'ansible'
    vaultid = 'test_do_vault'
    wrap_object = True

    # Test passing correct arguments
    result = do_vault(data, secret, vaultid=vaultid, wrap_object=wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.data == data

    # Test passing correct arguments
    result = do_vault(data, secret, vaultid=vaultid)
    assert isinstance(result, string_types)
    assert is_encrypted(result)

    # Test passing incorrect datatype for secret

# Generated at 2022-06-22 14:14:38.329714
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'testmaster'

# Generated at 2022-06-22 14:14:47.103573
# Unit test for function do_unvault
def test_do_unvault():

    test_vault = """$ANSIBLE_VAULT;1.1;AES256
33363730666534393135336330613165303164373138666261316636353034386637623336323631
383862363532393039306366366662346200
"""

    test_secret = "test-secret"
    test_unvaulted = do_unvault(test_vault, test_secret)
    assert test_unvaulted == """test-data
"""


# Generated at 2022-06-22 14:14:48.691777
# Unit test for function do_unvault
def test_do_unvault():
    pass  # TODO: test for do_unvault function


# Generated at 2022-06-22 14:14:58.770905
# Unit test for function do_vault
def test_do_vault():
    res = do_vault("this is data", "top secret", "default")
    print(res)
    assert res == '$ANSIBLE_VAULT;1.1;AES256;default\n30313163336436633966643533623536333032656261306332313562356330623334323238303130\n32373735336638653166613331343134383932353633393831636639323263623931386361623461\n353963393965393435323637323064376364616439373036346539633831636236613163353862\n'



# Generated at 2022-06-22 14:15:08.301744
# Unit test for function do_vault
def test_do_vault():
    FILTER_PLUGIN = FilterModule()
    FILTER_PLUGIN.filters()
    print(FILTER_PLUGIN.filters())
    non_encrypted_sample_text = "Hello World"
    secret = "ansible"
    sample_encrypted_text = do_vault(non_encrypted_sample_text, secret)
    if is_encrypted(sample_encrypted_text):
        print("Encrypted text: %s is encrypted" % sample_encrypted_text)
    else:
        print("Encrypted text: %s is not encrypted" % sample_encrypted_text)


# Generated at 2022-06-22 14:15:14.349629
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    data = "hello world"
    secret = "qwerty"
    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt(data, vs)
    assert vault == do_vault(data, secret)



# Generated at 2022-06-22 14:15:25.122572
# Unit test for function do_vault
def test_do_vault():
    """Unit test for do_vault"""
    secret = "bWFu0G4="
    salt = "WHxPVlNXRklORw=="

    # Test with a valid input
    data = "my_secret"

# Generated at 2022-06-22 14:15:38.440330
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test against valid encrypted data with valid secret
    secret = 'secret'
    data = 'plain text'
    enc = '$ANSIBLE_VAULT;1.1;AES256;ansible\r\n'
    enc += '663462663465633961646562323461316166393564633039643365653836383664656662366265\r\n'
    enc += '393231316664303533363933616463626435326663376236636366643530376339626439653530\r\n'
    enc += '\r\n'
    enc_vault = Ans

# Generated at 2022-06-22 14:15:50.589170
# Unit test for function do_vault
def test_do_vault():

    secret = 'mypassword'
    plaintext = 'string to encrypt'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    expected_output = '$ANSIBLE_VAULT;1.1;AES256\n3036353365376262313661313464653835313632313664303635643631333662323036333832363239340a6430316230643632393063613233316436393737393061306534666635333036383333656635653066650a366535363366373566306539303633323163383133373235326531653235316532353737316232653065'

# Generated at 2022-06-22 14:16:02.279397
# Unit test for function do_vault
def test_do_vault():
    # Test
    test_secret = '$ANSIBLE_VAULT;1.1;AES256'
    test_salt = '4321'
    test_data = 'this is a secret'


# Generated at 2022-06-22 14:16:09.931544
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("blah", "DEADBEEF", "salty") == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;salty\n          62346361373533313361323366633261366133313161323366373733393030626263303935373265\n          636130346531313262346635363934666363330a3864663635653034313034633563343332313764\n          61666131336465613864396164373464333835613937300a", "do_vault did not return the expected output"

# Generated at 2022-06-22 14:16:17.715138
# Unit test for function do_vault
def test_do_vault():
    # Expected to fail
    with pytest.raises(AnsibleFilterTypeError):
        do_vault('test', 5, 'filter_default')
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(5, 'test', 'filter_default')
    # Expected to succeed
    do_vault('test', 'test', 'filter_default')


# Generated at 2022-06-22 14:16:23.692329
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:35.776511
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret

    import sys

    if sys.version_info[0] >= 3:
        str_type = str
    else:
        str_type = unicode

    secret = 'password'
    data = 'secret'
    vault = do_vault(data, secret)

    vs = VaultSecret(secret)
    vl = VaultLib()
    assert data == vl.decrypt(vault)



# Generated at 2022-06-22 14:16:46.310492
# Unit test for function do_vault
def test_do_vault():
    data = 'this is a secret'
    secret = 'my secret'
    salt = 'one more secret'

    expected_vault = 'ANSIBLE_VAULT;1.1;AES256\n35313265626237366535333430653663356438613431323562386162336365333530646633656433\na63a3262333562363166653433663730366539393062333730396465306266623633356437656537\n66656366356161326135636562396134363437336364632\n'

    assert do_vault(data, secret, salt, 'filter_default') == expected_vault



# Generated at 2022-06-22 14:16:53.981408
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("foobar", "secret") == "$ANSIBLE_VAULT;1.1;AES256\n32636631633165656436663064336638653836613561366132613365633839303533366130343839\n62313335643261366235396234613139386639326162323139356236306338653133616339626137\n66303562316336643265653034656633623733393935636137353762"


# Generated at 2022-06-22 14:17:07.568660
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    result = do_vault(data, secret)

# Generated at 2022-06-22 14:17:20.101621
# Unit test for function do_vault

# Generated at 2022-06-22 14:17:29.297956
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = None
    vaultid = 'foo'
    wrap_object = False
    expected_vault = '$ANSIBLE_VAULT;1.1;AES256\n376561383235626261326236633736616662353534373331613864373530643736366433653064\n376465353637633832653466643833383035393532633333366234623465396534663832626333\n383964333830643734323137343133333834376135663661623332336536643863623964306361\n3733356465323032616166363263633835633661623762663665\n'
    vault = do_

# Generated at 2022-06-22 14:17:39.869498
# Unit test for function do_vault
def test_do_vault():

    test1_data = "hello world"
    test1_secret = "secret1"
    result1 = do_vault(test1_data, test1_secret)
    assert result1.startswith(b"!vault")

    test2_data = "hello world"
    test2_secret = "secret2"
    test2_salt = "$1$Jd1VxBxC$X9p63ZbnfhTuPp7Ln0nok1"
    result2 = do_vault(test2_data, test2_secret, salt=test2_salt)
    assert result2 != test2_data

    test3_data = "hello world"
    test3_secret = "secret3"

# Generated at 2022-06-22 14:17:50.689381
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('value', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n30363839663561646265396563346161623339326235336231333865373235363363656162326166\n37346664393766373639306433396137643635336431336532663735656232616363396335303439\n38666265336438630a32393761653235346230353665336439363466376363646638653061653662\n65323831623137313861393961333132626262356133616663613739623338636262626266373961\n34613662373732\n'
    assert do_vault

# Generated at 2022-06-22 14:17:59.698360
# Unit test for function do_vault
def test_do_vault():

    # only run this test if the dependencies have been installed (see docs in filters/vault.py)
    try:
        from ansible.parsing.vault import is_encrypted, encrypt
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    except ImportError:
        pass
    else:
        # no secret, raise AnsibleFilterTypeError
        secret = None
        data = None
        with pytest.raises(AnsibleFilterTypeError):
            do_vault(data, secret)

        # invalid secret type, raise AnsibleFilterTypeError
        secret = {}
        data = None
        with pytest.raises(AnsibleFilterTypeError):
            do_vault(data, secret)

        # no data, return '$ANSIBLE_VAULT;1.1

# Generated at 2022-06-22 14:18:07.488611
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:20.561852
# Unit test for function do_vault
def test_do_vault():

    secret = "secret"
    salt = "salt"
    vault = "vault"

    try:
        result = do_vault(vault, secret, salt)
    except Exception as e:
        result = to_native(e)


# Generated at 2022-06-22 14:18:31.488513
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'

# Generated at 2022-06-22 14:18:41.076968
# Unit test for function do_vault
def test_do_vault():

    test_secret = 'geese'
    inputs = [
        ("", test_secret, None, 'filter_default', False),
        ("this is a string", test_secret, None, 'filter_default', False),
        ("this is a string", test_secret, "asdfasdf3434", 'filter_default', False),
        ("this is a string", test_secret, "asdfasdf3434", 'other_default', False),
    ]

    for input_data in inputs:
        output = do_vault(*input_data)

        if not isinstance(output, string_types):
            raise AssertionError("%s is not a string" % output)


# Generated at 2022-06-22 14:18:47.409929
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1;AES256;ansible0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890\nZW5jcnlwdGVk\n", "secret") == "encrypted"


# Generated at 2022-06-22 14:18:57.684014
# Unit test for function do_vault
def test_do_vault():
    secret = 'HelloWorld'
    vault = do_vault(secret, 'secret', salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-22 14:19:07.108524
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:16.359886
# Unit test for function do_vault
def test_do_vault():
    # AnsibleVaultEncryptedUnicode object will be returned
    test_data = 'string to be vaulted'
    test_secret = 'abcdefghijklmnop'
    result_obj = do_vault(test_data, test_secret, wrap_object=True)
    assert type(result_obj) == AnsibleVaultEncryptedUnicode

    # String will be returned
    result_str = do_vault(test_data, test_secret)
    assert isinstance(result_str, str)
    assert is_encrypted(result_str)

    # Exceptions can be handled gracefully
    with pytest.raises(AnsibleFilterError):
        do_vault(1, test_secret)


# Generated at 2022-06-22 14:19:29.016708
# Unit test for function do_vault
def test_do_vault():

    data = {
        'not_vault_data': 'this is not vault data',
        'vault_data': 'this is a vaulted data',
        'vault_id': 'filter_default',
    }

    secret = 'this is a secret'
    vault = do_vault(data['vault_data'], secret, salt=None, vaultid=data['vault_id'], wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault.secrets.get(data['vault_id']).password == secret
    assert vault.data.decode('utf-8') == data['vault_data']

    # Test with incorrect secret

# Generated at 2022-06-22 14:19:37.352111
# Unit test for function do_vault
def test_do_vault():

    # Pre-requisites setup
    test_secret = 'mysecretpassword'
    test_data = 'mytestdata'

    # Call function with test parameters
    result = do_vault(test_data, test_secret)

    # Verify result
    assert result is not None
    assert isinstance(result, string_types)
    assert isinstance(result, binary_type)
    assert result.startswith(b'$ANSIBLE_VAULT')
    assert result.endswith(b'\n')



# Generated at 2022-06-22 14:19:49.866757
# Unit test for function do_unvault
def test_do_unvault():
    secret_orig = b'abc123'
    vault = b'$ANSIBLE_VAULT;1.1;AES256;admin;false\n393739373036363233346336366262656235326534316532393161363565366433363032356533\n366233616463396262666364643632626464333439643064343865656431'
    vaultid = 'filter_default'

    # Test with binary secret
    secret = secret_orig
    decrypted_data = do_unvault(vault, secret, vaultid)
    assert decrypted_data == 'comtest1'

    # Test with unicode secret
    secret = to_native(secret_orig)

# Generated at 2022-06-22 14:20:06.992750
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 14:20:18.941963
# Unit test for function do_vault
def test_do_vault():
    secret_key = 'f6JHV6zLVX9WJk8YFg/UoVJykrxYoLLD'
    vault_data = 'test string'

    # Case: Encrypt the vault data
    enc_data = do_vault(vault_data, secret_key)
    print(enc_data)

    # Case: Error case for Invalid data type
    try:
        enc_data = do_vault(True, secret_key)
        assert False
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

    # Case: Error case for Invalid secret key type

# Generated at 2022-06-22 14:20:31.226907
# Unit test for function do_vault
def test_do_vault():

    ### Verify that do_vault raises an exception if the secret parameter is not a string
    try:
        # The secret parameter is a number
        do_vault('data', 42)
        assert False
    except Exception as e:
        assert e.__class__.__name__ == 'AnsibleFilterTypeError' \
            and 'Secret passed is required to be a string, instead we got: <class \'int\'>' in str(e)


# Generated at 2022-06-22 14:20:36.829805
# Unit test for function do_vault
def test_do_vault():
    # Given I have a secret and data
    secret = 'mysecret'
    data = 'mydata'

    # When I encrypt the data with the secret and vault id
    vault = do_vault(data, secret, vaultid='filter_default')

    # Then the vault should be encrypted
    assert is_encrypted(vault) is True

    # And should be wrapped in AnsibleVaultEncryptedUnicode class
    assert isinsta

# Generated at 2022-06-22 14:20:45.634379
# Unit test for function do_vault
def test_do_vault():
    secret = "n0bodycanhearme"
    test_data = []
    test_data.append(("test", "AQAAAAEAADqzr0eamKfX9R6UZfnYha0wK5dMBw=="))
    test_data.append(("test test", "AQAAAAEAADZC2QZQn8Wy1SMfvGwNjPpJtP+WZQ=="))
    test_data.append(("test test test", "AQAAAAEAADoTmjzd4eV7sgdZ+gEZ7R+jXrzO7g=="))
    test_data.append((1, "AQAAAAEAADqzr0eamKfX9R6UZfnYha0wK5dMBw=="))

# Generated at 2022-06-22 14:20:53.999995
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:05.626252
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()

    data = 'foo'
    secret = 'secret'


# Generated at 2022-06-22 14:21:18.393594
# Unit test for function do_vault
def test_do_vault():
    secret = 'filter_secret_key'
    salt = 'salt'
    vaultid = 'filter_vault'
    wrap_object = True

    assert do_vault('', secret, salt, vaultid, wrap_object) == ''
    assert do_vault('a', secret, salt, vaultid, wrap_object).data == 'a'
    assert do_vault(b'a', secret, salt, vaultid, wrap_object).data == b'a'
    assert do_vault('1', secret, salt, vaultid, wrap_object).data == '1'
    assert do_vault(b'1', secret, salt, vaultid, wrap_object).data == b'1'
    assert do_vault('1.5', secret, salt, vaultid, wrap_object).data == '1.5'


# Generated at 2022-06-22 14:21:24.625316
# Unit test for function do_vault
def test_do_vault():
    secret = "This is a super secret password"
    test_value = "ThIs sHouLd bE EncrYpted"
    test_value_encrypted = do_vault(test_value, secret)

    assert is_encrypted(test_value_encrypted) is True
    assert do_unvault(test_value_encrypted, secret) == test_value


# Generated at 2022-06-22 14:21:31.004877
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("my_secret", "do_vault") != "my_secret"
    assert do_vault("my_secret", "do_vault2") != "my_secret"
    assert do_vault("my_secret", "do_vault2") != do_vault("my_secret", "do_vault")


# Generated at 2022-06-22 14:21:43.620980
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:55.382209
# Unit test for function do_vault
def test_do_vault():
    vault_filter = FilterModule()
    vault_filter_functions = vault_filter.filters()

    # Test secret as string
    test_secret = 'secret'
    test_data = 'this is a secret'

    test_vault = vault_filter_functions['vault'](test_data, test_secret)
    test_unvault = vault_filter_functions['unvault'](test_vault, test_secret)

    assert test_unvault == test_data

    # Test secret as bytes
    test_secret = b'secret'
    test_data = b'this is a secret'

    test_vault = vault_filter_functions['vault'](test_data, test_secret)