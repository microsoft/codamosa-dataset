

# Generated at 2022-06-22 14:11:58.586633
# Unit test for function do_unvault
def test_do_unvault():
    # Just check that the key is given and is a string
    assert do_unvault("dGVzdA==", "test", "default") == "test"

    # Given a non string key, an error should be raised
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault("blabla", 1)
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault("blabla", [1])
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault("blabla", {1:"1"})

    # Given a non string data, an error should be raised
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault({"blabla":"blabla"}, "test")


# Generated at 2022-06-22 14:12:05.534655
# Unit test for function do_vault
def test_do_vault():
    secret = 'Secret'
    data = 'Data'

    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert '$ANSIBLE_VAULT' in vault
    assert '$ANSIBLE_VAULT' not in do_unvault(vault, secret)


# Generated at 2022-06-22 14:12:13.856470
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:26.409852
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 14:12:37.917408
# Unit test for function do_vault
def test_do_vault():
    import textwrap
    from ansible.utils.encrypt import do_encrypt

# Generated at 2022-06-22 14:12:38.506826
# Unit test for function do_vault
def test_do_vault():
    pass

# Generated at 2022-06-22 14:12:50.961321
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filters = filter_module.filters()

    # Test error message for invalid type for secret
    try:
        filters['unvault'](vault='ansible', secret=1)
    except AnsibleFilterTypeError as e:
        assert "Secret passed is required to be as string, instead we got: <type 'int'>" in str(e)

    # Test error message for invalid type for vault
    try:
        filters['unvault'](vault=[], secret='secret')
    except AnsibleFilterTypeError as e:
        assert "Vault should be in the form of a string, instead we got: <type 'list'>" in str(e)

    # Test error message for not encrypted vault

# Generated at 2022-06-22 14:12:56.768095
# Unit test for function do_vault
def test_do_vault():
    secret = "vault_secret_1"
    data = "this is a secret"
    result = do_vault(data, secret)


# Generated at 2022-06-22 14:13:07.268773
# Unit test for function do_unvault
def test_do_unvault():

    # test case 1
    src = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3035386635336266623561366166383539366337653734333562336639386138613732313737393239\n          656366626664336565393066663862313635633531383939346138363135313833\n          3462616663363736396264333530353262646139"
    pw = "test"
    want = "test"
    got = do_unvault(src, pw)
    assert(want == got)

test_do_unvault()

# Generated at 2022-06-22 14:13:19.344629
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:32.204780
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:44.103603
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:51.929699
# Unit test for function do_unvault
def test_do_unvault():

    # Test for valid data
    data = 'test_123'
    secret = 'secret'
    vaultid='test_default'
    vault = do_vault(data, secret, vaultid)
    assert is_encrypted(vault) is True
    assert do_unvault(vault, secret, vaultid) == data

    # Test for invalid data
    data = ['123']
    secret = 'secret'
    vaultid='test_default'
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(data, secret, vaultid)
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(vault, data, vaultid)

    # Test for invalid secret
    data = 'test_123'
    secret = ['secret']

# Generated at 2022-06-22 14:14:02.705645
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data="my secret data", secret="vaultpass", salt="salt", wrap_object=False) == "!vault |\n$ANSIBLE_VAULT;1.2;AES256;filter_default\nsalt\n37983062ec0e6cab12a75799d0e59a2a3f3c8dced3987a94a95f9e30e91ab8a1\n"

# Generated at 2022-06-22 14:14:13.573491
# Unit test for function do_unvault
def test_do_unvault():
    import base64
    secret = 'password'
    vaultid = 'test_vault_id'
    vl = VaultLib([(vaultid, VaultSecret(to_bytes(secret)))])

    # test valid vault
    unvault = do_unvault('$ANSIBLE_VAULT;1.2;AES256;' + vaultid + ';' + base64.b64encode('test_string'), secret, vaultid)
    assert unvault == 'test_string'

    # test invalid vault

# Generated at 2022-06-22 14:14:15.475170
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-22 14:14:27.454792
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:37.329548
# Unit test for function do_unvault
def test_do_unvault():
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          313466623534356664366230263865336135636331396535336236653033326166353762636631\n          616339636235613431333163326430313731323862653036363562663066323362346636313339\n          313438643733343238336231643939613036353932303037666435363365613364623262613462\n          6135623963316630383439326333373436623039356566\n          "
    secret = 'TestSecret'
    expected_out = 'abc123'
    assert do_unvault(vault, secret)

# Generated at 2022-06-22 14:14:44.768084
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'bad_secret'
    vaultid = 'filter_default'

    secret = '$ANSIBLE_VAULT;1.1;AES256'
    secret_ = secret.encode('utf-8')

    nonce = '1234567890abcdef'.encode('utf-8')
    nonce_length = len(nonce)
    nonce_length_nbo = nonce_length.to_bytes(1, byteorder='big')

    cipher_bytes = '1234567890abcdef'.encode('utf-8')
    cipher_length = len(cipher_bytes)
    cipher_length_nbo = cipher_length.to_bytes(4, byteorder='big')

    hmac = '1234567890abcdef'.encode('utf-8')

# Generated at 2022-06-22 14:14:56.565665
# Unit test for function do_unvault
def test_do_unvault():

    # Test unvault with a secret
    secret = b'$ANSIBLE_VAULT;1.1;AES256;test_unvault_key_1\n6431303764366231656437376333343332666230356466363663366338616662656163646231620a3331356132373530393736643233346361303239353866386434663035653463313461373138340a643938653265383362383439313839373535616235313837656132323333313138333835306637350a'
    data = b'This is the secret data'
    unvaulted_data = b'This is the secret data'
   

# Generated at 2022-06-22 14:15:10.135192
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'asdfqwerty'
    vault = "$ANSIBLE_VAULT;1.1;AES256\n633162353665643766383730653537633365396433323161356566366430666539303231663338\n303431303634633532353163656536356634333365653161333564633535333064663236333435\n31323334366635386663316236313231393161363433653961\n"
    vaultid = 'unit_test'
    expected_result = 'Hellö Wörld'

    result = do_unvault(vault, secret, vaultid)
    assert result == expected_result

# Generated at 2022-06-22 14:15:20.166554
# Unit test for function do_unvault
def test_do_unvault():
    plain = u'test'
    password = 'secret'
    salt = 'salt'
    vault_version = '1.1'

# Generated at 2022-06-22 14:15:31.257243
# Unit test for function do_unvault
def test_do_unvault():
    # generate reference value by hand
    ref = 'hello\n'
    enc = do_vault(ref, 'junk', None, 'test_vault')
    assert isinstance(enc, str)
    assert enc.startswith('$ANSIBLE_VAULT;')
    assert is_encrypted(enc)
    assert do_unvault(enc, 'junk', 'test_vault') == ref

    # empty string

# Generated at 2022-06-22 14:15:41.226674
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:52.227178
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "filter_default"
    data = "Test data"

# Generated at 2022-06-22 14:16:00.212008
# Unit test for function do_unvault
def test_do_unvault():
    secret = b'1234'

# Generated at 2022-06-22 14:16:10.558388
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six import PY3
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import pytest

    # Test case 1: Check that the function raises an error when an invalid secret is provided
    secret = 1

# Generated at 2022-06-22 14:16:19.658697
# Unit test for function do_unvault
def test_do_unvault():
    test_values = {
        'secret': '$ANSIBLE_VAULT;1.1;AES256;ansible!',
        'vault': '$ANSIBLE_VAULT;1.1;AES256;ansible!466jNQ1NnEMogSXU6W8U6ZfU5Z5U4I4Uansible!',
        'expected': 'this is secret and should not be exposed!\n'
    }

    assert test_values['expected'] == do_unvault(test_values['vault'], test_values['secret'])

# Generated at 2022-06-22 14:16:24.307639
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data_str = 'hello world'
    try:
        result = do_vault(data_str, secret)
        assert type(result) == str
    except AnsibleFilterError:
        raise
    except Exception as e:
        raise


# Generated at 2022-06-22 14:16:31.896310
# Unit test for function do_unvault
def test_do_unvault():
    def assertUnvault(v, s, expected):
        _v = do_vault(v, s)
        actual = do_unvault(_v, s)
        assert actual == expected

    assertUnvault("", "", "")
    assertUnvault("", "secret", "")
    assertUnvault("test", "", "test")
    assertUnvault("test", "secret", "test")
    assertUnvault("test", "", "test")

# Generated at 2022-06-22 14:16:46.059748
# Unit test for function do_vault
def test_do_vault():

    # Ensure we get an AnsibleVaultEncryptedUnicode object back when we expect
    assert isinstance(do_vault('my_password', 'my_secret', wrap_object=True), AnsibleVaultEncryptedUnicode)

    # Ensure we get a string back when we expect
    assert isinstance(do_vault('my_password', 'my_secret'), str)

    # Ensure that we get back a string that is encrypted
    assert is_encrypted(do_vault('my_password', 'my_secret'))

    # Ensure that we can pass in an AnsibleVaultEncryptedUnicode object and get back an encrypted string
    assert is_encrypted(do_vault(do_vault('my_password', 'my_secret', wrap_object=True), 'my_secret', wrap_object=True))

    # Ensure that

# Generated at 2022-06-22 14:16:50.345028
# Unit test for function do_vault
def test_do_vault():
    test_secret = "mysecret"
    test_string = "Hello, World!"
    test_result = do_vault(test_string, test_secret)
    assert "vault" in test_result, "do_vault did not properly encrypt data"


# Generated at 2022-06-22 14:16:56.219377
# Unit test for function do_vault
def test_do_vault():
    display.verbosity = 3
    secret = "secret"

    assert b"!vault |" in do_vault("test", secret=secret)
    assert b"$ANSIBLE_VAULT;" in do_vault("test", secret=secret)
    assert "vault_" in do_vault("test", secret=secret, wrap_object=True)
    assert type(do_vault("test", secret=secret, wrap_object=True)) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-22 14:17:08.751562
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.parsing.vault import VaultEditor

    # Create a test vault file
    test_file = VaultEditor('filter', 'secret', 'filter_default')

# Generated at 2022-06-22 14:17:21.019841
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:29.846091
# Unit test for function do_vault
def test_do_vault():
    test_secret = '$ANSIBLE_VAULT;1.2;AES256;def1234567890123456789012345678901234567890123456789012345678901234'
    test_data = 'bar'
    vault = do_vault(test_data, test_secret, salt='123', vaultid='test_do_vault')
    assert vault == '$ANSIBLE_VAULT;1.2;AES256;test_do_vault;123\n63626264366662623662663336333364\n36663839356632395465663933613335\n39376538366135656239633231656539\n61656637366466353437663961613862\n3065353762\n'

# Generated at 2022-06-22 14:17:40.189621
# Unit test for function do_unvault
def test_do_unvault():

    secret = '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-22 14:17:45.214294
# Unit test for function do_unvault
def test_do_unvault():
    try:
        secret = 'test'
        do_unvault('$ANSIBLE_VAULT;6.95A;AES256', secret)
    except AnsibleFilterError as e:
        assert(str(e) == "Unable to decrypt: cannot decode data as base64")


# Generated at 2022-06-22 14:17:49.627799
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello', 'secret') == '$ANSIBLE_VAULT;1.1;AES256;some_uuid\n6438393064363339376231346362353161343630656635386466373664663733313805a0a0a0a\n0a'


# Generated at 2022-06-22 14:18:00.709934
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    salt = 'mysalt'
    vaultid = 'myvaultid'
    wrap_object = False

# Generated at 2022-06-22 14:18:15.633623
# Unit test for function do_unvault
def test_do_unvault():
    # Assert do_unvault for string
    assert('Good Morning' == do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256\n323041333532366162396335633930666433353064346166636166306365623132323862626364\n3566386264356164626530316639396239326164633137360a6363346132613931323431663835\n633535346362623832656163653432376138313363663465626361346631626464666563363539\n346631633230326439\n', secret='Ansible'))
    # Assert do_unvault for AnsibleVaultEncryptedUnicode

# Generated at 2022-06-22 14:18:28.389048
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault_id = 'michael'

# Generated at 2022-06-22 14:18:33.028444
# Unit test for function do_vault
def test_do_vault():
    secret = 'my_little_secret'
    data = 'my_little_data'

    result = do_vault(data, secret)

    assert isinstance(result, str), "Result must be a string."

# Generated at 2022-06-22 14:18:42.117280
# Unit test for function do_unvault
def test_do_unvault():
    # Test case 1: given a correctly encrypted string, it decrypts correctly
    # verify that it works with encrypted strings and also unencrypted strings
    # also verify that it works with a unicode string

    secret = "ansible"

# Generated at 2022-06-22 14:18:54.420336
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2.exceptions import UndefinedError

    secret = "password"

    # valid hexdigest
    test_vault = "!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  313162326432656231646139623965666231333962633936313337383337663938633563653061\n  613230373831623765356437316532636265313834656665303737383661333264373938373835\n  613431333737303633\n"
    test_data = "test data"
    result = do_unvault(test_vault, secret)
    assert result == test_data
    assert isinstance(result, string_types)

    # too

# Generated at 2022-06-22 14:19:04.865915
# Unit test for function do_vault
def test_do_vault():
    # pylint: disable=too-many-locals
    secret = 'string'
    salt = 'default'
    vaultid = 'filter_default'
    wrap_object = False
    data = 'string'
    filter_result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(filter_result, string_types)

# Generated at 2022-06-22 14:19:13.799788
# Unit test for function do_vault
def test_do_vault():

    # Secret is a string type
    secretA = "ansible"
    # Secret is a binary type
    secretB = b"ansible"
    data = "test"

    # Check if data is correctly encrypted
    assert do_vault(data, secretB) == b"$ANSIBLE_VAULT;1.1;AES256\n353837306534356638313532363235323765393666323666653761356333343862363938613265616\npVjh3q9zYCFt+E8t1hjR1J0t/B/vQ8mOI2nS5z+44eDy79FzWSIYlg4w4b+pvZJH\n"

    # Check if wrong data type input or output

# Generated at 2022-06-22 14:19:22.576256
# Unit test for function do_vault
def test_do_vault():
    # Check that do_vault throws an exception if the secret is not a string type
    test_vault = {}
    test_secret = "test_secret"
    test_salt = "test_salt"
    test_vaultid = "filter_default"
    test_wrap_object = False
    try:
        do_vault(test_vault, test_secret)
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)
    else:
        assert False, "do_vault did not throw an exception when it should have"
    try:
        do_vault(test_vault, test_secret, test_salt)
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

# Generated at 2022-06-22 14:19:34.424361
# Unit test for function do_unvault

# Generated at 2022-06-22 14:19:38.069193
# Unit test for function do_vault
def test_do_vault():
    res = do_vault('12345678901234567890123456789012', 'secret')
    assert '$ANSIBLE_VAULT;' in res


# Generated at 2022-06-22 14:19:53.393129
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    from ansible.parsing.vault import VaultSecret

    #
    # NOTE: The tests below use the same example password and salt used by
    #       the Ansible Vault command line tool, that is:
    #
    #         Password: mysecret
    #         Salt: salt
    #

    #
    # NOTE: This test is the same example from the Ansible Vault user's guide
    #       at http://docs.ansible.com/ansible/latest/user_guide/vault.html#example-vault-content-file
    #

    # Set up the Jinja2 environment
    vault_env = jinja2.Environment()
    # Add the vault filter
    vault_env.filters['vault'] = do_vault
    # Create the template
    vault_template = vault_

# Generated at 2022-06-22 14:20:05.599819
# Unit test for function do_unvault
def test_do_unvault():

    # Positive test - unvault a string
    string1 = 'insecure string'

# Generated at 2022-06-22 14:20:17.905360
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    data = 'unvaulted data'

    # Fail without a secret
    try:
        f.filters()['vault'](data, None)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "vault did not fail without a secret"

    # Fail with a non-string secret
    try:
        f.filters()['vault'](data, '')
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "vault did not fail with empty string as a secret"

    # Fail with a non-string data
    try:
        f.filters()['vault'](None, 'secret')
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-22 14:20:30.217861
# Unit test for function do_vault
def test_do_vault():
    import unittest
    import ansible.parsing.yaml.objects as objects
    import jinja2

    class TestVault(unittest.TestCase):
        def setUp(self):
            self.env = jinja2.Environment()
            self.env.filters.update({'vault': do_vault})

            self.test_string = 'testing'
            self.test_vault_id = 'filter_default'

        def test_vault_not_string(self):
            ''' do_vault raises AnsibleFilterTypeError if secret not string '''
            salt = None
            test_secret = 12345
            test_wrap_object = False


# Generated at 2022-06-22 14:20:41.446546
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)
    assert vault == u'$ANSIBLE_VAULT;1.1;AES256\n353033663633396435343663386533346661316565643333313130663138386436333861646633336\n3939643438346134313631343638626236636530373665356465663736386665653466396105153763\n613131656539373731666632306330373730356665363132613937366337646531346564636563363\n63366635663132376539666533383962663361666336316561353838613633306566623434393\n'

# Generated at 2022-06-22 14:20:50.455198
# Unit test for function do_vault
def test_do_vault():
    vault_id = 'filter_default'
    secret = 'something'
    salt = 'salt'
    data = 'data'
    expected = b"$ANSIBLE_VAULT;1.1;AES256;filter_default;bG9s;S/ZJNU7V40eQddhF7ETW4o8F0DziPzRZMHJmB1hQZ1mqfMz+bPplJ10kGXWS3tb3;tqxwDw=="
    result = do_vault(data, secret, salt, vault_id)
    assert result == expected


# Generated at 2022-06-22 14:21:02.765136
# Unit test for function do_unvault
def test_do_unvault():
    import ansible.parsing.vault
    ansible.parsing.vault.VaultLib._VAULT_VERSION = 2

# Generated at 2022-06-22 14:21:15.768647
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES128;foo\nbar\n", secret="bar") == "foo"
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;foo\nahPz+lGpfX9jKEnSa+nxvA==\n", secret="bar") == "foo"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;foo\nbar\n", secret="bar") == "foo"
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n", secret="bar") == "foo"

# Generated at 2022-06-22 14:21:27.997218
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Environment
    from jinja2.exceptions import UndefinedError

    env = Environment()
    env.filters['unvault'] = do_unvault

    template = env.from_string("{{ '!vault |'|unvault }}")
    assert '!vault |' == template.render()


# Generated at 2022-06-22 14:21:41.365147
# Unit test for function do_vault
def test_do_vault():
    # backward compat test
    secret = '$ANSIBLE_VAULT;1.1;AES256;'
    salt = 'salt'
    vaultid = 'plaintext_value'
    wrap_object = True
    data = 'pass123'

    assert do_vault(data, secret, salt, vaultid, wrap_object) == AnsibleVaultEncryptedUnicode(secret + salt + '\n' + data)

    vaultid = 'test_vault_id'
    salt = 'test_salt'
    # vaultid_salt is the output of: python -c 'import ansible.parsing.vault; print(ansible.parsing.vault.VaultLib._vaultid_salt(vaultid))'

# Generated at 2022-06-22 14:21:54.541554
# Unit test for function do_vault
def test_do_vault():
    filter_vault = FilterModule().filters()['vault']
    data = 'ansible'
    secret = 'secret'
    vault = filter_vault(data, secret)
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n65313039623365636539653233623239656563326339346162323136613331373132643066313036\n6132363938636132316462326261366239356563363065316531323865336262633165646566636261\n656535366631356531396564306633643366323331656637643466\n', 'vault() failed'
