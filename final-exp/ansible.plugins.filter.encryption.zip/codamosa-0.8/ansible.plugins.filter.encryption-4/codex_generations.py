

# Generated at 2022-06-22 14:11:48.425943
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == ''


# Generated at 2022-06-22 14:11:58.823348
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:03.691446
# Unit test for function do_vault
def test_do_vault():
    data = 'foo'
    secret = 'myvaultpassword'
    salt = 'mysecretsalt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = "{$ANSIBLE_VAULT;1.1;AES256;mysecretsalt\r\n367e6f6f0a\r\n}"
    assert do_vault(data, secret, salt, vaultid, wrap_object) == vault


# Generated at 2022-06-22 14:12:12.938476
# Unit test for function do_unvault
def test_do_unvault():
    import sys
    import os
    import errno

    cwd = os.getcwd()
    testdir = os.path.dirname(os.path.realpath(__file__))

    # Temporary change to test directory
    os.chdir(testdir)

    try:
        os.makedirs("unvault_temp")
    except OSError as exception:
        if exception.errno != errno.EEXIST:
            raise

    sys.path.insert(0, "unvault_temp")

    import ansible.module_utils.six as six

    # Copied and pasted these directly from the v1 tests.
    # 1.4_hmac_sha256__chars_32__aes256__base64

# Generated at 2022-06-22 14:12:20.435341
# Unit test for function do_unvault
def test_do_unvault():
    from nose.tools import assert_raises

    with assert_raises(AnsibleFilterTypeError) as cm:
        do_unvault('$ANSIBLE_VAULT;1.1;AES256;user;29213472557061\n346237613735630663231633665030306237333831373438353737326463653632666662386563', None)
    assert 'Vault should be in the form of a string' in str(cm.exception)

# Generated at 2022-06-22 14:12:33.080570
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:42.967357
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:47.269388
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = do_vault('mysecret', 'mysecret', 'my salt', 'mysaltfilter')
    unvault = do_unvault(vault, 'mysecret', 'mysaltfilter')
    assert unvault == 'mysecret', "Expected: '%s' Should be equal to '%s'" % ('mysecret', unvault)

    vault = do_vault('mysecret', 'mysecret', wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode), "Expected: '%s' Should be an AnsibleVaultEncryptedUnicode" % type(vault)

    vault = do_vault('mysecret', 'mysecret', wrap_object=False)


# Generated at 2022-06-22 14:12:51.612540
# Unit test for function do_unvault
def test_do_unvault():
    # FIXME: Need to find a way to test this without displaying the secret passphrase on console
    # At present no test is written as there is a risk it will show the secret passphrase
    # in the console on failure.
    pass

# Generated at 2022-06-22 14:13:01.942606
# Unit test for function do_vault
def test_do_vault():
    data_str = "sensitive data"
    data_int = 1234

    secret_str = "secret"
    secret_int = 1234

    # do_vault takes in two required parameters, data and secret.
    # We need to see every combination of having a string, integer, or undefined type for data and secret.

    # string for data and string for secret
    assert isinstance(do_vault(data_str, secret_str), AnsibleVaultEncryptedUnicode)
    # string for data and integer for secret
    assert isinstance(do_vault(data_str, secret_int), AnsibleVaultEncryptedUnicode)
    # string for data and undefined for secret
    assert isinstance(do_vault(data_str, Undefined), AnsibleVaultEncryptedUnicode)

    # integer for data and string

# Generated at 2022-06-22 14:13:16.331323
# Unit test for function do_vault
def test_do_vault():
    import uuid
    secret = str(uuid.uuid4())
    cleartext = 'abcdeg'
    salt = 'asdf'
    vaultid = 'filter_default'
    # wrap_object=False
    encrypted_data = do_vault(cleartext, secret, salt, vaultid)
    decrypted_data = do_unvault(encrypted_data, secret, vaultid)
    assert cleartext == decrypted_data
    # wrap_object=True
    encrypted_data = do_vault(cleartext, secret, salt, vaultid, True)
    decrypted_data = do_unvault(encrypted_data, secret, vaultid)
    assert cleartext == decrypted_data


# Generated at 2022-06-22 14:13:23.474212
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = "testsecret"
    vaultid = 'filter_default'

    # Test case 1: same key and message
    input = "!vault|%s|$ANSIBLE_VAULT;1.1;AES256;testmessage\n636138663332346163383861383833373566343335623931666361303462333862326339363633\n656434393863316239626666653839333239356664663138666439356664363066643863366162\n34643361" % vaultid
    assert do_unvault(input, test_secret, vaultid) == "testmessage"

    # Test case 2: Non-matching key

# Generated at 2022-06-22 14:13:32.864808
# Unit test for function do_vault

# Generated at 2022-06-22 14:13:42.839156
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import _get_vault_secret
    vaultsecret = _get_vault_secret(b'secret')

    def check_unvault_return_type(s):
        if isinstance(s, binary_type):
            assert isinstance(do_unvault(s, vaultsecret), to_native(s).__class__)
        else:
            assert isinstance(do_unvault(s, vaultsecret), s.__class__)

    check_unvault_return_type(u'string')
    check_unvault_return_type(b'bytes')

# Generated at 2022-06-22 14:13:51.239543
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    salt = 'bar'
    vaultid = 'filter_id'
    data = 'xyz'

    actual_result = do_vault(data, secret, salt, vaultid)

    expected_result = '$ANSIBLE_VAULT;1.1;AES256\n'
    expected_result += '3031323334353637383932353037333332366665653437646238613837356638626363313239636438'
    expected_result += '33626262636331666565364643061363864653361356435346633\n'
    expected_result += '303633343664323432373935663861623661626535663138323363326438323232336238633164623665\n'

# Generated at 2022-06-22 14:14:02.464365
# Unit test for function do_vault
def test_do_vault():
    ''' Test for plain text, unicode text and Jinja2.Undefined '''

    secret = 'password'
    data = 'secret'
    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible\n31356464303739633461336562653537643437396132616461393133346466343461346630366462\n38353334363037346435303739393533623932333763373836663531643566326632616633393466\n3035386462316235633861613531333533623863633663662613433643563666238323766323631\n323533363435623266383230386565\n')

# Generated at 2022-06-22 14:14:09.864462
# Unit test for function do_vault
def test_do_vault():
    # Mock an AnsibleVaultEncryptedUnicode Object
    class AnsibleVaultEncryptedUnicodeObject:
        def __init__(self, secret):
            ''' The Vault class has a decrypt method so we are mocking it '''
            self.secret = secret
            self.decrypt = 'decrypt method'

    # Mock the VaultLib class
    class VaultLibObject:
        def __init__(self):
            ''' The VaultLib class has an encrypt method so we are mocking it '''
            self.secret = AnsibleVaultEncryptedUnicodeObject
            self.encrypt = 'encrypt method'

    # Test 1: Tests if the filter raises an exception if the data variable is not a string
    temp_tuple = ('tuple', 'tuple')

# Generated at 2022-06-22 14:14:16.966006
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted

    secret = 'password'
    vaultid = 'vault_id'
    salt = 'salt'

    vs = VaultSecret(secret)
    vl = VaultLib([(vaultid, vs)])
    vault = vl.encrypt(b'hello', salt=salt)
    assert is_encrypted(vault)

    data = do_unvault(vault, secret, vaultid)
    assert data == 'hello'

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-22 14:14:26.725884
# Unit test for function do_vault
def test_do_vault():
    # ensure that error occurs if secret is not a string
    failed = True
    try:
        do_vault('my secret', 5)
    except AnsibleFilterTypeError:
        failed = False
    assert not failed

    # ensure that error occurs if data is not a string
    failed = True
    try:
        do_vault(5, 'hello')
    except AnsibleFilterTypeError:
        failed = False
    assert not failed

    # check if vaulting is happening correctly
    assert do_vault('hello', 'hello') != 'hello'
    assert do_vault('my secret', 'hello') != 'my secret'



# Generated at 2022-06-22 14:14:36.906596
# Unit test for function do_unvault
def test_do_unvault():
    class MyVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):

        def __init__(_, data):
            self.data = data

    # test as if vault is normal string
    assert do_unvault("secret", "password", 'filter_default') == "secret"

    # test if vault is AnsibleVaultEncryptedUnicode and password is correct
    assert do_unvault(MyVaultEncryptedUnicode("secret"), "password", 'filter_default') == "secret"

    # test if vault is AnsibleVaultEncryptedUnicode and password is wrong
    result = do_unvault(MyVaultEncryptedUnicode("secret"), "password1")
    assert result == "Invalid Vault Password"

    # test if vault is normal string and password is wrong, vault will be unvault

# Generated at 2022-06-22 14:14:53.466995
# Unit test for function do_vault
def test_do_vault():
    secret = 'my_secret_password'
    data = 'clear text data'
    vault_data = do_vault(data, secret)

# Generated at 2022-06-22 14:15:02.429988
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'foosecret'
    vaultid = 'foovaultid'

    # test 1: check that a plain text value is returned as-is
    assert do_unvault('foobar', secret, vaultid) == 'foobar'

    # test 2: check that an encrypted value is returned as plain text
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n62643135343232627630613838643865633763376231326435346430313039663735653038643737\n32316536653862373163313239346565366136323163323665', secret, vaultid) == 'password'

    # test 3: check that an error is raised if secret is not a string

# Generated at 2022-06-22 14:15:12.920654
# Unit test for function do_vault
def test_do_vault():
    my_secret = 'my_secret'

    # Test strings
    result = do_vault('my_data', my_secret)
    assert is_encrypted(result)

    result = do_vault('my_data', my_secret, wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Test multiple strings
    result = do_vault('another_data', my_secret, 'another_filter_default')
    assert is_encrypted(result)

    result = do_vault('another_data', my_secret, 'another_filter_default', wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # Test non-string argument
    bad_secret = {'a': 1, 'b':2, 'c':3}

# Generated at 2022-06-22 14:15:24.237019
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == None
    assert do_unvault(None, 'nosuchsecret') == None
    assert do_unvault(None, AnsibleVaultEncryptedUnicode(None)) == None
    assert do_unvault(AnsibleVaultEncryptedUnicode(None), 'nosuchsecret') == None
    # Ensure we handle a AnsibleVaultEncryptedUnicode object, even if the secret is wrong
    assert do_unvault(AnsibleVaultEncryptedUnicode(None), 'nosuchsecret') == None

# Generated at 2022-06-22 14:15:31.019313
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import tempfile
    import yaml

    class DictToObject(object):
        ''' Helper class to convert a dictionary to an object'''
        def __init__(self, data):
            for name, value in data.items():
                setattr(self, name, self._wrap(value))

        def _wrap(self, value):
            if isinstance(value, (tuple, list, set, frozenset)):
                return type(value)([self._wrap(v) for v in value])
            else:
                return DictToObject(value) if isinstance(value, dict) else value


# Generated at 2022-06-22 14:15:41.107343
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:48.697114
# Unit test for function do_unvault
def test_do_unvault():
    data = 'hello world'
    secret = 'password'
    vaultid = 'filter_default'
    result = do_vault(data=data, secret=secret, vaultid=vaultid)
    assert isinstance(result, string_types)
    assert isinstance(do_unvault(vault=result, secret=secret), string_types)
    assert data == do_unvault(vault=result, secret=secret, vaultid=vaultid)

# Generated at 2022-06-22 14:16:00.160450
# Unit test for function do_unvault
def test_do_unvault():
    import unit_tests.helper as unit_tests_helper

    plain_text = 'This is some secret'
    secret = "secret"

# Generated at 2022-06-22 14:16:10.482918
# Unit test for function do_unvault
def test_do_unvault():
    print("Running unit test for function do_unvault")

# Generated at 2022-06-22 14:16:15.692546
# Unit test for function do_unvault
def test_do_unvault():
    input_vault = u'$ANSIBLE_VAULT;1.1;AES256;test_vaultid\n' \
                  u'346236656131636365336366353834363563633664353039373264663137656531656137313663\n' \
                  u'63653436333163343737623861306138666662360a641\n'

    input_secret = u'This is secret'

    assert do_unvault(input_vault, input_secret) == u'anyvars'


# Generated at 2022-06-22 14:16:18.813303
# Unit test for function do_unvault
def test_do_unvault():
    assert 'hello' == do_unvault(do_vault('hello', 'hello'), 'hello')


# Generated at 2022-06-22 14:16:31.204722
# Unit test for function do_vault
def test_do_vault():
    password = 'password'
    secret = 'qiWZM2gv0o0mwMxF'
    salt = 'v0iD6ECn'
    vaultid = 'filter_default'
    not_encrypted = 'not_encrypted'

# Generated at 2022-06-22 14:16:43.701784
# Unit test for function do_vault
def test_do_vault():
    import sys
    import unittest
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    from ansible.parsing.vault import VaultSecret

    class TestAnsibleModuleTestCase(unittest.TestCase):
        def setUp(self):
            self.real_stderr = sys.stderr
            self.real_stdout = sys.stdout
            sys.stderr = StringIO()
            sys.stdout = StringIO()

        def tearDown(self):
            sys.stderr = self.real_stderr
            sys.stdout = self.real_stdout

        def test_vault_encrypt(self):
            secret = 'secret'
            data = 'data'
            vault_

# Generated at 2022-06-22 14:16:55.288501
# Unit test for function do_vault
def test_do_vault():
    from ansible.compat.tests import unittest
    from . import filters_common

    class TestDoVault(unittest.TestCase):
        vault_secret = '$ANSIBLE_VAULT;1.1;AES256;ansible\r\n31323334353637383930313233343536373839303132333435363738393031323\r\n33435363738393031323334353637383930313233343536373839303132333435\r\n36373839303132333435363738393031323334353637383930313233343536373\r\n8393031323334353637383930\r\n'

# Generated at 2022-06-22 14:17:07.781278
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    data = filters['unvault']({}, 'secret')
    assert data == '', "unvault filter did not work"

    data = filters['unvault']('', 'secret')
    assert data == '', "unvault filter did not work"

    data = filters['unvault']('test', 'secret')
    assert data == 'test', "unvault filter did not work"


# Generated at 2022-06-22 14:17:15.184518
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) is None
    assert do_unvault(Undefined(), Undefined()) is Undefined()
    assert do_unvault('', '') == ''
    assert do_unvault('', 'secret') == ''
    assert do_unvault(Undefined(), 'secret') is Undefined()
    assert do_unvault('', Undefined()) is Undefined()



# Generated at 2022-06-22 14:17:19.748464
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    plain_text = 'super secret data'
    vault = do_vault(plain_text, secret)

    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == plain_text



# Generated at 2022-06-22 14:17:29.079875
# Unit test for function do_vault

# Generated at 2022-06-22 14:17:38.607378
# Unit test for function do_vault
def test_do_vault():
    from datetime import datetime
    import json
    import pytest

    secret = 'fake_secret'

    a = {
        'a': 1,
        'b': 'hello',
        'c': [1, 2, 3],
        'd': {
            'a': 'foo',
            'b': 3
        },
        'e': datetime(2014, 12, 31, 23, 59, 59, 999999)
    }
    vault = do_vault(a, secret)
    # convert back to dict
    b = json.loads(do_unvault(vault, secret))
    # assert that the two objects are equal
    assert a == b



# Generated at 2022-06-22 14:17:49.938374
# Unit test for function do_vault
def test_do_vault():
    # Test with string secret
    test_secret = 'vault_secret'

# Generated at 2022-06-22 14:18:01.811039
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:14.783962
# Unit test for function do_vault
def test_do_vault():
    """Returns a string that can be decrypted with do_unvault"""
    assert do_vault('bacon', 'password', wrap_object=False) == '$ANSIBLE_VAULT;1.1;AES256\r\n39626634653163623461316365646362626631323133633961386166386336646332393562623833\r\n63653536333865313961316466656331666330653265626433393938326565653335363431666533\r\n63663938366461643833393239393136303361616431663461396463356534386637373530353133\r\n35306536366161396535373637393762386163633431663930\r\n'

# Generated at 2022-06-22 14:18:27.847273
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:32.129522
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'my_secret_password'
    salt = None

    vault = do_vault(data, secret, salt)
    assert vault != ''


# Generated at 2022-06-22 14:18:41.485735
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("foo", "secret")

# Generated at 2022-06-22 14:18:53.837543
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:04.192526
# Unit test for function do_vault
def test_do_vault():
    import pytest

    secret = ''
    salt = None
    vaultid = 'filter_default'

    with pytest.raises(AnsibleFilterTypeError) as e:
        secret = ''
        salt = None
        result = do_vault('', secret, salt, vaultid)
    assert "Secret passed is required to be as string" in str(e.value)

    with pytest.raises(AnsibleFilterTypeError) as e:
        secret = 'secret'
        salt = None
        result = do_vault(123, secret, salt, vaultid)
    assert "Can only vault strings" in str(e.value)

    secret = 'secret'
    salt = None
    result = do_vault('', secret, salt, vaultid)
    assert '$ANSIBLE_VAULT' in result

   

# Generated at 2022-06-22 14:19:16.061044
# Unit test for function do_vault
def test_do_vault():
    secret = u'foo'
    data = u'bar'
    vault = do_vault(data, secret)
    #assert vault == u'$ANSIBLE_VAULT;1.1;AES256\n34366664393165666432306261323133313632316137313431323666356265626537316166626564\n61363334313261386132353235316165653764303666633562300a66316632393962386166363339\n65656132353062366336393430656463326230363063383939323766363463303662653964353865\n3032356334393565386432656533636431303966343133666331633332633365353637363764

# Generated at 2022-06-22 14:19:23.669502
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six.moves import StringIO
    import ansible.plugins.filter.core as core_filters
    # Ansible does not have a good way to mock this yet
    # https://github.com/ansible/ansible/issues/56156
    core_filters.display.display = lambda msg, color=None: print("%s" % msg)
    # Save original stdout
    old_stdout = sys.stdout
    # Set stdout to StringIO
    sys.stdout = StringIO()
    # Test data
    data = 'password'
    secret = 'sekret'
    wrapped = True
    vault = do_vault(data=data, secret=secret, wrap_object=wrapped)
    # Compare output

# Generated at 2022-06-22 14:19:36.309466
# Unit test for function do_vault
def test_do_vault():
    from nose.tools import eq_, assert_raises

    # Tests for invalid input
    with assert_raises(AnsibleFilterTypeError):
        do_vault(1, 'secret')
    with assert_raises(AnsibleFilterTypeError):
        do_vault('data', 1)

    # Test for Undefined
    eq_(Undefined, do_vault(Undefined, Undefined))

    # Test for valid data

# Generated at 2022-06-22 14:19:50.464127
# Unit test for function do_vault
def test_do_vault():
    import sys
    import os
    import shutil
    import tempfile
    import hashlib
    import errno
    import random

    test_dir = tempfile.mkdtemp()
    vault_pass_file = os.path.join(test_dir, 'vault.txt')
    secret_file = os.path.join(test_dir, 'secret.txt')
    hash_file = os.path.join(test_dir, 'hash.txt')


# Generated at 2022-06-22 14:20:00.747273
# Unit test for function do_vault
def test_do_vault():
    test_secret = "test_secret"
    test_data = "test_data"
    test_vaultid = "test_vaultid"
    test_salt = "test_salt"

    result = do_vault(test_data, test_secret)
    assert type(result) == str

    result = do_vault(test_data, test_secret, test_salt)
    assert type(result) == str

    result = do_vault(test_data, test_secret, salt=test_salt, vaultid=test_vaultid)
    assert type(result) == str


# Generated at 2022-06-22 14:20:11.666808
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('abc', 'secret')
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n3065386438306263323462346465653336430346664356163313431623963636335643463356230\n343362346135613130386438666530356262640a363734366137373138343736653938313962353\n6653235616539623733663638363263393435393134373635366535393733616431353934363830\n30386135\n', 'Vault returned incorrect value'


# Generated at 2022-06-22 14:20:21.517330
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:33.959227
# Unit test for function do_vault
def test_do_vault():

    secret = 'password'
    salt = 'salt'
    data = 'data'

# Generated at 2022-06-22 14:20:45.255169
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.2;AES256;'
    vault += 'ansible\n'
    vault += '3936623938666231666337633636326337343666333033323334393533613062\n'
    vault += '3261346362363939663930386634653734323630613632323432336633323030\n'
    vault += '393465643766313832656630643439366435333039313437376435650a346632\n'
    vault += '3135663664323563306435343864663630643630613063643064343031323966\n'

# Generated at 2022-06-22 14:20:48.670711
# Unit test for function do_vault
def test_do_vault():
    try:
        result = do_vault("my_secret_data", "my_secret")
    except Exception as e:
        print('Unexpected exception:', e)
        assert False
    assert result != ''
    assert type(result) is str
    assert '$ANSIBLE_VAULT;' in result


# Generated at 2022-06-22 14:21:01.517308
# Unit test for function do_vault
def test_do_vault():
    import base64
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import string_types, binary_type
    import re

    secret = 'password'
    salt = 'NaCL'
    # ensure generated vault is using both 32-bit salt and 64-bit salt
    regex_salt1 = r'^\$ANSIBLE_VAULT\$1\$([a-zA-Z0-9]{16})'

# Generated at 2022-06-22 14:21:05.137845
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('secret', 'testpwd')
    unvault = do_unvault(vault, 'testpwd')
    assert unvault == 'secret'



# Generated at 2022-06-22 14:21:17.968118
# Unit test for function do_vault
def test_do_vault():
    test_data = "test_data"
    test_secret = "test_secret"
    test_salt = 'test_salt'
    test_vault_id = 'test_vault_id'
    test_wrap_object = False
    correct_result = u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61376565396436666530356637353833323530333731323934373863616263613863386133393432\n          35326331623331303934383538333865613566393636333565326131373839366561303966333061\n          623437616462363131626565653532636133363063313366363962330a'

# Generated at 2022-06-22 14:21:31.626630
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    from jinja2.loaders import DictLoader

    data = 'hello'

    environment = Environment(loader=DictLoader({'test.j2': '{{ data | vault("secret") }}'}))
    template = environment.get_template('test.j2')
    result = template.render(data=data)

    # Vaulted data is always different, since it includes a timestamp
    assert result.startswith('$ANSIBLE_VAULT;1.1;AES256')
    assert do_unvault(result, 'secret') == data



# Generated at 2022-06-22 14:21:44.590479
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_string', 'password') == '$ANSIBLE_VAULT;1.2;AES256;vault_default\n353235353665623563336662656466626433333762666164653766373433663336365393737623336\n3833383464636162326261663136393964313434366164663836373365313866373637663861333669\n3139653737326235386239383739653332333263653164653836386631623336346539363765383562\n3263353336356666313431626261306435363464373562366366316662326432363233316334613764\n656434356636383465'