

# Generated at 2022-06-22 14:11:55.228233
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;5;5;5;0epzOdkh1F0hcWlQQy85OUdiZWNzUFZhc0ZGZlZjYkxoaEIxVkw0MERRcGpvS1I4M1NkcEt4N2tYemZmNFNVRg==;xWSHu1nBHTHnjmFk9wi1zg==','') == 'secret_test'

# Generated at 2022-06-22 14:12:03.727610
# Unit test for function do_vault
def test_do_vault():
    import os
    import tempfile
    from .test_data import test_vault_template

    # read test data from the file vault.yml
    testdata = test_vault_template()

    # create temp dir for vault key and the file to hold the content
    tmpdir = tempfile.mkdtemp()
    tmp_vault_key = os.path.join(tmpdir, 'vault_key')
    tmp_vault_content = os.path.join(tmpdir, 'vault_content')

    # write vault key to a temp file
    with open(tmp_vault_key, 'w+') as fout:
        fout.write(testdata['vault_key'])
        fout.seek(0)

    # write vault content to a temp file

# Generated at 2022-06-22 14:12:12.966011
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:20.492242
# Unit test for function do_unvault
def test_do_unvault():
    # Testing function with following parameter patterns
    item = 'test'
    secret = 'mysecret'
    vaultid = 'default'

    # Asser True for string types
    assert isinstance(item, str)

    # Asser True for string types
    assert isinstance(secret, str)

    # Asser True for string types
    assert isinstance(vaultid, str)

    # Asser True for string types
    assert isinstance(do_unvault(item, secret, vaultid), str)

# Generated at 2022-06-22 14:12:33.133909
# Unit test for function do_vault
def test_do_vault():
    secret = "A3qNwT/1tTigT2e8/zJf1A=="

# Generated at 2022-06-22 14:12:41.142124
# Unit test for function do_vault
def test_do_vault():
    import os
    import yaml
    yaml.dump = lambda d,f: f.write(yaml.dump(d))

    vault_secret = 'foo' # enter your vault secret
    vault_test = """
test_vault1: test_value
test_vault2: test_value2"""

    vault_result = None
    result = None

    vault_result = do_vault(vault_test, vault_secret)

    try:
        result = do_unvault(vault_result, vault_secret)
    except AnsibleFilterError:
        assert False

    assert vault_test == result

# Generated at 2022-06-22 14:12:49.059182
# Unit test for function do_unvault
def test_do_unvault():
    # initialize global display
    global display
    display = Display()
    # set the secret
    secret = 'secret'
    # encrypt the test string with secret
    encrypt = do_vault('test', secret, wrap_object=True)
    # Decrypt the test string with secret
    decrypt = do_unvault(encrypt, secret)
    # compare the result
    if decrypt == 'test':
        display.display('OK')
    else:
        display.display('Unable to decrypt properly')


# Generated at 2022-06-22 14:13:01.084215
# Unit test for function do_vault
def test_do_vault():
    # Encrypt with salt
    test = do_vault('test', 'secret', salt='testsalt')

# Generated at 2022-06-22 14:13:05.426378
# Unit test for function do_unvault
def test_do_unvault():

    test_cases = [
        ({'vault': u'$ANSIBLE_VAULT;1.2;AES256;test_test\n633834353936623163326134363736356234306436666464326234316263386131306335633835\n6363633462616232333663633861316132396263326135613461313530313066363162336162633\n61313466303130656330343533626338393136', 'secret': 'secret', 'vaultid': 'wildcard', 'result': 'this is a test'},),
    ]

    for args in test_cases:
        result = do_unvault(**args[0])

# Generated at 2022-06-22 14:13:18.255317
# Unit test for function do_unvault
def test_do_unvault():

    """
    Run this unit test by executing below command
    ansible-playbook -i inventory/tasks/test/unittest.py
    """

    import unittest

    class TestUnvault(unittest.TestCase):
        def test_unvault(self):
            data = "Hey, this is a secret message!"
            secret = "password"
            vault = do_vault(data, secret)
            self.assertIsNotNone(vault)
            text = do_unvault(vault, secret)
            self.assertIsNotNone(text)
            self.assertEqual(data, text)
            self.assertEqual(is_encrypted(text), False)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestUnvault)
    unittest.TextTestRunner

# Generated at 2022-06-22 14:13:31.705005
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import binary_type

    test_vault = b'$ANSIBLE_VAULT;1.2;AES256;ansible_test^\
    \n16123597469306639238652324858118469625281288573708902791597381864563018073^\
    \n16123597469306639238652324858118469625281288573708902791597381864563018073^\
    \n20880172823247259869140952705993479678258659494497662490924885525555891533'


# Generated at 2022-06-22 14:13:38.493752
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Template
    t = Template('{{ secret | vault }}')
    result = t.render(secret='secret')
    assert result.startswith('$ANSIBLE_VAULT;')

    t = Template('{{ secret | vault(wrap_object=True) }}')
    result = t.render(secret='secret')
    assert isinstance(result, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-22 14:13:48.729764
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'secret'
    salt = 'salt'
    vaultid = 'unit_test_do_vault'

    # Create vault with salt
    vault_salt = do_vault(data, secret, salt, vaultid)

    # Create vault without salt
    vault_no_salt = do_vault(data, secret, None, vaultid)

    # Test that vault w/ salt and w/o salt are not the same
    assert vault_salt != vault_no_salt

    # Test that vault with salt can be decrypted with salt
    assert data == do_unvault(vault_salt, secret, vaultid)

    # Test that vault without salt cannot be decrypted with salt

# Generated at 2022-06-22 14:13:51.581886
# Unit test for function do_unvault
def test_do_unvault():
    # encrypted data
    data = VaultSecret("bar").get_bytes()
    # secret
    secret = "foo"

    # plaintext
    plaintext = do_unvault(data, secret)
    assert plaintext == "bar"


# Generated at 2022-06-22 14:14:02.661831
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'whitesalt'
    no_wrap_object_vault = ('$ANSIBLE_VAULT;1.1;AES256;whitesalt\n'
                            '393636666564633663623562316463366231326661663362646635336666626664343839386534\n'
                            '393636666564633663623562316463366231326661663362646635336666626664343839386534\n')

    wrap_object_vault = AnsibleVaultEncryptedUnicode(no_wrap_object_vault)

    assert do_vault('secret', secret, salt, wrap_object=False) == no_wrap_object_vault

# Generated at 2022-06-22 14:14:13.572111
# Unit test for function do_unvault
def test_do_unvault():
    expected = "test"
    test_filter = FilterModule()

# Generated at 2022-06-22 14:14:26.623834
# Unit test for function do_unvault
def test_do_unvault():
    secret = "superSecret123!"
    vault = "$ANSIBLE_VAULT;1.1;AES256\r\n61643432366231353566383438333038616463623539383037300a61376263656335656538353\r\n6613330626661376538356334613861316265663430626332653364360a35643036346630326463\r\n333562383564666164393261316132613339636339383634356566353639663166653039613365\r\n6237613130313732303465636462356332376333336637393664383136666434\r\n"
    result = do_unvault(vault, secret)

# Generated at 2022-06-22 14:14:33.670266
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('secret string', 'secret') == '$ANSIBLE_VAULT;1.1;AES256;test\n343738303833353933363738663762336662323639346361626662343865323233316661303932633835\n303365336466363661376136653364343262396435636332343166356433313738616262623166613137\n3362653939\n'


# Generated at 2022-06-22 14:14:36.661340
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'ansible'
    ret = do_vault(data, secret)
    assert ret.startswith('$ANSIBLE_VAULT;')
    assert ret.endswith(data)


# Generated at 2022-06-22 14:14:44.380930
# Unit test for function do_vault
def test_do_vault():
    import json

    # test empty input
    try:
        do_vault('', '')
        assert False
    except AnsibleFilterError as e:
        assert e.orig_exc.__class__.__name__ == 'UnboundLocalError'

    # test inconsistent length of secret and vaultid
    try:
        do_vault('aaa', 'bbb,ccc', vaultid='ddd')
        assert False
    except AnsibleFilterError as e:
        assert e.orig_exc.__class__.__name__ == 'UndefinedError'

    # -- salt is not used for hmac-sha256 --
    # test inconsistent length of salt and vaultid

# Generated at 2022-06-22 14:14:49.047921
# Unit test for function do_vault
def test_do_vault():
    data = 'secret'
    secret = 'secret'
    salt = 'salt'
    assert do_vault(data, secret, salt)



# Generated at 2022-06-22 14:14:54.438136
# Unit test for function do_vault
def test_do_vault():

    secret = 'secret'
    data = 'data'
    salt = vaultid = 'filter_default_test'

    result = do_vault(data, secret, salt, vaultid, wrap_object=False)
    assert isinstance(result, str)
    assert is_encrypted(result)


# Generated at 2022-06-22 14:14:56.209094
# Unit test for function do_vault
def test_do_vault():
    do_vault('test', 'secret', 'salt', 'vault_id')


# Generated at 2022-06-22 14:15:02.465627
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:13.015539
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:18.776812
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    secret = 'mysecret'
    data = 'mydata'
    salt = 'mysalt'
    vaultid = 'test_vault_id'
    vault = do_vault(data, secret, salt, vaultid)
    assert isinstance(vault, to_bytes)
    assert vault.startswith(b'$ANSIBLE_VAULT')


# Generated at 2022-06-22 14:15:30.594429
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:40.871590
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$6$0Y2NWiSo0hRsJ6p9$9spWfKG0i6dDsvhfW.1V7ArpT/KsV7Gc2Q8iT7XOdDkMV7K1tW8z0Fy34Srh0zR7SdFo8Plv7Z9BW4AqkVD4p/'

# Generated at 2022-06-22 14:15:50.908754
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n31393430333133363433663033643835313063656639646466306437316330643737313063376532\n39656434363537353532666533306137616437306434336335620a30643733626464663265386461\n30636463653931343264663632636132613637616232653335383932643065316539353963316165\n363430636461666361326566\n", "password") == "test"


# Generated at 2022-06-22 14:15:58.061035
# Unit test for function do_vault
def test_do_vault():
    # Given
    data = 'Hello world'
    secret = 'foo'
    salt = 'qux'
    vaultid = 'foo'
    wrap_object = False

    # When
    try:
        output = do_vault(data, secret, salt, vaultid, wrap_object)
    except (AnsibleFilterError, AnsibleFilterTypeError):
        output = None

    # Then
    assert output is not None


# Generated at 2022-06-22 14:16:09.472512
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:14.187474
# Unit test for function do_vault
def test_do_vault():
    h = "a" * 64
    d = "hello"
    s = do_vault(d, h)
    assert do_unvault(s, h) == "hello"



# Generated at 2022-06-22 14:16:26.783280
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:29.831964
# Unit test for function do_unvault
def test_do_unvault():
    '''
    Unit test for function do_unvault
    '''
    assert do_unvault(vault_str, vault_str_secret) == vault_str_no_id


# Generated at 2022-06-22 14:16:32.974932
# Unit test for function do_vault
def test_do_vault():
    secret = "test password"
    data = "test data"
    vault = do_vault(data, secret)
    assert isinstance(vault, str)



# Generated at 2022-06-22 14:16:45.223791
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:55.662955
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.errors import AnsibleFilterError
    from __main__ import do_unvault

    secret = 'NoVault'
    vaultid = 'filter_default'


# Generated at 2022-06-22 14:17:07.993068
# Unit test for function do_vault
def test_do_vault():
    secret = to_native(VaultSecret('my_secret'))

# Generated at 2022-06-22 14:17:20.495863
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.text_utils import last_match
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import crypt
    import base64

    data = 'mypass'
    secret = 'mysecret'

    try:
        vault = do_vault(data, secret)
    except Exception as e:
        assert False, e

    try:
        vault2 = do_vault(data, secret)
    except Exception as e:
        assert False, e

    # function do_vault returns a string with a different vault id each time.
    # Check that the first 8 characters are the vault id
    # and that the first characters of the salt are '$6$' for crypt algorithm 6
   

# Generated at 2022-06-22 14:17:31.975758
# Unit test for function do_vault
def test_do_vault():
    secret = "test"
    data = "test-data"
    salt = "test-sa"
    vaultid = "test-vaultid"
    def_vaultid = "filter_default"

# Generated at 2022-06-22 14:17:42.431634
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils import basic

    my_secret = 'my_secret'
    test_data = 'test_data'

    display.deprecated('Testing vaulting with a plaintext password is now deprecated for ansible-test. Please use ansible-vault commands to test vaulting')

    results = do_vault(test_data, my_secret)
    assert isinstance(results, (string_types, binary_type))
    assert results != test_data

    results = do_unvault(results, my_secret)
    assert isinstance(results, (string_types, binary_type))
    assert test_data == results

    results = do_vault(test_data, my_secret, wrap_object=True)
    assert isinstance(results, AnsibleVaultEncryptedUnicode)

    results = do_

# Generated at 2022-06-22 14:17:51.912410
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n376564353630643739396435373064653831376435383037363832316666363739373034643230\n656337626261613031613761363162313336323762636639663865313363623965353737393331\n35333738316735613864635d0a'
    assert AnsibleVaultEncryptedUnicode(do_vault('test', 'secret')) == do_vault('test', 'secret', wrap_object=True)


# Generated at 2022-06-22 14:18:01.897252
# Unit test for function do_vault
def test_do_vault():

    from ansible.module_utils.six.moves import builtins
    import os

    import pytest

    try:
        # Third party imports
        from unittest.mock import patch, mock_open, MagicMock
    except ImportError:
        # Python 2.x fallback
        from mock import patch, mock_open, MagicMock

    # These functions can be used in the tests to run code that uses the
    # python builtins.open() function. Doing this enables the code to be
    # tested while still allowing code coverage collection.
    def run_open_pyfile(filename, mode, mock_file):
        with builtins.open(filename, mode) as f:
            f.write(mock_file.read())


# Generated at 2022-06-22 14:18:14.874855
# Unit test for function do_vault
def test_do_vault():
    secret = 'my-secret'
    salt = 'my-salt'
    vaultid = 'test'
    data = 'my-data'

    encrypted_data = do_vault(data, secret, salt, vaultid)


# Generated at 2022-06-22 14:18:27.971995
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'salt'
    data = 'data'


# Generated at 2022-06-22 14:18:38.978734
# Unit test for function do_vault
def test_do_vault():

    # Create a test Vault instance
    class TestVault(VaultLib):
        def __init__(self):
            self.enc_data = ''

        def encrypt(self, data, secret, vaultid, salt=None):
            self.enc_data = data
            return data

    # Create a test VaultSecret instance
    secret = VaultSecret('thisismysecret')

    # Create a FilterModule instance
    fm = FilterModule()

    # Try encrypting some dummy data
    test_data = 'I am some dummy data'

    # Try encrypting some dummy data using the do_vault function
    result = fm.filters()['vault'](test_data, secret)

    assert result == test_data

    # Try encrypting a list
    test_data = ['some', 'dummy', 'data']

    # Should

# Generated at 2022-06-22 14:18:42.719376
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'mysecret') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault('foo', 'foo') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault(1, 'foo') == '1'


# Generated at 2022-06-22 14:18:51.591336
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('test', 'password')
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n39393738353064633831643236656131306633336263636537386538383638343762386163646361\n62303066336238613161373263386165653261323366623065653539356263626233316366663766\n3366343562623731309a0a\n'


# Generated at 2022-06-22 14:19:03.432886
# Unit test for function do_vault
def test_do_vault():

    secret = 'password'
    salt = 'foo'

    data = do_vault('mysecret', secret)

# Generated at 2022-06-22 14:19:13.275081
# Unit test for function do_unvault
def test_do_unvault():

    # Test for unvaulting in string format
    assert(do_unvault("$ANSIBLE_VAULT;1.2;AES256;foo\n633139646639666665373637343937623737333537643132626231643765323231636639633461666\n6134313761366132313165333234656437373465313165613331623639653866643636666430336664\n62393134663964653137653162343861396465383339", "bar", 'test_default') == "baz")

    # Test for unvaulting in AnsibleVaultEncryptedUnicode format

# Generated at 2022-06-22 14:19:23.285180
# Unit test for function do_unvault

# Generated at 2022-06-22 14:19:27.252907
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    salt = None
    vaultid = 'filter_default'
    vault = do_vault(data, secret, salt, vaultid)
    assert is_encrypted(vault)



# Generated at 2022-06-22 14:19:39.745320
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3

    class DummySecret:
        def __init__(self, secret):
            self.__secret = secret

        def __str__(self):
            return self.__secret

    class DummyVaultLib:
        def __init__(self):
            self.calls = list()

        def encrypt(self, data, secret, vaultid='filter_default', salt=None):
            self.calls.append({'data': data, 'secret': secret, 'vaultid': 'filter_default', 'salt': salt})
            return 'dummy'

    # test 1: without salt
    dummy_secret = 'dummy'
    dummy_data = 'dummy'
    dummy_vaultlib = DummyVaultLib()

# Generated at 2022-06-22 14:19:45.723628
# Unit test for function do_unvault
def test_do_unvault():
    vault_id = "filter_default"
    secret = "secret"
    plaintext = "plaintext"

    # case where vault data is plaintext
    input = "plaintext"
    result = do_unvault(input, secret, vault_id)
    assert result == plaintext

    # case where vault data is unicode
    input = u"plaintext"
    result = do_unvault(input, secret, vault_id)
    assert result == plaintext

    # case where vault data is encrypted
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    encrypted = vl.encrypt(to_bytes(plaintext), vs, vault_id)
    result = do_unvault(encrypted, secret, vault_id)
    assert result == plaintext

    # case where encrypted is an

# Generated at 2022-06-22 14:19:58.274577
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.hashing import secure_hash
    from ansible.module_utils.basic import bytes_to_human
    secret = secure_hash("test")
    # random salt
    salt = os.urandom(16)
    # encrypt a small amount of data to keep the test short
    data = ''.join([chr(x) for x in range(0, 255)])[:32768]
    wrapped = False
    # encrypt, then decrypt the unencrypted data
    # to see if the result matches
    encrypted = do_vault(data, secret, salt, wrap_object=wrapped)
    decrypted = do_unvault(encrypted, secret)

    assert data == decrypted, "Encryption returned a different value: %s" % decrypted

# Generated at 2022-06-22 14:20:06.201416
# Unit test for function do_vault
def test_do_vault():

    # setup
    secret = 'password'
    data = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    # test
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    data = do_unvault(vault, secret, vaultid)

    assert 'secret' == data

if __name__ == '__main__':
    test_do_vault()

# Generated at 2022-06-22 14:20:07.915846
# Unit test for function do_vault
def test_do_vault():

    ret = do_vault('teststring', 'testsecret', 'testsalt', 'testvaultid')

    assert isinstance(ret, string_types)
    assert ret != 'teststring'


# Generated at 2022-06-22 14:20:19.725571
# Unit test for function do_vault
def test_do_vault():
    # Test for invalid type arguments
    try:
        do_vault(16, 'password')
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "With an invalid type for the first argument, AnsibleFilterTypeError should be raised"

    try:
        do_vault('this is a test', 16)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "With an invalid type for the second argument, AnsibleFilterTypeError should be raised"

    # Test for valid arguments
    try:
        result = do_vault("this is a test", "password")
    except AnsibleFilterError:
        assert False, "No exception should be raised when input is valid"
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-22 14:20:32.063078
# Unit test for function do_vault
def test_do_vault():

    from ansible_collections.ansible.community.tests.unit.plugins.filter import test_filters

    fixture = test_filters.FixtureFilters()

# Generated at 2022-06-22 14:20:42.864776
# Unit test for function do_vault
def test_do_vault():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, mock_open

    class TestDoVault(unittest.TestCase):

        def setUp(self):
            self.mock_vault = "vault_encrypted_content"
            self.mock_data = "data to encrypt"
            self.mock_secret = "vault_secret"
            self.mock_salt = "vault_salt"
            self.mock_vaultid = "filter_default"
            self.mock_wrap_object = False


# Generated at 2022-06-22 14:20:53.820882
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("test-vault", "test-secret")

# Generated at 2022-06-22 14:21:01.078990
# Unit test for function do_vault
def test_do_vault():
    display.verbosity = 4

    data = 'This is some data'
    secret = 'my_secret_key'
    salt = 'my_salt_value'
    vaultid = 'test_vault'

    # Test that the function accepts a string as the secret and returns a string containing the encrypted data
    assert isinstance(do_vault(data, secret), str)

    # Test that the function accepts a string as the secret, a string as the salt, and returns a string containing the encrypted data
    assert isinstance(do_vault(data, secret, salt=salt), str)

    # Test that the function accepts a string as the secret, a string as the salt, a string as the vaultid, and returns a string containing the encrypted data

# Generated at 2022-06-22 14:21:04.946074
# Unit test for function do_vault
def test_do_vault():
    vaulted = do_vault('password', 'secret', 'salt', 'id')
    assert is_encrypted(vaulted)

    vaulted = do_vault('password', 'secret', 'salt', 'id', True)
    assert isinstance(vaulted, AnsibleVaultEncryptedUnicode)
    assert vaulted.data == 'password'
    assert is_encrypted(vaulted)



# Generated at 2022-06-22 14:21:17.825143
# Unit test for function do_vault
def test_do_vault():
    ansible_vault_string = "!vault |\n" \
                           "          $ANSIBLE_VAULT;1.2;AES256;macintosh\n" \
                           "          39376233653665323862653362373138636234316366633835326262613632323461666239376164\n" \
                           "          63636232656566363632383366366534393962663834653366383234393962646337633631633561\n" \
                           "          6562323432313336656438393864\n" \
                           "          "

    secret = "secret"

    assert ansible_vault_string == do_vault('vault_data', secret)


# Generated at 2022-06-22 14:21:21.237557
# Unit test for function do_vault
def test_do_vault():
    data = 'My dog has fleas'
    secret = 'password'
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(data, secret)



# Generated at 2022-06-22 14:21:33.987717
# Unit test for function do_unvault
def test_do_unvault():
    encrypted_text = b'$ANSIBLE_VAULT;1.1;AES256;ansibleadmin;591422607039646333613331323965343635333834323863613235633766666432666161626463363234326538666133313631643939343765326537346337643861386664646166656364306638376138383164666365623334310a3062336362353334363033396664383634306431643932336161333138623230393839386331396564356334636162393366363463616333303038316431613631323134616534393837353435633833343639'

# Generated at 2022-06-22 14:21:47.264535
# Unit test for function do_vault
def test_do_vault():

    # Here we test each of the case.

    # Test 1: Undefined secret
    secret = Undefined
    data = Undefined
    salt = Undefined
    vaultid = Undefined
    wrap_object = Undefined

    # Expected output:
    # AnsibleFilterTypeError: Secret passed is required to be as string, instead we got: <class 'jinja2.runtime.Undefined'>

    # Test 2: Secret is passed as string
    secret = "vault_password1"
    data = "text to vault"

    # Expected output:
    # $ANSIBLE_VAULT;1.1;AES256
    # 31333064663930646665373534313862313531326238616433353332316363656338633162616539
    # 653534633164613