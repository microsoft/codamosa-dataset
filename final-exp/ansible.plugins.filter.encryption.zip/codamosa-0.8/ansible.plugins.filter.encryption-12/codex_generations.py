

# Generated at 2022-06-22 14:11:48.305527
# Unit test for function do_vault
def test_do_vault():
    return dict(vault=do_vault, unvault=do_unvault)

# Generated at 2022-06-22 14:11:58.011892
# Unit test for function do_vault
def test_do_vault():
    secret = u'secret-phrase'
    data = u'Rosebud'
    vault = '$ANSIBLE_VAULT;1.1;AES256\r\nd0mhFjU6KI0U6Z/UcZd3q/br53Ny/N0z0w44NfTw2pi1obvA8A5n5C5GLdEm9XV7\r\nUlWV7EAD1fqbVt4x8t91Dg==\r\n'
    salt = u'zulk2YwSdSzKj2'
    vaultid = u'filter_default'

    assert do_vault(data, secret, salt, vaultid, False) == vault


# Generated at 2022-06-22 14:12:10.411586
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('data', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n3437346337663635306665373466383232333763393739303161336436386537373533326462323861330a62366238633465396162336331\n'
    assert do_vault('data', 'secret', vaultid='test') == '$ANSIBLE_VAULT;1.1;AES256;test\n3535316230396533663261326132316465663935306530393533636436323135343331666536386439320a3064626532633861363066376561\n'


# Generated at 2022-06-22 14:12:22.370111
# Unit test for function do_unvault
def test_do_unvault():
    if __name__ == '__main__':
        # When the function is used as a filter
        assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;myvault_id\n336435393465393066643537656434306564353332626533323766643533663334303662620a6364393031396166613164323833643666343932366362386165346133316565653037\n633231396137316230333738303635666234373962366266353066663764626130393338393862\n', b'secret123') == 'foo'

        # When the function is used as a function

# Generated at 2022-06-22 14:12:34.224228
# Unit test for function do_vault
def test_do_vault():
    # Test all possible scenarios
    assert do_vault('dummy_data', 'dummy_secret') == '$ANSIBLE_VAULT;1.1;AES256\ntiNjK4TCw7DDA0ZQ2H1K9/t0MVtDv/HWTSY8bTlTQFBN95sNk07zwxEx8X9JpfhK\nDtYTLW8gsEXMhEKjT1voxA==\n'

# Generated at 2022-06-22 14:12:47.129503
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'test_vault'

# Generated at 2022-06-22 14:12:49.439297
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert do_unvault("$ANSIBLE_VAULT;test1234;test1234", "test1234") == "test1234"
    except Exception:
        return False
    return True

if __name__ == "__main__":
    assert test_do_unvault() == True

# Generated at 2022-06-22 14:13:01.286101
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:08.263626
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'password'
    vaultid = 'abc'

    with open('test/test_vault.yml', 'r') as f:
        data = f.read()

    vault = do_vault(data, secret, vaultid=vaultid)

    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault != data

    unvault = do_unvault(vault, secret, vaultid=vaultid)

    assert unvault == data

# Generated at 2022-06-22 14:13:11.052685
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault(VaultSecret(b'foo'), b'bar')
    assert result == 'bar'

# Generated at 2022-06-22 14:13:14.394179
# Unit test for function do_vault
def test_do_vault():
    secret = 'key'
    res = do_vault('password', secret)
    assert isinstance(res, string_types)


# Generated at 2022-06-22 14:13:21.322563
# Unit test for function do_vault
def test_do_vault():
    # create a system random number generator
    random = SystemRandom()
    # choose random secret/password
    password = ''.join([random.choice(
        string.ascii_letters + string.digits + string.punctuation
    ) for i in range(32)])
    # create data to be encrypted
    data = 'secret_data'
    # encrypt data
    vault = do_vault(data, password)
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-22 14:13:24.161716
# Unit test for function do_vault
def test_do_vault():

    encrypted_value = do_vault('test_password', 'secret')

    assert isinstance(encrypted_value, str)



# Generated at 2022-06-22 14:13:28.770942
# Unit test for function do_unvault
def test_do_unvault():
  # Here the test for do_unvault function
  print("\nThis is the test for function do_unvault from do_unvault.py file")
  import pdb; pdb.set_trace()
  assert do_unvault('test', 'secret') == 'test'


# Generated at 2022-06-22 14:13:41.219608
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.parsing.vault import VaultSecret

    secret = 'secret'
    data = 'data'
    vaultid = 'filter_default'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    vault = vl.encrypt(to_bytes(data), vs, vaultid)
    unvault = do_unvault(vault, secret, vaultid)
    assert unvault

# Generated at 2022-06-22 14:13:44.820475
# Unit test for function do_unvault
def test_do_unvault():
    data = "hello world!!"
    try:
        data = do_unvault(do_vault(data, "secret_password"), "secret_password")
    except AnsibleFilterError as e:
        print(e)



# Generated at 2022-06-22 14:13:52.290662
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('foo', 'secret')

# Generated at 2022-06-22 14:14:02.949845
# Unit test for function do_vault
def test_do_vault():
    secret = 'test_secret'
    data = 'test_data'


# Generated at 2022-06-22 14:14:11.285830
# Unit test for function do_unvault
def test_do_unvault():
    text_list = [
        "Hello World!",
        "This needs to be vauted",
        "xyz",
        "1234",
        "This is a good test!",
        "",
        "  ",
        None,
        False,
        True,
        0,
        1,
    ]
    secret_list = [
        "$ANSIBLE_VAULT;1.1;AES256",
        "This is a test of the secret string",
        "This is an un-encrypted secret string",
        0,
        1,
        False,
        True,
        None,
        "Another test string",
        ""
    ]

# Generated at 2022-06-22 14:14:19.015908
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:33.764958
# Unit test for function do_vault
def test_do_vault():
    # Test data values
    vault_password = "ansible"
    input_string = "Passw0rd"
    expected_encrypted_value = "$ANSIBLE_VAULT;1.1;AES256;ansible_filter_default\n63646535613361386361376637306636313236616435633862623166326362323863306163323236\n363938346663316466656233383463336139376233326334366530383361333665666565343061326\n20a\n"
    salt = "1234567890abcdef"

# Generated at 2022-06-22 14:14:42.275945
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:54.284927
# Unit test for function do_vault
def test_do_vault():
    secret = 'this is my secret'
    salt = 'this is my salt'
    data = 'Hello world'
    vaulted_data = do_vault(data, secret, salt, vaultid='test')
    expected_data = '$ANSIBLE_VAULT;1.2;AES256;test\n303262663162303065643834633233653038343637376134313731376334613333326434323266633\n65666137303439653366393162636133346666636336265653464646264653365376436366130653738\n326464373339643537366266643635643338373436386463666563616662343235343665306366\n'

# Generated at 2022-06-22 14:15:02.707594
# Unit test for function do_vault
def test_do_vault():
    import os
    import pytest
    import tempfile
    from ansible.parsing.vault import VaultLib

    datadir = os.path.join(os.path.dirname(__file__), '..', 'data')

    def _do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False):
        return do_vault(data, secret, salt, vaultid, wrap_object)

    # test empty string
    assert _do_vault(u'', u'password') == ''

    password = u'blah'
    sec = VaultSecret(to_bytes(password))
    vl = VaultLib()

    # Test some data
    data = u'This is some data just for test'

# Generated at 2022-06-22 14:15:13.165273
# Unit test for function do_unvault
def test_do_unvault():
    secret = VaultSecret('secret')
    vaultid = 'filter_default'

# Generated at 2022-06-22 14:15:24.572945
# Unit test for function do_unvault
def test_do_unvault():
    # Case #1: Case when Vault secret is not defined
    secret = None
    vault = "$ANSIBLE_VAULT;1.1;AES256;my_name_is 001133445566778899aabbccddeeff00554433221100ffeeddccbbaa99887766"
    try:
        do_unvault(vault, secret)
    except AnsibleFilterError as e:
        if "Secret passed is required to be as string, instead we got: None" in str(e):
            print("TEST #1 - PASSED")
    except Exception as e:
        print("TEST #1 - FAILED")
        print(str(e))

    # Case #2: Case when vault is not defined
    secret = "my_name_is_secret"
    vault = None

# Generated at 2022-06-22 14:15:31.189511
# Unit test for function do_vault
def test_do_vault():
    import string
    import random
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultSecret, VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test is_encrypted

# Generated at 2022-06-22 14:15:40.446322
# Unit test for function do_vault
def test_do_vault():

    correct_data = "test"
    correct_secret = "test"
    correct_salt = "test"
    correct_vaultid = "test"
    correct_wrap_object = True

    test_data = "test"
    test_secret = "test"
    test_salt = "test"
    test_vaultid = "test"
    test_wrap_object = True

    result = do_vault(test_data, test_secret, test_salt, test_vaultid, test_wrap_object)
    result = result.strip()
    result = result.decode('utf-8')

    assert result is not None
    assert test_secret == result


# Generated at 2022-06-22 14:15:51.982323
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'test'

# Generated at 2022-06-22 14:16:03.331115
# Unit test for function do_vault
def test_do_vault():
    import os
    import tempfile
    try:
        from vault import VaultLib
    except ImportError:
        raise AssertionError("Skipping tests as vault library is not installed")

    # generate random strings from the charset below
    from string import ascii_letters, digits
    from random import choice
    charset = ascii_letters + digits
    def gen_random_str(length):
        return ''.join([choice(charset) for _ in range(length)])

    # create a temp file
    temp = tempfile.NamedTemporaryFile(delete=False)
    temp.close()

    # create vault_id
    vault_id = gen_random_str(8)
    # create vault_id1
    vault_id1 = gen_random_str(8)
    # create vault_id2

# Generated at 2022-06-22 14:16:13.809754
# Unit test for function do_unvault
def test_do_unvault():
    # Assert for string
    expected = 'some value'
    actual = do_unvault(do_vault('some value', 'mysecret'), 'mysecret')
    assert actual == expected

    # Assert for unicode
    expected = u'some value'
    actual = do_unvault(do_vault('some value', 'mysecret'), 'mysecret')
    assert actual == expected

    # Assert for vault object
    expected = u'some value'
    actual = do_unvault(do_vault('some value', 'mysecret', wrap_object=True), 'mysecret')
    assert actual == expected

# Generated at 2022-06-22 14:16:26.291807
# Unit test for function do_vault
def test_do_vault():
    # check to make sure we can encrypt a value
    assert do_vault('value', 'secret!', vaultid='foo') == b'!vault'
    # check to make sure we can encrypt a value with a wrap object
    assert do_vault('value', 'secret!', vaultid='foo', wrap_object=True).data == b'!vault'
    # check to make sure we get an error if we try to encrypt a string
    try:
        assert do_vault(1, 'secret!', vaultid='foo') != b'!vault'
    except AnsibleFilterTypeError:
        pass
    except Exception as e:
        print(e)
        assert False
    # check to make sure we get an error if we try to encrypt with an invalid secret

# Generated at 2022-06-22 14:16:30.927347
# Unit test for function do_vault
def test_do_vault():
    '''Unit test for function do_vault
    '''
    from ansible.module_utils.six import text_type

    secret = u'8Qv4jE4z4D4bZ4M9BIKfS4M4M4I15vT0KsH37w4w4WijJB8n2dNX'


# Generated at 2022-06-22 14:16:35.717970
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib
    import os
    import tempfile
    import json
    import re

    # Setup a temp file for storing the vault password.
    tmp_fd, tmp_path = tempfile.mkstemp(prefix='ansible-vault-filter-test')

# Generated at 2022-06-22 14:16:46.874021
# Unit test for function do_vault
def test_do_vault():

    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 14:16:56.623435
# Unit test for function do_vault
def test_do_vault():
    # Make sure to test both types of input
    #  string
    #  AnsibleVaultEncryptedUnicode
    assert do_vault("test", "secret") == do_vault(AnsibleVaultEncryptedUnicode("test"), "secret")

    # Test custom vaultid
    assert do_vault("test", "secret", vaultid="TEST") == do_vault("test", "secret", vaultid="TEST")

    # Make sure passing in a non-string generates an error
    try:
        do_vault(50, "secret")
    except AnsibleFilterTypeError:
        pass
    else:
        # Raise error if test doesn't fail
        assert False

    # Make sure passing in a non-string generates an error

# Generated at 2022-06-22 14:17:09.113212
# Unit test for function do_unvault
def test_do_unvault():
    # correct password
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n393862626563386130663235383463613161366132393534656537333130356566376539663730\n393365376530393933333361366162623363613935333436636161663438396433316236333930\n383339613030336465363561\n", "password") == "decrypted_string"

    # wrong password

# Generated at 2022-06-22 14:17:12.438114
# Unit test for function do_vault
def test_do_vault():
    display.verbosity = 4
    secret = 'secret'
    data = 'data'
    vaultid = 'filter_default'

    encr_data = do_vault(data, secret, None, vaultid)
    assert is_encrypted(encr_data)

    assert do_unvault(encr_data, secret, vaultid) == 'data'


# Generated at 2022-06-22 14:17:24.036953
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('test_data', 'this is a secret', 'salt_test')

# Generated at 2022-06-22 14:17:36.061288
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:52.054942
# Unit test for function do_vault
def test_do_vault():
    secret = 'abcdefghijklmnopqrstuvwxyz'
    salt = '1234567890'
    text = 'This is a top secret text!'

# Generated at 2022-06-22 14:18:01.994980
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret_key') == '$ANSIBLE_VAULT;1.1;AES256\n35306439316264643263613962333132376336306637303563313637393739616366623233336266\n6566323936386666653533653665326433623030303236636163323165353930616236333666613861\n6439343664336239396631303566336534646233336539653730363130353462356231633530356433\n3565613566333161643135303363313039343762626431333437313566356565653238363337626364\n303566\n'

# Generated at 2022-06-22 14:18:14.984668
# Unit test for function do_vault
def test_do_vault():

    from base64 import b64encode
    from jinja2.environment import Environment

    jinja2 = Environment()
    jinja2.filters['vault'] = do_vault

    data = 'Hello World!'
    salt = b64encode(b'12345678')
    secret = 'mysupersecret'
    vault = jinja2.from_string(
        "{{ 'Hello World!' | vault(secret, salt, wrap_object=True) }}"
    ).render(secret=secret, salt=salt)

    # check that we get an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-22 14:18:26.474830
# Unit test for function do_vault
def test_do_vault():
    test_filter_module = FilterModule()
    test_filters = test_filter_module.filters()
    data = to_bytes('My very secret message')
    secret = to_bytes('test')
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    # Assert that the encrypted data is the same
    # when executed the second time (for repeatability)
    vault = test_filters['vault'](data, secret, salt, vaultid, wrap_object)
    vault2 = test_filters['vault'](data, secret, salt, vaultid, wrap_object)
    assert vault == vault2


# Generated at 2022-06-22 14:18:36.309739
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n61306133613463363337653839666535336639653733356162653632393765393734386561336232\n31383233386232663038373766316161353037346537333932633434313238366133313334643636\n65353466653439666462316439343863396433393464303435643963653332363235633039653863\n35646639316238303335643231326139323431373238363437616532663430323039663735333034\n376535'


# Generated at 2022-06-22 14:18:44.340773
# Unit test for function do_vault
def test_do_vault():
    from os import urandom
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    import json
    import base64
    def run_module():
        # define the available arguments/parameters that a user can pass to
        # the module

        module_args = dict(
            secret='my_secret',
            data='This is my data',
            salt=None,
            vaultid='filter_default',
            wrap_object=True
        )


# Generated at 2022-06-22 14:18:55.265190
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:03.399556
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;testkeyxyztestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkeytestkey","secret","filter_default") == b"testing string\n"



# Generated at 2022-06-22 14:19:09.271607
# Unit test for function do_vault
def test_do_vault():
    data = 'abc'
    secret = 'abc'
    salt = 'abc'
    vaultid = 'test_vaultid'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert vault.startswith('$ANSIBLE_VAULT;')


# Generated at 2022-06-22 14:19:20.383216
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()

# Generated at 2022-06-22 14:19:40.679767
# Unit test for function do_vault
def test_do_vault():

    import base64
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # This is the result of encrypting the string "This is a test" with the password "testpass"
    # command: ansible-vault encrypt_string "This is a test" --vault-password-file=/home/travis/build/ansible/ansible/test/sanity/vault/test_vault_password.txt --name 'test_vault_result'
    # output: test_vault_result: !vault |
    #          $ANSIBLE_VAULT;1.2;AES256;ansible
    #          31363765356661613431326262616237636335343730363638

# Generated at 2022-06-22 14:19:53.719579
# Unit test for function do_unvault
def test_do_unvault():
    # basic
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;" + \
        "92113e58c66ae15d2bd0294c21e9692c79c75fcb17e0e8d8b9f18c7a9d3a16ae3f70f" + \
        "99b4de06f3c4b9ee9c7ce1d95acd8b5f6a5a5e5c65b2c95b5d593726ae6b5a6d29a6e", 
        'test_password') == 'test_data'

    # basic with vaultid

# Generated at 2022-06-22 14:20:06.148416
# Unit test for function do_vault
def test_do_vault():
    secret = "qwerty"
    data = "Testing do_vault"
    result = do_vault(data, secret, None)

# Generated at 2022-06-22 14:20:11.165187
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:21.245651
# Unit test for function do_vault
def test_do_vault():

    assert do_vault('$ANSIBLE_VAULT;1.1;AES256','my_secret','my_salt','filter_default',False) == '$ANSIBLE_VAULT;1.1;AES256\n66393834626531353165313531653135316531353165313531653135316334313537343066\n653132356237383231306631376393566323535373161346166323334663764616231646436\n65656631633230326630393436626137613165363738346335393334663132326235316139\n363833666239643065\n'

# Generated at 2022-06-22 14:20:28.565506
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'mysecret'
    test_data = 'mydata'
    test_salt = 'salty'

    result = do_vault(test_data, test_secret, test_salt)

    display.display("The vault data for \"%s\" is: \"%s\"" % (test_data, result))

    assert result is not None
    assert result != test_data


# Generated at 2022-06-22 14:20:34.049675
# Unit test for function do_unvault
def test_do_unvault():
    # set variables
    secret = 'secret'
    vaultid = 'filter_default'
    input_vault = AnsibleVaultEncryptedUnicode(data='test')
    output_data = 'test'
    # call function
    decrypted_data = do_unvault(input_vault, secret, vaultid)
    assert decrypted_data == output_data

# Generated at 2022-06-22 14:20:36.120082
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-22 14:20:45.197772
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = 'testsalt'
    vaultid = 'testvault'
    to_encrypt = 'test data'

    # Test with a string, salt, and vaultid
    encrypted = do_vault(to_encrypt, secret, salt, vaultid, wrap_object=False)

    assert is_encrypted(encrypted)

    # Try to encrypt empty string
    try:
        encrypted = do_vault('', secret, salt, vaultid)
    except Exception as e:
        assert type(e) == AnsibleFilterError

    # Try to encrypt None
    try:
        encrypted = do_vault(None, secret, salt, vaultid)
    except Exception as e:
        assert type(e) == AnsibleFilterError

    # Try to encrypt a list

# Generated at 2022-06-22 14:20:56.470738
# Unit test for function do_vault
def test_do_vault():
    import unittest
    import textwrap

    from ansible.parsing.vault import VaultLib

    class TestVaultJinja2(unittest.TestCase):

        def test_encrypt_string(self):
            secret = 'foo'
            data = 'bar'
            vaulted = do_vault(data, secret)

# Generated at 2022-06-22 14:21:17.527003
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'test_salt'
    vaultid = 'test_vault'

    result = do_vault('test', secret, salt, vaultid)

    assert result[:5] == '$ANSIBLE_VAULT;'
    assert result[-5:] == ';\n\n'
    assert '\\n' in result


# Generated at 2022-06-22 14:21:27.938329
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('secret', 'password') == '$ANSIBLE_VAULT;1.1;AES256\n35316233793965323331623530646530363132343532646533666661336661303830323166373439\n393765633537366335323863303634656164646635336466386265330a6137393434323663646138\n62353036356163633961323132306633653934303735633233343564366330613935313561623239\n3536316361383133386266640a\n'



# Generated at 2022-06-22 14:21:41.310401
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:44.804250
# Unit test for function do_vault
def test_do_vault():
    input_ = "Hello Ansible!"
    secret = "p@ssw0rd"
    ret = do_vault(input_, secret)
    assert len(ret) == 132
