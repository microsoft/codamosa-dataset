

# Generated at 2022-06-22 14:11:57.925879
# Unit test for function do_unvault
def test_do_unvault():
    secret = b'$ANSIBLE_VAULT;1.1;AES256\n624145666f62646c6361323930373664363435643033393965303533306361623566613939358e2c\n73666131613662346362326237356639356533386266396532633733626265623463613331396261\n643564633437633537383934396236643335303331643166373735666337663936306638\n'
    ansible_unvaulted = b'test'
    assert do_unvault(secret, 'test') == ansible_unvaulted

# Generated at 2022-06-22 14:12:11.054632
# Unit test for function do_unvault
def test_do_unvault():

    # If a string is not encrypted, unvault should return it back as it is
    # data being tested are random strings
    unencrypted = [
        'Hello world',
        '1234',
        '!@#$%^&*()_+|'
    ]

    for data in unencrypted:
        if not data == do_unvault(data, secret=''):
            raise AssertionError("We expect '%s' to be returned as it is but got '%s'"
                                 % (data, do_unvault(data, secret='')))

    # If a string is encrypted, unvault should return it back decrypted
    # data being tested are encryptions of random strings

# Generated at 2022-06-22 14:12:23.047879
# Unit test for function do_unvault
def test_do_unvault():
    import sys
    display.verbosity = 4
    secret = 'supersecret'
    enc_data = '$ANSIBLE_VAULT;1.1;AES256'
    enc_data += '\n'
    enc_data += '646632633931346536343331656133326537643935396136613161366232396164396361626134'
    enc_data += '\n'
    enc_data += '626633643765356335323861626265316430393537373035633136353137666231396265343837'
    enc_data += '\n'
    enc_data += '636538333232376137633965653564393166623163366266363262633336326465323766663662'


# Generated at 2022-06-22 14:12:34.771308
# Unit test for function do_vault
def test_do_vault():
    # Create our test secrets
    test_secret = 'mysecret'
    test_salt = 'mysalt'
    test_vault = 'myvault'
    test_wrap_object = True

    # Create our test data to encrypt
    test_data = 'mydata'

    # Create our test function arguments
    test_args = {
        'data': test_data,
        'secret': test_secret,
        'salt': test_salt,
        'vaultid': test_vault,
        'wrap_object': test_wrap_object,
    }

    # Create our test function input
    test_input = [
        test_data,
        test_secret,
        test_salt,
        test_vault,
        test_wrap_object,
    ]

    # Create our test function output

# Generated at 2022-06-22 14:12:47.488169
# Unit test for function do_unvault
def test_do_unvault():
    do_unvault('x','')

# Generated at 2022-06-22 14:12:59.995558
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'

# Generated at 2022-06-22 14:13:12.358526
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    salt = '2c1aef3373bbc9e4'

# Generated at 2022-06-22 14:13:22.209632
# Unit test for function do_vault
def test_do_vault():
    # Using a secret of 10 ascii characters
    secret = "secret10chars"
    input = "some plaintext"

# Generated at 2022-06-22 14:13:28.976588
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:41.450865
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:51.577888
# Unit test for function do_unvault
def test_do_unvault():
    secret = "password"

    # Test good and bad data
    data = "TopSecretPassword1"
    bad_data = "TopSecretPassword2"
    ansible_bad_data = "TopSecretPassword3"

    # get data returned by do_vault and do_ansible_vault
    vault_data = do_vault(data, secret)
    ansible_vault_data = do_vault(ansible_bad_data, secret)

    # do some checks

# Generated at 2022-06-22 14:13:53.606204
# Unit test for function do_unvault
def test_do_unvault():
    f = FilterModule()
    filters = f.filters()
    data = 'some secret'
    vault = filters['vault'](data, 'some secret', salt='123456789012345678901234', wrap_object=True)
    assert filters['unvault'](vault, 'some secret') == data

# Generated at 2022-06-22 14:14:03.590432
# Unit test for function do_vault
def test_do_vault():
    secret = "123456"
    data = "password"
    vault = do_vault(data, secret, wrap_object=False)

# Generated at 2022-06-22 14:14:13.960183
# Unit test for function do_unvault
def test_do_unvault():
    vaultid = 'test_vault_id'
    secret = 'test_secret'

# Generated at 2022-06-22 14:14:26.790133
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import base64
    import binascii
    import os
    import string

    empty_values = [None, '', [], (), {}]
    if 'ANSIBLE_VAULT_PASSPHRASE' in os.environ:
        secret = os.environ['ANSIBLE_VAULT_PASSPHRASE']
    else:
        secret = 'default'
    data = 'hello world'
    assert data == to_native(do_unvault(do_vault(data, secret), secret))

    # test with salt, by default with to_bytes
    salt = 'abcd'

# Generated at 2022-06-22 14:14:33.058392
# Unit test for function do_vault
def test_do_vault():
    test_data = "hello world"
    vault_id = "test_filter_vault_id_1"
    secret = "test_secret"
    salt = "mysalt"
    test_vault = do_vault(test_data, secret, salt=salt, wrap_object=True)
    test_unvault = do_unvault(test_vault, secret)
    assert test_data == test_unvault

# Generated at 2022-06-22 14:14:41.688751
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:54.139490
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:02.618269
# Unit test for function do_vault
def test_do_vault():
    value = None
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(value, None)

    value = 'My string to encrypt'
    secret = None
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(value, secret)

    value = None
    secret = 'My secret to encrypt with'
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(value, secret)

    value = 'My string to encrypt'
    secret = 'My secret to encrypt with'
    encrypted_value = do_vault(value, secret)

# Generated at 2022-06-22 14:15:07.641292
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    data = 'testdata'
    vaultid = 'testvaultid'

    test_vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(test_vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 14:15:20.021526
# Unit test for function do_unvault
def test_do_unvault():
    assert_check_unvault(".V2Q0bfFhL7sLUVZs1c7l79sHk/gVyjrXHMap7V2Eo/Bw7/uCojtMm7p", "testpassword", vaultid='testvaultid', expected='teststring')
    assert_check_unvault(".V2Q0bfFhL7sLUVZs1c7l79sHk/gVyjrXHMap7V2Eo/Bw7/uCojtMm7p", "testpassword", vaultid='testvaultid', expected='teststring')

# Generated at 2022-06-22 14:15:32.115015
# Unit test for function do_vault
def test_do_vault():
    secret = b'1a2b3c4d'
    salt = '0123456701234567012345670123456701234567'

# Generated at 2022-06-22 14:15:41.606538
# Unit test for function do_vault
def test_do_vault():
    try:
        from ansible.module_utils.crypto import ensure_bytes, ensure_str
    except ImportError:
        from ansible.module_utils.basic import to_native
    # Test with valid key
    valid_key = "AJARMMBITKQ6KO3KN6PVU6JHU6BCBGB6"
    secret = {'vault_password_file': '~/.vault_pass.txt'}
    data = 'test'
    vault = do_vault(data, secret)
    assert(isinstance(vault, string_types))
    vs = VaultSecret(ensure_bytes(valid_key))
    vl = VaultLib()
    rdata = vl.decrypt(ensure_str(vault))
    assert(to_native(data) == rdata)



# Generated at 2022-06-22 14:15:52.413160
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:01.510067
# Unit test for function do_unvault
def test_do_unvault():
    display.vvvv("test_do_unvault")
    # Begin test
    filter_ = FilterModule()
    filter_instance = filter_.filters()
    try:
        # unvault a string without encryption
        unvault = filter_instance['unvault']
        test_str = unvault("Hello", Password)
        if test_str == "Hello":
            display.display("unvault a string success")
        else:
            display.error("unvault a string falure")

    except Exception as e:
        display.error("unvault a string falure")
        display.error(e)


# Generated at 2022-06-22 14:16:09.542720
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('value', 'secret', '', '', True) == '$ANSIBLE_VAULT;1.1;AES256\n34393534363661613731376230386633364336663135653434323632643134643831623663346334\n33323530653164656132346536303436376333633239353632646130396363313834396462313862\nc6c2a33a3737c1df90\n'


# Generated at 2022-06-22 14:16:14.703703
# Unit test for function do_vault
def test_do_vault():
    secret = '12345'
    salt = 'abc'
    data = 'Hello!'
    vaultid = b'filter_default'

    to_native(do_vault('Hello!', secret, salt, vaultid))


# Generated at 2022-06-22 14:16:27.327239
# Unit test for function do_vault
def test_do_vault():
    # Test invalid data type
    try:
        do_vault(1, 'test_secret')
        assert False
    except AnsibleFilterTypeError:
        pass

    # Test invalid secret type
    try:
        do_vault('test_data', 1)
        assert False
    except AnsibleFilterTypeError:
        pass

    # Test valid data

# Generated at 2022-06-22 14:16:39.561979
# Unit test for function do_vault
def test_do_vault():
    data = u'data'
    secret = u'secret'
    test_vault = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)
    assert test_vault.startswith('$ANSIBLE_VAULT')
    assert test_vault.endswith('\n')

# Generated at 2022-06-22 14:16:48.897116
# Unit test for function do_vault
def test_do_vault():

    # Test case 1
    assert do_vault('secret', 'password', wrap_object=True) == '$ANSIBLE_VAULT;1.1;AES256\n353637663033656637626237336162353161623633396237623131373638363835301a346565303934\n346535656631333539656561343139326565663935303665386363356231343966\n'

    # Test case 2

# Generated at 2022-06-22 14:16:58.516175
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'secretsalt'
    vaultid = 'testid'
    data = {
        'name': 'mysecret',
        'password': 'mypassword',
        'list': [1, 2, 3, 4, 5]
    }

    # Test 1 - encrypt data

# Generated at 2022-06-22 14:17:00.847817
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    secret = 'test'
    vs = VaultSecret(secret)
    vl = VaultLib()
    text = 'text'
    encrypted = vl.encrypt(text, vs)
    assert not is_encrypted(text)
    assert is_encrypted(encrypted)
    assert do_unvault(encrypted, secret) == text

# Generated at 2022-06-22 14:17:04.585562
# Unit test for function do_unvault
def test_do_unvault():
    data = "test"
    test_secret = to_bytes("test_secret")
    result = do_unvault(do_vault(data, test_secret), test_secret)
    assert result == data


# Generated at 2022-06-22 14:17:08.903267
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:12.394507
# Unit test for function do_vault
def test_do_vault():
    import doctest
    failed, tests = doctest.testmod(do_vault)
    assert tests == 1
    assert failed == 0, 'doctest of vault filters failed.'

# Generated at 2022-06-22 14:17:16.371612
# Unit test for function do_unvault
def test_do_unvault():
    print('Testing do_unvault')
    data = 'foo'
    secret = 'bar'
    unvaulted_foo = do_unvault(do_vault(data, secret), secret)
    assert unvaulted_foo == data

# Generated at 2022-06-22 14:17:26.910082
# Unit test for function do_vault
def test_do_vault():
    # Test normal operation
    # Filter name, value, secret to use, salt, vaultid and wrap_object default to False
    data = do_vault('some_secret', 'some_key')
    assert data == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          333938333036386438393062366334373566346436373132373237333237343932353036313334372\n          3533393735303832353439656334353738396435376263663937366437378D\n          0D0015386633623561383631\n          ", data

    # Test with wrapped object
    data = do_vault('some_secret', 'some_key', wrap_object=True)

# Generated at 2022-06-22 14:17:38.609165
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six import PY3

    import os
    import tempfile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleVaultConstructor

    if not PY3:
        display.error("This test requires python3")
        return 1

    tmp = tempfile.mkstemp()
    os.close(tmp[0])
    test_string = os.urandom(64)

    display.display("Writing vaulted string to %s" % tmp[1])

# Generated at 2022-06-22 14:17:49.937133
# Unit test for function do_vault
def test_do_vault():
    secret = "12345678901234567890123456789012"
    plaintext = "hello world"

# Generated at 2022-06-22 14:17:54.161955
# Unit test for function do_vault
def test_do_vault():
    secret = b"secret"
    data = b"data"
    vaultid = "vaultid"

    vl = VaultLib()
    vs = VaultSecret(secret)
    assert vl.decrypt(vl.encrypt(data, vs, vaultid)) == data



# Generated at 2022-06-22 14:18:06.072244
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    data = 'data'

# Generated at 2022-06-22 14:18:17.175794
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:29.113803
# Unit test for function do_vault
def test_do_vault():
    fm = FilterModule()
    data = 'foo'
    secret = 'ansible'

# Generated at 2022-06-22 14:18:39.385389
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 14:18:46.160645
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('some secret', 'some secret') == '$ANSIBLE_VAULT;1.1;AES256\n396163653866613033316262383163626439386430333366343537663339636661356533356135\n396330316266353430626562643965353531353861623331303539346462333434336438336533\n356433653064623066623665330a63313736323339623134313161356132306363366437383664\n6563356435656332313438666636353734643835613964396636643462333864393634316631\n35346665633234616264326361350a'

# Unit test

# Generated at 2022-06-22 14:18:52.940413
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = "test_secret"
    test_vaultid = "test_vaultid"
    test_data = "test_data"
    encrypted_data = do_vault(test_data, test_secret, vaultid=test_vaultid)
    decrypted_data = do_unvault(encrypted_data, test_secret, vaultid=test_vaultid)

    assert test_data == decrypted_data


# Generated at 2022-06-22 14:18:56.515968
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault('secret', 'secret')


# Generated at 2022-06-22 14:19:06.350559
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # test with secret as string
    secret = 'ansible'
    data = 'hello'
    vault = do_vault(data, secret, wrap_object=False)
    assert type(vault) is str
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')

    # test with secret as string
    secret = 'ansible'
    data = 'hello'
    vault = do_vault(data, secret, wrap_object=True)
    assert type(vault) is AnsibleVaultEncryptedUnicode
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')

    # test with secret as bytes

# Generated at 2022-06-22 14:19:15.670259
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:22.576626
# Unit test for function do_vault
def test_do_vault():
    data = 'foo'
    secret = 'bar'
    assert do_vault(data, secret) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62366437323762356138383038343065663461636239656532316464343039353033366131656563\n          33343933303466303436663638346630383538326430393338626666626533306535383935646633\n          3334346439653963663162396264353364313131306433323165643439\n          '


# Generated at 2022-06-22 14:19:37.208939
# Unit test for function do_vault
def test_do_vault():
    s = 'secret'
    d = 'data'
    assert do_vault(d, s) == '$ANSIBLE_VAULT;1.1;AES256;id_filter_default\n35386538313361306639366236636563646638626237663137633235313161376137633531353262350a6539306233666233386235653035663364373566643964323935343337653135343764303366320a3733633264363464373034323239313561353037366264653533353065383038376633313431\n'


# Generated at 2022-06-22 14:19:49.615409
# Unit test for function do_vault
def test_do_vault():

    # Test case: data = 12345
    data = 12345
    secret = "123456"
    salt = "1234"
    vaultid = "vaultid"
    wrap_object = False


# Generated at 2022-06-22 14:19:51.782607
# Unit test for function do_unvault
def test_do_unvault():
    '''Test function exists'''
    do_unvault('', '', 'default')


# Generated at 2022-06-22 14:19:54.138424
# Unit test for function do_vault
def test_do_vault():
    # no exception raised
    do_vault('ansible', 'ansible', 'ansible')


# Generated at 2022-06-22 14:19:55.889367
# Unit test for function do_vault
def test_do_vault():

    assert do_vault('secret', 'password') is not None
    assert do_vault('secret', 'password', wrap_object=True) is not None

# Generated at 2022-06-22 14:20:08.507278
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:19.967121
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'foo'
    test_string = 'this is a test of the emergency broadcast system'
    test_vault = do_vault(test_string, test_secret)

# Generated at 2022-06-22 14:20:32.331392
# Unit test for function do_vault
def test_do_vault():
    import os
    vault_password = os.environ.get('VAULT_PASSWORD', 'test')


# Generated at 2022-06-22 14:20:43.632990
# Unit test for function do_unvault
def test_do_unvault():
    class FilterModule(object):
        def filters(self):
            filters = {
                'vault': do_vault,
                'unvault': do_unvault,
            }
            return filters

    secret = 'mysecret'
    vaultid = 'theid'
    new_module = FilterModule()
    new_module.filters()

# Generated at 2022-06-22 14:20:53.071086
# Unit test for function do_vault
def test_do_vault():
    class TestVars:
        pass
    vars = TestVars()
    vars.ansible_vault_password = "bar"


# Generated at 2022-06-22 14:21:06.818964
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(
        'hello world', 'mysecret') == '$ANSIBLE_VAULT;1.2;AES256;myvault\n37323631323763653439316236646265323831653135366265363037376362373766633135653635\n34393036336462636338636665323531653164643037633862626632663065336237343834613235\n36626663633631616664346631636433316166396262623463323134313561326435376363326336\n3134393734646338383633\n'


# Generated at 2022-06-22 14:21:13.072256
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.collections import ImmutableDict
    from collections import MutableMapping

    display.verbosity = 4
    display.debug("*** Entered do_vault function ***")

    data = "AnsibleFilterError: Secret passed is required to be a string, instead we got: <class 'ansible.vars.unsafe_proxy.AnsibleUnsafeText'>"
    secret = "SuperSecret"
    salt = "3w3j3k"
    vaultid = 'test'
    wrap_object = False
    display.debug("*** Default test (string) ***")
    test = do_vault(data, secret, salt=salt, vaultid=vaultid, wrap_object=wrap_object)

    display.debug("*** Test is {} ***".format(test))

    # Verify data

# Generated at 2022-06-22 14:21:18.801128
# Unit test for function do_unvault
def test_do_unvault():

    if is_encrypted('$ANSIBLE_VAULT;1.1;AES256'):
        display.display('$ANSIBLE_VAULT;1.1;AES256 is encrypted')
    else:
        display.display('$ANSIBLE_VAULT;1.1;AES256 is not encrypted')

    do_unvault('$ANSIBLE_VAULT;1.1;AES256', 'secret', 'test')


# Generated at 2022-06-22 14:21:31.719094
# Unit test for function do_unvault

# Generated at 2022-06-22 14:21:44.641391
# Unit test for function do_unvault
def test_do_unvault():
    # Unvault a non-vault string
    data = 'TEST'
    secret = 'TESTSECRET'
    out = do_unvault(data, secret)
    assert out == data

    # Unvault a vault string
    data = 'TEST'
    vault = do_vault(data, secret)
    out = do_unvault(vault, secret)
    assert out == data

    # Unvault a vault string with salt
    salt = 'TESTSALT'
    vault = do_vault(data, secret, salt)
    out = do_unvault(vault, secret)
    assert out == data

    # Unvault a vault object
    vault_obj = AnsibleVaultEncryptedUnicode(vault)

# Generated at 2022-06-22 14:21:56.145215
# Unit test for function do_vault
def test_do_vault():
    # Test with VaultSecret
    secret = 'kfwkfjwkefjwf'
    vs = VaultSecret(secret)

    # Test with protected un-encrypted string
    data = 'This is secret'
    result = do_vault(data, vs, wrap_object=True)

    # Test with unprotected un-encrypted string
    data = 'This is not secret'
    result = do_vault(data, vs, wrap_object=True)

    # Test with protected encrypted string
    data = result
    result = do_vault(data, vs, wrap_object=True)

    # Test with protected encrypted string
    data = result
    result = do_vault(data, vs, wrap_object=True)

    # Test with protected unicode string
    data = 'This is \u2665'
    result = do_