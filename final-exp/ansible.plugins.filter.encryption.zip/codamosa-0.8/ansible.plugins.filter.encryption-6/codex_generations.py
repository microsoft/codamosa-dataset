

# Generated at 2022-06-22 14:11:52.203117
# Unit test for function do_vault
def test_do_vault():
    # return data
    data = 'test data'
    secret = 'test'
    salt = 'test'
    vaultid = 'test'
    wrap_object = False
    # Vault object for expected result
    e_vault = do_vault(data, secret, salt, vaultid, wrap_object)
    d_vault = do_vault(data, secret)
    assert e_vault == d_vault

    # Test type error when secret passed is not a string
    secret = 123
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(data, secret, salt, vaultid, wrap_object)



# Generated at 2022-06-22 14:12:01.429744
# Unit test for function do_unvault
def test_do_unvault():
    import os

    # Do this in an isolated environment, to make sure we have the vault and keys
    # created exclusively for these tests
    import tempfile
    tempdir = tempfile.TemporaryDirectory(prefix="ansible_vault_filter_unittest_")
    tempdir.name
    vault_file = os.path.join(tempdir.name, "vault_file")
    vault_password_file = os.path.join(tempdir.name, "vault_password_file")

    # Create test vault file using ansible-vault
    # Attempting to create the vault file using the VaultLib class will not work.
    # It uses RSA encryption, while the vault file needs to be encrypted using AES.

# Generated at 2022-06-22 14:12:11.900754
# Unit test for function do_unvault
def test_do_unvault():
    class FilterModuleTest(object):
        def filters(self):
            return {
                'unvault': do_unvault,
            }
    secret = "secret"
    vaulted_data = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;default\n          383238656465383263393733346437656638653462336262316138333936356437616361363061\n          656237343461396437633235623065363261626661396165343264383030613530336536613961\n          62643763386539316462636465306236643033653035373739363438\n          "
    
    filter_mgr = FilterModuleTest()
    env = Environment()

# Generated at 2022-06-22 14:12:24.116930
# Unit test for function do_unvault
def test_do_unvault():
    import sys
    import unittest


# Generated at 2022-06-22 14:12:35.482791
# Unit test for function do_vault
def test_do_vault():
    data = 'test'
    secret = 'mysecret'
    salt = 'default_salt'
    vaultid = 'filter_default'
    wrap_object = False
    # Need a more robust test here

# Generated at 2022-06-22 14:12:48.183032
# Unit test for function do_vault
def test_do_vault():
    display = Display()
    display.verbosity=4
    # Make sure it can handle unicode properly
    data = u'hello world'
    secret = u'changeme'
    ret = do_vault(data, secret)
    if not isinstance(ret, AnsibleVaultEncryptedUnicode):
        raise AssertionError("%s is not instance of %s" % (ret, AnsibleVaultEncryptedUnicode))
    if is_encrypted(ret):
        raise AssertionError("%s is not encrypted" % (ret))
    if ret.data != data:
        raise AssertionError("%s is not the same as %s" % (ret.data, data))

    # Make sure it encrypts properly
    data = 'hello world'
    secret = 'changeme'
    ret = do

# Generated at 2022-06-22 14:12:57.318510
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, 'ansible', 'test_vault') == ''
    assert do_unvault('', 'ansible', 'test_vault') == ''
    assert do_unvault('abc test string', 'abc test string', 'test_vault') == 'abc test string'
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test_vault 1234567890123456', 'ansible', 'test_vault') == 'ansible'

# Generated at 2022-06-22 14:13:09.045766
# Unit test for function do_unvault
def test_do_unvault():
    """Unit test for function do_unvault"""
    class AnsibleExit(Exception):
        pass

    def get_config(key=None, value=None, vault_password=None):
        """This function is only used by the unit test."""
        return ''

    from ansible.cli.vault import VaultCLI

    class AnsibleModule(object):
        """This class is only used by the unit test."""
        def __init__(self, argument_spec, **kwargs):
            self.params = {}
            self.params['vault_password'] = None

        def fail_json(self, *args, **kwargs):
            raise AnsibleExit("Ansible module failed")

    def exit_json(*args, **kwargs):
        raise AnsibleExit("Ansible module succeeded")


# Generated at 2022-06-22 14:13:19.159303
# Unit test for function do_unvault
def test_do_unvault():

    secret = "secret-data"
    vault = "$ANSIBLE_VAULT;1.1;AES256;test-user\n313233313230332d3435362d3439362d3935302d613064323230353833383733\n6132323834376330373262633231346430373864663534623663336262623832\n6533303163396361616130333438303436623635323165366564396633363561\n"
    text = "the secret data"

    assert do_unvault(vault, secret) == text

# Generated at 2022-06-22 14:13:31.109586
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'

    # Test data strings
    test_data = 'test string'

# Generated at 2022-06-22 14:13:44.911305
# Unit test for function do_vault

# Generated at 2022-06-22 14:13:51.297444
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;foo\nblahblahblah==\n', 'foo') == 'blahblahblah=='
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;foo\nblahblahblah==\n', 'foo', 'test') == 'blahblahblah=='

# Generated at 2022-06-22 14:14:02.504161
# Unit test for function do_unvault
def test_do_unvault():
    """
    Test for function do_unvault
    """

    assert "asdfqwer" == do_unvault(b'$ANSIBLE_VAULT;1.1;AES256\n6437343364373236616265623864303136613839386530353830323132616630363762643063386166\n33333865333537663565323663653964333036396531313165330a6434663864393335643362653239\n3062376237366465386664373263323137303464643430643934653338656266656663366232393666\n66323737303365303861663966\n', 'asdfqwer')

    assert "asdfqwer" == do_un

# Generated at 2022-06-22 14:14:10.276826
# Unit test for function do_vault
def test_do_vault():

    from ansible.compat.tests import mock

    with mock.patch("ansible.parsing.vault.VaultSecret") as mock_VaultSecret, \
            mock.patch("ansible.parsing.vault.VaultLib") as mock_VaultLib:

        # Test for missing secret
        try:
            do_vault("test_data")
            assert False
        except AnsibleFilterTypeError:
            assert True
        except Exception:
            assert False

        # Test for missing data
        try:
            do_vault(secret="test_secret")
            assert False
        except AnsibleFilterTypeError:
            assert True
        except Exception:
            assert False

        # Test for invalid secret

# Generated at 2022-06-22 14:14:18.472833
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:22.259941
# Unit test for function do_vault
def test_do_vault():
    filter = FilterModule()
    res = filter.filters()['vault']('bacon', 'foo')
    assert '$ANSIBLE_VAULT;7;' in res


# Generated at 2022-06-22 14:14:33.183238
# Unit test for function do_vault
def test_do_vault():
    # 1. Test empty secret not allowed
    try:
        assert do_vault('text', '') == ''
    except AnsibleFilterError:
        pass

    # 2. Test type of secret not allowed
    try:
        assert do_vault('text', []) == ''
    except AnsibleFilterTypeError:
        pass

    # 3. Test return value as AnsibleVaultEncryptedUnicode
    assert isinstance(do_vault('text', '!@#$%^&*()_+=-', salt='1234567890', wrap_object=True), AnsibleVaultEncryptedUnicode)
    assert isinstance(do_vault(u'text', u'!@#$%^&*()_+=-', salt='1234567890', wrap_object=True), AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-22 14:14:41.797414
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n36343830633265343964353731346231326564343831646634323539623262306339623536363166\n34376330646630343737653362366231303966373532663934366530346134333835633536366565\n65353461613365356566316632376631633839303538363765613961636130316238633138326264\n6633616337616538396633636162626433373939393430383131303633\n", "password", vaultid='filter_default') == 'dummy'

# Generated at 2022-06-22 14:14:48.186649
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    # Note: secret is a unicode but it needs to be bytes for VaultSecret
    secret = 'secret\x00\x00\x00\x00\x00\x00\x00'
    salt = 'salt\x00\x00\x00\x00\x00\x00'
    data = 'data'

# Generated at 2022-06-22 14:14:58.937710
# Unit test for function do_vault
def test_do_vault():

    secret = 'my-very-long-and-s3cret-passw0rd'
    data = 'my_vaulted_data'
    salt = 'salt_for_next_gen_vaults'
    vault = do_vault(data, secret, salt)


# Generated at 2022-06-22 14:15:12.057979
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret, VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.loader import AnsibleLoader

    secret = VaultSecret('test')
    vaultlib = VaultLib(vault_secrets=[('default', secret)])
    data = to_bytes('test data')
    enc_data = vaultlib.encrypt(data)
    unenc_data = vaultlib.decrypt(enc_data)

    assert data == unenc_data

    # test if unvault works as expected
    assert unenc_data == do_unvault(enc_data, secret=secret)

    # test if unvault works as expected with vault_id

# Generated at 2022-06-22 14:15:19.917310
# Unit test for function do_vault
def test_do_vault():
    """Test do_vault filter method."""
    data = "Hello World"
    secret = "super_secret"
    salt = "random_salt"
    vaultid = "vault_id"
    wrapped = AnsibleVaultEncryptedUnicode(do_vault(data, secret, salt, vaultid))
    assert(wrapped.data == data)
    assert(secret == do_unvault(wrapped, secret, vaultid))



# Generated at 2022-06-22 14:15:32.009385
# Unit test for function do_unvault
def test_do_unvault():
    # Generate a secret
    secret = 'test'

# Generated at 2022-06-22 14:15:41.137487
# Unit test for function do_unvault
def test_do_unvault():
    case_data = "secret_password"
    case_secret = "wrong_password"
    case_vault = "$ANSIBLE_VAULT;1.1;AES256\n31386162336334626263656330306231386137366131393330646562633337336563163620a30616562393662626432613161333831616464663537633037393434656363353235380a313739353763393363313233383533343362356639316264633832396130303437363533\n"
    assert do_unvault(case_data=case_vault, secret=case_secret) == case_data

# Generated at 2022-06-22 14:15:52.193729
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:58.488457
# Unit test for function do_unvault
def test_do_unvault():
    v = do_vault("this is a secret", "secret", )
    assert '$ANSIBLE_VAULT' in v
    assert v != "this is a secret"
    assert do_unvault(v, "secret") == "this is a secret"

if __name__ == '__main__':
    # ansible-test sanity --test do_unvault
    test_do_unvault()

# Generated at 2022-06-22 14:16:07.676878
# Unit test for function do_vault
def test_do_vault():
    plaintext = "This is a test"
    vaultid = 'Test-Vault'
    secret = "b'12345678901234567890123456789012'"
    salt = 'test-salt'
    salt_vault_test = '$ANSIBLE_VAULT;9.9;TEST;test-salt'
    secret_vault_test = '$ANSIBLE_VAULT;9.9;TEST;12345678901234567890123456789012'

# Generated at 2022-06-22 14:16:20.452587
# Unit test for function do_vault
def test_do_vault():
    # Basic usage of the filter
    assert do_vault(data="hello", secret="p@s$vv0rd", salt="s@lt") == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;filter_default\n          56656175746831393435393930343963363164633562376261336362323032646466353864383762630a3835373564633530386265373465373261373138623963623665623133643639663539653064376461316338623162353739363235613239320a35373866383936633231383633623965303862383532333330343231643935336531323962643465316534359a"

# Generated at 2022-06-22 14:16:29.931775
# Unit test for function do_vault
def test_do_vault():
    import unittest
    import os

    # Creating a temporary file for the test
    fd, vault_filename = tempfile.mkstemp()

    # Cleanup the temporary file
    os.close(fd)
    os.remove(vault_filename)

    print("\nRunning test: test_do_vault\n")

    # Initialize and call the test class
    test = Test_do_vault('test_do_vault', vault_filename)
    test.test_do_vault()

# Unit test class
import tempfile
import os

# Generated at 2022-06-22 14:16:42.687019
# Unit test for function do_vault
def test_do_vault():

    data_plain = 'Ansible is cool'
    secret = 'myvirussucks'

# Generated at 2022-06-22 14:16:55.473214
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible_collections.ansible.community.plugins.filter.vault import do_unvault

    # Test of a plain text value
    plain_text_value = "ansible_is_awesome"
    assert do_unvault(plain_text_value, VaultSecret("")) == "ansible_is_awesome"

    # Test of a plain text value with a secret
    plain_text_value = "ansible_is_awesome"
    assert do_unvault(plain_text_value, VaultSecret("passw0rd")) == "ansible_is_awesome"

    #

# Generated at 2022-06-22 14:17:07.971310
# Unit test for function do_unvault
def test_do_unvault():

    
    display.verbosity = 3
    filters = FilterModule().filters()
    # unvault with a string
    assert filters['unvault']("$ANSIBLE_VAULT;1.1;AES256;some_key\n33393234306330363265343238376133613562626432373436623364333066376132316562613464\n33323935656366623463362d33056466393963323961316665323332643362646165623061336238\n38326161324131613236623761656635646164333932616132413161323662376165663564616433\n33", "some_key") == "524545454348095455434345"

    # unvault with encrypted

# Generated at 2022-06-22 14:17:20.449759
# Unit test for function do_vault
def test_do_vault():
    secret = 'some_random_secret'
    salt = '2f4d4ab4-4d55-4f96-8378-d7b08f40b8f7'
    to_encrypt = "Hello world"

# Generated at 2022-06-22 14:17:29.574554
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_native

    secret = '$ANSIBLE_VAULT;1.1;AES256'
    vl = VaultLib([
        ('default', VaultSecret(to_bytes(secret)))
    ])

    vault = vl.encrypt(b'hello world')
    unvault = do_unvault(vault, secret)
    assert isinstance(vault, str)
    assert isinstance(unvault, str)
    assert unvault == 'hello world'

    unvault = do_unvault(b'hello world', secret)
    assert isinstance(unvault, str)
    assert unvault == 'hello world'

    vault = AnsibleVault

# Generated at 2022-06-22 14:17:40.048695
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'sometestsecret'

# Generated at 2022-06-22 14:17:49.719087
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible_test_id\n323635333835363066396336396664633463316436633039346135313531316132396631633765\n35656631613431663231633862626264386162386139613931320a336262633863633432313031\n326239623031636437374337313239613730316437633833343832626433643037356665353866\n303232656436633435333065\n", "test_secret") == "test_data"

# Generated at 2022-06-22 14:17:59.113371
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:07.156420
# Unit test for function do_vault
def test_do_vault():
    # Test case with string
    test_data = 'test_data'
    test_secret = 'test_secret'

    # Expected result

# Generated at 2022-06-22 14:18:11.214053
# Unit test for function do_vault
def test_do_vault():
    secret = 'some secret'
    data = 'some data to encrypt'

    result = do_vault(data, secret, wrap_object=False)
    print(result)
    assert is_encrypted(result)


# Generated at 2022-06-22 14:18:14.405953
# Unit test for function do_vault
def test_do_vault():
    output = do_vault('test', 'passwordtestpasswordtestpasswordtestpasswordtest')
    assert (to_native(output).startswith('$ANSIBLE_VAULT;'))
    assert (to_native(output).endswith('\n'))



# Generated at 2022-06-22 14:18:29.739914
# Unit test for function do_unvault
def test_do_unvault():

    # 1. TEST CASE: Unvault a string
    vault = "$ANSIBLE_VAULT;1.2;AES256;filter_default\n353738393061646236616137646638396466346662633235363035366561656164386632626265\n646539336432363231336132626631383064656138366432633863366138393662623235383339\n613439313863363630663561\n"

    secret = "travis_secret_key"

    data = "travis_value"
    orig_data = do_unvault(vault, secret, vaultid='filter_default')
    assert data == orig_data


    # 2. TEST CASE: Unvault an already unvaulted string
   

# Generated at 2022-06-22 14:18:39.737938
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("foo", "bar", salt="foobar") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;foo\n          363436396634326336376164396231623366333765623535326437663236376262613361336336\n          37383561643437626232333231623032643064376532383537633261653939663161326430653665\n          3130336534386431366539656230656239326366666261346331\n          "
    

# Generated at 2022-06-22 14:18:51.902761
# Unit test for function do_vault
def test_do_vault():
    # unit tests for do_vault

    # Create mock input
    from jinja2 import Environment
    from jinja2.exceptions import UndefinedError
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.vault import VaultSecret
    import os
    import base64
    import jinja2
    import sys

    # setup the jinja environment
    env = Environment()

    # Get the function we want to test
    vault_func = env.filters['vault']

    # setup the test data
    data = AnsibleUnsafeText(b'HACKED!')

# Generated at 2022-06-22 14:19:03.640822
# Unit test for function do_vault
def test_do_vault():
    import re
    from jinja2 import Template

    template = Template("{{ 'test string' | vault('testsecret') }}")

    secret = 'testsecret'
    text = 'test string'

    result = template.render(text=text)

    # We are working in unicode here
    assert isinstance(result, unicode)

    # Check that the values in the encrypted string can be decrypted
    assert re.match('$ANSIBLE_VAULT;[0-9a-f]{64}', result)
    assert b'$ANSIBLE_VAULT;' in result

    # Check that the values get decrypted correctly
    template = Template("{{ vaulted | unvault('testsecret') }}")
    decrypted = template.render(vaulted=result)

    # We should be back to working in strings
    assert isinstance

# Generated at 2022-06-22 14:19:13.362514
# Unit test for function do_vault
def test_do_vault():
    # Test to confirm that the correct ansible vault encrypted string is returned.
    test_input_data = "test_string"
    test_input_secret = "test_secret"

    test_output = "AQAAUDvz0e/W8dIzwfq/Z1vHeL1APO8cHNxOQ9dqbYhYFQQ0B0+wTc="
    assert(do_vault(test_input_data, test_input_secret) == test_output)

    # Test to confirm the correct exception is raised for invalid input for data
    invalid_input_data = 123
    try:
        do_vault(invalid_input_data, test_input_secret)
        assert False
    except AnsibleFilterTypeError:
        assert True

    # Test to confirm the correct

# Generated at 2022-06-22 14:19:18.412281
# Unit test for function do_unvault
def test_do_unvault():
    data = b"4f9b9db0c9ad1ac46d2c1507975fefb0"
    secret = b"foobar"
    vaultid = "filter_default"
    assert do_unvault(do_vault(data, secret, salt=None, vaultid=vaultid, wrap_object=True), secret, vaultid=vaultid) == data

# Generated at 2022-06-22 14:19:30.371259
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("foo", "secret") == "ANSIBLE_VAULT;1.1;AES256\n3732363137653336663939346638376236623734643936366433653064363539313638633334336235\n3335383066366331666563353333323735653034633038656165613731376136336239626265313964\n3864636461353834393365613534623038303062663035636235336664353839316165376664373066\n36613164326165643338306435303562316664623862636264633566\n"



# Generated at 2022-06-22 14:19:42.349513
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Environment
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib

    def assert_crypto(plain_text, vaulted_text, secret):
        assert do_unvault(vaulted_text, secret) == plain_text

    def assert_crypto_vault(plain_text, vaulted_text, secret):
        assert do_unvault(vaulted_text, secret) == plain_text

    def assert_is_encrypted(text):
        assert is_encrypted(text)

    def assert_not_encrypted(text):
        assert not is_encrypted(text)

    def assert_crypto_unavailable(plain_text, vaulted_text, secret, filters):
        env = Environment()

# Generated at 2022-06-22 14:19:55.553230
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("", "") == ""
    assert do_vault("", "", wrap_object=True).data == ""

    assert do_vault("test-string", "secret") == "$ANSIBLE_VAULT;1.2;AES256;ansible\n366437623337626430656265396163663935313266303461613937303538386165623631653230\n" \
                                                  "6536313666393537306433353061366133346466353864646138640a3565643534633464653536\n" \
                                                  "3261623661306161666131653338306262356433623138341a7c6a40326d7e8a8c00f0b76d74b\n"

# Generated at 2022-06-22 14:20:07.821366
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:23.284508
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Template
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    do_vault_filter = FilterModule()
    test_string = "test"
    test_key = "1234"
    test_vaultid = "test"
    test_salt = "test"
    test_wrap_object = False

    vault_1 = do_vault(test_string, test_key, test_salt, test_vaultid, test_wrap_object)
    vault_temp = Template("{{ test_string | vault(test_key, test_salt, test_vaultid, test_wrap_object) }}")

# Generated at 2022-06-22 14:20:31.733028
# Unit test for function do_vault
def test_do_vault():
    secret = 'testsecret'
    data = 'testdata'

    vault = do_vault(data, secret)

# Generated at 2022-06-22 14:20:35.149631
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault(
        'data',
        'secret',
        salt='salt',
        vaultid='filter_default',
        wrap_object=False
    )

    assert isinstance(vault, string_types)


# Generated at 2022-06-22 14:20:46.955013
# Unit test for function do_vault
def test_do_vault():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, Mock
    from ansible_collections.misc.not_a_real_collection.plugins.filters import vault

    # Test secret as string
    with patch('ansible_collections.misc.not_a_real_collection.plugins.filters.vault.VaultSecret', Mock()):
        with patch(
            'ansible_collections.misc.not_a_real_collection.plugins.filters.vault.VaultLib', Mock()
        ) as mock_vault:
            mock_vault.return_value = mock_vault
            mock_vault.encrypt.return_value = b'$ANSIBLE_VAULT;1.1;AES256'
            assert vault.do_

# Generated at 2022-06-22 14:20:54.844847
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:06.446377
# Unit test for function do_vault
def test_do_vault():

    a = do_vault('super secret stuff', 'super secret', vaultid='testvault')
    assert isinstance(a, string_types)
    assert a.startswith('$ANSIBLE_VAULT')

    b = do_vault('super secret stuff', 'super secret', vaultid='testvault', wrap_object=True)
    assert isinstance(b, AnsibleVaultEncryptedUnicode)

    # Verify that we can encrypt with an Uncrypted VaultSecret
    c = do_vault('super secret stuff', 'super secret', vaultid='testvault')
    assert isinstance(c, string_types)
    assert c.startswith('$ANSIBLE_VAULT')

    # Verify that vaulting fails for non-strings

# Generated at 2022-06-22 14:21:19.364603
# Unit test for function do_vault
def test_do_vault():
        assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n3063346166663633373961326466303937646162663535616132613839653534303638366530623666\n6132666263356137623761653963623937633262616130396264633236646563353930336234633733\n366231360a626463333738663162653265326531653233356532613937633431303833666461303764\n3233316234336438616239356632393662356338633637626535663063643265363034346235656566\n3764303932\n'


# Generated at 2022-06-22 14:21:32.252396
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('mysecretpswd', 'mysecretkey') == '$ANSIBLE_VAULT;1.2;AES256;\n613530373861636135653833373638663331336134313338613635373635346466343564663932383\n6137303362666634303335393965386433323264643430653666653564313236366430333538343861\n3465613331663333643562326464\n'

# Generated at 2022-06-22 14:21:45.160220
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("test", "password") == '$ANSIBLE_VAULT;1.1;AES256\n32333461623963316562643966613461376137616161373533396538343632353533303962346366\n653033393962366133613230633164376338383739303337663032623562340a3737646166346561\n31356161323565303137306366623235336334616236633463333732373330663734663065613361\n636532366535333861666532316235316635643937610a\n'