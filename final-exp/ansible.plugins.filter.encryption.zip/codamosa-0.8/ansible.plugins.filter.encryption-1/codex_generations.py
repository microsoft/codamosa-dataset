

# Generated at 2022-06-22 14:11:55.439308
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'password'

    with open("encrypted_yaml_file.txt", "r") as encrypted_file:
        vault = encrypted_file.read()
        assert is_encrypted(vault)
        print("Encrypted file summary:\n", vault)

        vault_ansible = do_vault("This is my secret.", secret)
        print("Ansible Vaulted string:", vault_ansible)

        assert secret == do_unvault(vault, secret)
        print("Decryted Ansible Vault:", do_unvault(vault, secret))
        print("Decryted Ansible Vault:", do_unvault(vault_ansible, secret))

# Generated at 2022-06-22 14:12:02.067996
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n353962366533663039353338316261363233333836353465623965363066396437633462316138\n613833393066356537623236333565376437356630646136613337633063616130666431613861\n34653238656661333033306465363332613261366239\n",
                     secret="Password1",
                     vaultid="testid") == "MyVaultData"

# Generated at 2022-06-22 14:12:12.151091
# Unit test for function do_unvault
def test_do_unvault():

    # Test 1: string with vault tag
    secret = 'mypassword'
    test = "$ANSIBLE_VAULT;1.1;AES256\n363533376439626236623863633832386163353437393437383032303130333361353166373334\n376139346632633165663139633538653039363761396330383638393630633264343537393135\n313535346336653835363065383939326237373664613634643637393533373834663138633462\n3766343465326264303936366362356239306434323166356665356460"
    # Expected output
    expected = 'mypassword'
    # Unit test
    assert do_un

# Generated at 2022-06-22 14:12:24.312281
# Unit test for function do_unvault
def test_do_unvault():

    # test_data is a dictionary
    test_data={}

    # test_data[1] is a valid string
    test_data[1] = 'test'

    # test_data[2] is an empty string
    test_data[2] = ''

    # test_data[3] is a number
    test_data[3] = 123

    # test_data[4] is an None
    test_data[4] = None

    # test_data[5] is a vault encrypted string

# Generated at 2022-06-22 14:12:33.490065
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;10.yml;VaultSecret') == 'test'
    assert do_unvault('$ANSIBLE_VAULT;9.yml;VaultSecret') == 'test'
    assert do_unvault('$ANSIBLE_VAULT;9.yml;VaultSecret') == 'test'
    assert do_unvault('$ANSIBLE_VAULT;9.yml;VaultSecret') == 'test'
    assert do_unvault('$ANSIBLE_VAULT;9.yml;VaultSecret') == 'test'


# Generated at 2022-06-22 14:12:43.240259
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:56.521014
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()

# Generated at 2022-06-22 14:13:03.725780
# Unit test for function do_vault
def test_do_vault():
    from ansible import constants as C
    from ansible.utils.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.filter import core as filters

    secret_key1 = VaultSecret(b'test_secret_key1')
    secret_key2 = VaultSecret(b'test_secret_key2')
    plain_data = 'test_plain_data'
    vault_id1 = 'test_vault_id1'
    vault_id2 = 'test_vault_id2'

    vault_lib = VaultLib([(vault_id1, secret_key1), (vault_id2, secret_key2)])

# Generated at 2022-06-22 14:13:16.635712
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:29.655203
# Unit test for function do_vault
def test_do_vault():

    # !!! This is a simple test to check if vault function is working as expected
    # !!! Ideally, there should be tests for various different cases

    secret = 'secret'
    salt = 'EC_ROCKET'
    vaultid = 'filter_default'

    text = 'testtext'
    wrapped_text = do_vault(text, secret, salt, vaultid, True)
    assert isinstance(wrapped_text, AnsibleVaultEncryptedUnicode)
    unwrapped_text = do_unvault(wrapped_text, secret, vaultid)
    assert unwrapped_text == text
    
    text = 'testtext'
    wrapped_text = do_vault(text, secret, salt, vaultid, False)
    assert isinstance(wrapped_text, string_types)
    unwrapped_

# Generated at 2022-06-22 14:13:44.638833
# Unit test for function do_unvault
def test_do_unvault():
    import unittest
    from unittest import mock
    from jinja2.runtime import Undefined
    from ansible.parsing.vault import is_encrypted, VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes

    class MyTest(unittest.TestCase):
        @mock.patch('ansible.parsing.vault.VaultSecret')
        def test_do_unvault(self, VaultSecret_mock):
            secret = "my secret"
            vault_str = "$ANSIBLE_VAULT;1.1;"
            ansible_vault = AnsibleVaultEncryptedUnicode(vault_str)
            vs = VaultSecret(to_bytes(secret))


# Generated at 2022-06-22 14:13:55.358521
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_native

    assert do_unvault(VaultLib().encrypt('foo', VaultSecret('pass')), 'pass') == 'foo'
    assert not isinstance(do_unvault(VaultLib().encrypt('foo', VaultSecret('pass')), 'pass'), AnsibleVaultEncryptedUnicode)

    assert do_unvault('$ANSIBLE_VAULT;7.38;AES256;ansible\ntest\n', 'pass') == 'test'
    assert not isinstance(do_unvault('$ANSIBLE_VAULT;7.38;AES256;ansible\ntest\n', 'pass'), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-22 14:14:04.652398
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:14.575329
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'my_test_secret'
    test_string = 'my test string'

# Generated at 2022-06-22 14:14:23.141679
# Unit test for function do_vault
def test_do_vault():

    data = 'test_data'
    secret = 'test_secret'

# Generated at 2022-06-22 14:14:31.899116
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('12345', 'hunter2') == '$ANSIBLE_VAULT;1.1;AES256\ntNq6BChq3o9RyZ0VbIeHwW8Mx3xq0yCPDcYIYulWcoRiDAXKZPO7Oc/Fn2S8j5O5\n'
    assert do_vault('12345', 'hunter2', wrap_object=True).data == '12345'


# Generated at 2022-06-22 14:14:40.837824
# Unit test for function do_vault
def test_do_vault():
    '''
    Unit test for function do_vault

    :return: None
    '''

    # create a file with a password
    import tempfile
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    (fd, filename) = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    password = 'hush_hush'
    f.write(password)
    f.close()

# Generated at 2022-06-22 14:14:53.070984
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:02.144400
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:12.717764
# Unit test for function do_vault
def test_do_vault():
    # Test filter with string, expecting an encrypted string in return
    assert isinstance(do_vault(data='string_to_encrypt', secret='password'), str)

    # Test filter with string, expecting a AnsibleVaultEncryptedUnicode object in return
    assert isinstance(do_vault(data='string_to_encrypt', secret='password', wrap_object=True), AnsibleVaultEncryptedUnicode)

    # Test filter with integer, expecting an error
    try:
        do_vault(data=1, secret='password')
        assert False
    except AnsibleFilterTypeError:
        assert True

    # Test filter with string, expecting an error

# Generated at 2022-06-22 14:15:19.686916
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    encrypted = "$ANSIBLE_VAULT;1.2;AES256;test\n613439333432376265373065663936623765626261376133613561663136613937313238323165\n3165653865333466346166396630623637333339613066313761323065623133666163356538\n3436653733653332393931633038633661373132653161656631333165\n"
    unencrypted = "another secret"
    vaultid='filtertest'
    assert do_unvault(encrypted, secret, vaultid) == unencrypted
    assert do_unvault(unencrypted, secret, vaultid) == unencrypted

# Generated at 2022-06-22 14:15:31.741531
# Unit test for function do_vault
def test_do_vault():
    ret = do_vault('foo', 'secret')

# Generated at 2022-06-22 14:15:41.419735
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("password", "secret") == b'$ANSIBLE_VAULT;1.2;AES256;test_testfilterplugins5917133340991699967_qa\n36353932366362316431643064333939353931303835383735656636363531396331666137393366\n'
    assert do_vault("password", "secret", "salt", "vaultid") == b'$ANSIBLE_VAULT;1.2;AES256;vaultid\n36353932366362316431643064333939353931303835383735656636363531396331666137393366\n'
    assert do_vault("password", "secret", "salt", "vaultid", True)

# Generated at 2022-06-22 14:15:48.125490
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data="", secret="", salt=None, vaultid='filter_default', wrap_object=False) == ""
    assert do_vault(data="", secret="", salt=None, vaultid='filter_default', wrap_object=True)
    assert do_vault(data=None, secret="", salt=None, vaultid='filter_default', wrap_object=True)


# Generated at 2022-06-22 14:15:51.729463
# Unit test for function do_vault
def test_do_vault():
    res = do_vault('some_password', 'some_salt', salt='some_salt')
    assert res == '$ANSIBLE_VAULT;1.1;AES256;some_salt\nsome_password\n'



# Generated at 2022-06-22 14:16:03.331360
# Unit test for function do_vault
def test_do_vault():
    vault_data = do_vault('secret_data', 'password')

# Generated at 2022-06-22 14:16:08.531056
# Unit test for function do_vault
def test_do_vault():
    # define the secret
    secret = 'secret'

    # define the salt
    salt = 'salt'

    # define vaultid
    vaultid = 'filter_default'

    # define test data
    data = 'data'

    # encrypt data
    vault = do_vault(data, secret, salt, vaultid)

    assert not isinstance(vault, Undefined)
    assert not isinstance(vault, UndefinedError)
    assert isinstance(vault, string_types)



# Generated at 2022-06-22 14:16:14.599317
# Unit test for function do_vault
def test_do_vault():

    try:
        do_vault('', '')
    except AnsibleFilterError:
        assert False

    try:
        do_vault(None, None)
    except AnsibleFilterError:
        assert False

    try:
        do_vault(5, "")
        assert False
    except AnsibleFilterTypeError:
        assert True

    try:
        do_vault('', 5)
        assert False
    except AnsibleFilterTypeError:
        assert True

    try:
        do_vault('', "")
        assert False
    except AnsibleFilterError:
        assert True


# Generated at 2022-06-22 14:16:27.217595
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = u'Arnold'
    vault = do_vault(data, secret)
    assert(is_encrypted(vault))

# Generated at 2022-06-22 14:16:30.701799
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;test\nx0N/7jYd/N/35QVuI3qf5g==", "secret", "test") == "test"

# Generated at 2022-06-22 14:16:39.094443
# Unit test for function do_vault
def test_do_vault():
    data = 'This is a secret'
    secret = 'my_secret'
    salt = 'my_salt'
    result = do_vault(data, secret, salt, wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-22 14:16:48.661280
# Unit test for function do_vault
def test_do_vault():
    import json
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    # create vaulted data with 'password' as secret
    vaulted_data = do_vault('secret data', 'password')

    # load vaulted data and make sure it's AnsibleVaultEncryptedUnicode
    loaded_data = yaml.load(vaulted_data, Loader=AnsibleLoader)
    assert isinstance(loaded_data, AnsibleVaultEncryptedUnicode)

    # make sure the __dict__ of AnsibleVaultEncryptedUnicode is vaulted
    assert loaded_data.__dict__['vaulted_data'] == vaulted_data

    # make sure the data is unvaulted with the secret 'password'

# Generated at 2022-06-22 14:16:57.587628
# Unit test for function do_vault
def test_do_vault():

    secret = "foo"
    data = "bar"
    vault = "ANSIBLE_VAULT;1.2;AES256;default6e5d5b0a5a66373034663837383533376538613361336132343737343031343032386165386538376236643765396638616139613231356163343265653237392f363033303964316636356531624464636362616136643264633561333831643a3830383534333239316139383366373036666562646237343161393138336539653433613934373365366462393735613335"


# Generated at 2022-06-22 14:17:10.620980
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:22.328662
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("SecretString","SecretPassword") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          36366462386336663336336135393839613461613830346539393238613830353062623133613663\n          66306663363639653335303834313661643335306230336230306139613231376137310a3735313963\n          66336532306363376231303832313737316131663938396331376133613262326263333361653865\n          393166373731303063306132363931613334323964373334\n          ............................"

# Generated at 2022-06-22 14:17:30.088304
# Unit test for function do_unvault
def test_do_unvault():
    data = '$ANSIBLE_VAULT;1.1;AES256\n62303231626263303338306237323563316330663536376132313761313038383362383039653064\n333965363033653564326164383438376336620a3666343237616238393764326262613739333864\n39643035366466376262336238656466336238613765386462383561623966626263346161303934\n6535663435366633\n'
    secret = 'mysecret'
    expected_value = 'my_data'
    assert do_unvault(data, secret) == expected_value

# Generated at 2022-06-22 14:17:40.568495
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault(
        data='secret',
        secret='secret',
        salt=None,
        vaultid='filter_default',
        wrap_object=False)


# Generated at 2022-06-22 14:17:45.595532
# Unit test for function do_vault
def test_do_vault():
    secret = b'super-secret-password'
    decrypted_text = b'This is a secret'
    v = do_vault(decrypted_text, secret)
    encrypted_text = v.encode()
    data = do_unvault(encrypted_text, secret)
    assert decrypted_text == data

# Generated at 2022-06-22 14:17:55.668988
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "topsecret" 
    vault = do_vault(data, secret, salt="some-salt")
    assert vault == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61386136656234393733433631643038363534373963633262313461343136636438356633343730\n          39366164636464353665643664623764336339616638346564356563303938613165626263653665\n          30306366623761326639653366353638303839313966646332336334333165636330363437353437\n          38393561\n"

# Generated at 2022-06-22 14:18:04.042613
# Unit test for function do_vault
def test_do_vault():
    t = FilterModule()
    assert '$ANSIBLE_VAULT;7.4;AES256;ansible\n3330356436396561636230656333363438363833366638616135613332643561346333383538306239\n6463666332323663663733363633613964653833643032643565346539643963343530393637656637\n3230383737653132663035333133383661393739326262623561623961623938356632636231626662\n363938346537356538\n' == \
        t.filters()['vault']('ansible', 'password', salt='ansible')


# Generated at 2022-06-22 14:18:17.727792
# Unit test for function do_vault
def test_do_vault():

    # Test when input is invalid
    try:
        do_vault('myteststring', 12345678)
        assert False, 'expected filter to raise exception'
    except AnsibleFilterError:
        pass

    # Test when valid input is provided

# Generated at 2022-06-22 14:18:27.094490
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret password'
    data = 'this should be a secret'
    salt = 'salt'
    vaultid = 'test'
    wrap_object = True

    try:
        test_result = do_vault(data, secret, salt, vaultid, wrap_object)
    except:
        raise

    assert isinstance(test_result, AnsibleVaultEncryptedUnicode)
    assert test_result.vault_identifier == vaultid
    assert test_result.vault == test_result.vault
    assert test_result.data == data



# Generated at 2022-06-22 14:18:38.540725
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n31343865353764333032666232356364373336343037646363383335663763306433343564396534\n62626563323130346431623938643166613231366131633066353631666235616438353462616230\n62333963353030613937616633333262623635383436646633393537636236386332613234393739\n38303230\n'

# Generated at 2022-06-22 14:18:45.781075
# Unit test for function do_vault
def test_do_vault():

    # Test pass do_vault a non-string
    try:
        data = 4
        secret = "secret"
        result = do_vault(data, secret)
        raise AssertionError("do_vault should raise an AnsibleFilterTypeError exception when passing a non-string data")
    except AnsibleFilterTypeError:
        pass

    # Test pass do_vault an undefined string
    data = Undefined()
    secret = "secret"
    try:
        result = do_vault(data, secret)
        raise AssertionError("do_vault should raise an UndefinedError exception when passing an undefined data")
    except UndefinedError:
        pass

    # Test pass do_vault a real string
    data = "mydata"
    secret = "secret"

# Generated at 2022-06-22 14:18:56.620703
# Unit test for function do_vault
def test_do_vault():
    # test1: normal case
    secret = "some_secret"
    data = "some_data"
    salt = None
    wrap_object = False

    result = do_vault(data, secret, salt, "", wrap_object)

    # since in py3 result is binary, so change it to str
    result = result.decode('utf-8')

    # if result is wrapped by AnsibleVaultEncryptedUnicode, need to change it to string
    if isinstance(result, AnsibleVaultEncryptedUnicode):
        result = to_bytes(result.data)

    assert result.startswith("$ANSIBLE_VAULT;")

    # test2: if secret is empty
    secret = ""
    data = "some_data"
    salt = None
    wrap_object = False

    result = do

# Generated at 2022-06-22 14:19:06.432064
# Unit test for function do_unvault
def test_do_unvault():
    def do_unvault_test(input, expected, secret=None, vaultid='filter_default'):
        res = do_unvault(input, secret, vaultid)
        assert res == expected

    do_unvault_test('$ANSIBLE_VAULT;1.2;AES256;filter_default\n'
                    '3637643064623761386631623138663564386638653232313561643630323566343464363934\n'
                    '3832323332643561303430306333636532353165316435613035376332633035303164623930\n'
                    '373932613234316533613939616335\n',
                    'test',
                    secret='test')


# Generated at 2022-06-22 14:19:15.711091
# Unit test for function do_vault
def test_do_vault():
    """
    Tests to see if do_vault returns correct encrypted string
    """

# Generated at 2022-06-22 14:19:23.502064
# Unit test for function do_unvault

# Generated at 2022-06-22 14:19:36.158247
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:47.742731
# Unit test for function do_vault
def test_do_vault():
    secret = 'test_secret'
    salt = 'test_salt'
    data = 'test_data'
    vault = '$ANSIBLE_VAULT;1.2;AES256;test_salt;test_vault_hash;test_vault_encrypted_data'
    vaultid = 'test_vaultid'
    vaultid_default = 'filter_default'
    test_vault = do_vault(data, secret, salt=salt, vaultid=vaultid)
    test_vault_default = do_vault(data, secret, salt=salt)
    # print(test_vault)
    # print(test_vault_default)
    assert test_vault == vault and test_vault_default == vault


# Generated at 2022-06-22 14:20:03.111156
# Unit test for function do_unvault
def test_do_unvault():
    ''' test unvault string '''
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.2;AES256;default34337153633383038353864623439626439346233323530663437643933383066313332666363623661633162336336333038623635396262390a6463303464396633396265663132376339636431323265303564633963323864656534636639333434623132333738666361383966313138390a3933353030613733633966316435303439643833663636656265643730323566303834633565396464333130653462616262343161373832'

    assert do_unvault

# Generated at 2022-06-22 14:20:04.853857
# Unit test for function do_vault
def test_do_vault():
    do_vault("test", "test")


# Generated at 2022-06-22 14:20:17.235172
# Unit test for function do_vault

# Generated at 2022-06-22 14:20:29.464801
# Unit test for function do_vault
def test_do_vault():
    import json
    import six
    import random
    from ansible.parsing.vault import VaultLib

    # Call do_vault with secret string long enough
    data = 'kij11'
    secret = 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfs' + 'sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfs'
    salt = 'salt_0000000000000000'
    raw_vault = do_vault(data, secret, salt)
    vl = VaultLib()
    secret = VaultSecret(secret)
    decrypted_data = vl.decrypt(raw_vault, secret)
    assert decrypted_data == data

    # Call do_vault with secret string too short

# Generated at 2022-06-22 14:20:34.222971
# Unit test for function do_vault
def test_do_vault():
    import nose.tools as nt
    data = 'my secret data'
    vault = do_vault(data, 'secrete_password')
    nt.assert_not_equal(data, vault)
    # Ensure vault is a string
    assert isinstance(vault, str)


# Generated at 2022-06-22 14:20:36.050050
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'data'
    salt = 'test'

    result = do_vault(data=data, secret=secret, salt=salt)

    # Encrypted output should be different from plain text
    assert data != result

    # Encrypted output should contain the salt
    assert salt in result



# Generated at 2022-06-22 14:20:44.654955
# Unit test for function do_vault
def test_do_vault():
    from ansible.plugins.filter.vault import do_vault

    # GIVEN
    data = "password"
    secret = "secret"

    # WHEN
    result = do_vault(data, secret)

    # THEN
    assert(result == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          333239316234623264323166323637653631613663336634663931663666623963333230646162363\n          663353430623930386331366135613635613739326463636166366336306666343938306563373202\n          3333356535643366\n          ")



# Generated at 2022-06-22 14:20:49.577157
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    v = f.filters()
    assert "!vault" not in v['vault']("test", secret="password123")
    assert isinstance(v['vault']("test", secret="password123", wrap_object=True), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-22 14:21:02.380328
# Unit test for function do_vault
def test_do_vault():
    data = 'my secret'
    secret = 'some password'
    vault = '$ANSIBLE_VAULT;1.2;AES256;filter_default\n396239353138366565353931393664386261363132303131633663306437663564373334646561\n323437643838626136303864396538616265393566313332396163626663623763396438623231\n316562326130643935336336613832366535356334626363633034306465316533333136353062\n656539343265303566393565663439653738386233373830363337343036396433326237336165\n31353766353765333130'
   

# Generated at 2022-06-22 14:21:15.505471
# Unit test for function do_unvault

# Generated at 2022-06-22 14:21:31.057916
# Unit test for function do_unvault
def test_do_unvault():
    # Test for invalid input
    try:
        do_unvault(1234)
        raise
    except AnsibleFilterTypeError:
        pass  # exception expected

    try:
        do_unvault("1234")
        raise
    except AnsibleFilterTypeError:
        pass  # exception expected

    # Test for valid input
    expected = "foobar"

# Generated at 2022-06-22 14:21:39.929306
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'salt'
    vaultid = 'filter_default'
    salt_vault = do_vault(secret, secret, salt=salt, vaultid=vaultid)
    nosalt_vault = do_vault(secret, secret, vaultid=vaultid)
    assert len(salt_vault) > 0
    assert len(nosalt_vault) > 0
    assert salt_vault != nosalt_vault


# Generated at 2022-06-22 14:21:43.861733
# Unit test for function do_vault
def test_do_vault():
    vaulted = do_vault('hello', 'topsecret')
    unvaulted = do_unvault(vaulted, 'topsecret')

    assert vaulted is not None
    assert unvaulted == 'hello'