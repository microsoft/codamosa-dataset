

# Generated at 2022-06-22 14:11:56.283603
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:05.309462
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n643031333263663064636535346564346637393436316364653765373636633838396530343731\n32346664383362396331633463616261323637616661303636373933316430623139393230343766\n'

# Generated at 2022-06-22 14:12:13.769439
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:26.288901
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == ''
    assert do_vault(True, None) == ''
    assert do_vault(True, True) == ''

# Generated at 2022-06-22 14:12:37.778664
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:49.932852
# Unit test for function do_vault
def test_do_vault():
    import os
    import sys

    # Create fake AnsibleModule class that has the `display` method
    class AnsibleModuleFake(object):

        def __init__(self, *args, **kwargs):
            pass

        def display(self, msg, status=True):
            print(("succeeded" if status else "failed") + ": " + msg)

        def fail_json(self, *args, **kwargs):
            sys.exit(1)

    if not os.getenv("UNIT_TESTING"):
        raise Exception("For unit testing only")

    am = AnsibleModuleFake()
    display.verbosity = 4
    display.logger = am.display

    # Try to vault secrets
    secrets = ["ansible", "ansible123", "password"]
    salt = "11aa22cc"

# Generated at 2022-06-22 14:12:58.874412
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("Test", "test") == "$ANSIBLE_VAULT;1.1;AES256\n3062323161313637333735303636396637333335393234356233373439356566386538666433\n3561386131303833633764393465643961643338373530623462343763303565646232313864\n36643731333262636235316531353235316439663634\n"


# Generated at 2022-06-22 14:13:11.211762
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) is None
    assert do_unvault(10, None) == 10
    assert do_unvault(u'10', None) == u'10'
    assert do_unvault(b'10', None) == b'10'
    assert do_unvault('not_encrypted', None) == 'not_encrypted'
    assert do_unvault(u'not_encrypted', None) == u'not_encrypted'
    assert do_unvault(b'not_encrypted', None) == b'not_encrypted'

# Generated at 2022-06-22 14:13:17.879409
# Unit test for function do_vault
def test_do_vault():
    actual = do_vault("some text", "some_secret")

# Generated at 2022-06-22 14:13:30.012259
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 14:13:44.386429
# Unit test for function do_unvault
def test_do_unvault():
    secret = "vaultsecret"
    vaultid = 'filter_default'
    vault_correct_encryption = 'U2FsdGVkX1+6fWU6JX9RVu5S1Q5B5u5CRPxo7Pq3w4k='
    vault_incorrect_encryption = 'U2FsdGVkX1/Hn6+jU6gbodU6Nlh6nNb7VX9S1K82J5A='

    assert do_unvault(vault_correct_encryption, secret, vaultid) == 'my_secret'


# Generated at 2022-06-22 14:13:55.279420
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('{SSHA}secret', 'supersecret') == u'$ANSIBLE_VAULT;1.1;AES256\n6135376635306566373133356635653063663461323138393037396538366535343431626231363538\n3661623962366331346137623335643939306232303035336231636332316666366535303863353938\n36326261323561613236\n'

# Generated at 2022-06-22 14:13:59.705741
# Unit test for function do_unvault
def test_do_unvault():
    sec = 'my_secret'
    tar = "this_is_my_fancy_secret"
    encrypt = do_vault(tar, sec)
    assert do_unvault(encrypt, sec) == tar

    # Test undefined input
    assert do_unvault(Undefined, sec) == Undefined

# Generated at 2022-06-22 14:14:07.520461
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    vl = VaultLib()
    test_secret = 'my_test_secret_value'
    test_data = 'my_test_data_value'
    vault_data = vl.encrypt(to_bytes(test_data), VaultSecret(to_bytes(test_secret)))
    assert do_unvault(vault_data, test_secret) == test_data

# Generated at 2022-06-22 14:14:10.208703
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    ansible_vault_string = ""
    assert do_unvault(ansible_vault_string, secret) == ""


# Generated at 2022-06-22 14:14:17.093845
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault("mypassword", "secret"), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-22 14:14:28.589569
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:33.670146
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "filter_default"

    def _test(data):
        vault = do_vault(data, secret, vaultid=vaultid)
        text = do_unvault(vault, secret, vaultid=vaultid)
        assert text == data

    _test("This is a string")
    _test(42)
    _test(b"bytes")

# Generated at 2022-06-22 14:14:35.987766
# Unit test for function do_unvault
def test_do_unvault():
    data = u'password'
    secret = u'secret'

    assert data == do_unvault(do_vault(data, secret), secret)



# Generated at 2022-06-22 14:14:40.942382
# Unit test for function do_unvault
def test_do_unvault():

    from unit_tests.unit.filter_plugins import vault_secret

    plain = 'this is a secret'
    secret = vault_secret.VaultSecret.from_string(vault_secret.SECRET)
    vl = vault_secret.VaultLib([('filter_default', secret)])
    vault = vl.encrypt(plain)

    data = do_unvault(vault, vault_secret.SECRET)
    assert(data == plain)

# Generated at 2022-06-22 14:14:55.287995
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:04.851302
# Unit test for function do_unvault
def test_do_unvault():
    # when
    output = do_unvault("$ANSIBLE_VAULT;1.1;AES256;test_id\n333036636133613161323131666665326262653766353433663737373237393364303634646531386\n6373616465356634336566333439623238323931636231636261336335613831663636356330333232\n6638346364643761\n", "secret")

    # then
    assert output == 'secret'

# Generated at 2022-06-22 14:15:16.820615
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.vault import VaultLibWrapper

    vault_password = 'test'
    vault_id_text = 'test'
    vault_lib = None
    vault_lib_wrapper = None


# Generated at 2022-06-22 14:15:24.387029
# Unit test for function do_vault
def test_do_vault():
    data = 'The quick, brown fox jumped over the lazy dog.'
    secret = 'ansible-vault-password-file'
    vault_id = 'test_vault_id'
    salt = 'test_salt'
    output = do_vault(data, secret, salt=salt, vaultid=vault_id, wrap_object=False)

    assert output.startswith('$ANSIBLE_VAULT')
    assert output.endswith('V\n')


# Generated at 2022-06-22 14:15:31.094547
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Template
    from jinja2 import Environment

    env = Environment()

    # test the filter
    assert(b"$ANSIBLE_VAULT;1.1;AES256\n" in env.from_string('''{{ "test" | vault("ansible") }}''').render())

    # test the filter with a salt
    assert(b"$ANSIBLE_VAULT;1.1;AES256;saltIPyJXVuLr\n" in env.from_string('''{{ "test" | vault("ansible", salt="IPyJXVuLr") }}''').render())

    # test the filter with a custom vault id

# Generated at 2022-06-22 14:15:41.137972
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault="$ANSIBLE_VAULT;1.1;AES256;packaging\n393537336534313134303961303031663566333235333039656261633237633732356165623533\n3762623730393831363361620a6631666538663162656239363434616663326537306562356338\n663134373238616233346238643934373938356434353738303435336132333162663233613366\n663735336639383762616335373138633862336562336264\n",
                      secret='ansible',
                      vaultid="filter_vaultid"
                      ) == 'packaging'


# Generated at 2022-06-22 14:15:52.193824
# Unit test for function do_vault
def test_do_vault():

    secret = '$ANSIBLE_VAULT;1.1;AES256'
    data = 'secret_data'
    vaultid = 'filter_default'
    salt = None
    wrap_object = False
    

# Generated at 2022-06-22 14:16:03.374493
# Unit test for function do_unvault
def test_do_unvault():
    vault_raw = '$ANSIBLE_VAULT;1.1;AES256;test_vault\n34383039383633353936623337623839623134303436356332376138623838346533663730396636\n35333965363436373538613736653561666135316663353136656331313037653834336335333764\n36393536336439343138613264333036313330643566393062303235643936336431363263636137\n633062316566313461396635306466\n'
    result = do_unvault(vault_raw, 'passwd', 'test_vault')
    assert result == 'test'


# Generated at 2022-06-22 14:16:10.475780
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:17.023355
# Unit test for function do_vault
def test_do_vault():
    secret = 'donttellnobody'
    data = 'this is secret data'
    outvault = do_vault(data, secret)
    assert data == do_unvault(outvault, secret)

    outvault = do_vault(data, secret, vaultid='foobar')
    assert data == do_unvault(outvault, secret, vaultid='foobar')
    assert data != do_unvault(outvault, secret)

    outvault = do_vault(data, secret, salt='fizzbuzz')
    assert data == do_unvault(outvault, secret)

    if hasattr(outvault, 'data'):
        assert data == outvault.data
        assert hasattr(outvault, 'vault')

# Generated at 2022-06-22 14:16:23.220205
# Unit test for function do_unvault
def test_do_unvault():
    secret = VaultSecret("test123")
    vl = VaultLib()
    data = to_bytes("test")
    vault = vl.encrypt(data, secret)
    assert do_unvault(vault, "test123") == "test"

# Generated at 2022-06-22 14:16:35.924804
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:46.983135
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:56.677876
# Unit test for function do_vault

# Generated at 2022-06-22 14:17:01.432239
# Unit test for function do_vault
def test_do_vault():
    """
    Verify that secret is encrypted
    """
    data = 'test'
    secret = 'secret'
    vault = do_vault(data, secret)
    assert vault != data
    assert do_vault(vault, secret) != vault


# Generated at 2022-06-22 14:17:14.187815
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_value', 'mysecret', vaultid='test_vaultid') == b'$ANSIBLE_VAULT;1.1;AES256\n3565313364633131363735366332363465633530353332623365323532353136363331623861326331\n6431633139313162346132626166663263376636376530656264333634376136656437393533393530\n6137633033623335316530653339313638323430636632613761320a39356439356565333239653235\n3636386131633730343132656630323139613261323237323165333061326434326564313232663036\n66'

#

# Generated at 2022-06-22 14:17:21.255978
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vault = do_vault(data, secret)
    assert vault
    assert data != vault
    assert is_encrypted(vault)
    assert not isinstance(vault, string_types)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.data == to_native(data)

    v2 = do_unvault(vault, secret)
    assert v2 == data

# Generated at 2022-06-22 14:17:26.094131
# Unit test for function do_vault
def test_do_vault():
    secret = "dummy password"
    data = "secret data"
    salt = "salt"
    vaultid = "vaultid"
    result = do_vault(data=data, secret=secret, salt=salt, vaultid=vaultid)
    print(result)

if __name__ == '__main__':
    test_do_vault()

# Generated at 2022-06-22 14:17:36.795362
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'mysecret'

    # Test for regular string
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(data, secret)

    # Test for unicode
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(u'str', secret)

    # Test for uppercase string
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault('MYSTRING', secret)

    # Test for undefined string
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(Undefined(None), secret)



# Generated at 2022-06-22 14:17:40.876723
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    do_vault(data, secret)


# Generated at 2022-06-22 14:17:47.583223
# Unit test for function do_vault
def test_do_vault():
    ''' Test for function do_vault '''
    secret_text = "secret"
    data_text = "data"
    vault_text = do_vault(data_text, secret_text)
    assert vl.decrypt(vault_text) == data_text


# Generated at 2022-06-22 14:17:57.517514
# Unit test for function do_vault
def test_do_vault():
    secret = to_bytes('password')
    data = to_bytes('this data is Vaulted')
    salt = to_bytes('1234')
    vaultid = 'filter_default'
    wrap_object = False

    # Test hashicorp vault
    vaulted = do_vault(data, secret, salt, vaultid, wrap_object)

    assert '$ANSIBLE_VAULT' in vaulted
    assert isinstance(vaulted, str)

    # Test wrap_object
    wrap_object = True
    vaulted = do_vault(data, secret, salt, vaultid, wrap_object)

    assert '$ANSIBLE_VAULT' in vaulted
    assert isinstance(vaulted, AnsibleVaultEncryptedUnicode)
    assert vaulted.vault

    # Test Vault secret is not a string
   

# Generated at 2022-06-22 14:18:00.292876
# Unit test for function do_unvault
def test_do_unvault():
    data = 'secret string'
    secret = 'secret'
    vault_string = do_vault(data, secret)
    assert do_unvault(vault_string, secret) == data

# Generated at 2022-06-22 14:18:13.869448
# Unit test for function do_vault
def test_do_vault():
    data = "secret"
    secret = None
    vaultid = 'filter_default'
    wrap_object = False

    data2 = b"secret"
    secret2 = None
    vaultid2 = 'filter_default'
    wrap_object2 = False

    data3 = "secret"
    secret3 = None
    vaultid3 = 'filter_default'
    wrap_object3 = True

    data4 = "secre$"
    secret4 = None
    vaultid4 = 'filter_default'
    wrap_object4 = True

    # check if do_vault() raises AnsibleFilterTypeError
    try:
        do_vault(data, secret, vaultid, wrap_object)
    except AnsibleFilterTypeError:
        raise

# Generated at 2022-06-22 14:18:22.287671
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'my vault'
    wrap_object=False

    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert result == u'$ANSIBLE_VAULT;1.1;AES256\n3734376630346236623637353964643831366436353364623034636237353364643265386430613063363\n64303039646333656234326263623563620a30623134663939653565666263323135343831376361623536\n346262363636303937363062373738306636343031373965386134323861646332370a'



# Generated at 2022-06-22 14:18:27.528053
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = 'wrap_object'
    assert do_vault(data, secret, salt, vaultid, wrap_object) is not None


# Generated at 2022-06-22 14:18:38.708788
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None,'ABC') == None
    assert do_unvault('ABC','ABC') == 'ABC'

# Generated at 2022-06-22 14:18:45.864250
# Unit test for function do_vault
def test_do_vault():
    secret = 'pass123'
    data = 'secret'
    vault = do_vault(data, secret)
    assert vault == '$ANSIBLE_VAULT;1.1;AES256;filter_default\n376438623662343035666435646264643339376363623833623138653864346562646437663332\n396237663765353236623466626337623433373436396363376330663630653337626332316630\n30393836326533343765\n'
    data2 = 'secret'
    vault2 = do_vault(data2, secret)

# Generated at 2022-06-22 14:18:56.657756
# Unit test for function do_vault
def test_do_vault():
    test_secret = '$ANSIBLE_VAULT;1.2;AES256;foo\nbar'
    assert do_vault('secret', test_secret) == '$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n'
    assert do_vault('', test_secret) == '$ANSIBLE_VAULT;1.2;AES256;foo\n\n'
    assert do_vault('test123ãéìôü ÇñÑ', test_secret) == '$ANSIBLE_VAULT;1.2;AES256;foo\nbar\n'

# Generated at 2022-06-22 14:19:06.472644
# Unit test for function do_unvault
def test_do_unvault():
    # Test with valid vault and secret
    valid_vault = u'$ANSIBLE_VAULT;1.1;AES256;CHANGEME\n3462396336623166362316339613165366566361336533613364373933643561373564393538\n3338373035376431376233373036663439376661623632626262393732303536623731316332\n3662623234386538656164663536653564376234653565363964383363656166323564376339\n6463393133313731323332346437626436383665356465\n'
    valid_secret = u'CHANGEME'
    ansible_vault_decrypted_value = do_un

# Generated at 2022-06-22 14:19:20.813531
# Unit test for function do_vault
def test_do_vault():
    secret = "this is a secret"
    data = "this is a secret"
    # salt = "this is salt"
    vaultid = "filter_default"
    wrap_object = False
    result = do_vault(data, secret, vaultid, wrap_object)

# Generated at 2022-06-22 14:19:22.626602
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('password', 'secret'), str)


# Generated at 2022-06-22 14:19:29.211957
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'data'
    salt = None
    vaultid = 'test'
    vault = do_vault(data, secret, salt, vaultid, wrap_object=False)
    assert isinstance(vault, string_types)
    assert is_encrypted(vault)
    assert vault.endswith('\n')
    assert not vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-22 14:19:30.424291
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-22 14:19:36.063273
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('VAULT::YkFsZzNoYW5pcXVlX3ZhdWx0MTIzNA==', 'test123') == 'ansible_vault1234'
    assert do_unvault('VAULT::YkFsZzNoYW5pcXVlX3ZhdWx0MTIzNA==', 'test123', vaultid='filter_default') == 'ansible_vault1234'
    assert do_unvault('VAULT::YkFsZzNoYW5pcXVlX3ZhdWx0MTIzNA==', 'test123', 'filter_default') == 'ansible_vault1234'

# Generated at 2022-06-22 14:19:48.130012
# Unit test for function do_vault
def test_do_vault():
    ''' Ansible vault jinja filter test '''

    # Test list input

# Generated at 2022-06-22 14:20:00.938588
# Unit test for function do_vault
def test_do_vault():
    secret_subphrase = "bar"
    # string to encrypt
    data = "foo"
    vaultid = "filter_default_1"
    salt = None
    wrap_object = False

# Generated at 2022-06-22 14:20:05.856494
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    data = 'stringtoencrypt'
    wrapped_object = True
    vault = do_vault(data, secret, salt, wrap_object=wrapped_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    unwrapped_vault = do_unvault(vault, secret)
    assert unwrapped_vault == data
    assert isinstance(vault.vault, VaultLib)
    assert vault.data == unwrapped_vault
    assert vault.wrap_object is wrapped_object

    wrapped_object = False
    vault = do_vault(data, secret, salt, wrap_object=wrapped_object)
    assert isinstance(vault, string_types)

# Generated at 2022-06-22 14:20:18.089381
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('ADFGVX', 'crazysecret', 'foosalt')
    assert isinstance(result, string_types)
    assert result == '$ANSIBLE_VAULT;1.2;AES256;foosalt\n35343035343037646661303766323231346637343566343339333732356135306462383633346461\n64366332346539303764356536663430343330263236363432383139306432383662393163393063\n39353433382666643165356639623031396363353261626563653239316339383762383139306563\n6365666535393761\n'

    # Test with wrap_object=True
    result

# Generated at 2022-06-22 14:20:30.301562
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    from jinja2.loaders import DictLoader
    env = Environment(loader=DictLoader({
        'template': """
        {{ vaultid }}
        {{ salt }}
        {{ wrap_object }}
        {% for data in data_list %}
        {{ data | vault(password, salt, vaultid, wrap_object) | string }}
        {% endfor %}
        """
    }))

    template = env.get_template('template')

    password = "passw0rd"
    salt = "salt"
    vaultid = "filter_default"
    wrap_object = False
    data_list = [
        "abc",
        "",
        "",
        "abc123",
    ]


# Generated at 2022-06-22 14:20:37.560231
# Unit test for function do_unvault
def test_do_unvault():
    secret = ''
    try:
        do_unvault('', secret)
    except AnsibleFilterTypeError as e:
        assert "Secret passed is required to be as string" in str(e)
    except Exception as e:
        assert "AnsibleFilterTypeError" in str(e)


# Generated at 2022-06-22 14:20:46.164364
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:54.347246
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import text_type

    # Check for case when secret is not a string
    try:
        do_vault('test', 'password', object)
    except AnsibleFilterTypeError as e:
        assert('string' in text_type(e))

    # Check for case when data is not a string
    try:
        do_vault(object, 'password')
    except AnsibleFilterTypeError as e:
        assert('string' in text_type(e))

    # Check for usage of vault lib
    try:
        do_vault('test', 'badpassword')
    except AnsibleFilterError as e:
        assert('VaultLib' in text_type(e))

    # Check for undefined variable

# Generated at 2022-06-22 14:21:06.012846
# Unit test for function do_vault
def test_do_vault():
    # Test for basic encrypt and decrypt
    data = 'test-string'
    secret = 'test-secret'
    vault = do_vault(data, secret)
    check = do_unvault(vault, secret)
    assert check == data

    # Test for salt
    data = 'test-string'
    secret = 'test-secret'
    salt = 'test-salt'
    vault = do_vault(data, secret, salt)
    check = do_unvault(vault, secret)
    assert check == data

    # Test for wrong types
    data = 1
    secret = 'test-secret'
    try:
        do_vault(data, secret)
    except AnsibleFilterTypeError:
        assert True
    else:
        assert False

    # Test for wrong types

# Generated at 2022-06-22 14:21:17.192930
# Unit test for function do_vault
def test_do_vault():
    module = AnsibleModule(argument_spec=dict(
        data=dict(type='str'),
        secret=dict(type='str'),
        salt=dict(type='str'),
        vaultid=dict(default='filter_default'),
        wrap_object=dict(type='bool', default=False)
    ))

    result = do_vault(module.params['data'], module.params['secret'], module.params['salt'], module.params['vaultid'], module.params['wrap_object'])
    if module.params['data']:
        assert result
    else:
        assert not result
    print("FilterModule vault success")


# Generated at 2022-06-22 14:21:29.683304
# Unit test for function do_unvault
def test_do_unvault():
    # Case 1 - string
    secret = "mysecret"
    vaultid = 'filter_default'
    data = "mydata"
    encrypted_data = do_vault(data, secret)
    assert(data == do_unvault(encrypted_data, secret, vaultid))
    # Case 2 - AnsibleVaultEncryptedUnicode
    ansible_vault_data = AnsibleVaultEncryptedUnicode(encrypted_data)
    assert(data == do_unvault(ansible_vault_data, secret, vaultid))
    # Case 3 - is_encrypted(string)
    assert(data == do_unvault(encrypted_data, secret, vaultid))
    # Case 4 - not encrypted data
    data = "mydata"

# Generated at 2022-06-22 14:21:42.750456
# Unit test for function do_unvault
def test_do_unvault():
    # set secret
    secret = "test_secret"
    # test actual password vault
    vault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          393631363333663266363836383562366363386465626236633266353738323535616235613664\n          633633353164373261646435346362333262333861323062643566303462366330303565303637\n          3039353166316539303338303136653536\n          "
    assert do_unvault(vault,secret) == "Hello world"
    # test password as "password"