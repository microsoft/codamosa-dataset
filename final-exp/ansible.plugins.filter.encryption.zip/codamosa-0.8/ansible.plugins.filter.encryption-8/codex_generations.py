

# Generated at 2022-06-22 14:11:55.993473
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"
    # Decoding vault

# Generated at 2022-06-22 14:12:05.050179
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('ansible', 'my_secret') == "\x1c\x1e\x11\x1d\x16\x03\x0b\x0c\x15\x1b\x1a\x1d\x04\x17\x19\x03\x18\x10\x0a\x1b .[\x19\x1c\x1b\x1f:D\\\x06\x1d\x15\x05\x1c\x18\x19\x03\x0b\x0c\x15\x1b\x1a\x1d\x17\x04\x1b:D\\\x06\x1d\x15"

# Generated at 2022-06-22 14:12:13.646953
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('testsecret', 'testsecret', 'test_salt', wrap_object=False) == '$ANSIBLE_VAULT;1.1;AES256;test_salt\ndGVzdHNlY3JldAo=\n'
    assert do_vault('testsecret', 'testsecret', 'test_salt', wrap_object=True) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;test_salt\ndGVzdHNlY3JldAo=\n')

# Generated at 2022-06-22 14:12:20.595505
# Unit test for function do_vault
def test_do_vault():
    data = 'TESTDATA'
    secret = 'testsecret'
    salt = b'g'*16 # block-cipher needs a 16-byte salt, so we have to have this.
    vaultid = 'test_vault_id'
    wrap_object = False
    assert '$ANSIBLE_VAULT;1.1;AES256;g' + 'g'*17 in do_vault(data, secret, salt, vaultid, wrap_object)


# Generated at 2022-06-22 14:12:33.182607
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test"

# Generated at 2022-06-22 14:12:39.649359
# Unit test for function do_vault
def test_do_vault():

    assert do_vault('password', 'secret', 'salt', 'vaultid') == '$ANSIBLE_VAULT;1.1;AES256\n63336663643637653765343635346335346662633137613231323339323861656136636436336631\n623635646639386163356166666613936623430656232333030393298\n'


# Generated at 2022-06-22 14:12:52.408296
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:02.119108
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("password", 'correct') == '$ANSIBLE_VAULT;1.1;AES256;filter_default\n32643632356164653730366463303265333166626437653635343137303865376639643661333366\n363566336463366361393566393465303735613930626531613961350a3135633732363830366538\n32353637396536353633653438363335363265303130343763373238333732326532323638373431\n63323462626563653735343832303531613039316235620a', "Vaulted string does not match expected"

# Generated at 2022-06-22 14:13:14.573323
# Unit test for function do_vault
def test_do_vault():
    vault_secret = AnsibleFilterTypeError
    secret = 'bad type'
    data = 'bad type'
    salt = 'this is a salt'
    vaultid = 'default'
    wrap_object = False

    try:
        do_vault(data, secret, salt, vaultid, wrap_object)
    except vault_secret as e:
        assert 'Secret passed is required to be a string, instead we got:' in str(e)

    data = 'hello'
    secret = ''

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 14:13:18.701220
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'some data'

    # call the function
    result = do_vault(data, secret)

    # verify the result
    assert result is not None
    assert result != data



# Generated at 2022-06-22 14:13:30.265705
# Unit test for function do_unvault
def test_do_unvault():

    encrypted_string = u'$ANSIBLE_VAULT;1.1;AES256\n31663732633731633362396331393861616533303631666433363139313736643132343134356634\n34313035303864383330643830306331373430643965353162623665323532353235673d3d'
    secret = u'foobar'
    vaultid = 'test_unvault'
    expected_output = u'hello'

    output = do_unvault(encrypted_string, secret, vaultid)

    assert output == expected_output

# Generated at 2022-06-22 14:13:42.365668
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:50.902670
# Unit test for function do_unvault
def test_do_unvault():
    f = FilterModule()
    filters = f.filters()
    secret = 'secret'
    #single line

# Generated at 2022-06-22 14:14:02.210785
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.encrypt import do_encrypt
    # encode it with ansible.utils.encrypt.do_encrypt()
    password = '$6$salt$password'
    plaintext = 'stringtobevaulted'
    ciphertext = do_encrypt(password, 'data', plaintext)
    vl = VaultLib()
    # decode it with ansible.parsing.vault.VaultLib.decrypt()
    assert vl.decrypt(ciphertext) == unicode(plaintext)
    # decode it with ansible-doc jinja2 filter unvault()
    assert do_unvault(ciphertext, password) == unicode(plaintext)
    assert not do_unvault(plaintext, password)

# Generated at 2022-06-22 14:14:13.460306
# Unit test for function do_vault
def test_do_vault():
    from ansible.utils.unsafe_proxy import wrap_var

    data1 = "test_string"
    secret1 = "test_secret"
    salt1 = "test_salt"
    vaultid1 = "test_vaultid"

    vault1 = do_vault(data1, secret1, salt1, vaultid1)
    assert vault1 == "U2FsdGVkX1+FdPY5r5bNX1lb5O2Em/7q8qI2u+7VZoM="

    data2 = wrap_var(data1)
    secret2 = wrap_var(secret1)
    salt2 = wrap_var(salt1)
    vaultid2 = wrap_var(vaultid1)


# Generated at 2022-06-22 14:14:26.581614
# Unit test for function do_unvault
def test_do_unvault():
    """test_do_unvault.
    Goal of these tests is to verify that the function do_unvault can decrypt
    strings without error and with correct output
    """
    # Create a filter module object
    filters = FilterModule()
    filter_module = filters.filters()

# Generated at 2022-06-22 14:14:34.260517
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    vault = do_vault(data, secret)
    assert("mydata" == do_unvault(vault, secret))

    data = "my@data$"
    vault = do_vault(data, secret)
    assert("my@data$" == do_unvault(vault, secret))

    data = "\nmydata\n"
    vault = do_vault(data, secret)
    assert("\nmydata\n" == do_unvault(vault, secret))

# Generated at 2022-06-22 14:14:42.635606
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("foo", "bar")
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n31393664663163366434393265643339336131613861323631346630373566346563633435343566\n32643866326637306332386134613338373566643936633533653538343339623163633639326465\n37326533623165353739333866353339623438303265316532653235326539\n'
    vault = do_vault("foo", "bar", salt="abc")

# Generated at 2022-06-22 14:14:54.666533
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:02.870569
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("hello world", "secret")

# Generated at 2022-06-22 14:15:16.538954
# Unit test for function do_vault
def test_do_vault():
    secret = 'somesecret'
    data = 'somedata'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)

# Generated at 2022-06-22 14:15:22.401600
# Unit test for function do_vault
def test_do_vault():

    data = 'test'
    secret = 'password'
    salt = 'test'
    vaultid = 'test_vaultid'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

    assert isinstance(result, string_types)
    assert is_encrypted(result)
    assert result.startswith(b'$ANSIBLE_VAULT;') is True


# Generated at 2022-06-22 14:15:27.016956
# Unit test for function do_unvault
def test_do_unvault():
    result = do_vault("password123!", password="mysecret", wrap_object=True)
    assert "password123!" == do_unvault(result, "mysecret")
    assert "password123!" == do_unvault(result, "mysecret", vaultid="nonsense")


# Generated at 2022-06-22 14:15:30.436271
# Unit test for function do_vault
def test_do_vault():
    results = do_vault('foo', 'password', 'salt')
    #assert results == "bar"


# Generated at 2022-06-22 14:15:40.760141
# Unit test for function do_vault
def test_do_vault():
    from .helpers import AnsibleExitJson, AnsibleFailJson
    fixture_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures')
    secret = '18a1b134a89c7fe2'
    data = 'Hello World'

# Generated at 2022-06-22 14:15:50.184847
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("foobar", "secret") == "AQAAAKAAAAAaAAAAGgAAAAYMzc5ODMzODU0NDUxNTQyOQAAAQQAAABmZm9iYXIAAAZzZWNyZXQ="
    assert do_vault("bar", "foo") == "AQAAAKAAAAAaAAAAGwAAABhODJlMjE2Y2QxYmIxNzMxMDY4NjI4MWJlN2Q4ZDNiNzEAAAECAAAAYmFyAAAAAA=="


# Generated at 2022-06-22 14:16:01.821602
# Unit test for function do_vault
def test_do_vault():

    # Bad filter input
    filter = do_vault(None, 'secret')
    assert filter.endswith('FilterVault should be in the form of a string, instead we got: ')

    # Bad filter input
    filter = do_vault(False, 'secret')
    assert filter.endswith('FilterVault should be in the form of a string, instead we got: ')

    # Bad filter input
    filter = do_vault(1, 'secret')
    assert filter.endswith('FilterVault should be in the form of a string, instead we got: ')

    # Bad filter input
    filter = do_vault(True, 'secret')
    assert filter.endswith('FilterVault should be in the form of a string, instead we got: ')

    # Bad filter input
    filter = do_

# Generated at 2022-06-22 14:16:08.769037
# Unit test for function do_vault
def test_do_vault():
    import os
    import pytest

    from .vault_test_cases import DATA
    from .vault_test_cases import FILENAME
    from .vault_test_cases import FILENAME_OUTPUT
    from .vault_test_cases import SECRET
    from .vault_test_cases import SALT
    from .vault_test_cases import VAULTID
    from .vault_test_cases import WRAP_OBJECT

    def test_do_vault():
        vault = do_vault(DATA, SECRET, SALT, VAULTID, WRAP_OBJECT)
        assert vault == FILENAME_OUTPUT



# Generated at 2022-06-22 14:16:16.123139
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleFilterTypeError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    vl = VaultLib()
    secret = 'MySecrect'
    vaultid = 'filter_default'

    assert '$ANSIBLE_VAULT' in vl.encrypt('value', secret, vaultid).decode('utf-8')
    if PY3:
        assert '$ANSIBLE_VAULT' in vl.encrypt(r'value', secret, vaultid).decode('utf-8')
    else:
        assert '$ANSIBLE_VAULT' in vl.encrypt(r'value', secret, vaultid)
    assert '$ANSIBLE_VAULT'

# Generated at 2022-06-22 14:16:22.392160
# Unit test for function do_vault
def test_do_vault():

    result = do_vault("GRANT ALL ON *.* TO 'root'@'%' IDENTIFIED BY 'abc123';", 'mysecret')

# Generated at 2022-06-22 14:16:36.918559
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:47.650869
# Unit test for function do_unvault
def test_do_unvault():

    buf = b'\x00\x01\x02\x03\x04\x05\x06\x07'

    # test positive response

# Generated at 2022-06-22 14:16:57.035099
# Unit test for function do_vault
def test_do_vault():
    # test for success
    secret = 'ansible'
    salt = 'random data'
    data = 'hello world'

    # test for failure
    # no secret
    secret = None
    # no data
    data = None

    # test for failure
    # wrong secret type
    secret = 3

    # test for failure
    # wrong data type
    data = 3


# Generated at 2022-06-22 14:16:59.902908
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault("$ANSIBLE_VAULT;1.1;AES256;first_hash_value", "vault_secret") == "data")

# Generated at 2022-06-22 14:17:12.984772
# Unit test for function do_unvault
def test_do_unvault():
    # Correct usage
    secret = 'secret'
    expected = 'plain text'
    actual = do_unvault(do_vault(expected, secret), secret)
    assert actual == expected

    # Show error on incorrect type of `secret`
    secret = 1
    try:
        do_unvault(do_vault('', secret), secret)
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

    # Show error on incorrect type of `vault`
    secret = 'secret'
    vault = 1
    try:
        do_unvault(vault, secret)
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

    # Check that the output is always a string
    secret = 'secret'
    expected = ''
    actual = do_un

# Generated at 2022-06-22 14:17:22.373589
# Unit test for function do_vault
def test_do_vault():
    secret = 0x6B7C6146706871547066732F

    assert do_vault(b"This is a secret", secret) == "AQAAAAEAAD5hYGZoYFBmZGhgYmtmMDBzU1M="
    assert do_vault("This is a secret", secret) == "AQAAAAEAAD5hYGZoYFBmZGhgYmtmMDBzU1M="
    assert do_vault(b"This is a secret", secret, '$ANSSH') == "AQAAAAEAAD5hYGZoYFBmZGhgYmtmMDBzU1M="

# Generated at 2022-06-22 14:17:34.153496
# Unit test for function do_vault
def test_do_vault():
    from ansible.compat.tests import unittest

    class TestCase(unittest.TestCase):

        def test_returns_a_string(self):
            vault = do_vault('hello', 'secret')
            self.assertIsInstance(vault, str)

        def test_returns_a_wrapped_object_when_wrap_object_is_specified(self):
            vault = do_vault('hello', 'secret', wrap_object=True)
            self.assertIsInstance(vault, AnsibleVaultEncryptedUnicode)
            self.assertIsInstance(vault.data, str)


# Generated at 2022-06-22 14:17:42.570686
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:47.673162
# Unit test for function do_vault
def test_do_vault():
    secret = "MY_V@ULTP@SSW0RD"
    data = "Hello World"

    data_encrypted = do_vault(data, secret)
    data_decrypted = do_unvault(data_encrypted, secret)
    assert data == data_decrypted, "Test data doesn't match"


# Generated at 2022-06-22 14:17:57.592820
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:10.186806
# Unit test for function do_vault
def test_do_vault():
    secret = "abcdefghijklmnopqrstuvwxyz123456"
    data = "this is input data"
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          0000000000000000000000000000000000000700000000000000000000\n          00000000000000000000000000\n          00000000000000000000000000\n          00000000000000000000000000000000\n          00000000000000000000000000000000\n          00000000000000000000000000000000\n          00000000000000000000000000000000\n          00000000000000000000000000000000\n          0000\n          00000000000000000000000000"
    wrap_object = False
    salt = None
    vaultid = "test"
    assert do_vault(data, secret, salt, vaultid, wrap_object) == vault

# Generated at 2022-06-22 14:18:20.057799
# Unit test for function do_unvault
def test_do_unvault():
    data = '$ANSIBLE_VAULT;1.1;AES256\n35653251363131613563376236626261633361653561633239313461343934366435313566643361\n633361623263353937363964383166363263616662363965613366353130335a6566643838366566\n38333461666138306562643639386633316236636539393186376132393733363064663932303637\n37636638343739353961386564623138383565663534\n'
    unvaulted = do_unvault(data, 'secret')
    assert unvaulted == 'unvaulted'


# Generated at 2022-06-22 14:18:31.065560
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:40.754628
# Unit test for function do_vault
def test_do_vault():
    secret = 'vault_secret'


# Generated at 2022-06-22 14:18:46.142262
# Unit test for function do_unvault
def test_do_unvault():
    vault = VaultLib()
    secret = 'testsecret123'
    data = 'teststring'
    vid = 'filter_default'
    vs = VaultSecret(secret)
    encrypted = vault.encrypt(data, vs, vid)
    assert do_unvault(encrypted, secret) == data

# Generated at 2022-06-22 14:18:56.837865
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'salt'
    vaultid = 'vaultid'
    wrapped_object = True

# Generated at 2022-06-22 14:19:06.593557
# Unit test for function do_unvault
def test_do_unvault():
    vault = AnsibleVaultEncryptedUnicode('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          616132366161323661613236616132366161323661613236616132366161323636\n          61323661613236616132366161323661613236616132366161323661323661613\n          2366161323661613236616132366161323661613236616132366161323661613\n          23661613236616132366161323661613236616132366161323661613236616\n          3\n          ')

# Generated at 2022-06-22 14:19:18.093037
# Unit test for function do_unvault
def test_do_unvault():
    ''' Test function do_unvault '''

# Generated at 2022-06-22 14:19:30.884433
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:42.849858
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('foo', 'bar')

# Generated at 2022-06-22 14:19:57.893220
# Unit test for function do_vault
def test_do_vault():
    # Test a simple string without vault
    vault = do_unvault(vault='', secret='test_secret')
    assert isinstance(vault, string_types)
    # Test a simple string with vault
    vault_value = '$ANSIBLE_VAULT;1.1;AES256;test_secret\n34333135313035333766643837303565653934373330393461623366363962303662626134653136\n3039616663393265626564636665643138613362363530666639356264'
    vault = do_unvault(vault=vault_value, secret='test_secret')

# Generated at 2022-06-22 14:20:10.706701
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret, VaultLib
    import random
    import string

    for secret in [''.join(random.choices(string.ascii_letters, k=20)), '', None]:
        vs = VaultSecret(secret) if secret else None
        vl = VaultLib()
        salt = bytes(random.getrandbits(8) for i in range(8))

        for data in ['', 'A', 'AB', 'A'*432]:
            vlt = do_vault(data, secret, salt=salt, vaultid='not_default')

            if not vs:
                assert data == vlt
            else:
                assert data != vlt

                assert data == vl.decrypt(vlt)



# Generated at 2022-06-22 14:20:15.888162
# Unit test for function do_unvault
def test_do_unvault():
    data = "Hello world!"
    secret = "123"

    try:
        data_vault = do_vault(data, secret)
        data_unvault = do_unvault(data_vault, secret)
        assert data_unvault == "Hello world!"
    except Exception as e:
        assert False, to_native(e)

# Generated at 2022-06-22 14:20:23.967505
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:35.306986
# Unit test for function do_vault
def test_do_vault():
    class TestVars(object):
        def __init__(self, vault_secret, data, salt=None, vaultid='filter_default', wrap_obj=False):
            self.vault_secret = vault_secret
            self.data = data
            self.salt = salt
            self.vaultid = vaultid
            self.wrap_obj = wrap_obj

    def assert_exception(e):
        print(e)
        assert False


# Generated at 2022-06-22 14:20:47.127452
# Unit test for function do_unvault
def test_do_unvault():
    # normal string
    result = do_unvault('"hello world"', 'Vg3eA0r7fZkPdZnyofVJOkP/xgxD90j1XE/I2NcF51sqO1NpNdOoIyxkWe8Coxlx')
    assert result == 'hello world'

    # mark is_encrypted
    result = do_unvault('$ANSIBLE_VAULT;10.9;AES256;ansible-test\n"hello world"\n', 'Vg3eA0r7fZkPdZnyofVJOkP/xgxD90j1XE/I2NcF51sqO1NpNdOoIyxkWe8Coxlx')
    assert result == 'hello world'

    #

# Generated at 2022-06-22 14:20:54.958697
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:06.541001
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("hello", "secret") == "hello"

# Generated at 2022-06-22 14:21:12.827082
# Unit test for function do_vault
def test_do_vault():
    display.vvv = True

# Generated at 2022-06-22 14:21:23.630462
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('ansible', 's3creT') == '$ANSIBLE_VAULT;1.1;AES256\n613833356233656665323864656561303939333036356134666335666535396631626239383163\n656233346538663235373766643939323034346133353366376438313661663534666437326434\n613836643030633134376237653630656664383934616563316564653566643538666433306464\n323131653038643836636439323232646461383363303566\n'



# Generated at 2022-06-22 14:21:29.071058
# Unit test for function do_vault
def test_do_vault():
    data = 'hello'
    secret = 'secret'
    vault = do_vault(data, secret)
    unvault = do_unvault(vault, secret)
    assert data == unvault

# Generated at 2022-06-22 14:21:42.333045
# Unit test for function do_vault
def test_do_vault():
    # Test 1: Input data is a string
    in_data = 'my_secret_password'
    in_secret = 'my_secret_key'
    out_vault = do_vault(in_data, in_secret)
    assert out_vault == '$ANSIBLE_VAULT;1.1;AES256'
    assert '\n' not in out_vault

    # Test 2: Input data is unicode
    in_data = u'my_secret_password'
    in_secret = 'my_secret_key'
    out_vault = do_vault(in_data, in_secret)
    assert out_vault == '$ANSIBLE_VAULT;1.1;AES256'
    assert '\n' not in out_vault

    # Test 3: Input data is non-