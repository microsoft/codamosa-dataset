

# Generated at 2022-06-22 14:11:58.423410
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:11.054681
# Unit test for function do_unvault
def test_do_unvault():
    display.vvvv("Inside the test_do_unvault")

# Generated at 2022-06-22 14:12:23.052018
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    data = "this is a password"

# Generated at 2022-06-22 14:12:34.771538
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n353936373039383765653866383533326163363237396230663030396639616637333762623239\n3734636131346666613630646261643538333530653739327d0a'
    salt = '0123456789ABCDEF'
    vaultid = 'test_vault'
    plaintext = 'I love pizza'

    vault = do_vault(plaintext, secret, salt=salt, vaultid=vaultid, wrap_object=False)

# Generated at 2022-06-22 14:12:47.081613
# Unit test for function do_vault
def test_do_vault():
    assert (do_vault('obscured', 'somethingforsomething'))
    assert (do_vault(None, 'abc', wrap_object=False))
    assert (do_vault('', 'abc', wrap_object=False))
    assert (do_vault(None, 'abc', wrap_object=True))
    assert (do_vault('', 'abc', wrap_object=True))

    try:
        do_vault(None, None, wrap_object=True)
    except AnsibleFilterError as e:
        assert isinstance(e, AnsibleFilterError)

    try:
        do_vault(None, None, wrap_object=False)
    except AnsibleFilterError as e:
        assert isinstance(e, AnsibleFilterError)


# Generated at 2022-06-22 14:12:59.703058
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:12.220123
# Unit test for function do_unvault
def test_do_unvault():
    # pylint: disable=undefined-variable
    # pylint: disable=no-member
    # pylint: disable=unsupported-assignment-operation
    # pylint: disable=unsubscriptable-object
    # pylint: disable=unused-variable
    # pylint: disable=no-value-for-parameter
    from ansible.errors import AnsibleFilterTypeError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted
    secret = 'SomeSecret'
    unvaulted = 'some string'
    vl = VaultLib()
    vault = vl.encrypt(unvaulted, secret=secret, id='filter_default')
    data = do_unvault

# Generated at 2022-06-22 14:13:22.128586
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    not_secret = 'notmysecret'
    data = 'myvaulteddata'
    salt = 'my_salt'

    # Check for invalid types for secret
    for secret in 789, True, [], {}, ():
        try:
            do_vault(data, secret)
        except AnsibleFilterTypeError:
            continue
        raise AssertionError("do_vault() did not raise AnsibleFilterTypeError for secret of type %s" % type(secret))

    # Check for invalid types for data
    for data in 789, True, [], {}, ():
        try:
            do_vault(data, secret)
        except AnsibleFilterTypeError:
            continue

# Generated at 2022-06-22 14:13:28.856123
# Unit test for function do_vault
def test_do_vault():

    def _assert_vault_decrypt(pwd, secret, salt='$ANSIBLE_VAULT;1.1;AES256', vaultid='filter_default'):
        vault = do_vault(pwd, secret, salt, vaultid)
        decrypted = do_unvault(vault, secret, vaultid)
        assert decrypted == pwd, "Expected password: (%s) decrypted: (%s)" % (pwd, decrypted)

    # Check if passsword is encrypted
    _assert_vault_decrypt('password', None, salt=None)
    _assert_vault_decrypt('password', None, salt=None, vaultid='test_default')
    _assert_vault_decrypt('password', 'changeit', salt=None)

# Generated at 2022-06-22 14:13:35.953307
# Unit test for function do_unvault
def test_do_unvault():
    # GIVEN:
    # When secret is None
    secret = None
    # And data is None
    data = None
    # And vaultid is None
    vaultid = None
    # WHEN:
    # We call do_unvault with the given data
    ret = do_unvault(data, secret, vaultid)
    # THEN:
    # We should return None
    assert ret is None


# Generated at 2022-06-22 14:13:41.223568
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'data'
    vault = do_vault(data, secret)
    assert is_encrypted(vault) is True


# Generated at 2022-06-22 14:13:46.595783
# Unit test for function do_vault
def test_do_vault():
    # Data to encrypt
    data = 'my_data'
    # Vault password
    secret = 'my_secret'
    # Optional salt
    salt = 'my_salt'

    # Encrypt data
    v = do_vault(data, secret, salt)

    # Assert, fail if encrypted data != decrypted data
    assert v == do_unvault(v, secret)


# Generated at 2022-06-22 14:13:55.855562
# Unit test for function do_unvault
def test_do_unvault():
    import subprocess
    import json

    test_str = "test"
    test_failed_str = "wrong passphrase"
    test_secret = "ansible"
    test_failed_secret = "failed"

    p = subprocess.Popen(["ansible-vault", "encrypt_string", "--encrypt-vault-id", "debug_vault_id", test_str, "--vault-password-file", "vault_pass.txt"], stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    print(p.stdout.readline())
    vault_encoded = p.stdout.readline()


# Generated at 2022-06-22 14:14:01.275975
# Unit test for function do_vault
def test_do_vault():
    data = 'hello'
    secret = 'hush'
    vaultid = 'filter_default'
    salt = None
    wrap_object = False

    from jinja2 import Environment
    env = Environment()
    env.filters['vault'] = do_vault

# Generated at 2022-06-22 14:14:13.243548
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:23.526933
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import pytest 
    # Try an empty string
    try:
        do_unvault(None, "secret")
    except Exception as e:
        assert type(e) is AnsibleFilterError
    # Try an encrypted string with wrong secret
    try:
        test = "$ANSIBLE_VAULT;1.2;AES256;ansible;3934776714623963647853455667778>"
        do_unvault(test, "bad_secret")
    except Exception as e:
        assert type(e) is AnsibleFilterError

# Generated at 2022-06-22 14:14:35.018329
# Unit test for function do_unvault
def test_do_unvault():

    # Test correct vault secret
    secret = 'secret'
    data = do_vault("password", secret)
    assert do_unvault(data, secret) == "password"

    # Test incorrect vault secret
    secret = 'incorrect_secret'
    assert do_unvault(data, secret) != "password"

    # Test incorrect vault secret for a wrong vault_id
    assert do_unvault(data, secret, 'another_vault_id') != "password"

    # Test AnsibleVaultEncryptedUnicode object
    vault = do_vault("password", secret, wrap_object=True)
    assert do_unvault(vault, secret) == "password"

    # Test wrong vault object
    assert do_unvault("password", secret) != "password"

    # Test AnsibleVaultEnc

# Generated at 2022-06-22 14:14:43.201122
# Unit test for function do_unvault
def test_do_unvault():
    if display.verbosity > 0:
        display.display("Test: %s" % __name__)
    # Generate random string for secret
    import random
    import string
    chars = string.ascii_lowercase + string.ascii_uppercase + string.digits
    # Set secret to a random 16 char string
    secret = ''.join(random.choice(chars) for _ in range(16))
    # Generate random string for data
    data = ''.join(random.choice(chars) for _ in range(64))
    # Generate random string for salt
    salt = ''.join(random.choice(chars) for _ in range(16))
    vaultid = 'random_id'

# Generated at 2022-06-22 14:14:48.336544
# Unit test for function do_vault
def test_do_vault():

    vsecret = "mysecret"
    encrypted = do_vault("mydata", vsecret, wrap_object=False)
    assert encrypted != 'mydata'
    assert encrypted == do_vault("mydata", vsecret, wrap_object=False)
    assert do_unvault(encrypted, vsecret) == 'mydata'

# Generated at 2022-06-22 14:14:59.044448
# Unit test for function do_unvault
def test_do_unvault():
    import base64

    secret = 'TheWalrusAndTheCarpenter'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n'
    vault += base64.b64encode(b'In this style of verse,\nEach line rhymes with the next.\nWhen a pair of lines rhyme,\nThe effect is called ')

# Generated at 2022-06-22 14:15:11.286882
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello', 'abcd') == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62373838616661313939663163363236316230326536323462333337386632343936323439323138\n          32663335363632333435383938656530303262333563353361303361390a36333065356566363937\n          66306334336437333038643834643334636464306539646334363436663964343338356338333261\n          39646436336434396361336136626263630a'



# Generated at 2022-06-22 14:15:23.114184
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('my_secret', 'mysecret')

# Generated at 2022-06-22 14:15:30.503716
# Unit test for function do_unvault
def test_do_unvault():
    vault = ""
    secret = "ansible"
    vaultid = "test"

    try:
        do_unvault(vault, secret, vaultid)
    except AnsibleFilterError:
        pass
    try:
        do_unvault(None, secret, vaultid)
    except AnsibleFilterError:
        pass


# Generated at 2022-06-22 14:15:40.795306
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import get_vault_secret
    from ansible.plugins.loader import filter_loader

    results = filter_loader.all()

    mysecret = 'mysecret'

    vaultid = 'default'
    secret = get_vault_secret(vaultid)
    vault = do_vault(ImmutableDict({'foo': 'bar'}), mysecret, salt=None, vaultid=vaultid, wrap_object=False)
    vault = to_bytes(vault)
    data = do_unvault(vault, mysecret, vaultid=vaultid)


# Generated at 2022-06-22 14:15:49.452300
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret1'
    data = 'e'
    salt = 'salt1'
    result = do_vault(data, secret, salt)
    assert result == '$ANSIBLE_VAULT;1.0;AES256;salt1\naa000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000\n0000000004\n4f4c87430b7d0c22b3e2b1d8b1036772948f506c023421a4220f8a5\n'



# Generated at 2022-06-22 14:15:57.855708
# Unit test for function do_vault
def test_do_vault():
    """Test for function do_vault
    """

# Generated at 2022-06-22 14:16:07.229393
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:15.302970
# Unit test for function do_vault
def test_do_vault():
    '''Unit test for the do_vault filter'''

    import pytest
    from ansible.module_utils.six import PY2, PY3

    # Arrange
    if PY2:
        vault = unicode('$ANSIBLE_VAULT;1.2;AES256;test\n36363732303763346163373934356564663662353166613465336638306534303739386331666562633034\n396633306532643737386638376262306331366132356264393735\n')  # noqa

# Generated at 2022-06-22 14:16:27.708885
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret_data'
    data = 'some_data'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 14:16:35.364011
# Unit test for function do_vault
def test_do_vault():
    try:
        do_vault('zX2ZlR+f43GJ0Cvl7jKCoQ==$fRwAoajPt+5kITXZq3dKPtYW8tY5c+KjxrBUc1BbW8eo=', 'list', 'quux', 'filter_default', True)
    except AnsibleFilterError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 14:16:47.681119
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:52.584572
# Unit test for function do_vault
def test_do_vault():
    secret = 'foobar'
    salt = 'salt'
    vaultid = 'filter_default'
    data = 'plaintext'
    vault = do_vault(data, secret, salt, vaultid)
    assert isinstance(vault, str)
    assert vault != data
    assert vault != secret
    assert display.verbosity <= 4



# Generated at 2022-06-22 14:17:06.057767
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import _VaultEditor as VaultEditor
    from ansible.parsing.vault import get_file_vault_secret

    # use secrets
    secret = get_file_vault_secret(None)
    # use vault_pass.txt
    if secret is None:
        with open("test/dummyvault_pass.txt") as f:
            secret = f.read().replace('\n', '')

    vl = VaultLib([("test", VaultSecret(secret))])
    ve = VaultEditor(vl)
    example_vault_str = ve.encrypt("String to encrypt")
    assert is_encrypted(example_vault_str)


# Generated at 2022-06-22 14:17:12.275131
# Unit test for function do_unvault
def test_do_unvault():
    vault_secret = "my_secret"
    vault_data = "my_data"

    encrypted_vault = do_vault(vault_data, vault_secret)
    decrypted_vault = do_unvault(encrypted_vault, vault_secret)

    assert vault_data == decrypted_vault


# Generated at 2022-06-22 14:17:15.877580
# Unit test for function do_vault
def test_do_vault():
    obj = FilterModule()
    filters = obj.filters()
    value = filters['vault'](data='test', secret='test')
    assert isinstance(value, str)


# Generated at 2022-06-22 14:17:24.132506
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'test_secret'
    test_plain_text = 'test_plain_text'
    test_vaultid = 'test_vaultid'

    vl = VaultLib([(test_vaultid, VaultSecret(to_bytes(test_secret)))])
    test_vault_text = vl.encrypt(to_bytes(test_plain_text), vault_id=test_vaultid)
    assert(do_unvault(test_vault_text, test_secret, test_vaultid) == test_plain_text)



# Generated at 2022-06-22 14:17:36.061983
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    actual = do_vault('data', secret)

# Generated at 2022-06-22 14:17:39.032059
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'password'
    vaultid = 'filter_default'
    x = do_vault('hello', secret, wrap_object=False)
    assert do_unvault(x, secret, vaultid) == 'hello'


# Generated at 2022-06-22 14:17:49.988603
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import sys

    current_dir = os.path.dirname(os.path.realpath(__file__))
    ansible_path = os.path.join(current_dir, "../..")
    if not ansible_path in sys.path:
        sys.path.insert(0, ansible_path)

    from ansible.parsing.vault import get_file_vault_secret

    secret_file = os.path.join(current_dir, "../../examples/files/vault.key")
    vault_secret = get_file_vault_secret(secret_file)

# Generated at 2022-06-22 14:17:59.268631
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:15.282103
# Unit test for function do_unvault
def test_do_unvault():
    secret = "mysecret"
    vaultid = 'default'

# Generated at 2022-06-22 14:18:28.132490
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mypassword'
    res = do_vault(data, secret)

# Generated at 2022-06-22 14:18:33.926836
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'
    data = 'N3k7hb2aZuwR/0NNokPWCVhYp/0yGxRk5U5X6cZFpus='
    vault = do_vault(data, secret)
    assert data == do_unvault(vault, secret)


# Generated at 2022-06-22 14:18:41.897674
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n6230303636333837343530376634653065383038353933656436656638653631323334356565\n36653839386430356564376135356430353336336635346236663662356336380a343265623361\n613661613331326139313239613736653963373162366262396133316532336266376434323663\n316464306566643132306664396533393562386331650a', 'test') == 'test'

# Generated at 2022-06-22 14:18:54.226934
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    plaintext_data = 'plaintext_data'

# Generated at 2022-06-22 14:19:04.521320
# Unit test for function do_vault
def test_do_vault():
    filter = FilterModule()
    res = filter.filters()['vault']("secret", "foobar")

# Generated at 2022-06-22 14:19:12.225965
# Unit test for function do_vault
def test_do_vault():
    # Test data (using "ansible" as the password)
    test_data = {
        'foo': 'bar',
        'bigtext': 'A long string' * 1024 * 1024,
    }

    # Test that it works
    for key in test_data:
        value = test_data[key]
        vaulted = do_vault(value, password='ansible')
        assert vaulted != value
        unvaulted = do_unvault(vaulted, password='ansible')
        assert unvaulted == value

# Generated at 2022-06-22 14:19:22.005975
# Unit test for function do_vault
def test_do_vault():
    s = do_vault('some_string', 'some_secret')
    assert(s.startswith('$ANSIBLE_VAULT'))
    assert(s.endswith('\n'))

    with pytest.raises(AnsibleFilterTypeError):
        s = do_vault(['some_string'], 'some_secret')

    with pytest.raises(AnsibleFilterTypeError):
        s = do_vault({'some_string': 'some_string'}, 'some_secret')

    s = do_vault('some_string', 'some_secret', wrap_object=True)
    assert(isinstance(s, AnsibleVaultEncryptedUnicode))

    s = do_vault('some_string', 'some_secret', salt='some_salt')

# Generated at 2022-06-22 14:19:33.877392
# Unit test for function do_vault
def test_do_vault():
    # Test with valid input
    assert do_vault("Vaulted", "secret", salt="salt") == '$ANSIBLE_VAULT;1.1;AES256\r\n31323633656263626561386363323163393738333836663262633364386334313235306130353961336\r\n35343864393032646435347a26247466643d332338616236613331366262616329363242356537656133\r\n373365663839396437653739353034646566626363356366633910\r\n'
    # Test with invalid input

# Generated at 2022-06-22 14:19:46.202889
# Unit test for function do_unvault
def test_do_unvault():
    secret_key = 'abcdefgh'
    data = b'unvaulted_data'
    vaulted_data = b'$ANSIBLE_VAULT;1.1;AES256\n532764393063643337366436306664306139313632616262323063656162346361666664363761\n393766663733646430306139316364626166636531666234633661333166376165623139306430\n336134633631356262643236616138336664396566643565333330383466613461346566663362\n636665666539396162363236616438343632396332623534\n'
    unvaulted_data = do_un

# Generated at 2022-06-22 14:20:02.116345
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:12.079086
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible_test\n3330376134313461393137300a3565336664376234306465326366323462376431626263613231350a34356431623133326136356435623439306231653264663863326663356434353033653861360a323865643662653961316164653262356234363834386533666130313763363861356132643539\n","test_secret") == "test_data"

# Generated at 2022-06-22 14:20:21.741958
# Unit test for function do_vault

# Generated at 2022-06-22 14:20:28.904489
# Unit test for function do_vault
def test_do_vault():
    secret = 'TlQiTtSy1Gt8WFSg'
    salt = 'fDGKvry8WOyJpOwC'
    vault_string = do_vault('foo', secret=secret, salt=salt)
    assert 'foo' == do_unvault(vault_string, secret, 'test_do_vault')


# Generated at 2022-06-22 14:20:38.435266
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "filter_default"


# Generated at 2022-06-22 14:20:50.881392
# Unit test for function do_unvault
def test_do_unvault():
    # Invalid secret
    secret = 1234

# Generated at 2022-06-22 14:21:02.817613
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("secret", "password") == b"$ANSIBLE_VAULT;1.1;AES256\n306465353737366539653232336334373365333636316464373634333365303335626231623534\n346532356332386265356264626238313231376536336366613238653735333430343164623061\n303531633263643139613462316663383736633238383966363865353734303462396666383533\n636562323466393638666563646632313664663763633061666538653539363966303861643561\n363965393133\n"

# Generated at 2022-06-22 14:21:15.833989
# Unit test for function do_vault
def test_do_vault():
    # Encrypted case
    assert is_encrypted(do_vault('my_secret', 'my_password', wrap_object=True)) == True
    assert do_vault('my_secret', 'my_password', wrap_object=True) == '$ANSIBLE_VAULT;1.1;AES256;vault_test_filter\n623965646531303036333763346632613237663232386138626236653135323965623363623435\n323438343637623461356131373932313337326264313232303738347337306138336237613832\n30336331356137613236633361626263376337666365366335633739\n'
    # Non encrypted case

# Generated at 2022-06-22 14:21:28.047937
# Unit test for function do_vault
def test_do_vault():
    test_data = 'test_data'
    test_secret = 'mysecret'
    test_salt = 'mysalt'
    test_vaultid = 'filter_default'
    test_wrap_object = False

    # Test case 1: salt is None
    output = do_vault(test_data, test_secret, salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-22 14:21:36.705550
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('testdata', 'testsecret') == '$ANSIBLE_VAULT;1.1;AES256\n333336336261656132336563353065316433333764333630643163316233386366613361396333\n643537313461653235316137653065353038373839303361366363613661326166613038366334\n3836343333313932626134\n'


# Generated at 2022-06-22 14:21:51.945441
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible;\n3233656661323764333466353239633364356139306234316663393933373464376237373437\n3836383337363566653761386636333065313763366131303465663965336633\n','password') == 'test'