

# Generated at 2022-06-22 14:11:57.788659
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Template
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret

    secret_env_var = "ANSIBLE_VAULT_PASSWORD_FILE"
    vault_id_default = "filter_default"

    def _do_unvault(vault_data):
        secret = VaultSecret(None)
        return do_unvault(vault_data, secret, vault_id_default)

    # Test that unvault decrypts

# Generated at 2022-06-22 14:12:11.014818
# Unit test for function do_unvault
def test_do_unvault():
    """
    Tests for function do_unvault
    """
    filter_module = FilterModule()

# Generated at 2022-06-22 14:12:23.054899
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:34.771050
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:46.216228
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("my_secret", "my_secret") == "$ANSIBLE_VAULT;1.2;AES256;default\n373336333363653331633362663336353733363431626236613161663730653766633136653435\n306462653865336239623839376533663939653365376439336663666234636136636338316337\n363337656638616338663364393436346338636566613737326133636161313930663362383835\n65666433346664656336623239\n"



# Generated at 2022-06-22 14:12:57.082242
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    FUT = do_vault
    data = 'foo'
    secret = 'bar'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    vault = FUT(data, secret, salt, vaultid, wrap_object)

    context = {'vars': ImmutableDict()}
    templar = Templar(loader=None, variables=context)
    result = templar.do_vault(vault, secret, vaultid)
    assert result == data



# Generated at 2022-06-22 14:13:08.726349
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n35386635333730373032656331373935373632333936373061666439363638343735653130373065\n32323265616339616233656133653236396466353664663531346433353864303337336635396430\n61333636366461666137393666653637306234643730333735653665633037643538363162336530\n36663161643466333631346265373137303830383435343339343365653362393165625565363834\n346462646161693237\n", "secret") == 'ansible'


# Generated at 2022-06-22 14:13:20.330050
# Unit test for function do_vault
def test_do_vault():
    secret = 'mybigsecret'
    vault = do_vault('this string is to be encrypted', secret)

# Generated at 2022-06-22 14:13:31.703873
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:39.465995
# Unit test for function do_unvault
def test_do_unvault():
    import os
    cwd = os.path.dirname(os.path.realpath(__file__))
    test_vault_file = os.path.join(cwd, 'test_vault')
    test_secret = 'password'
    with open(test_vault_file, 'rb') as fh:
        encrypted_secret = fh.read()
    plain_secret = do_unvault(encrypted_secret, test_secret)
    assert plain_secret == 'Hello World'

# Generated at 2022-06-22 14:13:42.981979
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(True, False, False) == ''



# Generated at 2022-06-22 14:13:51.326889
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello', 'secret', 'salt') == '$ANSIBLE_VAULT;1.1;AES256;salt;aW52YWxpZCB1bmRlZmluZWQgY2hhcg==;6ceb87a0a0c19f461945e46388ec5b81a5a5c3e5ea5d96a4cc4f4b57f2b0a8b3d36d45e491599e789f2c9ce3422eabed'

# Generated at 2022-06-22 14:14:02.504532
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('example') == '!vault |\n  $ANSIBLE_VAULT;1.1;AES256\n  38653534306238333039333539346466653864663934636662636263306330353334656435333062\n  38386332386161373666393963643636343032313438\n  62356231346132613161373232353162363961636166333737663036353632363037366234313761\n  303366376531366230373637363361643338363830\n'

# Generated at 2022-06-22 14:14:10.276428
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.parsing.vault import is_encrypted
    from ansible.module_utils.six import text_type

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    import sys

    secret = VaultSecret('my_secret')
    vault_lib = VaultLib([('my_default', secret)])

    # Test case 1:
    raw_data = u'my_password'
    vault_data = vault_lib.encrypt(raw_data)

    # Assertion 1
    assert is_encrypted(vault_data) == True

    # Assertion 2
    assert do_unvault(vault_data, 'my_secret') == 'my_password'

    # Assertion 3

# Generated at 2022-06-22 14:14:14.477267
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('test', 'VaultSecret',
                     vaultid='test_pass', wrap_object=True)

# Generated at 2022-06-22 14:14:27.146136
# Unit test for function do_vault
def test_do_vault():
    secret = 'this is a very secret password'
    data = 'the quick brown fox jumps over the lazy dog'
    salt = 'salt'
    vaultid = 'filter_default'
    result = do_vault(data, secret, salt, vaultid, wrap_object=False)
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n31323166623264653430323666663936633962626532356139303239376236633830336131666434\n39653366616236316339653165353566363033666534346437303637353237356466616232643130\n65343364343766393336363961663738\n'


# Generated at 2022-06-22 14:14:31.359206
# Unit test for function do_vault
def test_do_vault():
    secret = "random_key_greater_than_32_bytes"
    data = "This is a secret"
    result = do_vault(data, secret)
    assert isinstance(result, str)


# Generated at 2022-06-22 14:14:41.308996
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ""
    assert do_unvault("1018974:b7e853b5ef501a2630c1ae9f87ab8f99", "secret") == "test_text"

# Generated at 2022-06-22 14:14:53.512984
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:02.430201
# Unit test for function do_vault
def test_do_vault():
    import json
    import os
    import sys
    import yaml
    from ansible.module_utils.common.collections import is_sequence

    assert sys.version_info >= (2, 6)

    # 'do_vault' function data provided by user and secret (password) for vault.
    data = 'ansible'
    secret = 'ansible123'

    # Call the function to encrypt data.
    vault = do_vault(data, secret)

    # Call the function to decrypt data.
    data_decrypted = do_unvault(vault, secret)

    # Verify whether the data encrypted is same as the data decrypted.
    assert data == data_decrypted

    # Verify whether the data encrypted is different from the data provided.
    assert data != vault

    # Verify whether the data is encrypted without salt and with salt and

# Generated at 2022-06-22 14:15:15.554853
# Unit test for function do_vault
def test_do_vault():
    test_data = 'test_data'
    test_secret = 'test_secret'
    test_salt = 'test_salt'
    test_vaultid = 'test_vaultid'
    test_wrap_object = False


# Generated at 2022-06-22 14:15:26.961999
# Unit test for function do_vault
def test_do_vault():

    # Setup test parameters
    secret = 'password'
    secret_utf_8 = 'utf_8'
    secret_ascii = 'ascii'
    secret_empty = ''
    data = 'This is a secret!'
    data_utf_8 = u'utf_8明確'
    data_ascii = 'ascii'
    data_empty = ''

    # Setup jinja2 filters
    filters = FilterModule()
    salt = 'f202001232e19d52'
    test_filter_dict = filters.filters()

    # Test secret with unicode str

# Generated at 2022-06-22 14:15:30.827340
# Unit test for function do_vault
def test_do_vault():
    data = "data"
    secret = "secret"

    assert do_vault(data, secret) == do_vault(data, secret)



# Generated at 2022-06-22 14:15:40.985663
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:51.082117
# Unit test for function do_vault
def test_do_vault():

    data = 'hello world'
    secret = 'password'
    vaultid = 'test'
    salt = 'abcdefghijklmnopqrstuvwxyz'
    _salt = 'abcdefghijklmnopqrstuvwxyz'
    wrap_object = True

    # Check that we get the expected encrypted data

# Generated at 2022-06-22 14:15:54.167948
# Unit test for function do_vault
def test_do_vault():
    secret = 'my_secret'
    data = 'this is secret data'
    vault = do_vault(data, secret)
    assert vault

# Generated at 2022-06-22 14:16:04.353233
# Unit test for function do_unvault
def test_do_unvault():

    vaulted = '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;filter_default\n          3662393837383436653433393932356333633035656633613332636665366636664393930353630\n          393336393437643437333235353039643033666435303464393463393833363061626263623165\n          31336464353361613432666564\n          '

    secret = 'test_secret_key'

    unvaulted = do_unvault(vaulted, secret)
    assert unvaulted == 'test_password'

# unit test for function do_vault

# Generated at 2022-06-22 14:16:09.274377
# Unit test for function do_vault
def test_do_vault():
    secret = "super_secret_key"
    data = "This is some secret data"
    vault = do_vault(data, secret)
    assert isinstance(vault, str)
    assert vault != data
    assert is_encrypted(vault)


# Generated at 2022-06-22 14:16:16.404521
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    input_str = "abc"
    wrapped_str = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;test_default\n          6435396438343530343734616465363631303263613661323561613236646637353062626231633666\n          3964323736383336623338306432306133343733316232633063376438326363303863323439623536\n          6466350a"

# Generated at 2022-06-22 14:16:22.975095
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n356437613664633536663464396633363439353366613736343931396565346634313339303531\n38386636626435663365666163303631333132333835396264353035383063306566663033396637\n66393730626534636332303763323862303264376230626337316635383738653738356633386566\n35346364313235346365626538633033613864633830336539336138646638326461663138333865\n66316363366334\n", "1234567890").startswith("{'target_host':")




# Generated at 2022-06-22 14:16:37.017461
# Unit test for function do_unvault
def test_do_unvault():
    try:
        secret = "difficult enough"
        vault = '$ANSIBLE_VAULT;1.2;AES256;default\n6665373466376564356431393839326262636134643265653135323331386132616262353466\n3934373835653730343532303936313931633362313761396364653262623334356234633466\n393233636365386539333563383363346564\n'
        assert do_unvault(vault, secret, 'default') == 'hello'
    except Exception as e:
        raise AnsibleFilterError("Unable to decrypt: %s" % to_native(e), orig_exc=e)

# Generated at 2022-06-22 14:16:47.712026
# Unit test for function do_unvault

# Generated at 2022-06-22 14:16:57.093390
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'testsecret'
    test_salt = 'testsalt'
    test_vaultid = 'testid'

    test_data = do_vault('testdata', test_secret, test_salt, test_vaultid, wrap_object=False)
    test_data = to_native(test_data)
    print(test_data)
    assert test_data[:10] == '$ANSIBLE_VAULT;1.1;AES256'

    test_data = do_vault('testdata', test_secret, test_salt, test_vaultid, wrap_object=True)
    assert isinstance(test_data, AnsibleVaultEncryptedUnicode)
    assert test_data.vault.secrets[test_vaultid] == test_secret

# Generated at 2022-06-22 14:17:10.136337
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'qwerty123'
    vaultid = 'test_id'

# Generated at 2022-06-22 14:17:21.856348
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:26.129290
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) is None
    assert not do_unvault(None, "secret")
    assert not do_unvault("", "secret")
    assert do_unvault(do_vault("text", "secret"), "secret") == "text"



# Generated at 2022-06-22 14:17:37.904110
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()

    # Test for expected value of vaulting
    secret = "KjNHI3q4q1VswN+2uHsb"
    data = "This is a test"
    vault = "AES256"
    salt = "123456789012345678901234567890ab"


# Generated at 2022-06-22 14:17:49.895775
# Unit test for function do_vault
def test_do_vault():
    import pytest
    from ansible.module_utils.six import text_type

    vault_data = u"""$ANSIBLE_VAULT;1.1;AES256
835a7a3cace93c95f2cfa8aef087f29e00daf9b0f0f8c6ce2ced6c669e0e1d63366ed6b70f9c
d7a782373fbc849bded2c731376bd611bdce6f8b6c59e71d118d9e69791e8cb51947ae40c14e
34ae05dbc8f7bfaaafe5b5c5bce2e
"""

    # test that input string is returned as is if secret is not provided
    data = u'hello'

# Generated at 2022-06-22 14:17:59.239183
# Unit test for function do_unvault
def test_do_unvault():
    # case 1: a string input
    secret = 'secret'

# Generated at 2022-06-22 14:18:02.034186
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'ansible'
    vault1 = do_vault(data, secret)
    vault2 = do_vault(data, secret)
    assert vault1 != data
    assert vault1 == vault2


# Generated at 2022-06-22 14:18:16.225258
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, 'ansible') == ''

    data = 'some_password'
    secret = 'ansible'
    vault = do_vault(data, secret)
    assert to_native(VaultLib().decrypt(vault)) == data

    vault = do_vault(data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert to_native(vault.vault.decrypt(vault)) == data

    data = ''
    secret = ''
    vault = do_vault(data, secret)
    assert to_native(VaultLib().decrypt(vault)) == data

    data = ' '
    secret = 'ansible'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 14:18:28.778827
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:39.405825
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"

# Generated at 2022-06-22 14:18:44.730480
# Unit test for function do_unvault
def test_do_unvault():
    data = "Secret text"
    secret = "mysecret"
    vaultid = "test-filter-default"
    vault = do_vault(data, secret, vaultid=vaultid)
    assert vault is not None
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 14:18:55.514820
# Unit test for function do_unvault
def test_do_unvault():
    unvault_data = do_unvault('$ANSIBLE_VAULT;1.1;ECHO\n35306436393635326435386330316235303935366433353362343137633130\n3536663536386639353765353063653365343937623261633862643130333965\n3566303436626339633932333362366534333730353732313162353337373930\n66313232626337313430323431303339653201\n', 'test_secret')
    assert unvault_data == 'test_data'

# Generated at 2022-06-22 14:19:07.492406
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n612531396132653936343762626561646632616237373938356634353736343337373961336466\n353037316136326264393233333533613939363736636666336133626465656636373630653530\n623938313436346161613939303234633166623262633034366334623065313761346265386565\n3464636235393565336366323336626162633961\n', 'secret', 'filter_default') == 'regular secret stuff'

# Generated at 2022-06-22 14:19:11.016957
# Unit test for function do_unvault
def test_do_unvault():
    data = u'test-data'
    secret = u'secret'
    vaultid = u'filter_default'
    assert do_unvault(do_vault(data, secret, vaultid), secret, vaultid) == data

# Generated at 2022-06-22 14:19:17.019514
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('password', 'secret', wrap_object=True).startswith('$ANSIBLE_VAULT')
    assert do_vault('password', 'secret', wrap_object=False).startswith('$ANSIBLE_VAULT')
    assert do_vault('password', 'secret', wrap_object=False).endswith('\n')


# Generated at 2022-06-22 14:19:22.477799
# Unit test for function do_vault
def test_do_vault():
    secret = "some_salt"
    data = "some_data"
    vault = do_vault(data, secret, wrap_object=False)
    assert(vault == AnsibleVaultEncryptedUnicode(to_bytes(vault)).data)


# Generated at 2022-06-22 14:19:34.326997
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Template
    from yaml import load

    import textwrap

    # Create secret for vault
    secret = '@AnsibleVault02!#'

    # Some strings to encrypt
    plain_1 = "plain string to encrypt"
    plain_2 = textwrap.dedent("""
            plain string
            also with new lines
        """).lstrip()

    # Create templates to test with
    tpl_1 = Template('{{ "{0}"|vault }}'.format(plain_1))
    tpl_2 = Template('{{ "{0}"|vault }}'.format(plain_2))

    tpl_3 = Template('{{ "{0}"|vault(secret="{1}") }}'.format(plain_1, secret))

# Generated at 2022-06-22 14:19:48.348620
# Unit test for function do_vault
def test_do_vault():
    secret = "123456789"
    vault_id = "test_do_vault"
    salt = "12345678910"

    ret_value = do_vault("", secret, salt=salt, vaultid=vault_id)
    assert isinstance(ret_value, string_types)
    assert ret_value.startswith("$ANSIBLE_VAULT;1.2;AES256;%s;") % vault_id
    assert ret_value.endswith(";")

    ret_value = do_vault("mytext", secret, salt=salt, vaultid=vault_id)
    assert isinstance(ret_value, string_types)
    assert ret_value.startswith("$ANSIBLE_VAULT;1.2;AES256;%s;") % vault_id

# Generated at 2022-06-22 14:20:01.160704
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256', 'mysecret') == ''
    assert do_unvault(b'$ANSIBLE_VAULT;1.1;AES256', 'mysecret') == ''
    assert do_unvault(b'$ANSIBLE_VAULT;1.1;AES256\n3161356131623831376132326338653161663762356237633966666562356136\n3564343535613837346533653836383532646639653566343330663663623766', 'mysecret') == ''

# Generated at 2022-06-22 14:20:13.920305
# Unit test for function do_unvault
def test_do_unvault():
    test_vault = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n373537343161356131633165343965353038373631393237330a386638646262333965623139373638623430293763323162626134\n30356531636230663137306631346235370a653962313165343637623231653036383062363064343033623435376339623433623066\n646630346433663739653232633164613031303865")
    data = 'test'

# Generated at 2022-06-22 14:20:17.522924
# Unit test for function do_vault
def test_do_vault():
    secret = "1231"
    data = "Hello"
    vault_data = do_vault(data, secret)
    assert vault_data is not None
    assert is_encrypted(vault_data) == True



# Generated at 2022-06-22 14:20:29.823234
# Unit test for function do_unvault
def test_do_unvault():
    import pytest

    with pytest.raises(AnsibleFilterTypeError, match="Secret passed is required to be as string, instead we got: <type 'bool'"):
        do_unvault(False, True)

    with pytest.raises(AnsibleFilterTypeError, match="Vault should be in the form of a string, instead we got: <type 'bool'"):
        do_unvault(True, 'secret')


# Generated at 2022-06-22 14:20:41.005532
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = 'test_salt'
    vaultid = 'test_vaultid'
    data = 'test_data'
    ansible_vault_converted_data = u'$ANSIBLE_VAULT;1.1;AES256\n613564356537616439323930383537323033326332346338376161386165373436393638343337\n653033613461396166663263366234623238313536313565366639643065326337636132383039\n6566356433663662336538302129\n'
    wrap_object = False

# Generated at 2022-06-22 14:20:51.066225
# Unit test for function do_unvault
def test_do_unvault():
    # Do not need to load filter_plugins to test
    import ansible.constants as C
    C.DEFAULT_FILTER_PLUGINS = ","
    C.DEFAULT_JINJA2_NATIVE = False
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib

    plaintext = 'This is an example of unvaulting data'
    secret = VaultSecret('secret')
    vl = VaultLib([('test', secret)])
    ciphertext = vl.encrypt(plaintext)
    unvaulted = do_unvault(ciphertext, 'secret', 'test')
    assert plaintext == unvaulted



# Generated at 2022-06-22 14:21:02.869856
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) is None

# Generated at 2022-06-22 14:21:05.955419
# Unit test for function do_vault
def test_do_vault():
    secret = 'dummy'
    data = 'dummy'
    result = do_vault(data, secret)
    assert(is_encrypted(result) == True)



# Generated at 2022-06-22 14:21:18.723946
# Unit test for function do_vault
def test_do_vault():
    import os
    import shutil
    import tempfile
    import yaml

    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    fd, path = tempfile.mkstemp()
    v = VaultEditor(path)
    secret = v.create_vault_string('secrets').encode('utf-8')

    from jinja2 import Template
    from ansible.parsing.yaml.dumper import AnsibleDumper
    vault = Template('{{ "hello world" | vault(secret) }}').render(secret=secret)
    data = yaml.load(vault, Loader=yaml.SafeLoader)
    assert isinstance(data, AnsibleVaultEncryptedUnicode)
    assert data

# Generated at 2022-06-22 14:21:33.400872
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultSecret

    for secret in ['ansible', to_bytes('ansible')]:
        for data in ['test', '1234', to_bytes('1234')]:
            for vaultid in ['', 'filter_default', to_bytes('filter_default')]:
                vault = do_vault(data, secret, vaultid='filter_default', wrap_object=False)
                assert isinstance(vault, string_types)
                assert is_encrypted(vault)

                decrypted = do_unvault(vault, secret, vaultid=vaultid)
                assert isinstance(decrypted, string_types)
                assert decrypted == data

                vs

# Generated at 2022-06-22 14:21:37.019040
# Unit test for function do_vault
def test_do_vault():

    with open('/opt/ansible/docs/source/_docs_filter_plugins_do_vault.yml', 'r') as test_data:
        pass

# Generated at 2022-06-22 14:21:49.541700
# Unit test for function do_vault
def test_do_vault():
    secret = 'my0secret1secret2secret3secret4secret5secret6secret7secret8secret9'
    data = 'hello'
    result = do_vault(data, secret)
    print(result)