

# Generated at 2022-06-22 14:11:58.013909
# Unit test for function do_unvault
def test_do_unvault():
    import sys
    import os

    sys.path.insert(1, os.path.join(sys.path[0], '..'))

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    class TestUnvault(unittest.TestCase):
        def setUp(self):
            self.filter = FilterModule()
            self.mock_vault_secret = VaultSecret(to_bytes('test_secret'))
            self.mock_vault_lib = VaultLib()

        def tearDown(self):
            pass


# Generated at 2022-06-22 14:12:11.055117
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:22.126358
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultEditor
    import os
    import random
    import tempfile
    import string

    secret = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(32))
    vaultid = 'vault_test'

    _, fname = tempfile.mkstemp()
    VaultEditor(fname, secret, vaultid)
    data = os.urandom(32)
    ve = VaultEditor(fname, secret, vaultid)

    decrypted_data = do_unvault(ve.encrypt(data), secret, vaultid)

    assert decrypted_data == data

# Generated at 2022-06-22 14:12:34.036440
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    vaultid = 'filter_default'

    # Test string
    data = 'test123'
    vault_data = do_vault(data, secret, vaultid=vaultid)
    unvault_data = do_unvault(vault_data, secret, vaultid=vaultid)
    assert data == unvault_data

    # Test empty string
    data = ''
    vault_data = do_vault(data, secret, vaultid=vaultid)
    unvault_data = do_unvault(vault_data, secret, vaultid=vaultid)
    assert data == unvault_data

    # Test boolean
    data = False
    vault_data = do_vault(data, secret, vaultid=vaultid)
    unvault_

# Generated at 2022-06-22 14:12:47.129443
# Unit test for function do_unvault
def test_do_unvault():
    plain_text = 'This is a plain text'

# Generated at 2022-06-22 14:12:53.771752
# Unit test for function do_vault
def test_do_vault():
    data = 'test_value'
    secret = 'secret_value'
    salt = 'salt_value'
    vaultid = 'filter_default'
    wrap_object = False

    test_data = do_vault(data, secret, salt, vaultid, wrap_object)

    assert test_data is not None
    assert test_data



# Generated at 2022-06-22 14:13:02.951222
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:04.464498
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'password')


# Generated at 2022-06-22 14:13:09.662668
# Unit test for function do_unvault
def test_do_unvault():
    test_vault = VaultSecret('ansible')
    test_vault.vault_id = 'filter_default'

    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(TestUnvault)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-22 14:13:14.718639
# Unit test for function do_vault
def test_do_vault():
    sec = "foo"
    value = "test"
    result = do_vault(value, sec)
    assert isinstance(result, string_types)
    assert isinstance(result, str)
    assert "ANSIBLE_VAULT;1.1" in result


# Generated at 2022-06-22 14:13:23.680531
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    vaultid = 'test_vaultid'

# Generated at 2022-06-22 14:13:32.979841
# Unit test for function do_vault

# Generated at 2022-06-22 14:13:37.397328
# Unit test for function do_vault
def test_do_vault():
    secret = 'this is not a secret'
    string = 'this is not an encrypted string'

    vault = do_vault(string, secret)
    data = do_unvault(vault, secret)

    assert string == data


# Generated at 2022-06-22 14:13:47.881411
# Unit test for function do_unvault
def test_do_unvault():
    # Ref:  https://github.com/ansible/ansible/issues/75401
    # Ref:  https://docs.python.org/3/library/unittest.html
    import unittest
    import random
    import re

    class TestVaultFilterModule(unittest.TestCase):

        def test_do_unvault_empty_secret_param(self):
            secret = ''

# Generated at 2022-06-22 14:13:51.748403
# Unit test for function do_unvault
def test_do_unvault():
    data = "abc123_test"
    secret = "password"
    vaultid = "test_filter"
    vault = do_vault(data, secret, vaultid=vaultid)
    decrypted_data = do_unvault(vault, secret, vaultid=vaultid)
    assert data == decrypted_data

# Generated at 2022-06-22 14:13:58.984310
# Unit test for function do_vault
def test_do_vault():
    print("Testing do_vault")
    import jinja2
    test_vars = {
        'secret': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz0123456789',
        'data': 'This is a test data string',
        'vaultid': 'test_do_vault'
    }
    test_template = jinja2.Template('''
{{ data | vault(secret, salt, vaultid) }}
''')
    result = test_template.render(test_vars)
    assert result
    result_data = do_unvault(result, test_vars['secret'], 'test_do_vault')
    assert result_data == test_vars['data']
    print

# Generated at 2022-06-22 14:13:59.932382
# Unit test for function do_unvault
def test_do_unvault():
    pass


# Generated at 2022-06-22 14:14:08.033198
# Unit test for function do_unvault
def test_do_unvault():

    assert (do_unvault("$ANSIBLE_VAULT;1.2;AES256;ansible-test\n61626262333832383237646662303966353964376132656466633064326463626638353462636330\n343436663232303539333539343833356434303234643831343565\n", "ansible-test") == "abcd12345")



# Generated at 2022-06-22 14:14:16.082054
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:27.796960
# Unit test for function do_unvault
def test_do_unvault():
     # the mock of vault secret is KEY, which is 16 bytes
    MockVaultSecret = VaultSecret("KEYKEYS")
    MockVaultLib = VaultLib([("filter_default", MockVaultSecret)])
    test_source = VaultSecret("key")
    encrypted_content = MockVaultLib.encrypt("foo", test_source, "filter_default")
    decrypted_content = do_unvault(encrypted_content, "KEYKEYS")
    assert decrypted_content == "foo"
    assert ansible.utils.display.Display.display("Unable to decrypt: %s" % decrypted_content, color=None, stderr=True, screen_only=False, log_only=False) == "Unable to decrypt: foo"
    # test when vault is a AnsibleVaultEncryptedUnicode, decrypt should be performed

# Generated at 2022-06-22 14:14:39.762455
# Unit test for function do_vault

# Generated at 2022-06-22 14:14:52.349526
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY2
    if PY2:
        from ansible.parsing.vault import _get_decoded_file, _get_encoded_file
        import tempfile

        secret = 'test_secret_password'
        data = 'test_data'
        vaultid = 'filter_default'
        salt = None
        wrap_object = False
        vault = do_vault(data, secret, salt, vaultid, wrap_object)

        assert is_encrypted(vault)

        # test with salt
        salt = 'test_salt'
        vault = do_vault(data, secret, salt, vaultid, wrap_object)

        assert is_encrypted(vault)

        # test with wrap_object
        wrap_object = True
        salt = None
        vault

# Generated at 2022-06-22 14:15:01.587616
# Unit test for function do_vault
def test_do_vault():
    data = b'a string of data to encrypt'
    secret = b'a secret to use'
    salt = None  # salt should be empty string
    vaultid = 'test_id'
    wrap_object = False


# Generated at 2022-06-22 14:15:09.826706
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vault = '$ANSIBLE_VAULT;1.2;AES256;salt\n3339613765343735376339323030616664633437313030353733663835343963333339313339\n6635363232316338363563613033613039313165626663363335663939656136313339663836'
    assert do_vault(data, secret, salt) == vault


# Generated at 2022-06-22 14:15:15.335982
# Unit test for function do_vault
def test_do_vault():
    display.debug("Checking for vault value")

    data = "abc"
    secret = "secret"
    vaultid = "test_vault"
    salt = "1234567890"
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    assert vault



# Generated at 2022-06-22 14:15:25.927629
# Unit test for function do_vault

# Generated at 2022-06-22 14:15:38.733714
# Unit test for function do_vault
def test_do_vault():
    data = 'my secret string'
    secret = 'super secret'
    salt = 'X'*16
    vaultid = 'default'

# Generated at 2022-06-22 14:15:50.906289
# Unit test for function do_unvault
def test_do_unvault():
    '''
    Function: test_do_unvault: tests jinja2 unvault filter

    Input: a vault secret string and a vaulted string

    Output: a unvaulted string

    Tests:
        Good:
            unvault a string encrypt with a valid vault secret string
        Bad:
            unvault a string not encrypt with a valid vault secret string
            unvault a string encrypt with a valid vault secret string using
                an invalid vault secret string
            unvault a non-string object
            unvault a string object not encrypt with a valid vault secret string
                using a non vault secret string object
    '''
    # pylint: disable=import-outside-toplevel

    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    import os

    vault_secret = to_

# Generated at 2022-06-22 14:15:55.237132
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;8.yml;0v7g9o9l0t7b8t0h8t7b8t0h", "password") == "password"



# Generated at 2022-06-22 14:16:05.456975
# Unit test for function do_vault
def test_do_vault():
    data1 = 'test_do_vault'
    secret1 = 'mysupers3cret'
    wrapped1 = False

# Generated at 2022-06-22 14:16:15.301800
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "junk"

# Generated at 2022-06-22 14:16:27.707845
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'test'
    test_vault = '$ANSIBLE_VAULT;1.2;AES256;test\n343765643065373337356361383936666664363533643534663739633731383865376435323537\n373439623931643166396664346665333866393663356361626333373265636333376461333065\n313734666536666536356633393331323234636230333834303930303166333638356265616366\n35373466313037343664353762396336373034383734393861333666373762633034656138\n'

# Generated at 2022-06-22 14:16:40.021639
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'

# Generated at 2022-06-22 14:16:51.803885
# Unit test for function do_unvault
def test_do_unvault():
    vl = vault_lib(b'test')

# Generated at 2022-06-22 14:17:04.908184
# Unit test for function do_vault
def test_do_vault():
    data = 'ansible'
    secret = 'encryptedsecret'
    salt = 'salt'
    vaultid = 'test'
    wrap_object = False
    expected_vault = '$ANSIBLE_VAULT;1.2;AES256;test;;6aa2c6b8cd6b9f6b5c5b5fc5d5c5c5af5b5c5c5c5a5c5c5c5c5c5c5c5c5d5a5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c23c'

    assert do_vault(data, secret, salt, vaultid, wrap_object) == expected_vault



# Generated at 2022-06-22 14:17:18.001777
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:25.218628
# Unit test for function do_vault
def test_do_vault():
    import ansible.parsing.yaml.objects
    from ansible.module_utils.six import u
    data = 'Hello world!'
    secret = 'secret'
    salt = 'salt'
    vaultid = 'vaultid'
    ret = do_vault(data, secret, salt, vaultid)
    assert isinstance(ret, ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode)
    assert isinstance(ret.data, u)
    assert ret.data == data


# Generated at 2022-06-22 14:17:37.023689
# Unit test for function do_vault
def test_do_vault():
    secret = 'test_secret'
    data = 'test_data'
    data_b = b'test_data_b'
    salt = 'test_salt'
    # json_object = '{"test_key": "test_value"}'
    vault = do_vault(data, secret, salt)
    assert vault.startswith('$ANSIBLE_VAULT;')
    assert vault != '$ANSIBLE_VAULT;'
    assert len(vault) > len('$ANSIBLE_VAULT;')
    assert to_native(do_unvault(vault, secret)) == data
    vault = do_vault(data_b, secret)
    assert vault.startswith('$ANSIBLE_VAULT;')
    assert vault != '$ANSIBLE_VAULT;'
    assert len(vault)

# Generated at 2022-06-22 14:17:49.631704
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mysecret"
    salt = "1234567890123456789012345"
    vault_id = "filter_default"
    x = do_vault(data, secret, salt, vault_id)

# Generated at 2022-06-22 14:18:00.711792
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    filters = f.filters()


# Generated at 2022-06-22 14:18:13.675096
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret)

    assert vault != data and vault is not None, "Test 1.1 Failed"

    vault = do_vault(data, 'invalid secret')
    assert vault == data and vault is not None, "Test 1.2 Failed"

    data = AnsibleVaultEncryptedUnicode(vault)
    vault = do_vault(data, secret, wrap_object=True)
    assert vault != data and vault is not None, "Test 1.3 Failed"



# Generated at 2022-06-22 14:18:21.753960
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n35306438343935613362316332396165323135613134333437383666353933316163326237616639\n37656639323963623732303937343361313433363566373733663664353731323038303939323862\n33343864396565643036623361333035643866363765303863363766333862326634396666613764\n3734626236613533353062333434343361303166653839653366636566\n'

# Generated at 2022-06-22 14:18:32.977136
# Unit test for function do_unvault
def test_do_unvault():

    try:
        do_unvault(1,'secret')
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError('do_unvault should not accept integer as vault parameter')

    try:
        do_unvault('vault','secret', 1)
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError('do_unvault should not accept integer as vaultid parameter')

    try:
        do_unvault('vault',1)
    except AnsibleFilterTypeError:
       pass
    else:
        raise AssertionError('do_unvault should not accept integer as secret parameter')

    try:
        do_unvault('vault','')
    except AnsibleFilterError:
        pass
    else:
        raise Ass

# Generated at 2022-06-22 14:18:42.117240
# Unit test for function do_vault

# Generated at 2022-06-22 14:18:54.420434
# Unit test for function do_vault
def test_do_vault():
    import os

    pass_fail = []


# Generated at 2022-06-22 14:19:04.867460
# Unit test for function do_vault
def test_do_vault():
    # Test that do_vault throws a type error if an invalid type is provided
    try:
        do_vault(1, 'secret', 'salt', 'vaultid')
        assert False
    except AnsibleFilterTypeError as e:
        pass

    # Test that do_vault throws a type error if an invalid secret is provided
    try:
        do_vault('data', 1, 'salt', 'vaultid')
        assert False
    except AnsibleFilterTypeError as e:
        pass

    # Test that do_vault throws a filter error if an invalid vaultid is passed
    try:
        do_vault('data', 'secret', 'salt', 'invalid_vaultid')
        assert False
    except AnsibleFilterError as e:
        pass

    # Test that do_vault throws a filter

# Generated at 2022-06-22 14:19:16.576516
# Unit test for function do_vault

# Generated at 2022-06-22 14:19:29.216110
# Unit test for function do_unvault
def test_do_unvault():

    import jinja2
    from jinja2 import Template
    import os
    import sys
    import tempfile
    import subprocess
    import pytest
    import json

    ansible_playbook_path = os.environ.get('ANSIBLE_PLAYBOOK_PATH', None)
    if not ansible_playbook_path:
        sys.stdout.write('ANSIBLE_PLAYBOOK_PATH environment variable must be set\n')
        sys.exit(1)

    # Test all supported vault formats

# Generated at 2022-06-22 14:19:41.394004
# Unit test for function do_vault
def test_do_vault():
    secret = 'A secret for the vault'
    salt = 'SALT'
    vaultid = 'new random vault ID'

    data = 'text to be encrypted'
    result = u'$ANSIBLE_VAULT;1.1;AES256\n3134343639643338366265363866643935663832353330333632646265626134363865623163633765\n6331323263356439353364343865643130623033626231636631316337613761336132376230653566\n3366323034376461613061626334326465323438623963653536333436336535326439336533633863\n'

# Generated at 2022-06-22 14:19:46.144144
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    def test_vault(m, data, secret, salt=None, vaultid='filter_default', wrap_object=False):
        l = locals()
        del l['m']
        return do_vault(**l)


# Generated at 2022-06-22 14:20:06.148107
# Unit test for function do_vault
def test_do_vault():
    import string
    import random
    import hashlib
    from copy import copy
    from jinja2.exceptions import UndefinedError

    # Test secret is undefined
    try:
        do_vault("foo", Undefined())
        assert False, "AnsibleFilterError was not raised"
    except AnsibleFilterError:
        pass

    # Test data is undefined
    try:
        do_vault(Undefined(), "foo")
        assert False, "AnsibleFilterError was not raised"
    except AnsibleFilterError:
        pass

    # Test secret is undefined
    try:
        do_vault("foo", Undefined())
        assert False, "AnsibleFilterError was not raised"
    except AnsibleFilterError:
        pass

    # Test data is not a string

# Generated at 2022-06-22 14:20:11.182270
# Unit test for function do_vault

# Generated at 2022-06-22 14:20:21.244510
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    expected_vault = '$ANSIBLE_VAULT;1.1;AES256;vault\r\n6138633938303365323939653565663936366635323839666232653665306462393464333438\r\n663362363531623738376633623835303439656430383533346137623338663136643936396261\r\n36323261663034656466\r\n'

    vault = do_vault('this is the data', secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert to_native(vault) == expected_vault
    assert to_native(vault.data) == 'this is the data'


# Generated at 2022-06-22 14:20:33.736996
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils import basic
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest


# Generated at 2022-06-22 14:20:44.517014
# Unit test for function do_vault
def test_do_vault():

    secret = 'secret'
    vault = do_vault('mystring', secret)
    assert len(vault) > 0, "Vault result is empty!"

    vault = do_vault(u'unicode', secret)
    assert len(vault) > 0, "Vault result is empty!"

    vault = do_vault(1, secret)
    assert vault == 1, "Vault result is not 1!"

    vault = do_vault(None, secret)
    assert vault == None, "Vault result is not None!"

    vault = do_vault({}, secret)
    assert vault == {}, "Vault result is not {}!"

    try:
        vault = do_vault([], secret)
    except Exception:
        assert True, "Vault result exception!"

# Generated at 2022-06-22 14:20:53.757035
# Unit test for function do_vault

# Generated at 2022-06-22 14:21:05.352957
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY2

    # Using string as password
    test_vault = do_vault('hello', 'secret')
    assert isinstance(test_vault, string_types)
    assert not isinstance(test_vault, AnsibleVaultEncryptedUnicode)

    # Using AnisbleVaultEncryptedUnicode as password

# Generated at 2022-06-22 14:21:18.160544
# Unit test for function do_vault
def test_do_vault():
    secret = 'hackathon172'
    data = 'password'

    res = do_vault(data, secret)
    expected_res = b'$ANSIBLE_VAULT;1.1;AES256\n32303135313631323731333531353136323232303538313765396531323035666536326239363035\n33323165623366623765616232343262633535636265343530386633653666393064663562333538\n6566363662333237386538356239333332393464356665303939353231366234633431655a346564\n63626637623864393366646534366430\n'
    assert res == expected_res


# Generated at 2022-06-22 14:21:28.433527
# Unit test for function do_vault
def test_do_vault():
    r1 = do_vault('secret', 'secret', wrap_object=False)
    assert isinstance(r1, str)
    assert not isinstance(r1, Undefined)

    r2 = do_vault('secret', 'secret', wrap_object=True)
    assert isinstance(r2, AnsibleVaultEncryptedUnicode)
    assert not isinstance(r2, Undefined)

    try:
        do_vault(None, 'secret')
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "AnsibleFilterError not raised"

# Unit tests for function do_unvault

# Generated at 2022-06-22 14:21:41.622758
# Unit test for function do_vault
def test_do_vault():
    # data: 'cloud'
    # secret: 'ansible'
    # salt: None
    # vaultid: 'filter_default'
    # wrap_object: False
    data = 'cloud'
    secret = 'ansible'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    assert do_vault(data, secret, salt, vaultid, wrap_object) == '$ANSIBLE_VAULT;1.1;AES256\n35393966373566373330363437393437353638363038613639353066653035363265353930623730\n38353834303832333139626162323137393536633231626538660a31383565666433356566356529\n'


