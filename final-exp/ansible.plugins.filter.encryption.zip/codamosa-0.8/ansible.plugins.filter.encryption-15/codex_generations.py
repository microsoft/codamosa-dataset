

# Generated at 2022-06-22 14:11:57.393197
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:05.967941
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:17.618430
# Unit test for function do_vault
def test_do_vault():
    '''
    This function test do_vault function of class FilterModule
    '''
    # Arrange
    data = 'this is vault data'
    secret = 'this is secret'
    salt = 'this is salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 14:12:29.686754
# Unit test for function do_vault

# Generated at 2022-06-22 14:12:41.058266
# Unit test for function do_unvault

# Generated at 2022-06-22 14:12:51.724907
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault("$ANSIBLE_VAULT;1.2;AES256;ansible_default\n396364376332386331393735326661356138313535333065373833346339323965323766623866\n636532313439353330663331663165393262633761613733636365646236383033663536343536\n396638646334313163386264636330356234666166633566323833313030666565343266393634\n\n", "ansible") == "ansible")

# Generated at 2022-06-22 14:12:54.997771
# Unit test for function do_vault
def test_do_vault():
    # test data
    data = "test_do_vault"
    secret = "test_do_vault"
    salt = "test_do_vault"
    vaultid = "test_do_vault"
    wrap_object = True

    # AnsibleVaultEncryptedUnicode should be returned
    assert type(do_vault(data, secret, salt, vaultid, wrap_object)) is AnsibleVaultEncryptedUnicode


# Generated at 2022-06-22 14:13:00.651890
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'this is a test'
    test_data = 'Hello World!'
    test_vaultid = 'filter_default'
    test_vault = do_vault(test_data, test_secret, vaultid=test_vaultid)

    data = do_unvault(test_vault, test_secret, vaultid=test_vaultid)
    assert data == test_data

# Generated at 2022-06-22 14:13:13.054360
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:20.430507
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;filter_default\n636333316637333139376234633765323561636663323963353164313765633532653164313036633\n3464363133376162623036346332396165313431653235316562653366653430633535616533653338\n31363564326236623735613739383339', "secret") == "hello world"


# Generated at 2022-06-22 14:13:29.114179
# Unit test for function do_vault
def test_do_vault():
    filter_out = do_vault("My data","My secret","My salt","My vaultid","My wrap_object")
    assert filter_out == "AES256:7VyEv+aFc7YMBYg4u4xVZ2zmHGi6MQmF:TIJr1TbQH0kcX9JlaC+feI7ZDx1BYsHs"


# Generated at 2022-06-22 14:13:39.127938
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault('foo', '_') == '$ANSIBLE_VAULT;1.1;AES256\n35393937363064333538343562333434633164326235383737653165343635386337666239636133\n62646536343234663839646631620a33326266653937386139303761383239633064303361306338\n66346239623032363366663837386439353837643036316564383534626261613932613965643738\n6136\n')



# Generated at 2022-06-22 14:13:42.913805
# Unit test for function do_unvault

# Generated at 2022-06-22 14:13:51.268512
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('test string', 'test secret')

# Generated at 2022-06-22 14:14:02.464095
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'HASHED_PASSWORD'
    vaultid = 'test_id'

    # vaultid is not in vault_id_list
    try:
        do_unvault('$ANSIBLE_VAULT;9.9;AES256;test_id;3623889822389842134898712349877293487129834719823741298374', secret)
    except AnsibleFilterError as e:
        assert "Vault id not found in vault_id_list" in str(e)
    # vaultid is in vault_id_list
    do_unvault('$ANSIBLE_VAULT;9.9;AES256;test_id;3623889822389842134898712349877293487129834719823741298374', secret, vaultid)

# Generated at 2022-06-22 14:14:13.459675
# Unit test for function do_unvault

# Generated at 2022-06-22 14:14:26.538813
# Unit test for function do_vault
def test_do_vault():
    secret = "ansible_filter_unit_test_secret"
    data = "ansible_filter_unit_test_data"
    salt = "ansible_filter_unit_test_salt"
    vaultid = "ansible_filter_unit_test_vaultid"
    display.verbosity = 0

# Generated at 2022-06-22 14:14:36.576085
# Unit test for function do_vault
def test_do_vault():
    # unit test for string
    assert do_vault(1, 'secret') == ''
    assert do_vault('secret', 'secret') == ''
    assert do_vault('secret', 'secret', salt=None, vaultid='filter_default', wrap_object=False)

    # unit test for secret
    assert do_vault('secret', 1) == ''
    assert do_vault('secret', 'secret') == ''

    # unit test for salt
    assert do_vault('secret', 'secret', salt='secret', vaultid='filter_default', wrap_object=False)

    # unit test for vaultid
    assert do_vault('secret', 'secret', salt=None, vaultid=1, wrap_object=False) == ''

# Generated at 2022-06-22 14:14:44.317578
# Unit test for function do_vault
def test_do_vault():
    secret = '8952e8e2-7ece-48f9-9196-b75aebd7a6fa'

# Generated at 2022-06-22 14:14:56.120072
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:02.206477
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault("$ANSIBLE_VAULT;9.9;AES256;foo\nbar", "foo")
    assert result == "bar\n"


# Generated at 2022-06-22 14:15:12.758436
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('data', 'secret') == '$ANSIBLE_VAULT;1.1;AES256;ansible\n38353036363334326630313862623636333663656662366562656531653939653063356333646138613\n303536653638373930356463376236663735636162353937353133666232353633353934643330336435\n6437356633636365616164356636643836336465343964343533653565356439\n'

# Generated at 2022-06-22 14:15:24.040554
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:26.402963
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'test'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data


# Generated at 2022-06-22 14:15:38.977242
# Unit test for function do_unvault

# Generated at 2022-06-22 14:15:51.194077
# Unit test for function do_vault
def test_do_vault():
    secret = '12345678beef'
    data = 'ansible'

# Generated at 2022-06-22 14:16:02.890438
# Unit test for function do_unvault
def test_do_unvault():
    import unittest

    from ansible.module_utils._text import to_bytes, to_text

    class TestVaultJinjaFilter(unittest.TestCase):

        def setUp(self):
            self.filter = FilterModule()


# Generated at 2022-06-22 14:16:10.257553
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    salt = ""
    vaultid = "unit_test"
    wrap_object = True

    data = "secret_data"
    actual_vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 14:16:15.889995
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'DEADBEEF'
    vault_id = 'test'
    data = 'test string'

    x = do_vault(data, secret, vaultid=vault_id)
    assert do_unvault(x, secret, vault_id) == 'test string'

# Generated at 2022-06-22 14:16:28.040017
# Unit test for function do_vault
def test_do_vault():
    data = 'abcdef'
    secret = 'secret'

# Generated at 2022-06-22 14:16:35.316096
# Unit test for function do_vault

# Generated at 2022-06-22 14:16:37.998127
# Unit test for function do_vault
def test_do_vault():

    testdata = 'https://docs.ansible.com'
    testsecret = 'testsecret'
    testsalt = 'testsalt'

    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(testdata, testsecret, testsalt)



# Generated at 2022-06-22 14:16:42.132348
# Unit test for function do_vault
def test_do_vault():
    # Test data, may be updated based on user input if required
    # Test data for function do_vault
    data = 'data'
    secret = 'secret'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    # Unit test for function do_vault
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode) == True


# Generated at 2022-06-22 14:16:54.743872
# Unit test for function do_unvault

# Generated at 2022-06-22 14:17:07.739620
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-22 14:17:20.328330
# Unit test for function do_vault
def test_do_vault():

    # Test for valid input
    test_input = "5"

# Generated at 2022-06-22 14:17:25.089227
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    s = 'the secret'
    d = 'the data to be encrypted'
    v = do_vault(d, s)
    assert type(v) == AnsibleVaultEncryptedUnicode
    assert v.data == d


# Generated at 2022-06-22 14:17:37.022744
# Unit test for function do_unvault
def test_do_unvault():
    obj = FilterModule()
    assert obj.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;vagrant\n34396639633462343163383136643661313964336634643536376133623266386638353034326231\n39343662393565656132656565383536343665323962323230633164323235373437303335663435\n36333737633063353633373566633734363565303334623562303539306638353834336430336134\n36\n', 'vagrant') == 'vagrant'

# Generated at 2022-06-22 14:17:47.395507
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault('$ANSIBLE_VAULT;1.2;AES256;filter_default\n3534326462333138613162336539616133356639616236333665366661643862366333633532630a3062343132353330396430386635343366343135316536666232316365316133313137643362330a653134313533623536333566386438363431666566666135656334626566326633306635383438\n', 'password')
    assert result == 'bar'

# Generated at 2022-06-22 14:17:57.365669
# Unit test for function do_vault
def test_do_vault():
    def do_test(secret, data, salt=None, vaultid='filter_default', wrap_object=False):
        expected = b'$ANSIBLE_VAULT;1.1;AES256\n63323934336630363663613139346233633462396661656566303338663865613639613532336238\n65383336333565653935636164383530663834653961303066363561333336393934303365303532\n61643630353236623335626133363638373638633333316662356333653830323039623737313038\n336563666261613931376136613963313564353266326355\n'

# Generated at 2022-06-22 14:18:08.819183
# Unit test for function do_vault
def test_do_vault():
    fake_secret = 'ANSIBLE'
    fake_salt = 'salt'
    fake_data = 'hello world'
    expected_output = '$ANSIBLE$v1$salt$EcpxHTRx6Uv4P4o0hKfs+w==$60uQKr8r7ZCEX9Z5V5FxzJBf8g='

    assert do_vault(fake_data, fake_secret, fake_salt) == expected_output


# Generated at 2022-06-22 14:18:18.148453
# Unit test for function do_vault
def test_do_vault():
    # Testing if it throws a AnsibleFilterTypeError when data is not string.
    failed = False
    data = 123
    secret = "mysecret"

    try:
        do_vault(data, secret)
    except AnsibleFilterTypeError as e:
        failed = True
        assert e.message == "Can only vault strings, instead we got: <type 'int'>"

    if not failed:
        raise AssertionError("Filter do_vault did not throw AnsibleFilterTypeError when data is not a string.")

    # Testing if it throws a AnsibleFilterTypeError when secret is not string.
    failed = False
    data = "mydata"
    secret = 123

    try:
        do_vault(data, secret)
    except AnsibleFilterTypeError as e:
        failed = True

# Generated at 2022-06-22 14:18:29.858341
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:39.835278
# Unit test for function do_unvault
def test_do_unvault():
    import base64

# Generated at 2022-06-22 14:18:52.001998
# Unit test for function do_unvault

# Generated at 2022-06-22 14:18:59.644884
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = "notagoodpassword"
    plaintext = "a secret"
    vault = do_vault(plaintext, secret)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    data = do_unvault(vault, secret)
    assert data == plaintext


# Generated at 2022-06-22 14:19:08.468137
# Unit test for function do_unvault
def test_do_unvault():
    """
    do_unvault() takes encrypted data and a password, and returns the
    decrypted data.  We use a constant string for the encrypted data
    so that this test does not fail if the encryption algorithm
    changes.

    The expected output for this particular encrypted string is also
    included in this function.
    """

    from ansible.module_utils.six import PY3
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    if not PY3:
        raise Exception("This test is only applicable on Python 3")


# Generated at 2022-06-22 14:19:10.873022
# Unit test for function do_vault
def test_do_vault():
    # mock input secret
    secret = 'password'
    # mock input data
    data = 'somedata'

    assert(do_vault(data, secret))



# Generated at 2022-06-22 14:19:20.988087
# Unit test for function do_vault
def test_do_vault():
    from ansible.errors import AnsibleFilterError
    # Test successful vault encryption
    test_string = 'This is a test string'
    test_secret = 'thisisthesecretkey'
    result = do_vault(test_string, test_secret)
    assert isinstance(result, str)
    assert is_encrypted(result)

    # Test unsuccessful vault encryption
    bad_string = ['This', 'is', 'a', 'test', 'string']
    bad_secret = ['this', 'is', 'the', 'secret', 'key']
    try:
        do_vault(bad_string, test_secret)
        raise AssertionError("Vault filter did not throw an exception when input was not of type string!")
    except AnsibleFilterError:
        pass

# Generated at 2022-06-22 14:19:22.694223
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test'
    vault = do_vault(data, secret)
    assert vault



# Generated at 2022-06-22 14:19:39.694349
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "plaintext"
    encrypted_data = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3065393865363736376466653937663236663532363637323034303537373365353863323863313\n          664362626365336130643066640a333538643232626138346131633361366136666335663630363\n          633863363062323335353964306535343664373135623136313762656638643836373965300a343\n          3323437353233663531323636373564343866363963383264386261363560000a\n          ."

    assert do

# Generated at 2022-06-22 14:19:45.724143
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n3132333435363738393031323334353637383930313233343536373839303132333435363738393031\n6363306636666377837390a6664373930353735616134366238336534393733653439663463636666\n6238\n', '123') == '123456'

# Generated at 2022-06-22 14:19:49.171603
# Unit test for function do_vault
def test_do_vault():
    val = do_vault("test", "test", "test", "test", False)
    assert isinstance(val, str)
    assert val


# Generated at 2022-06-22 14:20:01.767141
# Unit test for function do_vault

# Generated at 2022-06-22 14:20:14.462722
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:23.009824
# Unit test for function do_vault
def test_do_vault():
    secret = 'test-secret'
    salt = 'test-salt'
    vaultid = 'test-vaultid'
    test_data = 'ansible-data'

# Generated at 2022-06-22 14:20:30.302152
# Unit test for function do_vault
def test_do_vault():
    # Verify case where data to be encrypted is not a string
    assert type(do_vault(1234, "my_secret")) is str

    # Verify case where secret is not a string
    assert type(do_vault("my_data", 1234)) is str

    # Verify case where we pass in a valid string and secret
    assert type(do_vault("my_data", "my_secret")) is str



# Generated at 2022-06-22 14:20:33.152973
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    assert "my secret" == do_unvault(do_vault("my secret", "my secret"), "my secret")

# Generated at 2022-06-22 14:20:44.213281
# Unit test for function do_unvault

# Generated at 2022-06-22 14:20:53.478703
# Unit test for function do_vault
def test_do_vault():
    secret = "pass"

# Generated at 2022-06-22 14:21:14.971296
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    text = 'hello'
    vault = do_vault(text, secret)


# Generated at 2022-06-22 14:21:19.145657
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'VaultSecret'
    filtered_data = do_vault('MySecret', secret)

    assert '!vault' in filtered_data

    unfiltered_data = do_unvault(filtered_data, secret)

    assert unfiltered_data == 'MySecret'

# Generated at 2022-06-22 14:21:29.344734
# Unit test for function do_vault
def test_do_vault():
    data = 'sample_data'
    secret = '--vault-id default@prompt'
    salt = '123abc'
    vaultid = 'filter_default'
    wrap_object = False
    try:
        assert(is_encrypted(do_vault(data, secret, salt, vaultid, wrap_object)) == True)
        assert(do_unvault(do_vault(data, secret, salt, vaultid, wrap_object), secret, vaultid) == data)
    except AssertionError as err:
        raise AssertionError(err)
    except Exception as err:
        raise Exception(err)

# Generated at 2022-06-22 14:21:35.846064
# Unit test for function do_unvault

# Generated at 2022-06-22 14:21:43.621168
# Unit test for function do_unvault