

# Generated at 2022-06-21 04:29:54.677315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class args(object):
        pass

    class FilterModule(object):
        ''' Ansible vault jinja2 filters '''

        def filters(self):
            filters = {}
            return filters


    # Check that variables are created under the right methods
    try:
        fm = FilterModule()
        fm.filters()
    except Exception:
        raise AssertionError("Unable to extract nextcloud datetime format from config")
    assert FilterModule.filters is not None
    assert not FilterModule.filters()



# Generated at 2022-06-21 04:30:09.517157
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    class MockedFilterModule:
        ''' Class to mock Ansible FilterModule '''
        pass

    # Create object of Mocked FilterModule
    mockedFilterModule = MockedFilterModule()

    # Create object of FilterModule
    filterModule = FilterModule()

    # Set the filters attribute of MockedFilterModule to the return value of method filters of FilterModule
    mockedFilterModule.filters = filterModule.filters()

    # Assert if length of filters is equal to 2
    assert len(mockedFilterModule.filters) == 2

    # Assert if name of vault filter is 'vault'
    assert mockedFilterModule.filters['vault'].__name__ == 'do_vault'

    # Assert if name of unvault filter is 'unvault'
    assert mockedFilterModule.filters['unvault'].__name

# Generated at 2022-06-21 04:30:23.336660
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'supersecret'
    test_vault_id = 'test_vault'
    test_vault = b'$ANSIBLE_VAULT;1.1;AES256\n36616238616662653335343065363634373263306439373764306130383763643730306161363466\n30393964386638643837386433656564663436633132313136373563633661653435663965313030\n38633830663163356234616638643266333264616134623566616264333536303933633861643538\n6538363430623464\n'
    expected_result = 'this is a string'

# Generated at 2022-06-21 04:30:35.536434
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:38.049749
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()



# Generated at 2022-06-21 04:30:48.889702
# Unit test for function do_vault
def test_do_vault():
    from ansible.utils.vault import VaultLib

    # vl = VaultLib([])
    # vl.create_vault_id('test_vaultid','test_pass','test_salt')
    # data = do_vault('test_data','test_pass','test_salt','test_vaultid')
    # assert data == '$ANSIBLE_VAULT;1.1;AES256\n3138356332646537356436346462633266303362346333653765363366653464663965303137323763386364\n306264633961656634323964336530646662383462666231333163323731353630646630393362386365646230\n61653235323330396262613461323

# Generated at 2022-06-21 04:31:01.690226
# Unit test for function do_unvault
def test_do_unvault():

    class TestVault():
        def __init__(self, data):
            self.data = data

    assert(do_unvault('$ANSIBLE_VAULT;1.1;AES256\n1234567\n', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n1234567\n')
    assert(do_unvault('$ANSIBLE_VAULT;test;test\n1234567\n', 'secret') == '$ANSIBLE_VAULT;test;test\n1234567\n')
    assert(do_unvault('$ANSIBLE_VAULT;1.1;AES256\n1234567\n', 'secret', vaultid='default') == '$ANSIBLE_VAULT;1.1;AES256\n1234567\n')


# Generated at 2022-06-21 04:31:08.617103
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:12.511380
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() == {
        'vault': do_vault, 'unvault': do_unvault
    }

# Generated at 2022-06-21 04:31:13.916438
# Unit test for function do_unvault
def test_do_unvault():
    pass


# Generated at 2022-06-21 04:31:23.532126
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import is_encrypted, VaultSecret, key_for_vaults, VaultLib

    # AnsibleVaultEncryptedUnicode
    vault = do_vault('This is my secret', 'secret_password', wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert is_encrypted(vault.vault_text)
    assert key_for_vaults(vault.vault_text) == '$ANSIBLE_VAULT;1.1;AES256'

    # raw string
    vault = do_vault('This is my secret', 'secret_password')
    assert isinstance(vault, str)
    assert is_encrypted(vault)

# Generated at 2022-06-21 04:31:25.062034
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()


# Generated at 2022-06-21 04:31:39.681784
# Unit test for function do_unvault
def test_do_unvault():
    """
        Test the do_unvault filter.

        :returns: No return.
    """
    secret = 'foo'
    vaultid = 'filter_default'

    # Test unvault with non encrypted string
    val = 'non encrypted string'
    ret = do_unvault(val, secret, vaultid)

    assert(ret == val)

    # Test unvault with encrypted string
    val = do_vault('test', secret)

    ret = do_unvault(val, secret, vaultid)
    assert(ret == 'test')

    # Test unvault with encrypted object
    val = do_vault('test', secret, wrap_object=True)
    ret = do_unvault(val, secret, vaultid)
    assert(ret == 'test')

    # Test unvault with

# Generated at 2022-06-21 04:31:51.156753
# Unit test for function do_unvault

# Generated at 2022-06-21 04:31:55.015754
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert isinstance(filter_module, FilterModule)
    assert isinstance(filter_module.filters(), dict)
    assert len(filter_module.filters()) == 2



# Generated at 2022-06-21 04:32:07.945223
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj1 = FilterModule()
    data = "MySecretData"
    secret = "MySecret"
    result = obj1.filters()['vault'](data, secret, None, 'filter_default', True)

# Generated at 2022-06-21 04:32:23.409129
# Unit test for function do_unvault
def test_do_unvault():
    from collections import namedtuple

    # Mockup of keyword variable
    FilterModule.kw = namedtuple('object', ['secret', 'vaultid'])

    def _test(secret, vaultid):
        FilterModule.kw.secret = secret
        FilterModule.kw.vaultid = vaultid
        return do_unvault

    # Setup ansible-vault-test-file
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import decrypt_vault

    pwd = os.path.dirname(os.path.abspath(__file__))
    secret = os.path.join(pwd, 'ansible-vault-test-file.gpg')
    vaultid, vault

# Generated at 2022-06-21 04:32:33.229124
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:34.721655
# Unit test for constructor of class FilterModule
def test_FilterModule():
    d = {}
    assert d == FilterModule().filters()


# Generated at 2022-06-21 04:32:37.401192
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("password", "test")
    assert "!vault |" in vault


# Generated at 2022-06-21 04:32:50.505792
# Unit test for function do_unvault

# Generated at 2022-06-21 04:32:58.458505
# Unit test for function do_unvault
def test_do_unvault():
    a = '$ANSIBLE_VAULT;1.1;AES256;ansible\r\ndddfadfasdfasdfadfasdfasdfasdfasdfasdfadfadfasdfasdfasdfsdfsda'
    b = '123456'
    c = do_unvault(a, b)
    d = 'this is an example'
    assert c == d

# Generated at 2022-06-21 04:33:11.125519
# Unit test for function do_unvault

# Generated at 2022-06-21 04:33:13.111673
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert len(filters) == 2
    assert filters["vault"] == do_vault
    assert filters["unvault"] == do_unvault

# Generated at 2022-06-21 04:33:23.042280
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib, VaultSecret
    vl = VaultLib()
    vs = VaultSecret('foobar')
    assert isinstance(do_vault('foo', 'foobar'), str)
    assert "!vault |" in do_vault('foo', 'foobar', wrap_object=False)
    assert isinstance(do_vault('foo', 'foobar', wrap_object=True), AnsibleVaultEncryptedUnicode)
    assert isinstance(do_vault('foo', 'foobar', vaultid='test', wrap_object=False), str)
    assert vl.decrypt(do_vault('foo', 'foobar', vaultid='test', wrap_object=False), vs, 'test')[0] == 'foo'

# Generated at 2022-06-21 04:33:32.495837
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert fm_filters is not None
    assert isinstance(fm_filters, dict)
    assert 'vault' in fm_filters
    vault_method = fm_filters['vault']
    assert vault_method is not None
    assert callable(vault_method)
    assert 'unvault' in fm_filters
    unvault_method = fm_filters['unvault']
    assert unvault_method is not None
    assert callable(unvault_method)


# Generated at 2022-06-21 04:33:39.545289
# Unit test for function do_vault
def test_do_vault():
    vault_secret = 'ansible'
    vault_salt = 'ansible'
    vault_id = 'filter_default'
    vaultdata = 'ansible'
    filter_result = do_vault(vaultdata, vault_secret, vault_salt, vault_id, wrap_object=False)
    assert vaultdata != filter_result


# Generated at 2022-06-21 04:33:49.548985
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;ansible\n3837393162643261623931393836646264363330353666656535663133633365343065663635\n3830356534653033643039666531366534663335646336393637323966613531376166326365\n3462376366643335383166656232636334316534666133313230633130613262623939306436\n6439633163666566643133", "vault") == "test vault secret"

# Generated at 2022-06-21 04:33:52.362206
# Unit test for constructor of class FilterModule
def test_FilterModule():
     assert not hasattr(FilterModule, '__init__')

# Generated at 2022-06-21 04:33:53.696219
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:34:05.726517
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('secret', 'password') == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n383635366435373366653631623034363161373934306434626139303733643537343537663632\n376465333966666536666339363038336338393664333765653538313664343766376539316464\n6233393261623039346664'

# Generated at 2022-06-21 04:34:09.402571
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters().items() >= {'vault': do_vault, 'unvault': do_unvault}.items()



# Generated at 2022-06-21 04:34:11.094579
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' test FilterModule constructor '''
    x = FilterModule()
    assert x is not None

# Generated at 2022-06-21 04:34:23.660809
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import json
    import sys

    # CWD tests
    orig_cwd = os.getcwd()
    os.chdir('../..')
    base_cwd = os.getcwd()
    vault_id_file = 'test/data/vault_id'
    os.chdir('test/data/')
    unvaulted = do_unvault("test", vault_id_file)
    assert unvaulted == "test"
    os.chdir(base_cwd)
    unvaulted = do_unvault("test", vault_id_file)
    assert unvaulted == "test"

    # Eval tests
    eval_data = {"a": "b", "c": "d"}

# Generated at 2022-06-21 04:34:25.474543
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-21 04:34:35.265751
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Environment
    from jinja2.parser import Parser
    from jinja2.visitor import NodeVisitor
    from jinja2 import nodes

    class TestParser(Parser):
        def parse_expression(self):
            node = self.parse_assign_target()

            while self.stream.current.type in ('assign', 'pipe'):
                if self.stream.current.type == 'pipe':
                    self.stream.expect('pipe')
                    filter_name = self.stream.expect('name').value

# Generated at 2022-06-21 04:34:44.879046
# Unit test for function do_unvault
def test_do_unvault():
    vault_secret = "foo"

# Generated at 2022-06-21 04:34:55.360128
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.hashing import secure_hash

    _vault_id = 'test_do_unvault'
    _secret = 'foo'
    _data = 'bar'

    _vs = VaultSecret(to_bytes(_secret))
    _vl = VaultLib([(_vault_id, _vs)])
    _data = to_bytes(_data)
    _vault = _vl.encrypt(_data, _vs, vaultid=_vault_id)

    assert do_unvault(_vault, _secret, vaultid=_vault_id).decode() == _data.decode()

    # Test a single encrypted value without a vault id
    _hash = secure_hash

# Generated at 2022-06-21 04:34:59.074180
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_instance = FilterModule()
    assert filter_module_instance.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:35:10.965486
# Unit test for function do_vault
def test_do_vault():

    secret = "itsasecret"
    salt = "12345678"
    vaultid = "filter_default"
    data = "my data"


# Generated at 2022-06-21 04:35:24.537962
# Unit test for function do_vault
def test_do_vault():
    mysecret = "mysecret"
    mysalt = "mysalt"
    testdata = "testdata"
    realvault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible_filter_default\n          35393732623163366336383966616364383464353434326430363964353832376666623638643931\n          33356435393136623636336132613230396561336561613062336238633630663462323862303266\n          34333532326666656462643933303764316333393234626633336130646231623665653364326633\n          34626163346237613938643835376231376639\n          "


# Generated at 2022-06-21 04:35:30.544980
# Unit test for function do_unvault
def test_do_unvault():
    vl = VaultLib()
    data = b'my_secret'
    vs = VaultSecret(b'secret')
    vault = vl.encrypt(data, vs, b'filter_default')
    assert do_unvault(vault, 'secret') == b'my_secret'

# Generated at 2022-06-21 04:35:40.920561
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'mysecret'
    test_vault = '$ANSIBLE_VAULT;1.1;AES256'
    test_non_vault = 'this is not a vault'
    test_bad_vault = '$ANSIBLE_VAULT;1.1;AES256'

    secret = VaultSecret(test_secret)
    do_vault('mydata', secret, salt=None, vaultid='filter_default', wrap_object=False)
    vl = VaultLib([('filter_default', secret)])
    decrypted = vl.decrypt(test_vault)
    assert decrypted == 'mydata'
    decrypted = vl.decrypt(test_non_vault)
    assert decrypted == test_non_vault

# Generated at 2022-06-21 04:35:43.988412
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
   # Tests that filters return the expected type
   fm = FilterModule()
   filters = fm.filters()
   assert filters['vault'] == do_vault
   assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:35:52.773141
# Unit test for function do_vault
def test_do_vault():
    secret = "foo"
    salt = "bar"
    vaultid = "baz"
    data = "foobar"

# Generated at 2022-06-21 04:36:05.185001
# Unit test for function do_unvault
def test_do_unvault():
    # Test single value with default setting
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;default;default;333332313539343432353033373635363332333535333735303437333233383232343733313336323338303733303536343630363737353831333631373230353637323238363330353729', 'abc') == '1234567890'

    # Test multiple values with default setting

# Generated at 2022-06-21 04:36:10.961406
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ft = FilterModule()
    filters = ft.filters()
    assert filters is not None
    assert filters['vault'] is do_vault
    assert filters['unvault'] is do_unvault

# Generated at 2022-06-21 04:36:24.932855
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:32.316012
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    data = 'data'
    # For now we are assuming the unvault method is returning the same as input.
    # This can be improved later by adding more unit tests.
    assert do_unvault(data, secret) == data

# Generated at 2022-06-21 04:36:33.691811
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-21 04:36:37.817358
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None


# Generated at 2022-06-21 04:36:40.571850
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)


# Generated at 2022-06-21 04:36:51.671614
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:55.944411
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)
    decrypted = do_unvault(vault, secret)
    assert decrypted == data

# Generated at 2022-06-21 04:37:08.467081
# Unit test for function do_vault
def test_do_vault():
    # NOTE: this is currently **only** usable with python3 due to
    # ansible.parsing.vault.VaultLib using six.with_metaclass() which
    # sets the metaclass of the class to a python2 metaclass, which requires
    # changing the metaclass to a python3 metaclass.
    # Also, this cannot be a unittest.TestCase object as TestCase subclasses
    # are already instantiated, and the metaclass cannot be changed after that.
    # FIXME: Can the VaultLib class be instantiated in this test instead of
    # having to change the VaultLib class?
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.six import with_metaclass
    from ansible.module_utils.six.moves import reload_module

# Generated at 2022-06-21 04:37:14.173787
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # use monkey patching to mock out the environment ouside
    # the tested function.
    # mock the display object
    import sys
    import io

    # mock the display object
    display.display = io.StringIO()

    # redirect stdout and stderr to the display object
    sys.stderr = display.display
    sys.stdout = display.display

    # mocked data to be used by the test

# Generated at 2022-06-21 04:37:16.810800
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:37:21.792219
# Unit test for function do_vault
def test_do_vault():
    secret = 'ANSIBLE123'
    data = 'ANSIBLE_SECRET_DATA'
    vault = do_vault(data, secret)

    assert is_encrypted(vault)



# Generated at 2022-06-21 04:37:25.785449
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Ensure return
    assert(FilterModule)
    # No exception
    assert(False == hasattr(FilterModule,'exception'))

# Generated at 2022-06-21 04:37:27.296313
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj


# Generated at 2022-06-21 04:37:42.869841
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:51.285379
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256;default\n63323565383038353362336238346566353131366239306236613863663465646562633862336337\n62386264363132363638333564663065323466336564376133353162633232336236333462393162\n31633332656134663738646635666339613665646635366435653764653336643137326664333538\n38613663323762393161313530363731333939663135383863316264306633396533613161336261\n396135613233353635336533393964346665\n'
    unscrambled_secret

# Generated at 2022-06-21 04:38:04.273603
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:09.463714
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert callable(filters['vault'])
    assert 'unvault' in filters
    assert callable(filters['unvault'])


# Generated at 2022-06-21 04:38:10.037108
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:38:14.975218
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert callable(filter_module.filters())
    assert "vault" in filter_module.filters()
    assert "unvault" in filter_module.filters()


# Generated at 2022-06-21 04:38:24.918176
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultEditor
    import yaml

    password = "vault123"
    editor = VaultEditor(password)
    plaintext = "!ansible-vault |\n\t$ANSIBLE_VAULT;1.2;AES256\n"
    plaintext += "65373536376366633937376631386231333138313261616565353437613035666236643164333066\n"
    plaintext += "63313761353262613239336639636564383964633532316465353033303163336334666230336261\n"

# Generated at 2022-06-21 04:38:29.276205
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:38:39.386096
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:43.499885
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    actual = FilterModule().filters()
    expected = {'unvault': do_unvault, 'vault': do_vault}

    assert actual == expected

# Generated at 2022-06-21 04:38:57.292409
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:38:59.326456
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:39:08.346672
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'hello world'
    test_secret2 = 'hello world2'
    test_data = 'hello world'
    test_data2 = 'hello world2'

    test_data_vault = do_vault(test_data, test_secret)
    test_data2_vault = do_vault(test_data2, test_secret)

    # Make sure vaulted versions are different
    assert test_data_vault != test_data2_vault

    # Unvault and make sure get the original data
    assert test_data == do_unvault(test_data_vault, test_secret)
    assert test_data2 == do_unvault(test_data2_vault, test_secret)


# Generated at 2022-06-21 04:39:12.003261
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fmod = FilterModule()
    filters = fmod.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:39:17.544694
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    filters = f.filters()
    secret = 'secret_password'
    res = filters['vault']('test_value', secret)
    res_vault = AnsibleVaultEncryptedUnicode(res)
    res_vault.vault = VaultLib()
    res_vault.vault.secrets = {'filter_default': VaultSecret('secret_password')}
    assert res != 'test_value'
    assert res_vault.data == 'test_value'


# Generated at 2022-06-21 04:39:26.725805
# Unit test for function do_vault
def test_do_vault():
    # do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False):
    assert do_vault('test', 'secret', vaultid='test_id', wrap_object=True)
    assert do_vault('test', 'secret', vaultid='test_id')
    assert not do_vault(123, 'secret', vaultid='test_id')
    assert not do_vault('test', 123, vaultid='test_id')
    assert not do_vault('test', 'secret', salt=123, vaultid='test_id')
    assert not do_vault('test', 'secret', vaultid=123)
    assert not do_vault('test', 'secret', vaultid='test_id', wrap_object='true')


# Generated at 2022-06-21 04:39:29.016272
# Unit test for function do_unvault
def test_do_unvault():
    # Test for no vault data
    test = do_unvault(None, 'my_secret')
    assert test == None


# Generated at 2022-06-21 04:39:32.649864
# Unit test for function do_vault
def test_do_vault():
    string_value = "secret"
    secret_value = "mysecretvalue"
    wrapped_object = True
    result = do_vault(string_value, secret_value, wrap_object=wrapped_object)

    assert isinstance(result, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-21 04:39:42.304019
# Unit test for function do_vault
def test_do_vault():
    '''
    Ensures the vault filter uses the correct hash algorithm
    '''

    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    plaintext = "This is some plain text"
    secret = "secret"

    vault = do_vault(plaintext, secret)

    assert isinstance(vault, string_types)

    vl = VaultLib()
    assert plaintext == to_native(vl.decrypt(vault))
