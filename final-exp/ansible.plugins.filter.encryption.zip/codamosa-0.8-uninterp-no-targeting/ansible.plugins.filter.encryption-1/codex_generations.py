

# Generated at 2022-06-21 04:29:54.956544
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    vault_filter = FilterModule()
    filters = vault_filter.filters()
    assert 'vault' in filters.keys(), "vault filter not in filters"
    assert 'unvault' in filters.keys(), "unvault filter not in filters"

# Generated at 2022-06-21 04:30:09.607834
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    secret = "password"
    data = "test1"

# Generated at 2022-06-21 04:30:17.685823
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filters = FilterModule().filters()
    assert filters is not None
    assert type(filters) == dict

    vault_filter = filters['vault']
    assert vault_filter is not None
    assert callable(vault_filter)

    unvault_filter = filters['unvault']
    assert unvault_filter is not None
    assert callable(unvault_filter)

    assert len(filters) == 2


# Generated at 2022-06-21 04:30:20.757538
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_instance = FilterModule()
    assert(isinstance(test_instance, FilterModule))

# Unit tests for do_vault function

# Generated at 2022-06-21 04:30:22.621815
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None


# Generated at 2022-06-21 04:30:35.507344
# Unit test for function do_unvault
def test_do_unvault():

    # Test for correct output for unvault function with correct data
    def test_unvault_correct_output(vault_input, secret, vaultid):

        d_output = do_unvault(vault_input, secret, vaultid)

        assert isinstance(d_output, string_types)

        return d_output

    # Test for correct output for do_unvault function with incorrect data
    def test_unvault_incorrect_output(vault_input, secret, vaultid):

        try:
            d_output = test_unvault_correct_output(vault_input, secret, vaultid)
        except Exception as e:
            d_output = e

        assert isinstance(d_output, AnsibleFilterError)

        return d_output

    # Test for correct output for unvault function with correct

# Generated at 2022-06-21 04:30:48.276345
# Unit test for function do_vault
def test_do_vault():
    result = do_vault(None, None)
    assert result == ''
    result = do_vault('password', 'secret')

# Generated at 2022-06-21 04:30:49.216286
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:31:02.029320
# Unit test for function do_unvault
def test_do_unvault():
    vault_encoded = b'$ANSIBLE_VAULT;1.1;AES256;ansible\n30333761613138333331356337636461376266613233353134343764353839643435333261323564\n39366433623661306462626230613134666433386663643039646461663237363038646230373365\n64323030653937356238383337353866363938373031\n'
    secret = 'Vp5J!Ag9zV7&m5^$uVwL#gAY2^V7c%'
    data = do_unvault(vault_encoded, secret)
    print(data)
    assert data == "foo"


# Generated at 2022-06-21 04:31:03.793244
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    p = FilterModule()
    assert hasattr(p, "filters"), "Class 'FilterModule' misses method 'filters'"

# Generated at 2022-06-21 04:31:06.832053
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:31:08.456264
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-21 04:31:19.182481
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:31:27.880999
# Unit test for function do_vault
def test_do_vault():
    s = "this is a secret"
    p = "asdqwe123"
    r = do_vault(s, p)
    assert(is_encrypted(r))
    q = do_unvault(r, p)
    assert(s == q)

    # detect incorrect secret
    try:
        do_unvault(r, p + '0')
    except AnsibleFilterError as e:
        assert('Secret passed does not match' in str(e))

if __name__ == '__main__':
    test_do_vault()

# Generated at 2022-06-21 04:31:31.649039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:31:33.938415
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not 'foo' in FilterModule.filters(FilterModule)

# Generated at 2022-06-21 04:31:43.600817
# Unit test for function do_vault
def test_do_vault():
    from ansible.playbook.play_context import PlayContext

    secret = 'toor'
    salt = 'salt'
    vaultid = 'test_vault'
    wrap_object = False
    test_data = {'test_int': 1, 'test_dict': {'key1': 'val1', 'key2': 'val2'}, 'test_list': [1, 2, 3, 'test', 'test2']}

    # Test data is dict
    assert isinstance(test_data, dict) is True

    # Test function do_vault to encrypt data
    assert isinstance(do_vault(test_data, secret, salt, vaultid, wrap_object), string_types) is True

# Generated at 2022-06-21 04:31:46.641575
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_ = FilterModule()
    assert class_.filters()
    assert class_.filters()['vault']
    assert class_.filters()['unvault']


# Generated at 2022-06-21 04:31:47.938287
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-21 04:31:49.752055
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-21 04:31:53.130260
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['vault'] == do_vault
    assert FilterModule().filters()['unvault'] == do_unvault


# Generated at 2022-06-21 04:32:02.063053
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test filters
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.hashing import secure_hash_s
    from ansible.module_utils._text import to_native

    # Test vault filter
    secret = 'mysecret'
    salt = b'mysalt'
    string = 'secret'
    string_vault = do_vault(string, secret, salt, 'default', False)
    assert string_vault is not None
    data = do_unvault(string_vault, secret, 'default')
    assert data == string

    # Test unvault filter

# Generated at 2022-06-21 04:32:03.545682
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-21 04:32:11.230765
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vault = "!vault |"
    vault += "$ANSIBLE_VAULT;1.1;AES256;user;user@user.com;\n"
    vault += "3637386633326637663430663465353136636464663337643561393464363933\n"
    vault += "6130326535376633303839346165643664313661396336613632663930643631\n"
    vault += "63623463616337323636663830643634353332343330646666"
    result = do_unvault(vault, secret)
    assert "testing" == result


# Generated at 2022-06-21 04:32:25.608211
# Unit test for function do_vault
def test_do_vault():
    # Check if None input
    try:
        do_vault(None, 'secret')
        assert False, "Exception was not raised when input was None"
    except AnsibleFilterTypeError:
        pass

    # Check if Undefined input
    try:
        do_vault(Undefined(), 'secret')
        assert False, "Exception was not raised when input was Undefined"
    except AnsibleFilterTypeError:
        pass

    # Check if non-string secret
    try:
        do_vault('data', 2)
        assert False, "Exception was not raised when secret was non-string"
    except AnsibleFilterTypeError:
        pass

    # Check if Undefined secret

# Generated at 2022-06-21 04:32:28.856203
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Case-1: Test FilterModule constructor
    fm = FilterModule()

    # Case-1: Test FilterModule object
    assert fm is not None



# Generated at 2022-06-21 04:32:39.094574
# Unit test for function do_unvault

# Generated at 2022-06-21 04:32:50.505452
# Unit test for function do_vault
def test_do_vault():
    import pytest

    test_secret = 'test_secret'
    test_data = 'test_data'
    test_vault = '$ANSIBLE_VAULT;1.2;AES256;test_filter_default0000000000\n39623036613334393532316232303936646361666561643562316464393133396336336463376133\n35613161386636373866313761386532313636666535393833383065373537333566630a0a663035\n'
    assert test_vault == do_vault(test_data, test_secret)

    # Test with undefined
    pytest.raises(AnsibleFilterError, do_vault, Undefined, test_secret)

# Generated at 2022-06-21 04:33:00.336509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.compat.tests.unit.common.compat_fake_type import FakeString, FakeEncrypted

    # Test filters with a secret and a good vault
    filters = FilterModule().filters()
    secret = "my secret"
    cleared = b"my clear text data"
    vault = b'$ANSIBLE_VAULT;1.1;AES256;ansible\n36336462353331643432316433353737326432613562663931633335333032306363343035333665\n3730353733363362313561316237123132333435363738\n'

# Generated at 2022-06-21 04:33:10.754966
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_string', 'password') == '$ANSIBLE_VAULT;1.2;AES256;default\n3534373933363165363536396333353836643265393366323532333132303866333031353162330a6433343266643730346439326234316339353234376332646662616233383364613462336339630a346466353639663830333435336162346264643835386438646338383564373836633861373464', "Failed to encrypt string"


# Generated at 2022-06-21 04:33:26.785750
# Unit test for function do_vault
def test_do_vault():
    # Test case: test: ''
    actual = do_vault(data='test', secret='test')
    expected = '$ANSIBLE_VAULT;!vault |\n          $ANSIBLE_VAULT;1.2;AES256;filter_default\n          3765323663666633364653838376266313932396338643530336365303336376139636638663961\n          353432353861626230663230623862333962333562353533366566336536393939633862356366\n          626133313139653436633164663265653635646261633533363836653935653461373066653638\n          6164\n'
    assert expected == actual
    # Test case: test: ''

# Generated at 2022-06-21 04:33:35.015327
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    import re

    # Create a VaultLib containing two VaultSecrets (one with filterid "default" and one with filterid "other_id")
    vault_lib = VaultLib()
    vault_lib.secrets = {'default': VaultSecret(to_bytes("default_secret")), 'other_id': VaultSecret(to_bytes("other_id_secret"))}
    global_vault_lib = VaultLib.get_vault_secret([('default', VaultSecret(to_bytes("default_secret"))), ('other_id', VaultSecret(to_bytes("other_id_secret")))])

    # Three test cases

# Generated at 2022-06-21 04:33:40.895272
# Unit test for function do_unvault
def test_do_unvault():
    display.vvvv('Testing the ansible.builtin.vault plugin')
    vl = VaultLib()
    test_secret = 'foo'
    encrypted_string = vl.encrypt(b"foo", VaultSecret(b"foo"))
    plain_string = do_unvault(encrypted_string, test_secret)
    assert"foo" == plain_string

# Generated at 2022-06-21 04:33:44.743756
# Unit test for function do_vault
def test_do_vault():
    secret = 'one'
    plaintext = 'Unencrypted string'
    encrypted_string = do_vault(plaintext, secret)

    assert encrypted_string != plaintext


# Generated at 2022-06-21 04:33:46.149568
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-21 04:33:54.498920
# Unit test for function do_unvault
def test_do_unvault():

    from base64 import b64encode
    import binascii
    from ansible.parsing.vault import VaultEditor

    # Valid encrypted string
    data = b64encode(VaultEditor.encrypt_bytes(b'cowsay Hello Vault!', b'threeve'))
    output = do_unvault(data, 'threeve')
    assert output == 'cowsay Hello Vault!'

    # Corrupted string
    data_corrupted = b64encode(binascii.unhexlify(b'00000000'*20))
    try:
        output = do_unvault(data_corrupted, 'threeve')
        assert False
    except AnsibleFilterError:
        # Assert raised the AnsibleFilterError as expected
        assert True

    # Valid encrypted string but with wrong secret

# Generated at 2022-06-21 04:33:55.510239
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-21 04:34:02.740617
# Unit test for function do_vault
def test_do_vault():

    data = "Hello World"
    secret = "123"
    salt = ""
    vaultid = "test_vault_id"
    wrap_object = False

    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_function = filters['vault']

    res = filter_function(data, secret, salt, vaultid, wrap_object)

    assert res != ""
    assert res != "Hello World"


# Generated at 2022-06-21 04:34:08.104735
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Arrange
    filters = None

    # Act
    try:
        filters = FilterModule()
    except Exception as e:
        print(e)

    # Assert
    print(filters)


# Generated at 2022-06-21 04:34:23.265932
# Unit test for function do_unvault
def test_do_unvault():
    secret = "foo"

# Generated at 2022-06-21 04:34:28.191855
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:34:40.575958
# Unit test for function do_vault
def test_do_vault():

    # Expected to return a string
    assert isinstance(do_vault('foo',
                               'mysecret',
                               'mysecret',
                               False),
                      string_types)

    # Expected to throw an error when the data is not a string
    try:
        do_vault(12,
                 'mysecret',
                 'mysecret',
                 False)
    except AnsibleFilterTypeError:
        pass
    except Exception:
        assert False

    # Expected to throw an error when the secret is not a string
    try:
        do_vault('foo',
                 12,
                 'mysecret',
                 False)
    except AnsibleFilterTypeError:
        pass
    except Exception:
        assert False

    # Expected to return an AnsibleVaultEncryptedUnicode object
    assert isinstance

# Generated at 2022-06-21 04:34:48.969737
# Unit test for function do_vault
def test_do_vault():

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    secret = 'test'

    data = 'hello'
    vault = do_vault(data, secret)
    assert isinstance(vault, AnsibleUnsafeText)
    assert data == do_unvault(vault, secret)

    data = 'hello world'
    vault = do_vault(data, secret)
    assert isinstance(vault, AnsibleUnsafeText)
    assert data == do_unvault(vault, secret)

    data = b'hello'
    vault = do_vault(data, secret)
    assert isinstance(vault, AnsibleUnsafeText)
    assert data == do_unvault(vault, secret)

    data = b'hello world'

# Generated at 2022-06-21 04:34:49.961508
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-21 04:34:51.068819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()

# Generated at 2022-06-21 04:34:53.141000
# Unit test for constructor of class FilterModule
def test_FilterModule():
    global filters
    x = FilterModule()
    filters = x.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:34:59.488660
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''unit test for method filters of class FilterModule'''
    # Function get_filters will return a dictionary of all filters and
    # functions and callable objects of class FilterModule
    assert 'unvault' in FilterModule().filters()
    assert 'vault' in FilterModule().filters()

# Generated at 2022-06-21 04:35:00.954471
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test

# Generated at 2022-06-21 04:35:06.642701
# Unit test for function do_unvault
def test_do_unvault():
    input_value = '$ANSIBLE_VAULT;1.1;AES256;test\n343039633562333266623637633535346564343939336136363664383737633862343734363265\n306639383638383534356137363934366161356133313863630a65663834636463613834666665\n'
    output_value = do_unvault(input_value, "vault1")
    assert output_value == "hello"

# Generated at 2022-06-21 04:35:11.671559
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("secret", "password")
    assert do_vault("another secret", "password")
    assert do_vault(None, "password") is None
    assert do_vault("very secret", "very secret")


# Generated at 2022-06-21 04:35:24.815084
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'salt'
    vaultid = 'test_vaultid'
    wrap_object = True

    data = 'test'
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert do_unvault(vault, secret, vaultid) == data

    data = '!vault |' + vaultid + '\n' + vault
    unvault = do_unvault(data, secret, vaultid)
    assert unvault == data

    data = 'test'
    vault = do_vault(data, secret, salt, vaultid, True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert do_un

# Generated at 2022-06-21 04:35:26.780961
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-21 04:35:37.734321
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'foo'
    vaultid = 'filter_default'

    # check for non-string case
    for data in [
        [1, 2, 3],
        {'a':'b'},
        None
    ]:
        try:
            do_unvault(data, secret, vaultid)
        except AnsibleFilterTypeError as e:
            assert "Vault should be in the form of a string" in str(e)

    # check for non-encrypted data case
    plain_str = 'baz'
    assert do_unvault(plain_str, secret, vaultid) == plain_str

    # check for encrypted data case
    enc_str = do_vault(plain_str, secret, vaultid)
    assert do_unvault(enc_str, secret, vaultid) == plain_str

# Generated at 2022-06-21 04:35:42.775687
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Case 1: Returns dictionary for filters
    # Case 2: Raise TypeError if key 'filters' is not present
    assert type(FilterModule.filters(FilterModule)) == dict
    assert FilterModule.filters(FilterModule).has_key('filters') == True



# Generated at 2022-06-21 04:35:53.582075
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    salt = "salt"
    data = "data"


# Generated at 2022-06-21 04:36:05.559850
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mTnT8ZpWKxvxlAI09TEcYJlqe'

# Generated at 2022-06-21 04:36:13.919582
# Unit test for function do_vault
def test_do_vault():
    if __name__ == '__main__':
        from ansible.plugins.filter import vault

        d = "This is a test of do_vault"
        s = "foo"

        v = vault.do_vault(d, s)
        assert(v.startswith(b'$ANSIBLE_VAULT;'))

        d = vault.do_unvault(v, s)
        assert(d == 'This is a test of do_vault')


# Generated at 2022-06-21 04:36:20.931175
# Unit test for constructor of class FilterModule
def test_FilterModule():
    
    # create instance of class FilterModule
    f = FilterModule()

    # check if filters() return dict
    assert isinstance(f.filters(), dict)

    # check if filters() return dict with only 2 key-value pairs
    assert len(f.filters()) == 2



# Generated at 2022-06-21 04:36:24.465151
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    secret = 'password'
    data = 'secret'
    vault = do_vault(data, secret)
    assert do_unvault(vault, secret) == data

# Generated at 2022-06-21 04:36:36.505833
# Unit test for function do_vault
def test_do_vault():
    test_data = 'This is a test string'
    test_secret = 'test_secret'
    test_vault = do_vault(test_data, test_secret)
    test_vault_object = do_vault(test_data, test_secret, wrap_object=True)
    assert isinstance(test_vault, str) is True
    test_unvault = do_unvault(test_vault, test_secret)
    assert test_unvault == test_data
    assert isinstance(test_vault_object, AnsibleVaultEncryptedUnicode) is True
    assert isinstance(test_vault_object.data, str) is True
    assert test_vault_object.data == test_data

# Generated at 2022-06-21 04:36:42.265914
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__name__ == "FilterModule", "FilterModule's constructor not as expected"

# Generated at 2022-06-21 04:36:45.125562
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__doc__ == 'Ansible vault jinja2 filters'
    assert FilterModule.filters.__doc__ == 'Return the filters as dictionary'

# Generated at 2022-06-21 04:36:46.473397
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert isinstance(filter_module.filters(), dict)

# Generated at 2022-06-21 04:36:48.430481
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(isinstance(FilterModule(), FilterModule))


# Generated at 2022-06-21 04:36:49.256248
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-21 04:36:55.205907
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test for method filters of class FilterModule."""
    obj = FilterModule()
    filters = obj.filters()
    assert filters == {'vault': do_vault, \
                       'unvault': do_unvault}, \
        "Method FilterModule.filters does not return the correct dictionary."

# Generated at 2022-06-21 04:36:57.851508
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm.filters() is not None)



# Generated at 2022-06-21 04:37:00.265281
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Empty test. Just to validate the code format.
    assert FilterModule()

# Generated at 2022-06-21 04:37:02.913816
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for method filters of class FilterModule """

    instance = FilterModule()

    assert instance.filters()

# Generated at 2022-06-21 04:37:10.321907
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("my_secret_data", "my_secret") == '$ANSIBLE_VAULT;1.1;AES256\n63613965313566313035623133363965366466346163623639303663386165313938613765393065\n34303061663234616363306431323432353339366437633266326233653539336463383835613661\n39643361666237303766333938663837626436643262316132333935376537656531383939653737\n623436303739373230306264326232393933383738343566626537336262316133\n'


# Generated at 2022-06-21 04:37:29.749655
# Unit test for function do_unvault
def test_do_unvault():
    vault_id = 'filter_default'

# Generated at 2022-06-21 04:37:31.967477
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)

# Generated at 2022-06-21 04:37:42.870580
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          34353733633561323163336665616638666435326233343933666434343032336565343131333432\n          626233343566343532303937366631626263376132363931306337653033623164\n          3830343865633862316663396335663533613031613238616133356631383433\n          3965663563333464636237343233356438666564343035613462393035", 'CHANGEME') == "testunvault"


# Generated at 2022-06-21 04:37:50.369764
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("password", "secret", "salt", "filter1") == '$ANSIBLE_VAULT;1.1;AES256;salt;3398875471308436413c564117d2706491109f633389d2a2;01a9316f5a1a8f091c6a947b9dafc190908b98c39fabb1d6b3f6d0e6a6836b5d\n'


# Generated at 2022-06-21 04:37:57.925463
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"
    test_data = "hello"
    vault = do_vault(test_data, secret)
    assert do_unvault(vault, secret) == test_data
    assert do_unvault(test_data, secret) == test_data


# Generated at 2022-06-21 04:38:09.603364
# Unit test for function do_unvault
def test_do_unvault():
    # Empty string
    assert do_unvault("", "") == ""
    # Non-empty string

# Generated at 2022-06-21 04:38:15.736740
# Unit test for function do_vault
def test_do_vault():
    vault_secret = 'TEST_SECRET'
    data = 'TEST_DATA'
    wrapped_vault = do_vault(data, vault_secret)
    vault = do_vault(data, vault_secret, False)
    assert wrapped_vault != vault and len(wrapped_vault) == len(vault)
    assert do_unvault(wrapped_vault, vault_secret) == data
    assert do_unvault(vault, vault_secret) == data



# Generated at 2022-06-21 04:38:22.968175
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('secret', 'password', 'filter_default', True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode), "failed to vault 'secret' with password 'password'"

    vault = do_vault('secret', 'password', None, True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode), "failed to vault 'secret' with password 'password' and vaultid 'None'"


# Generated at 2022-06-21 04:38:37.862421
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test_default\n37306561316134613331336165623363653538393437363066636339623665323531353265313963350a313137316363323362623332323366326534666162383831356334326134613161336663396231610a3263326536353661653730393363663331633831653461333631613862653761333232313435\n', 'password', 'test_default') == 'foo'

# Generated at 2022-06-21 04:38:45.429279
# Unit test for function do_vault

# Generated at 2022-06-21 04:39:05.236477
# Unit test for function do_unvault
def test_do_unvault():
    if __name__ != '__main__':
        return
    import pytest

    # Testing with a vaulted string
    test_string = '$ANSIBLE_VAULT;1.1;AES256;test\n613639383561663337613361303764363930353332646237353830353964636265653137656533\n3439653035653338333539383564303631333766336538630a3863663630326262393132393734\n346561623763623064353434303738306635303164643335346437396564383763313761343135\n6132646336613566616633'
    secret = 'test'
    data = do_unvault(test_string, secret)


# Generated at 2022-06-21 04:39:19.936578
# Unit test for function do_vault
def test_do_vault():
    data = 'foo'
    key = '$ANSIBLE_VAULT;1.1;AES256;ansible'
    iv = '0123456789abcdef'
    salt = '0123456789abcdef0123456789abcdef'
    v_id = 'test_id'
    wrap = True

    expected = '$ANSIBLE_VAULT;1.1;AES256;ansible\n3439323663323166373762373830623463626564323134333036353064366338616235353864\n3964333332636261636238623862343633376432626233366665f5f5f5f5f5f5f5f5f5f5f5f5f\n'


# Generated at 2022-06-21 04:39:27.399083
# Unit test for function do_vault
def test_do_vault():
    from collections import namedtuple
    from ansible.module_utils._text import to_text, to_bytes

    # Mocking jinja2.Undefined
    class Undefined(object):
        def __getattr__(self, name):
            return self

        def __call__(self, *args, **kwargs):
            return self

    # Mocking ansible.parsing.vault.VaultAES256
    class VaultAES256(object):
        def __init__(self, secret, salt=None):
            self.secret = secret
            self.salt = salt

        def encrypt(self, data, salt=None):
            return data

    # Mocking jinja2.Environment()
    class Environment(object):
        undefined = Undefined()


# Generated at 2022-06-21 04:39:30.434310
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    print(type(obj))
    print(dir(FilterModule))
    assert type(obj) == FilterModule, "Object FilterModule not created"

# Generated at 2022-06-21 04:39:44.017432
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret1'
    data = 'password3'