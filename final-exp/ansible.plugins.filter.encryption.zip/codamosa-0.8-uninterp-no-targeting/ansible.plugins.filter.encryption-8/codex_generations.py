

# Generated at 2022-06-21 04:30:08.930485
# Unit test for function do_unvault
def test_do_unvault():
    key = 'test'
    value = 'myvaultstring'

    # Test with not encrypted data
    assert do_unvault(value, key) == value

    # Test with string and optional args set
    vaulted_value = do_vault(value, key)
    assert do_unvault(vaulted_value, key) == value

    # Test with vault object
    vaulted_value = do_vault(value, key, wrap_object=True)
    assert do_unvault(vaulted_value, key) == value

    # Test with an object that can't be decrypted
    vaulted_value = do_vault(value, key, wrap_object=True)
    vaulted_value.vault = None
    assert do_unvault(vaulted_value, key) == value



# Generated at 2022-06-21 04:30:20.784594
# Unit test for function do_unvault
def test_do_unvault():

    secret = "mypassword"
    #    vault = "$ANSIBLE_VAULT;1.1;AES256;ansible\n333430393762626335336163376161636564356533323762636661376166623531323932356237\n333736363864626239396339313162396261353864396135646135653165646435633834393537\n636336643733653431323166643965343766373166323038373866373065316262623237396364\n356531633237626264323630333765313630306165356361363663346136643033616166343639\n38363539"


# Generated at 2022-06-21 04:30:26.354541
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:33.771388
# Unit test for function do_unvault
def test_do_unvault():
    vault_password = 'vault_password'
    vault_data = 'vault_test_data'
    vault_encrypted_data = do_vault(vault_data, vault_password)
    vault_decrypted_data = do_unvault(vault_encrypted_data, vault_password)
    assert vault_decrypted_data == vault_data
    assert isinstance(vault_encrypted_data, binary_type)


# Generated at 2022-06-21 04:30:42.139727
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'this is some data'
    vault = do_vault(data, secret)

    assert isinstance(vault, string_types)
    assert is_encrypted(vault)

    data2 = do_unvault(vault, secret)
    assert data == data2


# Generated at 2022-06-21 04:30:53.084216
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:06.325900
# Unit test for function do_vault
def test_do_vault():
    secret_string = "This is a secret string"
    data_string = "This is data string"
    salt_string = "This is a salt string"

    secret_bytes = b"This is a secret bytes"
    data_bytes = b"This is data bytes"
    salt_bytes = b"This is a salt bytes"

    vault_secret_string = "vault"
    vault_data_string = "vault"
    vault_salt_string = "vault"

    vault_secret_bytes = b"vault"
    vault_data_bytes = b"vault"
    vault_salt_bytes = b"vault"

    wrapper_object_string = AnsibleVaultEncryptedUnicode(vault_data_string,
                                                         version=2,
                                                         vault_id='string')


# Generated at 2022-06-21 04:31:09.140412
# Unit test for constructor of class FilterModule
def test_FilterModule():
    flt = FilterModule()
    assert flt is not None
    # TODO: More tests here


# Generated at 2022-06-21 04:31:09.946049
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:31:11.973950
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-21 04:31:27.844365
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('password', 'secret', 'salt', 'vaultid', wrap_object=True).vault.decrypt('password') == 'password'

# Generated at 2022-06-21 04:31:29.445919
# Unit test for function do_vault
def test_do_vault():
    pass



# Generated at 2022-06-21 04:31:39.836337
# Unit test for function do_vault
def test_do_vault():

    data = "secret"
    secret = "password"

    result = do_vault(data, secret)

    if result != "$ANSIBLE_VAULT;1.1;AES256\n63323561623936343637656638313763633534353034396134356538353037366631356462336236\n3839316532653630343362613166376331323235633239393430353435356438636362383339653036\n6430626265646330653936613064396432646433366130343933646630626338\n":
        raise AssertionError()


# Generated at 2022-06-21 04:31:51.317866
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data_false = 'Hello world!'
    data_true = 'Boohoo!'

    data_filter = do_vault(data_false, secret)
    assert data_filter != data_false
    data_filter_decrypted = do_unvault(data_filter, secret)
    assert data_filter_decrypted == data_false

    data_filter = do_vault(data_false, secret, wrap_object=True)
    assert isinstance(data_filter, AnsibleVaultEncryptedUnicode)
    data_filter_decrypted = do_unvault(data_filter, secret)
    assert data_filter_decrypted == data_false

    data_filter = do_vault(data_true, secret, wrap_object=True)

# Generated at 2022-06-21 04:32:01.337578
# Unit test for function do_vault
def test_do_vault():
    data = "my_secret_data"
    secret = "my_vault_secret"
    salt = "my_salt"
    vaultid = "filter_unittest_do_vault"

    # Test string secrets
    vault_ansible = do_vault(data, secret, salt, vaultid, True)
    vault_vaultlib = VaultLib().encrypt(data, VaultSecret(secret), vaultid, salt)
    assert vault_ansible.data == vault_vaultlib

    # Test unicode secrets
    vault_ansible = do_vault(data, u"\u20ac", salt, vaultid, True)
    vault_vaultlib = VaultLib().encrypt(data, VaultSecret(u"\u20ac"), vaultid, salt)
    assert vault_ansible.data == vault_vault

# Generated at 2022-06-21 04:32:11.693128
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:13.724393
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f


# Generated at 2022-06-21 04:32:17.602912
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    vault = do_vault('secret', secret)
    assert type(vault) is str
    assert len(vault) > 0
    assert vault.startswith('$ANSIBLE_VAULT;')


# Generated at 2022-06-21 04:32:29.588643
# Unit test for function do_vault
def test_do_vault():
    data = "my secret message"
    secret = "my vault secret"
    vaultid = "filter_default"
    wrap_object = False

# Generated at 2022-06-21 04:32:44.226185
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault("$ANSIBLE_VAULT;1.1;AES256\n353037323331373762346163336363362663466393432366230376132306164393435313161626532\n356536613030343733323861386132366533356634366531320a353036373436623137383633366136\n3466393931393265333365666436653035313165343633363035306266363932633266313662396264\n6437663265626232650a3061393331663436643439", 'test_unvault') == "test_unvault")

# Generated at 2022-06-21 04:33:01.202395
# Unit test for function do_unvault
def test_do_unvault():

    # Use an arbitrary key to test values
    key = "6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6UeM6Ue"
    data = "This is a test value\n"
    vaultid = "filter_default"

    # Test to make sure a non-encrypted string returns the original value
    assert do_unvault(data, key, vaultid) == data

    # Test to make sure a string vaulted with ansible-vault and the same key works
    from ansible.parsing.vault import VaultEditor

# Generated at 2022-06-21 04:33:11.681685
# Unit test for function do_unvault

# Generated at 2022-06-21 04:33:22.581492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  from ansible.utils.unsafe_proxy import AnsibleUnsafeText
  import datetime

  f = FilterModule()
  r = f.filters()
  assert(r == { 'vault': do_vault, 'unvault': do_unvault })

  # Test vault filter
  #    The method does not raise AnsibleFilterTypeError for any valid type of secret
  #    The method does not raise AnsibleFilterError for any valid type of data
  assert(do_vault('data', 'secret') is not None)
  assert(do_vault('data', AnsibleUnsafeText('secret')) is not None)
  assert(do_vault(2, 3) is not None)
  assert(do_vault(2.0, 3.0) is not None)

# Generated at 2022-06-21 04:33:28.392586
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert(len(filters) == 2)
    assert(filters["vault"] == do_vault)
    assert(filters["unvault"] == do_unvault)

# Generated at 2022-06-21 04:33:35.240827
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' == list(filters.keys())[0]
    assert 'unvault' == list(filters.keys())[1]
    assert callable(filters['vault'])
    assert callable(filters['unvault'])


# Generated at 2022-06-21 04:33:37.297109
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() != None

# Generated at 2022-06-21 04:33:41.108017
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Given
    f = FilterModule()

    # When
    filters = f.filters()

    # Then
    assert len(filters) == 2



# Generated at 2022-06-21 04:33:44.309176
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()

    assert filters['vault'] is not None
    assert filters['unvault'] is not None

# Generated at 2022-06-21 04:33:53.715412
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import pytest
    from mock import Mock, patch

    def mock_encrypt(*args, **kwargs):
        return "test"

    def mock_encrypt_vault(*args, **kwargs):
        vault = AnsibleVaultEncryptedUnicode(u"test")
        vault.vault = Mock(vl=Mock(encrypt=Mock(return_value=vault)))
        return vault

    secret = "password"
    string_to_encrypt = "secret"
    salt = "salt"


# Generated at 2022-06-21 04:34:04.898097
# Unit test for function do_vault
def test_do_vault():
    """To run this test you need the python modules 'pytest' and 'pytest-cov' installed.
    To install them:
       pip install pytest pytest-cov
    To run the test:
       python-coverage run tests/sanity/code/filter_plugins/test_vault.py
       python-coverage report -m
    """
    import pytest
    from pytest import raises
    import os

    # Test that only a string is accepted
    with raises(AnsibleFilterTypeError):
        do_vault(data=3, secret='aW5mb3JtYXRpb25fc2VjcmV0')

    # Test that only a string is accepted
    with raises(AnsibleFilterTypeError):
        do_vault(data='information', secret=123)

    # Test wrong secret

# Generated at 2022-06-21 04:34:23.967999
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:34.698663
# Unit test for function do_unvault
def test_do_unvault():
    secret = u"secret"

# Generated at 2022-06-21 04:34:39.432360
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    result = FilterModule().filters()
    assert isinstance(result, dict)
    assert result == {"vault": do_vault, "unvault": do_unvault}



# Generated at 2022-06-21 04:34:43.402213
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Testing for method filters
    fm = FilterModule()

# Generated at 2022-06-21 04:34:53.426454
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    salt = "saltysalt"

    retval = do_vault(data, secret, salt=salt, wrap_object=True)
    assert isinstance(retval, AnsibleVaultEncryptedUnicode)
    assert retval.vaultid == "filter_default"
    assert retval.vault._salts['filter_default'] == salt

    retval = do_vault(data, secret, salt=salt, wrap_object=False)
    assert isinstance(retval, string_types)
    assert is_encrypted(retval)



# Generated at 2022-06-21 04:35:05.542607
# Unit test for function do_vault
def test_do_vault():

    # string
    filter_input = "foo"
    secret = "my-secret"
    assert do_vault(filter_input, secret) == "$ANSIBLE_VAULT;1.1;AES256\n35366532653066383863376861373238396232326537396661646466656132373833396434623935\n363131666165396466383637336633626235316362303333316236350a3231663735306632396330\n38633165633461613462376139313236396335643839336466326262623665623761623366363863\n65393131313032656530363062643961"

    # unicode
    filter_input = u"foo"
    secret = u

# Generated at 2022-06-21 04:35:08.142259
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_instance = FilterModule()
    assert isinstance(FilterModule_instance.filters(), dict)

# Generated at 2022-06-21 04:35:13.968981
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)
    assert isinstance(FilterModule(), FilterModule)
    assert isinstance(FilterModule().filters(), dict)
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()


# Generated at 2022-06-21 04:35:26.725829
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    display.deprecated(
        "Using vault filters without specifying a vault id is deprecated"
        " since Ansible 2.10. See"
        " https://docs.ansible.com/ansible/latest/user_guide/playbooks_vault.html#specifying-vault-identity-on-the-command-line"
        " for details.", version='2.10'
    )
    display.deprecated(
        "Using the default vault id of 'filter_default' is deprecated."
        " Please specify a vault id on the command line instead.",
        version='2.10'
    )
    source = "hello"
    assert source == do_unvault(do_vault(source, secret), secret)

    source = ['hello', 'world']

# Generated at 2022-06-21 04:35:38.519889
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    try:
        import hvac
    except ImportError:
        pytest.skip("The python module hvac is not installed. Skipping vault filter tests.")

    vault_client = hvac.Client()

    filters = FilterModule().filters()

    # try the function with an encrypted vault id, data and secret
    secret = vault_client.secrets.transit.read_encryption_key('filter_default', 'filter_default')
    assert secret['data']['keys']
    secret = secret['data']['keys'][0]['name']
    data_to_encrypt = "testing"

# Generated at 2022-06-21 04:35:51.040490
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate the FilterModule class
    filter_module = FilterModule()
    # Get the filters
    filters = filter_module.filters()
    # Check that the vault filter is in the filters
    assert('vault' in filters)
    # Check that the unvault filter is in the filters
    assert('unvault' in filters)

# Generated at 2022-06-21 04:35:59.659300
# Unit test for function do_vault
def test_do_vault():
    data = "data to be encrypted"
    secret = "secret for encrypting data"
    salt = "salt for encrypting data"
    vaultid = "filter_default"
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid=vaultid, wrap_object=wrap_object)

    assert isinstance(vault, string_types), "Encrypted data should be a string"



# Generated at 2022-06-21 04:36:08.193445
# Unit test for function do_vault
def test_do_vault():
    """
    Run test cases to test the do_vault function.
    """

# Generated at 2022-06-21 04:36:12.621957
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test when the field argument is a str
    test_field = "test_field"
    test_value = "test_value"
    test_vault = "test_vault"

    test_secret = "test_secret"

    filter_module = FilterModule()

    assert filter_module.filters()['vault'](data=test_value, secret=test_secret) == test_vault
    assert filter_module.filters()['unvault'](vault=test_vault, secret=test_secret) == test_value

# Generated at 2022-06-21 04:36:18.133906
# Unit test for function do_unvault
def test_do_unvault():

    plain_vault = '$ANSIBLE_VAULT;1.2;AES256;test;test'

    plain_vault_decrypted = do_unvault(plain_vault, 'test')

    assert plain_vault_decrypted is None

# Generated at 2022-06-21 04:36:28.602615
# Unit test for function do_unvault
def test_do_unvault():
    """Check the results of the do_unvault function."""

    # single value tests
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES;abc123\nabcdefghijkl\n", "secret") == "abcdefghijkl"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES;abc123\n\n", "secret") == ""
    assert do_unvault("$ANSIBLE_VAULT;1.2;AES;abcd1234\nabcd1234\n", "secret") == "abcd1234"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES;abc123\nabcdefghijkl\n", "secret") == "abcdefghijkl"
    assert do_

# Generated at 2022-06-21 04:36:38.151447
# Unit test for function do_vault
def test_do_vault():
    key = "foobar"
    value = "foobar"

    data = do_vault(value, key)


# Generated at 2022-06-21 04:36:45.867356
# Unit test for function do_vault
def test_do_vault():
    data = 'hello world'
    secret = 'mysecret'
    vaultid = 'myvaultid'
    wrap_object = True

    try:
        encrypted_data = do_vault(data, secret, vaultid=vaultid, wrap_object=wrap_object)
        decrypted_data = do_unvault(encrypted_data, secret, vaultid=vaultid)
    except Exception as e:
        raise

    assert data == decrypted_data

# Generated at 2022-06-21 04:37:01.131132
# Unit test for function do_unvault
def test_do_unvault():

    import pytest

    secret = "test"
    expected = "123456789"

    vault = "$ANSIBLE_VAULT;1.1;AES256;test\n"
    vault += "39383330373635343331666337623164656564373630643938633137333161333766343739373265\n"
    vault += "63633162656330663064393135613336343764646132613761366364326664333566613237343566\n"
    vault += "36306461666134613261346564666563316663323331653835346665376431316439343161613663\n"

# Generated at 2022-06-21 04:37:08.066129
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;2341.2342.1343;3453234;234423;asdfasdfasdfasd", "secret") == "asdfasdfasdfasd"
    # is not encrypted
    assert do_unvault("asdfasdfasdfasd", "secret") == "asdfasdfasdfasd"
    # test is_encrypted
    assert is_encrypted("$ANSIBLE_VAULT;2341.2342.1343;3453234;234423;asdfasdfasdfasd")
    assert not is_encrypted("asdfasdfasdfasd")


# Generated at 2022-06-21 04:37:16.864858
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:37:21.235731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    assert 'vault' in filter_obj.filters()
    assert 'unvault' in filter_obj.filters()


# Generated at 2022-06-21 04:37:31.630375
# Unit test for function do_unvault
def test_do_unvault():
    # Scenario1: Testing with plain data
    test_data = "Hello world"
    test_secret = "password"
    unvaulted_data = do_unvault(test_data, test_secret)
    assert unvaulted_data == test_data

    # Scenario2: Testing with vaulted data

# Generated at 2022-06-21 04:37:35.267175
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:37:44.116295
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2 import Template
    data = 'do_unvault test'
    secret = 'secret'
    vault_id = 'vault_id'
    t = Template("{{ data | unvault(secret, vaultid='{{ vaultid }}') }}")
    r = t.render(data=data, secret=secret, vaultid=vault_id)
    assert r == data
    assert isinstance(data, str)
    assert isinstance(secret, str)
    assert isinstance(vault_id, str)
    assert isinstance(r, str)


# Generated at 2022-06-21 04:37:52.948767
# Unit test for function do_unvault
def test_do_unvault():
    import pytest

    # Case 1: do_unvault input are strings and vault password is correct
    # Expected result: data = 'example'
    f = FilterModule()
    filters = f.filters()


# Generated at 2022-06-21 04:38:04.916890
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'

# Generated at 2022-06-21 04:38:06.613252
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    expected = 2
    actual = len(obj.filters())
    assert expected == actual


# Generated at 2022-06-21 04:38:08.189229
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:38:17.602552
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:44.085523
# Unit test for function do_unvault
def test_do_unvault():
    print("\nUnit Test for do_unvault() Function")
    testPassed = 0
    try:
        plain_text = do_unvault("test_string", "test_pass")
        if plain_text == "test_string":
            testPassed += 1
        else:
            print("Test 1: Failed")
    except UndefinedError as err:
        print(err)

    try:
        plain_text = do_unvault("test_string", "test_pass", "test_vaultid")
        if plain_text == "test_string":
            testPassed += 1
        else:
            print("Test 2: Failed")
    except UndefinedError as err:
        print(err)


# Generated at 2022-06-21 04:38:50.454657
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils import basic

    mod = basic.AnsibleModule(argument_spec={})
    mod.params = {}
    def do_assert(data, secret):
        # do the encrypt
        token = do_vault(data=data, secret=secret)
        assert len(token) == 128
        # validate it
        if token.startswith('$ANSIBLE_VAULT;'):
            token = token.split(';')[1]
        assert len(token) == 106
        assert token[2] == '$'
        assert token[4] == '$'
        # do the decrypt
        ddata = do_unvault(token, secret)
        assert ddata == data, "Expected: %s\nGot: %s" % (data, ddata)


# Generated at 2022-06-21 04:38:53.532670
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() is not None

# Generated at 2022-06-21 04:38:55.746457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-21 04:38:56.598956
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:39:00.636556
# Unit test for function do_vault

# Generated at 2022-06-21 04:39:02.410500
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        FilterModule()
    except Exception as e:
        return False
    return True

# Generated at 2022-06-21 04:39:06.100785
# Unit test for function do_unvault
def test_do_unvault():
    ret = do_vault('secret', 'password')
    assert '$ANSIBLE_VAULT;1.2;' in ret
    assert ret != 'secret'
    assert b'$ANSIBLE_VAULT;1.2;' in to_bytes(ret)
    assert to_native(do_unvault(ret, 'password')) == 'secret'


# Generated at 2022-06-21 04:39:13.818099
# Unit test for function do_unvault
def test_do_unvault():

    import os
    import pytest

    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import binary_type, string_types
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common._text import to_bytes, to_text
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.utils.vars import combine_vars

    # Vault id containing the passphrase for vault string
    PASSWORD_FILE = '/tmp/vault-password'

    # Vault id containing the passphrase for

# Generated at 2022-06-21 04:39:19.475261
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert len(filters.keys()) == 2
    assert filters.get('vault') == do_vault
    assert filters.get('unvault') == do_unvault
