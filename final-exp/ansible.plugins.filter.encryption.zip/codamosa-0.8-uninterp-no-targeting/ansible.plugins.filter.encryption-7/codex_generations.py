

# Generated at 2022-06-21 04:30:03.076620
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:05.162908
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:30:14.910309
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'hello secret world'


# Generated at 2022-06-21 04:30:18.949535
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    s = FilterModule()
    filters = s.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:30:28.232207
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.parsing.convert_bool import boolean

    secret = 'ansible'
    string_data = 'Hello World!'
    list_data = ['Hello', 'World']
    dict_data = {'name': 'Hello World'}
    bool_data_true = 'y'
    bool_data_false = 'n'

    # Testing as plain string
    vault = do_vault(string_data, secret)
    data = do_unvault(vault, secret)
    assert(data == string_data)

    # Testing as AnsibleVaultEncryptedUnicode
    vault = do_vault(string_data, secret, wrap_object=True)
    data = do_unvault(vault, secret)
    assert(data == string_data)

    # Testing an encrypted

# Generated at 2022-06-21 04:30:29.110353
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-21 04:30:32.201922
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_vault_filter = FilterModule()
    assert ansible_vault_filter is not None
    filters = ansible_vault_filter.filters()
    assert filters["vault"] is not None
    assert filters["unvault"] is not None

# Generated at 2022-06-21 04:30:38.738710
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:49.141281
# Unit test for function do_vault
def test_do_vault():
    """do_vault Test Cases:

    Test with secret and data"""
    # Test simple string

# Generated at 2022-06-21 04:30:52.243318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:31:00.048901
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class TestClass(object):
        def test_case_1(self):
            f = FilterModule()
            assert 'vault' in f.filters()
            assert 'unvault' in f.filters()

    obj = TestClass()
    obj.test_case_1()



# Generated at 2022-06-21 04:31:08.460262
# Unit test for function do_vault
def test_do_vault():
    print("\nUnit test for function do_vault.")

    # Test for string
    print("Test for string")
    result = do_vault("password123", "12345")
    assert result == "$ANSIBLE_VAULT;1.1;AES256" \
                     "\n613065326236326534346361383335653730393436386638306138613134396636333066" \
                     "\n346230333165336636363935653134636163313231316532633664346635626433393737" \
                     "\n35643632\n"

    # Test for undefined
    print("Test for undefined")

# Generated at 2022-06-21 04:31:19.211413
# Unit test for function do_vault
def test_do_vault():
    # Test for passing function valid data
    actual_result = do_vault('admin', 'password')
    expected_result = '$ANSIBLE_VAULT;1.1;AES256\n313535333634373533383538396332626661356136613431643865383737306533373565393565\n646130326662393236306630636532643532356532653962633165326335353232333862363036\n313537343631313661336635633463326232646136353065386362356337613464323462636331\n6462306664356137616231306664656262\n'
    assert actual_result == expected_result

    # Test for passing function invalid data

# Generated at 2022-06-21 04:31:29.690043
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils._text import to_text
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    fm = FilterModule()
    filters = fm.filters()

    # Test vault filter
    secret1 = "secret1"
    secret2 = to_text('secret2', encoding='utf-8')
    data1 = "unencrypted data"
    data2 = "encrypted data"
    vaultid1 = "vaultid1"
    vaultid2 = "vaultid2"

    # data = unencrypted data, secret = secret1
    # secret1 = VaultSecret('secret1')
    encrypted_data1 = do_vault(data1, secret1, vaultid=vaultid1)


# Generated at 2022-06-21 04:31:41.595987
# Unit test for function do_unvault
def test_do_unvault():
    import re
    # Test value defined in Ansible Vault specification
    test_value = '$ANSIBLE_VAULT;1.2;AES256;ansible\n34353163356639623166613931366262643232373439636633316437303937343234663761343533\n39663964366665643366313664393034336339623934383034623562666334623662373864323736\n36353438666162356235313036306433323966643665623765623061633233313264656535663865\n63386130313065386432623334633264316532653231346236613862356637383663346265\n'

# Generated at 2022-06-21 04:31:45.811405
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters == {'vault': do_vault,
                   'unvault': do_unvault}

# Generated at 2022-06-21 04:31:57.377186
# Unit test for function do_vault
def test_do_vault():

    secret = 'foo'
    salt = '1234'
    vaultid = 'vault_id'
    wrap_object = False

    assert do_vault('data', secret, salt, vaultid, wrap_object) == '$ANSIBLE_VAULT;1.2;AES256;vault_id;r1gAhtD+vEpxDH5aESYgjw==;xl09CZpO7O+lIk/is7z/eNyBHtDYw4g4I7V8otZs0s7QeLqXuTH7VciF0mjK7V0Y'


# Generated at 2022-06-21 04:32:04.029428
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six import PY2

    # Test using empty vault and secret
    try:
        do_unvault("", "")
    except AnsibleFilterError:
        pass

    # Test using empty vault with secret present
    try:
        do_unvault("", "secret")
    except AnsibleFilterError:
        pass

    # Test using empty secret and vault present
    try:
        do_unvault("$ANSIBLE_VAULT;1.1;AES256;foo1231\n6162636465666768696a6b6c6d6e6f707172737475767778797a0a\n", "")
    except AnsibleFilterError:
        pass

    # Test unvaulting an encrypted string

# Generated at 2022-06-21 04:32:11.883719
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:21.756257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' unit test for filters method of class FilterModule '''

    # Create an instance of class FilterModule
    flt = FilterModule()

    # Unit test for filters method of class FilterModule
    # with valid input parameters
    result = flt.filters()

    # If the output of the do_vault method is an object of
    # AnsibleVaultEncryptedUnicode, then assert the True
    if isinstance(result, dict):
        assert True
    else:
        assert False


# Generated at 2022-06-21 04:32:35.790900
# Unit test for function do_unvault
def test_do_unvault():
    # Example of a decryptable vault string
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible_vault_test_c1314862d2bb6c86\n353965613537653139643536393038343664336637326539363563346330633266366630613065\n343530346563646536326538366364336436353563363466646466653537333334343534333133\n653963313032326664363737663965383936626536663330336230393834653065\n'
    secret = 'A_SECRET'
    assert 'THE_SECRET_STRING_THAT_IS_INSIDE_OF_THE_VAULT' == do_unvault

# Generated at 2022-06-21 04:32:37.414781
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    filters = fm.filters()

    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:32:42.820853
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:32:53.201228
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    # Testing function vault

# Generated at 2022-06-21 04:32:58.438397
# Unit test for function do_vault
def test_do_vault():
    vaultid = "test_vaultid"
    secret = "mysecret"
    salt = "12345678"
    vault = do_vault("This is my test string", secret, salt, vaultid)
    assert is_encrypted(vault)



# Generated at 2022-06-21 04:33:11.073113
# Unit test for function do_unvault

# Generated at 2022-06-21 04:33:13.681439
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filters = FilterModule()
    assert test_filters is not None



# Generated at 2022-06-21 04:33:23.887897
# Unit test for function do_unvault
def test_do_unvault():
    import os

    # Create a temporary file to write out an vaulted string
    temp_file = 'example_vault'
    with open(temp_file, 'w') as f:
        f.write('!vault |\n')
        f.write('  $ANSIBLE_VAULT;1.1;AES256\n')
        f.write('  39653961656439616231363334666466663566643837663465303261326163383235626539353863\n')
        f.write('   ')

    # read the vaulted string and unvault it
    with open(temp_file) as f:
        vault = f.read()

    secret = os.environ['ANSIBLE_VAULT_PASSWORD']
    datastr = do_unvault

# Generated at 2022-06-21 04:33:25.614179
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule(object)

# Generated at 2022-06-21 04:33:29.746052
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expect_filters = {
        'vault': do_vault,
        'unvault': do_unvault,
    }
    assert FilterModule().filters() == expect_filters



# Generated at 2022-06-21 04:33:37.076085
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fltrs = FilterModule().filters()
    assert fltrs['vault'] == do_vault
    assert fltrs['unvault'] == do_unvault



# Generated at 2022-06-21 04:33:40.310402
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    y = x.filters()
    assert y['vault'] == do_vault
    assert y['unvault'] == do_unvault

# Generated at 2022-06-21 04:33:51.990242
# Unit test for function do_unvault
def test_do_unvault():
    '''Test the unvault function'''
    test_vault_secret = b'$ANSIBLE_VAULT;1.1;AES256\n3836303562316365363366396261383566633138346331626466643839623830656462326263373\n39313461336335613761333261333064386264366437393064393337643831333963323561643863\n393238386261636237326433633434653839373330656566\n'

# Generated at 2022-06-21 04:33:59.742004
# Unit test for function do_vault
def test_do_vault():
    # pylint: disable=no-self-use
    vault = do_vault('foo', 'bar')
    assert vault == '.vault.foo'
    # pylint: disable=no-self-use
    vault = do_vault('foo', 'bar', wrap_object=True)
    assert vault.data == 'foo'
    assert vault.vault is None


# Generated at 2022-06-21 04:34:08.837594
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:15.302935
# Unit test for function do_unvault
def test_do_unvault():
    import ansible.parsing.yaml.loader
    import ansible.parsing.yaml.dumper
    import ansible.parsing.yaml.objects
    import ansible.parsing.vault
    import ansible.utils.display
    import ansible.errors
    import ansible.module_utils._text
    import ansible.module_utils.six
    import ansible.parsing.yaml.loader
    import ansible.parsing.yaml.constructor
    import ansible.parsing.yaml.nodes
    import ansible.parsing.yaml.representer
    import ansible.module_utils.six
    import ansible.parsing.yaml.composer
    import ansible.parsing.yaml.scanner

# Generated at 2022-06-21 04:34:25.498495
# Unit test for function do_unvault
def test_do_unvault():
    # Test old-style vault
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          841e5472284c7bdb5d5b05f34cfa1d57f38b9f61ccb0355a8e70339bff719d40566a38426c0\n          c98aa9b9b39dcb6e8b37d16b2c2dccbaa8f7e8dcd4b79c372e4b4\n          3f6c528ef6d0ec6ca3336f7a8c0ddccba  \n        "
    secret = "devops"
    data = do_unvault(vault,secret)
    assert data == "super secret"

    # Test old-

# Generated at 2022-06-21 04:34:28.213966
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:34:29.563274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filter = FilterModule()
    result = test_filter.filters()
    assert 'vault' in result
    assert 'unvault' in result

# Generated at 2022-06-21 04:34:36.530868
# Unit test for function do_vault

# Generated at 2022-06-21 04:34:46.087939
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultLibNoKeyExist
    from ansible.parsing.vault import VaultLibKeyError
    from ansible.parsing.vault import VaultLibKeyStatusError

    vault_password = "vault_password"
    vault_salt = "salt"
    vault_id = "test_do_unvault"

    vault_secret = VaultSecret(vault_password.encode())
    vault_lib = VaultLib([(vault_id, vault_secret)])
    vault_lib_no_key = VaultLib()
    vault_lib_wrong_key = VaultLib

# Generated at 2022-06-21 04:34:52.780519
# Unit test for function do_vault
def test_do_vault():
    salt_string = '1234'
    secret = 'my-secret'
    data = 'my-data'
    vaultid = 'test_vault_id'
    vault_data = do_vault(data, secret, salt_string, vaultid)

    assert vault_data, 'Vaulted data is None'
    assert is_encrypted(vault_data), 'Expected vaulted data to be encrypted'

# Generated at 2022-06-21 04:35:04.520152
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()

    valid_data = {
        'key': 'value',
        'key1': 'value1',
    }

    invalid_data = {
        'key': 'value',
        'key1': 'value1',
        None: 'value1'
    }

    secret = 'secret'

    # case 1: Valid input dict
    result = obj.filters()['vault'](valid_data, secret)
    assert result != ''

    # case 2: In valid input dict
    try:
        result = obj.filters()['vault'](invalid_data, secret)
        assert result == ''
    except AnsibleFilterTypeError:
        assert True

    # case 3: Invalid input type

# Generated at 2022-06-21 04:35:08.044364
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()


# Generated at 2022-06-21 04:35:10.019871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert m



# Generated at 2022-06-21 04:35:13.992997
# Unit test for function do_vault
def test_do_vault():
    data = 'hello'
    secret = 'secret'
    salt = 'salt'
    vaultid = 'vaultid'
    encrypted_data = do_vault(data, secret, salt, vaultid)

    assert(encrypted_data != '') and (encrypted_data != Undefined)



# Generated at 2022-06-21 04:35:19.005092
# Unit test for function do_vault
def test_do_vault():
    yaml_data = {'password': 'MySecretPassword'}
    secret = 'vault_secret'
    vault_password = 'vault_password'
    wrapped_data = do_vault(yaml_data, vault_password)
    assert type(wrapped_data) is dict
    assert wrapped_data['password'].startswith('$ANSIBLE_VAULT')
    assert wrapped_data['password'].endswith('\n')
    unwrapped_data = do_unvault(wrapped_data, secret)
    assert unwrapped_data['password'] == yaml_data['password']



# Generated at 2022-06-21 04:35:21.195626
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("vault encrypted string", "secret string") == "vault encrypted string"



# Generated at 2022-06-21 04:35:23.653831
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }

# Unit tests for vault() function

# Generated at 2022-06-21 04:35:27.632457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()
    assert filters['vault'] is do_vault
    assert filters['unvault'] is do_unvault

# Generated at 2022-06-21 04:35:37.747322
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()
    assert 'unvault' in filter_module.filters()

# Unit tests for method do_vault

# Generated at 2022-06-21 04:35:44.786311
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    secret = 'secret'
    data = 'testdata'
    vault = do_vault(data, secret)
    vlib = VaultLib()
    vault_secret = VaultSecret(secret)
    assert vlib.decrypt(vault, vault_secret) == data, "Vaulted data does not match inital data"



# Generated at 2022-06-21 04:35:47.172074
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # FIXME: Write unit test for method filters of class FilterModule
    assert False


# Generated at 2022-06-21 04:35:55.224695
# Unit test for function do_vault
def test_do_vault():
    call_1 = do_vault('test', 'secret', vaultid='test_vaultid')

# Generated at 2022-06-21 04:36:04.493291
# Unit test for function do_vault
def test_do_vault():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = 'password'
    secret = 'random'
    salt = 'salt'
    vaultid = 'vault_id'
    ansible_vault = do_vault(data, secret, salt, vaultid, wrap_object=True)
    with open('example.yml', 'w') as f:
        yaml.dump(ansible_vault, f)
    vault_content = ansible_vault.data
    assert is_encrypted(vault_content)
    assert isinstance(ansible_vault, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-21 04:36:05.399211
# Unit test for constructor of class FilterModule
def test_FilterModule():
    c = FilterModule()

# Generated at 2022-06-21 04:36:08.410203
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule()) == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:36:16.812710
# Unit test for function do_vault
def test_do_vault():
    secret1 = "password"
    data1 = "data"
    salt1 = None
    vaultid1 = 'filter_default'
    wrap_object1 = False

# Generated at 2022-06-21 04:36:27.808064
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

    input_data = "This is the test data to be encrypted"
    vaultid = "test_vaultid"

    # checking if encrypt string is not empty
    assert do_vault(input_data, secret, vaultid=vaultid) != ''

    # checking if encrypted string is different from input string
    assert do_vault(input_data, secret, vaultid=vaultid) != input_data

    # checking if secret is None or not
    try:
        assert do_vault(input_data, secret=None, vaultid=vaultid)
    except AssertionError:
        pass

    # checking if secret is not empty
    try:
        assert do_vault(input_data, secret="", vaultid=vaultid)
    except AssertionError:
        pass

# Generated at 2022-06-21 04:36:35.353422
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test for method filters of class FilterModule"""
    ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode = AnsibleVaultEncryptedString
    fm = FilterModule()
    assert 'vault' in fm.filters(), "Ansible 'vault' filter is missing"
    assert 'unvault' in fm.filters(), "Ansible 'unvault' filter is missing"


# Generated at 2022-06-21 04:36:52.351039
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:37:01.699757
# Unit test for function do_vault
def test_do_vault():
    #
    # Return a string
    #
    test_string = "This is a test string"
    test_secret = "ansible"
    ret_string = do_vault(test_string, test_secret)
    #print(ret_string)
    assert(ret_string != test_string)
    #
    # Make sure we can unvault the string properly
    #
    ret_string = do_unvault(ret_string, test_secret)
    #print(ret_string)
    assert(ret_string == test_string)
    #
    # Make sure we can vault an object
    #
    test_object = AnsibleVaultEncryptedUnicode(test_string)
    ret_object = do_vault(test_object, test_secret, wrap_object=True)

# Generated at 2022-06-21 04:37:02.668378
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Unit Test for the do_vault function

# Generated at 2022-06-21 04:37:05.781472
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:37:18.861371
# Unit test for function do_vault
def test_do_vault():

    test_data = dict()
    test_data[0] = dict()
    test_data[0]['data'] = 'abcdefghijklmnopqrstuvwxyz'
    test_data[0]['secret'] = 'abcdefghijklmnopqrstuvwxyz'

# Generated at 2022-06-21 04:37:30.061871
# Unit test for function do_unvault
def test_do_unvault():
    filters = FilterModule()

# Generated at 2022-06-21 04:37:31.113103
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass

# Generated at 2022-06-21 04:37:36.149498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters['vault'] == do_vault
    assert filter_module.filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:37:40.116340
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:37:50.632555
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('vault value 1', 'age', vaultid='filter_unittest_vault') == 'age'
    assert do_unvault('vault value 2', 'age', vaultid='filter_unittest_vault') == 'age'
    assert do_unvault('vault value 3', 'age', vaultid='filter_unittest_vault') == 'age'
    assert do_unvault('vault value 4', 'age', vaultid='filter_unittest_vault') == 'age'
    assert do_unvault('vault value 5', 'age', vaultid='filter_unittest_vault') == 'age'
    assert do_unvault('vault value 6', 'age', vaultid='filter_unittest_vault') == 'age'
   

# Generated at 2022-06-21 04:38:06.883759
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # create an object of type FilterModule
    filter_module = FilterModule()

    filters = filter_module.filters()

    # test the vault function
    assert filters.get('vault') == do_vault
    # test the unvault function
    assert filters.get('unvault') == do_unvault

# Generated at 2022-06-21 04:38:10.271839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] == do_vault
    assert fm.filters()['unvault'] == do_unvault



# Generated at 2022-06-21 04:38:12.293765
# Unit test for constructor of class FilterModule
def test_FilterModule():
    objFilterModule = FilterModule()
    assert objFilterModule is not None

# Generated at 2022-06-21 04:38:23.534877
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest

    ff = FilterModule()

    assert ff.filters() is not None

    f = ff.filters()['vault']

    assert f is not None

    vault = f('1234', '1234')

    f = ff.filters()['unvault']

    assert f is not None

    unvault = f(vault, '1234')

    assert unvault == '1234'

    with pytest.raises(AnsibleFilterError):
        f('1234', '4567')

    with pytest.raises(AnsibleFilterTypeError):
        f('1234', 1234)

    with pytest.raises(AnsibleFilterTypeError):
        f(1234, '1234')

# Generated at 2022-06-21 04:38:24.980944
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert isinstance(FilterModule, object)

# Generated at 2022-06-21 04:38:27.579903
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # create object of class FilterModule
    FilterModule()



# Generated at 2022-06-21 04:38:34.292914
# Unit test for function do_unvault
def test_do_unvault():
    vault = do_vault('data', 'secret')
    # test with secret
    assert do_unvault(vault, 'secret') == 'data'
    # test with wrong secret
    try:
        do_unvault(vault, 'wrong_secret')
        assert False
    except AnsibleFilterError as err:
        assert True

# Generated at 2022-06-21 04:38:44.473021
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Instantiate the class FilterModule
    filter_module = FilterModule()

    def test_function_vault():
        test = 'test'
        secret = 'secret'
        salt = None
        vaultid = 'filter_default'
        wrap_object = False

        # Call the method filters of class FilterModule
        filters = filter_module.filters()

        actual = filters.get('vault')(test, secret, salt, vaultid, wrap_object)
        # Expected: b'$ANSIBLE_VAULT;1.1;AES256\n3137643162316331366137383935626633346631656338343064333435336261626632313735\n36396462653239643039333031623233393033636462376133356263303565303

# Generated at 2022-06-21 04:38:58.974116
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:39:01.134494
# Unit test for function do_vault
def test_do_vault():
    pass

# Generated at 2022-06-21 04:39:25.586715
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:39:37.750818
# Unit test for function do_unvault
def test_do_unvault():
    ansible_vault_secret = 'test_secret'
    salt = 'saltysalt'
    raw_data = 'some_data'
    raw_data_unicode = u'some_data_unicode'
    encrypted = do_vault(raw_data, ansible_vault_secret, salt)
    encrypted_unicode = do_vault(raw_data_unicode, ansible_vault_secret, salt)
    assert do_unvault(encrypted, ansible_vault_secret) == raw_data
    assert do_unvault(encrypted_unicode, ansible_vault_secret) == raw_data_unicode

# Generated at 2022-06-21 04:39:42.288793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'vault' in module.filters()
    assert 'unvault' in module.filters()


# Generated at 2022-06-21 04:39:55.625131
# Unit test for function do_vault
def test_do_vault():

    vault = do_vault("foo", "MyVaultSecret")
    assert "ANSIBLE_VAULT;1.1" in vault
    assert "AES256" in vault

    vault = do_vault("foo", "MyVaultSecret", salt="foobar")
    assert "ANSIBLE_VAULT;1.1" in vault
    assert "AES256" in vault

    vault = do_vault("foo", "MyVaultSecret", vaultid="myvault")
    assert "ANSIBLE_VAULT;1.1" in vault
    assert "AES256" in vault

    with pytest.raises(AnsibleFilterTypeError):
        do_vault("foo", 123)

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(123, "MyVaultSecret")

