

# Generated at 2022-06-21 04:30:06.048020
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault(data="test", secret="secret")
    assert vault == "$ANSIBLE_VAULT;1.1;AES256\n35663936306338623530336666333263333761393037386531643431626430653366383262626334\n63353866653938343866636263310a3536363035326438343565633832626237633766376163656166\n3134333066613561350a", "The encrypted message got by do_vault is wrong"



# Generated at 2022-06-21 04:30:15.143826
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'

# Generated at 2022-06-21 04:30:17.136253
# Unit test for constructor of class FilterModule
def test_FilterModule():
    actual_result = FilterModule()
    assert actual_result is not None

# Generated at 2022-06-21 04:30:25.495368
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:34.390316
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.module_utils.six import iteritems
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils.display import Display
    import os

    # Tests against sample vault file
    data_path = os.path.join(os.path.dirname(__file__), '..', '..', 'unit', 'parsing', 'vault', 'data')
    vault_path = os.path.join(data_path, 'vaulted_yaml.txt')
    f = open(vault_path)
    vaulted_yaml = f.read()
    f.close()

    data = AnsibleLoader(vaulted_yaml).get_single_data()

# Generated at 2022-06-21 04:30:47.908645
# Unit test for function do_unvault
def test_do_unvault():

    # Test decrypting with valid VaultSecret
    secret = "mysecret"

# Generated at 2022-06-21 04:30:58.770270
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert do_unvault('vaulted_value', 'password') == 'vaulted_value'
    except AnsibleFilterError:
        assert False
    try:
        assert do_unvault(None, 'password') is None
    except AnsibleFilterError:
        assert False
    try:
        assert do_unvault(False, 'password') is False
    except AnsibleFilterError:
        assert False

# Generated at 2022-06-21 04:31:03.861254
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:31:17.604123
# Unit test for function do_unvault
def test_do_unvault():
    """Test do_unvault function."""


# Generated at 2022-06-21 04:31:29.078748
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    secret_key = b'0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'
    secret_iv = b'123456789abcdef0123456789abcdef0'

# Generated at 2022-06-21 04:31:42.512621
# Unit test for function do_vault
def test_do_vault():
    unencrypted_data = 'foobar'
    secret = 'swordfish'
    salt = 'salt'
    vaultid = 'test_do_vault_id'
    wrap_object = True
    ciphertext = '$ANSIBLE_VAULT;1.1;AES256\n34306539643466386430333864353961613530663331353530656332653465613664416461a,' \
                 'aacabac8fa704faaacabac8fa704bc9baa12baa12baa12baa12baa12baa12baa12baa12baa12baa12baa12b\n'
    assert do_vault(unencrypted_data, secret, salt, vaultid, wrap_object) == ciphertext


# Generated at 2022-06-21 04:31:45.032407
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256", "test") == "test"

# Generated at 2022-06-21 04:31:58.751715
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_native
    from ansible.utils.display import Display
    display = Display()
    o = FilterModule()
    f = o.filters()
    secret = "gibberish"
    plaintext = "Hello World!"
    e = f['vault'](plaintext, secret, wrap_object=True)
    display.vvvv("Encrypted to: " + to_native(e.data))
    display.vvvv("Encrypted salt: " + to_native(e.salt))
    assert isinstance(e, AnsibleVaultEncryptedUnicode)
    assert e.data != plaintext
    display

# Generated at 2022-06-21 04:32:03.755937
# Unit test for function do_vault
def test_do_vault():
    data = 'Hello World'
    secret = 'secret'
    salt = 'salt'
    vault = do_vault(data, secret, salt)
    assert vault.startswith(b'$ANSIBLE_VAULT')


# Generated at 2022-06-21 04:32:07.216000
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-21 04:32:09.184369
# Unit test for function do_unvault
def test_do_unvault():

    ret = do_unvault('!vault |')
    assert ret == ''

# Generated at 2022-06-21 04:32:20.255167
# Unit test for function do_unvault
def test_do_unvault():
    secret = "password"
    vaultid = "dev"

# Generated at 2022-06-21 04:32:31.000720
# Unit test for function do_vault
def test_do_vault():
    secret = "secretPassword"
    data = "secretData"
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-21 04:32:33.163697
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-21 04:32:40.660570
# Unit test for function do_vault
def test_do_vault():
    vault_pass = "test_vault_pass"
    vault_pass2 = "test_vault_pass2"
    vault_id = "test_vault_id"
    vault_id2 = "test_vault_id2"
    non_vault_id = "test_non_vault_id"
    data = "Hello World!"
    salt = "abcdef"
    wrap_object = True

# Generated at 2022-06-21 04:32:44.877556
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:32:51.459745
# Unit test for function do_vault
def test_do_vault():
    secret = 'testsecret'
    data = 'testdata'
    salt = 'testsalt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-21 04:32:52.896752
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:32:53.800019
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-21 04:32:57.780118
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-21 04:33:01.350183
# Unit test for function do_unvault
def test_do_unvault():
    data = 'test123'
    secret = 'password'

    vault_encoded = do_vault(data, secret)
    assert isinstance(vault_encoded, string_types)
    plain_text = do_unvault(vault_encoded, secret)
    assert data == plain_text

# Generated at 2022-06-21 04:33:11.073516
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(
        '$ANSIBLE_VAULT;1.1;AES256;machine\r\n63336138636232353330663936333561643236633037336665393038356432643562663363\r\n6532656234386139643835376434363362313331300a323064373531323162313037373836\r\n61353734363532376236666132653938373833383262623134393064666436616661373635\r\n66646130666433366364\r\n',
        secret="password"
    ) == 'machine'



# Generated at 2022-06-21 04:33:22.332967
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    salt = 'young wombat'
    vaultid = 'filter_default'
    wrap_object = False

    v = do_vault(data, secret, salt, vaultid, wrap_object)
    assert v is not None
    assert isinstance(v, str) is True
    assert is_encrypted(v) is True

# Generated at 2022-06-21 04:33:33.315446
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    secret = "mysecret"
    salt = "salt"
    vaultid = "filter_default"
    wrap_object = False
    data = "mydata"


# Generated at 2022-06-21 04:33:34.343521
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert len(obj.filters()) > 0

# Generated at 2022-06-21 04:33:48.587639
# Unit test for function do_vault
def test_do_vault():
    # Secret string cannot be None
    assert do_vault('foo', None, salt=None, vaultid='filter_default', wrap_object=False)

    # Data cannot be None
    assert do_vault(None, 'hush', salt=None, vaultid='filter_default', wrap_object=False)

    # Data is type string
    assert do_vault('foo', 'hush', salt=None, vaultid='filter_default', wrap_object=False)

    # Data is type AnsibleVaultEncryptedUnicode
    assert do_vault(AnsibleVaultEncryptedUnicode(''), 'hush', salt=None, vaultid='filter_default', wrap_object=False)

    # Data is type Undefined

# Generated at 2022-06-21 04:33:56.032634
# Unit test for function do_vault
def test_do_vault():
    secret = 'dontlookatme'
    data = 'foo'
    salt = 'salty'
    vaultid = 'foo'

    ret = do_vault(data, secret, salt, vaultid)
    assert isinstance(ret, string_types)

# Generated at 2022-06-21 04:33:58.045577
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Call constructor of class FilterModule
    FM = FilterModule()


# Generated at 2022-06-21 04:33:59.465017
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:34:04.574806
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test for testing filters method of class FilterModule."""
    import sys
    import unittest
    from unittest.mock import MagicMock, patch

    class _Display(object):
        """A dummy class for Display class."""
        def __init__(self):
            self.verbosity = 0

    display = _Display()
    sys.modules['ansible.utils.display'] = display
    sys.modules['ansible.utils.display.Display'] = display
    sys.modules['ansible.module_utils.six'] = sys.modules['ansible.module_utils.six']
    sys.modules['ansible.parsing.yaml.objects'] = sys.modules['ansible.parsing.yaml.objects']

# Generated at 2022-06-21 04:34:06.532383
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert isinstance(module, FilterModule)



# Generated at 2022-06-21 04:34:10.545846
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()

    assert filters.get('vault') is do_vault
    assert filters.get('unvault') is do_unvault


# Generated at 2022-06-21 04:34:14.872531
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Constructor initialization
    test_class = FilterModule()

    # Constructor should return dict of functions
    assert isinstance(test_class.filters(), dict)


# Unit Test for vault()

# Generated at 2022-06-21 04:34:25.312866
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()

    assert 'unvault' in filters
    assert 'vault' in filters

    assert filters['vault'](1, 'secret') == 'U2FsdGVkX1+PCTRdcmB76w1yDnq7VuRNvMS2Q7VuFZ0='
    assert filters['vault'](None, 'secret') == ''
    assert filters['vault']('sometext', 'secret') == 'U2FsdGVkX19Lw/Hb8YOoDjvN/NX9ZHNd0xi4y4L2iGM='

# Generated at 2022-06-21 04:34:35.248828
# Unit test for function do_unvault
def test_do_unvault():
    import textwrap

# Generated at 2022-06-21 04:34:42.990102
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'ansible'
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible;;rD0aJMErJWyb+zwIYx0Kjg=='
    data = 'password'
    unvault = do_unvault(vault, secret)
    assert data == unvault


# Generated at 2022-06-21 04:34:54.482222
# Unit test for function do_unvault
def test_do_unvault():
    # Test case when the secret provided is a string
    assert do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256;fixtures4abf62cc87a14b2d8b90e858c9f43a87', secret='secret_pass', vaultid='test') == 'test'
    # Test case when the secret provided is an Undefined object
    assert isinstance(do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256;fixtures4abf62cc87a14b2d8b90e858c9f43a87', secret=Undefined, vaultid='test'), Undefined)
    # Test case when the secret is not provided

# Generated at 2022-06-21 04:34:57.167030
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''
       unit test for Method filters of class FilterModule
    '''
    filters = FilterModule().filters()
    # test method vault
    assert filters['vault'] == do_vault
    # test method unvault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:35:06.993967
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for method filters of class FilterModule """
    import os
    import tempfile
    import shutil
    import yaml

    def _init_env(home_dir, vault_id_file, vault_id_content):
        ''' Initialize environment variable HOME and create an ini file to set
            vault_id.
        '''
        os.environ['HOME'] = home_dir
        try:
            fd, filename = tempfile.mkstemp(prefix='ansible_test_')
            with open(filename, 'w') as fh:
                yaml.safe_dump(vault_id_content, fh)
        except:
            raise
        else:
            os.close(fd)
            shutil.move(filename, vault_id_file)


# Generated at 2022-06-21 04:35:16.696913
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'test_data'
    salt = None

# Generated at 2022-06-21 04:35:26.208555
# Unit test for function do_unvault

# Generated at 2022-06-21 04:35:32.693477
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters["vault"] is do_vault
    assert filters["unvault"] is do_unvault

# Generated at 2022-06-21 04:35:34.659525
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None


# Generated at 2022-06-21 04:35:38.692461
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    res = f.filters()
    assert "vault" in res
    assert "unvault" in res
    assert res["vault"] == do_vault


# Generated at 2022-06-21 04:35:42.357172
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    method = obj.filters()
    assert 'vault' in method
    assert 'unvault' in method


# Generated at 2022-06-21 04:35:46.111292
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:35:47.344378
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj=FilterModule()
    assert not obj.filters()


# Generated at 2022-06-21 04:35:48.520654
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Unit tests for function 'do_vault'

# Generated at 2022-06-21 04:35:49.713839
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:36:02.922121
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    import os
    import pytest
    secret = os.getenv('ANSIBLE_DUMMY_VAULT_SECRET')
    data = 'hello world'
    filter_env = Environment()
    filter_env.filters['vault'] = do_vault

    test_data = data

    expected_result = '$ANSIBLE_VAULT;1.1;AES256;dummy_vault_id;ec59e4954cfd983d0e62b47e9fff3147be3a8eb58748ccd2;'
    expected_result += 'e8d43c60e9f21e9c70d0f835e846516ae08f7c70e0da03d15cddfee0bf9a5712\nhello world'

   

# Generated at 2022-06-21 04:36:14.141549
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vaultid = "vaultid"
    salt = "salt"

    result = do_vault(data, secret, salt, vaultid)

    #result is a string starting with !vault |
    #so it is the vaulted data
    assert isinstance(result, string_types)
    assert result.startswith("$ANSIBLE_VAULT")

    #result is wrapped in AnsibleVaultEncryptedUnicode
    result = do_vault(data, secret, salt, vaultid, True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-21 04:36:18.608842
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
        }


# Generated at 2022-06-21 04:36:30.047736
# Unit test for function do_vault
def test_do_vault():

    input_arguments = [(None, 'password', 'salt'),
                        ('string_input', 'password', 'salt'),
                        ('string_input', 'password', 'salt', 'vaultid1'),
                        ('string_input', 'password', 'salt', 'vaultid1', True)]


# Generated at 2022-06-21 04:36:41.880489
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:52.423527
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:09.189690
# Unit test for function do_vault

# Generated at 2022-06-21 04:37:21.550606
# Unit test for function do_vault

# Generated at 2022-06-21 04:37:30.761273
# Unit test for function do_unvault
def test_do_unvault():
    # Type test
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:37:36.493781
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert hasattr(filter_module, 'filters')
    filters = filter_module.filters()
    assert type(filters) == dict
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:37:42.284077
# Unit test for function do_vault
def test_do_vault():
    secret = "testkey"
    data = "\nfoo: bar\n"
    result = do_vault(data, secret, "")
    assert "(encryption key vaultid filter_default)\n" in result



# Generated at 2022-06-21 04:37:50.781912
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(
        u'foo',
        u'password',
        u'89e8b9e9f9d9a3a3',
        u'test_vault',
        wrap_object=True
    ) == AnsibleVaultEncryptedUnicode(
        u'$ANSIBLE_VAULT;1.1;AES256;test_vault\n63643761316665653531333762376232326362343762323731376139313137303738663833366638\n6361623639373132326137306661663336663739343638363136626539376636353765643135633665\n3130'
    )


# Generated at 2022-06-21 04:37:55.136823
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:57.988191
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'vault', 'unvault'} == set(FilterModule().filters())


# Generated at 2022-06-21 04:38:06.299113
# Unit test for function do_unvault
def test_do_unvault():

    test_vault = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;ansible\r\n326664376537326233396233663666615631373462313761653863336539376232396639643861\r\n653035653034363530626565663038626261343066393762366532383066656364626262633035\r\n3631613137333639333264616533\r\n")
    test_vault.vault = VaultLib([('filter_default', VaultSecret("FOO"))])

    secrets = {
        'bar': VaultSecret("bar"),
        'foo': VaultSecret("foo"),
    }


# Generated at 2022-06-21 04:38:07.806118
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-21 04:38:33.305858
# Unit test for function do_vault
def test_do_vault():
    secret = "test_secret"
    data = "test"
    vault = do_vault(data, secret)

    assert vault == "$ANSIBLE_VAULT;1.1;AES256\n3938333534376665636334636623165623237336535653331333134313863376165323531653264\n66643139386632352d316430642d343835372d383964312d326539353764663630646635313961\n62063535626133313130623563356463353062363962366362386339386133366265383534366b", \
            "Vault mismatch"

# Generated at 2022-06-21 04:38:44.138065
# Unit test for function do_unvault
def test_do_unvault():
    vault = '$ANSIBLE_VAULT;1.1;AES256\n63613234357265623631373463663566396461373836333262623732386236373865383065333137\n3430623163396237303939356662316536303433353831636161363165613861333132626238313731\n3934633232396232626266623831303863303665373832333739363733366435633566393737333333\n663565383438303831393665343637\n'

    secret = 'test-secret'

    expected_output = 'test-string'

    print('#####################################################################################')

# Generated at 2022-06-21 04:38:55.005508
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    import jinja2
    from jinja2 import Template
    from jinja2.runtime import  Undefined
    import sys
    import tempfile
    import os
    display.verbosity = 1

    password = 'secret'
    salt = 'salt'
    vaultid = 'my_mypass'
    data = 'data'

# Generated at 2022-06-21 04:38:56.964368
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')


# Generated at 2022-06-21 04:39:06.346982
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = 'test_secret_data'
    secret = 'test_secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    vault_data_filter = do_vault(data, secret, salt, vaultid, wrap_object)
    vault_data_obj = AnsibleVaultEncryptedUnicode(vault_data_filter)
    assert(do_unvault(vault_data_filter, secret, vaultid) == data)
    # Test with salt
    salt = 'salt'
    vault_data_filter = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-21 04:39:17.160137
# Unit test for function do_vault
def test_do_vault():
    secret = 'hunter2'

    # Test: Encrypting a string
    data = 'foo'
    vault = do_vault(data, secret)
    assert is_encrypted(vault) is True

    # Test: Encrypting a unicode object
    data = 'bar'
    vault = do_vault(u'%s' % data, secret)
    assert is_encrypted(vault) is True

    # Test: Encrypting an AnsibleVaultEncryptedUnicode
    data = 'baz'
    vault = do_vault(AnsibleVaultEncryptedUnicode(data), secret)
    assert is_encrypted(vault) is True

    # Test: Encrypting an Undefined variable
    vault = do_vault(Undefined('UndefinedTest'), secret)

# Generated at 2022-06-21 04:39:26.598593
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # test vault filter
    secret = "my_s3cr3t"
    data = "my_d4t4"

    vault = filters["vault"](data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert do_unvault(vault, secret) == data

    vault = filters["vault"](data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault != data
    assert do_unvault(vault, secret) == data

    # test unvault filter
    unvault = filters["unvault"](vault, secret)
    assert unvault == data
    assert isinstance(unvault, string_types)


# Generated at 2022-06-21 04:39:31.174310
# Unit test for function do_vault
def test_do_vault():
    ansible_secret = 'fake secret'
    salt = 'fake salt'
    vaultid = 'fake vaultid'
    data = 'fake data'
    wrap_object = False

    assert do_vault(data, ansible_secret, salt, vaultid, wrap_object)



# Generated at 2022-06-21 04:39:41.896831
# Unit test for function do_unvault
def test_do_unvault():
    vaultid = 'test_id'
    secret = "super_secret"

    unencrypted_text = "Text to be encrypted"
    encrypted_text = do_vault(unencrypted_text, secret, vaultid=vaultid)

    decrypted_text = do_unvault(encrypted_text, secret, vaultid=vaultid)

    print("Encrypted text: " + encrypted_text)
    print("Decrypted text: " + decrypted_text)

    assert(unencrypted_text == decrypted_text)


# Generated at 2022-06-21 04:39:43.315045
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Execute the constructor of class FilterModule
    FilterModule()
