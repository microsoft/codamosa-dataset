

# Generated at 2022-06-21 04:29:50.828679
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'vault' in f.filters()
    assert 'unvault' in f.filters()



# Generated at 2022-06-21 04:29:52.324302
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test for a positive result
    fm = FilterModule()
    assert isinstance(fm, FilterModule)


# Generated at 2022-06-21 04:30:03.191909
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = "test_secret"

# Generated at 2022-06-21 04:30:04.632579
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-21 04:30:06.741195
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test to validate the constructor
    assert FilterModule().filters()

# Generated at 2022-06-21 04:30:12.159205
# Unit test for function do_vault
def test_do_vault():
    try:
        do_vault({}, None, None)
    except Exception as e:
        assert 'Secret passed is required to be a string' in str(e)
    else:
        assert False, 'Filter "vault" did not throw expected error'


# Generated at 2022-06-21 04:30:16.987193
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for the method filters of the class FilterModule '''

    assert do_vault("test_vault", "test_secret") == "test_vault"

# Generated at 2022-06-21 04:30:19.540150
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ans_filt_mod = FilterModule()
    assert ans_filt_mod is not None

# Generated at 2022-06-21 04:30:23.037022
# Unit test for function do_vault
def test_do_vault():
    secret = 'hello'
    data = 'world'
    vault = do_vault(data, secret)
    assert vault is not None
    assert vault != data
    assert is_encrypted(vault)
 


# Generated at 2022-06-21 04:30:24.846886
# Unit test for function do_vault
def test_do_vault():
    pass

# Generated at 2022-06-21 04:30:35.030011
# Unit test for function do_vault
def test_do_vault():
    secret = 'myvaultsecret'
    data = "foobar"
    vault = ''

    try:
        vault = do_vault(data, secret)
    except Exception as e:
        assert False, "Unexpected Exception(%s). When vaulting a string, we expected a string in return." % to_native(e)
    else:
        assert isinstance(vault, string_types)

    try:
        vault = do_vault(2, secret)
    except AnsibleFilterError as e:
        assert True, "Expected(%s), Got(%s)" % (AnsibleFilterTypeError, type(e))
    except AnsibleFilterTypeError as e:
        assert True

# Generated at 2022-06-21 04:30:48.205999
# Unit test for function do_vault
def test_do_vault():
    # Test 1: successful execution
    assert is_encrypted(do_vault('testdata', 'testsecret'))

    # Test 2: Secret argument is not a string
    try:
        do_vault('testdata', 1)
        assert False
    except AnsibleFilterTypeError:
        assert True

    # Test 3: Data argument is not a string
    try:
        do_vault(1, 'testsecret')
        assert False
    except AnsibleFilterTypeError:
        assert True

    # Test 4: Salt argument is not a string
    try:
        do_vault('testdata', 'testsecret', 1)
        assert False
    except AnsibleFilterTypeError:
        assert True

    # Test 5: No error is thrown if Undefined is passed as argument

# Generated at 2022-06-21 04:30:59.303311
# Unit test for function do_unvault

# Generated at 2022-06-21 04:31:01.271209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert do_vault('VaultMe', 'mypass')

# Generated at 2022-06-21 04:31:08.071779
# Unit test for function do_vault
def test_do_vault():
    ''''
    Unit test for function do_vault

    :return: None
    '''
    # All 8 tests are expected to succeed

# Generated at 2022-06-21 04:31:15.491352
# Unit test for function do_vault
def test_do_vault():
    # Positive test cases
    filter_vault = do_vault('secret', 'secret', salt='Saltsalt')

# Generated at 2022-06-21 04:31:21.699679
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert len(filters.keys()) == 2
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:31:25.016177
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters=FilterModule().filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:31:26.804900
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    return fm.filters()

# Generated at 2022-06-21 04:31:29.364662
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:31:34.245722
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        fm = FilterModule()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-21 04:31:35.861558
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-21 04:31:44.472257
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import __main__ as main

    # create the object
    filter_obj = FilterModule()

    # create a dict to save the filters
    func_name = {}

    # save filter inside dict
    for name in filter_obj.filters():
        func_name[name] = filter_obj.filters()[name]

    # The set of filters to test

# Generated at 2022-06-21 04:31:48.821862
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    result = module.filters()
    assert result is not None
    assert 'vault' in result
    assert 'unvault' in result
    assert type(result['vault']) is type(do_vault)
    assert type(result['unvault']) is type(do_unvault)



# Generated at 2022-06-21 04:32:00.143329
# Unit test for function do_vault
def test_do_vault():

    # Test 1: String filter
    secret = 'test'
    data = 'test_data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types), "test_do_vault: Test 1 test_vault is not a string"
    assert '$ANSIBLE_VAULT' in vault, "test_do_vault: Test 1 test_vault is not a valid vault string"

    # Test 2: String filter with salt
    secret = 'test'
    data = 'test_data'
    salt = 'test_salt'
    vault = do_vault(data, secret, salt)

    assert isinstance(vault, string_types), "test_do_vault: Test 2 test_vault is not a string"
    assert '$ANSIBLE_VAULT' in vault

# Generated at 2022-06-21 04:32:02.231785
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None

# Generated at 2022-06-21 04:32:06.770823
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:32:09.841187
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters().keys() == ['vault', 'unvault']


# Generated at 2022-06-21 04:32:14.393318
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:32:15.271240
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:32:24.442916
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    # Test case 1: filters
    result = fm.filters()
    assert isinstance(result, dict)
    assert result['vault'] == do_vault
    assert result['unvault'] == do_unvault



# Generated at 2022-06-21 04:32:27.809879
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'].__name__ == 'do_vault'
    assert filters['unvault'].__name__ == 'do_unvault'


# Generated at 2022-06-21 04:32:36.472742
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    f = FilterModule()
    assert isinstance(f.filters(), dict)
    # default value for secret is None
    assert f.filters()['vault']('foo', None) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62303436393837393036363231333038356261363534323832333866353235396365626132623036\n          30393637383638306535626365333064313035336635346163336232626431646436303964646231\n          6162626237333566326433616339623336316436\n'

# Generated at 2022-06-21 04:32:49.777693
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os

    fm = FilterModule()
    secret = "secret"
    data = "data"
    vault = fm.filters()['vault'](data, secret)
    result = fm.filters()['unvault'](vault, secret)

    assert result == data
    assert is_encrypted(vault)

    vault = fm.filters()['vault'](data, secret, wrap_object=True)
    result = fm.filters()['unvault'](vault, secret)

    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert result == data

    # Test if trying to vault

# Generated at 2022-06-21 04:32:52.256428
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-21 04:33:00.610799
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    import pytest

    # Unit test for function unvault_error1

# Generated at 2022-06-21 04:33:02.622025
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:33:05.226047
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert filters['vault'] is do_vault
    assert filters['unvault'] is do_unvault


# Generated at 2022-06-21 04:33:09.434186
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule().filters()
    assert o.get('vault') is do_vault
    assert o.get('unvault') is do_unvault
    assert len(o) == 2


# Generated at 2022-06-21 04:33:21.836625
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils import display as ansible_display
    from ansible.module_utils._text import to_native, to_bytes

    vault_secret = 'test'
    test_vault = VaultSecret(to_bytes(vault_secret))

    unvault_data = "test test"
    vlib = VaultLib([('test', test_vault)])

    result = vlib.encrypt(unvault_data, test_vault, 'test', None)
    result = AnsibleVaultEncryptedUnicode(result)

    ansible_display.Display.display(result)

    assert do

# Generated at 2022-06-21 04:33:46.917866
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    data = "value"
    vaultid = 'jhgjh'
    salt = None
    wrap_object = False
    output = do_vault(data, secret, salt, vaultid, wrap_object)
    # Use vault.py --encrypt-string "value" to get this value

# Generated at 2022-06-21 04:34:01.498061
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted
    test_data = """
        data:
          key: value
        """
    secret = "pass"
    vaultid = vaultid="filter_default"
    wrap_object = True
    vault = do_vault(test_data, secret, wrap_object=wrap_object)
    assert is_encrypted(vault)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault is not None
    assert vault.vault.secrets[vaultid].secret is secret
    assert vault.data == test_data

# Generated at 2022-06-21 04:34:13.378236
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'

    data = {
        'default': 'default',
        'str': 'str',
        'int': 10,
        'float': 3.14,
        'list': ['a', 'b', 1, 2],
        'dict': {'a': 'A', 'b': 'B', 'c': 'C'}
    }


# Generated at 2022-06-21 04:34:21.308867
# Unit test for function do_unvault
def test_do_unvault():
    # valid inputs
    secret = 'secretvalue\n'

# Generated at 2022-06-21 04:34:25.442590
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    instance = FilterModule()
    assert instance.filters() == {'unvault': do_unvault, 'vault': do_vault}


# Generated at 2022-06-21 04:34:31.901961
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert do_vault("test_data","test_secret") is not None
    assert do_unvault("AQAATgBNAA0AEgBBAEEAMQA0ADkAYQBzAGQAZQByAGEAZABlAGQAAwAIAAAAAAAABAAEAAAAwMDAAAAAA==","test_secret") is not None


# Generated at 2022-06-21 04:34:40.589255
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "test_data"
    vault = do_vault(data, secret)
    assert vault == "$ANSIBLE_VAULT;1.1;AES256\n6131353135323339323134313230630a34363630653365323936323336616232653466666535383\n3938333835303533383766656566663761306463616233390a6361313637343635653937333037\n633265663663326466353835663738333839626461653135313531353135313531353135313531\n313531353135313531\n"


# Generated at 2022-06-21 04:34:48.968381
# Unit test for function do_vault
def test_do_vault():
    secret = "I am top secret"
    salt = "I am salt"
    data = "Hi everyone"

    # Check the encrypted vault output
    expected_vault = b'$ANSIBLE_VAULT;3.4.0;AES256\n3966313033303637316231363633636333437373835343062323332626631633231366231373066\n39656564343332313865333464373635376634666661653935646665656432313165323437373430\n36373061\n'

    vault = do_vault(data, secret, salt, vaultid='test_vaultid')
    assert vault == expected_vault

    # Check the decrypted vault output

# Generated at 2022-06-21 04:34:55.034140
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultEditor
    ed = VaultEditor(4, False)
    unvaulted = ed.decrypt(ed.encrypt('test'))
    assert unvaulted == 'test'

# Generated at 2022-06-21 04:35:06.087087
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_text
    import pytest
    from ansible.module_utils.compat.ipaddress import (
        IPv4Address,
    )

    # Test secret is required to be a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault('secret', 123)

    # Test data is required to be a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(123, 'secret')

    # Test secret is required to be a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault('secret', 123)

    # Test data is required to be a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(123, 'secret')

# Generated at 2022-06-21 04:35:34.220223
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import is_encrypted, VaultSecret
    import pytest
    vs = VaultSecret('test_secret')
    data = 'test data'
    vault = do_vault(data, 'test_secret')
    assert is_encrypted(vault)

    # Test for error if wrong input types are passed.
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(None, 'test_secret')

    with pytest.raises(AnsibleFilterTypeError):
        do_vault('test_data', None)

    # Test for error if invalid secret is passed.
    with pytest.raises(AnsibleFilterError):
        # Trying to use a secret that is different than the one used to encrypt.
        vs = VaultSecret('test_secret2')
       

# Generated at 2022-06-21 04:35:38.518703
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:35:42.611069
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # execute method
    instance = FilterModule()
    result = instance.filters()
    assert isinstance(result, dict)
    assert "vault" in result
    assert "unvault" in result


# Generated at 2022-06-21 04:35:48.746952
# Unit test for function do_vault
def test_do_vault():
    from ansible.plugins.filter.vault import do_vault
    vault_secret = "vault"
    data = "mystring"
    if data == do_unvault(do_vault(data, vault_secret, wrap_object=False), vault_secret):
        assert True
    else:
        assert False


# Generated at 2022-06-21 04:35:51.189291
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fixture = FilterModule()
    assert fixture.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:35:56.233069
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    result = f.filters()
    assert(result['vault'].__name__ == 'do_vault')
    assert(result['unvault'].__name__ == 'do_unvault')


# Generated at 2022-06-21 04:36:06.104376
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # A FilterModule whose filters are to be tested
    filter_module = FilterModule()

    # The filters of the FilterModule
    filters = filter_module.filters()

    # Test the vault filter
    vault = filters['vault']
    secret = 'secret'
    data = 'data'
    vaulted = vault(data, secret)
    assert type(vaulted) is str

    # Test the unvault filter
    unvault = filters['unvault']
    secret = 'secret'
    unvaulted = unvault(vaulted, secret)
    assert type(unvaulted) is str

    # Test that unvault works on AnsibleVaultEncryptedUnicode objects
    unvaulted = unvault(AnsibleVaultEncryptedUnicode(vaulted), secret)
   

# Generated at 2022-06-21 04:36:12.631120
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()["vault"] == do_vault, "FilterModule.filters returns wrong function for vault filter name"
    assert fm.filters()["unvault"] == do_unvault, "FilterModule.filters returns wrong function for unvault filter name"

# Generated at 2022-06-21 04:36:26.228962
# Unit test for function do_vault
def test_do_vault():
    # Ensure that do_vault raises a filter error on an empty secret string
    try:
        do_vault('some-data', '')
    except AnsibleFilterError:
        pass

    # Ensure that do_vault raises a filter error on an empty secret list
    try:
        do_vault('some-data', [])
    except AnsibleFilterError:
        pass

    # Ensure that do_vault raises a filter error on an empty secret dict
    try:
        do_vault('some-data', {})
    except AnsibleFilterError:
        pass

    # Ensure that do_vault raises a filter error on a empty secret
    try:
        do_vault('some-data')
    except AnsibleFilterError:
        pass

    # Ensure that do_vault raises a filter error if an empty data is passed

# Generated at 2022-06-21 04:36:27.608173
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:37:07.207574
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    string = 'This is not a secret'
    vault_string = do_vault(string, secret)
    assert vault_string != string
    assert vault_string.startswith('$ANSIBLE_VAULT;')
    assert len(vault_string) > len(string)

    vault_string = do_vault(string, secret, wrap_object=True)
    assert vault_string.startswith('$ANSIBLE_VAULT;')
    assert len(vault_string) > len(string)



# Generated at 2022-06-21 04:37:22.943724
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:31.710013
# Unit test for function do_unvault
def test_do_unvault():
    secret = u'password'
    vault = u'$ANSIBLE_VAULT;1.2;AES256;default\n30373936636263323763396663333939376562346632303435303633303634663537336361306135\n62646464633339653565336331653239386162616636363366383133663637613361353932623264\n63346334306564343563643839396164376535333332623963316165663237343065326938353637\n39396264653337306137613236646236623339636536373562336266353937363165326162333865\n303964\n'
    do_unvault(vault, secret)

# Generated at 2022-06-21 04:37:39.895114
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Arrange and Act
    ansible_vault_filters = FilterModule()
    filters = ansible_vault_filters.filters()

    # Assert
    assert len(filters) == 2
    assert filters["vault"] is do_vault
    assert filters["unvault"] is do_unvault



# Generated at 2022-06-21 04:37:50.642660
# Unit test for function do_vault
def test_do_vault():
    data = 'this is a test'
    salt = 'na'
    secret = 'sljflsfjslfjslfjdlfjl'
    vaultid = 'test_vault_id'

    wrapped = do_vault(data, secret, salt, vaultid, True)
    unwrapped = do_vault(data, secret, salt, vaultid, False)
    assert type(wrapped) == AnsibleVaultEncryptedUnicode
    assert type(unwrapped) == str

    # identical input, wrapping or not, will produce identical output
    assert wrapped.vdata == unwrapped

    # the vaulted output, with salt, secret, and vaultid, is deterministic

# Generated at 2022-06-21 04:37:54.893418
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()

# Generated at 2022-06-21 04:38:05.421338
# Unit test for function do_unvault
def test_do_unvault():
    "Test call to do_unvault"
    from ansible import context
    from ansible.plugins.loader import filters_loader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    #from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import tempfile
    import os
    import re

    context._init_global_context(dict(CONFIG_FILE=C.CONFIG_FILE))

    # Load the data loader
    loader = DataLoader()

# Generated at 2022-06-21 04:38:10.622428
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n0t1r7vh8rty0", "mysecret", "myid") == ""


# Generated at 2022-06-21 04:38:20.140673
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:21.881079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:38:48.909737
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:38:52.117736
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert(filter_module.filters() == {'vault': do_vault, 'unvault': do_unvault})


# Generated at 2022-06-21 04:38:56.021987
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() != None


# Generated at 2022-06-21 04:39:01.559628
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    log = display.get_log()
    temp_FilterModule = FilterModule()
    filters_results = temp_FilterModule.filters()

    assert log is None
    assert filters_results.keys() == {'vault', 'unvault'}


# Generated at 2022-06-21 04:39:09.464332
# Unit test for function do_vault
def test_do_vault():
    secret = "foo"

    # Test that string is correctly vaulted
    assert do_vault("bar", secret) == '$ANSIBLE_VAULT;1.1;AES256\n306331353362313635633864353738646636363335386161663737643830386236626164323134\n373831656133653464333861333139623163643236323533626435326332623334616361383239\n336334\n'

    # Test that number is correctly vaulted

# Generated at 2022-06-21 04:39:18.560824
# Unit test for function do_unvault

# Generated at 2022-06-21 04:39:25.867083
# Unit test for function do_vault
def test_do_vault():
    secret = 'test secret'
    data = 'test 123'
    vaultid = 'test_vault_id'

    vault = do_vault(data, secret, vaultid=vaultid, wrap_object=True)

    assert vault.vault_secret == secret
    assert vault.vault_id == vaultid
    assert vault.data == data

    # assert that we can unwrap the object
    assert vault.unwrap() == data

    # assert that we can unwrap the object in template mode
    assert vault == data

    # assert that we can unwrap the object in template mode
    assert vault.data == data

# Generated at 2022-06-21 04:39:29.137332
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-21 04:39:31.951209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:39:44.038918
# Unit test for function do_unvault