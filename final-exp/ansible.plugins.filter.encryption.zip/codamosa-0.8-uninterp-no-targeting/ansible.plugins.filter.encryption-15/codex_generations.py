

# Generated at 2022-06-21 04:29:56.243726
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm.filters()

# Generated at 2022-06-21 04:30:02.690804
# Unit test for function do_vault
def test_do_vault():
    x = "this is a test"
    key = "my secret"
    salt = "salt"
    x_enc = do_vault(x, key, salt)
    x_dec = do_unvault(x_enc, key)
    assert x == x_dec

# Generated at 2022-06-21 04:30:14.287169
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:15.587280
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-21 04:30:19.087615
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with different valid inputs
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}



# Generated at 2022-06-21 04:30:20.485882
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None



# Generated at 2022-06-21 04:30:27.561670
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Initialization of the object
    ansible_vault_filter_module = FilterModule()

    # Retrieve the filters from the object
    filters = ansible_vault_filter_module.filters()

    # Check the filters exist
    assert 'vault' in filters
    assert 'unvault' in filters

    # Optional: create a mock filter object
    class MockFilter:
        def __init__(self):
            return None

    # Create a mock filter
    vault_filter = MockFilter()

    # Mock the filters method retuns the mock filter object
    ansible_vault_filter_module.filters = Mock(return_value=vault_filter)

    # Invoke the method filters of the object
    filters = ansible_vault_filter_module.filters()

    # Verify if the method filters was invoked
   

# Generated at 2022-06-21 04:30:28.372698
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-21 04:30:30.523820
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()

    if not filterModule.filters():
        raise Exception("{}".format("No filters found in FiltersModule!"))


# Generated at 2022-06-21 04:30:34.424820
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule.filters)
    f = FilterModule()
    assert callable(f.filters)
    filters = f.filters()
    assert "vault" in filters
    assert callable(filters["vault"])
    assert "unvault" in filters
    assert callable(filters["unvault"])



# Generated at 2022-06-21 04:30:37.611753
# Unit test for constructor of class FilterModule
def test_FilterModule():

    fake = FilterModule()
    assert fake.filters is not None


# Generated at 2022-06-21 04:30:40.402407
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fltrs = FilterModule()
    ret = fltrs.filters()
    print(ret)

# Generated at 2022-06-21 04:30:44.202138
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()['vault'] is do_vault
    assert FilterModule().filters()['unvault'] is do_unvault


# Generated at 2022-06-21 04:30:50.940669
# Unit test for function do_unvault
def test_do_unvault():
    # Test without vaultid
    vault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          39373533663937353166393162346335613436633033626332306161636337346665363061626665\n          30633863323436366562356631633161363337303631616334613861323237386630333866653865\n          39663339393931663865336337653466653563303934376535303337363738393530663637613031\n          643132343764613761342b30383334323337646664396565366265\n          "
    secret = "secret"

# Generated at 2022-06-21 04:31:03.471171
# Unit test for function do_unvault
def test_do_unvault():
    sample_vault = b'$ANSIBLE_VAULT;1.1;AES256\n6332396563643531323161363863346334316230383738643537666437303963623561323138633861\n3038333839653332396332316662633035663335376630343636393534333062626130663639363163\n3865666234646639333066656563376361336939306132626130663639363163306365643431386164\n3136613364656630353637396330363039656336336537643433376139373765393833653066343536\n6334336661333436\n'
    sample_vault_

# Generated at 2022-06-21 04:31:08.012031
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:31:09.436772
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule


# Generated at 2022-06-21 04:31:19.551845
# Unit test for function do_vault
def test_do_vault():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    result1 = do_vault('testdata', 'testsecret', 'testid', wrap_object=False)
    assert type(result1) == str
    # check if result contains dot
    assert '.' in result1
    # check if result contains id
    assert 'testid' in result1

    result2 = do_vault('testdata', 'testsecret', 'testid', wrap_object=True)
    assert type(result2) == AnsibleVaultEncryptedUnicode
    # check if result contains dot
    assert result2.startswith('$ANSIBLE_VAULT')
    # check if result contains id
    assert 'testid' in result

# Generated at 2022-06-21 04:31:29.800863
# Unit test for function do_unvault
def test_do_unvault():
    unvault_filter = FilterModule().filters().get('unvault')

    assert unvault_filter('$ANSIBLE_VAULT;1.1;AES256;filtertestid\n', 'filtersecret', 'filtertestid') == ''
    assert unvault_filter('$ANSIBLE_VAULT;1.1;AES256;filtertestid\nAAAAB3NzaC1yc2E_AAAA\n', 'filtersecret', 'filtertestid') == ''


# Generated at 2022-06-21 04:31:32.521492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    my_obj = FilterModule()
    assert isinstance(my_obj.filters(), dict)


# Generated at 2022-06-21 04:31:48.057559
# Unit test for function do_vault
def test_do_vault():
    filters = FilterModule().filters()
    data_1 = "Hello World"
    secret_1 = "secret"
    vault_object_1 = b'$ANSIBLE_VAULT;1.1;AES256\n33306436663735386164306434373335346630383136616561353330343366646433303464393338\n36366435376238626432646261386133383162346338623834383366326534653263623935636335\n34393538663033363832653539346238396365633664333036636163633134343036643961666331\n666435333464383063643965383737356564666335623633\n'
    vault_

# Generated at 2022-06-21 04:31:58.539054
# Unit test for function do_unvault
def test_do_unvault():

    try:
        do_unvault('$ANSIBLE_VAULT;1.1;AES256\n393761633538346433663664353065636233633639616262396436383534663565386639350a33326132383162363630353630323162316530363965373735663334393239313561310a3866333333366163636139303434323336333839306666343635656566366563653235\n', "test_secret")
    except AnsibleFilterError as e:
        assert False, "Unable to decrypt"
    else:
        print("Passed")

# Generated at 2022-06-21 04:32:02.300411
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert type(filters) == dict
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:32:11.755427
# Unit test for function do_vault
def test_do_vault():

    # Test string returned is encrypted
    assert is_encrypted(do_vault("secret", "password"))

    # Test if the returned vault is AnsibleVaultEncryptedUnicode
    assert isinstance(do_vault("secret", "password", wrap_object=True), AnsibleVaultEncryptedUnicode)

    # Test if the returned vault is AnsibleVaultEncryptedUnicode when salt is specified
    assert isinstance(do_vault("secret", "password", salt="anysalt", wrap_object=True), AnsibleVaultEncryptedUnicode)

    # Test if the returned vault is AnsibleVaultEncryptedUnicode when vaultid is specified
    assert isinstance(do_vault("secret", "password", vaultid="filter_tests", wrap_object=True), AnsibleVaultEncryptedUnicode)

    #

# Generated at 2022-06-21 04:32:20.922446
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:32:31.580578
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n62343332643264336437313064336531656437313137643534336436376664386463313961346235\n65616431326137303636643832653462323264396365616262393963663861353766386439336534\n3965636334383638373436623431383533393731396638313136626664636335\n'

# Generated at 2022-06-21 04:32:35.703220
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_FilterModule = FilterModule()
    result = test_FilterModule.filters()
    assert result == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:32:37.149422
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()
    assert 'vault' in filters


# Generated at 2022-06-21 04:32:49.819862
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    class VaultString(AnsibleBaseYAMLObject):
        def __init__(self, data):
            self.data = data

    test_passwd = 'test_passwd'
    test_fixture = 'test_fixture'
    test_fixture_do_unvault_output = 'test_do_unvault_output'
    test_fixture_vault_id = 'test_vault_id'
    test_fixture_vault_id_2 = 'test_vault_id_2'
    test_fixture_salt = 'test_salt'
    #

# Generated at 2022-06-21 04:32:50.570026
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, object)

# Generated at 2022-06-21 04:33:03.368405
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    import inspect
    import sys
    import os

    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))))

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    t = FilterModule()
    assert 'vault' in t.filters()
    assert 'unvault' in t.filters()

    # Test for vault filter
    test_secret = 'test_secret'

    test_data = 'test_data'

# Generated at 2022-06-21 04:33:13.059027
# Unit test for function do_unvault
def test_do_unvault():
    # Import is here because we need to test the real unvault function, not the
    # mocked one by test I pass through.

    data = 'TEST'
    secret = 'TEST'

# Generated at 2022-06-21 04:33:16.873016
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:33:20.608964
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:33:32.710548
# Unit test for function do_unvault
def test_do_unvault():

    text = "this\nis\na\nstring"
    passwd = "vault"
    vaultid = "filter_default"

# Generated at 2022-06-21 04:33:44.457531
# Unit test for function do_vault

# Generated at 2022-06-21 04:33:46.228761
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:33:53.571554
# Unit test for function do_vault
def test_do_vault():
    expected_vault = u'$ANSIBLE_VAULT;1.1;AES256;myvaultid\n3963366766583936386532633961356438636435363536396332386535343666643663632386436\n6135306635303439643330346333303635643162323663626363386338656430613032646534656\n626165303533363932646332643630616134\n'

    assert expected_vault == do_vault(u'SuperSecretText', 'mysecretpassword', vaultid='myvaultid')


# Generated at 2022-06-21 04:34:04.809476
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:15.419460
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.parsing.vault import VaultSecret

    with pytest.raises(AnsibleFilterTypeError) as info:
        do_vault(31337,VaultSecret('sekrit'),None,'filter_default')
    with pytest.raises(AnsibleFilterTypeError) as info:
        do_unvault(VaultSecret('sekrit'),'sekrit',None)


# Generated at 2022-06-21 04:34:18.348311
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:34:31.542577
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:32.867062
# Unit test for function do_vault
def test_do_vault():
    ret = do_vault('test', 'password')
    assert is_encrypted(ret)



# Generated at 2022-06-21 04:34:42.645585
# Unit test for function do_unvault
def test_do_unvault():
    f = open('test_data.txt', 'rt')
    test_data = f.read()
    f.close()

    f = open('test_vault.txt', 'rt')
    test_vault = f.read()
    f.close()

    f = open('test_data_no_vault.txt', 'rt')
    test_data_no_vault = f.read()
    f.close()

    f = open('test_vault_ansible_vault.txt', 'rt')
    test_vault_ansible_vault = f.read()
    f.close()

    secret_1 = 'test'
    f = FilterModule()
    assert f.filters()['do_unvault'](test_data, secret_1) == 'test'
    assert f.fil

# Generated at 2022-06-21 04:34:45.536246
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("test FilterModule")
    print("test filters: ", FilterModule().filters())


# Generated at 2022-06-21 04:34:47.657419
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print('Dummy test case for FilterModule.filters')
    pass

# Generated at 2022-06-21 04:34:49.520806
# Unit test for constructor of class FilterModule
def test_FilterModule():
    _filter = FilterModule()
    _filter.filters()
    assert True

# Generated at 2022-06-21 04:34:52.541554
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters.keys() == ['vault', 'unvault']


# Generated at 2022-06-21 04:34:53.865895
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule



# Generated at 2022-06-21 04:34:57.919194
# Unit test for function do_unvault
def test_do_unvault():
    vault = do_vault("mysecret", "mysecret")
    assert do_unvault(vault, "mysecret") == "mysecret"

# Generated at 2022-06-21 04:35:10.573139
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters, "filter 'vault' not found"
    assert 'unvault' in filters, "filter 'unvault' not found"
    assert filters['vault'] == do_vault, "vault filter function not found"
    assert filters['unvault'] == do_unvault, "unvault filter function not found"

# Generated at 2022-06-21 04:35:18.025643
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'mysecret'

# Generated at 2022-06-21 04:35:26.716802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    f_do_vault = fm.filters()['vault']
    f_do_unvault = fm.filters()['unvault']

    # Test for function do_vault
    f_do_vault("string_to_encrypt", "secret", "salt")
    f_do_vault("string_to_encrypt", "secret", "salt", wrap_object=True)

    # Test for function do_unvault
    f_do_unvault("string_to_decrypt", "secret")
    av_unvault = AnsibleVaultEncryptedUnicode("string_to_decrypt")
    av_unvault.vault = VaultLib()
    f_do_unvault(av_unvault, "secret")

# Generated at 2022-06-21 04:35:31.035763
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    res = filter.filters()
    assert(res and 'vault' in res)
    assert(res and 'unvault' in res)


# Generated at 2022-06-21 04:35:38.205870
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    result = FilterModule.filters(FilterModule())
    assert result == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:35:48.796645
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_text

    res = do_vault('secret', 'password')

# Generated at 2022-06-21 04:35:59.219529
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n35346535616637666532303465663265386437666162333133663735353633303130326136383964\n34663635336431626330643162363864316666386431623431663831303066363165646565353666\n34393835323665346564\n', 'secret',) == "this is a test\n"


# Generated at 2022-06-21 04:36:01.801526
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters

# Generated at 2022-06-21 04:36:03.676863
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vf = FilterModule()
    assert vf != None


# Generated at 2022-06-21 04:36:10.609472
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"
    test_data = "Test Data 123"
    vault = do_vault(test_data, secret)
    display.display(vault)
    result = do_unvault(vault, secret)
    assert result == test_data

# Generated at 2022-06-21 04:36:17.855350
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert issubclass(FilterModule, object)

# Generated at 2022-06-21 04:36:23.525939
# Unit test for function do_vault
def test_do_vault():
    secret = "foo"
    data = "secret"
    vault = do_vault(data, secret)
    assert is_encrypted(to_bytes(vault))
    assert do_unvault(vault, secret) == "secret"

# unit test for function do_unvault

# Generated at 2022-06-21 04:36:36.335489
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  from ansible.module_utils.six import PY2
  from ansible.module_utils.six.moves import range
  import jinja2

  def check_vault(d, s, w):
    o = do_vault(d, s, wrap_object=w)

    # Test PY2
    if PY2:
        assert type(o) is jinja2.runtime.Undefined or \
               type(o) is unicode, \
               "we expected type unicode or Undefined, instead we got: %s" \
               % type(o)
    # Test PY3
    else:
        assert type(o) is jinja2.runtime.Undefined or \
               type(o) is str, \
               "we expected type str or Undefined, instead we got: %s"

# Generated at 2022-06-21 04:36:42.195195
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:36:43.758449
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()


# Generated at 2022-06-21 04:36:45.909689
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = FilterModule()
    assert a.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:36:51.109447
# Unit test for function do_vault
def test_do_vault():
    from ansible import context
    context._init_global_context(config=dict(vault_password_file="~/.ansible/vault~1",vault_salt_size=20))

# Generated at 2022-06-21 04:37:00.950420
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import configparser
    import os
    import tempfile

    # Create a temporary private key and new vault password
    (fd, pem_file) = tempfile.mkstemp()
    private_key = RSA.generate(2048, os.urandom)
    private_key_string = private_key.exportKey('PEM')
    f = os.fdopen(fd, "w")
    f.write(private_key_string)
    f.close()
    os.chmod(pem_file, stat.S_IRUSR)

    # Create a temporary config file to point to the private key
    (fd, vault_pwd) = tempfile.mkstemp()
    f = os.fdopen

# Generated at 2022-06-21 04:37:01.905707
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert(a)


# Generated at 2022-06-21 04:37:06.531225
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Unit test whether AnsibleVaultEncryptedUnicode object is returned
# when wrap_object flag is set to true in do_vault function

# Generated at 2022-06-21 04:37:23.748291
# Unit test for function do_unvault
def test_do_unvault():
    if not test_do_vault():
        return False
    # This includes the newline, $ANSIBLE_VAULT;, version_id, space, vault_id, and newline
    # (no salt, so no additional newline)
    vault_id = 'filter_default'
    vault_id_len = len(vault_id.encode('utf-8'))
    version_id = '1.1'
    version_id_len = len(version_id.encode('utf-8'))
    salt_len = 0
    secret = 'secret'
    secret_len = len(secret.encode('utf-8'))
    data_len = 100

# Generated at 2022-06-21 04:37:25.838130
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:37:32.937585
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:39.165320
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class test_FilterModule:
        def __init__(self):
            self.ansible = dict(version=dict(full='2.10.1'))

    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:37:42.314064
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:37:48.737345
# Unit test for function do_unvault
def test_do_unvault():
    ''' Test unvault function '''
    vault_id = 'bob'
    vault_secret = 'secret'
    vault_salt = 'salt'
    plain_text = 'This is plain text'

    # Encrypt plain text
    vault = do_vault(plain_text, vault_secret, salt=vault_salt)

    # Decrypt vaulted text
    assert do_unvault(vault, vault_secret, vaultid='bob') == 'This is plain text'



# Generated at 2022-06-21 04:37:52.116809
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # not testing any filters, just testing the constructor
    # of class FilterModule
    fm = FilterModule()
    assert fm

# Generated at 2022-06-21 04:37:55.904330
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()

    assert(filters['vault'])
    assert(filters['unvault'])



# Generated at 2022-06-21 04:37:57.862808
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_object = FilterModule()
    assert test_object.filters()

# Generated at 2022-06-21 04:38:01.826276
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:38:25.191453
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    data = 'test'
    salt = '0000000000000000'
    vault_id = 'test'
    wrap_object = False

# Generated at 2022-06-21 04:38:37.176407
# Unit test for function do_vault
def test_do_vault():
    data = {
        'any_vault_id': 'any_value',
        'other_vault_id': 'other_value'
    }
    secret = 'correct_secret'

    for vault_id in data:
        vault = do_vault(
            data[vault_id],
            secret,
            vault_id=vault_id,
            wrap_object=True
        )
        assert(vault.vault_id == vault_id)
        assert(vault.vault.secrets[vault.vault_id]['secret'] == secret)

        data_unvault = do_unvault(vault, secret, vaultid=vault_id)
        assert(data_unvault == data[vault_id])


# Generated at 2022-06-21 04:38:38.554981
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__name__ == 'FilterModule'

# Generated at 2022-06-21 04:38:43.440377
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myvaultid\n0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\n",
                     "secret", "myvaultid") == "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"

# Generated at 2022-06-21 04:38:47.717353
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-21 04:38:51.424824
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj.filters() == {'vault': do_vault,
                             'unvault': do_unvault}



# Generated at 2022-06-21 04:38:52.225497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    f.filters()

# Generated at 2022-06-21 04:38:55.452137
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # test successful construction of a FilterModule
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:38:56.890106
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:38:58.294364
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-21 04:39:31.009613
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret, wrap_object=False)
    assert vault is not None
    assert vault != ''
    assert vault != data



# Generated at 2022-06-21 04:39:43.713809
# Unit test for function do_vault
def test_do_vault():

    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.text.converters import to_text

    data = "test-data"
    secret = "secret"

    result = do_vault(data, secret)

    assert isinstance(result, str) is True
    test_vault = AnsibleVaultEncryptedUnicode(result)
    assert isinstance(test_vault.data, str) is True
    try:
        assert test_vault.decrypt(vault_secrets=[secret]) == "test-data"
    except Exception as e:
        assert False, "Unable to decrypt a successfully encrypted value: %s" % to_text(e)

    result = do_vault(data, secret, wrap_object=True)
   

# Generated at 2022-06-21 04:39:46.250552
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-21 04:39:48.672998
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() is not None



# Generated at 2022-06-21 04:39:50.010733
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()