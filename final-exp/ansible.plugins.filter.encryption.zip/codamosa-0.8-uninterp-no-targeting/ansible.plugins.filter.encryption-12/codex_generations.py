

# Generated at 2022-06-21 04:30:09.646816
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'my_secret'
    vaultid = 'filter_default'


# Generated at 2022-06-21 04:30:11.572160
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-21 04:30:17.728435
# Unit test for function do_unvault
def test_do_unvault():
    correct_value = 'foo'
    wrong_value = 'bar'
    secret = 'foo'
    vault = do_vault(correct_value, secret)
    assert do_unvault(vault, wrong_value) == 'bar'
    assert do_unvault(vault, secret) == correct_value


# Generated at 2022-06-21 04:30:25.659159
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.vault import is_encrypted

    # Dummy data
    cdata = 'test'
    secret = 'my_secret'
    vaultid = 'filter_default'
    vault_id_list = ['filter_default', 'default', 'my_secret']

    # Invoke function to test
    cipher = do_vault(cdata, secret, vaultid=vaultid)

    # Validate output
    assert isinstance(cipher, str) == True
    assert is_encrypted(cipher) == True
    assert secret not in cipher
    assert vaultid in cipher
    assert vaultid not in cipher

    # Invoke function to test

# Generated at 2022-06-21 04:30:27.240246
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True == isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:30:35.352195
# Unit test for function do_unvault
def test_do_unvault():
    # Set up a fake filter module
    filter_module = FilterModule()

    test_secret = 'test_secret'
    test_unencrypted_string = 'test_string'
    test_vaultid = 'filter_default'
    test_vault_object = AnsibleVaultEncryptedUnicode(do_vault(test_unencrypted_string, test_secret, vaultid=test_vaultid, wrap_object=True))

    # Test unvaulting a string
    assert filter_module.filters()['unvault'](test_unencrypted_string, test_secret, test_vaultid) == 'test_string'
    # Test unvaulting an encrypted string

# Generated at 2022-06-21 04:30:48.276350
# Unit test for function do_vault
def test_do_vault():
    vault = {
            'class': 'ansible_vault.VaultLib',
            'method': 'encrypt',
            'params': {
                'data': 'my secret data',
                'secret': 'my secret',
                'vaultid': 'filter_default',
                'wrap_object': True
            }
        }
    assert vault == do_vault('my secret data', 'my secret', vaultid='filter_default', wrap_object=True), 'test with vaultid option'
    assert vault != do_vault('my secret data', 'my secret', wrap_object=True), 'test without vaultid option'
    assert vault != do_vault('my secret data', 'my secret', vaultid='filter_default'), 'test without wrap_object option'

# Generated at 2022-06-21 04:30:59.360647
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """test FilterModule filters"""

    #
    # TEST vault filter
    #
    # test filter when data is a string
    data = 'Hello'
    secret = '1234'
    result = do_vault(data, secret)
    expected_result = '$ANSIBLE_VAULT;1.1;AES256\n65363635663065326663343836663561663763306339353630353662396163363032356262626\n23038353330653665663261383132626434653934623239633163623631646262393732\n'
    assert result == expected_result, f'result is {result}, not {expected_result} as expected'

    # test filter when data is a unicode string
    data = u'Hello'


# Generated at 2022-06-21 04:31:07.416915
# Unit test for function do_unvault

# Generated at 2022-06-21 04:31:15.032342
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    import sys
    test_module = sys.modules[__name__]
    if PY3:
        from unittest import mock
    else:
        import mock
    with mock.patch.object(test_module, 'AnsibleFilterTypeError', create=True) as mock1:
        with mock.patch.object(test_module, 'AnsibleFilterError', create=True) as mock2:
            with mock.patch.object(test_module, 'display', create=True) as mock3:
                with mock.patch.object(test_module, 'do_vault', create=True) as mock4:
                    with mock.patch.object(test_module, 'do_unvault', create=True) as mock5:
                        fm = FilterModule()

# Generated at 2022-06-21 04:31:21.052816
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    do_vault()

# Generated at 2022-06-21 04:31:28.478147
# Unit test for function do_unvault
def test_do_unvault():
    vl = VaultLib()
    data = 'foo'
    secret = 'secret'
    vaultid = 'filter_default'
    vs = VaultSecret(to_bytes(secret))
    v = vl.encrypt(to_bytes(data), vs, vaultid)
    assert do_unvault(v, secret) == data

    # test for AnsibleVaultEncryptedUnicode
    v = AnsibleVaultEncryptedUnicode(v)
    v.vault = vl
    assert do_unvault(v, secret) == data

# Generated at 2022-06-21 04:31:29.303636
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-21 04:31:43.763940
# Unit test for function do_unvault
def test_do_unvault():
    filter_plugin = FilterModule()
    filters = filter_plugin.filters()


# Generated at 2022-06-21 04:31:49.732683
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible;30353332333562346236316234623663376234363332336337613636634646133'
    vaultid = 'filter_default'

    assert do_unvault(vault, secret, vaultid) == 'test'

# Generated at 2022-06-21 04:31:51.173760
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass



# Generated at 2022-06-21 04:31:53.536229
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with class name
    assert 'vault' in FilterModule.filters(FilterModule())
    assert 'unvault' in FilterModule.filters(FilterModule())



# Generated at 2022-06-21 04:31:58.199979
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:32:02.513723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-21 04:32:04.594391
# Unit test for constructor of class FilterModule
def test_FilterModule():
  fixture = FilterModule()
  assert fixture is not None, "FilterModule is not an object"

# Generated at 2022-06-21 04:32:10.304422
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()



# Generated at 2022-06-21 04:32:11.917236
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not FilterModule().filters() is None

# Generated at 2022-06-21 04:32:17.641582
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert 'vault' in fm.filters()
    assert fm.filters()['vault'] == do_vault

    assert 'unvault' in fm.filters()
    assert fm.filters()['unvault'] == do_unvault



# Generated at 2022-06-21 04:32:29.635999
# Unit test for function do_vault
def test_do_vault():
    # Setup secret key
    secret = 'ansible'
    # Setup input to do_vault
    data = 'ansible'
    # Setup expected output

# Generated at 2022-06-21 04:32:37.885681
# Unit test for function do_unvault

# Generated at 2022-06-21 04:32:48.493527
# Unit test for function do_vault
def test_do_vault():
    v = do_vault('hello', 'secret')
    e = AnsibleVaultEncryptedUnicode('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          38346538373963393537376465306638353366373334366437383331636463666664343737643339\n          36396464616230643065346637356439336234643130626564316339626463623462336431616531\n          333435613734663163663933\n        ')
    assert v == e


# Generated at 2022-06-21 04:32:50.440346
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-21 04:33:00.318622
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    import jinja2

    tmpl_env = jinja2.Environment()

    tmpl_env.filters['vault'] = do_vault
    tmpl_env.loader = jinja2.DictLoader({'res': '{{ "ok" | vault(secret) }}'})


# Generated at 2022-06-21 04:33:02.661891
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter = FilterModule()
    assert 'vault' in test_filter.filters() and 'unvault' in test_filter.filters()


# Generated at 2022-06-21 04:33:10.561908
# Unit test for function do_unvault
def test_do_unvault():
    with open(r'D:\Barkod\Test\test_do_unvault.yaml') as yaml_file:
        test_data = yaml.load(yaml_file, Loader=yaml.FullLoader)

    for encrypted_string in test_data:
        secret = encrypted_string['secret']
        vault = encrypted_string['encrypted']
        vaultid = encrypted_string['vaultid']

        decrypted_string = do_unvault(vault, secret, vaultid)

        assert decrypted_string == encrypted_string['decrypted']

# Generated at 2022-06-21 04:33:14.462539
# Unit test for function do_unvault
def test_do_unvault():
    pass

# Generated at 2022-06-21 04:33:27.484953
# Unit test for function do_unvault
def test_do_unvault():
    import ansible_collections.ansible.community.plugins.filter.vault as vault

    test_vault_good = '$ANSIBLE_VAULT;1.1;AES256;ansible\n3039633139626363326536303139656138353636383165626335616333383839606630316136650a373633306435363764373230643937366465616462396561633665613538643761353735333961'

# Generated at 2022-06-21 04:33:30.897622
# Unit test for function do_vault
def test_do_vault():

    data = 'dog'
    secret = 'my_test_secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    result = do_vault(data, secret, salt, vaultid, wrap_object)
    print(result)


# Generated at 2022-06-21 04:33:42.764485
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = 'j9yhkmcq'
    message = 'test'
    vault = '$ANSIBLE_VAULT;1.1;AES256;test\n6361323060343664323430656634393562316365346337383333326234616363623930636864363\n35313933393931353735303766343230393737346662623563363534363563656666653361663632\n36663034396634363536353261626436386238633231383466633863326565333539\n'
    assert vault == do_vault(message, secret, salt=salt, vaultid='testid')


# Generated at 2022-06-21 04:33:46.014414
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    my_filters = FilterModule().filters()

    assert 'vault' in my_filters
    assert 'unvault' in my_filters

# Generated at 2022-06-21 04:33:54.490237
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ''
    assert do_unvault("", "") == ''
    assert do_unvault("", None) == ''
    assert do_unvault(None, "") == ''
    assert do_unvault("!vault |", None) == ''
    assert do_unvault("!vault |", "") == ''
    assert do_unvault("!vault |", "abcd") == ''
    assert do_unvault("!vault |", "abcd") == ''
    assert do_unvault("!vault |", "abcd") == ''
    assert do_unvault("!vault |", "abcd", "filter_default") == ''

# Generated at 2022-06-21 04:33:55.890141
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None

# Generated at 2022-06-21 04:33:59.606774
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:34:04.675103
# Unit test for constructor of class FilterModule

# Generated at 2022-06-21 04:34:06.622114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert len(filters) == 2
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:34:14.394058
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-21 04:34:25.104194
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    def write_file(filename, secret):
        fh = open(filename, 'wb')
        fh.write(secret.encode('utf-8'))
        fh.close()

    def run_test(secret, vault, expected):
        secret_file = tempfile.mkstemp()[1]
        write_file(secret_file, secret)
        vs = VaultSecret(secret)
        vl = VaultLib()
        input_vault = vl.encrypt(vault, vs)
        result = do_unvault(input_vault, secret, 'filter_default')
        os.remove(secret_file)
        assert result == expected

# Generated at 2022-06-21 04:34:35.178811
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'vault_secret'
    vaultid = 'test_do_unvault'

# Generated at 2022-06-21 04:34:44.829196
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("abc", "abc") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          343039313932646533623531393730666432396563383662613563313037633961636362396537\n          313436373761663735343861623561376133313831626230663533373630393938613433623223\n          636564363561306534336230393662643236613838353864363366643832626361656136616331\n          3131323332613762333039626530666664636336363366303861\n"
    # Invalid secret

# Generated at 2022-06-21 04:34:51.857080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.parsing.vault import VaultSecret

    vault_secret = VaultSecret('secret')
    vault_secret_filters = FilterModule()
    assert vault_secret_filters.filters()['vault']("password", vault_secret) is not None
    assert vault_secret_filters.filters()['vault']("password", vault_secret) is not ''

# Generated at 2022-06-21 04:35:03.615166
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = 'test'
    plaintext = 'test'
    vault = do_vault(plaintext, secret, salt)
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n6332643236633964363530643263633137343530336535613563303765653663383166610a343261373934313963353933383736353439336261336332643639323461613766360a6236626462356264653335303436333637393538363838333037373465666532306664\n'


# Generated at 2022-06-21 04:35:15.216372
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret)
    assert isinstance(vault, str)

    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert isinstance(vault.data, str)

    secret = 'foo'
    data = u'bar'
    vault = do_vault(data, secret)
    assert isinstance(vault, str)

    secret = u'foo'
    data = 'bar'
    vault = do_vault(data, secret)
    assert isinstance(vault, str)

    secret = 'foo'
    data = None
    vault = do_v

# Generated at 2022-06-21 04:35:19.840447
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters, "vault filter missing"
    assert 'unvault' in filters, "unvault filter missing"


# Generated at 2022-06-21 04:35:27.537710
# Unit test for function do_unvault
def test_do_unvault():

    # 1. Invalid types passed
    try:
        do_unvault(42, 'blah')
        assert False, "Should have raised AnsibleFilterTypeError"
    except AnsibleFilterTypeError as e:
        if str(e) != "Vault should be in the form of a string, instead we got: <type 'int'>":
            assert False, "Should have raised AnsibleFilterTypeError: Vault should be in the form of a string, instead we got: <type 'int'>"


# Generated at 2022-06-21 04:35:31.688684
# Unit test for constructor of class FilterModule
def test_FilterModule():
    AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible;')

# Generated at 2022-06-21 04:35:42.102843
# Unit test for constructor of class FilterModule
def test_FilterModule():
  f = FilterModule()
  assert f.filters()["vault"] is not None
  assert f.filters()["unvault"] is not None


# Generated at 2022-06-21 04:35:44.853049
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        f = FilterModule()
    except Exception as e:
        print(e)


# Generated at 2022-06-21 04:35:53.375144
# Unit test for function do_unvault
def test_do_unvault():
    try:
        # Check for string type
        do_unvault('vault', 'secret')
    except Exception as e:
        raise AnsibleFilterError('Unable to unvault: %s' % to_native(e), orig_exc=e)

    try:
        # Check for int type
        do_unvault(123, 'secret')
    except AnsibleFilterError as e:
        if "Unable to unvault" not in str(e):
            raise
    except Exception as e:
        raise AnsibleFilterError('Unable to unvault: %s' % to_native(e), orig_exc=e)


# Generated at 2022-06-21 04:36:01.648871
# Unit test for constructor of class FilterModule
def test_FilterModule():
    v = FilterModule()

# Unit tests for function do_vault()
# TODO: Add test to verify if function do_vault throws expected error when passed invalid arguments
# def test_do_vault():
    # assert False
    # assert not isinstance(v, FilterModule)

# Unit tests for function do_unvault()

# Generated at 2022-06-21 04:36:03.544322
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_vault_filter_module = FilterModule()
    assert ansible_vault_filter_module is not None


# Generated at 2022-06-21 04:36:04.903840
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.__name__ == "FilterModule"

# Generated at 2022-06-21 04:36:06.441071
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:36:10.602371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_instance = FilterModule()
    assert FilterModule_instance.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:36:11.487362
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True is not False

# Generated at 2022-06-21 04:36:25.065267
# Unit test for function do_unvault
def test_do_unvault():

    secret = '!V@u1t_s3cR3t'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:36:50.280820
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultEditor
    from ansible.module_utils.six import PY2
    import base64
    import binascii
    import os
    import tempfile
    import unittest

    class TestVault(unittest.TestCase):

        def setUp(self):
            self.editor = VaultEditor(1, "ansible", "ansible2019", salt="ansible")
            self.tmpdir = tempfile.mkdtemp()
            self.testdir = os.path.join(self.tmpdir, "testdir")
            self.testfile = os.path.join(self.testdir, "testfile")
            os.mkdir(self.testdir)

        def test_vault_filter(self):
            plaintext = "hello world"
            vaulted_

# Generated at 2022-06-21 04:37:00.635198
# Unit test for function do_unvault
def test_do_unvault():
    # Test unvault function with a valid secret and vault to return the decrypted string
    secret = 'password'
    vaultid = 'test_do_unvault'
    test_data = do_vault('ansible', secret, vaultid=vaultid, wrap_object=False)
    decrypted_string = do_unvault(test_data, secret)
    assert decrypted_string == 'ansible'

    # Test unvault function with an AnsibleVaultEncryptedUnicode object and secret to return the decrypted string
    secret = 'password'
    vaultid = 'test_do_unvault'
    test_data = do_vault('ansible', secret, vaultid=vaultid, wrap_object=True)
    decrypted_string = do_unvault(test_data, secret)
   

# Generated at 2022-06-21 04:37:07.537901
# Unit test for function do_vault
def test_do_vault():
    data = 'test_value'
    secret = 'test_secret'
    salt = 'test_salt'
    vaultid = 'test_filter'

    test_vm = do_vault(data, secret, salt, vaultid, False)
    assert '$ANSIBLE_VAULT' in test_vm
    test_vm2 = do_unvault(test_vm, secret, vaultid)
    assert data == test_vm2
    test_vm3 = do_vault(test_vm, secret, salt, vaultid, True)
    assert '$ANSIBLE_VAULT' in test_vm3.data
    test_vm4 = do_unvault(test_vm3, secret, vaultid)
    assert data == test_vm4

# Generated at 2022-06-21 04:37:13.335992
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert len(filters) == 2
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:37:17.326212
# Unit test for function do_vault
def test_do_vault():
    secret = 'dummy_secret'
    data = 'dummy_data'
    vault = do_vault(data, secret)
    data2 = do_unvault(vault, secret)
    assert data == data2

# Generated at 2022-06-21 04:37:29.674054
# Unit test for function do_vault
def test_do_vault():

    # execute test for function do_vault with success
    x = do_vault("contain_password_123", "secret")
    assert x == '$ANSIBLE_VAULT;1.2;AES256;default\n36393231346231343638643934363336353439336532643633316231663566356538306230300a383332653365343965343062643833393538363364613666323264326230323961346136600a65393636646535653763646339396561653238313433323066376535663133346537333163390a36313665383335363462343235336534366635653830643764633535386266386431333133'

    # execute

# Generated at 2022-06-21 04:37:44.161115
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    data = 'password123'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:37:45.189518
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:37:53.212467
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:04.948970
# Unit test for function do_unvault
def test_do_unvault():
    # Check for string
    assert do_unvault('str', 'secret') == 'str'
    # Check for null strings
    assert do_unvault('', 'secret') == ''
    assert do_unvault(None, 'secret') == ''
    assert do_unvault(None, None) == ''
    assert do_unvault('', None) == ''
    # Check for vaults
    data = 'data'
    secret = 'secret'
    vault = do_vault(data, secret)
    assert do_unvault(vault, secret) == 'data'
    # Check for different vaults
    data = 'data'
    secret = 'secret'
    vault = do_vault(data, secret, vaultid='vault1')

# Generated at 2022-06-21 04:38:21.052250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    cmd = FilterModule()
    # assert false  # TODO: implement your test here
    print(cmd.filters())


# Generated at 2022-06-21 04:38:33.612145
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.errors import AnsibleFilterTypeError
    from ansible.module_utils.six import string_types

    fm = FilterModule()
    assert isinstance(fm.filters(), dict)
    assert 'vault' in fm.filters().keys()
    assert 'unvault' in fm.filters().keys()
    assert isinstance(fm.filters()['vault'], types.FunctionType)
    assert isinstance(fm.filters()['unvault'], types.FunctionType)

    assert fm.filters()['vault']('test', 'secret')

# Generated at 2022-06-21 04:38:42.621661
# Unit test for function do_vault
def test_do_vault():

    secret = 'my_secret'
    data = 'my_vault_data'
    vaultid = 'filter_default'
    wrap_object = False

    test = do_vault(data, secret, vaultid=vaultid, wrap_object=wrap_object)

    assert isinstance(test, str)


# Generated at 2022-06-21 04:38:53.979001
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_string', 'test_secret') == u'$ANSIBLE_VAULT;1.1;AES256\n62313838303632353165323430313739333564333563386262623639646139633761643232323437\n623536663764363365653866626536336532623461336234336336633038616332380a6432393836\n65623763366664323864363531323133613461663130623538393432623465346665326364356531\n33653531373462626134613163386336373763323163643933623165666534\n'


# Generated at 2022-06-21 04:38:58.471691
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:59.901742
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert len(FilterModule().filters()) == 2

# Generated at 2022-06-21 04:39:08.609195
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'this is a very secret password'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:39:14.425091
# Unit test for function do_vault
def test_do_vault():
    secret = "abcdef1234567890"
    salt = "1234567890123456"
    data = "mysecret"
    vault = "$ANSIBLE_VAULT;1.1;AES256"
    vaultid = "12345678901234567890"
    assert(do_vault(data, secret, salt, vaultid)[0:len(vault)] == vault)


# Generated at 2022-06-21 04:39:25.581399
# Unit test for function do_vault
def test_do_vault():
    import unittest
    from ansible.parsing.vault import is_encrypted

    class TestVault(unittest.TestCase):

        def test_vault_string(self):
            data = do_vault(data='Hello World!', secret='ansible')
            self.assertTrue(is_encrypted(data))
            self.assertEqual(do_unvault(data, 'ansible'), 'Hello World!')

        def test_vault_undefined(self):
            v = do_vault(secret='ansible', salt='test-vault-salt', wrap_object=True)
            self.assertEqual(type(v), AnsibleVaultEncryptedUnicode)
            data = do_unvault(v, 'ansible')
            self.assertEqual(data, '')



# Generated at 2022-06-21 04:39:26.842848
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None