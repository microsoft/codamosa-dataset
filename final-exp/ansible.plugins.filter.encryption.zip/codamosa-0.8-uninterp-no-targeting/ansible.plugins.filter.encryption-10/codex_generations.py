

# Generated at 2022-06-21 04:29:55.618768
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import unittest
    try:
        myclass = FilterModule()
        myclass = FilterModule
    except Exception as e:
        raise unittest.TestCase('FilterModule not created: %s' % str(e)) from e



# Generated at 2022-06-21 04:29:58.919073
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)
    assert callable(FilterModule.filters)


# Generated at 2022-06-21 04:30:02.295823
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:30:14.264344
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    import os

    # Create a secret
    secret = VaultSecret(os.urandom(16))

    # Encrypt some data
    vl = VaultLib()
    vault = vl.encrypt(b"my_secret", secret, 'my_vault')
    assert is_encrypted(vault)

# Generated at 2022-06-21 04:30:24.905606
# Unit test for function do_vault
def test_do_vault():
    import pytest
    from jinja2.exceptions import UndefinedError
    from jinja2.runtime import Undefined
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import binary_type, text_type

    secret = 'foo'
    data = 'bar'

    result = do_vault(data, secret)
    assert isinstance(result, text_type)
    assert is_encrypted(result)

    result = do_vault(data, Undefined())
    assert isinstance(result, Undefined)

    result = do_vault(Undefined(), secret)
    assert isinstance(result, Undefined)

    result = do_vault(Undefined(), Undefined())
    assert isinstance(result, Undefined)

   

# Generated at 2022-06-21 04:30:27.798949
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(do_vault('securevalue', 'secret'), 'secret') == 'securevalue'

# Generated at 2022-06-21 04:30:30.283912
# Unit test for function do_vault
def test_do_vault():
    ''' Test Ansible vault jinja2 filter '''
    filter_result = do_vault("test", "testsecret")
    assert is_encrypted(filter_result)



# Generated at 2022-06-21 04:30:30.810206
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:30:38.084632
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:48.913433
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.six import PY3
    import jinja2

    data = 'test_data'
    secret = 'test_secret'

    # Test the vault filter
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)

    # Test non-string types
    if not PY3:
        with pytest.raises(AnsibleFilterTypeError) as e:
            do_vault(data, secret, salt=None, vaultid='filter_default')
    assert u'Secret passed is required to be a string, instead we got: <type \'unicode\'>' == str(e.value)


# Generated at 2022-06-21 04:31:03.472749
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert do_vault("foo", "plaintext", wrap_object=True) == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;test_0\n63323661313433316232313865386437373834393733643566396437383764356632386336316235\n33623134343036656463616337656633383766663565366531346236613962373162346130623339\n31326365303233320a")

# Generated at 2022-06-21 04:31:05.794279
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert True


# Generated at 2022-06-21 04:31:18.188180
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("Vault\nfoo\nbar\n", "secret") == "Vault\nfoo\nbar\n"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\nfoo\nbar\n", "secret") == "foo\nbar\n"
    assert do_unvault("Vault\nfoo\nbar\n", "secret", "secret") == "Vault\nfoo\nbar\n"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\nfoo\nbar\n", "secret", "secret") == "foo\nbar\n"

# Generated at 2022-06-21 04:31:20.326874
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterM = FilterModule()
    filterM.filters()

# Generated at 2022-06-21 04:31:30.510589
# Unit test for function do_unvault
def test_do_unvault():
    secret = "supersecret"

# Generated at 2022-06-21 04:31:34.017620
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()

# Generated at 2022-06-21 04:31:43.630039
# Unit test for function do_vault
def test_do_vault():
    secret='VaultSecret'
    salt=None
    vaultid='filter_default'
    wrap_object=False

    data1='ABC'
    data2='xyz'
    data3=None
    data4=True
    data5=False
    data6=1
    data7=1.0
    data8=[]
    data9={}


# Generated at 2022-06-21 04:31:56.444480
# Unit test for function do_unvault

# Generated at 2022-06-21 04:32:07.842678
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\n38656661633137343366666365666664746262316365636663323537663631373762616239636230\n3262373663303363316137303862363138356462313838666535316230306439353133366633313166\n3965636430656635336364313863306635343366333564363262636433613761333133633933626535\n303732626639356639613733643132646662316631\n", "test") == "test secret"



# Generated at 2022-06-21 04:32:23.262458
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n35643031363264633535376235610a37343238633936323039346235636164373533385664303731\n653234376239636430663636393466383038326538376337660a3165303133653663343262303237\n34336362396663666335333166393530646634396438346531343439326261393565643139313534\n3466326234643234306564\n'

# Generated at 2022-06-21 04:32:27.023438
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:32:35.749980
# Unit test for function do_unvault
def test_do_unvault():
    # Test with a secret string
    secret_string = 'secret_string'

# Generated at 2022-06-21 04:32:37.389373
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule)
    assert 'unvault' in FilterModule.filters(FilterModule)


# Generated at 2022-06-21 04:32:41.077597
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:32:44.874700
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:32:48.073585
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:33:03.108587
# Unit test for function do_vault
def test_do_vault():
    secret = 'hello there'
    data = 'this is the data'

    vault = do_vault(data, secret)

# Generated at 2022-06-21 04:33:03.982119
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() != None


# Generated at 2022-06-21 04:33:04.994168
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-21 04:33:07.470414
# Unit test for function do_unvault
def test_do_unvault():
    assert "foo" == do_unvault(do_vault("foo", "bar"), "bar")

# Generated at 2022-06-21 04:33:14.868582
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:33:27.665196
# Unit test for function do_unvault
def test_do_unvault():
    from jinjatests import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 04:33:43.007853
# Unit test for function do_vault
def test_do_vault():
    secret = 'y1e8xWjMNcJeNp28jbnJvn8mZbJaC2mjYI1Mg2TukG3LKjSfD'
    salt = 'Np28jbnJvn8mZ'
    encrypted = do_vault('test123', secret, salt)

# Generated at 2022-06-21 04:33:46.769720
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault
    }



# Generated at 2022-06-21 04:34:01.360648
# Unit test for function do_vault
def test_do_vault():
    print('TestCase do_vault')
    secret = 'passw0rd'
    data = 'test string'
    salt = 'test salt'
    vaultid = 'filter_default'

# Generated at 2022-06-21 04:34:13.320042
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '../tests/'))

    from ansible import constants

    constants.DEFAULT_VAULT_ID_MATCH = [r'$ANSIBLE_VAULT;.*;']

    vault_password_file = os.path.join(os.path.dirname(__file__), '../tests/vault_password')

    # test when vault is not encrypted
    not_encrypted = 'This is not encrypted'
    unvaulted = do_unvault(not_encrypted, 'notasecret', vault_password_file)
    unittest.assertEqual(unvaulted, not_encrypted)

    # test when vault is encrypted
    vaulted = do_vault

# Generated at 2022-06-21 04:34:24.637043
# Unit test for function do_vault
def test_do_vault():
    secret = "@kEy@#%cOde"
    data = "my secret data"
    result = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-21 04:34:34.972000
# Unit test for function do_vault
def test_do_vault():
    # vault a string
    base64_string = 'amFtZXMK'
    vault_secret = 'secret'
    assert do_vault(base64_string, vault_secret) == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n313739323138393335386638333133663435393032353465633536306433373864363330373461\n396661366131626332386165393435356264383963633064626331626363303831323035626439\n33363938643136346634393463616431353363643262613530666236666365346639357d0a'

    # vault a unicode string
    unicode_string = '中国'

# Generated at 2022-06-21 04:34:44.776579
# Unit test for function do_vault

# Generated at 2022-06-21 04:34:48.598313
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_obj = FilterModule()
    assert isinstance(test_obj.filters(), dict)

# Unit tests for method do_vault of class FilterModule

# Generated at 2022-06-21 04:35:00.817965
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  test_object = FilterModule()
  actual_result = test_object.filters()

# Generated at 2022-06-21 04:35:08.629750
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_data', 'dev', 'test_salt') == '$ANSIBLE_VAULT;1.2;AES256;dev;test_salt;VfY5qWK5V7QGX9RmV7IaiA\n' \
                                                                                              'YtW8YZlC4X9l4Bf1JdkW2QFzwSdxSjkV7P5qWY5V7IaiQFzw==\n'

# Generated at 2022-06-21 04:35:15.108069
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    assert fm.filters() is not None, 'Filters method is not returning anything'
    assert type(fm.filters()) == dict, 'Filters method is not returning a dict'
    assert len(fm.filters()) > 0, 'Filters dict is empty'



# Generated at 2022-06-21 04:35:16.547149
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule().filters()) == 2

# Generated at 2022-06-21 04:35:19.431484
# Unit test for constructor of class FilterModule
def test_FilterModule():
    global filters
    filters = FilterModule()
    assert 'vault' in filters.filters()
    assert 'unvault' in filters.filters()

# Generated at 2022-06-21 04:35:21.085267
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() is not None

# Generated at 2022-06-21 04:35:22.016085
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()


# Generated at 2022-06-21 04:35:26.581201
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:35:37.731964
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('secret', 'password')

# Generated at 2022-06-21 04:35:39.080523
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-21 04:35:44.439435
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-21 04:35:45.262845
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:35:46.057457
# Unit test for function do_vault
def test_do_vault():
    pass

# Generated at 2022-06-21 04:35:54.846109
# Unit test for function do_vault
def test_do_vault():
    test_input = b'value to encrypt'
    test_input_type = type(test_input)
    test_secret = b'password'
    test_secret_type = type(test_secret)
    test_salt = b'70b1c2593fb7'
    test_salt_type = type(test_salt)
    test_vaultid = 'test_vaultid'
    test_vaultid_type = type(test_vaultid)
    test_wrap_object = True
    test_wrap_object_type = type(test_wrap_object)

# Generated at 2022-06-21 04:36:05.843824
# Unit test for function do_unvault
def test_do_unvault():
    # Read test data from test.txt file
    f = open('test.txt', 'r')

    # Convert the file content to string
    # test_data is a dictionary with the test data,
    # the key is a description of the test case
    test_data = eval(f.read())

    # Loop through each test item in test_data dictionary
    for item in test_data.items():
        # Get the description for test case
        description = item[0]
        # Get the expect result for test case
        expect_result = item[1]['expect_result']
        # Get the vault data for test case
        vault = item[1]['vault']
        # Get the secret for test case
        secret = item[1]['secret']

        # Call do_unvault function to decrypt the vault data
        result = do

# Generated at 2022-06-21 04:36:11.669070
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()



# Generated at 2022-06-21 04:36:15.897218
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    vault = FilterModule()
    assert 'vault' in vault.filters()
    assert 'unvault' in vault.filters()

# Generated at 2022-06-21 04:36:27.526694
# Unit test for function do_unvault

# Generated at 2022-06-21 04:36:31.748115
# Unit test for function do_unvault
def test_do_unvault():
    a = do_vault('my_secret', 'my_secret', 'my_salt')
    b = do_unvault(a, 'my_secret')
    assert b == 'my_secret'

# Generated at 2022-06-21 04:36:38.097988
# Unit test for function do_vault
def test_do_vault():
    # Unit test for function do_vault
    secret = "my_vault_password"
    data = "my_data"
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert do_unvault(vault, secret) == data



# Generated at 2022-06-21 04:36:52.053971
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'test_secret'
    test_values = [
        'test_string',
        'test test_string',
        'test test_string test',
        'test,test_string',
        'test,:test_string',
        'test,:test_string,test',
        to_bytes('test_binary', 'utf-8'),
        to_bytes('test test_binary', 'utf-8'),
        to_bytes('test test_binary test', 'utf-8'),
        to_bytes('test,test_binary', 'utf-8'),
        to_bytes('test,:test_binary', 'utf-8'),
        to_bytes('test,:test_binary,test', 'utf-8'),
    ]

# Generated at 2022-06-21 04:37:03.608037
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """AnsibleVaultEncryptedUnicode is a class defined in ansible/parsing/yaml/objects.py
    It allows us to understand if an object is encrypted or not
    """

    # Create a FilterModule object from the class
    v = FilterModule()
    # Call the filter method
    filters = v.filters()

    assert type(filters) is dict
    assert 'vault' in filters
    assert 'unvault' in filters
    assert type(filters['vault']) is types.FunctionType
    assert type(filters['unvault']) is types.FunctionType



# Generated at 2022-06-21 04:37:06.747004
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    TestFilters = FilterModule()
    result = TestFilters.filters()
    assert result['vault'] is do_vault
    assert result['unvault'] is do_unvault
    assert len(result.keys()) == 2


# Generated at 2022-06-21 04:37:19.175237
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:20.053499
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()


# Generated at 2022-06-21 04:37:31.572001
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test case for method filters of class FilterModule."""

# Generated at 2022-06-21 04:37:35.784477
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-21 04:37:45.263715
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import sys
    import subprocess
    import tempfile

    filter_module = FilterModule()
    filters = filter_module.filters()
    vault = filters['vault']
    unvault = filters['unvault']

    secret = subprocess.check_output(['openssl', 'rand', '-base64', '32']).strip()
    plain = subprocess.check_output(['openssl', 'rand', '-base64', '32']).strip()
    salt = subprocess.check_output(['openssl', 'rand', '-base64', '32']).strip()

    # Should work with a random secret
    assert plain == unvault(vault(plain, secret, salt=salt), secret)

    # Ensure that it works with a vaultid

# Generated at 2022-06-21 04:38:00.613035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import os
    import sys
    import unittest
    import ansible
    from ansible.module_utils.common.text_utils import jsonify_value
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils import context_objects as co

    class filter_module_unit_tests(unittest.TestCase):
        loader = AnsibleLoader
        filter_module = FilterModule()
        vault_secret = "SecretPassword"
        vault_id = "unit_testing"
        context_manager_var = co.VariableManager()

        def test_FilterModule_filters(self):
            filters = self.filter_module.filters()
            self.assertIsNotNone(filters)

        def test_vault(self):
            filters = self.filter_module.filters()


# Generated at 2022-06-21 04:38:09.776415
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'mypassword') == '$ANSIBLE_VAULT;1.1;AES256\n35393330363766393735663336623639373438666565623961386563333239316436333861346336\n66343262666338373133663439323338636439633935313263323932323361386139623662346435\n636163376139663163316366666433626363653835386565313900\n'


# Generated at 2022-06-21 04:38:25.221061
# Unit test for constructor of class FilterModule
def test_FilterModule():
    display.debug('FilterModule: test_FilterModule')
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.display import Display
    import sys
    import types

    display = Display()
    obj = FilterModule()

    if not (isinstance(obj, FilterModule)):
        display.error("FilterModule: failed constructor test")
        sys.exit(1)

    filters = obj.filters()

    if not (isinstance(filters, dict)):
        display.error("FilterModule: failed filters test")
        sys.exit(1)

    do_vault = filters['vault']
    do_unvault = filters['unvault']


# Generated at 2022-06-21 04:38:37.425048
# Unit test for function do_unvault
def test_do_unvault():
    print('Testing Ansible Jinja filter do_unvault')
    fm = FilterModule()

# Generated at 2022-06-21 04:38:41.003921
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule)
    assert 'unvault' in FilterModule.filters(FilterModule)



# Generated at 2022-06-21 04:38:47.582751
# Unit test for function do_vault
def test_do_vault():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.parsing.convert_bool import boolean
    filtered = do_vault({'moo': 'cow'}, 'secret', 'salt')
    assert isinstance(filtered, AnsibleVaultEncryptedUnicode)
    assert not boolean(filtered.vault._vault_secrets['filter_default'].is_encrypted)


# Generated at 2022-06-21 04:38:53.446971
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    data = "secret"
    secret = "password"
    salt = "salt"
    vaultid = "vault_id"
    wrap_object = "wrap_object"
    vault = "vault"

    obj = FilterModule()
    filters = obj.filters()

    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()


# Generated at 2022-06-21 04:38:57.403149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:39:06.183006
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'

    data = b'Hello'
    vault = do_vault(data=data, secret=secret)
    assert type(vault) == str

    data = b'Hello'
    vault = do_vault(data=data, secret=secret, wrap_object=True)
    assert type(vault) == AnsibleVaultEncryptedUnicode

    data = 'Hello'
    vault = do_vault(data=data, secret=secret)
    assert type(vault) == str

    data = 'Hello'
    vault = do_vault(data=data, secret=secret, wrap_object=True)
    assert type(vault) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-21 04:39:09.466064
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule().filters()
    assert f['vault'] == do_vault
    assert f['unvault'] == do_unvault


# Generated at 2022-06-21 04:39:15.070130
# Unit test for function do_vault
def test_do_vault():
    filter = FilterModule()
    data = 'data'
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    # do the test here
    assert filter.filters()['vault'](data, secret, salt, vaultid, wrap_object) == 'AQAAAAIAAAAAAFRhdGEAXnF6YwIRquW8/juJww=='
    

# Generated at 2022-06-21 04:39:19.091274
# Unit test for function do_unvault
def test_do_unvault():

    # test string value
    assert do_unvault('$ANSIBLE_VAULT;8.0;V1;AES256;a2V5Cg==', secret='secret') == 'key'

# Generated at 2022-06-21 04:39:34.670624
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'abcdef1234567890'

# Generated at 2022-06-21 04:39:44.382245
# Unit test for function do_vault
def test_do_vault():
    display.vvv("%s" % do_vault("password", "secret"))
    assert('$ANSIBLE_VAULT;1.1;AES256;ansible\r\n637275617263682d3133333230366531633162356264316236623233666134616231396132623961366135613\r\n366231336263376165623231613761313565326131353866353039663563336330633231636539653337363430\r\n36373931313961326239613661366132316365626536306139643937366433623237643765622d2d390d0a' == do_vault("password", "secret"))
