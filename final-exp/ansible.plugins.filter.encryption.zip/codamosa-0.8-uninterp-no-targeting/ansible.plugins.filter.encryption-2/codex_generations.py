

# Generated at 2022-06-21 04:29:55.102500
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:30:09.781140
# Unit test for function do_unvault
def test_do_unvault():
    import jinja2

    '''
    Ansible vault jinja2 filters - unit test cases
    '''

# Generated at 2022-06-21 04:30:20.880986
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'vault'
    result = do_vault(data, secret)

# Generated at 2022-06-21 04:30:22.107965
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:30:28.645067
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:29.825777
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    print(obj.filters())


# Generated at 2022-06-21 04:30:31.018431
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:30:32.162580
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Constructor test FilterModule object
    """
    FilterModule()

# Generated at 2022-06-21 04:30:39.790194
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.module_utils.six.moves import shlex_quote

    from ansible.parsing.vault import VaultEditor

    try:
        # NOTE : The SHELL_FORMAT setting is required to be 'auto' to allow the
        #        vault editor to work.
        # ImportError is not handled here
        import configparser
        config = configparser.ConfigParser(defaults={}, allow_no_value=True)
        config.read(os.path.expanduser("~/.ansible.cfg"))
        config.set('defaults', 'SHELL_FORMAT', 'auto')

    except (Exception, configparser.Error) as e:
        # Could not read or modify configuration, skipping test
        print("Skipping test_unvault, could not modify .ansible.cfg")

# Generated at 2022-06-21 04:30:49.539157
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:03.501893
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import sys
    import stat
    import tempfile
    import os
    from os.path import join
    from shutil import rmtree
    from tempfile import mkdtemp, mkstemp
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle as pickle

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    display.verbosity = 3

    #########################################################
    # Unit tests for do_vault
    #########################################################

    def test_do_vault():

        key = b'00' * 16
        salt = b'ab' * 16

# Generated at 2022-06-21 04:31:08.086508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:31:15.682990
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert 'vault' in filters
    assert 'unvault' in filters
    v = 'pass'
    s = 'pass'
    encrypted = filters['vault'](v, s)
    assert encrypted is not None
    decrypted = filters['unvault'](encrypted, s)
    assert decrypted == v
    # TODO: add more tests

# Generated at 2022-06-21 04:31:28.248287
# Unit test for function do_vault
def test_do_vault():
    # Should work
    assert do_vault('abc', 'def') == '$ANSIBLE_VAULT;1.1;AES256\n36353763306139636164633833356139363961633437363964653066643638666465626566303465\n323965386165313431636562383134643963663063653666640a3430326664393861653233353764\n35643937336561366366306565383634333037666137373936333738336163353736613261333138\n6539393638623665306661\n'

    # Should not work
    try:
        do_vault(None, None)
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:31:31.452401
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:31:33.203410
# Unit test for function do_vault
def test_do_vault():
    data = 'bar'
    secret = 'foo'
    vaultid = 'test_vault'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert vault != data



# Generated at 2022-06-21 04:31:35.488338
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-21 04:31:36.248940
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (FilterModule())

# Generated at 2022-06-21 04:31:38.313052
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_class = FilterModule()
    assert test_class is not None

# Generated at 2022-06-21 04:31:50.611872
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    filter_output = do_vault('test', secret)

# Generated at 2022-06-21 04:31:57.206093
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert "vault" in filter_module.filters()
    assert "unvault" in filter_module.filters()

# Generated at 2022-06-21 04:32:08.840305
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    secret = "my_secret"
    expected_result = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;filter_default\n          30396434663064643236633336393064376336383565393832613263356133616332360a306561656339326\n          5333231386332363135666135353862373439613363623134636663386266303532656338626436633337336\n          535031613438656334653365633437386265653063350a6639346232326464\n          "

    output = do_vault("Hello", secret)
    assert output == expected_result


# Generated at 2022-06-21 04:32:10.793783
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert vault.startswith(b'$ANSIBLE_VAULT;')


# Generated at 2022-06-21 04:32:25.467432
# Unit test for function do_unvault

# Generated at 2022-06-21 04:32:26.899791
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm



# Generated at 2022-06-21 04:32:29.541112
# Unit test for constructor of class FilterModule
def test_FilterModule():
    s = FilterModule()
    assert s is not None
    assert s.filters() is not None


# Generated at 2022-06-21 04:32:30.582359
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Success
    fm = FilterModule()
    assert fm



# Generated at 2022-06-21 04:32:36.053949
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('hello world', 'secret', 'salt', 'vaultid', True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.data == 'hello world'
    assert isinstance(result.vault, VaultLib)


# Generated at 2022-06-21 04:32:49.633557
# Unit test for function do_vault
def test_do_vault():
    filter_vault = FilterModule().filters()['vault']

# Generated at 2022-06-21 04:32:55.857887
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_class = FilterModule()

# Generated at 2022-06-21 04:33:09.434543
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-21 04:33:12.912648
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None)  == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:33:22.606946
# Unit test for function do_unvault
def test_do_unvault():
    # NOTE: for this test you need to have the following in your ansible.cfg:
    #
    #   [vault]
    #   vault_password_file = /vagrant/vaultpassword
    #
    # Pre-requisites:
    #   sudo apt-get install python-pip python-dev build-essential
    #   sudo pip install ansible
    #
    # Run:
    #   ansible-playbook -i tests/inventory tests/test_filter_plugins/test.yml
    #
    # The test.yml playbook contains this filter test (it's simple!)
    vault = do_vault('hello', 'secret')
    assert vault != 'hello'
    assert do_unvault(vault, 'secret') == 'hello'

# Generated at 2022-06-21 04:33:26.643848
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    assert mod.filters() == {'vault': do_vault,
 'unvault': do_unvault}


# Generated at 2022-06-21 04:33:28.619812
# Unit test for constructor of class FilterModule
def test_FilterModule():
    j = FilterModule()
    assert j


# Generated at 2022-06-21 04:33:44.159954
# Unit test for function do_unvault

# Generated at 2022-06-21 04:33:45.041997
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-21 04:33:54.073202
# Unit test for function do_vault
def test_do_vault():
    actual = do_vault('secretpassword', 'secretpass', 'salt', 'vaultid')

# Generated at 2022-06-21 04:33:55.515754
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:34:01.630272
# Unit test for function do_vault
def test_do_vault():
    test_secret = "test_secret"
    test_salt = "test_salt"
    test_vaultid = "unit_testing"
    test_data = "test_data"

# Generated at 2022-06-21 04:34:11.866005
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-21 04:34:13.965315
# Unit test for function do_vault
def test_do_vault():
    # TODO: make a unit test for do_vault
    pass


# Generated at 2022-06-21 04:34:15.896197
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not hasattr(vars()['FilterModule'], 'filter')


# Generated at 2022-06-21 04:34:25.734268
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'ansible'
    vaulted_data = '$ANSIBLE_VAULT;1.2;AES256;ansible\n3933373736326664653466643935323335633038643536326335326339643338656235373662370a663531633066383261366331613761396235633239396261626138333564343937646636356562660a3566343531366137613233346163326239353865346432323063386361332d2d2d2d2d2d2d2d393633616631356363383239346565396136373733396539356634623931613238636232636365\n'
    data = 'foo bar'

# Generated at 2022-06-21 04:34:35.331293
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:38.287208
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert dict == type(fm.filters())


# Generated at 2022-06-21 04:34:39.823497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None

# Generated at 2022-06-21 04:34:41.902306
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-21 04:34:54.370019
# Unit test for function do_vault
def test_do_vault():
    ''' execute unit test for do_vault '''

    import types
    import pytest

    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # function test
    secret = "password"
    vault = do_vault("my_secret", secret)

# Generated at 2022-06-21 04:34:56.178798
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:35:16.260655
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    x = f.filters()
    assert isinstance(x, dict), "FilterModule.filters returns a dict"

# Generated at 2022-06-21 04:35:25.974355
# Unit test for function do_unvault
def test_do_unvault():
    # Test for simple string unvault
    data = 'simple string'
    secret = 'simple_secret'
    vault = do_vault(data, secret)

    assert do_unvault(vault, secret) == data

    # Test for more complex string unvault
    data = '''
    #!/usr/bin/python
    import sys
    import os
    import subprocess
    import base64

    print "Hello World"
    '''
    secret = 'simple_secret'
    vault = do_vault(data, secret)

    assert do_unvault(vault, secret) == data

    # Test for AnsibleVaultEncryptedUnicode unvault
    data = 'complex string'
    secret = 'complex_secret'

# Generated at 2022-06-21 04:35:32.338876
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:35:38.633983
# Unit test for function do_unvault
def test_do_unvault():
    string = 'my super secret string'
    secret = 'very secret'
    vault = do_vault(string, secret, wrap_object=True)
    assert do_unvault(vault, secret) == string



# Generated at 2022-06-21 04:35:42.315176
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-21 04:35:53.501814
# Unit test for function do_vault
def test_do_vault():

    import ansible.module_utils.six as six

    if six.PY3:
        salt = "b'\x88\x0cT\x9c\xc8\xcc\x0c\xe0\x00\x8b\xe9='"
    else:
        salt = "'\x88\x0cT\x9c\xc8\xcc\x0c\xe0\x00\x8b\xe9='"

    secret = "secret"
    vaultid = 'filter_default'
    data = "data"

    res = do_vault(data, secret, salt, vaultid, False)
    assert '$ANSIBLE_VAULT' in res

    res = do_vault(data, secret, salt, vaultid, True)

# Generated at 2022-06-21 04:36:05.530161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-21 04:36:08.638135
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault_filter = FilterModule()
    assert vault_filter is not None


# Generated at 2022-06-21 04:36:19.071633
# Unit test for function do_unvault
def test_do_unvault():
    # No vault
    assert do_unvault('plain data', 'secret') == 'plain data'

    # Invalid vault
    with pytest.raises(AnsibleFilterError):
       assert do_unvault('$ANSIBLE_VAULT;1234;', 'secret') == 'plain data'

    # Invalid vault (no semicolon)
    with pytest.raises(AnsibleFilterError):
       assert do_unvault('$ANSIBLE_VAULT1234;', 'secret') == 'plain data'

    # Invalid vault (semicolon not at correct position)
    with pytest.raises(AnsibleFilterError):
       assert do_unvault('$ANSIBLE_VAULT;12;34', 'secret') == 'plain data'

    # Invalid vault (string is too short)

# Generated at 2022-06-21 04:36:23.158946
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    expected_result = {'vault': do_vault, 'unvault': do_unvault}
    assert fm.filters() == expected_result


# Generated at 2022-06-21 04:36:49.328729
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('secret', 'password'), string_types)  # encrypts a string with a password
    assert isinstance(do_vault('secret', 'password', wrap_object=True), AnsibleVaultEncryptedUnicode)  # encrypts a string with a password and wrap it
    assert isinstance(do_vault('secret', 'password', salt='salt'), string_types)  # encrypts a string with a password and salt
    assert isinstance(do_vault('secret', 'password', salt='salt', wrap_object=True), AnsibleVaultEncryptedUnicode)  # encrypts a string with a password and salt and wrap it
    assert isinstance(do_vault('secret', 'password', vaultid='vaultid'), string_types)  # encrypts a string with a password and vaultid


# Generated at 2022-06-21 04:36:59.271258
# Unit test for function do_unvault
def test_do_unvault():
    secret = "FooBar"
    data_str = 'String to test vault'
    data_list = [1,2,3,8]
    data_dict = {'key1': 'value1', 'key2': 'value2'}
    vault_str = do_vault(data_str, secret)
    vault_list = do_vault(data_list, secret)
    vault_dict = do_vault(data_dict, secret)
    assert do_unvault(vault_str, secret) == data_str
    assert do_unvault(vault_list, secret) == data_list
    assert do_unvault(vault_dict, secret) == data_dict

# Generated at 2022-06-21 04:37:01.925561
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('vault-secret-abcd', 'abcd', '12345') == ''

# Generated at 2022-06-21 04:37:05.385802
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    assert "vault" in filter_module.filters(), "Should have filter 'vault'"
    assert "unvault" in filter_module.filters(), "Should have filter 'unvault'"


# Generated at 2022-06-21 04:37:07.131215
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_obj = FilterModule()

# Generated at 2022-06-21 04:37:22.796783
# Unit test for function do_unvault
def test_do_unvault():
    # Test for vault data that has been vaulted with AnsibleVaultEncryptedUnicode
    assert do_unvault(AnsibleVaultEncryptedUnicode("mysecret"), "mysecret") == "mysecret"
    # Test for vault data that has been vaulted with vault_string
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myVaultId\n6334343137353436323133643836396239393532393663386234383730343533\n3963323839613539333736356531646535633936383565333865663062353267\n35633738633166323839336563363066316362626137613763383262", "mysecret") == "mysecret"
    # Test for vault data that

# Generated at 2022-06-21 04:37:28.215533
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters, "'vault' filter not found in %s" % str(filters.keys())
    assert 'unvault' in filters, "'unvault' filter not found in %s" % str(filters.keys())


# Generated at 2022-06-21 04:37:30.882035
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''FilterModule constructor'''

    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-21 04:37:39.595492
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Configure the test case
    filter_module = FilterModule()
    # Execute the code to be tested
    filters = filter_module.filters()
    # Verify the result
    assert isinstance(filters, dict)
    assert filters.get('vault')
    assert filters.get('unvault')


# Generated at 2022-06-21 04:37:46.427044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''

    obj = FilterModule()
    func = obj.filters()
    # This should return a callable object
    assert callable(func['vault'])
    assert callable(func['unvault'])


test_FilterModule_filters()

# Generated at 2022-06-21 04:38:04.884773
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("my secret", "my secret", vaultid='test_vault') == "$ANSIBLE_VAULT;1.1;"
    assert do_vault("{{ my_secret }}", "my secret", vaultid='test_vault') == "{{ my_secret }}"

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(42, "my secret", vaultid='test_vault')


# Generated at 2022-06-21 04:38:11.181808
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest

    sys.modules['ansible'] = object()
    sys.modules['ansible.errors'] = object()
    sys.modules['ansible.errors'].AnsibleFilterError = object()
    sys.modules['ansible.errors'].AnsibleFilterTypeError = object()
    sys.modules['ansible.module_utils'] = object()
    sys.modules['ansible.module_utils']._text = object()
    sys.modules['ansible.module_utils']._text.to_native = object()
    sys.modules['ansible.parsing'] = object()

# Generated at 2022-06-21 04:38:15.218919
# Unit test for function do_unvault
def test_do_unvault():
    """Test do_unvault()"""
    from .vault_fixture import test_vault_str
    secret = "my-secret"
    assert do_unvault(test_vault_str, secret) == "my-data-to-protect"

# Generated at 2022-06-21 04:38:24.206057
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    with pytest.raises(AnsibleFilterTypeError) as excinfo1:
        test = FilterModule.filters(FilterModule)
        test.get('vault')(2345, 'test', None, 'filter_default', False)
    assert 'Can only vault strings, instead we got' in str(excinfo1.value)
    with pytest.raises(AnsibleFilterTypeError) as excinfo2:
        test = FilterModule.filters(FilterModule)
        test.get('unvault')(2345, 'test', 'filter_default')
    assert 'Vault should be in the form of a string, instead we got' in str(excinfo2.value)

# Generated at 2022-06-21 04:38:39.481848
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:45.642631
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filter_module = FilterModule()
    assert test_filter_module.filters() == { "vault": do_vault,
                                             "unvault": do_unvault }

# Generated at 2022-06-21 04:38:55.576040
# Unit test for function do_unvault

# Generated at 2022-06-21 04:39:05.969684
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    with open('test_vault', 'r') as f:
        data = f.read()

    # Test with a salt
    salt = 'salt'
    vault = do_vault(data, secret, salt, vaultid='test_vault', wrap_object=False)
    assert vault

    # Test without a salt
    vault = do_vault(data, secret, vaultid='test_vault', wrap_object=False)
    assert vault

    # Test error handling
    expected_err = "Secret passed is required to be a string, instead we got: <class 'int'>"
    try:
        do_vault(data, 1000, vaultid='test_vault', wrap_object=False)
    except AnsibleFilterTypeError as err:
        assert str(err) == expected_err

# Generated at 2022-06-21 04:39:11.128689
# Unit test for function do_vault

# Generated at 2022-06-21 04:39:24.851604
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'