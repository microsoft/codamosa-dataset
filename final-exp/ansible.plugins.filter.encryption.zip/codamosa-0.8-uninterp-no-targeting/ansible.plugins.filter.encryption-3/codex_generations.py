

# Generated at 2022-06-21 04:29:52.913708
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class MockAnsibleVaultEncryptedUnicode(object):
        def __init__(self, vault):
            self.vault = vault

    ansibleVaultEncryptedUnicodeObj = MockAnsibleVaultEncryptedUnicode('someValue')

    # Tests for vault

# Generated at 2022-06-21 04:30:03.325368
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:14.378261
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:21.286563
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    # Test with valid values
    result = do_vault(data, secret)
    assert isinstance(result, string_types)
    # Test with salt
    result = do_vault(data, secret, 'salt')
    assert isinstance(result, string_types)
    # Test with invalid arguments
    try:
        result = do_vault(0, secret)
        assert False
    except AnsibleFilterTypeError:
        pass
    try:
        result = do_vault(data, 0)
        assert False
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-21 04:30:23.571703
# Unit test for function do_vault
def test_do_vault():
    ''' Unit test for function do_vault '''
    pass
    # Can't test these filters, please update


# Generated at 2022-06-21 04:30:27.779890
# Unit test for function do_vault
def test_do_vault():
    vault_secret = "my_vault_secret"
    data = "msg-to-vault: hello my vault"
    salt = "salt_value"

    vault = do_vault(data, vault_secret, salt)
    assert vault != data
    assert vault is not None

    unvault = do_unvault(vault, vault_secret)
    assert unvault == data

# Generated at 2022-06-21 04:30:35.604692
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    fm_filters = FilterModule().filters()

    # Test for method vault
    with open('/dev/null', 'rb') as null:
        secret = 'Ansible'
        data = 'Password is Ansible'

        vault = fm_filters['vault'](data, secret)
        assert isinstance(vault, str)
        assert is_encrypted(vault)
        assert fm_filters['unvault'](vault, secret) == data

        obj_vault = fm_filters['vault'](data, secret, wrap_object=True)
        assert isinstance(obj_vault, AnsibleVaultEncryptedUnicode)
        assert is_encrypted

# Generated at 2022-06-21 04:30:37.463575
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()
    assert len(fm.filters()) == 2

# Generated at 2022-06-21 04:30:42.064226
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters().get('vault') is not None
    assert fm.filters().get('unvault') is not None


# Generated at 2022-06-21 04:30:52.502531
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

    # Test undefined
    vault = Undefined()
    assert do_unvault(vault, secret, vaultid) == ''

    # Test string
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid) == data

    # Test AnsibleVaultEncryptedUnicode
    vault = AnsibleVaultEncryptedUnicode(vault)
    assert do_unvault(vault, secret, vaultid) == data

    # Test not encrypted
    vault = 'data'
    assert do_unvault(vault, secret, vaultid) == data

# Generated at 2022-06-21 04:31:05.672801
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    
    class MockConfig(object):
        def __init__(self, **kwargs):
            for key in kwargs:
                setattr(self, key, kwargs[key])

    class MockVaultLib(object):
        def __init__(self):
            pass

        def encrypt(self, data, secret, vaultid, salt):
            return 1
        
        def decrypt(self, vault):
            return 2

    class MockVaultSecret(object):
        def __init__(self):
            pass

    class MockVarsModule(object):
        def __init__(self):
            pass


# Generated at 2022-06-21 04:31:07.342308
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-21 04:31:08.164995
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-21 04:31:09.069769
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:31:23.001035
# Unit test for function do_unvault
def test_do_unvault():
    fm = FilterModule()
    filters = fm.filters()
    test_text = "test text"
    test_secret = 'test secret'
    test_vaultid = 'test_id'

    # test_string or test_vaultid is not in expected format
    try:
        filters['unvault'](test_secret, test_vaultid)
        assert False
    except AnsibleFilterTypeError:
        assert True

    try:
        filters['unvault'](test_text, test_vaultid, 1)
        assert False
    except AnsibleFilterTypeError:
        assert True

    # test_vault is not encrypted
    assert filters['unvault'](test_text, test_secret, test_vaultid) == test_text

    # test_vault is encrypted

# Generated at 2022-06-21 04:31:30.020525
# Unit test for function do_vault
def test_do_vault():
    data = "mypassword"
    secret = "mypassword"

    expected = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          33373265613962343337643036323761333265643462633531623361326565653162326437666539\n          38386166366135356463373065316261636138346566653630663831653933326433363435306563\n          613539613838643164\n          "

    result = do_vault(data, secret)

    assert result == expected



# Generated at 2022-06-21 04:31:38.992953
# Unit test for function do_vault
def test_do_vault():
    filter_plugin = FilterModule()
    func = filter_plugin.filters()['vault']
    data = 'super secret data'
    secret = 'super secret key'
    salt = 'super secret salt'
    vaultid = 'super secret vault id'
    wrap_object = True
    assert isinstance(func(data, secret, salt, vaultid, wrap_object), AnsibleVaultEncryptedUnicode)
    wrap_object = False
    assert isinstance(func(data, secret, salt, vaultid, wrap_object), string_types)



# Generated at 2022-06-21 04:31:41.735283
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-21 04:31:52.155225
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:31:55.015985
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-21 04:32:08.866204
# Unit test for function do_unvault
def test_do_unvault():

    test_vault = '$ANSIBLE_VAULT;1.1;AES256\n356431636132386339616238616563366366643066386339323137363563663864663733353739\n653230393561633037383938356631323937393633353563323531376162613531353161623166\n396264353034393233396339653938643230353733353531363966356466666634376438396432\n'
    test_secret = 'test'

    assert test_vault == do_vault('hello', test_secret)
    assert 'hello' == do_unvault(test_vault, test_secret)


# Generated at 2022-06-21 04:32:13.516384
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    input_data = 'this is a secret'

    fm = FilterModule()
    filters = fm.filters()
    result = filters['vault'](input_data)
    assert result


# Generated at 2022-06-21 04:32:16.230801
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-21 04:32:17.489958
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-21 04:32:18.842682
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-21 04:32:30.270169
# Unit test for function do_vault
def test_do_vault():
    from ansible.errors import AnsibleFilterTypeError
    from ansible.parsing.vault import is_encrypted

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils import vault as v
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils import vault as v2
    import pytest

    secret = 'my_secret'
    data = 'my_data'
    try:
        vault = v.do_vault(data, secret)
    except AnsibleFilterTypeError:
        assert False, 'AnsibleFilterTypeError not expected'

    assert is_encrypted(vault), 'Vaulted data is not encrypted'


# Generated at 2022-06-21 04:32:39.708371
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters()['vault']('test', 'hideme'), str)

# Generated at 2022-06-21 04:32:44.729766
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('foo', 'bar', salt=None, vaultid='filter_default', wrap_object=False)
    assert vault.startswith('$ANSIBLE_VAULT;1.1;AES256')


# Generated at 2022-06-21 04:32:47.802052
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters
    assert 'test' not in filters


# Generated at 2022-06-21 04:32:59.919134
# Unit test for function do_vault
def test_do_vault():
    data = "this is a test"
    secret = "mysecret"
    output = do_vault(data, secret)

# Generated at 2022-06-21 04:33:05.849565
# Unit test for function do_vault
def test_do_vault():
    secret = 'thisisasecret'
    data = 'password'
    expected_result = VaultLib().encrypt(data, VaultSecret(secret), 'filter_default')
    result = do_vault(data, secret, wrap_object=True)
    assert result == expected_result



# Generated at 2022-06-21 04:33:08.853039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:33:13.355243
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:33:19.513130
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert 'vault' in filters, "Should have vault as one of the filters defined"
    assert 'unvault' in filters, "Should have unvault as one of the filters defined"


# Generated at 2022-06-21 04:33:23.887605
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pylint: disable=protected-access
    assert not isinstance(FilterModule._filter_loader, Undefined)


# Generated at 2022-06-21 04:33:33.856241
# Unit test for function do_vault
def test_do_vault():
    # Test data
    test_data = "my secret password"
    test_secret = "test"
    test_salt = None
    test_vaultid = "test"
    test_wrap_object = False

    # Call function do_vault with test data
    vault = do_vault(test_data, test_secret, test_salt, test_vaultid, test_wrap_object)


# Generated at 2022-06-21 04:33:36.168751
# Unit test for function do_unvault
def test_do_unvault():

    secret = "test123"
    vaultid = "filter_default"

    data = "test123"
    vault = do_vault(data, secret, vaultid)
    result = do_unvault(vault, secret, vaultid)

    assert data == result

# Generated at 2022-06-21 04:33:37.009197
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()

# Generated at 2022-06-21 04:33:46.999045
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    # Passwords not passed
    assert do_vault('hi world', 'passwd1') == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;ansible_test\n636465353639386132633230393331663137613164633339353362386437616562336230626637\n396562633531396138613861356230316131386531656266636135303062323736363865383538\n333965666632373962')

# Generated at 2022-06-21 04:33:49.429383
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:33:57.361435
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    data = "secret data"

    encrypted_data = do_vault(data, secret)
    assert encrypted_data != data

# Generated at 2022-06-21 04:34:06.658687
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test with a string secret
    fm = FilterModule()
    filters = fm.filters()

    secret = 'test_secret'
    vault = do_vault('my data', secret)
    data = do_unvault(vault, secret)

    assert data == 'my data'

    # Test with a ansible.vars.vault.VaultSecret secret
    fm = FilterModule()
    filters = fm.filters()

    secret = VaultSecret(secret)
    vault = do_vault('my data', secret)
    data = do_unvault(vault, secret)

    assert data == 'my data'

    # Test with a ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode vault
    fm = FilterModule()
    filters = fm

# Generated at 2022-06-21 04:34:19.029467
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"
    data = "This is a test message"

# Generated at 2022-06-21 04:34:25.654908
# Unit test for function do_unvault
def test_do_unvault():
    # Test non-encrypt data
    a = 'Hello World'
    b = do_unvault(a, 'secret')
    assert a == b

    # Test encrypt data
    a = 'Hello World'
    b = do_vault(a, 'secret')
    c = do_unvault(b, 'secret')
    assert a == c

    # Test encrypt data with different salt
    a = 'Hello World'
    b = do_vault(a, 'secret')
    c = do_unvault(b, 'secret')
    assert a == c


# Generated at 2022-06-21 04:34:35.293034
# Unit test for function do_vault
def test_do_vault():
    print('>>> test_do_vault')
    assert do_vault(None, None) == ''
    assert do_vault(None, 'secret') == ''
    assert do_vault(None, 'secret', None) == ''
    assert do_vault(None, 'secret', None, 'vaultid') == ''
    assert do_vault('variable', 'secret') == 'variable'
    assert do_vault('variable', 'secret', None) == 'variable'
    assert do_vault('variable', 'secret', None, 'vaultid') == 'variable'
    assert do_vault('variable', 'secret', vaultid='vaultid') == 'variable'
    assert do_vault('variable', 'secret', 'salt', 'vaultid') == 'variable'

# Generated at 2022-06-21 04:34:37.295386
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-21 04:34:45.432633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # AnsibleFilterTypeError
    try:
        fm = FilterModule()
        fm.filters()['vault'](1, 'secret')
        assert False, 'test fail'
    except AssertionError as e:
        raise
    except Exception as e:
        pass
    # AnsibleFilterError
    try:
        fm = FilterModule()
        fm.filters()['vault']('not_encrypted', 'invalid_secret')
        assert False, 'test fail'
    except AssertionError as e:
        raise
    except Exception as e:
        pass
    # normal

# Generated at 2022-06-21 04:34:47.508564
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'vault' in FilterModule.filters(FilterModule)

# Generated at 2022-06-21 04:34:49.856379
# Unit test for constructor of class FilterModule
def test_FilterModule():
  fm = FilterModule()
  assert isinstance(fm, FilterModule)


# Generated at 2022-06-21 04:35:03.737453
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("test_data", "secret_key")

# Generated at 2022-06-21 04:35:22.145910
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    vaultid = 'test_unvault'
    vault = do_vault('testdata','testsecret', vaultid=vaultid, wrap_object=True)
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n63353338626162666230646661653730623438306439656534376361666565336235643862646636\n623537626336666166323761623933643936363337616535643630623936633039623432663766\n'
    data = do_unvault(vault, secret, vaultid=vaultid)
    assert data == 'testdata'

# Generated at 2022-06-21 04:35:34.305980
# Unit test for function do_vault
def test_do_vault():
    secret = "foo"
    data = "bar"
    vault = do_vault(secret, data)

# Generated at 2022-06-21 04:35:36.179436
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule().filters()) == 2


# Generated at 2022-06-21 04:35:47.591135
# Unit test for function do_unvault
def test_do_unvault():
    """
    Multiple filter tests
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultSecret, VaultLib
    from ansible.plugins.filter.vault import do_unvault

    secret = 'dummy'
    vault_secret = VaultSecret(b'dummy')
    vault_lib = VaultLib([('filename', vault_secret)])
    encrypted_data = vault_lib.encrypt(b'hello')


# Generated at 2022-06-21 04:35:52.464258
# Unit test for function do_vault
def test_do_vault():
    '''
    Tests the do_vault function
    '''
    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    mydata = 'mydata'
    vault = do_vault(mydata, secret, salt, vaultid)
    unvault = do_unvault(vault, secret, vaultid)

    assert mydata == unvault


# Generated at 2022-06-21 04:36:05.058984
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six.moves import StringIO
    import tempfile
    import yaml

    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_VAULT_ID_MATCH = '^$'

    # Create a temp file with a vaulted string
    (fd, fp) = tempfile.mkstemp(text=True)


# Generated at 2022-06-21 04:36:16.347547
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.module_utils.basic import AnsibleModule

    # Define test variables
    module = AnsibleModule({}, supports_check_mode=True)
    fake = "fake"
    real = "real"
    secret = "mysecret"

# Generated at 2022-06-21 04:36:18.608536
# Unit test for constructor of class FilterModule
def test_FilterModule():
    p = FilterModule()
    assert p is not None


# Generated at 2022-06-21 04:36:20.079411
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-21 04:36:21.580019
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    return

# Generated at 2022-06-21 04:36:37.088408
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:36:49.290695
# Unit test for function do_unvault
def test_do_unvault():
    from ansible_collections.ansible.community.plugins.filter.vault import FilterModule

    fm = FilterModule()

# Generated at 2022-06-21 04:37:00.005415
# Unit test for function do_vault
def test_do_vault():
    empty_secret = ""
    empty_string = ""
    empty_data = do_vault(empty_string, empty_secret)

# Generated at 2022-06-21 04:37:04.488279
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    test_filters = fm.filters()
    assert "vault" in test_filters
    assert "unvault" in test_filters


# Generated at 2022-06-21 04:37:05.721307
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert isinstance(module.filters(), dict)


# Generated at 2022-06-21 04:37:08.088956
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModule.filters()

# Generated at 2022-06-21 04:37:17.254404
# Unit test for function do_vault
def test_do_vault():
    data = "test_data"
    secret = "secret"
    assert do_vault(data,secret) == "$ANSIBLE_VAULT;1.2;AES256;default;00000000000000000000000\nanNhbGxlZnVja2V0Cg==\n66353739663033383635362d393038322d346138632d613934642d31363736383066\n35663736303639323939"


# Generated at 2022-06-21 04:37:21.096121
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:37:25.734952
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        FilterModule()
    except NameError:
        print ("Constructor Unit test for class FilterModule Failed")


# Generated at 2022-06-21 04:37:27.526274
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert isinstance(filter_module, FilterModule)


# Generated at 2022-06-21 04:37:48.883973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(None)
    assert 'unvault' in FilterModule.filters(None)

# Generated at 2022-06-21 04:38:04.006899
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # pylint: disable=protected-access
    print('\n***** Test FilterModule constructor *****')

    # Mask the Display class so we can inspect result
    display._debug = False
    display._display.verbosity = 3
    display._display.deprecated('Some deprecated message')
    display._display.skipped('Some skipped message')

    # Verify constructor
    f = FilterModule()
    assert isinstance(f, FilterModule)

    # Test filters()
    f = f.filters()
    assert isinstance(f, dict)
    assert 'vault' in f
    assert 'unvault' in f

    # Verify vault()

# Generated at 2022-06-21 04:38:10.884307
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:14.688690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:38:21.107479
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_vault_jinja2_filter = FilterModule()

    assert(hasattr(ansible_vault_jinja2_filter, 'filters'))


# Generated at 2022-06-21 04:38:33.635299
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('my secret', 'my secret', 'my salt', '12345') == b'!vault |$ANSIBLE_VAULT;1.1;AES256;12345\n306431303535623165333061346133386139386533623538356338650a32363435653962313434653961336238613961323137303737300a33366630333239323238323631643531653934656231346134313230333638626263323233663065346664376566643830390a', 'Unable to encrypt'

# Generated at 2022-06-21 04:38:41.442654
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f_module = FilterModule()
    filters = f_module.filters()

    assert len(filters.keys()) == 2
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:38:47.433962
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test that the filters dictionary is created as expected
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:38:51.635514
# Unit test for function do_unvault
def test_do_unvault():
    data=""
    secret=""
    vaultid=""
    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(data, secret, vaultid=vaultid)

# Generated at 2022-06-21 04:39:05.010517
# Unit test for function do_unvault
def test_do_unvault():
    from ansible_collections.misc.tests.units.modules.utils import set_module_args
    from ansible_collections.misc.tests.units.modules.utils import AnsibleExitJson
    from ansible_collections.misc.tests.units.modules.utils import AnsibleFailJson
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-21 04:39:55.682117
# Unit test for function do_vault