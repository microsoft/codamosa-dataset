

# Generated at 2022-06-21 04:30:03.145312
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'foo'
    plain_text = 'bar'
    vaultid = 'vaultid'

    def do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False):
        vs = VaultSecret(to_bytes(secret))
        vl = VaultLib()
        try:
            vault = vl.encrypt(to_bytes(data), vs, vaultid, salt)
        except UndefinedError:
            raise
        except Exception as e:
            raise AnsibleFilterError("Unable to encrypt: %s" % to_native(e), orig_exc=e)

        return vault

    vault = do_vault(plain_text, secret, vaultid)
    data = do_unvault(vault, secret, vaultid)
    assert plain_text == data

    #

# Generated at 2022-06-21 04:30:14.359118
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    from ansible.module_utils._text import to_text

    module = FilterModule()
    assert 'vault' in module.filters()

    string_to_encrypt = 'this string will be encrypted'
    vault_password = 'secret'

    # encrypt
    outcome = module.filters()['vault'](string_to_encrypt, vault_password)
    assert outcome
    assert string_to_encrypt != outcome
    assert isinstance(outcome, string_types)

    # decrypt
    outcome = module.filters()['unvault'](outcome, vault_password)
    assert outcome
    assert isinstance(outcome, string_types)
    assert string_to_encrypt == outcome

    # encrypt

# Generated at 2022-06-21 04:30:24.905848
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$$$sam'
    value = ''

# Generated at 2022-06-21 04:30:35.853304
# Unit test for function do_vault
def test_do_vault():
    import pytest

    vault = do_vault('sample_data', 'sample_salt', 'sample_secret')

# Generated at 2022-06-21 04:30:48.308606
# Unit test for function do_unvault
def test_do_unvault():

    # do_unvault should return string whenever no vault is provided
    assert isinstance(do_unvault('Any string', 'password'), str)

    # test vaulted string

# Generated at 2022-06-21 04:30:49.924225
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)


# Generated at 2022-06-21 04:30:53.180900
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert isinstance(result.filters(), dict)



# Generated at 2022-06-21 04:30:56.916373
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    print(x.__class__.__name__)
    assert x.__class__.__name__ == 'FilterModule'


# Generated at 2022-06-21 04:31:06.484701
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault_secret = '$ANSIBLE_VAULT;1.2;AES256;test_encryption_key435436543'
    secret = 'test_encryption_key435436543'
    vault = '$ANSIBLE_VAULT;1.2;AES256;test_encryption_key435436543\n83623864362636326331333664386638662d663764373263323635662d386534306436333834312d663939326562356536372d3330366532613066353663656239\n'
    expected_output = '1234567890'
    output = do

# Generated at 2022-06-21 04:31:18.454870
# Unit test for function do_vault
def test_do_vault():

    from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError

    vaultid = 'filter_default'

    class AnsibleFilterTypeErrorRaisingMock(object):
        def raise_excep(self, *args, **kwargs):
            raise AnsibleFilterTypeError(*args, **kwargs)


# Generated at 2022-06-21 04:31:25.627324
# Unit test for function do_unvault
def test_do_unvault():
    test_string = 'test'
    secret = 'test_secret'
    vault = do_vault(test_string, secret)
    assert do_unvault(vault, secret) == test_string

# Generated at 2022-06-21 04:31:32.667011
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    # assertEqual is a simple function that compares a and b and fails if they are not equal.
    assertEqual(filters['vault'], do_vault)
    assertEqual(filters['unvault'], do_unvault)


# Generated at 2022-06-21 04:31:33.714926
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:31:38.670311
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert not FilterModule().filters()['vault']('_test_data_', '_test_secret_')
    assert not FilterModule().filters()['unvault']('_test_data_', '_test_secret_')

# Generated at 2022-06-21 04:31:40.347133
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f

# Generated at 2022-06-21 04:31:41.136523
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:31:43.168240
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    my_filter = FilterModule()
    assert my_filter.filters() is not None

# Generated at 2022-06-21 04:31:52.701983
# Unit test for function do_vault
def test_do_vault():
    
    # test 1
    raw_data = 'test'
    vault_data = do_vault(raw_data, 'test_pass')
    assert(vault_data.startswith('$ANSIBLE_VAULT;'))
    assert(do_unvault(vault_data, 'test_pass') == raw_data)
    
    # test 2
    raw_data = 'how much wood would a woodchuck chuck if a woodchuck could chuck wood'
    vault_data = do_vault(raw_data, 'test_pass')
    assert(vault_data.startswith('$ANSIBLE_VAULT;'))
    assert(do_unvault(vault_data, 'test_pass') == raw_data)

    # test 3

# Generated at 2022-06-21 04:32:01.179313
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret_password'
    data = 'data_to_encrypt'
    expected_vault = '$ANSIBLE_VAULT;1.1;AES256;abcdefghij1234567890\n303735343837363330363731333166326137313962333864316665633138663162613838313363\n613436363965316661326262313461323461633962303861663365306639323236636236303834\n366130656334633630616335\n'

    vault = do_vault(data, secret)
    assert vault == expected_vault


# Generated at 2022-06-21 04:32:05.594295
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-21 04:32:20.076775
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    assert f.filters()['vault']('test', 'secret') == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6434626132313761316337643533383561323862653833326233386337653634663235363261396435\n          613663646662393064343063626261643239316665653864316635636335630a323364306535303338\n          6530626563393438363936343735336337613261316234633661623563613334623535343664383661\n          62636339323531666563393530643765666437610a'

# Generated at 2022-06-21 04:32:30.894586
# Unit test for function do_vault
def test_do_vault():
    b_secret = "AN5i1Hviivd896dyg5y5"
    s_secret = "AN5i1Hviivd896dyg5y5"
    s_data = "secret data"
    b_data = b"secret data"
    try:
        do_vault(s_secret, s_secret)
        assert False
    except AnsibleFilterTypeError:
        pass
    assert AnsibleVaultEncryptedUnicode(do_vault(b_data, b_secret, wrap_object=True)) == do_vault(s_data, s_secret)
    try:
        do_vault(b_secret, b_secret)
        assert False
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-21 04:32:39.913682
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello world', 'supersecret') == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n3533666464633638343962336662396133653530333666623664396365616432666363653738381a\n3465653862313961333232613261366230353033363837616136353665613564336538646532653839\n6631383462613064353536316663373536666363333966386533663161376331393533376331326438\n3465353066396662383663633166653235326531653166373065623431386133326262336439\n'


# Generated at 2022-06-21 04:32:50.570233
# Unit test for function do_unvault
def test_do_unvault():
    salt = 'salt'
    vaultid = 'test_do_unvault'
    secret1 = 'secret1'
    data = 'test_data'
    data_unicode = u'test_data'
    filtered_data = 'test_data'
    filtered_data_unicode = u'test_data'
    vault = do_vault(data, secret=secret1, salt=salt, vaultid=vaultid, wrap_object=False)
    do_unvault(vault, secret=secret1, vaultid=vaultid)
    vault = do_vault(data, secret=secret1, salt=salt, vaultid=vaultid, wrap_object=True)
    do_unvault(vault, secret=secret1)

# Generated at 2022-06-21 04:33:01.485712
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'foo'

    plain_data = 'bar'
    assert do_unvault(plain_data, secret) == plain_data

    plain_data = '{"foo": "bar", "baz": 1}'
    assert do_unvault(plain_data, secret) == plain_data

    try:
        do_unvault(1, secret)
        assert False
    except AnsibleFilterTypeError:
        assert True

    data = do_vault(plain_data, secret)
    assert do_unvault(data, secret) == plain_data

    data = AnsibleVaultEncryptedUnicode(do_vault(plain_data, secret))
    assert do_unvault(data, secret) == plain_data


# Generated at 2022-06-21 04:33:02.318989
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-21 04:33:12.287079
# Unit test for function do_vault
def test_do_vault():
    secret = "foobarbaz"
    plaintext = "plaintext"
    salt = "salt"
    vaultid = "foo"

    crypt = do_vault(plaintext, secret, salt, vaultid)


# Generated at 2022-06-21 04:33:18.800776
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters is not None
    assert 'vault' in filters
    assert 'unvault' in filters
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-21 04:33:24.983324
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import doctest
    from . import test_filter_vault
    test_filter_vault.__test__["FilterModule"] = doctest.testmod(test_filter_vault.test_FilterModule)

# Generated at 2022-06-21 04:33:30.834693
# Unit test for function do_unvault
def test_do_unvault():
    inStr = "vaulted password"
    outStr = "some password"
    vault = do_vault(outStr, inStr)
    assert vault.startswith("$ANSIBLE_VAULT;"), "Invalid vaulted password"
    unVault = do_unvault(vault, inStr)
    assert unVault == outStr, "Unvaulted password incorrect"

# Generated at 2022-06-21 04:33:43.485497
# Unit test for function do_unvault
def test_do_unvault():
    import unittest

    class TestDoUnvault(unittest.TestCase):

        def setUp(self):
            self.secret = 'ansible'


# Generated at 2022-06-21 04:33:46.953749
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        fl = FilterModule()
        assert fl
        assert fl.filters()
    except Exception as e:
        raise AnsibleFilterError("Unable to create: %s" % to_native(e), orig_exc=e)


# Generated at 2022-06-21 04:33:49.549206
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_unvault(do_vault('secret', 'password'), 'password') == 'secret'

# Generated at 2022-06-21 04:33:52.927991
# Unit test for function do_vault
def test_do_vault():
    result = do_vault(None, None)
    assert result == Undefined


# Generated at 2022-06-21 04:33:56.107009
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()

    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:34:02.107447
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:08.689347
# Unit test for function do_unvault
def test_do_unvault():
    import os;
    import yaml;
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = os.environ.get('VAULT_PASS', None)
    assert secret is not None, '$VAULT_PASS must be set in order to run this unit test'
    vaulted_yaml = yaml.load(open('test/data/test_unvault.yaml', 'r').read())
    for x in vaulted_yaml:
        if isinstance(x[1], AnsibleVaultEncryptedUnicode):
            x[1].vault = VaultLib([('test', VaultSecret(secret))])
        assert do_unvault(x[1], secret, 'test') == x[0]

# Generated at 2022-06-21 04:34:12.894787
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    vault = FilterModule()
    filters = vault.filters()

    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-21 04:34:27.110774
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:29.104351
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("yooo", "correct horse battery staple")


# Generated at 2022-06-21 04:34:42.178372
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:34:49.891938
# Unit test for function do_vault

# Generated at 2022-06-21 04:35:03.757401
# Unit test for function do_vault
def test_do_vault():
    # Test filter when secret is passed as a string
    secret = "secret"
    vault = do_vault(data="data", secret=secret, salt=None, vaultid='filter_default', wrap_object=False)
    assert isinstance(vault, string_types)
    assert vault.startswith("$ANSIBLE_VAULT")

    # Test filter when secret is passed as an Undefined object
    secret = Undefined()
    try:
        vault = do_vault(data="data", secret=secret, salt=None, vaultid='filter_default', wrap_object=False)
    except UndefinedError:
        assert True

    # Test filter when both secret and data are undefined objects
    secret = Undefined()
    data = Undefined()

# Generated at 2022-06-21 04:35:15.294246
# Unit test for function do_unvault
def test_do_unvault():
    # test code here
    v = do_vault('abcdef', 'ansible')
    print(v)
    # plaintext = do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\r\n34366430356639323962633635626438333835323739313366616138396634363064636539386562\r\n616565306332643336653338623863336632653335363836653339613036633461333663653230343\r\n53436637306331643737363533623538316363623730383163386130333762616139313861383163\r\n36383032633239346136303339633063366130653363343

# Generated at 2022-06-21 04:35:25.562074
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import unittest
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVault

    class TestFilterModule(unittest.TestCase):

        def setUp(self):
            self.filt_meta = FilterModule()
            self.filt_meta.filters()

        def tearDown(self):
            pass

        # Testing vault filter module

# Generated at 2022-06-21 04:35:40.557582
# Unit test for function do_unvault
def test_do_unvault():
    # Test passing in regular strings
    regular_string = "password"
    vault_secret = "vault_secret"
    data = do_unvault(regular_string, vault_secret)
    assert data == "password"

    # Test passing in encrypted strings
    vault = vault_secret.encode('base64').replace('\n', '')
    data = do_unvault(vault, vault_secret)
    assert data == "vault_secret"

    # Test passing in string that is too long to be vaulted
    # should raise an exception
    test_string = ""
    while len(test_string) < 16384:
        test_string += "a"
    try:
        data = do_unvault(test_string, vault_secret)
    except AnsibleFilterError:
        assert True

# Generated at 2022-06-21 04:35:42.228840
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()


# Generated at 2022-06-21 04:35:53.701866
# Unit test for function do_unvault
def test_do_unvault():
    secret_key = "hunter2"
    data_encrypted_correctly = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          633236643532626565663033646635313066303864373532333166393133666562313865316436\n          39383632376330623631653862363932360a333864383935643935653431336665303862626262\n          613236623134313234626262363764366137383638333634316333323730626238613231633761\n          62346362633065390a"
    data_decrypted = "test_data"
    data_decrypted_correctly = "test_data"

    assert do_

# Generated at 2022-06-21 04:36:04.116442
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible_user;1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef\n64543036326538353532356239653262633037373931306561353936363738663935653830653363\n62646533343765366262613833376266636434333961303633303062633061303938303831363261\n', 'secret', 'test') == 'test'

test_do_unvault()

# Generated at 2022-06-21 04:36:09.479235
# Unit test for function do_unvault
def test_do_unvault():
    assert isinstance(do_unvault('$ANSIBLE_VAULT;1.1;AES256;vault_default;255510155'
                                 '9315063.76061095474345235', 'vault_secret'), string_types)


# Generated at 2022-06-21 04:36:16.138973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'vault' in obj.filters()
    assert 'unvault' in obj.filters()


# Generated at 2022-06-21 04:36:25.979871
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class FilterModule:
        def filters():
            filters = {
                    'vault': do_vault,
                    'unvault': do_unvault,
            }

            return filters

    f = FilterModule()

    vault = f.filters['vault']


# Generated at 2022-06-21 04:36:40.142348
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:44.025878
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()



# Generated at 2022-06-21 04:36:46.145533
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:36:47.978731
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-21 04:36:58.081290
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:00.745686
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()


# Generated at 2022-06-21 04:37:01.218007
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()

# Generated at 2022-06-21 04:37:07.940574
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    result = do_vault(data, secret)
    expected = '$ANSIBLE_VAULT;1.1;AES256\n36396237363934366132393636653537616363303564623238623461343533613037613231633636\n3930616366653736663330643765656431326237300a356430616366656235353039363839383461\n65333335323038323065373536333431373437303665383764363466393765663463646233643662\n0a'
    assert result == expected


# Generated at 2022-06-21 04:37:17.186398
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    assert test_filter_module.filters()['unvault'] is do_unvault
    assert test_filter_module.filters()['vault'] is do_vault

# Generated at 2022-06-21 04:37:29.619916
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:44.139616
# Unit test for function do_vault
def test_do_vault():
    secret = "asdf"
    salt = "salt"
    vault_id = "filter_default"

    if not do_vault('test', secret).startswith('$ANSIBLE_VAULT'):
        raise AssertionError()

    if not do_vault('test', secret, salt).startswith('$ANSIBLE_VAULT'):
        raise AssertionError()

    if not do_vault('test', secret, vaultid=vault_id).startswith('$ANSIBLE_VAULT'):
        raise AssertionError()

    if not do_vault('test', secret, salt, vault_id).startswith('$ANSIBLE_VAULT'):
        raise AssertionError()


# Generated at 2022-06-21 04:37:52.948659
# Unit test for function do_vault
def test_do_vault():
    import json
    import os
    import pytest
    import tempfile

    # Get the vault secret
    secret = os.environ.get('ANSIBLE_VAULT_PASSWORD', 'secret')

    # Get the vault formats
    formats = json.load(open('tests/unit/filter_plugins/vault/vault_formats.json'))
    for version in formats:
        # Any vault id will do, don't need to reuse the salt
        salt = formats[version]["salt"]
        vaultid = 'test_id_%s' % version

        # Create a temporary file for testing
        with tempfile.NamedTemporaryFile() as f_name:
            # Write an unencrypted file to the temporary file
            data = {'foo': 'bar', 'baz': range(10)}

# Generated at 2022-06-21 04:38:04.918729
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:08.132112
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()['vault']
    assert FilterModule().filters()['unvault']

# Generated at 2022-06-21 04:38:10.975657
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm
    assert hasattr(fm, 'filters')
    assert hasattr(fm.filters(), '__call__')


# Generated at 2022-06-21 04:38:24.873552
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common._collections_compat import Mapping
    vault = do_vault("test", "blahblah")
    assert isinstance(vault, string_types)
    vault_obj = do_vault("test", "blahblah", wrap_object=True)
    assert isinstance(vault_obj, AnsibleVaultEncryptedUnicode)
    assert isinstance(vault_obj.vault, VaultLib)
    assert isinstance(vault_obj.vault._secrets, Mapping)
    assert isinstance(vault_obj.vault._secrets['filter_default'], VaultSecret)
    assert vault_obj.vault._secrets['filter_default'].get_secret() == 'blahblah'


# Generated at 2022-06-21 04:38:28.342814
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert callable(filters)
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:38:38.945741
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('', '', '') == ''
    assert do_unvault('yay', '', '') == 'yay'
    assert do_unvault('yay', '', '') == 'yay'
    assert do_unvault('foo', 'password', '') == 'foo'
    assert do_unvault('yay', 'password', '') == 'yay'

# Generated at 2022-06-21 04:38:56.233023
# Unit test for function do_vault
def test_do_vault():

    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils.six import PY3

    secret = VaultSecret('test')
    data = {
        'plain': 'hello world',
        'unicode': u'\u2713',  # checkmark
        }

    if PY3:
        data['bytes'] = b'\xff\xfe\xfd\xfc'  # other non-ascii bytes


# Generated at 2022-06-21 04:38:57.737777
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-21 04:39:00.910300
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'unvault': do_unvault, 'vault': do_vault}

# Generated at 2022-06-21 04:39:04.509806
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
	fm = FilterModule()
	filters = fm.filters()

	assert 'vault' in filters
	assert 'unvault' in filters

	assert len(filters['vault'].__doc__) > 0
	assert len(filters['unvault'].__doc__) > 0


# Generated at 2022-06-21 04:39:09.728997
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Check filters return value
    fm = FilterModule()
    filters = {
        'vault': do_vault,
        'unvault': do_unvault,
    }
    assert fm.filters() == filters

# Generated at 2022-06-21 04:39:11.557883
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f

# Generated at 2022-06-21 04:39:13.982829
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters().get('vault') == do_vault
    assert module.filters().get('unvault') == do_unvault



# Generated at 2022-06-21 04:39:22.896882
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    secret = 'secret'
    data = 'clear_data'

    vault = f.filters()['vault'](data, secret)
    assert data == f.filters()['unvault'](vault, secret)

    vault = f.filters()['vault'](data, secret, 'salt')
    assert data == f.filters()['unvault'](vault, secret, 'salt')



# Generated at 2022-06-21 04:39:26.685976
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create a FilterModule object
    obj = FilterModule()
    # Check if FilterModule is not null
    assert(obj is not None)

# Generated at 2022-06-21 04:39:33.936741
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    secret = '$ANSIBLE_VAULT;1.2;AES256;filter_default\n33353965666631356264626233313236636664346639323035643730393138386333653165323434\n32356236336661633664386665316238616432653832626130363933323366353336306664623838\n'
    secret = AnsibleUnicode(secret)
    output = do_unvault(secret, "foo")
    assert output == "bar"

# Generated at 2022-06-21 04:39:49.247396
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault_filters = FilterModule()
    assert vault_filters is not None
    assert vault_filters.filters() is not None

# Tests to demonstrate working of AnsibleVaultEncryptedUnicode