

# Generated at 2022-06-21 04:30:03.027092
# Unit test for function do_unvault
def test_do_unvault():

    test_vault_secret = 'Do_unvault_test_secret'
    test_vault_data = 'Do_unvault_test_data'
    failed_test_vault_data = 'Do_unvault_failed_test_data'
    test_salt = 'salt_value'
    test_vaultid = 'unvault_test_vaultid'

    # test_vault_data should be equal to the returned decrypted value
    test_vault_value = do_vault(test_vault_data, test_vault_secret, salt=test_salt, vaultid=test_vaultid)
    test_returned_vault_data = do_unvault(test_vault_value, test_vault_secret, vaultid=test_vaultid)


# Generated at 2022-06-21 04:30:14.371470
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import yaml
    assert do_unvault('$ANSIBLE_VAULT;1.1;AZUBVKzE1JHRV7hqf3dNUQwAJVugkMV7aQMhYYi1') == ''
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;blah;blah') == ''
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;blah;blah', 'super_secret') == ''
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;blah;blah', 'super_secret', 'blah') == ''

# Generated at 2022-06-21 04:30:23.808681
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:26.953753
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test with a string with valid length
    assert isinstance(FilterModule(), FilterModule) == True



# Generated at 2022-06-21 04:30:30.563922
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Unit test for constructor of class FilterModule

    Raises:
        None

    Returns:
        None

    """
    module = FilterModule()
    assert module

# Generated at 2022-06-21 04:30:31.093196
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(True)

# Generated at 2022-06-21 04:30:38.084529
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    filters = filter_module.filters()

# Generated at 2022-06-21 04:30:49.002478
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    data = 'data'

# Generated at 2022-06-21 04:31:01.824454
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:04.407595
# Unit test for constructor of class FilterModule
def test_FilterModule():
    v = FilterModule()
    assert isinstance(v.filters(), dict)


# Generated at 2022-06-21 04:31:18.454666
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:29.440504
# Unit test for function do_vault

# Generated at 2022-06-21 04:31:33.197858
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test"
    result = do_unvault(do_vault("test123", secret), secret)
    assert(result == "test123")


# Generated at 2022-06-21 04:31:36.332004
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Create a FilterModule
    """
    module = FilterModule()
    assert isinstance(module, FilterModule)


# Generated at 2022-06-21 04:31:40.420067
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'vault': do_vault,
        'unvault': do_unvault
    }

# Generated at 2022-06-21 04:31:51.570000
# Unit test for function do_unvault
def test_do_unvault():
    secret = "password"
    vault = '$ANSIBLE_VAULT;1.1;AES256\n333430363031386533323138363338353334353630336534623530333830656766393035663433\n383035633036343365303534376161350a3035383038386566336436663663396339356439666532\n3730383761323561303564376666313532653163633531613738336331663933\n'

# Generated at 2022-06-21 04:31:52.747609
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    F = FilterModule()
    assert F.filters().keys() == ["vault", "unvault"]

# Generated at 2022-06-21 04:31:55.015735
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(FilterModule.filters(FilterModule) is not None)


# Generated at 2022-06-21 04:31:58.461479
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:31:59.852216
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert issubclass(FilterModule, object)

# Generated at 2022-06-21 04:32:09.768617
# Unit test for function do_unvault
def test_do_unvault():
    vault_secret = "hello"
    vault_value = '$ANSIBLE_VAULT;1.1;AES256;x\n62346462343623464372364372626353662456332353437356439333764376261353333633538\n39333661356564343762623938353065386535643634396465663963333861623400000a\n'
    assert do_unvault(vault_value, vault_secret) == "xiaoyi"


# Generated at 2022-06-21 04:32:20.430945
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from datetime import datetime
    f = FilterModule()
    filters = f.filters()
    # Test do_vault filter

# Generated at 2022-06-21 04:32:31.101270
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:39.992148
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:42.088639
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None


# Generated at 2022-06-21 04:32:50.695321
# Unit test for function do_vault
def test_do_vault():

    secret = 'password'

    # Test that valid string is encrypted properly
    input_string = 'test'
    test_string = do_vault(input_string, secret)
    assert test_string != input_string

    # Test that invalid string raises an error
    input_string = ['test']
    try:
        do_vault(input_string, secret)
    except AnsibleFilterTypeError:
        assert True

    # Test that invalid secret raises an error
    input_string = 'test'
    secret = ['test']
    try:
        do_vault(input_string, secret)
    except AnsibleFilterTypeError:
        assert True


# Generated at 2022-06-21 04:33:01.950402
# Unit test for function do_unvault

# Generated at 2022-06-21 04:33:02.759414
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-21 04:33:03.599046
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()



# Generated at 2022-06-21 04:33:11.225680
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n306331333634383462336232633164643837356430353034363935643638666465366631323961653134\n643935653064616435643662383361623233336266613235633033643835\n'
    expected = 'vault'
    actual = do_unvault(vault, secret)
    assert actual == expected, "Expected: {0}, Actual: {1}".format(expected, actual)

# Generated at 2022-06-21 04:33:26.944692
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'plaintext'

# Generated at 2022-06-21 04:33:32.911090
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'secret'
    test_data = 'secret data'

# Generated at 2022-06-21 04:33:36.852789
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    x = f.filters()
    assert 'vault' in x
    assert 'unvault' in x


# Generated at 2022-06-21 04:33:39.471750
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters.get('unvault') == do_unvault

# Generated at 2022-06-21 04:33:47.482942
# Unit test for function do_vault
def test_do_vault():
    print("\n\n============================= test_do_vault =============================")
    data_1 = 'Inception'
    secret_1 = 'test'
    salt_1 = 'salt'
    vaultid_1 = 'test'
    wrap_object_1 = True
    expected_output_1 = '$ANSIBLE_VAULT;1.1;AES256;test\nsalt\nuXnRhsZJJGnZmB1q3w4geg==\n'

    data_2 = 'Inception'
    secret_2 = 'test'
    salt_2 = 'salt'
    vaultid_2 = 'test'
    wrap_object_2 = False

# Generated at 2022-06-21 04:34:02.061882
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:34:08.822739
# Unit test for function do_unvault
def test_do_unvault():
    unit_test_do_unvault = FilterModule()
    vault_value = "$ANSIBLE_VAULT;1.2;AES256;test_vaultid\n3035383063656139613661323965663365623834646564636631613238653836393933383262616534\n3466653036663664313864333662666132346165363065646566663564383038643033383734396362\n6537643637666430373364386361383565633138643633626161366134313662376335663933333231\n3536323333656636303130656437653938666563656264393334616665"

# Generated at 2022-06-21 04:34:23.889451
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'test_salt'
    vaultid = 'test_id'
    data = 'data'

# Generated at 2022-06-21 04:34:31.433350
# Unit test for function do_unvault
def test_do_unvault():
    import cryptography
    secret_key = 'A6Ug85vwnuV7fC9X'
    vault_secret = cryptography.fernet.Fernet(secret_key)
    original_data = 'tester'
    encrypted_data = vault_secret.encrypt(original_data)
    assert original_data == do_unvault(encrypted_data, secret_key)


# Generated at 2022-06-21 04:34:33.025762
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule.filters()

# Generated at 2022-06-21 04:34:42.810997
# Unit test for function do_vault
def test_do_vault():
    # Test for data
    data = 'foo'
    # Test for secret
    secret = 'bar'
    # Test for salt
    salt = 'salt'
    # Test for vaultid
    vaultid = 'test'
    wrap_object = False
    # Test for vault
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    assert vault.startswith('$ANSIBLE_VAULT;') == True



# Generated at 2022-06-21 04:34:43.562707
# Unit test for constructor of class FilterModule
def test_FilterModule():
  assert FilterModule() is not None

# Generated at 2022-06-21 04:34:52.417550
# Unit test for function do_vault
def test_do_vault():
    secret = 'my_secret'
    vault_string = do_vault('my_string', secret)
    assert isinstance(vault_string, string_types)

    vault_object = do_vault('my_string', secret, wrap_object=True)
    assert isinstance(vault_object, AnsibleVaultEncryptedUnicode)

    # This should pass and not raise an exception
    do_vault('my_string', secret, salt='my_salt')


# Generated at 2022-06-21 04:35:05.035565
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    vault = filters['vault']
    unvault = filters['unvault']

    # Test a string
    str = 'abc123'
    str_vaulted = vault(str, 'secret')
    str_unvaulted = unvault(str_vaulted, 'secret')
    assert str_unvaulted == str

    # Test an empty string
    str = ''
    str_vaulted = vault(str, 'secret')
    str_unvaulted = unvault(str_vaulted, 'secret')
    assert str_unvaulted == str

    # Test an empty string
    str = ' '
    str_vaulted = vault(str, 'secret')

# Generated at 2022-06-21 04:35:20.333250
# Unit test for function do_unvault
def test_do_unvault():
    # setup
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-21 04:35:22.460882
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['vault']
    assert filters['unvault']

# Generated at 2022-06-21 04:35:34.334141
# Unit test for function do_vault
def test_do_vault():
    secret = "test_secret"
    data = "test_data"
    output = do_vault(data, secret)

# Generated at 2022-06-21 04:35:43.246760
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    import os

    pwd = os.path.dirname(os.path.realpath(__file__))
    secret_file = os.path.join(pwd, 'vault.key')
    with open(secret_file) as f:
        secret = f.read()
    vl = VaultLib()
    vault = vl.encrypt('secret', secret_file=secret_file)
    data = vl.decrypt(vault)
    assert data == 'secret'

# Generated at 2022-06-21 04:35:44.576072
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return fm

# Generated at 2022-06-21 04:35:54.297498
# Unit test for function do_vault
def test_do_vault():
    secret = "testsecret"
    data = "testdata"

    # Assuming salt is returned as random and will be different every time this function is called
    salt = do_vault(data, secret)
    t = do_vault(data, secret, salt)
    assert t != data
    t1 = do_vault(data, secret, salt, "testvault")
    assert t1 != data
    assert t1 != t

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(123, 'secret')
    with pytest.raises(AnsibleFilterTypeError):
        do_vault('data', 123)
    with pytest.raises(AnsibleFilterError):
        do_vault(data, secret, salt='invalidsalt')

# Generated at 2022-06-21 04:36:06.634313
# Unit test for function do_vault
def test_do_vault():
    ''' Test do_vault function '''

    # Failure cases
    try:
        do_vault('data', None, None, 'VaultID', False)
    except AnsiFilterTypeError as exc:
        assert 'Secret passed is required to be a string' in str(exc)
    try:
        do_vault(None, 'Secret', None, 'VaultID', False)
    except AnsibleFilterTypeError as exc:
        assert 'Can only vault strings' in str(exc)
    try:
        do_vault([], 'Secret', None, 'VaultID', False)
    except AnsibleFilterTypeError as exc:
        assert 'Can only vault strings' in str(exc)

    # Success cases

# Generated at 2022-06-21 04:36:11.752125
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    v = do_vault('hello', secret)
    assert isinstance(v, string_types)
    assert do_unvault(v, secret) == 'hello'


# Generated at 2022-06-21 04:36:16.544343
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault_filters = FilterModule()
    filters = vault_filters.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:36:17.260688
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Should not fail, it is just a function
    FilterModule()

# Generated at 2022-06-21 04:36:27.962284
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('hello', 'secret', 'salt', 'vaultid', True) == '$ANSIBLE_VAULT;1.1;AES256;salt\n1234567890123456123456789012345612345678901234561234567890123456\n123456789012345612345678901234561234567890123456\n'
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;salt\n1234567890123456123456789012345612345678901234561234567890123456\n123456789012345612345678901234561234567890123456\n', 'secret', 'salt', 'vaultid') == 'hello'

# Generated at 2022-06-21 04:36:33.353653
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    retval = fm.filters()
    assert type(retval) is dict
    assert len(retval) == 2
    assert retval["vault"] == do_vault
    assert retval["unvault"] == do_unvault


# Generated at 2022-06-21 04:36:39.610864
# Unit test for function do_vault
def test_do_vault():
    secret = 'some-password'
    value = do_vault(data='some-data', secret=secret)
    assert value.startswith('$ANSIBLE_VAULT;')



# Generated at 2022-06-21 04:36:51.069099
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:56.757820
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:36:59.269493
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a is not None

# Generated at 2022-06-21 04:37:10.311436
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.__class__.__name__ == 'FilterModule'


# Generated at 2022-06-21 04:37:22.091748
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils import basic
    from jinja2 import Template

    vault_id = 'devsecops'
    vault_secret = 'Pa55w0rd'
    vault_salt = 'devsecops'

    # This playbook has one variable 'secret' which is encrypted using vault.
    # The variable 'secret' has a clear text value of 'devsecops'.
    # When we run the playbook through the filter plugin it should return the clear text value.
    # The playbook should run successfully and with no errors/exceptions/failures.

# Generated at 2022-06-21 04:37:31.686218
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-21 04:37:35.348680
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == do_vault, do_unvault



# Generated at 2022-06-21 04:37:40.938164
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-21 04:37:51.073778
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    data = 'geeks'
    test = do_vault(data, secret)
    assert test == '$ANSIBLE_VAULT;1.1;AES256\n37633762333637303864663566613939306464373531336263623964396136366432323737376\n33161326132303766656163323563373033383736373232653066373638313766376336396633\n34383330623962396666346334333662306230303262373163323533353763313630663862613\n6\n'

# Generated at 2022-06-21 04:38:04.161865
# Unit test for function do_vault
def test_do_vault():
    """
    Test do_vault function
    """
    # Make sure vault and unvault are working
    # We use different secrets to make sure that the secret is not reused
    # (and, thus, the vaultid is correctly used)

    # A secret that's a string and some arbitrary data
    assert do_unvault(do_vault("Top secret data", "secret"), "secret") == "Top secret data"

    # A secret that's a string and some arbitrary data (wrap object)
    assert do_unvault(do_vault("Top secret data", "secret", wrap_object=True), "secret") == "Top secret data"

    # A secret that's a string and some arbitrary data (vaultid)

# Generated at 2022-06-21 04:38:18.341745
# Unit test for function do_vault
def test_do_vault():
    class FilterModule(object):
        ''' dummy Ansible vault jinja2 filters '''

        def filters(self):
            filters = {
                'vault': do_vault,
                'unvault': do_unvault,
            }

            return filters

    my_filter = FilterModule()
    data = "mysecret"
    secret = "password"
    vault = data

    try:
        vault = my_filter.filters()['vault'](data, secret)
        data = my_filter.filters()['unvault'](vault, secret)
        print("Vault data: %s" % vault)
        print("Unvault data: %s" % data)
    except Exception as e:
        print ("unable to encrypt/decrypt: %s" % to_native(e))


# Generated at 2022-06-21 04:38:29.544277
# Unit test for function do_vault
def test_do_vault():
    # type: () -> None
    import pytest


# Generated at 2022-06-21 04:38:39.555873
# Unit test for function do_unvault

# Generated at 2022-06-21 04:39:02.656056
# Unit test for function do_vault
def test_do_vault():
    """
    Check that do_vault function return the encrypted string given input data and secret

    :return:
    """
    secret = 'PASSWORD'
    data = 'This is a secrect string'
    test_case = do_vault(data, secret)
    assert not is_encrypted(data)
    assert isinstance(test_case, str)
    assert is_encrypted(test_case)


# Generated at 2022-06-21 04:39:14.796238
# Unit test for function do_vault
def test_do_vault():

    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    data = "This is a secret string"
    secret = 'password123'

    # test values
    res_1 = '$ANSIBLE_VAULT;1.1;AES256;filter_default;xxxxx'
    res_2 = res_1 + "\nThis is a secret string\n"

    res_3 = '$ANSIBLE_VAULT;1.2;AES256;filter_default;XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX;XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\nXXX\n'

# Generated at 2022-06-21 04:39:25.398081
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret, VaultLib
    vs = VaultSecret('secret')
    vault = VaultLib([('default', vs)])
    default = vault.default_identity
    test_data = ['abc', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789']
    for data in test_data:
        encrypted_data = vault.encrypt(data, vs)
        decrypted_data = vault.decrypt(encrypted_data)
        assert data == decrypted_data
        assert vault.is_encrypted(encrypted_data)
        assert not vault.is_encrypted(data)
        assert not vault.is_encrypted(decrypted_data)

# Generated at 2022-06-21 04:39:40.391338
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for checking the filters.
    with open("FilterModule.txt", "w") as f:
        f.write("Hello World")

    data = "This is a sample string."
    secret = ""
    salt = ""
    vaultid = "test"
    wrap_object = False
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode("test")

    # Test for vault
    try:
        assert do_vault(data, secret, salt, vaultid, wrap_object) is not None
    except Exception as e:
        assert "Secret passed is required to be a string" in str(e)

    # Test for unvault

# Generated at 2022-06-21 04:39:48.958969
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('TestString', 'TestSecret')
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n3539366334613562393366306538393865323438623561643335393263393662343134613765316265\n3166346636353162396563623463396230303831333365356433636132373236353933616562366141\n3861303138386563643662366662346530626335343536663738323134393537663537656633653931\n\n'
