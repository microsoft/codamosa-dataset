

# Generated at 2022-06-21 04:30:08.927543
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:13.519024
# Unit test for function do_vault
def test_do_vault():

    test_data = 'this is a test'
    test_secret = 'vault_secret'

    filtered_data = do_vault(data=test_data, secret=test_secret)
    unfiltered_data = do_unvault(vault=filtered_data, secret=test_secret)

    assert unfiltered_data == test_data


# Generated at 2022-06-21 04:30:14.812889
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-21 04:30:27.189665
# Unit test for constructor of class FilterModule
def test_FilterModule():
    myFilter = FilterModule()
    myfilters = myFilter.filters()
    if not isinstance(myfilters, dict):
        return 'It is not a dictionary'
    if not 'unvault' in myfilters:
        return 'It does not have the filter "unvault"'
    if not callable(myfilters['unvault']):
        return 'It is not a function'
    if not isinstance(myfilters['unvault'], type(do_unvault)):
        return 'It is not the same function as the one defined in this file'
    if not 'vault' in myfilters:
        return 'It does not have the filter "vault"'
    if not callable(myfilters['vault']):
        return 'It is not a function'

# Generated at 2022-06-21 04:30:29.218028
# Unit test for function do_vault
def test_do_vault():
    secret='foo'
    data='bar'

    assert do_vault(data, secret) != "bar"


# Generated at 2022-06-21 04:30:36.701465
# Unit test for function do_vault

# Generated at 2022-06-21 04:30:39.807167
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    salt = 'test'
    vaultid = 'test'
    data = 'mystring'
    vault = do_vault(data, secret, salt, vaultid)
    assert isinstance(vault, str)



# Generated at 2022-06-21 04:30:50.908669
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.plugins.filter.vault import FilterModule
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import json

    # Generated vault string using ansible-vault encrypt_string --vault-id vaultid 'test'
    # The result is stored as a json string in the test_data_file because of expected newline characters
    with open('test_data.json', 'r') as json_data:
        test_data = json.load(json_data)
        test_vault_string = test_data['vault_string']

    filter_module = FilterModule()
    assert filter_module.filters()['unvault'](test_vault_string, 'test', 'vaultid') == 'test'

    # Test for a string without newline characters
    test_vault_string

# Generated at 2022-06-21 04:31:03.473771
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.template import Templar
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    templar = Templar(loader=None, variables={})

# Generated at 2022-06-21 04:31:07.194103
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    assert mod is not None, "Insufficient data to create class filter"


# Generated at 2022-06-21 04:31:11.376032
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Class FilterModule is not expected to have attributes
    pass

# Generated at 2022-06-21 04:31:12.215128
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:31:21.261075
# Unit test for function do_vault
def test_do_vault():
    secret = "raw_secret"
    plaintext = "raw_data"
    vaultenc = do_vault(plaintext, secret)

# Generated at 2022-06-21 04:31:22.678090
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:31:30.598290
# Unit test for function do_unvault
def test_do_unvault():
    f = FilterModule()
    filters = f.filters()
    assert filters['unvault']("$ANSIBLE_VAULT;1.1;AES256;test1\n33383066316135616262383764316338366338313237636237326261616561356337626261313433\n34663365383761656436333261376530636331623739623164376236663362623864336634393834\n32313936363362626238393835643435333661646236616262623965373331363765393162306531\n", "test1") == "password1"

# Generated at 2022-06-21 04:31:34.700857
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # trivial test to make sure FilterModule returns an object with expected elements (but not checking the content)
    fm = FilterModule()
    assert type(fm.filters) is dict

# Generated at 2022-06-21 04:31:45.813136
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35313262343162336366643366653536393764623038316635316462653934303362313431326137\n          64363437373335393937616435383735363635646432386564336432643034653964333233396431\n          31623431623363666433666539393\n'


# Generated at 2022-06-21 04:31:50.573854
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()

    result = filter_module.filters()

    # NOTE: the filter methods are not actually unit tested,
    #       because the unit tests already cover them in the ansible core library

    assert len(result) == 2
    assert result['vault'] == do_vault
    assert result['unvault'] == do_unvault

# Generated at 2022-06-21 04:31:54.235038
# Unit test for constructor of class FilterModule
def test_FilterModule():
    klass = FilterModule()
    assert klass.filters() == {'unvault': do_unvault, 'vault': do_vault}



# Generated at 2022-06-21 04:31:57.182158
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-21 04:32:01.953782
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() != {}


# Generated at 2022-06-21 04:32:08.082986
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-21 04:32:23.550935
# Unit test for function do_unvault
def test_do_unvault():
    """Test do_unvault method.
    """
    data = """
    {% set secret = 'my secret' %}
    {% set pwd = 'my pwd' %}
    {% set salt = 'my salt' %}
    {% set vault = '$ANSIBLE_VAULT;1.1;AES256' %}
    {% set vault_id = 'filter_default' %}
    {% set wrap_object = False %}
    {% do vault(data=secret, secret=pwd, salt=salt, vaultid=vault_id, wrap_object=wrap_object) %}
    """
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    loader = DataLoader

# Generated at 2022-06-21 04:32:33.290136
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six.moves import input
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.vault import get_file_vault_secret, get_vault_secret

    vaultid = None
    for arg in ('--vault-id', '--vault-password-file'):
        if arg in __import__('sys').argv:
            vaultid = arg
            break

    if vaultid:
        secret = get_vault_secret(vault_ids=[vaultid], vault_password_files=None, loader=None)
    else:
        secret = get_file_vault_secret(vault_password_files=['vault_password'], loader=None)


# Generated at 2022-06-21 04:32:34.819795
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-21 04:32:39.942833
# Unit test for function do_vault
def test_do_vault():
    # pylint: disable=import-error,unused-import
    from ansible.plugins.filter import vault

    assert isinstance(do_vault('secret', 'password'), string_types), 'Failed to encrypt'



# Generated at 2022-06-21 04:32:41.735352
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module
    assert filter_module.filters == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-21 04:32:42.623511
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-21 04:32:43.615206
# Unit test for function do_unvault
def test_do_unvault():
    pass

# Generated at 2022-06-21 04:32:50.853616
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible01\n31333366336231653930643338343139393563626239636439373130353836653735376339613638\n36363330343739666264653632613937663935663339633566646366353839373562313536303461\n31353962643738316562363365663565386634353861643266616463633239613064386362613263\n34363635663935366633\n', 'secret') == 'ansible01'
    assert not is_encrypted('ansible01')


# Generated at 2022-06-21 04:33:03.793041
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.hashing import secure_hash
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    filters = FilterModule()
    filters.filters()
    vault_pass = 'secret'
    test_data = "test data"
    salt = 'test-salt'
    vaultid = 'filter_default'
    vault_str = do_vault(test_data,secret=vault_pass, salt=salt, vaultid=vaultid)
    assert vault_str[:7] == '$ANSIBLE'

    assert vault_str[7:9] == '2A'
    assert vault_str[9:11] == '00'


# Generated at 2022-06-21 04:33:13.337501
# Unit test for function do_unvault
def test_do_unvault():
    # Test case with valid input
    data = do_unvault('$ANSIBLE_VAULT;1.1;AES256\n613534363138323961323536383262376539636536666532616463386233303865386631396235\n663530396664346566353837663432623561623461643265383635303835636266633463353932\n376864396632313962313734656538643336306365\n', 'Bogus key', vaultid='filter_default')
    assert data == 'Bogus text'

    # Test case VaultSecret with empty vault secret
    try:
        VaultSecret(b'')
    except Exception as e:
        assert str(e) == 'Secret must not be empty'

# Generated at 2022-06-21 04:33:15.439168
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert isinstance(obj, FilterModule)


# Generated at 2022-06-21 04:33:28.531567
# Unit test for function do_unvault
def test_do_unvault():
    clean_data = "This is some sample data"
    vault_secret = "This is my secret password"

    # Test with the given clean data, expecting it to be returned
    assert do_unvault(clean_data, vault_secret) == clean_data

    # Test with vault data, expecting the original data
    vaulted_data = do_vault(clean_data, vault_secret)
    assert do_unvault(vaulted_data, vault_secret) == clean_data

    # Test with a salt, expecting the original data
    vaulted_data = do_vault(clean_data, vault_secret, salt='salt')
    assert do_unvault(vaulted_data, vault_secret, salt='salt') == clean_data

    # Test with incorrect password

# Generated at 2022-06-21 04:33:32.351501
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected = {
        'vault': do_vault,
        'unvault': do_unvault,
    }

    assert FilterModule().filters() == expected

# Generated at 2022-06-21 04:33:45.916146
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test"

# Generated at 2022-06-21 04:33:47.170982
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-21 04:33:49.564584
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert hasattr(obj, 'filters')



# Generated at 2022-06-21 04:33:53.298508
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()

# Generated at 2022-06-21 04:34:06.180934
# Unit test for function do_unvault
def test_do_unvault():
    # We use a custom display class that does not write to stdout
    global display
    display = Display(verbosity=0)

    # Prepare filter for test
    f = FilterModule()

    # Test case 1
    # Secret is gibberish string
    secret = 'gibberish'
    # Vault is valid, but secret is not valid

# Generated at 2022-06-21 04:34:23.663961
# Unit test for function do_vault
def test_do_vault():
    result = do_vault(False, False)
    assert result == "", "do_vault failed. Expected 'False' result to be '', got: %s" % result

    result = do_vault("test_string", "secret")

# Generated at 2022-06-21 04:34:26.216442
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm_object = FilterModule()

    assert fm_object is not None, "Unable to create FilterModule object"


# Generated at 2022-06-21 04:34:30.455935
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    assert type(test_filter_module) == FilterModule
    assert type(test_filter_module.filters) == type(test_FilterModule.filters)


# Generated at 2022-06-21 04:34:33.365939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert isinstance(obj.filters(), dict)


# Generated at 2022-06-21 04:34:45.512817
# Unit test for function do_vault
def test_do_vault():
    # testing vault filter with some inputs

    import os
    import shutil
    import tempfile

    tmpdir = tempfile.mkdtemp()
    id_file = os.path.join(tmpdir, 'idfile')


# Generated at 2022-06-21 04:34:52.195527
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    vaultid = "filter_default"
    salt = None
    passwd = "password"

    # do vault
    vault_data = do_vault(passwd, secret, salt, vaultid)

    # do unvault
    data = do_unvault(vault_data, secret, vaultid)
    assert data == passwd, data

# Generated at 2022-06-21 04:35:01.879159
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('Test string', 'ansible', salt='test_id') == '$ANSIBLE_VAULT;1.1;AES256;test_id\r\n33316337313561633234623666316562333733303439653331393137316239633862603632336330\r\n396433346366663965313532653265316532663265336565303635663465383465\r\n'


# Generated at 2022-06-21 04:35:08.044483
# Unit test for method filters of class FilterModule

# Generated at 2022-06-21 04:35:09.540068
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-21 04:35:23.735077
# Unit test for function do_vault
def test_do_vault():
    secret = "vaultpass"
    data = "random-string"
    salt = "1234"
    vaultid = "filter_default"
    wrap_object = False

    # Call function do_vault without wrap_object
    assert do_vault(data, secret, salt, vaultid, wrap_object)[:8] == "$ANSIBLE_VAULT;1.1;AES256"
    assert do_vault(data, secret, salt, vaultid, False)[:8] == "$ANSIBLE_VAULT;1.1;AES256"

    # Call function do_vault with wrap_object
    assert do_vault(data, secret, salt, vaultid, True).data[:8] == "$ANSIBLE_VAULT;1.1;AES256"

# Generated at 2022-06-21 04:35:37.788564
# Unit test for function do_vault
def test_do_vault():
    import md5
    secret = "secret"
    data = "plaintext"
    salt = "salt"
    vault_obj = do_vault(data, secret, salt=salt, vaultid='testmd5')
    vault = vault_obj.data
    md5_obj = md5.new(secret+salt)
    md5_obj.update(data)
    expected_vault = "$ANSIBLE_VAULT;1.1;AES256;testmd5;%s\n%s\n" % (md5_obj.hexdigest(), data)
    if vault == expected_vault:
        display.display("test_do_vault PASSED")
    else:
        display.display("test_do_vault FAILED")

# Generated at 2022-06-21 04:35:40.444401
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_obj = FilterModule()
    assert isinstance(test_obj, FilterModule)


# Generated at 2022-06-21 04:35:50.262628
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('data_to_vault', 'data_to_vault') == '$ANSIBLE_VAULT;1.1;AES256;data_to_vault\n396262396534626436663963623637313763303365323937666436313862376336386132313665\n35363930333538323832666137386165643635393637373166643937333836316133390a\n'

# Generated at 2022-06-21 04:35:55.885727
# Unit test for function do_unvault

# Generated at 2022-06-21 04:36:04.329122
# Unit test for function do_unvault

# Generated at 2022-06-21 04:36:06.968387
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule())

# Generated at 2022-06-21 04:36:13.973100
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import LinuxDistribution
    from ansible.module_utils.facts.system.distribution import LinuxDistributionFact
    from ansible.module_utils.facts.system.distribution import LinuxDistributionMixin
    from ansible.module_utils.facts.system.distribution import LinuxDistributionSunOSMixin
    import facts
    secret = 'secretpassword'
    vaultid = 'ansible'
    salt = None
    wrap_object = False
    data = 'secretdata'
    data2 = [data]
    data3 = {data: data}
    data4 = 'secretdata,'
    data5 = 'secretdata\n'
    data6 = 'secretdata\r'
   

# Generated at 2022-06-21 04:36:26.881700
# Unit test for function do_vault

# Generated at 2022-06-21 04:36:33.831997
# Unit test for function do_unvault
def test_do_unvault():
    filtered_string = "This is a string"
    encrypted_string = "$ANSIBLE_VAULT;1.1;AES256\n3277725c5a5a5c3539303832336665333335336132356164363163393738316265303062346235\n34633931376439373764303631633331333231303638323662643035646233\n"
    secret = "password"
    assert do_unvault(encrypted_string, secret) == filtered_string

# Generated at 2022-06-21 04:36:47.648290
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common._collections_compat import _ensure_binary

    # Test exceptions
    secret = 'test_secret'
    data = 'test_data'
    salt = b'\xe0\x1d\xdb\x8d\xf0\xa3\x03\x94\xbc\xc8\x1d\x0b\xab\x8d\x1c\xf6\x00\x00\x00\x01'
    vaultid = 'vault_test'

    # 1. test default arguments

# Generated at 2022-06-21 04:37:05.312530
# Unit test for function do_vault
def test_do_vault():

    import base64
    from ansible.parsing.vault import VaultLib

    # Test that the vault works with simple text

# Generated at 2022-06-21 04:37:18.705394
# Unit test for function do_vault
def test_do_vault():
    secret = "R4ND0MPA55W0RD"
    data = "This is a secret, secret string"

# Generated at 2022-06-21 04:37:21.107664
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()


# Generated at 2022-06-21 04:37:24.928028
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    assert m.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:37:26.656407
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None



# Generated at 2022-06-21 04:37:27.425258
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:37:42.693965
# Unit test for function do_unvault

# Generated at 2022-06-21 04:37:52.368247
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:04.754671
# Unit test for function do_unvault

# Generated at 2022-06-21 04:38:07.153796
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Unit tests for function do_vault

# Generated at 2022-06-21 04:38:20.714077
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-21 04:38:25.072486
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)


# Generated at 2022-06-21 04:38:29.403570
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-21 04:38:33.188374
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None
    print("ansible.plugins.filter.vars.FilterModule::test_FilterModule() - \
           constructor - SUCCESS")

# Generated at 2022-06-21 04:38:36.259367
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert hasattr(FilterModule, "filters")
    assert callable(getattr(FilterModule, "filters"))


# Generated at 2022-06-21 04:38:45.073065
# Unit test for function do_vault
def test_do_vault():
    import random
    import string

    for i in range(10):
        # Test for 1000 times
        # Generate string

        str_len = random.randint(1, 100)
        secret_str = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(str_len))
        data_str = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(str_len))

        # Test for valid input
        vault = do_vault(data=data_str, secret=secret_str, wrap_object=False)
        data = do_unvault(vault=vault, secret=secret_str)

        assert is_encrypted(vault), "Vault result is not encrypted!"


# Generated at 2022-06-21 04:38:46.457826
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-21 04:38:55.919240
# Unit test for function do_vault

# Generated at 2022-06-21 04:39:06.083269
# Unit test for function do_unvault
def test_do_unvault():
    secret = None
    vaultid = None
    pv = do_unvault('!vault |$ANSIBLE_VAULT;1.1;AES256;foobar\r5661637465722d313531343335202d205675616e742077617463686573\r6393576838623264633731676234323738326763343966646661653663393\r3613763343131303236366635653966653238323732393739313230636266\r33303937393664363166303633343664393839633662366664663933646633\r36356338613833613237396264633330333466353562373162363236\r\r','foobar', 'foobar')

# Generated at 2022-06-21 04:39:13.820973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted
    from ansible.module_utils.six import string_types
    # Check if method filters of class FilterModule returns dict
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

    # Check if 'vault' key is present in dict
    filters = fm.filters()
    assert filters.get('vault') is not None

    # Check if 'unvault' key is present in dict
    assert filters.get('unvault') is not None

    # Check if 'vault' key has do_vault as its value.
    assert filters.get('vault') == do_vault

    # Check if 'unvault' key

# Generated at 2022-06-21 04:39:44.271744
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n356533626632626364326165346433326434623431643661343262613862393238326434643633\n303466316631376631616264663161626539646139626239653161376362643431643266353933\n303866386431333962306537623563626261376239323332643331313766666238353733353732\n663562646233393033356538396339623665393436616132393466373036363337306638343866\n34643136303735643930653437643237\n'


# Generated at 2022-06-21 04:39:49.248104
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    o = FilterModule()
    assert isinstance(o, FilterModule)
    assert o.filters() == {'unvault': do_unvault, 'vault': do_vault}