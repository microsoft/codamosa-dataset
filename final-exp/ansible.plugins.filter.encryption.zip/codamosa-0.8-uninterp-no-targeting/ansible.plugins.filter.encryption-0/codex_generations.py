

# Generated at 2022-06-21 04:30:09.588427
# Unit test for function do_unvault

# Generated at 2022-06-21 04:30:10.989757
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:30:13.878115
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()


# Generated at 2022-06-21 04:30:15.916684
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert FilterModule() is not None

# Generated at 2022-06-21 04:30:17.192433
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-21 04:30:22.998649
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'some-secret-key'
    vaultid = 'some-vault-id'
    text = 'unencrypted-text'
    vault = do_vault(text, secret, vaultid=vaultid)
    assert type(vault) is AnsibleVaultEncryptedUnicode
    assert do_unvault(vault, secret, vaultid) == text

# Generated at 2022-06-21 04:30:27.996864
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-21 04:30:30.496850
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        assert True
    except AssertionError:
        raise


# Generated at 2022-06-21 04:30:37.611343
# Unit test for function do_vault
def test_do_vault():
    secret = 'an_uncommon_secret'
    vaultid = 'filter_default'
    salt = 'insecurity'

    data = 'data_to_encrypt'
    expected_result = b'$ANSIBLE_VAULT;1.1;AES256\n36623163333763323562663762396431613138643161333333393836666233616138306465623833\n32646437346265646539316132313162306233366330663264356463393737353338316430383730\n343566363861306535356532303236353837373439'

    result = do_vault(data, secret, salt=salt, vaultid=vaultid, wrap_object=False)

    assert result == expected_result

# Unit

# Generated at 2022-06-21 04:30:48.485749
# Unit test for function do_vault
def test_do_vault():

    # No data
    assert do_vault(None, None) is None

    # No secret
    try:
        do_vault("foo", "bar")
    except AnsibleFilterError as e:
        assert "Secret passed is required to be as string" in e.args[0]
        assert "instead we got" in e.args[0]
        assert "foo" in e.args[0]

    # Invalid secret
    try:
        do_vault("foo", 123)
    except AnsibleFilterError as e:
        assert "Secret passed is required to be as string" in e.args[0]
        assert "instead we got" in e.args[0]
        assert "foo" in e.args[0]

    # Invalid data

# Generated at 2022-06-21 04:30:53.845726
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-21 04:31:04.456008
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean
    from ansible.plugins.loader import filters_loader

    # Add a fake filter plugin
    filters_loader.add_filter_plugin()

    # Mock ansible.module_utils.parsing.convert_bool.boolean() function
    BOOLEANS.clear()
    BOOLEANS['True'] = True
    setattr(boolean, 'return_value', True)

    # Run tests
    assert True == do_unvault('$ANSIBLE_VAULT;1.1;AES256;myuser54382359396235843745\nfjhdskjfhkdjsfhkdjkfhjsdfhkdjfhdsjkfhdsjkf\n;', '')

# Generated at 2022-06-21 04:31:10.236595
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    result = filter_obj.filters()
    print(result)

# Generated at 2022-06-21 04:31:12.883485
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule().filters()

# Test for method test_do_vault of class Answer

# Generated at 2022-06-21 04:31:16.456258
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters, "filter 'vault' not found in FilterModule"
    assert 'unvault' in filters, "filter 'unvault' not found in FilterModule"

# Generated at 2022-06-21 04:31:17.851690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-21 04:31:18.649552
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-21 04:31:25.324013
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_vault_filters = FilterModule()
    assert isinstance(ansible_vault_filters.filters(), dict)
    assert 'vault' in ansible_vault_filters.filters()
    assert 'unvault' in ansible_vault_filters.filters()


# Generated at 2022-06-21 04:31:39.398084
# Unit test for function do_vault
def test_do_vault():
    """ Unit test to check do_vault()"""
    secret = 'VaultSecret'
    salt = 'VaultSalt'
    vaultid = 'filter_default'
    data = 'Hello'
    expected_result = '$ANSIBLE_VAULT;1.2;AES256;filter_default;5gfB5pkHGJzYwYRQ6U1d+Q==;6hP4C4mJ5E5eLV+PegtkJbYHcODy/8+v3GqfNjLkp48J+o8d/NGuRQQ36fJ/wYC'
    result = do_vault(data, secret, salt, vaultid)
    assert result == expected_result


# Generated at 2022-06-21 04:31:51.053673
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.module_utils._text import to_native
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultSecret, VaultLib

    password = "vault-password"
    vaultid = "dev"

    # Create an instance of VaultSecret
    vs = VaultSecret(password)

    # Create an instance of VaultLib
    vl = VaultLib([(vaultid, vs)])

    # vaulted_data is a string

# Generated at 2022-06-21 04:31:55.231714
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), "filters")


# Generated at 2022-06-21 04:32:09.495139
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import sys
    import os
    import pytest
    sys.path.insert(1, os.path.join(os.path.dirname(__file__), '../../'))
    from ansible.plugins.filter import vault_legacy
    from ansible.parsing.vault import is_encrypted, VaultLib

    # If __name__ = '__main__' and this function is called,
    # the corresponding class FilterModule() will be executed.
    # The class FilterModule() will then call the filters() method
    # and finally assign the return dictionary value to the filters global var.
    filters = vault_legacy.FilterModule().filters()

    raw_data = "abc"
    secret = "@h4sht0ps3cr3t"
    salt = "pepper"
    vaultid = "filter_default"



# Generated at 2022-06-21 04:32:11.756387
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-21 04:32:13.712647
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-21 04:32:26.327617
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;myid\n63306639306435656564333537353334306235633233346162626131383666323632646639386336\n3864663633346539373534653835613461326261633662373834663163616366656531633663303132\n3031646431313365643034353938333864303666\n', 'ansible') == 'test'

# Generated at 2022-06-21 04:32:29.617447
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), "filters")
    assert callable(getattr(FilterModule(), "filters"))


# Generated at 2022-06-21 04:32:37.856460
# Unit test for function do_vault

# Generated at 2022-06-21 04:32:40.667735
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-21 04:32:51.103531
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import pytest

    vault = VaultLib()
    secret = 'secret'
    vs = vault.secrets[0].split('-')[0]
    with pytest.raises(AnsibleFilterError):
        do_unvault('$ANSIBLE_VAULT;1.2;AES256;ansible;616161616161', secret)

    with pytest.raises(AnsibleFilterError):
        do_unvault('$ANSIBLE_VAULT;1.2;ANSIBLE;ansible;616161616161', secret)


# Generated at 2022-06-21 04:33:02.663719
# Unit test for function do_vault
def test_do_vault():
    x = do_vault('hello world', 'my vault passwd')

    # This is the expected vault output

# Generated at 2022-06-21 04:33:12.998336
# Unit test for function do_vault

# Generated at 2022-06-21 04:33:23.003958
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'
    assert do_unvault(None, secret) is None
    assert do_unvault('', secret) == ''
    assert do_unvault('hello', secret) == 'hello'
    assert do_unvault(do_vault('hello', secret), secret) == 'hello'
    assert len(do_unvault(do_vault('hello', secret), secret, vaultid).encode("utf-8")) == 7

    # vaultid version
    assert len(do_unvault(do_vault('hello', secret), secret, 'otherid').encode("utf-8")) == 7

    # test vault object
    data = 'hello'
    vault = do_vault(data, secret)

# Generated at 2022-06-21 04:33:25.898854
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert isinstance(f.filters(), dict)



# Generated at 2022-06-21 04:33:31.502054
# Unit test for constructor of class FilterModule
def test_FilterModule():

    # Test if there is a filters method of type dict
    assert isinstance(FilterModule().filters(), dict)

    # Test if filters method returns the correct (key, value) pair
    assert isinstance(FilterModule().filters()['vault'], type(do_vault))
    assert isinstance(FilterModule().filters()['unvault'], type(do_unvault))


# Generated at 2022-06-21 04:33:32.929149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-21 04:33:37.148474
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'vault' in FilterModule().filters(), "Vault filter missing"
    assert 'unvault' in FilterModule().filters(), "Un-vault filter missing"


# Generated at 2022-06-21 04:33:47.062164
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.six.moves import cPickle
    teststr = 'a'*80
    secret = """$ANSIBLE_VAULT;1.1;AES256
3330653339643135333363362303639303565663364313465313862366363383835613161326236
3933383438316161393539650a3338663132616330336333633837353330666636333632653737
636561666631363833643465396331303633646539346435336665373130333865633165320a61
39373433353431653633613231346237313861366531306536613465363336353131"""

# Generated at 2022-06-21 04:33:51.222681
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] == do_vault
    assert fm.filters()['unvault'] == do_unvault



# Generated at 2022-06-21 04:33:56.094066
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert the_vault_method(filters['vault'])
    assert the_unvault_method(filters['unvault'])


# Generated at 2022-06-21 04:34:06.083783
# Unit test for function do_unvault

# Generated at 2022-06-21 04:34:23.393167
# Unit test for function do_unvault
def test_do_unvault():
    # Normal function
    assert do_unvault(u'$ANSIBLE_VAULT;1.1;AES256;teststringtest\n333137333566303762626237623566306532366137613931333964353530343839656132346165\n623439653930643163396130316163383961316334636536663061623732653635663332353866\n623166326439633861306531313230636132663238383737353635326330653066323261623365\n663837366234653137\n', secret=u'teststringtest') == u'testvaultstring'

    # Exception handling

# Generated at 2022-06-21 04:34:34.484013
# Unit test for function do_vault

# Generated at 2022-06-21 04:34:45.752947
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test with vault string
    filter_module = FilterModule()
    filters = filter_module.filters()
    # Test with vault string
    vault = filters['vault']('my_secret', 'my_pass')
    assert isinstance(vault, string_types)
    assert vault == u'$ANSIBLE_VAULT;1.1;AES256\r\n30623162383366343637323333643666643433333030623539353829383064633035663463363663\r\n3266306639303831613833383166663161623562646261663963383337396134373035\r\n'
    # Test with wrap object
    vault = filters['vault']('my_secret', 'my_pass', wrap_object=True)
   

# Generated at 2022-06-21 04:34:55.679598
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import string_types, binary_type, text_type
    import random
    import string

    random_string = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    random_data = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
    random_data_large = ''.join(random.choices(string.ascii_uppercase + string.digits, k=1024))

# Generated at 2022-06-21 04:35:06.371546
# Unit test for function do_vault

# Generated at 2022-06-21 04:35:16.442226
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.unsafe_proxy import AnsibleVarsUnsafeProxy
    import ansible.parsing.vault as vault

    class MockFiles(object):
        def __init__(self):
            self.content = "content=foo"

    class MockVaultLib(vault.VaultLib):
        def __init__(self):
            super(MockVaultLib, self).__init__()
            self.files = MockFiles()

    def mock_encrypt(self, data, secret, vault_id, salt=None):
        return "VAULT::foo"

    vault.VaultLib.file = property(lambda self: self.files)
    vault.VaultLib.encrypt = mock_encrypt

    secret = "foo"
    data = "bar"

# Generated at 2022-06-21 04:35:27.337658
# Unit test for function do_unvault
def test_do_unvault():
    # test the function do_unvault
    secret = "password"

# Generated at 2022-06-21 04:35:38.519522
# Unit test for function do_vault
def test_do_vault():
    import pytest
    data = "password: testing123"
    secret = "testing"
    vaultid = "testing"

    assert do_vault(data, secret, vaultid=vaultid, wrap_object=False) is not None

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(data, 1, vaultid=vaultid, wrap_object=False)

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(1, secret, vaultid=vaultid, wrap_object=False)

    with pytest.raises(AnsibleFilterError):
        do_vault(data, secret, vaultid='xxx', salt='xxx', wrap_object=False)


# Generated at 2022-06-21 04:35:51.428926
# Unit test for function do_unvault
def test_do_unvault():
    vault = "\$ANSIBLE_VAULT;1.2;AES256;filter_default\n35373735366638373566373933303733393830383335333634313033633330333561336136653935\n6632336239666161373730316262336534366234373738363230343638616535666539653139323\n9646634653162623239643461666462643931363266343531346261666536663564623162343664\n33643633\n."

    secret = "my_secret"

    assert do_unvault(vault, secret) == "my_data"

# Generated at 2022-06-21 04:35:57.201661
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class Object(object):
        pass

    obj = Object()
    obj.filters = FilterModule.filters(obj)

    assert isinstance(obj.filters, dict), \
        "Method `filters` of class FilterModule should return a dict"

# Generated at 2022-06-21 04:36:08.620878
# Unit test for function do_unvault
def test_do_unvault():
    # Test call with plain text
    plain_text = u"plain text"
    secret = VaultSecret('test')
    vaultid = 'test_vaultid'
    tests = [
        { "vault" : plain_text, "secret" : secret, "vaultid" : vaultid },
        { "vault" : AnsibleVaultEncryptedUnicode(plain_text), "secret" : secret, "vaultid" : vaultid },
    ]
    for test in tests:
        result = do_unvault(**test)
        expected_result = plain_text
        assert result == expected_result

    # Test call with encrypted text
    vault = u"test vault"
    secret = VaultSecret('test')
    vaultid = 'test_vaultid'

# Generated at 2022-06-21 04:36:14.549904
# Unit test for function do_unvault
def test_do_unvault():
    from base64 import b64encode
    from sys import version_info

    plain = b"test test %s" % version_info
    salt = b"password"
    secret = b"password"

    vault = b64encode(salt + b'$ANSIBLE_VAULT;1.1;AES256;n\n' + secret)

    assert do_unvault(vault, secret) == plain


# Generated at 2022-06-21 04:36:16.447269
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()


# Generated at 2022-06-21 04:36:18.323368
# Unit test for constructor of class FilterModule
def test_FilterModule():
    s = FilterModule()



# Generated at 2022-06-21 04:36:20.478089
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_obj = FilterModule()
    assert filter_obj is not None



# Generated at 2022-06-21 04:36:31.036871
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n633366303063326130376437333464333536643766336439663532683266343962366161386166\n653962003363666332316662333133353963313266623933386361663166656339613835386531\n3232353539616335396566663037636539\n", "", "filter_default") == "Hello World"

# Generated at 2022-06-21 04:36:41.926943
# Unit test for function do_vault
def test_do_vault():

    # Vault filter
    data = "hello world!"
    secret = "some_secret"

    vault = do_vault(data=data, secret=secret)

# Generated at 2022-06-21 04:36:52.456276
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import is_encrypted, VaultSecret
    from ansible.utils.encrypt import encrypt_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vaultid = 'filter_default'
    current_vault = VaultLib([(vaultid, VaultSecret('foo'))])
    vs = VaultSecret('foo')
    vault = encrypt_bytes(b'bar', vs)
    data = b'bar'
    secret = b'foo'
    salt = b'bar'
    result = AnsibleVaultEncryptedUnicode(vault)

    assert do_vault(data, secret, salt, vaultid) == result

# Generated at 2022-06-21 04:36:55.650153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert(module.filters['vault'](None, None, None, None, None) == '')


# Generated at 2022-06-21 04:37:08.439339
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'test_secret'
    test_data = 'This is a test'

# Generated at 2022-06-21 04:37:31.831882
# Unit test for function do_vault
def test_do_vault():
    test_vault = do_vault("test", "$ANSIBLE_VAULT;1.1;AES256;ansible", salt='ansible', wrap_object=True)
    assert isinstance(test_vault, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-21 04:37:43.174873
# Unit test for function do_unvault
def test_do_unvault():

    vault_secret = 'my secret'
    test_vault = '$ANSIBLE_VAULT;1.1;AES256\n363166303032626331663132376337363838316465366536343936643535613434633836353264\n623765653063653039616362386337643533373536363464383365663865326466396230303361\n39623662363936326437333735396163323561636661666336663643663626164336164326665\n6435653265643835336435393864663633376237636233633462616561\n'

    test_data = "Test line 1\nTest line 2\nTest line 3"


# Generated at 2022-06-21 04:37:51.415473
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'fasdfasdf'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n32353438646238616361643463353036353038353839646332366232353966373762633833353\n613536636433303535626261663164303539656665383936353562666232353338636638313961\n3433356261343166633433396634343130303536663339343666613531395a6b7a6b30632f396\n6003536383037\n'

# Generated at 2022-06-21 04:38:04.351465
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    # Valid vault
    v1 = '$ANSIBLE_VAULT;1.1;AES256\n393633623663303337303539386638353462356165333662373636306437343232333132376438\n62323263396266656039633662316364303763633263633236613231656139613132333561666634\n63393737353030323331393036356562633465366631323865\n'
    # Invalid vault

# Generated at 2022-06-21 04:38:07.289786
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

    # Testing the filters from the constructor
    assert f.filters() is not None


# Generated at 2022-06-21 04:38:10.384684
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-21 04:38:23.269078
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible import context
    import pytest
    from utils import set_module_args

    #
    # unit tests for filters of class FilterModule
    #

    # ----------
    # test:
    # ----------
    set_module_args(dict(password='password'))
    context._init_global_context(play_context=dict(password='password'))

# Generated at 2022-06-21 04:38:25.416216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule) is not None


# Generated at 2022-06-21 04:38:27.970839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        test_filter = FilterModule()
        assert True
    except:
        assert False



# Generated at 2022-06-21 04:38:38.677692
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vs = VaultSecret('mysecret')
    vl = VaultLib()
    vault = vl.encrypt('myvault', vs)
    assert is_encrypted(vault) == True
    assert isinstance(vault, AnsibleVaultEncryptedUnicode) == True
    assert isinstance(vault.vault, VaultLib) == True

    salt = vl.get_salt(vault)
    assert salt is not None

    data = vl.decrypt(vault)
    assert isinstance(data, bytes) == True
    assert data == b'myvault'

# Generated at 2022-06-21 04:39:05.852235
# Unit test for function do_vault
def test_do_vault():
    # Create a dummy filter to enable display
    class TestDisplay(Display):
        verbosity = 0
        display = False
        _display_warnings = False
        _display_skipped_hosts = False
        def verbosity_check(self, verbosity, *args, **kwargs):
            return self.display
    display = TestDisplay()
    # Create a playbook to enable get_vault_secret
    class TestPlaybook(object):
        def __init__(self, secret, vaultid):
            self.vault_passwords = {vaultid: secret}
    import os
    import doctest
    import ansible.parsing.vault
    from ansible.plugins.filter.vault import FilterModule

# Generated at 2022-06-21 04:39:08.370108
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'vault' in obj.filters()
    assert 'unvault' in obj.filters()


# Generated at 2022-06-21 04:39:18.123918
# Unit test for function do_vault

# Generated at 2022-06-21 04:39:24.672379
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Arrange
    ansible_vault_filter_module = FilterModule()
    # Act
    ansible_vault_filter_module_filters = ansible_vault_filter_module.filters()

    # Assert
    assert ansible_vault_filter_module_filters["vault"] == do_vault
    assert ansible_vault_filter_module_filters["unvault"] == do_unvault



# Generated at 2022-06-21 04:39:39.613461
# Unit test for function do_vault
def test_do_vault():
    # Test Value
    TEST_VALUE = 'Hello!'

    # Test secrets
    secret1 = 'TEST_SECRET'
    secret2 = 'TEST_SECRET2'
    secret3 = 'TEST_SECRET3'
    secret_data = 'Test Secret'

    # Test salts
    salt1 = 'TEST_SALT'
    salt2 = 'TEST_SALT2'
    salt_data = 'Test Salt'

    # Testing with no salt
    try:
        encrypted = do_vault(TEST_VALUE, secret_data)
        assert isinstance(encrypted, string_types)
        assert is_encrypted(encrypted)
    except Exception as e:
        assert False, to_native(e)

    # Testing with salt

# Generated at 2022-06-21 04:39:49.557779
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;1.1;AES256;foo_bar\n33386530623232613365656633396339373032353934383964636362376634633437393334336138\n63373839353731353563616439313766313763666332643235616432333462313464303032333865\n34303561633761643764366638643466366233353561323039333664353437643639346435643837\n3435363239333666353665666430376235643966626430633439\n' == do_vault('foo_bar', 'password')
