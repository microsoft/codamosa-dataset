

# Generated at 2022-06-25 09:09:32.074390
# Unit test for function do_vault

# Generated at 2022-06-25 09:09:42.305166
# Unit test for function do_vault
def test_do_vault():

    # Test for string
    assert do_vault("test","secret") is not None
    assert do_vault("test","secret")
    assert do_vault("multiline string\nwith newline {} \n{} {}","secret")
    assert do_vault("string with unicode ☃","secret")

    # Test for string in wrap_object format
    assert do_vault("test","secret",wrap_object=True) is not None
    assert do_vault("test","secret",wrap_object=True)
    assert do_vault("multiline string\nwith newline {} \n{} {}","secret",wrap_object=True)
    assert do_vault("string with unicode ☃","secret",wrap_object=True)

    # Test for binary

# Generated at 2022-06-25 09:09:47.176514
# Unit test for function do_vault
def test_do_vault():
    in_0 = "yFVnjfRxRnkMwS"
    in_1 = "XIe4qD4qPcHR"
    in_2 = "0py2BatS"
    assert(do_vault(in_0, in_1, in_2) == "yFVnjfRxRnkMwS")



# Generated at 2022-06-25 09:09:54.098534
# Unit test for function do_unvault
def test_do_unvault():
    # Test case variables
    vault_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    secret_0 = '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-25 09:10:00.028850
# Unit test for function do_unvault
def test_do_unvault():
    display.display('Test do_unvault...')

    my_secret = VaultSecret('foo')
    vlib = VaultLib([('my_secret', my_secret)])
    my_data = vlib.encrypt(to_bytes('my favorite data'))

    my_data = AnsibleVaultEncryptedUnicode(my_data)
    my_data.vault = vlib
    assert my_data.data == to_native('my favorite data')

    assert do_unvault(my_data, 'foo') == to_native('my favorite data')


# Generated at 2022-06-25 09:10:06.839163
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2.runtime import Undefined
    
    assert isinstance(do_unvault("", "", ""), str)
    
    assert do_unvault("", "", "") == ""

    assert isinstance(do_unvault("", "", str()), str)
    
    assert do_unvault("", "", str()) == ""
    
    assert isinstance(do_unvault("", Undefined, ""), Undefined)
    
    assert isinstance(do_unvault("", Undefined, Undefined), Undefined)



# Generated at 2022-06-25 09:10:15.341108
# Unit test for function do_vault
def test_do_vault():
    # Tests that the filter fails with a non-string secret
    secret_0 = false
    data_0 = ''
    salt_0 = None
    vaultid_0 = 'filter_default'
    wrap_object_0 = false
    test_0 = do_vault(data_0, secret_0, salt_0, vaultid_0, wrap_object_0)
    assert test_0 is UndefinedError
    # Tests that the filter fails with a non-string data
    secret_1 = ''
    data_1 = false
    salt_1 = None
    vaultid_1 = 'filter_default'
    wrap_object_1 = false
    test_1 = do_vault(data_1, secret_1, salt_1, vaultid_1, wrap_object_1)
    assert test_1 is UndefinedError

# Generated at 2022-06-25 09:10:18.902216
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault='$ANSIBLE_VAULT;1.2;AES256;foo', secret='foobar') == 'bar'

if __name__ == '__main__':
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:10:25.204977
# Unit test for function do_unvault
def test_do_unvault():
    list_0 = ['TESTSTRING', 'TESTSTRING']
    list_1 = []
    str_0 = 'filter_default'
    str_1 = 'TESTSTRING'
    str_2 = 'TESTSTRING'
    assert do_unvault(*list_0, **dict(vaultid=str_0)) == str_1
    assert do_unvault(*list_1, **dict(vaultid=str_2)) == str_1


# Generated at 2022-06-25 09:10:27.249166
# Unit test for function do_unvault
def test_do_unvault():
    vault_0 = '$ANSIBLE_VAULT;1.1;AES256;salt\n'
    secret_0 = ''
    assert do_unvault(vault_0, secret_0) == ''


# Generated at 2022-06-25 09:10:38.178569
# Unit test for function do_vault
def test_do_vault():
    fm = FilterModule()
    filters = fm.filters()
    # Make sure all the filters are loaded
    assert len(fm.filters()) > 0
    # Make sure our filter is loaded
    assert filters.get('vault') is not None
    # Check that ansible_vault.do_vault raises an AnsibleFilterTypeError
    # when secret is the wrong type
    try:
        filters['vault'](None, None, None)
        assert False
    except AnsibleFilterTypeError:
        assert True


# Generated at 2022-06-25 09:10:41.647827
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('testdata', 'testsecret') == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n3933643765353430353633363237396464623966613964363464303433316237663732613031\n3363316163636332316433396464613331386138613162366330316261353363303936'
# unit test for function do_unvault

# Generated at 2022-06-25 09:10:51.509325
# Unit test for function do_vault
def test_do_vault():
    secret = "This is a secret"
    vaultid = "filter_default"
    salt = None
    assert do_vault("mypassword", secret, salt, vaultid) == "$ANSIBLE_VAULT;1.1;AES256\n61616161616161616161616161616161616161616161616161616161616161616161616161616161616\n161616161616161616161616161616161616161616161616161616161616161616161616161616161616\n1616161616161616161616\n"

# Generated at 2022-06-25 09:10:57.937199
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(b'$ANSIBLE_VAULT;1.1;AES256;db2\n35613930666164313138336430363332623262643163383833663135323661653138626461356364\n38653464633963616232626663386534666330336463633234313161363132333264333536333034\n3231306263376562376264373566643332383364',
                      b'ansible',
                      vaultid='filter_default',
                      ) == 'test'


# Generated at 2022-06-25 09:11:04.289537
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == do_unvault(do_vault('test', 'secret'), 'secret')
    try:
        assert not do_vault('test', ['nope']) == do_unvault(do_vault('test', 'secret'), 'secret')
    except AnsibleFilterTypeError:
        pass

# Generated at 2022-06-25 09:11:09.964959
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    # Verify if function 'do_vault' raises a TypeError exception when the
    # 'secret' parameter is not a string or a unicode object.
    for secret_arg in [None, 1, {1: 2}, [1, 2]]:

        # Execute function 'do_vault'
        raised_exception = False
        try:
            filters['vault']('string', secret_arg)
        except AnsibleFilterTypeError:
            raised_exception = True
        assert raised_exception

    # Verify if function 'do_vault' raises a TypeError exception when the
    # 'data' parameter is not a string or a unicode object.

# Generated at 2022-06-25 09:11:21.138255
# Unit test for function do_unvault
def test_do_unvault():
    stat1 = dict()
    stat1["local_mode"] = "false"
    stat1["group"] = "root"
    stat1["mode"] = "0755"
    stat1["path"] = "/opt/ansible_test_00/test_00.txt"
    stat1["owner"] = "root"

    stat2 = dict()
    stat2["local_mode"] = "false"
    stat2["group"] = "root"
    stat2["mode"] = "0755"
    stat2["path"] = "/opt/ansible_test_01/test_01.txt"
    stat2["owner"] = "root"

    vault_secret = "vault_secret"
    vault_secret_id = "vault_id"
    test_data = dict()

# Generated at 2022-06-25 09:11:28.713189
# Unit test for function do_vault
def test_do_vault():
    #pass

    assert do_vault("abc 123", "mysecret") == b"$ANSIBLE_VAULT;1.2;AES256;filter_default\n396335616135393430613537333464666530316331353363616262623433653630373934646636\n613038643836353438626465316337623235333866326630633835663139363435636663353131\n626565356531353135316531656437303861623265663161356363613333396365326666656432\n61386366376536376265326365323032353139313231333138626236\n", "Test case 0 for function do_vault"

    


# Generated at 2022-06-25 09:11:39.410244
# Unit test for function do_unvault
def test_do_unvault():
    vault_string = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          373337373934366335333964356234396236616132393036353632373033363066613265373038\n          3532363331643935356161633130663736366635646236650a773266663965633561376564326f\n          373965346661313766316132666130353137636432623661393962643963306262303333346130\n          616232643866333536320a323466663135343164306534343237323032386232343239306234\n        "

    secret = "password"

    vaultid = "filter_default"

    result = do_

# Generated at 2022-06-25 09:11:43.447108
# Unit test for function do_vault
def test_do_vault():
    password = 'helloworld'
    data = 'secret'
    vault = do_vault(data, password)
    assert '$ANSIBLE_VAULT;' in vault



# Generated at 2022-06-25 09:11:54.901726
# Unit test for function do_vault
def test_do_vault():
    '''
    Unit test for function do_vault
    '''
    # Vaulting should succeed
    secret = 'secret'
    data = 'data to be vaulted'
    vault = do_vault(data, secret)
    assert isinstance(vault, str)

    # Undefined secret should throw an error
    secret = Undefined()
    data = 'data to be vaulted'
    try:
        vault = do_vault(data, secret)
        assert False
    except UndefinedError:
        assert True

    # Undefined data should throw an error
    secret = 'secret'
    data = Undefined()
    try:
        vault = do_vault(data, secret)
        assert False
    except UndefinedError:
        assert True
        
    # Invalid data type should throw an error

# Generated at 2022-06-25 09:11:56.312602
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("test", "test")

# Generated at 2022-06-25 09:12:05.818707
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:06.684685
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    assert filter_module_0.do_unvault()



# Generated at 2022-06-25 09:12:14.883632
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    user_input_0 = 'foo'
    user_input_1 = ''
    user_input_2 = '1'
    user_input_3 = False
    user_input_4 = True
    user_input_5 = 'foo'
    user_input_6 = 0
    user_input_7 = 'foo/bar/bar'
    assert filter_module_0.filters()['vault'](user_input_0, user_input_1, user_input_2, user_input_3, user_input_4, user_input_5, user_input_6, user_input_7) is not None

# Generated at 2022-06-25 09:12:25.486994
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:33.777458
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()

# Generated at 2022-06-25 09:12:40.903045
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()

    try:
        data = filter_module.filters()['vault']('hello world', 'mypassword')

        if '$ANSIBLE_VAULT;' in data:
            is_encrypted_data = True
        else:
            is_encrypted_data = False

        assert is_encrypted_data == True
    except AssertionError:
        pass
    else:
        print("Test case for function do_vault")


# Generated at 2022-06-25 09:12:45.856156
# Unit test for function do_vault
def test_do_vault():
    data = 'ANSIBLE-VAULT'
    assert (do_vault(data, 'secret', salt=None, vaultid='filter_default', wrap_object=False) == '$ANSIBLE_VAULT;1.1;AES256;filter_default\ndXJpZW50YXRpb24KZXhhbXBsZQo=\n')


# Generated at 2022-06-25 09:12:56.033798
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('abcdefg', 'abcdefg', salt=None, vaultid='filter_default', wrap_object=False) == '$ANSIBLE_VAULT;1.1;AES256\ndJGfbzcZj+a8RJykp7fhzznEIy+bK9JQ2q3qxJIDUuuk6UZ8Q2O3q53jAcP0uV7h\nnsRbV7v+z1ZN0CZgKTj0oQ==\n'


# Generated at 2022-06-25 09:13:08.270158
# Unit test for function do_vault
def test_do_vault():
    # Test with a simple string
    assert do_vault("foo", "bar") == "$ANSIBLE_VAULT;1.1;AES256\n6630323132303665373364633638333132626162303465666465633432313761663731623762613\n36323437616333613764323637326261656338323534376362316132376566393832623131393933\n3539653837663131610a663236383861626636353139613537396466353437666537656135343732\n363730376538363661\n"
    # Test with an empty string

# Generated at 2022-06-25 09:13:18.580638
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:24.872036
# Unit test for function do_vault
def test_do_vault():

    result = do_vault('test','test')

# Generated at 2022-06-25 09:13:33.107207
# Unit test for function do_vault
def test_do_vault():
    res = do_vault('test_string', 'secret')
    assert res == '$ANSIBLE_VAULT;1.1;AES256\n343662326662323864666534333934306231623132613163393566633230313864633839366663\n323661623135616439646366643833356662316137346565363832653766613039663738356630\n'


# Generated at 2022-06-25 09:13:40.361866
# Unit test for function do_vault
def test_do_vault():
    secret1 = "password"
    data1 = "This string is unencrypted"
    vault1 = '$ANSIBLE_VAULT;1.1;AES256;filter_default\n3930663733373734653038396565353738366633623962306362653366333263306630393663323538\n3034616338626230643433333335383265333161346236346665666631333963393066373337373465\n303839656535373836663362396230636265336633326330663039366332353830300a\n'
    assert(do_vault(data1, secret1) == vault1)



# Generated at 2022-06-25 09:13:49.118129
# Unit test for function do_vault
def test_do_vault():
    data = "foo"
    secret = "baz"
    salt = ""
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-25 09:13:58.798177
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:05.308363
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("data", "secret", "salt", "filter_default", False) == AnsibleVaultEncryptedUnicode(to_bytes(b"$ANSIBLE_VAULT;1.1;AES256\n36353739653437383437656236656532333462656337643931356161363635643338376434393564\n31643066356439633765643866313365616233323037613065353464303933303461316131663866\n3965653466306164313530656338\n"))


# Generated at 2022-06-25 09:14:15.029068
# Unit test for function do_unvault
def test_do_unvault():
    import unittest2

    ansible_vault_0 = AnsibleVaultEncryptedUnicode('ANSIBLE_VAULT;1.1;AES256')
    ansible_vault_1 = AnsibleVaultEncryptedUnicode('ANSIBLE_VAULT;1.1;AES256')
    test_case_0 = FilterModule()


# Generated at 2022-06-25 09:14:22.979599
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("0a1b2c3d4e5f6g7h8i9j", "ansible") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6161326263346435663667376836693a6a616b636b6e356c6f63756d7252707a686a694347302b37\n          404a6a663842356f305a61653d0a"


# Generated at 2022-06-25 09:14:27.865120
# Unit test for function do_unvault
def test_do_unvault():
    # Check for success
    assert isinstance(do_unvault("$ANSIBLE_VAULT;1.1;AES256;", "hashed"), string_types)



# Generated at 2022-06-25 09:14:36.176843
# Unit test for function do_vault
def test_do_vault():
    data='the quick brown fox jumped over the lazy dog'
    secret= 'this is my secret'
    salt=None
    vaultid='filter_default'
    wrap_object=False
    
    # Test the case where the data is not plain (undefined), secret is a string, salt is not defined and wrap_object is False
    assert do_vault(Undefined, secret, salt, vaultid, wrap_object) == 'Undefined'

    # Test the case where the data is plain (string), secret is a string, salt is not defined and wrap_object is False

# Generated at 2022-06-25 09:14:43.479538
# Unit test for function do_vault
def test_do_vault():

    # Call function do_vault with required args
    try:
        do_vault(data="ansible",secret="ansible")
    except AnsibleFilterError:
        pass

    # Call function do_vault with all args
    try:
        do_vault(data="ansible",secret="ansible",salt="ansible",vaultid="ansible",wrap_object="ansible")
    except AnsibleFilterError:
        pass



# Generated at 2022-06-25 09:14:47.308988
# Unit test for function do_unvault
def test_do_unvault():
    vl = VaultLib()
    text = 'ansible_password'
    secret = VaultSecret(text)
    secure_text = vl.encrypt(text, secret)
    assert do_unvault(secure_text, text)


# Generated at 2022-06-25 09:14:49.959054
# Unit test for function do_vault
def test_do_vault():
    res = do_vault('test', 'secret')
    print(res)


# Generated at 2022-06-25 09:14:55.275407
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'my_secret'
    vaultid = 'filter_default'
    data = 'Bagel'
    expected_result = 'Bagel'

    result = do_vault(data, secret, vaultid=vaultid)
    assert isinstance(result, string_types) == True
    assert is_encrypted(result) == True

    result = do_unvault(result, secret, vaultid=vaultid)
    assert isinstance(result, string_types) == True
    assert result == expected_result

# Generated at 2022-06-25 09:15:04.861734
# Unit test for function do_vault
def test_do_vault():

    data_0 = 'Hello World'
    secret_0 = 'my_secret'
    vault_0 = do_vault(data_0,secret_0)

# Generated at 2022-06-25 09:15:11.454356
# Unit test for function do_vault
def test_do_vault():
    vault_0 = do_vault('test_data', 'test_secret')


# Generated at 2022-06-25 09:15:16.744285
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    password = 'secret'
    data = 'my_secret_password'
    vaultid = 'vaultid_test'
    secret = 'secret'
    salt = 'salt'
    encrypted_data = filter_module.filters().get('vault')(data, secret, salt, vaultid)
    decrypted_data = filter_module.filters().get('unvault')(encrypted_data, secret, vaultid)
    assert data == decrypted_data

# Generated at 2022-06-25 09:15:29.472707
# Unit test for function do_vault
def test_do_vault():
    data = 'test'
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-25 09:15:43.430934
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:54.320500
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:00.040488
# Unit test for function do_unvault
def test_do_unvault():
    source_json = '{"key": "{{ vault_secret }}", "passwd": "default_pass"}'
    expected_json = '{"key": "super_secret_string", "passwd": "default_pass"}'
    filters = FilterModule()
    secret = "super_secret_string"
    ret = filters.filters()['unvault'](source_json, secret)
    assert ret == "super_secret_string"


# Generated at 2022-06-25 09:16:09.981668
# Unit test for function do_vault
def test_do_vault():
    display.display("Starting test_do_vault", color='green')

# Generated at 2022-06-25 09:16:10.454405
# Unit test for function do_unvault
def test_do_unvault():
    assert True == True


# Generated at 2022-06-25 09:16:21.275106
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:32.795817
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:43.133613
# Unit test for function do_vault
def test_do_vault():
    data = "foo"
    secret = "bar"
    salt = "baz"
    vaultid = "filter_default"
    wrap_object = False
    filter_module_0 = FilterModule()
    result = filter_module_0.filters()['vault'](data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-25 09:16:49.738167
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;a=b;c=d;t=y;m=aes256;1.4;12345678901234567890123456789012\n', 'totallySecret', '1.4') == 'Hello world!'

# Unit tests for function do_vault

# Generated at 2022-06-25 09:17:01.153421
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:04.766148
# Unit test for function do_vault
def test_do_vault():
    assert True == do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:17:15.073879
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'XIeqD4PPHR'
    str_1 = undef
    str_2 = 'XIeqD4PPHR'
    str_3 = 'XIeqD4PPHR'
    str_4 = 'XIeqD4PPHR'
    str_5 = 'XIeqD4PPHR'
    str_6 = undef
    str_7 = 'XIeqD4PPHR'
    str_8 = 'XIeqD4PPHR'
    str_9 = 'XIeqD4PPHR'
    str_10 = 'XIeqD4PPHR'
    str_11 = 'XIeqD4PPHR'
    var_0 = do_vault(str_0, str_1, str_2)

# Generated at 2022-06-25 09:17:17.936913
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'XIeqD4PPHR'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:17:27.047294
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:36.643765
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'tftFmf0nHr'
    var_0 = do_unvault(str_0, str_0)
    str_0 = 'CvejD8KKZB'
    var_0 = do_unvault(str_0, str_0)
    str_0 = 'oKj2fHe1'
    var_0 = do_unvault(str_0, str_0)
    str_0 = '7g0aJ6dHsy'
    var_0 = do_unvault(str_0, str_0)
    str_0 = 'zfEVQ9YOSW'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:17:45.399194
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'M7p8J5tmzR'
    str_1 = 'AxpFmI70eR'
    str_2 = 'BxIFU3H6zR'
    str_3 = 'sLL4LE4fKR'
    str_4 = 'xM8MzS6NTR'
    str_5 = 'JFQ4K4XHzR'
    str_6 = 'oTKzS7aOzR'
    str_7 = 'OU6M7R6oQR'
    str_8 = '6q3U6z2QdR'
    str_9 = 'm9nDeFbgzR'
    str_10 = 'nVmHvZcNzR'

# Generated at 2022-06-25 09:17:52.167677
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('@ANSIBLE_VAULT;1.1;AES256;user\r\nb64\r\n'
    'VaA3yOkZX0A2SPXW0rK7xCYTZGgTZKjfZht0b2M1TNyOvu7y9XjKHsxA==\r\n', 'secret') == 'XIeqD4PPHR'

# Generated at 2022-06-25 09:18:02.215339
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'C'
    var_0 = do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:18:06.784586
# Unit test for function do_vault
def test_do_vault():
    assert True

# Generated at 2022-06-25 09:18:18.688784
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:24.651438
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'XIeqD4PPHR'
    str_1 = 'XIeqD4PPHR'
    str_2 = 'XIeqD4PPHR'
    var_0 = do_vault(str_0, str_1, str_2)
    var_1 = do_unvault(var_0, str_0, str_1)



# Generated at 2022-06-25 09:18:29.338881
# Unit test for function do_vault
def test_do_vault():
    arg0 = ''
    arg1 = ''
    arg2 = ''
    arg3 = 'filter_default'
    arg4 = False

    # Call the function
    ret = do_vault(arg0, arg1, arg2, arg3, arg4)

    assert ret is None


# Generated at 2022-06-25 09:18:40.028598
# Unit test for function do_vault
def test_do_vault():
    test_0 = 'XIeqD4PPHR'
    try:
        result = do_vault(test_0, test_0, str_0)
    except AnsibleFilterError as afe:
        assert afe.orig_exc.strerror == 'Unexpected character encoding error: ASCII-8BIT'

# Generated at 2022-06-25 09:18:41.607426
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:18:47.234942
# Unit test for function do_vault
def test_do_vault():
    do_vault('nodelay', 'guess', '567', 'filter_default', True)

    # set up
    str_0 = 'nodelay'
    str_1 = 'guess'

    result_0 = do_vault(str_0, str_1)
    result_1 = do_vault(str_0, str_1)

    # unit test
    assert result_0 == result_1


# Generated at 2022-06-25 09:18:51.416488
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'XIeqD4PPHR'
    var_0 = do_vault(str_0, str_0, str_0)
    str_1 = 'XIeqD4PPHR'
    var_1 = do_vault(str_1, str_1, str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 09:18:54.837421
# Unit test for function do_vault
def test_do_vault():
    try:
        assert to_native(do_vault(None, None, None))
        assert to_native(do_vault('', '', ''))
        assert to_native(do_vault('', '', ''))
        assert to_native(do_vault('', '', ''))
    except Exception as e:
        display.error(e)


# Generated at 2022-06-25 09:18:59.515716
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'XIeqD4PPHR'
    str_1 = 'XIeqD4PPHR'
    str_2 = 'XIeqD4PPHR'
    var_0 = do_vault(str_0, str_1, str_2)


# Generated at 2022-06-25 09:19:06.540767
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abc'
    var_0 = do_vault(str_0, str_0)
    # str_1 = 'def'
    # var_0 = do_vault(str_1, str_1)
    # int_0 = 1
    # var_0 = do_vault(int_0, str_1)
    # int_1 = 2
    # var_0 = do_vault(str_1, int_1)
    # int_2 = 3
    # var_0 = do_vault(int_2, int_1)
    # list_0 = [1, 2, 3]
    # var_0 = do_vault(list_0, str_1)
    # tuple_0 = (1, 2, 3)
    # var_0 = do_v

# Generated at 2022-06-25 09:19:08.287087
# Unit test for function do_vault
def test_do_vault():
    for var_0 in [str_0, var_0]:
        assert do_vault(var_0, str_0, str_0) == var_0



# Generated at 2022-06-25 09:19:20.228065
# Unit test for function do_vault