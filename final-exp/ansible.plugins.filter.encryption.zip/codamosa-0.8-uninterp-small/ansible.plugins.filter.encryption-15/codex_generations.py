

# Generated at 2022-06-25 09:09:36.104939
# Unit test for function do_vault

# Generated at 2022-06-25 09:09:48.039468
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:09:56.265679
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault="!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          643633326461626231366562393566643164663330643435333133313231373961396163326530\n          642n", secret="secret") == "secret"


# Generated at 2022-06-25 09:10:08.382082
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('test_string', '')

# Generated at 2022-06-25 09:10:10.528595
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;jamesmcclain33', 'secret', 'filter_default') == ('jamesmcclain33')

# Generated at 2022-06-25 09:10:13.099351
# Unit test for function do_vault
def test_do_vault():
    # Testing not string type as input 
    try:
        assert['test_vault'] == do_vault(1, 'test_secret')
    except Exception:
        print("fails to accept non-string inputs")


# Generated at 2022-06-25 09:10:23.280070
# Unit test for function do_unvault
def test_do_unvault():
    secret = "root"

# Generated at 2022-06-25 09:10:26.714610
# Unit test for function do_unvault
def test_do_unvault():
    data = do_unvault("$ANSIBLE_VAULT;1.1;AES256;test\n63373933373730306338613436636239663833306665323561626266623264383261353931386331613d0a\n", 'ansible')
    assert data == "test"



# Generated at 2022-06-25 09:10:36.504514
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:42.636359
# Unit test for function do_vault
def test_do_vault():

    # Check encrypted_string is of AnsibleVaultEncryptedUnicode type if wrap_object is True
    encrypted_string = do_vault(data="Super@123", secret="testpass", wrap_object=True)
    assert isinstance(encrypted_string, AnsibleVaultEncryptedUnicode)
    assert encrypted_string.vault is None

    # Check encrypted_string is of type str if wrap_object is False
    encrypted_string = do_vault(data="Super@123", secret="testpass", wrap_object=False)
    assert isinstance(encrypted_string, str)

    # Check AnsibleFilterTypeError is raised if secret is not a string
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault(data="Super@123", secret=123)

    # Check Ans

# Generated at 2022-06-25 09:10:56.676474
# Unit test for function do_vault
def test_do_vault():
    filter_module_do_vault = FilterModule()

    # Test 1: Input string and secret key

# Generated at 2022-06-25 09:11:06.195506
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("this is the data", "this is the secret") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3064373636643938666264633238633236626637306664306562366533333039323931656535383\n          63632665646361363465323265346666313638353736626332303965376637632d0a3735343633\n          366636303235663937366633623266623338616664316534653533653936373633326133343633\n          353836313830336630363639396264353833316439616539393565653d0a\n          ".encode('utf-8')



# Generated at 2022-06-25 09:11:13.044960
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-25 09:11:19.289584
# Unit test for function do_vault
def test_do_vault():
    # Test case when do_vault raises an Exception
    secret = "secret"
    salt = None
    vaultid = "filter_default"
    wrap_object = False
    data = None

    try:
        do_vault(data,secret,salt,vaultid,wrap_object)
    
    except AnsibleFilterTypeError as e:
        pass


# Generated at 2022-06-25 09:11:25.606840
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()
    result = filter_module_1.filters()['vault']('test', '1', False)
    # Assert
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n6466306564336261633932396265336131303235666335343162636661636531353961356466366364\n613730353364646237613239386564666262623363616332373237663835366665383365336337323665\n6661316338\n'


# Generated at 2022-06-25 09:11:31.876286
# Unit test for function do_unvault
def test_do_unvault():
    # Test case 0
    secret = 'test_secret'
    vault = '$ANSIBLE_VAULT;1.2;AES256;test_test_test\n...\n...\n...'
    test_do_unvault_0 = do_unvault(
                                vault,
                                secret,
                                )
    # Test case 1
    secret_1 = 'test_secret_1'
    vault_1 = '$ANSIBLE_VAULT;1.2;AES256;test_test_test_1\n...\n...\n...'
    test_do_unvault_1 = do_unvault(
                                vault_1,
                                secret_1,
                                )
    # Test case 2
    secret_2 = 'test_secret_2'
    vault_2

# Generated at 2022-06-25 09:11:40.207253
# Unit test for function do_vault
def test_do_vault():
    secret = filter_module_0.filters()['vault']('some_string', 'foo')

# Generated at 2022-06-25 09:11:52.084966
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = "ansible"

# Generated at 2022-06-25 09:12:02.587822
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:14.280975
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:26.149569
# Unit test for function do_vault
def test_do_vault():
    assert to_native(do_vault("test_string", "test_string")) == '$ANSIBLE_VAULT;1.1;AES256\n63656435636237316264363861333265643834386435313534613534663564363838616539663530\n36333836653163313130316365323664333532306334336636373536313739656364356232626265\ntest_string\n'
    assert do_vault("test_string", "test_string", wrap_object=True).vault == VaultLib()

# Generated at 2022-06-25 09:12:27.458822
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('data', 'secret', 'salt', 'vaultid', False), six.string_types)


# Generated at 2022-06-25 09:12:30.399996
# Unit test for function do_vault
def test_do_vault():
    try:
        str_0 = 'test_string'
        var_0 = do_vault(str_0, str_0)
    except Exception as e:
        display.error(to_native(e))
        assert False


# Generated at 2022-06-25 09:12:31.815008
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('test_string', 'test_string') == 'test_string'


# Generated at 2022-06-25 09:12:35.218845
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

# Generated at 2022-06-25 09:12:40.358473
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0


# Generated at 2022-06-25 09:12:42.376611
# Unit test for function do_vault
def test_do_vault():
    try:
        test_case_0()
    except Exception:
        display.error('Caught exception')
        raise


# Generated at 2022-06-25 09:12:47.182437
# Unit test for function do_vault
def test_do_vault():
    #AssertionError: assertions: 1, failures: 1

    assert var_0 != str_0


# Generated at 2022-06-25 09:12:50.150317
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert str_0 == var_1


# Generated at 2022-06-25 09:12:55.587593
# Unit test for function do_vault
def test_do_vault():
    data = 'test_string'
    type(data) == str
    secret = 'test_string'
    type(secret) == str
    vaultid = 'filter_default'
    type(vaultid) == str
    wrap_object = False
    type(wrap_object) == bool
    assert do_vault(data, secret, vaultid, wrap_object) is not None


# Generated at 2022-06-25 09:13:03.419612
# Unit test for function do_unvault
def test_do_unvault():
    def test_case_0():
        str_0 = 'test_string'
        var_0 = do_vault(str_0, str_0)
        var_1 = do_unvault(var_0, str_0)
        assert var_1 == str_0
        assert var_0 is not str_0
    def test_case_1():
        str_0 = 'test_string'
        var_0 = do_vault(str_0, str_0)
        var_1 = do_unvault(var_0, str_0)
        assert var_1 == str_0
        assert var_0 is not str_0
    def test_case_2():
        str_0 = 'test_string'
        var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:13:05.458177
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

if __name__ == '__main__':
    test_case_0()
    print('Test finished')
    test_do_unvault()

# Generated at 2022-06-25 09:13:06.914619
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    print(var_1)
    test_case_0()


# Generated at 2022-06-25 09:13:09.326724
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_unvault(do_vault(str_0, str_0), str_0)
    assert var_0 == 'test_string'

# Generated at 2022-06-25 09:13:12.848206
# Unit test for function do_vault
def test_do_vault():
    secret = 'test_string'
    data = 'test_string'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    ret = do_vault(data, secret, salt, vaultid, wrap_object)
    assert type(ret) == str


# Generated at 2022-06-25 09:13:16.452634
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert var_0 is not None


# Generated at 2022-06-25 09:13:22.013042
# Unit test for function do_vault
def test_do_vault():
    # Run a single test
    test_case_0()


if __name__ == '__main__':
    # Do unit testing of individual functions
    test_do_vault()

# Generated at 2022-06-25 09:13:27.564143
# Unit test for function do_unvault
def test_do_unvault():
    generated_string = "test_string"

    expected_string = "test_string"

    #print 'generated_string:', generated_string
    #print 'expected_string:', expected_string
    assert generated_string == expected_string

# Generated at 2022-06-25 09:13:33.186684
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256'


# Generated at 2022-06-25 09:13:40.943959
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:13:47.419412
# Unit test for function do_vault
def test_do_vault():
    print("Testing do_vault")
    assert_equals("Run test_case_0", "test_string")
    assert_equals("Run test_case_1", "test_string")
    assert_equals("Run test_case_2", "test_string")
    assert_equals("Run test_case_3", "test_string")

# Generated at 2022-06-25 09:13:58.132084
# Unit test for function do_vault
def test_do_vault():
    # Output should be AnsibleVaultEncryptedUnicode
    assert isinstance(do_vault('test', 'test'), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 09:14:05.956614
# Unit test for function do_vault
def test_do_vault():
    start = 'test_string'
    var_1 = do_vault(start, start)

# Generated at 2022-06-25 09:14:08.084890
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert type(var_0) is str


# Generated at 2022-06-25 09:14:16.601389
# Unit test for function do_unvault
def test_do_unvault():
    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n36643365306465373864393831386535306664666636333036356235623963306230636565333035\n3232363361613831366238313732663736363335623239306364616335666162323031373866396564\n346466653539323066386330336130343737373262636136613335633636631313739\n')
    var_0 = do_unvault(vault, 'test_string')

# Generated at 2022-06-25 09:14:25.641352
# Unit test for function do_vault
def test_do_vault():

    # Test with vault secret
    test_secret = 'test_secret'
    test_data = b'test_data'
    test_result = do_vault(test_data, test_secret)
    assert test_result != test_data
    assert do_unvault(test_result, test_secret) == test_data

    # Test with invalid type
    test_invalid_type = ['test_invalid_type', ]
    try:
        do_vault(test_data, test_invalid_type)
    except AnsibleFilterTypeError as e:
        assert test_invalid_type in str(e)

    # Test with invalid type
    try:
        do_vault(test_invalid_type, test_secret)
    except AnsibleFilterTypeError as e:
        assert test_invalid_

# Generated at 2022-06-25 09:14:35.053543
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:40.715929
# Unit test for function do_vault
def test_do_vault():
    try:
        assert(test_case_0())
    except AssertionError as err:
        display.fail(str(err))
    except Exception as err:
        raise type(err)(str(err) +
                        '\nThe above exception was the direct cause of the following exception:\n\n')


# Generated at 2022-06-25 09:14:51.807212
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'

    try:
        var_0 = do_vault(str_0, str_0)
    except AnsibleFilterTypeError as e:
        print(e)
        sys.exit(1)

    try:
        var_1 = do_vault(str_0, str_0, str_0)
    except AnsibleFilterTypeError as e:
        print(e)
        sys.exit(1)

    try:
        var_2 = do_vault(str_0, str_0, str_0, str_0)
    except AnsibleFilterTypeError as e:
        print(e)
        sys.exit(1)


# Generated at 2022-06-25 09:14:58.201486
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0


# Generated at 2022-06-25 09:15:06.581479
# Unit test for function do_vault
def test_do_vault():
    try:
        assert to_native(test_case_0()) == 'test_string'
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-25 09:15:17.878597
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:15:25.003136
# Unit test for function do_vault
def test_do_vault():
    with pytest.raises(AnsibleFilterTypeError):
        str_0 = 'test_string'
        str_1 = 'test_string'
        str_2 = 'test_string'
        var_0 = do_vault(str_0, str_1, str_2)


# Generated at 2022-06-25 09:15:27.561684
# Unit test for function do_vault
def test_do_vault():
    try:
        test_case_0()
    except:
        import traceback
        print(traceback.format_exc())

nose.main(argv=['nosetests', '-v', __file__], exit=False)


# Generated at 2022-06-25 09:15:29.586990
# Unit test for function do_vault
def test_do_vault():
    assert callable(do_vault)
    try:
        do_vault('test_string', 'test_string')
    except Exception as e:
        print(e, file=sys.stderr)



# Generated at 2022-06-25 09:15:34.497940
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)

# Generated at 2022-06-25 09:15:40.708611
# Unit test for function do_vault
def test_do_vault():

    assert isinstance(do_vault('test_string', 'test_string'), str)

    try:
        do_vault(dict(), 'test_string')
    except AnsibleFilterTypeError as e:
        assert "we got" in e.message



# Generated at 2022-06-25 09:15:47.754463
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('test_string', 'test_string', 'test_salt')
    assert type(vault) is str, 'Return value should be a string'
    assert len(vault) > 0, 'Return value should not be empty'


# Generated at 2022-06-25 09:15:55.864385
# Unit test for function do_vault
def test_do_vault():

    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:15:59.053806
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == do_unvault(var_0, str_0) == 'test_string'


# Generated at 2022-06-25 09:16:08.203697
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0


# Generated at 2022-06-25 09:16:19.889231
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;example3\ndeclare -x ANSIBLE_VAULT_PASSWORD_FILE="/etc/.vault_pass_test"\n8c0e2b2a7bbe2590f0a8befa408591ca94771bfb8a9517cec35d53e61e761c15\n', 'test')
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n3bdf48e3cbb9c00c9e9e54bb5a2a8cb5a5d11f068bd54b3c3ed9d57c9c9d7747\n', 'test')

# Generated at 2022-06-25 09:16:23.394755
# Unit test for function do_vault
def test_do_vault():
    # No assertions needed here
    print("function do_vault() is not testable")


# Generated at 2022-06-25 09:16:33.239082
# Unit test for function do_vault
def test_do_vault():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()
    test_case_25()

# Generated at 2022-06-25 09:16:40.270266
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_0 = AnsibleVaultEncryptedUnicode(var_0)
    str_1 = do_unvault(var_0, str_0)


# Include the test code below when testing locally
if __name__ == '__main__':
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:16:46.524734
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:16:56.425350
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:58.195701
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('test_String', 'test_String')
    return result


# Generated at 2022-06-25 09:17:06.942252
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:17:08.302679
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault("test_string", "test_string")) == str


# Generated at 2022-06-25 09:17:23.085937
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert isinstance(var_0, to_native(binary_type).__class__)
    assert len(var_0) == 60 # 60 is the length of the output of do_vault method
    str_1 = 'a53b4c89d2f8e428d3e9c787ee1f2fae0b878c073f21fb0e1e0d31ff846e9f9e'
    var_1 = do_vault(str_1, str_1)
    assert isinstance(var_1, to_native(binary_type).__class__)
    assert len(var_1) == 60 # 60 is the length of the output of do_vault method

# Generated at 2022-06-25 09:17:31.392274
# Unit test for function do_vault
def test_do_vault():
    text_0 = 'Ansible'
    # { u'test_str_0': u'2Q==', u'test_str_1': u'Ansible' }
    text_1 = do_vault(text_0, text_0)
    print(text_1)
    print(len(text_1))
    result = do_vault(text_0, text_0)
    print(result)
    print(len(result))
    result = do_vault(text_0, text_0)
    print(result)
    print(len(result))
    # { u'test_str_0': u'Ansible', u'test_str_1': u'Ansible' }
    text_2 = do_unvault(text_1, text_0)

# Generated at 2022-06-25 09:17:33.991174
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = is_encrypted(var_0)

    assert var_1
    assert var_0


# Generated at 2022-06-25 09:17:39.274865
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == "$ANSIBLE_VAULT;1.1;AES256\r\n3339646365633534333633623535393462366661643738373531636432343830663437383163\r\n3837623662616261643539373438666332353530643539653038333838633233343433313334\r\n3736303539398a\r\n"


# Generated at 2022-06-25 09:17:40.609819
# Unit test for function do_vault
def test_do_vault():
    assert test_case_0() == True


# Generated at 2022-06-25 09:17:43.561277
# Unit test for function do_vault
def test_do_vault():
    try:
        test_case_0()
    except Exception as ae:
        print (ae.args)
        print (ae)


# Generated at 2022-06-25 09:17:45.533585
# Unit test for function do_vault
def test_do_vault():
    try:
        test_case_0()
    except TypeError as err:
        assert 'bad operand type for unary -' in str(err)


# Generated at 2022-06-25 09:17:48.708380
# Unit test for function do_vault
def test_do_vault():
    # Input param data
    # Input param secret
    # Input param salt
    # Input param vaultid
    # Input param wrap_object
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)

    if var_0 is not None:
        display.display("Vaulted content: %s" % var_0)



# Generated at 2022-06-25 09:17:49.950980
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_1 = do_unvault(var_0, var_0)


# Generated at 2022-06-25 09:17:52.607870
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

# Generated at 2022-06-25 09:18:06.834162
# Unit test for function do_vault
def test_do_vault():
    # Test Error Cases
    # Test Standard Cases
    var_0 = do_vault('test_string', 'test_string')
    # Test Custom Cases

# Generated at 2022-06-25 09:18:18.675266
# Unit test for function do_vault
def test_do_vault():
    vault_obj = False
    secret = 'test_string'
    data = 'test_string'

# Generated at 2022-06-25 09:18:21.156878
# Unit test for function do_vault
def test_do_vault():
    cl = VaultLib()
    returnval = cl.encrypt('test_string', VaultSecret('test_string'), 'default', 'foo')
    assert isinstance(returnval, str)



# Generated at 2022-06-25 09:18:24.503113
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_unvault(do_vault(str_0, str_0), str_0)
    print(var_0)
    var_1 = do_unvault(do_vault(str_0, str_0), str_1) # Should throw an error
    print(var_1)


# Generated at 2022-06-25 09:18:28.713525
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)



# Generated at 2022-06-25 09:18:29.494079
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
#

# Generated at 2022-06-25 09:18:40.136594
# Unit test for function do_unvault

# Generated at 2022-06-25 09:18:49.956064
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'

    vault_0 = do_vault(str_0, str_0)

    assert isinstance(vault_0, string_types)
    assert vault_0 is not None
    assert type(False) != type(True)
    assert type(1) != type(1.0)

# Generated at 2022-06-25 09:18:56.767870
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'test_string'
    var_1 = do_vault(str_1, str_1)


# Generated at 2022-06-25 09:19:00.673047
# Unit test for function do_vault
def test_do_vault():
    assert True


# Generated at 2022-06-25 09:19:20.199119
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_string'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == 'test_string'
    var_2 = do_unvault(var_0, 'other_string')
    assert isinstance(var_2, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 09:19:24.620658
# Unit test for function do_vault
def test_do_vault():
    assert not(test_case_0 == None)