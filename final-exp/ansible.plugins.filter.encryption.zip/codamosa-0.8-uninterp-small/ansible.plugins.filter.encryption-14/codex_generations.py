

# Generated at 2022-06-25 09:09:32.260459
# Unit test for function do_vault
def test_do_vault():
    data = "mysecret"
    secret = "@vault_password"
    salt = None
    vaultid = "dsfsdfsdf"
    wrap_object = False

    # Test return value and type is correct
    assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object), string_types)

    # Test that no exception raised for correct data
    try:
        assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object), string_types)
    except Exception:
        assert False, "The do_vault function raised an unexpected exception"

    data = "@vault_password"
    secret = "password"
    salt = None
    vaultid = "dsfsdfsdf"
    wrap_object = False

    # Test return value and type is correct

# Generated at 2022-06-25 09:09:42.304974
# Unit test for function do_vault
def test_do_vault():
    display.output = ('')
    output_0 = do_vault('data', 'secret', 'salt', 'vaultid', False)
    output_1 = do_vault('data', 'secret', 'salt', 'vaultid', True)
    try:
        output_2 = do_vault('data', 123, 'salt', 'vaultid', False)
    except AnsibleFilterTypeError as e:
        output_2 = repr(e)
    try:
        output_3 = do_vault(123, 'secret', 'salt', 'vaultid', False)
    except AnsibleFilterTypeError as e:
        output_3 = repr(e)
    display.output = ('')
    return (output_0, output_1, output_2, output_3)

# Unit test

# Generated at 2022-06-25 09:09:51.304777
# Unit test for function do_vault
def test_do_vault():
    # Testing valid data inputs
    assert do_vault('name', secret='mysecret') == '$ANSIBLE_VAULT;1.1;AES256\n3636663337643965306435633064333630333539376133306336306435363832356134323266633\n62666434306635646332326262326633336135626539353436303137653935626366623737343533\n3430363938'

# Generated at 2022-06-25 09:10:01.728095
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:09.816230
# Unit test for function do_vault
def test_do_vault():
    # Test: Pass in valid params
    filter_module_0 = FilterModule()
    test_data = 'password'
    test_secret = 'secret'
    result = filter_module_0.filters()['vault'](test_data, test_secret)
    assert result != None


# Generated at 2022-06-25 09:10:16.489476
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    test_vault = filter_module_0.filters().get('vault')
    assert isinstance(test_vault, object)
    assert isinstance(test_vault('Adios'), object)
    assert isinstance(test_vault('Adios', 'password'), object)
    assert isinstance(test_vault('Adios', 'password', wrap_object=True), object)
    assert isinstance(test_vault('Adios', 'password', salt="1234567890123456"), object)
    assert isinstance(test_vault('Adios', 'password', salt="1234567890123456", wrap_object=True), object)

# Generated at 2022-06-25 09:10:25.014900
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:35.040437
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:39.967578
# Unit test for function do_unvault
def test_do_unvault():
    print("Testing do_unvault(vault, secret, vaultid='filter_default')....")
    secret = "password"
    data = "data"
    vault = do_vault(data, secret)
    assert do_unvault(vault, secret) == data


# Generated at 2022-06-25 09:10:45.997515
# Unit test for function do_unvault
def test_do_unvault():
  assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n35363337303734303534386234636663326635653262653239613166633935323933333237616634\n36633131653065316663363063343364363839623962656664386361656134653564396263303130\n6431333464396236626439\n","ansible","filter_default") == "foo"


# Generated at 2022-06-25 09:10:57.322878
# Unit test for function do_vault
def test_do_vault():
    secret_0 = 'foobar'
    data_0 = 'test string'

# Generated at 2022-06-25 09:11:06.239693
# Unit test for function do_vault
def test_do_vault():
    # Do not display output during unit tests
    display.verbosity = 0


# Generated at 2022-06-25 09:11:13.798785
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault  = '$ANSIBLE_VAULT;1.1;AES256;ansible'
    #vault += '\n373433623037363732653538333234363937366666336646393366663732653231336634623034'
    #vault += '\n623763313064383538636466336437663131643762323064323662373235343064326339623133'
    #vault += '\n6533373461373136313164396630303165653335363935356232643063333636663533062366365'

# Generated at 2022-06-25 09:11:24.479342
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n3466613632386164623538303966353735633239306538353465333437343736333562386363343\n303531323265393733306566376661316365303537\n","foo") == "bar"
    try:
        do_unvault("$ANSIBLE_VAULT;1.1;AES256\n3466613632386164623538303966353735633239306538353465333437343736333562386363343\n303531323265393733306566376661316365303537\n","foo123")
    except AnsibleFilterError:
        pass

# Generated at 2022-06-25 09:11:31.192196
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:39.979320
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:51.812213
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:02.335161
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test_string'

# Generated at 2022-06-25 09:12:09.437328
# Unit test for function do_vault
def test_do_vault():
    do_vault_0 = do_vault(
        data=12345678901234567890,
        secret='vault_secret',
        salt='vault_salt',
        vaultid='vault_id',
        wrap_object=True,
    )

# Generated at 2022-06-25 09:12:16.325911
# Unit test for function do_vault
def test_do_vault():
    input_data = b'foo'
    input_secret = b'secret'
    input_salt = b'foo'

# Generated at 2022-06-25 09:12:27.869766
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:32.248176
# Unit test for function do_vault
def test_do_vault():
    try:
        test_input_0 = "value"

        expected_result_0 = AnsibleVaultEncryptedUnicode
        result_0 = isinstance(do_vault(test_input_0, 'nme', 'lz2'), expected_result_0)

        assert result_0 == True
    except Exception as e:
        display.error(to_native(e))
        raise e


# Generated at 2022-06-25 09:12:36.383765
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    value = 'my_secret'
    secret = 'password'
    result = do_vault(value, secret, wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault is not None


# Generated at 2022-06-25 09:12:47.166508
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:53.101393
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:56.230246
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('s3cr3t', 's3cr3ts@lt')
    assert vault == '$ANSIBLE_VAULT;1.1;AES256\n30646533316563636332316434353062333966666136303839633961316633616432356231326336\n37306337323463373633373734353230343365343966303337663831326662653\n'


# Generated at 2022-06-25 09:13:09.766051
# Unit test for function do_unvault
def test_do_unvault():
    import ansible.errors.AnsibleError
    import ansible.errors.AnsibleFilterTypeError
    import ansible.parsing.vault
    import ansible.parsing.yaml.objects
    import ansible.utils.display
    import ansible.utils.unsafe_proxy
    import collections
    import json
    from ansible.errors.AnsibleError import AnsibleError
    from ansible.errors.AnsibleFilterTypeError import AnsibleFilterTypeError
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.display import Display

# Generated at 2022-06-25 09:13:13.997022
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\n346561316633616339623031646335336162613237383538663033323466396235336630383438\n333430356137363935656562626230333865663435356162326636616663326262\n", "test") == "test"

# Generated at 2022-06-25 09:13:21.038877
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    vault_result = filter_module.filters()['vault']('password', 'secret')

# Generated at 2022-06-25 09:13:27.869686
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:35.855392
# Unit test for function do_vault
def test_do_vault():
    str_0 = binascii.b2a_hex(os.urandom(64))
    var_0 = do_vault(str_0, str_0)
    try:
        assert var_0.startswith('$ANSIBLE_VAULT;')
        assert var_0.endswith('==\n\n')
    except:
        raise AssertionError("Check if do_vault works correctly")


# Generated at 2022-06-25 09:13:42.926261
# Unit test for function do_vault
def test_do_vault():
    f = do_vault
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0, salt=None)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0, salt=None, vaultid='filter_default')
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

# Generated at 2022-06-25 09:13:50.175817
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert do_unvault(var_0, str_0) == str_0


# Generated at 2022-06-25 09:14:00.927052
# Unit test for function do_unvault

# Generated at 2022-06-25 09:14:12.654969
# Unit test for function do_vault
def test_do_vault():

    # test case 0: is basic string encryption
    vaulted_test_value = do_vault("123", "password", salt='test_salt')
    decrypted_test_value = do_unvault(vaulted_test_value, "password", vaultid='test_vaultid')

    assert decrypted_test_value == "123"

    # test case 1: is string encryption with alternate vaultid
    vaulted_test_value = do_vault("123", "password", salt='test_salt', vaultid='test_vaultid')
    decrypted_test_value = do_unvault(vaulted_test_value, "password", vaultid='test_vaultid')

    assert decrypted_test_value == "123"

    # test case 2: is object returned by do_vault
    vault

# Generated at 2022-06-25 09:14:14.218128
# Unit test for function do_unvault
def test_do_unvault():
    assert test_case_0()
    assert True


# Generated at 2022-06-25 09:14:18.817943
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_0) == str_0

# Generated at 2022-06-25 09:14:21.681060
# Unit test for function do_unvault
def test_do_unvault():
    data = 'mysecret'
    secret = 'mysecret'
    vaultid = 'filter_default'
    ret = do_unvault(data, secret, vaultid)
    assert ret == 'mysecret'


# Generated at 2022-06-25 09:14:25.915071
# Unit test for function do_vault
def test_do_vault():

    # Given:
    str_0 = 'mysecret'

    # When
    var_0 = do_vault(str_0, str_0)

    # Then
    print(var_0)

# Generated at 2022-06-25 09:14:33.767749
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:43.479453
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, secret)
    var_1 = do_unvault(var_0, secret, vaultid)


if __name__ == '__main__':
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:14:52.494703
# Unit test for function do_vault
def test_do_vault():
    # 1. Assert that the output is an encrypted string
    assert isinstance(do_vault('mysecret', 'mysecret'), str)

    # 2. Assert that invalid inputs raise AnsibleFilterTypeError
    assert "Secret passed is required to be a string, instead we got: <class 'int'>" in str(AnsibleFilterTypeError(do_vault(1000, 2000)))

    # 3. Assert that an unknown error raises AnsibleFilterError
    class TestException(Exception):
        pass
    assert "Unable to encrypt: TestException" in str(AnsibleFilterError(do_vault(1000, 1000, salt="Error", orig_exc=TestException())))



# Generated at 2022-06-25 09:14:59.233567
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:15:11.591906
# Unit test for function do_unvault

# Generated at 2022-06-25 09:15:14.401143
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    var_0 = do_unvault(str_0, str_0)
    assert var_0 == 'mysecret', 'mysecret'


# Generated at 2022-06-25 09:15:21.762636
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    print(var_0)
    str_1 = var_0
    var_1 = do_unvault(str_1, str_0)
    print(var_1)
    assert var_1 == str_0, "Error in function do_unvault"

if __name__ == "__main__":
    #test_case_0()
    test_do_vault()
    print("All tests passed")

# Generated at 2022-06-25 09:15:25.870827
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    str_1 = 'mysecret'
    try:
        var_0 = do_vault(str_0, str_1)
    except Exception as e:
        print(to_native(e))
        assert False


# Generated at 2022-06-25 09:15:32.629987
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'mysecret'
    var_0 = do_vault(str_1, str_1)
    str_2 = 'encryption string'
    var_0 = do_vault(str_2, str_1)
    str_3 = '2nd encryption string'
    var_0 = do_vault(str_3, str_1)
    str_4 = '3rd encryption string'
    var_0 = do_vault(str_4, str_1)
    str_5 = '4th encryption string'
    var_0 = do_vault(str_5, str_1)
    str_6 = '5th encryption string'
    var_0 = do_vault(str_6, str_1)
    str_7 = '6th encryption string'
    var_0

# Generated at 2022-06-25 09:15:34.220177
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    if str_0 == 'mysecret':
        return 'success!'
    else:
        raise AssertionError


# Generated at 2022-06-25 09:15:46.065311
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'ansible'
    var_0 = do_vault(str_0, 'mysecret')

# Generated at 2022-06-25 09:15:53.853510
# Unit test for function do_vault
def test_do_vault():
    assert to_native(do_vault('mysecret', 'mysecret')) == '$ANSIBLE_VAULT;1.2;AES256;mysecret\ntuvw\n'
    assert do_vault('mysecret', 'mysecret', wrap_object=True) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;mysecret\ntuvw\n')


# Generated at 2022-06-25 09:16:00.483501
# Unit test for function do_unvault

# Generated at 2022-06-25 09:16:08.238117
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'blah'
    str_1 = 'blah'
    str_2 = 'blah'
    str_3 = 'blah'
    str_4 = 'blah'
    str_5 = 'blah'
    assert do_vault(str_0, str_1) == str_2
    assert do_vault(str_3, str_4) == str_5


# Generated at 2022-06-25 09:16:12.833236
# Unit test for function do_vault
def test_do_vault():
    print("TEST: do_vault")
    check_type = type(do_vault("arg_0", "arg_1"))
    assert check_type == str, "Return type does not match"
    test_case_0()



# Generated at 2022-06-25 09:16:25.096904
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:16:33.804253
# Unit test for function do_vault
def test_do_vault():

    # Instantiation and initialization of variables
    str_0 = 'mysecret'

    # Invocation of filter
    var_0 = do_vault(str_0, str_0)

    # Testing filter output
    assert var_0 == '$ANSIBLE_VAULT;7.24;AES256\n61353839386463354336353465316366633665356537636230333465653436350a35363534386161393937333438643433373866363635613233326536313036650a3363613433322d383933612d343331662d626163612d643062353864383636396331350a\n'



# Generated at 2022-06-25 09:16:43.775910
# Unit test for function do_unvault

# Generated at 2022-06-25 09:16:52.054389
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    test_value_0 = '$ANSIBLE_VAULT;1.1;AES256;mysecret\n6363386365656663396233336333323834326165316537373433323131643832623664623661353132360a3439643736386137363531313637323934363035333938663265623663363135376231343066396435303764333665643530300a'
    assert var_0 == test_value_0, "Incorrect value returned"

# unit test for function do_unvault

# Generated at 2022-06-25 09:17:02.665265
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:04.999287
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, 'ansible') is None
    assert do_unvault(None, 'ansible', 'password') is None


# Generated at 2022-06-25 09:17:19.130967
# Unit test for function do_vault
def test_do_vault():
    test_case_0()



# Generated at 2022-06-25 09:17:19.954664
# Unit test for function do_vault
def test_do_vault():

    assert(True)



# Generated at 2022-06-25 09:17:30.287267
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    str_1 = 'mysecret'
    str_2 = 'mysecret'
    str_3 = 'mysecret'
    str_4 = 'mysecret'
    str_5 = 'mysecret'
    str_6 = 'mysecret'
    str_7 = 'mysecret'
    str_8 = 'mysecret'
    str_9 = 'mysecret'
    str_10 = 'mysecret'
    str_11 = 'mysecret'
    str_12 = 'mysecret'
    str_13 = 'mysecret'
    str_14 = 'mysecret'
    str_15 = 'mysecret'
    str_16 = 'mysecret'
    str_17 = 'mysecret'
    str_18 = 'mysecret'
    str_19 = 'mysecret'

# Generated at 2022-06-25 09:17:41.258714
# Unit test for function do_vault
def test_do_vault():
    res_0 = do_vault('mysecret', 'mysecret')
    res_1 = do_vault('mysecret', 'mysecret', wrap_object=True)

# Generated at 2022-06-25 09:17:42.675409
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:17:43.789139
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('mysecret', 'mysecret')


# Generated at 2022-06-25 09:17:45.253589
# Unit test for function do_vault
def test_do_vault():
    print("Testing do_vault")
    test_case_0()



# Generated at 2022-06-25 09:17:50.837787
# Unit test for function do_vault
def test_do_vault():

    # Encrypting a simple string
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

    # Encrypting a multiline string
    str_1 = 'my\nsecret\nstring'
    str_2 = 'secret'
    var_1 = do_vault(str_1, str_2)

    # Encrypting a simple string and enforces a salt
    str_3 = 'mysecret'
    str_4 = 'mysalt'
    str_5 = 'secret'
    var_3 = do_vault(str_3, str_5, salt=str_4)

    # Encrypting a multiline string and enforces a salt
    str_6 = 'my\nsecret\nstring'
    str_7 = 'secret'

# Generated at 2022-06-25 09:18:02.117984
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:18:08.222542
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'
    vault = '$ANSIBLE_VAULT;1.1;AES256'
    data = do_unvault(vault, secret)
    assert data == ''


# Generated at 2022-06-25 09:18:24.505901
# Unit test for function do_vault
def test_do_vault():
   assert(do_vault('mysecret', 'mysecret') == '$ANSIBLE_VAULT;1.1;AES256\n35616237316663323166623237336635633066653630633535663233643633666164383438363835\n65366639343732643262666165333265393033386536666131613262363463373039333437666634\n6635303266623264323935363634373537323832653761613763336432363363330396366616632\n3037356561336364383632333939623334393730\n')


# Generated at 2022-06-25 09:18:28.713126
# Unit test for function do_vault
def test_do_vault():
    assert do_unvault(do_vault('mysecret', 'mysecret'), 'mysecret') == 'mysecret'


# Generated at 2022-06-25 09:18:39.520543
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;9.9.9;AES256\n34393530313366303833383465323530316265616663376166623761396331653639353334326133613961393264\n6566343639636631616663633862643462323534396261386132333661396336353832653138363066656161646639\n3264366138623262626535336435366464306536313164366566653563333662356165653162646437373035393032\n3261393538303839363630663732373563633537303364'
    str_1 = 'mysecret'

# Generated at 2022-06-25 09:18:49.369807
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:53.985299
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mypassword'
    secret = 'mysecret'

    try:
        var_0 = do_vault(str_0, secret)
        if var_0 is not False:
            var_1 = do_unvault(var_0, secret)
            assert var_1 == str_0
        else:
            raise AssertionError()
    except Exception as e:
        raise AssertionError(e)


# Generated at 2022-06-25 09:19:05.193710
# Unit test for function do_unvault
def test_do_unvault():
    # Test for successful vault decryption
    str_0 = 'mysecret'
    str_1 = do_vault(str_0, str_0)
    var_0 = do_unvault(str_1, str_0)
    assert var_0 == str_0
    # Test for failure with wrong secret
    str_2 = 'mysecret_wrong'
    str_3 = do_vault(str_0, str_0)
    try:
        var_1 = do_unvault(str_3, str_2)
        raise AssertionError("Expected filter error, but filter did not fail")
    except AnsibleFilterError:
        pass
    # Test for failure with non-vault

# Generated at 2022-06-25 09:19:08.610884
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_0 = do_unvault(var_0, str_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:19:16.464943
# Unit test for function do_unvault
def test_do_unvault():
    # Make sure the AnsibleVaultEncryptedUnicode object can be decrypted with the correct secret.
    my_secret = 'the_secret'
    my_vault = AnsibleVaultEncryptedUnicode.encrypt(my_secret, my_secret)
    assert do_unvault(my_vault, my_secret) == my_secret

    # Make sure the AnsibleVaultEncryptedUnicode object cannot be decrypted with the incorrect secret.
    assert do_unvault(my_vault, "not_the_secret") != my_secret

    # Make sure the non-encryped string can be decrypted with the secret.
    non_vault = 'not_encrypted'
    assert do_unvault(non_vault, my_secret) == non_vault

    # Make sure passing a vault object

# Generated at 2022-06-25 09:19:18.599603
# Unit test for function do_vault
def test_do_vault():
    assert 'QmFzZTY0IHZhdWx0' == do_vault(to_bytes('Base64 vault'), to_bytes('mysecret'))



# Generated at 2022-06-25 09:19:21.278022
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'

    assert do_vault(str_0, str_0)
    assert do_vault(str_0, str_0, wrap_object=True)

test_do_vault()
test_case_0()