

# Generated at 2022-06-25 09:09:35.852655
# Unit test for function do_vault
def test_do_vault():
    def test_0():
        data_0 = 'abcdefghijklmnopqrstuvwxyz0123456789'
        secret_0 = 'password'
        vault_0 = do_vault(data_0, secret_0)
        assert vault_0 == '$ANSIBLE_VAULT;1.1;AES256\n38356639626434396165626235376161376534376535313131353839373261316434666435396135\n3337643162626532376234313961616637303664333731356136667d0a\n'

        salt_0 = 'salt'
        vault_0 = do_vault(data_0, secret_0, salt_0)

# Generated at 2022-06-25 09:09:43.338475
# Unit test for function do_vault
def test_do_vault():

    secret = 'test_secret'
    data = 'test_data'
    salt = 'test_salt'
    vaultid = 'test_filter_default'
    wrap_object = False


# Generated at 2022-06-25 09:09:52.075118
# Unit test for function do_vault
def test_do_vault():
    assert callable(do_vault)

    data, secret, salt, vaultid, wrap_object = 'test_data', 'test_secret', 'test_salt', 'test_vaultid', 'test_wrap_object'
    # test AnsibleFilterTypeError
    try:
        do_vault(data, secret, salt, vaultid, wrap_object)
    except AnsibleFilterTypeError:
        pass

    secret = 'test_secret'
    try:
        do_vault(data, secret, salt, vaultid, wrap_object)
    except AnsibleFilterTypeError:
        pass

    secret = 'test_secret'
    data = 'test_data'
    # test UndefinedError

# Generated at 2022-06-25 09:09:56.975108
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = do_vault(ansible_vault_0, ansible_vault_1, ansible_vault_2, ansible_vault_3, ansible_vault_4)
    assert var_0 == ansible_vault_5
    var_1 = ansible_vault_1


# Generated at 2022-06-25 09:10:05.659489
# Unit test for function do_vault
def test_do_vault():
    vaulted = do_vault('password', 'secret')
    assert vaulted
    assert not vaulted.endswith('\n')
    print("Vaulted secret: %s" % vaulted)

    unvaulted = do_unvault(vaulted, 'secret')
    assert unvaulted
    assert isinstance(unvaulted, string_types)
    print("Unvaulted secret: %s" % unvaulted)
    assert unvaulted == 'password'


# Generated at 2022-06-25 09:10:15.044280
# Unit test for function do_vault
def test_do_vault():

    # Test 1
    print("Testing : Test 1")
    secret = 'thesecret'
    data = 'thesecret'

    res = do_vault(data, secret)
    assert res == '$ANSIBLE_VAULT;1.1;AES256\n666639636138373066613838333835656135396665633961383032353961386441343335356465\n31316539346437363626306662323039386664376366663264346639653335643133343635653939\n30666362613235643336633964623434383338306961623334343965366134343538303634326565\n6438\n'

    # Test 2
    print("Testing : Test 2")

# Generated at 2022-06-25 09:10:24.155528
# Unit test for function do_vault
def test_do_vault():
    # Instantiate the class, and declare the variable
    filter_module = FilterModule()
    var = filter_filters()

    # Test AnsibleVaultEncryptedUnicode
    var_0 = do_vault('test', 'password')
    var_1 = do_vault('test', 'password', wrap_object=True)
    var_2 = var_1.data
    ''' CHECK_EQ('test', var_2) '''

    var_3 = do_vault('', 'password')
    ''' CHECK_EQ('', var_3) '''

    # Test
    var_4 = do_vault(None, 'password')
    var_5 = do_vault('test', 'password')
    var_6 = do_vault('test', 'password', wrap_object=True)

# Generated at 2022-06-25 09:10:34.974694
# Unit test for function do_vault
def test_do_vault():
    # Try to decrypt data with a wrong secret
    data = 'dGVzdA=='
    secret = 'foobar'
    salt = None
    vaultid = 'filter_default'

    with pytest.raises(AnsibleFilterError):
        do_vault(data, secret, salt, vaultid)

    encrypted_data = do_vault(data, secret)
    assert is_encrypted(encrypted_data)

    decrypted_data = do_unvault(encrypted_data, secret)
    assert decrypted_data == 'test'

    # Try to decrypt a string that is already decrypted
    with pytest.raises(AnsibleFilterError):
        do_unvault('test', secret)

    # Wrap secret in an object

# Generated at 2022-06-25 09:10:41.415283
# Unit test for function do_unvault
def test_do_unvault():
    var_1 = 'foo'
    var_2 = 'bar'
    var_3 = 'filter_default'
    var_4 = do_unvault(var_1, var_2, var_3)
    var_5 = 's3cr3t'
    var_6 = 'bar'
    var_7 = 'another_vault_object'
    var_8 = do_vault(var_1, var_5, var_6, var_7)
    var_9 = do_unvault(var_8, var_2, var_7)
    try:
        var_10 = do_unvault(var_8, var_2, var_3)
    except Exception as e:
        pass
    else:
        assert 0, 'Exception expected'

# Generated at 2022-06-25 09:10:44.099249
# Unit test for function do_vault
def test_do_vault():
    var_0 = do_vault(var_0, var_1)
    try:
        assert var_0 == var_1
    except AssertionError as e:
        print("Test case: test_do_vault")
        print("Expected: " + to_native(var_1))
        print("Got: " + to_native(var_0))
        assert False


# Generated at 2022-06-25 09:10:55.020635
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible_test\n353064356303764339613064383638343263336230363363666461373733353933623971671b\n316431396332363536306432663939636433643139383033323130393035303466300a", 'testpasswd') == 'test_string'


# Generated at 2022-06-25 09:10:59.018511
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(1, "asdf")


# Generated at 2022-06-25 09:11:09.175420
# Unit test for function do_vault

# Generated at 2022-06-25 09:11:20.481432
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:11:21.812907
# Unit test for function do_vault
def test_do_vault():
    clear_text = 'password'
    secret = 'secret'
    encrypted = do_vault(clear_text, secret)

    assert(is_encrypted(encrypted))


# Generated at 2022-06-25 09:11:26.078187
# Unit test for function do_unvault
def test_do_unvault():
    pass


# Generated at 2022-06-25 09:11:34.137532
# Unit test for function do_vault

# Generated at 2022-06-25 09:11:44.818714
# Unit test for function do_vault
def test_do_vault():
    # Test for non string secret
    secret = [1, 2, 3, 4]
    data = 'test_case'
    try:
        vault = do_vault(data, secret)
        # Expected to raise an exception ansible.errors.AnsibleFilterTypeError
        assert False
    except AnsibleFilterTypeError as e:
        assert True

    # Test for valid string secret
    secret = 'mysecret'
    data = 'test_case'
    try:
        vault = do_vault(data, secret)
    except AnsibleFilterTypeError as e:
        assert False

    # Test for non string data
    secret = 'mysecret'
    data = [1, 2, 3, 4]

# Generated at 2022-06-25 09:11:54.320040
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:01.304599
# Unit test for function do_vault
def test_do_vault():
    string_1 = 'string_01'
    string_2 = 'string_02'
    secret = 'my_secret'
    salt = 'my_salt'
    vault_id = 'filter_default'
    wrap_object = True
    ret_val_0 = do_vault(string_1, string_2, salt, vault_id, wrap_object)
    ret_val_1 = do_vault(string_1, secret, salt, vault_id, wrap_object)


# Generated at 2022-06-25 09:12:05.907033
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '0.0.0.0'   # SOURCE: Pattern(Literal)
    str_1 = '$HOME/.ansible/vault'   # SOURCE: Pattern(Literal)
    var_0 = do_unvault(str_0, str_1)
    assert var_0 == '0.0.0.0'


# Generated at 2022-06-25 09:12:11.531934
# Unit test for function do_unvault
def test_do_unvault():
    v = '$ANSIBLE_VAULT;1.1;AES256'
    k = 'foo'
    data = {'test': 'this is a test'}

    import yaml
    enc = do_vault(yaml.safe_dump(data), k)
    test_data = do_unvault(enc, k)

    if test_data != data:
        raise AssertionError('Unvaulted data is different than original data')


# Generated at 2022-06-25 09:12:20.902132
# Unit test for function do_vault
def test_do_vault():
    str_0 = ' '
    str_1 = '+'
    str_2 = '_'
    str_3 = '\'s'
    str_4 = 'N'
    str_5 = ','
    str_6 = 'L_'
    str_7 = 'S'
    str_8 = 'Pb'
    str_9 = 'O'
    str_10 = '\'s'
    str_11 = ' z'
    str_12 = ','
    str_13 = 'g'
    str_14 = '\'s'
    str_15 = 'w'
    str_16 = ','
    str_17 = 'E'
    str_18 = '\'s'
    str_19 = 'b`'
    str_20 = 'C'

# Generated at 2022-06-25 09:12:24.932673
# Unit test for function do_unvault
def test_do_unvault():
    assert AnsibleFilterTypeError , do_unvault('Secret passed is required to be a string, instead we got: ', 'Secret passed is required to be as string, instead we got: ')
    assert AnsibleFilterTypeError , do_unvault('Secret passed is required to be a string, instead we got: ', 'Vault should be in the form of a string, instead we got: ')


# Generated at 2022-06-25 09:12:31.066011
# Unit test for function do_vault
def test_do_vault():
    str_0 = "hi"
    str_1 = "hello"
    str_2 = "good"
    str_3 = "really"
    str_4 = "bad"
    str_5 = "goodbye"
    str_6 = "how"
    try:
        print(do_vault(str_0, str_1, str_2, str_3, str_4))
    except Exception as e:
        print(e.orig_exc)
    try:
        print(do_vault(str_5, str_6, str_2, str_1))
    except Exception as e:
        print(e.orig_exc)

# Generated at 2022-06-25 09:12:42.069238
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 's\rIt'

# Generated at 2022-06-25 09:12:44.976973
# Unit test for function do_unvault
def test_do_unvault():
    for _ in range(1):
        str_0 = 'CgklL'
        var_0 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:12:50.071937
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 09:12:51.715219
# Unit test for function do_unvault
def test_do_unvault():
    assert (do_unvault(str_0, str_0) == "test")

test_case_0()

# Generated at 2022-06-25 09:12:59.264280
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault(str_0, str_0, str_0)
    # assert equals

# Generated at 2022-06-25 09:13:09.101357
# Unit test for function do_vault
def test_do_vault():
    # The data is a string
    data = 'test'
    # The secret is a string
    secret = 'secret'
    # The salt string is optional, but if set it must be 32 characters long
    salt = 'salt'
    # The vaultid is optional, but if you have multiple vaults, you can specify the one you want to use
    vaultid = 'filter_default'
    # wrap_object is optional, so defaults to false
    wrap_object = False
    # Call do_vault()
    var_0 = do_vault(data, secret, salt, vaultid, wrap_object)

    test_case_0()

# Generated at 2022-06-25 09:13:12.261588
# Unit test for function do_unvault
def test_do_unvault():
    data = 'd\rIt'
    secret = 's\rIt'
    vaultid = 'vaultid'
    try:
        do_unvault(data, secret, vaultid)
    except AnsibleFilterTypeError:
        print('Exception Caught')


# Generated at 2022-06-25 09:13:18.800367
# Unit test for function do_vault
def test_do_vault():
    str_0 = '\r\nh'
    str_1 = '\x00\x01\x02\x03\x04'
    str_2 = '\x92'
    str_3 = '\x93'

# Generated at 2022-06-25 09:13:20.323956
# Unit test for function do_vault
def test_do_vault():
    global secret, data
    vault = do_vault(secret, data, vaultid='filter_default')
    assert vault is not None


# Generated at 2022-06-25 09:13:21.004896
# Unit test for function do_unvault
def test_do_unvault():
    assert isinstance(do_unvault(str_0, str_0, str_0), str)


# Generated at 2022-06-25 09:13:24.394095
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    data = do_unvault(var_0, str_0)
    assert data == str_0

# Generated at 2022-06-25 09:13:36.372573
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:13:46.288436
# Unit test for function do_vault
def test_do_vault():
    var_0 = 's\rIt'
    var_1 = 's\rIt'
    var_2 = 's\rIt'
    var_3 = 'VaultSecret(secret_type=VaultType.SHARED, secret_id=filter_default, secret=b\'s\\rIt\', salt=b\'s\\rIt\')'
    var_4 = 'VaultSecret(secret_type=VaultType.SHARED, secret_id=filter_default, secret=b\'s\\rIt\', salt=b\'s\\rIt\')'
    var_5 = 'VaultSecret(secret_type=VaultType.SHARED, secret_id=filter_default, secret=b\'s\\rIt\', salt=b\'s\\rIt\')'

# Generated at 2022-06-25 09:13:50.069317
# Unit test for function do_vault
def test_do_vault():
    display.display("Starting test_do_vault")

    # Testcase 0
    test_case_0()

    display.display("Test complete")


# Generated at 2022-06-25 09:14:00.522333
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:11.191257
# Unit test for function do_unvault
def test_do_unvault():
    # Example function test without set-up and tear-down
    try:
        assert to_native(do_unvault(str(b'$ANSIBLE_VAULT;1.1;AES256\r\n'), str(b'$ANSIBLE_VAULT;1.1;AES256\r\n'))) == to_native('\u0000')
    except Exception as e:
        raise Exception(e)

    # Example function test without set-up and tear-down

# Generated at 2022-06-25 09:14:17.955543
# Unit test for function do_vault
def test_do_vault():
    var_0 = 'It is a test case'
    var_1 = 'test'
    var_2 = var_0
    var_3 = do_vault(var_0, var_1, var_2)

    assert var_3 == '$ANSIBLE_VAULT;1.1;AES256\r\n63366133333164666532623636363766653865353737366535373635323065663730313661353136623\r\np0\r\n'


# Generated at 2022-06-25 09:14:24.651805
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:14:26.549103
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 's\rIt'
    str_1 = 's\rIt'
    str_2 = 's\rIt'
    var_0 = do_unvault(str_0, str_1, str_2)

# Generated at 2022-06-25 09:14:32.394246
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'real'
    str_1 = 'secret'
    str_2 = "'testing'"
    var_2 = do_vault(str_2, str_0, str_1)
    var_1 = do_unvault(var_2, 'real', str_0)
    assert var_1 == "testing"


# Generated at 2022-06-25 09:14:36.427015
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = ''
    str_0 = '$ANSIBLE_VAULT;1.1;AES256'
    assert do_unvault(str_0, str_1) == str_1


# Generated at 2022-06-25 09:14:39.160546
# Unit test for function do_vault
def test_do_vault():
    # Assert no throw
    try:
        test_case_0()
    except Exception as e:
        assert False


# Generated at 2022-06-25 09:14:50.702146
# Unit test for function do_vault
def test_do_vault():
    str_0 = '49', 'abF', 'abF'
    str_1 = '9', 'abF', 'abF'
    str_2 = 'abF', 'abF', 'abF'
    str_3 = '49', 'abF'
    str_4 = '49', 'abF', 'abF'
    str_5 = '9', 'abF'
    str_6 = 'abF', 'abF'
    str_7 = 's\rIt', 's\rIt', 's\rIt'

# Generated at 2022-06-25 09:14:58.902881
# Unit test for function do_unvault
def test_do_unvault():
    # Set up test inputs
    str_0 = 'SIt'
    bytes_0 = b'SIt'
    ansiblevaultencryptedunicode_0 = AnsibleVaultEncryptedUnicode(bytes_0)
    str_1 = 'salt'
    str_2 = 'filter_default'

    # Perform the action
    var_3 = do_unvault(ansiblevaultencryptedunicode_0, str_0, str_1)

    # Check for correct output
    assert var_3 == str_0



# Generated at 2022-06-25 09:15:10.932571
# Unit test for function do_vault
def test_do_vault():
    data = 'test'
    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    expected = to_bytes('$ANSIBLE_VAULT;1.1;AES256;filter_default'
                        '\n36353738353964633163653862346165383062316237656262316339663265343935373562363139360a'
                        '3965613762356137303366353365336434636464653433323562363939613963366361623361350a3930')
    actual = do_vault(data, secret, salt, vaultid, wrap_object)
    assert expected == actual


# Generated at 2022-06-25 09:15:22.175322
# Unit test for function do_vault
def test_do_vault():
    # test case 0
    # Expected output:
    #   'U2FsdGVkX19ZryOw8DQWI4d4V3q5cXlxW8aRb5ULIjE=\n'
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)

    assert var_0 == 'U2FsdGVkX19ZryOw8DQWI4d4V3q5cXlxW8aRb5ULIjE=\n'



# Generated at 2022-06-25 09:15:30.594720
# Unit test for function do_unvault
def test_do_unvault():
    print("Testing do_unvault...")
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    assert var_0 == 's\rIt', 'Value for var_0 is not correct'
    str_1 = '&\f\nk\\\x16'
    var_1 = do_vault(str_1, str_1, str_1)
    assert var_1 == '&\f\nk\\\x16', 'Value for var_1 is not correct'
    str_2 = '\x1e\x13\x14\x14\x06\x01\x11\x05'
    var_2 = do_vault(str_2, str_2, str_2)
    assert var

# Generated at 2022-06-25 09:15:39.626882
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    str_1 = 'se\x1e'
    str_2 = 's\rIt'
    var_1 = do_vault(str_1, str_2, str_0)
    str_3 = '\r'
    str_4 = 'se\x1e'
    str_5 = '\r'
    str_6 = '\r'
    var_2 = do_unvault(str_3, str_4, str_5)
    str_7 = '\r'
    str_8 = '\r'
    str_9 = '\r'

# Generated at 2022-06-25 09:15:48.264630
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'h\xc5\xa9\x16?\x8f\x13\x08\xc5/\xfd\t\xfe\xda\x9e\x89\xa8\x8d\x0c\x88\xba\xdc\x18\x04\x9b\x98\x87'
    var_0 = do_unvault(str_0, str_0)
    assert var_0 == 'sIt'



# Generated at 2022-06-25 09:15:56.218182
# Unit test for function do_vault
def test_do_vault():
    # Tests on a simple string
    str_0 = 'simple'
    var_0 = do_vault(str_0, str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256;simple\n30333638646234333738353036666437333735303438623535386361613862306135366364656539\n663331376131626463306538306637303536373934313334646265373631623163336163313861\n6232333565666338630a6632363237366262633863386361613936376161386132396532356361\n66'
    # Tests on a string with escape characters

# Generated at 2022-06-25 09:16:02.536951
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'sIt'
    var_0 = do_vault(str_0, str_0, str_0)

    str_1 = 's\rIt'
    var_1 = do_vault(str_1, str_1, str_1)

    str_2 = 's\r\nIt'
    var_2 = do_vault(str_2, str_2, str_2)

    str_3 = 's\r\n\tIt'
    var_3 = do_vault(str_3, str_3, str_3)

    str_4 = 's\r\n\t\x10It'
    var_4 = do_vault(str_4, str_4, str_4)


# Generated at 2022-06-25 09:16:06.303529
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('string', 'secret', 'salt')
    assert isinstance(vault, str)



# Generated at 2022-06-25 09:16:10.233395
# Unit test for function do_unvault
def test_do_unvault():

    # Test move to a new line
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    assert do_unvault(var_0, str_0) == 'sIt'

    # Test move to a new line
    str_0 = 's\rit'
    var_0 = do_vault(str_0, str_0, str_0)
    assert do_unvault(var_0, str_0) == 'sIt'

    # Test move to a new line
    str_0 = 's\r\nit'
    var_0 = do_vault(str_0, str_0, str_0)
    assert do_unvault(var_0, str_0) == 'sIt'

   

# Generated at 2022-06-25 09:16:13.982702
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'

    var_0 = do_vault(str_0, str_0, str_0)
    assert var_0 is None, "'return value' should be None"


# Generated at 2022-06-25 09:16:16.436970
# Unit test for function do_vault
def test_do_vault():
    var_1 = 's\rIt'
    assert isinstance(do_vault(var_1, var_1, var_1), string_types)


# Generated at 2022-06-25 09:16:31.978653
# Unit test for function do_vault
def test_do_vault():

    result = do_vault('string', 'string', 'string', 'string')

# Generated at 2022-06-25 09:16:43.026543
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:50.282149
# Unit test for function do_vault
def test_do_vault():
    # This function will return the result of the test cases
    try:
        # This is to test the result of the test case
        assert do_vault('s\rIt', 's\rIt', 's\rIt') is not None
        assert do_vault('Let us see if we can encrypt this', 'EncryptMe') is not None
    except Exception as e:
        print(e)


# Generated at 2022-06-25 09:17:01.238026
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    str_1 = '\t\x07'
    var_1 = do_vault(str_1, str_1, str_1)
    str_2 = '\x1b\n\t\x12\x06\t\x14\x06\t\x14\x06\t\x14\x06\t\x1a\x06\t\x17\x06\t\x1a\x06\t\x14\x06'
    var_2 = do_vault(str_2, str_2, str_2)

# Generated at 2022-06-25 09:17:03.111104
# Unit test for function do_vault
def test_do_vault():

    # 0, 's\rIt', 's\rIt', 's\rIt', False
    test_case_0()

# Generated at 2022-06-25 09:17:09.248737
# Unit test for function do_vault
def test_do_vault():

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode('m\rJz')
    str_0 = 's\rIt'
    var_0 = do_vault(ansible_vault_encrypted_unicode_0, str_0, str_0)

    # AssertionError: ('Vault should be in the form of a string, instead we got: <class \'ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode\'>',)
    assert var_0 == 'm\rJz'


# Generated at 2022-06-25 09:17:11.544071
# Unit test for function do_vault
def test_do_vault():
    if __name__ == '__main__':
        test_case_0()



# Generated at 2022-06-25 09:17:19.542857
# Unit test for function do_vault
def test_do_vault():
    assert ansible_vault.utils.do_vault("test_value", "test_secret", "test_salt")
    assert ansible_vault.utils.do_vault("test_value", "test_secret", "test_salt", "test_vaultid")
    assert ansible_vault.utils.do_vault("test_value", "test_secret", "test_salt", "test_vaultid", True)

# Generated at 2022-06-25 09:17:29.907399
# Unit test for function do_unvault

# Generated at 2022-06-25 09:17:36.907981
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:17:47.966135
# Unit test for function do_vault
def test_do_vault():
    example_1 = 's\rIt'
    secret_1 = 's\rIt'
    salt_1 = 's\rIt'

# Generated at 2022-06-25 09:17:56.222916
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:06.805984
# Unit test for function do_vault
def test_do_vault():
    assert len(do_vault('s\rIt', 's\rIt', 's\rIt')) == 64

# Generated at 2022-06-25 09:18:18.675391
# Unit test for function do_vault
def test_do_vault():

    # Test for built-in type data
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)

    # Test for Undefined value
    str_0 = Undefined
    var_0 = do_vault(str_0, str_0, str_0)

    # Test for built-in type secret
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)

    # Test for Undefined value
    str_0 = Undefined
    var_0 = do_vault(str_0, str_0, str_0)

    # Test for built-in type salt
    str_0 = 's\rIt'
    var_0 = do_vault

# Generated at 2022-06-25 09:18:25.748956
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.2;AES256;myvault_default\n33393035613361626366373036663336343238663435633766643065663062663566633037366465\n6430363364666233653338313165663563366666663306331656230636364616136363561333538\n36643330356431303033313332626663366432393864393566643765366432333131663236346431\n643537323065303766\n'.encode()

# Generated at 2022-06-25 09:18:27.730015
# Unit test for function do_vault
def test_do_vault():
    assert True  # is there a better way to test this?


# Generated at 2022-06-25 09:18:28.604624
# Unit test for function do_vault
def test_do_vault():
      test_case_0()
      test_case_1()

# Generated at 2022-06-25 09:18:31.890189
# Unit test for function do_vault
def test_do_vault():
    # str_0 = 's\rIt'
    # str_1 = 'Vault password: '
    # str_2 = 'AQA5YkRpNzRtbGJDb3ZDR0F3dTFpcQ=='
    # assert do_vault(str_0, str_1, str_2) == str_2
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 09:18:37.028013
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'wYU6'
    str_1 = 'n'
    str_2 = 'JXx'
    str_3 = ' '
    var_0 = do_vault(str_0, str_1, str_2, str_3)
    assert var_0 == '!&Vu$&&%'
    str_0 = 'C\r'
    str_1 = '\''
    str_2 = '\r'
    str_3 = '\rE'
    var_0 = do_vault(str_0, str_1, str_2, str_3)
    assert var_0 == '!&4&%'
    str_0 = '5'
    str_1 = 'lPQ'
    str_2 = 'iz'

# Generated at 2022-06-25 09:18:39.636630
# Unit test for function do_vault
def test_do_vault():
    try:
        assert do_vault(None, None, None, None) == None
    except TypeError:
        assert True

    try:
        assert do_vault(None, None, None, None) == None
    except TypeError:
        assert True

    try:
        assert do_vault(None, None, None, None) == None
    except TypeError:
        assert True


# Generated at 2022-06-25 09:18:50.079430
# Unit test for function do_vault
def test_do_vault():

    # This test case calls the function with arguments that satisfy
    # the following condition:
    # (isinstance(type(x), (type, Undefined)))
    test_case_0()    
    return None


# Generated at 2022-06-25 09:18:56.852694
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:57.915783
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:19:07.237556
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256\r\n62333265616431346232363364363830643461316233333433613731313464396565353836623066\r\nrGq3IqHyT3TtTnTtGq3ISI3MzGGnRnTtTnTtTnRnRq3ISI3MzGGnRnRq3IqHf\r\n'

# Generated at 2022-06-25 09:19:09.510613
# Unit test for function do_vault
def test_do_vault():
    str_0 = 's\rIt'
    var_0 = do_vault(str_0, str_0, str_0)
    assert type(var_0) is not AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 09:19:12.337917
# Unit test for function do_vault

# Generated at 2022-06-25 09:19:20.824479
# Unit test for function do_vault
def test_do_vault():

    # This function is responsible to test do_vault function
    # For this function following things needs to be tested:
    #       1) function should return AnsibleVaultEncryptedUnicode object
    #       2) function shouldn't accept objects that are not strings


    # TEST CASE 1: Function should return AnsibleVaultEncryptedUnicode object

    # Arrange

    # string to be encrypted
    str_0 = 's\rIt'

    # Act
    var_0 = do_vault(str_0, str_0, str_0)

    # Assert
    # Check whether the function returns an object of AnsibleVaultEncryptedUnicode

    assert isinstance(var_0, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 09:19:26.786433
# Unit test for function do_vault