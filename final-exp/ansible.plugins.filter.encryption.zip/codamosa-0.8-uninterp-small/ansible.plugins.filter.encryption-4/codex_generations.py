

# Generated at 2022-06-25 09:09:29.244561
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test_default\r\nyWcAnxhvHtI7RtbKrzWOzt0rIfdXjMNJe0y0pWlxD551vjKdo+0YxaYs8sZz\r\nz7hHm4cJZgMnZoRwV5pCJ5Gxq7g1yb'
, 'test') == 'test'

# Generated at 2022-06-25 09:09:37.434786
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'rt2&pGm}'
    str_1 = 'mW#0zMRogA$ioJ\\OQ3r'
    var_0 = do_vault(str_0, str_0, str_1)
    var_1 = AnsibleVaultEncryptedUnicode(var_0)
    var_2 = do_unvault(var_1, str_0)
    assert str_0 == var_2



# Generated at 2022-06-25 09:09:46.073352
# Unit test for function do_vault
def test_do_vault():
    instance = None
    str_0 = 'rt2&pGm}'
    str_1 = 'mW#0zMRogA$ioJ\OQ3r'
    var_0 = AnsibleVaultEncryptedUnicode(do_vault(str_0, str_0, str_1))
    var_1 = AnsibleVaultEncryptedUnicode(do_vault(var_0, str_0))
    var_2 = AnsibleVaultEncryptedUnicode(do_vault(var_1, str_0))



# Generated at 2022-06-25 09:09:52.696763
# Unit test for function do_unvault
def test_do_unvault():
    # initialize test values
    # Test for call of do_unvault() without parameters
    test_values = [
    ]
    for testvalue in test_values:
        try:
            result = do_unvault()
        except TypeError as e:
            # caught an exception, verify exception message
            assert e[0] == "unexpected keyword argument 'vault'"
        except Exception as e:
            # caught an exception, verify exception message
            assert str(e) == "unexpected keyword argument 'vault'"
        else:
            # no exception, verify return value
            assert True == False, "Expected Exception"


# Generated at 2022-06-25 09:09:58.015321
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'rt2&pGm}'
    str_1 = 'mW#0zMRogA$ioJ\\OQ3r'
    var_0 = do_vault(str_0, str_0, str_1)

    var_1 = do_unvault(var_0, str_0, str_1)

    assert var_1 == str_0


# Generated at 2022-06-25 09:10:08.496974
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:13.311234
# Unit test for function do_vault
def test_do_vault():
    assert 'Vault:::1:::7V5zke8W1IZVdD5oXI7YGnRwnRJAvKU+2Q2CE3qH1ye6L3+6UAnyXAe9ZfxjKZ8C3wFpBvsFG0=' == do_vault('rt2&pGm}', 'rt2&pGm}', 'mW#0zMRogA$ioJ\\OQ3r')


# Generated at 2022-06-25 09:10:16.761665
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = do_unvault(str_0, str_1)
    except AnsibleFilterError:
        assert False


# Generated at 2022-06-25 09:10:26.222175
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = 'rt2&pGm}'
        str_1 = 'mW#0zMRogA$ioJ\\OQ3r'
        var_0 = do_vault(str_0, str_0, str_1)
        var_1 = do_unvault(var_0, str_1, 'filter_default')
        assert var_0 is not None
        assert var_1 == str_0
    except AnsibleFilterError as afe:
        print(afe)
        assert False
    except Exception as e:
        print(e)
        assert False
    else:
        assert True


# Generated at 2022-06-25 09:10:30.053718
# Unit test for function do_unvault
def test_do_unvault():
    
    str_0 = 'rt2&pGm}'
    str_1 = 'mW#0zMRogA$ioJ\\OQ3r'
    var_0 = do_vault(str_0, str_0, str_1)
    var_1 = do_unvault(var_0, str_0)
    assert str_0 == var_1

# Generated at 2022-06-25 09:10:36.892654
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:38.132426
# Unit test for function do_vault
def test_do_vault():
    assert True


# Generated at 2022-06-25 09:10:47.634696
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n3539663132646332666436393438353365396265393232633233636530613034663537633032303066\n3961333765396131633731346132623235613162643530363432366232343566373536623432643933\n6265646364613232306134366530356539663439386635343863656338366163393330303161346233\n65383338663061633666636366366633636466653764393331\n'

# Generated at 2022-06-25 09:10:57.035800
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:59.580634
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('ansible', 'ansible_mito', wrap_object=True)


# Generated at 2022-06-25 09:11:06.012430
# Unit test for function do_vault
def test_do_vault():
    pass



# Generated at 2022-06-25 09:11:12.922690
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'secret_data'

# Generated at 2022-06-25 09:11:15.223567
# Unit test for function do_vault
def test_do_vault():
    print(do_vault('hello', 'secret'))


# Generated at 2022-06-25 09:11:26.012607
# Unit test for function do_vault

# Generated at 2022-06-25 09:11:34.084487
# Unit test for function do_vault
def test_do_vault():
    from lib.vault_filters import do_vault
    from jinja2 import Undefined


# Generated at 2022-06-25 09:11:44.801491
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)
    assert isinstance(var_0, str)
    assert var_0.private_key == 'cH3GB9@zKI4'
    assert var_0.vault_id != 'cH3GB9@zKI4'
    assert var_0.salt_bytes != 'cH3GB9@zKI4'
    assert var_0.data == 'cH3GB9@zKI4'
    assert var_0.vault != VaultLib(cipher='AES256')


# Generated at 2022-06-25 09:11:54.320661
# Unit test for function do_vault
def test_do_vault():
    salt_0 = 'gDNCddv'
    var_0 = do_vault('cH3GB9@zKI4', 'cH3GB9@zKI4', salt_0)


# Generated at 2022-06-25 09:11:59.929687
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:08.281016
# Unit test for function do_vault
def test_do_vault():
    arg0 = 'cH3GB9@zKI4'
    arg1 = 'cH3GB9@zKI4'
    arg2 = 'cH3GB9@zKI4'
    arg3 = 'filter_default'
    res = do_vault(arg0, arg1, arg2, arg3)

# Generated at 2022-06-25 09:12:13.710074
# Unit test for function do_vault
def test_do_vault():
    test_str_0 = 'cH3GB9@zKI4'
    test_str_1 = 'cH3GB9@zKI4'
    test_str_2 = 'cH3GB9@zKI4'
    try:
        var_0 = do_vault(test_str_0, test_str_1, test_str_2)
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 09:12:23.202637
# Unit test for function do_unvault
def test_do_unvault():
    # Test with a string
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_unvault(str_0, str_0, 'str_0')
    assert var_0 == str_0
    # Test with an AnsibleVaultEncryptedUnicode object
    str_1 = 'cH3GB9@zKI4'
    var_1 = do_vault(str_1, str_1, str_1)
    var_1 = do_unvault(var_1, str_1, 'str_1')
    assert var_1 == str_1

# Generated at 2022-06-25 09:12:32.032575
# Unit test for function do_vault
def test_do_vault():
    try:
        assert isinstance(do_vault('test', 'test', 'test', 'test'), str)
        assert isinstance(do_vault('test', 'test', 'test', 'test', True), AnsibleVaultEncryptedUnicode)
        assert isinstance(do_vault(123, 'test', 'test', 'test'), AnsibleFilterTypeError)
        assert isinstance(do_vault('test', 123, 'test', 'test'), AnsibleFilterTypeError)
        assert isinstance(do_vault('test', 'test', 123, 'test'), AnsibleFilterTypeError)
        assert isinstance(do_vault('test', 'test', 'test', 123), AnsibleFilterTypeError)

    except AssertionError as e:
        assert False, "Filter 'do_vault' returned %s" % e

# Generated at 2022-06-25 09:12:43.133693
# Unit test for function do_unvault
def test_do_unvault():

    # Store result
    result = do_unvault(str_0, str_0)
    str_1 = to_native(result)
    str_2 = 'cH3GB9@zKI4'
    str_3 = 'filter_default'
    str_4 = 'HchxwioApZRJWcAMfQAIzA=='
    str_5 = 'foo'

# Generated at 2022-06-25 09:12:47.761263
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:12:58.205785
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'secret'
    str_1 = 'secret'
    str_2 = 'salt'
    str_3 = 'filter_default'
    try:
        var_0 = do_vault(str_0, str_1, str_2, str_3)
    except AnsibleFilterTypeError:
        var_0 = None
    except AnsibleFilterError:
        var_0 = None
    except Exception:
        var_0 = None

# Generated at 2022-06-25 09:13:10.750611
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    str_1 = '!4$N4xh4F'
    str_2 = '!4$N4xh4F'
    str_3 = '!4$N4xh4F'

    var_0 = do_vault(str_0, str_1, str_2, str_3)

    str_0 = '$ANSIBLE_VAULT;1.2;AES256;filter_default'
    str_1 = '34393762626139353262383834333634306162326132613461353132353666663065323333643639'

# Generated at 2022-06-25 09:13:21.827700
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:32.033048
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:38.890542
# Unit test for function do_vault
def test_do_vault():
    args = {'data': 'test', 'secret': 'test', 'salt': 'test', 'vaultid': 'test', 'wrap_object': False}
    assert do_vault('test', 'test', 'test', 'test', False) == do_vault(*args.values())


# Generated at 2022-06-25 09:13:49.480635
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'RfkJHlI8m2'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:13:57.363503
# Unit test for function do_unvault
def test_do_unvault():
    # Provide values for filter test
    filter_test_data = 'nCVYlYp9A4mhlxl+FCQZGzmxbhg3rboe8hBQ5H5JJMdY81X'

    # Provide values for return test
    ret_test_data = 'cH3GB9@zKI4'

    # Call do_unvault with filter_test_data
    result = do_unvault(filter_test_data, 'cH3GB9@zKI4', 'filter_default')

    # Get assert result
    assert ret_test_data == result

# Generated at 2022-06-25 09:14:05.624805
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:13.921547
# Unit test for function do_vault
def test_do_vault():
    vault_obj = AnsibleVaultEncryptedUnicode()
    vault_obj.vault = VaultLib()
    vault_obj.vaultid = "test_secret"
    vault_obj.vault_version = 1
    vault_obj.hmac = None
    vault_obj.data = b"my data"

    assert isinstance(vault_obj, do_vault('my data', 'test_secret', wrap_object=True))

    assert is_encrypted(do_vault('my data', 'test_secret'))

    assert do_unvault(do_vault('my data', 'test_secret'), 'test_secret') == 'my data'

# Generated at 2022-06-25 09:14:22.017958
# Unit test for function do_vault
def test_do_vault():
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault(None, None, None)
    excinfo.match(r'.*Secret passed is required to be a string.*')
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault('', '', '')
    excinfo.match(r'.*Secret passed is required to be a string.*')
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault('', '', '')
    excinfo.match(r'.*Secret passed is required to be a string.*')
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault('', None, None)

# Generated at 2022-06-25 09:14:27.363331
# Unit test for function do_vault
def test_do_vault():
    data = "data"
    secret = "secret"
    salt = "salt"
    vaultid = "vaultid"
    wrap_object = False

# Generated at 2022-06-25 09:14:30.996783
# Unit test for function do_vault
def test_do_vault():
    assert True


# Generated at 2022-06-25 09:14:33.384311
# Unit test for function do_vault
def test_do_vault():

    # Testing when the function is called with valid parameters
    try:
        test_case_0()
    except Exception as exception:
        print('Exception:', exception)
        assert False


# Generated at 2022-06-25 09:14:45.637849
# Unit test for function do_unvault
def test_do_unvault():
    # Test for string with Undefined as secret
    ansible_vault_str_0 = '$ANSIBLE_VAULT;1.1;AES256\n66396137636263323239613561323936346633303439666236633139386664616639336563383036\n37643639306431346165633166666439386664353465643236323463356536646364653038363364\n666535\n'
    secret_0 = Undefined()
    vaultid_0 = 'filter_default'
    try:
	    do_unvault(ansible_vault_str_0, secret_0, vaultid_0)
    except AnsibleFilterError:
        pass
		
    # Test for string with empty string

# Generated at 2022-06-25 09:14:51.663450
# Unit test for function do_vault
def test_do_vault():
    try:
        str_0 = 'cH3GB9@zKI4'
        var_0 = do_vault(str_0, str_0, str_0)
        print("Success")
    except Exception as e:
        print(e)
        print("Failed")

if __name__ == "__main__":
    test_case_0()
    test_do_vault()

# Generated at 2022-06-25 09:15:01.574090
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:13.628615
# Unit test for function do_unvault

# Generated at 2022-06-25 09:15:23.248802
# Unit test for function do_vault
def test_do_vault():
    str_0 = '0Bz2X9RdMtzZ1NhNwcLk'
    var_0 = do_vault(str_0, str_0, str_0)
    var_1 = '$ANSIBLE_VAULT;1.1;AES256;'
    var_2 = '6637303962633259525078857619332963512531697e9f7e2d36362d6236316a3833'
    var_3 = '6a316732373939363762303f636b5d5c564c0a6432373b37343537643838376163'

# Generated at 2022-06-25 09:15:27.759221
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = u"BgtR1RZQW8OzOcZJKeAaFw"
    str_1 = u"cH3GB9@zKI4"
    var_0 = do_unvault(str_0, str_1)
    # Simple variable u'data' from do_unvault
    assert var_0 == 'test'



# Generated at 2022-06-25 09:15:39.114769
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    str_1 = 'cH3GB9@zKI4'
    str_2 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_1, str_2)
    str_3 = '$ANSIBLE_VAULT;1.1;AES256'
    str_4 = '6323033637353163393636643734656437393837356531323933373464353030663735313434396130'
    str_5 = '3539393732393437333335363338313061636562346339633339663965626166326236613130316630'

# Generated at 2022-06-25 09:15:51.716624
# Unit test for function do_vault
def test_do_vault():
    assert 75 == len(do_vault('cH3GB9@zKI4', 'cH3GB9@zKI4', 'cH3GB9@zKI4'))
    assert 75 == len(do_vault('cH3GB9@zKI4', 'cH3GB9@zKI4', 'cH3GB9@zKI4'))
    assert 75 == len(do_vault('cH3GB9@zKI4', 'cH3GB9@zKI4', 'cH3GB9@zKI4'))
    assert 75 == len(do_vault('cH3GB9@zKI4', 'cH3GB9@zKI4', 'cH3GB9@zKI4'))



# Generated at 2022-06-25 09:16:02.155534
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:09.250172
# Unit test for function do_vault
def test_do_vault():
    try:
        str_0 = '13pzgvR8WUTfzIY'
        str_1 = 'SRXQn1nrnEjKk'
        str_2 = 'WYFzrswcKrF'
        str_3 = do_vault(str_0, str_1, str_2)
    except Exception as err:
        print("Test do_vault failed: " + str(err))
        assert False
    else:
        assert True



# Generated at 2022-06-25 09:16:15.550932
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'cH3GB9@zKI4'

    var_0 = do_vault(str_0, str_0, str_0)

    # do_unvault needs to be called with the secret
    var_1 = do_unvault(var_0, str_0, str_0)

    assert var_1 == str_0

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-25 09:16:28.093194
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Load the srcdata for the test_case
    src_file = '../data/do_unvault_unit.src'
    srcdata = open(src_file, 'r').read()
    srcdata = do_unvault(srcdata, 'oxygen')

    # Load the refdata for the test_case
    ref_file = '../data/do_unvault_unit.ref'
    refdata = AnsibleUnicode(open(ref_file, 'r').read().rstrip())

    start_testcase("do_unvault")

    # Compare actual_data to expected_data
    try:
        assert refdata == srcdata
    except AssertionError as e:
        testfailed(e)

    end_

# Generated at 2022-06-25 09:16:33.676776
# Unit test for function do_vault
def test_do_vault():
    test_str = "Testing"
    test_secret = "secret"
    vaulted_str = do_vault(test_str, test_secret)
    unvaulted_str = do_unvault(vaulted_str, test_secret)
    assert unvaulted_str == test_str
    # Test an error case
    try:
        do_vault(1, 2, 3)
    except AnsibleFilterTypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 09:16:36.443615
# Unit test for function do_vault
def test_do_vault():
    test_case_0()

# Generated at 2022-06-25 09:16:40.499179
# Unit test for function do_vault
def test_do_vault():
    # Test with the necessary arguments
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)



# Generated at 2022-06-25 09:16:47.295264
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert do_unvault('uYj1Dn7u@CLm@A7gu2Ws') == 'cH3GB9@zKI4'
    except Exception as e:
        print(e)
        assert False
    try:
        assert do_unvault('ed@NefNhj@LNbQPxoZ') == 'cH3GB9@zKI4'
    except Exception as e:
        print(e)
        assert False
    try:
        assert do_unvault('966vn8ySdQHb5q5DOq') == 'cH3GB9@zKI4'
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-25 09:16:49.324081
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_unvault(str_0, str_0, str_0)
    print(str(var_0))


# Generated at 2022-06-25 09:17:00.941534
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:22.353522
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:17:27.525384
# Unit test for function do_vault
def test_do_vault():
    str_0 = str(random.randrange(100000000000000000))
    str_1 = str(random.randrange(100000000000000000))
    str_2 = str(random.randrange(100000000000000000))
    obj_3 = do_vault(str_0, str_1, str_2)
    assert_is_instance(obj_3, str)
    assert_equal(is_encrypted(obj_3), True)


# Generated at 2022-06-25 09:17:30.558469
# Unit test for function do_vault
def test_do_vault():
    assert func_0(str_1, str_2, str_3) == str_4
    assert func_0(str_1, str_2) == str_5
    assert func_0(str_1, str_2, str_3, str_6) == str_7


# Generated at 2022-06-25 09:17:41.259236
# Unit test for function do_unvault
def test_do_unvault():
    import ansible.parsing.yaml.objects
    str_1 = 'iVxGlvS5j7Y'
    str_2 = '5iQ6U2z6UoW'
    str_3 = '1@qYjG@WcyU'
    str_4 = 'U6RkgD6Wy9v'
    value = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode(str_1)
    ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.__init__(value, str_2)
    ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.data(value)
    ansible.parsing.yaml.objects.AnsibleV

# Generated at 2022-06-25 09:17:44.190559
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'cH3GB9@zKI4'
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:17:52.351013
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'wiLhDx6GTJK'
    str_1 = 'uu+bIa7VQ2j'
    str_2 = 'PdC7IuSqe9Y'
    var_1 = do_unvault(str_1, str_0)
    var_0 = do_unvault(str_0, str_1)
    var_2 = do_unvault(str_2, str_0)


# Generated at 2022-06-25 09:18:02.216880
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:06.890461
# Unit test for function do_vault
def test_do_vault():
    assert callable(do_vault)


# Generated at 2022-06-25 09:18:09.661271
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_unvault(do_vault(str_0, str_0, str_0), str_0)

# Generated at 2022-06-25 09:18:14.262234
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'b{#d>o#K0|:=^n>}KZ$!x'
    var_0 = do_vault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:18:34.459493
# Unit test for function do_vault
def test_do_vault():
    try:
        assert(type(do_vault('test')) == str)
    except AssertionError:
        return False

    try:
        assert(type(do_vault('test', 'test')) == str)
    except AssertionError:
        return False

    try:
        assert(type(do_vault('test', 'test', 'test')) == str)
    except AssertionError:
        return False

    try:
        assert(type(do_vault('test', 'test', 'test', 'test')) == str)
    except AssertionError:
        return False

    try:
        assert(type(do_vault('test', 'test', 'test', 'test', True)) == str)
    except AssertionError:
        return False


# Generated at 2022-06-25 09:18:39.870381
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'cH3GB9@zKI4'
    var_0 = do_vault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:18:41.400040
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:18:43.556286
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = 'cH3GB9@zKI4'
    var_0 = do_unvault(str_1, str_1)

# Generated at 2022-06-25 09:18:52.194858
# Unit test for function do_vault
def test_do_vault():
    input_0 = 'n$j07GDfSx'
    input_1 = 'yTp7VlN@s'
    input_2 = 'u#26jBQ*x'
    var_0 = do_vault(input_0, input_1, input_2)
    assert isinstance(var_0, AnsibleVaultEncryptedUnicode)
    assert var_0.vault
    assert var_0.vault.vault_password
    assert var_0.vault.secrets
    assert var_0.vault.secrets[0][0] == 'vault_id'
    assert var_0.vault.secrets[0][1] == 'filter_default'
    assert var_0.vault.secrets[1][0] == 'vault_salt'


# Generated at 2022-06-25 09:19:03.668788
# Unit test for function do_vault

# Generated at 2022-06-25 09:19:07.357373
# Unit test for function do_vault
def test_do_vault():
    assert test_case_0() is None

if __name__ == '__main__':
    test_do_vault()

# Generated at 2022-06-25 09:19:12.646812
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('string_0', 'string_1', 'string_2')
    assert result == '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;filter_default\n          62616135366663366535326465303766646235376266313365653633363839383465363432343162\n          33643661653932333961316132613162343162386332363733616266616635336639383738363031\n          303934353063323138346462353130663835326130396262633761000000\n'
    result = do_vault('string_0', 'string_1')

# Generated at 2022-06-25 09:19:15.707616
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('a','b','c') == ''
    assert do_unvault('ansible','python','vault') == ''


# Generated at 2022-06-25 09:19:19.755555
# Unit test for function do_vault
def test_do_vault():
    assert do_vault({}, '', '') == ''
    try:
        do_vault({}, True, '')
        assert True == False
    except AnsibleFilterTypeError:
        pass
    try:
        do_vault('', {}, '')
        assert True == False
    except AnsibleFilterTypeError:
        pass

