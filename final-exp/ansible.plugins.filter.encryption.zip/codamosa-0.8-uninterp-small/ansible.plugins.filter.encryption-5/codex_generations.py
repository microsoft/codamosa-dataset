

# Generated at 2022-06-25 09:09:31.289783
# Unit test for function do_unvault
def test_do_unvault():
    secret = ''

# Generated at 2022-06-25 09:09:42.067994
# Unit test for function do_vault
def test_do_vault():
    #
    # Assertions for function `do_vault`
    #

    # We'll need to ensure that vaulting actually works, so we'll do a basic test of that
    vaulted = do_vault("passw0rd", "abc123")
    unvaulted = do_unvault(vaulted, "abc123")
    assert unvaulted == "passw0rd"


# Generated at 2022-06-25 09:09:51.107582
# Unit test for function do_unvault
def test_do_unvault():
    print(do_unvault(u'!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61636538373964333562383263323536306461393132353065386566343761666335616435336237\n          64333839353263376530313631623563306466633761396132320a30353638623137396236323665\n          3562636134613161363131652b663335316438313532396338616237323232306564633739613662\n          61653535616661643763643d0a\n          ', 's3cr3t', 'filter_default'))

# Generated at 2022-06-25 09:09:52.388629
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('this is a secret', 'bettersecret') == 'this is a secret'


# Generated at 2022-06-25 09:09:56.748676
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret 3'
    vault_0 = do_vault('foo', 'secret 1', 'salt1', 'vault1', True)
    vaultid_0 = 'vault2'
    result_0 = do_unvault(vault_0, secret, vaultid_0)


### Unit tests for test_case_0


# Generated at 2022-06-25 09:10:05.087005
# Unit test for function do_vault
def test_do_vault():
    data_0 = 'abc'
    secret_0 = ''
    salt_0 = 'abc'
    vaultid_0 = ''
    wrap_object_0 = False
    try:
        do_vault(data_0, secret_0, salt_0, vaultid_0, wrap_object_0)
    except AnsibleFilterError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-25 09:10:11.062133
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

    # Tests with:
    #
    #   Response is:
    #   - b'$ANSIBLE_VAULT;1.1;AES256;ansible\r\n38653866663935653766623936663436656233316263636236326531343738343733383565353\r\n306234626630363366363265376636616235313861633639643563663364383363333430316365\r\n3335613535343063353764346365616337623064340a6262623232646434303238663035303234\r\n61643431313934363335303631333239336262336263303633663735306635646535316

# Generated at 2022-06-25 09:10:22.853527
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'Secret'
    vaultid = 'filter_default'
    
    # TODO: Add testing for case where `UndefinedError` is raised
    try:
        do_unvault(None, secret, vaultid)
    except UndefinedError:
        pass
    
    # TODO: Add testing for case where `AnsibleFilterTypeError` is raised
    try:
        do_unvault(None, None, vaultid)
    except AnsibleFilterTypeError:
        pass
    
    # TODO: Add testing for case where `AnsibleFilterTypeError` is raised
    try:
        do_unvault(None, 'Secret', vaultid)
    except AnsibleFilterTypeError:
        pass
    
    # TODO: Add testing for case where `AnsibleFilterError` is raised

# Generated at 2022-06-25 09:10:34.831547
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "default"

# Generated at 2022-06-25 09:10:41.308201
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:56.116153
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = 'yum'
    vaultid = 'ansible_filter_default'
    # decrypt vault
    vault = do_vault(str_0, secret, vaultid=vaultid, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert not is_encrypted(vault)
    assert secret == do_unvault(vault, secret, vaultid=vaultid)
    # throw an error if the wrong password is given
    vault_0 = do_vault(str_0, secret, vaultid=vaultid, wrap_object=True)
    assert vault_0 != vault


# Generated at 2022-06-25 09:11:06.136533
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:08.832271
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    test_default_0 = do_unvault(str_0, str_1)
    assert str_2 == test_default_0


# Generated at 2022-06-25 09:11:20.057255
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'hello'
    str_1 = 'world'
    str_2 = 'hello' + chr(32) + 'world'
    str_3 = chr(32) + str_2 + chr(32)
    str_4 = 'hello world hello world'
    str_5 = chr(32) + str_4 + chr(32)
    str_6 = str_4 + str_4
    str_7 = str_4 + chr(32) + str_4
    str_8 = str_6 + chr(32) + str_7
    str_9 = chr(10) + str_8 + chr(10)
    str_10 = 'hello world'
    str_11 = chr(10) + str_4 + chr(10)

# Generated at 2022-06-25 09:11:21.171541
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0,) == ''


# Generated at 2022-06-25 09:11:26.098919
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    assert not do_unvault(str_0, str_1, str_2) == do_unvault(str_3, str_4, str_5)
    assert not do_unvault(str_6, str_7, str_0) == do_unvault(str_1, str_2, str_3)
    assert do_unvault(str_4, str_5, str_6) == do_unvault(str_7, str_0, str_1)
    assert not do_unvault(str_2, str_3, str_4)

# Generated at 2022-06-25 09:11:32.390510
# Unit test for function do_unvault
def test_do_unvault():
    try:
        result = do_unvault(str_0, 'mysecret')
        print('PASS: do_unvault')
    except:
        print('FAIL: do_unvault')

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-25 09:11:44.484502
# Unit test for function do_unvault
def test_do_unvault():
    print('\033[1;32;40mTest: test_do_unvault\033[0m')
    str_0 = ''
    str_1 = 'RGVmYXVsdA==\n'
    print(do_unvault(str_1, str_0))
    str_0 = 'ansible'
    str_1 = 'UGxhdGZvcm06OmluY2lkZW50X3JvbGVzX2FjY2Vzcw==\n'
    print(do_unvault(str_1, str_0))
    str_0 = 'RGVmYXVsdA==\n'

# Generated at 2022-06-25 09:11:45.645420
# Unit test for function do_vault
def test_do_vault():
    assert do_vault()


# Generated at 2022-06-25 09:11:47.116965
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:11:51.293999
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-25 09:11:53.338890
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''

    assert do_vault(str_0, str_0, str_0, str_0) == ''



# Generated at 2022-06-25 09:12:03.348686
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:07.796254
# Unit test for function do_unvault
def test_do_unvault():

    # call the function
    assert do_unvault(vault, secret, 'test_0') == ''

# Generated at 2022-06-25 09:12:08.752853
# Unit test for function do_unvault
def test_do_unvault():
    test_case_0()



# Generated at 2022-06-25 09:12:13.494729
# Unit test for function do_unvault
def test_do_unvault():
    print("Test do_unvault...")
    assert do_unvault() == 0 #FIXME
    #assert do_unvault() == 0 #FIXME
    #assert do_unvault() == 0 #FIXME
    #assert do_unvault() == 0 #FIXME
    #assert do_unvault() == 0 #FIXME
    print("Passed all tests for do_unvault.")
	

# Generated at 2022-06-25 09:12:25.180939
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'password'
    vault = '$ANSIBLE_VAULT;1.1;AES256;tester\r\n35303233393132353531383338303835653533663563303933313537623236306165663436613230\r\n323437363638626263643337303537663939356336653765663260a333635336162346237396235\r\n38666535646538396466343564313462666430393364353163633862356134396542656165633163\r\n32353834386662663036396530333665\r\n'
    output = 'This is a test'

    print('Test for string: %s' % str_0)
   

# Generated at 2022-06-25 09:12:33.565057
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:44.785709
# Unit test for function do_unvault
def test_do_unvault():
    # The function should return string, when a string is passed as vault and secret
    assert type(do_unvault(str_0)) == str
    # The function do_unvault should raise the AnsibleFilterError, if an int is passed as secret
    with pytest.raises(AnsibleFilterError):
        do_unvault(str_0, 0)
    # The function do_unvault should raise the AnsibleFilterError, if a bool is passed as secret
    with pytest.raises(AnsibleFilterError):
        do_unvault(str_0, True)
    # The function do_unvault should raise the AnsibleFilterError, if a list is passed as secret
    with pytest.raises(AnsibleFilterError):
        do_unvault(str_0, [])
    #

# Generated at 2022-06-25 09:12:50.921744
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('qwerty123', 'qwerty123')
    assert is_encrypted(vault)


# Generated at 2022-06-25 09:12:54.085897
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_unvault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:13:01.495555
# Unit test for function do_vault
def test_do_vault():
    """
    Test :func:`~ansible_collections.community.general.plugins.filter.ansible_vault.do_vault`
    """

    # Unit test: missing arguments
    try:
        do_vault(None, None, None, None)
    except TypeError as type_err:
        assert 'filters.vault:' in str(type_err)

    # Unit test: missing elements
    try:
        do_vault('str_1', 'str_2', 'str_3', 'str_4')
    except TypeError as type_err:
        assert 'filters.vault:' in str(type_err)

    # Unit test: type error unwrap

# Generated at 2022-06-25 09:13:05.329671
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    vault = 'test_vault'
    secret = 'test_secret'
    vaultid = 'test_vaultid'
    assert do_unvault(vault,secret,vaultid) == None

# Generated at 2022-06-25 09:13:16.495920
# Unit test for function do_unvault
def test_do_unvault():
    data = b''
    secret = b'123'
    assert do_unvault(data, secret) == b''
#     secret = b''
#     assert do_unvault(data, secret) == b''

# Generated at 2022-06-25 09:13:27.128632
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'q3UCCP6UH8DFZW4F'
    str_1 = 'vault:$ANSIBLE_VAULT;1.1;AES256'
    str_2 = '\n'
    str_3 = 'bar\n'
    str_4 = '33333\n'
    str_5 = 'foo\n'
    str_6 = 'hello world\n'
    str_7 = '22222\n'
    str_8 = '111111\n'
    str_9 = '*' * 64
    str_10 = 'explicit'
    var_0 = do_vault(str_0, str_0, str_0, str_0)
    var_1 = str_1 + str_2 + str_3 + str_4 + str_5

# Generated at 2022-06-25 09:13:30.888648
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'imasecret'
    vault = do_vault('my secret data', secret)
    assert vault
    assert '$ANSIBLE_VAULT' in vault
    assert secret not in vault
    assert 'my secret data' not in vault
    assert do_unvault(vault, secret) == 'my secret data'
    assert not do_unvault(vault, secret + 'invalid')


# Generated at 2022-06-25 09:13:39.109772
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:49.571732
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:59.085495
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:05.378096
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test"
    var_0 = do_vault("test", secret, str_0, str_0)
    result = do_unvault(var_0, secret, str_0)
    assert result == "test"
    assert secret == "test"


# Generated at 2022-06-25 09:14:13.972118
# Unit test for function do_vault
def test_do_vault():
    for input_1 in ['', '', '', '']:
        for input_2 in ['', '', '', '']:
            for input_3 in ['', '', '', '']:
                for input_4 in ['filter_default', 'filter_default', 'filter_default', 'filter_default']:
                    var_0 = do_vault(input_1, input_2, input_3, input_4)
                    assert var_0 == 'something'


# Generated at 2022-06-25 09:14:24.854933
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    assert do_vault(str_0, str_0, str_0, str_0) == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n6331636663653137663736333363333432393232383239626237383964623032323161393132336332\n3832393036396437656130323032613661353764366132353165300a38613565643533626562326565\n3830623065376533663064653965613534623339363835656331656565643238353138626530396335\n663837336631316132326539\n')

# Generated at 2022-06-25 09:14:26.925671
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_unvault(str_0, str_0, str_0)


# Generated at 2022-06-25 09:14:27.722389
# Unit test for function do_unvault
def test_do_unvault():
    pass

# Generated at 2022-06-25 09:14:36.106585
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_value'
    assert str_0 == do_unvault(str_0, str_0, str_0)
    str_1 = 'test_value'
    assert str_1 == do_unvault(str_1, str_1, str_1)
    str_2 = 'test_value'
    assert str_2 == do_unvault(str_2, str_2, str_2)
    str_3 = 'test_value'
    assert str_3 == do_unvault(str_3, str_3, str_3)
    str_4 = 'test_value'
    assert str_4 == do_unvault(str_4, str_4, str_4)
    str_5 = 'test_value'
    assert str_5 == do_

# Generated at 2022-06-25 09:14:47.555721
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'filter_default'
    str_1 = ''
    str_2 = 'a'
    str_3 = '5'
    str_4 = 'a2'
    str_5 = 'b'
    str_6 = 'a'
    str_7 = '5'
    str_8 = 'a2'
    str_9 = 'b'
    var_0 = do_vault(str_1, str_0, str_0, str_0)
    var_1 = do_vault(str_2, str_1, str_0, str_0)
    var_2 = do_vault(str_3, str_2, str_0, str_0)
    var_3 = do_vault(str_4, str_3, str_0, str_0)

# Generated at 2022-06-25 09:14:56.580362
# Unit test for function do_unvault
def test_do_unvault():

    str_0 = u'ANSIBLE_VAULT;1.1;AES256;gordonc@gordon.com\n36393933316636663533346565363834356532346439623237626361656232666230303362363965\n36303431396263386633306566383338393838346365323362656364663363666566373039393564\n65646536613037333330616666323362326331666234616663663435333730393262626136313562\n343937316232383831626631636430346535366466393666636533656136636239\n'

# Generated at 2022-06-25 09:15:01.934714
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('1', '2', '3') == '$ANSIBLE_VAULT;1.2;AES256\n300000000000'


# Generated at 2022-06-25 09:15:09.204583
# Unit test for function do_unvault
def test_do_unvault():
    text_0 = ''
    text_1 = ''
    text_2 = ''
    text_3 = ''
    var_0 = do_unvault(text_0, text_1, text_2)
    var_1 = do_unvault(text_3, text_1, text_2)
    assert var_0 == var_1


# Generated at 2022-06-25 09:15:11.408300
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"

    var_0 = do_vault(data, secret)
    var_1 = do_vault(data, secret, None, 'default')
    var_2 = do_vault(data, secret, 'salt', 'default')

# Generated at 2022-06-25 09:15:16.949980
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_1, str_2) == ''

# Generated at 2022-06-25 09:15:29.473291
# Unit test for function do_vault
def test_do_vault():

    # Test with required args only
    str_1 = 'foo.bar'
    str_2 = 'foo.baz'
    str_3 = 'foo.food'
    str_4 = 'foo.boo'
    result = do_vault(str_1, str_2, str_3, str_4)

# Generated at 2022-06-25 09:15:35.706683
# Unit test for function do_unvault
def test_do_unvault():
    # Do function test for do_unvault
    str_0 = "22"
    str_1 = "44"
    ansible_var = do_unvault(str_0, str_1, str_1)
    print(ansible_var)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:15:46.254171
# Unit test for function do_unvault
def test_do_unvault():
    from jinja2.exceptions import UndefinedError
    from . import test_parameters as T
    for param_0 in T.do_unvault.param_0:
        for param_1 in T.do_unvault.param_1:
            for param_2 in T.do_unvault.param_2:
                if param_0.success and param_1.success and param_2.success:
                    continue
                try:
                    do_unvault(param_0, param_1, param_2)
                except UndefinedError as e:
                    assert param_0.success
                except AssertionError as e:
                    assert param_1.success
                except AnsibleFilterTypeError as e:
                    assert param_2.success


# Generated at 2022-06-25 09:15:52.123274
# Unit test for function do_vault
def test_do_vault():
    var_0 = 'abc'
    var_0 = do_vault(var_0, var_0)
    data = '123'
    data = '123'
    var_0 = do_vault(data, data)
    str_0 = ''
    var_0 = do_vault(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 09:15:57.033263
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    str_1 = ''
    var_0 = do_unvault(str_0, str_1, str_0)

################################################################################
#                                End of file
################################################################################

# Generated at 2022-06-25 09:16:00.624866
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0, str_0, str_0)
    var_1 = do_unvault(var_0, str_0, str_0)
    assert var_1 == ''

# Generated at 2022-06-25 09:16:03.659827
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('test_value_0', 'test_value_1', 'test_value_2') == 'test_value_0'


# Generated at 2022-06-25 09:16:05.694069
# Unit test for function do_vault
def test_do_vault():
    secret_0 = ''
    data_0 = ''
    salt_0 = ''
    vaultid_0 = 'filter_default'
    wrap_object_0 = False
    ret_0 = do_vault(data_0, secret_0, salt_0, vaultid_0, wrap_object_0)
    return ret_0


# Generated at 2022-06-25 09:16:08.777591
# Unit test for function do_unvault
def test_do_unvault():

    str_0 = ''
    var_0 = do_unvault(str_0, str_0, str_0)

    # assert return code
    assert var_0 == ''



# Generated at 2022-06-25 09:16:19.803043
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'Awjw/zYWg/D/zlzOzbj1/hcNhzMfX9sbO96G'
    str_1 = '0TtbBp0ga3q3q'

# Generated at 2022-06-25 09:16:25.405903
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0, str_0, str_0)
    var_1 = do_unvault(var_0, str_0, str_0)
    assert var_0 == var_1

# Generated at 2022-06-25 09:16:28.423465
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('4TmJaRHziwmXm0WJFcTvDw==', 'env_secret') == 'hello'


# Generated at 2022-06-25 09:16:30.474407
# Unit test for function do_vault
def test_do_vault():
    str_2 = ''
    str_3 = ''
    test_case_0(str_2, str_3, str_2, str_3)

# Generated at 2022-06-25 09:16:32.988829
# Unit test for function do_unvault
def test_do_unvault():
    param_0 = 'example'
    param_1 = 'example'
    test_func = do_unvault(param_0, param_1)
    assert is_encrypted(test_func)

# Generated at 2022-06-25 09:16:43.193316
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:46.749275
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_0, str_0) == str_0

# Generated at 2022-06-25 09:16:48.013825
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_unvault(str_0, str_0, str_0)
    assert var_0 == ''

# Generated at 2022-06-25 09:16:53.043316
# Unit test for function do_unvault
def test_do_unvault():
    v_0 = ''
    p_0 = ''
    id_0 = VaultSecret(str.encode(p_0))
    vl_0 = VaultLib([(id_0, '')])
    assert do_unvault(v_0, p_0) == vl_0.decrypt(v_0)


# Generated at 2022-06-25 09:16:55.054491
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_unvault(str_0, str_0, str_0)

# Generated at 2022-06-25 09:17:04.083940
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str, str, str) == do_unvault(str, str, str)


# Generated at 2022-06-25 09:17:15.627849
# Unit test for function do_vault
def test_do_vault():
    secret = 'SOME_SECRET'
    salt = 'SOME_SALT'
    vaultid = 'VAULT_ID'


# Generated at 2022-06-25 09:17:20.051208
# Unit test for function do_vault
def test_do_vault():
    p = do_vault(str_0, str_0, str_0, str_0)
    print(p)
    assert p == 'success'



# Generated at 2022-06-25 09:17:24.783199
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    # Using the default value for parameter 'vaultid'
    var_0 = do_unvault(str_0, str_0)
    assert var_0 == ''


# Generated at 2022-06-25 09:17:27.065563
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    str_1 = 'filter_default'
    var_0 = do_unvault(str_0, str_0, str_1)


# Generated at 2022-06-25 09:17:37.142006
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:43.485199
# Unit test for function do_vault
def test_do_vault():
    # Generated from the following line:
    # assert {{ ''|vault('', '')|unvault('', '') }} == ''
    assert do_unvault(do_vault('', '', '', ''), '', '') == ''


# Generated at 2022-06-25 09:17:51.278092
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'J'
    str_2 = 'Jej'
    str_3 = 'Jel'
    str_4 = 'Jel'
    str_5 = 'Jelj'
    str_6 = ''
    str_7 = 'J'
    str_8 = 'Jel'
    str_9 = 'Je'
    str_10 = 'Jel'
    str_11 = 'Jel'
    str_12 = 'Je'
    str_13 = 'Jel'
    str_14 = 'Jel'
    str_15 = 'J'
    str_16 = 'Je'
    str_17 = 'a'
    str_18 = 'J'
    str_19 = 'Jej'
    str_20 = 'Jel'
    var_1 = do_vault

# Generated at 2022-06-25 09:17:55.053557
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0, str_0, str_0)


# Generated at 2022-06-25 09:17:57.624472
# Unit test for function do_unvault
def test_do_unvault():
    if is_encrypted(str_0):
        str_0 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:18:06.841563
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, str_0, str_0, str_0) == ''

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:18:18.708239
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    str_0 = 'QW5zaWJsZVZhdWx0'
    str_1 = 'test'
    str_2 = 'Q2FuIG9ubHkgdG9wb3N0IHN0cmluZ3M='
    str_3 = 'ZGF0YQ=='
    try:
        do_unvault(str_0, str_0, str_0)
    except ValueError:
        pass
    try:
        do_unvault(str_1, str_1, str_1)
    except ValueError:
        pass
    try:
        do_unvault(str_2, str_2, str_2)
    except ValueError:
        pass


# Generated at 2022-06-25 09:18:23.355024
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    var_0 = do_vault(str_0, str_1, str_2, str_3)
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    var_1 = do_vault(str_4, str_5, str_6, str_7)



# Generated at 2022-06-25 09:18:28.396782
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = ''
    str_2 = ''
    str_3 = ''
    var_0 = do_unvault(str_1, str_2, str_3)

# Generated at 2022-06-25 09:18:33.950901
# Unit test for function do_vault
def test_do_vault():
    filt_args = [
        'hello',
        'world',
        'sample-salt',
        'sample-vaultid',
    ]
    filt_arg_types = [
        'str',
        'str',
        'str',
        'str',
    ]

# Generated at 2022-06-25 09:18:35.681509
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '@'
    assert do_unvault(str_0, str_0, str_0) == ''


# Generated at 2022-06-25 09:18:40.398655
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    var_0 = do_vault(str_0, str_1, str_2, str_3)
    assert var_0 is ''


# Generated at 2022-06-25 09:18:42.300807
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('prod_server') == 'prod_server'

# Generated at 2022-06-25 09:18:43.691300
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_0, str_0) == ''

# Generated at 2022-06-25 09:18:47.072562
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = "'"
        var_0 = do_unvault(str_0, str_0, str_0)
    except TypeError as exc:
        print("Caught TypeError: %s" % exc)


# Generated at 2022-06-25 09:18:53.701594
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = 'foo'
    str_0 = 'bar'
    dict_1 = do_unvault(str_0, str_1, str_0)
    assert dict_1


# Generated at 2022-06-25 09:18:55.814767
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'r^a'
    str_1 = '>0o|'
    str_2 = 'O'
    str_3 = 'f=y'
    assert not do_vault(str_0, str_1, str_2, str_3) == 'r^a'


# Generated at 2022-06-25 09:19:01.067897
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    type_0 = type(str_0)
    exc_0 = False
    try:
        var_0 = do_unvault(str_0, str_0, str_0)
    except Exception as var_1:
        exc_0 = True
    assert exc_0 == False
    result = var_0



# Generated at 2022-06-25 09:19:02.662213
# Unit test for function do_unvault
def test_do_unvault():
    assert not do_unvault(str, str, str)


# Generated at 2022-06-25 09:19:14.026244
# Unit test for function do_unvault

# Generated at 2022-06-25 09:19:18.332744
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    assert do_unvault(str_0, str_1, str_2) == ''


# Generated at 2022-06-25 09:19:24.456280
# Unit test for function do_vault
def test_do_vault():

    data = ''
    secret = ''
    salt = ''
    vaultid = ''

    # Output: