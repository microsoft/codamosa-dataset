

# Generated at 2022-06-25 09:09:31.015557
# Unit test for function do_unvault
def test_do_unvault():

    # encrypt string
    secret = 'myvaultsecret'
    data_0 = 'mydata'
    vault_0 = do_vault(data_0, secret)
    print('vaulted data: ', vault_0)
    assert len(vault_0) > len(data_0)

    # decrypt
    data_1 = do_unvault(vault_0, secret)
    assert data_0 == data_1
    print('unvaulted data: ', data_1)

    # encrypt list
    secret = 'myvaultsecret'
    data_0 = ['data_0', 'data_1', 'data_2']
    vault_0 = do_vault(data_0, secret)
    print('vaulted data: ', vault_0)
    assert len(vault_0) > len

# Generated at 2022-06-25 09:09:37.520738
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_password', 'test_secret') == '$ANSIBLE_VAULT;1.1;AES256\n6537303861303533613965306638393866366233653736333532666534323662393736303932\n3733343033343836323839663731613661326362373061613661663066313933353032353733\n36353063363765383562355d0a'

# Generated at 2022-06-25 09:09:40.704185
# Unit test for function do_unvault
def test_do_unvault():
    with pytest.raises(FilterError):
        do_unvault(None, None)


# Generated at 2022-06-25 09:09:43.083990
# Unit test for function do_unvault
def test_do_unvault():

    assert do_unvault('vault. This is a test case', 'test') == 'This is a test case'


# Generated at 2022-06-25 09:09:54.171322
# Unit test for function do_unvault
def test_do_unvault():
    # Unit test for function vault
    assert do_unvault('value', 'secret') == 'value'

    # Unit test for function do_vault

# Generated at 2022-06-25 09:10:00.087127
# Unit test for function do_unvault
def test_do_unvault():
    assert 'test' == do_unvault('$ANSIBLE_VAULT;1.1;AES256;test\n'
                                '623364643339616462326564643336346232376632323636663533386633343431313939383338\n'
                                '333036383362366164333265663433623663323431343639656530636231306331323366373362\n'
                                '65393666333662', 'secret')


# Generated at 2022-06-25 09:10:08.633949
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:15.573345
# Unit test for function do_unvault
def test_do_unvault():
    src = "ansible-vault encrypt somepassword --vault-id test1@prompt my_secret.txt"
    secret = "ansible"


# Generated at 2022-06-25 09:10:26.204633
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:30.423125
# Unit test for function do_unvault
def test_do_unvault():
    # function will raise ansible filter error when vault_id is not valid.
    vault_id = 'ansible-vault'
    secret = ''
    vault = '@EA'
    try:
        data_unvaulted = do_unvault(vault, secret, vault_id)
    except AnsibleFilterError as afe:
        assert 'Vault password must be supplied' in to_native(afe.orig_exc)


# Generated at 2022-06-25 09:10:44.231593
# Unit test for function do_vault
def test_do_vault():
    data = 'sample_secret'
    secret = 'sample_secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-25 09:10:48.674492
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters().get('vault') != None

    assert do_vault(None, 'secret', salt=None, vaultid='filter_default', wrap_object=False) != None


# Generated at 2022-06-25 09:10:57.659666
# Unit test for function do_unvault
def test_do_unvault():

    vaultid = 'filter_default'

# Generated at 2022-06-25 09:11:00.007542
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters().get('vault') is not None



# Generated at 2022-06-25 09:11:07.522963
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    result = do_vault(data, secret, salt, vaultid, wrap_object)

    assert result



# Generated at 2022-06-25 09:11:18.427497
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()


# Generated at 2022-06-25 09:11:20.887894
# Unit test for function do_vault
def test_do_vault():

    display.display("Test case 0")
    secret = "password"
    data = "Hello World"
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    display.display("vault = %s" % vault)


# Generated at 2022-06-25 09:11:32.506171
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("test_vault_value", "test_vault_secret") == '$ANSIBLE_VAULT;1.1;AES256\n34396664303466383562346363616163346530363330306163343561336638623535393533636466\n3431303334303061633036356663386232616236656264643465396466336230616365386435636264\n3530646461396564393533326230623161386366396465663961326264313561623432323764643833\n396261623963396436363064393938663334386438303837383337646630366435373933'

# Generated at 2022-06-25 09:11:42.924955
# Unit test for function do_unvault
def test_do_unvault():
    data = "secret"
    secret = "password"
    vaultid = "filter_default"
    
    assert do_vault(data,secret,vaultid) == "$ANSIBLE_VAULT;1$f83d084a4f9b4fe18a640e40f8e38f66$RN+o0/ZRRgPq3/Nq+9F0/w==\n"
    assert do_unvault(do_vault(data,secret,vaultid),secret,vaultid) == "secret"


# Generated at 2022-06-25 09:11:53.130425
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:06.888514
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:10.686187
# Unit test for function do_unvault
def test_do_unvault():
    value = '$ANSIBLE_VAULT;1.1;AES256'
    secret = 'secrettest'
    vaultid = 'filter_default'
    assert do_unvault(value, secret) == '$ANSIBLE_VAULT;1.1;AES256'


# Generated at 2022-06-25 09:12:17.004414
# Unit test for function do_vault
def test_do_vault():
    salt1 = "abcd"
    salt2 = "1234"
    secret0 = "ssh_pass"
    secret1 = "super_secret"
    secret2 = "ssh_pass"
    data0 = "SSH password for remote user"
    data1 = "SSH password for remote user"
    data2 = "SSH password for remote user"
    vaultid0 = "filter_default"
    vaultid1 = "filter_default"

    res = do_vault(data0, secret0, salt1)

# Generated at 2022-06-25 09:12:21.381196
# Unit test for function do_vault
def test_do_vault():

    data = None
    secret = None
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert result is None


# Generated at 2022-06-25 09:12:30.518519
# Unit test for function do_unvault
def test_do_unvault():
    data = ''
    vaultid = 'test_vaultid'
    secret = 'test_secret'
    vault = 'test_vault'
    returned = do_unvault(vault, secret, vaultid)
    assert returned == data

    secret = 'test_secret'

# Generated at 2022-06-25 09:12:31.511702
# Unit test for function do_unvault
def test_do_unvault():
    pass


# Generated at 2022-06-25 09:12:42.554259
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()
    vault = filter_module_1.filters()['vault']

    # Test 1, normal string
    input_string = 'my secret string'
    secret = 'secret'
    result = vault(input_string, secret)
    display.display(result)
    # Assert
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.data == input_string
    assert result.vault.vault_secrets == [(None, VaultSecret(to_bytes(secret)))]
    assert result.vault.vault_id == 'filter_default'

    # Test 2, with salt
    input_string = 'my secret string'
    secret = 'secret'
    salt = 'salt'
    result = vault(input_string, secret, salt)

# Generated at 2022-06-25 09:12:50.685041
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault1 = "$ANSIBLE_VAULT;1.1;AES256;ansible\n633037653665626631386562626437616232656565643063363631666135633663376464366165323\n663306163353265323538643837306431313434663962366638353762366436306462346337316135\n62380a31393732653963343936666536356636656662373437313834386161373863356162626665\n38373138333137393437646136626263343131363230363537663964616661373861666335336231\n353639\n"
    vault2 = "vaulted"
    res = do_un

# Generated at 2022-06-25 09:12:58.964550
# Unit test for function do_unvault
def test_do_unvault():
    unvault_filter = FilterModule().filters()['unvault']
    assert unvault_filter('$ANSIBLE_VAULT;1.1;AES256;test\n636330626338323761616438363432626565393764343332353366393139653961363464383430\n343364363635376637396361326165383431333661633365346162303934636435663335653239\n363663396236643639\n',
                         'secret',
                         vaultid='test'
                        ) == 'hello'

# Generated at 2022-06-25 09:13:08.533962
# Unit test for function do_unvault
def test_do_unvault():
    secret = "thisisasecret"

    vaultid = "filter_default"

# Generated at 2022-06-25 09:13:14.798517
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('test_secret', 'test_secret') == 'test_secret'



# Generated at 2022-06-25 09:13:17.684171
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(do_vault('Hello', 'World'), 'World') == 'Hello'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:13:24.024682
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = 'test_secret'
    str_2 = '$ANSIBLE_VAULT;1.1;AES256;test_secret00000000000000000000000000000000000000000000000000000000000000000'
    var_1 = do_unvault(str_2, str_1)
    assert var_1 == 'test_secret'



# Generated at 2022-06-25 09:13:27.071066
# Unit test for function do_unvault
def test_do_unvault():
    vault = do_vault('test_secret', 'test_secret')
    data = do_unvault(vault, 'test_secret')
    print(vault)
    print(data)
    assert data == 'test_secret'

# Generated at 2022-06-25 09:13:36.372926
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test_secret'
    data = 'test_data'

    # Create a vault object
    vault_string = do_vault(data, secret)
    vault = AnsibleVaultEncryptedUnicode(vault_string)
    # Assert that the vaulted string is not the same as the data
    assert vault_string != data

    # Decrypt the vault object
    decrypted_data = do_unvault(vault, secret)
    # Assert that decrypted_data matches the original data
    assert decrypted_data == data

# Generated at 2022-06-25 09:13:43.395391
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256;filter_default 63643964656361373565363232336165643530346461303861623033376634393166636564616432636162366537 336466653964376462376261356661353938656466383764663633330656538643635366534333537326438653031 3063366434316561663932333636633346365626162336132313331313634383162623335666134', 'Variable var_0 is not set to correct value'


# Generated at 2022-06-25 09:13:54.222368
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_vault(str_0, str_0, wrap_object=True)
    var_2 = do_vault(str_0, str_0, salt='salt')
    var_3 = do_vault(str_0, str_0, salt='salt', wrap_object=True)
    var_4 = ''
    try:
        do_vault(str_0, str_0, salt=123456)
    except AnsibleFilterTypeError:
        var_4 = 1

    # Print output to catch any errors
    print(var_0)
    print(var_1)
    print(var_2)
    print(var_3)
    print

# Generated at 2022-06-25 09:14:00.114474
# Unit test for function do_vault
def test_do_vault():
    ex1_expected = "vaulted_result"
    ex1_actual = do_vault("test_secret", "test_secret")

    assert ex1_actual == ex1_expected



# Generated at 2022-06-25 09:14:02.570491
# Unit test for function do_unvault
def test_do_unvault():
    do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:14:05.488335
# Unit test for function do_vault
def test_do_vault():
    filter_0 = filter(do_vault)
    assert filter_0 == ''


# Generated at 2022-06-25 09:14:19.223052
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret'
    var_0 = do_unvault(do_vault(str_0, str_0), 'test_secret')
    assert var_0 == str_0



# Generated at 2022-06-25 09:14:23.718700
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'AQAAdlV1lDeBAAAAABseNVdHxmeRcgRIsS9Ssz7E1TtT1w7Vq3s4FQfVuQQxOv3gCY9rZm'
    str_1 = 'test_secret'
    assert do_vault(str_0, str_1) == str_0


# Generated at 2022-06-25 09:14:26.362364
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret_0'
    str_1 = 'test_secret_1'
    var = do_vault(str_0, str_1)

    assert var == do_unvault(var, str_1)

# Generated at 2022-06-25 09:14:35.553370
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault("test", "test"), string_types)

# Generated at 2022-06-25 09:14:37.066549
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:14:48.086707
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 's3cr3t'

# Generated at 2022-06-25 09:14:51.663342
# Unit test for function do_vault
def test_do_vault():
    try:
        assert callable(do_vault)
    except NameError:
        display.warning('Cannot find function do_vault.')
    else:
        assert True


# Generated at 2022-06-25 09:14:57.214874
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    print(var_0)


# Generated at 2022-06-25 09:15:06.846956
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:15.101665
# Unit test for function do_vault
def test_do_vault():
    str1 = 'secret'
    str2 = 'secret'
    data = do_vault(str1, str2)
    assert data == '$ANSIBLE_VAULT;1.1;AES256\n38333563303630376362393531666239643065396438393464303562303630666133653566326631\n643935376462363033386638373863373162366239613066660a3938366361613465323564376333\n63653066343263366236383035376232306632613237323332623431323337383938386338636339\n6630653239643636376430\n'


# Generated at 2022-06-25 09:15:29.779964
# Unit test for function do_vault
def test_do_vault():
    # str_0 = 'test_secret'
    # var_0 = do_vault(str_0, str_0)

    try:
        str_0 = 'test_secret'
        var_0 = do_vault(str_0, str_0)
    except AnsibleFilterError:
        print("Unexpected AnsibleFilterError exception")
    except Exception:
        print("Error: expected AnsibleFilterError")

    try:
        str_0 = 'test_secret'
        var_0 = do_vault(str_0, str_0, 'bogus_salt')
    except AnsibleFilterError:
        print("Unexpected AnsibleFilterError exception")
    except Exception:
        print("Error: expected AnsibleFilterError")


# Generated at 2022-06-25 09:15:31.538615
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret'
    assert do_unvault(do_vault(str_0, str_0), str_0) == str_0

# Unit test

# Generated at 2022-06-25 09:15:33.525135
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault(str_0, str_0), str)



# Generated at 2022-06-25 09:15:36.652099
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert(var_1 == str_0)


# Generated at 2022-06-25 09:15:38.853573
# Unit test for function do_unvault
def test_do_unvault():
    data_0 = do_vault('data_0', 'secret_0')
    assert do_unvault(data_0, 'secret_0') == 'data_0'

# Generated at 2022-06-25 09:15:46.897400
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:50.264731
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;' in do_vault('test_secret', 'test_secret')
    assert 'test_secret' in do_unvault(do_vault('test_secret', 'test_secret'), 'test_secret')


# Generated at 2022-06-25 09:15:51.906404
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0

# Generated at 2022-06-25 09:15:56.689262
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    str_1 = 'test_secret'
    var_0 = do_vault(str_0, str_1)


# Generated at 2022-06-25 09:16:02.552285
# Unit test for function do_vault
def test_do_vault():
    # testing with a string that is in the form of a string
    str_1 = 'test_secret'
    var_1 = do_vault(str_1, str_1)
    assert isinstance(var_1, (str, unicode))
    # testing with a string that is a unicode string
    str_2 = u'test_secret'
    var_2 = do_vault(str_2, str_2)
    assert isinstance(var_2, (str, unicode))
    # testing with a string that is an integer
    str_3 = 1
    var_3 = do_vault(str_3, str_3)
    assert isinstance(var_3, (str, unicode))
    # testing with a string that is an integer
    str_4 = 1.0

# Generated at 2022-06-25 09:16:14.184617
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'secret'
    str_1 = 'secret'
    var_0 = do_vault(str_0, str_1)



# Generated at 2022-06-25 09:16:25.453726
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_secret', 'test_secret') == u'$ANSIBLE_VAULT;1.1;AES256\n6161616161616161616161616161616161616161616161616161616161616161616161616161616161\n6161616161616161616161616161616161616161616161616161616161616161616161616161616161\n6161616161616161616161616161616161616161616161616161616161616161616161616161616161\n61616161616161616161616161661\n'


# Generated at 2022-06-25 09:16:29.574755
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    str_1 = 'test_secret'
    var_0 = do_vault(str_0, str_1)
    assert var_0 is not None
    assert str_1 == str_0


# Generated at 2022-06-25 09:16:31.111610
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)
    return var_0


# Generated at 2022-06-25 09:16:41.908775
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'TEST_SECRET'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:16:51.417204
# Unit test for function do_vault
def test_do_vault():
    # Test whether provided str_0 is of type string_types or not
    assert isinstance(str_0, string_types) == True
    # Test whether provided str_0 is of type string_types or not
    assert isinstance(str_0, string_types) == True

    var_0 = do_vault(str_0, str_0)
    assert var_0 is not None and var_0 != ''

    var_1 = do_unvault(var_0, str_0)
    assert var_1 is not None and var_1 != ''



# Generated at 2022-06-25 09:17:02.131267
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('test_secret', 'test_secret'), string_types) or isinstance(do_vault('test_secret', 'test_secret'), binary_type)
    assert isinstance(do_vault('test_secret', 'test_secret', 'test_salt'), string_types) or isinstance(do_vault('test_secret', 'test_secret', 'test_salt'), binary_type)
    assert isinstance(do_vault('test_secret', 'test_secret', 'test_salt', 'test_vaultid'), string_types) or isinstance(do_vault('test_secret', 'test_secret', 'test_salt', 'test_vaultid'), binary_type)

# Generated at 2022-06-25 09:17:10.069550
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'test_secret'
    var_1 = do_vault(str_1, str_1)
    assert var_1 == '$ANSIBLE_VAULT;1.1;AES256\n6363316637353532666261633530356230353031326539396362386232316533653939643465396131\n3864663763363639643038396233623765643332626564636438653861303139353962366365653566\n36\n'
    str_2 = 'test_secret'
    var_2 = do_vault(str_2, str_2)

# Generated at 2022-06-25 09:17:18.278604
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:17:27.353937
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert type(do_unvault(vault0, secret0)) == str
    except:
        assert type(do_unvault(vault0, secret0)) == unicode
    try:
        assert type(do_unvault(vault0, secret1)) == str
    except:
        assert type(do_unvault(vault0, secret1)) == unicode
    try:
        assert type(do_unvault(vault1, secret0)) == str
    except:
        assert type(do_unvault(vault1, secret0)) == unicode
    try:
        assert type(do_unvault(vault1, secret1)) == str
    except:
        assert type(do_unvault(vault1, secret1)) == unicode

# Generated at 2022-06-25 09:17:45.057741
# Unit test for function do_vault
def test_do_vault():
    # Testing 'str_0', 'str_0'
    str_0 = 'test_secret'
    str_1 = 'test_secret'
    var_0 = do_vault(str_0, str_1)

# Generated at 2022-06-25 09:17:51.236907
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)

    var_1 = do_unvault(var_0, str_0)
    assert var_1 == 'test_secret', 'Test failed: {} != {}!'.format(var_1, 'test_secret')

# Generated at 2022-06-25 09:17:53.923688
# Unit test for function do_vault
def test_do_vault():
    assert test_case_0() == None

# Generated at 2022-06-25 09:18:02.759459
# Unit test for function do_vault
def test_do_vault():

    # Case: 0
    str_0 = 'test_secret'
    exp_var_0 = do_vault(str_0, str_0)
    assert exp_var_0

    # Case: 1
    str_1 = 'test_secret'
    str_2 = 'test_encrypt'
    exp_var_1 = do_vault(str_1, str_2)
    assert exp_var_1

    # Case: 2
    str_1 = 'test_secret'
    exp_var_1 = do_vault(str_1, 'test_encrypt')
    assert exp_var_1

    # Case: 3
    str_1 = 'test_secret'
    exp_var_1 = do_vault(str_1, 'test_encrypt')
    assert exp_var_1

# Generated at 2022-06-25 09:18:13.722861
# Unit test for function do_unvault

# Generated at 2022-06-25 09:18:23.690662
# Unit test for function do_unvault
def test_do_unvault():
    vlt = '$ANSIBLE_VAULT;1.1;AES256'
    sk1 = 'test_secret'
    a = 'AES256'
    b = 25
    c = 22
    d = 'ansible_test'
    e = 'this is a test string'
    f = 'a1d870d8ac3a9f3'
    g = '95b8dcf3f7ba2841eea2b7d747e'
    h = 'c79953c4ec1'
    i = 'e1a23b1400afd7f17a58a2'
    j = '6f8692aef0c6b0a7'
    k = 34
    l = 4
    m = 'aab6c1155a'

# Generated at 2022-06-25 09:18:34.382674
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:18:39.815194
# Unit test for function do_vault
def test_do_vault():
    """Test for `do_vault`
    """
    str_0 = 'test_secret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:18:45.266683
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_secret'
    str_1 = 'some_secret'
    try:
        var_0 = do_vault(str_0, str_1)
        var_1 = do_unvault(var_0, str_1)
    except Exception as e:
        var_1 = None
    assert var_0 != var_1


# Generated at 2022-06-25 09:18:52.130372
# Unit test for function do_vault
def test_do_vault():
    # Call the function with no arguments
    assert do_vault() == AnsibleFilterError

    # Call the function with arguments
    try:
        do_vault(test_case_0,test_case_0)
    except:
        assert False, 'do_vault failed to do what it is supposed to do'


# Generated at 2022-06-25 09:19:08.130299
# Unit test for function do_vault

# Generated at 2022-06-25 09:19:09.184639
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(False) == False

# Generated at 2022-06-25 09:19:19.115371
# Unit test for function do_unvault