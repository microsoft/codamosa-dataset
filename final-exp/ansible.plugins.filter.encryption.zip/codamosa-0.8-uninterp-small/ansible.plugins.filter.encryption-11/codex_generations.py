

# Generated at 2022-06-25 09:09:29.186805
# Unit test for function do_unvault

# Generated at 2022-06-25 09:09:37.439884
# Unit test for function do_vault

# Generated at 2022-06-25 09:09:48.953903
# Unit test for function do_unvault
def test_do_unvault():
    ''' Test do_unvault with dummy text and password '''

# Generated at 2022-06-25 09:09:58.984405
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:07.665729
# Unit test for function do_unvault
def test_do_unvault():
    """ Do unvault Unit-Test """

# Generated at 2022-06-25 09:10:12.465018
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:23.115518
# Unit test for function do_vault
def test_do_vault():
    secret1 = "secret1"
    plain_text1 = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " \
                  "Nulla elementum eros vitae viverra imperdiet. Nulla nec erat dapibus, " \
                  "laoreet nulla vitae, scelerisque tellus. Nunc vitae tortor congue, " \
                  "aliquet purus at, sodales metus. Ut accumsan neque ac augue semper, " \
                  "quis rutrum nibh dignissim."

# Generated at 2022-06-25 09:10:34.867215
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:40.064740
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'this is a secret'
    plain_text = 'this is plain text'
    vault_obj = '!vault |'+filter_module_0.filters()['vault'](plain_text, secret)
    assert filter_module_0.filters()['unvault'](vault_obj, secret) == plain_text

# Generated at 2022-06-25 09:10:43.248020
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == ''


# Generated at 2022-06-25 09:10:52.515992
# Unit test for function do_vault
def test_do_vault():
    str_vault = "ansible-vault encrypt_string ansible"
    str_unvault = "ansible"

    # Test case
    assert str_vault == do_vault(str_unvault, "ansible")


# Generated at 2022-06-25 09:10:55.835007
# Unit test for function do_vault
def test_do_vault():
# Arrange
    dummy_data = 'test_data'
    dummy_secret = 'test_secret'
# Act
    actual = do_vault(dummy_data, dummy_secret)
# Assert
    assert actual != dummy_data


# Generated at 2022-06-25 09:11:06.100711
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1_test = FilterModule()

# Generated at 2022-06-25 09:11:11.664554
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:21.273588
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:11:29.520921
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('a string', 'a string') == '$ANSIBLE_VAULT;1.2;AES256;ansible_default\n63313535363435336132323333656535626538626130396135346239633761656463656538313236\n34653534333862366663356638633862626262333239626330636364396236613962643134613163\nt\n'


# Generated at 2022-06-25 09:11:39.402873
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:51.487838
# Unit test for function do_vault
def test_do_vault():

    # Try to encrypt with wrong type of secret
    test_secret = [1, 2, 3, 4, 5]
    test_data = 'my secret data to encrypt'
    try:
        do_vault(test_data, test_secret)
    except AnsibleFilterTypeError:
        pass
    else:
        raise Exception('Expected AnsibleFilterTypeError but did not get it')

    # Try to encrypt with wrong type of data
    test_secret = 'my secret password'
    test_data = [1, 2, 3, 4, 5]
    try:
        do_vault(test_data, test_secret)
    except AnsibleFilterTypeError:
        pass
    else:
        raise Exception('Expected AnsibleFilterTypeError but did not get it')

    # Encrypt with correct data

# Generated at 2022-06-25 09:11:54.140171
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vault = "vault"
    vaultid = "filter_default"

    do_unvault(vault, secret, vaultid)


# Generated at 2022-06-25 09:12:04.589708
# Unit test for function do_unvault
def test_do_unvault():
    clear_text_0 = 'abc'
    secret_0 = ''
    vaultid_0 = 'filter_default'
    nu_0 = do_unvault(clear_text_0, secret_0, vaultid_0)
    if nu_0 != clear_text_0:
        print('Failed')
        return

    secret_0 = 'secret'
    clear_text_0 = 'abc'
    nu_0 = do_unvault(clear_text_0, secret_0, vaultid_0)
    if nu_0 == clear_text_0:
        print('Failed')
        return

    nu_0 = do_unvault(nu_0, secret_0, vaultid_0)
    if nu_0 != clear_text_0:
        print('Failed')
        return

   

# Generated at 2022-06-25 09:12:14.569236
# Unit test for function do_unvault
def test_do_unvault():

    # Testing with valid inputs
    filter_module_1 = FilterModule()

    # Testing with invalid type for vault
    filter_module_2 = FilterModule()

    # Testing with invalid type for secret
    filter_module_3 = FilterModule()

    # Testing with valid vaultid
    data = "ansible"
    secret = "secret"
    vault = filter_module_1.filters()["vault"](data, secret, "filter_default")
    unvault = filter_module_1.filters()["unvault"](vault, secret, "filter_default")
    assert unvault == "ansible"

    # Testing without vaultid
    vault = filter_module_1.filters()["vault"](data, secret)

# Generated at 2022-06-25 09:12:25.445477
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1 = FilterModule()

    # try to decrypt a message

# Generated at 2022-06-25 09:12:31.552863
# Unit test for function do_vault
def test_do_vault():

    secret = 'secret'
    data = 'data'
    salt = None

    expected_result = u"$ANSIBLE_VAULT;1.2;AES256;filter_default\n32323165333464383035643066613961336563323863666335316531643662353137303564343138\n623131656439363268656361366161343366363539343035620a"
    result = do_vault(data, secret, salt)
    assert result == expected_result



# Generated at 2022-06-25 09:12:33.597483
# Unit test for function do_unvault
def test_do_unvault():
    display.deprecated("Unable to find test case for do_unvault")


# Generated at 2022-06-25 09:12:44.786051
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:57.885346
# Unit test for function do_vault
def test_do_vault():
    # Test: vault a string
    filtered_string = do_vault('this is a test string', 'this is a test secret')
    assert isinstance(filtered_string, string_types)
    assert is_encrypted(filtered_string)

    # Test: attempting to vault something other than a string will fail
    try:
        do_vault(['this', 'is', 'a', 'test', 'list'], 'this is a test secret')
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

    # Test: attempting to vault with something other than a string secret will fail
    try:
        do_vault('this is a test string', ['this', 'is', 'a', 'test', 'list'])
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)

# Generated at 2022-06-25 09:13:05.566129
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n317364343333373736356664623163663437353763313261316534353936666236353332383534\n38336635333866383437663364386132313661\n'


# Generated at 2022-06-25 09:13:16.527404
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:27.127072
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:33.711168
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:41.189395
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'vault_secret'
    assert do_unvault('!vault |$ANSIBLE_VAULT;1.1;AES256;vault_default\n30623431613261326236666332396334373037366532376336363733316532373736656665306235\n396466303763336362393539303130643836346263396230616232663534303800\n', secret) == 'vault_data'


# Generated at 2022-06-25 09:13:50.585567
# Unit test for function do_unvault

# Generated at 2022-06-25 09:14:01.990037
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:05.035497
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test_encrypt', 'test_secret') == "test_encrypt"


# Generated at 2022-06-25 09:14:14.722068
# Unit test for function do_vault
def test_do_vault():
    ok = 'ok'
    vault = do_vault(ok, 'secret')

# Generated at 2022-06-25 09:14:25.056484
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(u'hello world', u'bad password', u'default') == '$ANSIBLE_VAULT;1.1;AES256\n3638373064646533353331366134623339316135656533613863623962356534303735376632316363\n6563653734393734383564633961663566316164633064363039643839366433363564303264396433\n6231396139313231346430386561646536396430636432373638616365386132643562626561666361\n663934653337343562616366653739666334323533\n'


# Generated at 2022-06-25 09:14:32.742727
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("old_password", "old_secret") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          30373431386366633030356638636237316234313331343165366435653334303362386163303862\n          363133323836663861660a3536333439383433356130656233343765633762626432366338636230\n          633036383862393933663161323332323631643960a\n          ".encode()

# Generated at 2022-06-25 09:14:38.891505
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;foo', 'foosecret') == 'foo'
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;foo', 'foosecret', vaultid='test_vaultid') == 'foo'


# Generated at 2022-06-25 09:14:45.329546
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    assert filter_module_0.filters()['vault']("test_value_1", "test_secret_1", "test_salt_1", "test_vaultid_1") == "$ANSIBLE_VAULT;1.1;AES256;test_vaultid_1;test_salt_1;test_iv_1;test_cipher_1"


# Generated at 2022-06-25 09:14:55.124754
# Unit test for function do_unvault
def test_do_unvault():
    with pytest.raises(AnsibleFilterError) as excinfo:
        do_unvault(1, 'blah')
    assert 'instead we got: <class' in str(excinfo.value)

    assert do_unvault('blah', '') == 'blah'
    assert do_unvault(AnsibleVaultEncryptedUnicode('blah'), '') == 'blah'
    assert do_unvault('', 'blah') == ''

    with pytest.raises(AnsibleFilterError) as excinfo:
        do_unvault('', 'blah', 'blah')
    assert 'instead we got: <class' in str(excinfo.value)


# Generated at 2022-06-25 09:14:59.147158
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('This is a dog', 'testing', 'dog')


# Generated at 2022-06-25 09:15:11.517699
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:18.781965
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:24.118589
# Unit test for function do_vault
def test_do_vault():
    secret_0 = filter_module_0.filters()['vault']("text_0", "secret_0", "salt_0")
    secret_1 = filter_module_0.filters()['vault']("text_1", "secret_1", "salt_1")
    assert secret_0 == secret_1


# Generated at 2022-06-25 09:15:29.237660
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n626f6f0a6d656461640a00f88bcec19d2a1a02769f8b0fe039c9a36e02cab6c0\n'


# Generated at 2022-06-25 09:15:31.407219
# Unit test for function do_unvault
def test_do_unvault():
    data = "test"
    secret = "password"
    vaultid = "filter_default"
    assert data == do_unvault(do_vault(data, secret, None, vaultid), secret, vaultid)


# Generated at 2022-06-25 09:15:37.176941
# Unit test for function do_unvault

# Generated at 2022-06-25 09:15:42.592825
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    failed = False
    try:
        data = 'test'
        secret = 'test'
        salt = None
        vaultid = 'filter_default'
        wrap_object = False
        filter_module_0.filters()['vault'](data, secret, salt, vaultid, wrap_object)
    except Exception as e:
        failed = True
    assert(not failed)


# Generated at 2022-06-25 09:15:54.723510
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n' \
             '65396463323964656533373038663739383131336262386335633464376233346662313965393534\n' \
             '6636313962363165353362303834326434353930666634383364636564303737326637333964\n'
    data = 'supersecure'
    salt = '0123456789ABCDEF'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-25 09:16:01.091483
# Unit test for function do_vault
def test_do_vault():
    # Create an instance of a module used to generate filter methods
    filter_module = FilterModule()

    # Create a result set of filter methods from the filter module
    filter_methods = filter_module.filters()

    # Test that the count of filter methods returned matches the number we expect to generate
    assert len(filter_methods) == 2, "The filter module did not return the expected number of filters"

    # Test that the result set contains the `vault`
    assert 'vault' in filter_methods, "The filter module did not return the `vault` filter"

    # Test the vault filter from the result set
    test_vault_value = filter_methods['vault']('test_vault_value', 'test_secret')

# Generated at 2022-06-25 09:16:11.030164
# Unit test for function do_vault

# Generated at 2022-06-25 09:16:17.696336
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data='foo', secret='bar', salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-25 09:16:29.221543
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("this is a secret", "password") == b"$ANSIBLE_VAULT;1.1;AES256\n393938643063643165333238633736363062646533373630643138373533646366366637303135\n643135383135303631313962326136643635363534666639343832333366633033626238623361\n343463346361656531363932643534306465303964366561306362616662363136646237336230\n363037353763626638353834353339303032646365323238623766323235313733\n"


# Generated at 2022-06-25 09:16:40.726300
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

    secret = 'test_secret'
    input_string = 'test_input_string'
    wrap_object = True
    filter_func = filter_module_0.filters().get('vault')

    ret = filter_func(input_string, secret, wrap_object=wrap_object)

# Generated at 2022-06-25 09:16:43.691282
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('Test data', 'secret', salt='123456')
    # Check vault length
    assert len(vault) == 41
    # Check vault is string
    assert isinstance(vault, str)
    # Check vault is encrypted
    assert is_encrypted(vault)


# Generated at 2022-06-25 09:16:53.125363
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:17:01.667313
# Unit test for function do_vault
def test_do_vault():
    print("Testing function do_vault")
    secret = "test_secret"
    data = "test_data"

    result = do_vault(data, secret)
    assert(result == "vault|$ANSIBLE_VAULT;1.1;AES256;filter_default\r\n3536393962636565333831643834383762353165313736666463353936666161323737616265\r\n61366234313766356534376361656539363765663865366366320a6565303634316135333260\r\n\r\n")


# Generated at 2022-06-25 09:17:04.139525
# Unit test for function do_unvault
def test_do_unvault():
    vault_str_0 = "hello"
    secret_str_0 = "to_native"

    assert do_unvault(vault_str_0, secret_str_0) == "hello"



# Generated at 2022-06-25 09:17:15.626772
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()

# Generated at 2022-06-25 09:17:26.447175
# Unit test for function do_vault
def test_do_vault():
    data = "test"
    secret = "dGVzdA=="
    actual_result = do_vault(data, secret)

# Generated at 2022-06-25 09:17:44.306191
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:55.309779
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

    assert filter_module_0.filters().get('vault')('1234', 'secret', None, None, False) == "ENC[Vault][0]:0f4d72d02f4e25ba:f0cf4e0754f1409bf2c556322e4278f6:\n"
    assert filter_module_0.filters().get('vault')('hello', 'secret', 'salt', None, False) == "ENC[Vault][0]:57f263d9edb9d1ab:bd7127bf194b2a8a9911819f2abbc950:\n"

# Generated at 2022-06-25 09:18:06.509853
# Unit test for function do_vault
def test_do_vault():
    print("TEST: function do_vault")
    filter_module = FilterModule()
    filters = filter_module.filters()
    test_data = {
        'secret': "password",
        'salt': "salt",
        'vaultid': "vaultid",
        'wrap_object': True
    }

    print("TEST: function do_vault: test_data: %s\n" % test_data)
    result = filters.get('vault')("data", test_data['secret'], test_data['salt'], test_data['vaultid'], test_data['wrap_object'])
    print("TEST: function do_vault: result: %s\n" % result)
    assert result

    # Testing 'wrap_object'

# Generated at 2022-06-25 09:18:09.698912
# Unit test for function do_vault
def test_do_vault():
    # No arguments passed to function
    display.display(do_vault(data='test_data', secret='test_secret', salt='test_salt', vaultid='test_vaultid', wrap_object=True))


# Generated at 2022-06-25 09:18:16.101027
# Unit test for function do_vault

# Generated at 2022-06-25 09:18:24.223237
# Unit test for function do_vault
def test_do_vault():
    test_input_data = 'do_vault'
    test_input_secret = 'dasda'
    test_input_salt = None
    test_input_vaultid = 'filter_default'
    test_input_wrap_object = False

# Generated at 2022-06-25 09:18:32.422447
# Unit test for function do_vault
def test_do_vault():
    v = do_vault('test', 'test')
    assert v == '$ANSIBLE_VAULT;1.1;AES256\n396339323162626661323666366364333233656239633139303635383561623863613961316436\n303339346639316166623337303737366332646162663861343736653837666565323030373466\n656637363033\n', "Vault string is not what is expected"


# Generated at 2022-06-25 09:18:43.234540
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256;test', secret="test") == 'test'
    with pytest.raises(AnsibleFilterTypeError, match=r".*Vault should be in the form of a string.*"):
        do_unvault(vault=[], secret="test")
    with pytest.raises(AnsibleFilterTypeError, match=r".*Secret passed is required to be as string.*"):
        do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256;test', secret=[])

# Generated at 2022-06-25 09:18:51.947758
# Unit test for function do_unvault

# Generated at 2022-06-25 09:19:03.633451
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:19:13.026586
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('MySecretPassword', 'MySecretPassword'), str)


# Generated at 2022-06-25 09:19:19.686864
# Unit test for function do_vault
def test_do_vault():

    vaulted_data = do_vault('plain_text_to_vault', 'secret')
    data = do_unvault(vaulted_data, 'secret')

    assert data == 'plain_text_to_vault'

if __name__ == '__main__':
    test_case_0()
    test_do_vault()