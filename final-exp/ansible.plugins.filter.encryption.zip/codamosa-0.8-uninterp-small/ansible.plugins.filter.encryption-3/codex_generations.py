

# Generated at 2022-06-25 09:09:32.494649
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None, None, None, None) is not None
    assert do_vault('', '', '', '', '') is not None
    assert do_vault(None, '', '', '', None) is not None
    assert do_vault('', '', None, None, False) is not None
    assert do_vault(None, None, None, '', False) is not None
    assert do_vault('', '', '', '', False) is not None
    assert do_vault(None, '', '', '', False) is not None
    assert do_vault('', '', None, None, False) is not None
    assert do_vault(None, None, None, '', False) is not None

# Generated at 2022-06-25 09:09:42.334450
# Unit test for function do_vault

# Generated at 2022-06-25 09:09:44.228198
# Unit test for function do_vault
def test_do_vault():
    # init
    data = None
    secret = None
    salt = None
    vaultid = None
    wrap_object = None

    # assert



# Generated at 2022-06-25 09:09:52.648708
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()

    # encrypt_string = filter_module_0.filters()['vault'](data="abc", secret="mysecret")
    # assert encrypt_string == "$ANSIBLE_VAULT;1.1;AES256\n3265343462326661613536663262643730356239316133353830353364353465643836656439653666\n396565666264663162316464316161333463386362396165380a666433306636343666383539636337\n6465616362613432656436363764653338646539623162623134393334666437373935326363313761\n30343830623431383530\n"

   

# Generated at 2022-06-25 09:09:54.264276
# Unit test for function do_unvault
def test_do_unvault():
    pass



# Generated at 2022-06-25 09:10:04.743155
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:10.193069
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;blah;blah;blah==','passw0rd') == 'blah'

# Generated at 2022-06-25 09:10:16.755788
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()

    # Pass
    try:
        result = do_vault(data='This is vault', secret='Changeit')
        assert result[0] == '$ANSIBLE_VAULT;1.1;AES256'
    except AnsibleFilterError as e:
        pass
    except AnsibleVaultEncryptedUnicode as v:
        pass

    # Pass
    try:
        result = do_vault(data='This is vault', secret='Changeit', wrap_object=True)
        assert isinstance(result, AnsibleVaultEncryptedUnicode)
    except AnsibleFilterError as e:
        pass
    except AnsibleVaultEncryptedUnicode as v:
        pass

    # Fail

# Generated at 2022-06-25 09:10:25.167778
# Unit test for function do_unvault
def test_do_unvault():
    # Setup
    filter_module = FilterModule()

# Generated at 2022-06-25 09:10:35.044878
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:41.540647
# Unit test for function do_unvault
def test_do_unvault():
    var_0 = do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n', 'my_password')
    assert var_0 == 'hello world'


# Generated at 2022-06-25 09:10:42.153061
# Unit test for function do_unvault
def test_do_unvault():
    pass


# Generated at 2022-06-25 09:10:42.533141
# Unit test for function do_unvault
def test_do_unvault():
    pass

# Generated at 2022-06-25 09:10:51.166766
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:01.291582
# Unit test for function do_unvault
def test_do_unvault():
    #Test the function on a string that is not encrypted
    string = 'This is a test string'
    secret = 'secret'
    vaultid = 'abc123'
    a = do_unvault(string, secret, vaultid)
    assert a == 'This is a test string'
    #Test the function on a string that is encrypted
    secret = 'secret'
    string = do_vault('This is a test string', secret)
    vaultid = 'abc123'
    b = do_unvault(string, secret, vaultid)
    assert b == 'This is a test string'
    # Test the function on a string that is encrypted but with a invalid secret
    secret = 'invalid'
    string = do_vault('This is a test string', secret)
    vaultid = 'abc123'

# Generated at 2022-06-25 09:11:09.867914
# Unit test for function do_unvault
def test_do_unvault():
    '''
    Test for the do_unvault function
    '''
    # Test for integer
    data = 1
    secret = 'test'
    assert do_unvault(data, secret) == 1
    # Test for string
    data = 'test'
    secret = 'test'
    assert do_unvault(data, secret) == 'test'
    # Test for unencrypt string
    data = 'test'
    secret = 'test'
    vaultid = 'filter_default'
    result = do_unvault(data, secret, vaultid)
    vault = do_vault(data, secret, vaultid)
    assert result == vault
    # Test for decrypt string
    data = 'test'
    secret = 'test'
    vaultid = 'filter_default'
    vault = do_vault

# Generated at 2022-06-25 09:11:21.053966
# Unit test for function do_unvault
def test_do_unvault():
    secret = "killer_whale"

# Generated at 2022-06-25 09:11:29.204968
# Unit test for function do_unvault
def test_do_unvault():
    # Test the returned value of function do_unvault
    filter_module = FilterModule()
    data = u'The quick brown fox jumped over the lazy dog.'
    secret = u'secret'
    vaultid = u'filter_default'

    result = do_unvault(vault, secret, vaultid)
    filtered_data = u'The quick brown fox jumped over the lazy dog.'
    assert result == filtered_data



# Generated at 2022-06-25 09:11:39.477444
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:51.494957
# Unit test for function do_unvault
def test_do_unvault():

    # Data has been decrypted
    assert do_unvault(' - test', '$ANSIBLE_VAULT;1.1;AES256;foo\n'
                                 '34343232326532323165323231653232316532323165323231653232316532\n'
                                 '323232323232323232323232323232323232323232323232323232323232323', 'filter_default') == ' - test'

    # Data has been decrypted

# Generated at 2022-06-25 09:12:00.712941
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(filter_input_0, filter_input_3, filter_input_2) == filter_expected_0
    assert do_unvault(filter_input_1, filter_input_3, filter_input_2) == filter_expected_1
    assert do_unvault(filter_input_4, filter_input_3, filter_input_2) == filter_expected_2
    assert do_unvault(filter_input_0, filter_input_3) == filter_expected_3



# Generated at 2022-06-25 09:12:01.549121
# Unit test for function do_vault
def test_do_vault():
    pass


# Generated at 2022-06-25 09:12:06.654562
# Unit test for function do_vault
def test_do_vault():
    test_var = "test_val"
    assert do_vault("test_val",Secret("test_val")) == test_var


# Generated at 2022-06-25 09:12:14.858235
# Unit test for function do_vault
def test_do_vault():
    data = 'string'
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-25 09:12:19.205247
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    assert filter_module_0 != None

    var_0 = do_unvault(b'Encrypted text', 'secret')
    assert var_0 == b'Encrypted text'


# Generated at 2022-06-25 09:12:25.961214
# Unit test for function do_unvault
def test_do_unvault():
    var_0 = 'The quick brown fox jumps over the lazy dog'
    var_1 = 'secret'
    var_2 = 'filter_default'
    var_3 = do_vault(var_0, var_1, None, var_2)

# Generated at 2022-06-25 09:12:31.771133
# Unit test for function do_vault
def test_do_vault():
    data = "TEST_DATA"
    secret = "TEST_SECRET"
    salt = None
    vaultid = "filter_default"
    wrap_object = False

# Generated at 2022-06-25 09:12:37.103190
# Unit test for function do_vault
def test_do_vault():
    secret_secret = string_types()
    vault_secret = string_types()
    salt_secret = string_types()
    vaultid_secret = string_types()
    wrap_object_secret = string_types()
    ansible_vinstall_var_0 = do_vault(vault_secret, secret_secret, salt_secret, vaultid_secret, wrap_object_secret)


# Generated at 2022-06-25 09:12:47.680456
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:52.725288
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    var_0 = filter_filters()
    var_1 = do_unvault(data='vault ansible')
    assert var_1 is not None



# Generated at 2022-06-25 09:12:55.576336
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('hello', 'my secret', 'my salt', 'my vaultid') != None


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 09:13:02.424957
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:03.455025
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == None
    assert do_vault('test string', 'test string') == None


# Generated at 2022-06-25 09:13:12.814916
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    var_0 = filter_filters()
    var_0_0 = var_0['vault']

    # Case for valid data, with correct secret
    var_1 = var_0_0('test', 'test')

# Generated at 2022-06-25 09:13:22.495175
# Unit test for function do_unvault
def test_do_unvault():
    var_0 = do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n303464323230356431396331623236356434333865653466353861366132656530326430653361\n343530333461326261653534313835346530343339366136633263343562396334656333626535\n353100000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n00000000000000000000000000000000000000000000000000000000000000000000000000000000\n000000000000000000000000000000000000000000000000000000000000000000000000\n', 'this is my password', 'filter_default')

# Generated at 2022-06-25 09:13:32.356906
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:40.185031
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    var_0 = filter_filters()
    var_0 = {}
    var_1 = {}
    var_1['vault'] = 'vault_0'
    var_1['secret'] = 'secret_0'
    var_1['vaultid'] = 'vaultid_0'
    var_2 = {}
    var_2['vault'] = 'vault_1'
    var_2['secret'] = 'secret_1'
    var_2['vaultid'] = 'vaultid_1'
    var_2 = {}
    var_2 = var_var_0.get('vault')
    var_0['vault'] = var_2
    var_3 = 'vaultid_0'
    var_0['secret'] = var_

# Generated at 2022-06-25 09:13:40.912731
# Unit test for function do_vault
def test_do_vault():
  test_case_0()



# Generated at 2022-06-25 09:13:46.323809
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('secret', 'val') == 'val'
    assert do_unvault('secret', '$ANSIBLE_VAULT;1.1;AES256', 'filter_default') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_unvault('secret', '$ANSIBLE_VAULT;1.1;AES256', 'filter_default') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_unvault('secret', '$ANSIBLE_VAULT;1.1;AES256', 'filter_default') == '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-25 09:13:47.627470
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1 = FilterModule()
    var_1 = filter_filters()


# Generated at 2022-06-25 09:13:56.890782
# Unit test for function do_vault
def test_do_vault():
    var_0 = do_vault('foobar', 'ansible')
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:14:05.594652
# Unit test for function do_unvault
def test_do_unvault():
    """
    Unit test for function do_unvault
    """

# Generated at 2022-06-25 09:14:11.987838
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'ansible'
    str_2 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_1 = do_unvault(str_2, str_1)
    str_3 = 'ansible'
    var_2 = do_vault(var_1, str_3)
    assert var_2 == str_2


# Generated at 2022-06-25 09:14:20.213463
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)

    if var_0 != 'test':
        raise RuntimeError("do_unvault did not perform as expected")



# Generated at 2022-06-25 09:14:30.512582
# Unit test for function do_unvault
def test_do_unvault():
    assert callable(do_unvault)

# Generated at 2022-06-25 09:14:36.079924
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)
    assert type(var_0) == str

# Generated at 2022-06-25 09:14:46.174858
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)
    var_1 = do_vault(var_0, var_0)


# Generated at 2022-06-25 09:14:47.732415
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None, None) == ''


# Generated at 2022-06-25 09:14:55.123718
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:15:04.819382
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n3866343533303632343466396264396336326162393537616431393736646166336636343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 09:15:17.853553
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:15:29.503889
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:15:39.543546
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)
    str_1 = 'kVu2m4mB7VuKbXrZrByKZ1'
    var_1 = do_unvault(str_1, str_1)

# Generated at 2022-06-25 09:15:47.773560
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;1.0;AES256;ansible\n3735633365353964306263353263363732303164663638373464333439643734373061623239\n393938346339623635653339346563666131363466343262366264623035396134\n'
    var_0 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:15:49.407950
# Unit test for function do_vault
def test_do_vault():
    test_case_0()



# Generated at 2022-06-25 09:15:50.264877
# Unit test for function do_vault
def test_do_vault():


  pass


# Generated at 2022-06-25 09:15:51.059461
# Unit test for function do_vault
def test_do_vault():
    assert 0 == do_vault


# Generated at 2022-06-25 09:15:57.680572
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

    try:
        str_1 = do_unvault(str_0, str_0)
    except Exception as e:
        print('Exception: ', e)


# Generated at 2022-06-25 09:16:02.653623
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("default_secret", "default_secret", "default_salt", "filter_default") == u'$ANSIBLE_VAULT;1.1;AES256;filter_default\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:16:08.663898
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('test', 'secret')

# Generated at 2022-06-25 09:16:18.071307
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_0) == '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:16:28.046560
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)



# Generated at 2022-06-25 09:16:29.409261
# Unit test for function do_vault
def test_do_vault():
    msg_0 = test_case_0()


# Generated at 2022-06-25 09:16:40.535625
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:16:46.166176
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0


# Generated at 2022-06-25 09:16:49.110622
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'asdf'

    var_0 = do_vault(str_0, str_0)

    assert var_0 == str_0



# Generated at 2022-06-25 09:16:57.607196
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('data', 'secret') == '$ANSIBLE_AULT;1.1;AES256;ansible\n383938396334366465303533343631623034326563636161313432303165373739623963333366\n6373623834353065626565376562623734396161366231636336633939366364376539$653734\n376635376462396534336634383132316138363339366463\n'


# Generated at 2022-06-25 09:17:06.529715
# Unit test for function do_unvault
def test_do_unvault():
    # see https://docs.python.org/3/library/unittest.html
    assert do_unvault(do_vault('ordinary_string', 'ordinary_secret'), 'ordinary_secret') == 'ordinary_string'
    assert do_unvault(do_vault('ordinary_string', 'ordinary_secret'), 'ordinary_secret') == 'ordinary_string'

    # test cases with data vaulted by ansible-vault

# Generated at 2022-06-25 09:17:12.862905
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:17:19.525796
# Unit test for function do_vault
def test_do_vault():
    # noinspection PyShadowingNames
    def do_vault_mock(self, data, secret, salt=None, vaultid='filter_default', wrap_object=False):
        if not isinstance(secret, (string_types, binary_type, Undefined)):
            raise AnsibleFilterTypeError("Secret passed is required to be a string, instead we got: %s" % type(secret))
        if not isinstance(data, (string_types, binary_type, Undefined)):
            raise AnsibleFilterTypeError("Filter can only be applied to strings, input was: %s" % type(data))
        vault = ''
        vs = VaultSecret(to_bytes(secret))
        vl = VaultLib()

# Generated at 2022-06-25 09:17:30.442268
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:17:31.289407
# Unit test for function do_vault
def test_do_vault():
    assert do_vault() == '###'


# Generated at 2022-06-25 09:17:32.645468
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault(str_0, str_0)) == str


# Generated at 2022-06-25 09:17:39.590039
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:17:50.284582
# Unit test for function do_vault
def test_do_vault():
    assert str == type(do_vault(str_0, str_0))
    assert str_0 == do_vault(str_0, str_0)
    assert str == type(do_vault(str_1, str_8))
    assert str_9 == do_vault(str_1, str_8)
    assert str == type(do_vault(str_3, str_1))
    assert str_10 == do_vault(str_3, str_1)
    assert str == type(do_vault(str_1, str_8))
    assert str_9 == do_vault(str_1, str_8)
    assert str == type(do_vault(str_3, str_1))
    assert str_10 == do_vault(str_3, str_1)

# Generated at 2022-06-25 09:18:02.051801
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)

if __name__ == "__main__":
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:18:11.954024
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:18:22.408608
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0

test_case_0()


# Generated at 2022-06-25 09:18:32.769309
# Unit test for function do_unvault
def test_do_unvault():
    str_arg_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:18:38.899133
# Unit test for function do_unvault

# Generated at 2022-06-25 09:18:50.193382
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'

# Generated at 2022-06-25 09:18:56.517794
# Unit test for function do_unvault
def test_do_unvault():
    # str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    # var_0 = do_vault(str_0, str_0)
    # var_1 = do_unvault(var_0, var_0)
    # assert var_1 == str_0
    pass



# Generated at 2022-06-25 09:19:06.769133
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n313838363132333162366666334626266636532353261646336666463665306537313162343034\n3730373134393733373836383336353736616266373161636232613530663231323633363461\n6336326262363531623562393835346565666135613261393139616331373664356335636335\n326635666436303964333539633233383561303164386438653633$383766393939623134\n66313033653836656463663438613231326131616533356633\n'


# Generated at 2022-06-25 09:19:11.783306
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '$ANSIBLE_VAULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:19:19.556612
# Unit test for function do_vault
def test_do_vault():
    str_0 = '$ANSIBLE_AULT;1.1;AES256;ansible\n333663643839326431386231666331386134616339663435643739623438313531653639353364\n38663435333036323434663962643963363261623935376164313937366461663366$6343961\n333532646161343131666137336663623863303936383661\n'
    var_0 = do_vault(str_0, str_0)
    assert str_0 == var_0


# Generated at 2022-06-25 09:19:29.276969
# Unit test for function do_vault
def test_do_vault():
    str0 = "test_value"
    str1 = "test_secret"
    str2 = "test_salt"
    str3 = "test_vaultid"
    str4 = "test_wrap_object"
    str5 = "test_data"
    str6 = "test_vault"
    str7 = "test_secret"
    str8 = "test_vaultid"
    var_0 = "test_value"
    var_1 = "test_secret"
    var_2 = "test_salt"
    var_3 = "test_vaultid"
    var_4 = "test_wrap_object"
    var_5 = "test_data"
    var_6 = "test_vault"
    var_7 = "test_secret"