

# Generated at 2022-06-25 09:09:36.507786
# Unit test for function do_vault
def test_do_vault():
    try:
        res = filter_module_0.filters()['vault'](
            "unencrypted content", "password", "my salt")
        assert res == "!$ANSIBLE_VAULT;1.1;AES256\n353138396566326235643065343635343134636334366431623961666535376133313262363466\n33663163626535326234633264613162653430316562323965336261326263663264306433323634\n6133643936653730316166353966663730376532363532303839\n", "Unable to apply filter"
    except AnsibleFilterError as e:
        assert False, "AnsibleFilterError calling filter"

# Generated at 2022-06-25 09:09:48.117686
# Unit test for function do_vault
def test_do_vault():
    print("Testing do_vault")
    vault_obj = FilterModule()
    vault_pass_secret = 'testsecret'
    test_vault_val = 'testval'
    test_vault1_val = do_vault(test_vault_val, vault_pass_secret, wrap_object=True)
    print("Vaulted Value1 = " + str(test_vault1_val))
    test_unvault_val = do_unvault(test_vault1_val, vault_pass_secret)
    print("Unvaulted Value1 = " + str(test_unvault_val))

    test_vault2_val = do_vault(test_vault_val, vault_pass_secret)

# Generated at 2022-06-25 09:09:56.290992
# Unit test for function do_vault
def test_do_vault():
    data, secret, salt, vaultid, wrap_object = "abcd", "my_secret", None, 'filter_default', False

# Generated at 2022-06-25 09:10:01.490452
# Unit test for function do_unvault
def test_do_unvault():
    cases = []
    test_cases = []
    for case in cases:
        test_cases.append(case)



# Generated at 2022-06-25 09:10:03.076324
# Unit test for function do_vault
def test_do_vault():
    test_val_0 = do_vault('', '')


# Generated at 2022-06-25 09:10:05.893031
# Unit test for function do_vault
def test_do_vault():
    secret = "hello"
    data = "world"

    do_vault(data, secret)


# Generated at 2022-06-25 09:10:13.080377
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert do_unvault("AQDmfFa1Wr3q3v8kBWb0ZDWIKBZVHxCxvj8IcgEBdG42rVb9XAogAQDr7QBAYQC", "test", "filter_default") == "secret"
    except Exception as e:
        msg = f"test_do_unvault => {str(e)}"
        display.error(msg)
        raise


# Generated at 2022-06-25 09:10:15.000469
# Unit test for function do_unvault
def test_do_unvault():
    with pytest.raises(AnsibleFilterError) as e:
        res = do_unvault('', 'password')
        assert res == ''
    assert 'Unable to decrypt' in str(e.value)


# Generated at 2022-06-25 09:10:24.133964
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:29.012286
# Unit test for function do_vault
def test_do_vault():
    try:
        assert do_vault(data, secret) == AnsibleVaultEncryptedUnicode(actual_output)
    except:
        print("Exception:", sys.exc_info()[0])
        raise


# Generated at 2022-06-25 09:10:36.930059
# Unit test for function do_vault
def test_do_vault():
    vault_plaintext = 'SECRET_VAULT'
    vault_secret = 'SECRET_PASSWORD'
    vault_salt = 'SECRET_SALT'

# Generated at 2022-06-25 09:10:42.900741
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault(
        '$ANSIBLE_VAULT;1.1;AES256\n62363335363239393037643735363935366537646164313138303834336637643763326564363330\n39353665363338353734653661373365346264663338326232646166663233633535396536333461\n65636436653938636632643538366536646266363966353764333039000000000000000000000000\n0000000000000000000000000001',
        'DK0mHx50QjKmJ0rZ',
        'filter_default'
    )

    assert result == 'abcdefghijklmnopqrstuvwxyz'


# Generated at 2022-06-25 09:10:46.940893
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data='123456', secret='password', wrap_object=False) == b'$ANSIBLE_VAULT;1.1;AES256\n32323563633162326665396537336666376534336330376265666162666230383136623939616262\n65323563353731643033386433316236663339613337616238643861613030663163336164326232\n3664663163653164\n'
    assert do_vault(data='123456', secret='password', wrap_object=True).__class__.__name__ == 'AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-25 09:10:56.769587
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_0 = FilterModule()
    secret = 'this is the secret'

# Generated at 2022-06-25 09:11:03.947005
# Unit test for function do_unvault
def test_do_unvault():
    from os import urandom

    filter_module_0 = FilterModule()
    test_data = urandom(128).decode('utf-8')
    test_salt = urandom(128).decode('utf-8')
    test_secret = urandom(128).decode('utf-8')

    test_vault = filter_module_0.filters()['vault'](test_data, test_secret, test_salt)

    assert filter_module_0.filters()['unvault'](test_vault, test_secret) == test_data


# Generated at 2022-06-25 09:11:09.533079
# Unit test for function do_vault
def test_do_vault():
    secret = "ansible"
    data = "ibm"

# Generated at 2022-06-25 09:11:16.520827
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    data = 'test'
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert type(vault) is str


# Generated at 2022-06-25 09:11:26.795088
# Unit test for function do_vault
def test_do_vault():

    # Setup a correct call
    data = 'Test value to be encrypted'
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-25 09:11:31.533441
# Unit test for function do_unvault
def test_do_unvault():
    # Test with a valid vault string
    secret_0 = 'secret'

# Generated at 2022-06-25 09:11:36.294220
# Unit test for function do_unvault
def test_do_unvault():
    string_0 = "xxxx"
    string_1 = "xxxx"
    string_2 = "xxxx"

    try:
        assert to_native(do_unvault(string_0, string_1, string_2)) == "xxxx"
    except AssertionError:
        print("Unable to decrypt: Bad padding")



# Generated at 2022-06-25 09:11:45.895686
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;foo\n313233343536373839306162636465663132333435363738393061626364656630\n", "ansible", "filter_default") == "1234567890123456789012345678901234567890"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;default\n306537336236326464633962616662376332366533386561643537393437626363\n", "ansible", "filter_default") == "fearless"

# Generated at 2022-06-25 09:11:55.078243
# Unit test for function do_vault
def test_do_vault():
    function_inputs = [
        {
            "data" : "This is a secret",
            "secret" : "my_secret"
        },
        {
            "data" : "This is another secret",
            "secret" : "my_other_secret",
            "salt" : "salt"
        }
    ]


# Generated at 2022-06-25 09:11:58.472184
# Unit test for function do_vault
def test_do_vault():
    data_0 = 'test_data'
    secret_0 = 'test_secret'
    test_result_0 = do_vault(data_0, secret_0)
    display.display(test_result_0)


# Generated at 2022-06-25 09:12:02.223621
# Unit test for function do_vault
def test_do_vault():
    data="abc123"
    secret="password123"
    salt="salt"
    vaultid="test"
    wrap_object=True
    assert do_vault(data, secret, salt, vaultid, wrap_object) is not None


# Generated at 2022-06-25 09:12:14.026245
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:25.403021
# Unit test for function do_vault
def test_do_vault():
    # testing 'secret' parameter of type string
    try:
        do_vault("testing string parameter", "string type")
    except Exception as e:
        print("Error while testing 'secret' parameter: " + str(e))

    # testing 'data' parameter of type string
    try:
        do_vault("string type", "testing string parameter")
    except Exception as e:
        print("Error while testing 'data' parameter: " + str(e))

    # testing 'salt' parameter of type string
    try:
        do_vault("testing string parameter", "string type", salt="string type")
    except Exception as e:
        print("Error while testing 'salt' parameter: " + str(e))

    # testing 'vaultid' parameter of type string

# Generated at 2022-06-25 09:12:33.470371
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n663632393539313934323132363338343633333935346561633238316630316262623735306636\n663365316233363062326234613639386130313164323339650a30333531316233666234316464\n323232613163323239666464313638333835666434306664656566643233343734656530373337\n39333863646639376263330a313466616232386134656464656630326266393538343062643530\n'


# Generated at 2022-06-25 09:12:44.637099
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == ''

# Generated at 2022-06-25 09:12:57.884529
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) is None
    assert do_unvault(None, None, None) is None
    assert do_unvault(None, '', None) is None
    assert do_unvault('', '', None) is ''
    assert do_unvault('', '', None, None) is ''
    assert do_unvault(None, '') is None
    assert do_unvault('', '') is ''

    assert type(do_unvault(None, '')) is unicode
    assert type(do_unvault(None, '')) is unicode
    assert type(do_unvault(None, '')) is unicode
    assert type(do_unvault(None, '')) is unicode

# Generated at 2022-06-25 09:13:01.948374
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    test_0 = filter_module_0.filters()['vault']('ansible', 'ansible')

# Generated at 2022-06-25 09:13:12.926142
# Unit test for function do_vault
def test_do_vault():
    # Test string
    data='My data'
    # Test secret
    secret='ansible_vault_password'
    # Test salt
    salt=None
    # Test vaultid
    vaultid='filter_default'
    # Test wrap_object
    wrap_object=False

    # Test vault encoding

# Generated at 2022-06-25 09:13:15.428779
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("testing", "password") == "!vault"


# Generated at 2022-06-25 09:13:17.471141
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    assert filter_module_0


# Generated at 2022-06-25 09:13:27.150939
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    data_0 = 'data'
    secret_0 = 'secret'
    salt_0 = 'salt'
    vaultid_0 = 'filter_default'
    wrap_object_0 = False

# Generated at 2022-06-25 09:13:33.750761
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("testing", "pass", vaultid='filter_default', wrap_object=False) == "$ANSIBLE_VAULT;1.2;AES256;filter_default\n35336466343761646635306466306564653530393465376234616632613261333563313939633166\n32636432336264623934623164626633356537343331326539306131646233356239316362666330\n66353037656235613033383438346261356166643933373031333065326530663230386634643732\n353737623339363737\n"


# Generated at 2022-06-25 09:13:41.189494
# Unit test for function do_vault
def test_do_vault():
     vault_0 = do_vault('This is a secret string', 'myvaultsecret', wrap_object=False)
     assert (vault_0) == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63633166626262386334323862313737363139383360386135613761643430616436356332376365\n          62666634303163363935636135613761363261633466653634663561373035363830323432633332\n          62653430653961306465363938663865373962363936313062623036393765663338396463363437\n          34373039373066\n          "


# Generated at 2022-06-25 09:13:51.823779
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('Hello', 'pass'), str)
    assert isinstance(do_vault('Hello', 'pass', 'test_filter'), str)
    assert isinstance(do_vault('Hello', 'pass', 'test_filter', 'test_vaultid'), str)
    assert isinstance(do_vault('Hello', 'pass', 'test_filter', 'test_vaultid', True), str)
    assert isinstance(do_vault('Hello', 'pass', 'test_filter', wrap_object=True), str)
    assert isinstance(do_vault('Hello', 'pass', wrap_object=True), str)
    assert isinstance(do_vault(None, 'pass', wrap_object=True), str)


# Generated at 2022-06-25 09:13:57.015909
# Unit test for function do_vault
def test_do_vault():
    x = "test_case_0"
    y = "test_case_1"
    z = "test_case_2"
    a = "test_case_3"
    b = "test_case_4"
    c = "test_case_5"
    d = "test_case_6"


# Generated at 2022-06-25 09:13:58.478833
# Unit test for function do_vault
def test_do_vault():
    assert True


# Generated at 2022-06-25 09:14:06.127941
# Unit test for function do_unvault

# Generated at 2022-06-25 09:14:15.360384
# Unit test for function do_vault
def test_do_vault():
    secret = '$6$rounds=4096'
    str_0 = 'Telegram Admin password: $6$rounds=4096$VUJy6cX7VUccYItJ$KjGzWOc8pw1CkJ1CVrOjKWb9EeB0H4A4lb4YaYsQZQsMZjS'
    var_0 = do_vault(str_0, secret, wrap_object=True)
    var_1 = do_unvault(var_0, secret)


# Generated at 2022-06-25 09:14:25.531410
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('', '') == ''
    assert isinstance(do_vault('', ''), str)
    assert do_vault('', '', salt='', vaultid='filter_default', wrap_object=False) == ''
    assert isinstance(do_vault('', '', salt='', vaultid='filter_default', wrap_object=False), str)
    assert do_vault('', '', salt='', vaultid='filter_default', wrap_object=True) == ''
    assert isinstance(do_vault('', '', salt='', vaultid='filter_default', wrap_object=True), str)
    assert do_vault('', '', wrap_object=False) == ''
    assert isinstance(do_vault('', '', wrap_object=False), str)

# Generated at 2022-06-25 09:14:32.826528
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0)

    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(str_0)
    assert isinstance(ansible_vault_encrypted_unicode_0, AnsibleVaultEncryptedUnicode)

    str_1 = '$ANSIBLE_VAULT;9.9;AES256'
    var_1 = do_vault(str_1, str_0)

    ansible_vault_encrypted_unicode_1 = AnsibleVaultEncryptedUnicode(var_0)
    var_2 = do_vault(var_0, var_1, var_1, var_0)


# Generated at 2022-06-25 09:14:38.891021
# Unit test for function do_vault
def test_do_vault():
    # Test without optional arguments.
    try:
        data = 'some_data'
        secret = 'some_secret'
        vault = do_vault(data, secret)
        assert vault is not None
    except Exception as e:
        print('do_vault failed: ' % to_native(e))
        assert False


# Generated at 2022-06-25 09:14:50.485684
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:57.924470
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:00.749595
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_1


# Generated at 2022-06-25 09:15:03.349479
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ";iy&S"
    var_0 = do_vault(str_0, str_0)
    var_5 = do_unvault(var_0, str_0)
    assert(str_0 == var_5)


# Generated at 2022-06-25 09:15:05.279916
# Unit test for function do_vault
def test_do_vault():
    # Keyword arguments passed to the function
    str_0 = ''
    salt_0 = None
    wrap_object_0 = False

    var_0 = do_vault(str_0, str_0, salt=salt_0, wrap_object=wrap_object_0)



# Generated at 2022-06-25 09:15:14.455542
# Unit test for function do_vault
def test_do_vault():

    # Passed variables
    str_0 = ''
    str_1 = ''
    data = None
    secret = None
    vaultid = ''

    # Return value tests
    assert do_vault(data, secret, vaultid) == "", "Return value test failed"
    assert do_vault(str_0, str_1, vaultid) == "", "Return value test failed"
    assert do_vault(data, secret, vaultid) == '', "Return value test failed"
    assert do_vault(str_0, str_1, vaultid) == '', "Return value test failed"

    # Call the function
    str_0 = 'Hello world!'
    str_1 = 'secret'
    data = 'Hello world!'
    secret = 'secret'
    vaultid = 'filter_default'

    # Return value

# Generated at 2022-06-25 09:15:21.704446
# Unit test for function do_vault
def test_do_vault():
    text_0 = 'I am the eggman, they are the eggmen.'
    str_0 = 'my_super_secret_password'
    var_0 = do_vault(text_0, str_0)
    var_0 = do_vault(var_0, str_0)
    var_0 = do_unvault(var_0, str_0)
    var_0 = do_unvault(var_0, str_0)
    return var_0

test_case_0()

# Generated at 2022-06-25 09:15:30.197700
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('', '', '', 'filter_default', True) is not None

# Generated at 2022-06-25 09:15:36.053475
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''

    # Call do_vault
    var_0 = do_vault(str_0, str_0)
    assert var_0 == ''

    # Call do_vault
    var_1 = do_vault(str_0, str_0)
    assert var_1 == ''


# Generated at 2022-06-25 09:15:46.192721
# Unit test for function do_vault
def test_do_vault():
    pass
    # secret = 'password'
    # data = 'data'
    # vault = do_vault(data, secret)
    # assert(isinstance(vault, str))
    # assert(is_encrypted(vault))
    # data_back = do_unvault(vault, secret)
    # assert(data == data_back)
    # assert(data == 'data')
    # assert(data_back == 'data')
    # assert(vault.startswith('$ANSIBLE_VAULT;'))
    #
    # #check that a long string is encrypted
    # data = 'a' * 10000
    # vault = do_vault(data, secret)
    # assert(isinstance(vault, str))
    # assert(is_encrypted(vault))
    # data_back =

# Generated at 2022-06-25 09:15:48.551521
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:53.755716
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n6635633136623830306263396430323234623035356233396232616130623537396633623163313431392d2d\n303365343031663537666335626162333832653966383330343965386535393036643132313535343035663834\n', 'test') == 'test'

# Generated at 2022-06-25 09:16:03.045783
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'YXNpYW4h'
    str_1 = 'YXNpYW4='
    str_2 = 'YXNpYW4='
    str_3 = 'YXNpYW4h'
    str_4 = 'YXNpYW4h'
    str_5 = 'YXNpYW4='
    str_6 = 'YXNpYW4h'
    str_7 = 'YXNpYW4='
    str_8 = 'YXNpYW4h'
    str_9 = 'YXNpYW4='
    str_10 = 'YXNpYW4h'
    str_11 = 'YXNpYW4='

# Generated at 2022-06-25 09:16:05.643767
# Unit test for function do_vault
def test_do_vault():
    try:
        assert(True)
    except AssertionError:
        display.warning("Testcase failed: do_vault")
    try:
        assert(True)
    except AssertionError:
        display.warning("Testcase failed: do_vault")


# Generated at 2022-06-25 09:16:10.750110
# Unit test for function do_vault
def test_do_vault():
    # Test with string
    assert do_vault('foo', 'foo') == '$ANSIBLE_VAULT;1.1;AES256\n376633616266626230643836366466653031333535376435363532313730386163623964633562666\n39393733376237613061316133326330353465623333656333666634326662396136633439396330\n37334235626638393334376531386461303230666337656466\n'

    # Test with vault

# Generated at 2022-06-25 09:16:22.671439
# Unit test for function do_vault
def test_do_vault():
    # Check filter_type_error exception is raised when data is not string
    with pytest.raises(AnsibleFilterTypeError) as e:
        do_vault(123, 'test')
    assert 'Secret passed is required to be a string' in str(e)
    assert 'instead we got: <class \'int\'>' in str(e)

    # Check filter_type_error exception is raised when secret is not string
    with pytest.raises(AnsibleFilterTypeError) as e:
        do_vault('test', 123)
    assert 'Secret passed is required to be a string' in str(e)
    assert 'instead we got: <class \'int\'>' in str(e)

    # Check ansible_filter_error exception is raised when secret is not string

# Generated at 2022-06-25 09:16:29.301550
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0)
    assert "".__eq__(var_0)

'''
print(AnsibleVaultEncryptedUnicode(var_0).decrypt)
print(do_unvault(var_0, 'password'))
'''

# Generated at 2022-06-25 09:16:30.908161
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;1.2;AES256' in var_0


# Generated at 2022-06-25 09:16:41.737549
# Unit test for function do_vault
def test_do_vault():
    print("")
    print("Test do_vault")
    print("==================")
    try:
        str_0 = ''
        var_0 = do_vault(str_0, str_0)
        assert var_0.startswith("$ANSIBLE_VAULT") == True
        assert len(var_0) > len("$ANSIBLE_VAULT")
    except Exception as e:
        print(e)
        assert e == None

    try:
        str_1 = ''
        var_1 = do_vault(str_1, str_1)
        assert var_1.startswith("$ANSIBLE_VAULT") == True
        assert len(var_1) > len("$ANSIBLE_VAULT")
    except Exception as e:
        print(e)
        assert e == None

   

# Generated at 2022-06-25 09:16:53.035407
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("unvaulted","password") == '$ANSIBLE_VAULT;1.1;AES256\n6637646434663564663365636662653864383462663262363364366363366232646466653565383633\n346239636138376466393564393765616661383566653839663733646337393261636561643564343532\n39646232636434623033651a363732646535366638336534623965383637633162643435653232316561\n613863336334626434386636353633343962616239616539626438653934303366313962663737396336\n36393531\n'
   

# Generated at 2022-06-25 09:17:03.228096
# Unit test for function do_vault
def test_do_vault():
    test_cases = [
        [   # Case 0
            {
                "data": "",
                "secret": "",
            }
        ],
        [   # Case 1
            {
                "data": "test",
                "secret": "test",
            }
        ],
        [   # Case 2
            {
                "data": "test",
                "secret": "test",
                "wrap_object": True,
            }
        ],
        [   # Case 3
            {
                "data": "test",
                "secret": "test",
                "salt": "",
            }
        ],
    ]


# Generated at 2022-06-25 09:17:04.890058
# Unit test for function do_vault
def test_do_vault():
    assert True == True
#     print('Hooray! test_do_vault() is working')


# Generated at 2022-06-25 09:17:15.624656
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:26.445049
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_16 = ''
    str_17 = ''
    str_18 = ''
    str_19 = ''
    str_20 = ''
    str_21 = ''
    str_22 = ''
    str_23 = ''
    str_24 = ''
    set_0 = set()
    int_0 = 0
    int_1 = 0
    float

# Generated at 2022-06-25 09:17:31.736939
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = ''
    var_0 = do_unvault(str_0, str_0)


# Generated at 2022-06-25 09:17:37.328436
# Unit test for function do_vault
def test_do_vault():
    assert test_case_0() == ''
    assert do_vault('test', 'test') == '$ANSIBLE_VAULT;1.1;AES256\n63326234313837373332373563313333306637356538336437306564356363346436326137643631\n66393864356163356236336239626463333764353462653365306438353838616235613638633365\n61336439356566613038316166', "do_vault(''test'', ''test'')"

# Generated at 2022-06-25 09:17:43.103416
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:17:46.746050
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={
        'str_0': {
            'type': 'str', 'required': True,
        },
        'str_1': {
            'type': 'str', 'required': True,
        },
    })

    str_0 = module.params['str_0']
    str_1 = module.params['str_1']

    module.exit_json(changed=False, ansible_facts={'do_vault': do_vault(str_0, str_1)})


# Generated at 2022-06-25 09:17:49.814604
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'test_string'
    str_1 = 'test_string'
    var_1 = do_vault(str_0, str_1)


# Generated at 2022-06-25 09:17:55.854215
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault(str_0, str_0)) == str
    assert do_vault(str_0, str_0) == str_0



# Generated at 2022-06-25 09:18:06.790616
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('', '') == '$ANSIBLE_VAULT;1.1;AES256\n35616332346539303337653465623134383861326133316665323336623239643165653962326463\n31373062333863396239313234373137386462656539303932336164633962326266653638323638\n35373762356264353864663733646230376435376333636234326234613364373634646537623762\n3137343163333234336665\n'

# Generated at 2022-06-25 09:18:18.638948
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'str_0'
    var_0 = do_vault(str_0, str_0)
    str_1 = 'str_1'
    var_1 = do_vault(str_1, str_0)
    str_2 = 'str_2'
    var_2 = do_vault(str_2, str_1)
    str_3 = 'str_3'
    var_3 = do_vault(str_3, str_2)
    str_4 = 'str_4'
    var_4 = do_vault(str_4, str_3)
    str_5 = 'str_5'
    var_5 = do_vault(str_5, str_4)
    str_6 = 'str_6'
    var_6 = do_v

# Generated at 2022-06-25 09:18:25.722477
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('my_string', 'my_string'), str) == True

    # Test for String Input
    str_0 = '123'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:18:27.730436
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(str_0, str_0) is None

# Generated at 2022-06-25 09:18:28.548571
# Unit test for function do_vault
def test_do_vault():
    test_case_0()



# Generated at 2022-06-25 09:18:29.993884
# Unit test for function do_vault
def test_do_vault():
    try:
        test_case_0()
    except:
        test_case_0()


# Generated at 2022-06-25 09:18:34.220817
# Unit test for function do_vault
def test_do_vault():
    test_case_0()

# Generated at 2022-06-25 09:18:38.874109
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test_secret'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n3638373737643936323033663161353566343135306631633962343135373466626163613931350a643564636265383536346465353664353065663232663339353463643662313762376366620a31633064623262316665633731646265356639333032626432346132363263316339306166'


    do_unvault(vault, secret)

# Generated at 2022-06-25 09:18:45.308890
# Unit test for function do_vault
def test_do_vault():

    try:
        test_case_0()
    except Exception:
        class_str = str(Exception)

        while class_str.find('(') > -1:
            class_str = class_str[:class_str.rfind('(')]

        if class_str.rfind('.') > -1:
            class_str = class_str[class_str.rfind('.') + 1:]

        return {class_name: class_str}

# Generated at 2022-06-25 09:18:55.157467
# Unit test for function do_unvault
def test_do_unvault():

    # Check type of arg 'vault' is right
    try:
        var_0 = do_unvault(["vault"], "secret")
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleFilterTypeError")

    # Check type of arg 'vault' is right
    try:
        var_0 = do_unvault({"vault": "vault"}, "secret")
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError("Failed to raise AnsibleFilterTypeError")

    # Check type of arg 'vault' is right
    try:
        var_0 = do_unvault(True, "secret")
    except AnsibleFilterTypeError:
        pass
    else:
        raise Assertion

# Generated at 2022-06-25 09:18:58.788205
# Unit test for function do_vault
def test_do_vault():
    try:
        assert test_case_0() == True
    except AnsibleVaultEncryptedUnicode as e:
        display.error(to_native(e.args[0]))
        assert False


# Generated at 2022-06-25 09:19:03.609656
# Unit test for function do_vault
def test_do_vault():
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    assert do_vault(str_0, str_1) == str_2
    assert do_vault(str_3, str_1) == str_2


# Generated at 2022-06-25 09:19:12.890893
# Unit test for function do_unvault

# Generated at 2022-06-25 09:19:21.839156
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'rQw$+n^L2tV)m5#'
    str_1 = 'q3F+^,p!=w62V;'
    var_0 = do_vault(str_0, str_1)