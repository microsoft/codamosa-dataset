

# Generated at 2022-06-25 09:09:35.904108
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''
    assert do_unvault('', '', '', '', '') == ''

# Generated at 2022-06-25 09:09:39.088985
# Unit test for function do_vault
def test_do_vault():
    with pytest.raises(AnsibleFilterTypeError) as exception_info:
        test_case_0()
    assert exception_info.value.args[0] == "Unable to encrypt: The ciphertext leading character '-' must be a number"


# Generated at 2022-06-25 09:09:44.657910
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '--reject-with'
    str_1 = '--reject-with'
    # No exception is raised
    assert do_unvault(str_0, str_1) == '--reject-with'
    # No exception is raised
    assert do_unvault(str_0, str_1) == '--reject-with'


# Generated at 2022-06-25 09:09:50.254866
# Unit test for function do_vault
def test_do_vault():
    list_0 = []
    str_0 = '--reject-with'
    var_0 = do_unvault(list_0, str_0)


# Generated at 2022-06-25 09:09:54.702215
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(['',ValueError('Unable to parse filters')], '*') == ''


# Generated at 2022-06-25 09:09:59.891174
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert to_native(do_unvault(list_0, str_0)) == """<class 'jinja2.runtime.Undefined'>""".encode('utf-8')
    except AssertionError as e:
        raise(AssertionError(to_native(e)))

if __name__ == '__main__':
    import datetime
    print()
    print(str(datetime.datetime.now()) + ' Running test cases:')
    print()
    test_case_0()

# Generated at 2022-06-25 09:10:08.482979
# Unit test for function do_vault
def test_do_vault():
    #Test cases
    #case 0
    assert do_vault(0, '') == None
    #case 1
    assert do_vault(0, '--reject-with') == None
    #case 2
    assert do_vault(0, '--reject-with') == None
    #case 3
    assert do_vault(0, '--reject-with') == None
    #case 4
    assert do_vault(0, '--reject-with') == None
    #case 5
    assert do_vault(0, '--reject-with') == None
    #case 6
    assert do_vault(0, '--reject-with') == None
    #case 7
    assert do_vault(0, '--reject-with') == None
    #case 8

# Generated at 2022-06-25 09:10:15.458239
# Unit test for function do_unvault
def test_do_unvault():
    assert 'Unable to decrypt: You must specify a value for the secret option' in to_native(do_unvault('', ''))
    assert 'Unable to decrypt: No vault provided' in to_native(do_unvault('', 'a'))
    assert 'Unable to decrypt: Provided string is not a valid encrypted string' in to_native(do_unvault('abc', 'a'))
    assert 'Unable to decrypt: Provided string is not a valid encrypted string' in to_native(do_unvault('!vault', 'a'))

# Generated at 2022-06-25 09:10:24.074119
# Unit test for function do_unvault
def test_do_unvault():
    list_0 = []
    str_0 = '--reject-with'
    var_0 = do_unvault(list_0, str_0)
    assert var_0 == []

    list_0 = []
    str_0 = '-A'
    var_0 = do_unvault(list_0, str_0)
    assert var_0 == []

    list_0 = []
    str_0 = '-p'
    var_0 = do_unvault(list_0, str_0)
    assert var_0 == []

    list_0 = []
    str_0 = '-X'
    var_0 = do_unvault(list_0, str_0)
    assert var_0 == []


# Generated at 2022-06-25 09:10:27.110623
# Unit test for function do_vault
def test_do_vault():
    assert do_vault([], '--reject-with') != None


# Generated at 2022-06-25 09:10:39.021840
# Unit test for function do_vault
def test_do_vault():
    # Make sure that this test is executed as part of the python test set
    assert __name__ == "__main__"

    # Setting up arguments and expected values
    secret = "secret"
    data = "data"
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-25 09:10:41.465534
# Unit test for function do_unvault
def test_do_unvault():
    filter_args = {
        'secret': str_0,
        'vault': str_0,
    }
    try:
        do_unvault(filter_args)
    except:
        print("Fail")
    else:
        print("Pass")

# Generated at 2022-06-25 09:10:43.753557
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:52.324323
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'abcdef123456'

# Generated at 2022-06-25 09:11:02.104509
# Unit test for function do_vault
def test_do_vault():
    # Create a string object
    str_0 = 'bogus'
    str_1 = 'bogus'
    str_2 = 'bogus'
    str_3 = 'bogus'
    str_4 = 'bogus'
    str_5 = 'bogus'
    str_6 = 'bogus'
    str_7 = 'bogus'
    str_8 = 'bogus'
    str_9 = 'bogus'
    str_10 = 'bogus'
    str_11 = 'bogus'
    str_12 = 'bogus'
    str_13 = 'bogus'
    str_14 = 'bogus'
    str_15 = 'bogus'

    # Try to use the function

# Generated at 2022-06-25 09:11:10.462801
# Unit test for function do_unvault
def test_do_unvault():
    test_can_only_vault_strings = 'utf-8'
    test_vault_should_be_in_the_form_of_a_string = 'utf-8'
    test_secret_passed_is_required_to_be_as_string = 'utf-8'
    test_utf_8 = 'utf-8'
    test_unable_to_decrypt = 'utf-8'
    test_unable_to_encrypt = 'utf-8'
    test_undefinederror = 'utf-8'

    test_vault_0 = 'utf-8'
    test_vault_1 = 'utf-8'
    test_vault_2 = 'utf-8'
    test_vault_3 = 'utf-8'

# Generated at 2022-06-25 09:11:20.503450
# Unit test for function do_vault
def test_do_vault():
    my_dict = {'a': 1, 'b': 2, 'c': 3}
    my_list_0 = ['a', 'b', 'c']
    my_list_1 = [1, 2, 3]
    my_str_0 = 'class'
    my_str_1 = 'utf-8'
    my_str_2 = 'a'
    try:
        assert do_vault(my_str_0, my_str_1) == 'Y2xhc3M=\n'
    except Exception as e:
        print('------------ Failed ------------')
        print('Test failed: {}'.format(e))
        print('------- End of the test -------')



# Generated at 2022-06-25 09:11:23.006055
# Unit test for function do_vault
def test_do_vault():
    assert (do_vault("plain_text", "secret", "salt", "vaultid", True) == "Unable to encrypt: bs64decode error: Incorrect padding")
    assert (do_vault("plain_text", "secret", "salt", "vaultid", False) == "Unable to encrypt: bs64decode error: Incorrect padding")


# Generated at 2022-06-25 09:11:32.648770
# Unit test for function do_unvault
def test_do_unvault():
    # Make sure that we raise an exception of type AnsibleFilterError if the vault parameter is of type
    # string_types, binary_type, AnsibleVaultEncryptedUnicode, Undefined, and of type string_types, binary_type,
    # Undefined for the secret paramater
    #
    # Arrange
    #
    # None
    #
    # Act
    #
    # Call do_unvault with various combinations of input parameters
    #
    # Assert
    #
    # An exception of type AnsibleFilterError should be raised for certain combinations

    with pytest.raises(AnsibleFilterError):
        do_unvault(1, 'ansible')
    
    with pytest.raises(AnsibleFilterError):
        do_unvault(1, 'ansible')


# Generated at 2022-06-25 09:11:40.196606
# Unit test for function do_unvault
def test_do_unvault():
  str_0 = 'ssssss'
  str_1 = 'ssssss'
  str_2 = 'ssssss'

  ret = do_unvault(str_0, str_1, str_2)
  print(ret)


# Generated at 2022-06-25 09:11:50.042697
# Unit test for function do_unvault
def test_do_unvault():
    vaultid = 'myvaultid'
    secret = 'mysecret'
    str_vault = '$ANSIBLE_VAULT;1.1;' + vaultid + '\n' + '6162636465667123456\n' + '6633613631623565323665633539356232626366336161343964623666353737653561626131653737\n'
    assert do_unvault(str_vault, secret, vaultid) == 'abcdef123456'


# Generated at 2022-06-25 09:11:53.315004
# Unit test for function do_vault
def test_do_vault():
    try:
        assert do_vault('abcdef123456', 'secret', 'salt', 'vaultid', 'wrap_object') == 'abcdef123456'
    except AssertionError:
        display.error('vault failed')



# Generated at 2022-06-25 09:11:57.448126
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    vault = do_vault(str_0, 'vault_secret')
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 09:12:01.729025
# Unit test for function do_unvault
def test_do_unvault():
    display.display("Testing do_unvault")
    test_str = 'test_str'
    secret = 'password'
    vault = do_vault(test_str, secret)
    assert test_str == do_unvault(vault, secret)
    display.display("do_unvault: PASS")

# Generated at 2022-06-25 09:12:06.961530
# Unit test for function do_vault
def test_do_vault():
    assert AnsibleVaultEncryptedUnicode(do_vault(test_case_0(), test_case_0()))


# Generated at 2022-06-25 09:12:13.399333
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62373162356363363231386136653334653335396565336661653435656430613638643339616664\n          33393566643534666465346163353566626263316130643961623364363762383565323034386665\n          6136663761633461656564613037353039\n          ', 'abcdef123456') == 'abcdef123456'

# Generated at 2022-06-25 09:12:25.008565
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:28.902527
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'abcdef123456'
    secret_0 = 'V2FsZG90b3J1cw=='
    vaultid_0 = 'filter_default'

    assert do_unvault(str_0, secret_0, vaultid_0) == 'abcdef123456'

# Generated at 2022-06-25 09:12:30.038772
# Unit test for function do_vault
def test_do_vault():
    str_0 = "abcdef123456"
    assert False

# Generated at 2022-06-25 09:12:41.037618
# Unit test for function do_unvault
def test_do_unvault():
    # Test 1. 
    plain_text = 'abcdef123456'
    cipher_text = '$ANSIBLE_VAULT;1.1;AES256\n353663313538623334373437313931313538653537386565326363326162666338636437306539\n386530626139316165373161366234633666313831626262306239336233316432336231666463\nb3030326137626466303238393161613439393465656635346538636364383633666262653231\n3034626435653164333466643938636434616365396165633631626534643630376439\n'
    secret_bytes = 'secret'
    vault_id

# Generated at 2022-06-25 09:12:49.294778
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    str_1 = 'foo'
    ret_2 = do_vault(str_0, str_1)
    display.display('ret_2: %s' % ret_2)
    str_3 = 'bar'
    ret_4 = do_unvault(ret_2, str_3)
    display.display('ret_4: %s' % ret_4)

# Generated at 2022-06-25 09:12:55.437840
# Unit test for function do_unvault
def test_do_unvault():
    s = 'level0'
    data = dict(
        vault_password_file=dict(
            ansible='data'
        )
    )

    data['vault_password_file'].update({'ansible': s})
    print(data)


# Generated at 2022-06-25 09:12:59.949649
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    str_1 = 'abcdef123456'
    assert do_vault(str_0, str_1) == b'$ANSIBLE_VAULT;1.1;AES256\n6162636465663132333435360b1e70b8bd7d4a2ad4d7f83c9d9e99b09e9660410a6488e0a00\n'


# Generated at 2022-06-25 09:13:02.475225
# Unit test for function do_unvault
def test_do_unvault():

    print('%%%%%%%%%%%%%%%')
    print('test_do_unvault()')
    assert to_native(do_unvault('$ANSIBLE_VAULT;1.1;AES256;user1','12345678','user1')) == 'abcdef123456'


# Generated at 2022-06-25 09:13:04.139544
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, 'test_secret') != None


# Generated at 2022-06-25 09:13:05.369289
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    print('all case done')


# Generated at 2022-06-25 09:13:09.297115
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    

# Generated at 2022-06-25 09:13:17.088700
# Unit test for function do_vault
def test_do_vault():
    # do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)
    st_0 = 'abcdef123456'
    st_1 = 'abcdef123456'
    st_2 = 'abcdef123456'
    st_3 = 'abcdef123456'
    st_4 = 'abcdef123456'
    # Save state
    old_st_1 = st_1
    old_st_2 = st_2
    old_st_3 = st_3
    old_st_4 = st_4
    # Do function call
    old_st_0 = st_0
    st_0 = do_vault(st_1, st_2, st_3, st_4)
    # Check original state
    assert old_st_1 == st_1

# Generated at 2022-06-25 09:13:27.149798
# Unit test for function do_vault
def test_do_vault():
    data = 'abcdef123456'
    secret = 'Ansible@123'
    vaultid = 'filter_default'
    wrap_object = False
    result_0 = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-25 09:13:38.428034
# Unit test for function do_vault
def test_do_vault():

    vault_0 = do_vault(data = str_0, secret = '1234')

# Generated at 2022-06-25 09:13:41.103017
# Unit test for function do_vault
def test_do_vault():
    test_case_0()

# Generated at 2022-06-25 09:13:43.895814
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'

    ## Vault
    str_1 = do_vault(str_0, 'secretpassword')
    str_2 = do_vault(str_0, 'secretpassword')
    assert str_0 != str_1
    assert str_0 != str_2
    assert str_1 != str_2


# Generated at 2022-06-25 09:13:50.313545
# Unit test for function do_vault
def test_do_vault():
    # Test for do_vault - has correct type for string return
    my_secret = 'shhh'
    my_vault = do_vault(str_0, my_secret)

    assert type(my_vault) == str


# Generated at 2022-06-25 09:14:01.762284
# Unit test for function do_vault
def test_do_vault():
    print("\n---------------------------------------------------")
    print("Test for do_vault")
    print("---------------------------------------------------")
    print("Test for str")
    print("---------------------------------------------------")
    str_0 = 'any string'
    str_1 = 'a very long string that should show us that long strings are working'
    str_2 = ''

    # Test for unicode
    print("---------------------------------------------------")
    print("Test for unicode")
    print("---------------------------------------------------")
    uni_0 = u'any unicode'
    uni_1 = u'a very long unicode that should show us that unicode strings are working'
    uni_2 = u''

    # Test for Undefined
    print("---------------------------------------------------")
    print("Test for Undefined")
    print("---------------------------------------------------")
    und = Undefined

    # Test for int


# Generated at 2022-06-25 09:14:12.742682
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:14.684534
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 09:14:20.942486
# Unit test for function do_vault
def test_do_vault():
    print("Testcase 0 for do_vault")
    vault = do_vault(test_case_0(), 'abcdef123456')
    assert vault == '$ANSIBLE_VAULT;1.1;AES256', "vault: %s" % vault


# Generated at 2022-06-25 09:14:30.705634
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:42.516308
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    str_1 = 'abcdef123456'
    str_2 = 'abcdef123456'
    assert do_vault(str_0, str_1) == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          64303437653434613233626437346637376362393162353730363337353939356562383730353436\n          63323435383863656566653264323762396164623363366536303732656134623433613232613766\n          62653839383465336635\n          '

# Generated at 2022-06-25 09:14:53.325344
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    str_1 = 'abcdef123456'
    str_2 = 'abcdef123456'
    dict_0 = dict()
    dict_0['abcdef123456'] = 'abcdef123456'
    dict_0['abcdef123456'] = 'abcdef123456'
    dict_0['abcdef123456'] = 'abcdef123456'
    dict_0['abcdef123456'] = 'abcdef123456'
    dict_0['abcdef123456'] = str_2
    dict_0['abcdef123456'] = str_1
    str_3 = 'abcdef123456'
    str_4 = 'abcdef123456'
    str_5 = 'abcdef123456'
    str_6 = 'abcdef123456'

# Generated at 2022-06-25 09:15:00.886553
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'abcdef123456'
    str_1 = 'abcdef123456'
    str_2 = 'abcdef123456'
    str_3 = 'abcdef123456'
    str_4 = 'abcdef123456'
    str_5 = 'abcdef123456'
    str_6 = 'abcdef123456'
    str_7 = 'abcdef123456'

    assert do_unvault(str_0, str_1) == 'abcdef123456'
    assert do_unvault(str_2, str_3) == 'abcdef123456'
    assert do_unvault(str_4, str_5) == 'abcdef123456'
    assert do_unvault(str_6, str_7) == 'abcdef123456'


# Generated at 2022-06-25 09:15:02.342905
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault('ansible', 'password')) == str


# Generated at 2022-06-25 09:15:03.535842
# Unit test for function do_vault
def test_do_vault():
    # stub
    test_case_0()


# Generated at 2022-06-25 09:15:08.454897
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    filter_1 = do_vault(str_0, '0', '01', 'filter_default', False)
    assert filter_1 == '$ANSIBLE_VAULT;1.2;AES256;filter_default01\n353331323263323264356434306664656663666436346635336566343233623537623762313535\n323966363035653337636661383638343134616566363463366162353134333735386262623365\n33396534663666623333333065663939336562'


# Generated at 2022-06-25 09:15:12.877070
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    str_1 = 'e'
    str_2 = str_0[::-1]
    assert str_1 == str_2


# Generated at 2022-06-25 09:15:15.347413
# Unit test for function do_unvault
def test_do_unvault():
    
    # Test case 0
    ret_0 = do_unvault('$$$V7$$$abcdef123456\n', 'password', 'default')
    assert ret_0 == str_0


# Generated at 2022-06-25 09:15:28.150056
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:39.421113
# Unit test for function do_vault
def test_do_vault():
    # Silent the display of warnings
    dummy_display = display
    display.verbosity = 0

    # Tests with parameters

# Generated at 2022-06-25 09:15:46.897603
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:51.651114
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, str_0, str_0) == '$ANSIBLE_VAULT;1.2;AES256;a;YWJjZGVmMTIzNDU2\nCmhsZkxpM0hjbWVPMUpTU05YTmwvTnJ6T2U9PQo=\n', "do_vault(str_0, str_0, str_0) == '$ANSIBLE_VAULT;1.2;AES256;a;YWJjZGVmMTIzNDU2\nCmhsZkxpM0hjbWVPMUpTU05YTmwvTnJ6T2U9PQo=\n'"

# Generated at 2022-06-25 09:16:01.467684
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'abcdef123456'

# Generated at 2022-06-25 09:16:11.091234
# Unit test for function do_unvault

# Generated at 2022-06-25 09:16:12.242782
# Unit test for function do_vault
def test_do_vault():

    # Testing execution for data = 'abcdef123456', secret = 'my_secret'
    test_case_0()

# Generated at 2022-06-25 09:16:15.413785
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'abcdef123456'
    str_1 = 'abcdef123456'
    assert do_unvault(str_0, str_1) == True


# Generated at 2022-06-25 09:16:20.052376
# Unit test for function do_vault
def test_do_vault():
    print('Testing function do_vault')
    try:
        do_vault(str_0, 'myp@ssw0rD', vaultid='filter_default')
    except RuntimeError as err:
        assert "We weren't able to decrypt the vault" in str(err)
        assert 'Invalid vault password' in str(err)
        assert 'myp@ssw0rD' in str(err)
    except TypeError:
        assert False, 'Unexpected error raised.'



# Generated at 2022-06-25 09:16:21.281538
# Unit test for function do_vault
def test_do_vault():
    assert 1 == 1

# Generated at 2022-06-25 09:16:25.836916
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'abcdef123456'
    assert isinstance(do_vault(str_0, 'secret', 'salt', 'filter_default', False), string_types)



# Generated at 2022-06-25 09:16:34.721946
# Unit test for function do_unvault
def test_do_unvault():
    print('\nRunning test for function: do_unvault')
    str_0 = 'abcdef123456'
    str_1 = 'abcde3456'
    str_2 = 'abcdef123456'

    # Test case 1
    # Example from https://docs.ansible.com/ansible/latest/modules/vault_module.html

# Generated at 2022-06-25 09:16:45.352822
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'abcdef123456'

# Generated at 2022-06-25 09:16:46.670375
# Unit test for function do_vault
def test_do_vault():
    # Run the following code
    test_case_0()
	

# Generated at 2022-06-25 09:17:01.545831
# Unit test for function do_vault
def test_do_vault():
    str_arg_0 = '--reject-with'
    str_arg_1 = '--reject-with'
    var_result_0 = do_vault(str_arg_0, str_arg_1)
    var_expected_0 = '$ANSIBLE_VAULT;1.1;AES256\n35346137613461333935646339376165636338333063346166383332346566623935353162356134\n35306639386166633266323731636539643630653634623962366337353065363164646662303039\n61343237626534363165633633343033633061376238366432366166643666\n'

# Generated at 2022-06-25 09:17:09.106500
# Unit test for function do_vault
def test_do_vault():

    assert do_vault('','secret') == '$ANSIBLE_VAULT;1.1;AES256\n636532353163333561616362656635326366633534396137633365646262616562393563313036316534\n393336663232353966356363363931396131613332333762313161663932303665666662376138303666\n653061383030643338336363663530336630633561316631666364666239386334306466363362366365\n35353166643639326262366265316332353266363630666334346536663463623334643937\n'


# Generated at 2022-06-25 09:17:12.032517
# Unit test for function do_vault
def test_do_vault():
    actual = do_vault()
    # assert actual == expected
    if actual != expected:
        raise AnsibleFilterError('do_vault failed')



# Generated at 2022-06-25 09:17:22.483848
# Unit test for function do_unvault

# Generated at 2022-06-25 09:17:30.472293
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('--reject-with', '--reject-with') == '$ANSIBLE_VAULT;1.1;AES256\n37333530316133393964663537646634356466356130663863653363626262346161363362393164\n39633062663834316563643034356639356466303631626166313237393162393131613238666564\n35643766333830383565346665373435363134323131663335663665376638653534316365386633\n6630356662643437653437353330313037363839613264\n'


# Generated at 2022-06-25 09:17:36.134497
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, str_0) == '$ANSIBLE_VAULT;1.1;AES256\n3464383638653235306535343135626530343331623937633862643361303766336536666535\n6338666161303065643939346566653031653062393564653334386636353461303937623463\n6362333832622d32366332653731326464306631313431312ab\n'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:17:40.497781
# Unit test for function do_vault
def test_do_vault():
    try:
        assert callable(do_vault)
        test_case_0()
    except AssertionError as ae:
        display.error("Testcase " + ae.__str__() + " failed")
        raise ae
    display.display("do_vault testcase passed")
    return True


# Generated at 2022-06-25 09:17:47.657804
# Unit test for function do_unvault
def test_do_unvault():
    # Example case
    str_0 = '-reject-with'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256\n363337646436333565333138366435313165643638663565613162303436663539613562353863\n653633306332393031646332643935643164613665343731656363376361323235643161653265\n38396532643362643864616365363938\n'
    assert var_1 == '--reject-with'


# Generated at 2022-06-25 09:17:52.515753
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('--reject-with', '--reject-with') == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35356466306431366331306438626465633836333864323932386435636164346137383361326561\n          65313531653165383130363365326232336363353131316133330a36626339616137666562376135\n          3432626261623763313636323231643137373734656263633463643323233613737306663376363\n          62653437636633363330650a3031326334363362303761653235\n'

# Generated at 2022-06-25 09:17:54.853298
# Unit test for function do_unvault
def test_do_unvault():
    assert isinstance(do_unvault(None, None, 'default'), Undefined)


# Generated at 2022-06-25 09:18:03.065182
# Unit test for function do_vault
def test_do_vault():
    # Test case 0
    str_0 = '--reject-with'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0
    # Test case 1
    str_0 = '-reject-with'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0
    # Test case 2
    str_0 = 'reject-with'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0
    # Test case 3
    str_0 = 'reject-with-error'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == str_0
    # Test case 4
   

# Generated at 2022-06-25 09:18:09.271108
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'a'
    str_1 = 'a'
    collected = do_unvault(str_0, str_1)


if __name__ == '__main__':
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:18:15.891919
# Unit test for function do_vault
def test_do_vault():
    arg0 = "--reject-with"
    arg1 = "--reject-with"
    arg2 = None
    arg3 = "filter_default"
    arg4 = False
    actual = do_vault(arg0, arg1, arg2, arg3, arg4)
    expected = '$ANSIBLE_VAULT;1.1;AES256\n30623433373137303530316662626166326339666362333538376434356132626335366432323035\n34656437356365653866333930663964666237633362376261643235323466653431313733643062\n666436653464383566303462\n'
    assert actual == expected


# Generated at 2022-06-25 09:18:18.364365
# Unit test for function do_vault
def test_do_vault():
    str_0 = '--reject-with'
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:18:22.218660
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = '--reject-with'
    var_0 = '--reject-with'
    var_1 = do_vault(str_0, str_0)
    var_2 = do_unvault(var_1, var_0)
    assert(var_2 == str_0)

# Unit tests for function do_vault

# Generated at 2022-06-25 09:18:32.597764
# Unit test for function do_unvault

# Generated at 2022-06-25 09:18:36.153305
# Unit test for function do_vault
def test_do_vault():
    result = do_vault(str_0, str_0)
    print(result)
    assert(result == var_0)


# Generated at 2022-06-25 09:18:46.958014
# Unit test for function do_vault
def test_do_vault():
    var_0 = do_vault('--reject-with', '--reject-with')

# Generated at 2022-06-25 09:18:49.005341
# Unit test for function do_unvault
def test_do_unvault():
    assert 'reject-with' == do_unvault('ASDASDASDASDASD', '--reject-with')


# Generated at 2022-06-25 09:18:49.841326
# Unit test for function do_vault
def test_do_vault():
    assert len(do_vault()) == 0

# Generated at 2022-06-25 09:19:05.118292
# Unit test for function do_vault
def test_do_vault():
    str_0 = '--reject-with'
    var_0 = do_vault(str_0, str_0)

    assert isinstance(var_0, (AnsibleVaultEncryptedUnicode, str)) == True
    ansible_vault_encrypted_unicode_0 = AnsibleVaultEncryptedUnicode(var_0)

    assert isinstance(ansible_vault_encrypted_unicode_0, (AnsibleVaultEncryptedUnicode, str)) == True
    str_1 = str(ansible_vault_encrypted_unicode_0)

    assert isinstance(str_1, (AnsibleVaultEncryptedUnicode, str)) == True
    var_1 = do_unvault(str_1, str_0)


# Generated at 2022-06-25 09:19:12.963239
# Unit test for function do_unvault
def test_do_unvault():
    # Initializing 'str_0' with value '--reject-with'
    str_0 = '--reject-with'

    # Necessary values for do_vault
    str_1 = '--reject-with'

    # Executing function 'do_vault'
    var_0 = do_vault(str_1, str_1)

    # Initializing 'str_2' with value 'test_str'
    str_2 = 'test_str'

    # Executing function 'do_vault' with arguments (str_2, str_2)
    var_1 = do_vault(str_2, str_2)

    # Executing function 'do_unvault' with arguments (var_0, str_0)

# Generated at 2022-06-25 09:19:17.632880
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'Some plain text value'
    str_1 = '--reject-with'
    var_0 = do_vault(str_0, str_1)
    var_1 = do_unvault(var_0, str_1)
    assert var_1 is not None
    assert var_1 == str_0

# Generated at 2022-06-25 09:19:25.034382
# Unit test for function do_vault
def test_do_vault():
    # First test case using dict/list/string/int
    # with string
    str_0 = '--reject-with'
    var_0 = do_vault(str_0, str_0)

    # invalid data type
    # with dict
    dict_0 = {}
    try:
        var_0 = do_vault(dict_0, str_0)
    except AnsibleFilterError as e:
        if 'Can only vault strings' in e.message:
            print('Expected exception message: %s' % e.message)
        else:
            print('Test case failed')
            print('Expected exception message is: %s' % 'Can only vault strings')
            print('Actual exception message is: %s' % e.message)

    # with list
    list_0 = []