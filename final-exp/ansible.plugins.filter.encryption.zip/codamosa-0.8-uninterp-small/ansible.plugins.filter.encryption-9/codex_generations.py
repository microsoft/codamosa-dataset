

# Generated at 2022-06-25 09:09:30.096379
# Unit test for function do_unvault
def test_do_unvault():
    print("\n")
    test_text = "Test Text"
    test_password = "MyPassword"
    data = do_vault(test_text, test_password, "vault_test")
    data = do_unvault(data, test_password)
    assert data == test_text

if __name__ == '__main__':
    test_do_unvault()
    test_case_0()

# Generated at 2022-06-25 09:09:41.077587
# Unit test for function do_unvault

# Generated at 2022-06-25 09:09:44.914089
# Unit test for function do_unvault
def test_do_unvault():
    try:
        # Place holder for test case
        unvault = do_unvault('{{ vault_key }}', 'test-test-test-test-test-test-test')
    except Exception as e:
        return False
    else:
        return True


# Generated at 2022-06-25 09:09:52.969456
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("foo", "bar", 'baz', wrap_object=True) == AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.2;AES256;baz\n36373331316235643336326265306461633635333835303563623666643830316430353861346436\n303539356136373838633661323136613236643132396263313737643538623030373664350a\n")

# Generated at 2022-06-25 09:10:00.089324
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3265653837333161383932616462663166666362373735336531313564663232613934653661616136\n          3833353066653939366361626536386431303935306631326362333461343934333632303237633832\n          326537336566633237653834656664\n          6465333139623535613035\n",
                    "ruby")=="omgdot"


# Generated at 2022-06-25 09:10:08.633311
# Unit test for function do_unvault
def test_do_unvault():

    # some values
    secret = 'foobar'

# Generated at 2022-06-25 09:10:15.573053
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test_data'
    result = do_vault(data, secret)

# Generated at 2022-06-25 09:10:26.194627
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("NON-ENCRYPTED-DATA", "PASSWORD", "SALT", "VAULT-ID") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;salt\n          38463242613431333633663335363830343661396435323333623235346161383833303937623331366\n          36164633962393166376162626131373832623333666332632393133313661386333643662393461633\n          63326338633066373731376633303839356363643861333133343963363232386533346235636265300\n          a\n          vault-id: VAULT-ID\n          "


# Generated at 2022-06-25 09:10:35.308712
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:43.372893
# Unit test for function do_vault
def test_do_vault():

    filter_module = FilterModule()
    filters = filter_module.filters()
    do_vault = filters.get("vault")
    do_unvault = filters.get("unvault")

    assert do_unvault(do_vault("foo", "bar"), "bar") == "foo"
    assert do_unvault(do_vault("", "bar"), "bar") == ""



# Generated at 2022-06-25 09:10:57.456244
# Unit test for function do_unvault

# Generated at 2022-06-25 09:11:04.573967
# Unit test for function do_unvault
def test_do_unvault():
    # Encrypted data
    vault = '$ANSIBLE_VAULT;1.1;AES256\n303837636464383331356332666564376530353631333564653730666636646332653766653662\n396637343835303130326162333937303866316565643264663761626135353637343731333766\n39616263366530386337336661307d0a'

    # Secret data
    secret = 'XXXXXXXXXX'

    res = do_unvault(vault, secret)
    assert res == 'ansible'


# Generated at 2022-06-25 09:11:12.064097
# Unit test for function do_vault
def test_do_vault():
    vault = filter_module_0.filters()['vault']
    data = "Hello World"
    secret = "secret"
    test_result = vault(data, secret)

# Generated at 2022-06-25 09:11:21.312634
# Unit test for function do_vault

# Generated at 2022-06-25 09:11:32.535884
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

    data = "foo"
    secret = "password"
    salt = None
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-25 09:11:44.485500
# Unit test for function do_unvault
def test_do_unvault():
    print('')
    print('Test do_unvault')

    secret = 'secret'
    vault_data = '$ANSIBLE_VAULT;1.1;AES256;vault_default\r\n3635626435306538663833656665373931373138616634393330353465643632393730353839\r\n3066336137616363323831363637373565343365383237613539613538613539333061326232\r\n3665623037663066663330373732633365643834393162346331626530363351336665323363\r\n376265383262633134386561386331306431653162333462636363383466\r\n'



# Generated at 2022-06-25 09:11:54.163938
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault='$ANSIBLE_VAULT;1.2;AES256;foo123456789\r\n8c80f07dc67b0c3e3e3af8c0b36625d224a2e1de854b8fb7137a889e730b3fb3\r\n8e75f79d9a9c2f2a8a8c7a39dec6ecdc\r\n', secret='abc123', vaultid='default') == 'foobar'

# Generated at 2022-06-25 09:12:04.620705
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:12.654812
# Unit test for function do_vault
def test_do_vault():
    test_data = "hello world"
    test_secret = "hunter2"
    test_salt = None
    test_vaultid = 'filter_default'
    test_wrap_object = False

    result = do_vault(test_data, test_secret, test_salt, test_vaultid, test_wrap_object)

# Generated at 2022-06-25 09:12:17.810296
# Unit test for function do_unvault

# Generated at 2022-06-25 09:12:28.484902
# Unit test for function do_unvault
def test_do_unvault():
    secret = "mysecret"
    vault = "\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          39303137646636346438303635663761316631376564663339646130306537376231336539653362\n          38653066386233333935373033633462356635343437656666333437\n"
    vaultid = 'filter_default'

    try:
        assert do_unvault(vault, secret, vaultid) == "this is my unvaulted content\n"
    except AssertionError as e:
        raise e



# Generated at 2022-06-25 09:12:35.581346
# Unit test for function do_vault

# Generated at 2022-06-25 09:12:46.593844
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()

    # Test with required args only
    test_string = 'foo'
    test_secret = 'bar'
    assert filter_module_1.filters()['vault'](test_string, test_secret) == '$ANSIBLE_VAULT;2.0;AES256;filter_default\n633136346463623936356465303664336530396635653065343037343331393262646332643531386\n365613361613935373938323133653037663432303139313166656336373338366237343736363732\n626331630a3431616361396132346366'

    # Test with secret as unicode
    test_secret = u'bar'
   

# Generated at 2022-06-25 09:12:57.943540
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

# Generated at 2022-06-25 09:13:08.240855
# Unit test for function do_unvault
def test_do_unvault():
    """
        Unit test for function do_unvault
    """

    # Test case 1

# Generated at 2022-06-25 09:13:18.258836
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('ansible', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n3432396163653939623233376436663862323966383234353465353039303262656237623466\n3437396430346236396635633166653862346231343135313162326164363639303538643933\n3065663862623066336663663433636530663733396638356162653631386165323430386161\n3937346330353766373061623030353865323033656539363336394366\n', \
    "Unexpected Ansible Vault output for valid input parameters"


# Generated at 2022-06-25 09:13:26.590063
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

    try:
        assert filter_module_0.filters().get('vault') is not None
        assert filter_module_0.filters().get('unvault') is not None
        assert filter_module_0.filters().get('vault')('password', 'secret') is not None
        assert filter_module_0.filters().get('unvault')('$ANSIBLE_VAULT;1.1;AES256', 'secret') is not None
    except AssertionError as e:
        display.error("test_do_vault(): " + str(e))
        return
    display.display("test_do_vault(): PASSED")



# Generated at 2022-06-25 09:13:37.964672
# Unit test for function do_vault
def test_do_vault():
    # Test default
    assert (do_vault('data', 'secret', None, 'filter_default') == '$ANSIBLE_VAULT;1.1;AES256\n30356364353464383938653130663339623966653765303633326362346336333739383538346336\n62303564343666633731643063336165396438373135616336666537633332306235623934326462\n383538366466\n')
    # Test case where wrap_object is False

# Generated at 2022-06-25 09:13:41.870974
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    secret = 'password123'
    data = 'my secret'
    wrapped = True
    assert do_vault(data, secret, wrap_object=wrapped) == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault(data, secret, wrap_object=wrapped) is not None
    assert not is_encrypted(data)



# Generated at 2022-06-25 09:13:46.073164
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test','test','test') == u'$ANSIBLE_VAULT;1.1;AES256\n313734373835333065333932316335663763336632346433633962333931373137656235636535\n626161333863333539366566373030623936616363623233366562653039\n'


# Generated at 2022-06-25 09:13:58.462309
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:04.314976
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'hello world'

    assert do_vault(data, secret) == '$ANSIBLE_VAULT;1.1;AES256\n3633383533303763623665653961623931626439326233356369306137623265616137326436641a\n63386130633162333367366164346438663862653735303636336564653836643133633463373239\n38313432346334'


# Generated at 2022-06-25 09:14:11.216432
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data='test', secret='secret') == '$ANSIBLE_VAULT;1.1;AES256\n396265316365643566323765313363366137303564343865616462386133306331636266303564\n36643831313662373263653631353737623536663432303465366131663533613863340a373636\n623864653036343763646438656564323235356433343764343965633131623666323662383934\n3033663166663733353065313232366565323938393930636636663536336130396632\n'

# Generated at 2022-06-25 09:14:20.400520
# Unit test for function do_unvault
def test_do_unvault(): 
    secret = '0123456789abcdef'

# Generated at 2022-06-25 09:14:30.511176
# Unit test for function do_vault
def test_do_vault():
    data_0 = 'Foobar!'

# Generated at 2022-06-25 09:14:42.373043
# Unit test for function do_vault

# Generated at 2022-06-25 09:14:53.172195
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test1'
    vaultid = 'filter_default'

# Generated at 2022-06-25 09:15:03.236193
# Unit test for function do_unvault

# Generated at 2022-06-25 09:15:08.920402
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    filter_filters = filter_module.filters()

    secret = 'mysecret'
    data = 'mydata'
    vault = filter_filters.get('vault')(data, secret)
    data_back = filter_filters.get('unvault')(vault, secret)

    assert data == data_back
    assert data != vault

    secret = 'mysecret'
    data = u'mydata'
    vault = filter_filters.get('vault')(data, secret)
    data_back = filter_filters.get('unvault')(vault, secret)

    assert data == data_back
    assert data != vault

    secret = u'mysecret'
    data = 'mydata'

# Generated at 2022-06-25 09:15:16.330886
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:29.774609
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:40.302329
# Unit test for function do_vault
def test_do_vault():

    vault_case_0 = do_vault('ansible.cfg',
                            'secret',
                            salt=None,
                            vaultid='filter_default',
                            wrap_object=False)

    vault_case_1 = do_vault('ansible.cfg',
                            None,
                            salt=None,
                            vaultid='filter_default',
                            wrap_object=False)

    vault_case_2 = do_vault(None,
                            'secret',
                            salt=None,
                            vaultid='filter_default',
                            wrap_object=False)

    vault_case_3 = do_vault(None,
                            None,
                            salt=None,
                            vaultid='filter_default',
                            wrap_object=False)


# Generated at 2022-06-25 09:15:47.513335
# Unit test for function do_vault
def test_do_vault():
    data = "this is the string to be encrypted"
    secret = "this is the secret"
    vaultid = "filter_default"
    salt = "salt"
    result = do_vault(data, secret, salt)
    assert result == "$ANSIBLE_VAULT;1.1;AES256\n6239626536346236326261303964373063313861323731636235666437633366646538306338630a65336138336465376161396235386438653865313364366638376235636234636131656237310a38393836353034356434363365663935306634383638333930366537343633343035373337\n"


# Generated at 2022-06-25 09:15:55.621024
# Unit test for function do_vault
def test_do_vault():
    passwd = "mysecret"
    data = "default"
    salt = None
    vaultid = 'filter_default'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n33633038343664616632616266636435666632656533386535343839613165656161376237633535\n33303666393534633533363334613062303630343666656434663930373831666565373364656634\n66336535376333643237623164626537336231366233346163363139386266373862623330376637\n363230337d'
    r = do_vault(data, passwd, salt, vaultid, False)

# Generated at 2022-06-25 09:15:58.008968
# Unit test for function do_vault
def test_do_vault():
    # Empty vault
    assert do_vault('', 'notasecret') == ''
    # Vault with a secret
    assert '$ANSIBLE_VAULT;' in do_vault('mydata', 'mysecret')


# Generated at 2022-06-25 09:16:05.410846
# Unit test for function do_vault
def test_do_vault():
    fail = False

    # Test case 1
    data = 'my-data'
    secret = 'my-password'
    salt = '12345678'
    vaultid = ''
    wrap_object = False

# Generated at 2022-06-25 09:16:16.176434
# Unit test for function do_vault
def test_do_vault():
    # check for vaulting a non string raises an error
    try:
        do_vault(1, 'password')
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError("Vaulting a non string data object did not raised expected AnsibleFilterTypeError")

    # check for vaulting a non string raises an error
    try:
        do_vault('encrypted', [])
    except AnsibleFilterTypeError:
        pass
    else:
        raise AssertionError("Vaulting a non string secret object did not raised expected AnsibleFilterTypeError")

    # check for vaulting a string returns the correct vault data

# Generated at 2022-06-25 09:16:18.223012
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("test", "secret") == do_unvault("test", "secret")

# Generated at 2022-06-25 09:16:29.302252
# Unit test for function do_vault
def test_do_vault():
    test_case_0()
    test_secret = '$ANSIBLE_VAULT'
    test_salt = '$default$'
    test_vaultid = 'filter_default'
    test_data = 'b'
    test_wrap_object = False
    test_output = b'$ANSIBLE_VAULT;1.1;AES256\n343730333934353135362d3933382d343564342d6335612d666437656264643263323400\n'
    assert do_vault(test_data, test_secret, test_salt, test_vaultid, test_wrap_object) == test_output



# Generated at 2022-06-25 09:16:32.602680
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vaultid = "vaultid"

    assert do_vault(data, secret, salt, vaultid) == "", "do_vault returns empty string"


# Generated at 2022-06-25 09:16:46.651024
# Unit test for function do_vault
def test_do_vault():
    filter_module_1 = FilterModule()


# Generated at 2022-06-25 09:16:52.763660
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'cowsaymoo', 'filter_default', False) == '$ANSIBLE_VAULT;1.1;AES256\n633937366530313633323530356163666335666233616262666563376237356337396637373866\n393764383730313163613864373063643738386332626336323661623563396366393933633236\n653665336264353963353833396266396165653962666166376566\n'


# Generated at 2022-06-25 09:17:03.072407
# Unit test for function do_vault
def test_do_vault():
    # Initializing test string, expected output and output string
    test_string = "test_string"
    secret = "secret"

# Generated at 2022-06-25 09:17:09.795629
# Unit test for function do_vault
def test_do_vault():
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          62656164627968444f535641524942513555764a6a65355a4742524d2b6c73643072766138754c4d\n          784d4f734e49597a4f7a4d4d4e6e356c66404d433668454e566b516471387763487057554d5333534d\n          784e45356a773d\n          "
    vault_result = do_vault("secret message", "secret")
    assert vault == vault_result


# Generated at 2022-06-25 09:17:18.160590
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:26.224869
# Unit test for function do_vault
def test_do_vault():
    data = "A test string"
    secret = "secret"
    vault_string = "AQAAAAEAACcQAAAAEPh1LdO+iKZcs5oZPt8chFt9XmKiO/c0ho1wH/Lfr0E0t/4K/ZiN3qxQC9XfN0OR1WA=="

    result = do_vault(data, secret)
    print("vault string:", result)
    assert result == vault_string
    assert result == do_vault(data, secret)
    assert result == do_vault(data, secret, wrap_object=True)



# Generated at 2022-06-25 09:17:31.548405
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:38.770724
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:50.229314
# Unit test for function do_unvault

# Generated at 2022-06-25 09:18:02.052402
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n356231316561363033613034313334653030633465306231643533396530396662303066356139\n656566656239306335666162366365353563633631356363336230393764616431663963643737\n653135666163666238653936373530333937363732343231616536373132316437626264636637\n643035396538343531613331316231393665613832393063353264376165323564353038333835\n',
                            '<password>',
                            vaultid='foo') == 'hello world\n'


# Generated at 2022-06-25 09:18:13.938094
# Unit test for function do_vault
def test_do_vault():
    """ Encrypts a string and returns a string of the vault file """
    assert do_vault("this is my secret", "ansible") == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          383061333637386266363862346333623063373437653535316439393932626262333362326465\n          35333863303362356166623438613966656532366133617d0a3739363336653737356366633163\n          616437653732303035623766316462626536653937316335313531653131633365306637356566\n          3834653130313936310a"

# Generated at 2022-06-25 09:18:24.659218
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    result = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=True)

# Generated at 2022-06-25 09:18:34.740907
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) is None
    assert do_unvault('test', 'pass') == 'test'
    assert do_unvault(u'test', u'pass') == u'test'
    assert do_unvault(b'test', b'pass') == b'test'

# Generated at 2022-06-25 09:18:46.839985
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()
    filter_module_0.filters()

    account = "johndoe"
    password = "secret"

# Generated at 2022-06-25 09:18:54.606276
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault('unvault_data1', 'unvault_secret1') == 'unvault_data1')
    assert(do_unvault(None, None) == None)
    assert(do_unvault(False, False) == False)
    assert(do_unvault(True, True) == True)
    assert(do_unvault(Undefined(), Undefined()) == Undefined())

    try:
        do_unvault(None, None, 'unvault_vaultid1')
    except AnsibleFilterTypeError as e:
        assert(str(e) == "Secret passed is required to be as string, instead we got: <class 'NoneType'>")
    except Exception as e:
        assert(str(e) == "Unhandled exception in unvault")


# Generated at 2022-06-25 09:19:01.264175
# Unit test for function do_vault
def test_do_vault():
    filter_module_0 = FilterModule()

    data = 'test_value_0'

    secret = 'test_value_1'

    salt = 'test_value_2'

    vaultid = 'test_value_3'

    wrap_object = True

    result = filter_module_0.filters()['vault'](data, secret, salt, vaultid, wrap_object)
    print()
    print("ACTUAL RETURNED RESULT: " + str(result))



# Generated at 2022-06-25 09:19:12.457754
# Unit test for function do_vault
def test_do_vault():
    # Testing with string secret
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)

# Generated at 2022-06-25 09:19:21.467572
# Unit test for function do_vault