

# Generated at 2022-06-25 09:09:31.853615
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import string_types
    from ansible.modules.crypto.hash import _digest_methods


# Generated at 2022-06-25 09:09:42.171150
# Unit test for function do_unvault

# Generated at 2022-06-25 09:09:51.173842
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(1, 2) == '1'

# Generated at 2022-06-25 09:10:01.610380
# Unit test for function do_vault
def test_do_vault():
    vd0 = do_vault("secret", "password")

# Generated at 2022-06-25 09:10:10.021692
# Unit test for function do_vault
def test_do_vault():

    do_vault_1 = do_vault(data="hello world", secret="MyVaultPassword", salt="SaltyVaultPassword")


# Generated at 2022-06-25 09:10:16.635990
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:26.929667
# Unit test for function do_unvault

# Generated at 2022-06-25 09:10:37.536549
# Unit test for function do_vault

# Generated at 2022-06-25 09:10:43.339965
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1 = FilterModule()
    assert filter_module_1.filters()['unvault'] is do_unvault
    assert type(filter_module_1.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256','ansible','filter_default')) == unicode
    assert isinstance(filter_module_1.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256','ansible','filter_default'), unicode)
    assert isinstance(filter_module_1.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256','ansible','filter_default'), unicode)

# Generated at 2022-06-25 09:10:47.835874
# Unit test for function do_unvault
def test_do_unvault():
    """ Test functionality of do_unvault """

    # Test with good values

# Generated at 2022-06-25 09:10:53.541463
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(do_vault('1', '2'), '2') == '1'

# Generated at 2022-06-25 09:11:00.212051
# Unit test for function do_unvault
def test_do_unvault():

    # case 0
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    assert var_1 == str_0



# Generated at 2022-06-25 09:11:09.383231
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:11:19.640444
# Unit test for function do_unvault
def test_do_unvault():
    # Test case: Password is not encrypted
    str_0 = 'password'
    var_0 = do_unvault(str_0, str_0)
    assert var_0 == str_0

    var_1 = do_vault(str_0, str_0)
    var_2 = do_unvault(var_1, str_0)
    assert var_2 == str_0

    # Test case: Password is not encrypted, secret is not matching
    str_1 = 'password'
    str_2 = 'password1'
    var_1 = do_unvault(str_1, str_2)
    assert var_1 == str_1


# Generated at 2022-06-25 09:11:27.360105
# Unit test for function do_unvault
def test_do_unvault():

    filtered = do_unvault("$ANSIBLE_VAULT;9.9;AES256\n61376234633838653835663732333663393735666163343838626434336333613237633361343034\n35363766303032356636393833656263326162323732356364633139613262623031393066343033\n6666666666666666666666666666666666666666666666666666666666666666666666666666\n6666666666666666666666666666666666666666666666666666666666666666666666666666\n666666666666", "test")

    assert filtered == "test"

    try:
        filtered = do_unvault("test", "test")
    except Exception:
        from traceback import print_exc
        print_exc()
        assert False

    assert filtered == "test"


# Generated at 2022-06-25 09:11:32.034314
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == None

# Generated at 2022-06-25 09:11:36.038925
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)

    test_case_1()
    test_case_2()


# Generated at 2022-06-25 09:11:39.056244
# Unit test for function do_unvault
def test_do_unvault():
    # This function is just a placeholder for unit tests
    # It should be implemented in the future
    pass

# Generated at 2022-06-25 09:11:50.850044
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'secret'
    str_1 = 'secret'
    var_0 = do_vault(str_0, str_1, '1', 'filter_default', False)

# Generated at 2022-06-25 09:11:52.635173
# Unit test for function do_vault
def test_do_vault():

    # Do the test
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)



# Generated at 2022-06-25 09:11:57.972655
# Unit test for function do_vault
def test_do_vault():
    display('Test 1')
    str_0 = 'password'
    secret_0 = 'password'
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(str_0, secret_0)


# Generated at 2022-06-25 09:12:04.919272
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = 'password'
        str_1 = 'foo'
        var_0 = do_unvault(str_0, str_1)
    except Exception as ex:
        var_1 = str(ex)
        print("An exception occurred: {}".format(var_1))
    else:
        var_0 = type(var_0)
        print("var_0: {}".format(var_0))


if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-25 09:12:14.640496
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    print(var_0)

# Generated at 2022-06-25 09:12:16.217561
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:12:26.451723
# Unit test for function do_vault
def test_do_vault():
    str_0 = b'password'
    var_0 = do_vault(str_0, str_0)
    str_1 = b'2.9.4'
    var_1 = do_vault(str_1, str_0)
    str_2 = ''
    try:
        var_2 = do_vault(str_2, str_0)
    except AnsibleFilterError:
        pass
    dict_0 = dict()
    dict_0['prompt'] = str_2
    dict_0['salt'] = var_1
    dict_0['confirm_prompt'] = str_2
    dict_0['keep_order'] = True
    dict_0['hide_input'] = True
    dict_0['replace'] = True
    dict_0['default'] = str_2


# Generated at 2022-06-25 09:12:34.361113
# Unit test for function do_vault
def test_do_vault():
    """Test Function do_vault
    """
    str_0 = 'password'
    str_1 = 'password'
    ret_0 = do_vault(str_0, str_1)

# Generated at 2022-06-25 09:12:37.231838
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    assert do_unvault(var_0, str_0) == str_0

# Generated at 2022-06-25 09:12:47.680357
# Unit test for function do_vault
def test_do_vault():
    # Get data for the tests
    data = get_test_data()

    for testcase in data:
        # Set the secret and salt values
        secret = testcase['secret']
        salt = testcase['salt']

        # Create the vault
        var_0 = do_vault(testcase['input'], secret, salt, vaultid='testcase_vault')

        # Check the vault string
        if var_0 != testcase['output']:
            raise AssertionError("Expected output: %s but got output: %s" % (testcase['output'], var_0))

        # Decrypt the vault
        var_1 = do_unvault(var_0, secret)

        # Check the decrypted vault string

# Generated at 2022-06-25 09:12:51.043253
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(do_vault('password', 'password'), 'password') == 'password'


# Generated at 2022-06-25 09:13:00.403543
# Unit test for function do_vault
def test_do_vault():
    test_str_vault = 'password'
    vault_str = do_vault(test_str_vault, test_str_vault)
    assert isinstance(vault_str, string_types)
    #assert vault_str == test_str_vault

    test_int_vault = 12345
    vault_int = do_vault(test_int_vault, test_str_vault)
    assert isinstance(vault_int, string_types)
    #assert vault_int == test_int_vault

    test_list_vault = [1, 'a', 2, 'b']
    vault_list = do_vault(test_list_vault, test_str_vault)
    assert isinstance(vault_list, string_types)
    #assert vault_list == test

# Generated at 2022-06-25 09:13:10.709787
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    str_1 = 'password'
    var_0 = do_vault(str_0, str_1)

# Generated at 2022-06-25 09:13:17.977263
# Unit test for function do_vault

# Generated at 2022-06-25 09:13:19.049250
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault('',0) == None)


# Generated at 2022-06-25 09:13:27.240205
# Unit test for function do_unvault
def test_do_unvault():
    # Test basic scenario with required parameters
    data = {
      "param_0": "param_0",
      "param_1": "param_1"
    }
    ansible_vault_encrypted_unicode_0 = do_vault(data, 'password')
    # Test basic scenario with required parameters and VaultLib
    vault_lib_0 = VaultLib()
    ansible_vault_encrypted_unicode_1 = do_vault(data, 'password', vault_lib=vault_lib_0)
    # Test basic scenario with required parameters and VaultLib and salt
    ansible_vault_encrypted_unicode_2 = do_vault(data, 'password', salt='salt', vault_lib=vault_lib_0)
    # Test basic scenario with required parameters and VaultLib and salt and wrap_object
   

# Generated at 2022-06-25 09:13:33.187811
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    str_1 = to_bytes('password')
    var = do_vault(str_0, str_1)
    assert type(var) == AnsibleVaultEncryptedUnicode


# Generated at 2022-06-25 09:13:40.945468
# Unit test for function do_vault
def test_do_vault():
    # Setup
    str_0 = 'password'
    # Run
    result = do_vault(str_0, str_0)
    # Verify

# Generated at 2022-06-25 09:13:46.000347
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(u'password', u'ANSIBLE_VAULT_SECRET_1') == u'$ANSIBLE_VAULT;1.2;AES256;ansible\n36396538303834313230326564346666616662346532616131653864663136386631323538636364\n323331323130610a3939363065653632613465373934643635653362326566336130666438633862\n30653966353430640a38333836363466306438663032626165663134353633643034393934346261\n653864666533623235\n'



# Generated at 2022-06-25 09:13:52.307354
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('password', 'password'), str) == True
    assert isinstance(do_vault('password', 'password'), unicode) == True
    assert isinstance(do_vault('password', 'password'), object) == False
    assert isinstance(do_vault('password', 'password', salt='a_salt'), str) == True
    assert isinstance(do_vault('password', 'password', salt='a_salt'), unicode) == True
    assert isinstance(do_vault('password', 'password', salt='a_salt'), object) == False



# Generated at 2022-06-25 09:13:53.272801
# Unit test for function do_vault
def test_do_vault():
    assert test_case_0() is None

# Generated at 2022-06-25 09:14:04.425062
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    var_1 = '$ANSIBLE_VAULT;1.1;AES256\n35623363313463343431343534613033623438633632396264386633643735366261393833383435\n39393664303531323561356665306334313564666666646565663833343564303361626439393564\n6664363039376163623332303065666330313032363036353032333363663613266386231333166\n6532646530346362656139663331633663623233316336\n'
    # assert var_0 == var_1
    str

# Generated at 2022-06-25 09:14:10.452727
# Unit test for function do_vault
def test_do_vault():
    print('Test vaults.py do_vault')
    test_case_0()

if __name__ == '__main__':
    test_do_vault()

# Generated at 2022-06-25 09:14:14.363837
# Unit test for function do_vault
def test_do_vault():
    # Test only runs when pytest is installed
    try:
        import pytest
        # No arguments have been provided, so assign default values
        pytest.main()
    except ImportError:
        pass

# Generated at 2022-06-25 09:14:23.687060
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    str_1 = '$ANSIBLE_VAULT;1.1;AES256;default\n' \
            '30636464343635643038396235326661613461333532666364333331393262623461633335643630\n' \
            '31366461306134663430393737346464\n'
    str_2 = 'password'
    var_1 = do_unvault(str_1, str_2)
    assert var_1 == str_0


# Generated at 2022-06-25 09:14:33.540015
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    str_1 = 'password'
    str_2 = 'password'
    str_3 = 'password'
    str_4 = 'password'
    str_5 = 'password'
    str_6 = 'password'
    str_7 = 'password'
    str_8 = 'password'
    str_9 = 'password'
    str_10 = 'password'
    str_11 = 'password'
    str_12 = 'password'
    str_13 = 'password'
    str_14 = 'password'
    str_15 = 'password'
    str_16 = 'password'
    str_17 = 'password'
    str_18 = 'password'
    str_19 = 'password'
    str_20 = 'password'
    str_21 = 'password'
   

# Generated at 2022-06-25 09:14:45.816198
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:14:54.986677
# Unit test for function do_unvault

# Generated at 2022-06-25 09:14:58.812311
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    str_1 = 'abcdefghijklmnop'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_1)
    assert str_0 == var_1


# Generated at 2022-06-25 09:15:01.717454
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault('password', 'password') is not None)


# Generated at 2022-06-25 09:15:05.874669
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    var_0 = do_unvault(var_0, str_0)

# Generated at 2022-06-25 09:15:15.772173
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = 'password'
        var_0 = do_vault(str_0, str_0)
    except Exception as e:
        print("Exception in do_vault: %s" % str(e))
    else:
        try:
            var_1 = do_unvault(var_0, str_0)
        except Exception as e:
            print("Exception in do_unvault: %s" % str(e))
        else:
            print(str(var_1))


# Generated at 2022-06-25 09:15:29.660181
# Unit test for function do_vault

# Generated at 2022-06-25 09:15:36.583024
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'password'
    var_1 = do_vault(str_1, str_1)
    assert var_1 != str_1
    assert is_encrypted(var_1)

    str_2 = 'password'
    var_2 = do_vault(str_2, str_2, wrap_object=True)
    assert is_encrypted(var_2)
    assert var_2.data != str_2


# Generated at 2022-06-25 09:15:45.626978
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'test'
    str_1 = '$ANSIBLE_VAULT;'
    str_1 += '1.1;'
    str_1 += 'AES256'
    str_1 += '336438313531656332326432323139613561336333666534663332303636326637643064636'
    str_1 += '331323065643565666467306665353736646530383166353839346234336664353332626334'
    str_1 += '663635396630643465653932336639666137393563383062626261316636306130356566376'
    str_1 += '1386237653962302'
    str_2 = 'password'
    var

# Generated at 2022-06-25 09:15:51.948833
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'This is a test'
    str_1 = 'This is secret'
    vaultid = 'testid'
    ret = do_unvault( do_vault(str_0, str_1, salt=None, vaultid=vaultid), str_1, vaultid=vaultid)
    print(ret)

if __name__ == '__main__':
    test_case_0()
    test_do_unvault()

# Generated at 2022-06-25 09:15:58.406180
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = 'password'
        var_0 = do_unvault(str_0, str_0)
        return var_0
    except Exception as e:
        display.error("Unable to execute test: " + str(e))
        return False


# Generated at 2022-06-25 09:16:00.588345
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    print(var_0)



# Generated at 2022-06-25 09:16:10.950970
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    str_1 = 'password'
    vault_0 = do_vault(str_0, str_1)

# Generated at 2022-06-25 09:16:17.383853
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    assert not var_0
    str_1 = 'password'
    str_2 = 'password'
    var_1 = do_vault(str_1, str_2, None, 'filter_default', True)
    assert var_1
    str_3 = 'password'
    str_4 = 'password'
    var_2 = do_vault(str_3, str_4)
    assert var_2
    str_5 = 'password'
    str_6 = 'password'
    var_3 = do_vault(str_5, str_6, None, 'filter_default', True)
    assert var_3


# Generated at 2022-06-25 09:16:28.562356
# Unit test for function do_unvault
def test_do_unvault():
    # Specifying str_0 and str_1 as a list
    str_0 = ['filter_default', 'password']
    str_1 = 'filter_default!vault-kUxz6Uc0fXGgr6-L7RQMIQ'

    # Returns the value returned by function do_unvault
    ans = do_unvault(str_1, str_0)

    # Returns the value returned by function do_vault
    test_var = do_vault('password', 'password')

    # Asserts the value of ans is equal to value of test_var
    assert test_var == ans

# Test function do_vault passing 'password' and 'password'

# Generated at 2022-06-25 09:16:39.187139
# Unit test for function do_unvault

# Generated at 2022-06-25 09:16:45.069024
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'
    data = 'foo'
    vault = do_vault(data, secret)
    decrypted = do_unvault(vault, secret)

    assert decrypted == data



# Generated at 2022-06-25 09:16:48.094763
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)


# Generated at 2022-06-25 09:16:51.983001
# Unit test for function do_vault
def test_do_vault():

        # Test case 0
        str_0 = 'password'
        var_0 = do_vault(str_0, str_0)

        # Test case 1
        str_0 = 'password'
        var_0 = do_vault(str_0, str_0)

        # Test case 2
        str_0 = 'password'
        var_0 = do_vault(str_0, str_0)

        # Test case 3
        str_0 = 'password'
        var_0 = do_vault(str_0, str_0)




# Generated at 2022-06-25 09:17:02.584285
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:09.920991
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:13.376960
# Unit test for function do_vault
def test_do_vault():
    str_in_0 = 'password'
    str_in_1 = 'password'
    res = do_vault(str_in_0, str_in_1)
    assert str_in_0 == res



# Generated at 2022-06-25 09:17:18.461848
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;6$vslPPFsc0C7RFwn8$lJf0vxfe0b4V4PK4e4hZ2dv0TJTtT/mKLwP/Q2Stmvs', 'secret', 'filter_default') == 'password'



# Generated at 2022-06-25 09:17:27.469866
# Unit test for function do_unvault
def test_do_unvault():
    # Try to decrypt a string
    str_0 = 'password'
    unvault0 = do_vault(str_0, str_0)
    unvault1 = do_unvault(unvault0, str_0)
    assert unvault1 == 'password'
    # Try to decrypt an AnsibleVaultEncryptedUnicode object
    str_0 = 'password'
    unvault0 = do_vault(str_0, str_0, wrap_object=True)
    unvault1 = do_unvault(unvault0, str_0)
    assert unvault1 == 'password'
    # Try to decrypt a non-string

# Generated at 2022-06-25 09:17:29.419873
# Unit test for function do_vault
def test_do_vault():
    # ------------------------------------------------------------------
    # Test Variant:
    #   Parameter: str_0 = 'password'
    test_case_0()
# END OF FILE

# Generated at 2022-06-25 09:17:30.442240
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault(str, str)) == str


# Generated at 2022-06-25 09:17:40.861376
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'password'
    str_1 = '$ANSIBLE_VAULT;1.1;AES256'
    str_2 = '356639633564663162656263303562623763633634386233653036393539613835623137663732'
    str_3 = '643935363932656536643735656438343462636161313533663739386633323932666564393031'
    str_4 = '393533626264636561333963383565396634346439646361633365366466353464303665646635'

# Generated at 2022-06-25 09:17:48.155865
# Unit test for function do_unvault

# Generated at 2022-06-25 09:17:49.530503
# Unit test for function do_unvault
def test_do_unvault():
    assert False, "Unit test for function test_do_unvault"


# Generated at 2022-06-25 09:17:53.673280
# Unit test for function do_vault
def test_do_vault():
    test_case_0()

# Generated at 2022-06-25 09:17:54.767957
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:18:03.282538
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('password', 'password') == '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-25 09:18:05.125986
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    assert var_0, 'assertion failed'


# Generated at 2022-06-25 09:18:13.904689
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'password'
    str_2 = 'password'
    var_1 = do_vault(str_1, str_2)

# Generated at 2022-06-25 09:18:24.629498
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'password'
    var_0 = do_vault(str_0, str_0)
    assert type(var_0) == str
    assert var_0 == "$ANSIBLE_VAULT;1.1;AES256\n6133653365653535623531633231306638653630366463366262613230303534666135313531653235\n30366136343936376631323365303861623966303838623135613431340a3735363462616338316361\n373837353363313737626261323231663565396234633863306266326236363062366231653663656\n62353436666132313264313031346230\n"

# Unit test

# Generated at 2022-06-25 09:18:29.766748
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'password'
    data = 'secret'
    vault_str = do_vault(data, secret)
    assert vault_str != data
    assert do_unvault(vault_str, secret) == data



# Generated at 2022-06-25 09:18:39.362437
# Unit test for function do_vault
def test_do_vault():

    # test:
    result = do_vault('password', 'password')
    assert type(result) == str

# Generated at 2022-06-25 09:18:49.207163
# Unit test for function do_unvault
def test_do_unvault():
    # First test for all the cases where data is not encrypted,
    # and both argument and return type can be a string or unicode.
    # Case 0: input is of type string and output will also be a string
    str_0 = 'password'
    var_0 = do_unvault(str_0, str_0)
    assert isinstance(var_0, str)
    assert var_0 == str_0

    # Case 1: input is of type unicode and output will also be a unicode
    uni_0 = u'password'
    var_1 = do_unvault(uni_0, uni_0)
    assert isinstance(var_1, six.text_type)
    assert var_1 == uni_0

    # Case 2: input is of type unicode and output will be a string
   

# Generated at 2022-06-25 09:18:55.993631
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'plaintext'
    str_1 = 'password'
    var_0 = do_vault(str_0, str_1, salt='super_secret_salt', vaultid='test_do_vault')

# Generated at 2022-06-25 09:19:06.083462
# Unit test for function do_vault
def test_do_vault():

    secret = 'password'
    data = 'mysecret'
    vault = do_vault(data, secret)
    assert not is_encrypted(data)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == data

    secret = 'password'
    data = 'mysecret'
    vault = do_vault(data, secret, wrap_object=True)
    assert not is_encrypted(data)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == data

    secret = 'password'
    data = Undefined()
    assert do_vault(data, secret) == data

    assert do_vault("string", None) == "string"
    display.vv("Passed vault tests")



# Generated at 2022-06-25 09:19:14.535241
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault('password', 'password'), str)
    assert isinstance(do_vault('password', 'password', salt=None, vaultid='filter_default', wrap_object=False), str)
    assert isinstance(do_vault('password', 'password', salt=None, vaultid='filter_default', wrap_object=True), AnsibleVaultEncryptedUnicode)
    assert isinstance(do_vault('password', 'password', salt=None, vaultid='filter_default', wrap_object=True), AnsibleVaultEncryptedUnicode)
    assert isinstance(do_vault('password', 'password', salt=None, vaultid='filter_default', wrap_object=True), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-25 09:19:22.997464
# Unit test for function do_vault