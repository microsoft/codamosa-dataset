

# Generated at 2022-06-25 09:09:23.086535
# Unit test for function do_vault
def test_do_vault():
    secret='Its a secret to everyone'
    data='This is my data'
    vault=do_vault(data,secret)


# Generated at 2022-06-25 09:09:31.550615
# Unit test for function do_unvault

# Generated at 2022-06-25 09:09:42.065697
# Unit test for function do_vault

# Generated at 2022-06-25 09:09:44.956066
# Unit test for function do_unvault
def test_do_unvault():
    input = "this is a secret!"
    secret = "this is the secret!"
    result = do_unvault(input, secret)
    assert result == "this is a secret!"


# Generated at 2022-06-25 09:09:52.434577
# Unit test for function do_vault
def test_do_vault():
    args = {}
    cur_args = {}
    cur_args['data'] = 'test'
    cur_args['secret'] = 'secret'
    cur_args['salt'] = 'salt'
    cur_args['vaultid'] = 'filter_default'
    cur_args['wrap_object'] = False
    args['cur_args'] = cur_args

# Generated at 2022-06-25 09:09:57.409263
# Unit test for function do_unvault
def test_do_unvault():
    secret = "abc"
    vaultid = "filter_default"
    vault = "U2FsdGVkX1+6i4fI4Za3qH/wJiU/GcMB+oBz01Ih1pk="
    data = "test"
    assert do_unvault(vault, secret, filter_default) == data


# Generated at 2022-06-25 09:10:08.224530
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('secret', 'secret', None, 'filter_default', False) == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          63346237643230663762306164653566376132353633343539343731326530643536653965333062\n          6162313137656262636634353131623963366466353036383164340a353634666365323237363539\n          64333835653437646563376266626433333432613634636531643032376365623137323064356537\n          34373532356133646531390a".replace(" ", "")


# Generated at 2022-06-25 09:10:11.658287
# Unit test for function do_unvault
def test_do_unvault():
    filter_module_1 = FilterModule()
    data = 'ansible'
    secret = 'test'
    vault = filter_module_1.filters()['vault'](data, secret)
    assert(data == filter_module_1.filters()['unvault'](vault, secret))


# Generated at 2022-06-25 09:10:22.965224
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n63336131303235393238316665643663343964303533643632303132336632306262666133386130\n34653763396139373062633264316637333936356330303166613261366139623639383463323163\n35653339303337303564313664666666306536626132313661303365313137373639306431383061\n353066666164323137623661623266613263656665616430383638393463\n'
    real_result = 'sensitive information'
    assert do_unvault(secret, secret) == real_result, 'Test failed'



# Generated at 2022-06-25 09:10:34.868029
# Unit test for function do_unvault
def test_do_unvault():
    # testing functions are run.
    assert True

    vault_id = 'filter_default'
    secret = 's3cr3t'

    unvaulted_data0 = "hello"
    vaulted_data0 = do_vault(data = unvaulted_data0, secret = secret, salt = None, vaultid = vault_id, wrap_object = True)  # AnsibleVaultEncryptedUnicode
    unvaulted_data1 = do_unvault(vault = vaulted_data0, secret = secret, vaultid = vault_id)
    assert (unvaulted_data0 == unvaulted_data1)

    unvaulted_data0 = "world"

# Generated at 2022-06-25 09:10:38.025345
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("mysecret", "mysecret")
    assert isinstance(result, string_types)


# Generated at 2022-06-25 09:10:46.402824
# Unit test for function do_vault
def test_do_vault():
    # with pytest.raises(AnsibleFilterTypeError) as excinfo:
    #     do_vault('ABC', '123')
    # assert str(excinfo.value) == 'Secret passed is required to be a string, instead we got: <class \'str\'>'

    # with pytest.raises(AnsibleFilterTypeError) as excinfo:
    #     do_vault('ABC', '123', wrap_object=True)
    # assert str(excinfo.value) == 'Secret passed is required to be a string, instead we got: <class \'str\'>'

    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        do_vault(123, '123')

# Generated at 2022-06-25 09:10:57.249981
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('abc','secret') == '$ANSIBLE_VAULT;1.1;AES256\n39363761353830386430333964343566633861303139633035346433373464383433613632363561\n3962366162393162626431653635396635333433316435303532613462313036610a383062396139\n64663435313761663236616137633633386330623962643362366464663737643066656433663864\n633164633132363962373365396164623831626533386636353966303633666435\n'


# Generated at 2022-06-25 09:10:58.419245
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('string', 'string', 'string', 'string', False) is None


# Generated at 2022-06-25 09:11:01.857614
# Unit test for function do_vault
def test_do_vault():
    """ Test cases for do_vault """

    # TODO
    assert False



# Generated at 2022-06-25 09:11:08.793885
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(u'$ANSIBLE_VAULT;1.1;AES256;ansible\r\n3438663335653831616236643465316331323063656537636266623735346639393033653531\r\n6631383034376638353833323165323334353334306436663935376633383761626262316537\r\n643465613739333465643635666435383264313363633561626262316500\r\n', u'ansible') == 'Hello World'


# Generated at 2022-06-25 09:11:14.362887
# Unit test for function do_vault
def test_do_vault():
    from jinja2.undefined import Undefined as jinja2_undefined
    # Test with correct parameters

# Generated at 2022-06-25 09:11:22.865118
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("password", "secret", salt="salt", vaultid='filter_default', wrap_object=False) == "$ANSIBLE_VAULT;1.1;AES256;filter_default;salt;\n39663961333362626435623261396139313761333962333262643562396433316464643466646\n353363636232356439343362333136313562326239333562663161343464373130643037643338\ntest"


# Generated at 2022-06-25 09:11:23.745204
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault="test", secret="test") == ""


# Generated at 2022-06-25 09:11:30.989757
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == ('$ANSIBLE_VAULT;1.1;AES256;filter_default\n3933323866386561633933633139663962643431386138653134363735373834666262613837\n30373732313331316138363866393565636231620a6234363033656531326337366137613339\n3933633139663962643431386138653134363735373834666262613837653734393161326531\n623132336562666562320a') is not None


# Generated at 2022-06-25 09:11:44.507278
# Unit test for function do_vault
def test_do_vault():
    salt = None
    secret = 'secret'
    data = 'data'
    vaultid = 'vaultid'
    wrap_object = False

    # Test with good data
    assert do_vault(data, secret) == '$ANSIBLE_VAULT;1.1;AES256\n653632386466376132306632326431313734646630656165326435623762363663383539363334\n34313737633539666162626631323963396633323037636239350a6166393436363365383935626\n3431666433633666313231396262326264323137643963353939623831663339336437376462390a\n'

    # Test with bad data

# Generated at 2022-06-25 09:11:54.194119
# Unit test for function do_unvault
def test_do_unvault():
    # Note this should fail for the reasons mentioned in the bugs
    # https://github.com/ansible/ansible/issues/59539
    # https://github.com/ansible/ansible/issues/59512

    # When input is a string
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)

    assert var_1 == str_0

    # When input is a dict
    dict_0 = {'my_plaintext': 'mysecret'}
    var_0 = do_vault(dict_0, str_0)
    var_1 = do_unvault(var_0, str_0)

    assert var_1 == dict_0

    # When input is

# Generated at 2022-06-25 09:11:57.449268
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == "$ANSIBLE_VAULT;"


# Generated at 2022-06-25 09:11:59.203497
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('mysecret', 'mysecret') == 'mysecret'


# Generated at 2022-06-25 09:12:00.853855
# Unit test for function do_vault
def test_do_vault():
    assert isinstance(do_vault("test", "password"),str)


# Generated at 2022-06-25 09:12:12.874702
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n633237353234303766663239343639333238326135613661613939663531316436623938346536\n343435366437353163336236633635396664343539643538646338323630643536666438386265\n616561623561333164343335386637646462313361343064346533643537306431666638643863\n38353162653666316265323966363166636537393034383137623232616238646662333432336c\n6266366634356431\n', 'mysecret') == 'mysecret')



# Generated at 2022-06-25 09:12:15.057582
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    str_1 = 'mysecret'
    var_1 = do_vault(str_1, str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 09:12:20.108008
# Unit test for function do_unvault
def test_do_unvault():
    try:
        str_0 = 'mysecret'
        var_0 = do_unvault(var_0, str_0)
    except Exception as e:
        display.error(str(e))
        raise e
    else:
        display.display("do_unvault ran successfully")



# Generated at 2022-06-25 09:12:29.023046
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    str_1 = 'mysecret'
    var_0 = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256\n38373365363864643136386433343132623962366431616637323666633136613665396430366564\n35326466333536353563393834396161393539623463363663306635633262623431316231636236\np1IwTkMnTJGoK+vT8TgWQQ==\n')
    var_1 = do_vault(str_0, str_1)
    assert var_0 == var_1


# Generated at 2022-06-25 09:12:32.536604
# Unit test for function do_vault
def test_do_vault():

    str_0 = 'mysecret'
    str_1 = ''
    str_2 = 'mysecret'
    var_0 = do_vault(str_0, str_1)
    var_1 = do_vault(str_0, str_2)
    assert var_0 == var_1


# Generated at 2022-06-25 09:12:42.813285
# Unit test for function do_vault
def test_do_vault():
    salt = '3qfklkzvkngldimh0w5e'
    str_0 = 'mysecret'
    str_1 = 'mysecret with salt'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256'
    var_1 = do_vault(str_1, str_0, salt=salt)
    assert var_1 == '$ANSIBLE_VAULT;1.1;AES256'


# Generated at 2022-06-25 09:12:50.688323
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256\n35643162626139623664326537346564316265336433623264313536656133613666323239326165\n39393336353131623962333063353762353166633830313161353131623861663037393365313965\n323538376639306331303637363738343866373232202f2beb9a29ba23a822f39b5536a24c53\nzfxv7xg==\n'


# Generated at 2022-06-25 09:13:00.483293
# Unit test for function do_vault
def test_do_vault():
    var_0 = 'mysecret'
    var_1 = 'mysecret'
    var_2 = None
    var_3 = 'filter_default'
    var_4 = False
    str_0 = 'mysecret'

    do_vault(str_0, var_1)
    var_5 = do_vault(var_0, var_1, var_2, var_3, var_4)

    do_vault('source', '{{secret}}')
    do_vault('source', '{{secret}}', '{{salt_0}}', '{{vaultid}}', True)
    do_vault('10', '{{secret_0}}')
    do_vault('10', '{{secret_0}}', '{{salt_0}}', '{{vaultid}}', True)
    do_v

# Generated at 2022-06-25 09:13:10.443315
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    test_case_0()

    # Test case when passing invalid type
    input_0 = None
    secret_0 = None
    vaultid_0 = 'filter_default'
    try:
        do_unvault(input_0, secret_0, vaultid_0)
    except AnsibleFilterTypeError as e:
        assert(e.msg == "'NoneType' was passed to unvault but can only be of type 'str'")

    # Test case when passing invalid type
    input_1 = None
    secret_1 = 'secret'
    vaultid_1 = 'filter_default'

# Generated at 2022-06-25 09:13:17.842144
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:24.328339
# Unit test for function do_unvault

# Generated at 2022-06-25 09:13:25.402667
# Unit test for function do_vault
def test_do_vault():
    print("Test do_vault ...")
    test_case_0()
    print("")



# Generated at 2022-06-25 09:13:30.445684
# Unit test for function do_unvault
def test_do_unvault():
    assert display.display(do_unvault(vault, secret, vaultid='filter_default')) is None
    assert display.display(do_unvault(vault, secret, vaultid='filter_default')) is None



# Generated at 2022-06-25 09:13:38.939794
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:13:44.719206
# Unit test for function do_vault
def test_do_vault():
    # Make sure it is returning the correct value
    assert do_vault('mysecret', 'mysecret')
    # Make sure it has the correct type
    assert isinstance(do_vault('mysecret', 'mysecret'), string_types)



# Generated at 2022-06-25 09:14:00.520840
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256\n393064393038333266623664653639646631343465323562613231333961623663316236303662323\n63383064383935363835386661336263313365306636653166650a39393438333031303735363132\n3231386533343261653038653163666333393331653562383930343331363336343730393230353837\n32386164353735346466300a'
    str_1 = 'myvault'

# Generated at 2022-06-25 09:14:02.504314
# Unit test for function do_unvault
def test_do_unvault():
    ret_val = do_unvault('')
    assert isinstance(ret_val, str) or isinstance(ret_val, Undefined)
    assert ret_val == ''

# Generated at 2022-06-25 09:14:06.673113
# Unit test for function do_vault
def test_do_vault():
    assert callable(do_vault), "Filter 'do_vault' is not callable"
    try:
        # Call the filter function
        do_vault('mysecret', 'mysecret')
    except:
        pass


# Generated at 2022-06-25 09:14:16.751776
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    str_1 = 'mysecret'
    var_0 = do_vault(str_0, str_1)
    assert var_0 == '$ANSIBLE_VAULT;1.1;AES256;tester\n62363739373532393636383032316339626462383261353863323337353363316636353266663436\n30616366376431393166626264623237623763616661376562343664390a63353165623065333865\n34653933666433356664353866393635373938326164333363353465323035343764376261666130\n663261633335336232666437626532613062360a'


# Generated at 2022-06-25 09:14:24.063854
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = 'mysecret'
    str_2 = '$ANSIBLE_VAULT;1.1;AES256;mysecret63273663656366383961313064386335346332383262613466313338323233653466656436613064333336393061306331636237383066666663386634386264373061633966323032396139343762646436306237633133336530313762626132353162363734663835643766326532353131306536363061303331636166373233376238313333383533653462376634313935633037383038333934323732323230626536333839373438373833'
    var_1 = do_unv

# Generated at 2022-06-25 09:14:33.871749
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    str_1 = 'vaulted'
    var_1 = do_vault(str_1, str_0)
    str_2 = 'vaulted'
    var_2 = do_vault(str_2, str_0)
    assert var_0 != None
    assert var_1 != None
    assert var_2 != None
    assert str_1 != var_1
    assert str_2 != var_2
    assert var_1 != var_2
    str_3 = 'mysecret'
    var_3 = do_unvault(var_2, str_3)
    assert var_3 == str_2

# Generated at 2022-06-25 09:14:46.175040
# Unit test for function do_vault
def test_do_vault():
    str_1 = 'mysecret'
    var_1 = '$ANSIBLE_VAULT;1.2;AES256;mysecret32937373564321462608580153398543476393066373633727\
633613365356339323165633962623333666439313561383034333934306266613163396138626464\
6363613061643465666439306564653834393330666566613462333030326464366139366432636232\
66393235376366336323400000000000000000000000000000000000000000000000000000000000000\
00000000000000000'
    var_2 = do_unvault(var_1, str_1)
    print("var_2")
    print(var_2)
    print("str_1")

# Generated at 2022-06-25 09:14:50.830730
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    str_1 = do_vault(str_0, str_0)
    str_2 = do_unvault(str_1, str_0)
    assert str_0 == str_2


# Generated at 2022-06-25 09:14:57.646079
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

    # AssertionError: AssertionError: 'Encrypted vault' != '$ANSIBLE_VAULT;1.1;AES256;filter_default\n643732666239303761386433353464303330613938353864303762373165343664656635333466\n633132376637653033373536366537303737623338636561666132653230626335356639383236\n373536616363353265323863353037376230313132613561373136616431366164613166393036\n32646431323664623363353739373766643039

# Generated at 2022-06-25 09:15:00.907639
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert isinstance(var_0, str)
    assert var_0
    try:
        str_0 = 'mysecret'
        var_0 = do_vault(str_0, str_0)
    except UndefinedError:
        assert True


# Generated at 2022-06-25 09:15:11.228917
# Unit test for function do_vault
def test_do_vault():
    # No param passed
    try:
        do_vault()
    except TypeError as e:
        assert "do_vault() missing 2 required positional arguments" in str(e)
    # 1 param passed, not enough
    try:
        do_vault("")
    except TypeError as e:
        assert "do_vault() missing 1 required positional argument" in str(e)
    # Make sure vault is a string
    try:
        do_vault(1, "")
    except AnsibleFilterTypeError:
        pass



# Generated at 2022-06-25 09:15:17.062846
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, str_0) == b'$ANSIBLE_VAULT;1.1;AES256\n31353737303436663230316666313862316564343031313733656665626165323632653836613231663\n66562613966643563303964356562306531353164356663323230633165353466323166313235633361\n636533363063356337653863303165666163313134666533\n'


# Generated at 2022-06-25 09:15:23.774494
# Unit test for function do_vault
def test_do_vault():
    assert len(do_vault(str_0, str_0)) == 28

# Generated at 2022-06-25 09:15:24.599978
# Unit test for function do_vault
def test_do_vault():
    test_case_0()


# Generated at 2022-06-25 09:15:27.237945
# Unit test for function do_vault
def test_do_vault():
    # Test case 0
    test_case_0()



# Generated at 2022-06-25 09:15:33.978498
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    str_1 = do_vault(str_0, str_0)
    str_2 = '$ANSIBLE_VAULT;1.1;AES2563938074602345893456783456784356784356728345738456783425678'

# Generated at 2022-06-25 09:15:46.023380
# Unit test for function do_vault
def test_do_vault():
    var_1 = "mysecret"
    var_2 = do_vault(var_1, var_1)

# Generated at 2022-06-25 09:15:46.999863
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

# Generated at 2022-06-25 09:15:54.943807
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'

# Generated at 2022-06-25 09:15:58.522189
# Unit test for function do_vault
def test_do_vault():
    try:
        # Input parameters
        # Mandatory args
        str_0 = 'mysecret'
        var_0 = do_vault(str_0, str_0)

    except Exception as e:
        assert False, "Unable to run test case "


# Generated at 2022-06-25 09:16:11.526436
# Unit test for function do_unvault
def test_do_unvault():

    # Case # 0: Vaulted string
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    assert var_0 == do_unvault(var_0, str_0)

    # Case # 1: Vaulted unicode string
    str_1 = u'mysecret'
    var_1 = do_vault(u'mysecret', str_1)
    assert var_1 == do_unvault(var_1, str_1)

    # Case # 2: Unvaulted string
    str_2 = 'mysecret'
    var_2 = 'mysecret'
    assert var_2 == do_unvault(var_2, str_2)

    # Case # 3: Unvaulted unicode string

# Generated at 2022-06-25 09:16:17.118289
# Unit test for function do_vault
def test_do_vault():
    try:
        str_0 = 'mysecret'
        var_0 = do_vault(str_0, str_0)
        if var_0 != '$ANSIBLE_VAULT;1.1;AES256':
            raise AssertionError()
    except AssertionError:
        display.error('Expected values: test_do_vault')
        raise


# Generated at 2022-06-25 09:16:24.233300
# Unit test for function do_vault
def test_do_vault():
    try:
        str_0 = 'mysecret'
        var_0 = do_vault(str_0, str_0)
        var_1 = do_unvault(var_0, str_0)
        assert str_0 == var_1
    except BaseException as e:
        assert False, "Exception when calling the function do_vault: %s" % e


# Generated at 2022-06-25 09:16:29.982774
# Unit test for function do_vault
def test_do_vault():
    assert AnsibleFilterTypeError is not None
    assert AnsibleFilterError is not None
    assert AnsibleVaultEncryptedUnicode is not None
    assert Display is not None
    assert VaultLib is not None
    assert VaultSecret is not None
    assert is_encrypted is not None
    assert to_native is not None
    assert to_bytes is not None
    assert test_case_0 is not None


# Generated at 2022-06-25 09:16:41.009196
# Unit test for function do_unvault

# Generated at 2022-06-25 09:16:47.743619
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    dict_0 = dict()
    dict_1 = dict()
    dict_0['string'] = str_0
    dict_0['integer'] = 10
    dict_0['float'] = 8.7
    dict_0['bool'] = True
    dict_0['list'] = [1, 2, 3, 4]
    dict_0['dict'] = dict_1
    dict_1['foo'] = 'bar'
    dict_1['blah'] = 4
    dict_0['url'] = 'https://www.ansible.com/'

    for key in dict_0.keys():
        val = dict_0[key]
        if isinstance(val, (string_types, binary_type)):
            str_1 = do_vault(val, str_0)


# Generated at 2022-06-25 09:16:52.055376
# Unit test for function do_unvault
def test_do_unvault():
    str_1 = 'mysecret'
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_0 = do_unvault(var_0, str_1)
    print('var_0', var_0)
    assert var_0 == str_0

# TESTCASE_1: Testing function do_unvault
# Case 1: testing basic do_unvault function

# Generated at 2022-06-25 09:17:02.665767
# Unit test for function do_vault

# Generated at 2022-06-25 09:17:06.504084
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_1 = '$ANSIBLE_VAULT;1.1;AES256'
    assert isinstance(var_0, str) and var_1 in var_0, 'Expected var_0 to contain var_1.'


# Generated at 2022-06-25 09:17:12.580060
# Unit test for function do_vault
def test_do_vault():
    display.display("do_vault test")

    # Get secret
    secret = 'mysecret'

    # Encrypt the secret
    var_0 = do_vault(secret, secret)

    # Decrypt the encrypted secret
    var_1 = do_unvault(var_0, secret)

    # Verify
    if secret == var_1:
        display.display("SUCCESS")
    else:
        display.display("FAILURE")


# Generated at 2022-06-25 09:17:22.667566
# Unit test for function do_vault
def test_do_vault():
    assert True


# Generated at 2022-06-25 09:17:30.820430
# Unit test for function do_vault
def test_do_vault():
    data = 'mysecret'
    secret = 'mysecret'
    output = do_vault(data, secret)

# Generated at 2022-06-25 09:17:32.318063
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    var_0 = do_unvault(str_0, str_0)

# Generated at 2022-06-25 09:17:34.847869
# Unit test for function do_vault
def test_do_vault():
    # Verify function returns an object with type AnsibleVaultEncryptedUnicode
    assert (type(do_vault('test_value', 'test_secret')) == AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-25 09:17:36.411211
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)



# Generated at 2022-06-25 09:17:40.053627
# Unit test for function do_vault
def test_do_vault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)

    assert var_0 != 'mysecret'
    if var_0 == 'mysecret' :
        print("Error do_vault")


# Generated at 2022-06-25 09:17:50.309067
# Unit test for function do_vault
def test_do_vault():
    hs = 'SHA256:ZgMcf87uVHs8bEwNp/1MjKSB/oN0H/xQxX9gOv/1jIc='
    assert '$ANSIBLE_VAULT;' in do_vault('mysecret', 'mysecret')
    assert '"mysecret"' in do_unvault(do_vault('mysecret', 'mysecret'), 'mysecret')
    assert '"{$ANSIBLE_VAULT;' in do_vault('{mysecret}', 'mysecret')
    assert '"{mysecret}' in do_unvault(do_vault('{mysecret}', 'mysecret'), 'mysecret')
    assert '"^ANSIBLE_VAULT;' in do_vault('=mysecret=', 'mysecret')
   

# Generated at 2022-06-25 09:17:56.898839
# Unit test for function do_vault
def test_do_vault():
    # unit test
    try:
        assert(str(test_case_0()) == '$ANSIBLE_VAULT;1.1;AES256')
    except AssertionError as e:
        display.warning("Test case failed: {}".format(e))



# Generated at 2022-06-25 09:18:06.805073
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)

    # issue #27885 - should catch and raise exception on unencryptable input
    try:
        var_2 = do_unvault('invalid_encryption_string', str_0)
        assert False
    except AnsibleFilterError:
        assert True
    try:
        var_3 = do_unvault(123, str_0)
        assert False
    except AnsibleFilterTypeError:
        assert True
    try:
        var_3 = do_unvault(123, 123)
        assert False
    except AnsibleFilterTypeError:
        assert True


# Generated at 2022-06-25 09:18:08.302996
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(unicode, unicode) == unicode


# Generated at 2022-06-25 09:18:20.523124
# Unit test for function do_vault
def test_do_vault():
    try:
        assert(test_case_0())
    except AssertionError as e:
        raise AssertionError(str(e))

# Test Cases for function do_vault
test_cases = [
    (["This is a secret"], "mysecret", ""),
    (["This is a secret"], "mysecret", "0123456789abcdef"),
]


# Generated at 2022-06-25 09:18:29.063970
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          61626134623165623931633665643833623436366638356532396530663630333734306264346665\n          32303366343139653435386163626266313931666232316165333539663264303438363865393430\n          3638323137363336353466333037650a\n', 'Failed to match expected value'



# Generated at 2022-06-25 09:18:36.327455
# Unit test for function do_vault
def test_do_vault():
    salt = '$ANSIBLE_VAULT;9.9;AES256'
    secret = 'vault_password'
    data_0 = 'mysecret'
    var_0 = do_vault(data_0, secret=secret, salt=salt)
    expected_0 = '$ANSIBLE_VAULT;9.9;AES256\n633531346335383165313234633037326562626666666239316436653930633365343337666264326233\n3538323834336166376534393133623561613965363461633234313536343331356536323531323335\n33356662646330633066346437653636393766383438333436626635'
    assert var_0 == expected_0

# Generated at 2022-06-25 09:18:38.837940
# Unit test for function do_unvault
def test_do_unvault():
    assert 'mysecret' == do_unvault(do_vault('mysecret', 'mysecret'))


# Generated at 2022-06-25 09:18:43.691889
# Unit test for function do_unvault
def test_do_unvault():


    # Call method for testing
    str_0 = 'mysecret'
    var_0 = do_vault(str_0, str_0)
    var_1 = do_unvault(var_0, str_0)
    print("output: {}".format(var_1))

# Recreate function call

# Generated at 2022-06-25 09:18:48.451935
# Unit test for function do_vault
def test_do_vault():
    print('Start function test_do_vault')
    var_0 = '$ANSIBLE_VAULT;1.1;AES256;nelson 314331333464656235663531363263386266366462646631386135633463666630a313633646131613532343132386262653766353830336436353631333265633863306537386137613239623237626331383233653236613561366165350a3766663531366565323161353139636564323038643735653666636461666366336466336234626133386161343264383232333562663131623963343636'
    var_1 = 'mysecret'

# Generated at 2022-06-25 09:18:50.138817
# Unit test for function do_unvault
def test_do_unvault():
    str_0 = 'mysecret'
    out_0 = 'mysecret'
    assert do_unvault(str_0, str_0) == out_0


# Generated at 2022-06-25 09:18:51.565723
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(str_0, str_0) == var_0


# Generated at 2022-06-25 09:18:55.116616
# Unit test for function do_vault
def test_do_vault():
    test_case_0()

# Generated at 2022-06-25 09:19:05.606038
# Unit test for function do_vault