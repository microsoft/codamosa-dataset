

# Generated at 2022-06-23 10:05:29.458973
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()
    assert 'unvault' in filter_module.filters()



# Generated at 2022-06-23 10:05:30.646977
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:05:43.341858
# Unit test for function do_vault
def test_do_vault():
    my_filter = FilterModule()

# Generated at 2022-06-23 10:05:49.330204
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vaultid = "test_vaultid"
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, string_types)


# Generated at 2022-06-23 10:05:52.853019
# Unit test for function do_vault
def test_do_vault():

    assert isinstance(do_vault('test', 'secret'), string_types)
    assert isinstance(do_vault('test', 'secret', wrap_object=True), AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 10:06:03.018168
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six.moves import StringIO

    vault_data = u'vaulted_data'
    vault_secret = u'vault_secret'
    vault_salt = u'vault_salt'
    vault_id = u'filter_test'

    try:
        vault_encoded = do_vault(vault_data, vault_secret, vault_salt, vault_id)
    except TypeError:
        print("TypeError: secret passed is required to be as string")

    try:
        vault_encoded = do_vault([1, 2, 3, 4], vault_secret, vault_salt, vault_id)
    except TypeError:
        print("TypeError: can only vault strings")


# Generated at 2022-06-23 10:06:04.808830
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

  filters = FilterModule().filters()
  assert 'vault' in filters
  assert 'unvault' in filters


# Generated at 2022-06-23 10:06:12.773605
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    test_secrets = ["randompasswords", "hockeynight", "lacoste"]
    # test various things
    # test various things
    for s in test_secrets:
        for salt in ['', 'x', 'xxx']:
            for wrap in [True, False]:
                for id in ['default', 'vault1', 'vault2']:
                    vault = do_vault('bacon', s, salt=salt, vaultid=id, wrap_object=wrap)
                    data = do_unvault(vault, s, vaultid=id)
                    assert isinstance(data, basestring) and data == 'bacon'



# Generated at 2022-06-23 10:06:15.400565
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('foo', 'pass123')
    assert isinstance(result, string_types)


# Generated at 2022-06-23 10:06:18.530269
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    if filters['vault'] != do_vault:
        raise AssertionError("Failed to return filter do_vault")
    if filters['unvault'] != do_unvault:
        raise AssertionError("Failed to return filter do_unvault")

test_FilterModule()


# Generated at 2022-06-23 10:06:18.938698
# Unit test for constructor of class FilterModule
def test_FilterModule():
  pass


# Generated at 2022-06-23 10:06:26.831590
# Unit test for function do_unvault
def test_do_unvault():

    # Test data
    secret = 'VaultSecret'

# Generated at 2022-06-23 10:06:29.405553
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    :return: Unit test True or throw an error
    """
    fm = FilterModule()
    assert fm != None


# Generated at 2022-06-23 10:06:40.076740
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:41.474700
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:06:43.979317
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:06:51.275587
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import PY3

    v = do_vault('teststring', 'testsecret')

    assert isinstance(v, binary_type)
    assert v.startswith(to_bytes(b'$ANSIBLE_VAULT', encoding='utf-8')) and v.endswith(to_bytes(b'\n\n', encoding='utf-8'))

    uv = do_unvault(v, 'testsecret')
    if PY3:
        assert isinstance(uv, str)
    else:
        assert isinstance(uv, unicode)
    assert uv == 'teststring'

    # If provide an object of AnsibleVaultEncryptedUnicode
    v

# Generated at 2022-06-23 10:06:55.021271
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"

    # valid test
    vault = do_vault(data, secret)
    assert isinstance(vault, str)

    # invalid test
    secret = 1
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(data, secret)


# Generated at 2022-06-23 10:07:07.409535
# Unit test for function do_vault
def test_do_vault():
    from os import environ
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    with patch.dict(environ, ANSIBLE_VAULT_PASSWORD_FILE="/dev/null"):
        import ansible_collections.ansible.netcommon.plugins.filter.netcommon_vault as netcommon_vault
        netcommon_vault.default_vault = "/dev/null"


# Generated at 2022-06-23 10:07:10.395749
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = {
        'vault': do_vault,
        'unvault': do_unvault,
    }
    assert fm.filters() == filters


# Generated at 2022-06-23 10:07:16.677793
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_unvault = filters["unvault"]

# Generated at 2022-06-23 10:07:19.214546
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:07:20.244507
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm
    assert fm.filters

# Generated at 2022-06-23 10:07:32.125274
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('Abcdefg', 'secret') == b'$ANSIBLE_VAULT;1.2;AES256;ansible\r\n63323359666165656332366432616463306638613464663132336433366463331323430656638\r\n653162396633376137663830353264313166626338610a37623737353734313331653462616331\r\n3365311a3430313264303766363061643265303335656366343865623262666239386564373033\r\n6465303166373565343338\r\n'


# Generated at 2022-06-23 10:07:44.988166
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:07:49.147618
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # No test for 'vault' as it depends on VaultSecret which is not available
    # for the test.
    # No test for 'unvault' as it depends on VaultLib which is not available
    # for the test.
    return

# Generated at 2022-06-23 10:07:54.718829
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters.keys() ==  {'vault', 'unvault'}
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:08:03.067774
# Unit test for function do_unvault
def test_do_unvault():
    test_vault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          3831666565616237626664386135313762366338343831643061366666663137323262636465\n          63313239306232653861326138323566393332363634653766313000a356530383365343735\n          3862386161326363646236626466613433303230353937363865\n          "
    test_secret = 'test'
    assert do_unvault(test_vault,test_secret) == "test"

# Generated at 2022-06-23 10:08:04.010756
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:08:05.634622
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)


# Generated at 2022-06-23 10:08:14.345651
# Unit test for function do_vault
def test_do_vault():
  f = FilterModule()

# Generated at 2022-06-23 10:08:25.880417
# Unit test for function do_vault
def test_do_vault():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text

    secret = 'mysecret123'
    data = 'mydata_one_2'
    vault = do_vault(data, secret, wrap_object=True)

    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vaultid == 'filter_default'
    assert vault.data == data
    assert vault.vault.secrets == {'filter_default': VaultSecret(to_bytes(secret))}
    assert isinstance(vault.vault.secrets['filter_default'].bytes, binary_type)
    assert isinstance(vault.data, string_types)

# Generated at 2022-06-23 10:08:36.466993
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.unsafe_proxy import VaultSecret
    from ansible.vars.unsafe_proxy import VaultLib

    VS = VaultSecret("""$ANSIBLE_VAULT;1.1;AES256
64343136636166653931313231326235303364383137646231393231383766363634373865303241
3063666237376237633261626639613130306361373139310a663136356661303963656331666266
61393733326335313431363134613331363936366334323363386634653032376531336331393539
3764303565613339370a30653936663230396533373566383531656265373039
""")

   

# Generated at 2022-06-23 10:08:48.695428
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_native, to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import string_types, binary_type
    from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError
    from jinja2.runtime import Undefined
    import pytest

    # test 1, test case isinstance(secret, (string_types, binary_type, Undefined))
    secret = 123
    assert type(secret) == int
    assert type(secret) != str
    assert type(secret) != binary_type
    assert type(secret) != Undefined



# Generated at 2022-06-23 10:09:01.139694
# Unit test for function do_unvault
def test_do_unvault():
    secret = "hello world"
    vaultid = 'test'

# Generated at 2022-06-23 10:09:06.461286
# Unit test for function do_vault
def test_do_vault():
    import os

    def vault(data, secret):
        return do_vault(data, secret, wrap_object=True)

    assert vault("data", "")
    assert vault("data", os.environ.get('ANSIBLE_VAULT_PASSWORD'))
    assert vault("data", os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE'))


# Generated at 2022-06-23 10:09:13.784868
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import pytest
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Test for method do_vault
# Test case:
#   vault = do_vault(data, secret)
# Success scenario:
#   1. data and secret are both strings:
#       Return a string containing vaulted data
#   2. data is string, secret is None:
#       Return a string containing vaulted data
#   3. data is None, secret is string:
#       Return a string containing vaulted data
#   4. data and secret are both None:
#       Return a string containing vaulted data
#   5. data is string and secret is undefined:
#       Return a string containing vaulted data
#

# Generated at 2022-06-23 10:09:18.170261
# Unit test for function do_unvault
def test_do_unvault():
    secret = "foo"
    vault = do_vault("Hello world", secret)

    assert do_unvault(vault, secret) == "Hello world"

# Generated at 2022-06-23 10:09:31.079785
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n36356630363766366535656038613936393331613332326530663166393935633230313638653265\n36306633626139616237313439316633366462393833363132303937656534633130653566383532\n3863386634396364\n', 'test') == 'test'

# Generated at 2022-06-23 10:09:38.260181
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('password', 'secret', vaultid='filter_default', wrap_object=False) == '$ANSIBLE_VAULT;1.1;AES256\n35316631333236313233616266656563656339343735343835336566393737396234303363633363\n3626533633262633437343966373132663939373466376262666561643734393738303433311966\n66373339653731393834383334313961326662336562333961316266336233613430356165623665\n63633139346665336535626233366231383338643732323134386366376434373964326563313165\n'

# Generated at 2022-06-23 10:09:51.493366
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:55.460084
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Construct class object
    filter_module = FilterModule()

    # Assert filters are correctly added
    assert 'vault' in filter_module.filters()
    assert 'unvault' in filter_module.filters()


# Generated at 2022-06-23 10:10:06.838254
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:10:11.444674
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()


# Generated at 2022-06-23 10:10:15.433511
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    data = {
        'vault': do_vault,
        'unvault': do_unvault,
    }
    assert fm.filters() == data

# Generated at 2022-06-23 10:10:17.572431
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'unvault': do_unvault, 'vault': do_vault}



# Generated at 2022-06-23 10:10:31.364908
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    test_case = dict(
        description="Test AnsibleVaultEncryptedUnicode(value)",
        filters=filter_module.filters,
        # TODO: enable filters and secret values' test cases
        # test_cases=dict(
        #     vault=dict(
        #         data=None,
        #         secret=None,
        #         salt=None,
        #         vaultid='filter_default',
        #         wrap_object=False,
        #     ),
        #     unvault=dict(
        #         vault=None,
        #         secret=None,
        #         vaultid='filter_default',
        #     ),
        # ),
    )
    # import pudb; pu.db
    # 1/0
    # import pudb;

# Generated at 2022-06-23 10:10:32.510465
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)


# Generated at 2022-06-23 10:10:35.957902
# Unit test for function do_vault
def test_do_vault():
    secret = 'my-secret'
    data = 'my-data'
    ret = do_vault(data, secret)
    assert(ret[:7] == "$ANSIBLE")
    assert(ret[-1:] == '$')


# Generated at 2022-06-23 10:10:42.942359
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:45.853661
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.__class__ is FilterModule


# Generated at 2022-06-23 10:10:49.709667
# Unit test for function do_unvault
def test_do_unvault():
    text = 'foobar'
    secret = 'secret'
    vault = do_vault(text, secret)
    unvault = do_unvault(vault, secret)
    assert text == unvault

# Generated at 2022-06-23 10:10:50.285486
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 1 == 1

# Generated at 2022-06-23 10:10:52.764601
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Unit test for the constructor of class FilterModule
    """
    fm = FilterModule()

    assert isinstance(fm, FilterModule)



# Generated at 2022-06-23 10:11:00.242920
# Unit test for function do_unvault
def test_do_unvault():

    # Test for invalid secret
    try:
        result = do_unvault('this is a test', None)
        assert False
    except AnsibleFilterError:
        pass
    except AssertionError:
        pass

    # Test for invalid vault
    try:
        result = do_unvault(None, 'password')
        assert False
    except AnsibleFilterError:
        pass
    except AssertionError:
        pass

    # Test for invalid vault type
    try:
        result = do_unvault(('this', 'is', 'a', 'test'), 'password')
        assert False
    except AnsibleFilterError:
        pass
    except AssertionError:
        pass

    # Test for normal decrypt
    data = 'this is a test'

# Generated at 2022-06-23 10:11:01.301564
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:11:13.725762
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import VaultSecret
    d = {}
    f = FilterModule()
    data = 'h3ll0w0rld'
    secret = VaultSecret('ansibl3')
    salt = 'ans1bl3'
    vaultid = 'filt3r_d3fault'
    wrap_object = False

# Generated at 2022-06-23 10:11:22.943860
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:35.813575
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:38.302562
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _ = FilterModule().filters()

# Generated at 2022-06-23 10:11:44.666912
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:11:53.445881
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filter_module.filters()

# Generated at 2022-06-23 10:11:56.736613
# Unit test for function do_vault
def test_do_vault():
    try:
        secret = 'mysecret'
        result = do_vault('mystring', secret)
        assert result is not None
    except Exception:
        assert False



# Generated at 2022-06-23 10:11:58.533719
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ Unit test for constructor of class FilterModule """
    obj = FilterModule()
    assert obj is not None


# Generated at 2022-06-23 10:12:10.979549
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test for def filters(self) method
    # Create object for FilterModule
    object_FilterModule = FilterModule()

    # Test for method filters
    test_object_FilterModule = object_FilterModule.filters()

    # Test for method do_vault
    test_do_vault = test_object_FilterModule['vault']("test_vault", "test_secret")
    assert isinstance(test_do_vault, str)

    # Test for method do_unvault
    test_do_unvault = test_object_FilterModule['unvault'](test_do_vault, "test_secret")
    assert isinstance(test_do_unvault, str)
    assert test_do_unvault == "test_vault"

# Generated at 2022-06-23 10:12:20.235535
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    from jinja2 import Environment
    env = Environment()
    env.filters['vault'] = do_vault
    env.filters['unvault'] = do_unvault
    assert isinstance(x.filters(), dict)
    assert isinstance(env.filters['vault']('peperoni', 'password', 'salt'), str)

# Generated at 2022-06-23 10:12:27.602742
# Unit test for function do_vault
def test_do_vault():
  secret = "asdf"
  data = "asdf..."
  assert(do_vault(data, secret, "blah") == '$ANSIBLE_VAULT;1.1;AES256;blah\n32303139393736343132313036373339396635376130666237643065336434623362336166386538\n66316432613561346131623334616132316263313536623038356531373039393066383338663361\n66616336613435396232626365633036346538656330383965333430663661393566333938663865\n3830346130623631663962623532656331306531343634376164\n')

  # Test

# Generated at 2022-06-23 10:12:28.507387
# Unit test for constructor of class FilterModule
def test_FilterModule():
   obj = FilterModule()
   if not isinstance(obj, object):
       raise AssertionError("FilterModule is not object")

# Generated at 2022-06-23 10:12:31.581487
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:12:33.473530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert(filter_module.filters() is not None)



# Generated at 2022-06-23 10:12:45.378595
# Unit test for function do_vault
def test_do_vault():
    secret = 'testsecret'
    data = 'testdata'

    # Function returns vault encrypted strings

# Generated at 2022-06-23 10:12:46.209900
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:12:47.290917
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-23 10:12:55.769213
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:06.151869
# Unit test for function do_unvault
def test_do_unvault():
    # Arrange
    enc_data = b"$ANSIBLE_VAULT;1.2;AES256;default\n32653766643961366237303866383338353430376239636166323863626530383365393837613861\n34623966656331623363626461653862643833353664613934326133326339376266336631646361\n38643333303732656332396264656134366539386239613037326331613661653934663733313564\n3130333335633664"

    # Act
    unvault = do_unvault(enc_data, 'test_secret')

    #Assert
    assert unvault == 'foobar'


# Generated at 2022-06-23 10:13:18.085297
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:19.771842
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-23 10:13:22.945080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filters = FilterModule()
    filters = test_filters.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:13:26.730266
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    # vault
    assert filters.get('vault') is not None

    # unvault
    assert filters.get('unvault') is not None

# Generated at 2022-06-23 10:13:28.544444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule.filters.__name__ == 'filters'

# Generated at 2022-06-23 10:13:30.588648
# Unit test for constructor of class FilterModule
def test_FilterModule():
    o = FilterModule()
    assert o is not None


# Generated at 2022-06-23 10:13:31.703529
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:13:34.621754
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert(filters['vault'] == do_vault)
    assert(filters['unvault'] == do_unvault)


# Generated at 2022-06-23 10:13:35.784538
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print('Testing FilterModule')


# Generated at 2022-06-23 10:13:42.235145
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:53.839791
# Unit test for function do_vault
def test_do_vault():
    data = 'This is a sentence to encrypt.'
    secret = 'VaultSecret'
    result_vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          613463386132366162333862333964303733353936363837383735313962353933323261323737\n          396532323834636432306535363330636335623635383532343938386262616337303362306365\n          3235333839393565653734356666346538346539336165623866396666366661\n          "
    result = 'This is a sentence to encrypt.'
    assert do_vault(data, secret) == result_vault
    assert do_unvault

# Generated at 2022-06-23 10:13:57.218869
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class Foo:
        def filters(self):
            return {"x": "y"}

    assert FilterModule().filters() == Foo().filters()

# Generated at 2022-06-23 10:14:00.966077
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:14:10.009001
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:21.750502
# Unit test for function do_unvault

# Generated at 2022-06-23 10:14:34.146013
# Unit test for function do_unvault

# Generated at 2022-06-23 10:14:36.505451
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-23 10:14:38.225794
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()

# Generated at 2022-06-23 10:14:49.600027
# Unit test for function do_unvault
def test_do_unvault():
    # Generate a random string of 100 characters
    random_string = ''.join(random.choices(string.ascii_uppercase + string.digits, k=100))
    # Make sure that the first run of the function is successful
    assert do_unvault(do_vault(random_string, 'dummy_secret', wrap_object=True), 'dummy_secret') == random_string
    # Make sure that the second run of the function is successful
    assert do_unvault(do_vault(random_string, 'dummy_secret'), 'dummy_secret') == random_string
    # Make sure that the first run of the function is a failure

# Generated at 2022-06-23 10:14:56.629516
# Unit test for function do_vault
def test_do_vault():
    # Test with valid input and default value of wrap_object
    assert isinstance(do_vault("test", "secret_string"), string_types), "do_vault string test failed."
    # Test with valid input and wrap_object with value True
    assert isinstance(do_vault("test", "secret_string", "salt_string", "vaultid", True), AnsibleVaultEncryptedUnicode), "do_vault boolean test failed."


# Generated at 2022-06-23 10:15:06.239788
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:12.302991
# Unit test for function do_vault
def test_do_vault():
    key = 'testpassword'
    data = 'testdata'
    vault = do_vault(data, key)
    assert vault.startswith('$ANSIBLE_VAULT;')



# Generated at 2022-06-23 10:15:16.663939
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()

# Generated at 2022-06-23 10:15:23.244059
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment

    ctx = {
        'x': "value",
        'y': None,
        'secret': "password",
        'json_dic': {'a':'b', 'c':'d', 'e':'f'},
        'person_dic': {'firstname':'John', 'secondname':'Smith'},
    }

    env = Environment()
    env.filters['vault'] = do_vault

    template_str = '{{ x | vault("password") }}'
    msg = env.from_string(template_str).render(ctx)
    assert msg != None
    assert msg != ""
    assert msg != "value"

    template_str = '{{ x | vault("password") }}'

# Generated at 2022-06-23 10:15:32.642636
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault("my_secret_data", "my_secret_password") == AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;ansible_vault_1\n33393763623361353661353736333833343962626131633638613335636338353738666534646635\n65343062316361373564636263316265393939613233613933333466303939626232623662343839\n65653539316562633261613764313936336131363335653966356232666435306130393330313033\n3133653165313437373835343733\n', 'my_secret_password')
    assert do_unvault