

# Generated at 2022-06-23 10:05:28.272963
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()


# Generated at 2022-06-23 10:05:38.743492
# Unit test for function do_vault
def test_do_vault():
    given_secret = to_bytes('correct horse battery staple')
    given_data = to_bytes('some data')

# Generated at 2022-06-23 10:05:46.340530
# Unit test for function do_unvault

# Generated at 2022-06-23 10:05:53.530935
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible_test\n323336643761333362626662653663616133623663363166653265326532353265333165323265\n3666306263366131653132333438363238336163353265316532353265653265323932653166626\n30a\n'
    assert do_unvault(vault, secret) == "Hello world"

# Generated at 2022-06-23 10:06:03.254524
# Unit test for function do_vault
def test_do_vault():

    # import library to run unit test for this function
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultSecret

    # define the inputs
    params = {'vault': 'my vault'}

    original_vault_secret = VaultSecret(b'password')

    # call the method to test
    value = do_vault(params['vault'], original_vault_secret)

    # define the expected output

# Generated at 2022-06-23 10:06:11.835965
# Unit test for function do_unvault
def test_do_unvault():
    from docutils.parsers.rst import directives
    import os
    import sys
    from ansible.module_utils.six import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.vault import VaultLib

    class vault_data_filter(object):
        def __init__(self, obj):
            self.obj = obj

        def __getattr__(self, name):
            if name in ('vault', 'unvault_directive'):
                return AnsibleVaultEncryptedUnicode(getattr(self.obj, name))
            else:
                return getattr(self.obj, name)


# Generated at 2022-06-23 10:06:12.358836
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(True)

# Generated at 2022-06-23 10:06:18.426938
# Unit test for function do_unvault
def test_do_unvault():
    try:
        import pytest
    except ImportError:
        print('Could not import the pytest library. Skipping tests.')
        return

    import jinja2

    env = jinja2.Environment()
    env.filters['unvault'] = do_unvault

    SECRET = 'password'
    DATA = 'hello world'

    vault = do_vault(DATA, SECRET)
    assert vault

    data = env.from_string('{{ vault | unvault(secret) }}').render(
        secret=SECRET,
        vault=vault
    )
    assert data == DATA

    vault = do_vault(DATA, SECRET)
    assert vault

    data = do_unvault(vault, SECRET)
    assert data == DATA

# Generated at 2022-06-23 10:06:23.374473
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Dummy string for testing
    dummy_str = "Test value to be encrypted"
    # Dummy secret for testing
    dummy_secret = "Test secret"

    # Create object of class FilterModule
    obj_filterModule = FilterModule()

    # Access property filters
    filters = obj_filterModule.filters()

    # Access property vault of filters
    vault_filter = filters['vault']

    # Run method do_vault of vault_filter
    encrypted_text = vault_filter(dummy_str, dummy_secret)

    # Check if encryption was successful
    assert encrypted_text != dummy_str

    # Access property unvault of filters
    unvault_filter = filters['unvault']

    # Run method do_unvault of unvault_filter

# Generated at 2022-06-23 10:06:25.538893
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert isinstance(instance, FilterModule)


# Generated at 2022-06-23 10:06:34.803749
# Unit test for function do_unvault
def test_do_unvault():
    import jinja2
    import sys
    import re

    class AnsibleVaultEncryptedUnicode(object):
        def __init__(self, data):
            self.data = data
            self.vault = None

        def __str__(self):
            if self.vault:
                return self.vault.decrypt(self.data).decode('utf-8')
            else:
                return str(self.data)

        def __add__(self, other):
            return str(self) + str(other)

        def __radd__(self, other):
            return str(other) + str(self)

        def __eq__(self, other):
            return str(self) == other

        def __neq__(self, other):
            return str(self) != other

    do_

# Generated at 2022-06-23 10:06:35.480741
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:06:43.468403
# Unit test for function do_unvault
def test_do_unvault():
    from io import StringIO
    import sys

    # Simulate ansible-playbook command line
    sys.argv = ["ansible-playbook", "--vault-password-file", "~/.vault_pass.txt"]

    # Initialize Display()
    display = Display()
    display.verbosity = 4

    # Create a StringIO object
    strio = StringIO()

    # Assign to sys.stdout so we can catch output
    sys.stdout = strio

    data_unencrypted = 'I am unencrypted'

# Generated at 2022-06-23 10:06:50.964928
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:54.452372
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    res = fm.filters()
    assert type(res) == dict
    assert 'vault' in res
    assert 'unvault' in res


# Generated at 2022-06-23 10:07:04.583856
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256;test'
    vault_string = '$ANSIBLE_VAULT;1.1;AES256;test\n6576616374730a174131454b485a31594f5a564c476554316b5866636f356c73572b496d6c7a\n72534f5a72742b354c6e7a365038646e7677444e6d71373d'
    assert do_unvault(vault_string, secret) == 'unvault_secret'


# Generated at 2022-06-23 10:07:12.791862
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('test', 'password') == '$ANSIBLE_VAULT;1.1;AES256 62316462306134633236663232646565626236373233663037363834366531353066616263656661 30623239663336323662333832326233343238613431346230613463612630383532653430396465 62333862386232366166326661323630656139613061306531653964633361343365323831353465 33323639353235663761386537303933303830613331636264393761386433623366643834633662 \n'


# Generated at 2022-06-23 10:07:20.934061
# Unit test for function do_unvault
def test_do_unvault():
    import tempfile
    import os

    secret_file = tempfile.mktemp()
    with open(secret_file, 'w') as f:
        f.write("ansible")

    vault_file = tempfile.mktemp()

# Generated at 2022-06-23 10:07:25.085209
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:07:33.793996
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    fm = "some text_1"
    result = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;filter_default\n          35343265346565303462323538326263666231623563376339663233356163346237343930636461\n          30303362656266623337336631663166393331376163323762303161326533636330a"
    assert do_vault(fm, secret, wrap_object=False) == result


# Generated at 2022-06-23 10:07:40.701156
# Unit test for constructor of class FilterModule
def test_FilterModule():
    objFilterModule = FilterModule()
    out = objFilterModule.filters()

# Generated at 2022-06-23 10:07:43.086706
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters.get('vault') == do_vault
    assert filters.get('unvault') == do_unvault

# Generated at 2022-06-23 10:07:45.465190
# Unit test for function do_unvault
def test_do_unvault():
    payload = "ThisIsMySecretData"
    assert payload == do_unvault(do_vault(payload, "mysecret"), "mysecret")

# Generated at 2022-06-23 10:07:58.058622
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256\n'
    data = "3n3r0y4l3"
    salt = "ABCD"
    vaultid = 'test_do_vault_filter_default'

    assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object=False), str)
    assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object=True), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 10:08:00.561619
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:08:10.383524
# Unit test for function do_vault
def test_do_vault():
    data = b"data to be encrypted"
    secret = b"test123test123test123"

# Generated at 2022-06-23 10:08:23.177974
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:35.274524
# Unit test for function do_unvault
def test_do_unvault():
    def _do_unvault(vault, secret, vaultid):
        assert(do_unvault(vault=vault, secret=secret, vaultid=vaultid) == data)

    data = '1234567'

# Generated at 2022-06-23 10:08:43.622995
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("foo", "baz")
    assert isinstance(result, str)

    result = do_vault("foo", "baz", wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    with pytest.raises(AnsibleFilterTypeError):
        do_vault(1, "baz")

    with pytest.raises(AnsibleFilterTypeError):
        do_vault("foo", 1)

    with pytest.raises(AnsibleFilterError):
        do_vault("foo", "baz", 123)

    with pytest.raises(AnsibleFilterError):
        do_vault("foo", "baz", salt=123)

    with pytest.raises(AnsibleFilterError):
        do

# Generated at 2022-06-23 10:08:53.005779
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data="ansible", secret="vault") == u'$ANSIBLE_VAULT;1.1;AES256\n34326665613333636132313434356537626362663166336161356664616230653361363762653266\n62336665353637653765303935386533646665623535663461613066303763363165306434663564\n38643961623262633362303733626664303732386130653531333662316335346639333138633963\n34383163336637663464313965326538\n'

# Generated at 2022-06-23 10:08:55.827801
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:09:08.001454
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    """Test when vault is not encrypted."""
    vault = "NOT_Encrypted"
    assert vault == do_unvault(vault, secret)

    """Test when vault is encrypted."""

# Generated at 2022-06-23 10:09:11.276536
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print("Test FilterModule")
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:09:13.025233
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj



# Generated at 2022-06-23 10:09:16.603308
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('mydata', 'mypassword') == 'mydata'

# Generated at 2022-06-23 10:09:29.018088
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:32.092530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ft = FilterModule()
    assert ft.filters() is not None, "expected to get FilterModule.filters() NOT NONE"

# Generated at 2022-06-23 10:09:34.829817
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}, 'ansible_vault_jinja2_filters filter test failed!'


# Generated at 2022-06-23 10:09:37.253971
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test to validate FilterModule class created successfully
    assert(isinstance(FilterModule(), FilterModule))

# Generated at 2022-06-23 10:09:50.689370
# Unit test for function do_vault
def test_do_vault():
    data = "'ansible' --ask-vault-pass"
    secret = "secret"
    assert do_vault(data, secret) == "$ANSIBLE_VAULT;1.2;AES256;ansible\r\n363135373933653231363933353465383766303733663930323062353135316164656632\r\n303239333465663737326665636236616362636535303833323962656632666661613032\r\n306333356333666131616639346437626163636365656465663664353439383761613838\r\n6632313839663465336462633664383630336635\r\n"



# Generated at 2022-06-23 10:10:02.844907
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test1'
    res = do_vault(data, secret)

# Generated at 2022-06-23 10:10:13.071673
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_bytes
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    salt = b'\x98:\x9e\x96\x18\x1b\xb7{\x00\x80\xd4\xc4\xf6\x9e\xee\xec\xf2\xdc\x8d\xf1\x92\xbe'

# Generated at 2022-06-23 10:10:18.068341
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    data="this is secret"
    secret="secret"
    vaultid="test_vault"
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    vault = vl.encrypt(to_bytes(data),  vaultid=vaultid)
    result = do_unvault(vault, secret, vaultid)
    assert result=="this is secret"

# Generated at 2022-06-23 10:10:19.922407
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:10:32.819168
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:41.527560
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.errors import AnsibleFilterTypeError
    from ansible.parsing.vault import is_encrypted

    # Test the case where the vault string is not encrypted
    vault = 'vault_string'
    d1 = do_unvault(vault, 'test_secret')
    assert vault == d1

    # Test the case where the vault string is encrypted
    secret = 'test_secret'
    data = 'data_string'
    d2 = do_vault(data, secret)
    assert is_encrypted(d2)
    d3 = do_unvault(d2, secret)
    assert d3 == data

    # Test the case where the vault string is an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-23 10:10:50.874409
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:52.099474
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-23 10:10:56.505115
# Unit test for function do_unvault
def test_do_unvault():
    data = "password"
    secret = "secret"
    vaultid = "filter_default"
    vault = do_vault(data, secret, vaultid, wrap_object=False)
    data1 = do_unvault(vault, secret, vaultid)
    assert data == data1

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-23 10:11:09.289089
# Unit test for function do_unvault
def test_do_unvault():

    dummy_str = 'test'
    vaultid = 'test_id'
    dummy_secret = 'test_secret'
    dummy_secret_2 = 'test_secret_2'

    # Encode with secret
    dummy_vault_str = do_vault(dummy_str, dummy_secret, vaultid=vaultid)

    # Decode with wrong secret
    assert do_unvault(dummy_vault_str, dummy_secret_2, vaultid=vaultid) != dummy_str

    # Decode with right secret
    assert do_unvault(dummy_vault_str, dummy_secret, vaultid=vaultid) == dummy_str

    # Undefined values are unusable
    assert do_unvault(Undefined(), dummy_secret, vaultid=vaultid) == Undefined()

# Generated at 2022-06-23 10:11:12.146208
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule(), 'filters')


# Generated at 2022-06-23 10:11:22.158233
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myvaultid\n313233") == "123"
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myvaultid\nc2VjcmV0\n") == "secret"
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myvaultid\nc2VjcmV0\n", vaultid="myvaultid") == "secret"
    assert do_unvault("$ANSIBLE_VAULT;9.9;AES256;myvaultid;other_stuff\nc2VjcmV0\n", vaultid="myvaultid") == "secret"

# Generated at 2022-06-23 10:11:23.837181
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() is not None


# Generated at 2022-06-23 10:11:36.609818
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:49.143763
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n6332353064313635386664363466376131666561393539643336336135383336313530343363613863\n636538393962653064613630333838616535383437333432303537363637336633653764303765646539\n3061303333343566643534666430617d0a', 'secretpassword') == 'test'


# Generated at 2022-06-23 10:11:58.693211
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'ansible') == '$ANSIBLE_VAULT;1.1;AES256\n63323963303766396330343332613936376535336232393337386262376539363765303635336639\n66343564386534643930373833623064363562356437363935373031353132376264343562393261\n393639323565353430363765366239326361386537386138356530386330\n'


# Generated at 2022-06-23 10:12:04.466493
# Unit test for function do_unvault
def test_do_unvault():
    plaintext = 'plain text'
    secret = 'secret'
    vault = do_vault(plaintext, secret)
    print('vault', vault)
    #unvault = do_unvault(vault, secret)
    #assert unvault == plaintext

# Generated at 2022-06-23 10:12:11.610704
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    secret = 'mysecret'
    result = do_vault("hello", secret, wrap_object=True)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.unvault(secret).encode('utf-8') == yaml.dump("hello").encode('utf-8')


# Generated at 2022-06-23 10:12:20.719505
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    secret = AnsibleUnsafeText('my_secret')
    salt = AnsibleUnsafeText('my_salt')
    data = AnsibleUnsafeText('my_data')
    # Make sure we don't encrypt without salt
    assert do_vault(data, secret) != do_vault(data, secret, salt)
    # Make sure we can encrypt successfully with AnsibleUnsafeText
    assert do_vault(data, secret)
    assert do_vault(data, secret, salt)

    # Make sure we can decrypt what we've encrypted
    assert do_unvault(do_vault(data, secret), secret) == data
    assert do_unvault(do_vault(data, secret, salt), secret) == data

    # Make

# Generated at 2022-06-23 10:12:23.389893
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert fm_filters['vault'] == do_vault
    assert fm_filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:12:25.117579
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("0", "foo") == ""


# Generated at 2022-06-23 10:12:31.316393
# Unit test for function do_unvault
def test_do_unvault():
    data = "password"
    secret = "secret"

# Generated at 2022-06-23 10:12:39.293677
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n63363536346438376137663164393364386638643961623339623432363932303337373964366536\n6373633033656466313134626532653032353061333865343461353336343532633761646238656466\n6631313134666463386239623163393935383634303232626234313636363531316362333135613131\n36646131666166356235653264373965326263363837656537\n'
    data = 'data'


# Generated at 2022-06-23 10:12:42.482275
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None



# Generated at 2022-06-23 10:12:50.830607
# Unit test for function do_vault
def test_do_vault():
    data = 'Some secret that needs to be protected'
    secret = 'mysecret'
    vaultid = 'test_vault'

# Generated at 2022-06-23 10:12:53.655396
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_vault_filter_module = FilterModule()
    assert ansible_vault_filter_module.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:13:00.785687
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # NOTE: FilterModule not a real class, so no defined method
    assert hasattr(fm, 'filters')
    assert type(fm.filters()) == dict
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()



# Generated at 2022-06-23 10:13:02.128220
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters.filters() is not None

# Generated at 2022-06-23 10:13:10.713008
# Unit test for function do_vault
def test_do_vault():
    # Arrange
    data = 'mydata'
    secret = 'mysecret'
    salt = 'abcdefgh'
    vaultid = 'filter_default'
    wrap_object = False

    # Act
    out = do_vault(data, secret, salt, vaultid, wrap_object)

    # Assert
    assert out.startswith(b'$ANSIBLE_VAULT;')



# Generated at 2022-06-23 10:13:20.392077
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:33.420190
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:36.594640
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('test_string', 'my_secret', 'mySalt', 'my_filter')
    assert isinstance(result, string_types)
    assert result.startswith('$ANSIBLE_VAULT;')



# Generated at 2022-06-23 10:13:38.339158
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    return fm.filters()


# Generated at 2022-06-23 10:13:50.501169
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'vaultsecret') == '$ANSIBLE_VAULT;1.2;AES256;default\n3032666534363864323162323535333664643965643534663033323338633962643065363233320a35316332303761623763346262626134613331376434306664356666383332326135643066620a333763323232353663363939346465323563393133666135656566333537653238623931620a6334'

# Generated at 2022-06-23 10:13:54.821300
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.module_utils.six import string_types, binary_type

    def do_test_FilterModule_filters(args):
        secret = 'foo'
        vault = FilterModule().filters()['vault']('bar', secret)
        unvault = FilterModule().filters()['unvault'](vault, secret)

        assert isinstance(secret, (string_types, binary_type))
        assert isinstance(unvault, (string_types, binary_type))
        assert secret == 'foo'
        assert unvault == 'bar'

    do_test_FilterModule_filters(None)



# Generated at 2022-06-23 10:13:59.362074
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # pylint: disable=W0212
    filter_module = FilterModule()
    filters = filter_module.filters()
    # pylint: enable=W0212
    assert 'unvault' in filters
    assert 'vault' in filters

# Generated at 2022-06-23 10:13:59.978028
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:14:05.683398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Returns a dictionary of filters this module implements.
    # The returned dictionary must use strings as keys and have callables as values.
    # It is recommended that filter names be prefixed with the name of the module.
    # This makes it possible to register a set of filters provided by a module
    filters = FilterModule().filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-23 10:14:11.518241
# Unit test for function do_unvault
def test_do_unvault():
    secret=secret = to_bytes('password1')
    test_data = 'test data'
    vl = VaultLib([('filter_default', VaultSecret('password1'))])
    vault = vl.encrypt(test_data, secret, 'filter_default', None)
    unvault = do_unvault(vault, 'password1')
    if unvault != test_data:
        raise AssertionError("Unvault data is not the same as input data")

# Generated at 2022-06-23 10:14:22.857787
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.plugins.lookup.vault import _VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.encrypt import _get_file_vault_secret_at_path
    import tempfile

    vault_id = 'filter_unvault'
    secret = 'notsosecret'
    data = 'datavault'

    # Test with vault '\' format
    vault = VaultAES256.encrypt(secret, data, vault_id)

# Generated at 2022-06-23 10:14:25.729390
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_vault_filters = FilterModule()
    ansible_vault_filters_filters = ansible_vault_filters.filters()
    assert ansible_vault_filters_filters['vault'] == do_vault
    assert ansible_vault_filters_filters['unvault'] == do_unvault



# Generated at 2022-06-23 10:14:26.383092
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:14:31.374416
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] == do_vault
    assert fm.filters()['unvault'] == do_unvault


# Generated at 2022-06-23 10:14:34.309211
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)
    assert isinstance(FilterModule.filters(FilterModule()), dict)


# Generated at 2022-06-23 10:14:35.690206
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert 'vault' in module.filters()
    assert 'unvault' in module.filters()


# Generated at 2022-06-23 10:14:37.055838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    mod = FilterModule()
    assert mod.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:14:38.826769
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)



# Generated at 2022-06-23 10:14:40.550367
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()


# Generated at 2022-06-23 10:14:52.898242
# Unit test for function do_vault
def test_do_vault():
    secret = "a"*32

    test_vault_1 = do_vault('secret', secret)
    test_vault_2 = do_vault('super secret', secret)
    test_vault_3 = do_vault('old secret', secret)

    assert isinstance(test_vault_1, string_types)
    assert isinstance(test_vault_2, string_types)
    assert isinstance(test_vault_3, string_types)

    assert test_vault_1 != "secret"
    assert test_vault_2 != "super secret"
    assert test_vault_3 != "old secret"

    assert test_vault_1 == do_vault('secret', secret)
    assert test_vault_2 == do_vault('super secret', secret)
    assert test

# Generated at 2022-06-23 10:15:02.185554
# Unit test for function do_unvault
def test_do_unvault():

    # Tested with a secret of 'ansible'
    vault = '$ANSIBLE_VAULT;1.1;AES256'
    vault += '\n3165333463356635613735303336336331653335306435386665633833663139396263376429'
    vault += '\n6331363862653235633233373466356432633737643532616337323865383965386365306562'
    vault += '\n6466313761623234643737313931633133613863623134623664306535643935396466376261'
    vault += '\n6437653264386463653235313738636164303533303236396637376334313438343565336636'


# Generated at 2022-06-23 10:15:03.728452
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule().filters()) == 2


# Generated at 2022-06-23 10:15:09.250486
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("mydata", "my_vault_password") == '$ANSIBLE_VAULT;1.2;AES256;ansible\r\n39633934663531323863313461386163343337643963353464353366626530356639393831363265\r\n3065643338646434376464333137376435303735316361386439653564373761386465613366346200\r\n'


# Generated at 2022-06-23 10:15:15.825987
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:17.147921
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'ansible'
    vault = '$ANSIBLE_VAULT;1.1;AES256'
    data = do_unvault(vault, secret)
    assert data == ''
    return None

# Generated at 2022-06-23 10:15:18.532866
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:15:20.305010
# Unit test for function do_vault
def test_do_vault():
    assert True == do_vault('test', 'password', None, 'filter_default', False)


# Generated at 2022-06-23 10:15:24.945013
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }
