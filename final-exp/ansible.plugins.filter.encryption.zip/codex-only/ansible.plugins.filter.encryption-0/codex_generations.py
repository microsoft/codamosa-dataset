

# Generated at 2022-06-23 10:05:33.785348
# Unit test for function do_unvault
def test_do_unvault():
    from six import u
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    import jinja2
    import json



# Generated at 2022-06-23 10:05:44.281567
# Unit test for function do_vault
def test_do_vault():
    import os
    import sys
    import unittest
    import yaml

    with open(os.path.join(os.path.dirname(__file__), 'test_data.yml'), 'r') as ymlfile:
        test_data = yaml.load(ymlfile)
        if sys.version_info >= (2, 7):
            ymlfile.close()
        filter_test = filter(lambda x: x['action'] == 'vault' and x['type'] in ('string', 'unicode'),
                             test_data['test_list'])
        for test in filter_test:
            test['data'] = test['data'].encode('utf-8')
            test['expected_result'] = test['expected_result'].encode('utf-8')
            vault = do_vault

# Generated at 2022-06-23 10:05:54.952171
# Unit test for function do_unvault

# Generated at 2022-06-23 10:05:56.867023
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_Filter = FilterModule()
    assert(isinstance(test_Filter, FilterModule))

# Generated at 2022-06-23 10:06:05.283112
# Unit test for function do_vault
def test_do_vault():

    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.vars.unsafe_proxy import UnsafeProxy
    else:
        from ansible.vars.unsafe_proxy import wrap_var

    # test for vaulting of a string
    secret = 'my_secret'
    vault = do_vault('my_data', secret)
    if isinstance(vault, UnsafeProxy):
        vault = wrap_var(vault)

    assert isinstance(vault, string_types)

# Generated at 2022-06-23 10:06:10.294757
# Unit test for function do_unvault
def test_do_unvault():
    unit_test_secret = 'some_secret'
    unit_test_vault = '$ANSIBLE_VAULT;1.2;AES256;some_vault32423423\n34236426236423642362364236213423\n3623642364236423642364236236423621\n'

    assert(do_unvault(unit_test_vault, unit_test_secret) == 'foo')

# Generated at 2022-06-23 10:06:14.591352
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # TODO: Implement test_FilterModule_filters
    # v = FilterModule()
    # def test_vault(self, data, secret, salt=None, vaultid='filter_default', wrap_object=False):
    # def test_unvault(self, vault, secret, vaultid='filter_default'):
    # assert isinstance(v.filters(), dict)
    raise NotImplementedError

# Generated at 2022-06-23 10:06:15.487863
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:06:22.120553
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import random
    import string
    import unittest

    import mock
    import tempfile

    user_secret = ''.join(random.choice(string.ascii_uppercase + string.digits) for i in range(8))
    test_data = ''.join(random.choice(string.ascii_uppercase + string.digits) for i in range(128))

    mock_disp = mock.Mock()
    with mock.patch.multiple(Display, display=mock_disp):

        # Correct password, return the expected decrypted data
        ret = do_unvault(
            do_vault(test_data, secret=user_secret),
            secret=user_secret)
        assert ret == test_data

        # Incorrect password, return a empty string

# Generated at 2022-06-23 10:06:24.339154
# Unit test for function do_vault
def test_do_vault():
    function = do_vault
    assert function('data','secret') == 'vaulted_data'


# Generated at 2022-06-23 10:06:33.298690
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('my_content', 'my_secret', salt='my_salt') == '$ANSIBLE_VAULT;1.1;AES256;my_salt;16\n616767346664616e6f446c7a4a646c594965656436386b6439345a30796f\n6d357a6f5864794f6669356539726a72\n78363736354d736b6377626e7a427a76\n6c37614d6f2b49797553327a59504c51\n6b6c48483668783531566a32514e6b46'

# Generated at 2022-06-23 10:06:42.467176
# Unit test for function do_unvault
def test_do_unvault():
    unvault_text = do_unvault("!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          393032316633373630353230643735366331386132383466333737663832633731623463376330\n          65633836383664633462313631353165326430653166323338650a316434363039646534356438\n          636636643963336663373638326164343132363233343336376462306132613331656434393564\n          366135663661646237630a3634646663346239613332626155", "password")

# Generated at 2022-06-23 10:06:43.149994
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:06:43.553491
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:06:55.309186
# Unit test for function do_unvault

# Generated at 2022-06-23 10:07:07.454369
# Unit test for function do_unvault
def test_do_unvault():
    ''' test_do_unvault'''

    secret = 'foo'
    vault_str = '$ANSIBLE_VAULT;1.2;AES256;ansible123\n3536383331633566323361643930333566626530343565393565383162313163356533376136633464\n3464303339383166616666303335643466386231306334643339636438303862656239616663396338\n6165346533643932303565303733656239393765636637663536306639666339336162316638323732\n35373035'

    assert do_unvault(vault_str, secret) == '1585'

# Generated at 2022-06-23 10:07:10.124417
# Unit test for function do_vault
def test_do_vault():
    val = 'test'
    secret = 'password'
    vault = do_vault(val, secret)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == 'test'

# Generated at 2022-06-23 10:07:13.468910
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule()) == {
        'vault': do_vault,
        'unvault': do_unvault
    }

# Generated at 2022-06-23 10:07:15.823275
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert repr(obj) == "<ansible.plugins.filter.vault.FilterModule object at 0x{{hex(id(obj))}}>"

# Generated at 2022-06-23 10:07:19.106627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters == { 'vault': do_vault, 'unvault': do_unvault }

# Generated at 2022-06-23 10:07:22.727723
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()



# Generated at 2022-06-23 10:07:34.337419
# Unit test for function do_unvault
def test_do_unvault():
    secret = "hush"

# Generated at 2022-06-23 10:07:42.268719
# Unit test for function do_unvault
def test_do_unvault():
    # For this test to work, the VaultSecret must be the same as what ansible-vault creates
    unvault_secret = 'mysecret'
    test_vault = '$ANSIBLE_VAULT;1.1;AES256'
    test_unvault = do_unvault(test_vault, unvault_secret)
    assert test_unvault == test_vault

# Generated at 2022-06-23 10:07:50.294899
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'vault_test_secret'

    data = 'plain text'

# Generated at 2022-06-23 10:07:51.832706
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:08:02.795069
# Unit test for function do_unvault
def test_do_unvault():
    vaultid = 'filter_default'
    secret = 'secret'
    str_input = 'secret_string'

# Generated at 2022-06-23 10:08:04.160461
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None


# Generated at 2022-06-23 10:08:13.262945
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'myvaultsecret'
    vault = '$ANSIBLE_VAULT;1.2;AES256;myvaultsecret;307b64e5adc0da941d5a5e5c36095ac8c0871b3a3f3d3c9a9530f9cc9f22ab127252e2b742d8c6eef62a89a2d1c28a8e9190b9d6a86394bc3a98fe8a0c12f776'
    data = 'mysecretstring'

    assert(do_unvault(vault, secret) == data)

    vaultid = 'filter_different'

# Generated at 2022-06-23 10:08:25.076948
# Unit test for function do_vault
def test_do_vault():
    print('Test : %s' % (do_vault('my_secret', 'my_secret_password')))
    print('Test : %s' % (do_vault(1, 'my_secret_password')))
    print('Test : %s' % (do_vault('my_secret', ['test'])))
    print('Test : %s' % (do_vault(Undefined(), 'my_secret_password')))
    print('Test : %s' % (do_vault('my_secret', Undefined())))
    print('Test : %s' % (do_vault('my_secret', 'my_secret_password', Undefined())))
    print('Test : %s' % (do_vault('my_secret', 'my_secret_password', 'my_salt', Undefined())))
    print

# Generated at 2022-06-23 10:08:27.509113
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert hasattr(obj, 'filters')


# Generated at 2022-06-23 10:08:30.507517
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:08:40.137574
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'abcdefg'

# Generated at 2022-06-23 10:08:50.813273
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'd34db33f'

# Generated at 2022-06-23 10:08:55.316977
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] == do_vault
    assert fm.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:09:07.581201
# Unit test for function do_unvault
def test_do_unvault():
    # Set test_inputs
    test_inputs = {}
    test_inputs['secret'] = 'some_secret'
    test_inputs['vaultid'] = 'filter_default'
    test_inputs['string_var'] = 'Hello World!'

# Generated at 2022-06-23 10:09:19.180848
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:31.908142
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'some_secret'
    data = 'data'
    wrap_object = False
    vaultid = 'filter_default'

    vault_plaintext = do_vault(data, secret, wrap_object=wrap_object, vaultid=vaultid)
    decrypted_plaintext = do_unvault(vault_plaintext, secret, vaultid=vaultid)
    assert data == decrypted_plaintext

    vault_object = do_vault(data, secret, wrap_object=True, vaultid=vaultid)
    decrypted_object = do_unvault(vault_object, secret, vaultid=vaultid)
    assert data == decrypted_object

    # Test AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-23 10:09:34.776014
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("test value", secret="asdf")
    assert isinstance(result, string_types)
    assert result != "test value"


# Generated at 2022-06-23 10:09:41.644083
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:53.967047
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:56.472826
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == dict(vault=do_vault, unvault=do_unvault)

# Generated at 2022-06-23 10:09:57.880251
# Unit test for function do_vault
def test_do_vault():
    do_vault('this is a test', 'password')



# Generated at 2022-06-23 10:09:59.245911
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:10:05.649066
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        from unittest import mock
        from unittest.mock import patch
    except ImportError:
        mock = None
        patch = None
    import pytest
    if mock is not None and patch is not None:
        filter_module = FilterModule()
        filters = filter_module.filters()
        assert isinstance(filters, dict)
        assert 'vault' in filters
        assert 'unvault' in filters



# Generated at 2022-06-23 10:10:07.755432
# Unit test for constructor of class FilterModule
def test_FilterModule():

    x = FilterModule()

    filters = x.filters()

    assert filters['vault']
    assert filters['unvault']

# Generated at 2022-06-23 10:10:12.245296
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_class = FilterModule()
    assert test_class.filters() == dict(
        vault=do_vault,
        unvault=do_unvault
    )

# Generated at 2022-06-23 10:10:21.792540
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("secret", "secret", salt='123').startswith("$ANSIBLE_VAULT;1.1;AES256;123")
    assert do_vault("secret", "secret", salt='123', vaultid='other_id').startswith("$ANSIBLE_VAULT;1.1;AES256;123;other_id")
    assert do_vault("secret", "secret", salt='123', wrap_object=True).startswith("$ANSIBLE_VAULT;1.1;AES256;123")
    assert do_vault("secret", "secret", salt='123', vaultid='other_id', wrap_object=True).startswith("$ANSIBLE_VAULT;1.1;AES256;123;other_id")


# Generated at 2022-06-23 10:10:22.997199
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:10:25.115025
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("test", "secret", "testid") == "test"

# Generated at 2022-06-23 10:10:34.354220
# Unit test for function do_vault
def test_do_vault():

    # Test to ensure 'vault' wrapper is included when setting `wrap_object` to `True`:
    assert(isinstance(do_vault('foo', 'bar', wrap_object=True), AnsibleVaultEncryptedUnicode))
    # Test to ensure 'wrap_object' is set to `False` (default) and the plaintext is returned:

# Generated at 2022-06-23 10:10:42.202783
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:53.777783
# Unit test for function do_vault
def test_do_vault():
    for plaintext, secret, vaultid in [
        (u'foobar', u'vault-password', 'filter_default'),
        (b'foobar', u'vault-password', 'filter_default'),
        (u'foobar', b'vault-password', 'filter_default'),
        (b'foobar', b'vault-password', 'filter_default'),
        (u'foobar', u'vault-password', 'filter_id'),
        (b'foobar', u'vault-password', 'filter_id'),
        (u'foobar', b'vault-password', 'filter_id'),
        (b'foobar', b'vault-password', 'filter_id'),
        ]:
        v = do_vault(plaintext, secret, None, vaultid)
        assert do_

# Generated at 2022-06-23 10:10:58.573030
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    secret = 'secret'
    data = 'hello world'
    vaultid = 'nocrypt'
    vault = AnsibleVaultEncryptedUnicode(VaultLib().encrypt(data, secret, vaultid))
    assert(do_unvault(vault, secret, vaultid) == data)


# Generated at 2022-06-23 10:11:01.557991
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule)
    assert 'unvault' in FilterModule.filters(FilterModule)



# Generated at 2022-06-23 10:11:13.881354
# Unit test for function do_unvault
def test_do_unvault():
    my_vault = AnsibleVaultEncryptedUnicode(u'$ANSIBLE_VAULT;1.1;AES256\n3635333233316464303166376433356530653966376161323762636538363661303335346531333\n366353730336137613136373430376131623661633362623363346461353837376135376534663034\n6438346630363533313031326362343163663663165303935\n')
    my_vault.vault = VaultLib([('default', VaultSecret('default_secret'))])
    result = do_unvault(my_vault, 'default_secret', vaultid='default')
    assert result == u'abc'

# Generated at 2022-06-23 10:11:15.145699
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:11:17.886728
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()


# Generated at 2022-06-23 10:11:18.811450
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module is not None

# Generated at 2022-06-23 10:11:26.618394
# Unit test for function do_unvault
def test_do_unvault():
    # Test to check that do_unvault returns decrypted data
    result = do_unvault(
        '$ANSIBLE_VAULT;1.2;AES256;filter_default\n663465336265363965313064333638363865613433396563376261633864666535646639\n333837393836363762363335306161333238613266613038393865386166630a31643865\n363737366661633338373636373935663765623739396161363733353966643835363433\n653233633364373865616337386166616434616662393939663831666566',
        'secret')
    assert result == 'ansible'

    # Test to

# Generated at 2022-06-23 10:11:37.518309
# Unit test for function do_unvault
def test_do_unvault():
    # Use same VaultId and salt as in the Ansible Vault
    vaultId = 'filter_default'
    vaultSalt = '202cb962ac59075b964b07152d234b70'

    # Create Passphrase
    passphrase = 'The passphrase'

    # Create Vault Object
    vault = VaultLib([(vaultId, VaultSecret(to_bytes(passphrase), salt=vaultSalt))])

    # Encrypt the secret and get encrypted string
    secret = to_native(vault.encrypt(to_bytes('this is a secret')))

    # Call do_unvault function
    data = do_unvault(secret, passphrase, vaultId)

    # Compare
    assert data == 'this is a secret'



# Generated at 2022-06-23 10:11:40.319339
# Unit test for function do_unvault
def test_do_unvault():
    fm = FilterModule()
    assert fm.filters()["unvault"]("$ANSIBLE_VAULT;7.05;AES256;test_vault", "test_secret") == "test"

# Generated at 2022-06-23 10:11:42.052108
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert not FilterModule().filters() is None

# Generated at 2022-06-23 10:11:52.736898
# Unit test for function do_unvault
def test_do_unvault():
    # test case #1: decrypt using vaultid and vault secret
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256\ng6UdHkN/hvz8JNIAQ+LtKjZ/X9k+IkC5QddlB0yhJ1IXxzt5c5f5txEJZpBXRjkS\nS1H7VtOiGfyj4x4qz3Zspg==\n",
                      "test_secret",
                      "filter_default") == "encrypt me"
    # test case #2: decrypt using vaultid and vault secret

# Generated at 2022-06-23 10:11:53.866876
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()



# Generated at 2022-06-23 10:11:57.134838
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(None)['vault'] is do_vault
    assert FilterModule.filters(None)['unvault'] is do_unvault


# Generated at 2022-06-23 10:11:58.348220
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:12:11.568419
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = 'salt'
    vaultid = 'testvaultid'
    data = 'testdata'
    wrap_object = True

    enc_obj = do_vault(data, secret, salt, vaultid, wrap_object)
    # Check if AnsibleVaultEncryptedUnicode is returned
    assert isinstance(enc_obj, AnsibleVaultEncryptedUnicode)
    # Check if the vault is decrypted
    assert enc_obj.data == data

    # Check if the wrapped object is decrypted
    enc_obj.vault = VaultLib([
        ('testvaultid', VaultSecret(secret)),
    ])
    assert enc_obj.data == data

    # Check if the wrapped object works with a list of secrets

# Generated at 2022-06-23 10:12:12.191816
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:12:21.239840
# Unit test for function do_vault
def test_do_vault():
    # Set mock arguments
    override_args = dict(
        secret='a_secret',
        data='a_data',
    )

    # Set expected return value

# Generated at 2022-06-23 10:12:24.293491
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'foo'
    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;foo;bar\n1234567890')
    data = do_unvault(vault, secret)
    assert data == '1234567890'

# Generated at 2022-06-23 10:12:34.357390
# Unit test for function do_vault
def test_do_vault():

    bad_secrets = [
        1,
        ['some element'],
        {'some key': 'some value'}
    ]

    with display.override_ui_to_ansible_color():
        for secret in bad_secrets:
            try:
                do_vault(data='some data', secret=secret)
                display.error("Expected AnsibleFilterTypeError exception not raised for secret: %s" % type(secret))
            except AnsibleFilterTypeError:
                display.display("Correctly raised AnsibleFilterTypeError exception for secret: %s" % type(secret))



# Generated at 2022-06-23 10:12:36.890825
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None


# Generated at 2022-06-23 10:12:37.880576
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:12:42.103458
# Unit test for function do_unvault
def test_do_unvault():
    data = "test"
    secret = "secret"
    vaultid = "test_vaultid"

    vault = do_vault(data, secret, vaultid=vaultid)
    assert vault is not None
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-23 10:12:52.391297
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:56.772771
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:13:00.191959
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;foo\n66373438663836656633623431336334313337643338346430613231373131653033646233366365640a3335643065626135663339313530353561353365353865383636323130326565353330363362666233626161663939333835356132313161326432623137396233623364636464636665326532616562303266336565633435623064396330333830373537326434333264636362366263616663396161633037363137346439\n", "test") == "test"

# Generated at 2022-06-23 10:13:08.354558
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret

    secret = VaultSecret('secret')
    vaultid = 'filter_default'

# Generated at 2022-06-23 10:13:12.893065
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {'unvault': do_unvault, 'vault': do_vault}

# Generated at 2022-06-23 10:13:20.530553
# Unit test for function do_vault
def test_do_vault():
    f = FilterModule()
    filters = f.filters()
    # Secret string is empty, invalid
    secret = ''
    data = 'This is an unencrypted string.'
    with pytest.raises(AnsibleFilterError):
        filters['vault'](data, secret)
    # Secret string is empty, but wrap_object is True, so we should expect an AnsibleVaultEncryptedUnicode object.
    wrap_object = True
    with pytest.raises(AnsibleFilterError):
        filters['vault'](data, secret, wrap_object=wrap_object)
    # Secret string is not a string, invalid
    secret = 1
    wrap_object = False

# Generated at 2022-06-23 10:13:22.585341
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module != None


# Generated at 2022-06-23 10:13:26.459296
# Unit test for function do_unvault
def test_do_unvault():
    value = do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256', secret='password')

    assert value == u'$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-23 10:13:28.289444
# Unit test for constructor of class FilterModule
def test_FilterModule():
    res = FilterModule()
    print(res)
    assert res != None

# Generated at 2022-06-23 10:13:38.206972
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:40.314949
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert type(filter_module) == FilterModule


# Generated at 2022-06-23 10:13:44.580325
# Unit test for function do_unvault
def test_do_unvault():
    test_vault = do_vault('y', 'Y')
    assert is_encrypted(test_vault)
    test_unvaulted = do_unvault(test_vault, 'Y')
    assert test_unvaulted == 'y'

# Generated at 2022-06-23 10:13:45.518743
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert FilterModule()

# Generated at 2022-06-23 10:13:49.209556
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

# Generated at 2022-06-23 10:13:52.108838
# Unit test for constructor of class FilterModule
def test_FilterModule():
    testObject = FilterModule()
    assert(testObject.filters() == {'vault': do_vault, 'unvault': do_unvault})


# Generated at 2022-06-23 10:14:01.279715
# Unit test for function do_vault
def test_do_vault():
    secret = 'T2l0WUhDc3hHdVBYd3g0cWp1ZzlEc0ZDVzZNbGE='
    salt = 'b2NxaE80YUFYc1pEM1pXaXhERDVkZjdneWJlQ2lJQT09'
    d = 'DoSecretStuff'
    vault = do_vault(d, secret, salt)
    assert do_unvault(vault, secret) == d



# Generated at 2022-06-23 10:14:10.141373
# Unit test for function do_vault
def test_do_vault():
    secret = 'foobar'
    # no salt
    data = 'Hello world'
    result = do_vault(data, 'foobar')

# Generated at 2022-06-23 10:14:21.373165
# Unit test for function do_unvault
def test_do_unvault():
    a = do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256\n383465663934336432343332656632323735613135326332653433623231343935336533616431\n353936363430656665366136636565343339316266353735393961666637346535383730643230\n373830306162313037666537643538313331643965643530336438623936653830656438313662\n61363163626263363265353933333539386238636330643533\n', secret='12345', vaultid='filter_default')
    assert a == 'password'


# Generated at 2022-06-23 10:14:24.663230
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    actual_data = do_vault(data, secret)
    assert actual_data.startswith('$ANSIBLE_VAULT;')
    assert actual_data.endswith(';')



# Generated at 2022-06-23 10:14:25.432098
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:14:36.453058
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.tests.unit.utils.unicode_helper import str
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    secret = str("password")
    demo_string = str("This is a Demo string.")
    vl = VaultLib()
    vs = VaultSecret(secret)
    encrypted_string = vl.encrypt(demo_string, vs)
    decrypted_string = do_unvault(encrypted_string, secret)
    assert demo_string == decrypted_string


# Generated at 2022-06-23 10:14:43.085044
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_case = [{
            "in": {
                "data": "test",
                "secret": "vault filter test",
            },
            "out": AnsibleVaultEncryptedUnicode,
        }]

    f = FilterModule()
    for each in test_case:
        value = f.filters()['vault'](
            each['in']['data'],
            each['in']['secret'],
            wrap_object=True,
        )

        assert isinstance(value, each['out'])

    display.display("PASS")



# Generated at 2022-06-23 10:14:53.833802
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'


# Generated at 2022-06-23 10:14:56.481026
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:14:58.461750
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:14:59.486520
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:15:08.549218
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:20.304324
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n633163633837333436306634373263316332323235343165343733363561306562373233343539613\n3663238626661306234353139353462393131363665343339393561643204371b93bea02fe23acb\n84558fba79e2b2d03b00409cc8e73ce1f2', 'somesecret') == "This is a secret\n"

# Generated at 2022-06-23 10:15:22.339730
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()