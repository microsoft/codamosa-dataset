

# Generated at 2022-06-23 10:05:33.962666
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from ansible.parsing.vault import VaultSecret, VaultLib

    # Unencrypted data
    data = "This is unencrypted data"

    # Secret key to encrypt data
    secret = "ansible"
    vs = VaultSecret(secret)
    vl = VaultLib()

    # Encrypt data
    vault = vl.encrypt(data, vs, salt='8888')

    # Test do_vault() with default salt
    f = FilterModule()
    assert f.filters()['vault'](data=data, secret=secret) == vault

    # Test do_vault() with pass custom salt
    assert f.filters()['vault'](data=data, secret=secret, salt='8888') == vault

    # Test do_unvault()

# Generated at 2022-06-23 10:05:35.319307
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f=FilterModule()
    assert f

# Generated at 2022-06-23 10:05:40.006258
# Unit test for function do_vault
def test_do_vault():
   result = do_vault('foo', 'vault_password', 'salt')
   assert result.startswith('$ANSIBLE_VAULT;1.1;AES')


# Generated at 2022-06-23 10:05:53.139417
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()

    # Test AnsibleVaultEncryptedUnicode object as vault in do_unvault method
    vault_obj = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256;vault_default\n35643165313430373863313631323065343737623035393962323864656661610a36656636373533633933383462313332656262393063303739333537653163\n")
    assert "This is secret" == do_unvault(vault_obj, "password")

    # Test unvault method with vault string

# Generated at 2022-06-23 10:05:55.474890
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f_module = FilterModule()
    assert f_module is not None


# Generated at 2022-06-23 10:06:03.516814
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    secret = 'vault_secret'
    data = 'I am plaintext'
    test_data = 'AQDSAWVhR1JEZnplMTZPbXhPdFB6b3NWOU1Fc2FIQUpWZgF6bG5HZVxkZlxEZlx6Zlx6'
    test_data_wrapped = '!vault |' + test_data
    vault = filter_module.filters()['vault'](data, secret)
    unvault = filter_module.filters()['unvault'](vault, secret)
    assert test_data in vault
    assert data in unvault

# Generated at 2022-06-23 10:06:06.849992
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()

# Generated at 2022-06-23 10:06:15.182673
# Unit test for function do_unvault
def test_do_unvault():
    # Create a vault string
    vault_string = '$ANSIBLE_VAULT;1.1;AES256;foo123\n343530343664633938333866386430666364336634643066313033306538303530326230363664\n303233363861633136366636653732626636376465336238323163326165373435373863356431\n643137616564663762366466343633353661636339613261346331633332306266346338\n'
    secret = 'foobar'

    # Test the unvault function
    unvaulted_string = do_unvault(vault_string, secret, 'filter_default')

# Generated at 2022-06-23 10:06:18.659044
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = 'DumbPassw0rd'
    secret = 'ThisIsASuperSecret'
    vault = do_vault(data, secret)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 10:06:22.006316
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters.get('vault') == do_vault
    assert filters.get('unvault') == do_unvault

# Unit tests for method do_vault of class FilterModule

# Generated at 2022-06-23 10:06:33.084757
# Unit test for function do_vault
def test_do_vault():
    """ Validate function_vault filter. """

    data = 'My secret message.'
    secret = 'My secret password.'
    vaultid = 'filter_default'
    wrap_object = True

    assert do_vault(data, secret, vaultid, wrap_object)

    data = ''
    secret = ''
    vaultid = 'filter_default'
    wrap_object = True

    assert not do_vault(data, secret, vaultid, wrap_object)

    data = 1
    secret = 1
    vaultid = 'filter_default'
    wrap_object = True

    assert not do_vault(data, secret, vaultid, wrap_object)

    data = []
    secret = []
    vaultid = 'filter_default'
    wrap_object = True


# Generated at 2022-06-23 10:06:33.700199
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:06:39.792698
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test for success
    filter_module = FilterModule()
    assert filter_module.filters() == {"vault": do_vault, "unvault": do_unvault}
    # Test for failure
    try:
        filter_module = FilterModule()
        assert filter_module.filters() == {"vault": do_vault, "unvault_test": do_unvault}
    except AssertionError:
        assert True



# Generated at 2022-06-23 10:06:43.549283
# Unit test for function do_unvault
def test_do_unvault():

    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.2;AES256;%s;63337372616c7433353561383264393662336162626662346233336164623863373762' % ('vault_name'))
    assert do_unvault(vault, 'secret') == 'secret_string'

# Generated at 2022-06-23 10:06:45.304507
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    assert mod is not None



# Generated at 2022-06-23 10:06:47.903457
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == { 'vault': do_vault, 'unvault': do_unvault }


# Generated at 2022-06-23 10:06:56.893662
# Unit test for function do_vault
def test_do_vault():
    secret = to_native(b'TEST_SECRET')
    data = to_native(b'TEST_DATA')
    salt = to_native(b'TEST_SALT')
    vaultid = 'TEST_VAULTID'

    # Test with salt
    vault = do_vault(data, secret, salt, vaultid)

    assert isinstance(vault, string_types)
    assert is_encrypted(vault) is True

    # Test without salt
    vault = do_vault(data, secret)

    assert isinstance(vault, string_types)
    assert is_encrypted(vault) is True



# Generated at 2022-06-23 10:07:08.283400
# Unit test for function do_unvault
def test_do_unvault():

    secret = "foobar"
    vaultid = "filter_default"

    data = "testdata"

    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    encrypted = vl.encrypt(to_bytes(data), vs, vaultid, None)

    assert do_unvault(encrypted, secret, vaultid) == data
    assert do_unvault(encrypted, secret) == data
    assert do_unvault(encrypted, secret, vaultid=None) == data
    assert do_unvault(encrypted, secret, vaultid='') == data

    # Test defaults
    encrypted_vault = AnsibleVaultEncryptedUnicode(encrypted)
    encrypted_vault.vault = vl

# Generated at 2022-06-23 10:07:19.138508
# Unit test for function do_vault

# Generated at 2022-06-23 10:07:24.681895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from collections import Mapping

    fm = FilterModule()

    assert isinstance(fm.filters(), Mapping)
    assert fm.filters()['unvault'] == do_unvault
    assert fm.filters()['vault'] == do_vault

# Generated at 2022-06-23 10:07:27.407608
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:07:28.620970
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()


# Generated at 2022-06-23 10:07:29.608528
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-23 10:07:37.815002
# Unit test for function do_vault

# Generated at 2022-06-23 10:07:48.292455
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    assert filter_module.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;test\n33303832383034326263393435393661623063393363346666373332663864356634333432313863\n33393730343539333236663635613339616261306366646541362d323039\n', 'secret') == '1234567890'

# Generated at 2022-06-23 10:08:00.298709
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;7.03;AES256'
    data = 'Dorothy the goldfish'
    vault = '''$ANSIBLE_VAULT;7.03;AES256
                  6432393865303864383636643861653661366166323662626564663537636432643037613635
                  3337633235376462643733623462313066376433626132343162346331613239616434303566
                  3963323835343062633562666131623763396161303430393539373263373530'''

    assert do_vault(data, secret) == vault


# Generated at 2022-06-23 10:08:08.869479
# Unit test for function do_vault
def test_do_vault():
    result = do_vault("foo", "bar")

# Generated at 2022-06-23 10:08:11.212695
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filter_dict = filter_module.filters()
    assert 'vault' in filter_dict
    assert 'unvault' in filter_dict

# Generated at 2022-06-23 10:08:23.397632
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:26.309306
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None



# Generated at 2022-06-23 10:08:36.858323
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.listify import listify_lookup_plugin_terms

    test_data = """
---
password: my_password
password_b64: "{{ password | b64encode }}"
password_b64_vault: "{{ password_b64 | vault('pass') }}"
password_vault: "{{ password | vault('pass') }}"
"""
    data = {'password': 'my_password'}
    secret = 'secret'

    # First check if vault_data_encrypted is True
    vault_data_encrypted = VaultLib()
    # TODO: add a way to get this variable
    #for yaml_data in listify_lookup_plugin_terms(test_data, templar=self.mock_templar,

# Generated at 2022-06-23 10:08:38.134910
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:08:39.026163
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule() != None)

# Generated at 2022-06-23 10:08:41.142383
# Unit test for function do_vault
def test_do_vault():
    assert AnsibleFilterTypeError in do_vault.__code__.co_varnames

# Generated at 2022-06-23 10:08:44.890258
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:08:53.514386
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import inspect
    import types

    assert sys is not None
    assert inspect is not None
    assert types is not None
    assert FilterModule is not None

    filter_module_object = FilterModule()
    assert filter_module_object is not None
    assert isinstance(filter_module_object, FilterModule)

    filters_func = None
    try:
        filters_func = filter_module_object.filters
    except AttributeError:
        assert False


# Generated at 2022-06-23 10:09:02.498094
# Unit test for function do_unvault
def test_do_unvault():
    secret = "PASSWORD"

# Generated at 2022-06-23 10:09:05.797435
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    value = "hello"
    vault = do_vault(value, secret)
    assert is_encrypted(vault) is True
    assert value == do_unvault(vault, secret)


# Generated at 2022-06-23 10:09:13.355347
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys
    import pytest

    # Setup
    sys.stderr = StringIO()

# Generated at 2022-06-23 10:09:27.349595
# Unit test for function do_vault
def test_do_vault():
    # test correct do_vault
    test_data = b'Vault_test'
    test_pass = 'password'
    test_salt = 'salt'
    test_vaultid = 'vault_test'
    data = do_vault(test_data, test_pass, test_salt, test_vaultid)

# Generated at 2022-06-23 10:09:30.641843
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # test normal
    filter_module = FilterModule()
    assert filter_module.__class__.__name__ == 'FilterModule'



# Generated at 2022-06-23 10:09:37.909485
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    import pytest
    filter_plugin = FilterModule()
    env = Environment()
    env.filters.update(filter_plugin.filters())
    # Test with vaultid
    filtered = env.from_string('''{{ "ansible" | vault("s3cr3t", "f00", "filter_default") }}''').render()

# Generated at 2022-06-23 10:09:41.512537
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test the constructor with passing valid parameters
    # Here there is no parameters to pass
    # Test that the return of the constructor is correct
    assert isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-23 10:09:53.851625
# Unit test for function do_vault
def test_do_vault():
    vault_secrets = {'filter_default': 'a_password_that_is_not_the_same_as_vim_fileencoding'}
    vs = VaultSecret(to_bytes(vault_secrets['filter_default']))

    vl = VaultLib()
    vault = vl.encrypt(to_bytes('Vaulted text'), vs, 'filter_default')

# Generated at 2022-06-23 10:09:57.292410
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("test", "vault_secret", "salt") == "$ANSIBLE_VAULT;1.1;AES256;base-64"



# Generated at 2022-06-23 10:10:01.831369
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filtermodule = FilterModule()
    filters = filtermodule.filters()

    assert filters is not None
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-23 10:10:03.288742
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:10:03.854532
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:10:13.106361
# Unit test for constructor of class FilterModule
def test_FilterModule():

    import sys
    from ansible.module_utils._text import to_bytes, to_unicode, to_native
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    secrets = [
        to_bytes('secret'),
        to_bytes('secret'),
        to_bytes('secret'),
        to_bytes('secret'),
        to_bytes('secret'),
        to_bytes('secret'),
    ]

    vault_id = 'test_filter_vault'
    seed_values = set()
    vl = VaultLib()
    while len(seed_values) < len(secrets):
        seed_values.add(vl.get_random_bytes(vl.get_default_seed_length()))


# Generated at 2022-06-23 10:10:13.795803
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule().filters()

# Generated at 2022-06-23 10:10:15.256292
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_plugins = FilterModule()
    assert filter_plugins.filters() == {
        'vault': do_vault,
        'unvault': do_unvault
    }

# Generated at 2022-06-23 10:10:19.538005
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert len(filters.keys()) == 2
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()
    assert callable(filters['vault'])
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:10:22.377320
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_object = FilterModule()
    assert callable(test_object.filters())


# Generated at 2022-06-23 10:10:31.208748
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    ret = fm.filters()
    assert isinstance(ret, dict)
    assert "vault" in ret
    assert "unvault" in ret

    assert callable(ret["vault"])
    assert ret["vault"](None, None) == None
    assert isinstance(ret["vault"]("foo", "bar"), str)

    assert callable(ret["unvault"])
    assert ret["unvault"](None, None) == None
    assert isinstance(ret["unvault"]("foo", "bar"), str)

# Generated at 2022-06-23 10:10:32.544662
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:10:32.885071
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:10:41.581870
# Unit test for function do_vault
def test_do_vault():
    data = "my_test_data"
    secret = "my_test_secret"
    salt = "my_test_salt"
    vaultid = "my_test_vaultid"
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    assert not is_encrypted(vault)
    assert vault != data

# Generated at 2022-06-23 10:10:50.905530
# Unit test for function do_vault
def test_do_vault():

    # do_vault(<data>, <secret>)
    #   <data> is either a string or a unicode string
    #   <secret> is either a string or a unicode string
    # return: a string

    # Test: <data> is a non-empty string
    # Test: <data> is an empty string
    # Test: <data> is not a string
    # Test: <secret> is a non-empty string
    # Test: <secret> is an empty string
    # Test: <secret> is not a string

    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_function = filters.get("vault")
    assert filter_function is not None

    # Test: <data> is a non-empty string
    test_data="This is a test"
    expected_

# Generated at 2022-06-23 10:10:52.800883
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}



# Generated at 2022-06-23 10:10:55.585038
# Unit test for function do_vault
def test_do_vault():
    secret = 'DontTellAnyone!!!'
    data = 'This is some secret data.'
    assert do_vault(data, secret) == do_vault(data, secret)


# Generated at 2022-06-23 10:11:00.516338
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class FilterModuleTest(FilterModule):
        def filters(self):
            return FilterModule.filters(self)
    fm = FilterModuleTest()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()

# Generated at 2022-06-23 10:11:12.917285
# Unit test for function do_vault
def test_do_vault():
    module = AnsibleModule(argument_spec={
        'data': {'type': 'str'},
        'secret': {'type': 'str'},
    })


# Generated at 2022-06-23 10:11:22.669443
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ unit testing for FilterModule.filters() method """

    class Obj(object):

        def __init__(self):
            self.obj_1 = 'abc'
            self.obj_2 = {'def': 'def'}

    obj = Obj()
    fm = FilterModule()
    filters = fm.filters()

    assert 'vault' in filters
    assert 'unvault' in filters

    # Testing vault
    secret = 'password'
    salt = 'AAAQ0gAAAAIAAAAAAAAAAAAAAAAGUsMRcAAAAB3NzaC1yc2EAAAADAQABAAABAQCpR'

# Generated at 2022-06-23 10:11:24.823451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters_module = FilterModule()
    filters = filters_module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:11:30.089042
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    filters = fm.filters()

    assert 'vault' in filters
    assert callable(filters['vault'])
    assert 'unvault' in filters
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:11:35.312134
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'test_secret'
    test_vaultid = 'test_vaultid'

# Generated at 2022-06-23 10:11:42.618698
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:11:52.848099
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()
    filters = filter_module.filters()
    filter_vault = filters['vault']
    filter_unvault = filters['unvault']

    plaintext = 'The quick brown fox jumped over the lazy dog'
    secret = 'test_vault_secret'
    salt = 'test_salt'
    vaultid = 'test_vaultid'

    with display.override_verbosity(0):
        vault = filter_vault(plaintext, secret, salt, vaultid)

    assert plaintext == filter_unvault(vault, secret, vaultid)

    with display.override_verbosity(0):
        vault_obj = filter_vault(plaintext, secret, salt, vaultid, True)


# Generated at 2022-06-23 10:11:58.902627
# Unit test for function do_unvault
def test_do_unvault():
    secret = "foo"
    test_data_1 = "test_data_1"
    test_data_2 = u"test_data_2"

    assert do_unvault(do_vault(test_data_1, secret), secret) == test_data_1
    assert do_unvault(do_vault(test_data_2, secret), secret) == test_data_2

# Generated at 2022-06-23 10:12:11.934840
# Unit test for function do_unvault
def test_do_unvault():
    import sys
    import os
    import yaml
    import pytest
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.dataloader import DataLoader

    # JUNIT_OUTPUT_DIR is defined in tox.ini
    junit_output_dir = os.environ.get('JUNIT_OUTPUT_DIR')
    if junit_output_dir is None:
        junit_output_dir = '.'

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import binary_type # pylint: disable=import-

# Generated at 2022-06-23 10:12:13.888089
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    args = fm.filters()

    assert 'vault' in args
    assert 'unvault' in args

# Generated at 2022-06-23 10:12:22.728730
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from argparse import Namespace
    from ansible.module_utils import basic

    test_args = {
        'ANSIBLE_MODULE_ARGS': {},
    }
    setattr(basic, 'AnsibleModule', lambda *args, **kwargs: Namespace(params=test_args))

    module = FilterModule()
    assert 'vault' in module.filters()
    assert 'unvault' in module.filters()



# Generated at 2022-06-23 10:12:26.880386
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_mod = FilterModule()
    filters = {
        'vault': do_vault,
        'unvault': do_unvault,
    }
    assert filter_mod.filters() == filters

# Generated at 2022-06-23 10:12:28.431877
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()


# Generated at 2022-06-23 10:12:37.988105
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\r\n33393430663862656339363834376232653335396332356439653631303933363461303861650a306463303764343733386332396136373338643634383233343930366630313236633138650a34643538376431623863316238656232626333323135356164366135646361376361633565\r\n', 'ansible') == 'secret'

# Generated at 2022-06-23 10:12:48.618832
# Unit test for function do_unvault
def test_do_unvault():
    assert(do_unvault('$ANSIBLE_VAULT;1.1;AES256;anonymous\n353332313438336664353039343633636430363336653435323138353666386434663035\n3963646631373233613333313332313736306534623963346538355a6535663431663730\n356533333538316465643936336232353432343230343637303835663335376637316439\n35\n', 'tooploox') == 'secret')

# Generated at 2022-06-23 10:12:56.531500
# Unit test for function do_unvault
def test_do_unvault():

    # Test for Normal Inputs
    # Input has valid vault and secret
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test89898989898989898989898989898989898989898989898989898989898989898989898989898989898989898989\n6335396661646266626238633234393532656337313733653265346632303461663764373661356139623037623634\n393534343832626333666232373939633530303165613337616430373538376332366164323466326263366362656\n', 'test') == 'test'

    # input has valid vault and secret
    assert do_un

# Generated at 2022-06-23 10:13:04.253163
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

    # Case 1: filters should be a dict with vault and unvault as keys; dict should have 2 keys
    assert isinstance(f.filters(), dict)
    assert len(list(f.filters().keys()))==2

    # Case 2: vault items in dict should be callable
    assert callable(f.filters()['vault'])

    # Case 3: unvault items in dict should be callable
    assert callable(f.filters()['unvault'])



# Generated at 2022-06-23 10:13:17.273472
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:23.395922
# Unit test for function do_unvault
def test_do_unvault():
    vault_secret = "password"

# Generated at 2022-06-23 10:13:24.464034
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:13:36.463401
# Unit test for function do_unvault
def test_do_unvault():
    assertion_test = False

    try:
        secret = 'test'
        vault = '$ANSIBLE_VAULT;1.2;AES256;test\n63376138343730353336363037633262633130336137623965393764626466386534393166363531\n30653637353665346632613832376165613231376264643763383232326438643162386564353062\n65316166393264373261323035616466343664663539643532643439623835356333393330623634\n'
        data = do_unvault(vault, secret)
        assertion_test = True
    except Exception as e:
        assertion_test = False
        print(e)

    assert assertion_

# Generated at 2022-06-23 10:13:38.241953
# Unit test for constructor of class FilterModule
def test_FilterModule():

    vault_filters = FilterModule()
    assert vault_filters is not None


# Generated at 2022-06-23 10:13:49.939528
# Unit test for function do_vault
def test_do_vault():
    d = do_vault("testdata", "testsecret", "testvaultid", True)
    assert type(d) is AnsibleVaultEncryptedUnicode
    assert d.vault is not None
    assert d.data == "testdata"
    assert d.vault_id == "testvaultid"

    d = do_vault("testdata", "testsecret", "testvaultid", False)
    assert not isinstance(d, AnsibleVaultEncryptedUnicode)
    assert isinstance(d, string_types)

    d = do_vault("testdata", "testsecret", "testvaultid")
    assert not isinstance(d, AnsibleVaultEncryptedUnicode)
    assert isinstance(d, string_types)


# Generated at 2022-06-23 10:13:51.124423
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-23 10:13:56.617154
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters['vault'] is do_vault
    assert filters['unvault'] is do_unvault

# Generated at 2022-06-23 10:14:00.817957
# Unit test for function do_vault
def test_do_vault():
    try:
        assert isinstance(do_vault('test', 'secret'), string_types)
    except Exception as e:
        display.error('Error in do_vault:')
        display.error(e)
        raise


# Generated at 2022-06-23 10:14:01.346035
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-23 10:14:03.965126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(None)
    assert 'unvault' in FilterModule.filters(None)


# Generated at 2022-06-23 10:14:05.438197
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule(object()).filters(), dict)

# Generated at 2022-06-23 10:14:15.927613
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'la' # string
    vaultid = 'filter_default'
    # success case
    data = '{"a": {"b": "c"}}' # string
    vault = '$ANSIBLE_VAULT;1.1;AES256;filter_default\n343937323565303737386535653230646164373665386436653532613635376432366365656230\n353661303633396435653864383065643536363132653166386637376466333038633565383533\n622a' # success case
    result = do_unvault(vault, secret, vaultid)
    assert result == data
    # Failed case: bad decryption

# Generated at 2022-06-23 10:14:19.815326
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Assignment
    fm = FilterModule()
    # Test with assertEquals
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-23 10:14:28.167353
# Unit test for function do_unvault
def test_do_unvault():

    # test unvault with no vault and not vault
    data = do_unvault(None, 'foo')
    assert data is None
    data = do_unvault('bar', 'foo')
    assert data == 'bar'

    # test unvault with vault input
    vault = '$ANSIBLE_VAULT;1.2;AES256;foo;bar'
    result = do_unvault(vault, 'foo')
    assert result == 'bar'

    # test unvault with vaultid
    vault = '$ANSIBLE_VAULT;1.2;AES256;new_vault;bar'
    result = do_unvault(vault, 'new_secret', vaultid='new_vault')
    assert result == 'bar'

    # test unvault with bad secret

# Generated at 2022-06-23 10:14:32.832605
# Unit test for function do_vault
def test_do_vault():
    secret = 'secr3t'
    data = 'A long string to encrypt'

# Generated at 2022-06-23 10:14:37.380678
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test = FilterModule()
    assert test.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:14:44.913955
# Unit test for function do_unvault
def test_do_unvault():
    # Set up the vault
    vaultid = 'test_id'
    secret = 'secret'
    vl = VaultLib([(vaultid, VaultSecret(secret))])

    # Encrypt the plaintext
    plaintext = 'some plaintext'
    vaulttext = vl.encrypt(plaintext, vl.secrets[vaultid], vaultid)

    # Test that we can decrypt the plaintext
    result = do_unvault(vaulttext, secret, vaultid)
    if result != plaintext:
        print("Error: do_unvault: Decrypted text did not match")
        return False

    # Test that we can decrypt an AnsibleVaultEncryptedUnicode object
    vault = AnsibleVaultEncryptedUnicode(vaulttext, vaultid)
    vault.vault = vl

   

# Generated at 2022-06-23 10:14:47.069031
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class EmptyFilterModule(FilterModule):
        pass
    assert EmptyFilterModule() is not None

# Generated at 2022-06-23 10:14:55.742858
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import jinja2
    from jinja2.runtime import Undefined
    from jinja2.exceptions import UndefinedError
    import sys
    import pytest

    from ansible.module_utils.six import string_types, binary_type
    from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted, VaultSecret
    from ansible.utils.display import Display

    display = Display()

    # Create environment to load the module and run the filters
    env = jinja2.Environment()
    env.filters['vault'] = do_vault
    env.filters['unvault'] = do_unvault

    # Test do

# Generated at 2022-06-23 10:15:06.232262
# Unit test for function do_unvault
def test_do_unvault():
    secret = VaultSecret('PASSWORD')
    vl = VaultLib([('filter_default', secret)])
    orig_str = u'I am a vaulted string'
    vaulted_str = vl.encrypt(orig_str)
    assert do_unvault(vaulted_str, 'PASSWORD') == orig_str

    # Make sure that if it's not vaulted, we get back the same thing as what we pass in
    vaulted_str = u'I am an unvaulted string.'
    assert do_unvault(vaulted_str, 'PASSWORD') == vaulted_str

# Generated at 2022-06-23 10:15:15.929250
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('my_secret_data', 'my_secret_password', salt='my_salt') == '$ANSIBLE_VAULT;1.1;AES256;my_salt\n34623134636235616233623363323839336266623333393538306335643134346435363364313435\n38663963303631336637343064666237316536356234363437343162303232\n'


# Generated at 2022-06-23 10:15:24.351319
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("secret", "password") == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          38393365663737356632633634393834306231326266306332376339313565343763383538393234\n          6233633036663039666232373266666338323665360a333564616537396235663661653362616233\n          32763134303635393832626231303236356232386165633431376136636231366237333762333562\n          66646635613037650a646335353437656530363935366665343837623365306362\n"
