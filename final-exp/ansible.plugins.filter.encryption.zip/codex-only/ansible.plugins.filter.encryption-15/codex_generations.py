

# Generated at 2022-06-23 10:05:29.107170
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:05:30.910305
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:05:36.384355
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_obj = FilterModule()
    filters = filter_obj.filters()
    assert filters.get('vault') == do_vault
    assert filters.get('unvault') == do_unvault

# Generated at 2022-06-23 10:05:44.834500
# Unit test for function do_unvault
def test_do_unvault():
    """Test vaulting with salt and vaultid."""
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml import load
    from ansible.module_utils.six import text_type

    secret1 = VaultSecret('SECRET_1')
    secret2 = VaultSecret('SECRET_2')
    vaultlib = VaultLib([('foo', secret1), ('bar', secret2)])
    data_unvaulted = 'hello world'
    # Invalid vaultid raises an exception
    data_vaulted = vaultlib.encrypt(data_unvaulted, secret1, 'foo')
    assert do_unvault(data_vaulted, 'SECRET_1', 'foo') == data_unvaulted

# Generated at 2022-06-23 10:05:49.461213
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    fm = FilterModule()
    filters = fm.filters()

    assert 'unvault' in filters
    assert 'vault' in filters

    assert filters['unvault'] == do_unvault
    assert filters['vault'] == do_vault


# Generated at 2022-06-23 10:05:51.718362
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(object) == { 'vault': do_vault, 'unvault': do_unvault }



# Generated at 2022-06-23 10:05:52.902895
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters()

# Generated at 2022-06-23 10:06:03.014673
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:03.874819
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True == isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:06:07.028682
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters is not None, "Method filters of class FilterModule should not return None"

# Generated at 2022-06-23 10:06:08.892794
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:06:14.719881
# Unit test for function do_vault
def test_do_vault():
    test = do_vault('test', 'secret', 'salt')
    assert test == '$ANSIBLE_VAULT;1.2;AES256;salt\n35373366643639656535326336323165623431613938633563303339623861386132366361316536\n39303362636532373031623235363330613332393662353539396634356234343231376336653639\n3766623461336436\n'


# Generated at 2022-06-23 10:06:21.673963
# Unit test for function do_vault
def test_do_vault():
    # default wrapping
    assert b'$ANSIBLE_VAULT;1.1;AES256\n39323134353764356164613161323064656337316463356239633239623836373930626635313765\n33353066653934666435306535336663376561653235623164363638653632346632663737356662\n37303437323030346435333936383666393539633464333066323166366663303066643832656662\n\n'.startswith(do_vault(b'The quick brown fox jumps over the lazy dog', b'secret').encode())

    # no wrapping

# Generated at 2022-06-23 10:06:23.211669
# Unit test for constructor of class FilterModule
def test_FilterModule():
    t = FilterModule()
    assert isinstance(t, FilterModule)


# Generated at 2022-06-23 10:06:28.777381
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'vault' in obj.filters()
    assert 'unvault' in obj.filters()
    assert obj.filters()['vault'] == do_vault
    assert obj.filters()['unvault'] == do_unvault


# Generated at 2022-06-23 10:06:32.355953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}



# Generated at 2022-06-23 10:06:34.598706
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    assert filtermodule is not None



# Generated at 2022-06-23 10:06:43.062492
# Unit test for function do_unvault
def test_do_unvault():
    # Test for strings
    assert do_unvault('tobeunvaulted', 'ansible') == 'tobeunvaulted', "Failed to unvault string"

    # Test for list

# Generated at 2022-06-23 10:06:54.499307
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'xxxx'
    vaultid = 'filter_default'

# Generated at 2022-06-23 10:07:06.943458
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted

    test_secret = 'test'
    vault = VaultLib([('test_vaultid', VaultSecret(test_secret))])
    plaintext = 'test_plaintext'

    # test with plaintext
    assert plaintext == do_unvault(plaintext, test_secret)
    assert plaintext == do_unvault(plaintext, 'test_secret')

    # test with encrypted data
    plaintext2 = 'test_plaintext2'
    encrypted_data = vault.encrypt(plaintext2)
    assert plaintext2 == do_unvault(encrypted_data, test_secret)
    assert plaintext2 == do_un

# Generated at 2022-06-23 10:07:08.283504
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-23 10:07:10.197281
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert type(FilterModule()) == FilterModule

# Generated at 2022-06-23 10:07:10.748254
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:07:15.659044
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Environment
    env = Environment()
    env.filters['vault'] = do_vault
    template = env.from_string("{{ 'vaultme' | vault('MYSECRET', 'SALTS') }}")
    assert template.render().strip() == "$ANSIBLE_VAULT;1.1;AES256;SALTS"

# Generated at 2022-06-23 10:07:26.509549
# Unit test for function do_unvault
def test_do_unvault():
    display.verbosity = 0
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test_default\n3435666237366134386537356632323934323832626461623862353338316430653331313530666\n62633336343133633861633862346263346362323464303837326566356631363037333262363230\n66376130636532353262626264386239396530393463366365\n', 'ansible') == 'password'


# Generated at 2022-06-23 10:07:31.356254
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    filterModuleFilters = filterModule.filters()
    assert len(filterModuleFilters) == 2
    assert filterModuleFilters['vault'] == do_vault
    assert filterModuleFilters['unvault'] == do_unvault

# Generated at 2022-06-23 10:07:32.275926
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-23 10:07:39.672907
# Unit test for function do_vault
def test_do_vault():
    secret = "testsecret"
    data = "testdata"
    salt = "testtestsalt"
    vaultid = "testvaultid"
    wrap_object = False

# Generated at 2022-06-23 10:07:48.723459
# Unit test for function do_unvault
def test_do_unvault():
    secret_text = "thisismysecret"

# Generated at 2022-06-23 10:08:01.251090
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types, binary_type

    # initialize
    yaml_data = 'password'
    secret = 'password'
    salt = 'random_string'
    vaultid = 'filter_default'
    wrap_object = False
    f = FilterModule()
    ansible_vault_result = AnsibleVaultEncryptedUnicode
    vault_result = string_types

    # test filters
    assert isinstance(f.filters()['vault'](yaml_data, secret, salt, vaultid, wrap_object), ansible_vault_result)

# Generated at 2022-06-23 10:08:03.067181
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None



# Generated at 2022-06-23 10:08:05.697462
# Unit test for function do_vault
def test_do_vault():
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault('hello world', 'secret', vaultid='filter_default')


# Generated at 2022-06-23 10:08:12.207472
# Unit test for function do_unvault
def test_do_unvault():

    try:
        do_unvault("test", "123")
    except AnsibleFilterTypeError:
        pass
    else:
        raise "Expected a AnsibleFilterTypeError"

    try:
        do_unvault("test", 123)
    except AnsibleFilterTypeError:
        pass
    else:
        raise "Expected a AnsibleFilterTypeError"

    try:
        do_unvault(123, "123")
    except AnsibleFilterTypeError:
        pass
    else:
        raise "Expected a AnsibleFilterTypeError"


# Generated at 2022-06-23 10:08:23.038169
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    vaultid = 'test_do_vault'
    vault = do_vault('string', secret, vaultid=vaultid)
    assert isinstance(vault, str)
    assert vault == "$ANSIBLE_VAULT;1.2;AES256;test_do_vault\n3638373034383538333734393663303061346534636313432383336316362656166373163386131613732370a6338316666326462386337393733336232353565326336626664383438623033316462373939653436363136633836\n"


# Generated at 2022-06-23 10:08:34.848395
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:35.906348
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert callable(FilterModule)

# Generated at 2022-06-23 10:08:44.040026
# Unit test for function do_unvault
def test_do_unvault():
    import sys

    display.display(do_unvault('$ANSIBLE_VAULT;1.2;AES256;test\n663530646265393063353962386434613763383132326331396132383239643336666439353464\n396332343339643530366436616434383539386162346336610a39653965366634666335643338\n623364623862343035393735633036313835663661643239363035343233623838616130343661\n633138646666393730346665\n', 'ansible', vaultid='test'))


# Generated at 2022-06-23 10:08:45.852917
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (FilterModule().filters() is not None)


# Generated at 2022-06-23 10:08:59.506332
# Unit test for function do_unvault
def test_do_unvault():
    """
    Tests the return data from do_unvault
    """

# Generated at 2022-06-23 10:09:01.029005
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    print(fm)

# Generated at 2022-06-23 10:09:02.088639
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters()

# Generated at 2022-06-23 10:09:04.735758
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:09:06.017057
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Test that FilterModule is created without errors"""
    FilterModule()

# Generated at 2022-06-23 10:09:08.612807
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert not filters is None
    assert len(filters.keys()) == len(['vault', 'unvault'])

# Generated at 2022-06-23 10:09:19.682832
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:09:22.951793
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:09:25.374863
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test the return type of filters
    assert isinstance(FilterModule.filters(None), dict)


# Generated at 2022-06-23 10:09:34.417846
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secretEncryptionKey'
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          30666537376638633761623665653736356537643266333937653764326466613761326638306366\n          33323731666564343366393465333232303366643537626464653332613338613466326361646662\n          35356539353662663331303464343264396538353864663230396737323066646162323031303230\n          62636131613339323831393761663832343033386431613465643061\n"


# Generated at 2022-06-23 10:09:39.108742
# Unit test for function do_vault
def test_do_vault():
    d = FilterModule()
    f = d.filters()

# Generated at 2022-06-23 10:09:40.261921
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-23 10:09:43.174986
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()
    assert 'unvault' in filter_module.filters()


# Generated at 2022-06-23 10:09:48.226951
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:09:53.459991
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault("foobar", "password") == """$ANSIBLE_VAULT;1.1;AES256
353239316366613231366232393339333164656638326634353337633934366662633737303538
3466363630663338393266323930666462653839656535336435666531
""")


# Generated at 2022-06-23 10:09:59.304347
# Unit test for function do_unvault
def test_do_unvault():

    # Test that failure occurs if vault is not a string
    try:
        do_unvault(vault=1, secret="1")
        assert False, "AnsibleFilterTypeError wasn't raised!"
    except AnsibleFilterTypeError:
        assert True

    # Test that failure occurs if vault is not a string
    try:
        do_unvault(vault=1, secret="1")
        assert False, "AnsibleFilterTypeError wasn't raised!"
    except AnsibleFilterTypeError:
        assert True

    # Test that failure occurs if data is not a string
    try:
        do_unvault(vault="!vault |", secret=1)
        assert False, "AnsibleFilterTypeError wasn't raised!"
    except AnsibleFilterTypeError:
        assert True

    # Test that failure occurs if

# Generated at 2022-06-23 10:10:08.748862
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils.common.text_type import to_native
    import os
    # test unvault
    vault_secret = os.environ.get("VAULT_PASSWORD", "")
    vault_secret_2 = os.environ.get("VAULT_PASSWORD_2", "")
    data = 'abcdefg'
    vault_data = do_vault(data, vault_secret)
    unvault_data = do_unvault(vault_data, vault_secret)
    assert data == unvault_data

    # test unvault with multiple IDs
    vault_id_1 = "vault_id_1"
    vault_id_2 = "vault_id_2"

# Generated at 2022-06-23 10:10:11.010196
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:10:21.481272
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    hypenated_vault_id = 'filter-default'
    vaultid = 'filter_default'

# Generated at 2022-06-23 10:10:28.494808
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'mysecret') == '$ANSIBLE_VAULT;1.1;AES256\n316439303464313638393336383362366139613831633539303436353364316434663736633a0a3335613734393564613335396565383538326234333636663564616663656166650a'


# Generated at 2022-06-23 10:10:31.099149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:10:37.760684
# Unit test for function do_unvault
def test_do_unvault():

    assert do_unvault(None, None) == None
    assert do_unvault('test', None) == 'test'

    secret = 'secret'

# Generated at 2022-06-23 10:10:49.324153
# Unit test for function do_unvault
def test_do_unvault():
    # Test to decrypt valid vault data
    secret_key = 'SECRETKEY'
    vault_data = '$ANSIBLE_VAULT;1.1;AES256;default;66616333366265653964646333383335363738653235323762613033360a626632356234633232626562616233386231333664363366646538666435383738653761303539653232626531636231330a3237373537656235393663666366343333613665653337623463623234333735653034393033616136613763376636653533'

    decrypted_data = 'test'

# Generated at 2022-06-23 10:10:50.213589
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:10:52.426956
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'unvault' in filters
    assert 'vault' in filters


# Generated at 2022-06-23 10:11:00.038916
# Unit test for function do_vault
def test_do_vault():
    import hashlib
    import random
    import string

    # Let's create a secret passphrase
    random_string = ''.join(random.choice(string.ascii_lowercase) for i in range(16))
    secret = hashlib.sha256(random_string.encode('utf-8')).hexdigest()

    # Let's create a random string
    random_string = ''.join(random.choice(string.ascii_lowercase) for i in range(16))

    # We can encrypt the string
    vault = do_vault(random_string, secret)
    assert(isinstance(vault, AnsibleVaultEncryptedUnicode))

    # We can decrypt the same string
    data = do_unvault(vault, secret)
    assert(random_string == data)

    # The file

# Generated at 2022-06-23 10:11:03.833646
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f.filters(), dict)
    assert 'vault' in f.filters()
    assert 'unvault' in f.filters()


# Generated at 2022-06-23 10:11:15.720866
# Unit test for function do_vault
def test_do_vault():
    import sys
    import hashlib
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    # This code is not running in a Python 3.5 environemnt and therefore we have to mock random.SystemRandom
    # so the unittest will run on all supported python versions.
    class SystemRandomMock(object):
        def __init__(self):
            self.rng = MagicMock(name='rng')

        def randrange(self, a, b=None, *args, **kwargs):
            ret = self.rng.randrange(a, b, *args, **kwargs)
            return ret


# Generated at 2022-06-23 10:11:24.082422
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:27.198285
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:11:30.532536
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:11:31.128656
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:11:40.796028
# Unit test for function do_unvault
def test_do_unvault():
    secret = "password"

# Generated at 2022-06-23 10:11:49.728601
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('data', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n393064373165336462333234343635366464616530643731653364623332343436353664646165\n3064373165336462333234343635366464616530643731653364623064373165336462\n0300de2b7f10e5f5e5d02dc837a2d4b6d4e4f4a4b813b7e97b65e\n'


# Generated at 2022-06-23 10:11:53.040853
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filtermodule = FilterModule()
    assert filtermodule.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:11:54.589733
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_ = FilterModule()
    assert class_.filters()

# Generated at 2022-06-23 10:11:57.724348
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('Hello, World!', 'secret', salt='abc')
    assert vault == '$ANSIBLE_VAULT;1.1;AES256'



# Generated at 2022-06-23 10:12:11.128328
# Unit test for function do_unvault
def test_do_unvault():
    f = FilterModule()
    unvault_f = f.filters()['unvault']

    # Test unvaulting a plain string
    plain_string = 'This is a plain string.'
    plain_string_unvaulted = unvault_f(plain_string, 'password')
    assert plain_string_unvaulted == plain_string, 'Unvaulting a plain string failed.'

    # Test unvaulting an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-23 10:12:14.962458
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Create an instance of class FilterModule
    filter = FilterModule()
    # Verify that the FilterModule class constructor creates an object with the expected attribute
    assert hasattr(filter, "filters")


# Generated at 2022-06-23 10:12:17.860634
# Unit test for constructor of class FilterModule
def test_FilterModule():

    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-23 10:12:26.692473
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("secret", "password", "salt", "default", True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault

    # try to do some decryption
    vault_str = to_native(vault.data)
    from_vault = do_unvault(vault_str, "password", "default")
    assert from_vault == "secret"

    # make sure that we can decrypt the same data using vault object
    data = vault.data
    assert data == vault_str
    assert vault.decrypt(data) == 'secret'

    # let's make sure that the string is encrypted
    assert is_encrypted(vault_str)

    # make sure that we don't try to encrypt garbage
    data = None

# Generated at 2022-06-23 10:12:37.592880
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    filters = filter_module.filters()


# Generated at 2022-06-23 10:12:48.974781
# Unit test for function do_vault
def test_do_vault():
    print ("Running test_do_vault")
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert vault != ''
    assert is_encrypted(vault)

    vault = do_vault(data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)

    try:
        secret = None
        data = 'data'
        do_vault(data, secret)
        assert False, "do_vault() accepted a secret with a wrong type."
    except AnsibleFilterTypeError as e:
        pass
    except:
        assert False, "do_vault() failed with an unexpected exception: %s" % sys.exc_info()[0]


# Generated at 2022-06-23 10:12:56.693830
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import AnsibleVaultEncryptedUnicode

    vault_secret = "VAULT_SECRET"

    data = "VAULT_DATA"
    vault = "!vault |\n          $ANSIBLE_VAULT;" + do_vault(data, vault_secret)
    data_returned = do_unvault(vault, vault_secret)
    assert data == data_returned

    data = "data"
    vault = AnsibleVaultEncryptedUnicode("!vault |\n          $ANSIBLE_VAULT;" + do_vault(data, vault_secret))
    data_returned = do_unvault(vault, vault_secret)
    assert data == data_returned

    data = "data"
    unvaulted = do_unvault

# Generated at 2022-06-23 10:13:06.684409
# Unit test for function do_vault
def test_do_vault():
    secret = 'VaultSecret'
    data = 'test_do_vault'

# Generated at 2022-06-23 10:13:18.423439
# Unit test for function do_vault

# Generated at 2022-06-23 10:13:20.808262
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:13:33.790161
# Unit test for function do_vault
def test_do_vault():
    ''' Unit test for function do_vault '''
    display.vvvv(__file__)
    display.vvvv("Running unit test for function do_vault")

    # Verify exception for asking for vaulting of non-string
    try:
        do_vault(1, 'password')
    except AnsibleFilterTypeError as e:
        display.vvvv("Expected exception thrown (wrong type): %s" % to_native(e))
    else:
        raise AssertionError("Expected exception not thrown")

    # Verify exception for asking for vaulting of undefined
    try:
        do_vault(Undefined, 'password')
    except AnsibleFilterTypeError as e:
        display.vvvv("Expected exception thrown (undefined): %s" % to_native(e))
    else:
        raise Assert

# Generated at 2022-06-23 10:13:46.126624
# Unit test for function do_vault

# Generated at 2022-06-23 10:13:56.100955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    secret = "test_secret"
    assert isinstance(filter_module.filters(), dict)
    assert "vault" in filter_module.filters()
    assert isinstance(filter_module.filters()["vault"], type(do_vault))
    assert "unvault" in filter_module.filters()
    assert isinstance(filter_module.filters()["unvault"], type(do_unvault))

    # Test for input data type
    data = 123
    try:
        do_vault(data, secret)
        assert False
    except AnsibleFilterTypeError:
        assert True

    data = 123.56
    try:
        do_vault(data, secret)
        assert False
    except AnsibleFilterTypeError:
        assert True

   

# Generated at 2022-06-23 10:13:59.518627
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:14:09.381728
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib

    secret = 'supersecret'
    vaultid = 'filter_default'
    vs = VaultSecret(secret)
    vl = VaultLib([(vaultid, vs)])

    # test with normal string
    data = 'test123'
    output = do_unvault(vl.encrypt(data, salt='salt'), secret, vaultid=vaultid)
    assert output == data

    # test with string that is already encrypted
    data = 'test123'
    output = do_unvault(vl.encrypt(data, salt='salt'), secret, vaultid=vaultid)
    assert output == data

    # test with VaultEncryptedUnicode
    data = 'test123'


# Generated at 2022-06-23 10:14:13.968440
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert('vault' in filters.keys())
    assert('unvault' in filters.keys())


# Generated at 2022-06-23 10:14:24.298375
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    vaultid = 'filter_default'

    # Test functions returns data when it's not encrypted
    data = 'test data'
    assert do_unvault(data, secret, vaultid) == data

    # Test function raises error when vault is not string
    vault = 1
    try:
        do_unvault(vault, secret, vaultid)
        failed = False
    except Exception as e:
        failed = True
    assert failed

    # Test function raises error when secret is not string

# Generated at 2022-06-23 10:14:30.264932
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(None, None) == ''
    assert do_vault('mysecret', None) == ''
    assert do_vault(None, 'mysecret') == ''
    assert do_vault('mysecret', 'notsecret') == ''
    assert do_vault('mysecret', '', None, wrap_object=True).__class__ == AnsibleVaultEncryptedUnicode
    assert do_vault('mysecret', 'notsecret', None, wrap_object=True).__class__ == AnsibleVaultEncryptedUnicode
    assert do_vault('mysecret', 'notsecret', None, 'filter_default', True).vaultid == 'filter_default'
    assert do_vault('mysecret', 'notsecret', 'saltkey', 'filter_default', True).salt == 'saltkey'

# Generated at 2022-06-23 10:14:41.497744
# Unit test for function do_vault
def test_do_vault():
    secret = '$ANSIBLE_VAULT;1.1;AES256\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\naaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n'
    salt = 'aaaaaaaaaaaaaaaa'
    vaultid = 'test_vault'
    vault = do_vault('katarina_ho@mymail.sutd.edu.sg', secret, salt, vaultid)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode), "Wrong type of vault"
    assert not vault.data == "katarina_ho@mymail.sutd.edu.sg", "Filtered vault object is not equal"


# Generated at 2022-06-23 10:14:43.824437
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:14:54.129342
# Unit test for function do_vault
def test_do_vault():
    secret = 'my_secret'
    salt = '5dbd2ecee59c'
    data = 'my_data'
    vaultid = 'filter_test'

    vault = do_vault(data, secret, salt, vaultid, wrap_object=False)


# Generated at 2022-06-23 10:14:58.857475
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret', vaultid='test_vaultid') == '$ANSIBLE_VAULT;1.1;AES256;test_vaultid\n633633656534393263613733663864393764333230316138613432666639363332326538303661633d00\n'


# Generated at 2022-06-23 10:15:01.276933
# Unit test for constructor of class FilterModule
def test_FilterModule():
    creator = FilterModule()
    filters = creator.filters()
    assert filters is not None and len(filters) == 2

# Generated at 2022-06-23 10:15:09.061823
# Unit test for function do_unvault
def test_do_unvault():
    data = b'\n            \n        \n    \n    \n    \n    \n    \n    \n    \n\n    \n    \n        \n            \n                \n                \n            \n            \n        \n\n        \n            \n                \n                    \n                    \n                        \n                        \n                            \n                            \n                                \n                                \n                                    \n                                        \n                                    \n                                \n                            \n                        \n                    \n                \n            \n        \n\n    \n    \n    \n    \n    \n    \n    \n    \n\n    \n'

# Generated at 2022-06-23 10:15:13.297954
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:15:15.023697
# Unit test for constructor of class FilterModule
def test_FilterModule():
    print('Test constructor')
    print('--------------')
    fm = FilterModule()

    return fm


# Generated at 2022-06-23 10:15:23.721062
# Unit test for function do_vault
def test_do_vault():
    ''' Test with valid inputs '''

    # Test with a valid string
    string = 'my password'
    secret = 'secret'
    vault = do_vault(string, secret)
    assert is_encrypted(vault)

    # Test with a valid unicode string
    string = u'my password'
    secret = u'secret'
    vault = do_vault(string, secret)
    assert is_encrypted(vault)

    # Test without salt by default
    string = 'my password'
    secret = 'secret'
    vault = do_vault(string, secret)
    assert is_encrypted(vault)

    # Test passing a valid salt
    string = 'my password'
    secret = 'secret'
    salt = 'salt'
    vault = do_vault(string, secret, salt)


# Generated at 2022-06-23 10:15:32.720621
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret

    # Get VaultSecret from Ansible 1.9 cipher version
    vs = VaultSecret(b'$ANSIBLE_VAULT;1.9;AES256;test_account')

    # Specifically using AES256, because that is the only one that is supported by Ansible 1.9
    vl = VaultLib()

    # Test string to encrypt
    data = b'hello world'

    # Test character salt
    salt = b'@'
    vault = vl.encrypt(data, vs, 'ansible', salt)

    # Test character salt
    salt = b'B'
    vault2 = vl.encrypt(data, vs, 'ansible', salt)

    assert vault != vault2

