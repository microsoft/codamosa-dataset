

# Generated at 2022-06-23 10:05:30.598784
# Unit test for function do_vault
def test_do_vault():
    RET = do_vault("something", "test", wrap_object=True)
    assert isinstance(RET, AnsibleVaultEncryptedUnicode)
    assert RET.vault is None
    assert RET.data == "something"

    RET = do_vault("something", "test")
    assert isinstance(RET, (string_types, binary_type))
    assert RET.startswith("$ANSIBLE_VAULT;")



# Generated at 2022-06-23 10:05:43.341628
# Unit test for function do_unvault

# Generated at 2022-06-23 10:05:54.537520
# Unit test for function do_unvault

# Generated at 2022-06-23 10:05:56.603055
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None

# Generated at 2022-06-23 10:06:05.062746
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:13.396315
# Unit test for function do_vault
def test_do_vault():

    secret = 'mysecret'
    vaultid = 'filter_default'
    salt = None

    # Test with string type
    data = 'allnig'
    assert do_vault(data, secret, salt, vaultid) == '!vault |' + vaultid + '\n$ANSIBLE_VAULT;1.1;AES256\n3136313435363765653036313237656535613961373635653466643039663538313338643037\n646362633261666632303437376563396264386535666530336634643565\n'
    vault = do_vault(data, secret, salt, vaultid, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode) == True
   

# Generated at 2022-06-23 10:06:18.791755
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AVEU
    data = to_bytes('foobar')
    secret = to_bytes('secret')
    salt = 'salt'
    vault = do_vault(data, secret, salt)
    assert isinstance(vault, (binary_type, AVEU))
    assert vault != data
    assert vault.startswith(b'$ANSIBLE_VAULT;')



# Generated at 2022-06-23 10:06:27.511064
# Unit test for function do_vault
def test_do_vault():
    obj = FilterModule()

# Generated at 2022-06-23 10:06:35.772300
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:43.606548
# Unit test for function do_vault
def test_do_vault():
    ''' ansible-vault filters: do_vault '''

    v1 = 'test_test'
    s1 = 'test_test_test'
    v1_evault = do_vault(v1, s1)

    def pre_process_v1_evault(v1_evault):
        v1_evault = v1_evault.split('\n')
        for n in range(len(v1_evault)):
            if v1_evault[n].startswith('$ANSIBLE_VAULT;'):
                del v1_evault[n]
                break
        return '\n'.join(v1_evault)

    v1_evault_expected = pre_process_v1_evault(v1_evault)
    v1_evault_actual

# Generated at 2022-06-23 10:06:55.393405
# Unit test for function do_vault
def test_do_vault():
    fm = FilterModule()
    filters = fm.filters()

    # Test 1: encrypt text
    vaulted = filters['vault']('ansible', 'password')

# Generated at 2022-06-23 10:06:59.408167
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['vault'] is not None
    assert filters['unvault'] is not None

# Generated at 2022-06-23 10:07:02.412092
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert callable(filters['vault'])
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:07:02.996170
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:07:04.633398
# Unit test for constructor of class FilterModule
def test_FilterModule():
    t = FilterModule()
    assert type(t) == FilterModule

# Generated at 2022-06-23 10:07:08.929031
# Unit test for function do_vault
def test_do_vault():
    secret = 'sup3rs3cr3t'
    salt = 'sup3rs4lt'
    vault_result = do_vault('secret', secret, salt=salt)

# Generated at 2022-06-23 10:07:19.403147
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    secret = "foobar"
    vaultid = 'filter_default'
    data = "TheQuietRoom"
    salt = "salt"
    data_wrap_object = "TheQuietRoom"

# Generated at 2022-06-23 10:07:24.969876
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Success case
    try:
        f = FilterModule()
        assert f is not None
    except Exception as e:
        assert False, "Failed to create FilterModule: %s" % to_native(e)
# Unit test if the test_FilterModule method exists

# Generated at 2022-06-23 10:07:31.700006
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate FilterModule
    fm = FilterModule()

    # Get the filters
    filters = fm.filters()
    assert type(filters) == dict
    assert len(filters) == 2
    assert type(filters['vault']) == type(do_vault)
    assert type(filters['unvault']) == type(do_unvault)


# Generated at 2022-06-23 10:07:34.334192
# Unit test for function do_vault
def test_do_vault():
    'Test vault filter'
    secret = 'this is a very good secret'
    data = 'this is not a secret'

    assert do_vault(data, secret) == data


# Generated at 2022-06-23 10:07:43.395154
# Unit test for function do_vault
def test_do_vault():
    secret = "password"
    salt = "salt"
    vault_str = do_vault("secret_string", secret, salt)
    vault_str_wrapped = do_vault("secret_string", secret, salt, wrap_object=True)

    assert vault_str == vault_str_wrapped
    assert vault_str.startswith("$ANSIBLE_VAULT;")
    assert vault_str.endswith("\n")
    assert is_encrypted(vault_str) == True


# Generated at 2022-06-23 10:07:46.671199
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    f = m.filters()
    assert 'vault' in f
    assert 'unvault' in f

# Generated at 2022-06-23 10:07:58.880152
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:00.501492
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:08:10.350075
# Unit test for function do_vault
def test_do_vault():
    import base64
    secret = "testsecret"
    salt = "test"
    data = "vault_test"

# Generated at 2022-06-23 10:08:14.386802
# Unit test for function do_vault
def test_do_vault():
    secret = '$4iNj4!2@91'
    data = 'super secret data'
    vault = do_vault(data, secret)
    assert vault.startswith('$ANSIBLE_VAULT')



# Generated at 2022-06-23 10:08:18.362729
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule_instance = FilterModule()
    assert isinstance(FilterModule_instance, FilterModule)
    assert isinstance(FilterModule_instance.filters(), dict)


# Generated at 2022-06-23 10:08:23.222923
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Make sure that the method filters of class FilterModule returns
    the expected data.
    """

    filter_module = FilterModule()

    result = filter_module.filters()

    assert result == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:08:35.262333
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:37.085403
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_dict = {}
    f = FilterModule()
    assert f.filters() == test_dict



# Generated at 2022-06-23 10:08:40.251367
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('123456789', 'pass12345')
    assert vault.startswith('$ANSIBLE_VAULT;1.1;AES256')

# Generated at 2022-06-23 10:08:50.931774
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    salt = 'salt'
    data = 'ansible'

    # Should return AnsibleVaultEncryptedUnicode
    assert isinstance(do_vault(data, secret, salt, wrap_object=True), AnsibleVaultEncryptedUnicode)
    # ...with valid data
    assert 'ansible' in str(do_vault(data, secret, salt, wrap_object=True))
    # ...with valid salt
    assert 'salt' in str(do_vault(data, secret, salt, wrap_object=True))
    # ...with valid secret
    assert 'password' in str(do_vault(data, secret, salt, wrap_object=True))
    
    # Should raise AnsibleFilterTypeError

# Generated at 2022-06-23 10:08:59.095565
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;test\n38393731353431353865316336643661376131373566613037663939343631633836663562633961\n623461310a6565643238626663386166623165383635373735326435386661373932333436633361\n61633132363662626162366334363836643031303232336162623939623263346132323839363262\n323936663735653135", "secret") == 'test'

    assert do_unvault("test") == 'test'

    secret = "secret"

# Generated at 2022-06-23 10:09:09.076587
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'foobar'
    salt = None
    vaultid = 'test_vaultid'
    wrap = False
    expected = '$ANSIBLE_VAULT;1.1;AES256;test_vaultid\n37353837353638396263303930653661363834313230303534353264633235666330356361353534\n3962633263353934303162366538396465623165643966366437663364336632663538663132633330\n39343364356539646533327\n'
    actual = do_vault(data, secret, salt, vaultid, wrap)
    assert(actual == expected)



# Generated at 2022-06-23 10:09:11.210447
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:09:20.630366
# Unit test for function do_unvault
def test_do_unvault():
    from unittest import TestCase
    from ansible.module_utils.basic import AnsibleModule
    import os
    import sys

    class CryptoTestCase(TestCase):
        def setUp(self):
            self.mock = AnsibleModule(
                argument_spec={},
            )

            self.mock_params = {}

        def tearDown(self):
            self.mock.exit_json.reset_mock()

        def test_valid_vault_string(self):
            """Ansible vault string is valid"""

# Generated at 2022-06-23 10:09:32.833271
# Unit test for function do_vault
def test_do_vault():
    secret = "random_secret" # must be string
    salt = None # must be string
    vaultid = 'test_vaultid' # must be string
    wrap_object = False # must be boolean
    data = "test_data" # must be string

    # test for invalid input: secret = ""
    secret = ""
    try:
        do_vault(data, secret, salt, vaultid, wrap_object)
    except AnsibleFilterError as e:
        assert "Secret passed is required to be a string" in e.args[0]
    else:
        assert False

    # test for invalid input: secret = "password"
    secret = "password"

# Generated at 2022-06-23 10:09:35.197089
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    data = "Data to encrypt"
    vault = do_vault(data, secret)
    assert {"vault": data} == do_unvault(vault, secret)


# Generated at 2022-06-23 10:09:38.264434
# Unit test for function do_unvault
def test_do_unvault():
    vault = VaultLib([('filter_default', VaultSecret(b'foo'))])
    encrypted = vault.encrypt_data(b'bar')

    # use a known secret
    assert 'bar' == do_unvault(encrypted, b'foo')
    # use a bogus secret
    assert '' == do_unvault(encrypted, b'bogus')

# Generated at 2022-06-23 10:09:40.023419
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-23 10:09:52.707280
# Unit test for function do_vault
def test_do_vault():
    filters = FilterModule()
    vault_str = filters.filters()['vault']('test', 'secret')
    # If there is an exception raised, the assert will fail

# Generated at 2022-06-23 10:09:53.513844
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:09:54.805015
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert('vault' in filters)
    assert('unvault' in filters)


# Generated at 2022-06-23 10:10:00.540810
# Unit test for function do_vault
def test_do_vault():
    # This function should correctly encrypt a string using 'test' as the password
    # It should return a string that starts with $ANSIBLE_VAULT;
    secret = 'test'
    data = 'Username: test\nPassword: test'
    vault = do_vault(data, secret)
    assert vault[0:16] == "$ANSIBLE_VAULT;"

    # This function should raise an AnsibleFilterError if the secret is wrong
    # It should return an error message stating the problem
    try:
        data = 'Username: test\nPassword: test'
        vault = do_vault(data, 'wrong')
    except AnsibleFilterError as e:
        assert "Unable to encrypt" in e.message
    else:
        assert False, "Unable to encrypt was not returned"

    # This function should raise an Ansible

# Generated at 2022-06-23 10:10:02.196962
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters is not None
    assert callable(fm.filters)


# Generated at 2022-06-23 10:10:07.164633
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    _FilterModule = FilterModule()
    assert 'vault' in _FilterModule.filters()
    assert 'unvault' in _FilterModule.filters()


# Generated at 2022-06-23 10:10:20.196912
# Unit test for function do_vault

# Generated at 2022-06-23 10:10:32.980217
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:41.633157
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vaultid = 'filter_default'
    salt = None
    fail_if = 'Unable to encrypt'

# Generated at 2022-06-23 10:10:45.681180
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters()['vault'] == do_vault
    assert filter_module.filters()['unvault'] == do_unvault

# Generated at 2022-06-23 10:10:55.830070
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:01.454445
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'bar'
    vaultid = 'filter_default'
    vl = VaultLib()
    s = b'foo\n'
    vault = vl.encrypt(s, VaultSecret(secret), vaultid)
    d = do_unvault(vault, secret, vaultid)
    assert(d == s)

# Generated at 2022-06-23 10:11:04.708282
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:11:06.984926
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)
    print(vault)


# Generated at 2022-06-23 10:11:18.950073
# Unit test for function do_unvault
def test_do_unvault():
    # No encryption, no vaultid
    assert do_unvault("test_string", "") == "test_string"
    assert do_unvault("test_string", "", vaultid="") == "test_string"
    # No encryption, valid vaultid
    assert do_unvault("test_string", "", vaultid="vault_1") == "test_string"
    assert do_unvault("test_string", "", vaultid="vault_2") == "test_string"
    # Encrypted, no vaultid

# Generated at 2022-06-23 10:11:31.877038
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:35.490421
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:11:51.594185
# Unit test for function do_vault
def test_do_vault():
    test_secret = 'test_secret'
    test_string = 'test_string'
    test_salt = 'test_salt'
    test_vaultid = 'filter_default'
    test_wrap_object = False

    # test_secret and test_string are equal
    # test_secret, test_string, and test_salt are equal
    do_vault(test_string, test_secret, test_salt, test_vaultid, test_wrap_object)

    # test_secret and test_string are equal
    # test_secret, test_string, and test_salt are equal
    # test_wrap_object is equal to True
    test_wrap_object = True

# Generated at 2022-06-23 10:11:52.921183
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:11:56.682258
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    filtermodule_filters = filtermodule.filters()
    assert isinstance(filtermodule_filters, dict)
    assert len(filtermodule_filters) == 2


# Generated at 2022-06-23 10:12:06.207418
# Unit test for function do_unvault
def test_do_unvault():
    import os
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret_password = 'secret'
    secret_file = '/tmp/secret'

    # Dump secret to secret_file
    with open(secret_file, 'w') as f:
        if PY3:
            f.write(secret_password)
        else:
            f.write(to_bytes(secret_password))

    # Create VaultSecret object
    vs = VaultSecret(secret_file)

    # Create VaultLib object

# Generated at 2022-06-23 10:12:13.482764
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    # Test with decrypted string
    s_out = do_unvault('string', secret)
    assert s_out == 'string'
    # Test with encrypted (vaulted) string
    s_out = do_unvault(do_vault('string', secret), secret)
    assert s_out == 'string'
    # Test with encrypted (vaulted) unicode
    u_out = do_unvault(do_vault(u'unicode', secret), secret)
    assert u_out == u'unicode'

# Generated at 2022-06-23 10:12:25.591251
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:33.538803
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert to_native(do_vault('hello', 'password'))
    assert to_native(do_vault('hello', 'password', wrap_object=True))
    assert to_native(do_unvault(do_vault('hello', 'password'), 'password'))
    assert to_native(do_unvault(do_vault('hello', 'password', wrap_object=True), 'password'))

# Generated at 2022-06-23 10:12:45.419289
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    actual = FilterModule().filters()['vault']('secret', 'password', vaultid='vault_id', wrap_object=True)

# Generated at 2022-06-23 10:12:54.869551
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:00.122230
# Unit test for function do_unvault
def test_do_unvault():
    a = "$ANSIBLE_VAULT;1.1;AES256;ansible\n363561343830323536326532353264336532316534356238313431333932656264393435363562\n343263376363353836626133313232363038663265613338616664393038643335616635396136\n353539326361653964613136336231353038346565386439653564353563363161636134353430\n6639363766383038\n"
    secret = "password"
    data = "This is a message"
    b = do_unvault(a, secret)
    print("Data is: " + b)
    assert(str(b) == str(data))



# Generated at 2022-06-23 10:13:01.624138
# Unit test for constructor of class FilterModule
def test_FilterModule():

    filter = FilterModule()
    assert filter is not None


# Generated at 2022-06-23 10:13:15.123107
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common._collections_compat import Mapping

    secret_single = 'single line string'
    secret_multiple = ["single line list", 'multi', 'line', 'list']


# Generated at 2022-06-23 10:13:23.182177
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('abc', 'secret')
    assert do_unvault(do_vault('abc', 'secret'), 'secret') == 'abc'
    try:
        do_vault('abc', 1)
    except AnsibleFilterTypeError:
        assert True
    else:
        assert False
    try:
        do_vault(1, 'secret')
    except AnsibleFilterTypeError:
        assert True
    else:
        assert False
    try:
        do_unvault('abc', 'secret')
    except AnsibleFilterError:
        assert True
    else:
        assert False
    try:
        do_unvault(do_vault('abc', 'secret'), 'wrongsecret')
    except AnsibleFilterError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 10:13:24.621251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:13:26.295761
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    assert test is not None

# Generated at 2022-06-23 10:13:37.226522
# Unit test for function do_vault
def test_do_vault():

    # Test for proper functionality of do_vault function
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible import constants as C

    context = PlayContext()
    context._task_vars['foo'] = 'bar'
    context._task_vars['vault_secret'] = 'my_secret'
    context._task_vars['vault_secret2'] = 'other_secret'

    templar = Templar(loader=None, variables=context._task_vars)
    output = templar.template('{{ "foo"|vault }}', fail_on_undefined=True, context=context)


# Generated at 2022-06-23 10:13:42.909400
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    vault_string = filter_module.filters()['vault']('test', 'vault_secret')

# Generated at 2022-06-23 10:13:44.968427
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:13:55.543488
# Unit test for function do_unvault
def test_do_unvault():
    display.debug('TESTING do_unvault')
    secret = 'test'
    bad_secret = 'bad'

# Generated at 2022-06-23 10:14:01.514094
# Unit test for function do_unvault
def test_do_unvault():
    secr = "randomsecret"

# Generated at 2022-06-23 10:14:02.912993
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:14:09.153185
# Unit test for function do_unvault
def test_do_unvault():

    # setup
    vl = VaultLib()
    vs = VaultSecret('secret')
    data = 'test_123'

    # execute
    vault = vl.encrypt(data, vs, 'filter_default')

    # assert
    assert isinstance(vault, string_types)
    assert data == do_unvault(vault, 'secret')

# Generated at 2022-06-23 10:14:11.534170
# Unit test for function do_vault
def test_do_vault():
    do_vault('string', 'secret')


# Generated at 2022-06-23 10:14:16.457077
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import is_encrypted
    d = "abcd"
    s = "hello world"
    v = do_vault(d,s)
    assert is_encrypted(v) == True
    assert do_unvault(v,s) == d

# Generated at 2022-06-23 10:14:25.652902
# Unit test for function do_vault
def test_do_vault():
    vault, secret, salt, vaultid, wrap_object = '$ANSIBLE_VAULT;1.2;AES256;foo;;....', 'password', 'salt', 'vaultid', True
    assert do_vault(vault, secret) == "vaulted data"
    assert do_vault(vault, secret, salt=salt) == "vaulted data"
    assert do_vault(vault, secret, salt=salt, vaultid='vaultid') == "vaulted data"
    assert do_vault(vault, secret, salt=salt, vaultid='vaultid', wrap_object=True) == "vaulted data"

# Generated at 2022-06-23 10:14:39.896660
# Unit test for function do_vault
def test_do_vault():
    ret = do_vault("SECRET", "PASSWORD")

# Generated at 2022-06-23 10:14:52.093778
# Unit test for function do_vault
def test_do_vault():
    data = "This is the test string"
    secret = "test_secret"

# Generated at 2022-06-23 10:15:01.682255
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:09.157370
# Unit test for function do_vault
def test_do_vault():
    test_data = "Ansible"
    test_secret = "I am a secret"

# Generated at 2022-06-23 10:15:15.763186
# Unit test for function do_vault
def test_do_vault():
    filter_module = FilterModule()

# Generated at 2022-06-23 10:15:21.980683
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible_test\n63376336363730323737363365613930353337653634633137343365663131316264356539663334\n65653835303063326438353435303436333538333136633534396637393466653366663361663538\n3638323035373532633062326566373435714","test") == 'test'