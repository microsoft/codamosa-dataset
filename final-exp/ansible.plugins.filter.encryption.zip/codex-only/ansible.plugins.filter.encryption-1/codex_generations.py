

# Generated at 2022-06-23 10:05:31.830892
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('secret', 'vaultpassword') == '$ANSIBLE_VAULT;1.2;AES256;default\n36333964613231653232646636633162323766666132656533363437616264383931336336383934\n3265306262623937663131653731376239623434316332626164326631613237396531306463633565\n6537663163316662373165613033336234323166383366\n'



# Generated at 2022-06-23 10:05:36.616834
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Create instance of FilterModule
    filter_module = FilterModule()

    # Create instance of filters
    x = filter_module.filters()

    # assert if filters is type of dict
    assert isinstance(x, dict)

# Generated at 2022-06-23 10:05:44.916272
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault("my_secret", "my_pass") != "my_secret"
    assert do_vault("my_secret", "my_pass") != "my_pass"
    assert do_unvault(do_vault("my_secret", "my_pass"), "my_pass") == "my_secret"
    assert do_vault("my_secret", "my_pass", wrap_object=True) != "my_secret"
    assert do_vault("my_secret", "my_pass", wrap_object=True) != "my_pass"
    assert do_unvault(do_vault("my_secret", "my_pass", wrap_object=True), "my_pass") == "my_secret"
    assert do_vault(None, "my_pass") is None
    assert do_

# Generated at 2022-06-23 10:05:47.088234
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None

# Generated at 2022-06-23 10:05:49.329260
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:05:59.294847
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Create an instance of a FilterModule object
    fm = FilterModule()
    filters = fm.filters()

    # Test method vault with parameters "test" and "test"

# Generated at 2022-06-23 10:06:05.749006
# Unit test for function do_vault
def test_do_vault():

    salt = 'Random string that needs to be replaced'

    assert do_vault('mysecretpassword', 'testpassword123') == '$ANSIBLE_VAULT;1.1;AES256\n35646263323563633731356230386132323534306261386265656631353137393438646637653036\n34343938613634616337643866383132343130666665663562373966313165613836393431383038\n3863643036653637\n', 'Test failed for secret arguments of type string'


# Generated at 2022-06-23 10:06:08.927357
# Unit test for function do_vault
def test_do_vault():
    secret = 'unittest_secret'
    res = do_vault('test', secret)
    assert res[:5] == '$ANS'
    assert res[:10] != 'test'
    assert do_unvault(res, secret) == 'test'


# Generated at 2022-06-23 10:06:12.985443
# Unit test for function do_vault
def test_do_vault():
    assert do_vault(data='', secret='') == ''

    secret = VaultSecret('password')
    vault = AnsibleVaultEncryptedUnicode()
    assert do_vault(data='', secret=secret, wrap_object=True) == vault


# Generated at 2022-06-23 10:06:14.746117
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:06:16.892641
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters() == {
            'vault': do_vault,
            'unvault': do_unvault,
        }

# Generated at 2022-06-23 10:06:24.153246
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # In order to test module filters we need to initialize it
    # and use it's filters
    fm = FilterModule()
    filters = fm.filters()

    assert isinstance(filters, dict)
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()


# Generated at 2022-06-23 10:06:26.713028
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)


# Generated at 2022-06-23 10:06:29.631672
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_instance = FilterModule()
    assert 'unvault' in test_instance.filters()
    assert 'vault' in test_instance.filters()



# Generated at 2022-06-23 10:06:32.122703
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)



# Generated at 2022-06-23 10:06:36.990753
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert(len(filters.items()) == 2)
    assert(filters['vault'] == do_vault)
    assert(filters['unvault'] == do_unvault)


# Generated at 2022-06-23 10:06:41.997128
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:06:50.122728
# Unit test for function do_vault

# Generated at 2022-06-23 10:06:59.553437
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    salt = 'some salt'
    vaultid = 'filter_default'
    data = 'Some data to encrypt'

    assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object=False), string_types), 'do_vault returns a string'
    assert isinstance(do_vault(data, secret, salt, vaultid, wrap_object=True), AnsibleVaultEncryptedUnicode), 'do_vault returns a vault object'

    vault = do_vault(data, secret, salt, vaultid, wrap_object=True)
    assert is_encrypted(vault) is True, 'Vault object is_encrypted should return True'


# Generated at 2022-06-23 10:07:02.417865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmod = FilterModule()
    assert 'vault' in fmod.filters()
    assert 'unvault' in fmod.filters()



# Generated at 2022-06-23 10:07:04.035437
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """Unit test for ``ansible.module_utils.basic.FilterModule``"""

    class_object = FilterModule()
    assert class_object is not None

# Generated at 2022-06-23 10:07:07.364884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert len(filters.items()) == 2
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-23 10:07:13.130012
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    data = 'data'
    vault1 = do_vault(data, secret, salt=salt, vaultid='vault_test')
    vault2 = do_vault(data, secret, salt=salt, vaultid='vault_test')
    assert type(vault1) is str
    assert vault1.startswith('$ANSIBLE_VAULT;1.1')
    assert len(vault1) > 50
    assert vault1 != vault2


# Generated at 2022-06-23 10:07:21.134311
# Unit test for function do_unvault

# Generated at 2022-06-23 10:07:25.954365
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters_dict = filter_module.filters()
    assert isinstance(filters_dict, dict)
    assert "vault" in filters_dict
    assert "unvault" in filters_dict


# Generated at 2022-06-23 10:07:29.477062
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-23 10:07:30.381498
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:07:33.764342
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert isinstance(filters, dict)
    assert len(filters) == 2
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-23 10:07:37.267688
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = filter_module = FilterModule()
    assert 'vault' in filters.filters()
    assert 'unvault' in filters.filters()



# Generated at 2022-06-23 10:07:48.132366
# Unit test for function do_vault

# Generated at 2022-06-23 10:07:52.382056
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("this is not encrypted", "secret") == "this is not encrypted"
    assert do_unvault("!this is encrypted", "secret") == "this is encrypted"


# Generated at 2022-06-23 10:07:53.563808
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule())

# Generated at 2022-06-23 10:08:03.514602
# Unit test for function do_unvault
def test_do_unvault():
    # Test data
    unvault_data = {
        'Encrypted_data': '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          613862316362343139373335373034666335323963353136623164643236393262656135613431310a\n          396462323762343064356566616335343237616332346466346366643536323165663965313735340a\n          353835306230393063336436366561646365386439303635383562626230353135383034663431610a\n          30303836666530653063623634363365353430396635643035\n          '
    }
   

# Generated at 2022-06-23 10:08:09.177702
# Unit test for function do_unvault
def test_do_unvault():
    plaintext = """This is a secret message.
It contains
some secret
lines."""

    # Encrypt plaintext
    secret = b"This is a secret message."
    encrypted_text = do_vault(plaintext, secret)
    assert encrypted_text != plaintext
    assert encrypted_text.startswith(b"$ANSIBLE_VAULT;")
    assert encrypted_text.endswith(b";")
    assert plaintext == do_unvault(encrypted_text, secret)

# Generated at 2022-06-23 10:08:17.023159
# Unit test for function do_unvault
def test_do_unvault():

    if not isinstance(secret, (string_types, binary_type, Undefined)):
        raise AnsibleFilterTypeError("Secret passed is required to be as string, instead we got: %s" % type(secret))

    if not isinstance(vault, (string_types, binary_type, AnsibleVaultEncryptedUnicode, Undefined)):
        raise AnsibleFilterTypeError("Vault should be in the form of a string, instead we got: %s" % type(vault))

    data = ''
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    if isinstance(vault, AnsibleVaultEncryptedUnicode):
        vault.vault = vl
        data = vault.data

# Generated at 2022-06-23 10:08:27.246940
# Unit test for function do_vault
def test_do_vault():
    data = "THIS SHOULD BE VAULTED"
    secret = "ansible"
    salt = "salt"
    vaultid = "default"

    # Wrap object should be optional, default False
    actual = do_vault(data, secret, salt, vaultid)

# Generated at 2022-06-23 10:08:28.501618
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:08:38.521614
# Unit test for constructor of class FilterModule
def test_FilterModule():
    import json
    #Test for 1. successful instantiation
    # 2. failure due to wrong parameters to constructor of FilterModule
    fm = FilterModule()
    assert fm is not None
    assert hasattr(fm, 'filters')

    filters = fm.filters()
    assert filters is not None
    assert len(filters) == 2

    assert 'vault' in filters
    assert 'unvault' in filters

    # Test all the filter methods to ensure filter implementation present
    # and only the right number of parameters are passed to filter impl
    try:
        filters['vault'](vaultid='filter_default')
    except TypeError:
        assert True
    except Exception as e:
        assert False, "Expected TypeError, but received exception: %s" % json.dumps(e)

# Generated at 2022-06-23 10:08:39.762249
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:08:41.455184
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert callable(fm.filters)

# Generated at 2022-06-23 10:08:51.659296
# Unit test for function do_unvault
def test_do_unvault():
    src = "$ANSIBLE_VAULT;1.1;AES256\n63313130393463386530386436353664386165656433363964396265316530613062313331366166323\n356337643036333630323639623362353865383737386164343435663636376665376265306232373837\n6561383433653437643964626461633332\n"
    secret = "secret"
    salt = None
    vaultid = 'filter_default'
    is_match_expected = True
    expected = "password"
    actual = do_unvault(src, secret, vaultid)
    assert is_match_expected == (expected == actual), "{} doesn't match expected: {}".format(actual, expected)

# Generated at 2022-06-23 10:08:52.712451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert callable(FilterModule().filters())

# Generated at 2022-06-23 10:08:54.761155
# Unit test for constructor of class FilterModule
def test_FilterModule():
    
    ret = FilterModule()
    assert ret.filters() is not None



# Generated at 2022-06-23 10:09:03.178535
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:06.065095
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }

# Generated at 2022-06-23 10:09:13.530692
# Unit test for function do_vault
def test_do_vault():
    import os
    import json
    import pytest

    # Test Encryption
    #
    # Test both encrypted and unencrypted data to verify that the function
    # properly detects both

    # Test a string
    vault = do_vault('string', os.environ['ANSIBLE_VAULT_PASSWORD'])
    assert vault != 'string'
    assert is_encrypted(vault)
    unvault = do_unvault(vault, os.environ['ANSIBLE_VAULT_PASSWORD'])
    assert unvault == 'string'

    # Test an object
    vault_object = do_vault(
        {'key':'string'},
        os.environ['ANSIBLE_VAULT_PASSWORD'],
        wrap_object=True
    )

# Generated at 2022-06-23 10:09:15.963158
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj

# Generated at 2022-06-23 10:09:17.391518
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:09:28.155491
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n6330646536356433346361333533666439336365643431306463646664653937333037666136323036\n35653762346630616463380a636539656262613466663839343031653239343535323436363332643238\n37663233323236343266396462633637613331323531613565313534360a323732343236396336623238\n3732623665643139363839386438'


# Generated at 2022-06-23 10:09:36.289721
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    result = do_vault(secret, data)
    assert result == '!vault |\n          $ANSIBLE_VAULT;1.2;AES256;filter_default\n          3235643566396436383232663238316230666333638666463323939636232353930333162363537\n          61323132666265616566643531333233636662373566653132386366643365336437333964656633\n          6664396634636234663664313631326232396432643865323834613431340a'
    result = do_vault(secret, data, wrap_object=True)

# Generated at 2022-06-23 10:09:36.898314
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-23 10:09:37.910484
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-23 10:09:46.455547
# Unit test for function do_vault
def test_do_vault():
    args = dict(
        data="data",
        secret="secret",
        salt="salt",
        vaultid="vaultid",
        wrap_object=True
    )
    assert do_vault(**args) == "$ANSIBLE_VAULT;1.1;AES256\r\nsMVr0ecReHg8LblqfXGtjQ==\r\norG8wdxORJ2s0sVCsTMIVg==\r\n"


# Generated at 2022-06-23 10:09:56.315797
# Unit test for function do_vault
def test_do_vault():
    display.vvv("Test function do_vault")
    from ansible.parsing.vault import VaultLib
    if not VaultLib.get_default_vault_id():
        display.warning("No vault password set!")

# Generated at 2022-06-23 10:09:57.749857
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:10:08.230395
# Unit test for constructor of class FilterModule

# Generated at 2022-06-23 10:10:13.404700
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:10:22.390327
# Unit test for function do_vault
def test_do_vault():

    # Test for string
    assert "!vault |$ANSIBLE_VAULT;1.2;AES256;test_do_vault;94823494856784659234655355545553453453343^\n56443434434353453433454334434353453433354^\n45344545343453433453453334345345345334553^\n34345344343453433453443453445454545453445^\n345345344345345345" == do_vault("This is a secret string", "This is a secret", salt="test_do_vault")

    # Test for dictionary

# Generated at 2022-06-23 10:10:33.379828
# Unit test for function do_unvault
def test_do_unvault():
    # Setup
    secret = "super_awesome_secret"
    vaulted_data = "!vault |\n      $ANSIBLE_VAULT;1.1;AES256\n      63366162376336653436396533326462626133613532343336346637306264663432626463656266\n      313863663866330623439663161336133316562373166393463363838626234636566393764616563\n      64373162613163643730\n      "
    expected_result = "super_awesome_value"

    # Run the unvault
    result = do_unvault(vaulted_data, secret)

    # Test
    assert(result == expected_result)

# Generated at 2022-06-23 10:10:34.691997
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:10:36.048698
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f, FilterModule)

# Generated at 2022-06-23 10:10:37.638378
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:10:42.800133
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:10:49.489566
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    # Test for method filters of class FilterModule

# Generated at 2022-06-23 10:10:58.073483
# Unit test for function do_vault
def test_do_vault():
    secret = 'dummy_secret'
    data = 'dummy_data'
    salt = 'dummy_salt'
    vaultid = 'dummy_vaultid'
    wrap_object = False
    # Calling do_vault function
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    # Asserting the result

# Generated at 2022-06-23 10:11:00.989250
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Tests for basic scenarios
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:11:02.201069
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:11:14.293330
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:15.341734
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:11:23.826892
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:24.871404
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not isinstance(FilterModule, FilterModule())

# Generated at 2022-06-23 10:11:31.647986
# Unit test for function do_unvault
def test_do_unvault():

    # Test strings
    vault_strs = [
        '.vault-password-1',
        '.vault-password-2',
        '{{ vault_password_2 }}',
        '{{ vault_password }}',
        'foo',
    ]

    # Test secrets
    secrets = [
        'password1',
        'password2',
    ]

    # Test vaultids
    vaultids = [
        'filter_default',
        'vault-password-1',
        'vault-password-2',
    ]

    # Test data
    data = [
        'password1',
        'password2',
        'password3',
    ]


# Generated at 2022-06-23 10:11:33.527906
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:11:36.261957
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    assert isinstance(filtermodule, FilterModule), "Constructor of FilterModule does not return FilterModule object"


# Generated at 2022-06-23 10:11:43.718990
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-23 10:11:47.480306
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-23 10:12:00.054427
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:04.780895
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:12:07.148717
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:12:08.014278
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:12:14.712562
# Unit test for function do_vault
def test_do_vault():

    secret = '$ANSIBLE_VAULT;1.1;AES256'
    data = 'ZGVhZGJlZWYK'
    result = '$ANSIBLE_VAULT;1.1;AES256;filter_default 079d0980f16f9e48e2c10e7ae284f2614ef6e22a31bfaef7790e086a8a9b76a6b'

    vault = do_vault(data, secret)
    assert vault == result


# Generated at 2022-06-23 10:12:25.799500
# Unit test for function do_vault
def test_do_vault():
    input_string = u"this is a test string"

# Generated at 2022-06-23 10:12:27.629048
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert FilterModule()


# Generated at 2022-06-23 10:12:28.282621
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

# Generated at 2022-06-23 10:12:35.909796
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'

    # Successful vault
    data = 'To vault: the secret is mine!'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)

    # Failing vault
    data = 'To vault: the secret is mine!'
    # Can't vault a vault!
    with pytest.raises(AnsibleFilterError):
        vault = do_vault(vault, secret)
    assert not isinstance(vault, string_types)



# Generated at 2022-06-23 10:12:40.657444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    print("\n\nBeginning FilterModule_filters tests\n")
    result = FilterModule.filters()
    print("result is type %s and value %s" % (type(result), result))

    assert isinstance(result, dict), "Result should be a dictionary, it is type %s and value %s" % (type(result), result)

    assert len(result) == 2, "Result should have two items, it has %s" % result

    assert 'vault' in result, "Result should contain vault, it is %s" % result

    assert 'unvault' in result, "Result should contain unvault, it is %s" % result

    print("\nEnding FilterModule_filters tests\n\n")


# Generated at 2022-06-23 10:12:43.659181
# Unit test for constructor of class FilterModule
def test_FilterModule():
    class_object = FilterModule()
    assert(class_object is not None)


# Generated at 2022-06-23 10:12:49.004704
# Unit test for function do_unvault
def test_do_unvault():
    test_data = ['to be or not to be', '', '2+2=4']
    test_secret = 'password'
    test_vaultid = 'default'
    for data in test_data:
        assert do_unvault(do_vault(data, test_secret, vaultid=test_vaultid), test_secret, vaultid=test_vaultid) == data, 'do_unvault() or do_vault() test failed'


# Generated at 2022-06-23 10:12:54.375862
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'string_to_vault'

# Generated at 2022-06-23 10:13:05.618776
# Unit test for function do_vault
def test_do_vault():
    # Test 1:
    # Test if we get back a string
    assert isinstance(do_vault("test", "secret_key"), str)

    # Test 2:
    # Test if the resulting string is encrypted
    assert do_vault("test", "secret_key") != "test"

    # Test 3:
    # Test if we get back the same value that we started with when
    # we unvault
    assert "test" == do_unvault(do_vault("test", "secret_key"), "secret_key")

    # Test 4:
    # Test if the Vaulted object contains all the same parameters
    # as the original object. Note that this doesn't test if they
    # are the same instance, nor does it test if the dict values
    # are the same instance

# Generated at 2022-06-23 10:13:11.302080
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert fm.filters() is not None
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-23 10:13:13.766747
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:13:22.580565
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'foo'
    vaultid = 'filter_default'

# Generated at 2022-06-23 10:13:34.787080
# Unit test for function do_vault
def test_do_vault():
    from jinja2 import Template
    from .mock_ansible_vars import MockAnsibleVars, MockAnsibleVars_vault_string, MockAnsibleVars_vault_dict
    from .mock_ansible_vars import MockAnsibleVars_unvault_string, MockAnsibleVars_vault_string_nested_dict, MockAnsibleVars_vault_string_list
    from .mock_ansible_vars import MockAnsibleVars_vault_string_list_nested_dict, MockAnsibleVars_vault_string_file, MockAnsibleVars_vault_dict_unwrap
    from .mock_ansible_vars import MockAnsibleVars_vault_dict_wrap, MockAnsibleV

# Generated at 2022-06-23 10:13:46.827631
# Unit test for function do_unvault
def test_do_unvault():
    # Valid data
    data = 'secret data'
    secret = 'secret password'
    vault = do_vault(data, secret)
    assert data == do_unvault(vault, secret)

    # Invalid secret
    secret = 'invalid secret'
    vault = do_vault(data, secret)
    try:
        assert data == do_unvault(vault, secret)
    except AnsibleFilterError:
        assert True
    else:
        assert False

    # Valid data - using vaultid
    data = 'secret data'
    secret = 'secret password'
    vault = do_vault(data, secret, vaultid='test_vaultid')
    assert data == do_unvault(vault, secret, vaultid='test_vaultid')

    # Invalid vaultid

# Generated at 2022-06-23 10:13:49.048745
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:13:51.199025
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x is not None, 'TEST SUCCEEDED: Filters can be created'

# Generated at 2022-06-23 10:14:04.301127
# Unit test for function do_unvault
def test_do_unvault():
    vault_str = u'''$ANSIBLE_VAULT;1.2;AES256;default
33613531316431623963396633633066653937666537633134623531323666653233313531353239
35313465363830336635363138636430376337303736613639396534303738633031316537393663
373533323534386639333562303634386437393964
'''
    assert do_unvault(vault_str, "foo") == "bar"
    assert do_unvault(vault_str, "foo", vaultid="unittest") == "bar"


# Generated at 2022-06-23 10:14:07.298975
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filter_list = f.filters()
    assert filter_list['vault'] == do_vault
    assert filter_list['unvault'] == do_unvault


# Generated at 2022-06-23 10:14:09.587386
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    f = m.filters()
    assert f['vault']
    assert f['unvault']

# Generated at 2022-06-23 10:14:17.574569
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import ansible.errors
    import ansible.module_utils.six
    import ansible.parsing.yaml.objects
    import ansible.parsing.vault
    import ansible.utils.display
    f = FilterModule()
    assert isinstance(f.filters(), dict)
    assert f.filters()['unvault'] is do_unvault
    assert f.filters()['vault'] is do_vault


# Generated at 2022-06-23 10:14:18.113330
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:14:21.656213
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fltmod = FilterModule()
    assert isinstance(fltmod.filters(), dict)
    assert 'vault' in fltmod.filters()
    assert 'unvault' in fltmod.filters()


# Generated at 2022-06-23 10:14:23.984916
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'unvault' in filters
    assert 'vault' in filters


# Generated at 2022-06-23 10:14:25.102865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterobj = FilterModule()
    filterobj.filters()



# Generated at 2022-06-23 10:14:39.531206
# Unit test for function do_unvault
def test_do_unvault():
    def unvault_and_assert(vault, secret, expected, vaultid, *args, **kwargs):
        assert do_unvault(vault, secret, vaultid=vaultid, *args, **kwargs) == expected

    # Should decrypt an AnsibleVaultEncryptedUnicode
    unvault_and_assert('$ANSIBLE_VAULT;1.2;AES256;awesome3858\n34613763350606663163646665323162626634396533353835396236613432343633353166613235\n3534383235313730326262353265323433306130666434383664393566366539\n', 'awesome', 'test string', 'test_vaultid', wrap_object=True)

    # Should

# Generated at 2022-06-23 10:14:40.839351
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert {'vault': do_vault, 'unvault': do_unvault} == FilterModule().filters()

# Generated at 2022-06-23 10:14:48.096584
# Unit test for function do_vault
def test_do_vault():
    data = 'test'
    secret = 'test'
    vaultid = 'filter_default'
    salt = None
    wrap_object = False
    result = do_vault(data, secret, salt=salt, vaultid=vaultid, wrap_object=wrap_object)
    assert result is not None


# Generated at 2022-06-23 10:14:54.552991
# Unit test for function do_vault
def test_do_vault():
    secret = to_bytes('treesandbeesandrosesandwhiskey')
    salt = to_bytes('salt')
    data = to_bytes('Just a bunch of letters and numbers')

    result = do_vault(data, secret, salt, 'unit_test_vault_id')
    assert isinstance(result, string_types)

    result = do_unvault(result, secret, 'unit_test_vault_id')
    assert isinstance(result, string_types)
    assert result == to_native(data)



# Generated at 2022-06-23 10:15:04.045359
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256\n313233363262396533663439616431343835636234306565396135623366323931636236343339\n663534313466316565336164366335383633373730623439363337353464353665346432343033\n356536343035653835323033303736613964616137373734663137313536396263626663366637\n346432653338353162373539\n')
    # If the vault is encrypted, return decrypted data as string.

# Generated at 2022-06-23 10:15:11.780002
# Unit test for function do_vault
def test_do_vault():
    data = "hello world"
    secret = "password"
    vault = do_vault(data, secret)

# Generated at 2022-06-23 10:15:22.540898
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.parsing.vault import VaultSecret, VaultLib

    secret = VaultSecret('test')
    vault = VaultLib([('test', secret)])
    plaintext = 'plaintext'

    assert 'plaintext' == do_unvault(vault.encrypt(plaintext), 'test')

    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(None, secret)

    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(None, None)

    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(plaintext, None)

    with pytest.raises(AnsibleFilterTypeError):
        do_unvault(plaintext, 'encryption key')
