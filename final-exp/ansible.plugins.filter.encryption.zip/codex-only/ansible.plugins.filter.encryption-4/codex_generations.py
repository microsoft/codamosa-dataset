

# Generated at 2022-06-23 10:05:34.894188
# Unit test for function do_unvault
def test_do_unvault():
    # Should be able to decrypt using a password, but not using a wrong password
    assert do_unvault(do_vault("Secret text", "password"), "password") == "Secret text"
    assert do_unvault(do_vault("Secret text", "password"), "wrong password") != "Secret text"

    # Should be able to decrypt using a custom salt
    assert do_unvault(do_vault("Secret text", "password", salt="salt"), "password", "") == "Secret text"

    # Should not be able to decrypt using a custom salt different from what was used to encrypt
    assert do_unvault(do_vault("Secret text", "password", salt="salt"), "password", "") != "Secret text"

    # Should not be able to decrypt a non-encrypted string

# Generated at 2022-06-23 10:05:36.816053
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:05:40.226947
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:05:53.179497
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'data'
    salt = 'test'
    vaultid = 'test'

    cached_result = do_vault(data, secret, salt, vaultid)
    assert isinstance(cached_result, AnsibleVaultEncryptedUnicode)

    result = do_vault(data, secret, salt, vaultid)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)

    # The result should not be equal to the cached_result salt
    assert cached_result != result

    # The result should be equal to the cached_result salt
    cached_result = do_vault(data, secret, salt, vaultid)
    assert cached_result == result

    # Change the setting of wrap_object should also change the result

# Generated at 2022-06-23 10:05:56.256777
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule.filters(FilterModule()) == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:06:04.808616
# Unit test for function do_vault
def test_do_vault():

    assert do_vault('thepassword', 'thepassword') == do_unvault(do_vault('thepassword', 'thepassword'), 'thepassword')
    assert do_vault('thepassword', 17) == do_unvault(do_vault('thepassword', 17), 17)
    assert do_vault(None, 17) == do_unvault(do_vault(None, 17), 17)
    assert do_vault(None, None) == do_unvault(do_vault(None, None), None)
    assert do_vault(17.5, 17.5) == do_unvault(do_vault(17.5, 17.5), 17.5)

# Generated at 2022-06-23 10:06:15.317412
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n36353635363066363339613535656564383363646533626565313132386336656664346166630a63323233383663313861353139626532353138616432323536376138363466356439663736620a3131326537613834653864633332623938643065613066346363376333376166633539356637\n'

# Generated at 2022-06-23 10:06:17.888370
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    actual = fm.filters()

    assert actual == {'vault': do_vault, 'unvault': do_unvault}, 'Expected {\'vault\': do_vault, \'unvault\': do_unvault}, but got {}'.format(actual)


# Generated at 2022-06-23 10:06:22.132617
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filtermodule = FilterModule()
    filters = filtermodule.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:06:23.853251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule().filters(), dict)

# Generated at 2022-06-23 10:06:28.096185
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()

    assert filter_module.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:06:36.069259
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'Ansible'
    data = 'Hello World!'
    vaultid = 'test_123'
    secret2 = 'Test'
    ansible_vault_obj = do_vault(data, secret, vaultid)
    assert(ansible_vault_obj.startswith('$ANSIBLE_VAULT;'))
    ansible_vault_output = do_unvault(ansible_vault_obj, secret, vaultid)
    assert(ansible_vault_output == u'Hello World!')
    # Test with wrong secret
    ansible_vault_output = do_unvault(ansible_vault_obj, secret2, vaultid)

# Generated at 2022-06-23 10:06:43.779690
# Unit test for function do_vault
def test_do_vault():
    # Return type of do_vault must be string
    assert isinstance(do_vault(data="hello", secret="foo"), string_types)
    # Return type of do_vault must be string
    assert isinstance(do_vault(data="bar", secret="foo"), string_types)
    # Return type of do_vault must be string
    assert isinstance(do_vault(data="test", secret="test"), string_types)
    # Return type of do_vault must be string
    assert isinstance(do_vault(data="test", secret="test", salt="test"), string_types)
    # Return type of do_vault must be string
    assert isinstance(do_vault(data="test", secret="test", vaultid="id"), string_types)
    # Return type of do_vault must

# Generated at 2022-06-23 10:06:46.080526
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    x = FilterModule()
    filters = x.filters()

    assert 'vault' in filters
    assert 'unvault' in filters



# Generated at 2022-06-23 10:06:48.100892
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert do_vault in f.filters().values()
    assert do_unvault in f.filters().values()

# Generated at 2022-06-23 10:06:59.133094
# Unit test for function do_vault
def test_do_vault():
    test_do_vault_wrap_object(vaultid='filter_default')
    test_do_vault_wrap_object(vaultid='filter_salt')
    test_do_vault_wrap_object(vaultid='filter_salt_ephemeral')
    test_do_vault_wrap_object(vaultid='filter_salt_ephemeral_short_salt')
    test_do_vault_wrap_object(vaultid='filter_salt_ephemeral_long_salt')
    test_do_vault_wrap_object(vaultid='filter_salt_long_salt')

    # test backward compatibility with Salt Vault type
    test_do_vault_wrap_object(vaultid='filter_salt', wrap_object=False)
    test_

# Generated at 2022-06-23 10:07:09.637386
# Unit test for function do_vault

# Generated at 2022-06-23 10:07:19.472901
# Unit test for function do_unvault
def test_do_unvault():
    data = 'password'
    secret = '$ANSIBLE_VAULT;1.1;AES256\n35363933633938643365303466323466643562643135343134323963393236366534646536306634\n30373332356630653666383431396331363663323862343534626164626536386336333439336130\n34326262366665346234366538346536363263326264316163633239316133313161343962633665\n32663735336436396236333835333263663437643465306432633134326535346437616466646437\n37323462316536636437623435306439\n'

# Generated at 2022-06-23 10:07:21.241089
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert hasattr(f, 'filters')


# Generated at 2022-06-23 10:07:32.574053
# Unit test for function do_unvault

# Generated at 2022-06-23 10:07:45.461587
# Unit test for function do_vault
def test_do_vault():
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.playbook.play_context import PlayContext
    data = 'abc'
    secret = 'abc'
    vaultid = 'filter_default'
    wrap_object = False
    context = PlayContext()
    host = Host(vars=HostVars(vars={}, hostname='all'))
    context.network_os = 'ios'
    context._host = host
    context._play = None
    context._play_context = None
    context.hostvars = HostVars(vars={}, hostname='all')
    context.CLIARGS = None
    context.variables = {}
    context.extra_vars = {}

# Generated at 2022-06-23 10:07:47.854899
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault,
                                        'unvault': do_unvault}


# Generated at 2022-06-23 10:07:53.872110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys
    import pytest
    pytest.importorskip('ansible_vault')

    result = FilterModule().filters()
    expected = {
        'vault': do_vault,
        'unvault': do_unvault,
    }

    assert result == expected


# Generated at 2022-06-23 10:07:54.669326
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:08:04.059403
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:06.979315
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t = FilterModule()
    assert t.filters()['vault'] == do_vault
    assert t.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:08:14.797991
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(vault='$ANSIBLE_VAULT;1.1;AES256;ansible\n6136363938313930333836396536663962626163663638373362363236333435656462623234613d0a31386130363635376435393766653139616234316466373338666536356137613361373137610a30656434396564646237633662306132366266393530373364393431336133323163343236', secret='test') == 'test'
    assert do_unvault(vault='', secret='test') == ''

# Generated at 2022-06-23 10:08:22.334877
# Unit test for constructor of class FilterModule
def test_FilterModule():

    obj = FilterModule()
    assert obj != None

    filters = obj.filters()
    assert filters != None

    assert filters.get("vault") != None
    assert filters.get("unvault") != None

if __name__ == '__main__':
    print("This script is not meant to be run directly.")
    print("Please do an import instead.")
    print("Use -h or --help for more info.")

# Generated at 2022-06-23 10:08:24.657290
# Unit test for constructor of class FilterModule
def test_FilterModule():
  filterModule = FilterModule()
  filterModule.filters()


# Generated at 2022-06-23 10:08:35.953138
# Unit test for function do_vault
def test_do_vault():
    """ Test function do_vault to encrypt a string """
    from ansible.module_utils.six import PY3

    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestDoVault(unittest.TestCase):

        def test_do_vault(self):
            vault = do_vault(data='this is a test', secret='secret')
            self.assertTrue(vault.startswith("$ANSIBLE_VAULT;1.1;"))

            vault = do_vault(data='this is a test', secret='secret', salt=None)
            self.assertTrue(vault.startswith("$ANSIBLE_VAULT;1.1;"))


# Generated at 2022-06-23 10:08:39.236057
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'

    r = do_vault(data, secret)
    assert(r.endswith('$ANSIBLE_VAULT;1.1;AES256'))



# Generated at 2022-06-23 10:08:40.053010
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:08:50.729790
# Unit test for function do_unvault
def test_do_unvault():
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault_id = 'filter_default'

# Generated at 2022-06-23 10:09:01.629816
# Unit test for function do_unvault
def test_do_unvault():
    secret = "ansible"

# Generated at 2022-06-23 10:09:10.706452
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:20.434898
# Unit test for function do_vault
def test_do_vault():
    import os
    import stat
    from jinja2.exceptions import UndefinedError

    from ansible.utils.vault import VaultSecret

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secrets = [
        {'test': 'vault'},
        {'test': 'vault', 'test2': 'foo'},
        {'test': 'vault', 'test2': 'foo', 'test3': 'bar'},
    ]

    data = 'secret'
    vaultid = 'vault_id'
    salt = 'salt'

    vault_obj = AnsibleVaultEncryptedUnicode(
        do_vault(data, secrets[0]['test'], salt, vaultid, True)
    )
    vault_obj.vault = Vault

# Generated at 2022-06-23 10:09:32.652906
# Unit test for function do_vault
def test_do_vault():
    import yaml
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultSecret

    # Unit test for an undefined data
    try:
        do_vault(Undefined, 'test123')
    except UndefinedError as e:
        assert "{{ missing }}" in to_native(e)

    # Unit test for an undefined secret
    try:
        do_vault('test123', Undefined)
    except UndefinedError as e:
        assert "{{ missing }}" in to_native(e)

    # Unit test for a non-string secret
    try:
        do_vault('test123', [])
    except AnsibleFilterTypeError as e:
        assert "required to be a string" in to_native(e)

    # Unit test for a non-string data
   

# Generated at 2022-06-23 10:09:33.812211
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert x.filters() is not None


# Generated at 2022-06-23 10:09:34.252492
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:09:47.031485
# Unit test for function do_unvault
def test_do_unvault():
    # check with test vault
    secret = '$ANSIBLE_VAULT;1.2;AES256;foo'
    #key = '$ANSIBLE_VAULT;1.2;AES256;foo'
    salt = 'c2FuZGJveA=='
    data = 'hello world'
    vl = VaultLib()

    # check with vault
    vault, csum = vl.encrypt(to_bytes(data), 'foo', 'test', to_bytes(salt))

    assert do_unvault(vault, 'foo', 'test') == 'hello world'
    assert do_unvault(vault, 'foo', 'bad_id') == 'hello world'
    assert do_unvault(vault, 'bar', 'test') == 'hello world'

    # check with bad vault


# Generated at 2022-06-23 10:09:51.178091
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    filters = test.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:09:54.376435
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret)
    assert data == do_unvault(vault, secret)
    assert 'bar' == do_unvault(vault, secret)


# Generated at 2022-06-23 10:10:00.162750
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:04.835973
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:10.491269
# Unit test for function do_unvault
def test_do_unvault():
    secret_key = "password"
    encrypted_vault = "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;foo\n          353633353033316532633663303066666630313731346139613332396132663439326663623235\n          323066316534663261653666316337376435396161323265386435626238646639666336363330\n          633626363064\n          "
    decrypted_vault = do_unvault(encrypted_vault, secret_key, vaultid="foo")
    assert decrypted_vault == "test\n"



# Generated at 2022-06-23 10:10:12.865098
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()

if __name__ == '__main__':
    test_FilterModule()

# Generated at 2022-06-23 10:10:15.779801
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''Test constructor of class FilterModule'''
    test_obj = FilterModule()
    assert test_obj is not None


# Generated at 2022-06-23 10:10:23.404429
# Unit test for function do_vault
def test_do_vault():
    assert do_vault({}, 'secret')
    assert do_vault('hi', 'hikari') == '$ANSIBLE_VAULT;1.2;AES256;hikari\n39383736353433323131383966653239343063643639653838313736363565313366373966\n39326131666566653565633237363165326532653165323162396165366438356532323961\n35336634336463613065\n'

# Generated at 2022-06-23 10:10:25.183055
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not hasattr(FilterModule, '_ansible_filter_plugins')

# Generated at 2022-06-23 10:10:33.611383
# Unit test for function do_unvault
def test_do_unvault():
    ''' Unit test for function do_unvault '''
    assert do_unvault('!vault |', 'password') == '!vault |'
    assert do_unvault('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          356563656536623962626662373566376565626135653666343730663831313439303132626665\n          633634363931313431333832613263316632383465363733393837373565323030373336373230\n          363964346631633961376137370a', 'password') == '\n'

# Generated at 2022-06-23 10:10:41.915241
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import tempfile
    import unittest

    dirpath = tempfile.mkdtemp(prefix='ansible_vault_test_')
    filename = os.path.join(dirpath, 'test_vault')

    plaintext = 'test_do_unvault'
    secret = 'test_vault'

    # create a vault file from password and plaintext data
    f = open(filename, 'w')

# Generated at 2022-06-23 10:10:53.480665
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible123\n38343036646635393166316332396635333134326233653061650a363733396563613833623262623130\n333865356665613034306537303938666232303665303633666538643830353365356532366563386131\n33333366613434373337393636353738\n'

    try:
        do_unvault("test", secret)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "Secrete type string is not valid"


# Generated at 2022-06-23 10:11:06.990269
# Unit test for function do_unvault
def test_do_unvault():
    # Test 1: test_secret to unvault test_vault_1
    test_secret = '0OH4dXsEXm8J24ZUmk+6TQ=='

# Generated at 2022-06-23 10:11:18.950520
# Unit test for function do_vault
def test_do_vault():

    from ansible.compat.tests.mock import patch

    from ansible.parsing.vault import _get_file_vault_secret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    with patch('ansible.parsing.vault._get_file_vault_secret', _get_file_vault_secret):
        display.verbosity = 2

# Generated at 2022-06-23 10:11:22.444616
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256'


# Generated at 2022-06-23 10:11:28.688370
# Unit test for function do_unvault
def test_do_unvault():
    test_filter = FilterModule().filters()
    secret = 'hackme'
    vaultid = 'filter_default'
    encrypted_data = test_filter['vault']('hackme', 'hackme')
    decrypted_data = test_filter['unvault'](encrypted_data, secret)
    assert(decrypted_data == 'hackme')


# Generated at 2022-06-23 10:11:39.332918
# Unit test for function do_unvault
def test_do_unvault():
    '''Test function do_unvault'''
    # Test with an AnsibleVaultEncryptedUnicode object
    filter_module = FilterModule()
    ansible_vault_encrypted_unicode_object = AnsibleVaultEncryptedUnicode(b'$ANSIBLE_VAULT;1.1;AES256;test_default\n3637653536396465356534363933363961316461653333613436333235386562356365393335332\n30366638653135333630353262313439666530646665346334623237646637313362386539343761\n6530323037613335653337386162626336633730663138313435643734396438363564353962\n')
   

# Generated at 2022-06-23 10:11:42.216658
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()
    assert result == {'unvault': do_unvault, 'vault': do_vault}

# Generated at 2022-06-23 10:11:52.793284
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.text.formatters import obfuscate_text
    res = do_vault('anystring', 'correct horse battery staple', vaultid='filter_default')

# Generated at 2022-06-23 10:11:59.492374
# Unit test for function do_unvault
def test_do_unvault():

    secret = 'bar'
    vaultid = 'test_default'

    assert do_unvault('foo', secret=secret, vaultid=vaultid) == 'foo'

    mydir = os.path.dirname(os.path.abspath(__file__))
    data = open('%s/vault.test' % mydir, 'rb').read()

    assert do_unvault(data, secret=secret, vaultid=vaultid) == 'baz'

# Generated at 2022-06-23 10:12:12.325724
# Unit test for function do_vault
def test_do_vault():
    # test `vault` filter with plain text
    secret = 'foo'
    data = 'bar'

# Generated at 2022-06-23 10:12:21.394960
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'hunter2'

# Generated at 2022-06-23 10:12:28.366234
# Unit test for function do_vault

# Generated at 2022-06-23 10:12:28.711134
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:12:31.806131
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:12:39.456544
# Unit test for function do_vault
def test_do_vault():

    secret = b'ASECRET'
    data = b'foo: MYDATA'

    vaulted_data = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-23 10:12:43.230905
# Unit test for constructor of class FilterModule
def test_FilterModule():
    my_filter_module = FilterModule()

    assert my_filter_module is not None


# Generated at 2022-06-23 10:12:48.326228
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # create object FilterModule
    fm = FilterModule()
    # check type of filters
    assert type(fm.filters()) == dict
    # check filters

# Generated at 2022-06-23 10:12:50.488767
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    for filter in filters:
        assert filter in ['vault', 'unvault']

# Generated at 2022-06-23 10:12:54.836459
# Unit test for function do_vault
def test_do_vault():
    import ansible.modules.system.ping

    secret_key = 'secret'

    data = 'This is a test'
    data_vault = str(do_vault(data, secret_key, wrap_object=True))

    assert is_encrypted(data_vault)

    data_unvault = do_unvault(data_vault, secret_key)
    assert data == data_unvault

# Generated at 2022-06-23 10:12:57.916865
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    f = FilterModule()
    assert f.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:13:07.277259
# Unit test for function do_vault

# Generated at 2022-06-23 10:13:18.755811
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:19.191221
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule

# Generated at 2022-06-23 10:13:20.316808
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None


# Generated at 2022-06-23 10:13:33.325938
# Unit test for function do_unvault
def test_do_unvault():
    secret_data = 'ansible_secret'

# Generated at 2022-06-23 10:13:35.873231
# Unit test for function do_unvault
def test_do_unvault():
    if do_unvault("$ANSIBLE_VAULT;1.1;AES256", "MyTopSecretPassword", "filter_default") == "":
        return True
    else:
        return False


# Generated at 2022-06-23 10:13:42.312227
# Unit test for function do_vault
def test_do_vault():

    class FakeVaultSecret(object):
        def __init__(self, data):
            self.data = data

    class FakeVaultLib(object):
        def __init__(self, data):
            self.data = data

        def encrypt(self, data, s, v, salt):
            return data + self.data

        def decrypt(self, data):
            return data + self.data

    secret = FakeVaultSecret('test')
    vl = FakeVaultLib('test')

    assert do_vault('test', secret, vaultid='test', salt='test', wrap_object=False) == 'testtest'
    assert do_vault('test', secret, vaultid='test', salt='test', wrap_object=True) == AnsibleVaultEncryptedUnicode('test', vl)

    assert do_un

# Generated at 2022-06-23 10:13:53.916222
# Unit test for function do_vault
def test_do_vault():
    secret = 'VaultPassword'
    salt = '12345'
    vaultid = 'test_vault'
    data = 'TEST'

    # correct secret
    assert do_vault(data, secret, salt, vaultid)
    # wrong secret
    try:
        do_vault(data, 'abc', salt, vaultid)
    except AnsibleFilterError:
        pass
    # wrong salt
    try:
        do_vault(data, secret, '123', vaultid)
    except AnsibleFilterError:
        pass
    # wrong vaultid
    try:
        do_vault(data, secret, salt, 'test_vault1')
    except AnsibleFilterError:
        pass
    # wrong type data

# Generated at 2022-06-23 10:13:56.787035
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:13:57.934236
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    FilterModule().filters()

# Generated at 2022-06-23 10:14:08.660725
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:16.880724
# Unit test for function do_unvault
def test_do_unvault():
    secret = "testsecret"
    vault = "testvault"
    # Simple test
    assert do_unvault(do_vault(vault, secret), secret) == vault
    # Test an incorrect secret
    assert do_unvault(do_vault(vault, secret), secret + "bad") != vault
    # Test a direct match
    assert do_unvault(vault, secret) == vault

# Generated at 2022-06-23 10:14:18.152453
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm


# Generated at 2022-06-23 10:14:26.993335
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    from ansible.module_utils._text import to_bytes
    vaultid='filter_default'
    secret='password'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    data = 'Hello there'
    encrypted = do_vault(data, secret, vaultid='filter_default', wrap_object=True)
    assert isinstance(encrypted, AnsibleVaultEncryptedUnicode), "The return object should be of type AnsibleVaultEncryptedUnicode, instead we got {}".format(type(encrypted))
    assert is_encrypted(encrypted), "The return encrypted object is not encrypted"
    assert v

# Generated at 2022-06-23 10:14:29.656079
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
   filter_module = FilterModule()
   filters = filter_module.filters()
   assert filters is not None
   assert 'vault' in filters
   assert 'unvault' in filters


# Generated at 2022-06-23 10:14:30.061188
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:14:30.694290
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()

# Generated at 2022-06-23 10:14:34.044232
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fl = fm.filters()
    assert fl is not None
    assert type(fl) is dict
    assert len(fl) == 2

# Generated at 2022-06-23 10:14:42.935516
# Unit test for function do_vault
def test_do_vault():

    secret = '12345678'
    test_cases = [
        (1, False, AnsibleFilterTypeError('Can only vault strings, instead we got: <class \'int\'>')),
        ('123', '', AnsibleFilterTypeError('Secret passed is required to be a string, instead we got: <class \'NoneType\'>')),
        ('', '123', AnsibleFilterError('Unable to encrypt: No salt provided and no salt in configuration file'))
    ]

    for data, salt, expected in test_cases:
        try:
            do_vault(data, secret, salt)
        except Exception as e:
            assert type(e) == expected



# Generated at 2022-06-23 10:14:44.824675
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert dir(filter_module) == ['filters']

# Generated at 2022-06-23 10:14:48.627024
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter = FilterModule()
    filters = ansible_filter.filters()

    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:14:56.680185
# Unit test for function do_vault

# Generated at 2022-06-23 10:15:06.278718
# Unit test for function do_unvault
def test_do_unvault():
    test_secret = 'test secret'
    test_vaultid = 'test vaultid'
    test_vault = '$ANSIBLE_VAULT;1.2;AES256;testvault\n666236393962636235613334333331323333333133343737333030326434313164313965323965\n353932623864626465613831333238323266346239616635326264363863323965363436333366\n313566666365653733666539653837343066636462643539\n'
    test_data = 'this is a test data'
    filtered_data = do_unvault(test_vault, test_secret, test_vaultid)

# Generated at 2022-06-23 10:15:19.231893
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import _get_vault_secret

# Generated at 2022-06-23 10:15:20.410415
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters()


# Generated at 2022-06-23 10:15:22.339710
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:15:31.984102
# Unit test for function do_unvault
def test_do_unvault():
    filter = FilterModule()
    assert filter.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;filter_default\n') == ''
    assert isinstance(filter.filters()['unvault'](AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;filter_default\n')), AnsibleVaultEncryptedUnicode)
    assert isinstance(filter.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;filter_default\n'), str)
    try:
        filter.filters()['unvault'](dict())
    except Exception as e:
        assert isinstance(e, AnsibleFilterTypeError)