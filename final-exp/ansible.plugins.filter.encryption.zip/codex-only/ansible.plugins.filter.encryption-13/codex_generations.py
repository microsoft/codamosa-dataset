

# Generated at 2022-06-23 10:05:32.089946
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256\n3861636362616337323832363437363835313133343732313761613433663132656466353736646135\n6130346465343064393937643336306439316663373366306435656366316662633535346232396330\n393965356436626134613038353063366232383066\n', 'vaulttest') == 'test'



# Generated at 2022-06-23 10:05:34.718769
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert getattr(FilterModule, 'filters', None) is not None, "Class `FilterModule` must contain a `filters` method."


# Generated at 2022-06-23 10:05:42.648284
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import is_encrypted
    import base64

    vl = VaultLib()
    decrypted_value = "The secret message"
    secret = vl.gen_secret()

    # Use default salt
    data = do_vault(decrypted_value, secret)

    assert is_encrypted(data)

    assert base64.decodestring(data)
    assert to_native(decrypted_value) == do_unvault(data, secret)


# Generated at 2022-06-23 10:05:54.213045
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes
    from jinja2.runtime import StrictUndefined
    fs = FilterModule()
    f = fs.filters()
    assert 'vault' in f
    assert f['vault'] == do_vault
    assert f['unvault'] == do_unvault
    try:
        v = f['vault']('foo', 'foo')
    except UndefinedError:
        assert isinstance(AnsibleUnsafeText('foo'), Undefined)
    try:
        v = f['vault']('foo', 'foo', 'foo')
    except UndefinedError:
        assert isinstance(AnsibleUnsafeText('foo'), Undefined)

# Generated at 2022-06-23 10:05:57.236605
# Unit test for function do_unvault
def test_do_unvault():

    v = do_vault('password', 'secret')
    assert do_unvault(v, 'secret') == 'password'

# Generated at 2022-06-23 10:05:59.574004
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Test FilterModule filters."""
    assert do_vault('test', 'test') == ''
    assert do_unvault('test', 'test') == ''

# Generated at 2022-06-23 10:06:07.774658
# Unit test for function do_unvault
def test_do_unvault():
    # Test with ansible vault library object
    vault = VaultLib()
    secret = 'test'
    plaintext = 'test_text'
    data = vault.encrypt(plaintext, secret)
    assert do_unvault(data.decode('utf-8'), secret) == plaintext

    # Test with ansible vault encrypted unicode string
    vault = AnsibleVaultEncryptedUnicode(vault.encrypt(plaintext, secret).decode('utf-8'))
    assert do_unvault(vault, secret) == plaintext

    # Test with ansible vault encrypted string
    # The data is encrypted with the secret 'test'

# Generated at 2022-06-23 10:06:10.386756
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    filters = module.filters()
    assert filters.get('vault') is not None
    assert filters.get('unvault') is not None

# Generated at 2022-06-23 10:06:11.263188
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None

# Generated at 2022-06-23 10:06:15.204360
# Unit test for function do_vault
def test_do_vault():
    import pytest
    from ansible.module_utils._text import to_bytes

    secret_key = "mysecret"
    data = "mydata"
    vaultid = "filter_default"
    salt = None

    vault = do_vault(data, secret_key, salt, vaultid)
    data = do_unvault(vault, secret_key)

    assert data == to_bytes(data)


# Generated at 2022-06-23 10:06:17.428669
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:06:22.132158
# Unit test for function do_vault
def test_do_vault():
    data = "hello"
    secret = "testsecret"
    vault = do_vault(data, secret)
    assert "ANSIBLE_VAULT" in vault


# Generated at 2022-06-23 10:06:23.311982
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(FilterModule)

# Generated at 2022-06-23 10:06:33.934910
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret

    assert do_unvault("$ANSIBLE_VAULT;1.2;AES256;michaeltest\n356465616462653833316362376335643734356439396634333137663035386431656462343139340a6532326536646533633732343538643463663066343365663431663163353265313532376661390a323839616336653262656231623661613437663036336539336265353631396336316230613837\n", "password", 'ansible_vault') == u"testpassword\n"

    # test VaultSecret
    secret = VaultSecret('testpassword')
    assert do_unvault

# Generated at 2022-06-23 10:06:36.720978
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()

    result = filter.filters()

    assert result['vault'] == do_vault
    assert result['unvault'] == do_unvault

# Generated at 2022-06-23 10:06:41.818967
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert test_ansible_vault_filter.get_all_code_lines(FilterModule.filters) == \
        [
            ['filters', '=', '{', '\n'],
            ['\t', '\'vault\': ', 'do_vault,', '\n'],
            ['\t', '\'unvault\': ', 'do_unvault,', '\n'],
            ['}', '\n']
        ]


# Generated at 2022-06-23 10:06:42.836444
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters() is not None

# Generated at 2022-06-23 10:06:43.492578
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:06:46.124509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:06:47.045063
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:06:51.769560
# Unit test for function do_vault
def test_do_vault():
    secret = 'supersecret'
    data = 'notvault'
    assert '$ANSIBLE_VAULT;' in do_vault(data, secret)
    assert do_vault(do_vault(data, secret), secret) == data


# Generated at 2022-06-23 10:07:01.322922
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:07:11.021901
# Unit test for function do_unvault
def test_do_unvault():
    import pytest

    # correct password given

# Generated at 2022-06-23 10:07:13.075977
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:07:14.753193
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)



# Generated at 2022-06-23 10:07:16.133497
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fdict = fm.filters()
    assert "vault" in fdict
    assert "unvault" in fdict


# Generated at 2022-06-23 10:07:17.140008
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert (isinstance(FilterModule(), FilterModule))



# Generated at 2022-06-23 10:07:21.634232
# Unit test for function do_vault
def test_do_vault():

    secret = "password"
    data = "data"
    vault = do_vault(data, secret)
    assert is_encrypted(vault)



# Generated at 2022-06-23 10:07:27.568259
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    env = jinja2.Environment()
    env.filters['vault'] = do_vault
    template = env.from_string(
        """{{ "ABCD" | vault("password") }}"""
    )
    assert "vault(ABCD)" == template.render()


# Generated at 2022-06-23 10:07:36.524654
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("ansible", "ansible")

# Generated at 2022-06-23 10:07:39.235428
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    f.filters()

# Generated at 2022-06-23 10:07:48.592620
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.template.safe_eval import safe_eval

    # Initialize test vars
    data = "test"
    secret = "secret"
    salt = "salt"
    vaultid = "filter_default"
    wrap_object = False

# Generated at 2022-06-23 10:07:50.243809
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)


# Generated at 2022-06-23 10:07:54.081658
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible_id;', 'foobardoo') == ''

# Generated at 2022-06-23 10:08:03.825277
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from jinja2 import Environment
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY2
    import os
    import tempfile
    import shutil
    import sys
    import pytest

    vault_lib = VaultLib()

# Generated at 2022-06-23 10:08:04.572329
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:08:13.578318
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;test\n3433333334323432333333333332333332333331343333333433233333343332333\n3433333334323432333333333332333332333331343333333433233333343332333\n3433333334323432333333333332333332333331343333333433233333343332333\n3433333334323432333333333332333332333331343333333433233333343332333\n3433333334323432333333333332333332333331343333333433233333343332333\n3433333334323432333333333332333332333331343333333433233333343332334\n", "vault_test") == "test"

# Generated at 2022-06-23 10:08:15.325945
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None
    assert filter_module.filters is not None

# Generated at 2022-06-23 10:08:26.578674
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Unit test for method filters of class FilterModule
    # Initial test to demonstrate usage of AnsibleVaultEncryptedUnicode type in jinja2 filter vault
    filter_module = FilterModule()
    filters = filter_module.filters()
    vault = filters.get('vault')('ansible_is_the_best', 'secret1', wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)

    # Initial test to demonstrate usage of AnsibleVaultEncryptedUnicode type in jinja2 filter vault
    encrypted_vault = filters.get('vault')('ansible_is_the_best', 'secret1', wrap_object=False)
    unvault = filters.get('unvault')(encrypted_vault, 'secret1')
    assert unvault

# Generated at 2022-06-23 10:08:37.040361
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:08:48.805578
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'foo'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n36303636633262396131316363303331633033343764613933653864346264396433376564353866\n39306565336636373834623462333762613561323737396632646165613765623930336162366334\n64343063353939363564303961316661643539633434616366663331366430653864656337346438\n3939393161363261636336623564346634316562656138\n'
    data = 'A1|B2|C3'

# Generated at 2022-06-23 10:09:01.209397
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible_collections.ansible.community.plugins.module_utils.facts import ansible_vault_password

    vl = VaultLib(
        [(
            'filter_default',
            VaultSecret(ansible_vault_password)
        )],
        'filter_default'
    )


# Generated at 2022-06-23 10:09:03.495403
# Unit test for constructor of class FilterModule
def test_FilterModule():
    '''Dummy test'''
    ansible_vault_filter_module = FilterModule()
    assert ansible_vault_filter_module is not None

# Generated at 2022-06-23 10:09:06.374054
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Module execution (used by test cases)

# Generated at 2022-06-23 10:09:13.736967
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:18.677957
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    testfilter = FilterModule()
    assert testfilter.filters()['vault'] == do_vault
    assert testfilter.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:09:31.595467
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # This is not a proper testcase but it may be useful for the future.
    from ansible.module_utils._text import to_text

    filter_module = FilterModule()
    filters = filter_module.filters()

    assert 'vault' in filters
    assert 'unvault' in filters

    # Ripped from ansible.playbooks.filters.core
    passphrase = to_text('passphrase')
    vault_id = to_text('vault_id')
    salt = 'abcd1234'


    data = to_text("data")
    vaulted = filters['vault'](data, passphrase, salt, vault_id)
    assert is_encrypted(vaulted)
    assert filters['unvault'](vaulted, passphrase, vault_id) == data
    # unvaulting

# Generated at 2022-06-23 10:09:33.754694
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module_obj = FilterModule()
    assert filter_module_obj is not None
    assert filter_module_obj.filters is not None

# Generated at 2022-06-23 10:09:46.821158
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:48.379153
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule.filters) == 2
    assert "vault" in FilterModule.filters()
    assert "unvault" in FilterModule.filters()

# Generated at 2022-06-23 10:09:50.458297
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() != None


# Generated at 2022-06-23 10:09:53.138453
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    filters = filter_module.filters()

    assert filters["vault"] == do_vault
    assert filters["unvault"] == do_unvault


# Generated at 2022-06-23 10:09:59.040500
# Unit test for function do_unvault
def test_do_unvault():
    # Create mock VaultSecret
    class MockVaultSecret(VaultSecret):
        def __init__(self, secret):
            super(MockVaultSecret, self).__init__(secret)
            self.secret = secret

        def secret_value(self):
            return self.secret

    # Create mock VaultLib
    class MockVaultLib(VaultLib):
        def __init__(self):
            super(MockVaultLib, self).__init__()

            self.secrets = {
                'filter_default': MockVaultSecret(b'secret'),
            }

            self.is_encrypted = True
            self.decrypted_data = b'decrypted'

    # The actual test
    vl = MockVaultLib()

# Generated at 2022-06-23 10:09:59.960877
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:10:08.862919
# Unit test for function do_vault
def test_do_vault():
    # Test result of original function do_vault
    data = "testdata"
    secret = "testsecret"
    salt = 123456789
    vaultid = 'ansible-vault-id'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-23 10:10:20.479516
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:29.373143
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible0164104271164303175464\n63363362333338323331346633623762323236333634656533363431326465303565323562310a3035356331616264663035336637363232353334356338633862396638393831353266346638326532613835323661383430663464323939\n", "test") == "test"

# Generated at 2022-06-23 10:10:36.722333
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    salt = "3476873944787098"
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256;vault_test_do_vault\n          323265643734663735636338643837646135383236626362346664333735376531353639376565\n          666435633533646130353135653733663834313662353235326565653930306261623462643035\n          376532373835366431626539333066316531373831616434613166303334353831656266306334\n          333362326263366264\n          "


# Generated at 2022-06-23 10:10:41.489584
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:10:42.123212
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:10:45.810912
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:10:49.664169
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    filters = filter_module.filters()

    assert filters is not None
    assert filters['vault'] is not None
    assert filters['unvault'] is not None

# Generated at 2022-06-23 10:10:50.921189
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:11:03.069056
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-23 10:11:07.685570
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:08.821063
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)


# Generated at 2022-06-23 10:11:20.872074
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'

# Generated at 2022-06-23 10:11:22.662402
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for constructor of class FilterModule
    '''
    obj = FilterModule()

# Generated at 2022-06-23 10:11:23.655932
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters()

# Generated at 2022-06-23 10:11:26.331326
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert set(FilterModule().filters().keys()) == {'vault', 'unvault'}


# Generated at 2022-06-23 10:11:37.272688
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultEditor
    if not VaultEditor.is_available():
        display.warning("Vault Editor not present - skipping vault/unvault tests")
        return
    # Make sure that we can decrypt the vault values
    plaintext = "Hello world!"
    plaintext2 = u"Hello world!"
    secret = "secret"

    vault1 = do_vault(plaintext, secret)
    vault2 = do_vault(plaintext2, secret)

    assert do_unvault(vault1, secret) == plaintext
    assert do_unvault(vault2, secret) == plaintext

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-23 10:11:51.861936
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testpass'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n3433636131343935303932613736656231353036666135343633343038393338313566663963356337\n312c3430366530353835613331646336636613733633534616139393665386363323961333131623263\na333661316637303463323663636266638373863313333316662383765393433656338356537396231\n63352c61376536306661663164663865386635383938636434383564346139613339323764\n'
    assert do_unvault(vault, secret) == 'helloworld'

# Generated at 2022-06-23 10:11:52.420399
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:11:53.816316
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:57.459433
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    fm_filters = fm.filters()
    assert 'vault' in fm_filters
    assert 'unvault' in fm_filters

# Generated at 2022-06-23 10:12:00.052796
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert dict == type(obj.filters())
    assert 1 == len(obj.filters())
    assert 'vault' in obj.filters()


# Generated at 2022-06-23 10:12:08.202306
# Unit test for function do_unvault
def test_do_unvault():
    vault_key = "vault"
    data = "sensitive data"
    vaultid = "filter_default"
    vs = VaultSecret(to_bytes(vault_key))
    vl = VaultLib()
    encrypted_data = vl.encrypt(to_bytes(data), vs, vaultid, None)
    decrypted_data = do_unvault(encrypted_data, vault_key, vaultid)
    assert data == decrypted_data

# Generated at 2022-06-23 10:12:12.995112
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module_cls = FilterModule()
    assert module_cls._load_name == "vault_lookup", "Failed to load module name"
    assert module_cls._load_prio == 0, "Failed to load module priority"
    assert module_cls.filters(), "Failed to return filters"

# Generated at 2022-06-23 10:12:15.169180
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:12:26.027703
# Unit test for function do_vault
def test_do_vault():

    result = do_vault('test', 'test_secret')
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n3137366664383430616131306664346661623931623338323234643435336437303239643831636\n65303633636631333333386233663266643665626537393739643439636163373133366330393065\n63636131386664333461333431383864333363393161643464336630333433633564386638643666\n393730643736633163343835386662623361626538663306397d', 'test_do_unvault() failed'


# Generated at 2022-06-23 10:12:28.432423
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

    assert fm is not None

# Generated at 2022-06-23 10:12:31.860190
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Testing "filters" method of class FilterModule
    a = FilterModule()
    assert a.filters() == {'vault': do_vault, 'unvault': do_unvault}, 'Test failed because expected answer: {\'vault\': <function do_vault at 0x1131e7840>, \'unvault\': <function do_unvault at 0x112d0b840>} and got: ' + str(a.filters())


# Generated at 2022-06-23 10:12:36.029488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f1 = FilterModule()
    filters1 = f1.filters()
    assert 'vault' in filters1
    assert filters1['vault'] == do_vault
    assert 'unvault' in filters1
    assert filters1['unvault'] == do_unvault


if __name__ == '__main__':
    pass

# Generated at 2022-06-23 10:12:47.819290
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mypassword'
    vault = '$ANSIBLE_VAULT;1.1;AES256\n3343413965643161663662343164653435363861343132336532326464333734643534666437\n3561653334633739353338666461306362316339633039633734616263326665383938643962\n3732643464366639343233306338323665316266373862653262633562313064613636356231\n6233376635393766333332376635363637633036626262643238636231643065\n'

    try:
        assert do_unvault(vault, secret) == 'mypassword'
    except Exception as e:
        assert False

# Generated at 2022-06-23 10:12:56.160068
# Unit test for function do_vault
def test_do_vault():
    data = 'Ansible'
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    salt = 'hashicorp'
    vault = do_vault(data, secret, salt)

# Generated at 2022-06-23 10:13:01.275555
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('supersecret', 'ansible', salt='salt', vaultid='test_vault')
    assert vault == b'$ANSIBLE_VAULT;1.2;AES256;salt;ejMzNzJjYzZiYjZlYmI0OC9kbU1hTUg1a2QxTnVwM2lZMytqb3lKZ0U9;6f4d6cd4be6ab4cdc8edb4e5f5c25b0d9e5e5cf5c2bcb7e3b3e3d8a1e57aefb7'



# Generated at 2022-06-23 10:13:09.659830
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    input = { "data": "test", "secret": "test", "salt": "salt", "vaultid": "test", "wrap_object": "value" }
    expected = { "data": "test", "secret": "test", "salt": "salt", "vaultid": "test", "wrap_object": "value" }
    actual = FilterModule().filters()
    assert expected == actual

# Generated at 2022-06-23 10:13:12.672398
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert(filters['vault'] == do_vault)
    assert(filters['unvault'] == do_unvault)

# Generated at 2022-06-23 10:13:21.827873
# Unit test for function do_unvault
def test_do_unvault():
    secret = "password"
    vaultid = "filter_default"

# Generated at 2022-06-23 10:13:34.322512
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.utils import stringutils
    vault_text = '$ANSIBLE_VAULT;1.1;AES256;ansible_vault_test\n3232323232323232323232323232323232323232323232323232323232323232\n'

    secret_text = 'secret'

    # With valid vault id and secret
    vault_id = 'ansible_vault_test'
    ansible_vault_lib = VaultLib([(vault_id, VaultSecret(stringutils.to_bytes(secret_text)))])

# Generated at 2022-06-23 10:13:46.384093
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible-test-vault\n30336636383438646333313836346661383565333639303362626238613034303362386165300a3936332d34643531352d343338642d396566652d3735333835356131646338300a', 'A1S1I1B1L1E1D1', 'ansible-test-vault') == "ANSIBLE_VAULT"

# Generated at 2022-06-23 10:13:51.528431
# Unit test for function do_unvault
def test_do_unvault():
    secret = "This is my secret"
    vaulted_unvaulted_secret = do_vault(secret, secret)
    unvaulted_secret = do_unvault(vaulted_unvaulted_secret, secret)
    assert unvaulted_secret == secret


# Generated at 2022-06-23 10:14:05.223162
# Unit test for function do_unvault
def test_do_unvault():

    # Ensure that the correct exception is raised when an invalid secret is passed
    try:
        do_unvault("vaulted", None)
        assert False
    except AnsibleFilterTypeError as e:
        assert True

    # Ensure that the correct exception is raised when an invalid vault is passed
    try:
        do_unvault(None, "my_secret")
        assert False
    except AnsibleFilterTypeError as e:
        assert True

    # Ensure that the correct exception is raised when an invalid vault is passed
    try:
        do_unvault(1, "my_secret")
        assert False
    except AnsibleFilterTypeError as e:
        assert True

    # Ensure that an encrypted vault can be unvaulted

# Generated at 2022-06-23 10:14:15.927748
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('Hello world', 'MySecretPassword') == '$ANSIBLE_VAULT;1.2;AES256;ansible_filter_default\n33366333666663336631663734656433666564393064643564613333656334353865663634313165320a6637653866603133376237613232393432323064333637663437366636333138376235393466\n'

# Generated at 2022-06-23 10:14:25.616375
# Unit test for function do_unvault
def test_do_unvault():
    encrypted = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n393162326666653633353165636362323938333965373865663561336665656564313839303063616\nv3535616134366237323335373661396132326336636238613235343936656264646230306435613565\n3730336665396431366361333661656437373364333236343837326261626566376439353662333365\n3636663730376561383438363837383533373966\n")
    password = "password"
    result = do_unvault(encrypted, password)
    assert result == "foobar"

# Generated at 2022-06-23 10:14:39.852946
# Unit test for function do_vault
def test_do_vault():
    test_filter = FilterModule()
    vault = test_filter.filters()['vault']

# Generated at 2022-06-23 10:14:43.039873
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()

    assert callable(fm.filters)
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-23 10:14:53.186042
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultEditor

    secret = 'password'
    data = 'secret_data'
    salt = 'Salt_is_good'
    vaultid = 'somevaultid'
    wrap_object = False

    # Encrypt data.
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    # Test VaultEditor
    v = VaultEditor(VaultSecret(secret))
    v.cipher = 'aes'
    v.identifier = vaultid
    v.salt = salt
    # Decrypt data.
    data1 = v.decrypt(vault)
    # Check if decrypted data is equal to original data.
    assert data1 == data



# Generated at 2022-06-23 10:15:02.330894
# Unit test for function do_unvault
def test_do_unvault():
    ''' Test do_unvault function '''
    secret = 'secret'

# Generated at 2022-06-23 10:15:09.412841
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == b'$ANSIBLE_VAULT;1.1;AES256\n356536396632663163653665336138373933363734656665613336633437366563303766646335\n343037363336653331623365633166626438356634353632633138613562306539333136313033\n343833383562653031336364656665313439386262636665613233646663966653034613939326\n635633663733366634353866333635663635656332653965653230666164626235336232333832\ntest\n'

# Generated at 2022-06-23 10:15:10.206715
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule.filters != None

# Generated at 2022-06-23 10:15:11.790149
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:15:14.574066
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'ansible'
    vault = do_vault(data, secret)
    assert vault is not None


# Generated at 2022-06-23 10:15:22.562955
# Unit test for function do_unvault
def test_do_unvault():
    try:
        assert do_unvault("notavault", "secret") == "notavault"
        assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;filter_default\n63623163326661653933633462303465353061316133313632626162396332343164303365303866\n633834326466356362356161363133623262613038626434303539623236", "secret") == "this is a secret"
    except Exception as e:
        print("Failed test cases for function do_unvault. Error: %s" % to_native(e))
        exit(1)


# Generated at 2022-06-23 10:15:24.734452
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """ Test FilterModule constructor """
    vault_filter = FilterModule()
    assert isinstance(vault_filter, FilterModule)



# Generated at 2022-06-23 10:15:33.653197
# Unit test for function do_unvault
def test_do_unvault():
    # Test 1
    try:
        do_unvault(1, 'ansible')
    except TypeError as e:
        assert 'can only concatenate str' in str(e)
    
    # Test 2