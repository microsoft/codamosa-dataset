

# Generated at 2022-06-23 10:05:33.962054
# Unit test for function do_unvault
def test_do_unvault():
    secret = "this_is_my_super_secret"
    ciphertext = "ANSIBLE_VAULT;1.1;AES256\n3737353066643437393661323439323432373066636163396161636139353937363138326566333536\n396565343534623463616366643365623062373431376235616665313166636235313531373832653236\n656235616465613862653831326162316565346635616366623863323362626565\n"

    # print("Ciphertext is: {}".format(ciphertext))
    plaintext = do_unvault(ciphertext, secret)
    # print("Plaintext is: {}".format(plaintext))



# Generated at 2022-06-23 10:05:45.254160
# Unit test for function do_vault
def test_do_vault():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_native, to_bytes
    from ansible.module_utils.yaml.objects import AnsibleVaultEncryptedUnicode

    f_vault = FilterModule().filters()
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault_msg1 = '$ANSIBLE_VAULT;1.1;AES256'
    vault_msg2 = 155

    assert f_vault['vault']('123456789', secret) == vault_msg1
    assert isinstance(f_vault['vault']('123456789', secret), string_types)

    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        f

# Generated at 2022-06-23 10:05:48.931110
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:05:59.032664
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:00.119874
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()


# Generated at 2022-06-23 10:06:02.621206
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c = FilterModule()

# Generated at 2022-06-23 10:06:04.460637
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filterModule = FilterModule()
    assert filterModule

# Generated at 2022-06-23 10:06:11.499192
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.2;AES256;ansible_secret_filter_default\n3235306334626162616534393033373430613332336666663132626135633365333134366335660a623139376466353364346361666466373064383438643737383231653335336162636239\n'
    assert do_vault('foo', 'bar', wrap_object=True).__class__.__name__ == 'AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-23 10:06:13.611007
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:06:16.362821
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fltrm = FilterModule()

    assert fltrm.filters()['vault'] == do_vault
    assert fltrm.filters()['unvault'] == do_unvault

# Generated at 2022-06-23 10:06:30.519433
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:33.479688
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-23 10:06:42.585217
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.2;AES256;default\n63313662626332313937653538333064386239616263623565653333666434633064663238666435\n39646665336134316338326438623761646662636662323633393638643637336162326134643562\n6130653933363538666166', 'mszymborski') == 'Michał Szymborski'

# Generated at 2022-06-23 10:06:50.484956
# Unit test for function do_vault
def test_do_vault():
    data = do_vault("{'foo':'bar'}", "mysecret")

# Generated at 2022-06-23 10:06:52.258625
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-23 10:07:01.613632
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import sys

    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch


# Generated at 2022-06-23 10:07:11.327375
# Unit test for function do_vault
def test_do_vault():
    filtermodule = FilterModule()
    filtermethod = filtermodule.filters()['vault']

# Generated at 2022-06-23 10:07:20.277346
# Unit test for function do_vault
def test_do_vault():
    # Test with ``wrap_object=False``.
    vault = do_vault(data='hello world', secret='mysecret', salt='my_salt')

# Generated at 2022-06-23 10:07:30.949077
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor

    secret = VaultSecret('abc123')
    ve = VaultEditor(secret)

    # Test that a plaintext input produces a plaintext output
    input_str = 'this is a test'
    output_str = do_unvault(input_str, secret)
    assert(input_str == output_str)

    # Test that a valid encrypted string decrypts
    enc_string = ve.encrypt(input_str)
    output_str = do_unvault(enc_string, secret)
    assert(input_str == output_str)

    # Test that it raises a TypeError

# Generated at 2022-06-23 10:07:34.654220
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    data = 'testdata'
    vault = do_vault(data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert data == do_unvault(vault, secret)


# Generated at 2022-06-23 10:07:36.946393
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ansible_filter = FilterModule()
    assert ansible_filter.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:07:39.016913
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj is not None

# Generated at 2022-06-23 10:07:40.960031
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() is not None

# Generated at 2022-06-23 10:07:45.495530
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert 'vault' in FilterModule().filters()
    assert 'unvault' in FilterModule().filters()
    assert 'do_vault' in FilterModule().filters()['vault'].__name__
    assert 'do_unvault' in FilterModule().filters()['unvault'].__name__


# Generated at 2022-06-23 10:07:46.809966
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:07:49.655157
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters == {'unvault': do_unvault, 'vault': do_vault}

# Generated at 2022-06-23 10:07:59.537424
# Unit test for function do_vault
def test_do_vault():
    secret = VaultSecret('SecretPassword').as_dict()
    vaultid = secret['vault_id']
    assert do_vault(None, secret, vaultid) is None
    assert not is_encrypted(do_vault('', secret, vaultid))
    assert is_encrypted(do_vault('test', secret, vaultid))
    assert is_encrypted(do_vault('test', secret, vaultid))
    assert is_encrypted(do_vault('test', secret, vaultid))
    assert is_encrypted(do_vault('test', secret, vaultid, salt='salt'))


# Generated at 2022-06-23 10:08:01.290273
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    output = obj.filters()
    assert isinstance(output, dict)


# Generated at 2022-06-23 10:08:10.628309
# Unit test for function do_unvault
def test_do_unvault():
    secret_value = 'ansible'
    vault_value = '$ANSIBLE_VAULT;1.1;AES256;ansible\n3066653662333531353165313236303761366535396531623961666363303366333763666265\n3339383666663730346463643364343039313536353334383637363232393965333736643432\n363735373865306465\n'
    vault_object = AnsibleVaultEncryptedUnicode(vault_value)
    assert do_unvault(vault_value, secret_value) == 'this is my secret'
    assert do_unvault(vault_object, secret_value) == 'this is my secret'

# Generated at 2022-06-23 10:08:23.313019
# Unit test for function do_unvault
def test_do_unvault():
    # Secret is required
    try:
        do_unvault(None, None)
        assert False
    except AnsibleFilterTypeError:
        assert True
    except Exception:
        assert False

    # function expect a string to unvault
    try:
        do_unvault(None, "secret")
        assert False
    except AnsibleFilterTypeError:
        assert True
    except Exception:
        assert False

    # If an unencrypted string is passed, it should be returned
    assert do_unvault('unencrypted_string', 'secret') == 'unencrypted_string'

    # If an encrypted string is passed, it should be decrypted
    assert do_unvault('!vault |', 'secret') == ''

    # If a vault object is passed, it should be decrypted

# Generated at 2022-06-23 10:08:35.351783
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:43.655384
# Unit test for function do_vault
def test_do_vault():
    secret = '$6$rounds=4096$6b3q92/9r6PxI8Rz$6.0ge7F.Zmw0aT/TgYJTl7P9l0sTz7V0'
    salt = '$6$rounds=4096$6b3q92/9r6PxI8Rz'
    vaultid = 'testid'

    data = 'ecdsa key'

# Generated at 2022-06-23 10:08:44.103928
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:08:49.215419
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('scalar', 'secret') == '$ANSIBLE_VAULT;1.1;AES256;ansible_vault\noAAAA\n0wAAAAAu4izWlV7d3BiqXyj7SvNOeWyb8Z0tjZiVdGhvLcWok\nj9sG2QO7OvMFDWfB8cGnxQJD1ZKj/ACN/PfXE9pzCYC+/\n'

# Generated at 2022-06-23 10:08:55.229606
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'].__name__ == 'do_vault'
    assert filters['unvault'].__name__ == 'do_unvault'



# Generated at 2022-06-23 10:09:04.130860
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:09:07.537230
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_vault_filters = FilterModule()
    assert ansible_vault_filters.filters()['vault'] == do_vault
    assert ansible_vault_filters.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:09:14.456098
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:16.492856
# Unit test for constructor of class FilterModule
def test_FilterModule():
    x = FilterModule()
    assert(x)

# Generated at 2022-06-23 10:09:28.920772
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:33.062744
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'test', salt='test', vaultid='test') == '$ANSIBLE_VAULT;1.2;AES256;test\n6333626634626162666162643636643330666432323866383530666230656533353030363066653d0a'


# Generated at 2022-06-23 10:09:40.506352
# Unit test for function do_vault
def test_do_vault():
    secret = 'shhhh'
    test_string = 'test string'

# Generated at 2022-06-23 10:09:52.399187
# Unit test for function do_vault
def test_do_vault():
    vault_string = "ANSIBLE_VAULT;1.1;AES256\n613738636565623439333532663261643134613164623661613335646164386531646663633863316\n3863346539353366663763463736313866333930653638363531316138333233656137353636336330\n366431353363386339363937373332653036653734303236663238653633\n"
    secret = 'password'
    data = 'This is a test'
    result = do_vault(data, secret, wrap_object=False, vaultid='filter_default')
    assert result == vault_string


# Generated at 2022-06-23 10:09:53.883365
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test with no params
    assert True == isinstance(FilterModule(), FilterModule)



# Generated at 2022-06-23 10:10:05.941509
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from jinja2.runtime import Undefined


# Generated at 2022-06-23 10:10:10.418386
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """Unit test of method filters of class FilterModule"""
    test_string = 'test filter'
    filter_module = FilterModule()
    assert filter_module.filters()['vault'](test_string, 'test', 'test')
    assert filter_module.filters()['unvault'](filter_module.filters()['vault'](test_string, 'test', 'test'), 'test')

# Generated at 2022-06-23 10:10:19.532710
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    # test with good data
    secret = "correcthorsebatterystaple"
    salt = "salt"
    vault = do_vault("top_secret_data", secret, salt)
    assert vault != "top_secret_data"
    assert is_encrypted(vault)
    data = do_unvault(vault, secret)
    assert data == "top_secret_data"

    # test with bad data
    try:
        do_unvault("top_secret_data", secret)
        assert False
    except:
        assert True

# Generated at 2022-06-23 10:10:20.877237
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:10:22.567433
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_inst = FilterModule()
    assert test_inst

# Generated at 2022-06-23 10:10:24.508193
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)



# Generated at 2022-06-23 10:10:34.066996
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    unvault_cipher = '''$ANSIBLE_VAULT;1.1;AES256
33373632333736625d366b61326137613f3d3233303138653533363764663436353936396132653336
38353333613461316335646232393435333b6636626462616338623362646631663537343631306537
6530393335'''

# Generated at 2022-06-23 10:10:35.087229
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm != None

# Generated at 2022-06-23 10:10:42.540396
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:46.874020
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert len(filters) == 2
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:10:50.284181
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert len(FilterModule().filters()) == 2
    assert FilterModule().filters()['unvault'] == do_unvault
    assert FilterModule().filters()['vault'] == do_vault

# Generated at 2022-06-23 10:10:58.590792
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:00.728909
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test method filters of class FilterModule
    module = FilterModule()
    assert module.filters() != None

# Generated at 2022-06-23 10:11:13.079084
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    from ansible.template import Templar

    templar = Templar(None, loader=None)

    secret = 'foo'
    vaultid = 'test_do_vault'
    data = 'bar'

    # Test a string
    enc_data = do_vault(data, secret, vaultid=vaultid)
    assert enc_data
    assert '$ANSIBLE_VAULT;' in enc_data
    dec_data = do_unvault(enc_data, secret, vaultid=vaultid)
    assert dec_data == 'bar'

    # Test a jinja2 variable
    data = 'bar'
    jinja2_data = jinja2.Variable(data)


# Generated at 2022-06-23 10:11:13.804370
# Unit test for constructor of class FilterModule
def test_FilterModule():
    return FilterModule()

# Generated at 2022-06-23 10:11:23.003313
# Unit test for function do_vault

# Generated at 2022-06-23 10:11:26.154649
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    assert m.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:11:26.796758
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:11:28.211618
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')

# Generated at 2022-06-23 10:11:29.689656
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f


# Generated at 2022-06-23 10:11:33.837530
# Unit test for function do_vault
def test_do_vault():
    data = "abc"
    secret = "abc"
    vaultid = "test"
    assert isinstance(do_vault(data, secret, vaultid=vaultid), string_types)


# Generated at 2022-06-23 10:11:37.478192
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert 'unvault' in filters
    assert 'vault' in filters
    assert filters['unvault'] == do_unvault
    assert filters['vault'] == do_vault


# Generated at 2022-06-23 10:11:39.491296
# Unit test for constructor of class FilterModule
def test_FilterModule():
    """
    Constructor test
    """
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:11:39.959619
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:11:42.009282
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm
    fm = FilterModule()

# Generated at 2022-06-23 10:11:51.102123
# Unit test for function do_vault
def test_do_vault():
    data = 'secret'
    secret = 'sekrettt'
    salt = 'randomstring'
    vaultid = 'unique'
    wrap_object = True
    #act
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    #assert
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vaultid == vaultid
    assert result.salt == salt
    assert result.data == data
    assert result.wrap_object == wrap_object
    assert result.vault_secret == secret


# Generated at 2022-06-23 10:11:52.791603
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault_filter = FilterModule()
    assert vault_filter is not None

# Generated at 2022-06-23 10:12:02.413748
# Unit test for function do_unvault
def test_do_unvault():

    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os


# Generated at 2022-06-23 10:12:13.612129
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.modules.security.hardening.osx.test import test_ansible_vault

# Generated at 2022-06-23 10:12:25.591142
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:30.011844
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_mod = FilterModule()
    assert 'vault' in filter_mod.filters()
    assert 'unvault' in filter_mod.filters()


# Generated at 2022-06-23 10:12:38.959743
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:42.434970
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule()
    assert 'vault' in filters



# Generated at 2022-06-23 10:12:44.148058
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_obj = FilterModule()
    assert(test_obj is not None)

# Generated at 2022-06-23 10:12:51.575834
# Unit test for function do_unvault
def test_do_unvault():
    # pylint: disable=redefined-outer-name
    def _do_unvault(vault, secret):
        return do_unvault(vault, secret)

    # Invalid vault data type should raise error
    from datetime import datetime
    datetime_type = datetime.now()
    try:
        _do_unvault(datetime_type, 'secret')
        assert False, 'AnsibleFilterTypeError not raised for vault type datetime'
    except AnsibleFilterTypeError:
        pass

    # Invalid secret data type should raise error
    try:
        _do_unvault(vault, datetime_type)
        assert False, 'AnsibleFilterTypeError not raised for secret type datetime'
    except AnsibleFilterTypeError:
        pass

    # Check encryption of string
    secret

# Generated at 2022-06-23 10:13:00.593162
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.module_utils._text import to_native
    secret_txt = "foo"
    secret = VaultSecret(secret_txt)
    data = "bar"
    assert secret.secret == to_native("foo")
    assert data == to_native("bar")
    assert do_vault(data, secret_txt) == do_vault(data, secret)

# Generated at 2022-06-23 10:13:04.162089
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    vaultfilter = FilterModule()

    assert vaultfilter.filters()['vault'] == do_vault
    assert vaultfilter.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:13:10.208102
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    # Call method filters of the class
    filters = filter_module.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:13:20.052609
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    env = jinja2.Environment()
    env.filters['vault'] = do_vault
    template = env.from_string('{{ input | vault("f8W7Fz6Z6mjP3qmYWnD8yw==") }}')
    result = template.render(input='password')

# Generated at 2022-06-23 10:13:32.990494
# Unit test for function do_vault
def test_do_vault():
    atup = ('a', 'b', 'c')
    btup = ('d', 'e', 'f')
    ctup = ('g', 'h', 'i', 'j')
    dtup = ('k', 'l', 'm')
    etup = ('n', 'o', 'p', 'q')


# Generated at 2022-06-23 10:13:35.613834
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    assert mod.filters()['vault'] == do_vault
    assert mod.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:13:37.254491
# Unit test for constructor of class FilterModule
def test_FilterModule():

    tst = FilterModule()
    tst.filters()

# Generated at 2022-06-23 10:13:39.668690
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() is not None, "The filters method should return a dict."


# Generated at 2022-06-23 10:13:51.705953
# Unit test for function do_vault

# Generated at 2022-06-23 10:13:57.106945
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "password"
    vault = do_vault(data, secret)
    unvault = do_unvault(vault, secret)
    assert unvault == data


# Generated at 2022-06-23 10:14:08.247227
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    # Test vault
    assert len(do_vault('secretval', 'secretkey')) > 1
    # Test unvault
    assert do_unvault(do_vault('secretval', 'secretkey'), 'secretkey') == 'secretval'
    # Test unvault of plain text
    assert do_unvault('secretval', 'secretkey') == 'secretval'

    # Test vault with salt
    assert len(do_vault('secretval', 'secretkey', 'salt')) > 1
    # Test unvault with salt
    assert do_unvault(do_vault('secretval', 'secretkey', 'salt'), 'secretkey') == 'secretval'
    # Test unvault of plain text with salt
    assert do_unvault('secretval', 'secretkey') == 'secretval'

# Generated at 2022-06-23 10:14:15.024595
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'foo', 'foo') == '$ANSIBLE_VAULT;1.1;AES256\n39633a64363831646336653764663137666664376639643563653031303438643539306465373765\n31646133343462623334656466303134366337636635313135613531333835303633663830656630\n633966623661303832356363313332336132613166616433\n'


# Generated at 2022-06-23 10:14:16.709631
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Unit tests for the vault filter


# Generated at 2022-06-23 10:14:19.218020
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()



# Generated at 2022-06-23 10:14:30.121545
# Unit test for function do_vault
def test_do_vault():
    salt = 'mysalt'
    secret = 'mysupersecret'
    test_string = 'test_string'

# Generated at 2022-06-23 10:14:35.689788
# Unit test for function do_unvault
def test_do_unvault():
    data = u' This is a test'
    secret = b'ansible'
    vaultid = 'another'

# Generated at 2022-06-23 10:14:41.087570
# Unit test for function do_unvault
def test_do_unvault():

    dummy_filter = FilterModule()
    expected_result = 'dummy_data'
    secret = 'dummy_secret'

    try:
        result = dummy_filter.filters()['unvault'](expected_result, secret)
        assert result == expected_result
    except AnsibleFilterError as e:
        print(e)
        return 1

    return 0


# Generated at 2022-06-23 10:14:53.268216
# Unit test for function do_unvault
def test_do_unvault():
    import json
    # Create data to be encrypted
    data = {"username": "admin", "password": "admin"}
    data2 = {"username": "admin2", "password": "admin2"}

    # Encrypt the data using secret 'test'
    vaulted_data = do_vault(json.dumps(data), secret='test')
    vaulted_data2 = do_vault(json.dumps(data2), secret='test')

    assert vaulted_data != json.dumps(data)
    assert vaulted_data2 != json.dumps(data2)
    assert vaulted_data != vaulted_data2

    # Decrypt the vaulted data
    unvaulted_data = do_unvault(vaulted_data, secret='test')
    unvaulted_data2 = do_unv

# Generated at 2022-06-23 10:15:02.411310
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:09.445845
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:11.299027
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert set(FilterModule().filters()) == {'vault', 'unvault'}

# Unit tests for method do_vault of class FilterModule

# Generated at 2022-06-23 10:15:13.827011
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:15:16.249646
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fml = FilterModule()
    assert isinstance(fml, object)
    assert vars(fml) == {}
    assert isinstance(fml.filters, object)


# Generated at 2022-06-23 10:15:18.390134
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()

# Generated at 2022-06-23 10:15:19.889855
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None


# Generated at 2022-06-23 10:15:23.500665
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not hasattr(FilterModule, 'tests')
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-23 10:15:32.773721
# Unit test for function do_unvault
def test_do_unvault():
    import ansible.module_utils.common
    import os
    import sys

    # Ansible needs this to be loaded to look it up
    sys.path.append(os.path.dirname(ansible.__file__))
    password = open('tests/data/filter_plugin/vault.test', 'rb').readline().strip()

    vl1 = do_vault("unencrypted value", password, vaultid='test')