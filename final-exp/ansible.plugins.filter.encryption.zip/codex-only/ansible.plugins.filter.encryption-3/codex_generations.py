

# Generated at 2022-06-23 10:05:34.047624
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    secret = VaultSecret("hunter2")
    secretvs = secret.get_payload()
    secretvs_encoded = secretvs.decode('utf-8')
    assert 'Z3Vlc3Q', do_vault('guest', 'hunter2')
    assert 'YWRtaW4=', do_vault('admin', 'hunter2')
    assert secretvs_encoded in do_vault('hunter2', 'hunter2')
    assert 'Z3Vlc3Q=', do_vault('guest', 'hunter2', wrap_object=True)
    assert 'YWRtaW4=', do_vault('admin', 'hunter2', wrap_object=True)

# Generated at 2022-06-23 10:05:37.581953
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    '''Unit test for method filters of class FilterModule'''

    filter_module = FilterModule()
    assert filter_module.filters() == {
        'unvault': do_unvault,
        'vault': do_vault
    }


# Generated at 2022-06-23 10:05:45.885681
# Unit test for function do_vault
def test_do_vault():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 10:05:48.887187
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:05:59.024545
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:03.131328
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1122334455667788;1122334455667788;68617368657370616365227A746169742A7175616E7469736B2F73746174652E747874", "password", "tag_abcdefg") == "vault: tag_abcdefg password payload"

# Generated at 2022-06-23 10:06:11.711265
# Unit test for function do_vault
def test_do_vault():
    import pytest
    from base64 import b64decode


# Generated at 2022-06-23 10:06:15.359333
# Unit test for function do_unvault
def test_do_unvault():
    v = '$ANSIBLE_VAULT;1.1;AES256'
    s = 'mysecretpassword'
    data = 'this is some data'

    ansiblevault = do_vault(data, s)

    assert ansiblevault[0:len(v)] == v
    assert do_unvault(ansiblevault, s) == data

# Generated at 2022-06-23 10:06:22.075635
# Unit test for function do_vault

# Generated at 2022-06-23 10:06:33.120121
# Unit test for function do_unvault
def test_do_unvault():
    # First we define the unvault function
    def do_unvault(vault, secret):
        decrypted_bytes = b''
        secret_bytes = to_bytes(secret)
        vs = VaultSecret(secret_bytes)
        vl = VaultLib([('filter_default', vs)])
        if is_encrypted(to_bytes(vault)):
            decrypted_bytes = vl.decrypt(vault)
        else:
            decrypted_bytes = to_bytes(vault)

        return to_native(decrypted_bytes)

    # Then we set the password
    secret = 'ansible_vault'

    # Then we create a string
    data = 'ansible'

    # And we encrypt it
    vault = do_vault(data, secret)

    # Now we unvault the vault


# Generated at 2022-06-23 10:06:35.884812
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule)
    assert 'unvault' in FilterModule.filters(FilterModule)

# Generated at 2022-06-23 10:06:43.684755
# Unit test for function do_vault
def test_do_vault():
    unencrypted_data = 'dev'

# Generated at 2022-06-23 10:06:46.407828
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert hasattr(f, 'filters')
    assert callable(f.filters)

# Generated at 2022-06-23 10:06:49.787672
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils._text import to_text
    v = do_vault('secret text', 'secret')
    assert isinstance(v, to_text)
    assert is_encrypted(v)



# Generated at 2022-06-23 10:07:00.368761
# Unit test for function do_vault
def test_do_vault():
    import os
    import base64
    import pytest
    from ansible.parsing.vault import VaultSecret, VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vs = VaultSecret('TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST')
    vl = VaultLib()
    vault = vl.encrypt('foo', vs)

    assert(do_vault('foo', 'TESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTESTTEST') == vault)


# Generated at 2022-06-23 10:07:01.560388
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), FilterModule)

# Generated at 2022-06-23 10:07:06.247365
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters()['unvault']('test'), str)
    assert isinstance(fm.filters()['vault']('test', 'secret'), str)
    assert isinstance(fm.filters()['unvault'](fm.filters()['vault']('test', 'secret')), str)

# Generated at 2022-06-23 10:07:16.932623
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.plugins.filter.vault import FilterModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'test'
    vaultid='filter_default'
    data = 'test'

    fmodule = FilterModule()
    assert fmodule.filters()['unvault'](data, secret, vaultid) == data
    assert fmodule.filters()['unvault'](AnsibleVaultEncryptedUnicode(data), secret, vaultid) == data

    display.display = StringIO()
    with pytest.raises(AnsibleFilterTypeError) as excinfo:
        fmodule.filters()['unvault'](1234, secret, vaultid)

# Generated at 2022-06-23 10:07:19.731209
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm is not None
    assert fm.filters is not None
    assert type(fm.filters()) is dict
    assert len(fm.filters()) == 2



# Generated at 2022-06-23 10:07:22.779104
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:07:34.374650
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    vault = '$ANSIBLE_VAULT;1.1;AES256\r\n63336536383630643965663431346235383665313438333438313938333536326536306238326265\r\n39393834366564623937316662356262343234383035343965313236636161366134313561336166\r\n63613564373637323065333163643662323131633662623934323265363833386563356437656233\r\n3564633765393361366235633666326137313832333062'
    assert do_vault('mydata', secret) == vault

# Generated at 2022-06-23 10:07:36.441092
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert(fm is not None)

# Generated at 2022-06-23 10:07:45.035342
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$ANSIBLE_VAULT;1.2;AES256;ansible_test\n39696b33393134393437385a67684051383157633664524a7a5035383477536f5a784e50437a3d3d\n'
    filter_module = FilterModule()
    filters = filter_module.filters()
    unvault_value = 'secret value'
    assert(filters['unvault'](secret, 'test_password') == unvault_value)

# Generated at 2022-06-23 10:07:58.008070
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_FilterModule = FilterModule()
    assert test_FilterModule.filters()['vault'](data='foo', secret='bar') == "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          39373633643433613764656165346361633637376630626464666463376231326564333735643037\n          3935356337363737363335393232326535646632383633663762610a326564306530623766343463\n          34663831643534666432353930343930383564363333326664326434646561623863353763323538\n          6363623835313037366330620a\n          "
    assert test_FilterModule.fil

# Generated at 2022-06-23 10:07:58.620360
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()

# Generated at 2022-06-23 10:08:07.434551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fmodule = FilterModule()

    from ansible import context
    from ansible.utils.path import unfrackpath

    context.CLIARGS = {'vault_password_files': [unfrackpath('/path/to/vault_password_file')]}
    context._init_global_context(context.CLIARGS)

    # getter for the vault_ids
    vault_ids = context.CLIARGS['vault_ids']

    assert isinstance(fmodule.filters(), dict)
    assert fmodule.filters()['vault'] == do_vault
    assert fmodule.filters()['unvault'] == do_unvault

    # no error when vaultid is "vault_default"

# Generated at 2022-06-23 10:08:15.986025
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:26.884861
# Unit test for function do_vault
def test_do_vault():
    display.v(4, "Testing do_vault")
    secret = VaultSecret("password")
    vl = VaultLib()

# Generated at 2022-06-23 10:08:28.959696
# Unit test for constructor of class FilterModule
def test_FilterModule():
    cls = FilterModule()
    assert hasattr(cls, 'filters')


# Generated at 2022-06-23 10:08:36.320884
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    try:
        import javaproperties
    except ImportError:
        print('Skipping because javaproperties is not installed')
        return
    # does not work with jinja2 from the venv if not in the same dir
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.unsafe_proxy import AnsibleUnsafeProxy
    from ansible.compat.collections import MutableMapping
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnic

# Generated at 2022-06-23 10:08:48.608232
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'

    # Test unvaulting an empty string

# Generated at 2022-06-23 10:09:01.103919
# Unit test for function do_vault
def test_do_vault():

    input_secret = 'testsecret'
    input_data = 'testdata'

# Generated at 2022-06-23 10:09:03.403485
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test for creating object
    fm = FilterModule()
    assert fm.filters() is not None


# Generated at 2022-06-23 10:09:11.818040
# Unit test for function do_unvault
def test_do_unvault():

    result = do_unvault("$ANSIBLE_VAULT;1.2;AES256;default3930609236370848250\n333464373335656637343733656233643762313963386366343930301a383336363730656434\n6438353864323337616632316466306334623161340a37363039613735396238313232373365\n6332373038333836353466653933363435656630653633613236383338653166666532653266\n316133643066383566323565\n", "secret", "default")

    assert result == "ansible"

    result = do_unvault("ansible", "secret", "default")


# Generated at 2022-06-23 10:09:20.854891
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:23.002889
# Unit test for constructor of class FilterModule
def test_FilterModule():
    m = FilterModule()
    assert isinstance(m, FilterModule)


# Generated at 2022-06-23 10:09:24.422438
# Unit test for constructor of class FilterModule
def test_FilterModule():
    FilterModule()



# Generated at 2022-06-23 10:09:33.812527
# Unit test for function do_unvault
def test_do_unvault():
    # no exception
    assert isinstance(do_unvault('foo', 'bar'), string_types)

    # exceptions
    try:
        do_unvault('foo', 5)
    except AnsibleFilterTypeError as e:
        assert isinstance(e.message, string_types)

    try:
        do_unvault(5, 'bar')
    except AnsibleFilterTypeError as e:
        assert isinstance(e.message, string_types)

    try:
        do_unvault('foo', 'bar', vaultid=5)
    except AnsibleFilterTypeError as e:
        assert isinstance(e.message, string_types)


# Generated at 2022-06-23 10:09:35.083253
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(None)
    assert 'unvault' in FilterModule.filters(None)


# Generated at 2022-06-23 10:09:36.478101
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        FilterModule()
    except:
        assert False
    assert True

# Generated at 2022-06-23 10:09:50.220671
# Unit test for function do_unvault
def test_do_unvault():
    import os

    secret = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    data_list = [
        'Test',
        'Test without secret'
    ]
    data_list_with_secret = [
        'Test'
    ]

    for data in data_list:
        assert do_vault(
            data, secret, wrap_object=False) == do_vault(
            data, secret, wrap_object=True)

    for i, data in enumerate(data_list):
        assert do_unvault(
            do_vault(data, secret, wrap_object=False), secret) == data

# Generated at 2022-06-23 10:10:01.909410
# Unit test for function do_vault
def test_do_vault():
    # test if type of secret is string
    try:
        value = do_vault('password', 123)
    except AnsibleFilterTypeError as e:
        assert "Secret passed is required to be a string" in str(e)

    # test if type of data is string
    try:
        value = do_vault(123, 'password')
    except AnsibleFilterTypeError as e:
        assert "Can only vault strings" in str(e)

    # test if secret is empty string
    try:
        value = do_vault('password', '')
    except AnsibleFilterError as e:
        assert 'the secret is empty' in str(e)

    # test if data is empty string

# Generated at 2022-06-23 10:10:05.059014
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f

# Generated at 2022-06-23 10:10:13.193515
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted

    # Setup an instance of FilterModule and fetch filters for it
    fm = FilterModule()
    filters = fm.filters()

    # Test vault filter
    assert not isinstance(filters['vault']('test_data', 'test_secret'), AnsibleVaultEncryptedUnicode)
    assert isinstance(filters['vault']('test_data', 'test_secret', wrap_object=True), AnsibleVaultEncryptedUnicode)
    assert is_encrypted(filters['vault']('test_data', 'test_secret', wrap_object=True))

    # Test unvault filter

# Generated at 2022-06-23 10:10:13.877941
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter=FilterModule()


# Generated at 2022-06-23 10:10:15.757275
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:10:16.759412
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:10:17.704352
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:10:31.365436
# Unit test for function do_unvault
def test_do_unvault():
    def _check_unvault(input, secret, output):
        assert do_unvault(input, secret) == output
    # test: unvault a string

# Generated at 2022-06-23 10:10:40.801154
# Unit test for function do_vault

# Generated at 2022-06-23 10:10:52.305969
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.hashing import checksum_s
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from vaultlib import VaultSecret, VaultLib
    import yaml
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestDoVault(unittest.TestCase):

        def test_with_bytes(self):
            secret = VaultSecret('secret')
            vault = VaultLib()
            data = 'data'
            salt = None
            wrapped = False

            expected = vault.encrypt(to_bytes(data), secret, '', salt)
            actual = do_vault

# Generated at 2022-06-23 10:10:59.958493
# Unit test for constructor of class FilterModule
def test_FilterModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import is_encrypted

    tf = FilterModule()

    # test vauling and unvauling
    data = "my_secret"
    secret = "my_secret"
    salt = "my_salt"
    vaultid = 'filter_default'

    vault = tf.filters()['vault'](data, secret, salt, vaultid)
    data_back = tf.filters()['unvault'](vault, secret, vaultid)

    assert data == data_back

    # test with AnsibleUnicode
    data = AnsibleUnicode("my_secret")
    secret = AnsibleUnicode("my_secret")

# Generated at 2022-06-23 10:11:05.107161
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    result = obj.filters()
    assert result['vault'] is do_vault, 'method filters of class FilterModule does not work'
    assert result['unvault'] is do_unvault, 'method filters of class FilterModule does not work'



# Generated at 2022-06-23 10:11:16.660551
# Unit test for function do_vault
def test_do_vault():
    import os

    try:
        test_secret = os.environ['ANSIBLE_VAULT_TEST_SECRET']
    except KeyError:
        test_secret = 'password'


# Generated at 2022-06-23 10:11:23.177925
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.vault import is_encrypted
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters
    vault = filters['vault']
    unvault = filters['unvault']
    assert vault("data", "secret", wrap_object=True)
    assert is_encrypted(vault("data", "secret", wrap_object=True))
    assert isinstance(unvault("$ANSIBLE_VAULT;1.1;AES256;alias", "secret"), string_types)

# Generated at 2022-06-23 10:11:36.040825
# Unit test for function do_unvault
def test_do_unvault():
    vault_provider = [['filter_default', 'secret']]

    # Create cases for the unit test

# Generated at 2022-06-23 10:11:46.931613
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ''' Unit test for method filters of class FilterModule '''
    f = FilterModule()
    results = f.filters()
    assert 'vault' in results
    assert type(results['vault']) is type(do_vault)

    assert 'unvault' in results
    assert type(results['unvault']) is type(do_unvault)


# Generated at 2022-06-23 10:11:48.298143
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    fm.filters()


# Generated at 2022-06-23 10:11:51.692903
# Unit test for function do_unvault
def test_do_unvault():
    unvault = do_unvault(unvault, secret)
    assert unvault is not None


# Generated at 2022-06-23 10:12:00.610507
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n36336534303632666132383366343733346232363633373364303831333637313863303165393531\n65396665353836393734333830663166363132623066306364663866616562333136613163366138\n39306362393334626537616362623763313930313661316334336432363662613365353262376539\n38324641633130643630643163\n'


# Generated at 2022-06-23 10:12:10.913597
# Unit test for function do_vault
def test_do_vault():
    import pytest

    class FilterModuleTest(object):
        def filters(self):
            return {}

    defs = FilterModuleTest()

    # Valid tests

    # test string
    data = "test data"
    secret = "test secret"
    ret = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)
    assert isinstance(ret, string_types)

    # test byte
    data = b"test data"
    secret = b"test secret"
    ret = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)
    assert isinstance(ret, string_types)

    # test data - AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 10:12:12.755454
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert(set(FilterModule().filters().keys()) == {"vault", "unvault"})


# Generated at 2022-06-23 10:12:21.760966
# Unit test for function do_vault
def test_do_vault():

    data = 'This is the data to encrypt'
    secret = 'Forthewin1'


# Generated at 2022-06-23 10:12:22.859952
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')


# Generated at 2022-06-23 10:12:30.011921
# Unit test for function do_vault
def test_do_vault():
    data = 'secret'
    secret = 'ansible'
    salt = None
    vault_id = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vault_id, wrap_object)
    new_data = do_unvault(vault, secret, vault_id)
    assert data == new_data


# Generated at 2022-06-23 10:12:41.530320
# Unit test for function do_vault

# Generated at 2022-06-23 10:12:45.784625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """ Unit test for method filters of class FilterModule """

    fm = FilterModule()
    out = fm.filters()
    assert out == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:12:47.763761
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert repr(FilterModule()) == '<ansible.plugins.filter.vault.FilterModule object at %s>' % hex(id(FilterModule()))


# Generated at 2022-06-23 10:12:50.889132
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    answer = "password"
    vault_obj = filter_module.filters()['vault'](answer, "vault_secret")
    assert vault_obj is not None
    assert filter_module.filters()['unvault'](vault_obj, "vault_secret") == answer

# Generated at 2022-06-23 10:12:51.547130
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:12:55.018707
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecrete'
    data = 'Hello World!'
    expected = '$ANSIBLE_VAULT;1.1;AES256\n' \
               '6338356566393464616165353730363762323031383338663863326630373533623337633337\n' \
               '3031643633636166336666386134373634303635396638323537303032393265353336666165\n' \
               '373533\n'

    assert expected == do_vault(data, secret)



# Generated at 2022-06-23 10:13:05.871517
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("test", "password") == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;ansible\n          3262323935633937643565386436323339316334396164623431666331356338613535663731353630\n          366663376561326264626535313564313063616365653336366631316465303564356366350a613738\n          3565613339623033616361376139613838333732323265353833383763653437656163336263623930\n          3537633136313231656439316232346361336530363765333965373433636162646531"

# Generated at 2022-06-23 10:13:11.871075
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    t_vault = FilterModule.filters(FilterModule)
    assert t_vault.get('vault') == do_vault
    assert t_vault.get('unvault') == do_unvault
    assert t_vault.get('test') == None


# Generated at 2022-06-23 10:13:21.269794
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'an_awesome_secret'

# Generated at 2022-06-23 10:13:34.146250
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import random
    from ansible_collections.ansible.community.plugins.filter.vault import FilterModule

    # prepare the test data.
    test_contents = {
        'key_1': 'test_value_1',
        'key_2': 'test_value_2',
        'key_3': 'test_value_3',
        'key_4': 'test_value_4',
        'key_5': 'test_value_5',
    }

    # generate 5 random secrets
    secrets = [os.urandom(random.randint(10, 25)) for i in range(5)]
    secrets_dict = dict(zip(test_contents.keys(), secrets))

    # generate 5 random vault passwords

# Generated at 2022-06-23 10:13:41.557827
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'some_secret'
    vaultid = 'filter_default'
    mydata = 'some_data'

    # Encrypt mydata
    myvault = do_vault(mydata, secret, vaultid=vaultid)

    data = do_unvault(myvault, secret, vaultid=vaultid)

    assert type(data) == Undefined
    assert data.data == mydata
    assert data.vaultid == vaultid



# Generated at 2022-06-23 10:13:42.685282
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:13:54.140914
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:55.972017
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:14:04.485107
# Unit test for function do_unvault
def test_do_unvault():
    '''
    Unit test for function do_unvault
    :return:
    '''
    # the data to encrypt
    data = 'data_to_encrypt'
    # the vault password
    secret = 'my_secret_password'

    # encrypt the data
    encrypted_data = do_vault(data, secret)
    # decrypt the data
    decrypted_data = do_unvault(encrypted_data, secret)

    # check if the data is the same
    assert True if data == decrypted_data else False

# Generated at 2022-06-23 10:14:15.189408
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:22.228443
# Unit test for function do_vault
def test_do_vault():
    class Options:
        salt = None

    import jinja2

    env = jinja2.Environment()
    env.filters['vault'] = do_vault

    secret = 'test'
    salt = 'aa'
    data = 'test_data'

    t = env.from_string("{{ data | vault(secret, salt) }}")
    result = t.render(data=data, secret=secret, salt=salt)

    assert is_encrypted(result)



# Generated at 2022-06-23 10:14:22.862637
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass

# Generated at 2022-06-23 10:14:26.130244
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import get_file_vault_secret

    password = get_file_vault_secret(["tests/unit/fixtures/vault_secret"], None, None)
    value = "my secret string"
    encrypted_value = do_vault(value, password)
    decrypted_value = do_unvault(encrypted_value, password)
    assert(value == decrypted_value)

# Generated at 2022-06-23 10:14:29.294403
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert isinstance(FilterModule().filters(), dict)


# Generated at 2022-06-23 10:14:41.424713
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:45.703030
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    result = filter_module.filters()

    assert result == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:14:46.429733
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert(isinstance(FilterModule().filters(), dict))



# Generated at 2022-06-23 10:14:48.720029
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:14:54.092117
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('Hello World', 'VaultSecret')
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n366432653661633463356438643235643933353030316665623334323161386133313661623239316\n306461383631626632633661383034613567393064316135378332427334374723650e\n'


# Generated at 2022-06-23 10:14:57.157419
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    a = {"vault": (do_vault), "unvault": (do_unvault)}
    fm = FilterModule()
    assert a == fm.filters()


# Generated at 2022-06-23 10:15:06.837278
# Unit test for function do_vault
def test_do_vault():
    secret = 'donttell'
    data = 'hello world'
    vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          36626534303835383635333339656439663735346638613234303232303562376137613232383031\n          6331653563353162653835646636653037343962643563396134653262366330326632653465373733\n          343765663735363764333036\n"
    assert do_vault(data, secret) == vault



# Generated at 2022-06-23 10:15:19.679172
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:31.390345
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Test case where secret is not passed
    try:
        FilterModule().filters()["vault"]("foo", None)
    except AnsibleFilterTypeError as e:
        pass
    else:
        assert False, "AnsibleFilterTypeError was not raised"

    # Test case where secret is not a string
    try:
        FilterModule().filters()["vault"]("foo", 123456)
    except AnsibleFilterTypeError as e:
        pass
    else:
        assert False, "AnsibleFilterTypeError was not raised"

    # Test case where data is not passed
    try:
        FilterModule().filters()["vault"](None, "bar")
    except AnsibleFilterTypeError as e:
        pass
    else:
        assert False, "AnsibleFilterTypeError was not raised"

   