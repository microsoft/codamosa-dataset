

# Generated at 2022-06-23 10:05:26.991944
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    F = FilterModule()
    filters = F.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:05:30.174172
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    x = fm.filters()

    assert x['vault'] == do_vault
    assert x['unvault'] == do_unvault



# Generated at 2022-06-23 10:05:34.154911
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert 'vault' in obj.filters()
    assert 'unvault' in obj.filters()

# Generated at 2022-06-23 10:05:43.793279
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'MyPasword123') == '$ANSIBLE_VAULT;1.1;AES256;'
    assert do_vault('foo', 'MyPasword123', salt='somesalt') == '$ANSIBLE_VAULT;1.1;AES256;somesalt'
    assert do_vault('foo', 'MyPasword123', vaultid='special') == '$ANSIBLE_VAULT;1.1;AES256;special'
    assert do_vault('foo', 'MyPasword123', wrap_object=True).__class__.__name__ == 'AnsibleVaultEncryptedUnicode'


# Generated at 2022-06-23 10:05:54.817400
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:03.461454
# Unit test for function do_unvault
def test_do_unvault():
    secret = '7c9f04e71e7bb9f72f37c7247136701700d1daf57e0fef1f'
    vaultid = '19b0a6b0-6b15-6d56-0c09-a0b050034c1d'

# Generated at 2022-06-23 10:06:08.004975
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module.filters()['vault'] == do_vault
    assert filter_module.filters()['unvault'] == do_unvault



# Generated at 2022-06-23 10:06:17.324499
# Unit test for function do_vault
def test_do_vault():
    secret = 'Ch1ang3M3!'
    salt = 'Ch1ang3M3!'
    vaultid = 'Ch1ang3M3!'
    data = 'This data is secret'
    wrap_object = True

# Generated at 2022-06-23 10:06:31.564534
# Unit test for function do_vault
def test_do_vault():
    import pytest

    secret = "mysecret"
    data = "mydata"

    result = {'data': data, 'secret': secret}

    # Happy path
    assert do_vault(data, secret) is not None
    assert do_vault(data, secret) != data

# Generated at 2022-06-23 10:06:41.330379
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import pytest
    from jinja2.runtime import Undefined


# Generated at 2022-06-23 10:06:43.845868
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filt = FilterModule().filters()
    assert filt is not None
    assert 'unvault' in filt
    assert 'vault' in filt

# Generated at 2022-06-23 10:06:55.557082
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    vl = VaultLib()

    vault_key = 'password'
    vault_secret = VaultSecret(to_bytes(vault_key))
    vault_data = 'top_secret'

    # Encrypt plain_text
    if is_encrypted(vault_data):
        raise AnsibleFilterError('Plain text is encrypted')

    vault_encrypt = vl.encrypt(to_bytes(vault_data), vault_secret)

    # Check if the encrypted data is encrypted
    if not is_encrypted(vault_encrypt):
        raise AnsibleFilterError('Encrypted text is not an encrypted data')

    # Decrypt data
    vault_decrypt = do_unvault(vault_encrypt, vault_key)

    # Check if the decrypted data

# Generated at 2022-06-23 10:07:06.504214
# Unit test for function do_unvault
def test_do_unvault():
	import os
	with open("/home/szibik/shared/techwithtim/Ansible/Building_Ansible_from_Scratch/Ansible/AnsibleVault/vault-secret") as f:
		secret_string = f.read()
	with open("/home/szibik/shared/techwithtim/Ansible/Building_Ansible_from_Scratch/Ansible/AnsibleVault/vault") as f:
		vault_string = f.read()
	data = do_unvault(vault_string, secret_string)
	print(data)
	assert data == "pete"


# Generated at 2022-06-23 10:07:08.965411
# Unit test for function do_unvault
def test_do_unvault():
    vaulted = "!vault |1|1|foo"
    assert(do_unvault(vaulted, "foo", vaultid='filter_default') == "!vault")

# Generated at 2022-06-23 10:07:19.402830
# Unit test for function do_vault
def test_do_vault():

    secret = "superSecret"
    data = "Hello there General Kenobi"
    salt = "salty"
    vaultid = "filter_default"
    wrap_object = False


# Generated at 2022-06-23 10:07:32.559381
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    display.vv("do_vault: secret: %s, salt: %s, data: %s" % (secret, salt, data))
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    display.vv("do_vault: vault: %s" % (vault))
    display.vv("do_vault: data: %s" % (do_unvault(vault, secret, vaultid)))
    assert isinstance(vault, string_types)
    assert isinstance(data, string_types)
    assert isinstance(do_unvault(vault, secret, vaultid), string_types)

# Generated at 2022-06-23 10:07:34.773274
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  fm = FilterModule()
  filters = fm.filters()
  assert 'vault' in filters
  assert 'unvault' in filters



# Generated at 2022-06-23 10:07:35.925208
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters() is not None


# Generated at 2022-06-23 10:07:47.389741
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'some data'
    salt = 'somesalt'
    vaultid = 'test_file'

    # Encrypting a string data
    result = do_vault(data, secret)

# Generated at 2022-06-23 10:08:00.007788
# Unit test for function do_vault
def test_do_vault():
    secret = 'test_secret'
    data = 'test_data'

# Generated at 2022-06-23 10:08:08.618107
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_filter_module = FilterModule()
    test_filters = test_filter_module.filters()

    test_secret = 'testsecret'
    test_salt = 'testsalt'
    test_input_data = 'test'
    test_output = '$ANSIBLE_VAULT;1.1;AES256;testsalt\n6330323735333831303632323237653763313232376236396530653439363633376231343530643\n6163643139303834333763633835303636396630626435663338366634393864392b0d0a'

    # test filters with expected input and expected output
    assert test_filters['vault'](test_input_data, test_secret, test_salt) == test_output

# Generated at 2022-06-23 10:08:10.612050
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
  

# Generated at 2022-06-23 10:08:13.310558
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:08:25.111068
# Unit test for function do_vault
def test_do_vault():

    # Input
    secret = '$ANSIBLE_VAULT;1.1;AES256'
    salt = b'A' * 16
    data = 'test filter'

    # Output

# Generated at 2022-06-23 10:08:34.804572
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible_default\n6236393564663033646638356439636539643563616265373863316632353065366233346638\n3465353764336539633337373934343238393165363337373536333065346664353937303731\n3537383537313862303162653436336633626261643635346632373239313238393365653066\n6337623631396162366432632633265', 'secret') == 'my_secret'


# Generated at 2022-06-23 10:08:37.135251
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    # check return type of filters, we cannot check the rest here
    assert isinstance(fm.filters, dict)

# Generated at 2022-06-23 10:08:48.843814
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    # test invalid secret type
    try:
        do_vault('secret', ['secret'])
        assert False
    except AnsibleFilterTypeError:
        pass

    # test invalid datatype
    try:
        do_vault(1, 'secret')
        assert False
    except AnsibleFilterTypeError:
        pass

    # test vault
    vault = do_vault('secret', 'secret')
    assert isinstance(vault, string_types)
    assert not vault.startswith('$ANSIBLE_VAULT')

    # test wrapped vault
    vault = do_vault('secret', 'secret', wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
   

# Generated at 2022-06-23 10:09:01.242424
# Unit test for function do_unvault
def test_do_unvault():
    secret = '$argon2i$v=19$m=4096,t=3,p=1$7i0gDT/uV/Z0DxHxOkeK3w$lgV7N/iRkTSlKcG83gTfKd9M8R+WUZv6LwgYUyjL8sI'
    vault1 = '$ANSIBLE_VAULT;1.2;AES256;filter_default;'
    vault1 = vault1 + '39743265326532632623532353265396635303561663764653735643966656437653564'
    vault1 = vault1 + '373566383566623332626636323138393736613835316232653761303933363237373463'

# Generated at 2022-06-23 10:09:05.138344
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filterModule = FilterModule()
    filters = filterModule.filters()

    assert 'vault' in filters
    assert callable(filters['vault'])

    assert 'unvault' in filters
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:09:06.765148
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:09:07.999839
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()

    assert filter_module.filters()['vault']

# Generated at 2022-06-23 10:09:19.433152
# Unit test for function do_vault
def test_do_vault():
    ''' Test function do_vault '''

# Generated at 2022-06-23 10:09:24.082978
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # Instantiate FilterModule class
    fm = FilterModule()
    # Test method filters
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:09:33.575447
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:46.663437
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:48.424962
# Unit test for function do_vault
def test_do_vault():
    secret = 'my-secret'
    data = 'my-data'
    vault = do_vault(data, secret)
    assert AnsibleVaultEncryptedUnicode(vault).decrypt(secret) == data

# Generated at 2022-06-23 10:09:48.954589
# Unit test for constructor of class FilterModule
def test_FilterModule():
    instance = FilterModule()
    assert(instance != None)

# Generated at 2022-06-23 10:09:57.054210
# Unit test for function do_vault
def test_do_vault():
    # Tests for function 'do_vault'
    # Case: Regular run with a valid string
    assert do_vault("12345", "test", salt=None, vaultid='filter_default', wrap_object=False) == "!vault " \
                                                                                              "$ANSIBLE_VAULT;1.1;" \
                                                                                              "AES256;filter_default\n" \
                                                                                              "38306535323066636439306365323532316433366536626430373566653739336137633161393264\n" \
                                                                                              "35333066393533663533613366363761336234343066633137366635396532386133386338656665\n" \
                                                

# Generated at 2022-06-23 10:09:58.670059
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:10:08.388066
# Unit test for function do_unvault
def test_do_unvault():
    ''' do_unvault unvaults vaulted data '''

    # Test valid unvault
    data = b'$ANSIBLE_VAULT;1.1;AES256;test\n6133643039613864633038353239336561346363663735613431323463636161663237613031633066\n353934323066653933666630373062623961333463633038616236633239656637326233343235336662\n31343136386530336638613531353134396638353866'
    secret = b'test'
    result = 'test'
    assert do_unvault(data, secret) == result

    # Test invalid unvault

# Generated at 2022-06-23 10:10:13.408123
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['vault'] == do_vault
    assert f.filters()['unvault'] == do_unvault


# Generated at 2022-06-23 10:10:15.177582
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault_filters = FilterModule()
    vault_filters.filters()

# Generated at 2022-06-23 10:10:23.151594
# Unit test for function do_unvault
def test_do_unvault():
    # Given string without encryption
    unencrypted_string = 'test'
    secret = 'my_secret'
    # When do_unvault is called
    result = do_unvault(unencrypted_string, secret)
    # Then
    # Result is equal to unencrypted_string
    assert result == unencrypted_string

    # Given encrypted string
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    data = 'test'

# Generated at 2022-06-23 10:10:25.578522
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-23 10:10:32.094697
# Unit test for function do_unvault
def test_do_unvault():
    try:
        vault = do_vault("foo", "secret")
        assert isinstance(vault, string_types), "Encryption function should return a string"
        data = do_unvault(vault, "secret")
        assert isinstance(data, string_types), "Decryption function should return a string"
        assert data == "foo", "Decryption was unsuccessful"
    except Exception as e:
        assert False, "Unable to call function do_unvault: %s" % to_native(e)

# Generated at 2022-06-23 10:10:33.511426
# Unit test for function do_vault
def test_do_vault():

    assert "Vault encrypted" in do_vault("secret", "password", wrap_object=True)



# Generated at 2022-06-23 10:10:36.592551
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    sut = FilterModule()
    result = sut.filters()

    assert len(result) == 2
    assert result['vault'] == do_vault
    assert result['unvault'] == do_unvault

# Generated at 2022-06-23 10:10:48.615889
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 10:10:57.393040
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:10.117703
# Unit test for function do_vault
def test_do_vault():
    secret = "hello"
    data = "hello world"

    # Without salt
    encrypted_data = do_vault(data, secret)
    #print(encrypted_data)

# Generated at 2022-06-23 10:11:14.046784
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:11:17.097216
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert len(filters) == 2
    assert "vault" in filters
    assert "unvault" in filters

# Generated at 2022-06-23 10:11:23.970987
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('str', 'str') == '$ANSIBLE_VAULT;1.1;AES256\n63346162396132613366323837373438363734666437623866646662323163396236396131393665\n65326634356531623730336165353134373835666531633237316666333665393537363631636664\n363435363438663130656239326134383461633130610a6661393835303862393265636334303862\n383738663833356266323535646237\n'


# Generated at 2022-06-23 10:11:36.737581
# Unit test for function do_unvault
def test_do_unvault():
    # for unit tests, vaultid must be 'test'
    # otherwise, VaultSecret will throw KeyError
    try:
        assert do_unvault('$ANSIBLE_VAULT;1.2;ESO;1;1;0lhZP+it8ns3q3fBp1fBJt+cA8XeWk5v5dSz5fZJpA+COa4PvwTa4A==', 'password', 'test') == 'test'
    except UndefinedError as e:
        assert "Unable to decrypt: missing secret for test in password" in e.message
    except:
        # KeyError may also be thrown by VaultSecret
        pass

# Generated at 2022-06-23 10:11:43.043039
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.vault import do_encrypt
    import jinja2
    from datetime import datetime

    myclass = FilterModule()
    display.display('My class %s' % myclass.__class__.__name__, color='blue', stderr=True)
    myfilters = myclass.filters()
    display.display('My filters %s' % ','.join(myfilters), color='blue', stderr=True)

    secret = 'A very long and complicated password to test encryption and decryption of text'
    salt = None
    fn = 'filter_default'

# Generated at 2022-06-23 10:11:52.975581
# Unit test for function do_vault
def test_do_vault():

    # Return type
    assert isinstance(do_vault("hello", "world"), string_types)
    assert isinstance(do_vault("hello", "world", wrap_object=True), AnsibleVaultEncryptedUnicode)

    # Expected/valid vault

# Generated at 2022-06-23 10:11:54.998060
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert f.filters()['unvault'] == do_unvault

# Generated at 2022-06-23 10:11:58.218588
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters().keys()
    assert 'unvault' in fm.filters().keys()

# Generated at 2022-06-23 10:12:11.428363
# Unit test for function do_vault
def test_do_vault():
    print("Test do_vault")

    # Should work with secret and salt

# Generated at 2022-06-23 10:12:15.949131
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule(None)
    filters = fm.filters()

    # Check length of keys of filters
    assert (len(filters.keys()) == 2)

    # Check filters keys
    assert (filters.keys() == ['vault', 'unvault'])

    # Check filters values
    assert (filters.values() == [do_vault, do_unvault])

# Generated at 2022-06-23 10:12:18.166227
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter


# Generated at 2022-06-23 10:12:26.809465
# Unit test for function do_vault

# Generated at 2022-06-23 10:12:28.982869
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'unvault' in FilterModule.filters(FilterModule())

# Generated at 2022-06-23 10:12:38.510672
# Unit test for function do_vault

# Generated at 2022-06-23 10:12:49.632823
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:51.561199
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)



# Generated at 2022-06-23 10:12:58.349172
# Unit test for function do_unvault
def test_do_unvault():

    secret = "abc123"
    vaultid = "unvault_default"

# Generated at 2022-06-23 10:12:59.874757
# Unit test for constructor of class FilterModule
def test_FilterModule():
    a = FilterModule()
    assert a.filters

# Generated at 2022-06-23 10:13:08.174297
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"

    data = "secret test"
    vault = do_vault(data, secret)

# Generated at 2022-06-23 10:13:18.830552
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foobar', 'secret', wrap_object=True).data == 'ANSIBLE_VAULT;1.0;AES256;filter_default\n323235316662363339346531613161333131343930636631633337383431353136636532353165\na36234636263643239356661656363376337343363336530343134313662663665396237626236\n616466633131363661613935393963376234326266636335636534366463336664327d0a', 'Encrypting a string should return VaultSecrets'

# Generated at 2022-06-23 10:13:20.960955
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] == do_vault
    assert fm.filters()['unvault'] == do_unvault


# Generated at 2022-06-23 10:13:22.543317
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    pass



# Generated at 2022-06-23 10:13:23.718469
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:13:24.415432
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:13:36.044499
# Unit test for function do_vault
def test_do_vault():

    # Test that encryption works as expected
    test_secret = 'testsecret'
    test_string = 'teststring'

    # Test that encryption works as expected
    encrypted = do_vault(test_string, test_secret)
    decrypted = do_unvault(encrypted, test_secret)

    assert decrypted == test_string

    # Test that NotImplementedError is raised when secret is not str or binary
    try:
        do_vault(test_string, True)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False

    # Test that NotImplementedError is raised when data is not str or binary
    try:
        do_vault(True, test_secret)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 10:13:37.149837
# Unit test for constructor of class FilterModule
def test_FilterModule():
    pass



# Generated at 2022-06-23 10:13:42.870299
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:13:44.038227
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    return True

# Generated at 2022-06-23 10:13:47.703098
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:13:57.029993
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("abc123", "secret") == "\n$ANSIBLE_VAULT;1.1;AES256\n30663964383763646631373634376664353766633463656564383434616465623336626164613338\n6630623334343938336239633762616139643165346531310a636266656333363133383864663937\n62383938626331663734376338616333643338313263646630646337663664363930336134363834\n313733373432313734340a\n"

# Generated at 2022-06-23 10:13:59.361957
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert set(['vault', 'unvault']) == set(FilterModule().filters().keys())

# Generated at 2022-06-23 10:14:04.942558
# Unit test for function do_unvault
def test_do_unvault():
    # Test cases
    # case 1: Data is vaulted, correct password is given, correct vault id is given
    # case 2: Data is vaulted, incorrect password is given, correct vault id is given
    # case 3: Data is vaulted, correct password is given, incorrect vault id is given
    # case 4: Data is vaulted, incorrect password is given, incorrect vault id is given
    # case 5: Data is not vaulted, password is not given

    # Default vault id
    vaultid = 'filter_default'

    # Create vaulted data with vault id "filter_default"
    password = 'ansible_password'
    input_1 = 'ansible'
    vaulted = do_vault(input_1, password, vaultid=vaultid)

    # Create vaulted data with vault id 'filter_default2'
    password_2

# Generated at 2022-06-23 10:14:08.715857
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    c = FilterModule()
    assert c.filters() == {
            'vault': do_vault,
            'unvault': do_unvault,
    }, 'Filters are not returned correctly'

# Generated at 2022-06-23 10:14:19.214588
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test_secret"
    data = "test_data"
    vault = "$ANSIBLE_VAULT;1.1;AES256\n353334643138323731363666646662626331613861386131636437383531346333663660a3334383431643336303737663538356133383939653533323566653538333839650a3165646635373739343536356633323432643361353234653430646336343531323233\n"
    assert do_unvault(vault, secret) == data

# Generated at 2022-06-23 10:14:27.751610
# Unit test for function do_unvault
def test_do_unvault():
    test_filter = FilterModule()
    filters = test_filter.filters()

    secret = 'supersecret'

    # Simple input with only a string
    input_single_string = 'the quick brown fox jumps over the lazy dog'
    output = filters['unvault'](input_single_string, secret)
    assert output == input_single_string

    # Simple input with vault
    input_simple_vault = AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256\n353933373735653335346165386364663035323331326133373335643065386439306531353038326\n63396135623665346530383533393761313539323965316260626264393339\n")

# Generated at 2022-06-23 10:14:31.269390
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test'
    vault = do_vault(data, secret)
    assert data == do_unvault(vault, secret)

# Generated at 2022-06-23 10:14:42.656709
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.utils.vault import VaultAES256, VaultLib

    secret = VaultSecret()
    secret.secrets = b"abcdefghijklmno"

    s = VaultLib()
    e = VaultAES256()
    e.update(b'A long time ago in a galaxy far far away...')
    s.keys = {b"filter_default": secret}
    s.cipher = e


# Generated at 2022-06-23 10:14:44.561653
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Verify that object of class FilterModule is created
    assert FilterModule()


# Generated at 2022-06-23 10:14:52.390474
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'mysecret') == '$ANSIBLE_VAULT;1.1;AES256\n363633353034653039393635303332393638393163386131653034383335303062333566383665\n6530353966663165656432643665346330333866353361363564313764623335643036316463\n316132623461333236333236616439643765323262626432653933386538\n'


# Generated at 2022-06-23 10:14:54.690488
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'vault' in f.filters()
    assert 'unvault' in f.filters()


# Generated at 2022-06-23 10:14:56.114506
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault(5, 2) == 7


# Generated at 2022-06-23 10:15:08.029044
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultEncryptedUnicode

    data = 'data'
    secret = 'secret'
    vaultid = 'myvault'

    test_data = do_vault(data, secret, vaultid=vaultid)
    assert isinstance(test_data, VaultEncryptedUnicode)
    assert test_data != data

    test_data = do_vault(data, secret, vaultid=vaultid, wrap_object=False)
    assert isinstance(test_data, str)
    assert test_data != data

    test_data = do_vault(data, Undefined())
    assert isinstance(test_data, Undefined)

    test_data = do_vault(data, [], vaultid=vaultid)

# Generated at 2022-06-23 10:15:09.416017
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_filter_module = FilterModule()
    print(test_filter_module.filters())



# Generated at 2022-06-23 10:15:10.485913
# Unit test for function do_vault
def test_do_vault():
    print(do_vault('hello', 'bar'))


# Generated at 2022-06-23 10:15:20.618666
# Unit test for function do_unvault

# Generated at 2022-06-23 10:15:22.385501
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule