

# Generated at 2022-06-23 10:05:35.403029
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("secret text", "f9XpDcbTjKHpZmhf")
    assert vault == '$ANSIBLE_VAULT;1.2;AES256;default\n30326466336534386466633433643766366430373364353662356364613064363538346630356433\n31356461613662626361643335386637623334636266643335336631323465663738346331356535\n6530623039340a653539316463323063663466383538663736636162393533623135616139373166\n3338313032316336\n'


# Generated at 2022-06-23 10:05:45.581857
# Unit test for function do_vault
def test_do_vault():
    filter = FilterModule()
    data = 'hello world'
    secret = 'secret'
    salt = '12345'
    vaultid = 'filter_default'
    wrap_object = False
    result = filter.filters()['vault'](data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-23 10:05:55.402257
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None, 'filter_default') == ''
    assert do_unvault('Not encrypted', None, 'filter_default') == 'Not encrypted'
    assert do_unvault(b'Not encrypted', None, 'filter_default') == 'Not encrypted'

# Generated at 2022-06-23 10:06:04.160350
# Unit test for function do_vault
def test_do_vault():
    ''' Unit testing for function do_vault '''
    import pytest

    with pytest.raises(AnsibleFilterTypeError):
        do_vault('foo', 1)
    with pytest.raises(AnsibleFilterTypeError):
        do_vault(1, 'bar')
    with pytest.raises(AnsibleFilterError):
        do_vault('foo', 'bar', 'baz')

    vault_foo_bar = do_vault('foo', 'bar')
    assert is_encrypted(vault_foo_bar)
    vault_foo_bar_wrap = do_vault('foo', 'bar', wrap_object=True)
    assert isinstance(vault_foo_bar_wrap, AnsibleVaultEncryptedUnicode)


# Generated at 2022-06-23 10:06:05.282240
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-23 10:06:13.851568
# Unit test for function do_vault
def test_do_vault():

    # Successful vault
    assert do_vault("data", "secret", None, 'filter_default') == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n66346264646161646437666564383436643537333739363563336632616233323865626530666437\n393866633664333730343639393864633363616262666231373466327d0a\n'

    # Secret cannot be None
    try:
        do_vault("data", None)
    except AnsibleFilterTypeError:
        pass
    else:
        assert False, "AnsibleFilterTypeError should be raised"

    # Data cannot be None

# Generated at 2022-06-23 10:06:18.183889
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault("secret", "password")
    unvault = do_unvault(vault, "password")
    assert unvault == "secret"


# Generated at 2022-06-23 10:06:21.513349
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert result == FilterModule()


# Generated at 2022-06-23 10:06:22.603299
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None


# Generated at 2022-06-23 10:06:23.329632
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:06:26.973656
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:06:38.265098
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid_1 = "filter_default"
    vaultid_2 = "external_vault"
    vaultid_3 = "filter_default_2"
    _vault_1 = do_vault("secret_msg", secret, salt=None, vaultid=vaultid_1)
    _vault_2 = do_vault("secret_msg_2", secret, salt=None, vaultid=vaultid_2)
    _vault_3 = do_vault("secret_msg", secret, salt=None, vaultid="filter_default")
    _vault_4 = do_vault("secret_msg", secret, salt=None, vaultid=vaultid_1)


# Generated at 2022-06-23 10:06:42.332444
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert "vault" in filters.keys()
    assert "unvault" in filters.keys()



# Generated at 2022-06-23 10:06:50.348831
# Unit test for function do_unvault
def test_do_unvault():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 10:06:54.967181
# Unit test for function do_unvault
def test_do_unvault():
    data = 'test123'
    secret = 'secret123'
    vaultid = 'filter_default'
    vault = do_vault(data, secret)
    assert data == do_unvault(vault, secret, vaultid), 'unvault() works'


# Generated at 2022-06-23 10:06:59.266126
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:07:04.278859
# Unit test for function do_vault
def test_do_vault():
    ''' Unit tests for function do_vault '''
    test_filter = FilterModule()
    assert do_vault(test_filter, 'secret', 'data', vaultid='default', wrap_object=False)
    assert do_vault(test_filter, 'secret', 'data', vaultid='secret', wrap_object=True)
    assert do_vault(test_filter, 'secret', 'data', vaultid='secret', wrap_object=False)


# Generated at 2022-06-23 10:07:06.007937
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Unit test for constructor of class FilterModule
    #test = FilterModule()
    return 0


# Generated at 2022-06-23 10:07:13.797220
# Unit test for function do_vault
def test_do_vault():
    # Basic test
    data = 'secret'
    secret = 'mySecret'
    vault = do_vault(data, secret)
    assert is_encrypted(vault) is True

    # Test exceptions
    try:
        do_vault('secret', {})
    except AnsibleFilterTypeError as e:
        # Expected exception
        assert 'Secret passed is required to be a string' in str(e)
    else:
        assert False, 'Expected exception'

    try:
        do_vault({}, 'secret')
    except AnsibleFilterTypeError as e:
        # Expected exception
        assert 'Can only vault strings' in str(e)
    else:
        assert False, 'Expected exception'



# Generated at 2022-06-23 10:07:19.908664
# Unit test for function do_vault
def test_do_vault():
    secret = "This is my secret"
    salt = "This is my salt"
    data = "This is my data"

    vault_test = do_vault(data, secret, salt)
    assert isinstance(vault_test, string_types)
    assert len(vault_test) > len(data)

    vault_test = do_vault(data, secret, salt, wrap_object=True)
    assert isinstance(vault_test, AnsibleVaultEncryptedUnicode)
    assert len(vault_test) > len(data)


# Generated at 2022-06-23 10:07:20.956496
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert filters is not None

# Generated at 2022-06-23 10:07:33.472416
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    dumper = AnsibleDumper()
    encrypted_data = '$ANSIBLE_VAULT;1.1;AES256\n38393866626138653763376665353866336264613934353366336135383038396465326436373361\n373639393736383730616462633837376662306564353739643365300a3439336330306632316366\n65636662633638663866663034643331336137333432613431386334613863306662396332386136\n6637326332653062336364393634'
    secret = '12345'

# Generated at 2022-06-23 10:07:45.824945
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'bar'
    vault = do_vault(data, secret)


# Generated at 2022-06-23 10:07:46.890027
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()


# Generated at 2022-06-23 10:07:55.467967
# Unit test for function do_vault
def test_do_vault():
    salt = '$ANSIBLE_VAULT;1.1;AES256'
    secret = 'This is a secret'
    value = 'I am not a secret'
    vault = do_vault(value, secret, salt)
    assert is_encrypted(vault) is True, 'Encrypted string is not encrypted'
    assert isinstance(vault, string_types), 'Encrypted string is not of type str'
    assert len(vault) == 62, 'Encrypted string is not the right length'



# Generated at 2022-06-23 10:08:05.915741
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:07.294540
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert not isinstance(FilterModule, Undefined)
    assert not isinstance(FilterModule, dict)

# Generated at 2022-06-23 10:08:10.612830
# Unit test for function do_vault
def test_do_vault():

    # Arrange
    vault = do_vault('secret', 'password')

    # Assert
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-23 10:08:13.310724
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters
    assert "vault" in filters
    assert "unvault" in filters

# Generated at 2022-06-23 10:08:15.859824
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test = FilterModule()
    filters = test.filters()
    assert filters.get('vault') is not None
    assert filters.get('unvault') is not None

# Generated at 2022-06-23 10:08:21.238943
# Unit test for function do_vault
def test_do_vault():
    mysecret = 'mysecret'
    mydata = 'This is some vaulted data'
    vaulted = do_vault(mydata, mysecret)
    print('vaulted: %s' % vaulted)


# Generated at 2022-06-23 10:08:22.794130
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)

# Generated at 2022-06-23 10:08:34.590651
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:37.703721
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:08:45.116300
# Unit test for function do_unvault

# Generated at 2022-06-23 10:08:47.018920
# Unit test for constructor of class FilterModule
def test_FilterModule():
    tester = FilterModule()
    assert tester is not None

# Generated at 2022-06-23 10:09:00.138466
# Unit test for function do_unvault
def test_do_unvault():
    display.notify = False
    display.verbosity = False
    assert do_unvault('$ANSIBLE_VAULT;1.2;AES256;default3959321414397371520155579624558725907', 'test') == ''
    assert do_unvault('$ANSIBLE_VAULT;1.2;AES256;default3959321414397371520155579624558725907', '') == ''
    assert do_unvault('', '') == ''
    assert do_unvault('', 'test') == ''
    assert do_unvault('!vault |\n          $ANSIBLE_VAULT;1.2;AES256;default3959321414397371520155579624558725907\n          ', 'test') == ''
   

# Generated at 2022-06-23 10:09:09.706392
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.module_utils._text import to_text
    import pytest


# Generated at 2022-06-23 10:09:12.058151
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == None

# Generated at 2022-06-23 10:09:20.989363
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:31.574480
# Unit test for function do_vault
def test_do_vault():
    res = do_vault('foo', 'mysecret')

# Generated at 2022-06-23 10:09:33.691246
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:09:37.941674
# Unit test for function do_vault
def test_do_vault():
    secret = "This is a secret"
    salt = "This is the salt"
    data = "This is the data"
    expected_vault = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6466353130623734353666386537393036346164353561666664343765353336383038653166633539\n          3530663161658\n          "
    vault = do_vault(data, secret, salt, "filter_default")
    assert vault == expected_vault


# Generated at 2022-06-23 10:09:41.095005
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Test class FilterModule constructor '''
    fm = FilterModule()
    assert fm.filters() is not None, 'FilterModule.__init__() failed'

# Generated at 2022-06-23 10:09:53.540066
# Unit test for function do_unvault
def test_do_unvault():
    # Assert a vault file is encrypted
    assert is_encrypted("$ANSIBLE_VAULT;1.1;AES256;ansible\n373337303562333761653764363338643436396438626434633339333232653339313662363435\n65373061656331623731326536333933383536363236653433373966643330663462626433383930\n")

# Generated at 2022-06-23 10:09:59.383161
# Unit test for function do_vault
def test_do_vault():
    ''' Test do_vault function '''
    import pytest
    from jinja2.exceptions import UndefinedError
    Undefined = Undefined("Undefined")

    # Test good data
    assert do_vault("hello", "secret", vaultid="test1") == "$ANSIBLE_VAULT;1.1;AES256;test1\n613336356336613838323131616564363632653531616430373262653165323530333739656362366\ntest1\n"

# Generated at 2022-06-23 10:10:08.631283
# Unit test for function do_vault

# Generated at 2022-06-23 10:10:20.476819
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    import mock
    #Test for FilterModule.filters()
    ansible_module = mock.Mock()
    vault_id = 'filter_default'
    salt=b"1234567890123456"

    filter_module = FilterModule()
    filters = filter_module.filters()


# Generated at 2022-06-23 10:10:33.178090
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib, VaultSecret
 
    add_vault_id = 'add_default'
    add_vault_secret = 'aabbccdd'
    add_vault_secret_vs = VaultSecret(to_bytes(add_vault_secret))
    add_vault_lib = VaultLib([(add_vault_id, add_vault_secret_vs)])
    v_data = "test_data"
    enc_data = add_vault_lib.encrypt(to_bytes(v_data), add_vault_secret_vs, add_vault_id)
    print(enc_data) 
    dec_data = add_vault_lib.decrypt(enc_data)
    print(dec_data)

# Generated at 2022-06-23 10:10:39.247220
# Unit test for function do_unvault

# Generated at 2022-06-23 10:10:49.819450
# Unit test for function do_vault
def test_do_vault():
    from ansible.errors import AnsibleFilterTypeError
    from ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common import ansible_vault_filter

    # Test for string
    val = "foo"
    secret = "bar"
    filter = ansible_vault_filter.do_vault(val, secret)
    assert isinstance(filter, string_types)

    # Test for unicode
    val = u"foo"
    secret = "bar"
    filter = ansible_vault_filter.do_vault(val, secret)
    assert isinstance(filter, string_types)

    # Test for integer
    val = 5
    secret = "bar"

# Generated at 2022-06-23 10:10:54.456132
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('password', 'secret') == '$ANSIBLE_VAULT;1.1;AES256;ansible\n63336430373634346334636237616365346130346434626462663238333861353135323738\n356637626463396236613230643362313564336537626663336163313231320a316565613239\n30396234633764373239656436646362623338616665623132353832386162643964363230\n3736343533613034646262663238333861353135323738\n'

# Generated at 2022-06-23 10:10:57.580782
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test"
    vaultid = "test"
    data = "data"
    vault = do_vault(data, secret, salt=None, vaultid="test")
    test = do_unvault(vault, secret, vaultid="test")
    assert test == data

# Generated at 2022-06-23 10:11:02.305464
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()

    assert filter_module
    assert filter_module.filters
    assert filter_module.filters()
    assert filter_module.filters()['vault']
    assert filter_module.filters()['unvault']


# Generated at 2022-06-23 10:11:06.336627
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert dict == type(filter_module.filters())
    assert 'dict_items' == type(filter_module.filters().items()).__name__



# Generated at 2022-06-23 10:11:18.409430
# Unit test for method filters of class FilterModule

# Generated at 2022-06-23 10:11:22.782246
# Unit test for function do_unvault
def test_do_unvault():
    display.verbosity = 3
    filter_module = FilterModule()
    vault = filter_module.filters()['vault']
    unvault = filter_module.filters()['unvault']
    encrypted = vault('test_data', 'secret-password')
    assert unvault(encrypted, 'secret-password') == 'test_data', "Verify do_unvault would decrypt the data"

# Generated at 2022-06-23 10:11:35.631036
# Unit test for function do_unvault
def test_do_unvault():
    import pytest

    # Testing case: unvault a string

# Generated at 2022-06-23 10:11:51.631878
# Unit test for function do_vault
def test_do_vault():
    secret = 'vtest123'
    data = 'test1'
    salt = 'test2'
    vaultid = 'test_vaultid'
    wrap_object = True

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vaultid == vaultid

    # Test unvault with decrypted AnsibleVaultEncryptedUnicode
    assert do_unvault(vault, secret, vaultid) == data
    # Test unvault with encrypted string
    assert do_unvault(to_native(vault), secret, vaultid) == data
    # Test unvault with decrypted string
    assert do_unvault(data, secret, vaultid) == data
    # Test

# Generated at 2022-06-23 10:12:01.637084
# Unit test for function do_unvault
def test_do_unvault():
    # Test type errors
    try:
        do_unvault(object, b'password')
        assert False
    except AnsibleFilterTypeError:
        pass
    try:
        do_unvault(b'vault', object)
        assert False
    except AnsibleFilterTypeError:
        pass

    # Test undefined errors
    try:
        do_unvault(Undefined, b'password')
        assert False
    except UndefinedError:
        pass
    try:
        do_unvault(b'vault', Undefined)
        assert False
    except UndefinedError:
        pass

    # Test filter errors
    try:
        do_unvault(b"invalid vault", b"password")
        assert False
    except AnsibleFilterError:
        pass

# Generated at 2022-06-23 10:12:04.466793
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert len(fm.filters()) > 0


# Generated at 2022-06-23 10:12:09.711114
# Unit test for function do_unvault
def test_do_unvault():
    secret = b'123'
    vl = VaultLib()
    encrypted_data = vl.encrypt(b'12345678910', secret)
    data = do_unvault(encrypted_data, '123')
    print(data)

if __name__ == '__main__':
    test_do_unvault()

# Generated at 2022-06-23 10:12:11.907432
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filters = FilterModule()
    assert isinstance(filters.filters(), dict)
    assert 'vault' in filters.filters()


# Generated at 2022-06-23 10:12:19.441014
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert do_vault('foo', 'secret') == b'$ANSIBLE_VAULT;1.2;AES256;filter_default\n343065373135323936313034643766366437343833386639313763383231376637353439333963633d0a6363643038366266623862666365393438396334313433303263393936363565386565613237390a613766333233366334333933393164343563343332373266313833643566363465623762383538\n'
    # test_FilterModule_filters()

# Generated at 2022-06-23 10:12:20.804095
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f.filters() != None

# Generated at 2022-06-23 10:12:27.523464
# Unit test for function do_unvault

# Generated at 2022-06-23 10:12:37.997644
# Unit test for function do_vault
def test_do_vault():

    assert do_vault(None, None) == ''

    assert do_vault(None, None, wrap_object=True).data == 'None'


# Generated at 2022-06-23 10:12:46.682350
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;test_vault_id\n656232303031653262366562383163656438633937643236666163663362343637633861656430\n343937363637323030333637373839353736353433353466303738396430373031353437333464\n653262383035643932643336", 'test') == 'test'

# Generated at 2022-06-23 10:12:52.991228
# Unit test for function do_vault
def test_do_vault():
    try:
        assert do_vault("my secret data", "not_secret", wrap_object=True) == vault
    except AnsibleFilterError:
        pass
    else:
        assert False, "should have raised AnsibleFilterError!"

    try:
        assert do_vault("my secret data", 123, wrap_object=True) == vault
    except AnsibleFilterError:
        pass
    else:
        assert False, "should have raised AnsibleFilterError!"

    try:
        assert do_vault(123, "not_secret", wrap_object=True) == vault
    except AnsibleFilterError:
        pass
    else:
        assert False, "should have raised AnsibleFilterError!"


# Generated at 2022-06-23 10:13:05.442337
# Unit test for function do_unvault
def test_do_unvault():
    try:
        do_unvault("test", "")
    except AnsibleFilterError as e:
        display.display(str(e))
        assert False

    try:
        do_unvault("test", "", "")
    except AnsibleFilterError as e:
        display.display(str(e))
        assert False

    try:
        do_unvault("test", "", 1)
    except AnsibleFilterTypeError as e:
        display.display(str(e))
        assert False

    try:
        do_unvault("test", 1)
    except AnsibleFilterTypeError as e:
        display.display(str(e))
        assert False


# Generated at 2022-06-23 10:13:08.883337
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == { 'vault': do_vault, 'unvault': do_unvault }

# Generated at 2022-06-23 10:13:19.189136
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultSecret, VaultLib
    import ansible

    # Set up the class
    fixture = FilterModule()

    # Test everything
    assert fixture.filters() is not None

    result = fixture.filters()

    # Test vault
    # Test a string
    data = 'secret'
    secret = 'password'
    salt = None
    vaultid = 'filter_default'
    wrap_object = True
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)

    # Test a unicode
    data = u'secret'
    secret = u'password'

# Generated at 2022-06-23 10:13:20.450771
# Unit test for constructor of class FilterModule
def test_FilterModule():
    mod = FilterModule()
    fn = mod.filters()
    assert fn['vault'] is do_vault

# Generated at 2022-06-23 10:13:33.510883
# Unit test for function do_unvault
def test_do_unvault():
    # Givens
    # standard vault
    vault_standard = "$ANSIBLE_VAULT;1.1;AES256;default\n33383431396338393234306438343564343330623066663564663630643734396434653037383732\n39373565663764366263643433653536373431363535333966323637383132306233386338393433\n6631613435363935336631633166613065336236356234353765343039\n"

    # unvaulted vault
    vault_unvaulted = "secret"

    # AnsibleVaultEncryptedUnicode vault

# Generated at 2022-06-23 10:13:36.994234
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    test_obj = FilterModule()
    filters = test_obj.filters()

    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()

# Generated at 2022-06-23 10:13:38.731924
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    m = FilterModule()
    assert isinstance(m.filters(), dict)

# Generated at 2022-06-23 10:13:50.978183
# Unit test for function do_unvault

# Generated at 2022-06-23 10:13:57.548217
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters')
    assert callable(FilterModule.filters)
    assert isinstance(AnsibleVaultEncryptedUnicode, type)
    assert callable(VaultLib)
    assert callable(VaultSecret)


# Generated at 2022-06-23 10:14:00.817718
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:14:04.639845
# Unit test for function do_unvault
def test_do_unvault():
  test_vault = '$ANSIBLE_VAULT;1.1;AES256\n35343633666433376231396235616431326338306233396438376563656238306436393461356566\n6135346666386265373061366263393233316365356361306131653963353538396266623539\n'
  test_secret = 'password'
  result = do_unvault(test_vault, test_secret)
  assert result == 'test'

# Generated at 2022-06-23 10:14:15.189734
# Unit test for function do_unvault
def test_do_unvault():
    import six
    import base64
    import pytest
    if six.PY2:
        from StringIO import StringIO
    else:
        from io import StringIO
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.serialization import load_pem_private_key
    from cryptography.hazmat.primitives.asymmetric.padding import PKCS1v15
    from ansible.parsing.vault import VaultLib, VaultSecret

    # Encrypted string

# Generated at 2022-06-23 10:14:25.265346
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:27.868231
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f


# Generated at 2022-06-23 10:14:32.360951
# Unit test for function do_unvault
def test_do_unvault():
    filter_module = FilterModule()
    assert filter_module.filters()['unvault']('$ANSIBLE_VAULT;1.1;AES256;test_default\n39346538643333316230623830643031336131383363643736376466396265623731393363366163380a3430656538643865323134303163353166613562643631386233386136316231363036626364300a61326461356163313661313439343634343632323763306334656537353363656162326264633037\n', 'test') == 'hello world'


# Generated at 2022-06-23 10:14:36.452038
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    ret = fm.filters()
    assert ret == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:14:37.092520
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:14:41.047443
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    """
    Test the method filters()
    """

    ansible_filter = FilterModule()

    assert ansible_filter.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:14:42.939720
# Unit test for constructor of class FilterModule
def test_FilterModule():

    assert(True)

# Generated at 2022-06-23 10:14:47.656919
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    ftest = fm.filters().get('vault')
    assert ftest
    ftest = fm.filters().get('unvault')
    assert ftest


# Generated at 2022-06-23 10:14:49.958682
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(do_vault('ansible', 'ansible'),'ansible') == "ansible"

# Generated at 2022-06-23 10:14:54.013237
# Unit test for function do_vault
def test_do_vault():
    secret = 'foo'
    data = 'foobar'
    vault = do_vault(data, secret)
    data2 = do_unvault(vault, secret)
    assert data == data2


# Generated at 2022-06-23 10:14:57.068194
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    assert obj.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:15:08.104347
# Unit test for function do_vault
def test_do_vault():
    fm = FilterModule()
    do_vault_filter = fm.filters()['vault']

    # test when secret is not a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault_filter('Data to be vaulted', 1)

    # test when data is not a string
    with pytest.raises(AnsibleFilterTypeError):
        do_vault_filter(1, 'Secret')

    # test secret and data given as string

# Generated at 2022-06-23 10:15:10.316566
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_type = FilterModule()
    filter_dict = class_type.filters()
    assert "vault" in filter_dict
    assert "unvault" in filter_dict
    return



# Generated at 2022-06-23 10:15:17.019139
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()

    ansible_filter = filter_module.filters()

    assert ansible_filter["vault"] == do_vault
    assert ansible_filter["unvault"] == do_unvault



# Generated at 2022-06-23 10:15:18.574276
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:15:19.281943
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:15:22.540677
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()


# Generated at 2022-06-23 10:15:23.696845
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)

# Generated at 2022-06-23 10:15:24.606006
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None