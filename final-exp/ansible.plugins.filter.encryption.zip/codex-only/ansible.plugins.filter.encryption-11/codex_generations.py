

# Generated at 2022-06-23 10:05:23.863737
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()

# Generated at 2022-06-23 10:05:26.946662
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  filter_module = FilterModule()
  assert filter_module.filters() is not None

# Generated at 2022-06-23 10:05:37.662904
# Unit test for function do_vault

# Generated at 2022-06-23 10:05:43.433089
# Unit test for function do_vault
def test_do_vault():
    vault = do_vault('secret', 'password')
    assert(vault.startswith('$ANSIBLE_VAULT;'))
    assert(len(vault) > len('$ANSIBLE_VAULT;1.1;'))
    vault = do_vault('secret', 'password', 'salt')
    assert(vault.startswith('$ANSIBLE_VAULT;'))
    assert(len(vault) > len('$ANSIBLE_VAULT;1.1;'))


# Generated at 2022-06-23 10:05:44.330784
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:05:46.022482
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule is not None

# Generated at 2022-06-23 10:05:49.374141
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()

    assert type(filter_module) is FilterModule
    assert filter_module.filters() is not None
    assert type(filter_module.filters()) is dict



# Generated at 2022-06-23 10:05:55.996173
# Unit test for function do_vault
def test_do_vault():
    secret = 'I love cats'
    data = 'cats are cute'
    vault = do_vault(data, secret)

    assert vault == '$ANSIBLE_VAULT;1.2;AES256;filter_default\n63384f6b7b6d737055707133426c3236366670316d6f3373646746426e677a6a306d6b46\n58556f6c454e3968786b4370436f6d7c0a3d3d3d3d0a'


# Generated at 2022-06-23 10:06:04.621788
# Unit test for function do_vault
def test_do_vault():

    # Test 1 : Create a vault
    vault = do_vault("password", "secret", "salt", "vaultid")
    display.debug("Vault  = %s" % vault)
    assert vault.startswith("$ANSIBLE_VAULT")

    # Test 2 : Create a vault with no salt
    vault = do_vault("password", "secret", vaultid="vaultid")
    display.debug("Vault  = %s" % vault)
    assert vault.startswith("$ANSIBLE_VAULT")

    # Test 3 : Create a vault with no vaultid
    vault = do_vault("password", "secret", "salt")
    display.debug("Vault  = %s" % vault)
    assert vault.startswith("$ANSIBLE_VAULT")

    # Test 4 : Create a

# Generated at 2022-06-23 10:06:06.635322
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:06:08.478310
# Unit test for function do_unvault
def test_do_unvault():
    vault = do_vault('foo', 'bar')
    assert do_unvault(vault, 'bar') == 'foo'


# Generated at 2022-06-23 10:06:13.818519
# Unit test for function do_vault
def test_do_vault():
    # Unit test for function do_vault
    # Positive test
    encrypted_string = do_vault('string_to_encrypt', 'secret')
    assert isinstance(encrypted_string, str)
    assert isinstance(encrypted_string, AnsibleVaultEncryptedUnicode)
    assert encrypted_string is not 'string_to_encrypt'
    assert do_unvault(encrypted_string, 'secret') == 'string_to_encrypt'



# Generated at 2022-06-23 10:06:19.514269
# Unit test for function do_vault
def test_do_vault():
    do_vault_string = 'mypass'
    secret_string = 'mysecret'
    secret_string_bad = 'mysecret_bad'
    salt_string = 'mysalt'
    vaultid_string = 'filter_test'

    assert do_vault(do_vault_string, secret_string, salt=salt_string, vaultid=vaultid_string) != ''
    assert do_vault(do_vault_string, secret_string_bad, salt=salt_string, vaultid=vaultid_string) != ''

# Generated at 2022-06-23 10:06:21.980720
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule, type)
    fm = FilterModule()
    assert isinstance(fm, FilterModule)

# Generated at 2022-06-23 10:06:27.567444
# Unit test for function do_vault
def test_do_vault():
    secret = 'ansible'
    text = 'the quick brown fox jumped over the lazy dog'
    salt = 'salt'

    vault = do_vault(text, secret, salt)
    assert vault == '$ANSIBLE_VAULT;1.1;AES256'



# Generated at 2022-06-23 10:06:38.979442
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    def test_vault_data_secret_salt_vaultid_wrap_object():
        from jinja2.runtime import StrictUndefined
        from jinja2.exceptions import UndefinedError
        from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError

        filters = FilterModule().filters()
        data = b'abc'
        secret = b'password'
        salt = b'0123456789'
        vaultid = b'filter_default'
        data_info = filters['vault']
        if not isinstance(data, (string_types, binary_type, Undefined)):
            raise AnsibleFilterTypeError("Can only vault strings, instead we got: %s" % type(data))

# Generated at 2022-06-23 10:06:48.942320
# Unit test for function do_vault
def test_do_vault():
    data = "my_password"
    secret = "my_secret"
    assert do_vault(data, secret, salt=None, vaultid='my_vaultid') == b'$ANSIBLE_VAULT;1.1;AES256\n663279636662323762656235653536326535316335303835386530366630363231616565383630\n663963346465386163356237346430336537643838326265333764646638623333303931306264\n336166346465396537613037313832646665313333313163666332316330393037383738386138\n35333435346238623635323031383265386330393\n'


# Generated at 2022-06-23 10:06:59.823800
# Unit test for function do_unvault
def test_do_unvault():
    # Test with simple string
    assert do_unvault(do_vault('my_secret', 'my_secret'), 'my_secret') == 'my_secret'
    # Test with unicode string
    assert do_unvault(do_vault(u'\u20ac', 'my_secret'), 'my_secret') == u'\u20ac'
    # Test with encrypted unicode string
    assert do_unvault(do_vault(u'\u20ac', 'my_secret', wrap_object=True), 'my_secret') == u'\u20ac'
    # Test with AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 10:07:02.905736
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()

    assert filters['vault'] is do_vault
    assert filters['unvault'] is do_unvault


# Generated at 2022-06-23 10:07:05.328122
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert 'vault' in f.filters()
    assert 'unvault' in f.filters()


# Generated at 2022-06-23 10:07:12.227923
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('secret', 'vaultpassword')
    assert result == '$ANSIBLE_VAULT;1.1;AES256\n3734396538373630393130626263386661356265383338396534656363333133613862356339316365\n3839653566626164643631633932333337646531633333636262313233393237346665316232613464\n31366633656664343362316131663563636365306439386633\n'


# Generated at 2022-06-23 10:07:13.255825
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter = FilterModule()
    assert filter is not None


# Generated at 2022-06-23 10:07:21.205466
# Unit test for function do_vault

# Generated at 2022-06-23 10:07:25.996753
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters()['vault'] is do_vault
    assert fm.filters()['unvault'] is do_unvault


# unit tests for method do_vault of class FilterModule

# Generated at 2022-06-23 10:07:26.630008
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    obj.filters()

# Generated at 2022-06-23 10:07:30.588043
# Unit test for function do_vault
def test_do_vault():
    import os
    secret = 'foobar'
    salt = os.urandom(32)
    vault_data = do_vault('this is a test', secret, salt)
    data = do_unvault(vault_data, secret)
    assert data == 'this is a test'

# Generated at 2022-06-23 10:07:33.273367
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module_instance = FilterModule()
    filters = filter_module_instance.filters()
    assert callable(filters['vault'])
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:07:40.368202
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib as orig_VaultLib
    from ansible.parsing.vault import VaultSecret as orig_VaultSecret

    def new_VaultLib(self, secrets=[], password=None):
        return orig_VaultLib(self, secrets, password)

    def new_VaultSecret(self, password=None, _getpass=None, _stdin=None, confirm=True):
        return orig_VaultSecret(password, _getpass, _stdin, confirm)

    data = "Encryption test"
    secret = "ansible"
    vaultid = "filter_default"
    wrap_object = False
    salt = None
    vault = ""
    old_vault_lib = VaultLib
    old

# Generated at 2022-06-23 10:07:42.435711
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert isinstance(fm.filters(), dict)


# Generated at 2022-06-23 10:07:47.224238
# Unit test for function do_vault
def test_do_vault():
    import json

    # valid value
    vault = do_vault("my_secret", "my_password")
    assert json.loads(vault)

    # invalid value
    failure = False
    try:
        do_vault({"invalid": "value"}, "my_password")
    except AnsibleFilterTypeError as e:
        failure = True
    assert failure

    # invalid secret
    failure = False
    try:
        do_vault("my_secret", {"invalid": "value"})
    except AnsibleFilterTypeError as e:
        failure = True
    assert failure


# Generated at 2022-06-23 10:07:49.147366
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert filter_module.filters() is not None


# Generated at 2022-06-23 10:07:51.069356
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f.filters(), dict)

# Generated at 2022-06-23 10:07:55.840136
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert filters is not None
    assert len(filters.keys()) == 2
    assert 'vault' in filters.keys()
    assert 'unvault' in filters.keys()

# Generated at 2022-06-23 10:07:58.572242
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(FilterModule)
    assert 'unvault' in FilterModule.filters(FilterModule)



# Generated at 2022-06-23 10:08:00.340997
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ans_filter = FilterModule()
    assert ans_filter is not None

# Generated at 2022-06-23 10:08:01.226321
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:08:04.161541
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()

    assert callable(filters['vault'])
    assert callable(filters['unvault'])

# Generated at 2022-06-23 10:08:07.024398
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters.get('vault') == do_vault
    assert filters.get('unvault') == do_unvault

# Generated at 2022-06-23 10:08:15.715848
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:20.372917
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()

    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-23 10:08:21.812375
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() is not None


# Generated at 2022-06-23 10:08:30.536246
# Unit test for function do_vault

# Generated at 2022-06-23 10:08:37.049481
# Unit test for function do_unvault
def test_do_unvault():

    import pytest

    def test_values():
        assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;admin", "admin") == "admin"

    def test_values_assertion():
        assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;admin", "admin") == "admin2" # assert fails

    def test_type_mismatch():
        with pytest.raises(AnsibleFilterTypeError):
            do_unvault(123, "admin")

    def test_secret_type_mismatch():
        with pytest.raises(AnsibleFilterTypeError):
            do_unvault("$ANSIBLE_VAULT;1.1;AES256;admin", 123)


# Generated at 2022-06-23 10:08:47.166751
# Unit test for function do_unvault
def test_do_unvault():
    result = do_unvault('$ANSIBLE_VAULT;1.1;AES256;michael\n63336361366230646463613265366431363364653263376436393963643335386561663138393330\n65386438346131646139363563303764333939323062613637366238663332376233326738373065\n65333734356337313735313933396534353836353466316639663365306636343738306361333662\n356538','michael')
    assert result

# Generated at 2022-06-23 10:09:00.248977
# Unit test for function do_unvault
def test_do_unvault():
    if __name__ != '__main__':
        return

    # Set up the plugin name, so we can get the passphrase
    display.plugin_name = 'filter'

    vault_ids = ['filter_default']
    # Test with both strings and AnsibleVaultEncryptedUnicode objects
    test_vault_data = {
        'foo': '$ANSIBLE_VAULT;1.1;AES256;filter_default;',
        'bar': AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;1.1;AES256;filter_default;'),
    }
    secret = 'filter_default_passphrase'

# Generated at 2022-06-23 10:09:09.777134
# Unit test for function do_vault

# Generated at 2022-06-23 10:09:14.560429
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)
    unvault_data = do_unvault(vault, secret)
    assert data == unvault_data


# Generated at 2022-06-23 10:09:20.927520
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ansible_vault_secret = "This is the secret.  It should not end up in the output"
    ansible_vault_data = "This is the data.  It should end up in the output"
    test_vault_data = FilterModule()
    assert test_vault_data is not None

# Generated at 2022-06-23 10:09:22.218826
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:09:34.208021
# Unit test for function do_unvault

# Generated at 2022-06-23 10:09:37.860689
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    assert module.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:09:40.576296
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() == {'vault': do_vault, 'unvault': do_unvault}


# Generated at 2022-06-23 10:09:44.120921
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f_m = FilterModule()
    filters = f_m.filters()
    assert filters is not None
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:09:55.083160
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():

    filter_module = FilterModule()
    filters = filter_module.filters()

    # test function do_vault()
    some_data = 'somedata'
    secret = 'cGFzc3dvcmQ='
    salt = 'K3J1Y2VzY2FyZQ=='
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-23 10:09:58.094698
# Unit test for function do_unvault
def test_do_unvault():
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible_test'
    hh = "c2VjcmV0Cg==\n"
    secret = "secret"

    res = do_unvault(vault, secret, 'ansible_test')
    assert res == "secret", "%s != %s" % (res, secret)

# Generated at 2022-06-23 10:10:04.282525
# Unit test for function do_vault
def test_do_vault():

    import os
    import sys
    import pytest

    from ansible.module_utils.common.removed import removed
    from ansible.module_utils.common.jinja import AnsibleJ2
    from ansible.parsing.dataloader import DataLoader

    display.verbosity = 1

    #setup filters
    j2_env = AnsibleJ2.get_default_j2_env()
    j2_env.filters.update({'vault': do_vault})
    f = j2_env.filters['vault']

    #setup dataloader
    local_data_loader = DataLoader()

    # basic encryption


# Generated at 2022-06-23 10:10:10.672991
# Unit test for function do_vault
def test_do_vault():
    # test that string is encrypted with default vault_id
    secret = "this is the password"
    data = "this is the data"
    vault = do_vault(data, secret)
    assert vault != data

    # test that data encrypted with salt is different
    salt = "this is the salt"
    vault = do_vault(data, secret, salt=salt)
    assert vault != data

    # test that wrong secret throws an error
    secret = "this is the wrong secret"
    try:
        do_vault(data, secret, salt=salt)
        assert False
    except AnsibleFilterError as e:
        assert "encrypt" in to_native(e)

    # test that data encrypted with salt and vault_id is different
    vault_id = "this is the vault_id"
    vault = do

# Generated at 2022-06-23 10:10:21.287757
# Unit test for function do_vault

# Generated at 2022-06-23 10:10:25.114716
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    ret = FilterModule().filters()
    assert type(ret) is dict
    assert len(ret) == 2

# Generated at 2022-06-23 10:10:29.507598
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.2;AES256;awesome\r\nblahblah\r\n', 'awesome') == 'blahblah\n'

# Generated at 2022-06-23 10:10:36.835462
# Unit test for function do_vault
def test_do_vault():
    """
    Test
    """
    assert do_vault("hello", "mypassword", "mypassword", "mypassword") == "!vault |\n          $ANSIBLE_VAULT;1.2;AES256;mypassword\n          643133323561313437336333633438653565646639396137666534313535336564333130383432\n          63396366613739346665616662326537386639633038316134653365358a\n          "

# Generated at 2022-06-23 10:10:48.850342
# Unit test for function do_vault
def test_do_vault():
    # do_vault input args
    data = 'password'
    secret = 'secret'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False

    # Expected vault object

# Generated at 2022-06-23 10:10:57.580345
# Unit test for function do_vault
def test_do_vault():
    assert do_vault("data", "secret") == '$ANSIBLE_VAULT;1.1;AES256\n646231376265633239633033393462356334613162626666373732316661366365613662323434\n303663633164653166623437633661663538396565336438353136663138396631623534643436\n393138386438346333646634363933656233666133386466383936636661613936393835653065\n663065343331323632626165643135343831376530356130636435366261353031653465393830\n32666435666262343363646131303266363433\n'
   

# Generated at 2022-06-23 10:10:59.939866
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters() is not None


# Generated at 2022-06-23 10:11:11.963248
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:14.861201
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert(f.filters() == {'vault': do_vault, 'unvault': do_unvault})

# Generated at 2022-06-23 10:11:23.586557
# Unit test for function do_unvault
def test_do_unvault():
    # Do nothing if empty string
    assert do_unvault('') == ''
    # Do nothing if non-encrypted string
    assert do_unvault('test') == 'test'

    # Do decrypt if encrypted string

# Generated at 2022-06-23 10:11:24.581625
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()


# Generated at 2022-06-23 10:11:37.191218
# Unit test for function do_vault
def test_do_vault():
    unit_test_key = "f8bc9d7e5db5de5c7117fcb5f7988d51"
    unit_test_data = "This is so secret"
    unit_test_vault = b'$ANSIBLE_VAULT;1.1;AES256\n31333235636265336361633866306331306131623133303438346231643862366331386137613361\n64393963316234653864333934643835353263316665643935333365666561356163623539643236\n36303666346462653433636638663863643135393434316331323433\n'
    unit_test_salt = "8f6e56c6b1d6ddab"
   

# Generated at 2022-06-23 10:11:41.913276
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert isinstance(FilterModule(), object)


# Generated at 2022-06-23 10:11:52.677642
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:54.734950
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert isinstance(f.filters, collections.Callable)


# Generated at 2022-06-23 10:11:58.985088
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'Hello world!'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-23 10:12:11.975111
# Unit test for function do_vault

# Generated at 2022-06-23 10:12:16.839417
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:12:19.821443
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:12:27.282316
# Unit test for function do_unvault
def test_do_unvault():
    secret_key = 'asdfghjklzxcvbnm1234'

# Generated at 2022-06-23 10:12:37.061006
# Unit test for function do_unvault
def test_do_unvault():
    # plain string
    assert do_unvault('test', 'secret') == 'test'
    # encrypted string
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;test\n343034323532343035656538646634303733303761303263656564306333646437623331643431\n393538646634336366376339366466363431613065306435396533376232396435313065396630\n626664376134653636663739346562616239326237376236656230303861396362623665\n', 'secret') == 'test'

# Generated at 2022-06-23 10:12:41.933625
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    filters = f.filters()
    assert type(filters) is dict
    assert len(filters) == 2
    assert type(filters['vault']) is type(do_vault)
    assert type(filters['unvault']) is type(do_unvault)



# Generated at 2022-06-23 10:12:50.586491
# Unit test for function do_vault
def test_do_vault():
    # No exception expected
    assert is_encrypted(do_vault('secret_first', 'password'))
    # No exception expected
    assert is_encrypted(do_vault('secret_second', 'password'))
    # No exception expected

# Generated at 2022-06-23 10:12:56.129351
# Unit test for function do_unvault
def test_do_unvault():

    ''' test for various cases of unvault '''
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib, VaultSecret
    secret = 'Ansible'
    vaultid = 'A'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    data = 'ansible'
    vault = vl.encrypt(to_bytes(data), vs, vaultid)
    assert do_unvault(vault,'ansible') == 'ansible'

# Generated at 2022-06-23 10:12:59.536977
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'unvault' in FilterModule.filters(FilterModule)
    assert 'vault' in FilterModule.filters(FilterModule)


# Generated at 2022-06-23 10:13:02.305378
# Unit test for constructor of class FilterModule
def test_FilterModule():
    vault = do_vault("test", "test", "test", wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode) is True

# Generated at 2022-06-23 10:13:15.743897
# Unit test for function do_unvault
def test_do_unvault():
    # expected output from queries in vault
    expected_return1 = '123456'
    expected_return2 = 'abcdef'
    # data from vault
    test_secrets_data = {
        "vault_id": "test_id",
        "vault_method": "aes256",
        "vault_version": 1,
        "vault": {
            "filter_default": {
                "salt": "salt value",
                "hmac": "hmac value",
                "iterations": 123456789,
                "ciphertext": "ciphertext value",
                "keys": {
                    "key1": "key1 value",
                    "key2": "key2 value"
                }
            }
        }
    }
    # get filter class object
    vault_filter = FilterModule()

# Generated at 2022-06-23 10:13:20.475497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    # These are just some basic tests, more filters exist
    assert fm.filters().has_key('vault')
    assert fm.filters().has_key('unvault')
    assert fm.filters()['vault'] is do_vault
    assert fm.filters()['unvault'] is do_unvault


# Generated at 2022-06-23 10:13:22.103344
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert obj != None

# Generated at 2022-06-23 10:13:34.455223
# Unit test for function do_vault
def test_do_vault():

    # Test case 1: do vault of sensitive data with normalized secret
    secret = "test_secret"
    data = "test_data"
    salt = "test_salt"

    vault = do_vault(data, secret, salt)
    assert is_encrypted(vault) == True
    assert do_unvault(vault, secret) == data

    # Test case 2: do vault of sensitive data with secret in unicode
    secret = u"test_secret"
    data = "test_data"
    salt = "test_salt"

    vault = do_vault(data, secret, salt)
    assert is_encrypted(vault) == True
    assert do_unvault(vault, secret) == data

    # Test case 3: do vault of sensitive data with secret in AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 10:13:36.598990
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    assert hasattr(obj, 'filters')


# Generated at 2022-06-23 10:13:40.215114
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters

# Unit tests for function do_vault

# Generated at 2022-06-23 10:13:42.276893
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm.filters is not None


# Generated at 2022-06-23 10:13:45.971571
# Unit test for constructor of class FilterModule
def test_FilterModule():
    try:
        f = FilterModule()
    except Exception as err:
        assert False, "Failed to instantiate FilterModule class: " + to_native(err)
    else:
        assert True



# Generated at 2022-06-23 10:13:47.188613
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule().filters()
    return

# Generated at 2022-06-23 10:13:47.751151
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:13:57.057244
# Unit test for function do_vault
def test_do_vault():
    from jinja2.exceptions import UndefinedError
    from ansible.module_utils.six import string_types, binary_type
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import is_encrypted

    secret = "123456"
    data = "thisisjustatest"


# Generated at 2022-06-23 10:13:57.785619
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:14:08.602519
# Unit test for function do_unvault
def test_do_unvault():
    ansible_vault_string_1 = AnsibleVaultEncryptedUnicode(b'dummy encrypted string')
    ansible_vault_string_2 = AnsibleVaultEncryptedUnicode(b'dummy encrypted string')

    ansible_vault_string_1.vault = VaultLib([('filter_default', VaultSecret('dummy secret'))])
    ansible_vault_string_2.vault = VaultLib([('filter_default', VaultSecret('dummy secret'))])

    assert ansible_vault_string_1 == ansible_vault_string_2
    assert ansible_vault_string_1._secret().secret == ansible_vault_string_2._secret().secret
    assert ansible_vault_string_1._secret(vaultid='filter_default') == ansible_v

# Generated at 2022-06-23 10:14:10.291894
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:14:21.889232
# Unit test for function do_unvault

# Generated at 2022-06-23 10:14:22.431555
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert True

# Generated at 2022-06-23 10:14:29.574795
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.vault import VaultSecret

    secret = 'foo'
    salt = 'bar'
    vaultid = 'filter_default'
    wrap_object = False

    # Result should be encrypted with secret and salt
    fact = do_vault('foo', secret, salt, vaultid, wrap_object)
    assert isinstance(fact, string_types)
    assert not fact.startswith('$ANSIBLE_VAULT;')
    fact = do_unvault(fact, secret, vaultid)
    assert fact == 'foo'

    # Result should be given vault_secret object, secret and salt
    fact = do_vault('foo', VaultSecret(secret), salt, vaultid, wrap_object)

# Generated at 2022-06-23 10:14:30.609599
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert FilterModule().filters() != None


# Generated at 2022-06-23 10:14:42.274742
# Unit test for function do_unvault
def test_do_unvault():
    def test_filter(vault, secret, expected_data, vaultid='filter_default', contains=False):
        data = do_unvault(vault, secret, vaultid)
        if contains:
            assert expected_data in data
        else:
            assert data == expected_data

    test_filter('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3431613361366562313561643466356661633765623861343563646636313462363238636130386465\n          6333386466653438643761663533666631\n          3266383938366361323435646130343036323732382e0a',
                'secret',
                'Oh hai mark!\n')

    test

# Generated at 2022-06-23 10:14:51.122468
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.module_utils._text import to_bytes

    secret = VaultSecret(b'foo')
    data = "foobar"
    vault = do_vault(data, secret, wrap_object=False)
    assert is_encrypted(to_bytes(vault)) == True

    vault = do_vault(data, secret, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)



# Generated at 2022-06-23 10:14:51.699679
# Unit test for constructor of class FilterModule
def test_FilterModule():
	assert True

# Generated at 2022-06-23 10:14:56.828650
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Test that defaults are set
    fm = FilterModule()
    assert fm is not None

    fm_filters = fm.filters()
    assert fm_filters is not None
    assert len(fm_filters) == 2
    assert 'vault' in fm_filters
    assert 'unvault' in fm_filters
    assert isinstance(fm_filters['vault'], types.FunctionType)
    assert isinstance(fm_filters['unvault'], types.FunctionType)

# Generated at 2022-06-23 10:15:00.021298
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    assert type(f.filters()) == dict

# Generated at 2022-06-23 10:15:03.587365
# Unit test for function do_unvault
def test_do_unvault():
    vault_key = "vault 123456"
    data = "hello， world"
    value = do_vault(data, vault_key)
    assert do_unvault(value, vault_key) == data

# Generated at 2022-06-23 10:15:05.045966
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:15:08.217406
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    filters = filter_module.filters()
    assert filters is not None, "Failed to get filters!"
    assert 'vault' in filters, "Failed to get vault filter!"
    assert 'unvault' in filters, "Failed to get unvault filter!"

# Generated at 2022-06-23 10:15:14.247930
# Unit test for function do_vault
def test_do_vault():
    """ Unit test for the do_vault filter """

    assert do_vault('my_password', 'my_secret', 'my_salt') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault('This is a test', 'my_secret_key', 'my_salt') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault('12345', 'my_secret_key', 'my_salt') == '$ANSIBLE_VAULT;1.1;AES256'
    assert do_vault('', 'my_secret_key', 'my_salt') == '$ANSIBLE_VAULT;1.1;AES256'



# Generated at 2022-06-23 10:15:22.910568
# Unit test for function do_vault