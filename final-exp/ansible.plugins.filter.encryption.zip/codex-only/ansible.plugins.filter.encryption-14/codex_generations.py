

# Generated at 2022-06-23 10:05:33.961608
# Unit test for function do_vault
def test_do_vault():
    import collections

    # Test strings
    test_string_0 = 'some string'
    test_string_1 = 'some string'

    # Test secrets
    test_secret_0 = 'bad secret'
    test_secret_1 = 'good secret'

    # No vault id
    data = do_vault(test_string_0, test_secret_0)
    assert not isinstance(data, collections.Sequence)

    # Verify encryption
    data = do_vault(test_string_0, test_secret_0)
    assert is_encrypted(data)

    # Verify decryption
    data = do_vault(test_string_0, test_secret_0)
    assert not is_encrypted(do_unvault(data, test_secret_0))

    # Verify decryption with bad secret

# Generated at 2022-06-23 10:05:44.353164
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 10:05:49.956609
# Unit test for function do_vault

# Generated at 2022-06-23 10:05:51.284997
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    vs = VaultSecret('vault')
    data = do_vault('some_data', vs.secret)
    assert 'some_data' == do_unvault(data, vs.secret)


# Generated at 2022-06-23 10:05:57.903105
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('o', 'b') == '$ANSIBLE_VAULT;1.1;AES256\n3037633336346663643136623532653163376161643131316132363435323261303561633631343466\n3266613131383834313138343330666631643630613236656630623633383538336138343537666539\n61333336603465356231\n'


# Generated at 2022-06-23 10:06:00.581078
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert callable(fm.filters)
    assert 'unvault' in fm.filters()
    assert 'vault' in fm.filters()



# Generated at 2022-06-23 10:06:08.763928
# Unit test for function do_unvault

# Generated at 2022-06-23 10:06:10.387576
# Unit test for constructor of class FilterModule
def test_FilterModule():
    __filtermodule = FilterModule()
    assert __filtermodule

# Validate that vault filter is available

# Generated at 2022-06-23 10:06:15.662894
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes

    vid = 'test_id'
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vid, vs)])
    vd = vl.encrypt(to_bytes(data), vs, vid, salt)

    assert do_unvault(vd, secret, vid) == data


# Generated at 2022-06-23 10:06:18.210124
# Unit test for constructor of class FilterModule
def test_FilterModule():
    module = FilterModule()
    assert module.filters()['vault'] is do_vault
    assert module.filters()['unvault'] is do_unvault

# Unit tests for method do_vault

# Generated at 2022-06-23 10:06:18.604097
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule

# Generated at 2022-06-23 10:06:21.199252
# Unit test for function do_vault
def test_do_vault():
    data = 'foo'
    secret = 'bar'
    salt = 'baz'
    vaultid = 'filter_default'
    wrap_object = False
    assert do_vault(data, secret, salt, vaultid, wrap_object) == '!vault |'


# Generated at 2022-06-23 10:06:32.356797
# Unit test for function do_vault
def test_do_vault():
    assert type(do_vault('test', 'secret', vaultid='test_vault_filter')) == str
    assert do_vault('test', 'secret') != 'test'
    assert do_vault('test', 'secret') == do_vault('test', 'secret')
    assert do_vault('test', 'secret', salt='salt') != do_vault('test', 'secret')
    assert isinstance(do_vault('test', 'secret', wrap_object=True), AnsibleVaultEncryptedUnicode)

    try:
        do_vault(123, 'secret', vaultid='test_vault_filter')
        raise
    except AnsibleFilterTypeError:
        pass


# Generated at 2022-06-23 10:06:41.889111
# Unit test for function do_vault

# Generated at 2022-06-23 10:06:46.681808
# Unit test for function do_unvault
def test_do_unvault():
    """
    do_unvault() is testing for AnsibleVaultEncryptedUnicode and is_encryted
    """

    import sys
    from unittest import TestCase

    def mock_is_encrypted(value):
        # this function is mocked to avoid calling the actual function
        # it just checks if value is an instance of AnsibleVaultEncryptedUnicode
        return isinstance(value, AnsibleVaultEncryptedUnicode)

    class FilterTestCases(TestCase):

        @classmethod
        def setUpClass(cls):
            cls.filt = FilterModule()

        def setUp(self):
            # this function is mocked to avoid calling the actual function
            # it just checks if vault is an instance of AnsibleVaultEncryptedUnicode
            self.old_is_encrypted = sys.modules

# Generated at 2022-06-23 10:06:57.967775
# Unit test for function do_vault
def test_do_vault():
    data = '''
    ---
    some_key: This is 1234
    '''
    secret = 'secret'
    vault = b'$ANSIBLE_VAULT;1.1;AES256\n31386530323165623332343865653161623734373639333435336164316636363035323234343334\n63633533373534303566323230373436373464626133626331366135636631373334396530656635\n6533666433663266646662366232643362626161323961\n'
    ans = do_vault(data, secret, wrap_object=False)
    assert ans == vault.decode('utf-8')


# Generated at 2022-06-23 10:07:01.343828
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    filters = module.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault

# Generated at 2022-06-23 10:07:02.404525
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    assert f is not None

# Generated at 2022-06-23 10:07:07.174678
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'testsecret'
    # unvault non-encrypted data
    data = 'non-encrypted data'
    assert do_unvault(data, secret) == data
    # unvault with vault key
    data = '!vault |'
    assert do_unvault(data, secret) == data



# Generated at 2022-06-23 10:07:14.853337
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import _data_decrypt
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_id = 'test_default'

# Generated at 2022-06-23 10:07:21.624196
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'password'
    salt = None
    vaultid = 'filter_default'
    wrap_object = False
    # Assert function do_vault
    assert '$ANSIBLE_VAULT;1.1;AES256' in do_vault(data, secret, salt, vaultid, wrap_object)


# Generated at 2022-06-23 10:07:33.764290
# Unit test for function do_unvault

# Generated at 2022-06-23 10:07:37.266655
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:07:41.061267
# Unit test for constructor of class FilterModule
def test_FilterModule():
    ''' Unit test for FilterModule constructor '''
    filterModule = FilterModule()
    filterModule.filters()


# Generated at 2022-06-23 10:07:48.506451
# Unit test for function do_unvault
def test_do_unvault():
    def test(data, expected, secret, vaultid):
        # Test method
        assert do_unvault(data, secret, vaultid) == expected

    # Test cases
    test(None, None, None, None)
    test(1, 1, None, None)
    test("", "", "", "")
    test("encrypted ", "secret", "secret", "")
    test("encrypted ", "secret", "secret", "default")
    test("encrypted ", "secret", "secret", "default_vaultid")
    test("encrypted ", "secret", "secret", "default_vaultid_1")
    test("encrypted ", "secre", "secre", "default_vaultid")

# Generated at 2022-06-23 10:08:01.173594
# Unit test for function do_unvault
def test_do_unvault():

    from ansible.compat.tests.mock import patch
    from io import StringIO
    from ansible.parsing.vault import VaultSecret

    patched_input = patch('ansible.parsing.vault.getpass.getpass', return_value='secret')
    patched_output = patch('sys.stderr', new_callable=StringIO)

    with patched_input as patched_input_mock, patched_output as patched_output_mock:
        do_vault('example', secret='secret')

    assert patched_input_mock.call_args_list[0][0][0] == 'Vault password (filter_default): '

    vs = VaultSecret(to_bytes('secret'))
    vl = VaultLib()

# Generated at 2022-06-23 10:08:10.572105
# Unit test for function do_vault
def test_do_vault():
    data = b'hello'
    assert do_vault(data, b'secret') == b'$ANSIBLE_VAULT;1.1;AES256\n63613234336534396538373838636131383437333566633133643536386632393135646538336461\n39356533313034636333616861383136313933386638393466363733666536326436396462623162\n38303330613235656231376137653539396637626438396565303638653966353330343166663433\n303836626362386565386233309d'
    #do_vault requires data to be a string not an int

# Generated at 2022-06-23 10:08:14.512299
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    filters = fm.filters()
    assert filters == {
        'vault': do_vault,
        'unvault': do_unvault,
    }



# Generated at 2022-06-23 10:08:17.785428
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filt = FilterModule()
    assert filt.filters() == {'vault': do_vault, 'unvault': do_unvault}

# Generated at 2022-06-23 10:08:22.081788
# Unit test for function do_vault
def test_do_vault():
    """ Unit test for function do_vault """


# Generated at 2022-06-23 10:08:24.412561
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
  assert FilterModule().filters()['vault'] == do_vault
  assert FilterModule().filters()['unvault'] == do_unvault


# Generated at 2022-06-23 10:08:26.250208
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert callable(FilterModule)

# Generated at 2022-06-23 10:08:32.419830
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    vaultid = "test_vault"
    wrap_object = True
    salt = None
    try:
        result = do_vault(data, secret, salt, vaultid, wrap_object)
    except Exception as e:
        print("Unable to unit test do_vault() function: %s" % e)
        raise

    return result



# Generated at 2022-06-23 10:08:33.384651
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert fm

# Generated at 2022-06-23 10:08:34.873605
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule()

# Generated at 2022-06-23 10:08:36.767197
# Unit test for constructor of class FilterModule
def test_FilterModule():
    test_class = FilterModule()

    assert(test_class.filters() is not None)


# Generated at 2022-06-23 10:08:41.238410
# Unit test for function do_vault
def test_do_vault():
    data = 'This is a secret message to encrypt'
    secret = 'mysecret'
    result = do_vault(data, secret, salt=None, vaultid='filter_default')
    assert data != result


# Generated at 2022-06-23 10:08:51.457053
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 10:08:59.449411
# Unit test for function do_vault
def test_do_vault():
    from jinja2.runtime import Undefined
    assert do_vault('foo', 'secret')
    assert do_vault(Undefined(''), 'secret') == ''
    assert do_vault('foo', Undefined('')) == ''
    assert do_vault(Undefined(''), Undefined('')) == ''

# Generated at 2022-06-23 10:09:02.749042
# Unit test for constructor of class FilterModule
def test_FilterModule():
    members = [attr for attr in dir(FilterModule) if not callable(attr) and not attr.startswith("__")]
    assert len(members) == 1
    assert members.pop() == "filters"

    f = FilterModule()
    assert hasattr(f, "filters" )


# Generated at 2022-06-23 10:09:11.369761
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import is_encrypted, VaultSecret, VaultLib
    # 1.test unvault fail
    # 1.1.test vault is invalid
    try:
        do_unvault('test', 'test', 'test')
    except Exception as e:
        assert str(e) == 'Vault should be in the form of a string, instead we got: <class \'str\'>'
    # 1.2.test secret is invalid
    try:
        do_unvault('$ANSIBLE_VAULT;1.1;AES256', ['1', '2'], 'test')
    except Exception as e:
        assert str(e) == 'Secret passed is required to be as string, instead we got: <class \'list\'>'

    # 2.test unvault success
    # 2.

# Generated at 2022-06-23 10:09:13.075584
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert hasattr(FilterModule, 'filters'), "Invalid FilterModule"

# Generated at 2022-06-23 10:09:17.580335
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'

    result = do_vault(data, secret)
    assert result



# Generated at 2022-06-23 10:09:19.463144
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None

# Generated at 2022-06-23 10:09:29.796176
# Unit test for function do_vault
def test_do_vault():
    # Test function do_vault
    import unittest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_text

    class Testcase(unittest.TestCase):
        def test_do_vault(self):
            # Test for do_vault

            import jinja2
            from ansible.parsing.vault import VaultSecret

            data = 'test content'
            secret = 'secret'

            vs = VaultSecret('secret')
            vl = VaultLib()
            vaulted = vl.encrypt(to_text(data), vs, wrap_object=True)
            self.assertTrue(vaulted.vault is not None)

# Generated at 2022-06-23 10:09:41.958030
# Unit test for function do_unvault
def test_do_unvault():
    import re
    import pytest
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultUpdater
    from ansible.parsing.vault import VaultEditor

    # Encrypt test string
    vs = VaultSecret('ansible-vault-orig')
    vl = VaultLib([('test', vs)])
    teststring = "this is a test string\n"

# Generated at 2022-06-23 10:09:54.194269
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'

# Generated at 2022-06-23 10:09:55.985227
# Unit test for function do_vault
def test_do_vault():
    import unittest
    result = do_vault('TEST_STRING', 'password')
    assert result != 'TEST_STRING', "vault filter should encrypt the data"


# Generated at 2022-06-23 10:09:57.490826
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:09:59.040797
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    expected = {'vault': do_vault, 'unvault': do_unvault}
    actual = FilterModule().filters()
    assert expected == actual


# Generated at 2022-06-23 10:10:00.235254
# Unit test for function do_unvault
def test_do_unvault():
    result_unvault = do_unvault(vault1, 'foo')
    assert result_unvault == 'bar'

# Generated at 2022-06-23 10:10:08.943558
# Unit test for function do_vault
def test_do_vault():
    # Create dict to store test data
    test_dict = {}

    # Create string to be used for encryption
    test_dict['string_to_encrypt'] = 'This text will be encrypted'

    # Create secret string to be used for encryption
    test_dict['secret'] = 'thisshouldbeaverysecretstring'

    # Create salt string to be used for encryption
    test_dict['salt'] = 'thisshouldbeaverysaltedstring'

    # Create vaultid string to be used for encryption
    test_dict['vaultid'] = 'testid'

    # Create object to store encrypted data

# Generated at 2022-06-23 10:10:12.142232
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filters = FilterModule().filters()
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:10:20.665579
# Unit test for function do_vault
def test_do_vault():
    result = do_vault('password', 'secret', 'salt')
    assert result == '$ANSIBLE_VAULT;1.2;AES256;salt\n3630633130653666653463396239323633373265363433316163356664653539653536616463610a36623036643731316464383634646537306438633232636365396435336236636432666431320a33373863373136353164323566623463303037363364316431393166383162373134663634\n'



# Generated at 2022-06-23 10:10:24.955124
# Unit test for function do_vault
def test_do_vault():
    import os
    # Create a secret file
    fd, path = tempfile.mkstemp()
    os.write(fd, "mysecret")
    os.close(fd)
    # Run tests

# Generated at 2022-06-23 10:10:27.901268
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert 'vault' in fm.filters()
    assert 'unvault' in fm.filters()


# Generated at 2022-06-23 10:10:31.520497
# Unit test for constructor of class FilterModule
def test_FilterModule():
    key = 'secret'
    salt = 'salt'
    vaultid = 'answer_to_life_the_universe_and_everything'
    wrap_object = False
    fm = FilterModule()
    assert fm is not None


# Generated at 2022-06-23 10:10:40.866840
# Unit test for function do_unvault
def test_do_unvault():
    print("test_do_unvault")
    # do_unvault filter needs to be initialized with a vault secret
    secret = "test"
    encrypted = "!vault |"
    vault = VaultSecret(secret)
    vl = VaultLib([("test", vault)])
    print("do_unvault with encrypted data")
    # Does not throw any exceptions
    unvault = do_unvault(encrypted, secret, "test")
    if unvault != encrypted:
        raise Exception("unvault failed")
    print("do_unvault with encrypted data of type bytes")
    unvault = do_unvault(encrypted.encode(), secret, "test")
    if unvault != encrypted:
        raise Exception("unvault failed")

# Generated at 2022-06-23 10:10:44.708681
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    assert fm.filters() == {
        'vault': do_vault,
        'unvault': do_unvault,
    }


# Generated at 2022-06-23 10:10:51.893313
# Unit test for function do_vault
def test_do_vault():
    secret_value = "SECRET"
    vault_value = "vault"
    salt_value = "salt"
    filtered_vault = do_vault(vault_value, secret_value, salt_value)
    assert vault_value not in filtered_vault
    assert secret_value not in filtered_vault
    assert salt_value not in filtered_vault
    filtered_data = do_unvault(filtered_vault, secret_value)
    assert vault_value == filtered_data

# Generated at 2022-06-23 10:10:53.215872
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_module = FilterModule()
    assert filter_module is not None

# Generated at 2022-06-23 10:10:57.379661
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    filters = f.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault



# Generated at 2022-06-23 10:11:02.511726
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'ansible'
    vaultid = 'filter_default'

    data = 'foo'
    vault = do_vault(data, secret, wrap_object=True)
    unvault = do_unvault(vault, secret, vaultid)
    assert unvault == data



# Generated at 2022-06-23 10:11:14.992645
# Unit test for function do_unvault
def test_do_unvault():
    from tempfile import mkdtemp
    import shutil
    import os
    from ansible.parsing.vault import VaultSecret

    plaintext = 'Hello, world!'
    secret = VaultSecret(b'Abcd1234')
    salt = b'abcdefgh'
    vaultid = 'filter_default'

    # Ensure do_unvault fails appropriately when no password is provided
    try:
        do_unvault(plaintext, None, vaultid)
        assert False, 'Expected do_unvault to throw an exception when secret is None'
    except AnsibleFilterTypeError:
        pass

    # Ensure do_unvault fails appropriately when no vaultid is provided

# Generated at 2022-06-23 10:11:23.648676
# Unit test for function do_vault
def test_do_vault():
    secrets = { 'secret': 'password', 'vault': 'foobar' }
    display.info('Testing for secret: %s' % secrets['secret'])
    display.info('Testing for vault: %s' % secrets['vault'])

    assert do_vault('hello world', secrets['secret']) != 'hello world'
    assert do_vault('hello world', secrets['secret']) == do_unvault(do_vault('hello world', secrets['secret']), secrets['secret'])
    assert do_vault(123, secrets['secret']) == do_unvault(do_vault(123, secrets['secret']), secrets['secret'])

# Generated at 2022-06-23 10:11:36.437284
# Unit test for function do_unvault

# Generated at 2022-06-23 10:11:44.609539
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()
    assert isinstance(filters, dict)
    assert 'vault' in filters
    assert 'unvault' in filters


# Generated at 2022-06-23 10:11:52.615585
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;xxxxx\r\n346365623764646237316265343133337066306430313338646661343464366636646537396434\r\n3264643935333961306633336336331306334343630666162393239363562626161356132646639\r\n34303263386365656130663266333865646365626332366533356664356563386538353833\r\n', 'secret', 'filter_default') == "unit_test"

# Generated at 2022-06-23 10:11:56.423226
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    module = FilterModule()
    res = module.filters()
    assert (res['vault'] == do_vault)
    assert (res['unvault'] == do_unvault)


# Generated at 2022-06-23 10:12:04.257867
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;foo;42;42;e1NTSEF9ZmFsCg==', secret) == 'bar'
    assert do_unvault(None, secret) == None

    vault = do_vault('foo', secret)
    assert do_unvault(vault, secret) == 'foo'



# Generated at 2022-06-23 10:12:14.325027
# Unit test for function do_unvault
def test_do_unvault():
    secret = "test_secret"

    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\r\ntest_secret\r\n3330383134393834323331333932313261326333356466653362656632333333\r\n", secret) == "test_secret"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\r\ntest_secret\r\nmultiple\r\nlines\r\n", secret) == "test_secret\r\nmultiple\r\nlines"
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\r\ntest_secret", secret) == ""

# Generated at 2022-06-23 10:12:25.684138
# Unit test for function do_unvault
def test_do_unvault():
    data_in = 'xyzzy'
    secret = 'xyzzy'

# Generated at 2022-06-23 10:12:28.191197
# Unit test for constructor of class FilterModule
def test_FilterModule():
    filter_class = FilterModule()
    assert filter_class


# Generated at 2022-06-23 10:12:38.211370
# Unit test for function do_unvault
def test_do_unvault():
    # Create test cases
    test_cases = [
        "1234",
        "this is a test",
        "this is a test !@#$%^&*()_+",
        "this is a test !@#$%^&*()_+",
        "this is a test !@#$%^&*()_+?",
        "\r\n\r\n",
        "\r\r",
        "\n\n",
        "a" * 100,
        "a" * 1000,
        "a" * 10000,
        "a" * 100000,
        "a" * 1000000,
    ]

    # Run test cases
    for test_case in test_cases:
        print("Testing %s" % test_case)

# Generated at 2022-06-23 10:12:39.818207
# Unit test for constructor of class FilterModule
def test_FilterModule():
    f = FilterModule()
    return f.filters()


# Generated at 2022-06-23 10:12:50.099117
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'test'
    wrap_object = False
    display.verbosity = 2
    vault = do_vault(data, secret, salt=None, vaultid='filter_default', wrap_object=False)

# Generated at 2022-06-23 10:12:52.350526
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter = FilterModule()
    assert filter.filters() == {'vault': do_vault, 'unvault': do_unvault}



# Generated at 2022-06-23 10:12:53.422181
# Unit test for constructor of class FilterModule
def test_FilterModule():
    assert FilterModule() is not None


# Generated at 2022-06-23 10:12:57.492836
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    f = FilterModule()
    # Call method filters of class FilterModule
    assert callable(f.filters)



# Generated at 2022-06-23 10:13:02.039938
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    vf = FilterModule()
    assert isinstance(vf.filters(), dict)
    assert vf.filters().get('vault') == do_vault
    assert vf.filters().get('unvault') == do_unvault


# Generated at 2022-06-23 10:13:09.718395
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    class_ = FilterModule()

    assert class_.filters() is not None

# Generated at 2022-06-23 10:13:11.206574
# Unit test for constructor of class FilterModule
def test_FilterModule():
    result = FilterModule()
    assert result is not None


# Generated at 2022-06-23 10:13:20.730721
# Unit test for function do_unvault
def test_do_unvault():
    # Unit test: normal execution
    expected = "this is a secret string"
    data = "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          6138313161646438636234313761643132333434623732363136646662393466363932366137383130\n          3462623166343833383534373165323739356262653264396665623561316136326664356338323264\n          3239653436326234636265636433373267663334303135633366663235656363373833366439363034\n          623864323435666131643235336166633739\n          "
    secret = "my_secret"
    assert do_

# Generated at 2022-06-23 10:13:26.689961
# Unit test for function do_vault

# Generated at 2022-06-23 10:13:30.085451
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    fm = FilterModule()
    filters = fm.filters()

    # Assert method filter exists
    assert 'vault' in filters
    assert 'unvault' in filters

# Generated at 2022-06-23 10:13:39.044518
# Unit test for function do_unvault
def test_do_unvault():
    from tempfile import mkstemp
    from shutil import move

    fd, path = mkstemp()
    with open(path, 'w') as new_file:
        new_file.write('''
        ---
        - hosts: localhost
          tasks:
          - name: Decrypt string using default vaultid
            debug:
              msg: "{{ encrypted_string | unvault(secret) }}"
          - name: Decrypt string using vaultid
            debug:
              msg: "{{ encrypted_string | unvault(secret, vaultid='filter_second') }}"
          - name: Decrypt string using vaultid
            debug:
              msg: "{{ encrypted_string_vault | unvault(secret, vaultid='filter_third') }}"
        ''')



# Generated at 2022-06-23 10:13:41.900117
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    assert 'vault' in FilterModule.filters(None)
    assert 'unvault' in FilterModule.filters(None)


# Generated at 2022-06-23 10:13:53.517715
# Unit test for function do_unvault

# Generated at 2022-06-23 10:14:06.165342
# Unit test for function do_unvault

# Generated at 2022-06-23 10:14:10.390481
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    # AssertionError raised by 0.25.1 and not in 0.25.2
    try:
        filters_dict = FilterModule().filters()
        assert 'vault' in filters_dict
        assert 'unvault' in filters_dict
    except AssertionError as e:
        raise e

# Generated at 2022-06-23 10:14:14.800705
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filter_module = FilterModule()
    assert 'vault' in filter_module.filters()
    assert 'unvault' in filter_module.filters()
    assert 'unsupported_method' not in filter_module.filters()


# Generated at 2022-06-23 10:14:17.286568
# Unit test for constructor of class FilterModule
def test_FilterModule():
    # Instantiate FilterModule class
    obj = FilterModule()

    # Check if the instance is a class FilterModule
    assert isinstance(obj, FilterModule)

# Generated at 2022-06-23 10:14:26.265512
# Unit test for function do_vault
def test_do_vault():
    import jinja2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO

    class DummyVars(dict):
        def get_vars(self, loader, search_paths, shared_loader_obj=None):
            return {}

    class DummyLoader(jinja2.BaseLoader):
        def get_source(self, environment, template):
            return (template, None, lambda: True)

        def list_templates(self):
            return []


# Generated at 2022-06-23 10:14:40.421771
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    # test simple vault password
    pw = 'pw'
    assert test_do_unvault_args(pw, pw, 'pw') == 'pw'

    # test vault password containing special characters
    pw = '!@#$%^&*()'
    assert test_do_unvault_args(pw, pw, 'pw') == 'pw'

    # test vault password containing special characters
    pw = AnsibleUnsafeText('!@#$%^&*()')
    assert test_do_unvault_args(pw, pw, 'pw') == 'pw'

    # test vault password as None
    pw = None

# Generated at 2022-06-23 10:14:52.773992
# Unit test for function do_vault

# Generated at 2022-06-23 10:14:56.355455
# Unit test for constructor of class FilterModule
def test_FilterModule():
    def1 = FilterModule()
    def1_filters = def1.filters()
    assert def1_filters['vault'] == do_vault
    assert def1_filters['unvault'] == do_unvault


# Generated at 2022-06-23 10:14:58.337313
# Unit test for constructor of class FilterModule
def test_FilterModule():
    fm = FilterModule()
    assert isinstance(fm, FilterModule)
    assert len(fm.filters()) == 2


# Generated at 2022-06-23 10:15:04.765731
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    filt = FilterModule()
    filters = filt.filters()

    # test filter vault
    assert filters['vault']('this should be encrypted', 'super_secret_string') is not 'this should be encrypted'
    # test unvault
    assert filters['unvault'](filters['vault']('this should be encrypted', 'super_secret_string'), 'super_secret_string') == 'this should be encrypted'

# Generated at 2022-06-23 10:15:07.090059
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    vault_filter_module = FilterModule()
    result = vault_filter_module.filters()
    assert 'vault' in result and 'unvault' in result


# Generated at 2022-06-23 10:15:14.155155
# Unit test for method filters of class FilterModule
def test_FilterModule_filters():
    obj = FilterModule()
    result = obj.filters()

# Generated at 2022-06-23 10:15:23.001329
# Unit test for function do_vault
def test_do_vault():
    assert(do_vault('pass', 'AES256', salt='AES256') == '$ANSIBLE_VAULT;1.2;AES256;AES256\n633933356461376133396236353933663436313663616336656333164333534393262633664\nd6a7a39b59f4616cac6ec3d3d549272b3cd\n')

# Generated at 2022-06-23 10:15:25.853420
# Unit test for constructor of class FilterModule
def test_FilterModule():
    obj = FilterModule()
    filters = obj.filters()
    assert filters['vault'] == do_vault
    assert filters['unvault'] == do_unvault
