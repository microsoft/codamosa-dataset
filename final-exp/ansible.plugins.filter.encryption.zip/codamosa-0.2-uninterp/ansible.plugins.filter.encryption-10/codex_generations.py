

# Generated at 2022-06-22 16:38:21.378384
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native

    secret = 'secret'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([('filter_default', vs)])
    vault = vl.encrypt(to_bytes('test'), vs, 'filter_default')
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == 'test'

# Generated at 2022-06-22 16:38:32.590002
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:39.266453
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:49.861618
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n3634653534643536306566363633653765376635646466653735653435643933653530653530\n3464373533643530646437383564363334643037353465386535343335373565383730656564\n3633653534643536306566363633653765376635646466653735653435643933653530653530\n3464373533643530646437383564363334643037353465386535343335373565383730656564\n'

# Generated at 2022-06-22 16:39:00.702466
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:12.878443
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:22.766466
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:33.625656
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n6331623662396231316232623462356236623762386239623a623b623c623d623e623f623g623h623i623j\n623k623l623m623n623o623p623q623r623s623t623u623v623w623x623y623z6231623262336234\n62356236623762386239', 'password') == 'test'

# Generated at 2022-06-22 16:39:42.146712
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:54.104416
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'test') == '$ANSIBLE_VAULT;1.1;AES256\n633262316662333132333232316232396332623166623331323332323162323963326231666233313233323231623239\n393336353766343933666537383736653933363537663439336665373837366539333635376634393366653738373665\n'

# Generated at 2022-06-22 16:40:00.474901
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:11.783822
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:19.473552
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:30.956510
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:42.164730
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:40:54.096965
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:06.241089
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:15.048648
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:26.171716
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:31.994916
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)


# Generated at 2022-06-22 16:41:47.569858
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:58.521192
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:08.472063
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:42:12.250719
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert is_encrypted(vault)


# Generated at 2022-06-22 16:42:19.787365
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:28.501024
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:39.885237
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:42:52.597116
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:00.583389
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:13.367229
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:29.299870
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:43:39.082418
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type
    import os
    import sys
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()

    # Create the vault password file
    vault_

# Generated at 2022-06-22 16:43:51.091758
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted

# Generated at 2022-06-22 16:44:02.502212
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:07.811259
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')


# Generated at 2022-06-22 16:44:15.037833
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:27.408747
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:35.288222
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:46.926883
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:44:58.890085
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:14.314232
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:22.545144
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = '$ANSIBLE_VAULT;1.1;AES256'
    salt = '$ANSIBLE_VAULT;1.1;AES256'
    vaultid = 'filter_default'
    wrap_object = False
    data = 'test'

    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt(data, vs, vaultid, salt)

    assert vault == do_vault(data, secret, salt, vaultid, wrap_object)


# Generated at 2022-06-22 16:45:34.605960
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:45.861859
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:45:57.780808
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:08.067606
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:20.518921
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:33.118267
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:45.306291
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:58.107060
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'


# Generated at 2022-06-22 16:47:11.811228
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3
    assert vault.count('\n') == 3

# Generated at 2022-06-22 16:47:24.485094
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:33.074111
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:47:43.575491
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)


# Generated at 2022-06-22 16:47:55.686615
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:48:06.794429
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:10.898396
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data