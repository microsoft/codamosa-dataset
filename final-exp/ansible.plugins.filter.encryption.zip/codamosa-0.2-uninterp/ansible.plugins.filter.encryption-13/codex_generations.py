

# Generated at 2022-06-22 16:38:19.910501
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:30.779228
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:38:38.969574
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:43.317648
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == data



# Generated at 2022-06-22 16:38:52.166726
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:02.420431
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import quote
    from ansible.parsing.vault import VaultLib
    import sys
    import os
    import tempfile

    # Create a temporary file to store the vault password
    (fd, vault_password_file) = tempfile.mkstemp()
    os.close(fd)

    # Write the vault password to the temporary file
    with open(vault_password_file, 'wb') as f:
        f.write(b'ansible')

    # Create a temporary file to store the vault id
    (fd, vault_id_file) = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-22 16:39:14.654040
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:39:22.775617
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:33.627051
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:43.529678
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:57.866928
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:09.178322
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n353733356536333635666537363966653764653536393635653738353937663633373435373336\n353733356536333635666537363966653764653536393635653738353937663633373435373336\n'

# Generated at 2022-06-22 16:40:17.910139
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:28.793038
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:40:36.143052
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:46.858402
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:59.475975
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:11.107574
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:17.359119
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:27.823535
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:39.137371
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:48.623610
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:54.214648
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:05.110486
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:42:13.798819
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:20.168776
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert do_unvault(vault, secret) == data


# Generated at 2022-06-22 16:42:28.684709
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:39.959242
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:52.597594
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:58.689283
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:17.342819
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:43:29.298970
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:36.979358
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:49.008622
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:44:01.596693
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:44:12.301327
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:24.961168
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:34.879592
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:46.705858
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:58.741641
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:15.453358
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:23.967086
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:35.399330
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:46.669343
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:58.187400
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:08.332936
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True


# Generated at 2022-06-22 16:46:20.807079
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:33.117565
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:45.305841
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ''
    assert do_unvault('', None) == ''
    assert do_unvault('', '') == ''
    assert do_unvault('test', '') == 'test'

# Generated at 2022-06-22 16:46:58.157845
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:47:13.271480
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:25.948058
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:33.559783
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:43.823549
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:56.014873
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:48:07.114654
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:15.726956
# Unit test for function do_unvault