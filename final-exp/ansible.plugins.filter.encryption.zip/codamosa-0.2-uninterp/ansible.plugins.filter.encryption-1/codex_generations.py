

# Generated at 2022-06-22 16:38:09.542319
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:38:18.410646
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"

# Generated at 2022-06-22 16:38:30.917900
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text

    secret = 'secret'
    vaultid = 'filter_default'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib([(vaultid, vs)])
    data = 'data'
    vault = vl.encrypt(to_bytes(data), vs, vaultid)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret, vaultid) == data
    assert do_unvault

# Generated at 2022-06-22 16:38:38.969155
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:49.737505
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:00.629591
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:07.043753
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:17.536395
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:24.210074
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type
    from ansible.utils.display import Display
    from ansible.errors import AnsibleFilterError, AnsibleFilterTypeError
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_str

# Generated at 2022-06-22 16:39:34.278971
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:39:47.991773
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with string

# Generated at 2022-06-22 16:39:52.850856
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 16:40:03.464747
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:14.322061
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False


# Generated at 2022-06-22 16:40:18.953856
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 16:40:30.446729
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:40:41.644444
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:53.545520
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:05.666516
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:14.769788
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:27.597775
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:37.543809
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:49.702805
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:01.118914
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:10.685010
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:18.308571
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:25.628822
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:37.814549
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:50.504175
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:59.088848
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:43:14.302514
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:23.315840
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:34.042252
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:46.816959
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:00.073489
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:44:11.435939
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:44:23.841394
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:44:33.154839
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:44:45.960863
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:58.470468
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:14.431059
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:25.380922
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:35.855038
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:46.945651
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:55.225466
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n35376536666464656637353633353633373035653635343738363537353537353665363337373636\n35376536666464656637353633353633373035653635343738363537353537353665363337373636\n'


# Generated at 2022-06-22 16:46:00.163862
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert is_encrypted(vault)


# Generated at 2022-06-22 16:46:09.282838
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:21.563443
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:33.629542
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:45.410363
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test_secret'
    vaultid = 'test_vaultid'

# Generated at 2022-06-22 16:47:00.843767
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:47:10.967943
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:47:23.860420
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:32.431990
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:43.275476
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:54.943467
# Unit test for function do_unvault

# Generated at 2022-06-22 16:48:01.062929
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False