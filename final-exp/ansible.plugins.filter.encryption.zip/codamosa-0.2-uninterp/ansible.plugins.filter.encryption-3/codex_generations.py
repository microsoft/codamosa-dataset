

# Generated at 2022-06-22 16:38:19.117058
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:29.882915
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:38:38.970917
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:43.767301
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:52.442777
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:02.529724
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:12.675981
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'secret'
    data = 'data'
    vaultid = 'filter_default'
    salt = None
    wrap_object = False

    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt(data, vs, vaultid, salt)

    assert do_vault(data, secret, salt, vaultid, wrap_object) == vault


# Generated at 2022-06-22 16:39:21.543767
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:26.371580
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT;')
    assert vault.endswith('\n')
    assert vault != data


# Generated at 2022-06-22 16:39:35.188028
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ''
    assert do_unvault('', '') == ''
    assert do_unvault('', None) == ''
    assert do_unvault(None, '') == ''
    assert do_unvault('', 'secret') == ''
    assert do_unvault('secret', '') == 'secret'
    assert do_unvault('secret', None) == 'secret'
    assert do_unvault(None, 'secret') == ''
    assert do_unvault('secret', 'secret') == 'secret'

# Generated at 2022-06-22 16:39:44.195486
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n35373330666437356537353436333765373435393436653335363537346536333633356533383536\n39656536373437356537353436333765373435393436653335363537346536333633356533383536\n'

# Generated at 2022-06-22 16:39:55.505643
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:40:07.291279
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:40:16.579622
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:27.600585
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:36.336572
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:47.039407
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:59.614436
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:41:11.243797
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:41:23.934837
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:33.207544
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:46.015872
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "filter_default"

# Generated at 2022-06-22 16:41:56.910891
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:42:06.602280
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:15.263616
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:27.064659
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type
    import pytest

    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = ''
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    try:
        vault = vl.encrypt(to_bytes(data), vs, vaultid, salt)
    except Exception as e:
        raise Ans

# Generated at 2022-06-22 16:42:39.338604
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:52.288563
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:43:00.375785
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:13.070222
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:24.908464
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.six import string_types, binary_type
    from ansible.errors import AnsibleFilterTypeError, AnsibleFilterError
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    import os
    import sys

    display = Display()

    # Test with a

# Generated at 2022-06-22 16:43:34.816515
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:47.098434
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:51.206164
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    vault = do_vault(data, secret)
    assert vault != data
    assert vault.startswith("$ANSIBLE_VAULT;")


# Generated at 2022-06-22 16:44:02.555793
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:12.896043
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:25.432836
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:34.220288
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:46.370697
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:44:53.228645
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:10.630084
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:21.059877
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:33.277913
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:45.286263
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:56.991761
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:07.832724
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:20.353111
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:32.902130
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:38.955159
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ''
    assert do_unvault('', None) == ''
    assert do_unvault('', '') == ''
    assert do_unvault('', 'secret') == ''

# Generated at 2022-06-22 16:46:47.167916
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:47:02.725609
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:12.193004
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible_default\n3637353633396535333635663665306539343338653833393537373736353534373334373535\n35333635663665306539343338653833393537373736353534373334373535\n", "secret") == "123456789e53656fe6e0e9438e83957777655473473555\n53656fe6e0e9438e83957777655473473555\n"

# Generated at 2022-06-22 16:47:16.262395
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 16:47:28.937382
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:41.185262
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:47.794711
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:59.722041
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault(None, None) == ''
    assert do_unvault('', '') == ''
    assert do_unvault('', None) == ''
    assert do_unvault(None, '') == ''
    assert do_unvault('', 'secret') == ''
    assert do_unvault('secret', 'secret') == 'secret'

# Generated at 2022-06-22 16:48:10.702441
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'