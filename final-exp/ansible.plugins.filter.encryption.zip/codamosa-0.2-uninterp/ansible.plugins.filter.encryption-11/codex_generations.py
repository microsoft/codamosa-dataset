

# Generated at 2022-06-22 16:38:20.230742
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:31.090634
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:42.703356
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:51.788779
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:02.185639
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:14.618188
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:23.081831
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:39:34.481315
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:45.359789
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:56.448297
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    data = 'data'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:09.916553
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:16.833368
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets[vaultid].secret == secret
    assert result.data == data
    assert result.vault.secrets[vaultid].salt == salt
    assert result.vault.secrets[vaultid].vaultid == vaultid


# Generated at 2022-06-22 16:40:27.818665
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:36.418870
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:47.232676
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:59.750580
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:11.316324
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:23.934496
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.vault import VaultAES256HMAC
    from ansible.parsing.vault import VaultAES256HMACSha256
    from ansible.parsing.vault import VaultAES256CBC
    from ansible.parsing.vault import VaultAES256CBCHMAC
    from ansible.parsing.vault import VaultAES256CBCHMACSha256
    from ansible.parsing.vault import VaultAES256GCM


# Generated at 2022-06-22 16:41:31.689164
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:39.613153
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:50.054969
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:01.460767
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:11.010547
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:18.547129
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:28.177502
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:39.849744
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:52.536965
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:42:58.644603
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:10.213584
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:20.725163
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:33.826466
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:43:46.602265
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:59.899097
# Unit test for function do_vault
def test_do_vault():
    secret = "test"
    data = "test"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:44:11.318423
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:23.650122
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:32.871495
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:45.843898
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:58.469385
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:11.534515
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:21.719060
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:45:35.436040
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:46.671799
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:58.187266
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:08.332664
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'

# Generated at 2022-06-22 16:46:20.806816
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:33.116940
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:45.305836
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n343764353635643335366439643465306436346664373535653536353733363564373337353635\n343764353635643335366439643465306436346664373535653536353733363564373337353635\n', 'password') == '1234565d3566d9d4e0d64fd7555e5657365d735765d735765'

# Generated at 2022-06-22 16:46:58.152801
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:08.574594
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:18.989732
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:27.202757
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:39.944362
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:47.030261
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:58.443075
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:07.426226
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n3635373535653633373565663539376565373464353335373765653534333535333465353536\n6635373535653633373565663539376565373464353335373765653534333535333465353536\n3465353536663537353565363337356566353937656537346435333537376565353433353533\n', 'secret') == 'test'

# Generated at 2022-06-22 16:48:15.947624
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'