

# Generated at 2022-06-22 16:38:20.660315
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:31.906325
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:43.216104
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:38:52.106276
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:02.392309
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:14.654712
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:22.775438
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:34.108289
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:42.469313
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:54.406171
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:08.900215
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:17.718200
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:28.793584
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:36.142324
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:46.858608
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:59.474821
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

    # Test for valid input

# Generated at 2022-06-22 16:41:04.142202
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:12.314592
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:24.345721
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:31.970235
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:47.387674
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:58.372500
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:08.307255
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:16.746738
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:27.861683
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:39.655423
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:52.368897
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:43:00.437203
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:13.170234
# Unit test for function do_unvault
def test_do_unvault():
    import pytest
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test for non-encrypted string
    data = 'test'
    secret = 'test'
    vaultid = 'filter_default'
    assert do_unvault(data, secret, vaultid) == 'test'

    # Test for encrypted string
    data = 'test'
    secret = 'test'
    vaultid = 'filter_default'
    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt

# Generated at 2022-06-22 16:43:22.687844
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:36.819611
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:48.870207
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:01.500756
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:12.232578
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:24.873877
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:44:33.827086
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:46.337253
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:58.553506
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:11.623199
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:45:21.849419
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:45.600660
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'test_vault'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:45:52.405457
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:01.449472
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:09.713182
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:21.769253
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:32.988275
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes

    secret = 'secret'
    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    data = 'data'
    vault = vl.encrypt(to_bytes(data), vs, 'filter_default', None)
    assert do_vault(data, secret) == vault
    assert do_vault(data, secret, wrap_object=True) == AnsibleVaultEncryptedUnicode(vault)


# Generated at 2022-06-22 16:46:45.224433
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:58.003304
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:08.448755
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:15.745078
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:48:03.623609
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT;')
    assert vault.endswith('\n')
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2
    assert vault.count('\n') == 2

# Generated at 2022-06-22 16:48:13.346177
# Unit test for function do_unvault