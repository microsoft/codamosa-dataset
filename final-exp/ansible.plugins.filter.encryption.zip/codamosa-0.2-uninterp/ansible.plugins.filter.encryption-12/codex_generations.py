

# Generated at 2022-06-22 16:38:18.783320
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:38:29.422376
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:38:40.787823
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:38:50.595713
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:01.307706
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:07.689370
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os
    import tempfile
    import yaml

    # Create a temporary file
    fd, temp_path = tempfile.mkstemp()
    os.close(fd)

    # Create a vault secret
    vault_secret = VaultSecret('secret')

    # Create a vault editor
    vault_editor = VaultEditor(vault_secret)

    # Create a vault lib
    vault_lib = VaultLib([('default', vault_secret)])

    # Create a vault encrypted

# Generated at 2022-06-22 16:39:18.440746
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:28.168433
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:35.589059
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:47.379286
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:40:01.268051
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:40:12.574276
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:24.140004
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import is_encrypted_file
    from ansible.parsing.vault import is_encrypted_file_v1
    from ansible.parsing.vault import is_encrypted_file_v2
    from ansible.parsing.vault import is_encrypted_file_v2_1
    from ansible.parsing.vault import is_encrypted_file_v2_2
    from ansible.parsing.vault import is_encrypted_file_v2_3
    from ansible.parsing.vault import is_encrypted_file_v2_4
   

# Generated at 2022-06-22 16:40:35.110145
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:46.015590
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:58.608369
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:10.041404
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:18.398374
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:28.657377
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:34.059476
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:49.539876
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:00.948323
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:10.351980
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:18.108665
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:25.350499
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:37.438964
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:46.697296
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False
    assert do_vault(data, secret, salt, vaultid, wrap_object) == '$ANSIBLE_VAULT;1.1;AES256\n35373736643538336437363034656633353466363738666536653737366435383364373630346566333534663637386665\n'


# Generated at 2022-06-22 16:42:56.337977
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:03.949825
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:16.408506
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:33.051938
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:46.140909
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:59.592375
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:11.229548
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:23.506498
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:32.023339
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:45.402780
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:58.426743
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:11.485499
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:21.616293
# Unit test for function do_vault
def test_do_vault():
    secret = 'test'
    data = 'test'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:44.130571
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:56.066466
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:07.429090
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:20.097655
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:31.016662
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    vaultid = 'test_vaultid'
    data = 'data'

    vault = do_vault(data, secret, salt, vaultid)
    assert isinstance(vault, string_types)
    assert is_encrypted(vault)
    assert vault.startswith('$ANSIBLE_VAULT;')

    vault = do_vault(data, secret, salt, vaultid, wrap_object=True)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert is_encrypted(vault)
    assert vault.startswith('$ANSIBLE_VAULT;')


# Generated at 2022-06-22 16:46:43.626713
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:56.447943
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:07.184930
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:15.040338
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 16:47:28.093213
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:48:00.920897
# Unit test for function do_unvault

# Generated at 2022-06-22 16:48:11.451091
# Unit test for function do_vault