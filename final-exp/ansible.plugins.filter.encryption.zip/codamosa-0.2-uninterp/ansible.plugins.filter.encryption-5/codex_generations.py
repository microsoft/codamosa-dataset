

# Generated at 2022-06-22 16:38:16.934628
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:38:27.334546
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:38.604465
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:38:42.237007
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert is_encrypted(vault)


# Generated at 2022-06-22 16:38:47.278369
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-22 16:38:59.210167
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:10.758658
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:24.017848
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:34.163166
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:42.497649
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:55.759625
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:07.590711
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:16.797629
# Unit test for function do_unvault
def test_do_unvault():
    # Test for valid input
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\n333735646665346466373764663565643437333437353064353737373835306535343533363565\n393564646530646534353633353437353064353737373835306535343533363565\n", "ansible") == "test"

    # Test for invalid input

# Generated at 2022-06-22 16:40:27.782929
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:36.185170
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    assert do_vault(data, secret, salt, vaultid, wrap_object) == '$ANSIBLE_VAULT;1.1;AES256\n363764356533393765666438366664653734643533666437356536336635373737363565363733\n373565373565363366353737373635653637333637643565333937656664383666646537346435\n33666437356536336635373737363565363733\n'


# Generated at 2022-06-22 16:40:46.897218
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:59.482953
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:11.106267
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:17.358595
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:27.824322
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import is_encrypted_file
    from ansible.parsing.vault import is_encrypted_file_v1
    from ansible.parsing.vault import is_encrypted_file_v2
    from ansible.parsing.vault import is_encrypted_file_v2_1
    from ansible.parsing.vault import is_encrypted_file_v2_2
    from ansible.parsing.vault import is_encrypted_file_v2_3

# Generated at 2022-06-22 16:41:38.283449
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:48.057898
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('foo', 'bar') == '$ANSIBLE_VAULT;1.1;AES256\n3539656635333765393437643533366464373864356534643335306536356637333730363535\n3965663533376539343764353336646437386435653464333530653635663733373036353500\n'

# Generated at 2022-06-22 16:41:53.616635
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:04.671195
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:13.412804
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:25.392651
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:37.495215
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:50.192142
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.parsing.vault import VaultLib
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-22 16:42:58.822495
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:10.513917
# Unit test for function do_vault
def test_do_vault():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the vault password file
    vault_pass_file = os.path.join(tmpdir, "vault_pass.txt")
    with open(vault_pass_file, "w") as f:
        f.write("vault_password")

    # Create the playbook
    playbook = os.path.join(tmpdir, "playbook.yml")

# Generated at 2022-06-22 16:43:22.000758
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:30.323320
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'
    # Test with a string
    data = 'mydata'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data
    # Test with an AnsibleVaultEncryptedUnicode object
    vault = AnsibleVaultEncryptedUnicode(vault)
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 16:43:36.875024
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.data == data
    assert result.vault.secrets[vaultid].secret == secret
    assert result.vault.secrets[vaultid].salt == salt
    assert result.vault.secrets[vaultid].vaultid == vaultid
    assert result.vault.secrets[vaultid].hmac_key == None


# Generated at 2022-06-22 16:43:48.916031
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:01.500758
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:12.232104
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:24.874320
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:34.824489
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:45.190759
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'test_vault'
    wrap_object = True
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault.secrets[vaultid].secret == secret
    assert vault.vault.secrets[vaultid].salt == salt
    assert vault.data == data
    assert vault.vault.secrets[vaultid].vaultid == vaultid


# Generated at 2022-06-22 16:44:58.293599
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:12.656082
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:23.065320
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:45:34.987499
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:46.262451
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:45:58.108451
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:46:08.259913
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:20.726639
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.configparser import ConfigParser
    from ansible.parsing.vault import VaultLib
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-22 16:46:33.117165
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:45.305609
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:58.106521
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:11.276373
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:23.967932
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types, binary_type
    from ansible.module_utils.six.moves import xrange
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text
    import random

    # Create a random secret
    secret = VaultSecret(to_bytes(str(random.randint(1, 1000000))))

    # Create a random string

# Generated at 2022-06-22 16:47:32.482384
# Unit test for function do_vault
def test_do_vault():
    secret = 'password'
    data = 'secret'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:43.274561
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:54.942768
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:01.036690
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:48:11.561881
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)