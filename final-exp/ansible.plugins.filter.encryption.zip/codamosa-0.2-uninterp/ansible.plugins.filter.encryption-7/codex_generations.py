

# Generated at 2022-06-22 16:38:14.316641
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    data = 'data'
    wrap_object = False

    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt(data, vs, vaultid, salt)

    assert do_vault(data, secret, salt, vaultid, wrap_object) == vault


# Generated at 2022-06-22 16:38:25.422778
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:38:37.491163
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:48.571149
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLibNoKey
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLibNoKey
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-22 16:39:00.296533
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:11.832755
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:22.742178
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:33.625739
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:42.146399
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'secret'
    data = 'data'
    vaultid = 'filter_default'
    salt = None
    wrap_object = False

    vs = VaultSecret(secret)
    vl = VaultLib()
    vault = vl.encrypt(data, vs, vaultid, salt)
    assert vault == do_vault(data, secret, salt, vaultid, wrap_object)

    wrap_object = True
    vault = AnsibleVaultEncryptedUnicode(vault)
    assert vault == do_vault(data, secret, salt, vaultid, wrap_object)

# Unit

# Generated at 2022-06-22 16:39:54.103275
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:07.495001
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:16.725829
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:27.711255
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:36.364834
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:40.785103
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert do_unvault(vault, secret) == data



# Generated at 2022-06-22 16:40:52.652978
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:04.543105
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:13.511852
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:25.459874
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:32.663630
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:47.032903
# Unit test for function do_vault
def test_do_vault():
    # Test for valid input
    secret = "test_secret"
    data = "test_data"
    salt = "test_salt"
    vaultid = "test_vaultid"
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.data == data

    # Test for invalid input
    secret = "test_secret"
    data = "test_data"
    salt = "test_salt"
    vaultid = "test_vaultid"
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result

# Generated at 2022-06-22 16:41:52.893743
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:03.769213
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:12.783442
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:20.186595
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:28.710462
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:39.958276
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:52.596969
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:43:03.023332
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:43:15.430056
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:25.291815
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:43:35.022722
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:47.202692
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:00.452718
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:11.678057
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:24.234832
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:33.667936
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:46.267734
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:58.553530
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:45:11.625648
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:28.774258
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:37.453896
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:48.129947
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:58.638749
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:08.494341
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:20.986150
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:30.578495
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vault = '$ANSIBLE_VAULT;1.1;AES256;ansible\n353465653736663635376633373736373533393464363864643633663633363336353637353435\n353465653736663635376633373736373533393464363864643633663633363336353637353435\n'
    assert do_unvault(vault, secret) == 'secret'


# Generated at 2022-06-22 16:46:37.722915
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:46.769807
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:58.959373
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:12.706240
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:25.144119
# Unit test for function do_vault
def test_do_vault():
    import os
    import tempfile
    import shutil
    import yaml

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the vault password file
    vault_pass = os.path.join(tmpdir, "vault_pass.txt")
    with open(vault_pass, "w") as f:
        f.write("mysecret")

    # Create the vault file
    vault_file = os.path.join(tmpdir, "vault.yml")
    with open(vault_file, "w") as f:
        f.write("---\n")
        f.write("vault_data: !vault |\n")
        f.write("          $ANSIBLE_VAULT;1.1;AES256\n")

# Generated at 2022-06-22 16:47:33.324202
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:43.716499
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:47:55.882571
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:06.990550
# Unit test for function do_vault