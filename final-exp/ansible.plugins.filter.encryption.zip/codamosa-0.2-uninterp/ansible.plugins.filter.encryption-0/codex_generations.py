

# Generated at 2022-06-22 16:38:18.677609
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:25.422235
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    salt = 'mysalt'
    vaultid = 'myvaultid'
    wrap_object = True

    result = do_vault(data, secret, salt, vaultid, wrap_object)

    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets[0].secret == secret
    assert result.vault.secrets[0].salt == salt
    assert result.vault.secrets[0].vaultid == vaultid
    assert result.data == data


# Generated at 2022-06-22 16:38:37.491358
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:48.561609
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:00.297776
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:11.832427
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:23.079588
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes

    secret = 'secret'
    data = 'data'
    vaultid = 'test_vault'
    salt = 'salt'

    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    vault = vl.encrypt(to_bytes(data), vs, vaultid, salt)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.data == data
    assert vault.vault == vl
    assert vault.vaultid == vaultid
    assert vault.s

# Generated at 2022-06-22 16:39:34.480684
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:45.358741
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:56.447878
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:10.224913
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:19.948721
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:31.391511
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:40:42.521828
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:54.381893
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:06.887196
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:16.244167
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:27.085232
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:33.675772
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:41.826383
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:51.286615
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'test_vault'
    wrap_object = False

# Generated at 2022-06-22 16:42:02.337713
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:11.306525
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:18.751365
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:26.211685
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:38.492857
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:51.221252
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:43:03.023622
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:15.430785
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:24.003592
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:37.081906
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:43:49.100691
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:43:59.114060
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.vault.secrets[vaultid].secret == secret
    assert vault.data == data
    assert vault.vault.secrets[vaultid].salt == salt


# Generated at 2022-06-22 16:44:11.142340
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:44:23.081226
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:32.650470
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import is_encrypted_file
    from ansible.parsing.vault import is_encrypted_file_v1
    from ansible.parsing.vault import is_encrypted_file_v2
    from ansible.parsing.vault import is_encrypted_file_v2_1
    from ansible.parsing.vault import is_encrypted_file_v2_2
    from ansible.parsing.vault import is_encrypted_file_v2_3

# Generated at 2022-06-22 16:44:45.685525
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:58.429726
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:11.535770
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:45:21.717769
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:36.366114
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:47.356739
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fd, temp_path = tempfile.mkstemp(dir=tmpdir)
    # Write data to the temporary file
    data = 'This is a test'

# Generated at 2022-06-22 16:45:58.262940
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:08.376299
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:20.844396
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:32.814740
# Unit test for function do_vault
def test_do_vault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text

    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

    vs = VaultSecret(to_bytes(secret))
    vl = VaultLib()
    vault = vl.encrypt(to_bytes(data), vs, vaultid, salt)

    assert do_vault(data, secret, salt, vaultid, wrap_object) == to_text(vault)


# Generated at 2022-06-22 16:46:38.916406
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:43.837626
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:56.652271
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:07.353281
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:24.130038
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'test_vaultid'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 16:47:32.559099
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:37.400369
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:45.716076
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:57.279422
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:48:04.480850
# Unit test for function do_unvault

# Generated at 2022-06-22 16:48:13.881474
# Unit test for function do_unvault