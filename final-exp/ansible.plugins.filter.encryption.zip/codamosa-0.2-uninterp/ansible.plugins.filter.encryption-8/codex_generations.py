

# Generated at 2022-06-22 16:38:10.257135
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:38:18.651479
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:38:29.218198
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:40.411325
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:50.441774
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:01.242489
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:07.282178
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:18.174984
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:28.094465
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:38.856271
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:55.172485
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:06.897263
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:16.280895
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:27.337358
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:36.279129
# Unit test for function do_unvault
def test_do_unvault():
    # Test for unvaulting a string
    assert do_unvault(do_vault('test', 'test'), 'test') == 'test'

    # Test for unvaulting an AnsibleVaultEncryptedUnicode object
    assert do_unvault(do_vault('test', 'test', wrap_object=True), 'test') == 'test'

    # Test for unvaulting a string that is not encrypted
    assert do_unvault('test', 'test') == 'test'

    # Test for unvaulting a string that is encrypted with a different secret
    assert do_unvault(do_vault('test', 'test'), 'test2') == ''

    # Test for unvaulting a string that is encrypted with a different vaultid

# Generated at 2022-06-22 16:40:46.994217
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:59.611901
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:11.242172
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:23.934846
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:29.152260
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert is_encrypted(vault)


# Generated at 2022-06-22 16:41:45.743435
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:56.604093
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:06.441795
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:15.112371
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:26.993863
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:39.292634
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:52.289321
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:00.375382
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:13.063129
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:20.414227
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:34.423733
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    vaultid = 'test_vaultid'
    data = 'data'

    # Test with salt
    result = do_vault(data, secret, salt, vaultid)

# Generated at 2022-06-22 16:43:46.912921
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:00.202826
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:11.557685
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:24.028687
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:33.168244
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:46.000704
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:50.880302
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret


# Generated at 2022-06-22 16:45:00.553383
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:12.905915
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:28.076828
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:45:37.549027
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:48.195330
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:58.673539
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:08.495074
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:20.952276
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:33.228589
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Test with a string
    secret = 'secret'

# Generated at 2022-06-22 16:46:45.344089
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:58.153445
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import string_types, binary_type
    from ansible.module_utils.six.moves import range

    # Test with a string
    data = 'test_string'
    secret = 'test_secret'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert is_encrypted(vault)

# Generated at 2022-06-22 16:47:05.640659
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:16.245423
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:28.901887
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:47:41.184906
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:44.037755
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret


# Generated at 2022-06-22 16:47:56.152082
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)