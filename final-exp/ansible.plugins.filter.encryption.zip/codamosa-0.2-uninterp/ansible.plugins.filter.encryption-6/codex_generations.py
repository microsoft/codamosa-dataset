

# Generated at 2022-06-22 16:38:20.540359
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:31.818007
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:37.950243
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:48.905812
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:00.332551
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:11.885007
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:39:22.742116
# Unit test for function do_unvault
def test_do_unvault():
    secret = "secret"
    vaultid = "filter_default"

# Generated at 2022-06-22 16:39:33.627982
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:42.146584
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:54.102879
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:08.097895
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:17.176432
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:28.096271
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:36.887623
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:48.501601
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:40:59.843106
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'mysecret'
    vs = VaultSecret(secret)
    vl = VaultLib([('filter_default', vs)])

    # Test unvaulting a string
    data = 'mydata'
    vault = vl.encrypt(data)
    assert do_unvault(vault, secret) == data

    # Test unvaulting an AnsibleVaultEncryptedUnicode
    vault = AnsibleVaultEncryptedUnicode(vault)
    assert do_unvault(vault, secret) == data

# Generated at 2022-06-22 16:41:11.406736
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:41:23.934928
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:34.490649
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:47.032319
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:05.955866
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:14.516987
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:21.430014
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False

# Generated at 2022-06-22 16:42:29.291174
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:40.192282
# Unit test for function do_vault
def test_do_vault():
    # Test for valid input
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n363539363566373634666534353736353337363335663535353437373566363533653737353536\n34656537363435373633356635353534373735663635336537373535363533373635663736346665\n34353736353337363335663535353437373566363533653737353536\n'

# Generated at 2022-06-22 16:42:52.733938
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:00.664136
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:13.411595
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:21.200915
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:32.553654
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:48.571429
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:44:01.297607
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:12.095280
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:24.693263
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:34.480928
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:46.495524
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:53.309655
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:01.581030
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:13.401103
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'
    vaultid = 'test'

# Generated at 2022-06-22 16:45:23.167123
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:45:36.504454
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:47.467030
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:58.262836
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:46:08.376570
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:20.880435
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:46:33.228783
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:45.349779
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:46:58.153340
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:08.574175
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:47:15.815479
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:31.139174
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 16:47:42.409782
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:53.365847
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:48:05.101265
# Unit test for function do_unvault

# Generated at 2022-06-22 16:48:14.372648
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'