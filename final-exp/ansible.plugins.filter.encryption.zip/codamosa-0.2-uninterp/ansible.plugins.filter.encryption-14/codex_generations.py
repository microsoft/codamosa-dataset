

# Generated at 2022-06-22 16:38:10.335065
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:18.710764
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:29.320984
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:38:33.250667
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 16:38:39.500323
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:38:44.409018
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:52.795165
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:57.651026
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'test'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 16:39:04.185070
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    salt = 'mysalt'
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:39:16.125418
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:28.167764
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:38.895978
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:49.739834
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:00.937849
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:12.240570
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:23.604065
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:35.615628
# Unit test for function do_unvault
def test_do_unvault():
    # Test for valid input
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\n333064653566376536306435383465373730643365356665353836643335653435333436333566\n393064653566376536306435383465373730643365356665353836643335653435333436333566\n", "secret") == "test"
    # Test for invalid input

# Generated at 2022-06-22 16:40:39.095323
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert is_encrypted(vault)
    assert do_unvault(vault, secret) == data


# Generated at 2022-06-22 16:40:51.016947
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:02.420389
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:14.133832
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:25.821626
# Unit test for function do_unvault
def test_do_unvault():
    secret = "mysecret"
    vaultid = "filter_default"

# Generated at 2022-06-22 16:41:37.186847
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:49.620289
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:01.030967
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:10.646070
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:18.279730
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:42:25.647791
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:37.853675
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLibError
    from ansible.parsing.vault import VaultSecretError
    from ansible.parsing.vault import VaultUnsupportedVersionError
    from ansible.parsing.vault import VaultFormatError
    from ansible.parsing.vault import VaultChecksumError
    from ansible.parsing.vault import VaultEncryptionUnavailableError
    from ansible.parsing.vault import VaultDecryptionError
    from ansible.parsing.vault import VaultPasswordError

# Generated at 2022-06-22 16:42:50.548210
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:42:58.550588
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:09.944693
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:20.521861
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:32.061833
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:37.818654
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')


# Generated at 2022-06-22 16:43:49.803336
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:02.039370
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:12.590318
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:25.087823
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:33.981335
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:47.767354
# Unit test for function do_vault
def test_do_vault():
    secret = "mysecret"
    data = "mydata"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:44:59.169746
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import sys
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLibNoKeyError
    from ansible.parsing.vault import VaultLibKeyError
    from ansible.parsing.vault import VaultLibVersionError
    from ansible.parsing.vault import VaultLibMacError
    from ansible.parsing.vault import VaultLibModeError
    from ansible.parsing.vault import VaultLibIntegrityError
    from ansible.parsing.vault import VaultLibDecryptionError

# Generated at 2022-06-22 16:45:12.145748
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:22.445726
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:34.527142
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:45.815757
# Unit test for function do_vault
def test_do_vault():
    # Test for valid input
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:45:53.064282
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:01.681292
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:46:08.550872
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vaultid = "vaultid"
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets[0].secret == secret
    assert result.vault.secrets[0].salt == salt
    assert result.vault.secrets[0].vaultid == vaultid
    assert result.data == data


# Generated at 2022-06-22 16:46:21.021260
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:34.731304
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:45.826583
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:58.304938
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:47:08.698822
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:19.238380
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:30.893521
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:42.372226
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:47:48.522130
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:48:00.548941
# Unit test for function do_vault