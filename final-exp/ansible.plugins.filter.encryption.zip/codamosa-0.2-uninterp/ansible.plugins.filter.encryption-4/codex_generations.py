

# Generated at 2022-06-22 16:38:15.658245
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:22.898934
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.data == data
    assert vault.vault.secrets[vaultid] == secret
    assert vault.vault.secrets[vaultid].salt == salt


# Generated at 2022-06-22 16:38:34.127237
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:45.956592
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:57.921266
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    data = 'data'
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:39:01.132881
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'test_vaultid'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 16:39:07.234522
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:18.137445
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:28.095030
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:35.560929
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:44.262442
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:39:55.599239
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:06.599128
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    secret = 'secret'
    vs = VaultSecret(secret)
    vl = VaultLib([('filter_default', vs)])
    vault = vl.encrypt('data')
    assert do_unvault(vault, secret) == 'data'

    vault = AnsibleVaultEncryptedUnicode(vault)
    vault.vault = vl
    assert do_unvault(vault, secret) == 'data'

    assert do_unvault('data', secret) == 'data'

# Generated at 2022-06-22 16:40:16.050289
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:27.057993
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:36.153750
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:40:46.860900
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    salt = 'mysalt'
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:59.475220
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:11.114787
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:41:17.359251
# Unit test for function do_unvault
def test_do_unvault():
    assert do_unvault("$ANSIBLE_VAULT;1.1;AES256;ansible\n3564663034656635353735306464373939643330646436376566373536663565366536356466\n3034656635353735306464373939643330646436376566373536663565366536356466\n", "test") == "test"

# Generated at 2022-06-22 16:41:29.122861
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:37.944597
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:47.875907
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:58.865028
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:08.715731
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:16.994039
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:28.006441
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:39.772691
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:52.499500
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:43:00.496773
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:15.341762
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:23.972662
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:34.355143
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'test'

# Generated at 2022-06-22 16:43:46.867788
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:51.856727
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-22 16:44:02.839896
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:44:13.043423
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:25.557192
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:34.308653
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'mysecret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:46.439985
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:59.286678
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:03.754943
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data


# Generated at 2022-06-22 16:45:14.616975
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:19.159115
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

    assert isinstance(vault, string_types)
    assert vault.startswith('$ANSIBLE_VAULT')


# Generated at 2022-06-22 16:45:25.895084
# Unit test for function do_vault
def test_do_vault():
    import os
    import sys
    import pytest
    import tempfile
    import shutil
    import subprocess
    import json
    import yaml
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create the vault secret file
    secret_file = os.path.join(tmpdir, "secret.txt")
    with open(secret_file, "w") as f:
        f.write("secret")

    # Create the vault password file
    password_file = os.path.join(tmpdir, "password.txt")

# Generated at 2022-06-22 16:45:36.091758
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:47.135809
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:58.225627
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:06.887401
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:19.578453
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:34.127569
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:45.527856
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:54.812115
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vaultid = "vaultid"
    wrap_object = True
    result = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(result, AnsibleVaultEncryptedUnicode)
    assert result.vault.secrets[vaultid].secret == secret
    assert result.data == data
    assert result.salt == salt
    assert result.vaultid == vaultid


# Generated at 2022-06-22 16:47:05.520648
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:14.101341
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:27.484983
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:40.127288
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:47:51.291377
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:56.574663
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)
    assert isinstance(vault, string_types)
    assert vault != data
    assert vault != secret
    assert vault.startswith('$ANSIBLE_VAULT')
    assert vault.endswith('\n')


# Generated at 2022-06-22 16:48:07.388433
# Unit test for function do_vault