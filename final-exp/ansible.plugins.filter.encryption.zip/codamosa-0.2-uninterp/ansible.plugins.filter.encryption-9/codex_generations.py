

# Generated at 2022-06-22 16:38:12.767943
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:38:23.716682
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:31.619279
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:38:38.990355
# Unit test for function do_unvault

# Generated at 2022-06-22 16:38:43.787254
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:47.552310
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert do_unvault(vault, secret, vaultid=vaultid) == data

# Generated at 2022-06-22 16:38:59.467496
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:39:10.908275
# Unit test for function do_vault

# Generated at 2022-06-22 16:39:20.620432
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False
    result = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:39:31.858561
# Unit test for function do_unvault

# Generated at 2022-06-22 16:39:47.901846
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:59.549271
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:40:10.846042
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:40:18.896083
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:40:30.393987
# Unit test for function do_vault

# Generated at 2022-06-22 16:40:41.594747
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:53.495707
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:05.612230
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:14.698692
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:26.128850
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:39.022636
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:48.560895
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:41:59.723321
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:09.395616
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:17.196547
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import get_file_vault_secret
    from ansible.parsing.vault import get_vault_secret
    from ansible.parsing.vault import get_vault_secrets
    from ansible.parsing.vault import get_vault_password
    from ansible.parsing.vault import get_vault_id
    from ansible.parsing.vault import get_vault_ids
    from ansible.parsing.vault import get_vault_version
    from ansible.parsing.vault import get_vault_

# Generated at 2022-06-22 16:42:28.064374
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:39.810228
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:42:52.537542
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:00.525656
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:13.274313
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:43:29.499533
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:43:36.502255
# Unit test for function do_vault
def test_do_vault():
    assert do_vault('test', 'secret') == '$ANSIBLE_VAULT;1.1;AES256\n3539653038353864356537303466653635663730653636383566376433353064663437333635\n3039653366353464666536356637306536363835663764333530646634373336353965303835\n3864356537303466653635663730653636383566376433353064663437333635\n'


# Generated at 2022-06-22 16:43:48.527783
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:01.297462
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:44:12.094557
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:24.693378
# Unit test for function do_vault
def test_do_vault():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    import sys

    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    # Test valid input

# Generated at 2022-06-22 16:44:34.481522
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:46.496259
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:53.308734
# Unit test for function do_unvault
def test_do_unvault():
    import os
    import sys
    import pytest
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLibNoKeyError
    from ansible.parsing.vault import VaultLibKeyError
    from ansible.parsing.vault import VaultLibError
    from ansible.parsing.vault import VaultLibVersionError
    from ansible.parsing.vault import VaultLibFormatError
    from ansible.parsing.vault import VaultLibSignatureError
    from ansible.parsing.vault import VaultLibMacError
    from ansible.parsing.vault import VaultLibChecksumError
   

# Generated at 2022-06-22 16:45:01.580509
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:17.609762
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:24.751099
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:35.472338
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types, binary_type


# Generated at 2022-06-22 16:45:46.670035
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 16:45:58.187081
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:08.333542
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:20.806205
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:33.118136
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:45.307001
# Unit test for function do_unvault

# Generated at 2022-06-22 16:46:58.106971
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:47:14.953875
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:28.052931
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:47:40.301710
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:51.293225
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:48:00.109124
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True
    vault = do_vault(data, secret, salt, vaultid, wrap_object)
    assert isinstance(vault, AnsibleVaultEncryptedUnicode)
    assert vault.data == data
    assert vault.vault.secrets[vaultid].secret == secret
    assert vault.vault.secrets[vaultid].salt == salt
    assert vault.vault.secrets[vaultid].vaultid == vaultid
