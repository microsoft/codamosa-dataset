

# Generated at 2022-06-22 16:38:18.410336
# Unit test for function do_vault

# Generated at 2022-06-22 16:38:28.914276
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:38:38.944843
# Unit test for function do_unvault
def test_do_unvault():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import is_encrypted
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-22 16:38:49.737312
# Unit test for function do_vault
def test_do_vault():
    secret = 'mysecret'
    data = 'mydata'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:00.630752
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:39:07.067724
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:39:18.019829
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:39:28.095592
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:39:32.933395
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'
    data = 'data'
    vault = do_vault(data, secret, vaultid=vaultid)
    assert data == do_unvault(vault, secret, vaultid=vaultid)

# Generated at 2022-06-22 16:39:41.676225
# Unit test for function do_vault
def test_do_vault():
    secret = "secret"
    data = "data"
    salt = "salt"
    vaultid = "vaultid"
    wrap_object = True

# Generated at 2022-06-22 16:39:55.170710
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'test_vaultid'
    wrap_object = True


# Generated at 2022-06-22 16:40:06.897466
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    salt = 'salt'
    data = 'data'
    vaultid = 'filter_default'
    wrap_object = False

    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:40:12.238077
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:19.737750
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False


# Generated at 2022-06-22 16:40:31.216833
# Unit test for function do_unvault
def test_do_unvault():
    # Test with a string
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n396435306664383565643839653730343366353737663035376435343436303735373533363530\n35393435306664383565643839653730343366353737663035376435343436303735373533363530\n', 'secret') == 'secret'

    # Test with an AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-22 16:40:42.419597
# Unit test for function do_unvault

# Generated at 2022-06-22 16:40:54.286487
# Unit test for function do_unvault

# Generated at 2022-06-22 16:41:06.509827
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:15.193233
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'

# Generated at 2022-06-22 16:41:26.257972
# Unit test for function do_vault

# Generated at 2022-06-22 16:41:37.612415
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:41:49.742117
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:42:01.159582
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:10.175168
# Unit test for function do_unvault

# Generated at 2022-06-22 16:42:18.080313
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:28.149031
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = True

# Generated at 2022-06-22 16:42:39.848038
# Unit test for function do_vault

# Generated at 2022-06-22 16:42:52.538819
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:42:58.622245
# Unit test for function do_vault

# Generated at 2022-06-22 16:43:10.152831
# Unit test for function do_unvault

# Generated at 2022-06-22 16:43:21.323591
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:43:32.672140
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'vaultid'
    wrap_object = False
    vault = do_vault(data, secret, salt, vaultid, wrap_object)

# Generated at 2022-06-22 16:43:45.805759
# Unit test for function do_unvault
def test_do_unvault():
    # Test with a string
    assert do_unvault('$ANSIBLE_VAULT;1.1;AES256;ansible\n36333764663833376639353465353064663435643737306439663335656537393634363537\n36333764663833376639353465353064663435643737306439663335656537393634363537\n', 'secret') == 'secret'
    # Test with a AnsibleVaultEncryptedUnicode object

# Generated at 2022-06-22 16:43:59.319102
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:11.186178
# Unit test for function do_unvault
def test_do_unvault():
    secret = 'secret'
    vaultid = 'filter_default'

# Generated at 2022-06-22 16:44:23.185360
# Unit test for function do_unvault

# Generated at 2022-06-22 16:44:31.733169
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:44:45.233828
# Unit test for function do_vault

# Generated at 2022-06-22 16:44:58.337760
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:45:11.388235
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:23.714771
# Unit test for function do_vault
def test_do_vault():
    data = 'test'
    secret = 'secret'
    salt = 'salt'
    vaultid = 'filter_default'
    wrap_object = False

# Generated at 2022-06-22 16:45:35.363659
# Unit test for function do_unvault

# Generated at 2022-06-22 16:45:46.630132
# Unit test for function do_vault

# Generated at 2022-06-22 16:45:58.187974
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:08.335701
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:20.806354
# Unit test for function do_vault

# Generated at 2022-06-22 16:46:33.120572
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:45.305008
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:46:58.112566
# Unit test for function do_vault

# Generated at 2022-06-22 16:47:05.581229
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:24.674020
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:33.110193
# Unit test for function do_unvault

# Generated at 2022-06-22 16:47:43.610179
# Unit test for function do_vault
def test_do_vault():
    secret = 'secret'
    data = 'data'
    vault = do_vault(data, secret)

# Generated at 2022-06-22 16:47:55.725178
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:02.031775
# Unit test for function do_vault

# Generated at 2022-06-22 16:48:12.314198
# Unit test for function do_unvault