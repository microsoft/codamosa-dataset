

# Generated at 2022-06-26 04:50:59.920063
# Unit test for function fix_command
def test_fix_command():
    test_passed = 0
    test_failed = 0
    try:
        logging.disable(sys.maxint)
        test_case_0()
        test_passed += 1
    except:
        test_failed += 1


# Generated at 2022-06-26 04:51:04.954507
# Unit test for function fix_command
def test_fix_command():
    known_args = mock.Mock()
    known_args.force_command = []
    known_args.command = ['/usr/bin/du']
    os.environ['TF_HISTORY'] = '/usr/bin/du'
    real_command = fix_command(known_args)
    assert dict(real_command._raw_script) == dict(known_args.command)

# Generated at 2022-06-26 04:51:05.708735
# Unit test for function fix_command
def test_fix_command():
    assert test_case_0() == None

# Generated at 2022-06-26 04:51:06.666685
# Unit test for function fix_command
def test_fix_command():
    # test case 0
    test_case_0()

# Generated at 2022-06-26 04:51:17.399187
# Unit test for function fix_command

# Generated at 2022-06-26 04:51:24.123378
# Unit test for function fix_command
def test_fix_command():
    from ..types import CorrectedCommand

    assert fix_command([]) == None
    assert fix_command(['echo $a', 'echo $b']) == None
    assert fix_command(['echo $a', 'echo $b']) == None
    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None

    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None
    assert fix_command(['foo', 'bar']) == None

# Generated at 2022-06-26 04:51:30.018969
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = b'z\xab\x1a\xba\x90\xc1\xd1 \xe3\x9c\x8e\xf7\xdd;\xf5\n\xe8\xdb\xd8'
    var_0 = fix_command(bytes_0)
    assert var_0 == '''alias thefuck="'$(brew --prefix)/bin/fuck'"'''


# Generated at 2022-06-26 04:51:33.673851
# Unit test for function fix_command
def test_fix_command():
    # initialize
    test_case_0()
    # check if value has been changed
    assert (var_0 == 0)

# Generated at 2022-06-26 04:51:42.735616
# Unit test for function fix_command
def test_fix_command():
    from . import utils
    from .utils import fix_command as orig_fix_command
    from thefuck.types import Command
    import thefuck.types
    import thefuck.const
    import thefuck.utils

    def fix_command_mock(Command, get_all_executables, get_alias=None, get_corrected_commands=None,
                         select_command=None, KnownArgs=None, settings=None):
        return 'fixed command'
    orig_fix_command.__globals__['fix_command'] = fix_command_mock

    thefuck.types.Command = utils.MockCommand
    thefuck.const.DIFF_WITH_ALIAS = 0.1
    thefuck.utils.get_all_executables = utils.MockGetAllExecutables()
    the

# Generated at 2022-06-26 04:51:46.548788
# Unit test for function fix_command
def test_fix_command():
    var_0 = fix_command(b"ls /home/user")
    assert var_0 == b'ls /home/user'

# Generated at 2022-06-26 04:52:01.126220
# Unit test for function fix_command
def test_fix_command():
    flag_0 = False
    try:
        str_0 = '/usr/bin/du'
        argv_0 = [str_0]
        argv_1 = []
        argv_2 = []
        argv_3 = []
        argv_4 = []
        argv_5 = []
        argv_6 = []
        argv_7 = []
        argv_8 = []
        argv_9 = []
        argv_10 = []
        argv_11 = []
        argv_12 = []
        argv_13 = []
        argv_14 = []
        argv_15 = []
        argv_16 = []
        argv_17 = []
        argv_18 = []
        argv_19 = []
    except:
        flag_0 = True



# Generated at 2022-06-26 04:52:07.248340
# Unit test for function fix_command
def test_fix_command():
    #print(test_case_0.__doc__)
    logs.init(1)
    assert fix_command('/usr/bin/du') == ['du']


# Generated at 2022-06-26 04:52:08.504889
# Unit test for function fix_command
def test_fix_command():
    assert fix_command(test_case_0) == 0

# Generated at 2022-06-26 04:52:12.189553
# Unit test for function fix_command
def test_fix_command():
    assert(True)

if __name__ == '__main__':
    test_fix_command()

# Generated at 2022-06-26 04:52:15.232127
# Unit test for function fix_command
def test_fix_command():
    # Test case #0
    str_0 = '/usr/bin/du'
    _test_fix_command(str_0)


# Generated at 2022-06-26 04:52:28.249593
# Unit test for function fix_command
def test_fix_command():
    try:
        from test_settings import DEFAULT, ALIAS
    except ImportError:
        sys.exit("Please define test settings to run the test script")
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("command", nargs='*',
        help="Original command")
    parser.add_argument("-d", "--debug",
        help="Debug mode",
        action="store_true")
    parser.add_argument("-v", "--version",
        help="Show version and exit",
        action="store_true")
    parser.add_argument("-l", "--list",
        help="List available rules and exit",
        action="store_true")

# Generated at 2022-06-26 04:52:33.194904
# Unit test for function fix_command
def test_fix_command():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()

# Cases for function fix_command

# Generated at 2022-06-26 04:52:34.746133
# Unit test for function fix_command
def test_fix_command():
    assert 1 == 1


# Generated test cases for _get_raw_command

# Generated at 2022-06-26 04:52:38.549932
# Unit test for function fix_command
def test_fix_command():
    # Test Case # 0
    try:
        assert True # TODO: implement your test here
    except AssertionError as e:
        print('Test Case # 0 Failed: ' + str(e))

# Generated at 2022-06-26 04:52:44.005510
# Unit test for function fix_command
def test_fix_command():
    settings.init()
    assert types.Command.from_raw_script(['/usr/bin/du']).script == '/usr/bin/du'

# Generated at 2022-06-26 04:52:54.795165
# Unit test for function fix_command
def test_fix_command():

    # Call function with argument values
    # function calls are inserted here
    # var_0 = var_0
    # var_plb_0 = var_0
    # var_plb_1 = var_0
    # var_plb_2 = var_0
    # var_plb_3 = var_0
    # var_plb_4 = var_0
    # var_plb_5 = var_0
    # var_plb_6 = var_0
    # var_plb_7 = var_0
    fix_command(var_0)

    # Check for function return value
    assert (var_plb_0 == var_plb_1)

    # Check function calls
    assert (fix_command.call_count == var_plb_2)

    # Check if exception was raised


# Generated at 2022-06-26 04:52:57.557583
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_1 = fix_command(bytes_0)



# Generated at 2022-06-26 04:52:59.946821
# Unit test for function fix_command
def test_fix_command():
    assert True
    print("Test success")

test_fix_command()

# Generated at 2022-06-26 04:53:11.119969
# Unit test for function fix_command
def test_fix_command():
    known_args = types.KnownArgs(force_command=None, command=None, quiet=None, settings_path=None, history=None)
    try:
        test_case_0()
    except:
        assert False
    finally:
        cleanup()


if __name__ == '__main__':
    import types
    argtypes = [types.KnownArgs,]
    argnames = ['known_args',]
    tests = [test_fix_command,]

# Generated at 2022-06-26 04:53:13.154042
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)


# Generated at 2022-06-26 04:53:14.750953
# Unit test for function fix_command
def test_fix_command():
    assert test_case_0() == None

if __name__ == '__main__':
    exit(test_fix_command())

# Generated at 2022-06-26 04:53:17.181598
# Unit test for function fix_command
def test_fix_command():
    var_0 = None
    var_1 = fix_command(var_0)
    return


# Generated at 2022-06-26 04:53:29.029225
# Unit test for function fix_command
def test_fix_command():
    with mock.patch('sys.argv', ['thefuck']):
        with TemporaryDirectory() as temp_dir:
            os.chdir(temp_dir)
            with TemporaryDirectory() as home_dir:
                with mock.patch.dict('os.environ', {'HOME': home_dir}):
                    os.mkdir(os.path.expanduser('~/.thefuck'))
                    with open(os.path.expanduser('~/.thefuck/rules'), 'w') as f:
                        f.write('\n'.join([
                            'def _get_new_command(command):',
                            '    return "fuck"',
                            '',
                            'enabled_by_default = True']))


# Generated at 2022-06-26 04:53:31.077578
# Unit test for function fix_command
def test_fix_command():
    command = "echo \"cd ..\""
    args = types.Command(command, [])
    if fix_command(args) == "cd ..":
        return True
    else:
        return False



# Generated at 2022-06-26 04:53:38.044761
# Unit test for function fix_command
def test_fix_command():
    try:
        test_case_0()
        print('Test for fix_command has been passed!')
    except AssertionError as e:
        print(e)
    except Exception as e:
        print('Test for fix_command has been failed!')

if __name__ == '__main__':
    test_fix_command()

# Generated at 2022-06-26 04:53:53.052543
# Unit test for function fix_command
def test_fix_command():
    with mock.patch('os.environ.get') as get:
        get.return_value = None
        with mock.patch('sys.exit') as sys_exit:
            with mock.patch('os.path.isfile') as isfile:
                isfile.return_value = False
                with mock.patch('thefuck.settings.settings.init') as settings_init:
                    with mock.patch('thefuck.utils.get_alias') as get_alias:
                        get_alias.return_value = 'emacs'
                        with mock.patch('thefuck.utils.get_all_executables') as get_all_executables:
                            get_all_executables.side_effect = ['emacs']

# Generated at 2022-06-26 04:53:55.354694
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    assert_equal(fix_command(bytes_0), None)

# Generated at 2022-06-26 04:54:04.495691
# Unit test for function fix_command

# Generated at 2022-06-26 04:54:13.822860
# Unit test for function fix_command
def test_fix_command():
    known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    # known_args = types.SimpleNamespace(force_command=[])
    #

# Generated at 2022-06-26 04:54:17.706345
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)


# Generated at 2022-06-26 04:54:21.647822
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    #No exception thrown
    try:
        fix_command(bytes_0)
    except Exception:
        assert False == True

# Generated at 2022-06-26 04:54:26.223058
# Unit test for function fix_command
def test_fix_command():
    assert fix_command(None) == None
    assert fix_command(bytes(10)) == None
    assert fix_command(bytes(0)) == None
    assert fix_command(bytes(40)) == None

# Generated at 2022-06-26 04:54:29.697238
# Unit test for function fix_command
def test_fix_command():
    try:
        test_case_0()
    except:
        import sys
        print("In test case 0:")
        print("Unexpected error:", sys.exc_info()[0])
        assert False

test_fix_command()

# Generated at 2022-06-26 04:54:36.119157
# Unit test for function fix_command
def test_fix_command():
    arg_0 = None
    exception_0 = EmptyCommand
    # Call the function
    try:
        fix_command(arg_0)
    except EmptyCommand as e:
        var_0 = e
    # Check if exception was raised
    assert type(var_0) == type(exception_0)
    # Check if return value was expected
    assert var_0 == exception_0



# Generated at 2022-06-26 04:54:38.438032
# Unit test for function fix_command
def test_fix_command():
    try:
        test_case_0()
    except:
        logging.exception('Caught exception')

# Generated at 2022-06-26 04:54:52.980240
# Unit test for function fix_command
def test_fix_command():
    output_0 = 'Total'

# Generated at 2022-06-26 04:55:03.060271
# Unit test for function fix_command
def test_fix_command():

    cmd = 'ls'

    # Check for exception flag for function

# Generated at 2022-06-26 04:55:04.749030
# Unit test for function fix_command
def test_fix_command():
    # Test case #0
    try:
      test_case_0()
    except:
      print("[FAIL] Unable to test the function fix_command")

# Main function for unit tests

# Generated at 2022-06-26 04:55:05.703457
# Unit test for function fix_command
def test_fix_command():
    assert fix_command(settings.__dict__) == None



# Generated at 2022-06-26 04:55:08.123967
# Unit test for function fix_command
def test_fix_command():
    assert 1 == 1

if __name__ == '__main__':
    test_fix_command()

# Generated at 2022-06-26 04:55:09.881209
# Unit test for function fix_command
def test_fix_command():
    assert callable(fix_command)
    test_case_0()

# Generated at 2022-06-26 04:55:16.914485
# Unit test for function fix_command
def test_fix_command():
    fake_command = FakeRawCommand()
    fake_corrected_commands = FakeCorrectedCommands()
    fake_command.script = 'ls'
    fake_corrected_commands.corrected_commands = ['ls']
    correct_command = fix_command(fake_command)
    assert correct_command == "ls"


# Generated at 2022-06-26 04:55:19.847631
# Unit test for function fix_command
def test_fix_command():
    # First case test
    test_case_0()

test_fix_command()

# Generated at 2022-06-26 04:55:31.926522
# Unit test for function fix_command
def test_fix_command():
    from argparse import Namespace
    from ..types import Command
    from ..corrector import get_changed_for_path_alias, get_changed_for_script
    from unittest import mock
    history_command = 'echo "test"'
    os.environ['TF_HISTORY'] = history_command
    known_args = Namespace(
        alias='alias thefuck="thefuck"',
        debug=True,
        dry_run=False,
        no_colors=False,
        require_confirmation=False,
        settings_path=None,
        slow_commands=(),
        xtrace=False,
        wait_command=(),
        no_wait=False,
        respawn_cost=None,
        repeat=False)
    result = fix_command(known_args)
    assert result == None



# Generated at 2022-06-26 04:55:36.487423
# Unit test for function fix_command
def test_fix_command():
    assert callable(fix_command)


# Generated at 2022-06-26 04:55:46.860083
# Unit test for function fix_command
def test_fix_command():
    assert True, 'Unit test failed'

# Do the unit test!
test_fix_command()

# Generated at 2022-06-26 04:55:49.820296
# Unit test for function fix_command
def test_fix_command():
    assert fix_command(bytes_0) == var_0

# Generated at 2022-06-26 04:55:51.374788
# Unit test for function fix_command
def test_fix_command():
    assert True == True


test_case_0()

# Generated at 2022-06-26 04:55:59.285503
# Unit test for function fix_command
def test_fix_command():
    print("--Begin test for function fix_command")
    stdout = sys.stdout
    stdout_redirect = io.StringIO()
    sys.stdout = stdout_redirect
    test_case_0()
    sys.stdout = stdout
    stdout_text = stdout_redirect.getvalue()
    print("--End test for function fix_command")

# Generated at 2022-06-26 04:56:00.789220
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)
    assert var_0 == None

# Generated at 2022-06-26 04:56:11.677057
# Unit test for function fix_command

# Generated at 2022-06-26 04:56:15.295519
# Unit test for function fix_command
def test_fix_command():
    test_case_0()
    print('Test cases passed')


if __name__ == '__main__':
    test_fix_command()

# Generated at 2022-06-26 04:56:19.653177
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)
    print(var_0)

test_fix_command()

# Generated at 2022-06-26 04:56:29.253597
# Unit test for function fix_command
def test_fix_command():
    from test_thefuck.utils import capture_output
    from .arguments import parse_known_args

    # Tests case 1
    args = '-l --alias echo fck'
    with capture_output() as (stdout, stderr):
        sys.argv = args.split()
        known_args = parse_known_args()
        test_case_0()
        assert stdout.getvalue() == 'Corrected command: echo fck'
        assert stderr.getvalue() == ''
        # Tests case 2

# Generated at 2022-06-26 04:56:31.047068
# Unit test for function fix_command
def test_fix_command():
    os.system('python3.6 -m unittest test_fix_command')

# Generated at 2022-06-26 04:56:53.351312
# Unit test for function fix_command
def test_fix_command():
    test_case_0()


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(
        '--verbose --capture=no "{}" "{}"'.format(__file__, '-s')))

# Generated at 2022-06-26 04:56:57.629434
# Unit test for function fix_command
def test_fix_command():
    try:
        # write your test case here
        bytes_0 = None
        var_0 = fix_command(bytes_0)
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-26 04:57:01.277132
# Unit test for function fix_command

# Generated at 2022-06-26 04:57:03.721384
# Unit test for function fix_command
def test_fix_command():
    print ("Testing function fix_command")
    test_case_0()
    print ("Function fix_command passed all test cases")

# Generated at 2022-06-26 04:57:06.702954
# Unit test for function fix_command
def test_fix_command():
    assert test_case_0() == None

# Unit tests for module tf_fix

# Generated at 2022-06-26 04:57:07.322601
# Unit test for function fix_command
def test_fix_command():
    assert True


# Generated at 2022-06-26 04:57:08.700665
# Unit test for function fix_command
def test_fix_command():
    assert fix_command


# Generated at 2022-06-26 04:57:12.781481
# Unit test for function fix_command
def test_fix_command():
    var_1 = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        '__pycache__', 'sample_log_0.log'
    )
    var_2 = open(var_1, 'rb')
    var_3 = var_2.read()
    bytes_1 = None
    var_4 = fix_command(bytes_1)


# Generated at 2022-06-26 04:57:23.921224
# Unit test for function fix_command
def test_fix_command():
    from .. import conf
    from .. import corrector
    from .. import ui
    from .. import utils
    from .. import types
    from .. import exceptions
    from .. import logs
    from .. import const

    # Arrange
    original_Settings_init = conf.Settings.init
    def mock_Settings_init(self, system_binary, env, history_limit, wait_command, no_colors,
                           slow_commands, require_confirmation, exclude_rules,
                           require_confirmation_rules, env_profile, alter_history,
                           repeat, wait_slow_command, wait_command_interval,
                           use_alt_key):
        pass
    conf.Settings.init = mock_Settings_init

    original_get_corrected_commands = corrector.get_corrected_commands


# Generated at 2022-06-26 04:57:31.871611
# Unit test for function fix_command
def test_fix_command():
    try:
        # This is a generated test, therefore it might be wrong.
        # If you find an error, please let me know!
        # You can view the original test here:
        # https://github.com/guyzmo/thefuck/blob/e5a5776cee1c48d8f5a94603f200ab6cfa9f74a8/tests/scripts/test_fix_command.bash
        # print('test_1')
        # assert False
        test_case_0()
    except AssertionError:
        print('test_fix_command failed')

test_fix_command()

# Generated at 2022-06-26 04:58:11.248570
# Unit test for function fix_command
def test_fix_command():
    test_case_0()

# Generated at 2022-06-26 04:58:22.688713
# Unit test for function fix_command
def test_fix_command():
    # Testing Edge Case 0
    test_case_0()
    # Testing Edge Case 1
    bool_0 = True
    int_0 = 0x3f50c28f
    str_0 = ""
    bool_1 = True
    bool_2 = True
    float_0 = -100.0
    int_1 = 0x7b
    int_2 = 0xf
    bytes_0 = None
    fix_command(None)
    fix_command(bytes_0)
    fix_command(True)
    var_0 = fix_command(False)
    fix_command(bool_0)
    fix_command(int_0)
    fix_command(str_0)
    var_1 = fix_command(bool_1)
    var_2 = fix_command(bool_2)
    fix_command

# Generated at 2022-06-26 04:58:28.698774
# Unit test for function fix_command
def test_fix_command():
    # Make sure these variables are the same
    # e.g. var_1 should be var_0
    bytes_0 = None
    var_0 = fix_command(bytes_0)
    assert var_0 == var_0

# Generated at 2022-06-26 04:58:33.701895
# Unit test for function fix_command

# Generated at 2022-06-26 04:58:41.743559
# Unit test for function fix_command
def test_fix_command():
    var_0 = fix_command('')
    assert type(var_0) == ''
    assert var_0 is None
    var_1 = fix_command('')
    assert type(var_1) == ''
    assert var_1 is None
    var_2 = fix_command('')
    assert type(var_2) == ''
    assert var_2 is None
    var_3 = fix_command('')
    assert type(var_3) == ''
    assert var_3 is None

# Generated at 2022-06-26 04:58:46.590917
# Unit test for function fix_command
def test_fix_command():
    test_case_0()


# Generated at 2022-06-26 04:58:49.148378
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)
    assert var_0 == None


# Generated at 2022-06-26 04:58:57.918331
# Unit test for function fix_command
def test_fix_command():
    from collections import namedtuple
    from pprint import pformat

    KnownArgs = namedtuple('KnownArgs', [
        'force_command',
        'command'
    ])

    os.environ['TF_HISTORY'] = 'ls -a'
    bytes_0 = KnownArgs('', '')
    var_0 = fix_command(bytes_0)
    assert var_0 == None


# Generated at 2022-06-26 04:59:03.376985
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    assert fix_command(bytes_0) == None

if __name__ == '__main__':
    test_fix_command()
    test_case_0()

# Generated at 2022-06-26 04:59:05.593066
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)


# Generated at 2022-06-26 05:00:22.572841
# Unit test for function fix_command
def test_fix_command():
    # Generate inputs
    args_0 = bytes("RANDOM_SEED")
    args_1 = bytes("RANDOM_SEED")
    args_2 = bytes("RANDOM_SEED")
    args_3 = bytes("RANDOM_SEED")
    args_4 = bytes("RANDOM_SEED")
    args_5 = bytes("RANDOM_SEED")
    args_6 = bytes("RANDOM_SEED")
    args_7 = bytes("RANDOM_SEED")
    args_8 = bytes("RANDOM_SEED")
    args_9 = bytes("RANDOM_SEED")
    args_10 = bytes("RANDOM_SEED")
    args_11 = bytes("RANDOM_SEED")

# Generated at 2022-06-26 05:00:26.963811
# Unit test for function fix_command
def test_fix_command():
    with open(os.devnull, 'w') as devnull:
        with mock.patch('sys.stderr', devnull):
            test_case_0()

# Generated at 2022-06-26 05:00:28.075261
# Unit test for function fix_command
def test_fix_command():
    bytes_0 = None
    var_0 = fix_command(bytes_0)



# Generated at 2022-06-26 05:00:37.244269
# Unit test for function fix_command
def test_fix_command():
    from argparse import Namespace
    import random
    from .exceptions import EmptyCommand
    from .utils import set_log_level
    from .types import Command, WrongCommand
    from .corrector import get_corrected_commands
    from .ui import select_command
    from .conf import settings
    import fcntl
    import os
    import io

    def check_expect_output(case):
        def read_to_str(stream):
            data = stream.read().decode('utf8')
            stream.seek(0)
            stream.truncate()
            return data


# Generated at 2022-06-26 05:00:40.650221
# Unit test for function fix_command
def test_fix_command():
    try:
        test_case_0()
    except:
        pass

# main function get called when thefuck is called directly

# Generated at 2022-06-26 05:00:48.159018
# Unit test for function fix_command
def test_fix_command():
	param_0 = mock.MagicMock()
	assert fix_command(param_0) == 0
	param_0.force_command = u"echo"
	assert fix_command(param_0) == 0
	param_0.force_command = u"ls"
	assert fix_command(param_0) == 0