

# Generated at 2022-06-21 19:21:00.793913
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(
        lambda a: a + 1) == Maybe.just(
        lambda a: a + 1)
    assert Maybe.just(
        lambda a: Maybe.just(a + 1)) == Maybe.just(
        lambda a: Maybe.just(a + 1))
    assert Maybe.nothing().ap(Maybe.just([])) == Maybe.nothing()
    assert Maybe.nothing().ap(
        Maybe.just(lambda a: Maybe.just(a + 1))) == Maybe.nothing()

    assert Maybe.just(lambda a: Maybe.just(a + 1)).ap(
        Maybe.just(10)) == Maybe.just(11)

    assert Maybe.just(lambda a: Maybe.just(a + 1)).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:21:02.709824
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(4)
    assert maybe.get_or_else(0) == 4

    maybe = Maybe.nothing()
    assert maybe.get_or_else(0) == 0

# Generated at 2022-06-21 19:21:08.978312
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 1).get_or_else(None) == 1
    assert Maybe(1, False).filter(lambda x: x == 2).get_or_else(None) == None
    assert Maybe(1, True).filter(lambda x: x == 1).get_or_else(None) == None
    assert Maybe(1, True).filter(lambda x: x == 2).get_or_else(None) == None


# Generated at 2022-06-21 19:21:12.200758
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(10, False).bind(lambda x: Maybe(x + 10, False)) == Maybe(20, False)
    assert Maybe(None, True).bind(lambda x: Maybe(x, True)) == Maybe(None, True)


# Generated at 2022-06-21 19:21:15.889791
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:20.835483
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    def add2(x):
        return x + 2

    maybe_function = Maybe.just(add2)
    maybe_number = Maybe.just(2)

    # When
    actual = maybe_number.ap(maybe_function)

    # Then
    expected = Maybe.just(4)
    assert actual == expected


# Generated at 2022-06-21 19:21:26.363153
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) == Maybe.just(3)

# Generated at 2022-06-21 19:21:29.234776
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)

    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:21:34.730667
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x + 1) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(3).map(lambda x: x + 1).map(lambda x: x * 2) == Maybe.just(8)



# Generated at 2022-06-21 19:21:39.845636
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just('str')) == Maybe.just('str1')
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just('str1')) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Unit tests for Maybe class

# Generated at 2022-06-21 19:21:53.704012
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test for constructors
    a = Maybe(1, True)
    b = Maybe(1, False)
    assert a.value is None
    assert b.value is 1
    assert a.is_nothing is True
    assert b.is_nothing is False

    # Test for equality
    assert a == Maybe(None, True)
    assert b == Maybe(1, False)
    assert a != Maybe(None, False)
    assert b != Maybe(2, False)

    # Test for statically created
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) == Maybe(1, False)

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)

    assert Maybe

# Generated at 2022-06-21 19:21:58.793814
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    res = Maybe.just(True).to_try()
    assert res == Try(True, is_success=True)

    res = Maybe.nothing().to_try()
    assert res == Try(None, is_success=False)



# Generated at 2022-06-21 19:22:02.198927
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:22:08.247856
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(10, False).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(11)
    assert Maybe(10, False).bind(lambda x: Maybe.just(x / 0)) == Maybe.nothing()
    assert Maybe(None, True).bind(lambda x: Maybe.just(x)) == Maybe.nothing()

# Generated at 2022-06-21 19:22:17.460679
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)

    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()



# Generated at 2022-06-21 19:22:24.871063
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def func_to_maybe() -> Maybe[int]:
        return Maybe.just(1)

    assert func_to_maybe().to_lazy() == Lazy(lambda: 1)
    assert func_to_maybe().to_lazy() == Lazy(lambda: 1)
    assert func_to_maybe().to_lazy().call() == 1


# Generated at 2022-06-21 19:22:27.789769
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != 1


# Generated at 2022-06-21 19:22:30.225930
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(3) == 2
    assert Maybe.nothing().get_or_else(3) == 3
    assert Maybe.nothing().get_or_else(None) is None


# Generated at 2022-06-21 19:22:37.282981
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert \
        Maybe.just(lambda x: x * 2).ap(Maybe.just(3)) == \
        Maybe.just(6)

    assert \
        Maybe.nothing().ap(Maybe.just(3)) == \
        Maybe.nothing()

    assert \
        Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == \
        Maybe.nothing()



# Generated at 2022-06-21 19:22:44.424759
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Maybe(1, False).ap(Box(lambda x: x + 1)) == Box(2)
    assert Maybe(1, False).ap(Box(lambda x, y: x + y)).get_or_else(None) == 2

    assert Maybe(1, False).ap(Try(lambda x: x + 1, is_success=True)) == Try(2, is_success=True)
    assert Maybe(1, False).ap(Try(lambda x: x + 1, is_success=False)) == Try(None, is_success=False)

    assert Maybe(1, False).ap(Right(lambda x: x + 1)) == Right(2)

# Generated at 2022-06-21 19:22:48.869697
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either().is_right
    assert Maybe(1, False).to_either().right_value == 1


# Generated at 2022-06-21 19:22:52.541966
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    def is_positive(value: int) -> bool:
        return value > 0

    assert Maybe.just(10).filter(is_positive) == Maybe.just(10)
    assert Maybe.just(-10).filter(is_positive) == Maybe.nothing()
    assert Maybe.nothing().filter(is_positive) == Maybe.nothing()


# Generated at 2022-06-21 19:22:54.416313
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:22:57.215876
# Unit test for method map of class Maybe
def test_Maybe_map():
    def square(x: int) -> int:
        return x * x

    assert Maybe.just(2).map(square) == Maybe.just(4)
    assert Maybe.nothing().map(square) == Maybe.nothing()


# Generated at 2022-06-21 19:23:00.581404
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test case for method to_either of class Maybe.
    """
    maybe_1 = Maybe.just(2)
    maybe_2 = Maybe.nothing()

    assert maybe_1.to_either() == Right(2)
    assert maybe_2.to_either() == Left(None)



# Generated at 2022-06-21 19:23:06.508421
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1).is_nothing == False
    assert Maybe.nothing().is_nothing == True



# Generated at 2022-06-21 19:23:10.158014
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just(2).bind(lambda x: Maybe.just(x + 1))
    assert result == Maybe.just(3)
    result = Maybe.nothing().bind(lambda x: Maybe.just(x + 1))
    assert result == Maybe.nothing()



# Generated at 2022-06-21 19:23:16.854111
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_filterer(value):
        return value >= 10

    assert Maybe.just(10).filter(test_filterer) == Maybe.just(10)
    assert Maybe.just(30).filter(test_filterer) == Maybe.just(30)
    assert Maybe.just(3).filter(test_filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(test_filterer) == Maybe.nothing()



# Generated at 2022-06-21 19:23:19.253604
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(100, False) == Maybe.just(100)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:23:21.077664
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)

# Generated at 2022-06-21 19:23:30.235112
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert(Maybe.just(1).to_either() == Either.of(1))
    assert(Maybe.nothing().to_either() == Either.of(None))


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-21 19:23:34.364489
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.nothing()
    assert maybe.to_lazy() == Lazy(lambda: None)

    maybe = Maybe.just(123)
    assert maybe.to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-21 19:23:40.632644
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        if value > 5:
            return True
        return False

    assert Maybe.just(6).filter(filterer) == Maybe.just(6)
    assert Maybe.just(5).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()


# Generated at 2022-06-21 19:23:47.037095
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # given
    from pymonet.either import Left, Right
    maybe = Maybe.just(3)

    # when
    res = maybe.to_either()

    # then
    assert res == Right(3)

    # given
    maybe = Maybe.nothing()

    # when
    res = maybe.to_either()

    # then
    assert res == Left(None)


# Generated at 2022-06-21 19:23:53.228216
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test for map method.

    :returns: True if test successful
    :rtype: Boolean
    """
    assert Maybe.just(1).map(lambda a: a + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda a: a + 1).map(lambda a: a + 1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda a: a + 1) == Maybe.nothing()
    return True



# Generated at 2022-06-21 19:23:57.049552
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:03.254951
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # Arrange
    from pymonet.validation import Validation

    # Act
    maybe_not_empty = Maybe.just(True)
    maybe_empty = Maybe.nothing()

    # Assert
    assert maybe_not_empty.to_validation() == Validation.success(True)
    assert maybe_empty.to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:24:09.884362
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(4, False).filter(lambda x: x <= 5) == Maybe(4, False)
    assert Maybe(3, False).filter(lambda x: x <= 5).get_or_else(5) == 3
    assert Maybe.nothing().filter(lambda x: x <= 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x <= 5).get_or_else(5) == 5

# Generated at 2022-06-21 19:24:12.886797
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_one(n):
        return n + 1
    m = Maybe.just(1)
    assert m.ap(Maybe.just(add_one)) == Maybe.just(2)



# Generated at 2022-06-21 19:24:15.278617
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    box = Maybe.just(10)
    assert box.to_box() is not None


# Generated at 2022-06-21 19:24:26.330695
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    assert m1 == m2

    m3 = Maybe.nothing()
    m4 = Maybe.nothing()
    assert m3 == m4

    m5 = Maybe.just(2)
    m6 = Maybe.nothing()
    assert m5 != m6

    m7 = Maybe.just(None)
    m8 = Maybe.nothing()
    assert m7 != m8


# Generated at 2022-06-21 19:24:34.502325
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Returns Bool
    assert Maybe.just(2).bind(lambda x: x % 2 == 0) == Maybe.just(True)

    # Returns Bool
    assert Maybe.nothing().bind(lambda x: x) == Maybe.nothing()

    # Returns Int
    assert Maybe.just(2).bind(lambda x: x * 2) == Maybe.just(4)

    # Returns Int
    assert Maybe.nothing().bind(lambda x: x) == Maybe.nothing()

    # Returns String
    assert Maybe.just('a').bind(lambda x: x * 2) == Maybe.just('aa')

    # Returns String
    assert Maybe.nothing().bind(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-21 19:24:36.968981
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(12).to_either() == Right(12)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:24:39.424363
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:24:50.641235
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()

    assert Maybe.just(1).bind(lambda x: Left(x + 1)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Right(x + 1)) == Maybe.just(2)

# Generated at 2022-06-21 19:24:58.776147
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test Maybe.bind method.

    :returns: true if test passed else false
    :rtype: boolean
    """
    # Test empty Maybe
    assert Maybe.nothing().bind(None) == Maybe.nothing()
    # Test not empty Maybe
    x = Maybe.just(5).bind(lambda x: Maybe.just(x * 10) if x % 2 == 0 else Maybe.nothing())
    assert x == Maybe.just(50)
    # Test Maybe with not empty mapper
    x = Maybe.just(4).bind(lambda x: Maybe.just(x * 10) if x % 2 == 0 else Maybe.nothing())
    assert x == Maybe.just(40)
    return True


# Generated at 2022-06-21 19:25:01.054259
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:25:08.552814
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.
    """
    maybe = Maybe.just(1)
    assert maybe == maybe.filter(lambda x: x == 1)
    assert Maybe.nothing() == maybe.filter(lambda x: x == 2)

    maybe = Maybe.nothing()
    assert maybe == maybe.filter(lambda x: x == 1)
    assert maybe == maybe.filter(lambda x: x == 2)


# Generated at 2022-06-21 19:25:13.083168
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(Box(5)).to_lazy() == Lazy(lambda: Box(5))


# Generated at 2022-06-21 19:25:19.725819
# Unit test for method map of class Maybe
def test_Maybe_map():
    _assert(Maybe.just(1).map(lambda x: x + 1).value, 2)
    _assert(Maybe.just(1).map(lambda x: None).is_nothing, True)
    _assert(Maybe.nothing().map(lambda x: print(x)), None)
    _assert(Maybe.just('2').map(lambda x: int(x)).value, 2)
    _assert(Maybe.just(3).map(lambda x: x * x).value, 9)



# Generated at 2022-06-21 19:25:27.471793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(0).to_either() == Right(0)
    assert Maybe.nothing().to_either() == Left(None)

# Generated at 2022-06-21 19:25:30.828304
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return isinstance(value, int)
    assert Maybe.just(10).filter(filterer) == Maybe.just(10)
    assert Maybe.just('hey').filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()

# Generated at 2022-06-21 19:25:32.424256
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y

    assert Maybe.just(1).ap(Maybe.just(add(2))) == Maybe.just(3)



# Generated at 2022-06-21 19:25:37.128793
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: x + 1, False).ap(Maybe(1, False)) == Maybe(2, False)
    assert Maybe(lambda x: x + 1, True).ap(Maybe(1, False)) == Maybe(None, True)

# Generated at 2022-06-21 19:25:46.547151
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # get_or_else return value of not empty Maybe
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.just('test').get_or_else(1) == 'test'
    assert Maybe.just([1, 2]).get_or_else([]) == [1, 2]

    # get_or_else return default value for empty Maybe
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.nothing().get_or_else('test') == 'test'
    assert Maybe.nothing().get_or_else([1, 2]) == [1, 2]



# Generated at 2022-06-21 19:25:56.512574
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_identity import I
    from pymonet.box import Box
    from pymonet.monad_reader import Reader
    from pymonet.monad_writer import Writer
    from pymonet.monad_state import State
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    assert Maybe.just(4).ap(Maybe.just(lambda x: x + 2)) == Maybe.just(6)
    assert Maybe.just(4).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(lambda x: x + 2)) == Maybe.nothing()

# Generated at 2022-06-21 19:26:00.939261
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # when Maybe is not empty and filterer returns True
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    # when Maybe is not empty and filterer returns False
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    # when Maybe is empty and filterer returns True
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:26:04.567574
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:26:08.054553
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:26:14.667186
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    def validation_to_tuple(validation):
        return (validation.is_success, validation.value)

    assert validation_to_tuple(Maybe.just(1).to_validation()) == (True, 1)
    assert validation_to_tuple(Maybe.nothing().to_validation()) == (True, None)

# Unit tests for method ap of class Maybe

# Generated at 2022-06-21 19:26:26.986587
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:26:31.625331
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.just(4).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 4) == Maybe.nothing()


# Generated at 2022-06-21 19:26:39.326402
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.asserts import assert_equals
    assert_equals(Maybe.nothing(), Maybe.nothing())
    assert_equals(Maybe.just(1), Maybe.just(1))
    assert_equals(Maybe.just(1.0), Maybe.just(1.0))
    assert_equals(Maybe.just("asd"), Maybe.just("asd"))
    assert_equals(Maybe.just([1,2,3]), Maybe.just([1,2,3]))


# Generated at 2022-06-21 19:26:41.280641
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:26:44.684039
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:26:53.075452
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just("elixir").get_or_else("Haskell") == "elixir"
    assert Maybe.nothing().get_or_else("Haskell") == "Haskell"
    assert Maybe.just("elixir").get_or_else(None) == "elixir"
    assert Maybe.nothing().get_or_else(None) is None
    assert Maybe.just(10).get_or_else("Haskell") == 10
    assert Maybe.nothing().get_or_else("Haskell") == "Haskell"



# Generated at 2022-06-21 19:26:58.520009
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(add_one) == Maybe.just(2), 'Maybe.map do not work properly'
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3), 'Maybe.map do not work properly'
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing(), 'Maybe.map do not work properly'



# Generated at 2022-06-21 19:27:08.311615
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test for Maybe_bind.

    :returns: if test pass, return True, else False
    :rtype: boolean
    """
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    def add(x):
        return x + 8

    def add_try(x):
        return Try(add(x), True)

    functor_of_maybe = Maybe.just(2).map(add)
    monad_of_maybe = Maybe.just(2).bind(add_try)

    return isinstance(functor_of_maybe, Functor) and isinstance(monad_of_maybe, Try)



# Generated at 2022-06-21 19:27:11.555634
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(
        'value1'
    ).get_or_else(
        'default_value'
    ) == 'value1'

    assert Maybe.nothing().get_or_else(
        'default_value'
    ) == 'default_value'



# Generated at 2022-06-21 19:27:15.527863
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try

    # According to the test method returns empty Maybe when Maybe is empty
    assert Maybe.nothing().bind(lambda x: Try(x, True).to_maybe()) == Maybe.nothing()

    # According to the test method returns result of mapper function
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * 2)) == Maybe.just(4)



# Generated at 2022-06-21 19:27:42.305960
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(123).to_validation() == Validation.success(123)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:27:45.453203
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe(10, False)
    assert Maybe(10, True) == Maybe(10, True)
    assert Maybe(10, False) != Maybe(5, False)
    assert Maybe(10, False) != Maybe(10, True)


# Generated at 2022-06-21 19:27:52.568774
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value1 = 1
    value2 = 1.0
    value3 = "a"
    value4 = "A"

    assert Maybe.just(value1) == Maybe.just(value1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(value1) != Maybe.nothing()
    assert Maybe.just(value1) != Maybe.just(value2)
    assert Maybe.just(value3) == Maybe.just(value4)


# Generated at 2022-06-21 19:27:54.400510
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5).is_nothing == False
    assert Maybe.nothing().is_nothing == True


# Generated at 2022-06-21 19:28:03.718069
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    test_first_param = [
        (Maybe.just(1), Maybe.just(1), True),
        (Maybe.just(1), Maybe.just(2), False),
        (Maybe.just(1), Maybe.nothing(), False),
        (Maybe.nothing(), Maybe.just(1), False),
        (Maybe.nothing(), Maybe.nothing(), True)
    ]
    for first_param, second_param, expected in test_first_param:
        assert first_param.__eq__(second_param) == expected


# Generated at 2022-06-21 19:28:10.579124
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(1)
    res = m.filter(lambda x: x > 0)
    assert res == Maybe.just(1)
    res = m.filter(lambda x: x < 0)
    assert res == Maybe.nothing()
    m = Maybe.nothing()
    res = m.filter(lambda x: x > 0)
    assert res == Maybe.nothing()

# Generated at 2022-06-21 19:28:14.979352
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test function for constructor of class Maybe.

    :return: None
    :rtype: None
    """
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:28:24.205457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    just10 = Maybe.just(10)
    just30 = Maybe.just(30)
    nothing = Maybe.nothing()

    def moreThan25(x : int) -> bool:
        return x > 25

    moreThan25_Maybe = moreThan25(10)
    assert moreThan25_Maybe is False
    moreThan25_Maybe = moreThan25(30)
    assert moreThan25_Maybe is True

    assert just10.filter(moreThan25) == Maybe.nothing()
    assert just30.filter(moreThan25) == Maybe.just(30)
    assert nothing.filter(moreThan25) == Maybe.nothing()


# Generated at 2022-06-21 19:28:32.629065
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe.to_box method to create box from Maybe.

    :returns: None
    :rtype: NoneType
    """
    from pymonet.box import Box

    print('Unit test for method to_box of class Maybe')

    class_ = Maybe

    assert class_.just(3).to_box() == Box(3), \
        'To create Box with value 3 from Maybe.just'

    assert class_.nothing().to_box() == Box(None), \
        'To create Box with None from Maybe.nothing'

    print('Test pass')



# Generated at 2022-06-21 19:28:41.859171
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import List, Functor
    from pymonet.monoid import Monoid

    def mapper(x):
        return x + x

    assert Maybe.just(List([1, 2, 3, 4]).fmap(mapper)).ap(Maybe.just(mapper)) == \
        Maybe.just(List([1, 2, 3, 4]).fmap(mapper).fmap(mapper))

    assert Maybe.just(List([1, 2, 3, 4])).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(List([1, 2, 3, 4]))) == Maybe.nothing()



# Generated at 2022-06-21 19:29:09.128559
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test the method to_box of class Maybe.
    """
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)

# Generated at 2022-06-21 19:29:12.151920
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Right(None)


# Generated at 2022-06-21 19:29:15.996848
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('test').to_validation() == Validation.success('test')
    assert Maybe.nothing().to_validation() == Validation.success(None)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 19:29:22.850854
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import operator

    test_string_value = 'test_string'
    test_int_value = 10

    # bind: just
    assert Maybe.just(test_int_value)\
        .bind(lambda x: Maybe.just(operator.add(x, test_int_value)))\
        .get_or_else(-1) == 2 * test_int_value

    # bind: just
    assert Maybe.just(test_string_value)\
        .bind(lambda x: Maybe.just(x + test_string_value))\
        .get_or_else(-1) == test_string_value * 2

    # bind: nothing
    assert Maybe.nothing()\
        .bind(lambda x: Maybe.just(None)) == Maybe.nothing()

    # bind: just

# Generated at 2022-06-21 19:29:26.804428
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # pylint: disable=unused-variable
    bind_def = lambda x: Maybe.just(x + 10)
    assert Maybe.just(1).bind(bind_def) == Maybe.just(11)
    assert Maybe.nothing().bind(bind_def) == Maybe.nothing()



# Generated at 2022-06-21 19:29:31.239399
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    # Test for empty Maybe
    assert Maybe.nothing().to_either() == Left(None)

    # Test for notEmpty Maybe
    assert Maybe.just(2).to_either() == Right(2)



# Generated at 2022-06-21 19:29:33.147835
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().force() == 1
    assert Maybe.nothing().to_lazy().force() is None

# Generated at 2022-06-21 19:29:37.897525
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:29:43.009161
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    '''
    >>> from pymonet.either import Left, Right
    >>> from pymonet.maybe import Maybe

    >>> x = Maybe.just(1)
    >>> x.to_either() == Right(1)
    True

    >>> x = Maybe.nothing()
    >>> x.to_either() == Left(None)
    True
    '''


# Generated at 2022-06-21 19:29:45.259318
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(3)) == Maybe.just(4)
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()


# Generated at 2022-06-21 19:30:11.962383
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 3)
    lazy_none = Lazy(lambda: None)

    assert Maybe.just(3).to_lazy() == lazy_value
    assert Maybe.nothing().to_lazy() == lazy_none



# Generated at 2022-06-21 19:30:21.842999
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def test_to_either_with_empty_maybe():
        maybe = Maybe.nothing()
        expected_result = Left(None)
        actual_result = maybe.to_either()
        assert expected_result == actual_result

    def test_to_either_with_non_empty_maybe():
        some_value = 1
        maybe = Maybe.just(some_value)
        expected_result = Right(some_value)
        actual_result = maybe.to_either()
        assert expected_result == actual_result

    test_to_either_with_empty_maybe()
    test_to_either_with_non_empty_maybe()

# Generated at 2022-06-21 19:30:23.866070
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:30:26.219809
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.just("asdsa") == Maybe("asdsa", False)

    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:30:29.366163
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-21 19:30:38.055031
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    a = Maybe.just(12)
    b = Maybe.nothing()
    c = Maybe.just(11)

    def add100(x: int) -> Maybe[int]:
        return Maybe.just(x + 100)

    assert Maybe.just(112) == a.bind(add100)
    assert Maybe.nothing() == b.bind(add100)
    assert Maybe.just(111) == c.bind(add100)



# Generated at 2022-06-21 19:30:42.994897
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    try_ = Maybe.just(1).to_try()
    assert try_ == Try(1, is_success=True)

    try_ = Maybe.nothing().to_try()
    assert try_ == Try(None, is_success=False)

# Generated at 2022-06-21 19:30:45.361242
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(1, False).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()

# Generated at 2022-06-21 19:30:56.901977
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda a, b: a * b).ap(Maybe.just(3)).ap(Maybe.just(4)) == Maybe.just(12)
    assert Maybe.just(lambda a, b: a * b).ap(Maybe.nothing()).ap(Maybe.just(4)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)).ap(Maybe.just(4)) == Maybe.nothing()
    assert Maybe.just(lambda a, b: a * b).ap(Maybe.just(3)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda a, b: a * b).ap(Maybe.nothing()).ap(Maybe.nothing()) == Maybe.nothing()
