

# Generated at 2022-06-21 19:20:53.311867
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-21 19:20:57.159520
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:21:03.211431
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.nothing() == Maybe.nothing()

# Unit tests for map

# Generated at 2022-06-21 19:21:06.796355
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    f = lambda x: x == 1

    assert Maybe.just(1).filter(f).is_nothing == False
    assert Maybe.just(0).filter(f).is_nothing == True

# Test method ap of class Maybe

# Generated at 2022-06-21 19:21:09.522929
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:21:10.909275
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(5, False).to_box() == Box(5)



# Generated at 2022-06-21 19:21:21.888543
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    nothing = Maybe.nothing()
    just1 = Maybe.just(1)
    just2 = Maybe.just(2)
    maybe_result = nothing.bind(lambda x: nothing)
    assert maybe_result == nothing
    maybe_result = nothing.bind(lambda x: just1)
    assert maybe_result == nothing
    maybe_result = nothing.bind(lambda x: just2)
    assert maybe_result == nothing
    maybe_result = just1.bind(lambda x: nothing)
    assert maybe_result == nothing
    maybe_result = just1.bind(lambda x: just1)
    assert maybe_result == just1
    maybe_result = just1.bind(lambda x: just2)
    assert maybe_result == just2
    maybe_result = just2.bind(lambda x: nothing)

# Generated at 2022-06-21 19:21:27.992134
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    a = 1
    maybe_a = Maybe.just(a)
    maybe_b = Maybe.nothing()
    from pymonet.box import Box

    assert(maybe_a.to_box() == Box(a))
    assert(maybe_b.to_box() == Box(None))


# Generated at 2022-06-21 19:21:32.830609
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:21:36.610905
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(5).to_either() == Right(5)



# Generated at 2022-06-21 19:21:45.645880
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(1, False).bind(lambda k: Maybe.just(k * 2)) == Maybe(2, False)
    assert Maybe(1, False).bind(lambda k: Maybe.nothing()) == Maybe(None, True)
    assert Maybe(1, True).bind(lambda k: Maybe.just(k * 2)) == Maybe(None, True)


# Generated at 2022-06-21 19:21:50.529001
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    result = Maybe.just(1).to_either()
    assert isinstance(result, Right)
    assert result.value == 1

    result = Maybe.nothing().to_either()
    assert isinstance(result, Left)
    assert result.value is None



# Generated at 2022-06-21 19:21:55.239822
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import SuccessfulTry as Success
    from pymonet.monad_try import FailureTry as Failure

    assert Maybe.just(1).to_try() == Success(1)
    assert Maybe.nothing().to_try() == Failure(None)



# Generated at 2022-06-21 19:21:59.194433
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:22:05.538803
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(3)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-21 19:22:11.100441
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda _: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()



# Generated at 2022-06-21 19:22:15.594296
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    @Validate()
    def add(x):
        return x + 1

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:18.343223
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('hello') == Maybe.just('hello').to_lazy().value()
    assert Maybe.nothing() == Maybe.nothing().to_lazy().value()


# Generated at 2022-06-21 19:22:23.261886
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(42).to_either() == Maybe.just(42).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()

# Generated at 2022-06-21 19:22:26.142341
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-21 19:22:32.074906
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).to_lazy().run() == 10
    assert Maybe.nothing().to_lazy().run() == None


# Generated at 2022-06-21 19:22:41.872597
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test cases:
        1. maybe_a.is_nothing == True, maybe_b.is_nothing == True
        2. maybe_a.is_nothing == True, maybe_b.is_nothing == False
        3. maybe_a.is_nothing == False, maybe_b.is_nothing == True
        4. maybe_a.is_nothing == False, maybe_b.is_nothing == False
    """
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    class TrueFunctor(Functor[int]):
        def map(self, mapper: Callable[[int], U]) -> 'TrueFunctor[U]':
            return TrueFunctor()


# Generated at 2022-06-21 19:22:47.165241
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    result = Maybe(None, True).to_try()
    assert result == Try(None, is_success=False)

    result = Maybe(2, False).to_try()
    assert result == Try(2, is_success=True)



# Generated at 2022-06-21 19:22:51.891906
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x * 3) == Maybe.just(6)
    assert Maybe.just(2).map(lambda x: x / 2) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-21 19:22:59.166452
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad_try import Failure
    from pymonet.box import Box

    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1

    assert Maybe.just(Failure(RuntimeError('test'))).get_or_else(1) == Failure(RuntimeError('test'))
    assert Maybe.nothing().get_or_else(Failure(RuntimeError('test'))) == Failure(RuntimeError('test'))

    assert Maybe.just(Box(1)).get_or_else(1) == Box(1)
    assert Maybe.nothing().get_or_else(Box(1)) == Box(1)

# Generated at 2022-06-21 19:23:09.881703
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Test None value
    m = Maybe.just(None)
    assert m.map(lambda n: n * n) == Maybe.just(None)
    # Test integer value
    m_1 = Maybe.just(5)
    assert m_1.map(lambda n: n * n) == Maybe.just(25)
    # Test float value
    m_2 = Maybe.just(5.0)
    assert m_2.map(lambda n: n * n) == Maybe.just(25.0)
    # Test None value
    m_3 = Maybe.nothing()
    assert m_3.map(lambda n: n * n) == Maybe.nothing()



# Generated at 2022-06-21 19:23:15.587062
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(12) == Maybe(12, False)
    assert Maybe.just(12) != Maybe(12, True)
    assert Maybe.just(12) != Maybe(13, False)
    assert Maybe.just(12) != Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe(None, False)



# Generated at 2022-06-21 19:23:19.304442
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe(None, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)

# Generated at 2022-06-21 19:23:31.541459
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Unit test which tests Maybe.ap method.

    :returns: True when tests are passed
    :rtype: Boolean
    """

    from pymonet.validation import Validation

    assert Maybe.just(lambda a: a).ap(Maybe.just(2)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.just(lambda a: a).ap(Maybe.nothing()) == Maybe.nothing()

    assert Validation.success(lambda a: a).ap(Validation.success(2)) == Validation.success(2)
    assert Validation.failure([]).ap(Validation.success(2)) == Validation.failure([])
    assert Validation.success(lambda a: a).ap(Validation.failure([])) == Val

# Generated at 2022-06-21 19:23:36.112444
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # result of func to_try
    result = Maybe.just("apple").to_try()
    assert result.value == "apple"
    assert result.is_success

    result = Maybe.nothing().to_try()
    assert result.value is None
    assert not result.is_success

# Generated at 2022-06-21 19:23:44.052477
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: True) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-21 19:23:47.754155
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # given
    maybe = Maybe.just('some')

    # when
    result = maybe.to_lazy()

    # then
    assert result == Lazy(lambda: 'some')


# Generated at 2022-06-21 19:23:51.695729
# Unit test for method map of class Maybe
def test_Maybe_map():
    def inc(m):
        return m + 1

    print("Maybe.map(inc)")
    assert Maybe.just(1).map(inc) == Maybe.just(2)
    assert Maybe.nothing().map(inc) == Maybe.nothing()


# Generated at 2022-06-21 19:24:04.817888
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    try_nothing = Try.failure(None)

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() == None
    assert Maybe.just(1).to_lazy() == Lazy.unit(1)
    assert Maybe.nothing().to_lazy() == Lazy.unit(None)
    assert Maybe.just(1).to_lazy().map(lambda x: x + 1).get() == 2

# Generated at 2022-06-21 19:24:09.336151
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    monad_value = Maybe.just(1)
    assert monad_value.to_try() == Try(1, is_success=True)
    monad_nothing = Maybe.nothing()
    assert monad_nothing.to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:12.402700
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda x: x * 2) == Maybe.just(20)
    assert Maybe(10, True).map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-21 19:24:16.326902
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(0) == 5
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just("Hello").get_or_else("") == "Hello"
    assert Maybe.nothing().get_or_else("") == ""


# Generated at 2022-06-21 19:24:21.965255
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    expected_result = Validation.success(2)
    actual_result = Maybe.just(2).to_validation()
    assert expected_result == actual_result

    expected_result = Validation.success(None)
    actual_result = Maybe.nothing().to_validation()
    assert expected_result == actual_result


# Generated at 2022-06-21 19:24:24.250036
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just('test').to_validation() == Validation.success('test')
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:24:29.644158
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(1).to_box().value == 1

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.nothing().to_box().value == None


# Generated at 2022-06-21 19:24:38.297479
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert isinstance(Maybe.nothing().to_box(), Maybe)
    assert isinstance(Maybe.just('A').to_box(), Maybe)
    assert Maybe.nothing().to_box() == Maybe.nothing()
    assert Maybe.just('A').to_box() == Maybe.just('A')


# Generated at 2022-06-21 19:24:41.858638
# Unit test for method map of class Maybe
def test_Maybe_map():
    import pytest

    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    with pytest.raises(TypeError):
        Maybe.just(1).map(lambda x: x + 1, lambda x: x)



# Generated at 2022-06-21 19:24:53.261287
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just("Jakiś tekst") == Maybe("Jakiś tekst", False)
    assert Maybe.just("Jakiś tekst") == Maybe.just("Jakiś tekst")
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe(1, False) != Maybe("Jakiś tekst", False)
    assert Maybe(1, False) != Maybe("Jakiś tekst", True)

# Generated at 2022-06-21 19:24:55.844108
# Unit test for constructor of class Maybe
def test_Maybe():
    nothing = Maybe.nothing()
    assert nothing.is_nothing, 'Must be empty'
    assert type(nothing) is Maybe


# Generated at 2022-06-21 19:24:56.545879
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    pass

# Generated at 2022-06-21 19:25:00.715986
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from nose.tools import assert_equals
    assert_equals(
        Maybe.just(1).to_box(),
        Box(1)
    )
    assert_equals(
        Maybe.nothing().to_box(),
        Box(None)
    )


# Generated at 2022-06-21 19:25:05.143960
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe(None, True)



# Generated at 2022-06-21 19:25:08.336896
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Nothing().map(lambda x: x + 1) == Nothing()
    assert Some(2).map(lambda x: x + 1) == Some(3)


# Generated at 2022-06-21 19:25:14.363456
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just('a') != Maybe.just('b')
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('a') != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('a')
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:25:16.953678
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-21 19:25:26.378110
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Maybe
    assert (
        Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    ) == True
    assert (
        Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    ) == True

# Generated at 2022-06-21 19:25:28.749175
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:25:31.036953
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # given
    x = 1
    maybe = Maybe.just(x)
    # when
    result = maybe.to_box()
    # then
    assert result.get() == x



# Generated at 2022-06-21 19:25:34.252469
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filter method.
    """
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just("name").filter(lambda x: len(x) > 4) == Maybe.just("name")
    assert Maybe.just("name").filter(lambda x: len(x) > 20) == Maybe.nothing()


# Generated at 2022-06-21 19:25:46.299223
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.functor import Functor
    from pymonet.monad_maybe import Maybe, Nothing, Box
    from pymonet.validation import Validation

    def mapper_bind_test(maybe: Maybe[int]) -> Maybe[int]:
        return maybe.bind(lambda v: Maybe.just(v + 1))

    def mapper_map_test(maybe: Maybe[int]) -> Maybe[int]:
        return maybe.map(lambda v: v + 1)

    def mapper_Functor_test(maybe: Maybe[int]) -> Functor[Callable[[int], int]]:
        return maybe.map(lambda v: lambda _: v + 1)


# Generated at 2022-06-21 19:25:49.930115
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.just(2).get_or_else(1) != 1
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.nothing().get_or_else(1) != 2

# Generated at 2022-06-21 19:25:54.403092
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_one = Maybe.just(3)
    assert maybe_one == Maybe.just(3)
    assert maybe_one.value == 3

    maybe_two = Maybe.nothing()
    assert maybe_two == Maybe.nothing()
    assert maybe_two.is_nothing

test_Maybe()


# Unit tests for method map of class Maybe

# Generated at 2022-06-21 19:26:00.009664
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    # given
    success = Maybe.just(100)
    fail = Maybe.nothing()

    # when
    result = success.to_validation()
    result_fail = fail.to_validation()

    # then
    assert isinstance(result, Validation)
    assert result.is_success
    assert result.value == 100

    assert isinstance(result_fail, Validation)
    assert result_fail.is_success
    assert result_fail.value == None


# Generated at 2022-06-21 19:26:06.264282
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def foo():
        return 'bar'

    actual_maybe_lazy = Maybe.just(foo).to_lazy()

    expected_maybe_lazy = Lazy(foo)

    assert expected_maybe_lazy == actual_maybe_lazy

    actual_nothing_maybe_lazy = Maybe.nothing().to_lazy()

    expected_nothing_maybe_lazy = Lazy(lambda: None)

    assert expected_nothing_maybe_lazy == actual_nothing_maybe_lazy


# Generated at 2022-06-21 19:26:18.791738
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe = Maybe.just(2).to_lazy()  # Lazy[Int] = Lazy(<function <lambda> at 0x7f04c9d530d0>)

    assert isinstance(maybe, Lazy)
    assert maybe.get() == 2

    maybe = Maybe.nothing().to_lazy()  # Lazy[None] = Lazy(<function <lambda> at 0x7f04c9d530d0>)

    assert isinstance(maybe, Lazy)
    assert maybe.get() is None

    maybe = Maybe.just(2).to_lazy()  # Lazy[Int] = Lazy(<function <lambda> at 0x7f04c9d530d0>)


# Generated at 2022-06-21 19:26:33.131669
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just("just value").to_try() == Try("just value", is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:26:37.079090
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.just(42).filter(lambda x: x < 100) == Maybe.just(42)



# Generated at 2022-06-21 19:26:40.780418
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 19:26:47.547798
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe = Maybe.just(1)
    assert(maybe.to_try() == Try(1, is_success=True))

    maybe = Maybe.nothing()
    assert (maybe.to_try() == Try(None, is_success=False))


# Generated at 2022-06-21 19:26:54.778458
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of Maybe monad.
    """

    def __test_map(x: int) -> int:
        """
        Test map method.

        :param x: test value
        :type x: int
        :returns: x + 1
        """
        return x + 1

    assert Maybe.just(1).map(__test_map) == Maybe.just(2)
    assert Maybe.nothing().map(__test_map) == Maybe.nothing()



# Generated at 2022-06-21 19:27:02.411715
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert not Maybe.just(1).__eq__(Maybe.just(2))
    assert Maybe.just(1).__eq__(Maybe.just(2)) == Maybe.just(2).__eq__(Maybe.just(1))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert not Maybe.nothing().__eq__(Maybe.just(1))
    assert not Maybe.just(1).__eq__(Maybe.nothing())


# Generated at 2022-06-21 19:27:05.072917
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(23).get_or_else(42) == 23
    assert Maybe.nothing().get_or_else(42) == 42

# Generated at 2022-06-21 19:27:07.341413
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)


# Generated at 2022-06-21 19:27:09.702907
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(100) == 10
    assert Maybe.nothing().get_or_else(100) == 100



# Generated at 2022-06-21 19:27:12.219239
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("Hello").value == "Hello"
    assert Maybe.just("Hello").is_nothing == False
    assert Maybe.nothing().is_nothing == True
    assert Maybe.nothing().value == None



# Generated at 2022-06-21 19:27:39.401255
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(7).get_or_else('7') == 7
    assert Maybe.just(7).filter(lambda x: x > 5).get_or_else('7') == 7
    assert Maybe.nothing().get_or_else('7') == '7'



# Generated at 2022-06-21 19:27:46.932439
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Maybe.map with not empty Maybe and lambda function
    m = Maybe(123, False)
    result = m.map(lambda x: x * 2)
    assert result == Maybe.just(246)

    # Maybe.map with empty Maybe and lambda function
    result = Maybe.nothing().map(lambda x: x * 2)
    assert result == Maybe.nothing()

    # Maybe.map with not empty Maybe and function
    def f(x):
        return x * 2
    result = m.map(f)
    assert result == Maybe.just(246)

    # Maybe.map with empty Maybe and function
    result = Maybe.nothing().map(f)
    assert result == Maybe.nothing()


# Generated at 2022-06-21 19:27:56.016217
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Unit test for method get_or_else of class Maybe.
    """
    def test_nothing_get_or_else(default_value):
        """
        If Maybe is empty return default_value, in other case.

        :param default_value: value to return if Maybe is empty
        :type default_value: Any
        :returns: value of Maybe or default_value
        :rtype: A
        """
        # Given
        nothing = Maybe.nothing()

        # When
        actual = nothing.get_or_else(default_value)

        # Then
        assert actual == default_value


# Generated at 2022-06-21 19:28:00.251925
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(123, False) == Maybe.just(123)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe(123, False) != Maybe(123, True)


# Generated at 2022-06-21 19:28:03.609080
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    box = Maybe.just(1)
    maybe = Maybe.just(1)
    nothing = Maybe.nothing()

    assert box == maybe
    assert box != nothing
    assert maybe != nothing



# Generated at 2022-06-21 19:28:09.624135
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    result = Maybe.just('x').to_box()
    expected = Box('x')
    if result != expected:
        raise Exception(
            'Unit test failed: ' +
            str(result) +
            ' was expected to be ' +
            str(expected)
        )



# Generated at 2022-06-21 19:28:12.723485
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:28:17.261909
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(20) == Maybe.just(20)
    assert Maybe.just(1) != Maybe.just(10)

    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)



# Generated at 2022-06-21 19:28:21.609230
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe.
    """
    assert Maybe(3, False).to_validation() == Validation.success(3)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:28:24.962894
# Unit test for method map of class Maybe
def test_Maybe_map():
    f = lambda x: 2 * x
    assert Maybe.just(2).map(f) == Maybe.just(4)
    assert Maybe.nothing().map(f) == Maybe.nothing()



# Generated at 2022-06-21 19:29:16.392703
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Maybe.just(1).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()
    assert Maybe.just(1).to_either().left_value == Maybe.nothing().to_either().left_value



# Generated at 2022-06-21 19:29:21.577619
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x * 3) == Maybe.just(3)
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe.just(2)



# Generated at 2022-06-21 19:29:25.938149
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(4).to_box() == Box(4)
    assert Maybe.just(None).to_box() == Box(None)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:29:30.106574
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:29:40.312113
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation

    assert Maybe.just(lambda a: a + 1).ap(Maybe.just(5)) == Maybe.just(6)
    assert Maybe.just(lambda a: a + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe.just(lambda a: a + 1).ap(Validation.success(5)) == Maybe.just(6)
    assert Maybe.just(lambda a: a + 1).ap(Validation.fail(['Foo'])) == Maybe.nothing()


# Generated at 2022-06-21 19:29:42.243049
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    maybe_applicative = Maybe.just(lambda i: i+1)
    maybe_value = Maybe.just(2)

    # When
    result = maybe_value.ap(maybe_applicative)

    # Then
    assert result.value == 3


# Generated at 2022-06-21 19:29:46.328714
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x**2)) == Maybe.just(9)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x**2)) == Maybe.nothing()


# Generated at 2022-06-21 19:29:55.863472
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Maybe(3, False).bind(lambda x: Maybe.just(x)) == Maybe.just(3)
    assert Maybe(3, False).bind(lambda x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe(3, False).bind(lambda x: Validation.success(x)) == Validation.success(3)

# Generated at 2022-06-21 19:29:59.624375
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:30:06.103356
# Unit test for constructor of class Maybe
def test_Maybe():
    x = Maybe.just(2)
    assert isinstance(x, Maybe)
    assert x.value == 2
    assert x.is_nothing == False

    y = Maybe.nothing()
    assert isinstance(y, Maybe)
    assert y.is_nothing == True

    z = Maybe(1, False)
    assert isinstance(z, Maybe)
    assert z.value == 1
    assert z.is_nothing == False