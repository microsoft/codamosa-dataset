

# Generated at 2022-06-21 19:20:53.975931
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(0, False).map(lambda x: x + 1) == Maybe(1, False)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:20:57.388296
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    _assert_equals(Maybe.just(1).get_or_else(0), 1)
    _assert_equals(Maybe.nothing().get_or_else(0), 0)



# Generated at 2022-06-21 19:21:00.407162
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2).value == 2
    assert Maybe.nothing().is_nothing


# Generated at 2022-06-21 19:21:05.562683
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * x) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x + x) == Maybe.just(4)
    assert Maybe.just(6).map(lambda x: x - x) == Maybe.just(0)



# Generated at 2022-06-21 19:21:09.784179
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(None).ap(Maybe.just(1)) == Maybe.just(None)
    assert Maybe.just(1).ap(Maybe.just(None)) == Maybe.just(None)
    assert Maybe.just(None).ap(Maybe.just(None)) == Maybe.just(None)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.just(None)
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.just(None)


# Generated at 2022-06-21 19:21:12.434435
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-21 19:21:16.168727
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:21:23.271064
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe(lambda x: x + 3, False).ap(Lazy(lambda: 2)) == Right(5)
    assert Maybe(lambda x: x + ' something', False).ap(Box('something')) == Box('something something')
    assert Maybe(None, True).ap(Box(5)) == Box(None)

# Generated at 2022-06-21 19:21:24.936227
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    print("Unit test for method to_box of class Maybe")
    assert(Maybe.just(1).to_box() == Box(1))
    assert(Maybe.nothing().to_box() == Box(None))
    print("Unit test success.")
    print()


# Generated at 2022-06-21 19:21:30.641991
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 10)) == Maybe.just(15)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 10)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:35.647834
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(4).to_box() == Box(4)


# Generated at 2022-06-21 19:21:39.648009
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.box import Box
    from pymonet.validation import Validation, Success, Failure

    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Box.success(None)

Maybe.Nothing = Maybe.nothing
Maybe.Just = Maybe.just

# Generated at 2022-06-21 19:21:46.455776
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)



# Generated at 2022-06-21 19:21:49.698045
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(2).to_either() == Right(2)

# Generated at 2022-06-21 19:21:51.919728
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(1, True).to_box() == Box(None)

# Generated at 2022-06-21 19:21:58.067217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x > 0).filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-21 19:22:01.666144
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(53).get_or_else(12) == 53
    assert Maybe.nothing().get_or_else(12) == 12



# Generated at 2022-06-21 19:22:09.752264
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe1 = Maybe.just(lambda value: value ** 2)
    maybe2 = Maybe.just(4)
    assert maybe1.ap(maybe2) == Maybe.just(16)
    assert maybe2.ap(Maybe.nothing()) == Maybe.nothing()
    maybe_value = Maybe.nothing()
    assert maybe1.ap(maybe_value) == Maybe.nothing()

test_Maybe_ap()


# Generated at 2022-06-21 19:22:13.695010
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(3)
    assert maybe.to_lazy() == Lazy(lambda: 3)
    maybe1 = Maybe.nothing()
    assert maybe1.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:22:19.052245
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.box import Box

    f = lambda: 'str'
    l = Box(f)
    m = Maybe(1, False)
    assert Validation.success(1) == m.to_validation(), 'm should be Maybe(1)'
    maybe_none = Maybe.nothing()
    assert Validation.success(None) == maybe_none.to_validation(), 'Maybe none should be Maybe(None)'


# Generated at 2022-06-21 19:22:25.058391
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:22:27.506831
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:22:32.595237
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(None).map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:22:41.111554
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # When
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    m3 = Maybe.just("1")
    m4 = Maybe.nothing()
    m5 = Maybe.just("1")
    m6 = Maybe.just("1")

    # Then
    assert m1 == m2
    assert m2 == m1
    assert m1 != m3
    assert m3 != m1
    assert m1 != m4
    assert m4 != m1
    assert m3 == m5
    assert m5 == m3
    assert m4 == m4
    assert m5 == m6
    assert m6 == m5



# Generated at 2022-06-21 19:22:46.388684
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.list import List

    def sum_values(a: int, b: int) -> int:
        return a + b

    def sum_maybe_values(maybe_a: Maybe[int], maybe_b: Maybe[int]) -> Maybe[int]:
        return maybe_a.bind(
            lambda a: maybe_b.map(
                lambda b: a + b
            )
        )

    assert sum_maybe_values(Maybe.just(1), Maybe.just(2)) == Maybe.just(3)
    assert sum_maybe_values(Maybe.just(1), Maybe.nothing()) == Maybe.nothing()
    assert sum_maybe_values(Maybe.nothing(), Maybe.just(2)) == Maybe.nothing()
    assert sum_maybe_values(Maybe.nothing(), Maybe.nothing()) == Maybe.nothing()

# Unit

# Generated at 2022-06-21 19:22:49.349847
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(2) == 3
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-21 19:22:52.823196
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda val: Maybe.just(val * 2)) == Maybe.just(4)
    assert Maybe.just(2).bind(lambda val: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:22:54.756998
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:22:56.957670
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-21 19:23:02.408635
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe

    :returns: Nothing
    :rtype: None
    :raises AssertionError:
    """
    try:
        from pymonet.validation import Validation
        assert Validation.success(None) == Maybe.just(1).to_validation()
        assert Validation.success(2) == Maybe.just(2).to_validation()
        assert Validation.success(None) == Maybe.nothing().to_validation()
    except AssertionError:
        print("test_Maybe_to_validation - AssertionError")
        raise AssertionError


# Generated at 2022-06-21 19:23:08.870993
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:23:13.151468
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.just(1).second().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:23:15.496335
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just(4)
    assert maybe.value == 4
    assert maybe.is_nothing is False



# Generated at 2022-06-21 19:23:17.984560
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def foo():
        return 5

    lazy_maybe = Maybe.just(foo).to_lazy()
    assert lazy_maybe.force()() == 5
    assert Maybe.nothing().to_lazy().force() is None

# Generated at 2022-06-21 19:23:20.592353
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:26.855025
# Unit test for method map of class Maybe
def test_Maybe_map():
    f = lambda x: x
    g = lambda x: x + 1

    assert Maybe(2, False).map(f) == Maybe(2, False)
    assert Maybe(2, False).map(g) == Maybe(3, False)
    assert Maybe.nothing().map(f) == Maybe.nothing()
    assert Maybe.nothing().map(g) == Maybe.nothing()


# Generated at 2022-06-21 19:23:30.320367
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Maybe.just(1).to_validation(), Validation)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:23:34.520533
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_unit = Lazy(lambda: 3)
    assert Maybe.just(3).to_lazy() == lazy_unit
    assert Maybe.nothing().to_lazy() == lazy_unit



# Generated at 2022-06-21 19:23:41.669995
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    add2 = Maybe.just(lambda x: x + 2)
    mult2 = Maybe.just(lambda x: x * 2)
    result1 = Maybe.just(1).ap(add2).ap(mult2)
    result2 = result1.ap(Maybe.nothing())
    assert Maybe.just(6).__eq__(result1)
    assert Maybe.nothing().__eq__(result2)


# Unit tests for method map of class Maybe

# Generated at 2022-06-21 19:23:45.752108
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:23:53.043560
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe = Maybe.just(11)
    assert maybe.to_try() == Try(11, is_success=True)
    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:23:56.558676
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(2).to_try() == Try(2)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:01.470348
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-21 19:24:02.664788
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:24:06.075703
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-21 19:24:16.682344
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test for `ap` method of class Maybe
    """
    class AddOne:
        """
        Simple class for testing
        """

        def __init__(self, value: int) -> None:
            self.value = value

        def __call__(self, other: int) -> int:
            return self.value + other

    class SubOne:
        """
        Simple class for testing
        """

        def __init__(self, value: int) -> None:
            self.value = value

        def __call__(self, other: int) -> int:
            return self.value - other

    maybe1 = Maybe.just(AddOne(2))
    maybe2 = Maybe.just(SubOne(3))
    maybe3 = Maybe.just(SubOne(4))


# Generated at 2022-06-21 19:24:23.133998
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Lazy(lambda: Right(10)) == Maybe.just(10).to_lazy()
    assert Lazy(lambda: Right(None)) == Maybe.just(None).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Unit tests for method to_try of class Maybe

# Generated at 2022-06-21 19:24:28.049790
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    def multiply(value: int) -> int: return value * 2

    def add(value: int) -> int: return value + 3

    m = Maybe.just(multiply)
    result = m.ap(Maybe.just(add))
    assert result.value == multiply(add(0))
    assert result.is_nothing == False

# Generated at 2022-06-21 19:24:31.111908
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:24:37.008574
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2
    try:
        assert Maybe.just(1).get_or_else(raise_error()) == 1
    except Exception as e:
        assert str(e) == 'Error'
    else:
        assert False
    try:
        assert Maybe.nothing().get_or_else(raise_error()) == 2
    except Exception as e:
        assert str(e) == 'Error'
    else:
        assert False

# Generated at 2022-06-21 19:24:47.854752
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    
    :returns: Nothing
    :rtype: Nothing
    """

    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:24:54.390234
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy
    lazy = Maybe.just(3).to_lazy()
    assert isinstance(lazy, pymonet.lazy.Lazy), "Maybe.to_lazy() does not return Lazy"
    assert lazy() == 3, "Maybe.to_lazy() does not return Lazy with the same value"
    assert Maybe.nothing().to_lazy()() is None, "Maybe.to_lazy() does not return Lazy with None"



# Generated at 2022-06-21 19:24:58.693077
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = Just(1).filter(lambda x: x == 1)
    assert test_value == Just(1)

    test_value = Just(1).filter(lambda x: x == 2)
    assert test_value == Nothing

    test_value = Nothing.filter(lambda x: x == 1)
    assert test_value == Nothing


# Generated at 2022-06-21 19:25:05.632617
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.just(1).map(lambda x: x + 2).filter(lambda x: x != 3) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 3) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 3).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

    assert Maybe.just(1).to_either

# Generated at 2022-06-21 19:25:09.898413
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe1 = Maybe.just(1)
    assert maybe1.get_or_else(2) == 1

    maybe2 = Maybe.nothing()
    assert maybe2.get_or_else(2) == 2


# Generated at 2022-06-21 19:25:14.110128
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v <= 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda v: v > 0) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda v: v <= 0) == Maybe.nothing()



# Generated at 2022-06-21 19:25:16.701633
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:25:27.752464
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test method bind of class Maybe

    :return: Boolean
    """
    global_var = [None]

    _bind = lambda x: Maybe.just(x * 2)
    _map = lambda val: Maybe.just(val * 3)
    _map2 = lambda val: Maybe.just(val * 10)
    _map3 = lambda: Maybe.just(1000)

    # test for case when Maybe is not empty
    val = Maybe.just(10)

    def case1(value, result):
        global_var[0] = value
        return result

    val = val.bind(_bind)
    val = val.bind(_map)
    val = val.bind(_map2)

    assert val == Maybe.just(600)
    assert global_var[0] == 20
    assert case1(100, 200)

# Generated at 2022-06-21 19:25:31.321568
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.nothing()
    result = maybe.map(lambda x: x + 1)
    expected = Maybe.nothing()
    assert result == expected

    maybe = Maybe.just(1)
    result = maybe.map(lambda x: x + 1)
    expected = Maybe.just(2)
    assert result == expected


# Generated at 2022-06-21 19:25:40.728014
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_add_one = Maybe.just(lambda a: a + 1)
    assert maybe_add_one.ap(Maybe.just(2)) == Maybe.just(3)

    maybe_add_one = Maybe.nothing()
    assert maybe_add_one.ap(Maybe.just(2)) == Maybe.nothing()

    maybe_add_one = Maybe.just(lambda a: a + 1)
    assert maybe_add_one.ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:25:57.262973
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != Try(1, is_success=True)
    assert Maybe.nothing() != Try(1, is_success=False)
    assert Try(1, is_success=True) != Maybe.just(1)
    assert Try(1, is_success=False) != Maybe.nothing()


# Generated at 2022-06-21 19:26:01.177757
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, False).to_either() == Right(None)

    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:26:04.448951
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()



# Generated at 2022-06-21 19:26:11.618687
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure as TryFailure

    assert (Maybe.just(1).to_try() ==
            Try(1, is_success=True))
    assert (Maybe.nothing().to_try() ==
            Try(None, is_success=False))



# Generated at 2022-06-21 19:26:15.022331
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:26:17.127635
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Maybe.nothing()



# Generated at 2022-06-21 19:26:20.987922
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:26:22.756380
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:26:32.081949
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    :returns: Nothing
    :rtype: None
    :raises AssertionError: when one of test fails
    """
    def mapper(x):
        if x == 0 or x == 1 or x == 10 or x == 11 or x == 12 or x == 13 or x == 14 or x == 15 or x == 16 or x == 17 or x ==18 or x == 19:
            return Maybe.just(x)
        return Maybe.nothing()

    assert mapper(0).bind(mapper) == Maybe.just(0)
    assert mapper(1).bind(mapper) == Maybe.just(1)
    assert mapper(10).bind(mapper) == Maybe.just(10)
    assert mapper(2).bind(mapper) == Maybe.nothing()


# Generated at 2022-06-21 19:26:36.417713
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert (Maybe.just(1).to_try()) == Try(1, is_success=True)
    assert (Maybe.nothing().to_try()) == Try(None, is_success=False)

# Generated at 2022-06-21 19:26:54.386693
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter.

    :returns: None
    """
    # pylint: disable=unused-variable
    maybe = Maybe.nothing()
    actual = maybe.filter(lambda x: True)
    expected = Maybe.nothing()

    assert actual == expected

    maybe = Maybe.just(1)
    actual = maybe.filter(lambda x: x == 2)
    expected = Maybe.nothing()

    assert actual == expected

    maybe = Maybe.just(1)
    actual = maybe.filter(lambda x: x == 1)
    expected = Maybe.just(1)

    assert actual == expected



# Generated at 2022-06-21 19:27:02.553106
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1).value == 1
    assert Maybe.nothing().value is None
    assert Maybe.just(1) is not Maybe.just(1)
    assert Maybe.nothing() is not Maybe.nothing()


# Unit tests for methods of class Maybe

# Generated at 2022-06-21 19:27:04.420279
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    maybe = Maybe.just(10)

    # when
    new_maybe = maybe.filter(lambda x: x % 2 == 0)

    # then
    assert maybe != new_maybe
    assert new_maybe == Maybe.just(10)


# Generated at 2022-06-21 19:27:08.225957
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Test map of not empty Maybe
    assert Maybe.just(1).map(lambda r: r + 1) == Maybe.just(2)

    # Test map of empty Maybe
    assert Maybe.nothing().map(lambda r: r + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:27:12.456668
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x).ap(Maybe.just(10)) == Maybe.just(10)
    assert Maybe.just(lambda x: x).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(10)) == Maybe.nothing()


# Generated at 2022-06-21 19:27:16.548391
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:27:19.896897
# Unit test for method map of class Maybe
def test_Maybe_map():
    # when Maybe is empty
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    # when Maybe is not empty
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)



# Generated at 2022-06-21 19:27:23.444921
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:27:27.914362
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe_just = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    assert 1 == maybe_just.get_or_else(0)
    assert 0 == maybe_nothing.get_or_else(0)



# Generated at 2022-06-21 19:27:32.856819
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from nose.tools import assert_equals

    def _to_int(x: str) -> Maybe[int]:
        val = int(x)
        return Maybe.just(val)

    assert_equals(Maybe.just('1').bind(_to_int), Maybe.just(1))
    assert_equals(Maybe.nothing().bind(_to_int), Maybe.nothing())



# Generated at 2022-06-21 19:28:03.928644
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # function to multiply by 2
    def times2(x: int) -> int:
        return x * 2

    # function to square value
    def square(x: int) -> int:
        return x**2

    func_to_ap = Maybe.just(times2)

    # Test Maybe with Maybe[Function]
    result = Maybe.just(2).ap(func_to_ap)
    expected = Maybe.just(4)
    assert result == expected

    # Test Maybe with Either[Function] where Either is Right

# Generated at 2022-06-21 19:28:07.686930
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-21 19:28:10.828405
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:28:15.079659
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    successful_maybe = Maybe.just("test")
    assert successful_maybe.to_validation() == Validation("test")

    fail_maybe = Maybe.nothing()
    assert fail_maybe.to_validation() == Validation(None)

# Generated at 2022-06-21 19:28:16.365062
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)

# Generated at 2022-06-21 19:28:18.956969
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.nothing().get_or_else(1) == 1)
    assert(Maybe.just(10).get_or_else(1) == 10)

# Generated at 2022-06-21 19:28:22.460823
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.utils import eq

    assert eq(Maybe.just(2).get_or_else(5), 2)
    assert eq(Maybe.nothing().get_or_else(5), 5)



# Generated at 2022-06-21 19:28:29.105383
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    maybe = Maybe.just(True)

    assert maybe.to_either() == Right(True)

    maybe = Maybe.nothing()

    assert maybe.to_either() == Left(None)

    try_ = Try(True)

    assert maybe.to_either() == try_.to_either()


# Generated at 2022-06-21 19:28:38.663274
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # swap elements of list with list of strings value
    def test_mapper(val: list) -> Maybe[list]:
        return Maybe.just(
            ifilter(
                lambda el: isinstance(el, str), val
            )
        )

    # test empty list
    assert Maybe.bind(Maybe.just([]), test_mapper) == Maybe.just([])

    # test list with strings
    assert Maybe.bind(Maybe.just(['a', 2, 'b', 3]), test_mapper) == Maybe.just(['a', 'b'])

    # test list without strings
    assert Maybe.bind(Maybe.just([5, 6]), test_mapper) == Maybe.just([])

    # test empty Maybe
    assert Maybe.bind(Maybe.nothing(), test_mapper) == Maybe.nothing()


# Unit

# Generated at 2022-06-21 19:28:48.560918
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    def mod_3(number):
        return number % 3 == 0

    # When
    maybe_with_6 = Maybe.just(6)
    maybe_with_9 = Maybe.just(9)
    maybe_with_8 = Maybe.just(8)
    maybe_with_none = Maybe.nothing()

    # Then
    assert maybe_with_6.filter(mod_3) == Maybe.just(6)
    assert maybe_with_9.filter(mod_3) == Maybe.just(9)
    assert maybe_with_8.filter(mod_3) == Maybe.nothing()
    assert maybe_with_none.filter(mod_3) == Maybe.nothing()


test_Maybe_filter()

# Generated at 2022-06-21 19:29:12.581712
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either.

    :returns: result of test
    :rtype: bool
    """
    from pymonet.either import Left, Right

    maybe = Maybe.just(2)
    assert maybe.to_either() == Right(2)
    maybe = Maybe.nothing()
    assert maybe.to_either() == Left(None)


# Generated at 2022-06-21 19:29:16.054105
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    maybe = Maybe.just(lambda x: x + 3)
    try_ = Try(2, is_success=True)
    assert maybe.ap(try_).get_or_else(None) == 5


# Generated at 2022-06-21 19:29:22.345295
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Test function which will be applied to Maybe
    def add(value: int) -> Maybe[int]:
        return Maybe.just(value + 1)

    assert add(1).bind(add) == Maybe.just(3)
    assert add(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(add) == Maybe.nothing()
    assert (
            Maybe.just(1)
            .bind(lambda val: Maybe.just(val))
            .bind(lambda val: Maybe.just(val))
            .bind(lambda val: Maybe.just(val))
            .bind(lambda val: Maybe.just(val))
    ) == Maybe.just(1)



# Generated at 2022-06-21 19:29:25.305294
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()



# Generated at 2022-06-21 19:29:28.754434
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:29:41.085240
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.test_utils import assert_maybe_equal

    assert_maybe_equal(
        Maybe.just(lambda x: x + 1).ap(Maybe.just(True)),
        Maybe.just(True + 1)
    )

    assert_maybe_equal(
        Maybe.just(lambda x: x + 1).ap(Maybe.just(False)),
        Maybe.just(False + 1)
    )

    assert_maybe_equal(
        Maybe.just(lambda x: x + 1).ap(Maybe.nothing()),
        Maybe.nothing()
    )

    assert_maybe_equal(
        Maybe.nothing().ap(Maybe.just(True)),
        Maybe.nothing()
    )

    assert_maybe_equal(
        Maybe.nothing().ap(Maybe.just(False)),
        Maybe.nothing()
    )



# Generated at 2022-06-21 19:29:47.324438
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda x: x + 1) == Maybe.just(11)
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe(None, True).map(lambda x: None) == Maybe.nothing()
    assert Maybe(10, False).map(lambda x: None) == Maybe.just(None)



# Generated at 2022-06-21 19:29:52.650276
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x / 2) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-21 19:30:01.099128
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def f1(x: int) -> Maybe[int]:
        return Maybe.just(x * 2)
    def f2(x: int) -> Maybe[int]:
        return Maybe.just(x * 4)
    def f3(x: int) -> Maybe[int]:
        return Maybe.nothing()

    assert Maybe.just(2).bind(f1).bind(f2) == Maybe.just(16)
    assert Maybe.just(2).bind(f1).bind(f2).bind(f3) == Maybe.nothing()
    assert Maybe.just(2).bind(f3) == Maybe.nothing()


# Generated at 2022-06-21 19:30:02.675958
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy().run()() == 1

# Generated at 2022-06-21 19:30:45.960126
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right

    def concat(s1: str, s2: str) -> str:
        return ''.join([s1, s2])

    maybe = Maybe.just(concat)

    assert maybe.ap(Left('World')) == Maybe.nothing()
    assert maybe.ap(Right('Hello ')) == Maybe.just('Hello World')

# Generated at 2022-06-21 19:30:50.167922
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0
