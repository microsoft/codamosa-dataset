

# Generated at 2022-06-21 19:20:55.704781
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # TODO: add more examples
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:21:00.281603
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    value1 = 42
    value2 = 'frunzel'
    assert Maybe.just(value1).to_validation() == Validation.success(value1)
    assert Maybe.just(value2).to_validation() == Validation.success(value2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:02.510576
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(4).to_try() == Try(4, is_success=True)

# Generated at 2022-06-21 19:21:05.877105
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test for method ap of class Maybe[A].

    :returns: None
    :rtype: None
    """
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:07.417487
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # when
    actual = Maybe.just(3).get_or_else(2)

    # then
    assert actual == 3


# Generated at 2022-06-21 19:21:12.158347
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1).value == 1

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().is_nothing == True

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)



# Generated at 2022-06-21 19:21:15.566764
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(1, True).to_box() == Box(None)


# Generated at 2022-06-21 19:21:19.928953
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert(Maybe.just('abc').to_box() == Box('abc'))
    assert(Maybe.nothing().to_box() == Box(None))


# Generated at 2022-06-21 19:21:31.466028
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def function(x):
        return x * 2

    def function_erroneous():
        raise Exception('Error')

    assert Maybe.just(2).ap(Maybe.just(function)) == Maybe.just(4)
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(function)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(2).ap(Right(function)) == Right(4)

# Generated at 2022-06-21 19:21:34.773686
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(None, True).to_try() == Try(None, False)

# Generated at 2022-06-21 19:21:42.728016
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.box import BoxError

    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.just("test").to_box() == Box("test")
    assert Maybe.nothing().to_box() ==  Box(None)


# Generated at 2022-06-21 19:21:45.395568
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy().force() == Maybe.just(5).value

# Generated at 2022-06-21 19:21:48.422050
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just("some value").to_either() == Right("some value")


# Generated at 2022-06-21 19:21:52.010849
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monoid import Sum, Product

    assert Maybe.just(Sum(10)).to_lazy().value() == 10
    assert Maybe.nothing().to_lazy().value() is None



# Generated at 2022-06-21 19:21:54.791711
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:21:59.989754
# Unit test for method map of class Maybe
def test_Maybe_map():
    # given
    maybe = Maybe.just(10)
    multiple_by_two = lambda x: x * 2
    # when
    new_maybe = maybe.map(multiple_by_two)
    # then
    assert new_maybe == Maybe.just(20), "Map not working."



# Generated at 2022-06-21 19:22:06.914190
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    def add_one(el: int) -> int:
        return el + 1

    def multiply_two(el: int) -> int:
        return el * 2

    assert Maybe.just(add_one).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(add_one).ap(Maybe.just(1)).ap(Maybe.just(multiply_two)) == Maybe.just(4)
    assert Maybe.just(add_one).ap(Maybe.nothing()).ap(Maybe.just(multiply_two)) == Maybe.nothing()
    assert Maybe.just(add_one).ap(Maybe.nothing()).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:22:12.988209
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-21 19:22:17.679883
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.just(None).to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:22:24.250492
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_func = Maybe.just(lambda x: x + 1)
    maybe_value = Maybe.just(1)

    assert maybe_func.ap(maybe_value).get_or_else(None) == 2
    assert maybe_func.ap(Maybe.nothing()).get_or_else(None) is None



# Generated at 2022-06-21 19:22:29.016396
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(10, False)
    assert m.value == 10
    assert m.is_nothing == False
    assert m == Maybe.just(10)
    assert m != Maybe.nothing()



# Generated at 2022-06-21 19:22:40.358819
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # GIVEN
    nothing = Maybe.nothing()
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    # WHEN
    empty_nothing_nothing = nothing.ap(nothing)
    nothing_nothing_maybe_1 = nothing.ap(maybe_1)
    nothing_maybe_1_maybe_2 = maybe_1.ap(maybe_2)
    nothing_maybe_1_empty_nothing = maybe_1.ap(nothing)
    # THEN
    assert empty_nothing_nothing == Maybe.nothing()
    assert nothing_nothing_maybe_1 == Maybe.nothing()
    assert nothing_maybe_1_maybe_2 == Maybe.just(2)
    assert nothing_maybe_1_empty_nothing == Maybe.nothing()



# Generated at 2022-06-21 19:22:45.186404
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:22:47.666035
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:22:50.853265
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:22:53.727067
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(2, False).map(lambda x: x ** 2) == Maybe(4, False)
    assert Maybe(None, True).map(lambda x: x ** 2) == Maybe(None, True)


# Generated at 2022-06-21 19:22:56.339183
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:22:57.999109
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:23:01.324960
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test simple case
    assert Maybe(5, False).value == 5
    assert Maybe(5, False).is_nothing == False

    # Test raising exception
    with pytest.raises(AttributeError):
        Maybe(None, True).value
    assert Maybe(None, True).is_nothing == True


# Generated at 2022-06-21 19:23:12.855026
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test Maybe.just
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(0) == Maybe(0, False)

    # Test Maybe.nothing
    assert Maybe.nothing() == Maybe(None, True)

    # Test Maybe.__eq__
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just([]) == Maybe.just([])

    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(0)
    assert Maybe.just([1, 2, 3]) != Maybe.just([])
    assert Maybe.just([1, 2, 3]) != Maybe.just([1, 2, 3, 4])

   

# Generated at 2022-06-21 19:23:29.802033
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    # None is a value of any object
    result = Maybe.just(None).bind(lambda x: Maybe.just(x))

    assert isinstance(result, Maybe)
    assert result == Maybe.just(None)

    # None is a value of any object
    result = Maybe.just(3).bind(
        lambda x: Maybe.just(x / 0)
    )

    assert isinstance(result, Maybe)
    assert result == Maybe.just(float('inf'))

    # None is a value of any object
    result = Maybe.nothing().bind(
        lambda x: Maybe.nothing()
    )

    assert isinstance(result, Maybe)
    assert result == Maybe.nothing()

    # None is a value of any object
    result = Maybe.just(3).bind(
        lambda x: Maybe.nothing()
    )



# Generated at 2022-06-21 19:23:34.363812
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:23:38.091704
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) != Maybe.nothing()


# Generated at 2022-06-21 19:23:40.714885
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.just(0) != Maybe.nothing()


# Generated at 2022-06-21 19:23:52.306605
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test for bind for Maybe class.
    :returns: None
    """
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def bind_lambda(x):
        return Maybe.just(x+1)

    def bind_lambda2(x):
        return Try.unit(x+1)

    def bind_lambda3(x):
        return Either.right(x+1)

    def bind_lambda4(x):
        return Box.unit(x+1)

    def bind_lambda5(x):
        return Lazy(lambda: x+1)

    maybe = Maybe.just(1)
    maybe1 = maybe.bind(bind_lambda)

# Generated at 2022-06-21 19:23:58.440113
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(None).to_validation().value == None
    assert Maybe.nothing().to_validation().value is None
    assert not Maybe.nothing().to_validation().is_failure()
    assert Maybe.just(1).to_validation().value == 1
    assert not Maybe.just(1).to_validation().is_failure()

# Generated at 2022-06-21 19:24:06.562273
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    maybe_one = Maybe.just(5)
    maybe_two = Maybe.just(2)
    maybe_three = Maybe.nothing()

    def filterer(value: int) -> bool:
        if value < 5:
            return True
        return False

    assert Functor(maybe_one, maybe_two, maybe_three).map(lambda x: x.filter(filterer)) == \
        [Maybe.nothing(), Maybe.just(2), Maybe.nothing()] and \
        maybe_one.filter(filterer) == Maybe.nothing()

# Generated at 2022-06-21 19:24:12.163368
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.just(7) == Maybe.just(7))
    assert (Maybe.nothing() == Maybe.nothing())
    assert (Maybe.just(7) != Maybe.just(6))
    assert (Maybe.just(7) != Maybe.nothing())
    assert (Maybe.nothing() != Maybe.just(6))



# Generated at 2022-06-21 19:24:16.437851
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(True)
    assert m1.filter(lambda x: x) == Maybe.just(True)
    m2 = Maybe.just(False)
    assert m2.filter(lambda x: x) == Maybe.nothing()
    m3 = Maybe.nothing()
    assert m3.filter(lambda x: x) == Maybe.nothing()

# Generated at 2022-06-21 19:24:26.330735
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.monad_list import List
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(10).filter(lambda v: v > 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda v: v > 9) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda v: v > 9) != Maybe.just(20)
    assert Maybe.just(10).filter(lambda v: v > 9) != Maybe.nothing()
    assert Maybe.just(10).filter(lambda v: v > 9).to_box() == Box(10)

# Generated at 2022-06-21 19:24:34.265477
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    assert(
        Maybe.just(5).to_either() == Right(5)
    )

    assert(
        Maybe.nothing().to_either() == Left(None)
    )

# Generated at 2022-06-21 19:24:38.699239
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    f = Maybe.just(lambda x: x + x)

    assert f.ap(Maybe.just(10)) == Maybe.just(20)
    assert f.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(f) == Maybe.nothing()

    assert Maybe.just(10).ap(Maybe.just(lambda x: x + x)) == Maybe.just(20)


# Generated at 2022-06-21 19:24:40.297970
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:44.144062
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe("Hi", False).to_validation() == Validation.success("Hi")
    assert Maybe(None, True).to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:24:47.404567
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() is None



# Generated at 2022-06-21 19:24:51.387301
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == (Left(None))
    assert Maybe.just(5).to_either() == (Right(5))
    assert Maybe.just(None).to_either() == (Right(None))



# Generated at 2022-06-21 19:24:53.195306
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(333) == Maybe.just(333)
    assert Maybe.just(333) == Maybe(333, False)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:25:05.098289
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.box import Box

    # Test for success case
    assert Maybe(42, False) == Maybe.just(42) \
        == Maybe.nothing().bind(lambda: Maybe.just(42)).bind(lambda x: Maybe.just(x))

    # Test for empty case
    assert Maybe(None, True) == Maybe.nothing() \
        == Box(Maybe.just(42)).filter(lambda x: x % 5 == 0).get_or_else(Maybe.nothing())

    # Test for bad arguments
    try:
        assert Maybe(42, True) == Maybe.just(42)
    except AssertionError:
        pass

    try:
        assert Maybe(42, False) == Maybe.nothing()
    except AssertionError:
        pass


# Generated at 2022-06-21 19:25:11.080307
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 10) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(None) == Maybe.nothing()


# Generated at 2022-06-21 19:25:13.974073
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-21 19:25:22.497585
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe(None, True)


# Generated at 2022-06-21 19:25:24.637977
# Unit test for constructor of class Maybe
def test_Maybe():

    assert Maybe.just('test') == Maybe('test', False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:25:27.873932
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("thing") == Maybe.just("thing")
    assert Maybe.just("thing") != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just("thing")


# Generated at 2022-06-21 19:25:33.740675
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pymonet.validation as vl

    def separate_even_odd(number: int) -> vl.Validation[int, str]:

        def is_even(value: int) -> vl.Validation[int, str]:
            if value % 2 == 0:
                return vl.success(value)
            return vl.failure('Value is not even')

        return is_even(number).bind(vl.success)

    assert Maybe.just(2).to_validation() == separate_even_odd(2)
    assert Maybe.just(4).to_validation() == separate_even_odd(4)

    assert Maybe.nothing().to_validation() == vl.success(None)



# Generated at 2022-06-21 19:25:41.286561
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Maybe.just(2).to_try() == Try(2, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(Lazy(lambda: 2)).to_try() == Try(2, is_success=True)



# Generated at 2022-06-21 19:25:44.897322
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(10).map(lambda a: a * 5) == Maybe.just(50)
    assert Maybe.nothing().map(lambda a: a * 5) == Maybe.nothing()



# Generated at 2022-06-21 19:25:49.388228
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


if __name__ == '__main__':
    test_Maybe_ap()

# Generated at 2022-06-21 19:25:53.030290
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_1 = Maybe.just(1)
    maybe_1_copy = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    assert maybe_1 == maybe_1_copy
    assert maybe_1 != maybe_2



# Generated at 2022-06-21 19:25:57.133467
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def _(x):
        return 'ok'

    assert Maybe.just(_).ap(Maybe.just(None)) == Maybe.just('ok')
    assert Maybe.just(_).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(None)) == Maybe.nothing()  # type: ignore


# Generated at 2022-06-21 19:26:06.634550
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.maybe import Maybe

    maybe = Maybe.just('test')
    try_test = maybe.to_try()

    assert isinstance(try_test, Try)
    assert isinstance(try_test, Success)
    assert not isinstance(try_test, Failure)
    assert try_test.value == 'test'
    assert try_test.is_success == True

    maybe2 = Maybe.nothing()
    try_test2 = maybe2.to_try()

    assert isinstance(try_test2, Try)
    assert isinstance(try_test2, Failure)
    assert not isinstance(try_test2, Success)
    assert try_

# Generated at 2022-06-21 19:26:14.971254
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:26:19.031601
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(10).bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.just(20)

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.nothing()



# Generated at 2022-06-21 19:26:26.302159
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(
        lambda x: Maybe.just(x + 2)
    ) == Maybe.just(4)

    assert Maybe.just(2).bind(
        lambda x: Maybe.just(None)
    ) == Maybe.just(None)

    assert Maybe.just(2).bind(
        lambda x: Maybe.just(x)
    ) == Maybe.just(2)

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x + 2)
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(None)
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:26:30.263728
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_func():
        return 1

    maybe = Maybe.just(lazy_func)
    lazy = maybe.to_lazy()
    assert(isinstance(lazy, Lazy))
    assert(lazy.value() == lazy_func)


# Generated at 2022-06-21 19:26:40.217498
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y

    success_maybe_add_maybe_value = Maybe.just(add)(Maybe.just(1))
    assert Maybe.just(2).equals(success_maybe_add_maybe_value)

    fail_maybe_add_maybe_value = Maybe.just(add)(Maybe.nothing())
    assert Maybe.nothing().equals(fail_maybe_add_maybe_value)

    fail_maybe_add_maybe_value_twice = Maybe.nothing().ap(Maybe.just(add))
    assert Maybe.nothing().equals(fail_maybe_add_maybe_value_twice)

test_Maybe_ap()

# Generated at 2022-06-21 19:26:51.828024
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test for class Maybe
    """
    # Create maybe with value and check if it is not nothing
    maybe_val = Maybe(10, False)
    assert not maybe_val.is_nothing

    # Create maybe with value and check if it is not nothing
    maybe_other = Maybe.just(10)
    assert not maybe_other.is_nothing

    # Create nothing maybe and check if it is nothing
    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.is_nothing

    # Create nothing maybe and check if it is nothing
    maybe_nothing = Maybe(None, True)
    assert maybe_nothing.is_nothing



# Generated at 2022-06-21 19:26:57.464793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe.

    :returns: None
    :rtype: None
    """

    from pymonet.either import Either

    # Test with non empty Maybe
    assert Maybe.just(1).to_either() == Either.right(1)

    # Test with empty Maybe
    assert Maybe.nothing().to_either() == Either.left(None)


# Generated at 2022-06-21 19:27:00.357361
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:27:06.638595
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # Given
    some_maybe = Maybe.just('some')
    nothing_maybe = Maybe.nothing()
    # When
    some_try = some_maybe.to_try()
    nothing_try = nothing_maybe.to_try()
    # Then
    assert some_try.is_success()
    assert some_try.get_value() == 'some'
    assert not nothing_try.is_success()
    assert nothing_try.get_value() is None


# Generated at 2022-06-21 19:27:08.873923
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:27:16.767798
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:27:23.297481
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe = Maybe.just(1)
    maybe2 = Maybe.just(2)
    maybe3 = Maybe.just(3)
    maybe_none = Maybe.nothing()

    # When
    maybe = maybe.filter(lambda x: x > 1)
    maybe2 = maybe2.filter(lambda x: x > 1)
    maybe3 = maybe3.filter(lambda x: x > 1)
    maybe_none = maybe_none.filter(lambda x: x > 1)

    # Then
    assert maybe.is_nothing
    assert maybe2.is_nothing
    assert maybe3.value == 3
    assert maybe_none.is_nothing



# Generated at 2022-06-21 19:27:33.768001
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x - 2) == Maybe.just(0)
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x / 2) == Maybe.just(1)
    assert Maybe.just(2).map(lambda x: x / 0) == Maybe.just(float('inf'))
    assert Maybe.just('abc').map(lambda x: x + 'c') == Maybe.just('abcc')
    assert Maybe.just('abc').map(lambda x: x + 'c') == Maybe.just('abcc')

test_Maybe_map()


# Generated at 2022-06-21 19:27:38.067933
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:27:41.511144
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just("asdf") == Maybe("asdf", False)


# Generated at 2022-06-21 19:27:44.626407
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Test for empty Maybe
    assert Maybe.nothing().get_or_else(2) == 2
    # Test for not empty Maybe
    assert Maybe.just(1).get_or_else(2) == 1



# Generated at 2022-06-21 19:27:49.950326
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # test with not empty Maybe
    assert Maybe.just(42).to_try() == Try(42, is_success=True)

    # test with empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:27:56.641590
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("Scala") == Maybe.just("Scala")
    assert Maybe.just("Haskell") != Maybe.just("Scala")
    assert Maybe.just("Haskell") != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

# Unit tests for Maybe.map method of class Maybe

# Generated at 2022-06-21 19:28:01.444028
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    def validate_maybe(m):
        return m.to_either()

    assert validate_maybe(Maybe.just(1)) == Right(1)
    assert validate_maybe(Maybe.nothing()) == Left(None)


# Generated at 2022-06-21 19:28:05.100979
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:28:16.485937
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    def func_that_may_throw():
        raise Exception("My custom exception")

    assert Maybe.just("foo").to_either() == Right("foo")
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(func_that_may_throw).to_either() == Right(func_that_may_throw)


# Generated at 2022-06-21 19:28:28.368312
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.reader import Reader, ReaderT
    from pymonet.monad_writer import Writer, WriterT

    """
        Reader
    """

    def read_value(num: int) -> str:
        return str(num)

    def read_value_two(num: int) -> int:
        return num % 2

    reader_num = Reader(lambda ctx: 5)
    reader_num_even = Reader(lambda ctx: 4)
    reader_num_odd = Reader(lambda ctx: 5)

    reader_num_mapped = reader_num.map(read_value)
    reader_num_even_mapped = reader_num_even.map(read_value_two)
    reader_num_odd_mapped = reader_num_odd.map(read_value_two)

    assert reader

# Generated at 2022-06-21 19:28:30.174327
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    check_Maybe_bind_test(Maybe.just(0), 0)
    check_Maybe_bind_test(Maybe.just(0), 1, expected_is_exception=True)
    check_Maybe_bind_test(Maybe.nothing(), 0)


# Generated at 2022-06-21 19:28:37.333175
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit test for method map of class Maybe.
    Function returns new Maybe with double value of previous Maybe.
    """
    # Test for empty Maybe
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * 2).is_nothing

    # Test for not empty Maybe
    assert Maybe.just(5).map(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.just(5).map(lambda x: x * 2).is_nothing is False


# Generated at 2022-06-21 19:28:40.867519
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(2).to_either() == _Either.right(2)
    assert Maybe.nothing().to_either() == _Either.left(None)



# Generated at 2022-06-21 19:28:50.686239
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    instance1 = Maybe(0, False)
    instance2 = Maybe(0, False)
    instance3 = Maybe(0, True)
    instance4 = Maybe(1, False)
    instance5 = Maybe(1, True)
    instance6 = Maybe(None, True)
    instance7 = Maybe(None, True)
    instance8 = Maybe(None, False)

    assert instance1 != instance2
    assert instance1 != instance3
    assert instance2 != instance3
    assert instance1 != instance4
    assert instance2 != instance4
    assert instance3 != instance4
    assert instance3 != instance5
    assert instance5 != instance6
    assert instance7 != instance6
    assert instance7 != instance8



# Generated at 2022-06-21 19:28:53.883305
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1) and \
        Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:28:56.680668
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)

# Generated at 2022-06-21 19:28:59.875759
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:29:03.901812
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:29:18.593092
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:29:25.026249
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(100).filter(lambda el: el == 100) == Maybe.just(100)
    assert Maybe.just("Hello").filter(lambda el: el == "Hello") == Maybe.just("Hello")
    assert Maybe.just("Hello").filter(lambda el: el == "world") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda el: el == "world") == Maybe.nothing()



# Generated at 2022-06-21 19:29:37.004197
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # pylint: disable=unused-argument
    def test(a: int, b: int) -> int:
        return a * b

    assert Maybe.just(test).ap(Maybe.just(2)).ap(Maybe.just(3)).get_or_else(None) == 6
    assert Maybe.just(test).ap(Maybe.nothing()).ap(Maybe.just(2)).get_or_else(None) is None
    assert Maybe.just(test).ap(Maybe.just(2)).ap(Maybe.nothing()).get_or_else(None) is None
    assert Maybe.nothing().ap(Maybe.just(test)).ap(Maybe.nothing()).get_or_else(None) is None
    assert Maybe.nothing().ap(Maybe.just(test)).ap(Maybe.nothing()).get_or_else(None)

# Generated at 2022-06-21 19:29:39.258161
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-21 19:29:42.348983
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:29:47.887314
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe.to_box
    """
    box = Maybe.just(3).to_box()
    assert isinstance(box, Box)
    assert box.get_value() == 3

    box = Maybe.nothing().to_box()
    assert isinstance(box, Box)
    assert box.get_value() is None



# Generated at 2022-06-21 19:29:52.334461
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert(Maybe.just(1).to_lazy() == Lazy(lambda: 1))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-21 19:29:54.299930
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:30:05.448559
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    m = Maybe(5, False)
    m_n = Maybe(5, True)

    def inc(a):
        return a + 1

    # Applicative with Maybe
    assert m.ap(Maybe.just(inc)) == Maybe.just(6)
    assert m_n.ap(Maybe.just(inc)) == Maybe.nothing()
    assert m.ap(Maybe.nothing()) == Maybe.nothing()
    assert m_n.ap(Maybe.nothing()) == Maybe.nothing()

    # Applicative with Either
    assert m.ap(Right(inc)) == Maybe.just(6)

# Generated at 2022-06-21 19:30:08.806743
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just('str').bind(lambda x: Maybe.just(x))
    assert result == Maybe.just('str')

    result = Maybe.nothing().bind(lambda x: Maybe.just(x))
    assert result == Maybe.nothing()



# Generated at 2022-06-21 19:30:36.621975
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # Test not empty Maybe
    assert Maybe.just(1).to_try() == Try(1, is_success=True)

    # Test empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:30:45.960741
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    @Maybe.just
    def test(x):
        return x

    @Maybe.just
    def test_mapper(x):
        return x + 1

    @Maybe.just
    def test_nothing(x):
        return Maybe.nothing()

    @Maybe.nothing
    def test_nothing_mapper(x):
        return x + 1

    assert (Maybe.just(123).bind(test_mapper) == Maybe.just(124))
    assert (Maybe.just(123).bind(test_nothing) == Maybe.nothing())
    assert (Maybe.nothing().bind(test_mapper) == Maybe.nothing())
    assert (Maybe.nothing().bind(test_nothing) == Maybe.nothing())


# Generated at 2022-06-21 19:30:52.518952
# Unit test for constructor of class Maybe
def test_Maybe():
    res = Maybe.just(3)
    assert(res == Maybe.just(3))
    assert(res != Maybe.just(4))
    assert(res != Maybe.nothing())
    assert(Maybe.nothing() == Maybe.nothing())
    assert(res.value == 3)
