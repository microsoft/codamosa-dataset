

# Generated at 2022-06-21 19:20:50.237724
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('value') == Maybe.just('value')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just('value')
    assert Maybe.just('value') != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('value')
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:20:54.861883
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)  # Positive case
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()  # Positive case


# Generated at 2022-06-21 19:20:58.860717
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-21 19:21:05.874688
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # checking the success of the bind method
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2 + 1)
    # checking the success of the bind method
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.just({'a': 'q'}).bind(lambda a: Maybe.just(a['a'])) == Maybe.just('q')



# Generated at 2022-06-21 19:21:10.887196
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def increment(number):
        return number + 1

    def multiply(number1, number2):
        return number1 * number2

    def add_str(first_str, second_str):
        return first_str + second_str

    assert Maybe.nothing().ap(Maybe.just(increment)) == Maybe.nothing()
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(increment).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(multiply).ap(Maybe.just(2)).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just(add_str).ap(Maybe.just("foo")).ap(Maybe.just("bar")) == Maybe.just("foobar")

# Generated at 2022-06-21 19:21:16.860630
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x ** 2) == Maybe.just(1)
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.just(1).map(lambda x: '') == Maybe.just('')
    assert Maybe.nothing().map(lambda x: 1) == Maybe.nothing()


# Generated at 2022-06-21 19:21:20.643218
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy_test import LazyTest
    assert LazyTest(Maybe.just(1).to_lazy()) == LazyTest(lambda: 1)
    assert LazyTest(Maybe.nothing().to_lazy()) == LazyTest(lambda: None)



# Generated at 2022-06-21 19:21:23.681916
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box.nothing()
    assert Maybe.just(5).to_box() == Box(5)


# Generated at 2022-06-21 19:21:30.276582
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('value').to_validation() == Validation.success('value')
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:34.556774
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def add(number):
        return Maybe.just(number + 1)

    assert Maybe.just(1).bind(add) == Maybe.just(2)
    assert Maybe.nothing().bind(add) == Maybe.nothing()



# Generated at 2022-06-21 19:21:44.878772
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def test_binder(value):
        if value % 2 == 0:
            return Maybe.just(value / 2)
        return Maybe.nothing()

    assert Maybe.just(4).bind(test_binder) == Maybe.just(2)
    assert Maybe.just(5).bind(test_binder) == Maybe.nothing()
    assert Maybe.nothing().bind(test_binder) == Maybe.nothing()


# Generated at 2022-06-21 19:21:49.845535
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:22:01.414699
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    def try_as_maybe(try_value):
        if try_value.is_success():
            maybe_result = Maybe.just(try_value.value)
        else:
            maybe_result = Maybe.nothing()
        return maybe_result

    def maybe_as_try(maybe_value):
        if maybe_value.is_nothing:
            try_result = Try(None, is_success=False)
        else:
            try_result = Try(maybe_value.value, is_success=True)

        return try_result

    assert(maybe_as_try(Maybe.just(5)) == Try(5, is_success=True))
    assert(maybe_as_try(Maybe.nothing()) == Try(None, is_success=False))

# Generated at 2022-06-21 19:22:06.889952
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_function = Maybe.just(lambda x: x * 2)
    maybe_arg = Maybe.just(2)
    maybe_result = maybe_function.ap(maybe_arg)
    assert maybe_result == Maybe.just(4)

    maybe_function = Maybe.nothing()
    maybe_arg = Maybe.just(3)
    maybe_result = maybe_function.ap(maybe_arg)
    assert maybe_result == Maybe.nothing()

    maybe_function = Maybe.just(lambda x: x * 2)
    maybe_arg = Maybe.nothing()
    maybe_result = maybe_function.ap(maybe_arg)
    assert maybe_result == Maybe.nothing()



# Generated at 2022-06-21 19:22:14.111679
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    five = Maybe.just(5)
    assert five.to_box() == Box(5)
    assert five.to_box().to_maybe() == Maybe.just(5)

    empty = Maybe.nothing()
    assert empty.to_box() == Box(None)
    assert empty.to_box().to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:22:16.869904
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2) == Maybe.just(2).to_box()
    assert Maybe.nothing() == Maybe.nothing().to_box()


# Generated at 2022-06-21 19:22:22.310390
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    maybe_success = Maybe.just(1)
    assert maybe_success.to_validation() == Validation.success(1)

    maybe_fail = Maybe.nothing()
    assert maybe_fail.to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:22:30.763077
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test Maybe.ap method

    :returns: True when test failed and False when test passed
    :rtype: Boolean
    """
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add(x: int, y: int) -> int:
        return x + y

    def square(x: int) -> int:
        return x * x

    def fail(x: int) -> int:
        raise Exception('Fail')

    maybe = Maybe.just(2)

    assert maybe.ap(Maybe.just(add)) == Maybe.just(add(2, 2))

    assert maybe.ap(Maybe.just(square)) == Maybe

# Generated at 2022-06-21 19:22:38.853617
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, True) != Maybe(10, True)

    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(2) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)

# Test methods of class Maybe

# Generated at 2022-06-21 19:22:44.420727
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe(42, False).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:49.765078
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('Hello').get_or_else('world') == 'Hello'
    assert Maybe.nothing().get_or_else('world') == 'world'



# Generated at 2022-06-21 19:22:52.774728
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:22:55.693324
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.just(None).to_try() == Try(None, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-21 19:22:57.964898
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe(None, True)



# Generated at 2022-06-21 19:23:01.030021
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right, Left

    assert Maybe.just(lambda x: x + 1).ap(Right(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Left(2)) == Maybe.nothing()



# Generated at 2022-06-21 19:23:04.663304
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda v: v == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v == 1) == Maybe.nothing()

# Generated at 2022-06-21 19:23:08.169371
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-21 19:23:10.247098
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:19.578235
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    add_one = lambda x: Box(x + 1)

    sum_string_duplicate = lambda x: Try(x + x, is_success=True)

    assert add_one(5) == Box(6)
    assert add_one(5).bind(add_one) == Box(7)
    assert add_one(5).bind(add_one).bind(add_one) == Box(8)

    assert sum_string_duplicate("5") == Try("55", is_success=True)
    assert sum_string_duplicate("5").bind(sum_string_duplicate) == Try("5555", is_success=True)

# Generated at 2022-06-21 19:23:26.063267
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda v: str(v).startswith('a')) == Maybe.nothing()
    assert Maybe.just('abc').filter(lambda v: str(v).startswith('a')) == Maybe.just('abc')
    assert Maybe.just('abc').filter(lambda v: str(v).startswith('b')) == Maybe.nothing()


# Generated at 2022-06-21 19:23:33.442755
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(2)) == Maybe.just(4)



# Generated at 2022-06-21 19:23:37.468005
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(1)
    assert maybe.to_box() == Box(1)

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)


# Generated at 2022-06-21 19:23:41.070899
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1


# Generated at 2022-06-21 19:23:45.574412
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Unit test for method to_box of class Maybe
    """
    assert Maybe.just('value').to_box() == Box('value')
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:23:51.243829
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x)) == Maybe.just(1)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:23:57.389718
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:24:07.120804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value > 0

    t = Maybe.just(1)
    assert t.filter(filterer) == Maybe.just(1)
    assert t.filter(filterer).is_nothing == False
    t = Maybe.just(0)
    assert t.filter(filterer) == Maybe.nothing()
    assert t.filter(filterer).is_nothing == True
    t = Maybe.just(-1)
    assert t.filter(filterer) == Maybe.nothing()
    assert t.filter(filterer).is_nothing == True
    t = Maybe.nothing()
    assert t.filter(filterer) == Maybe.nothing()
    assert t.filter(filterer).is_nothing == True


# Generated at 2022-06-21 19:24:11.040008
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('Unit test for method __eq__ of class Maybe')

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:24:13.772153
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else('A') == 1
    assert Maybe.nothing().get_or_else('B') == 'B'


# Generated at 2022-06-21 19:24:16.911378
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 19:24:24.366206
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    value = Maybe.just(1)
    assert value.to_either() == Right(1)

    value = Maybe.nothing()
    assert value.to_either() == Left(None)



# Generated at 2022-06-21 19:24:28.313310
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-21 19:24:30.360218
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:24:32.997183
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:24:38.175815
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test Maybe.bind() method.
    """
    from pymonet.functor import Functor
    from pymonet.monad_list import List

    functor = Functor(Maybe.just(22))
    assert functor.fmap(lambda value: value * 2).bind(lambda x: List.of(x)) == List.of(44)



# Generated at 2022-06-21 19:24:44.888761
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    add = Maybe(lambda x: x + 10, False)
    monad = Maybe.just(20)
    ap_result = monad.ap(add)
    assert isinstance(ap_result, Maybe)
    assert ap_result == Maybe.just(30)

    monad_fail = Maybe.nothing()
    ap_fail_result = monad_fail.ap(add)
    assert isinstance(ap_fail_result, Maybe)
    assert ap_fail_result == Maybe.nothing()

    add_validation = Validation.success(lambda x: x + 10)
    ap_validation_result = monad.ap(add_validation)
    assert isinstance(ap_validation_result, Validation)
    assert ap_

# Generated at 2022-06-21 19:24:51.612553
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.just(1).to_either() != Left(1)
    assert Maybe.just(1).to_either() != Left(None)
    assert Maybe.just(1).to_either() != Right(None)


# Generated at 2022-06-21 19:24:55.503046
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe.
    """
    from pymonet.monad_try import Try

    assert Maybe.just(2).to_try() == Try(2, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-21 19:25:00.754398
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(None).map(lambda x: x == None) == Maybe.just(True)
    assert Maybe.nothing().map(lambda x: x == None) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x+1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x*2) == Maybe.just(2)


# Generated at 2022-06-21 19:25:05.148709
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x ** 2) == Maybe.just(25)
    assert Maybe.nothing().map(lambda x: x ** 2) == Maybe.nothing()



# Generated at 2022-06-21 19:25:14.151341
# Unit test for constructor of class Maybe
def test_Maybe():
    test_value_1 = "test_value_1"
    test_value_2 = "test_value_2"

    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(test_value_1) == Maybe(test_value_1, False)



# Generated at 2022-06-21 19:25:24.889460
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2.0)
    assert Maybe.just(1.0) != Maybe.just(2)
    assert Maybe.just(1.0) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.just(1) != Maybe.just("1")
    assert Maybe.just(True) != Maybe.just("True")
    assert Maybe.just('string') != Maybe.just("string")
    assert Maybe.just('string') != Maybe.just("other_string")
    assert Maybe.just(1) != Maybe.just(True)

# Generated at 2022-06-21 19:25:28.799802
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Box.just(1) == Just(1) == Box.just(1)
    assert Box.nothing() == Nothing() == Box.nothing()

    assert Box.just(1) != Just(2) != Box.just(2)
    assert Box.nothing() != Just(2) != Box.just(2)



# Generated at 2022-06-21 19:25:31.223179
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-21 19:25:33.052773
# Unit test for constructor of class Maybe
def test_Maybe():
    nothing = Maybe.nothing()
    assert nothing.value is None
    assert nothing.is_nothing == True

    just = Maybe.just(1)
    assert just.value == 1
    assert just.is_nothing == False



# Generated at 2022-06-21 19:25:37.885767
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def double(value):
        return Maybe.just(2 * value)

    maybe = Maybe.just(1).bind(double)
    assert maybe == Maybe.just(2)

    maybe = Maybe.nothing().bind(double)
    assert maybe == Maybe.nothing()

# Generated at 2022-06-21 19:25:43.714533
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda _: True) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()


# Generated at 2022-06-21 19:25:45.452054
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

test_Maybe()



# Generated at 2022-06-21 19:25:48.580228
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:25:54.085552
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe(1, False)
    m2 = Maybe(2, False)
    assert m1 != m2
    m3 = Maybe(1, True)
    m4 = Maybe(1, False)
    assert m3 != m4
    m5 = Maybe(None, False)
    m6 = Maybe(None, False)
    assert m5 == m6


# Generated at 2022-06-21 19:26:05.001554
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(3)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:26:18.180550
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Test to_either of not empty Maybe
    assert Maybe(10, False).to_either() == \
        Maybe(10, False).to_box().to_either() == \
        Maybe(10, False).to_lazy().to_either() == \
        Maybe(10, False).to_try().to_either() == \
        Maybe(10, False).to_validation().to_either() == \
        Maybe(10, False).to_validation().to_try().to_either() == \
        Maybe(10, False).to_box().to_try().to_either() == \
        Maybe(10, False).to_lazy().to_try().to_either()

    # Test to_either of empty Maybe
    assert Maybe.nothing().to_either() == \
        Maybe.nothing().to_box().to

# Generated at 2022-06-21 19:26:20.883097
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:26:29.011570
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test with Maybe[1] and filterer returns False for 1
    maybe_one_filter_false = Maybe.just(1).filter(lambda x: x != 1)
    assert Maybe.nothing() == maybe_one_filter_false

    # Test with Maybe[1] and filterer returns True for 1
    maybe_one_filter_true = Maybe.just(1).filter(lambda x: x == 1)
    assert Maybe.just(1) == maybe_one_filter_true

    # Test with empty Maybe and filterer returns False for 1
    maybe_nothing_filter_false = Maybe.nothing().filter(lambda x: x != 1)
    assert Maybe.nothing() == maybe_nothing_filter_false

    # Test with empty Maybe and filterer returns True for 1

# Generated at 2022-06-21 19:26:34.090954
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(10) == 10
    assert Maybe.just(1).get_or_else(10) == 1
    assert Maybe.just(True).get_or_else(False)
    assert Maybe.just(False).get_or_else(True) == False


# Generated at 2022-06-21 19:26:37.642692
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:26:40.085218
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: True) == Maybe(1, False)
    assert Maybe(1, False).filter(lambda x: False) == Maybe(None, True)

# Generated at 2022-06-21 19:26:46.816312
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from operator import mul
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, Failure
    import pytest

    def mapper(value):
        return Try(mul(value, 10))


    def validation_mapper(value):
        return Validation.success(value + 10)

    assert Maybe.just(10).bind(mapper) == mapper(10)
    assert Maybe.just(10).bind(lambda x: Maybe.just(x + 10)) == Maybe.just(20)
    assert Maybe.just(10).bind(validation_mapper).bind(lambda x: Failure(x + 10)) == Failure(30)
    assert Maybe.nothing().bind(mapper) == Try(None, is_success=False)

# Generated at 2022-06-21 19:26:53.978572
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.do import do, Do

    do(
        Do(lambda: Maybe.just([1, 2, 3]))
        .bind(
            Do(lambda x: Maybe.just(x[:2]))
        )
    ) \
    .bind(
        Do(lambda i: Maybe.just(i[0]))
    ) \
    .bind(
        Do(lambda x: print(x))
    )
    # Output:
    # 1


# Generated at 2022-06-21 19:26:56.673789
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # When is empty
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:27:13.511085
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1).value == 1
    assert Maybe.nothing().is_nothing is True



# Generated at 2022-06-21 19:27:20.281038
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.monad_try import Try

    try:
        assert Maybe(1, False).to_try() == Try(1, True)
    except AssertionError:
        print("AssertionError exception caught")

    try:
        assert Maybe(None, True).to_try() == Try(None, False)
    except AssertionError:
        print("AssertionError exception caught")



# Generated at 2022-06-21 19:27:29.843225
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def addition(x):
        return lambda y: x + y

    assert Maybe.just(2).ap(Maybe.just(3)) == Maybe.just(5)
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(addition(2)).ap(Maybe.just(3)) == Maybe.just(5)
    assert Maybe.just(addition(2)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:27:33.011945
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(45).to_try() == Try(45, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:27:38.421771
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    assert Maybe.just(42).get_or_else(666) == 42
    assert Maybe.nothing().get_or_else(666) == 666
    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(42).to_lazy().value == Lazy(lambda: 42).value
    assert Maybe.nothing().to_lazy().value

# Generated at 2022-06-21 19:27:42.355387
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 5
    maybe_value = Maybe.just(value)

    assert maybe_value == Maybe.just(value)
    assert maybe_value != Maybe.just(value + 10)
    assert maybe_value != Maybe.nothing()


# Generated at 2022-06-21 19:27:44.954325
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-21 19:27:49.060127
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:27:52.065893
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    mapper = lambda x: x - 1
    assert Maybe.just(1).ap(Maybe.just(mapper)) == Maybe.just(0)

# Generated at 2022-06-21 19:27:54.254966
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-21 19:28:18.154296
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.just(1)
    assert maybe.map(lambda x: x + 1) == Maybe.just(2)
    maybe2 = Maybe.nothing()
    assert maybe2.map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:28:21.490099
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 3) == Maybe.just(8)
    assert Maybe.just(5).map(lambda x: [x]) == Maybe.just([5])


# Generated at 2022-06-21 19:28:30.990920
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Unit test for method to_lazy of class Maybe."""
    from pymonet.lazy import Lazy

    def first_fibonacci_number_greater_than_100():
        f1 = f2 = 1
        while f1 <= 100:
            f1, f2 = f2, f1 + f2
        return f1

    assert Maybe.just(first_fibonacci_number_greater_than_100).to_lazy() == Lazy(first_fibonacci_number_greater_than_100)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:28:35.301415
# Unit test for constructor of class Maybe
def test_Maybe():
    a = Maybe.just(1)
    b = Maybe.just(1)
    c = Maybe.just(2)
    d = Maybe.nothing()
    e = Maybe.nothing()

    assert a == b
    assert a != c
    assert a != d
    assert d == e
    assert a != e

# Generated at 2022-06-21 19:28:38.806715
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(None, True)
    assert Maybe(1, False) != Maybe(None, False)


# Generated at 2022-06-21 19:28:44.001936
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: x + 1, False).ap(Maybe.just(5)) == Maybe.just(6)
    assert Maybe(lambda x: x + 1, False).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe(None, True).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:28:48.800354
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:28:53.561938
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    maybe = Maybe.just(1)
    maybe_none = Maybe.nothing()

    assert maybe.to_validation() == Validation.success(1)
    assert maybe_none.to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:28:56.006282
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:28:59.047029
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:29:50.739693
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Setup
    a = Maybe(1, True)
    b = Maybe(2, False)
    assert a == Maybe.nothing()
    assert b == Maybe.just(2)

    # When
    a_result = a.bind(lambda x: Maybe.just(x + 1))
    b_result = b.bind(lambda x: Maybe.just(x + 1))

    # Verify
    assert a_result == Maybe.nothing()
    assert b_result == Maybe.just(3)


# Generated at 2022-06-21 19:29:54.634248
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Test for method get_or_else of class Maybe.
    """
    just_five = Maybe.just(5)
    assert just_five.get_or_else(0) == 5

    nothing_int = Maybe.nothing()
    assert nothing_int.get_or_else(0) == 0



# Generated at 2022-06-21 19:30:05.814374
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Function test Maybe.map.
    """

    def test_case(input_value, output_value, input_is_nothing, output_is_nothing, mapper):
        new_input_maybe = Maybe(input_value, input_is_nothing)
        new_output_maybe = Maybe(output_value, output_is_nothing)
        assert new_input_maybe.map(mapper) == new_output_maybe

    int_add_one = lambda arg: arg + 1
    test_case(1, 2, False, False, int_add_one)
    test_case(2, 3, False, False, int_add_one)

    test_case(1, None, False, True, lambda arg: None)
    test_case(2, None, False, True, lambda arg: None)

    test_

# Generated at 2022-06-21 19:30:14.308525
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test import test_passes, test_fails

    test_passes(
        actual=Maybe.just(5).filter(lambda _x: True),
        expected=Maybe.just(5),
        message='Filter with True'
    )

    test_passes(
        actual=Maybe.nothing().filter(lambda _x: True),
        expected=Maybe.nothing(),
        message='Filter with True when nothing'
    )

    test_passes(
        actual=Maybe.just(5).filter(lambda _x: False),
        expected=Maybe.nothing(),
        message='Filter with False'
    )


# Generated at 2022-06-21 19:30:21.167499
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(72) == Maybe.just(72)
    assert Maybe.just(72) != Maybe.just(3)
    assert Maybe.just(72) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(72)
    assert Maybe.nothing() != Maybe.just(3)

# Unit tests for function map

# Generated at 2022-06-21 19:30:25.526482
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # testing for empty Maybe
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy().value == None
    # testing for not empty Maybe
    assert Maybe.just("test").to_lazy() == Lazy(lambda: "test")
    assert Maybe.just("test").to_lazy().value == "test"

# Generated at 2022-06-21 19:30:29.144958
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe.just("value")
    m2 = Maybe.just("value")
    assert m == m2
    assert m.is_nothing == False
    assert m2.is_nothing == False
    assert m.value == "value"
    assert m2.value == "value"
    n = Maybe.nothing()
    n2 = Maybe.nothing()
    assert n == n2
    assert n.is_nothing == True
    assert n2.is_nothing == True



# Generated at 2022-06-21 19:30:33.987228
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    actual = Maybe.just('foo').to_lazy()
    expected = Lazy(lambda: 'foo')
    assert actual == expected

    actual = Maybe.nothing().to_lazy()
    expected = Lazy(lambda: None)
    assert actual == expected

# Generated at 2022-06-21 19:30:39.310692
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # case: not empty Maybe
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    # case: empty Maybe
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:30:47.138583
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Function will take a number as a parameter and will return
    # a number + 1
    identity = lambda x: x + 1

    # Create empty maybe
    maybe = Maybe.nothing()

    # Apply map to empty maybe
    maybe_after_map = maybe.map(identity)

    # Assert that result is empty maybe
    assert maybe_after_map.is_nothing

    # Create not empty maybe
    maybe = Maybe.just(1)

    # Apply map to not empty maybe
    maybe_after_map = maybe.map(identity)

    # Assert that result is not empty maybe with correct value
    assert not maybe_after_map.is_nothing
    assert maybe_after_map.value == 2

