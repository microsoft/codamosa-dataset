

# Generated at 2022-06-21 19:21:00.283806
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test when two Maybes with different values are not equal
    to_test = (
        (
            Maybe(1, False),
            Maybe(2, False)
        ),
        (
            Maybe(1, False),
            Maybe.nothing()
        )
    )
    for maybe_1, maybe_2 in to_test:
        assert maybe_1 != maybe_2, 'Expected maybe_1 != maybe_2'

    # Test when two Maybes with the same values are equal

# Generated at 2022-06-21 19:21:05.095446
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 6) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.nothing().filter(lambda x: x > 4) == Maybe.nothing()


# Generated at 2022-06-21 19:21:06.617958
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:21:07.564467
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just('1').map(int) == Maybe.just(1)



# Generated at 2022-06-21 19:21:18.162403
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    m1 = Maybe('a', False)
    m2 = Maybe('a', False)
    assert m1 == m2
    assert m1 != Maybe('b', False)
    assert m1 != Left('a')
    assert m1 != Box('a')
    assert m1 != Lazy(lambda: 'a')
    assert m1 != Try('a', True)
    assert m1 != Validation.success('a')
    assert m1 != Validation.failure('a')
    assert m1 == Maybe.just('a')
    assert m1 != Maybe.nothing()

# Generated at 2022-06-21 19:21:19.984279
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-21 19:21:24.144715
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(123).filter(lambda x: x == 123) == Maybe.just(123)
    assert Maybe.just(123).filter(lambda x: x == 321) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 123) == Maybe.nothing()


# Generated at 2022-06-21 19:21:24.725661
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass

# Generated at 2022-06-21 19:21:28.556713
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:21:32.517894
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

# Generated at 2022-06-21 19:21:39.288540
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    maybe1 = Maybe.just(3)
    either1 = maybe1.to_either()
    assert either1 == Right(3)

    maybe2 = Maybe.nothing()
    either2 = maybe2.to_either()
    assert either2 == Left(None)


# Generated at 2022-06-21 19:21:42.833087
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("test").filter(lambda x: len(x) > 4) == Maybe.nothing()
    assert Maybe.just("test").filter(lambda x: len(x) == 4) == Maybe.just("test")

# Generated at 2022-06-21 19:21:47.920458
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    val = Validation.success(2)
    maybe = Maybe.just(1)
    assert val.bind(lambda x: maybe.to_validation().map(lambda y: x + y)) == Validation.success(3)


# Generated at 2022-06-21 19:21:53.044968
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    actual = Maybe.just(1) == Maybe.just(1)
    assert actual
    actual = Maybe.just(1) == Maybe.just(2)
    assert not actual
    actual = Maybe.just(1) == Maybe.nothing()
    assert not actual
    actual = Maybe.nothing() == Maybe.nothing()
    assert actual

# Generated at 2022-06-21 19:21:57.718560
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Arrange
    def double(x):
        return Maybe.just(x * 2)

    # Act
    test = Maybe.just(10).bind(double)

    # Assert
    assert test == Maybe.just(20)
    assert test.is_nothing == False
    assert test.value == 20

# Generated at 2022-06-21 19:22:00.665803
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:22:03.690757
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(10) != Maybe.just(2)

# Generated at 2022-06-21 19:22:17.268911
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('') == Maybe.just('')
    assert Maybe.just('10') == Maybe.just('10')
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1.0) == Maybe.just(1.0)
    assert Maybe.just(1.0) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(1.0)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing

# Generated at 2022-06-21 19:22:21.466154
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)


# Generated at 2022-06-21 19:22:24.032930
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe = Maybe.just(123)
    either = maybe.to_either()

    assert either.get_or_else(None) == 123


# Generated at 2022-06-21 19:22:34.668564
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test_function():
        return 123

    assert Maybe.just(test_function).to_lazy() == Lazy(test_function)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:22:39.023998
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-21 19:22:47.670986
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try

    assert Maybe.just(1).filter(lambda x: x == 1).get_or_else(0) == 1
    assert Maybe.just(2).filter(lambda x: x == 1).get_or_else(0) == 0
    assert Maybe.nothing().filter(lambda x: True).get_or_else(0) == 0


# Generated at 2022-06-21 19:22:54.853994
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(None) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.nothing().bind(None) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: None) == Maybe.nothing()

# Generated at 2022-06-21 19:22:57.039914
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(6) == 5
    assert Maybe.nothing().get_or_else(6) == 6


# Generated at 2022-06-21 19:23:00.131767
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    def test(m: Maybe):
        return m.to_validation()

    assert test(Maybe.just(1)) == Validation.success(1)
    assert test(Maybe.nothing()) == Validation.success(None)


# Generated at 2022-06-21 19:23:02.993812
# Unit test for method map of class Maybe
def test_Maybe_map():
    # if Maybe is empty return new empty Maybe
    assert Maybe(None, True).map(lambda x: x) == Maybe.nothing()

    # if Maybe is not empty return new Maybe with result of mapper
    assert Maybe(12, False).map(lambda x: x * 2) == Maybe.just(24)


# Generated at 2022-06-21 19:23:14.686428
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    @staticmethod
    def add_one(value):
        return value + 1

    m_5 = add_one(5)
    m_5_2 = add_one(5.2)
    m_none = None
    assert m_5 == 6
    assert m_5_2 == 6.2
    assert m_none is None
    assert Maybe.just(m_5).ap(Maybe.just(add_one)) == Maybe.just(7)
    assert Maybe.just(m_5).ap(Maybe.just(m_5_2)) == Maybe.just(10)
    assert Maybe.just(m_5).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(m_5)) == Maybe.nothing()

# Generated at 2022-06-21 19:23:19.416625
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe.just(2).filter(lambda x: x % 2 == 0)
    expected_result = Maybe.just(2)
    assert result == expected_result

    result = Maybe.just(3).filter(lambda x: x % 2 == 0)
    expected_result = Maybe.nothing()
    assert result == expected_result

    result = Maybe.nothing().filter(lambda x: x)
    expected_result = Maybe.nothing()
    assert result == expected_result



# Generated at 2022-06-21 19:23:26.804068
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.functor import Functor
    from pymonet.box import Box

    def f(value):
        return Box(Functor(value + 1))

    assert Maybe.just(1).bind(f).bind(lambda x: x.fmap(lambda y: y ** 2)).value == 4
    assert Maybe.nothing().bind(f).bind(lambda x: x.fmap(lambda y: y ** 2)).value is None

# Generated at 2022-06-21 19:23:40.802850
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test for method to_box of class Maybe

    :returns: Nothing
    :rtype: None
    """
    assert(Maybe.just(3).to_box() == Box(3))
    assert(Maybe.nothing().to_box() == Box(None))



# Generated at 2022-06-21 19:23:48.542455
# Unit test for constructor of class Maybe
def test_Maybe():
    # unit test for nothing constructor
    maybe = Maybe.nothing()
    assert isinstance(maybe, Maybe)
    assert maybe.is_nothing
    try:
        maybe.value
        assert False, 'Empty Maybe should not have variable value'
    except AttributeError:
        pass
    # unit test for just constructor
    maybe = Maybe.just(5)
    assert isinstance(maybe, Maybe)
    assert not maybe.is_nothing
    assert maybe.value == 5


# Generated at 2022-06-21 19:23:55.773178
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Check correctness method Maybe.map.
    """
    assert Maybe(True, False).map(lambda x: x).is_nothing == False
    assert Maybe(True, False).map(lambda x: x).value == True
    assert Maybe(0, False).map(lambda x: x).value == 0
    assert Maybe(False, False).map(lambda x: x).value == False
    assert Maybe(True, False).map(lambda x: x).get_or_else(None) == True
    assert Maybe(True, False).map(lambda x: x).get_or_else(1) == 1
    assert Maybe(True, False).map(lambda x: x).get_or_else(2) == 2

    assert Maybe(None, True).map(lambda x: x).is_nothing == True

# Generated at 2022-06-21 19:23:59.809858
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(None, False).to_box() == Box(None)
    assert Maybe(1, False).to_box() == Box(1)
    assert (Maybe('value', False).to_box() == Box('value') is True)


# Generated at 2022-06-21 19:24:08.133252
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    assert Maybe.just(lambda x: x + 1).ap(Lazy(lambda: Maybe.just(1))) == Maybe.just(2), 'Test 1'
    assert Maybe.just(lambda x: x + 1).ap(Lazy(lambda: Maybe.nothing())) == Maybe.nothing(), 'Test 2'
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2), 'Test 3'
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing(), 'Test 4'
    assert Maybe.nothing().ap(Lazy(lambda: Maybe.just(1))) == Maybe.nothing(), 'Test 5'
   

# Generated at 2022-06-21 19:24:12.303903
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)

    assert Maybe.just(5).is_nothing == False
    assert Maybe.nothing().is_nothing == True



# Generated at 2022-06-21 19:24:17.551293
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(True).to_either() == Right(True)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just('').to_either() == Right('')
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:24:21.658369
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    just_none = Maybe.just(None)
    assert just_none.to_try() == Try(None, is_success=True)
    nothing_none = Maybe.nothing()
    assert nothing_none.to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:23.558533
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test Maybe to Either.

    :return: None
    """
    from pymonet.either import Left, Right

    assert Maybe(1, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)


# Generated at 2022-06-21 19:24:29.509011
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x * 3)) == Maybe.just(9)
    assert Maybe.just(3).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * 3)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:24:44.523966
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_filterer(value):
        return value % 2 == 0

    def test_filterer_bigger_then_six(value):
        return value > 6

    def test_filterer_bigger_then_eight(value):
        return value > 8

    assert Maybe.just(2).filter(test_filterer).get_or_else(None) == 2
    assert Maybe.just(2).filter(test_filterer_bigger_then_six).get_or_else(None) is None
    assert Maybe.nothing().filter(test_filterer_bigger_then_eight).get_or_else(None) is None


# Generated at 2022-06-21 19:24:49.737699
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(10).to_box() == Box(10)


# Generated at 2022-06-21 19:24:52.877168
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def test():
        assert Maybe.just(4).to_box() == Box(4)
        assert Maybe.nothing().to_box() == Box(None)

    run_test("Unit test for method to_box of class Maybe", test)


# Generated at 2022-06-21 19:24:57.326466
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2) == Maybe.just(2).map(lambda val: val)
    assert Maybe.nothing() == Maybe.just(2).map(lambda val: None)
    assert Maybe.just(3) == Maybe.just(2).map(lambda val: val + 1)


# Generated at 2022-06-21 19:25:02.324921
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        def inner(y):
            return x + y
        return inner
    assert Maybe.just(add(1)).ap(Maybe.just(4)) == Maybe.just(5)
    assert Maybe.nothing().ap(Maybe.just(4)) == Maybe.nothing()
    assert Maybe.just(add(1)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:25:05.426040
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test for constructor of class Maybe.

    :returns: true if test passed
    :rtype: Boolean
    """
    return Maybe('just', False) == Maybe.just('just')


# Generated at 2022-06-21 19:25:09.697063
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:25:12.426134
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(None) == 42
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:25:22.749226
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, Failure
    res = Maybe.just(lambda x: x + 1).ap(Right(1)).to_either()
    assert(res == Right(2))
    res = Maybe.just(lambda x: x + 1).ap(Left(1)).to_either()
    assert(res == Left(1))
    res = Maybe.just(lambda x: x + 1).ap(Maybe.just(1)).to_either()
    assert(res == Right(2))
    res = Maybe.just(lambda x: x + 1).ap(Maybe.nothing()).to_either()

# Generated at 2022-06-21 19:25:25.610663
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:25:47.058554
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:25:50.210221
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(5).to_try() == Try(5, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-21 19:25:53.959252
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    m = Maybe.just(5).bind(lambda x: Maybe.just(x + 1))
    assert m == Maybe.just(6)

    m = Maybe.nothing().bind(lambda x: Maybe.just(x + 1))
    assert m == Maybe.nothing()


# Generated at 2022-06-21 19:25:55.918720
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:25:58.742642
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('foo') == Maybe.just('foo')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('bar') != Maybe.just('foo')
    assert Maybe.nothing() != Maybe.just('foo')



# Generated at 2022-06-21 19:26:04.502455
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(10, False).filter(lambda x: x > 5) == Maybe(10, False)
    assert Maybe(2, False).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    print("test_Maybe_filter: OK")



# Generated at 2022-06-21 19:26:09.984905
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(1).to_box().value == 1
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.nothing().to_box().value is None


# Generated at 2022-06-21 19:26:14.085967
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe(3, False).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:26:21.349794
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try, Failure

    test_result = Maybe.nothing().to_try()
    assert isinstance(test_result, Try)
    assert test_result.is_success is False
    assert isinstance(test_result.failure, Failure)
    assert test_result.failure.value is None

    test_result = Maybe.just(123).to_try()
    assert isinstance(test_result, Try)
    assert test_result.is_success is True
    assert test_result.value == 123



# Generated at 2022-06-21 19:26:27.065535
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Create function that returns Maybe with value
    def func1(param):
        return Maybe.just(param * 2)

    # Create function that returns Maybe without value
    def func2(param):
        return Maybe.nothing()

    just = Maybe.just(1)
    nothing = Maybe.nothing()
    assert just.bind(func1) == Maybe.just(2) and just.bind(func2) == Maybe.nothing() and \
        nothing.bind(func1) == Maybe.nothing() and nothing.bind(func2) == Maybe.nothing()



# Generated at 2022-06-21 19:27:09.087149
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.maybe import Maybe

    assert Maybe.just(Maybe.just(1)).bind(lambda inner_maybe: inner_maybe) == Maybe.just(1)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe(None, True)

# Generated at 2022-06-21 19:27:16.414002
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda sum_: lambda a, b: sum_(a + b)).ap(Maybe.just(40)) == Maybe.just(40 + 40)
    assert Maybe.just(lambda sum_: lambda a, b: sum_(a + b)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(40)) == Maybe.nothing()
    assert Maybe.just(lambda sum_: lambda a, b: sum_(a + b)).ap(Maybe.just(40)) == Maybe.just(40 + 40)
    assert Maybe.just(lambda sum_: lambda a, b: sum_(a + b)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(40)) == Maybe.nothing()


# Generated at 2022-06-21 19:27:20.312770
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:27:25.109898
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(9) == Maybe.just(9)
    assert Maybe.just(9) != Maybe.just(8)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(9)


# Generated at 2022-06-21 19:27:32.387035
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Setup
    maybe = Maybe.just(2)

    # Exercise
    lazy = maybe.to_lazy()

    # Test
    assert lazy.__class__.__name__ == 'Lazy'
    assert lazy.get() == 2
    assert lazy._has_value

    # Setup
    maybe = Maybe.nothing()

    # Exercise
    lazy = maybe.to_lazy()

    # Test
    assert lazy.__class__.__name__ == 'Lazy'
    assert lazy.get() is None
    assert lazy._has_value is False



# Generated at 2022-06-21 19:27:34.891580
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe = Maybe.just(1)
    assert maybe.to_box() == Box(1)

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)


# Generated at 2022-06-21 19:27:41.508539
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def multiplier(mul):
        def multiplier_func(value):
            return value*mul

        return multiplier_func

    lazy_value = Lazy(multiplier(7))
    maybe = Maybe.just(lazy_value)

    result = maybe.to_lazy()()

    assert result == Lazy(lambda: 42 * 7)

# Generated at 2022-06-21 19:27:45.196224
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(8)
    assert m == Maybe.just(8)

    assert Maybe.nothing() == Maybe.nothing()

    m = Maybe.just(4)
    assert m != Maybe.just(3)

    m = Maybe.just(4)
    assert m != Maybe.nothing()



# Generated at 2022-06-21 19:27:49.575591
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe.
    """
    from pymonet.either import Right

    assert Maybe.just(8).to_either() == Right(8)
    assert Maybe.nothing().to_either() == Right(None)


# Generated at 2022-06-21 19:27:52.998686
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:29:17.661612
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-21 19:29:21.577201
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_a = Maybe.just(5)
    maybe_b = Maybe.nothing()

    assert maybe_a == Maybe.just(5)
    assert maybe_b == Maybe.nothing()
    assert maybe_a != maybe_b


# Generated at 2022-06-21 19:29:25.213217
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_1 = Maybe.just(5)
    assert Maybe.just(5) == maybe_1

    maybe_2 = Maybe.nothing()
    assert Maybe.nothing() == maybe_2


# Generated at 2022-06-21 19:29:32.777597
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.nothing().ap(Maybe.just(lambda x: x + 1)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)



# Generated at 2022-06-21 19:29:37.055978
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:29:39.313583
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:29:43.156545
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just((lambda x: x + 1)).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:29:46.243552
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    def check_type(obj):
        assert isinstance(obj, Try)
        return True

    assert check_type(Maybe(Box(10), False).to_try())
    assert check_type(Maybe(Box(10), True).to_try())


# Generated at 2022-06-21 19:29:51.148320
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(
        lambda value: Maybe.just(value * 3)
    ) == Maybe.just(6)

    assert Maybe.nothing().bind(
        lambda value: Maybe.just(value * 3)
    ) == Maybe.nothing()



# Generated at 2022-06-21 19:29:55.150647
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():

    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
