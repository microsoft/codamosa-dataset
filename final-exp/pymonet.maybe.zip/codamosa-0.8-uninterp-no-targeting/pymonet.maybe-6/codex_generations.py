

# Generated at 2022-06-21 19:20:54.715226
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-21 19:20:58.120785
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:21:01.183976
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe('test', False).to_either() == Right('test')
    assert Maybe('test', True).to_either() == Left(None)



# Generated at 2022-06-21 19:21:03.758190
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:21:05.722717
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)
test_Maybe_to_validation()



# Generated at 2022-06-21 19:21:07.978832
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # given
    from pymonet.either import Either

    either = Either.success(None)
    expected = Either.success(None)

    # when
    result = Maybe(None, True).to_either()

    # then
    assert result == expected


# Generated at 2022-06-21 19:21:11.871214
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(10).to_try() == Try(10, is_success=True)



# Generated at 2022-06-21 19:21:21.884308
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda x: Maybe.just(x)) == Maybe.just(2)
    assert Maybe.just(3).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(4)

    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()

    assert Maybe.just(5).bind(lambda x: Maybe.just(x - 2)).bind(lambda x: Maybe.just(x ** 2)) == Maybe.just(9)
    assert Maybe.just(5).bind(lambda x: Maybe.just(x - 2)).bind(lambda x: Maybe.nothing()) == Maybe.nothing

# Generated at 2022-06-21 19:21:31.968442
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 0) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:21:36.873130
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    x = Maybe(10, False)
    y = Maybe(10, False)
    z = Maybe.nothing()
    assert x.to_lazy().get() is y.to_lazy().get()
    assert x.to_lazy().get() != z.to_lazy().get()


# Generated at 2022-06-21 19:21:45.442587
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert isinstance(Maybe.just(3).to_box(), Box)
    assert Maybe.just(3).to_box() == Box(3)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:21:48.061336
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(0).get_or_else(-1) == 0)
    assert(Maybe.nothing().get_or_else(-1) == -1)


# Generated at 2022-06-21 19:21:59.597472
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe
    """
    assert Maybe.just(5).to_either() == Maybe.just(5).bind(lambda value: Maybe.just(value)).to_either()
    assert Maybe.just(5).to_either() == Maybe.just(5).bind(lambda value: Maybe.just(value)).map(lambda value: value).to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().bind(lambda value: Maybe.just(value)).map(lambda value: value).to_either()
    assert Maybe(5, False).to_either() == Maybe.just(5).to_either()
    assert Maybe(None, True).to_either() == Maybe.nothing().to_either()


# Generated at 2022-06-21 19:22:02.983031
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    value = Maybe.just(1).to_box()
    assert 1 == value.get_or_else(None)
    value = Maybe.nothing().to_box()
    assert None == value.get_or_else(None)

# Generated at 2022-06-21 19:22:08.704495
# Unit test for method to_either of class Maybe

# Generated at 2022-06-21 19:22:17.069145
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    with pytest.raises(AttributeError):
        maybe.filter(lambda x: isinstance(x, int))
    assert maybe.filter(lambda x: isinstance(x, int)).get_or_else(0) == 1
    assert maybe.filter(lambda x: isinstance(x, str)).get_or_else(0) == 0
    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: True).is_nothing



# Generated at 2022-06-21 19:22:23.983275
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    >>> add_one = lambda x: Maybe.just(x + 1)
    >>> get_none = lambda _: Maybe.nothing()
    >>> Maybe.just(1).bind(add_one).bind(add_one).value
    3
    >>> Maybe.just(1).bind(get_none)
    Maybe(None, True)
    """


# Generated at 2022-06-21 19:22:26.731532
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(3).to_either() == Right(3)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:22:29.604592
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    result = Maybe.just(1).to_lazy()
    assert result == Lazy(lambda: 1)

    result = Maybe.nothing().to_lazy()
    assert result == Lazy(lambda: None)


# Generated at 2022-06-21 19:22:34.071087
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:22:44.622172
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(4).map(lambda x: x ** 2) == Maybe.just(16)
    assert Maybe.just(4).map(lambda x: x ** 2).map(lambda x: x ** 2 ** 0.5) == Maybe.just(16)
    assert Maybe.just(4).map(lambda x: x ** 2).map(lambda x: x ** 2 ** 0.5).map(lambda x: x ** 0.25) == Maybe.just(4)
    assert Maybe.just(4).map(lambda x: x ** 2).map(lambda x: x ** 2 ** 0.5).map(
        lambda x: x ** 0.25).map(math.ceil) == Maybe.just(4)

# Generated at 2022-06-21 19:22:48.785794
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != 1
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:22:52.328643
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x % 2 == 1) == Maybe.nothing()



# Generated at 2022-06-21 19:22:54.545342
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-21 19:22:57.025294
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(111).to_try() == Try(111, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:22:58.738828
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert isinstance(Maybe.just(1).to_try(), Try)
    assert isinstance(Maybe.nothing().to_try(), Try)


# Generated at 2022-06-21 19:23:02.219658
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def execute_action():
        return 'action execute'

    result = Maybe.just(execute_action).to_lazy()
    assert result == Lazy(execute_action)
    result = Maybe.nothing().to_lazy()
    assert result == Lazy(lambda: None)



# Generated at 2022-06-21 19:23:05.608885
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:23:08.871630
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else('none') == 42
    assert Maybe.nothing().get_or_else('none') == 'none'



# Generated at 2022-06-21 19:23:11.073646
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(-1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(-1).filter(lambda x: x < 1) == Maybe.just(-1)


# Generated at 2022-06-21 19:23:20.840831
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def test_to_either(monad: Maybe[int], is_nothing: bool, expected_result: str) -> bool:
        actual_result = str(monad)
        if actual_result == expected_result:
            return True
        else:
            print("fails for: ", actual_result, "!=", expected_result)
            return False

    t = test_to_either(Maybe(1, True), True, "Maybe.Nothing")
    print("test 1: ", "OK" if t else "FAIL")
    t = test_to_either(Maybe(1, False), False, "Maybe.Some(1)")
    print("test 2: ", "OK" if t else "FAIL")


# Generated at 2022-06-21 19:23:27.474573
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right
    assert Maybe.nothing().to_either() == Left(None)

    assert Maybe.just(2).to_either() == Right(2)

    assert Maybe.just(None).to_either() == Right(None)

if __name__ == '__main__':
    test_Maybe_to_either()

# Generated at 2022-06-21 19:23:39.233134
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    equal_cases = [
        (Maybe.just(1), Maybe.just(1)),
        (Maybe.just(None), Maybe.just(None)),
        (Maybe.just([]), Maybe.just([])),
        (Maybe.just((1, 2)), Maybe.just((1, 2))),
        (Maybe.just({'key': 1}), Maybe.just({'key': 1})),
        (Maybe.nothing(), Maybe.nothing())
    ]


# Generated at 2022-06-21 19:23:50.903846
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # given
    from pymonet.validation import Validation

    nothing = Maybe.nothing()
    just_1 = Maybe.just(1)

    expected_success_1 = Validation.success(1)
    expected_failure_1 = Validation.failure([None])
    expected_success_2 = Validation.success(None)

    # when
    actual_success_1 = just_1.to_validation()
    actual_failure_1 = nothing.to_validation()
    actual_success_2 = nothing.to_validation()

    # then
    assert actual_success_1 == expected_success_1
    assert actual_failure_1 == expected_failure_1
    assert actual_success_2 == expected_success_2



# Generated at 2022-06-21 19:23:56.119294
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    value = Maybe.just(10)
    assert value.to_either() == Either.Right(10)
    empty_value = Maybe.nothing()
    assert empty_value.to_either() == Either.Left(None)



# Generated at 2022-06-21 19:24:01.470353
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(x: int) -> bool:
        return x % 2 == 0
    assert Maybe.just(1).filter(filterer) == Maybe.nothing()
    assert Maybe.just(2).filter(filterer) == Maybe.just(2)
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()



# Generated at 2022-06-21 19:24:05.502216
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:24:09.678651
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:24:18.303120
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.just(4)

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:24:29.513545
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x > 0), Maybe)

# Generated at 2022-06-21 19:24:38.659916
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:24:40.482621
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(123) == Maybe(123, False)


# Generated at 2022-06-21 19:24:42.275636
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1


# Generated at 2022-06-21 19:24:53.610120
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.either import Right
    from pymonet.lazy import Lazy


    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)

    # Test nothing method
    assert Maybe.nothing().get_or_else(5) == 5
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(lambda x: x + 1)) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.nothing().to_either() == Right(None)
    assert Maybe.nothing().to_validation() == 5
    assert Maybe.nothing

# Generated at 2022-06-21 19:24:57.919091
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    empty = Maybe.nothing()
    assert (empty.to_either() == Left(None))

    full = Maybe.just(7)
    assert (full.to_either() == Right(7))


# Generated at 2022-06-21 19:25:02.260778
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.validation import Validation

    maybe = Maybe.just(lambda value: value ** 2)
    validation = maybe.ap(Box(10))
    assert validation == Validation.success(100) is True

    maybe = Maybe.nothing()
    validation = maybe.ap(Box(10))
    assert validation == Validation.success(None) is True


# Generated at 2022-06-21 19:25:05.089106
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    result = Maybe.nothing().to_try()
    assert isinstance(result, Try)
    assert result == Try(None, False)
    result = Maybe.just(1).to_try()
    assert isinstance(result, Try)
    assert result == Try(1, True)

# Generated at 2022-06-21 19:25:08.732668
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda n: n * n) == Maybe.just(4)
    assert Maybe.nothing().map(lambda n: n * n) == Maybe.nothing()


# Generated at 2022-06-21 19:25:14.235742
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    assert(maybe.filter(lambda x: x % 2 == 0) == Nothing)

    maybe = Maybe.just(2)
    assert (maybe.filter(lambda x: x % 2 == 0) == Maybe.just(2))

    maybe = Maybe.nothing()
    assert (maybe.filter(lambda x: x % 2 == 0) == Maybe.nothing())



# Generated at 2022-06-21 19:25:18.245708
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != 4
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != None
    assert Maybe.just('abc') == Maybe.just('abc')
    assert Maybe.just('abc') != 'abc'
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:25:36.467623
# Unit test for constructor of class Maybe
def test_Maybe():
    nothing = Maybe.nothing()
    assert nothing.is_nothing is True

    maybe = Maybe.just(1)
    assert maybe.is_nothing is False
    assert maybe.value == 1



# Generated at 2022-06-21 19:25:39.139259
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)



# Generated at 2022-06-21 19:25:42.246130
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:25:46.700480
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    assert Maybe.just(1).bind(
        lambda x: Maybe.just(x + 1)
    ) == Maybe.just(2)

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x + 1)
    ) == Maybe.nothing()



# Generated at 2022-06-21 19:25:50.734966
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    x = Maybe.just(1).to_validation()
    y = Maybe.nothing().to_validation()

    assert x == Validation.success(1)
    assert y == Validation.success(None)
    assert x is not Validation.success(1)
    assert y is not Validation.success(None)


# Generated at 2022-06-21 19:25:54.749563
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda value: value + 1) == Maybe.just(2)
    assert Maybe.just(6).map(lambda value: value - 5) == Maybe.just(1)
    assert Maybe.nothing().map(lambda value: value + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:25:58.929622
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    result = Maybe.just(1) == Maybe.just(1)
    assert result == True

    result = Maybe.just(1) == Maybe.just(2)
    assert result == False

    result = Maybe.just(1) == Maybe.nothing()
    assert result == False

    result = Maybe.nothing() == Maybe.nothing()
    assert result == True



# Generated at 2022-06-21 19:26:02.328338
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:26:08.979505
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe.just(2).to_try() == Try(2)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:26:14.668902
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # given
    x = Maybe.just(1)
    y = Maybe.nothing()

    # when
    result_x = x.to_lazy()
    result_y = y.to_lazy()

    # then
    assert result_x.get() == 1
    assert result_y.get() is None

# Generated at 2022-06-21 19:26:31.622890
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:26:34.424001
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functors.functor_test import filter_test_for_Maybe
    filter_test_for_Maybe(lambda v: v > 0)


# Generated at 2022-06-21 19:26:44.156176
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import pymonet.box
    import pymonet.maybe
    import pymonet.str_utils

    test_data_1 = 'Hello, world'
    test_data_2 = 'Hello'
    test_data_3 = 'World'
    test_data_4 = None
    test_data_5 = 'world'

    assert Maybe.just(test_data_1)\
        .bind(pymonet.str_utils.get_first_symbol)\
        .get_or_else(test_data_2) == 'H'
    assert Maybe.nothing()\
        .bind(pymonet.str_utils.get_first_symbol)\
        .get_or_else(test_data_2) == test_data_2

# Generated at 2022-06-21 19:26:47.346777
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:26:58.067469
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry

    def raise_error():
        raise ValueError("error")

    x = Maybe.just(12)
    assert isinstance(x.to_lazy(), Lazy)
    assert Functor.fmap(x.to_lazy(), lambda x: x ** 2).__repr__() == Lazy(lambda: 144).__repr__()
    assert Monad.pure(Lazy, x).__repr__() == Lazy(lambda: x).__repr__()

# Generated at 2022-06-21 19:27:03.951716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    with_value = Maybe.just(42)
    without_value = Maybe.nothing()

    assert with_value.to_lazy() == Lazy(lambda: 42)
    assert without_value.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:27:07.754950
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just('a').to_try() == Try('a', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:27:09.703410
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:27:12.281609
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # If Maybe is empty return not successfull Try with None
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    # If Maybe is not empty return successfull Try
    assert Maybe.just(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 19:27:14.819461
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(10) == Maybe.just(10).to_validation()
    assert Validation.success(None) == Maybe.nothing().to_validation()


# Generated at 2022-06-21 19:27:49.255436
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-21 19:27:56.561671
# Unit test for method map of class Maybe
def test_Maybe_map():
    import pymonet.either
    import pymonet.function

    assert Maybe.just(4).map(pymonet.function.double) == Maybe.just(8)
    assert Maybe.just(4).map(pymonet.function.multiply(3)) == Maybe.just(12)
    assert Maybe.just([1, 2, 3]).map(pymonet.function.sum) == Maybe.just(6)
    assert Maybe.nothing().map(pymonet.function.double) == Maybe.nothing()
    assert Maybe.just(pymonet.either.Right(3)).map(pymonet.function.to_string) == \
           Maybe.just(pymonet.either.Right("3"))



# Generated at 2022-06-21 19:28:02.276649
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-21 19:28:08.033469
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import _is_success, _value

    assert Maybe.just("abc").to_try() == Try("abc", True)
    assert _is_success(Maybe.just("abc").to_try())
    assert _value(Maybe.just("abc").to_try()) == "abc"

    assert Maybe.nothing().to_try() == Try(None, False)
    assert not _is_success(Maybe.nothing().to_try())
    assert _value(Maybe.nothing().to_try()) is None


# Generated at 2022-06-21 19:28:11.839186
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-21 19:28:22.086723
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    import unittest

    class TestMaybe___eq__(unittest.TestCase):

        def test_Maybe___eq___type_error(self):
            m = Maybe.just(1)
            self.assertRaises(TypeError, m.__eq__, 'abc')

        def test_Maybe___eq__true(self):
            m1 = Maybe.just(1)
            m2 = Maybe.just(1)
            m3 = Maybe.nothing()
            m4 = Maybe.nothing()
            self.assertTrue(m1.__eq__(m2))
            self.assertTrue(m3.__eq__(m4))

        def test_Maybe___eq__false(self):
            m1 = Maybe.just(1)
            m2 = Maybe.just(2)
            m3 = Maybe.nothing()
           

# Generated at 2022-06-21 19:28:27.926522
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test_function():
        return "value"

    maybe_value = Maybe.just(test_function)
    assert maybe_value.to_lazy() == Lazy(test_function)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:28:34.234050
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # 1. Empty collection
    maybe_val = Maybe.just([])
    new_maybe = maybe_val.filter(lambda val: len(val) > 0)
    assert new_maybe == Maybe.nothing()

    # 2. Non empty collection
    maybe_val = Maybe.just([1, 2, 3, 4, 5])
    new_maybe = maybe_val.filter(lambda val: len(val) > 0)
    assert new_maybe == maybe_val


# Generated at 2022-06-21 19:28:37.159084
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:28:42.541485
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.nothing().bind(lambda _: Maybe.just(2)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)


# Generated at 2022-06-21 19:29:14.346777
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    two_Box = Maybe.just(2).to_box()
    assert two_Box.value == 2

    none_Box = Maybe.nothing().to_box()
    assert none_Box.value is None


# Generated at 2022-06-21 19:29:18.283880
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    empty_maybe_box = Maybe(None, is_nothing=True).to_box()
    assert empty_maybe_box == Box(None)

    some_maybe_box = Maybe(1, is_nothing=False).to_box()
    assert some_maybe_box == Box(1)


# Generated at 2022-06-21 19:29:24.965284
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    maybe = Maybe.just(1)
    try_1 = Try.success(1)
    assert maybe.to_try() == try_1

    maybe_none = Maybe.nothing()
    fail_try_none = Try(None, is_success=False)
    assert maybe_none.to_try() == fail_try_none



# Generated at 2022-06-21 19:29:29.523946
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(
        lambda x: x + 1
    ) == Maybe.just(2)

    assert Maybe.nothing().map(
        lambda x: x + 1
    ) == Maybe.nothing()

    assert Maybe.just(1).map(
        lambda x: x
    ) == Maybe.just(1)



# Generated at 2022-06-21 19:29:33.066822
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy, Thunk

    assert Maybe.just(10).to_lazy() == Lazy(Thunk(10))
    assert Maybe.nothing().to_lazy() == Lazy(Thunk(None))

# Generated at 2022-06-21 19:29:39.076579
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:29:41.056604
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:29:45.096600
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:29:55.262185
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    from pymonet.box import Box
    from pymonet.lazy import Lazy

    maybe = Maybe(lambda x: x * x, False)
    assert maybe.ap(Maybe(Box(3), False)) == Maybe.just(9)
    assert maybe.ap(Box(3)) == Maybe.just(9)
    assert maybe.ap(Maybe(Lazy(lambda: 2), False)) == Maybe.just(4)
    assert maybe.ap(Lazy(lambda: 2)) == Maybe.just(4)
    assert maybe.ap(Maybe(Maybe.nothing(), True)) == Maybe.nothing()
    assert maybe.ap(Maybe(2, False)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe(2, False)) == Maybe.nothing()



# Generated at 2022-06-21 19:30:00.678203
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_validation() == Validation.success(None)

    not_empty_maybe = Maybe.just(10)
    assert not_empty_maybe.to_validation() == Validation.success(10)



# Generated at 2022-06-21 19:30:36.678100
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pytest

    assert Maybe.nothing().to_try() == Try(None, is_success=False) == Try(None, is_success=False)
    assert Maybe.just(True).to_try() == Try(True, is_success=True)
    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)


test_Maybe_to_try()

# Generated at 2022-06-21 19:30:43.038095
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test if instances of Maybe are correctly created.

    :returns: None
    :rtype: NoneType
    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:30:45.398474
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda v: v + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda v: v + 1) == Maybe.nothing()

