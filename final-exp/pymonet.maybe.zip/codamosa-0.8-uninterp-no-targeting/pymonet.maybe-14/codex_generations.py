

# Generated at 2022-06-21 19:20:50.838265
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad_test_util import assert_output
    from pymonet.monad_test_util import fn_a_to_b
    from pymonet.monad_test_util import two_inputs_two_outputs

    assert_output(expected=1, monad=Maybe.just(1), function=Maybe.get_or_else, args=(2,))
    assert_output(expected=2, monad=Maybe.nothing(), function=Maybe.get_or_else, args=(2,))
    assert_output(expected=None, monad=Maybe.nothing(), function=Maybe.get_or_else, args=(None,))
    assert_output(expected=None, monad=Maybe.just(None), function=Maybe.get_or_else, args=(2,))

# Generated at 2022-06-21 19:20:54.127839
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:20:56.767984
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 5).ap(Maybe.just(5)) == Maybe.just(10)


# Generated at 2022-06-21 19:21:01.743053
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def ok():
        return True

    assert(Maybe.just('Hello').to_box() == Box('Hello'))
    assert(Maybe.nothing().to_box() == Box(None))


# Generated at 2022-06-21 19:21:05.094940
# Unit test for constructor of class Maybe
def test_Maybe():
    # Initialize
    just_5 = Maybe.just(5)
    nothing = Maybe.nothing()

    # Assert
    assert just_5.value == 5
    assert nothing.is_nothing


# Generated at 2022-06-21 19:21:06.448930
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-21 19:21:09.740617
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def test_to_either(value: None, expected_value: 'Either[None]') -> None:
        actual_value = Maybe.just(value).to_either()
        assert expected_value == actual_value, f"Expected {expected_value}, but got {actual_value}"

    from pymonet.either import Left, Right
    test_to_either(1, Right(1))
    test_to_either(None, Left(None))


# Generated at 2022-06-21 19:21:13.441794
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:16.416056
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)
test_Maybe_to_validation()



# Generated at 2022-06-21 19:21:19.787729
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(value):
        return Maybe.just(value)

    assert Maybe(1, False).bind(mapper) == Maybe.just(1)

    assert Maybe(None, True).bind(mapper) == Maybe.nothing()



# Generated at 2022-06-21 19:21:24.721793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(10).to_either() == Right(10)


# Generated at 2022-06-21 19:21:37.065216
# Unit test for method map of class Maybe
def test_Maybe_map():
    from collections import namedtuple
    from functools import partial

    Match = namedtuple("Match", ["home", "away"])

    def map_match_to_result(match: Match) -> [str, int]:
        return "%s:%d" % (match.home, match.away)

    # Given
    match = Match("Liverpool", 5)

    # When
    maybe_result = Maybe.just(match).map(map_match_to_result)

    # Then
    assert maybe_result.get_or_else("") == "Liverpool:5"

    # When
    maybe_result = maybe_result.map(partial(map, lambda x: x.upper()))

    # Then
    assert maybe_result.get_or_else("") == "LIVERPOOL:5"

    # When
    maybe_

# Generated at 2022-06-21 19:21:42.035130
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:21:45.078260
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:21:50.421728
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-21 19:21:54.695344
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    a = Maybe.just(lambda x: x.lower())
    assert a.ap(Maybe.just('PYTHON')) == Maybe.just('python')
    assert a.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(a) == Maybe.nothing()


# Generated at 2022-06-21 19:22:02.400344
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe = Maybe.just(lambda x: x + 5)
    maybe1 = Maybe.just(5)

    assert maybe.ap(maybe1) == Maybe.just(10)
    assert isinstance(maybe.ap(maybe1), Maybe)
    assert maybe.ap(Maybe.nothing()) == Maybe.nothing()
    assert isinstance(maybe.ap(Maybe.nothing()), Maybe)
    assert Maybe.nothing().ap(maybe1) == Maybe.nothing()
    assert isinstance(Maybe.nothing().ap(maybe1), Maybe)

# Generated at 2022-06-21 19:22:05.745863
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:16.000821
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 10) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 10) == Maybe.nothing()

    def test_Maybe_filter_negative(x: int) -> bool:
        return x < 10

    assert Maybe.just(1).filter(test_Maybe_filter_negative) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 10) == Maybe.just(1)


# Generated at 2022-06-21 19:22:20.845016
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-21 19:22:27.362963
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2).__eq__(Maybe.just(3)) is False
    assert Maybe.just(2).__eq__(Maybe.nothing()) is False
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:22:29.680024
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.box import Box

    just_box = Box(Box(1))
    print(just_box.bind(lambda x: Box(x.value + 2)))
    #>> Box(3)

# Generated at 2022-06-21 19:22:37.188569
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    empty_maybe = Maybe.nothing()
    non_empty_maybe = Maybe.just('string')
    assert empty_maybe.to_either() == \
        (
            (
                (lambda: None)
            ),
            True
        )
    assert non_empty_maybe.to_either() == \
        (
            (
                (lambda: 'string')
            ),
            False
        )


# Generated at 2022-06-21 19:22:39.956785
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)


# Generated at 2022-06-21 19:22:44.017253
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(3, False).to_either() == Right(3)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-21 19:22:50.332609
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test ap method of class Maybe.

    :returns: Nothing
    :rtype: Nothing
    """
    maybe = Maybe.just(lambda x: x * 2)
    other_maybe = Maybe.just(3)
    assert maybe.ap(other_maybe) == Maybe.just(6)

    maybe = Maybe.nothing()
    assert maybe.ap(other_maybe) == Maybe.nothing()



# Generated at 2022-06-21 19:22:55.672429
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    class MyException(Exception):
        pass

    assert Maybe.just('a').to_either() == Right('a')
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(MyException('Error')).to_either() == Right(MyException('Error'))
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:22:58.849958
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.assertion import assert_that
    from pymonet.either import Right

    assert_that(Maybe.just(4), Right(4))
    assert_that(Maybe.just('Hello'), Right('Hello'))
    assert_that(Maybe.nothing(), Right(None))


# Generated at 2022-06-21 19:23:01.560181
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert(Maybe.just(10).to_try() == Try(10))
    assert(Maybe.nothing().to_try() == Try(None, False))



# Generated at 2022-06-21 19:23:05.203775
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    print('Maybe to_validation - ok')


# Generated at 2022-06-21 19:23:10.496729
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-21 19:23:14.514657
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def mapper(x):
        return x * 2
    mb = Maybe.just(mapper)
    mba = Maybe.just(1)

    assert mb.ap(mba).value == 2



# Generated at 2022-06-21 19:23:17.625393
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:23:21.239793
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(10, True) == Maybe.nothing()
    assert Maybe(10, False) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just('10')



# Generated at 2022-06-21 19:23:24.649534
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    double = lambda x: 2 * x
    four = Maybe.just(2).ap(Maybe.just(double))
    assert four == Maybe.just(4)


# Generated at 2022-06-21 19:23:36.606404
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)

    with pytest.raises(AttributeError) as ex:
        assert Maybe.nothing().value == 1
        assert str(ex.value) == "'Maybe[None]' object has no attribute 'value'"

    with pytest.raises(AttributeError) as ex:
        assert Maybe.nothing().is_nothing == False
        assert str(ex.value) == "'Maybe[None]' object has no attribute 'is_nothing'"

    assert Maybe.just(None).is_nothing == False
    assert Maybe.just(1).value == 1

# Unit

# Generated at 2022-06-21 19:23:42.634008
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # GIVEN
    m1 = Maybe.just(1)
    m2 = Maybe.nothing()

    # WHEN
    def add_one(v):
        return Maybe.just(v + 1)

    # THEN
    assert m1.bind(add_one) == Maybe.just(2)
    assert m2.bind(add_one) == Maybe.nothing()

# Generated at 2022-06-21 19:23:47.938310
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    assert Maybe.just(3).map(lambda x: x + 1) == Maybe.just(4)
    assert Maybe.just(3).map(lambda x: x + 1).map(lambda x: x * 2) == Maybe.just(8)



# Generated at 2022-06-21 19:23:54.966574
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.monad_try import Try

    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.just(Try(1, is_success=True)) == Maybe.just(Try(1, is_success=True))
    assert not Maybe.just(Try(1, is_success=True)) == Maybe.just(Try(1, is_success=False))
    assert Maybe.just(Try(1, is_success=True)) != Maybe.just(Try(1, is_success=False))



# Generated at 2022-06-21 19:23:58.384558
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(
        1
    ).get_or_else(
        0
    ) == 1
    assert Maybe.nothing().get_or_else(
        0
    ) == 0


# Generated at 2022-06-21 19:24:04.372573
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    >>> test_Maybe_map()
    True
    """
    return Maybe(3, False).map(lambda x: x + 2) == Maybe(5, False)


# Generated at 2022-06-21 19:24:06.114702
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:24:11.672125
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(1, False).value == 1
    assert Maybe(None, True).value is None
    assert Maybe(1, False).is_nothing is False
    assert Maybe(None, True).is_nothing is True


# Generated at 2022-06-21 19:24:14.760504
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(1, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:24:18.360348
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(3) == 1
    assert Maybe.just(2).get_or_else(3) == 2
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-21 19:24:24.742359
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # arrange
    maybe1 = Maybe.just(12)
    expected_result1 = 12
    # act
    result1 = (maybe1.to_box()).unbox()
    # assert
    assert result1 == expected_result1

    # arrange
    maybe2 = Maybe.nothing()
    expected_result2 = None
    # act
    result2 = (maybe2.to_box()).unbox()
    # assert
    assert result2 == expected_result2


# Generated at 2022-06-21 19:24:28.822024
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(3) == 5
    assert Maybe.nothing().get_or_else(3) == 3



# Generated at 2022-06-21 19:24:31.778828
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:24:35.071336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from ut.monet.helpers import med_or_empty

    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert med_or_empty('abcabc').filter(lambda x: x == 'a') == Maybe.nothing()


# Generated at 2022-06-21 19:24:37.215266
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(10) == 1
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-21 19:24:46.844382
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(2, False).to_either() == Right(2)
    assert Maybe(None, False).to_either() == Right(None)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-21 19:24:56.240591
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(
        Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    ), "Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)"

    assert(
        Maybe.just(-1).filter(lambda x: x > 0) == Maybe.nothing()
    ), "Maybe.just(-1).filter(lambda x: x > 0) == Maybe.nothing()"

    assert(
        Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()
    ), "Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()"


# Generated at 2022-06-21 19:24:59.527532
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 5).ap(Maybe.just(4)) == Maybe.just(9)
    assert Maybe.just(lambda x: x + 3).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:25:06.136993
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-21 19:25:11.284143
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(v):
        return Maybe.just(v + 1)

    def mapper1(v):
        return Maybe.nothing()

    assert Maybe.just(1).bind(mapper) == Maybe.just(2)
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()


# Generated at 2022-06-21 19:25:13.413337
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:25:19.332191
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad import Identity

    test_maybe = Maybe.just(2)
    test_applicative = Maybe.just(lambda x: x * 2)
    test_wrong_applicative = Maybe.nothing()

    assert test_maybe.ap(test_applicative) == Maybe.just(4)
    assert test_wrong_applicative.ap(test_applicative) == Maybe.nothing()
    assert test_maybe.ap(test_wrong_applicative) == Maybe.nothing()
    assert test_maybe.ap(Identity.of(lambda x: x * 2)) == Maybe.just(4)



# Generated at 2022-06-21 19:25:29.492508
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_validation import Validation

    assert Maybe(
        1
    ).to_validation() == Validation.success(1)

    assert Maybe(
        'string'
    ).to_validation() == Validation.success('string')

    assert Maybe(
        None
    ).to_validation() == Validation.success(None)

    # Test with list of operations
    assert Maybe(
        1
    ).map(
        lambda a: a * 2
    ).map(
        lambda a: a / 2
    ).to_validation() == Validation.success(1)

    assert Maybe(
        1
    ).map(
        lambda a: a * 2
    ).map(
        lambda a: a / 2
    ).to_valid

# Generated at 2022-06-21 19:25:33.911594
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    _ = Maybe.just(None)
    assert Maybe.just(1).bind(lambda a: Maybe.just(a)) == Maybe.just(1)
    assert Maybe.nothing().bind(lambda a: Maybe.just(a)) == Maybe.nothing()


# Generated at 2022-06-21 19:25:37.889561
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1) == Maybe.just(1).filter(lambda x: x > 0)
    assert Maybe.nothing() == Maybe.just(1).filter(lambda x: x < 0)



# Generated at 2022-06-21 19:25:52.020091
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Successful and empty Maybe
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    # Successful and not empty Maybe
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    # Failing Maybe
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:25:56.882819
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != None
    assert Maybe.nothing() != None



# Generated at 2022-06-21 19:26:00.649592
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:26:04.048115
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:26:09.272328
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation(True, 1)
    assert Maybe.nothing().to_validation() == Validation(True, None)


# Generated at 2022-06-21 19:26:15.555818
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :return: nothing
    """
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 2) == Maybe(2, False).to_lazy()
    assert Lazy(lambda: None) == Maybe(None, True).to_lazy()


# Generated at 2022-06-21 19:26:20.987906
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit test for Maybe.

    :returns: True when test passed
    :rtype: Boolean
    """
    def _test_maybe():
        assert Maybe.just(10) == Maybe(10, False)
        assert Maybe.just(10) != Maybe(10, True)
        assert Maybe.nothing() == Maybe(None, True)
        assert Maybe.nothing() != Maybe(None, False)
        return True
    return _test_maybe()

# Generated at 2022-06-21 19:26:23.131767
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:26:29.410197
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe(1, is_nothing=False)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('string') != Maybe.just(2)
    assert Maybe.just('string') != Maybe(2, is_nothing=False)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe(1, is_nothing=False) != Maybe.nothing()



# Generated at 2022-06-21 19:26:34.470098
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1), \
        'Maybe.just(1).to_box() should return Box(1)'
    assert Maybe.nothing().to_box() == Box(None), \
        'Maybe.nothing().to_box() should return Box(None)'


# Generated at 2022-06-21 19:26:49.552563
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:26:54.183837
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.nothing() == Maybe.nothing()) == True
    assert (Maybe.nothing() == Maybe.just(1)) == False
    assert (Maybe.just(1) == Maybe.just(1)) == True
    assert (Maybe.just(1) == Maybe.just(2)) == False

# Generated at 2022-06-21 19:27:00.309345
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
        Tests for map method.
    """
    double = lambda x: x * 2

    res1 = Maybe.just(3).map(double)
    res2 = Maybe.just(0).map(double)
    assert res1 == Maybe.just(6)
    assert res2 == Maybe.just(0)
    assert Maybe.nothing().map(double) == Maybe.nothing()


# Generated at 2022-06-21 19:27:06.579258
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    validation = Maybe.just(0).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get_or_else(1) == 0

    validation = Maybe.nothing().to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success()
    assert validation.get_or_else(1) == None


# Generated at 2022-06-21 19:27:15.045410
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_list import List
    from pymonet.monad_either import Right
    from pymonet.monad_maybe import Maybe

    assert Maybe.just(2).bind(lambda x: Right(x)) == Right(2)
    assert Maybe.nothing().bind(lambda x: Right(x)) == Maybe.nothing()

    assert Maybe.just(2).bind(lambda x: List.unit(x)) == List.unit(2)
    assert Maybe.nothing().bind(lambda x: List.unit(x)) == Maybe.nothing()

    assert Maybe.just(2).bind(lambda x: Maybe.unit(x)) == Maybe.unit(2)
    assert Maybe.nothing().bind(lambda x: Maybe.unit(x)) == Maybe.unit(None)

    # Assert that method binds different types of monads with different

# Generated at 2022-06-21 19:27:17.379705
# Unit test for constructor of class Maybe
def test_Maybe():
    nothing = Maybe.nothing()
    assert nothing.is_nothing == True

    something = Maybe.just(1)
    assert something.value == 1
    assert something.is_nothing == False

if __name__ == '__main__':
    test_Maybe()

# Generated at 2022-06-21 19:27:20.035573
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    assert Maybe.just(Box(1)).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:27:24.698131
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:27:32.426666
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import List
    from pymonet.monad_either import Left, Right

    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(List.unit([1, 2])) == List.unit([2, 3])
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Left(1)) == Left(1)



# Generated at 2022-06-21 19:27:43.849670
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import pymonet.utils

    assert \
        Maybe.just(10) \
            .bind(lambda x: Maybe.just(x * 2)) \
            .bind(lambda x: Maybe.just(x / 2)) \
            .bind(lambda x: Maybe.just(x + 1)) == Maybe.just(11)

    assert \
        Maybe.nothing() \
            .bind(lambda x: Maybe.just(x * 2)) \
            == Maybe.nothing()

    assert \
        Maybe.just(10) \
            .bind(lambda x: Maybe.nothing()) \
            == Maybe.nothing()

    assert \
        Maybe.just(10) \
            .bind(pymonet.utils.get_if(lambda x: x % 2 == 0, lambda x: x)) \
            == Maybe.just(10)

   

# Generated at 2022-06-21 19:28:02.494915
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import List

    x = Maybe.just(lambda x: x * 2)
    y = List([1, 2, 3])

    assert x.ap(y) == List([2, 4, 6])

    x = Maybe.nothing()
    y = List([1, 2, 3])

    assert x.ap(y) == List([])

if __name__ == '__main__':
    test_Maybe_ap()

# Generated at 2022-06-21 19:28:08.979990
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit tests for Maybe class constructor.
    """
    from pymonet.lazy import Lazy

    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(7)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(5).map(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()

    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-21 19:28:16.061732
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.just('ololo').get_or_else('') == 'ololo'
    assert Maybe.just(True).get_or_else(False) is True
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.nothing().get_or_else('') == ''
    assert Maybe.nothing().get_or_else(False) is False


# Generated at 2022-06-21 19:28:19.722256
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe_with_value = Maybe.just(13)
    maybe_without_value = Maybe.nothing()
    assert maybe_with_value.to_box() == Box(13)
    assert maybe_without_value.to_box() == Box(None)

# Generated at 2022-06-21 19:28:28.976410
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(6) == 5
    assert Maybe.nothing().get_or_else(6) == 6
    assert Maybe.just(7).get_or_else(6) == 7
    assert Maybe.nothing().get_or_else(6) == 6
    assert Maybe.just(8).get_or_else(6) == 8
    assert Maybe.nothing().get_or_else(6) == 6
    assert Maybe.just(9).get_or_else(6) == 9
    assert Maybe.nothing().get_or_else(6) == 6

# Generated at 2022-06-21 19:28:36.787601
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    # Test for not empty Maybe
    value = 123
    maybe_value = Maybe(value, False)

    lazy_value = maybe_value.to_lazy()

    functor_value = Functor.fmap(lazy_value, lambda value: value + 1)
    applicative_value = Applicative.pure(lazy_value, 456)
    applicative_value = Applicative.ap(lazy_value, applicative_value)
    monad_value = Monad.flat_map(lazy_value, lambda value: Maybe.just(value * 2))

    assert isinstance(maybe_value, Maybe) is True

# Generated at 2022-06-21 19:28:47.868027
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test Maybe.bind() method.

    :returns: None
    :rtype: None
    """
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def add_eight(int_value: int) -> Right[int]:
        """
        Adds 8 to int value.

        :param int_value: int value
        :type int_value: int
        :returns: Right monad with added 8
        :rtype: Right[int]
        """
        return Right(int_value + 8)

    assert Maybe(8, False).bind(add_eight) == Maybe(16, False)

# Generated at 2022-06-21 19:28:53.257630
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x - 1) == Maybe.just(0)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:28:56.864026
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:28:59.991704
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:29:35.706697
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Asserts that Maybe.ap method works as expected

    :returns: None
    :rtype: None
    """
    from pymonet.applicative import Applicative
    from pymonet.applicative_maybe import ApplicativeMaybe
    from pymonet.box import Box
    import operator

    adder = Box(operator.add)
    adder_maybe = ApplicativeMaybe(adder.unbox())

    def adder_mapper(boxed_value: Box[int]) -> ApplicativeMaybe[int]:
        return adder_maybe.map(boxed_value.unbox())

    assert Maybe.just(1).ap(Maybe.just(Box(2)).map(adder_mapper)) == Maybe.just(3)

# Generated at 2022-06-21 19:29:37.103163
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)


# Generated at 2022-06-21 19:29:39.944586
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)


# Generated at 2022-06-21 19:29:45.197324
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-21 19:29:52.373519
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.nothing() is False
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(4) == Maybe.just(5) is False
    assert Maybe.just(4) == Maybe.just('4') is False
    assert Maybe.just(2) == 3 is False
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:29:57.957991
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != 10
    assert Maybe.just(10) != [10]
    assert Maybe.just(10) != {'value': 10, 'is_nothing': False}



# Generated at 2022-06-21 19:30:08.644643
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test Maybe.ap(self, applicative)

    Should return new Maybe with result of function
    when applicative contains function, in other case
    returns copy of itself
    """
    from pymonet.validation import Validation

    def function(arg):
        return arg * 2

    assert Maybe.just(function).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.just(function).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(function).ap(Validation.success(2)) == Maybe.just(4)
    assert Maybe.just(function).ap(Validation.fail([None])) == Maybe.nothing

# Generated at 2022-06-21 19:30:14.712085
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of class Maybe.

    :returns: None
    """
    def add_one(num: int) -> int:
        """
        Add one for given number.

        :param num: number for processing
        :type num: int
        :returns: result of processing
        :rtype: int
        """
        return num + 1

    # Test for value 4
    assert Maybe.just(4).map(add_one) == Maybe.just(5)

    # Test for None
    assert Maybe.nothing().map(add_one) == Maybe.nothing()



# Generated at 2022-06-21 19:30:19.278555
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1).get_or_else(None) == 1
    assert Maybe.just(2).filter(lambda x: x == 1).get_or_else(None) is None



# Generated at 2022-06-21 19:30:27.600769
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda value: value).get_or_else(False) is True
    assert Maybe.just(False).filter(lambda value: value).get_or_else(True) is True
    assert Maybe.just(True).filter(lambda value: value)\
        .filter(lambda value: value).get_or_else(True) is True
    assert Maybe.just(True).filter(lambda value: value)\
        .filter(lambda value: value).filter(lambda value: False).get_or_else(True) is True
    assert Maybe.just(False).filter(lambda value: value).get_or_else(False) is False
    assert Maybe.nothing().filter(lambda value: True).get_or_else(True) is True
