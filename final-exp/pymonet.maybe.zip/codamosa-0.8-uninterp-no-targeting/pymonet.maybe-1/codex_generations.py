

# Generated at 2022-06-21 19:20:49.069129
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter method.

    :returns: None
    :rtype: None
    """
    import pytest

    maybe = Maybe.just(1)
    assert maybe.filter(lambda x: True) == Maybe.just(1)
    assert maybe.filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-21 19:20:52.494660
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(5) == 5
    assert Maybe.just(0).get_or_else(5) == 0

# Generated at 2022-06-21 19:20:54.101141
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:20:57.159600
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.just(3).get_or_else(1) == 3


# Generated at 2022-06-21 19:21:04.933511
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try

    l = Maybe.just(42).to_lazy()
    assert l.get() == 42

    l = Maybe.nothing().to_lazy()
    assert l.get() == None

    # Test with transformation from Maybe to other monads
    assert Try.unit(l.get) == Try(42, True)
    assert Try.unit(l.get) == Try(None, False)

# Generated at 2022-06-21 19:21:09.631625
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    try:
        from pymonet.validation import Validation
    except ImportError:
        pass
    else:
        assert Maybe.just(lambda x: x * 2).ap(Validation.success(3)) == Maybe.just(6)
        assert Maybe.nothing().ap(Validation.failure(["Error"])) == Maybe.nothing()


# Generated at 2022-06-21 19:21:12.989172
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(100).to_box() == Box(100)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:21:14.851944
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:21:19.571847
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.just(5) != 6
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)


# Generated at 2022-06-21 19:21:22.194307
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 5) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 5) == Maybe.nothing()


# Generated at 2022-06-21 19:21:36.791853
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pytest
    from pymonet.validation import Validation

    success = Maybe.just(42) # => Just(42)
    success_validation = success.to_validation()
    assert isinstance(success_validation, Validation)
    assert success_validation.is_success()

    failure = Maybe.nothing()
    failure_validation = failure.to_validation()
    assert isinstance(failure_validation, Validation)
    assert failure_validation.is_success()

    assert success_validation.with_default(0) == 42
    assert failure_validation.with_default(0) == 0


# Generated at 2022-06-21 19:21:43.110965
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def f1(a: int) -> int:
        return 2*a

    def f2(b: int) -> int:
        return 3*b

    f1_box = Maybe.just(f1)
    f2_box = Maybe.just(f2)

    assert f1_box.ap(Maybe.just(1)) == Maybe.just(2)
    assert f1_box.ap(Maybe.just(2)).ap(f2_box) == Maybe.just(12)
    assert f2_box.ap(f1_box.ap(Maybe.just(2))) == Maybe.just(12)

    f1_box_none = Maybe.nothing().ap(Maybe.just(f1))
    f2_box_none = Maybe.just(f2).ap(Maybe.nothing())

    assert f1_box

# Generated at 2022-06-21 19:21:48.147877
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    success_test = Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    failure_test = Maybe.nothing().to_lazy() == Lazy(lambda: None)
    return success_test and failure_test


# Generated at 2022-06-21 19:21:52.871387
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failed

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:21:56.560897
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    m_just = Maybe.just(3)
    assert m_just.get_or_else(2) == 3
    m_nothing = Maybe.nothing()
    assert m_nothing.get_or_else(2) == 2



# Generated at 2022-06-21 19:22:00.489931
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(2)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(2)) == Maybe.nothing()



# Generated at 2022-06-21 19:22:04.931685
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert str(Maybe.just(1).to_validation()) == "Success[1]"
    assert str(Maybe.nothing().to_validation()) == "Success[None]"
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:08.704656
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(5).to_try() == Try(5, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-21 19:22:13.372285
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:22:17.940466
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just("test").to_validation().is_success
    assert "test" == Maybe.just("test").to_validation().value
    assert not Maybe.nothing().to_validation().is_success
    assert None == Maybe.nothing().to_validation().value



# Generated at 2022-06-21 19:22:25.974699
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()  # unchanged


# Generated at 2022-06-21 19:22:30.983187
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # Given
    x, y, z = 1, Maybe(10, False), Maybe(None, True)

    # When
    x_try, y_try, z_try = x.to_try(), y.to_try(), z.to_try()

    # Then
    assert x_try.is_success() and x_try.value == x
    assert y_try.is_success() and x_try.value == y
    assert not z_try.is_success() and z_try.value is None

test_Maybe_to_try()

# Generated at 2022-06-21 19:22:34.767490
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(17)
    assert maybe.get_or_else(0) == 17

    maybe = Maybe.nothing()
    assert maybe.get_or_else(21) == 21



# Generated at 2022-06-21 19:22:40.099852
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(4).to_validation() == Validation.success(4)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(4).to_validation() != Validation.fail(4)
    assert Maybe.nothing().to_validation() != Validation.fail(None)

# Generated at 2022-06-21 19:22:45.386334
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Nothing().get_or_else(10) == 10
    assert Box(2).get_or_else(10) == 2
    assert Nothing().get_or_else(None) is None
    assert Box(None).get_or_else(None) is None


# Generated at 2022-06-21 19:22:48.685268
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:22:51.852187
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try.new(None, is_success=False)
    assert Maybe.just(1).to_try() == Try.new(1, is_success=True)


# Generated at 2022-06-21 19:22:54.709643
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Box(1) == Maybe.just(1).to_box() == \
        Maybe.just(1).to_box() == \
        Maybe.just(1).to_box()



# Generated at 2022-06-21 19:22:58.111075
# Unit test for method map of class Maybe
def test_Maybe_map():
    def add_three(value: int) -> int:
        return value + 3

    assert Maybe.just(2).map(add_three) == Maybe(5, False)
    assert Maybe.nothing().map(add_three) == Maybe(None, True)



# Generated at 2022-06-21 19:22:59.916443
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:08.873277
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 5) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-21 19:23:11.675076
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value > 2

    assert Maybe(1, False).filter(filterer) == Maybe.nothing()
    assert Maybe(None, True).filter(filterer) == Maybe.nothing()
    assert Maybe(3, False).filter(filterer) == Maybe.just(3)



# Generated at 2022-06-21 19:23:15.027002
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(2, False).map(lambda x: x + 1) == Maybe(3, False)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:23:17.923533
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(5, False).bind(lambda x: Maybe(x**2, False)) == Maybe(25, False)
    assert Maybe(5, True).bind(lambda x: Maybe(x**2, False)) == Maybe(None, True)


# Generated at 2022-06-21 19:23:29.884771
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    m3 = Maybe.just(1)
    m4 = Maybe.just(None)
    m5 = Maybe.nothing()
    m6 = Maybe.nothing()

    assert(m1 == m1)
    assert(m2 == m2)
    assert(m3 == m3)
    assert(m4 == m4)
    assert(m5 == m5)
    assert(m6 == m6)
    assert(not (m1 == m2))
    assert(not (m1 == m3))
    assert(not (m1 == m4))
    assert(not (m1 == m5))
    assert(not (m1 == m6))
    assert(not (m2 == m3))

# Generated at 2022-06-21 19:23:36.669127
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left

    def mapper(x):
        return Left(x)

    empty_maybe: Maybe[int] = Maybe.nothing()
    not_empty_maybe: Maybe[int] = Maybe.just(2)

    assert not_empty_maybe.bind(mapper) == Left(2)
    assert empty_maybe.bind(mapper) == Maybe.nothing()



# Generated at 2022-06-21 19:23:40.330121
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)

test_Maybe_to_validation()


# Generated at 2022-06-21 19:23:44.498162
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:23:50.859676
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    success_validation = Maybe(1, False).to_validation()
    assert isinstance(success_validation, Validation) and success_validation.value == 1

    empty_validation = Maybe.nothing().to_validation()
    assert isinstance(empty_validation, Validation) and empty_validation.value == None



# Generated at 2022-06-21 19:23:56.120716
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test transform Maybe to Box.

    :returns: None
    """
    assert Maybe(1, False).to_box() == Box(1)

    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-21 19:24:07.324620
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.list import List

    def bind_one(x):
        return List.from_iterable([x])

    def bind_two(x):
        return List.from_iterable([x, x])

    assert Maybe.just(1).bind(bind_one) == List.from_iterable([1])
    assert Maybe.just(1).bind(bind_two) == List.from_iterable([1, 1])
    assert Maybe.nothing().bind(bind_one) == List.from_iterable([])
    assert Maybe.nothing().bind(bind_two) == List.from_iterable([])


# Generated at 2022-06-21 19:24:11.430580
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(42, False).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:24:18.632200
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    from pymonet.validation import Validation, ValidationResult

    a = Maybe.just(lambda x: x * 3)
    b = Maybe.just(3)

    c = a.ap(b)
    assert type(c) == Maybe
    assert c == Maybe.just(9)

    a = Maybe.nothing()
    b = Maybe.just(3)
    c = a.ap(b)
    assert type(c) == Maybe
    assert c == Maybe.nothing()

    a = Maybe.just(lambda x: x * 3)
    b = Maybe.nothing()
    c = a.ap(b)
    assert type(c) == Maybe
    assert c == Maybe.nothing()



# Generated at 2022-06-21 19:24:20.836000
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    result = Maybe.just(None).to_box()
    expected = Box(None)
    assert result == expected

# Generated at 2022-06-21 19:24:23.311930
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box().value == None
    assert Maybe.just(25).to_box().value == 25


# Generated at 2022-06-21 19:24:24.843615
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Unit test for method to_lazy of class Maybe."""
    assert Maybe(2, False).to_lazy() == Lazy(lambda: 2)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:24:29.279874
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(Box(100)).to_box() == Box(100)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:37.542319
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_list import List

    assert Maybe.just(3).map(lambda x: x * 3) == Maybe.just(9)
    assert Maybe.just("a").map(lambda x: x + "b") == Maybe.just("ab")
    assert Maybe.just("a").map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 4) == Maybe.nothing()
    assert Maybe.just(List.just("a")).map(lambda x: x.map(lambda y: y + "b")) == Maybe.just(List.just("ab"))
    assert Maybe.just(List.just("a")).map(lambda x: x.map(lambda y: None)) == Maybe.just(List.nothing())

# Generated at 2022-06-21 19:24:41.218457
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right, Either

    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.just(True).to_box() == Box(True)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:24:43.334115
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_list import List

    m = Maybe.just(3)
    def f(x):
        return List.just(x)
    assert m.bind(f) == List.unit(3)


# Generated at 2022-06-21 19:24:50.543168
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    monad_maybe = Maybe.just(5)
    assert monad_maybe.to_try() == Try(5, is_success=True)

    monad_maybe = Maybe.nothing()
    assert monad_maybe.to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:24:53.609033
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(True).to_try() == Try(True, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:24:57.362294
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import ListMonad

    assert Maybe.just(lambda x: x + 5).ap(ListMonad.of(Maybe.just(2))) \
        == ListMonad.of(Maybe.just(7))

# Generated at 2022-06-21 19:25:00.329106
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(False) != Maybe.just(True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()

# Generated at 2022-06-21 19:25:08.732923
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(3)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)

    assert Maybe.just(5).get_or_else(7) == 5
    assert Maybe.nothing().get_or_else(7) == 7



# Generated at 2022-06-21 19:25:09.920299
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    instance = Maybe.just(lambda x: x + 1)
    assert instance.ap(Maybe(4, False)) == Maybe(5, False)


# Generated at 2022-06-21 19:25:14.159517
# Unit test for method map of class Maybe
def test_Maybe_map():
    value = Maybe.just(5)
    actual = value.map(lambda x: x + 1)
    expected = Maybe.just(6)
    assert actual == expected
    actual = Maybe.nothing().map(lambda x: x + 1)
    assert actual == Maybe.nothing()


# Generated at 2022-06-21 19:25:18.153346
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Test 1: Try | success
    my_maybe = Maybe.just('a')
    assert my_maybe.to_lazy() == Lazy(lambda: 'a')

    # Test 2: Try | fail
    my_maybe = Maybe.nothing()
    assert my_maybe.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:25:21.807600
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(2, False).bind(lambda x: Maybe.just(x + 2)) == Maybe(4, False)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()


# Generated at 2022-06-21 19:25:25.900187
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe = Maybe.just(1)
    assert maybe.to_try() == Try.unit(1)
    maybe = Maybe.just(1).map(lambda x: x + 10)
    assert maybe.to_try() == Try.unit(11)



# Generated at 2022-06-21 19:25:41.723514
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    actual = Maybe.just(1).get_or_else(3)  # type: int
    expected = 1  # type: int
    assert actual == expected, \
        'Actual %s but expected %s' % (actual, expected)

    actual = Maybe.nothing().get_or_else(3)  # type: int
    expected = 3  # type: int
    assert actual == expected, \
        'Actual %s but expected %s' % (actual, expected)


# Generated at 2022-06-21 19:25:47.657673
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x + 2) == Maybe.just(5)
    assert Maybe.just(3).map(lambda x: x + 2).value == 5
    assert Maybe.just(3).map(lambda x: x + None) == Maybe.just(None)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-21 19:25:50.336137
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:25:55.468277
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe_some = Maybe.just(1)
    maybe_none = Maybe.nothing()

    # When
    filtered_some = maybe_some.filter(lambda x: x % 2 == 0)
    filtered_none = maybe_none.filter(lambda x: x % 2 == 0)

    # Then
    assert filtered_some is Maybe.nothing()
    assert filtered_none is Maybe.nothing()



# Generated at 2022-06-21 19:26:00.444576
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x*2)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x*2)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:26:05.598361
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy: Lazy[Callable[[], int]] = Maybe.just(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1

    lazy: Lazy[Callable[[], None]] = Maybe.nothing().to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None



# Generated at 2022-06-21 19:26:16.247088
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 3)) == Maybe.just(5)
    assert Maybe.just(2).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.just(x)).bind(lambda x: Maybe.just(x + x)) == Maybe.just(1 + 1)
    assert Maybe.just(1).bind(lambda x: Maybe.just(x)).bind(lambda x: Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:26:18.890923
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just = Maybe.just(42)
    just_another = Maybe.just(42)
    nothing = Maybe.nothing()

    assert just == maybe
    assert just != nothing



# Generated at 2022-06-21 19:26:22.905830
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda value: Maybe.just(value + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda value: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda value: Maybe.just(value + 1)) == Maybe.nothing()

# Generated at 2022-06-21 19:26:27.906169
# Unit test for method map of class Maybe
def test_Maybe_map():
    def transform(x):
        return x ** 2

    result = Maybe.just(10).map(transform)
    expected = Maybe.just(100)

    assert result == expected

    result = Maybe.nothing().map(transform)
    expected = Maybe.nothing()

    assert result == expected



# Generated at 2022-06-21 19:26:37.000719
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe(1, False)



# Generated at 2022-06-21 19:26:39.006889
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert (Maybe.just('value').to_either() ==
            Either.right('value'))



# Generated at 2022-06-21 19:26:41.952894
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def f(x):
        return Maybe.just(x)
    assert Maybe.just(1).bind(f) == Maybe.just(1)
    assert Maybe.nothing().bind(f) == Maybe.nothing()


# Generated at 2022-06-21 19:26:49.714060
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.just(None)



# Generated at 2022-06-21 19:26:53.521156
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:26:57.782271
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:27:07.652158
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(5, False).ap(Maybe(lambda value: value + 2, False)) == Maybe(7, False)
    assert Maybe(None, True).ap(Maybe(lambda value: value + 2, False)) == Maybe(None, True)
    assert Maybe(5, False).ap(Maybe(None, True)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(None, True)) == Maybe(None, True)
    assert Maybe(lambda x: x + 3, False).ap(Maybe(7, False)) == Maybe(10, False)
    assert Maybe(lambda x: x + 3, False).ap(Maybe(None, True)) == Maybe(None, True)



# Generated at 2022-06-21 19:27:11.374837
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.type_var import A
    just_one = Maybe.just[A](1)
    assert just_one.filter(lambda x: x == 1) == Maybe.just(1)
    assert just_one.filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-21 19:27:14.077305
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:27:18.638617
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # Arrange
    # Create Maybe
    maybe_value = Maybe.just(1)
    # Act
    # Transform Maybe to Box
    box = maybe_value.to_box()
    # Assert
    # Check equality
    assert box == Box(1)


# Generated at 2022-06-21 19:27:34.322715
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test import monad_test
    monad_test(Maybe, [
        ('filter', [
            (lambda value: not (value is None), Maybe.nothing(), Maybe.nothing()),
            (lambda value: not (value is None), Maybe.just(1), Maybe.just(1)),
            (lambda value: value < 10, Maybe.just(9), Maybe.just(9)),
            (lambda value: value < 10, Maybe.just(10), Maybe.nothing()),
            (lambda value: value < 10, Maybe.just(11), Maybe.nothing()),
        ])
    ])


# Generated at 2022-06-21 19:27:39.304331
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.just(3).map(lambda x: x + 2) == Maybe.just(5)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()



# Generated at 2022-06-21 19:27:47.430246
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.tuple_monad import TupleMonad
    from pymonet.validation import Validation

    # Apply function from Box to Maybe
    result = Maybe.just(2).ap(Box(lambda x: x + 1))
    assert isinstance(result, Maybe) \
        and not result.is_nothing \
        and result.value == 3

    # Apply function from Right to Maybe
    result = Maybe.just(2).ap(Right(lambda x: x + 1))
    assert isinstance(result, Maybe) \
        and not result.is_nothing \
        and result.value == 3

    # Apply function from

# Generated at 2022-06-21 19:27:51.842953
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-21 19:28:04.324101
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test ap of Maybe.

    :returns: Void
    :rtype: None
    """
    def sum_two_number(number1: int, number2: int) -> int:
        return number1 + number2

    maybe1 = Maybe.just(5)
    maybe2 = Maybe.just(10)

    assert Maybe.just(sum_two_number).ap(maybe1).ap(maybe2) == Maybe.just(15)
    assert Maybe.just(sum_two_number).ap(maybe1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(sum_two_number).ap(Maybe.nothing()).ap(maybe2) == Maybe.nothing()
    assert Maybe.just(sum_two_number).ap(Maybe.nothing()).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:28:08.080327
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:28:14.889815
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    # Arrange
    m_1 = Maybe.just(1)
    m_2 = Maybe.nothing()

    # Act
    m_1_box = m_1.to_box()
    m_2_box = m_2.to_box()

    # Assert
    assert m_1_box == Box(1)
    assert m_2_box == Box(None)



# Generated at 2022-06-21 19:28:18.524207
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just("notempty string").to_box() == Box("notempty string")
    assert Maybe.just(3).to_box() == Box(3)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:28:21.559910
# Unit test for constructor of class Maybe
def test_Maybe():
    instance = Maybe.just("value")
    assert isinstance(instance, Maybe)
    assert not instance.is_nothing
    assert instance.value == "value"



# Generated at 2022-06-21 19:28:24.962661
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:28:36.261681
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:28:42.453827
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(11).bind(lambda x: Maybe.just(x+1)) == Maybe.just(12)

    assert Maybe.just(11).bind(lambda _: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.nothing().bind(lambda _: Maybe.just(11)) == Maybe.nothing()

    assert Maybe.nothing().bind(lambda _: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:28:45.851499
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('hello').get_or_else('default value') == 'hello'
    assert Maybe.nothing().get_or_else('default value') == 'default value'



# Generated at 2022-06-21 19:28:54.009408
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    # Empty Maybe to Try
    maybe = Maybe.nothing()
    result = maybe.to_try()
    assert isinstance(result, Try)
    assert result.is_success is False
    assert result.value is None

    # Not empty Maybe to Try
    maybe = Maybe.just(10)
    result = maybe.to_try()
    assert isinstance(result, Try)
    assert result.is_success is True
    assert result.value == 10


# Generated at 2022-06-21 19:28:58.776339
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:29:00.755793
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:29:05.942367
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.nothing()
    assert Maybe.just(False) == Maybe.just(None)



# Generated at 2022-06-21 19:29:15.016771
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2), \
        "Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) != Maybe.just(2)"
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * 3)) == Maybe.just(6), \
        "Maybe.just(2).bind(lambda x: Maybe.just(x * 3)) == Maybe.just(6)"
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing(), \
        "Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()"



# Generated at 2022-06-21 19:29:17.617471
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just('abcabcabc').to_validation() == Validation.success('abcabcabc')


# Generated at 2022-06-21 19:29:20.011783
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:29:31.239691
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:29:42.919133
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # Given
    test_inputs = [
        # success cases
        {'t': Maybe.just(1), 'f': lambda n: n == 1, 'result': Maybe.just(1)},
        {'t': Maybe.just(1), 'f': lambda n: n == 2, 'result': Maybe.nothing()},
        {'t': Maybe.nothing(), 'f': lambda n: n == 2, 'result': Maybe.nothing()},
        {'t': Maybe.nothing(), 'f': lambda n: n == 2, 'result': Maybe.nothing()},
    ]

    # When
    actual_results = []
    for test_input in test_inputs:
        actual_results.append(
            test_input['t'].filter(test_input['f']) == test_input['result']
        )

    #

# Generated at 2022-06-21 19:29:46.621097
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:29:51.960791
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:29:53.780401
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:29:56.011149
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda v: v + 1) == Maybe(2, False)
    assert Maybe(None, True).map(lambda v: v + 1) == Maybe(None, True)



# Generated at 2022-06-21 19:30:01.218839
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():

    # Maybe is empty, result is successfull Validation with None
    assert Maybe.nothing().to_validation() == Validation.success(None)

    # Maybe is not empty, result is successfull Validation with value
    assert Maybe.just(1).to_validation() == Validation.success(1)



# Generated at 2022-06-21 19:30:11.806090
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit testing method to_try of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try

    assert Maybe(1, False).to_try() == Try(1, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)
    assert Maybe(1, False).to_try().get_or_else(0) == 1
    assert Maybe(None, True).to_try().get_or_else(0) == 0
    assert Maybe(1, False).to_try().map(lambda x: x + 1) == Try(2, is_success=True)

# Generated at 2022-06-21 19:30:19.094646
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x : Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x : Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x : Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x : Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:30:21.187184
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    just = Maybe.just(lambda x: 1 + x)
    just2 = Maybe.just(2)
    nothing = Maybe.nothing()

    # When/Then
    assert just.ap(just2) == Maybe.just(3)
    assert just.ap(nothing) == Maybe.nothing()
    assert nothing.ap(just2) == Maybe.nothing()
    assert nothing.ap(nothing) == Maybe.nothing()
