

# Generated at 2022-06-21 19:20:55.020808
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(42).to_either() == \
        (Right(42))
    assert Maybe.nothing().to_either() == \
        (Left(None))


# Generated at 2022-06-21 19:20:57.994369
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:21:04.674892
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    from pymonet.monad_try import Try

    assert Maybe.just(10).to_either() == Right(10)

    assert Maybe.nothing().to_either() == Left(None)

    assert Try(10).to_either() == Right(10)
    assert Try(10, is_success=False).to_either() == Left(None)


# Generated at 2022-06-21 19:21:12.162457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Case when Maybe is not empty and filterer returns True
    assert Maybe.just(1).filter(lambda value: True) == Maybe.just(1)

    # Case when Maybe is not empty and filterer returns False
    assert Maybe.just(1).filter(lambda value: False) == Maybe.nothing()

    # Case when Maybe is empty and filterer returns True
    assert Maybe.nothing().filter(lambda value: True) == Maybe.nothing()

    # Case when Maybe is empty and filterer returns False
    assert Maybe.nothing().filter(lambda value: False) == Maybe.nothing()


# Generated at 2022-06-21 19:21:15.497196
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(x: int) -> int:
        return x ** x

    def mapper_raise_exception(x: int) -> int:
        raise Exception(str(x))

    # test bind with empty maybe
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()
    assert Maybe.nothing().bind(mapper_raise_exception) == Maybe.nothing()

    # test bind with not empty maybe
    assert Maybe.just(3).bind(mapper) == Maybe.just(mapper(3))
    assert Maybe.just(3).bind(mapper_raise_exception) == Maybe.just(mapper_raise_exception(3))

# Generated at 2022-06-21 19:21:21.016006
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe = Maybe.just(2)
    assert maybe.to_try().is_success()
    assert maybe.to_try().get_or_else(lambda: None) == 2

    maybe = Maybe.nothing()
    assert not maybe.to_try().is_success()
    assert maybe.to_try().get_or_else(lambda: None) is None



# Generated at 2022-06-21 19:21:25.426504
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe.

    :return: None
    """
    from pymonet.validation import Validation, Success, Failure

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:34.034212
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just("str")
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just("str")
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:21:42.047867
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    assert Maybe.just(10).to_lazy() == Box(10).to_lazy()
    assert Maybe.nothing().to_lazy() == Either(None).to_lazy()
    assert Maybe.nothing().to_lazy() == Box(None).to_lazy()



# Generated at 2022-06-21 19:21:50.687353
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), 'Should be equal'
    assert Maybe.nothing() == Maybe.nothing(), 'Should be equal'
    assert Maybe.just(1) != Maybe.just(2), 'Should not be equal'
    assert Maybe.just(1) != Maybe.nothing(), 'Should not be equal'
    assert Maybe.nothing() != Maybe.just(1), 'Should not be equal'
    assert Maybe.just(1).__dict__ != Maybe.just(1).__dict__, 'Should not be equal'



# Generated at 2022-06-21 19:22:02.400600
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_builder import MonadBuilder

    # Test case with not empty Maybe
    assert Maybe.just(
        MonadBuilder.just(2)
    ).map(
        lambda x: MonadBuilder.just(x).to_either()
    ) == Maybe.just(
        MonadBuilder.just(2).to_either()
    )

    # Test case with empty Maybe
    assert Maybe.nothing().map(
        lambda x: MonadBuilder.just(x)
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:22:10.613530
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just([1]) == Maybe.just([1])
    assert Maybe.just([1]) != Maybe.just(1)



# Generated at 2022-06-21 19:22:13.095069
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:22:19.694003
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Map function of class Maybe will call function with value and return new Maybe with result of function.

    :returns: Nothing
    """

    def plus_one(x: int) -> int:
        return x + 1

    maybe_with_int = Maybe.just(1)
    maybe_with_int.map(plus_one)
    assert maybe_with_int == Maybe.just(1)

    maybe_with_nothing = Maybe.nothing()
    maybe_with_nothing.map(plus_one)
    assert maybe_with_nothing == Maybe.nothing()

    print("Test for map method for Maybe passed successfully")



# Generated at 2022-06-21 19:22:29.524819
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    def to_maybe(val):
        return Maybe.just(val)

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

    assert Maybe.just(1).ap(to_maybe(lambda x: x + 10)).to_validation() == Validation.success(11)
    assert Maybe.nothing().ap(to_maybe(lambda x: x + 10)).to_validation() == Validation.success(None)

    assert Maybe.just(1).bind(to_maybe).to_valid

# Generated at 2022-06-21 19:22:36.253682
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_value = Maybe.just('test')
    maybe_nothing = Maybe.nothing()

    def length(text: str) -> int:
        return len(text)

    assert (maybe_value.map(length) == Maybe.just(4))
    assert (maybe_nothing.map(length) == Maybe.nothing())


# Generated at 2022-06-21 19:22:41.005855
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def add(a, b):
        return a + b
    assert Maybe.just(4).to_lazy().unsafe_get()() == 4
    assert Maybe.nothing().to_lazy().unsafe_get()() is None
    assert Maybe.just(2).to_lazy().fmap(lambda x: add(x, x)).unsafe_get()() == 4


# Generated at 2022-06-21 19:22:45.288378
# Unit test for method map of class Maybe
def test_Maybe_map():
    def addOne(x):
        return x + 1

    assert Maybe.just(1).map(addOne) == Maybe.just(2)
    assert Maybe.nothing().map(addOne) == Maybe.nothing()


# Generated at 2022-06-21 19:22:47.816551
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    value = 1
    maybe = Maybe.just(value)
    assert maybe.get_or_else(0) == value

# Generated at 2022-06-21 19:22:54.599578
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of class Maybe.

    We expect that for empty Maybe we return empty Maybe and for not empty
    with value 1 we return new not empty Maybe with value 2.

    :returns: True when test passed, False in other case
    :rtype: Boolean
    """
    return Maybe.nothing().map(lambda value: value + 1) == Maybe.nothing() and\
        Maybe.just(1).map(lambda value: value + 1) == Maybe.just(2)


# Generated at 2022-06-21 19:23:04.706259
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:23:08.970903
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-21 19:23:11.074209
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:23:14.060459
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:23:17.550855
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just('hello').bind(lambda msg: Maybe.just(msg + ' world')) == Maybe.just('hello world')
    assert Maybe.nothing().bind(lambda msg: Maybe.just(msg + ' world')) == Maybe.nothing()


# Generated at 2022-06-21 19:23:29.761205
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    import pytest

    assert Maybe.just(lambda x: x + 1).ap(Box(2)) == Box(3)
    assert Maybe.just(lambda x: x + 1).ap(Lazy(lambda: 2)) == Box(3)
    assert Maybe.just(lambda x: x + 1).ap(Right(2)) == Right(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Try(2, True)) == Try(3, True)
    assert Maybe

# Generated at 2022-06-21 19:23:33.569514
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Arrange
    maybe_a = Maybe.just(1)

    # Act
    actual_result = maybe_a.get_or_else(42)

    # Assert
    assert actual_result == 1


# Generated at 2022-06-21 19:23:37.627678
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else("default_value") == 1
    assert Maybe.nothing().get_or_else("default_value") == "default_value"



# Generated at 2022-06-21 19:23:41.157957
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Just to_try
    """
    assert Maybe(2, False).to_try() == Try(2, True)
    assert Maybe(None, True).to_try() == Try(None, False)


# Generated at 2022-06-21 19:23:46.793540
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:24:02.541828
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

# Generated at 2022-06-21 19:24:05.671016
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:24:09.882571
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-21 19:24:18.416406
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test method bind of class Maybe.

    :returns: True if test succeed, else False
    :rtype: Boolean
    """
    try:
        assert Maybe.bind(Maybe.just(2), lambda x: Maybe.just(x * 3)) == Maybe.just(6)
        assert Maybe.bind(
            Maybe.bind(Maybe.just(3), lambda x: Maybe.just(x * x)),
            lambda x: Maybe.just(x + 1)) == Maybe.just(10)
        assert Maybe.bind(Maybe.nothing(), lambda x: Maybe.just(x + 1)) == Maybe.nothing()
        assert Maybe.bind(Maybe.just(4), lambda x: Maybe.nothing()) == Maybe.nothing()
    except AssertionError:
        return False
    except Exception:
        return False
    return True


#

# Generated at 2022-06-21 19:24:22.823500
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    def test_success():
        assert Maybe.just(1).to_try() == Try(1, is_success=True)

    def test_failure():
        assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:29.786641
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def bind_function(value):
        if value is None:
            return Maybe.nothing()
        else:
            return Maybe.just(value)

    assert Maybe.just(None)\
        .bind(bind_function)\
        .bind(bind_function)\
        .bind(bind_function) == Maybe.nothing()
    assert Maybe.just(1)\
        .bind(bind_function)\
        .bind(bind_function)\
        .bind(bind_function) == Maybe.just(1)



# Generated at 2022-06-21 19:24:33.185529
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit test for method map of class Maybe.
    """

    def add(x: int) -> int:
        return x + 1

    assert Maybe.just(1).map(add) == Maybe.just(2)
    assert Maybe.nothing().map(add) == Maybe.nothing()


# Generated at 2022-06-21 19:24:37.109764
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    actual_result = Maybe.just(1).to_either()
    assert actual_result == Right(1)

    actual_result = Maybe.nothing().to_either()
    assert actual_result == Left(None)



# Generated at 2022-06-21 19:24:43.072571
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # 1. Create not empty Maybe.
    maybe_value = Maybe.just('value')
    # 2. Get Either from maybe_value.
    right_value = maybe_value.to_either()
    # 3. Create empty Maybe.
    maybe_empty = Maybe.nothing()
    # 4. Get Either from maybe_empty.
    left_empty = maybe_empty.to_either()
    # 5. Check equals of values.
    assert right_value.is_right()
    assert right_value.right.value == 'value'
    assert left_empty.is_left()
    assert left_empty.left.value is None



# Generated at 2022-06-21 19:24:45.670880
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-21 19:25:02.258388
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def do_box(value: None):
        return Maybe.nothing().to_box()

    assert do_box(None) == Box(None)

    def do_box(value: int):
        return Maybe.just(value).to_box()

    assert do_box(1) == Box(1)


# Generated at 2022-06-21 19:25:05.010240
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    value = Maybe.just(lambda x: x + 1)
    assert Maybe.just(1).ap(value).get_or_else(None) == 2



# Generated at 2022-06-21 19:25:10.048918
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe_box = Maybe.just(Box(5))
    maybe_box2 = Maybe.nothing().to_box()
    assert (maybe_box == Maybe.just(Box(5)))
    assert (maybe_box2 == Maybe.just(Box(None)))


# Generated at 2022-06-21 19:25:12.052761
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(12).map(lambda x: x + 2) == Maybe.just(14)


# Generated at 2022-06-21 19:25:18.085327
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    eq = Maybe.just(1) == Maybe.just(1)
    assert eq == True

    eq = Maybe.nothing() == Maybe.nothing()
    assert eq == True

    eq = Maybe.just(1) == Maybe.nothing()
    assert eq == False

    eq = Maybe.just(1) == Maybe.just(2)
    assert eq == False

    eq = Maybe.nothing() == Maybe.just(2)
    assert eq == False


# Generated at 2022-06-21 19:25:22.602660
# Unit test for constructor of class Maybe
def test_Maybe():

    maybe_just = Maybe(13, False)
    assert maybe_just.value == 13
    assert maybe_just.is_nothing == False

    maybe_nothing = Maybe(0, True)
    assert maybe_nothing.value == 0
    assert maybe_nothing.is_nothing == True


# Generated at 2022-06-21 19:25:25.467202
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-21 19:25:28.632457
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just('a').to_box() == Box('a')
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:25:32.733392
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(a):
        return lambda b: a + b

    assert Maybe.just(1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(add).ap(Maybe.just(1)).ap(Maybe.just(1)) == Maybe.just(2)



# Generated at 2022-06-21 19:25:37.273716
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:26:09.984546
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(1).get_or_else(2) == 1)
    assert(Maybe.just(1).get_or_else(2) == 1)
    assert(Maybe.nothing().get_or_else(2) == 2)

# Generated at 2022-06-21 19:26:20.088092
# Unit test for method __eq__ of class Maybe

# Generated at 2022-06-21 19:26:26.750552
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation

    def _func(value):
        return value + 2

    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(_func).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(_func).ap(Maybe.just(1)) == Maybe.just(3)
    assert Maybe.nothing().ap(Validation.success(1)) == Maybe.nothing()
    assert Maybe.just(_func).ap(Validation.success(1)) == Maybe.just(3)

# Generated at 2022-06-21 19:26:32.893469
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    nothing1: Maybe[None] = Maybe.nothing()
    nothing2: Maybe[None] = Maybe(None, True)
    assert nothing1 == nothing2

    box1: Maybe[int] = Maybe.just(5)
    box2: Maybe[int] = Maybe(5, False)
    assert box1 == box2

    assert nothing1 != box1
    assert box1 != nothing1
    assert box1 != box2


# Generated at 2022-06-21 19:26:39.368656
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """Unit test for method to_validation of class Maybe."""
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    # Run the tests
    test_Maybe_to_validation.__doc__ = 'Unit test for method to_validation of class Maybe.'


# Generated at 2022-06-21 19:26:41.321410
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:26:47.602225
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:26:52.654675
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """Test method to_box of class Maybe."""
    maybe_of_10 = Maybe.just(10)
    assert maybe_of_10.to_box() == Box(10)

    maybe_of_none = Maybe.nothing()
    assert maybe_of_none.to_box() == Box(None)


# Generated at 2022-06-21 19:27:03.550703
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.the(None)
    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.the(None) != Maybe.the(None)
    assert Maybe.the(None) != Maybe.just(1)
    assert Maybe.the(None) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.the(None)
    assert not (Maybe.just(1) != Maybe.just(1))

# Generated at 2022-06-21 19:27:08.181812
# Unit test for constructor of class Maybe
def test_Maybe():
    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    m3 = Maybe.nothing()

    assert m1.is_nothing == False
    assert m1.value == 1
    assert m2.is_nothing == False
    assert m2.value == 2
    assert m3.is_nothing == True



# Generated at 2022-06-21 19:28:13.803328
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda a: a > 2) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda a: a > 4) == Maybe.nothing()
    assert Maybe.just('a').filter(lambda a: a > 'b') == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a > 'b') == Maybe.nothing()


# Generated at 2022-06-21 19:28:17.179402
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x % 2 == 0) == Maybe.just(42)
    assert Maybe.just(42).filter(lambda x: x % 2 != 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()

# Generated at 2022-06-21 19:28:22.754928
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Test Just
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 5)) == Maybe.just(10)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    # Test Nothing
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()


# Generated at 2022-06-21 19:28:25.679839
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:28:31.274577
# Unit test for constructor of class Maybe
def test_Maybe():
    # creation with None value return maybe with empty value
    assert Maybe.just(None) == Maybe.nothing()
    # creation with any value not eq to None return maybe with that value
    assert Maybe.just(1) != Maybe.nothing()
    # compare two maybe with same value
    assert Maybe.just(1) == Maybe.just(1)

# Generated at 2022-06-21 19:28:36.637754
# Unit test for method map of class Maybe
def test_Maybe_map():

    assert Maybe.just(2).map(lambda x: x + x) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x * x) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()



# Generated at 2022-06-21 19:28:42.495597
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Transform Maybe to Box.

    :returns: Box monad with previous value when Maybe is not empty, in other case Box with None
    :rtype: Box[A | None]
    """
    from pymonet.box import Box

    if self.is_nothing:
        return Box(None)
    return Box(self.value)



# Generated at 2022-06-21 19:28:45.080337
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x).ap(Maybe.just(1)) == Maybe.just(1)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()

# Generated at 2022-06-21 19:28:47.621287
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.just(1).get_or_else(2) == 1


# Generated at 2022-06-21 19:28:51.085859
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(5)
    assert maybe.to_lazy().value() == 5

    maybe = Maybe.nothing()
    assert maybe.to_lazy().value() is None

# Generated at 2022-06-21 19:29:52.690905
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box().value == 1
    assert Maybe.nothing().to_box().value is None


# Generated at 2022-06-21 19:29:55.889423
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(20).filter(lambda x: x > 10) == Maybe.just(20)
    assert Maybe.just(20).filter(lambda x: x > 30).is_nothing
    assert Maybe.nothing().filter(lambda x: x > 10).is_nothing


# Generated at 2022-06-21 19:30:07.210882
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.monad_try import Try

    # Test constructor maybe when value is None
    m_maybe = Maybe(None, True)
    assert m_maybe.is_nothing == True

    # Test constructor maybe when value is True
    m_maybe = Maybe(None, False)
    assert m_maybe.is_nothing == False and m_maybe.value == None

    # Test constructor maybe when value is True
    m_maybe = Maybe(True, False)
    assert m_maybe.is_nothing == False and m_maybe.value == True

    # Test constructor maybe when value is True
    m_maybe = Maybe(1.0, False)
    assert m_maybe.is_nothing == False and m_maybe.value == 1.0

    # Test constructor maybe when value is True
    m_maybe = Maybe(1, False)


# Generated at 2022-06-21 19:30:10.728664
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:30:12.998867
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:30:20.415457
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    def f(x):
        return x

    assert Maybe.just(1).to_either() == Right(1), 'to_either with not empty Maybe fails'
    assert Maybe.nothing().to_either() == Left(None), 'to_either with empty Maybe fails'
    assert Maybe.just(1).to_either().map(f) == Right(1), 'to_either from Maybe fails'



# Generated at 2022-06-21 19:30:24.197755
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """ Unit test for method to_try of class Maybe """
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-21 19:30:25.667025
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(5)
    assert maybe.get_or_else(None) == 5


# Generated at 2022-06-21 19:30:28.619176
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just('test').to_lazy() == Lazy(lambda: 'test')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:30:40.705464
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just('foo') == Maybe.just('foo')
    assert Maybe.just('bar') == Maybe.just('bar')
    assert Maybe.just('') == Maybe.just('')

    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.just(True) != Maybe.just(False)
    assert Maybe.just(False) != Maybe.just(True)
    assert Maybe.just('foo') != Maybe.just('bar')