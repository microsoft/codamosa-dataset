

# Generated at 2022-06-21 19:20:58.820694
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.just(Box(5)).to_either() == Right(Box(5))
    assert Maybe.just(Lazy(lambda: 5)).to_either() == Right(Lazy(lambda: 5))
    assert Maybe.just(Try(5)).to_either() == Right(Try(5))
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:21:03.753204
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    assert Maybe.just(lambda x: x * 2).ap(Try(1)).to_try() == Try(2, True)
    assert Maybe.nothing().ap(Try(1)).to_try() == Try(None, False)


# Generated at 2022-06-21 19:21:07.995181
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x + 5) == Maybe.nothing()
    assert Maybe.just(3).map(lambda x: x + 5) == Maybe.just(8)
    assert Maybe.just(None).map(lambda x: x + 5) == Maybe.just(None)



# Generated at 2022-06-21 19:21:12.851295
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(
        lambda x: Maybe.just(x + 1)
    ) == Maybe.just(
        2
    )

    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:16.481951
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) is not Maybe.just(1)



# Generated at 2022-06-21 19:21:25.948012
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    maybe_add = Maybe.just(lambda a: lambda b: a + b)
    maybe_two = Maybe.just(2)
    # When
    res = maybe_add.ap(maybe_two)
    # Then
    assert res == Maybe.just(2)
    # When
    res = maybe_add.ap(Maybe.nothing())
    # Then
    assert res == Maybe.nothing()
    # When
    res = Maybe.nothing().ap(maybe_two)
    # Then
    assert res == Maybe.nothing()
    # When
    res = Maybe.nothing().ap(Maybe.nothing())
    # Then
    assert res == Maybe.nothing()



# Generated at 2022-06-21 19:21:30.730173
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, is_nothing=False).to_validation() == Validation.success(1)
    assert Maybe(None, is_nothing=True).to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:21:34.644699
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    value = 'test'
    expected = 'default'
    assert Maybe.just(value).get_or_else(expected) == value
    assert Maybe.nothing().get_or_else(expected) == expected



# Generated at 2022-06-21 19:21:41.440248
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def test_Maybe_to_box_1():
        assert Maybe.just(None).to_box() == Box(None)

    def test_Maybe_to_box_2():
        assert Maybe.nothing().to_box() == Box(None)

    def test_Maybe_to_box_3():
        assert Maybe.just(2).to_box() == Box(2)

    def test_Maybe_to_box_4():
        assert Maybe.just(3).to_box() != Box(2)

    test_Maybe_to_box_1()
    test_Maybe_to_box_2()
    test_Maybe_to_box_3()
    test_Maybe_to_box_4()


# Generated at 2022-06-21 19:21:45.800566
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1), \
        'Should return Right monad'
    assert Maybe.nothing().to_either() == Left(None), \
        'Should return Left monad'


# Generated at 2022-06-21 19:21:51.450659
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just('test').to_try() == Try('test')
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:21:54.592375
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-21 19:21:57.765806
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 1) == Maybe.just(6)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:22:06.257598
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit test for method map of class Maybe.
    """
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Maybe.just(5).map(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.just(5).map(lambda x: Box(x + 2)) == Maybe.just(Box(7))
    assert Maybe.just(5).map(lambda x: Try(x + 1)) == Maybe.just(Try(6))
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-21 19:22:12.319135
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-21 19:22:16.717837
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    assert Maybe.just(1).to_lazy() == Lazy(f)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:22:21.572991
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:26.017703
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:22:30.791396
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    m = Maybe(lambda x: x + 2, False)
    m1 = m.ap(Try(1, is_success=True))

    assert isinstance(m1, Maybe)
    assert m1 == Maybe.just(3)

    m2 = m.ap(Try(1, is_success=False))

    assert isinstance(m2, Maybe)
    assert m2 == Maybe.nothing()

test_Maybe_ap()


# Generated at 2022-06-21 19:22:35.106342
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('a').to_validation() == Validation.success('a')
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:44.268071
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(3, False).to_either() == Either(3, is_left=False)
    assert Maybe(None, True).to_either() == Either(None, is_left=True)


# Generated at 2022-06-21 19:22:48.437907
# Unit test for constructor of class Maybe
def test_Maybe():
    value = Maybe(10, True)
    assert value.is_nothing
    value = Maybe(10, False)
    assert value.value == 10
    assert not value.is_nothing

# Unit tests for function Maybe.just

# Generated at 2022-06-21 19:22:51.603118
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) != Maybe.nothing() != Maybe.just(2) == Maybe(1, False)


# Generated at 2022-06-21 19:22:56.058247
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    test_value = Maybe.just(5)
    result = test_value.to_box()

    assert result.__class__.__name__ == "Box"
    assert result.value == 5

    test_value = Maybe.nothing()
    result = test_value.to_box()

    assert result.__class__.__name__ == "Box"
    assert result.value is None


# Generated at 2022-06-21 19:22:57.778347
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(1)
    box = maybe.to_box()
    assert maybe.value == box.value


# Generated at 2022-06-21 19:23:02.156778
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # when
    just1 = Maybe.just(1)
    just2 = Maybe.just(2)
    just3 = Maybe.just(1)
    nothing = Maybe.nothing()
    nothing_else = Maybe.nothing()

    # then
    assert just1 == just1
    assert just1 == just3
    assert just2 != just1
    assert just2 != just3
    assert nothing == nothing
    assert nothing == nothing_else

# Generated at 2022-06-21 19:23:10.488352
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Set up
    maybe_with_value = Maybe(10, False)
    maybe_with_nothing = Maybe.nothing()

    # Assert
    assert maybe_with_value.map(lambda x: x * 2) == Maybe(20, False)
    assert maybe_with_nothing.map(lambda x: x * 2) == Maybe.nothing()
    assert maybe_with_value.map(lambda x: x * 2) != Maybe(10, False)
    assert maybe_with_nothing.map(lambda x: x * 2) != Maybe(10, False)


# Generated at 2022-06-21 19:23:17.093049
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pytest

    from pymonet.validation import Validation

    maybe_with_value = Maybe(123, False)
    expected_result = Validation.success(123)
    assert maybe_with_value.to_validation() == expected_result

    maybe_without_value = Maybe(None, True)
    expected_result = Validation.success(None)
    assert maybe_without_value.to_validation() == expected_result


# Generated at 2022-06-21 19:23:21.185151
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:23:26.062416
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.try_ import Try

    maybe_success = Maybe.just(1)
    maybe_failure = Maybe.nothing()
    assert maybe_success.to_try() == Try(1, True)
    assert maybe_failure.to_try() == Try(None, False)

# Generated at 2022-06-21 19:23:33.911081
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert maybe.get_or_else(None) == 1

    nothing = Maybe.nothing()
    assert nothing.get_or_else(None) is None



# Generated at 2022-06-21 19:23:38.436820
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:23:44.848453
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Function tests to_box method.

    :return: True if test passed, else raise AssertionError
    :rtype: Boolean
    """

    from pymonet.box import Box

    # Test 1: mapper argument is callable
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

    return True


# Generated at 2022-06-21 19:23:52.118736
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    import pymonet.box as box

    # Given
    maybe = Maybe.just(1)
    box_s = box.Box(1)

    # When
    result_s = maybe.to_box()

    # Then
    assert result_s == box_s

    # Given
    maybe = Maybe.nothing()
    box_f = box.Box(None)

    # When
    result_f = maybe.to_box()

    # Then
    assert result_f == box_f



# Generated at 2022-06-21 19:23:55.290057
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def f(x):
        return x + 1

    assert Maybe(2).ap(Maybe(f)) == Maybe(3)

# Generated at 2022-06-21 19:24:04.271464
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(3) != Maybe.just(True)
    assert Maybe.just(3) != Maybe.just(False)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('abcd') != Maybe.just('efgh')
    assert Maybe.just('w') != Maybe.just(1)
    assert Maybe.just(None) != Maybe.just(0)
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:24:06.074893
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(100).to_box() == Box(100)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:08.414494
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('test') == Maybe('test', False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:24:12.839376
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pymonet.monad_try as monad
    assert Maybe.just("test").to_try() == monad.Try("test", is_success=True)
    assert Maybe.nothing().to_try() == monad.Try(None, is_success=False)


# Generated at 2022-06-21 19:24:15.424935
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, is_nothing=False)
    assert Maybe.nothing() == Maybe(None, is_nothing=True)


# Generated at 2022-06-21 19:24:32.922503
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)

    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:35.675601
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    def mapper_func(value: int) -> Maybe[int]:
        return Maybe.just(value + 1)

    assert Maybe.just(1).bind(mapper_func) == Maybe.just(2)



# Generated at 2022-06-21 19:24:39.424769
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad_maybe import Maybe
    from pymonet.validation import Validation

    # Test for empty maybe
    assert Maybe.nothing().to_validation() == Validation.success(None)

    # Test for not empty maybe
    assert Maybe.just(5).to_validation() == Validation.success(5)

# Generated at 2022-06-21 19:24:43.016892
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-21 19:24:45.117947
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    print('Unit test for method get_or_else of class Maybe')
    assert Maybe.just(2).get_or_else(-1) == 2
    assert Maybe.nothing().get_or_else(-1) == -1
    print('Test passed\n')


# Generated at 2022-06-21 19:24:49.832103
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """Unit test for method to_either of class Maybe"""
    assert Maybe.just(1).to_either() == Either.right(1)
    assert Maybe.nothing().to_either() == Either.left(None)

# Generated at 2022-06-21 19:24:52.622406
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(1, False)
    assert m.value == 1
    assert m.is_nothing == False
    assert m != Maybe(2, False)
    assert m == Maybe(1, False)


# Generated at 2022-06-21 19:24:57.104200
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_test():
        print("This function should never be called")

    assert Maybe.just("test").to_lazy() == Lazy("test")
    assert Maybe.nothing().to_lazy() == Lazy(lazy_test)


# Generated at 2022-06-21 19:25:01.915639
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe.

    :returns: True if unit test passed, in other case raises AssertionError exception
    :rtype: bool
    """
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    return True

# Generated at 2022-06-21 19:25:05.285201
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('value').to_lazy() == Lazy(lambda: 'value')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:25:23.798935
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(12) == 12
    assert Maybe.just(1).get_or_else(12) == 1



# Generated at 2022-06-21 19:25:27.142780
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just('1').to_try() == Try('1', True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-21 19:25:29.659916
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just('hello').to_either() == Right('hello')
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:25:37.885349
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(4).map(lambda x: x + 2) == Maybe.just(6)
    assert Maybe.just(4).map(lambda x: x / 2) == Maybe.just(2)
    assert Maybe.just(4).map(lambda x: x - 2) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x - 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-21 19:25:42.649750
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(True)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:25:48.181544
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation().value == 1
    assert Maybe.nothing().to_validation().value is None



# Generated at 2022-06-21 19:25:54.681050
# Unit test for constructor of class Maybe
def test_Maybe():
    # Case for empty Maybe
    print(Maybe.nothing() == Maybe.nothing())
    print(Maybe.nothing() == Maybe.just(1))
    print(Maybe.nothing().get_or_else(1) == 1)
    print(Maybe.nothing().to_box().get_or_else(1) == 1)
    print(Maybe.nothing().to_either().get_or_else(1) == 1)
    print(Maybe.nothing().to_lazy().get_or_else(1) == 1)
    print(Maybe.nothing().to_try().get_or_else(1) == 1)
    print(Maybe.nothing().to_validation().get_or_else(1) == 1)
    # Case for not empty Maybe
    print(Maybe.just(1) == Maybe.just(1))

# Generated at 2022-06-21 19:26:01.865897
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test Maybe.bind method

    :returns: result of unit test
    :rtype: bool
    """
    def f(x):
        return Maybe.just(x + 1)

    def g(x):
        return Maybe.just(x)

    some = Maybe.just(1)
    assert some.bind(f) == Maybe.just(2)
    assert some.bind(g) == Maybe.just(1)


    def f(x):
        return Maybe.just(x + 1)

    def g(x):
        return Maybe.nothing()

    some = Maybe.just(1)
    assert some.bind(f) == Maybe.just(2)
    assert some.bind(g) == Maybe.nothing()


    def f(x):
        return Maybe.nothing()


# Generated at 2022-06-21 19:26:04.602891
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert (Maybe.just("123").to_either()) == Right("123")

    assert (Maybe.nothing().to_either()) == Left(None)


# Generated at 2022-06-21 19:26:11.142504
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe.to_box method.
    """

    # case: Maybe is not empty
    assert Maybe.just(1).to_box() == Box(1)

    # case: Maybe is empty
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:26:29.814865
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(None).to_box() == Box(None)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:26:35.828257
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(None)
    assert not Maybe.just(1) == Maybe.nothing()


# Generated at 2022-06-21 19:26:39.098011
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just('test').to_box() == Box('test')
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:26:46.346406
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # 1. Nothing
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()

    # 2. Maybe[Nothing]
    assert Maybe.just(Maybe.nothing()).filter(lambda x: x == Maybe.nothing()) == Maybe.nothing()

    # 3. Maybe[Maybe[Something]]
    assert Maybe.just(Maybe.just(1)).filter(lambda x: x == Maybe.just(1)) == Maybe.just(Maybe.just(1))

    # 4. Maybe[bool]
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda x: not x) == Maybe.nothing()

    # 5. Maybe[string]

# Generated at 2022-06-21 19:26:55.473328
# Unit test for method map of class Maybe
def test_Maybe_map():
    # create some maybe with value
    maybe_a = Maybe.just(5)
    # when: multiply value in maybe_a by 2
    maybe_b = maybe_a.map(lambda x: x * 2)
    # then: assert that maybe_b is equal to 10
    assert maybe_b == Maybe.just(10)
    # when: create nothing
    maybe_a = Maybe.nothing()
    # when: multiply value in maybe_a by 2
    maybe_b = maybe_a.map(lambda x: x * 2)
    # then: assert that maybe_b is equal to nothing
    assert maybe_b == Maybe.nothing()



# Generated at 2022-06-21 19:26:57.679344
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-21 19:27:01.897966
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:27:04.525481
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:27:09.745062
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda val: val % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda val: val % 2 == 0) == Maybe.just(2)
    assert Maybe.just('a').filter(lambda val: val == 'a') == Maybe.just('a')
    assert Maybe.nothing().filter(lambda val: False) == Maybe.nothing()


# Generated at 2022-06-21 19:27:15.177078
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    maybe_1 = Maybe.just(10)
    maybe_2 = Maybe.just(10)
    maybe_3 = Maybe.just(20)
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.nothing()

    # Then
    assert maybe_1 == maybe_2
    assert maybe_2 == maybe_1
    assert maybe_1 != maybe_3
    assert maybe_2 != maybe_3
    assert maybe_4 == maybe_5
    assert maybe_5 == maybe_4



# Generated at 2022-06-21 19:27:52.206023
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:27:54.446078
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:27:58.386954
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-21 19:28:03.497139
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:28:07.596395
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-21 19:28:17.016843
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_a = Maybe.just(2)  # Maybe[Int] = Maybe.just(Int)
    assert maybe_a.map(lambda v: v + 1) == Maybe.just(3)  # Maybe[Int] = Maybe[Int].map(Function(Int) -> Int)
    assert maybe_a.map(lambda v: "text").map(lambda v: 1) == Maybe.nothing()  # Maybe[Int] = Maybe[String].map(Function(String) -> Int)
    assert maybe_a.nothing().map(lambda v: v + 1) == Maybe.nothing()  # Maybe[Int] = Maybe[None].map(Function(None) -> Int)



# Generated at 2022-06-21 19:28:21.288159
# Unit test for method map of class Maybe
def test_Maybe_map():
    return_empty = Maybe.just(0).map(lambda x: 1 / x).is_nothing is True
    return_5 = Maybe.just(5).map(lambda x: x * 2).value == 10
    return return_empty and return_5



# Generated at 2022-06-21 19:28:24.357912
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(3, False).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:28:32.250582
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_a = Maybe.just(lambda x: x * 2)

    def maybe_b():
        return Maybe.nothing()

    maybe_a2 = Maybe.just(lambda x: x * 3)

    assert maybe_a.ap(maybe_b()) == maybe_b()
    assert maybe_a.ap(maybe_a2).get_or_else(None) == maybe_a2.get_or_else(None)(2)
    assert maybe_b().ap(maybe_a2) == maybe_b()



# Generated at 2022-06-21 19:28:33.364929
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    pass



# Generated at 2022-06-21 19:29:09.581254
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == \
        Right(1)
    assert Maybe.nothing().to_either() == \
        Left(None)


# Generated at 2022-06-21 19:29:12.363837
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-21 19:29:17.434756
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # arrange
    maybe1 = Maybe.just('Hello world!')
    maybe2 = Maybe.just('Hello world!')
    maybe3 = Maybe.just(3)
    maybe4 = Maybe.nothing()
    maybe5 = Maybe.nothing()
    # act
    # assert
    assert maybe1 == maybe2
    assert maybe1 != maybe3
    assert maybe3 != maybe4
    assert maybe4 == maybe5


# Generated at 2022-06-21 19:29:20.474245
# Unit test for method map of class Maybe
def test_Maybe_map():
    # for empty Maybe
    assert (Maybe.just("a").map(lambda v: v+"b")) == Maybe("ab", False)
    # for not empty Maybe
    assert (Maybe.nothing().map(lambda v: v+"b")) == Maybe(None, True)



# Generated at 2022-06-21 19:29:26.150182
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, Success
    from pymonet.monad import Monad

    assert Maybe.nothing().to_validation() == Success(None)
    assert Maybe.just(1).to_validation() == Success(1)
    assert Validation.success(None) == Validation.success(None).bind(lambda x : Maybe.just(x).to_validation())


# Generated at 2022-06-21 19:29:37.845264
# Unit test for method map of class Maybe
def test_Maybe_map():
    def double(value: int) -> int:
        return value * 2

    def triple(value: int) -> int:
        return value * 3

    assert Maybe.just(1).map(double) == Maybe.just(2)
    assert Maybe.nothing().map(double) == Maybe.nothing()
    assert Maybe.nothing().map(triple) == Maybe.nothing()
    assert Maybe.just(1)\
        .map(double)\
        .map(triple) == Maybe.just(6)

    assert Maybe.just(1)\
        .map(double)\
        .map(triple)\
        .map(lambda val: val / 2) == Maybe.just(3)

    assert Maybe.nothing().map(double).map(triple) == Maybe.nothing()


# Generated at 2022-06-21 19:29:42.158968
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.nothing import Nothing
    from pymonet.some import Some

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 19:29:46.672267
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Maybe.just(5).to_either().equals(Right(5)) == True
    assert Maybe.nothing().to_either().equals(Left(None)) == True

# Generated at 2022-06-21 19:29:52.849701
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(6) != Maybe.nothing()



# Generated at 2022-06-21 19:29:55.370177
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert(Just(1).bind(lambda x: Just(x+1)) == Just(2))
    assert(Nothing().bind(lambda x: Just(x+1)) == Nothing())
