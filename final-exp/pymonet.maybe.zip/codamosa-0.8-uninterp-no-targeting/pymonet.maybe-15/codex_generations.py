

# Generated at 2022-06-21 19:20:53.014528
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just('test')
    assert maybe.value == 'test'
    assert not maybe.is_nothing

    maybe = Maybe.nothing()
    assert maybe.is_nothing



# Generated at 2022-06-21 19:20:56.057681
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    import pytest
    assert Maybe.just(2).get_or_else(0) == 2
    assert Maybe.nothing().get_or_else(0) == 0



# Generated at 2022-06-21 19:21:02.613155
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def example():
        return 1

    assert Maybe.just(1).to_lazy() == Lazy(example)
    assert Maybe.nothing().to_lazy() == Lazy(example)


# Generated at 2022-06-21 19:21:07.379556
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe(1, False).filter(lambda x: x == 1) == Maybe(1, False)
    assert Maybe(1, False).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe("", False).filter(lambda x: True) == Maybe("", False)
    assert Maybe("", False).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-21 19:21:09.382156
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() == None

# Generated at 2022-06-21 19:21:12.315260
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * x) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()


# Generated at 2022-06-21 19:21:15.525018
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box().to_maybe() == Maybe.nothing()
    assert Maybe.just(1).to_box().to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:21:20.750531
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_1 = Maybe.just(1)
    assert maybe_1.map(lambda x: x * 2) == Maybe.just(2)
    assert maybe_1.map(lambda: None) == Maybe.nothing()
    assert maybe_1.map(lambda x: None) == Maybe.nothing()

    maybe_none = Maybe.nothing()
    assert maybe_none.map(lambda x: x * 2) == Maybe.nothing()
    assert maybe_none.map(lambda: None) == Maybe.nothing()
    assert maybe_none.map(lambda x: None) == Maybe.nothing()


# Generated at 2022-06-21 19:21:23.823305
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    result1 = Maybe.just(3).get_or_else(2)
    result2 = Maybe.nothing().get_or_else(2)
    assert result1 == 3
    assert result2 == 2

# Generated at 2022-06-21 19:21:26.539179
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:21:34.914810
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not (Maybe.nothing() == Maybe.just(1))
    assert Maybe.just(1) == Maybe.just(2).map(lambda x: 1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:21:38.203509
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Either.right(1)
    assert Maybe.just(None).to_either() == Either.right(None)
    assert Maybe.nothing().to_either() == Either.left(None)


# Generated at 2022-06-21 19:21:44.828884
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_maybe import Maybe

    assert Maybe(1, False).map(lambda x: x * 2) == Maybe(2, False)
    assert Maybe(1, False).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-21 19:21:48.367093
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()



# Generated at 2022-06-21 19:21:53.456869
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    import pymonet.box as box

    just = Maybe.just(10)
    nothing = Maybe.nothing()

    assert isinstance(just.to_box(), box.Box)
    assert isinstance(nothing.to_box(), box.Box)
# END of Unit test for method to_box of class Maybe


# Generated at 2022-06-21 19:21:58.114680
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:22:02.984465
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    m = Maybe.just('test')
    assert m.to_box() == Box('test')
    assert m.to_box().value == 'test'

    m = Maybe.nothing()
    assert m.to_box() == Box(None)
    assert m.to_box().value == None


# Generated at 2022-06-21 19:22:11.819721
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(None).bind(lambda _: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(None).bind(lambda _: Maybe.just(None)) == Maybe.just(None)
    assert Maybe.just((1, 2)).bind(lambda x: Maybe.just(x[0] + x[1])) == Maybe.just(3)
    assert Maybe.just(2).bind(lambda x: Maybe.just(x ** 2)) == Maybe.just(4)

# Generated at 2022-06-21 19:22:17.069130
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # case when Maybe is empty
    maybe = Maybe.nothing()
    default_value=30
    assert maybe.get_or_else(default_value) == default_value
    # case when Maybe not empty
    value=5
    maybe = Maybe.just(value)
    assert maybe.get_or_else(default_value) == value


# Generated at 2022-06-21 19:22:21.219248
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    actual = Maybe.just(2)
    expected = Maybe.just(2)

    assert actual == expected
    assert actual.to_box().value == expected.value



# Generated at 2022-06-21 19:22:28.499667
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.try_ import Try
    from pymonet.monad_try import is_success

    m = Maybe.just(12)
    try_ = m.to_try()

    assert is_success(try_)
    assert try_.value == 12

    m = Maybe.nothing()
    try_ = m.to_try()

    assert not is_success(try_)
    assert try_.value is None

# Generated at 2022-06-21 19:22:34.962229
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:22:38.593312
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    result = Maybe.nothing().to_box()
    expected = Box(None)
    assert result == expected

    result = Maybe.just(10).to_box()
    expected = Box(10)
    assert result == expected


# Generated at 2022-06-21 19:22:43.558608
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:22:50.814791
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Tests for bind method of Maybe class.
    """
    def mapper(x: int) -> Maybe[int]:
        if x == 0:
            return Maybe.just(100)
        return Maybe.nothing()

    assert Maybe.just(5).bind(mapper) == Maybe.nothing()
    assert Maybe.just(0).bind(mapper) == Maybe.just(100)
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()



# Generated at 2022-06-21 19:22:54.507994
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet import maybe

    assert maybe.nothing().to_either() == Left(None)
    assert maybe.just(None).to_either() == Right(None)
    assert maybe.just(2).to_either() == Right(2)


# Generated at 2022-06-21 19:22:56.986593
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(4).to_try() == Try(4, is_success=True) and \
        Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:22:59.670236
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Arrange
    maybe = Maybe.just(123)
    default_value = 456

    # Act
    result = maybe.get_or_else(default_value)

    # Assert
    assert result == 123


# Generated at 2022-06-21 19:23:01.418865
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:04.403720
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert maybe.get_or_else(2) == 1

    maybe = Maybe.nothing()
    assert maybe.get_or_else(2) == 2



# Generated at 2022-06-21 19:23:17.626741
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative
    from pymonet.monad_list import List
    from pymonet.monad_set import Set
    from pymonet.monad_dict import Dict

    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.just(lambda x, y: [x, y]).ap(Maybe.just(1)).ap(Maybe.just(2)) == Maybe.just([1, 2])
    assert Maybe.just(lambda x, y: [x, y]).ap(Maybe.nothing()).ap(Maybe.just(2)) == Maybe.nothing()

# Generated at 2022-06-21 19:23:22.608131
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    maybe = Maybe.just(5)
    validation = maybe.to_validation()
    assert validation.value == 5

    maybe = Maybe.nothing()
    validation = maybe.to_validation()
    assert validation.is_success
    assert validation.value is None

# Generated at 2022-06-21 19:23:26.586620
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(33, False).bind(lambda x: Maybe(x * 2, False)) == Maybe(66, False)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 2, False)) == Maybe(None, True)


# Generated at 2022-06-21 19:23:30.495812
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    string = Maybe('Nice to meet you!', False)
    expected = Maybe('Nice to meet you!', False)

    # When
    actual = string.filter(lambda x: x == 'Nice to meet you!')

    # Then
    assert expected == actual

# Generated at 2022-06-21 19:23:38.074767
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test_fun1():
        return 10

    m1 = Maybe.just(test_fun1)
    expected1 = Lazy(test_fun1)
    assert m1.to_lazy() == expected1

    m2 = Maybe.nothing()
    expected2 = Lazy(lambda: None)
    assert m2.to_lazy() == expected2



# Generated at 2022-06-21 19:23:41.734966
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:23:43.715158
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, Check

    assert Maybe.just(13).to_validation() == Validation.success(13)
    asse

# Generated at 2022-06-21 19:23:49.376906
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test_function():
        return 1

    maybe = Maybe.just(test_function)
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value()() == 1

# Unit tests for method to_try of class Maybe

# Generated at 2022-06-21 19:23:52.079242
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-21 19:23:57.100587
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, success, failure

    assert Maybe.just('Python').to_validation() == success('Python')
    assert Maybe.nothing().to_validation() == success(None)



# Generated at 2022-06-21 19:24:02.335365
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().force() == 1
    assert Maybe.nothing().to_lazy().force() is None


# Generated at 2022-06-21 19:24:05.836039
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(
        lambda x: x > 0
    ) == Maybe.just(1)
    assert Maybe.just(1).filter(
        lambda x: x < 0
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:24:08.622595
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation().is_success == True
    assert Maybe.nothing().to_validation().is_success == True



# Generated at 2022-06-21 19:24:12.649445
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(4)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()



# Generated at 2022-06-21 19:24:15.261892
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:24:23.313829
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.utils import class_property_test

    test_cases = [
        {
            'name': 'nothing',
            'method': Maybe.nothing,
            'arguments': [],
            'expected': Maybe(None, True),
        },
        {
            'name': 'just',
            'method': Maybe.just,
            'arguments': [55],
            'expected': Maybe(55, False),
        },
    ]
    test_result = class_property_test(Maybe, test_cases)
    print(test_result)


# Generated at 2022-06-21 19:24:26.294589
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative
    a = Maybe(2, False)
    b = Maybe(lambda x: x * 10, False)

    print(a.ap(b))
    assert a.ap(b) == Maybe.just(20)



# Generated at 2022-06-21 19:24:29.003920
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:24:31.319164
# Unit test for method map of class Maybe
def test_Maybe_map():
    # GIVEN
    # WHEN
    maybe = Maybe.just("1").map(int)
    # THEN
    assert maybe == Maybe(1, False)



# Generated at 2022-06-21 19:24:35.237165
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    # Test with not empty Maybe
    value = 1
    monad = Maybe.just(value)
    assert monad.to_validation() == Validation.success(value)

    # Test with empty Maybe
    monad = Maybe.nothing()
    assert monad.to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:24:40.856886
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Test when result is equal to default value
    assert Maybe.nothing().get_or_else(True) == True

    # Test when result is equal to value
    assert Maybe.just(True).get_or_else(False) == True


# Generated at 2022-06-21 19:24:43.943561
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-21 19:24:49.543683
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.validation import Validation

    maybe = Maybe.just(7)
    maybe_validation = maybe.bind(lambda x: Validation.success(x * 2))
    assert maybe_validation == Validation.success(14)


# Generated at 2022-06-21 19:24:52.358416
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:24:56.454770
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:25:00.677880
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    maybe_empty = Maybe.nothing()
    maybe_with_value = Maybe(5, False)
    assert maybe_empty.to_validation() == Validation.success(None)
    assert maybe_with_value.to_validation() == Validation.success(5)


# Generated at 2022-06-21 19:25:05.143897
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def f():
        return 1

    assert Maybe.just(1).to_lazy() == Lazy(f)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:25:07.922130
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(2).ap(Maybe.just(lambda x: x * 3)) == Maybe.just(6)



# Generated at 2022-06-21 19:25:11.755994
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # unit test for method get_or_else of class Maybe
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:25:18.690418
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.just(3).filter(lambda x: x % 2 == 0)
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) != Maybe.just(3).filter(lambda x: x % 2 == 0)
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4).filter(lambda x: x % 2 == 0)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing().filter(lambda x: x % 2 == 0)



# Generated at 2022-06-21 19:25:26.661623
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:25:33.911411
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m1 = Maybe.just(lambda x: x * 2)
    m2 = Maybe.just(2)
    assert m1.ap(m2).is_nothing is False
    assert m1.ap(m2).get_or_else(None) == 4

    m3 = Maybe.just(1)
    m4 = Maybe.nothing()
    assert m3.ap(m4).is_nothing

    m5 = Maybe.nothing()
    m6 = Maybe.just(2)
    assert m5.ap(m6).is_nothing


# Generated at 2022-06-21 19:25:39.547360
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-21 19:25:49.892050
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # maybe value to box test schema
    def test_case(value):
        def test_impl():
            assert Maybe(value, True).to_box() == Box(None)
            assert Maybe(value, False).to_box() == Box(value)
        return test_impl

    # add test cases
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_box import Box
    from pymonet.test.test_monad import add_test_cases


# Generated at 2022-06-21 19:25:52.858547
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(5, False).map(lambda x: x + 1) == Maybe(6, False)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:25:54.919326
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just('test').to_box().value == 'test'
    assert Maybe.nothing().to_box().value is None

# Generated at 2022-06-21 19:25:59.068028
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """ Should returns Validation[A, []] """
    from pymonet.validation import Validation

    x = Maybe.just(2)
    assert x.to_validation().__eq__(Validation.success(2))

    x = Maybe.nothing()
    assert x.to_validation().__eq__(Validation.success(None))


# Generated at 2022-06-21 19:26:02.804367
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.just(2).get_or_else(1) == 2


# Generated at 2022-06-21 19:26:05.133319
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:26:07.291437
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert(maybe.get_or_else(2) == 1)
    maybe = Maybe.nothing()
    assert(maybe.get_or_else(2) == 2)


# Generated at 2022-06-21 19:26:18.541489
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    val = Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1).to_lazy() == Maybe.just(1).to_lazy()
    assert Maybe.nothing().to_lazy() == Maybe.nothing().to_lazy()


# Generated at 2022-06-21 19:26:22.099843
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-21 19:26:26.643846
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:26:34.141192
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(5).bind(lambda x: Maybe.just(x * 10)) == Maybe.just(50)
    assert Maybe.just(7).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * 10)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:26:39.660278
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    result = Maybe.just(1).to_validation()
    expected_result = Validation.success(1)
    assert result == expected_result

    result = Maybe.nothing().to_validation()
    expected_result = Validation.success(None)
    assert result == expected_result

# Generated at 2022-06-21 19:26:44.671053
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Unit test for method to_lazy of class Maybe"""
    from pymonet.lazy import Lazy

    def func():
        pass

    Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    Maybe.just(None).to_lazy() == Lazy(lambda: None)
    Maybe.just(func).to_lazy() == Lazy(lambda: func)
    Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:26:56.414246
# Unit test for method filter of class Maybe

# Generated at 2022-06-21 19:27:04.925950
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from collections import namedtuple
    from pymonet.either import Left, Right

    Person = namedtuple('Person', ['name', 'age'])

    def get_person(name: str) -> 'Maybe[Person]':
        if name == 'Tom':
            return Maybe.just(Person('Tom', 15))
        return Maybe.nothing()

    assert get_person('Tom').bind(lambda person: Maybe.just(person.age)) == Maybe.just(15)
    assert get_person('Mike').bind(lambda person: Maybe.just(person.age)) == Maybe.nothing()


# Generated at 2022-06-21 19:27:12.381851
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    def f(value: int) -> int:
        return value + 1
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).bind(lambda x: Maybe.just(f(x))).to_try() == Try(2, is_success=True)
    assert Maybe.nothing().bind(lambda x: Maybe.just(f(x))).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:27:16.401245
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    result = Maybe.just(1).to_lazy().eval()
    assert(result == 1)

    result = Maybe.nothing().to_lazy().eval()
    assert(result == None)



# Generated at 2022-06-21 19:27:29.504438
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    result = Maybe.nothing().to_try()
    assert isinstance(result, Try)
    assert not result.is_success
    assert result.value == None

    result = Maybe.just(5).to_try()
    assert isinstance(result, Try)
    assert result.is_success
    assert result.value == 5


# Generated at 2022-06-21 19:27:34.959036
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # given
    maybe_nothing = Maybe.nothing()
    maybe_just_value = Maybe.just(1)
    default_value = 2

    # when
    maybe_nothing_value = maybe_nothing.get_or_else(default_value)
    maybe_just_value_value = maybe_just_value.get_or_else(default_value)

    # then
    assert maybe_nothing_value == default_value
    assert maybe_just_value_value == 1



# Generated at 2022-06-21 19:27:37.593392
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:27:41.359687
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    val1 = Maybe.just(100)
    assert val1.get_or_else(50) == 100

    val2 = Maybe.nothing()
    assert val2.get_or_else(50) == 50



# Generated at 2022-06-21 19:27:43.889175
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe(None, True)
    print('test_Maybe passed')


# Generated at 2022-06-21 19:27:54.853689
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(3, is_nothing=False).map(lambda x: x+1) == Maybe(4, is_nothing=False)
    assert Maybe(3, is_nothing=False).map(lambda x: x+1).map(lambda x: x-2) == Maybe(3, is_nothing=False)
    assert Maybe(3, is_nothing=False).map(lambda x: x+1).map(lambda x: x-1) == Maybe(4, is_nothing=False)
    assert Maybe(None, is_nothing=True).map(lambda x: x) == Maybe(None, is_nothing=True)
    assert Maybe(None, is_nothing=True).map(lambda x: x + 1) == Maybe(None, is_nothing=True)


# Generated at 2022-06-21 19:28:00.648729
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:28:08.400533
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test 1
    empty_maybe_1 = Maybe.nothing()
    assert empty_maybe_1.is_nothing
    assert empty_maybe_1 is empty_maybe_1
    empty_maybe_2 = Maybe.nothing()
    assert empty_maybe_2.is_nothing
    assert empty_maybe_2 is empty_maybe_2
    assert empty_maybe_1 is not empty_maybe_2
    try:
        empty_maybe_2.value
    except AttributeError:
        pass
    else:
        assert False

    # Test 2
    not_empty_maybe_1 = Maybe.just(21)
    assert not not_empty_maybe_1.is_nothing
    assert not_empty_maybe_1 is not_empty_maybe_1
    assert not_empty_maybe_1.value == 21
    not_empty

# Generated at 2022-06-21 19:28:12.150647
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(10).get_or_else(20) == 10)
    assert(Maybe.nothing().get_or_else(20) == 20)


# Generated at 2022-06-21 19:28:15.350863
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:28:25.331536
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(4) == 5
    assert Maybe.nothing().get_or_else(4) == 4
    print('[test] Maybe_get_or_else::test_Maybe_get_or_else done')


# Generated at 2022-06-21 19:28:36.430240
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.functions import compose

    m: Maybe[int] = Maybe.just(1)
    assert isinstance(m, Functor)
    assert isinstance(m, Functor)
    assert isinstance(m, Applicative)
    assert isinstance(m, Monad)

    assert m.filter(lambda _: True) == m
    assert m.filter(lambda _: False) == Maybe.nothing()

    def filterer(value):
        return value > 0

    assert Maybe.just(1).filter(filterer) == Maybe.just(1)
    assert Maybe.just(0).filter(filterer) == Maybe.nothing()


# Generated at 2022-06-21 19:28:38.487425
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    result = Maybe.just(10).to_box()
    assert isinstance(result, Box)
    assert result == Box(10)


# Generated at 2022-06-21 19:28:42.454054
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # given
    maybe = Maybe.just(1)

    # when
    lazy = maybe.to_lazy()

    # then
    assert lazy.get_value() == 1



# Generated at 2022-06-21 19:28:46.505905
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either().is_right
    assert Maybe.just(1).to_either().value == 1
    assert Maybe.nothing().to_either().is_left
    assert Maybe.nothing().to_either().value is None


# Generated at 2022-06-21 19:28:49.072037
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:29:01.186963
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test `to_lazy` method of class Maybe.
    """

    def func(x):
        return x * 2

    def empty_func():
        return NoReturnValue

    assert Maybe.nothing().to_lazy().apply(func) == Maybe.nothing()
    assert Maybe.just(5).to_lazy().apply(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.just(5).to_lazy().apply(lambda x: x * 2).to_lazy().apply(lambda x: x * 2) == Maybe.just(20)
    assert Maybe.nothing().to_lazy().apply(empty_func) == Maybe.nothing()
    assert Maybe.just(5).to_lazy().apply(lambda x: x).to_lazy().apply(empty_func) == Maybe.nothing

# Generated at 2022-06-21 19:29:04.241912
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe.just(1).filter(lambda x: x % 2 == 0)
    expected = Maybe.nothing()
    assert result == expected

# Generated at 2022-06-21 19:29:09.928688
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda i: i + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:29:12.941380
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(Box(3)).to_box() == Box(3)



# Generated at 2022-06-21 19:29:29.942782
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe


# Generated at 2022-06-21 19:29:32.856734
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:29:38.340867
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    maybe1 = Maybe.just('1')
    maybe2 = Maybe.just('2')
    maybe3 = Maybe.just('1')

    # Then
    assert maybe1 == maybe3
    assert maybe1 != maybe2
    assert maybe2 == maybe2

# Generated at 2022-06-21 19:29:42.345988
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    def mult(x):
        def mult2(y):
            return x * y
        return mult2

    assert Maybe.just(2).ap(Maybe.just(mult))(10) == 20
    assert Maybe.just(mult).ap_left(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(mult).ap_right(Maybe.just(2))(10) == 20
    assert Maybe.nothing().ap(Maybe.just(mult))(10) == Maybe.nothing()

# Generated at 2022-06-21 19:29:47.489337
# Unit test for method map of class Maybe
def test_Maybe_map():
    def raise_err():
        raise TypeError("fake_function_error")

    def return_maybe(value):
        def func():
            return Maybe.just(value)

        return func

    def maybe_value(value):
        def func():
            return value

        return func

    assert Maybe.just("i'm not empty").map(maybe_value("mapped value")) == Maybe.just("mapped value")
    assert Maybe.nothing().map(maybe_value("mapped value")) == Maybe.nothing()
    assert Maybe.just("i'm not empty").map(raise_err) == Maybe.nothing()
    assert Maybe.nothing().map(raise_err) == Maybe.nothing()
    assert Maybe.just("i'm not empty").map(return_maybe("mapped value")) == Maybe.just("mapped value")

# Generated at 2022-06-21 19:29:50.300344
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:29:53.351909
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import List

    assert Maybe(2, False).ap(List.pure(lambda x: x + 2)) == List.pure(4)


# Generated at 2022-06-21 19:29:57.661922
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():

    m = Maybe.just(5)
    print(m.to_try())

    val = m.to_try().get()
    print(val)
    assert val is 5

    m = Maybe.nothing()
    print(m.to_try())

    val = m.to_try().get()
    print(val)
    assert val is None

# Generated at 2022-06-21 19:29:59.966996
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:30:04.048723
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe = Maybe.just(5)
    try_ = maybe.to_try()
    assert try_ == Try(5, True)
    maybe = Maybe.nothing()
    try_ = maybe.to_try()
    assert try_ == Try(None, False)


# Generated at 2022-06-21 19:30:15.526406
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    maybe1 = Maybe.just(1)
    maybe2 = Maybe.nothing()

    assert maybe1.bind(lambda value: Maybe.just(value)) == maybe1
    assert maybe2.bind(lambda value: Maybe.just(value)) == maybe2
    assert maybe1.bind(
        lambda value: Maybe.just(
            value * 2
        )
    ) == Maybe.just(2)
    assert maybe2.bind(
        lambda value: Maybe.just(
            value * 2
        )
    ) == maybe2
    assert maybe1.bind(
        lambda value: Maybe.nothing()
    ) == Maybe.nothing()



# Generated at 2022-06-21 19:30:23.781095
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    def test_function(value):
        import math
        return Try(math.sqrt(value), is_success=True)

    assert Maybe(6, False).ap(Maybe.just(test_function)) == Maybe.just(2.5)
    assert Maybe(6, False).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe(6, True).ap(Maybe.just(test_function)) == Maybe.nothing()
    assert Maybe(6, True).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:30:25.871160
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-21 19:30:31.259447
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda v: Maybe.just(v + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda v: Maybe.just(v + 1)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda v: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:30:38.666395
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test converting Maybe to Try.
    """
    from pymonet.monad_try import Try

    # Test with empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(0).to_try() == Try(0, is_success=True)
    assert Maybe.just(100).to_try() == Try(100, is_success=True)


# Generated at 2022-06-21 19:30:45.322688
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    def run(test_function, test_input, expected_value):
        actual_value = test_function(test_input)
        assert actual_value == expected_value

    # Test case for Maybe.to_try with empty Maybe
    run(Maybe.nothing().to_try, None, Try(None, is_success=False))

    # Test case for Maybe.to_try with not empty Maybe
    run(Maybe.just(1).to_try, None, Try(1, True))
