

# Generated at 2022-06-21 19:20:53.512723
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:20:56.108855
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:20:59.215342
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 5)) == Maybe.just(10)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 5)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:08.836633
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test function for Maybe class.

    :returns: nothing
    :rtype: None
    """
    from pymonet.try_ import Try

    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5).is_nothing is False
    assert Maybe.just(5).value == 5
    assert Maybe.nothing().is_nothing is True
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().is_nothing is True
    assert Maybe.just(
        Try.of(lambda: 1 / 0).to_maybe()
    ).is_nothing is True



# Generated at 2022-06-21 19:21:13.263121
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def plus(a, b):
        return a + b
    assert Maybe.just(plus).ap(Maybe.just(5)).ap(Maybe.just(5)) == Maybe.just(10)
    assert Maybe.just(plus).ap(Maybe.just(5)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:17.002842
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(42).to_validation().is_success()
    assert Maybe.nothing().to_validation().is_success()
    assert Validation.success(42) == Maybe.just(42).to_validation()
    assert Validation.success(None) == Maybe.nothing().to_validation()



# Generated at 2022-06-21 19:21:19.924973
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:22.961982
# Unit test for constructor of class Maybe
def test_Maybe():
    instance = Maybe(1, False)
    assert not instance.is_nothing
    assert instance.value == 1

    instance = Maybe.nothing()
    assert instance.is_nothing
    try:
        assert instance.value == None # pylint: disable=W0104
    except Exception:
        pass

    instance = Maybe.just(1)
    assert not instance.is_nothing
    assert instance.value == 1



# Generated at 2022-06-21 19:21:26.800342
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(5).to_box() == Box(5)


# Generated at 2022-06-21 19:21:35.868125
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    try:
        Lazy(lambda: 10).bind(lambda x: Lazy(lambda: Maybe.just(x))).bind(lambda x: x.to_lazy()).get_or_else(0).get() == 10
        Lazy(lambda: Maybe.just(10)).bind(lambda x: x.to_lazy()).bind(lambda x: Try.raise_error(Exception('error'))).bind(lambda x: x.to_lazy()).get_or_else(0).get() == 0
    except:
        assert False
    assert True

# Generated at 2022-06-21 19:21:46.456485
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("a").map(lambda x: x + "b").get_or_else("d") == "ab"
    assert Maybe.just("a").map(lambda x: None).get_or_else("d") == "d"
    assert Maybe.nothing().map(lambda x: None).get_or_else("d") == "d"
    assert Maybe.nothing().get_or_else("d") == "d"



# Generated at 2022-06-21 19:21:47.930063
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just('hello').to_box() == Box('hello')



# Generated at 2022-06-21 19:21:51.593387
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(10).to_either() != Left(None)


# Generated at 2022-06-21 19:21:59.290433
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just('42') == Maybe.just('42')
    assert Maybe.just('42') != Maybe.just('nope')
    assert Maybe.just(42) != Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-21 19:22:06.213756
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pytest

    try_type = Maybe.just(10).to_try()
    assert type(try_type) is Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

    with pytest.raises(Exception) as exception_info:
        Maybe.nothing().to_try().get_or_raise()
    assert exception_info.type is None

    assert Maybe.just(10).to_try().get_or_raise() == 10

    assert Maybe.nothing().to_try().is_success is False
    assert Maybe.just(10).to_try().is_success is True

# Generated at 2022-06-21 19:22:17.322374
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe_acitivity = Maybe.just('coding')
    not_empty_validation = maybe_acitivity.to_validation()
    assert isinstance(not_empty_validation, Validation)
    assert not_empty_validation.is_success
    assert not_empty_validation == Validation.success('coding')

    maybe_acitivity = Maybe.nothing()
    empty_validation = maybe_acitivity.to_validation()
    assert isinstance(empty_validation, Validation)
    assert empty_validation.is_success
    assert empty_validation == Validation.success(None)


# Generated at 2022-06-21 19:22:27.484010
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test for bind() method of Maybe class.

    :return: True when test passed
    :rtype: Boolean
    """
    from pymonet.file import File

    path = './assets/file.txt'

    # when Maybe is not empty
    result = Maybe.just(path).bind(lambda path: Maybe(File(path).read(), False))

    assert isinstance(result, Maybe)
    assert result == Maybe('some text\n', False)

    # when Maybe is empty
    result = Maybe.nothing().bind(lambda path: Maybe(File(path).read(), False))

    assert isinstance(result, Maybe)
    assert result == Maybe.nothing()

# Generated at 2022-06-21 19:22:32.640486
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.just(3).map(lambda x: x + 2) == Maybe.just(5)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-21 19:22:40.249968
# Unit test for method map of class Maybe
def test_Maybe_map():
    import pytest

    Just5 = Maybe.just(5)
    Just6 = Maybe.nothing()
    assert Just5.map(lambda x: x + 1) == Maybe.just(6)
    assert Just6.map(lambda x: x + 1) == Maybe.nothing()

    def raise_exception():
        raise Exception("SomeException")
    # Raise exception in map method
    with pytest.raises(Exception) as exc:
        Just5.map(raise_exception)

    assert str(exc.value) == "SomeException"


# Generated at 2022-06-21 19:22:44.219114
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:22:49.712749
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(11, False).to_box() == Box(11)
    assert Maybe(11, True).to_box() == Box(None)

# Generated at 2022-06-21 19:22:52.723958
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)

if __name__ == '__main__':
    test_Maybe()

# Generated at 2022-06-21 19:22:55.323166
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x * 2) == Maybe(2, False)
    assert Maybe(1, True).map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-21 19:23:02.211635
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x / 2) == Maybe.just(0.5)
    assert Maybe.just(1).map(lambda x: x % 2) == Maybe.just(1)
    assert Maybe.just(1).map(lambda x: x >= 0) == Maybe.just(True)
    assert Maybe.just(1).map(lambda x: x <= 0) == Maybe.just(False)
    assert Maybe.just(1).map(lambda x: x == 0) == Maybe.just(False)

# Generated at 2022-06-21 19:23:07.551698
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda item: item > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda item: item > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda item: True) == Maybe.nothing()


# Generated at 2022-06-21 19:23:11.712838
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Nothing().bind(lambda n: n*2) == Nothing()
    assert Box(1).bind(lambda n: Box(n*2)) == Box(2)
    assert Box(2).bind(lambda n: n*2) == Box(4)
    assert Box([1, 2, 3]).bind(lambda x: Box(x[0])).bind(lambda x: Box(x+1)).bind(Box) == Box(2)
    assert Box(Box(2)).bind(Box).bind(lambda x: Box(x*2)).bind(Box) == Box(4)
    assert Box(2).bind(lambda n: n * 2).bind(Box) == Box(4)
    assert Box([1, 2, 3]).bind(lambda x: Box(x[0])).bind(lambda x: Box(x+1)).bind(Box)

# Generated at 2022-06-21 19:23:15.074590
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:23:19.370098
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:23:25.337328
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda v: v % 2 == 0) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda v: v % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-21 19:23:29.101618
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(7)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()


# Generated at 2022-06-21 19:23:39.332981
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(True).to_either() == Right(True)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:23:42.648921
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        def _(y):
            return x + y
        return _

    assert Maybe.just(add).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(add).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:23:45.880110
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-21 19:23:50.053561
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x + 1).ap(Box(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Box(2)) == Maybe.nothing()


# Generated at 2022-06-21 19:23:56.347351
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # valid cases
    assert(
        Maybe.just(lambda x: x + 3).ap(Maybe.just(1)) ==
        Maybe.just(4)
    )
    assert(
        Maybe.just(lambda x: x + 3).ap(Maybe.nothing()) ==
        Maybe.nothing()
    )

    # invalid cases
    assert(
        Maybe.nothing().ap(Maybe.just(lambda x: x + 3)) ==
        Maybe.nothing()
    )
    assert(
        Maybe.nothing().ap(Maybe.nothing()) ==
        Maybe.nothing()
    )

# Generated at 2022-06-21 19:24:01.684031
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    maybe_value = Maybe.just(100)
    validation_success = maybe_value.to_validation()
    assert(validation_success.is_success())

    maybe_empty = Maybe.nothing()
    validation_success = maybe_empty.to_validation()
    assert(validation_success.is_success())



# Generated at 2022-06-21 19:24:07.374899
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Recursion test method __eq__ of class Maybe.

    :param f: function to test
    :type f: function
    :returns: None
    :rtype: None
    """

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-21 19:24:11.088043
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, is_nothing=False)
    assert Maybe.nothing() == Maybe(None, is_nothing=True)

# Unit tests for methods of class Maybe

# Generated at 2022-06-21 19:24:14.581308
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just("Hello").to_validation() == Validation.success("Hello")
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:24:17.897636
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:24:30.832481
# Unit test for method map of class Maybe
def test_Maybe_map():
    # input
    input_value = 42
    input_mapper = lambda x: x * 2

    # expected result
    expected_result = Maybe(input_value * 2, False)

    # actual result
    actual_result = Maybe.just(input_value).map(input_mapper)

    # test
    assert expected_result == actual_result



# Generated at 2022-06-21 19:24:36.336966
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe.just(1).to_box() == Box(1)
    assert Box(1) == Maybe.just(Box(1)).to_box()
    assert Maybe.nothing().to_box() == Box(None)
    assert Box(Box(1)) == Maybe.just(Box(Box(1))).to_box()
    assert Box(Box(None)) == Maybe.nothing().to_box()


# Generated at 2022-06-21 19:24:39.503312
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x % 2 == 0) == Maybe.just(42)
    assert Maybe.just(43).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()

# Generated at 2022-06-21 19:24:42.031039
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()


# Generated at 2022-06-21 19:24:44.741487
# Unit test for method map of class Maybe
def test_Maybe_map():
    cube = lambda a: a**3
    assert Maybe.just(3).map(cube) == Maybe.just(27)
    assert Maybe.nothing().map(cube) == Maybe.nothing()


# Generated at 2022-06-21 19:24:51.111894
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:24:53.775067
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(10).map(lambda a: a + 10) == Maybe.just(20)
    assert Maybe.nothing().map(lambda a: a + 10) == Maybe.nothing()


# Generated at 2022-06-21 19:25:02.976741
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test bind method.

    :returns: True when test is ok, otherwise return False
    :rtype: Boolean
    """

    a1 = Maybe.just(2)
    a2 = Maybe.just(4)
    a3 = Maybe.nothing()

    if a1.bind(lambda value: Maybe.just(value * 2)) != a2 or\
       a1.bind(lambda value: Maybe.nothing()) != a3 or\
       a3.bind(lambda value: Maybe.just(value * 2)) != a3:
        return False

    return True


# Generated at 2022-06-21 19:25:06.822126
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:25:10.252311
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda v: v + 5).ap(Box(6)) == Box(11)



# Generated at 2022-06-21 19:25:25.690464
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation(None, [])


# Generated at 2022-06-21 19:25:29.147935
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_true():
        return True

    assert Maybe.just(
        10
    ).to_lazy().value() == 10

    assert Maybe.nothing().to_lazy().value() is None

    assert Maybe.just(
        test_true
    ).to_lazy().value()(
    ) is True


# Generated at 2022-06-21 19:25:33.857880
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x == 4) == Maybe.just(4)
    assert Maybe.just(7).filter(lambda x: x == 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 4) == Maybe.nothing()


# Generated at 2022-06-21 19:25:38.230566
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:25:42.205598
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:25:47.440750
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just('value').filter(lambda m: 'value' == m) == Maybe.just('value')
    assert Maybe.just('value').filter(lambda m: 'value' != m) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda m: 'value' == m) == Maybe.nothing()


# Generated at 2022-06-21 19:25:51.246220
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Create not empty Maybe
    maybe = Maybe.just(10)

    # Assert method get_or_else return value of Maybe
    assert maybe.get_or_else(0) == 10

    # Create empty Maybe
    maybe = Maybe.nothing()

    # Assert method get_or_else return default value
    assert maybe.get_or_else(0) == 0



# Generated at 2022-06-21 19:25:53.420962
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:25:55.468678
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)



# Generated at 2022-06-21 19:26:02.349559
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When the filter function returns True, return the original value
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > -1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)

    # When the filter function returns False, return the default value
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()

    # When the filter function returns False, return the default value

# Generated at 2022-06-21 19:26:32.235305
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:26:37.515390
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test method to_lazy of class Maybe.

    :returns: nothing
    """
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 19:26:40.352950
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()



# Generated at 2022-06-21 19:26:46.417226
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test method to_try of class Maybe.

    :return: Nothing
    :rtype: None
    """
    from pymonet.monad_try import Try

    value = 1
    m: Maybe[int] = Maybe.just(value)

    assert m.to_try() == Try(value)

    m: Maybe[int] = Maybe.nothing()

    assert m.to_try() == Try(None, is_success=False)

    another_value: int = 2
    m: Maybe[int] = Maybe.just(value)

    assert m.to_try() == Try(value)

    assert m.to_try() != Try(another_value)



# Generated at 2022-06-21 19:26:50.254247
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def square(x):
        return x ** 2

    assert Maybe.just(2).to_lazy().fmap(square).value() == 4
    assert Maybe.nothing().to_lazy().fmap(square).value() is None

# Generated at 2022-06-21 19:26:52.356848
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert(
        Maybe.just(1).to_validation() ==
        Validation.success(1)
    )
    assert (
        Maybe.nothing().to_validation() ==
        Validation.success(None)
    )

    def error_mapper(data):
        raise Exception('Test error')

    assert (
        Maybe.nothing().to_validation() ==
        Validation.success(None)
    )



# Generated at 2022-06-21 19:26:55.965616
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    lazy: Lazy[str] = Maybe.just('test').to_lazy()
    assert lazy() == 'test'



# Generated at 2022-06-21 19:27:01.700819
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Box and Lazy should be the same
    assert Lazy(lambda: 1) == Lazy(lambda: 1)

    # Boxes with different values should not be the same
    assert Lazy(lambda: 1) != Lazy(lambda: 2)


# Generated at 2022-06-21 19:27:04.578476
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.just(True).filter(lambda x: True) == Maybe.just(True)
    assert Maybe.just(False).filter(lambda x: x) == Maybe.nothing()



# Generated at 2022-06-21 19:27:08.394856
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just('value').to_lazy() == Lazy(lambda: 'value')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:27:39.951479
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 19:27:43.603188
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)
    assert Maybe.just(False).filter(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()

# Generated at 2022-06-21 19:27:51.278755
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value == 5

    assert(Maybe.just(5).filter(filterer) == Maybe.just(5))
    assert(Maybe.just(6).filter(filterer) == Maybe.nothing())
    assert(Maybe.nothing().filter(filterer) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda _: True) == Maybe.nothing())


# Generated at 2022-06-21 19:27:54.602301
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe = Maybe.just(4)

    # When
    result = lambda: maybe.filter(lambda x: x == 4)

    # Then
    assert isinstance(result(), Maybe)
    assert result() == Maybe(4, False)

test_Maybe_filter()



# Generated at 2022-06-21 19:27:58.544735
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == Monet(5)
    assert Maybe.nothing().to_either() == Monet(None)


# Generated at 2022-06-21 19:28:02.384481
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:28:05.447682
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:28:10.045826
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test bind method of Maybe class.
    """
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * x)) == Maybe.just(4)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * x)) == Maybe.nothing()


# Generated at 2022-06-21 19:28:14.197492
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:28:17.217911
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just(1)
    assert maybe.value == 1
    assert not maybe.is_nothing

    maybe = Maybe.nothing()
    assert maybe.is_nothing
    assert maybe.value is None


# Generated at 2022-06-21 19:28:52.205534
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(8).map(lambda a: a + 2) == Maybe.just(10)
    assert Maybe.just(8).map(lambda a: a + 2).map(lambda a: a / 2) == Maybe.just(5)
    assert Maybe.nothing().map(lambda a: a + 2) == Maybe.nothing()
    assert Maybe.just(8).map(lambda a: a + 2).map(lambda a: a / 0) == Maybe.nothing()


# Generated at 2022-06-21 19:28:55.374595
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('example').get_or_else('Not example') == 'example'
    assert Maybe.nothing().get_or_else('Not example') == 'Not example'



# Generated at 2022-06-21 19:28:59.432925
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda t: t) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda t: not t) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda t: t) == Maybe.nothing()
    assert Maybe.just("").filter(lambda t: True) == Maybe.nothing()
    assert Maybe.just("").filter(lambda t: False) == Maybe.nothing()

# Generated at 2022-06-21 19:29:03.991124
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:29:07.308913
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """Test to_box method of Maybe class."""
    assert Maybe.nothing().to_box().is_nothing
    assert Maybe.just(1).to_box().get() == 1



# Generated at 2022-06-21 19:29:14.495264
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def fn1(x):
        return Maybe(x + 10, False)

    def fn2(x):
        return Maybe(x * x, False)

    result = Maybe.just(5) \
        .bind(fn1) \
        .bind(fn2)

    assert result == Maybe.just(225)

    result = Maybe.just(5) \
        .bind(lambda x: Maybe.nothing()) \
        .bind(fn1) \
        .bind(fn2)

    assert result == Maybe.nothing()



# Generated at 2022-06-21 19:29:18.751554
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: y + x

    assert Maybe.just(1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(add(1)).ap(Maybe.just(3)) == Maybe.just(4)


# Generated at 2022-06-21 19:29:22.817592
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-21 19:29:26.106183
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:29:31.579122
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(5)
    assert Maybe.just(0).bind(lambda x: Maybe.just(x / 0)) == Maybe.nothing()
    assert Maybe.just(0).bind(None) == Maybe.nothing()
    assert Maybe.nothing().bind(None) == Maybe.nothing()



# Generated at 2022-06-21 19:30:40.198816
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test case 1
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(1)
    assert maybe_1 == maybe_2

    # Test case 2
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    assert maybe_1 != maybe_2

    # Test case 3
    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.nothing()
    assert maybe_1 == maybe_2

    # Test case 4
    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.just(None)
    assert maybe_1 != maybe_2

    # Test case 5
    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.just(0)
    assert maybe_1 != maybe_2



# Generated at 2022-06-21 19:30:44.134470
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(
        None,
        is_success=False
    )
    assert Maybe.just(5).to_try() == Try(
        5,
        is_success=True
    )

# Generated at 2022-06-21 19:30:55.158431
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x+1) == Maybe.just(2)
    assert Maybe.just("test").map(lambda x: x + "test") == Maybe.just("testtest")
    assert Maybe.just(1).map(lambda x: None) == Maybe.nothing()
    assert Maybe.just("test").map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
