

# Generated at 2022-06-21 19:20:54.912518
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()

    assert Lazy(lambda: 1) == lazy
    assert 1 == lazy.get_value()



# Generated at 2022-06-21 19:21:00.317522
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad import assert_equals
    from pymonet.lazy import assert_equals_lazy

    lazy_maybe = Maybe.just(1).to_lazy()
    assert_equals_lazy(1, lazy_maybe.get_value())

    lazy_maybe = Maybe.nothing().to_lazy()
    assert_equals_lazy(None, lazy_maybe.get_value())


# Generated at 2022-06-21 19:21:02.534556
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:06.995401
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.lazy import Lazy

    assert Maybe.just(Lazy(lambda x: x + 1).map)(1) == Maybe.just(2)
    assert Maybe.just(Lazy(lambda x: x + 1).ap)(Maybe.just(1)) == Maybe.just(2)



# Generated at 2022-06-21 19:21:09.391920
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:21:12.002875
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:21:14.888656
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    mapper = lambda x: x + 1
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1).bind(mapper) == Maybe.just(2)
    assert Maybe.just(1).map(mapper) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1).__eq__(2) == False



# Generated at 2022-06-21 19:21:17.298238
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe(10, False).to_box() == Box(10)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-21 19:21:25.114734
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation

    def add1(x):
        return x + 1

    def square(x):
        return x * x

    # Mapping a function over an applicative will yield a different applicative
    assert Validation.just(add1).ap(Validation.just(2)).value.value == 3
    assert Validation.just(square).ap(Validation.just(2)).value.value == 4
    assert Validation.just(square).ap(Validation.nothing()).value.value == None
    assert Validation.nothing().ap(Validation.nothing()).value.value == None

# Generated at 2022-06-21 19:21:29.128901
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:21:37.017186
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x - 1) == Maybe.just(1)


# Generated at 2022-06-21 19:21:40.474558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def get_lazy_value(value):
        return Lazy(lambda: value)

    assert Maybe.just(1).to_lazy() == get_lazy_value(1)
    assert Maybe.nothing().to_lazy() == get_lazy_value(None)



# Generated at 2022-06-21 19:21:45.079149
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe = Maybe.just(5)
    assert maybe.to_box() == Box(5)

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)


# Generated at 2022-06-21 19:21:51.592704
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, True), 'Equality of Nothing Maybe is wrong'
    assert Maybe(1, False) == Maybe(1, False), 'Equality of Some Maybe is wrong'
    assert Maybe(1, False) != Maybe(1, True), 'Equality of Maybe with different values is wrong'
    assert Maybe(1, True) != Maybe(2, True), 'Equality of Maybe with different values is wrong'


# Generated at 2022-06-21 19:21:55.320629
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    mb = Maybe.just(1)
    res = mb.to_lazy()

    assert isinstance(res, Lazy)
    assert res.get() == 1

    mb = Maybe.nothing()
    res = mb.to_lazy()

    assert isinstance(res, Lazy)
    assert res.get() is None


# Generated at 2022-06-21 19:22:05.234116
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_reader import Reader

    def print_times_2(x: int) -> int:
        return x * 2

    def times_3(x: int) -> int:
        return x * 3

    def return_func(x: int) -> Callable[[int], int]:
        return print_times_2

    a_maybe = Maybe.just(1)
    a_maybe_nothing = Maybe.nothing()

    assert a_maybe.ap(a_maybe) == Maybe.just(2), "Error, ap faiiled accaptance test"
    assert a_maybe_nothing.ap(a_maybe) == Maybe.nothing(), "Error, ap faiiled accaptance test"

# Generated at 2022-06-21 19:22:17.851132
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    :raises AssertionError: raise AssertionError if test failed
    """

    from pymonet.monad_factory import MonadFactory

    def add_twenty(x: int) -> Maybe[int]:
        return Maybe.just(x + 20)

    def add_twenty2(x: int) -> Maybe[int]:
        return Maybe.just(x + 20)

    assert Maybe.just(5).bind(add_twenty) == Maybe.just(25)
    assert Maybe.just(5).bind(add_twenty).bind(add_twenty2) == Maybe.just(45)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()).bind(add_twenty2) == Maybe.nothing()
    assert Maybe.just

# Generated at 2022-06-21 19:22:22.836346
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    f = Maybe.just(lambda x: x ** 2)
    m = Maybe.just(2)

    # When
    result = m.ap(f)

    # Then
    assert result == Maybe.just(4)



# Generated at 2022-06-21 19:22:26.185901
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Case 1: Maybe is not empty
    assert Maybe.just(1).get_or_else(0) == 1

    # Case 2: Maybe is empty
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:22:28.361481
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.other_classes import Identity

    assert Maybe.just(Identity(3)).bind(Identity) == Identity(Identity(3))
    assert Maybe.nothing().bind(Identity) == Identity(None)

# Generated at 2022-06-21 19:22:41.343185
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_lazy().evaluate() == 1
    assert Maybe.nothing().to_lazy().evaluate() == None
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-21 19:22:44.068481
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(50).to_either() == Right(50)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:22:46.052374
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    assert maybe.to_lazy().get() == 1



# Generated at 2022-06-21 19:22:49.712519
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(42) != Maybe.nothing()


# Generated at 2022-06-21 19:22:52.843150
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe.just(Box(5)).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:22:55.089699
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(1, True).to_try() == Try(None, False)



# Generated at 2022-06-21 19:23:00.097426
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_with_none = Maybe.nothing().to_lazy()
    assert isinstance(lazy_with_none, Maybe)
    assert lazy_with_none.get_or_else(1) is None

    lazy_with_value = Maybe.just(10).to_lazy()
    assert isinstance(lazy_with_value, Maybe)
    assert lazy_with_value.get_or_else(1) == 10


# Generated at 2022-06-21 19:23:02.964776
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-21 19:23:05.514452
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:23:10.336968
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_either() == Left(None)

    not_empty_maybe = Maybe.just(1)
    assert not_empty_maybe.to_either() == Right(1)



# Generated at 2022-06-21 19:23:18.458597
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # empty Maybe
    null = Maybe.nothing()
    assert null.to_lazy() == Lazy(lambda: None)

    # not empty Maybe
    value = Maybe.just(1)
    assert value.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-21 19:23:30.447691
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 1) == Maybe.just(6)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(5).map(lambda x: x ** 2) == Maybe.just(25)
    assert Maybe.just(None).map(lambda x: x ** 2) == Maybe.just(None)
    assert Maybe.just(5.0).map(lambda x: int(x) * 2 + 1) == Maybe.just(11)
    assert Maybe.just("hello").map(lambda x: x[0]) == Maybe.just("h")
    assert Maybe.just("hello").map(lambda x: x[1]) == Maybe.just("e")

# Generated at 2022-06-21 19:23:40.718651
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe1 = Maybe.just(1)
    assert maybe1.filter(lambda x: x > 0) == Maybe.just(1)

    maybe2 = Maybe.just(5)
    assert maybe2.filter(lambda x: x > 10) == Maybe.nothing()

    maybe3 = Maybe.just(True)
    assert maybe3.filter(lambda x: x == False) == Maybe.nothing()

    maybe4 = Maybe.just(100)
    assert maybe4.filter(lambda x: x != 100) == Maybe.nothing()

    maybe5 = Maybe.nothing()
    assert maybe5.filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:23:47.990549
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda v: Maybe.just(v + 5)) == Maybe.just(10), 'Should return Maybe with value 10'
    assert Maybe.just(5).bind(lambda v: Maybe.nothing()) == Maybe.nothing(), 'Should return Maybe with nothing'
    assert Maybe.nothing().bind(lambda v: Maybe.just(v + 5)) == Maybe.nothing(), 'Should return Maybe with nothing'


# Generated at 2022-06-21 19:23:54.123261
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    assert Maybe.just(66).filter(lambda value: value > 0) == Maybe.just(66)
    assert Maybe.just(0).filter(lambda value: value > 0) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda value: Box(value).map(lambda x: x > 0).get_value()
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:24:00.568217
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test_func():
        return 10

    test_Maybe = Maybe.just(test_func)
    test_lazy = test_Maybe.to_lazy()
    assert isinstance(test_lazy, Lazy)
    assert isinstance(test_lazy.eval(), int)
    assert test_func() == test_lazy.eval()



# Generated at 2022-06-21 19:24:04.468000
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2).get_or_else(-1) == 2
    assert Maybe.nothing().map(lambda x: x * 2).get_or_else(-1) == -1



# Generated at 2022-06-21 19:24:06.837038
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    value = 7
    just = Maybe.just(value)
    assert just.get_or_else(None) == 7

    nothing = Maybe.nothing()
    assert nothing.get_or_else(None) == None

# Generated at 2022-06-21 19:24:17.259213
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_list import MonadList
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    v1 = Maybe.just(1)
    v2 = Maybe.nothing()

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert v1.filter(lambda x: x != 1) == Maybe.nothing()
    assert v2.filter(lambda x: x != 1) == Maybe.nothing()
    assert v1.filter(lambda x: x != 2) == Maybe.just(1)

# Generated at 2022-06-21 19:24:21.905904
# Unit test for method map of class Maybe
def test_Maybe_map():
    print('Unit test for method map of class Maybe')

    assert Maybe.just(1).map(lambda x: x ** 2) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x ** 2) == Maybe.nothing()

    print('Success!\n')


# Generated at 2022-06-21 19:24:29.911937
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.just('a') == Maybe('a', False)


# Generated at 2022-06-21 19:24:34.872653
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Unit test for static method Maybe.ap.
    """
    assert Maybe.just(lambda x: x + 2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.just(lambda x: x + 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:24:37.977480
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(None).to_box() == Box(None)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:40.104357
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(1).to_lazy()
    assert isinstance(maybe, Lazy)


# Generated at 2022-06-21 19:24:42.915006
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x * 0) == Maybe.just(0)
    assert Maybe.nothing().map(lambda x: x * 1) == Maybe.nothing()


# Generated at 2022-06-21 19:24:44.839112
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:24:51.567877
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # GIVEN
    def add(arg1: int, arg2: int) -> int:
        return arg1 + arg2

    # WHEN
    result = Maybe.just(add).ap(Maybe.just(2)).ap(Maybe.just(4))

    # THEN
    assert isinstance(result, Maybe)
    assert result.is_nothing is False
    assert result.value == 6

# Generated at 2022-06-21 19:24:55.432005
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()

# Generated at 2022-06-21 19:24:59.818325
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    def add(x):
        return lambda y: x + y
    assert Maybe.just(7).ap(Box(add(4))) == Box(11)
    assert (Maybe.nothing()).ap(Box(add(4))) == Maybe.nothing()


# Generated at 2022-06-21 19:25:09.748698
# Unit test for constructor of class Maybe
def test_Maybe():

    assert Maybe.just('str') == Maybe.just('str')
    assert Maybe.just('str') != Maybe.nothing()
    assert Maybe.just('str') != Maybe.just(10)
    assert Maybe.just('str') != 's'

    assert Maybe.just('str').value == 'str'
    assert not hasattr(Maybe.nothing(), 'value')
    assert hasattr(Maybe.just('str'), 'value')

    assert isinstance(Maybe.nothing(), Maybe)
    assert isinstance(Maybe.just('str'), Maybe)



# Generated at 2022-06-21 19:25:17.687201
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(1, True).to_box() == Box(None)


# Generated at 2022-06-21 19:25:24.540530
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 1) == Maybe.just(6)
    assert Maybe.just(5).map(lambda x: x + 1).is_nothing == False
    assert Maybe.just(5).map(lambda x: x + 1).value == 6
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1).is_nothing == True



# Generated at 2022-06-21 19:25:27.471484
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(15).map(lambda v: v * v) == Maybe.just(225)
    assert Maybe.nothing().map(lambda v: v * v) == Maybe.nothing()


# Generated at 2022-06-21 19:25:29.178266
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x ** 2) == Maybe.just(4)


# Generated at 2022-06-21 19:25:35.457826
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-21 19:25:39.641718
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(2).to_try() == Try(2, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-21 19:25:42.273171
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just("a").to_box() == Box("a")
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:25:49.108021
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Arrange
    maybe_1 = Maybe.just(42)
    maybe_2 = Maybe.nothing()
    # Act
    result_1 = maybe_1.bind(
        lambda v: Maybe.just(v * 10)
    )
    # Assert
    assert result_1 == Maybe.just(420)
    result_2 = maybe_2.bind(
        lambda v: Maybe.just(v * 10)
    )
    # Assert
    assert result_2 == Maybe.nothing()


# Generated at 2022-06-21 19:25:52.300097
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = Lazy(lambda: Maybe.just(1))
    result = Maybe.just(1).to_lazy()
    assert result == value


# Generated at 2022-06-21 19:25:55.064353
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 5).ap(Maybe.just(6)) == Maybe.just(11)
    assert Maybe.nothing().ap(Maybe.just(6)) == Maybe.nothing()



# Generated at 2022-06-21 19:26:09.983590
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:26:14.143598
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    m = Maybe.just(3.14)
    result = m.to_box()
    assert result == Box(3.14)


# Generated at 2022-06-21 19:26:17.514650
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe = Maybe.just(2)
    assert maybe.to_try() == Try(2, is_success=True)

    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:26:27.729055
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import operators
    assert Maybe.just(5).bind(operators.divide).is_nothing
    assert Maybe.just(5).bind(operators.divide).get_or_else("Nope") \
        == Maybe.nothing().get_or_else("Nope")
    assert Maybe.just(1).bind(operators.divide).get_or_else("Nope") == Maybe.just(1).get_or_else("Nope")
    assert Maybe.just(0).bind(operators.divide).get_or_else("Nope") == Maybe.just(0).get_or_else("Nope")
    assert Maybe.nothing().bind(operators.divide).get_or_else("Nope") == Maybe.nothing().get_or_else("Nope")


# Generated at 2022-06-21 19:26:31.724262
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(
        lambda x: x + 1
    ) == Maybe.just(2)

    assert Maybe.nothing().map(
        lambda x: x + 1
    ) == Maybe.nothing()



# Generated at 2022-06-21 19:26:37.407219
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    not_empty_maybe: Maybe[int] = Maybe.just(42)
    empty_maybe: Maybe[int] = Maybe.nothing()

    assert not_empty_maybe.get_or_else(None) == 42
    assert empty_maybe.get_or_else(None) == None

# Unit tests for method map of class Maybe

# Generated at 2022-06-21 19:26:45.422745
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Failure

    def double_argument(value):
        return value * 2

    def convert_to_int(value):
        return int(value)

    # when func is not empty
    actual = Maybe(double_argument, False).ap(Maybe(1, False))
    expected = Maybe.just(2)
    assert actual == expected

    # when func is empty
    actual = Maybe(double_argument, True).ap(Maybe(1, False))
    expected = Maybe.nothing()
    assert actual == expected

    # when func is empty
    actual = Maybe(double_argument, True).ap(Maybe(1, True))
    expected = Maybe.nothing()
    assert actual == expected

    # when value is empty
    actual = Maybe(double_argument, False).ap(Maybe(1, True))


# Generated at 2022-06-21 19:26:57.181685
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test `map` method of class Maybe.

    :returns: None
    :rtype: None
    """
    def add_one(x): return x + 1
    assert Maybe.just(1).map(add_one) == Maybe(2, False)
    assert Maybe.just(1).__class__.__name__ != 'Nothing'
    assert Maybe.nothing().map(add_one) == Maybe(None, True)
    assert Maybe.nothing().__class__.__name__ == 'Nothing'
    assert Maybe.nothing().map(add_one) == Maybe.nothing()
    assert Maybe.nothing().__class__.__name__ == 'Nothing'
    assert Maybe.just(None).map(add_one) == Maybe.nothing()
    assert Maybe.just(None).__class__.__name__ != 'Nothing'

# Generated at 2022-06-21 19:27:03.202523
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.just(5) != 5
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != 5


# Generated at 2022-06-21 19:27:07.968446
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value: int) -> bool:
        return value % 2 == 0

    assert Maybe.just(2).filter(filterer) == Maybe.just(2)
    assert Maybe.just(1).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()

# Generated at 2022-06-21 19:27:24.563621
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # Test empty maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    # Test not empty maybe
    assert Maybe.just(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 19:27:30.002957
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x >= 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x >= 1) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-21 19:27:33.767463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.just('10')
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)



# Generated at 2022-06-21 19:27:37.859556
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(object())
    assert Maybe.just(1) != Maybe(1, True)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe(None, True)
    assert Maybe.nothing() != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(3)
    assert Maybe.just(1) != 1


# Generated at 2022-06-21 19:27:42.980308
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(4, False).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe(3, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-21 19:27:46.480892
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    actual = Maybe(None, is_nothing=True).get_or_else('test')
    expected = 'test'
    assert actual == expected



# Generated at 2022-06-21 19:27:52.766873
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * x)) == Maybe.just(4)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * x)) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * x)).bind(
        lambda y: Maybe.just(y / 2)) == Maybe.just(2)


# Generated at 2022-06-21 19:28:05.234650
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    test_cases = (
        (
            Maybe.just(3),
            lambda a: a % 2 == 0,
            Maybe.nothing()
        ),
        (
            Maybe.just(3),
            lambda a: a % 2 == 1,
            Maybe.just(3)
        ),
        (
            Maybe.nothing(),
            lambda a: a % 2 == 0,
            Maybe.nothing()
        ),
        (
            Maybe.nothing(),
            lambda a: a % 2 == 1,
            Maybe.nothing()
        )
    )

# Generated at 2022-06-21 19:28:06.699304
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)


# Generated at 2022-06-21 19:28:09.668831
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    (Maybe.just(1).get_or_else(0) == 1) and \
    (Maybe.nothing().get_or_else(0) == 0)

# Generated at 2022-06-21 19:28:38.262120
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def strict_func():
        return 1

    def lazy_func():
        return Lazy(lambda: 1)

    monad_1 = Maybe.just(strict_func)
    monad_2 = Maybe.just(lazy_func)
    monad_3 = Maybe.nothing()

    assert monad_1.to_lazy().unwrap() == 1
    assert monad_2.to_lazy().unwrap() == 1
    assert monad_3.to_lazy().unwrap() == None


# Generated at 2022-06-21 19:28:43.140477
# Unit test for method map of class Maybe
def test_Maybe_map():
    def inc(x):
        return x + 1
    maybe = Maybe.just(4)
    assert maybe.map(inc) == Maybe.just(5)
    maybe = Maybe.nothing()
    assert maybe.map(inc) == Maybe.nothing()


# Generated at 2022-06-21 19:28:46.668188
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert(Maybe.just(100).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(101))
    assert(Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing())



# Generated at 2022-06-21 19:28:58.537172
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).ap(Maybe.just(lambda x: x + 1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(lambda x: x + 1)) == Maybe.nothing()

    assert Maybe.just(1).ap(Left(lambda x: x + 1)) == Maybe.nothing()
    assert Maybe.just(1).ap(Right(lambda x: x + 1)) == Maybe.just(2)

    assert Maybe.just(1).ap(Box(lambda x: x + 1)) == Maybe.just(2)
    assert Maybe.nothing().ap

# Generated at 2022-06-21 19:29:01.097183
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(None, True).get_or_else(0) == 0
    assert Maybe(10, False).get_or_else(0) == 10


# Generated at 2022-06-21 19:29:06.536693
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    value = 1
    assert Maybe(value, False).to_either() == Right(value)
    assert Maybe(value, True).to_either() == Left(None)
    assert Maybe(None, False).to_either() == Right(None)


# Generated at 2022-06-21 19:29:09.580776
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just("test").to_validation() == Validation.success("test")
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:29:12.536006
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Unit test for method to_lazy of class Maybe."""
    result = Maybe.just(1).to_lazy().value()
    expected = 1
    assert result == expected


# Generated at 2022-06-21 19:29:15.200737
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Construct new Maybe.

    :returns: None
    """
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-21 19:29:20.580845
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import pytest

    def bind_mapper(x: int) -> Maybe[int]:
        return Maybe.just(x + 1)

    test_cases = [
        (Maybe.just(0), Maybe.just(1)),
        (Maybe.just(1), Maybe.just(2)),
        (Maybe.nothing(), Maybe.nothing()),
    ]

    for case, expected_result in test_cases:
        result = case.bind(bind_mapper)
        assert result == expected_result


# Generated at 2022-06-21 19:30:08.766325
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, False).to_box() == Box(None)
    assert Maybe(1, True).to_box() == Box(None)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-21 19:30:15.669561
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # set of test cases
    test_cases = [
        ({
            'm': Maybe.just(lambda x: x),
            'ma': Maybe.just(1),
            'expected': Maybe.just(1)
        }),
        ({
            'm': Maybe.nothing(),
            'ma': Maybe.just(1),
            'expected': Maybe.nothing()
        }),
        ({
            'm': Maybe.just(lambda x: x),
            'ma': Maybe.nothing(),
            'expected': Maybe.nothing()
        })
    ]

    # check result of ap with test cases
    for test_case in test_cases:
        assert test_case['m'].ap(test_case['ma']) == test_case['expected']



# Generated at 2022-06-21 19:30:26.075958
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int = Maybe.just(1)

    maybe_filtered_int = maybe_int.filter(lambda x: x < 2)
    assert(
        maybe_filtered_int == Maybe.just(1)
    ), 'AssertionError: maybe_filtered_int should be Maybe.just(1)'

    maybe_maybe_filtered_int = maybe_filtered_int.filter(lambda x: x > 0)
    assert(
        maybe_maybe_filtered_int == Maybe.just(1)
    ), 'AssertionError: maybe_maybe_filtered_int should be Maybe.just(1)'

    maybe_maybe_nothing_int = maybe_maybe_filtered_int.filter(lambda x: x < 0)

# Generated at 2022-06-21 19:30:28.452424
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:30:30.989542
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-21 19:30:33.864294
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert (Maybe.just(5).get_or_else(10) == 5)
    assert (Maybe.nothing().get_or_else(10) == 10)


# Generated at 2022-06-21 19:30:37.905585
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert(Maybe.just(42).to_try() == Try(42, True))
    assert(Maybe.nothing().to_try() == Try(None, False))

# Generated at 2022-06-21 19:30:41.521003
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    empty_maybe: Maybe[int] = Maybe.nothing()

    assert empty_maybe == Maybe.nothing()

    non_empty_maybe: Maybe[str] = Maybe.just('hola')

    assert non_empty_maybe == Maybe.just('hola')

# Generated at 2022-06-21 19:30:45.432709
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(1, False)
    assert m.value == 1
    assert not m.is_nothing

    m = Maybe.nothing()
    assert m.is_nothing

    m = Maybe.just(1)
    assert m.value == 1
    assert not m.is_nothing


# Generated at 2022-06-21 19:30:50.492632
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) and \
        Maybe.just(1) != Maybe.nothing() and \
        Maybe.nothing() == Maybe.nothing()
