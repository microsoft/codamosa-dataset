

# Generated at 2022-06-21 19:20:51.683843
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_none = Maybe.just(None)
    result_map = maybe_none.map(lambda x: x + 1)
    assert result_map == Maybe.just(None)

    maybe_int = Maybe.just(2)
    result_map = maybe_int.map(lambda x: x + 1)
    assert result_map == Maybe.just(3)

    maybe_str = Maybe.just("2")
    result_map = maybe_str.map(lambda x: int(x) + 1)
    assert result_map == Maybe.just(3)

    maybe_none = Maybe.nothing()
    result_map = maybe_none.map(lambda x: x + 1)
    assert result_map == Maybe.nothing()



# Generated at 2022-06-21 19:20:54.656451
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(2, False) == Maybe.just(2)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-21 19:20:59.328684
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test method Maybe.to_try
    :return: True if all test passed
    :rtype: Boolean
    """
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)
    return True



# Generated at 2022-06-21 19:21:02.885950
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == \
        Maybe.nothing().to_either() == \
        Maybe.just(5).to_box().to_either()



# Generated at 2022-06-21 19:21:06.894420
# Unit test for constructor of class Maybe
def test_Maybe():
    test_value = "test_value"
    test_value_2 = "test_value_2"

    assert Maybe.just(test_value) == Maybe(test_value, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-21 19:21:16.596921
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == \
        Maybe.nothing().to_either() == \
        Maybe.nothing().bind(lambda _: Maybe.just(1)).to_either() == \
        Maybe.nothing().bind(lambda _: Maybe.nothing()).to_either() == \
        Maybe.just(1).bind(lambda _: Maybe.nothing()).to_either() == \
        Maybe.just(1).bind(lambda _: Maybe.just(1)).to_either() == \
        Maybe.just(1).bind(lambda _: Maybe.just(2)).to_either() == \
        Maybe.just(1).bind(lambda _: Maybe.just(3)).to_either() == \
        Maybe.just(1).bind(lambda x: Maybe.just(x)).to_either()



# Generated at 2022-06-21 19:21:21.016525
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.asserts import assert_that

    first_maybe = Maybe.just(6)
    second_maybe = Maybe.nothing()

    assert_that(first_maybe.get_or_else(0)).is_equal_to(6)
    assert_that(second_maybe.get_or_else(0)).is_equal_to(0)


# Generated at 2022-06-21 19:21:25.805148
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    val_1 = Validation.success('Some')
    val_2 = Validation.failure('None')

    assert Maybe.just(1).to_validation() == val_1
    assert Maybe.nothing().to_validation() == val_1
    assert Maybe.just(0).to_validation() == val_2
    assert Maybe.nothing().to_validation() == val_2


# Generated at 2022-06-21 19:21:29.469762
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-21 19:21:34.599511
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.just(1).get_or_else(3) == 1
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-21 19:21:40.092168
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left

    assert Maybe.just(123).to_lazy() == Lazy(lambda: 123)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:21:46.056115
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-21 19:21:50.929167
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.utils import identity, inc

    m = Maybe.just(1)
    assert m.to_lazy().run() == 1

    m = Maybe.nothing()
    assert m.to_lazy().run() is None



# Generated at 2022-06-21 19:21:54.445669
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m = Maybe.just(10)
    l = m.to_lazy()
    assert isinstance(l, Lazy)
    assert l.get() == 10


# Generated at 2022-06-21 19:22:02.157631
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.just(2)

    assert Maybe.just(1).bind(
        lambda _: Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda _: Maybe.nothing()
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:22:05.539411
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(3) == 1
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-21 19:22:09.232646
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('a').get_or_else('b') == 'a'
    assert Maybe.nothing().get_or_else('b') == 'b'


# Generated at 2022-06-21 19:22:15.897305
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Tests method ap of class Maybe.

    :return:
    """
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()


# Generated at 2022-06-21 19:22:20.389649
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:22:29.763625
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.box import Box

    monads = [
        Maybe.just(1),
        Maybe.nothing()
    ]


# Generated at 2022-06-21 19:22:36.383602
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def add_one(value):
        return Maybe.just(value + 1)

    assert Maybe.just(1).bind(add_one) == Maybe.just(2)
    assert Maybe.nothing().bind(add_one) == Maybe.nothing()



# Generated at 2022-06-21 19:22:43.287253
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """Test ap method of Maybe class."""
    from pymonet.box import Box
    from pymonet.either import Right, Left

    assert Maybe.just(lambda x: x+1).ap(Right(2)) == Right.pure(3)
    assert Maybe.nothing().ap(Right(2)) == Maybe.nothing()
    assert Maybe.just(lambda x: x+1).ap(Left("error")) == Maybe.nothing()
    assert Maybe.nothing().ap(Left("error")) == Maybe.nothing()
    assert Maybe.just(lambda x: x+1).ap(Box.pure(2)) == Box.pure(3)
    assert Maybe.nothing().ap(Box.pure(2)) == Maybe.nothing()



# Generated at 2022-06-21 19:22:45.686408
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:22:49.869982
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-21 19:22:53.211279
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:22:56.476534
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.just(0).to_either() == Right(0)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:22:58.216085
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:01.887478
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test bind method in Maybe.

    :returns: True if test passed
    :rtype: Boolean
    """
    def maybe_to_string(value):
        if value is None:
            return Maybe.nothing()
        return Maybe.just(str(value))

    m = Maybe.just(123)
    m = m.bind(maybe_to_string)
    return m == Maybe.just('123')


# Generated at 2022-06-21 19:23:05.561512
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def f(a):
        return Maybe.just(a + 1)

    assert Maybe.just(1).bind(f) == Maybe.just(2)
    assert Maybe.nothing().bind(f) == Maybe.nothing()


# Generated at 2022-06-21 19:23:16.815537
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # mapper returns Maybe[A]
    def mapper(x):
        return Maybe.just(x + 1)

    # mapper returns Maybe[None]
    def mapper_none(x):
        return Maybe.nothing()

    # value to store in Maybe
    x = 10

    # value to store in Maybe as function
    def func(y):
        return y + x

    # assert ap on notempty Maybe
    val = Maybe.just(func).ap(Maybe.just(1))
    assert val == Maybe.just(func(1))
    # assert ap on empty Maybe
    val = Maybe.just(func).ap(Maybe.nothing())
    assert val == Maybe.nothing()
    # assert ap on notempty Maybe
    val = Maybe.just(mapper).ap(Maybe.just(1))

# Generated at 2022-06-21 19:23:26.908366
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    try:
        # case: return Lazy monad with function returning previous value
        assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
    except NameError:
        # case: return Lazy monad with function returning previous value in other case Left with None
        assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
        assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:23:32.863593
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    error = "to_either of Maybe is incorrect."
    assert Maybe.nothing().to_either().is_left is True, error
    assert Maybe.just(10).to_either().is_right is True, error
    assert Maybe.nothing().to_either().get_or_else('not_none') is None, error
    assert Maybe.just(10).to_either().get_or_else('not_none') == 10, error

# Generated at 2022-06-21 19:23:36.852397
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-21 19:23:39.077516
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.just(2)
    maybe_empty = Maybe.nothing()

    assert maybe_one.map(lambda x: x + 1) == Maybe.just(2)
    assert maybe_two.map(lambda x: x - 1) == Maybe.just(1)
    assert maybe_empty.map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-21 19:23:43.362305
# Unit test for constructor of class Maybe
def test_Maybe():
    from asserts.asserts import assert_

    with assert_(Maybe.just(2).value == 2):
        Maybe.just(2)
    with assert_(Maybe.nothing() is Maybe.nothing()):
        Maybe.nothing()


# Generated at 2022-06-21 19:23:50.202971
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit tests for map method of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    assert type(Maybe.just(1).map(lambda x: x + 10)) is Maybe
    assert Maybe.just(1).map(lambda x: x + 10) == Maybe.just(11)
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()


# Generated at 2022-06-21 19:23:53.228258
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just(3).bind(lambda x: Maybe.just(x + 3))
    assert result == Maybe.just(6)
    result = Maybe.nothing().bind(lambda x: Maybe.just(x + 3))
    assert result == Maybe.nothing()



# Generated at 2022-06-21 19:23:58.386636
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-21 19:24:00.514089
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:24:04.818063
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(42).to_try() == Try(42, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:24:15.667588
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import List

    list_of_maybe = List(Maybe.just(2), Maybe.just(3), Maybe.just(4))
    result = Maybe.just(lambda x: x * 3).ap(list_of_maybe)
    assert isinstance(result, List)
    assert result.value == [6, 9, 12]

    result = Maybe.just(List).ap(list_of_maybe)
    assert isinstance(result, List)
    assert result.value == [Maybe.just(2), Maybe.just(3), Maybe.just(4)]



# Generated at 2022-06-21 19:24:18.329967
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-21 19:24:22.372769
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-21 19:24:25.824430
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, True), "Maybe.to_try() test failed"
    assert Maybe.nothing().to_try() == Try(None, False), "Maybe.to_try() test failed"
    print("Maybe.to_try() test passed")


# Generated at 2022-06-21 19:24:28.497593
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:24:29.823508
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(4, False) == Maybe(4, False)


# Generated at 2022-06-21 19:24:32.012068
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(11).get_or_else(10) == 11
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-21 19:24:38.590720
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    value_1 = 1
    value_2 = 2
    f = lambda x: x + 1
    result = Maybe.just(value_1).ap(Maybe.just(f))
    expected = Maybe.just(f(value_1))
    assert expected == result

    result = Maybe.just(value_1).ap(Maybe.nothing())
    expected = Maybe.nothing()
    assert expected == result

    result = Maybe.nothing().ap(Maybe.just(f))
    expected = Maybe.nothing()
    assert expected == result

    result = Maybe.nothing().ap(Maybe.nothing())
    expected = Maybe.nothing()
    assert expected == result



# Generated at 2022-06-21 19:24:40.407966
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:24:42.470908
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:24:57.885571
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():

    from pymonet.monad import compose
    from pymonet.monad_try import Try, _raise
    from pymonet.monad_operators import bind_to, map_to, apply_to

    def testable_function(value):
        if value == 1:
            return value * 2
        else:
            return _raise('test exception')

    value = 2
    composed = compose(Maybe.just(value),
                       bind_to(Maybe.just),
                       map_to(testable_function),
                       apply_to(Maybe.just))

    assert composed.to_try() == (Try(4, is_success=True))
    assert composed.to_try() != (Try(2, is_success=True))
    assert composed.to_try() != (Try(None, is_success=False))
   

# Generated at 2022-06-21 19:25:01.385134
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(42) != Maybe.nothing()


# Generated at 2022-06-21 19:25:03.984552
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def my_lazy_function():
        return 'lazy'

    assert Maybe.just(my_lazy_function).to_lazy().foce() == 'lazy'
    assert Maybe.nothing().to_lazy().foce() is None


# Generated at 2022-06-21 19:25:13.789383
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.lazy import Lazy

    assert Maybe.just(lambda a: a + 1).ap(Maybe.just(5)) == Maybe.just(6)
    assert Maybe.just(lambda a: a + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

    # TODO: Test ap on Lazy
    # assert Maybe.just(lambda a: a + 1).ap(Lazy(lambda: 5)) == Maybe.just(6)
    # assert Maybe.nothing().ap(Lazy(lambda: 5)) == Maybe.nothing()


# Generated at 2022-06-21 19:25:16.604930
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:25:20.998529
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.just(None).to_box() == Box(None)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:25:27.832323
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.just(321) != Maybe.just(123)
    assert Maybe.just(321) == Maybe.just(321)
    assert Maybe.just(123) != Maybe.just(321)
    assert Maybe.just(123) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(123)
    assert Maybe.nothing() != Maybe.just(321)


# Generated at 2022-06-21 19:25:30.530529
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def func():
        return '3'
    actual = Maybe.just(func).to_lazy()
    assert actual.value(lambda: '1') == '3'
    assert actual.value(func) == '3'


# Generated at 2022-06-21 19:25:31.810022
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:25:41.369853
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # GIVEN maybe with value 3
    maybe = Maybe.just(3)
    # AND empty maybe
    maybe_empty = Maybe.nothing()

    # WHEN transform to Box
    maybe_box = maybe.to_box()
    # AND transform empty Maybe to Box
    maybe_box_empty = maybe_empty.to_box()

    # THEN result is Box(3)
    assert maybe_box.value == 3
    # AND empty result is Box(None)
    assert maybe_box_empty.value is None



# Generated at 2022-06-21 19:25:48.060959
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(5).to_validation().is_success()
    assert Maybe.nothing().to_validation().is_success()

# Generated at 2022-06-21 19:25:53.327448
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_identity import Identity

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.just([1, 2, 3]).to_validation() == Validation.success([1, 2, 3])
    assert Maybe.just(Identity.of(2)).to_validation() == Validation.success(Identity.of(2))
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:25:57.379132
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor
    def add_1(n1): return n1 + 1
    f = Maybe.just(Functor.pure(add_1))
    assert f.ap(Maybe.just(1)) == Maybe.just(2)
    assert f.ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:26:03.753162
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(
        lambda x: Maybe.just(x + 2)
    ) == Maybe.just(5)

    assert Maybe.just(3).bind(
        lambda x: Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x + 2)
    ) == Maybe.nothing()


# Generated at 2022-06-21 19:26:08.191306
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(2, False).to_either() == Either.right(2)
    assert Maybe(None, True).to_either() == Either.left(None)

# Generated at 2022-06-21 19:26:12.937032
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    f = lambda a: a + 1
    functor = Maybe.just(f)
    assert functor.ap(Maybe.just(1)) == Maybe.just(2)
    assert functor.ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:26:20.634180
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    Validation.success(5).ap(Maybe.just(lambda x: x * 2)).to_box() == Box(10)
    Validation.success(5).ap(Maybe.nothing()).to_box() == Box(None)

    assert Validation.success(5).ap(Maybe.just(lambda x: x * 2)).to_box() == Box(10)
    assert Validation.success(5).ap(Maybe.nothing()).to_box() == Box(None)

# Generated at 2022-06-21 19:26:23.058762
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    actual = Maybe.just(3).to_validation()

    expected = Validation.success(3)

    assert actual == expected



# Generated at 2022-06-21 19:26:24.981949
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def func():
        return 'Some'

    maybe = Maybe.just(func)
    lazy = maybe.to_lazy()
    assert lazy() == 'Some'

# Generated at 2022-06-21 19:26:27.767429
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-21 19:26:38.186504
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1).get_or_else(2) == 1
    assert Maybe.just(1).filter(lambda x: x == 2).get_or_else(2) == 2
    assert Maybe.nothing().filter(lambda x: True).get_or_else(2) == 2

# Generated at 2022-06-21 19:26:41.602739
# Unit test for method map of class Maybe
def test_Maybe_map():
    val = Maybe.just(1).map(lambda x: x + 1)
    val_nothing = Maybe.nothing().map(lambda x: x + 1)
    assert val == Maybe.just(2)
    assert val_nothing == Maybe.nothing()



# Generated at 2022-06-21 19:26:47.663556
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(2, False) != Maybe(1, False)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe(2, True) == Maybe(2, True)

# Test for method just of class Maybe

# Generated at 2022-06-21 19:26:58.384420
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test Maybe to_lazy method.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe(4, False).to_lazy() == Lazy(lambda: 4)
    assert Maybe(5, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(6, False).to_lazy() == Try(6, is_success=True).to_lazy()
    assert Maybe(7, True).to_lazy() == Try(7, is_success=False).to_lazy()
    assert Maybe(8, False).to_lazy() == Right(8).to_

# Generated at 2022-06-21 19:27:08.616514
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    # Test: to_either works good with empty Maybe
    def test_to_either_empty_Maybe():
        my_maybe = Maybe.nothing()
        my_either = my_maybe.to_either()
        assert my_either.is_left()
        assert my_either.value is None

    # Test: to_either works good with not empty Maybe
    def test_to_either_not_empty_Maybe():
        my_maybe = Maybe.just(1)
        my_either = my_maybe.to_either()
        assert my_either.is_right()
        assert my_either.value == 1

    test_to_either_empty_Maybe()
    test_to_either_not_empty_Maybe()



# Generated at 2022-06-21 19:27:10.869428
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # arrange
    maybe = Maybe.just(10)
    expected = 20

    # act
    actual = maybe.get_or_else(20)

    # assert
    assert actual == expected

# Generated at 2022-06-21 19:27:15.708834
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.tuple_ import Tuple2
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.just(Tuple2(1, 2)).get_or_else(Tuple2(3, 4)) == Tuple2(1, 2)
    assert Maybe.nothing().get_or_else(Tuple2(3, 4)) == Tuple2(3, 4)


# Generated at 2022-06-21 19:27:18.094128
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe(6, False)
    assert maybe.value == 6
    assert maybe.is_nothing == False


# Generated at 2022-06-21 19:27:20.066406
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation(1, [])
    assert Maybe.nothing().to_validation() == Validation(None, [])



# Generated at 2022-06-21 19:27:23.266692
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    box = Maybe.just(4).to_box()
    assert box.value == 4

    box = Maybe.nothing().to_box()
    assert box.value == None


# Generated at 2022-06-21 19:27:33.383619
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(1)
    b = Maybe.just(1)
    c = Maybe.nothing()
    d = Maybe.just(2)
    assert (a == a) is True
    assert (a == b) is True
    assert (a == c) is False
    assert (a == d) is False
    assert (c == c) is True


# Generated at 2022-06-21 19:27:39.027147
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad_maybe import Maybe

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:27:44.954221
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    ap1 = Maybe.just(lambda x: x + 1)
    ap2 = Maybe.just(2)
    ap3 = Maybe.nothing()

    assert ap1.ap(ap2) == Maybe.just(3)
    assert ap1.ap(ap3) == Maybe.nothing()
    assert ap3.ap(ap2) == Maybe.nothing()
    assert ap3.ap(ap3) == Maybe.nothing()



# Generated at 2022-06-21 19:27:55.203394
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit tests for map method of Maybe class.
    """
    def f(x: int) -> str:
        return str(2 * x)

    # Test empty Maybe
    m_nothing = Maybe.nothing()
    assert m_nothing.map(f) == Maybe.nothing()

    # Test nonempty Maybe and correct mapper function
    m_just_int = Maybe.just(3)
    assert m_just_int.map(f) == Maybe.just("6")

    # Test nonempty Maybe and wrong mapper function
    def f_wrong(x: str) -> str:
        return x

    m_just_int = Maybe.just(3)
    with pytest.raises(TypeError):
        assert m_just_int.map(f_wrong) == Maybe.just("6")



# Generated at 2022-06-21 19:27:59.866343
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(1).to_validation().value == 1
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:28:08.116732
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_list import List
    from pymonet.monad_tuple import Tuple

    assert Maybe(4, False).map(lambda x: x + 2) == Maybe(6, False)
    assert Maybe(4, True).map(lambda x: x + 2) == Maybe(None, True)
    assert Maybe(4, False).map(lambda x: List(x)) == List(Maybe(4, False))
    assert Maybe(4, False).map(lambda x: Tuple(x)) == Maybe(Tuple(4), False)
    assert Maybe(4, False).map(lambda x: x + Maybe.just(20)) == Maybe(24, False)
    assert Maybe(4, False).map(lambda x: x + Maybe.nothing()) == Maybe(None, True)



# Generated at 2022-06-21 19:28:10.728214
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-21 19:28:14.372045
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:28:17.096583
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:28:20.978635
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    a = Maybe.just(1)
    b = Maybe.nothing()

    assert a.to_either() == Right(1)
    assert b.to_either() == Left(None)

# Generated at 2022-06-21 19:28:39.428318
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    # maybe = Maybe(None, True)
    maybe = Maybe.nothing()
    assert maybe.is_nothing == True
    assert Try(maybe.value).is_success == False

    # maybe = Maybe(None, False)
    maybe = Maybe.just(None)
    assert maybe.is_nothing == False
    assert maybe.value is None

    # maybe = Maybe(10, True)
    maybe = Maybe.nothing()
    assert maybe.is_nothing == True
    assert Try(maybe.value).is_success == False

    # maybe = Maybe(10, False)
    maybe = Maybe.just(10)
    assert maybe.is_nothing == False
    assert maybe.value == 10


# Generated at 2022-06-21 19:28:42.282827
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(1) == 42
    assert Maybe.nothing().get_or_else(1) == 1

# Generated at 2022-06-21 19:28:46.667812
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_num = Maybe.just(5)
    maybe_mul = Maybe.just(lambda x: x * 2)

    assert maybe_num.ap(maybe_mul) == Maybe(10, False)
    assert Maybe.nothing().ap(maybe_mul) == Maybe(None, True)


# Generated at 2022-06-21 19:28:51.975637
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    m = Maybe.just(2)
    assert m.to_either() == Right(2)

    n = Maybe.nothing()
    assert n.to_either() == Left(None)


# Generated at 2022-06-21 19:29:01.716709
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, True).is_nothing == True
    assert Maybe(1, True).value is None

    assert Maybe(1, False).is_nothing == False
    assert Maybe(1, False).value == 1

    assert Maybe(1, True).__eq__(Maybe(1, True)) == True
    assert Maybe(1, False).__eq__(Maybe(1, True)) == False
    assert Maybe(1, False).__eq__(Maybe(2, False)) == False
    assert Maybe(1, False).__eq__(Maybe(1, False)) == True

    assert Maybe.just("foo").is_nothing == False
    assert Maybe.just("foo").value == "foo"

    assert Maybe.nothing().is_nothing == True
    assert Maybe.nothing().value is None



# Generated at 2022-06-21 19:29:04.724830
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy()() is None
    assert Maybe.just(3).to_lazy()() == 3



# Generated at 2022-06-21 19:29:13.559045
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe1 = Maybe.just(2)
    maybe2 = Maybe.just(0)
    maybe3 = Maybe.nothing()

    # When
    result1 = maybe1.filter(lambda x: x > 1)
    result2 = maybe1.filter(lambda x: x > 10)
    result3 = maybe2.filter(lambda x: x > 1)
    result4 = maybe3.filter(lambda x: x > 1)

    # Then
    assert result1 == Maybe.just(2)
    assert result2 == Maybe.nothing()
    assert result3 == Maybe.nothing()
    assert result4 == Maybe.nothing()


# Generated at 2022-06-21 19:29:19.015622
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    assert Maybe.just(1).filter(is_even) == Maybe.nothing()
    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()


# Generated at 2022-06-21 19:29:23.434561
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-21 19:29:33.685884
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Nothing()
    assert Maybe.just(1) != Box(1)
    assert Maybe.nothing() != Box(1)
    
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != ()
    assert Maybe.just(1) != [1]
    assert Maybe.just(1) != {1:2}
    assert Maybe.just(1) != {1}
    assert Maybe.just(1) != None


# Generated at 2022-06-21 19:29:45.569536
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m1 = Maybe.just(1)
    assert 1 == m1.to_lazy().value()
    m2 = Maybe.nothing()
    assert None == m2.to_lazy().value()


# Generated at 2022-06-21 19:29:52.385295
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def is_even(x):
        return x % 2 == 0

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

    assert Maybe.just(5).map(is_even).to_lazy() == Lazy(lambda: False)

# Generated at 2022-06-21 19:29:54.329198
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(9).get_or_else('None') == 9
    assert Maybe.nothing().get_or_else('None') == 'None'



# Generated at 2022-06-21 19:30:00.954319
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.nothing()
    another_maybe = Maybe.nothing()
    assert maybe == another_maybe

    maybe = Maybe.just(5)
    another_maybe = Maybe.just(5)
    assert maybe == another_maybe

    maybe = Maybe.just(5)
    another_maybe = Maybe.just(8)
    assert maybe != another_maybe

    maybe = Maybe.just(5)
    another_maybe = Maybe.nothing()
    assert maybe != another_maybe



# Generated at 2022-06-21 19:30:04.310266
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:30:07.459983
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe(5, True) != Maybe(5, False)


# Generated at 2022-06-21 19:30:12.240396
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m = Maybe.just(1)
    l = m.to_lazy()
    assert l == Lazy(lambda: 1)

    m = Maybe.nothing()
    l = m.to_lazy()
    assert l == Lazy(lambda: None)


# Generated at 2022-06-21 19:30:15.576071
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just("Some value").to_either() == Right("Some value")
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:30:20.232137
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:30:23.737935
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe.to_box method.
    :return:
    """

    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:30:38.666563
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2) == Box(2)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:30:43.162001
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either, Left, Right

    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(None).to_either() == Right(None)
