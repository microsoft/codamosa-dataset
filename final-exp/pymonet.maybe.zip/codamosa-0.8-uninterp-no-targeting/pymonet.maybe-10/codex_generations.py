

# Generated at 2022-06-21 19:20:49.473441
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = Maybe(111, False)
    result = value.to_lazy()

    assert isinstance(result, Lazy)
    assert callable(result.value)
    assert result.value() == 111


# Generated at 2022-06-21 19:20:53.974788
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-21 19:20:58.414126
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe_empty = Maybe.nothing()
    maybe_not_empty = Maybe.just('Test')

    assert maybe_empty.get_or_else('default 0') == 'default 0'
    assert maybe_not_empty.get_or_else('default 1') == 'Test'



# Generated at 2022-06-21 19:21:02.612595
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:21:08.130461
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test to check filter method of Maybe class.

    :returns: Nothing
    :rtype: None
    """
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:21:11.443227
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Arrange
    m = Maybe.just(1)
    default_value = 2

    # Act
    result = m.get_or_else(default_value)

    # Assert
    assert result == 1


# Generated at 2022-06-21 19:21:19.232933
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    We test Maybe.get_or_else method in Maybe class

    :returns: None
    """
    print('Test Maybe.get_or_else method in Maybe class')
    print('Maybe.nothing().get_or_else(2)')
    assert Maybe.nothing().get_or_else(2) == 2
    print('Maybe.just(1).get_or_else(2)')
    assert Maybe.just(1).get_or_else(2) == 1
    print('Passed!')



# Generated at 2022-06-21 19:21:21.005239
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(None, True).get_or_else("Default") == "Default"
    assert Maybe("Hello", False).get_or_else("Default") == "Hello"



# Generated at 2022-06-21 19:21:27.599316
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test Maybe.to_try method.
    """
    assert Maybe.just(123).to_try() == Try(123, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:21:32.517922
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert isinstance(Maybe.just(1).to_lazy(), Lazy)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:21:48.062775
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    assert Maybe.just('value').ap(Maybe.just(lambda x: x.upper())) == Maybe.just('VALUE')
    assert Maybe.nothing().ap(Maybe.just(lambda x: x.upper())) == Maybe.nothing()
    assert Maybe.just('value').ap(Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(1).ap(Try.success(lambda x: x + 1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Try.success(lambda x: x + 1)) == Maybe.nothing()
    assert Maybe.just(1).ap

# Generated at 2022-06-21 19:21:52.828478
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-21 19:21:59.826648
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe.just(123).filter(lambda x: x > 1)
    expected = Maybe.just(123)
    assert result == expected

    result = Maybe.just(123).filter(lambda x: x > 123)
    expected = Maybe.nothing()
    assert result == expected

    result = Maybe.nothing().filter(lambda x: x > 1)
    expected = Maybe.nothing()
    assert result == expected


# Generated at 2022-06-21 19:22:03.689668
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    mapper = lambda x: x ** 2
    maybe1 = Maybe.just(mapper)
    maybe2 = Maybe.just(2)
    assert maybe1.ap(maybe2) == Maybe.just(mapper(maybe2.value))
    assert maybe1.ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-21 19:22:09.808955
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad_maybe import Maybe
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-21 19:22:14.941396
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-21 19:22:24.726117
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    >>> test_Maybe_filter()
    True
    """

    def even(x):
        return x % 2 == 0

    def odd(x):
        return not even(x)

    assert Maybe.just(2).filter(even) == Maybe.just(2)
    assert Maybe.just(3).filter(even) == Maybe.nothing()
    assert Maybe.just(2).filter(odd) == Maybe.nothing()
    assert Maybe.just(3).filter(odd) == Maybe.just(3)
    assert Maybe.nothing().filter(odd) == Maybe.nothing()

    return True


# Generated at 2022-06-21 19:22:26.729701
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-21 19:22:30.125842
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test for method to_try of class Maybe.
    """
    from pymonet.monad_try import Try
    assert Maybe.just('').to_try() == Try('', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:22:35.752223
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.just(12).to_either() == Right(12)



# Generated at 2022-06-21 19:22:48.123311
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def test_mapper(value):
        return value + 2

    m1 = Maybe(test_mapper, False)
    m2 = m1.map(lambda f: f(1))
    m3 = m2.to_box()
    m4 = m3.map(lambda x: str(x) + " World!")
    assert m4 == Box("3 World!")



# Generated at 2022-06-21 19:22:52.872554
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(value):
        return Maybe.just(2 * value)

    assert Maybe.just(1).bind(mapper).value == 2
    assert Maybe.just(1).bind(mapper).is_nothing is False
    assert Maybe.nothing().bind(mapper).value is None
    assert Maybe.nothing().bind(mapper).is_nothing is True

# Generated at 2022-06-21 19:22:59.490079
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    def method_under_test(value: object) -> Maybe[object]:
        return Maybe.just(value)

    from pymonet.validation import Validation

    assert method_under_test('hello').to_validation() == Validation.success('hello')
    assert method_under_test(None).to_validation() == Validation.success(None)
    assert method_under_test(Maybe.nothing()).to_validation() == Validation.success(Maybe.nothing())
    assert method_under_test(Maybe.just('he')).to_validation() == Validation.success(Maybe.just('he'))


# Generated at 2022-06-21 19:23:03.917365
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(1, False)
    assert(m == Maybe.just(1))
    m = Maybe(None, True)
    assert(m == Maybe.nothing())
    print('Maybe unit test finished correctly.')


# Generated at 2022-06-21 19:23:07.453972
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('1').get_or_else('2') == '1'
    assert Maybe.nothing().get_or_else('2') == '2'



# Generated at 2022-06-21 19:23:14.515959
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(
        lambda x: x * 2
    ).ap(
        Maybe.just(2)
    ) == Maybe.just(4)

    assert Maybe.just(
        lambda x: x * 2
    ).ap(
        Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().ap(
        Maybe.just(2)
    ) == Maybe.nothing()

    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-21 19:23:18.689899
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    # maybe = Maybe.nothing()
    # try_from_maybe = maybe.to_either()
    # assert try_from_maybe == Left(None)
    #
    # maybe = Maybe.nothing()
    # try_from_maybe = maybe.to_try()
    # assert try_from_maybe == Try(None, is_success=False)
    #
    # maybe = Maybe.just(5)
    # try_from_maybe = maybe.to_either()
    # assert try_from_maybe == Right(5)
    #
    # maybe = Maybe.just(5)
    # try_from_maybe = maybe.to_try()
    # assert try_from_maybe == Try(5, is_success=

# Generated at 2022-06-21 19:23:23.243919
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """Test method get_or_else of class Maybe."""
    assert Maybe.just(10).get_or_else(0) == 10
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-21 19:23:25.847504
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:23:28.296827
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-21 19:23:36.848467
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('Hello') == Maybe('Hello', False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-21 19:23:48.733063
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(-1, False).to_box() == Box(-1)
    assert Maybe(0, False).to_box() == Box(0)

    assert Maybe(True, False).to_box() == Box(True)
    assert Maybe(False, False).to_box() == Box(False)

    assert Maybe("one", False).to_box() == Box("one")
    assert Maybe("", False).to_box() == Box("")

    assert Maybe((1, 2), False).to_box() == Box((1, 2))
    assert Maybe(("one", "two"), False).to_box() == Box(("one", "two"))

    assert Maybe([1, 2], False).to_box() == Box([1, 2])

# Generated at 2022-06-21 19:23:52.414795
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Create 2 instances of Maybe and check if they are equal.

    :return: None
    :rtype: None
    """
    maybe1 = Maybe(2, False)
    maybe2 = Maybe(2, False)

    assert maybe1 == maybe2


# Generated at 2022-06-21 19:23:56.665846
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-21 19:24:00.133114
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Right(None)



# Generated at 2022-06-21 19:24:04.069121
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:24:06.626821
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-21 19:24:11.093253
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x: int) -> int:
        return x + 1

    m1 = Maybe.just(add)
    m2 = Maybe.just(1)
    assert m1.ap(m2) == Maybe.just(2)


# Generated at 2022-06-21 19:24:16.779494
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test method bind of class Maybe.

    :returns: True if test was successfull otherwise exception
    :rtype: Boolean
    :raises: AssertionError if test was not successfull
    """
    assert Maybe(2, False).bind(lambda x: Maybe(x * 2, False)) == Maybe(4, False)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 2, False)) == Maybe(None, True)
    return True


# Generated at 2022-06-21 19:24:22.866433
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != "Hello"


# Generated at 2022-06-21 19:24:38.736870
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter((lambda x: x > 1)) == Maybe.just(2)
    assert Maybe.just(1).filter((lambda x: x > 1)) == Maybe.nothing()
    assert Maybe.nothing().filter((lambda x: x > 1)) == Maybe.nothing()
    assert Maybe.just(2).filter((lambda x: x < 1)) == Maybe.nothing()



# Generated at 2022-06-21 19:24:42.859878
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():

    def eq(a, b): return (isinstance(a, Maybe) and isinstance(b, Maybe) and a.value == b.value and a.is_nothing == b.is_nothing) or (a == b)

    assert_that(Maybe.just(1).to_box(), equal_to(Box(1)))
    assert_that(Maybe.nothing().to_box(), equal_to(Box.empty()))


# Generated at 2022-06-21 19:24:44.379222
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:24:56.406656
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pytest
    from pymonet.validation import Validation
    from pymonet.validation import Invalid as VInvalid

    assert Maybe.just(11).to_validation() == Validation.success(11)
    assert Maybe.just(None).to_validation() == Validation.success(None)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.nothing().to_validation().is_success()
    assert not Maybe.nothing().to_validation().is_fail()
    assert Maybe.nothing().to_validation().is_validation()
    assert Maybe.just('test').to_validation().is_success()
    assert not Maybe.just('test').to_validation().is_fail()
    assert Maybe.just('test').to_validation().is_validation

# Generated at 2022-06-21 19:25:00.943276
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-21 19:25:03.625211
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:25:07.014580
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just("one") == Maybe.just("one")
    assert Maybe.just("one") != Maybe.nothing()
    assert Maybe.just("one") != Maybe.just("two")


# Generated at 2022-06-21 19:25:12.147465
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(3) == 5
    assert Maybe.nothing().get_or_else(3) == 3
    assert Maybe.nothing().get_or_else(None) is None
    assert Maybe.just(5).get_or_else(None) == 5


# Generated at 2022-06-21 19:25:14.901806
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    from pymonet.either import Right, Left

    assert Maybe(10, False).to_either() == Right(10)

    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-21 19:25:18.405187
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(324).to_validation() == Validation.success(324)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:25:46.871523
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(value: int) -> Maybe[bool]:
        if value == 1:
            return Maybe.just(True)
        return Maybe.nothing()
    assert Maybe.just(1).bind(mapper) == Maybe.just(True)
    assert Maybe.just(0).bind(mapper) == Maybe.nothing()
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()


# Generated at 2022-06-21 19:25:50.221838
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-21 19:25:55.012191
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x) == Maybe.just(1)
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)



# Generated at 2022-06-21 19:26:02.025000
# Unit test for method __eq__ of class Maybe

# Generated at 2022-06-21 19:26:04.948192
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(0, False).to_validation() == Validation.success(0)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:26:12.358091
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: True).get_or_else(None) == 1
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-21 19:26:16.440564
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-21 19:26:19.444141
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:26:22.293284
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe.to_box() method
    """
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-21 19:26:26.021710
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(True, False) == Maybe(True, False)
    assert Maybe(True, True) == Maybe(True, True)


# Generated at 2022-06-21 19:27:14.467384
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('data').to_validation() == Validation.success('data')
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:27:18.143872
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(2, False).ap(Maybe.just(lambda x: x * 2)) == Maybe(4, False)
    assert Maybe(2, True).ap(Maybe.just(lambda x: x * 2)) == Maybe.nothing()
    assert Maybe.just(2).ap(Maybe(lambda x: x * 2, False)) == Maybe(4, False)
    assert Maybe.just(2).ap(Maybe(lambda x: x * 2, True)) == Maybe.nothing()


# Generated at 2022-06-21 19:27:22.251335
# Unit test for method map of class Maybe
def test_Maybe_map():
    empty_value = Maybe.nothing()
    assert empty_value.map(lambda x: x) == empty_value

    positive_num = lambda x: x > 0
    negative_num = lambda x: x < 0
    zero_num = lambda x: x == 0
    double_num = lambda x: x * 2
    plus_100 = lambda x: x + 100
    div_by_2 = lambda x: x / 2

    assert Maybe.just(5).map(double_num) == Maybe.just(10)
    assert Maybe.just(5).map(plus_100) == Maybe.just(105)
    assert Maybe.just(5).map(positive_num) == Maybe.just(True)
    assert Maybe.just(5).map(negative_num) == Maybe.just(False)
    assert Maybe.just(5).map

# Generated at 2022-06-21 19:27:26.795485
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    m = Maybe.just(1)
    assert (m.to_validation() == Validation.success(1))
    m = Maybe.nothing()
    assert (m.to_validation() == Validation.success(None))



# Generated at 2022-06-21 19:27:34.802798
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Invalid
    assert Maybe.just(1).to_validation().value == 1
    assert Maybe.nothing().to_validation().value == None
    assert isinstance(Maybe.nothing().to_validation(), Invalid) == False
    from pymonet.validation import Validation
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert isinstance(Maybe.nothing().to_validation(), Invalid) == False
    assert Maybe.just(1).to_validation().to_maybe().value == 1
    assert Maybe.nothing().to_validation().to_maybe().is_nothing == True


# Generated at 2022-06-21 19:27:36.458961
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda value: value + 2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda value: value + 2) == Maybe.nothing()



# Generated at 2022-06-21 19:27:43.970336
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(Box(1)).to_either() == Right(1)
    assert Maybe.just(Try(1, True)).to_either() == Right(1)
    assert Maybe.just(Try(1, False)).to_either() == Left(1)


# Generated at 2022-06-21 19:27:49.729210
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, Success, Failure

    maybe = Maybe.just(1)
    assert maybe.to_validation() == Validation.success(1)

    maybe = Maybe.nothing()
    assert maybe.to_validation() == Validation.success(None)



# Generated at 2022-06-21 19:27:53.984412
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x * x) == Maybe.just(25)
    assert Maybe.just(5).map(lambda x: x / 0) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x / 0) == Maybe.nothing()



# Generated at 2022-06-21 19:27:57.307019
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else('Error') == 42
    assert Maybe.nothing().get_or_else('Error') == 'Error'

# Generated at 2022-06-21 19:29:38.339441
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).value == 1
    assert Maybe.just("1").value == "1"
    assert Maybe.nothing().is_nothing

# Generated at 2022-06-21 19:29:42.207432
# Unit test for constructor of class Maybe
def test_Maybe():
    print('Testing Maybe constructor')

    maybe = Maybe(1, False)
    assert maybe == Maybe.just(1)
    assert maybe.value == 1

    maybe = Maybe.nothing()
    assert maybe == Maybe.nothing()
    assert maybe.is_nothing is True


# Generated at 2022-06-21 19:29:45.634217
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x.upper()).ap(Maybe.just('test')) == \
        Maybe.just('TEST')
    assert Maybe.nothing().ap(Maybe.just('test')) == Maybe.nothing()
    assert Maybe.just(lambda x: x.upper()).ap(Maybe.nothing()) == \
        Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-21 19:29:48.377045
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-21 19:29:56.552332
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Maybe(42, False).bind(lambda a: Maybe.just(a + 2)) == Maybe.just(44)
    assert Maybe(42, True).bind(lambda a: Maybe.just(a + 2)) == Maybe.nothing()
    assert Maybe(42, False).bind(
        lambda a: Maybe.just(a + 2) if a % 2 == 0 else Maybe.nothing()) == Maybe.just(44)
    assert Maybe(42, False).bind(
        lambda a: Maybe.just(a + 2) if a % 2 == 1 else Maybe.nothing()) == Maybe.nothing()

    assert Maybe(42, False).bind(lambda a: Right[str](str(a))) == Right('42')

# Generated at 2022-06-21 19:29:59.710348
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(12, False) == Maybe(12, False)
    assert Maybe(None, True) == Maybe(None, True)


# Generated at 2022-06-21 19:30:03.373216
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-21 19:30:07.279612
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as Lazy

    assert Lazy.Lazy(lambda: 'something') == Maybe.just('something').to_lazy()
    assert Lazy.Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-21 19:30:11.805863
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-21 19:30:17.302882
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    res1 = Maybe.just(lambda x: x + 10).ap(Maybe.just(5))
    res2 = Maybe.just(lambda x: x + 10).ap(Maybe.nothing())

    assert res1 == Maybe.just(15)
    assert res2 == Maybe.nothing()