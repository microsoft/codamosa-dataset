

# Generated at 2022-06-25 23:53:08.635065
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'NQvGJkC#8=H+u$D`'
    maybe_0 = Maybe.just(str_0)
    maybe_1 = maybe_0
    bool_0 = maybe_0 == maybe_1
    str_1 = '>|4D4t|s@R1'
    maybe_2 = Maybe.just(str_1)
    bool_1 = maybe_0 == maybe_2
    bool_2 = not maybe_0 == maybe_2


# Generated at 2022-06-25 23:53:16.126696
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(lambda b: maybe_0)
    assert maybe_1.is_nothing
    maybe_0 = Maybe.just('yE_|>*hk')
    maybe_1 = maybe_0.filter(lambda e: maybe_0)
    assert not maybe_1.is_nothing
    assert maybe_1 == Maybe.just('yE_|>*hk')
    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(lambda b: maybe_1)
    assert maybe_0.is_nothing
    assert maybe_1.is_nothing
    maybe_0 = Maybe.just('d|`')
    maybe_1 = maybe_0.filter(lambda b: maybe_0)
    assert not maybe_1.is_

# Generated at 2022-06-25 23:53:28.218836
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Create a Maybe object
    maybe_0 = Maybe.just(False)
    maybe_1 = Maybe(False, True)
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe(False, True)
    maybe_4 = Maybe(False, False)
    maybe_5 = Maybe(False, True)
    maybe_6 = Maybe(False, True)
    maybe_7 = Maybe.just(False)

    # Assert that the Maybe object equals to itself
    assert maybe_0 == maybe_0
    assert not maybe_1 == maybe_1
    assert not maybe_2 == maybe_2
    assert maybe_3 == maybe_3
    assert maybe_4 == maybe_4
    assert maybe_5 == maybe_5
    assert maybe_6 == maybe_6
    assert maybe_7 == maybe_7

    # Assert

# Generated at 2022-06-25 23:53:31.947037
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '<MSqu=Z8d:<g'
    int_0 = -12
    maybe_0 = Maybe.just(int_0)
    def func_0(arg_0):
        return bool_0
    bool_0 = False
    maybe_1 = maybe_0.filter(func_0)



# Generated at 2022-06-25 23:53:35.269586
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # simple_print(maybe_0.__eq__(maybe_0))
    maybe_0 = Maybe.just('D8L!$H').filter(lambda var_0: var_0.upper())
    assert maybe_0.__eq__(Maybe.just('D8L!$H'))



# Generated at 2022-06-25 23:53:43.997356
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test case for __eq__ method of Maybe.
    """
    maybe_0 = Maybe(False, True)
    maybe_1 = Maybe(True, False)
    assert maybe_0.__eq__(maybe_1) == False

    maybe_0 = Maybe(True, True)
    assert maybe_0.__eq__(maybe_0) == True

    maybe_0 = Maybe(False, False)
    maybe_1 = Maybe(False, False)
    assert maybe_0.__eq__(maybe_1) == True



# Generated at 2022-06-25 23:53:50.992425
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'D*U_dhg:Jl!0@F=R'
    int_0 = -9
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    maybe_1 = Maybe(int_0, bool_0)
    assert maybe_0 == maybe_1
    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.nothing()
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:53:57.525380
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 's8/&'
    list_0 = [1, 2, 3]
    maybe_0 = Maybe.just(list_0)
    var_0 = maybe_0.filter(lambda x: x)
assert var_0.value == list_0

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 23:53:59.934271
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe(Maybe.just(42), False)
    result = maybe_1 == Maybe.just(42)
    assert result == True


# Generated at 2022-06-25 23:54:12.295475
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'cxB`'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    maybe_0 = Maybe(maybe_0.bind(dict_0), bool_0)
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    maybe_1 = Maybe(maybe_0.bind(dict_0), bool_0)
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0}
    bool_0 = False
    maybe_2 = Maybe(maybe_0.bind(dict_0), bool_0)
    maybe_2 = maybe_

# Generated at 2022-06-25 23:54:20.573602
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 0

    maybe_0 = Maybe(int_0, False)
    maybe_1 = Maybe(int_0, True)

    maybe_0_lazy = maybe_0.to_lazy()
    assert maybe_0_lazy.get_value() == 0

    maybe_1_lazy = maybe_1.to_lazy()
    assert maybe_1_lazy.get_value() == None


# Generated at 2022-06-25 23:54:34.073109
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 42
    bool_0 = False
    bool_1 = bool_0
    bool_0 = bool_1
    int_1 = 0
    bool_0 = bool_0

    m_maybe = Maybe.just(int_0)
    bool_0 = bool_0
    bool_2 = bool_0
    bool_0 = (m_maybe == Maybe.just(int_0)) and bool_0
    bool_0 = (m_maybe.filter(lambda data: data == int_0) == Maybe.just(int_0)) and bool_0
    bool_0 = (m_maybe.filter(lambda data: data != int_0) == Maybe.nothing()) and bool_0
    assert bool_0

# Generated at 2022-06-25 23:54:40.515655
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def func_0():
        return int_0

    int_0 = 42

    maybe_0 = Maybe.just(int_0).to_lazy() # maybe_0 : Lazy = Lazy(func_0)
    lazy_0 = maybe_0.value
    int_1 = lazy_0()
    assert int_0 == int_1



# Generated at 2022-06-25 23:54:47.590538
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 42
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    test_val_0 = lazy_0.get()
    test_val_1 = lazy_1.get()
    assert test_val_0 == int_0
    assert test_val_1 is None


# Generated at 2022-06-25 23:54:52.542061
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_none = Maybe.nothing()
    maybe_0 = Maybe.just(False)

    maybe_result = maybe_0.filter(bool)

    assert(maybe_0.value == maybe_result.value)
    assert(type(maybe_result) is Maybe)
    assert(maybe_result.is_nothing == False)

    maybe_result = maybe_none.filter(bool)

    assert(type(maybe_result) is Maybe)
    assert(maybe_result.is_nothing == True)


# Generated at 2022-06-25 23:54:57.842309
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(42, False).filter(lambda _: True).is_nothing == False
    assert Maybe(42, False).filter(lambda x: x > 41).is_nothing == False
    assert Maybe(42, False).filter(lambda x: x > 42).is_nothing == True
    assert Maybe(42, True).filter(lambda _: True).is_nothing == True



# Generated at 2022-06-25 23:55:10.709585
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = 42
    bool_1 = False
    maybe_0 = Maybe.just(int_1)
    maybe_1 = Maybe.just(bool_1)
    maybe_2 = Maybe.just(int_1)
    maybe_3 = Maybe.just(bool_1)
    maybe_4 = Maybe.nothing()
    maybe_4 = maybe_4.filter(lambda x:bool(x))
    maybe_5 = Maybe.nothing()
    maybe_5 = maybe_5.filter(lambda x:bool(x))
    try:
        assert maybe_0 == maybe_2
        assert maybe_1 == maybe_3
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-25 23:55:21.383951
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Maybe.just(100)
    ret_0 = Maybe.just(100).filter(lambda value: value > 0)
    assert isinstance(ret_0, Maybe) and ret_0.value == 100

    # Maybe.just(100)
    ret_1 = Maybe.just(100).filter(lambda value: value < 0)
    assert isinstance(ret_1, Maybe) and ret_1.is_nothing

    # Maybe.just(100)
    ret_2 = Maybe.just(100).filter(lambda value: value == 100)
    assert isinstance(ret_2, Maybe) and ret_2.value == 100

    # Maybe.nothing()
    ret_3 = Maybe.nothing().filter(lambda value: value == 100)
    assert isinstance(ret_3, Maybe) and ret_3.is_nothing

# Unit

# Generated at 2022-06-25 23:55:33.631607
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 42
    bool_1 = False
    maybe_0 = Maybe.just(int_0)
    bool_2 = maybe_0.is_nothing
    assert bool_2 == bool_1
    int_1 = maybe_0.value
    assert int_1 == int_0
    bool_2 = maybe_0.is_nothing
    assert bool_2 == bool_1
    bool_1 = True
    maybe_1 = Maybe.nothing()
    bool_2 = maybe_1.is_nothing
    assert bool_2 == bool_1
    bool_1 = True
    maybe_2 = maybe_0.filter(lambda x1: int_0 == x1)
    bool_2 = maybe_2.is_nothing
    assert bool_2 == bool_1



# Generated at 2022-06-25 23:55:37.969713
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 42
    bool_0 = not (int_0 == 50)
    maybe_0 = Maybe.just(int_0)
    def f(x: int) -> bool:
        return x == 50
    maybe_1 = maybe_0.filter(f)
    bool_1 = maybe_1.is_nothing
    assert (bool_1) == bool_0


# Generated at 2022-06-25 23:55:47.725186
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = test_0()
    bool_1 = test_1()
    bool_2 = test_2()
    bool_3 = test_3()
    bool_4 = test_4()
    bool_5 = test_5()
    bool_6 = test_6()

    if bool_0 and bool_1 and bool_2 and bool_3 and bool_4 and bool_5 and bool_6:
        return True
    else:
        return False


# Generated at 2022-06-25 23:55:51.622476
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda value: value) == Maybe.just(0)
    assert Maybe.just(0).filter(lambda value: not value) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: not value) == Maybe.nothing()


# Generated at 2022-06-25 23:55:58.470204
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    integer_0 = Maybe.just(10)
    integer_1 = Maybe.nothing()

    print(integer_0.to_lazy())
    print(integer_1.to_lazy())

    lazy_0 = Lazy(lambda: 10)
    lazy_1 = Lazy(lambda: None)

    assert integer_0.to_lazy() == lazy_0
    assert integer_1.to_lazy() == lazy_1


# Generated at 2022-06-25 23:56:02.807795
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x % 2 == 0) == Maybe.just(42)
    assert Maybe.just(42).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-25 23:56:06.031942
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Create Maybe with int value
    maybe_int = Maybe.just(7)

    # Create function which checks if value is less than 10
    filterer = lambda value: value < 10

    # Check if Maybe has value less than 10
    maybe_int_filtered = maybe_int.filter(filterer)

    # Check expected result
    assert maybe_int_filtered == Maybe.just(7)


# Generated at 2022-06-25 23:56:11.191685
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    maybe_0 = Maybe.just(0)
    maybe_1 = maybe_0.filter(lambda x: x > 10)
    bool_0 = maybe_1 == Maybe.nothing()
    assert bool_0
    bool_1 = maybe_0 != maybe_1
    assert bool_1


# Generated at 2022-06-25 23:56:21.681810
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test for method to_lazy of class Maybe.
    """
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(2)
    maybe_1 = Maybe.nothing()

    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()

    bool_0 = False
    bool_1 = True

    pymonet_lazy = Lazy(lambda: 2)
    pymonet_lazy_0 = Lazy(lambda: None)
    if lazy_0 != pymonet_lazy:
        bool_0 = True
    if lazy_1 != pymonet_lazy_0:
        bool_1 = False
    assert bool_0 == bool_1


# Generated at 2022-06-25 23:56:26.078712
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe

    """
    from pymonet.lazy import Lazy

    def get_value():
        return 1

    def get_nothing():
        return None

    assert Maybe.just(1).to_lazy() == Lazy(get_value)
    assert Maybe.nothing().to_lazy() == Lazy(get_nothing)



# Generated at 2022-06-25 23:56:29.990461
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe(True, False).filter(lambda value: value == True)
    assert (result.is_nothing == False)

    result = Maybe(False, False).filter(lambda value: value == True)
    assert (result.is_nothing == True)


# Generated at 2022-06-25 23:56:39.873372
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0()
    test_Maybe_filter_value_0 = True
    test_Maybe_filter_value_1 = Maybe.just(2)
    test_Maybe_filter_value_2 = Maybe.just(3)
    expected_value_2 = Maybe.just(3)
    actual_value_2 = test_Maybe_filter_value_2
    assert actual_value_2 == expected_value_2

    expected_value_3 = Maybe.nothing()
    actual_value_3 = test_Maybe_filter_value_1.filter(lambda x: x>3)
    assert actual_value_3 == expected_value_3


if __name__ == "__main__":
    test_Maybe_filter()

# Generated at 2022-06-25 23:56:45.321541
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False

    bool_0 = True



# Generated at 2022-06-25 23:56:50.866677
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(2)

    # Test 0 checklist:
    # m should contain 2
    assert m.value == 2
    # and should not be empty
    assert not m.is_nothing
    # if check value with function is_even it will return
    # new Maybe with the same value
    assert m.filter(is_even) == Maybe.just(2)
    # if check value with function is_odd it will return
    # new empty Maybe
    assert m.filter(is_odd) == Maybe.nothing()


# Generated at 2022-06-25 23:57:00.274007
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    def bool_0():
        return True
    def bool_1():
        return False
    maybe_0 = Maybe.just(bool_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    assert type(lazy_0) == Lazy
    assert lazy_0.value() is True
    lazy_1 = maybe_1.to_lazy()
    assert type(lazy_1) == Lazy
    assert lazy_1.value() is None


# Generated at 2022-06-25 23:57:02.616087
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() == None


# Generated at 2022-06-25 23:57:06.266631
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    x = lazy_0.eval()
    assert x == 1
    bool_0 = False


# Generated at 2022-06-25 23:57:11.830605
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-25 23:57:17.748523
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    case_0 = Maybe.just('a')
    case_0_return = case_0.to_lazy()
    bool_0 = case_0_return.value() == 'a'
    assert bool_0
    case_1 = Maybe.nothing()
    case_1_return = case_1.to_lazy()
    bool_0 = case_1_return.value() == None
    assert bool_0


# Generated at 2022-06-25 23:57:21.630975
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    class_attr = Maybe(1, True)
    bool_2 = bool(class_attr.is_nothing)
    bool_0 = bool(class_attr.get_or_else(None) == None)
    bool_1 = bool(class_attr.filter(bool) == Maybe.nothing())
    return bool_0 and bool_1 and bool_2


# Generated at 2022-06-25 23:57:27.998720
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Test for "from pymonet.lazy import Lazy"
    from pymonet.lazy import Lazy
    maybe_0 = Maybe.just(None)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value == maybe_0.value
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1.value == maybe_1.value


# Generated at 2022-06-25 23:57:34.833442
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    for bool_0 in [False, True]:
        for bool_1 in [False, True]:
            for bool_2 in [False, True]:
                maybe_0 = Maybe(bool_0, bool_1)

                if bool_1:
                    assert maybe_0.to_lazy().get_or_none() is None
                else:
                    assert maybe_0.to_lazy().get_or_none() is bool_0


# Generated at 2022-06-25 23:57:42.005012
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just('42').filter(lambda str: str == '42') == Maybe.just('42')
    assert Maybe.just('42').filter(lambda str: str == '43') == Maybe.nothing()
    assert Maybe.nothing().filter(lambda str: str == '42') == Maybe.nothing()



# Generated at 2022-06-25 23:57:52.396561
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    list_0 = list()
    list_1 = list()
    def input_0(x):
        return x < 2
    list_2 = list()
    def input_1(x):
        return x > 2
    list_3 = list()
    print("Test: method filter of class Maybe")
    list_0.append(Maybe.just(1).filter(input_0).get_or_else(None))
    list_0.append(Maybe.just(1).filter(input_1).get_or_else(None))
    list_0.append(Maybe.just(3).filter(input_0).get_or_else(None))
    list_0.append(Maybe.nothing().filter(input_0).get_or_else(None))

# Generated at 2022-06-25 23:58:00.293689
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_list import List

    # Case 0
    test_case_0()

    # Case 1
    maybe_0 = Maybe.nothing()
    lazy_0 = Lazy(lambda: bool_0)
    maybe_0 = maybe_0.to_lazy()
    lazy_0 = lazy_0.join()
    lazy_1 = Lazy(lambda: True)
    assert(maybe_0 == lazy_0)



# Generated at 2022-06-25 23:58:01.206673
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-25 23:58:05.140192
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Case where Maybe is empty
    bool_0 = Maybe.nothing().to_lazy().is_nothing
    # Case where Maybe is not empty
    bool_1 = Maybe.just(4).to_lazy().is_success
    # Case where Maybe is not empty
    bool_2 = Maybe.just(None).to_lazy().is_success
    assert bool_0
    assert bool_1
    assert bool_2


# Generated at 2022-06-25 23:58:12.466395
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe

    def is_even(value):
        return value % 2 == 0

    assert Maybe.just(2).filter(is_even).get_or_else(None) == 2
    assert Maybe.just(3).filter(is_even).get_or_else(None) == None
    assert Maybe.nothing().filter(is_even).get_or_else(None) == None


# Generated at 2022-06-25 23:58:16.855829
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_none = Maybe.nothing()
    test_0 = maybe_none == maybe_none.filter(lambda x: x > 5)
    test_1 = Maybe.just(7) == maybe_none.filter(lambda x: x > 5)

    return test_0 and test_1


# Generated at 2022-06-25 23:58:26.151844
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Positive test cases (examples) with expected results
    assert (Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)) == True # Maybe[1].filter(lambda x: x == 1) == Maybe[1]
    assert (Maybe.just(2).filter(lambda x: x != 3) == Maybe.just(2)) == True # Maybe[2].filter(lambda x: x != 3) == Maybe[2]
    assert (Maybe.nothing().filter(lambda _: False) == Maybe.nothing()) == True # Maybe[None].filter(lambda _: False) == Maybe[None]
    assert (Maybe.nothing().filter(lambda _: True) == Maybe.nothing()) == True # Maybe[None].filter(lambda _: True) == Maybe[None]

    # Negative test cases (counterexamples) with unexpected inputs

# Generated at 2022-06-25 23:58:30.568305
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(True).to_lazy() == Lazy(lambda: True)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:58:32.868497
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).to_lazy().eval() == 10
    assert Maybe.nothing().to_lazy().eval() is None


# Generated at 2022-06-25 23:58:41.157486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Test Case 0
    expected_0 = Lazy(lambda: 1)
    maybe_0 = Maybe.just(1)
    result_0 = maybe_0.to_lazy()
    assert result_0 == expected_0

    # Test Case 1
    expected_1 = Lazy(lambda: False)
    maybe_1 = Maybe.nothing()
    result_1 = maybe_1.to_lazy()
    assert result_1 == expected_1


# Generated at 2022-06-25 23:58:47.554905
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad import unit
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe(None, False).to_lazy() == Lazy(lambda: None)
    assert Maybe(unit(1), True).to_lazy() == Lazy(lambda: 1)
    assert Maybe(Try(40, True), True).to_lazy() == Lazy(lambda: 40)
    assert Maybe(Box(False), True).to_lazy() == Lazy(lambda: False)


# Generated at 2022-06-25 23:58:59.401994
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad import Monad
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Create not empty Maybe
    money = Maybe(22.0, False)
    if not isinstance(money, Maybe):
        return False

    test_value = money.filter(lambda x: x > 10.0)
    if not isinstance(test_value, Maybe):
        return False
    if not test_value.is_nothing:
        return False

    test_value = money.filter(lambda x: x == 22.0)

# Generated at 2022-06-25 23:59:01.682513
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    if isinstance(test_case_0(), Maybe):
        try:
            test_case_0().to_lazy()
        except Exception:
            return False

    return True

# Generated at 2022-06-25 23:59:09.106071
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(Maybe.just(1))
    maybe_1 = Maybe.just(Maybe.nothing())
    maybe_2 = Maybe.nothing()

    ret = maybe_0.filter(lambda x: isinstance(x, Maybe))
    assert ret == Maybe.just(Maybe.just(1))

    ret = maybe_1.filter(lambda x: isinstance(x, Maybe))
    assert ret == Maybe.just(Maybe.nothing())

    ret = maybe_2.filter(lambda x: isinstance(x, Maybe))
    assert ret == Maybe.nothing()



# Generated at 2022-06-25 23:59:11.566474
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    print("test_Maybe_filter")
    maybe_0 = Maybe(1, False)
    value = maybe_0.filter(lambda x: x == 1)
    assert value == Maybe.just(1)
    value = maybe_0.filter(lambda x: x == 2)
    assert value == Maybe.nothing()


# Generated at 2022-06-25 23:59:15.177976
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m_0 = Maybe.just(10)
    result_0 = m_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.run() == 10

    m_1 = Maybe.nothing()
    result_1 = m_1.to_lazy()
    assert result_1.run() is None
    assert type(result_1.run()) is None


# Generated at 2022-06-25 23:59:19.335125
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 5).get_or_else(-1) == 10
    assert Maybe.just(10).filter(lambda x: x < 5).get_or_else(-1) == -1
    assert Maybe.nothing().filter(lambda x: x > 5).get_or_else(-1) == -1


# Generated at 2022-06-25 23:59:20.144254
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_Maybe_filter_0()


# Generated at 2022-06-25 23:59:24.127085
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Test for case when Maybe is empty
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    test_value = "test value"
    assert Maybe.just(test_value).to_lazy() == Lazy(lambda: test_value)


# Generated at 2022-06-25 23:59:34.287743
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.function import identity

    maybe_0 = Maybe.just(1)

    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert callable(lazy_0.f)
    lazy_0.f = identity
    assert lazy_0.f() == 1

    maybe_1 = Maybe.nothing()

    assert maybe_1.to_lazy().f() is None


# Generated at 2022-06-25 23:59:37.201925
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # It must return a Lazy monad with value 0
    assert Maybe.just(0).to_lazy() == Lazy(lambda: 0)

    # It must return a Lazy monad with function that return 0
    assert Maybe.just(lambda: 0).to_lazy() == Lazy(lambda: lambda: 0)

    # It must return a Lazy monad with None
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:59:39.629944
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 2) != Maybe.just(1)



# Generated at 2022-06-25 23:59:47.993834
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # if Maybe is empty
    assert Maybe.just(10).filter(lambda value: value == 10) == Maybe.just(10)
    assert Maybe.nothing().filter(lambda value: value == 10) == Maybe.nothing()

    # if Maybe isn't empty and filterer returns True
    assert Maybe.just(1).filter(lambda value: value == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda value: value > 0) == Maybe.just(2)

    # if Maybe isn't empty and filterer returns False
    assert Maybe.just(1).filter(lambda value: value == 2) == Maybe.just(None)
    assert Maybe.just(2).filter(lambda value: value > 10) == Maybe.just(None)


# Generated at 2022-06-25 23:59:52.005846
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m_0 = Maybe.just(1)
    m_1 = m_0.filter(lambda x: x % 2 == 0)
    
    assert m_1 == Maybe.nothing()

    m_0 = Maybe.just(2)
    m_1 = m_0.filter(lambda x: x % 2 == 0)

    assert m_1 == Maybe.just(2)


# Generated at 2022-06-26 00:00:00.671269
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_case_1():
        int_1 = 1
        maybe_0: Maybe[int] = Maybe.just(int_1)
        lazy_0 = maybe_0.to_lazy()

    def test_case_2():
        string_0 = "2"
        maybe_0: Maybe[str] = Maybe.just(string_0)
        lazy_0 = maybe_0.to_lazy()

    def test_case_3():
        string_0 = "3"
        maybe_0: Maybe[str] = Maybe.just(string_0)
        lazy_0 = maybe_0.to_lazy()

    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 00:00:07.548275
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(2)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    env_0 = lazy_0.get_value()
    assert env_0() == 2
    lazy_1 = maybe_1.to_lazy()
    env_1 = lazy_1.get_value()
    assert env_1() == None


# Generated at 2022-06-26 00:00:15.571885
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    for _ in range(10000):
        m = Maybe.just(random.randint(-1000, 1000))
        if m.filter(lambda x: x > 0).get_or_else(None) != m.value:
            test_case_0()
        if m.filter(lambda x: x > m.value).get_or_else(None) is not None:
            test_case_0()
        if Maybe.nothing().filter(lambda x: x == 0).get_or_else('x') != 'x':
            test_case_0()


if __name__ == '__main__':
    test_Maybe_filter()
    print("All tests passed")

# Generated at 2022-06-26 00:00:26.393966
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test True case
    maybe_0 = Maybe.just(1)
    maybe_0 = maybe_0.filter(lambda x: x == 1)
    assert maybe_0 == Maybe.just(1)

    # Test False case
    maybe_1 = Maybe.just(1)
    maybe_1 = maybe_1.filter(lambda x: x == 0)
    assert maybe_1 == Maybe.nothing()

    # Test default case
    maybe_2 = Maybe.nothing()
    maybe_2 = maybe_2.filter(lambda x: x == 0)
    assert maybe_2 == Maybe.nothing()


# Generated at 2022-06-26 00:00:32.006755
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    fake_Maybe = Maybe(None, True)

    class fake_Lazy(object):
        def __init__(self, func: Callable):
            self.func = func

    fake_Lazy_instance = fake_Lazy(lambda: None)

    fake_Maybe.to_lazy = lambda: fake_Lazy_instance
    actual = fake_Maybe.to_lazy()
    expected = fake_Lazy_instance
    # assert actual == expected



# Generated at 2022-06-26 00:00:44.467068
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    not_empty_maybe = Maybe.just(True)
    assert not_empty_maybe.to_lazy() == Lazy(lambda: test_case_0())

    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:00:53.521509
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    global bool_0
    bool_1 = False
    bool_2 = False
    bool_3 = False

    def function_0(value: int):
        global bool_1
        bool_1 = value == 0
        return True
    def function_1(value: int):
        global bool_2
        global bool_3
        bool_2 = value == 1
        bool_3 = True
        return True
    maybe_0 = Maybe.just(0)
    maybe_1 = maybe_0.filter(function_0)
    maybe_2 = maybe_0.filter(function_1)
    maybe_3 = Maybe.nothing().filter(function_1)

    assert maybe_0 == Maybe.just(0)
    assert maybe_1 == Maybe.just(0)
    assert maybe_2 == Maybe.nothing()

# Generated at 2022-06-26 00:00:56.631111
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box

    assert Maybe.just(Box(5)).to_lazy() == Box(5).to_lazy()
    assert Maybe.nothing().to_lazy() == Box(None).to_lazy()


# Generated at 2022-06-26 00:00:59.903130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing())


# Generated at 2022-06-26 00:01:02.340657
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create Lazy with given function
    maybe = Maybe.just(lambda x: x + 1)
    lazy = maybe.to_lazy()

    assert maybe == lazy.value().value()

# Generated at 2022-06-26 00:01:13.148482
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a_0 = Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))
    assert a_1 == Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))
    assert a_1 == Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))
    assert a_1 == Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))
    assert a_1 == Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))
    assert a_1 == Maybe.just(1)
    a_1 = a_0.filter(lambda x: bool(x))

# Generated at 2022-06-26 00:01:16.749661
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(3)
    m_filt = m.filter(lambda x: x % 2 == 0)
    print(m_filt)
    assert m_filt == Maybe.nothing()

    m = Maybe.just(4)
    m_filt = m.filter(lambda x: x % 2 == 0)
    assert m_filt == Maybe.just(4)



# Generated at 2022-06-26 00:01:19.761193
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just("test").to_lazy()
    assert lazy.get() == "test"
    assert Maybe.nothing().to_lazy().get() is None


# Generated at 2022-06-26 00:01:25.265921
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_object = Maybe(True, False)
    result = test_object.filter(lambda x: x)
    assert result == Maybe.just(True)

    test_object = Maybe(True, False)
    result = test_object.filter(lambda x: not x)
    assert result == Maybe.nothing()

    test_object = Maybe(True, False)
    result = test_object.filter(None)
    assert result == Maybe.nothing()
    

# Generated at 2022-06-26 00:01:31.807951
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try_0 = Try(False, is_success=False)
    lazy_0 = try_0.to_lazy()
    box_0 = Box(lazy_0)
    box_1 = box_0.map(lambda x: x.flatmap(lambda y: y))
    bool_0 = box_1.unbox() == Try(False, is_success=False)
    bool_1 = bool_0

    test_case_0()
    assert bool_1

# Generated at 2022-06-26 00:01:44.263895
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy

    def function_lazy_0(x):
        return x / 10

    def function_lazy_1(x):
        return x / 10

    def function_lazy_2(x):
        return x + 1

    def function_lazy_2_1(x):
        return x + 1

    def function_lazy_3(x):
        return x

    def function_lazy_3_1(x):
        return x

    lazy_0 = function_lazy_3_1(Maybe.just(123).to_lazy().value().bind(function_lazy_0).bind(function_lazy_2).bind(function_lazy_3).value())

# Generated at 2022-06-26 00:01:52.980570
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.evaluate() == bool_0
    bool_0 = True
    maybe_0 = Maybe.just(bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.evaluate() == bool_0
    maybe_0 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.evaluate() == None


# Generated at 2022-06-26 00:01:58.974316
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monoid import Just, List, Monoid, None_

    # Test case 0
    # |-
    maybe_0 = Just([1, 2, 3])
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy(lambda: [1, 2, 3])

    # Test case 1
    # |-
    maybe_1 = None_()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1 == Lazy(lambda: None)


# Generated at 2022-06-26 00:02:06.084936
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def bool_0():
        return True
    def bool_1():
        return False
    def bool_2():
        return False
    bool_3 = Maybe.just(bool_0)
    bool_2 = Maybe.just(bool_1)
    bool_1 = bool_3.to_lazy()
    bool_0 = bool_2.to_lazy()
    assert bool_1.eval() == True
    assert bool_0.eval() == False


# Generated at 2022-06-26 00:02:08.748766
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:02:12.840778
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    if lazy_0.f():
        print(lazy_0.get_or_raise())
    try:
        lazy_0 = Maybe.nothing().to_lazy()
        lazy_0.get_or_raise()
    except:
        test_case_0()


# Generated at 2022-06-26 00:02:21.098131
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import lazy
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Test case 0
    m = Maybe.just(1)
    test_case_0 = m.to_lazy() == Lazy(lambda: 1)

    # Test case 1
    test_case_1 = m.to_lazy().value() == 1

    # Test case 2
    test_case_2 = m.to_lazy().map(lambda x: x + 1).value() == 2

    # Test case 3
    test_case_3 = m.to_lazy().flat_map(lambda x: Lazy(lambda: x * 2)).value() == 2

    # Test case 4
    test_case_4

# Generated at 2022-06-26 00:02:24.984259
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    l_0 = Lazy(lambda: "Monad")
    m_0 = Maybe.just("Monad")
    l_1 = m_0.to_lazy()
    b_0 = (l_0 == l_1)
    return b_0


# Generated at 2022-06-26 00:02:31.905075
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just('A')
    maybe_1 = Maybe.nothing()
    bool_0 = maybe_0.is_nothing
    lazy_0 = maybe_0.to_lazy()
    bool_1 = lazy_0.is_lazy
    bool_2 = lazy_0.is_strict
    bool_3 = lazy_1.is_lazy
    bool_4 = lazy_1.is_strict
    bool_5 = bool_1
    lazy_1 = maybe_1.to_lazy()
    bool_6 = bool_3

if __name__ == '__main__':
    test_Maybe_to_lazy()

# Generated at 2022-06-26 00:02:38.357269
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create Maybe instance with value 123
    maybe_0: Maybe[int] = Maybe.just(123)
    # Get function from Maybe using lazy to_lazy
    maybe_0_to_lazy: Lazy[Callable[[], int]] = maybe_0.to_lazy()
    # Apply function to get value of Maybe
    maybe_0_val_0: int = maybe_0_to_lazy.get_value()
    # Create Maybe instance with value '123'
    maybe_1: Maybe[str] = Maybe.just('123')
    # Get function from Maybe using to_lazy
    maybe_1_to_lazy: Lazy[Callable[[], str]] = maybe_1.to_lazy()
    # Apply function to get value of Maybe
    maybe_1_val_0: str = maybe_1_

# Generated at 2022-06-26 00:02:51.501560
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # CASE 0:
    # Initialized with value
    maybe_0 = Maybe("test", False)
    lazy_0 = maybe_0.to_lazy()
    bool_0 = lazy_0.unbox()() == "test"
    if not bool_0:
        raise Exception("Test case 0 failed. Lazy not initialized with expected value.")

    # CASE 1:
    # Initialized with None
    maybe_0 = Maybe(None, True)
    lazy_0 = maybe_0.to_lazy()
    bool_0 = lazy_0.unbox()() is None
    if not bool_0:
        raise Exception("Test case 0 failed. Lazy not initialized with expected value.")

if __name__ == "__main__":
    test_case_0()
    test_Maybe_to_lazy()

# Generated at 2022-06-26 00:02:55.608216
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test method to_lazy of class Maybe.
    """
    bool_0 = False
    maybe_0 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    v_0 = lazy_0.value()
    if (v_0 == 1):
        bool_0 = True
    assert bool_0


# Generated at 2022-06-26 00:03:03.032779
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    val_0 = Maybe.just(2)
    val_1 = Maybe.just('a')
    val_2 = Maybe.just(test_case_0)
    val_3 = Maybe.just(2.5)
    val_4 = Maybe.nothing()
    val_5 = Maybe.just('b')
    val_6 = Maybe.just(test_case_0)
    val_7 = Maybe.nothing()
    val_8 = Maybe.just(2.5)
    val_9 = Maybe.just('c')
    val_10 = Maybe.just(test_case_0)
    val_11 = Maybe.nothing()
    val_12 = Maybe.just(2.5)
    val_13 = Maybe.just('d')
    val_14 = Maybe.just(test_case_0)
    val_