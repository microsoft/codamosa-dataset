

# Generated at 2022-06-25 23:53:10.287510
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = {}
    t0 = Maybe.just(value)
    t1 = Maybe.just(value)
    t0 == t1
    value = 1
    t0 = Maybe.just(value)
    t1 = Maybe.just(value)
    t0 == t1
    value = {}
    t0 = Maybe.just(value)
    t1 = Maybe.just(value)
    t0 == t1
    value = 1
    t0 = Maybe.just(value)
    t1 = Maybe.just(value)
    t0 == t1
    t0 = Maybe.nothing()
    t1 = Maybe.nothing()
    t0 == t1


# Generated at 2022-06-25 23:53:14.571733
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = True
    string_0 = "a"
    maybe_0 = Maybe.just(string_0)
    maybe_1 = maybe_0.filter(lambda x: not bool_0)
    assert maybe_1 == Maybe.nothing()

    maybe_2 = maybe_0.filter(lambda x: bool_0)
    assert maybe_2 == maybe_0



# Generated at 2022-06-25 23:53:26.850080
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test for method to_lazy of class Maybe.
    """
    from pymonet.lazy import Lazy

    dict_0 = {}
    dict_1 = {"Test": "String"}
    bool_0 = True
    bool_1 = False
    from pymonet.monad import monad_compose
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(dict_1, bool_1)
    maybe_2 = Maybe(dict_0, bool_1)
    maybe_3 = Maybe(dict_1, bool_0)

    assert (maybe_0.to_lazy() == Lazy(lambda: dict_0)), "Failed: test_Maybe_to_lazy"

# Generated at 2022-06-25 23:53:30.958529
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(int(1)) == Maybe.just(int(1))
    assert Maybe.just(int(1)) != Maybe.just(None)
    assert Maybe.just(int(1)) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(int(1))
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-25 23:53:34.641264
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Initialize argument 'arg_value'
    arg_value = None

    # Initialize argument 'arg_filterer'
    arg_filterer = None

    # Invoke method
    ret_value = Maybe.filter(arg_value, arg_filterer)

    # Check return value
    assert ret_value is None


# Generated at 2022-06-25 23:53:38.548033
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = maybe_0
    bool_1 = (maybe_0 == maybe_1)
    return bool_1


# Generated at 2022-06-25 23:53:49.991912
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    dict_1 = dict_0
    bool_1 = bool_0
    maybe_1 = Maybe(dict_1, bool_1)
    assert maybe_0 == maybe_1
    dict_2 = {}
    bool_2 = False
    maybe_2 = Maybe(dict_2, bool_2)
    dict_3 = dict_2
    bool_3 = bool_2
    maybe_3 = Maybe(dict_3, bool_3)
    assert not maybe_2 == maybe_3
    dict_4 = {}
    bool_4 = True
    maybe_4 = Maybe(dict_4, bool_4)
    dict_5 = dict_4
    bool_5 = bool_4
    maybe

# Generated at 2022-06-25 23:54:00.178658
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(dict_0, bool_0)
    bool_0 = maybe_0.__eq__(maybe_1)
    assert bool_0
    bool_0 = maybe_0.__eq__(maybe_0)
    assert bool_0
    bool_0 = maybe_0.__eq__(dict_0)
    assert not bool_0
    bool_0 = maybe_0.__eq__(maybe_1)
    assert bool_0


# Generated at 2022-06-25 23:54:04.733212
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # default test method
    dict_0 = {}
    maybe_0 = Maybe.just(dict_0)
    dict_1 = {}
    maybe_1 = Maybe.just(dict_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:54:09.533459
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def method_0():
        dict_0 = {}
        bool_0 = True
        maybe_0 = Maybe(dict_0, bool_0)
        maybe_1 = maybe_0.to_lazy()

    method_0()


# Generated at 2022-06-25 23:54:22.742469
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Testing Maybe.filter')

    # Creating Maybe

    var_0 = Maybe.just(5)

    # Testing Maybe

    if var_0.filter(lambda x: x > 1).get_or_else(0) == 5:
        print('Test Maybe.filter 0 success')
    else:
        print('Test Maybe.filter 0 failed')

    var_1 = Maybe.just(5)

    if var_1.filter(lambda x: x < 1).get_or_else(0) == 0:
        print('Test Maybe.filter 1 success')
    else:
        print('Test Maybe.filter 1 failed')

    var_2 = Maybe.nothing()

    if var_2.filter(lambda x: x is True).get_or_else(0) == 0:
        print('Test Maybe.filter 2 success')

# Generated at 2022-06-25 23:54:35.999716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Define test input.
    maybe_0 = Maybe.just(1)
    maybe_1 = Maybe.just(1)

    # Define correct output.
    result_0 = maybe_0.to_lazy()
    expected_0 = lambda: 1
    result_1 = maybe_1.to_lazy()
    expected_1 = lambda: 1

    if not result_0.value() == expected_0():
        raise Exception(
            f'{maybe_0.to_lazy()} should be {expected_0()} but is {result_0.value()}')

    if not result_1.value() == expected_1():
        raise Exception(
            f'{maybe_1.to_lazy()} should be {expected_1()} but is {result_1.value()}')

# Unit

# Generated at 2022-06-25 23:54:47.945918
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # var_0 = {}
    # var_1 = []
    assert Maybe.just("T").filter(lambda value: True) == Maybe.just("T"), "test_0-0"
    # assert Maybe.just("T").filter(lambda value: False) == Maybe.nothing(), "test_0-1"
    # assert Maybe.just("T").filter(lambda value: True) == Maybe.just("T"), "test_0-2"
    # assert Maybe.just("T").filter(lambda value: False) == Maybe.nothing(), "test_0-3"
    assert Maybe.just("T").filter(lambda value: True) == Maybe.just("T"), "test_0-4"
    # assert Maybe.just("T").filter(lambda value: False) == Maybe.nothing(), "test_0-5"
    # assert Maybe.

# Generated at 2022-06-25 23:54:52.915755
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # nothing.filter(lambda x: True) == nothing
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    # just(2).filter(lambda x: x % 2 == 1) == nothing
    assert Maybe.just(2).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    # just(2).filter(lambda x: x % 2 == 0) == just(2)
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)


# Generated at 2022-06-25 23:54:56.469898
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    var_0 = Maybe.just(1)
    var_1 = Maybe.nothing()
    var_2 = var_0.to_lazy()
    var_3 = var_1.to_lazy()
    pass


# Generated at 2022-06-25 23:54:58.088168
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_0 = {}
    var_1 = {}


# Generated at 2022-06-25 23:55:10.817253
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_0 = Maybe.just({})
    var_1 = var_0.filter(lambda value: True)
    var_2 = {}
    assert var_1.get_or_else(var_2) == var_0.get_or_else(var_2)
    var_3 = var_0.filter(lambda value: False)
    var_4 = {}
    assert var_3.get_or_else(var_4) != var_0.get_or_else(var_4)
    var_5 = Maybe.just({"": ""})
    var_6 = {"": ""}
    assert var_5.get_or_else(var_6) == var_0.get_or_else(var_6)
    var_7 = var_5.filter(lambda value: True)
    var_

# Generated at 2022-06-25 23:55:21.538047
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_0 = Maybe.just(1)
    var_1 = var_0.filter(lambda x: x > 0)
    var_2 = var_1.filter(lambda x: x < 2)
    var_3 = var_1.filter(lambda x: x < 0)
    var_4 = var_0.filter(lambda x: x > 0)
    var_5 = var_1.filter(lambda x: x > 2)
    var_6 = var_1.filter(lambda x: x > 0)
    var_7 = var_0.filter(lambda x: x > 2)
    var_8 = var_0.filter(lambda x: x < 0)
    var_9 = var_1.filter(lambda x: x < 2)

# Generated at 2022-06-25 23:55:22.952364
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter()


# Generated at 2022-06-25 23:55:33.240079
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    try:
        from pymonet.monad_try import Try
        from pymonet.box import Box
        from pymonet.lazy import Lazy
        from pymonet.either import Right, Left
        from pymonet.validation import Validation
        test_case_0()
        print("Pass test case 0 of Maybe.to_lazy")
    except AssertionError as e:
        print("Fail test case 0 of Maybe.to_lazy")
        print(e)
    except TypeError as e:
        print("Fail test case 0 Maybe.to_lazy")
        print(e)


# Generated at 2022-06-25 23:55:38.194653
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for filter method of Maybe class.
    """
    int_0 = 3
    int_1 = 3

    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.nothing()

    assert not maybe_0.filter(lambda x: x == 3) == maybe_2
    assert maybe_1.filter(lambda x: x == 3) == maybe_1

# Generated at 2022-06-25 23:55:51.106837
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    maybe_monad = Maybe.just(1)
    lazy_monad_from_maybe = maybe_monad.to_lazy()
    assert maybe_monad is not lazy_monad_from_maybe
    assert lazy_monad_from_maybe is not None
    assert lazy_monad_from_maybe.value() == 1
    assert isinstance(lazy_monad_from_maybe, Lazy)

    maybe_monad = Maybe.nothing()
    lazy_monad_from_maybe = maybe_monad.to_lazy()
    assert maybe_monad is not lazy_monad_from_maybe
    assert lazy_monad_from_maybe is not None
   

# Generated at 2022-06-25 23:56:00.992854
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = 5
    result_0 = sizeof(int_0)
    result_1 = 0
    result_1 = sizeof(int_1)
    result_2 = sizeof(result_0)
    result_2 = sizeof(result_1)
    expected_0 = result_2
    expected_1 = result_2
    result_3 = Maybe.just(int_0).filter(lambda x: sizeof(result_0) == result_2)
    result_3 = Maybe.just(int_1).filter(lambda x: sizeof(result_1) == result_2)
    expected_0 = result_3.get_or_else(int_0)
    expected_1 = result_3.get_or_else(int_1)
    expected_0 = result_2
    expected_

# Generated at 2022-06-25 23:56:07.027880
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # test_case_0
    m_0 = Maybe.just([-2, 3, 4])
    m_1 = Maybe.just(0)
    m_2 = Maybe.just(1)
    m_0 = m_0.filter(lambda x: x[1] > 0)
    # assert m_0 == Maybe.just([-2, 3, 4])
    m_1 = m_1.filter(lambda x: False)
    assert m_1 == Maybe.nothing()
    m_2 = m_2.filter(lambda x: True)
    # assert m_2 == Maybe.just(1)

    # test_case_1
    m_0 = Maybe.nothing()
    m_0 = m_0.filter(lambda x: False)
    assert m_0 == Maybe.nothing()

    # test_

# Generated at 2022-06-25 23:56:18.538084
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # [1]
    try:
        # Assertion 1
        assert Maybe.just(int_0).filter(lambda x: x > 2) == Maybe.just(3)
    except AssertionError as e:
        __logger__.error("Assertion 1 failed")

    # [2]
    try:
        # Assertion 2
        assert Maybe.just(int_0).filter(lambda x: x < 2) == Maybe.nothing()
    except AssertionError as e:
        __logger__.error("Assertion 2 failed")

    # [3]
    try:
        # Assertion 3
        assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()
    except AssertionError as e:
        __logger__.error("Assertion 3 failed")



# Generated at 2022-06-25 23:56:23.930106
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 3

    maybe_0 = Maybe.just(int_0)

    maybe_1 = maybe_0.to_lazy()

    # Test for type Maybe[A] -> Lazy[Function() -> A]
    assert isinstance(maybe_1, Lazy)

    # Test for value
    assert maybe_1.value() == int_0


# Generated at 2022-06-25 23:56:32.433194
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3

    maybe_0 = Maybe(int_0, False)
    maybe_1 = maybe_0.filter(lambda x: x == int_0)
    assertMaybe(maybe_1, False, int_0)

    int_1 = 3
    maybe_2 = maybe_1.filter(lambda x: x == int_1)
    assertMaybe(maybe_2, False, int_1)

    int_2 = 2
    maybe_3 = maybe_2.filter(lambda x: x == int_2)
    assertMaybe(maybe_3, True, None)

    maybe_4 = maybe_3.filter(lambda x: x == int_2)
    assertMaybe(maybe_4, True, None)


# Generated at 2022-06-25 23:56:39.825166
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    empty_maybe = Maybe.nothing()
    not_empty_maybe = Maybe.just(2)
    assert empty_maybe.filter(lambda x: x == 2) == Maybe.nothing()
    assert not_empty_maybe.filter(lambda x: x == 2) == Maybe.just(2)
    assert empty_maybe.filter(lambda x: x == None) == Maybe.nothing()
    assert not_empty_maybe.filter(lambda x: x == None) == Maybe.nothing()


# Generated at 2022-06-25 23:56:44.247764
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda x: True)
    assert maybe_1.value == int_0
    maybe_1 = maybe_0.filter(lambda x: x % 2 == 0)
    assert maybe_1.is_nothing


# Generated at 2022-06-25 23:56:52.099972
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_number = Maybe.just(3)
    def _is_even(number):
        return number % 2 == 0

    assert maybe_number.filter(_is_even) == Maybe.nothing()

    maybe = Maybe.just(3).map(lambda x: x + 1)
    assert maybe == Maybe.just(4)
    assert maybe.map(lambda x: x + 2) == Maybe.just(6)
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert maybe.filter(lambda x: x % 2 != 0) == Maybe.nothing()

    maybe = Maybe.nothing()
    assert maybe.map(lambda x: x + 2) == Maybe.nothing()
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-25 23:56:58.063726
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    actual = Maybe.just(int_0).filter(lambda x: x > 0)
    expected = Maybe.just(int_0)
    assert actual == expected, " Maybe.filter failed"

test_case_0()


# Generated at 2022-06-25 23:57:06.209978
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    def resolver():
        return int_0

    def test_0():
        try:
            Maybe.nothing().to_lazy().resolver()
            return False
        except TypeError:
            return True

    def test_1():
        maybe = Maybe.just(int_0)
        lazy = maybe.to_lazy()
        try:
            if lazy.resolver() == int_0:
                return True
        except TypeError:
            return False

    assert test_0() is True
    assert test_1() is True



# Generated at 2022-06-25 23:57:12.184431
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from copy import deepcopy

    integer_maybe = Maybe.just(3)
    mapper = lambda value: value * 3

# Generated at 2022-06-25 23:57:20.626830
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    _lambda = lambda value: value != 4
    _value = 4
    _value_1 = 5
    _string_value = '4'
    _integer_value = 4
    _float_value = 4.0
    _list_value = [4]
    _dict_value = {4: 4}
    _set_value = set(4)

    assert Maybe.just(_value).filter(_lambda) == Maybe.nothing()
    assert Maybe.just(_value_1).filter(_lambda) == Maybe.just(_value_1)
    assert Maybe.just(_string_value).filter(_lambda) == Maybe.nothing()
    assert Maybe.just(_integer_value).filter(_lambda) == Maybe.nothing()

# Generated at 2022-06-25 23:57:22.609285
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = Maybe.just(1)
    Result = int_0.to_lazy()
    assert Result.value() == 1


# Generated at 2022-06-25 23:57:28.087835
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy() == \
        Lazy(lambda: None)
    assert Maybe.just(3).to_lazy() == \
        Lazy(lambda: 3)


if __name__ == '__main__':
    import pymonet.monad_try
    import pymonet.validation
    import pymonet.lazy
    test_Maybe_to_lazy()

# Generated at 2022-06-25 23:57:34.932905
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print('\n')
    just_2 = Maybe.just(2)
    lazy_multi_2 = just_2.to_lazy()
    print(
        f'lazy_multi_2.get() --> {lazy_multi_2.get()}'
    )

    maybe_nothing = Maybe.nothing()
    lazy_nothing = maybe_nothing.to_lazy()
    print(
        f'lazy_nothing.get() --> {lazy_nothing.get()}'
    )


# Generated at 2022-06-25 23:57:39.082473
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = 3
    boolean_0 = Maybe.just(int_0).filter(lambda int_2: int_2 == 3)
    boolean_1 = Maybe.just(int_1).filter(lambda int_3: int_3 == 3)
    boolean_2 = boolean_0 == boolean_1
    assert boolean_2


# Generated at 2022-06-25 23:57:42.108397
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    int_1 = 2
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()

    assert lazy_0.value() == int_0
    assert lazy_1.value() == None


# Generated at 2022-06-25 23:57:46.059039
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    x = Maybe(3, False)
    y = Maybe(None, True)
    assert x.to_lazy() == Lazy(lambda: 3)
    assert y.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:52.306678
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    maybe = Maybe.just(1)
    expected = Maybe.just(1)

    # Act
    actual = maybe.filter(lambda x: x > 0)

    # Assert
    assert actual == expected


# Generated at 2022-06-25 23:58:01.163680
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Transform Maybe to Lazy.

    :returns: Lazy monad with function returning previous value when Maybe is not empty, in other case Lazy with None
    :rtype: Lazy[Function() -> (A | None)]
    """
    from pymonet.lazy import Lazy

    maybe_1 = Maybe(5, False)

# Generated at 2022-06-25 23:58:10.937743
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual_results_0 = Maybe.just(int_0).filter(bool).is_nothing
    # Maybe.just(int_0).filter(bool) -> Maybe.just(int_0) -> Maybe.just(int_0).is_nothing -> False
    expected_results_0 = False
    assert actual_results_0 == expected_results_0

    actual_results_1 = Maybe.just(int_0).filter(lambda x: x == int_0).is_nothing
    # Maybe.just(int_0).filter(lambda x: x == int_0) -> Maybe.just(int_0).is_nothing -> False
    expected_results_1 = False
    assert actual_results_1 == expected_results_1


# Generated at 2022-06-25 23:58:21.224970
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    int_0 = 3
    int_1 = 6
    may_0 = Maybe.just(int_0)
    may_1 = Maybe.just(int_1)
    # Act
    act_0 = may_0.filter(lambda x: x < int_1)
    act_1 = may_0.filter(lambda x: x > int_1)
    act_2 = may_1.filter(lambda x: x < int_1)
    act_3 = may_1.filter(lambda x: x > int_1)
    # Assert
    assert act_0 != may_0
    assert act_0 == may_0
    assert act_1 != may_0
    assert act_1 == Maybe.nothing()
    assert act_2 != may_1
    assert act_2 == may_

# Generated at 2022-06-25 23:58:24.390387
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_valid = Maybe.just(9)
    maybe_invalid = Maybe.nothing()

    assert maybe_valid.to_lazy().get() == 9
    assert maybe_invalid.to_lazy().get() == None


# Generated at 2022-06-25 23:58:27.422545
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    maybe_0 = Box(8).filter(lambda x: x > 7)
    maybe_1 = Box(2).filter(lambda x: x > 5)

    assert maybe_0 == Box(8)
    assert maybe_1 == Box(None)


# Generated at 2022-06-25 23:58:32.777647
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_0 = Maybe(int_0, False)
    maybe_1 = maybe_0.filter((lambda x: x < 1))
    assert maybe_1.value == 3
    assert maybe_1.is_nothing == False


# Generated at 2022-06-25 23:58:37.768989
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(int_0).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(int_0).filter(lambda x: x == 3) == Maybe.just(int_0)


# Generated at 2022-06-25 23:58:45.627202
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    for _ in range(1000):
        int_0 = random.randint(0, 100)
        maybe_int = Maybe.just(int_0)
        maybe_empty = Maybe.nothing()

        # assert maybe_int.filter(lambda value: value % 2 == 0).is_nothing == (int_0 % 2 != 0)
        # assert maybe_empty.filter(lambda value: value % 2 == 0).is_nothing == True

        assert maybe_int.filter(lambda value: value % 2 == 0).get_or_else(-1) == (int_0 if int_0 % 2 == 0 else -1)
        assert maybe_empty.filter(lambda value: value % 2 == 0).get_or_else(-1) == -1


# Generated at 2022-06-25 23:58:56.029237
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    global int_0
    int_0 = 3
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    # Box with value
    maybe = Maybe.just('a')
    result = maybe.to_lazy()
    assert result == Lazy(lambda: 'a')
    assert result.value() == 'a'

    # Box with value
    maybe = Maybe.just(int_0)
    result = maybe.to_lazy()
    assert result == Lazy(lambda: int_0)
    assert result.value() == int_0

    # Box with value
    maybe = Maybe.just(Box('b'))
    result = maybe.to_lazy()
    assert result == Lazy(lambda: Box('b'))
   

# Generated at 2022-06-25 23:59:07.566961
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == 3
    lazy_1 = maybe_0.to_lazy()
    assert lazy_1.value() == 3
    maybe_1 = Maybe.nothing()
    assert maybe_1.to_lazy().value() == None
    maybe_2 = Maybe.just(maybe_1)
    maybe_3 = maybe_2.to_lazy().value()
    assert maybe_3.is_nothing
    assert maybe_3.to_lazy().value() == None
    #assert maybe_3.to_lazy().value() == None


# Generated at 2022-06-25 23:59:09.751458
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = int_0
    int_2 = int_1
    int_3 = int_2
    test_case_0()

# Generated at 2022-06-25 23:59:12.864938
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(1)
    m2 = m1.filter(lambda x: x == 1)
    assert m2 == Maybe.just(1)
    m3 = m1.filter(lambda x: x != 1)
    assert m3 == Maybe.nothing()
    m4 = Maybe.nothing()
    m5 = m4.filter(lambda x: x != 1)
    assert m5 == Maybe.nothing()



# Generated at 2022-06-25 23:59:15.543493
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = 3
    maybe = Maybe.just(int_0)

    print('Maybe %s' % maybe)
    print('  to Lazy %s' % maybe.to_lazy())
    assert maybe.to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-25 23:59:20.373828
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-25 23:59:28.717853
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Validation

    val_1 = Validation.success(1)
    val_0 = Validation.success(0)

    maybe_1 = Maybe.just(val_1)
    maybe_0 = Maybe.just(val_0)
    maybe_nothing = Maybe.nothing()

    assert maybe_1.filter(lambda v: v.is_success())\
        == maybe_1
    assert maybe_0.filter(lambda v: v.is_success())\
        == Maybe.nothing()

    assert maybe_1.filter(lambda v: v.value > 0)\
        == maybe_1
    assert maybe_0.filter(lambda v: v.value > 0)\
        == Maybe.nothing()

    assert maybe_nothing.filter(lambda v: v.value > 0)\
        == Maybe.nothing

# Generated at 2022-06-25 23:59:32.665387
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:59:41.269764
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3

    m_0 = Maybe.just(int_0)
    m_1 = Maybe.just(int_1)
    m_2 = Maybe.just(int_2)
    m_3 = Maybe.nothing()

    input_0_filterer = lambda value: value == int_1
    input_1_filterer = lambda value: value == int_2

    output_0_filterer = m_1
    output_1_filterer = Maybe.nothing()

    output_of_0_filterer = m_0.filter(input_0_filterer)
    output_of_1_filterer = m_1.filter(input_0_filterer)

# Generated at 2022-06-25 23:59:43.974343
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    mb = Maybe.just(10)
    assert mb.filter(lambda x: x > 5).value == 10
    assert mb.filter(lambda x: x < 5).is_nothing



# Generated at 2022-06-25 23:59:51.402638
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import identity

    lazy_0 = Maybe.just(3).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.immediate() == 3
    assert identity(lazy_0) == Lazy(lambda: 3)

    lazy_1 = Maybe.nothing().to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.immediate() == None
    assert identity(lazy_1) == Lazy(lambda: None)

    # Test to check that lazy monad is really lazy :)
    int_0 = 3

    # Lazy is really lazy monad :)
    # Method Lazy.immediate will call function with one argument
    # And function will return int_0

# Generated at 2022-06-26 00:00:01.842673
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_value = Maybe.just(3)
    maybe_value_0 = Maybe.nothing()
    maybe_value_1 = maybe_value_0.filter(lambda x: x <= 3)
    maybe_value_2 = maybe_value.filter(lambda x: False)
    maybe_value_3 = maybe_value.filter(lambda x: True)
    maybe_value_4 = maybe_value.filter(lambda x: x == 3)
    assert maybe_value_1.is_nothing == True
    assert maybe_value_2.is_nothing == True
    assert maybe_value_3.get_or_else(int_0) == 3
    assert maybe_value_4.get_or_else(int_0) == 3


# Generated at 2022-06-26 00:00:13.702962
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = 1

    # Test for empty Maybe with custom filterer
    test_Maybe_filter_0(int_0, int_1)
    # Test for not empty Maybe with custom filterer
    test_Maybe_filter_1(int_0, int_1)
    # Test for empty Maybe with lambda filterer
    test_Maybe_filter_2(int_0, int_1)
    # Test for not empty Maybe with lambda filterer
    test_Maybe_filter_3(int_0, int_1)
    # Test for empty Maybe with None as filterer
    test_Maybe_filter_4(int_0, int_1)
    # Test for not empty Maybe with None as filterer
    test_Maybe_filter_5(int_0, int_1)


# Generated at 2022-06-26 00:00:18.483227
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x != 3) == Maybe.nothing()
    assert Maybe.just(3).filter(test_case_0) == Maybe.nothing()

# Generated at 2022-06-26 00:00:28.849792
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    int_0 = 3

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_0_filtered = maybe_int_0.filter(lambda x : x > 1 and x < 4)

    assert maybe_int_0_filtered == maybe_int_0

    # Test case 1
    maybe_int_1 = Maybe.just(int_0)
    maybe_int_1_filtered = maybe_int_1.filter(lambda x : x > 5)

    assert maybe_int_1_filtered == Maybe.nothing()

    # Test case 2
    maybe_int_2 = Maybe.nothing()
    maybe_int_2_filtered = maybe_int_2.filter(lambda x : x > 1 and x < 4)


# Generated at 2022-06-26 00:00:36.615551
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = "a string"
    bool_0 = True
    maybe_0 = Maybe.just(str_0)
    assert maybe_0.filter(lambda item: item == str_0) == Maybe.just(str_0)
    maybe_1 = Maybe.just(int)
    assert maybe_1.filter(lambda item: item == int) == Maybe.just(int)
    maybe_2 = Maybe.just(bool_0)
    assert maybe_2.filter(lambda item: item == bool_0) == Maybe.just(bool_0)


# Generated at 2022-06-26 00:00:43.467348
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    bool_0 = maybe_0.filter(lambda item: item is int_0 and True).to_box().value is not None
    bool_1 = maybe_0.filter(lambda item: item is int_0 and True).get_or_else(0) is not None
    bool_2 = maybe_0.filter(lambda item: item is int_0 and False).to_box().value is None
    bool_3 = maybe_0.filter(lambda item: item is int_0 and False).get_or_else(0) is None
    bool_4 = maybe_0.filter(lambda item: item is int_0 and True).to_box().value is maybe_0.to_box().value

# Generated at 2022-06-26 00:00:46.170666
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 is not None


# Generated at 2022-06-26 00:00:55.501373
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: True) == Maybe.just(0)
    assert Maybe.just(False).filter(lambda x: True) == Maybe.just(False)
    assert Maybe.just(3.14).filter(lambda x: True) == Maybe.just(3.14)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(False).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(3.14).filter(lambda x: False) == Maybe.nothing()

# Generated at 2022-06-26 00:00:58.791685
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-26 00:01:07.130355
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try

    def is_even(value):
        return value % 2 == 0

    assert Maybe.just(1).filter(is_even) == Maybe.nothing()
    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()

    assert Maybe.just(1).filter(is_even).get_or_else(0) == 0
    assert Maybe.just(2).filter(is_even).get_or_else(0) == 2
    assert Maybe.nothing().filter(is_even).get_or_else(0) == 0

    assert Maybe.just(1).filter(is_even).to_either() == Try.failure(None)
    assert Maybe.just(2).filter

# Generated at 2022-06-26 00:01:14.293002
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    box = Maybe.just(3)
    filterer = lambda x: x > 3
    assert box.filter(filterer).to_box().value == None, "When filterer returns False then filter must return empty Maybe"



# Generated at 2022-06-26 00:01:23.364624
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    for i in range(100):
        int_value = random.randint(-100, 100)
        int_maybe = Maybe.just(int_value)
        def filterer(n):
            return n % 2 == 0
        def filterer_0(n):
            return n % 2 == 1
        filtered_maybe = int_maybe.filter(filterer)
        filtered_maybe_0 = int_maybe.filter(filterer_0)
        if int_value % 2 == 0:
            assert filtered_maybe == Maybe.just(int_value)
            assert filtered_maybe_0 == Maybe.nothing()
        else:
            assert filtered_maybe == Maybe.nothing()
            assert filtered_maybe_0 == Maybe.just(int_value)



# Generated at 2022-06-26 00:01:29.232835
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try

    # Nothing
    m_int_0 = Maybe.nothing()
    assert m_int_0.to_lazy().map(lambda: int_0) == Lazy(lambda: None)

    # Just
    m_int_1 = Maybe.just(int_0)
    assert m_int_1.to_lazy().map(lambda: int_0) == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:01:32.054176
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x % 2 == 1) == Maybe.just(3)


# Generated at 2022-06-26 00:01:36.569281
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    expected_lazy_maybe = Lazy(lambda: 1)
    maybe = Maybe.just(1)

    result_maybe = maybe.to_lazy()

    result = result_maybe == expected_lazy_maybe
    print("result:", result)
    print("result_maybe:", result_maybe)
    print("expected_lazy_maybe:", expected_lazy_maybe)

    assert result


# Generated at 2022-06-26 00:01:41.813900
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_box = Maybe.just(4).filter(lambda v: v % 2 == 0)
    assert maybe_box == Maybe.just(4)

    maybe_box = Maybe.nothing().filter(lambda v: v % 2 == 0)
    assert maybe_box == Maybe.nothing()

    maybe_box = Maybe.just(5).filter(lambda v: v % 2 == 0)
    assert maybe_box == Maybe.nothing()


# Generated at 2022-06-26 00:01:45.591416
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_0 = Maybe(int_0, False)
    value_0 = maybe_0.to_lazy()

    assert isinstance(value_0, Lazy)
    assert value_0.get() == int_0



# Generated at 2022-06-26 00:01:48.848398
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    Maybe1 = Maybe.just(int_0)
    Maybe2 = Maybe1.filter(lambda v: v == 3)
    Maybe3 = Maybe2.filter(lambda v: v == 2)
    assert Maybe3 == Maybe(None, True)



# Generated at 2022-06-26 00:01:51.248206
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = Maybe.nothing()
    assert int_0.filter(lambda x: x % 2 == 0) == Maybe.nothing()


test_Maybe_filter()


# Generated at 2022-06-26 00:02:01.720672
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Positive test case
    maybe_0 = Maybe.just(int(5))
    assert maybe_0.filter(lambda x: x >= 5) == Maybe.just(int(5))

    # Negative test case
    maybe_0 = Maybe.just(int(5))
    assert maybe_0.filter(lambda x: x > 7) == Maybe.nothing()

    # test case with not existing parameter
    # maybe_0 = Maybe.just(U)
    # assert maybe_0.filter(lambda x: x >= 3) == Maybe.nothing()
    # assert maybe_0.filter(lambda x: x >= 5) == Maybe.just(int(5))

    # test case with not existing parameter
    # maybe_0 = Maybe.just(int(3))
    # assert maybe_0.filter(lambda x: x > 3) == Maybe.

# Generated at 2022-06-26 00:02:10.992150
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = Maybe.just(3)
    def is_positive(value):
        return value > 0
    value.filter(is_positive)


# Generated at 2022-06-26 00:02:18.552794
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_0 = Maybe.just(3)

    if not isinstance(maybe_0, Maybe):
        raise RuntimeError(
            'Failed test_Maybe_to_lazy: maybe_0 is not Maybe type'
        )

    maybe_1 = maybe_0.to_lazy()

    if not isinstance(maybe_1, Lazy):
        raise RuntimeError(
            'Failed test_Maybe_to_lazy: maybe_1 is not Lazy type'
        )

    if not maybe_0 == maybe_1:
        raise RuntimeError(
            'Failed test_Maybe_to_lazy: Maybe.to_lazy() returns not the same value'
        )


# Generated at 2022-06-26 00:02:27.123595
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # assert_equal is a function of unittest
    int_0 = 3
    int_1 = 7
    int_2 = 5
    int_3 = 4
    int_4 = 8
    int_6 = 2
    int_7 = 9
    int_8 = 3
    int_9 = 10
    maybe_0 = Maybe.just(int_0)
    # maybe_1 = maybe_0.filter(lambda x: x < 6)
    # maybe_2 = maybe_1.filter(lambda x: x > 4)
    maybe_3 = maybe_0.filter(lambda x: x < 6)
    maybe_4 = maybe_3.filter(lambda x: x < 4)
    maybe_5 = maybe_4.filter(lambda x: x > 2)
    maybe_5_5 = maybe_5.filter

# Generated at 2022-06-26 00:02:35.800639
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test 1
    maybe = Maybe.just(2)
    maybe = maybe.filter(lambda x : True)
    assert isinstance(maybe, Maybe)
    assert not maybe.is_nothing
    assert maybe.value == 2
    # Test 2
    maybe = Maybe.just(2)
    maybe = maybe.filter(lambda x : False)
    assert isinstance(maybe, Maybe)
    assert maybe.is_nothing
    # Test 3
    maybe = Maybe.just(None)
    maybe = maybe.filter(lambda x : False)
    assert isinstance(maybe, Maybe)
    assert maybe.is_nothing
    # Test 4
    maybe = Maybe.just(None)
    maybe = maybe.filter(lambda x : True)
    assert isinstance(maybe, Maybe)
    assert not maybe.is_nothing
    assert maybe.value

# Generated at 2022-06-26 00:02:38.377548
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_1 = Maybe.just(int_0)
    bool_0 = maybe_1.filter((lambda mapper: mapper > 0))
    assert bool_0 == Maybe.just(int_0)


# Generated at 2022-06-26 00:02:42.196589
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 0) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-26 00:02:46.479875
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    eval_ = Maybe.just(2).to_lazy().get()
    int_0 = eval_()
    assert int_0 == 2



# Generated at 2022-06-26 00:02:52.649696
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # case 0
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda a: a == 0)
    maybe_2 = Maybe.nothing()
    assert maybe_1 == maybe_2

    # case 1
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda a: a == 3)
    maybe_2 = Maybe.just(int_0)
    assert maybe_1 == maybe_2

    # case 2
    int_0 = 3
    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(lambda a: a == 3)
    maybe_2 = Maybe.nothing()
    assert maybe_1 == maybe_2

# Unit test

# Generated at 2022-06-26 00:03:01.085324
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Input
    int_0 = 3
    def function_0(int_0):
        if int_0 > 5:
            return True
        return False
    
    # Output
    bool_0 = True
    bool_1 = False

    # Test
    result_0 = Maybe.just(int_0).filter(function_0)
    result_1 = result_0.get_or_else(None)
    result_2 = result_1 is None
    assert (bool_0 is result_2)

    # Input
    int_0 = 5
    def function_0(int_0):
        if int_0 > 3:
            return True
        return False
    
    # Output
    bool_0 = True
    bool_1 = False

    # Test