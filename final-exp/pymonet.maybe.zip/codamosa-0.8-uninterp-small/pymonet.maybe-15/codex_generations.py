

# Generated at 2022-06-25 23:53:12.786418
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def fn_is_even(val):
        return val % 2 == 0

    def fn_is_odd(val):
        return val % 2 == 1

    maybe_0 = Maybe(3, False)
    maybe_1 = maybe_0.filter(fn_is_even)  # maybe_1 = Maybe.nothing()
    maybe_2 = maybe_0.filter(fn_is_odd)  # maybe_2 = Maybe.just(3)

    validation_0 = Validation.failure([0])
    validation_1 = maybe_2.to_validation()  # validation_1 = Validation.success()

    try_0 = Try(3, False)
    try_1 = maybe_1.to_try() 

# Generated at 2022-06-25 23:53:24.776547
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pickle
    import collections

    dict_0 = dict()
    dict_0['maybe_0'] = Maybe(dict(), False)
    dict_0['maybe_1'] = Maybe(dict(), True)

    with open('res/out_Maybe_to_lazy.pickle', 'wb') as file:
        pickle.dump(dict_0, file)

    with open('res/out_Maybe_to_lazy.pickle', 'rb') as file:
        assert pickle.load(file) == dict_0

    dict_1 = dict()
    dict_1['maybe_0'] = Maybe(dict(), False).to_lazy()
    dict_1['maybe_1'] = Maybe(dict(), True).to_lazy()


# Generated at 2022-06-25 23:53:30.837910
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('\nTesting Maybe.__eq__')
    dict_0 = {}
    dict_1 = {}
    maybe_0 = Maybe(dict_0, False)
    maybe_1 = Maybe(dict_0, False)
    maybe_2 = Maybe(dict_1, False)
    maybe_3 = Maybe(dict_0, True)
    maybe_4 = Maybe(dict_1, True)
    print(maybe_0 == maybe_1)
    print(maybe_1 == maybe_2)
    print(maybe_2 == maybe_3)
    print(maybe_3 == maybe_4)


# Generated at 2022-06-25 23:53:39.476684
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(str)
    maybe_1 = Maybe.just(str)
    maybe_2 = Maybe.just(str)
    maybe_3 = Maybe.just(str)
    maybe_4 = Maybe.just(str)
    maybe_5 = Maybe.just(str)
    maybe_6 = Maybe.just(str)
    maybe_7 = Maybe.just(str)
    maybe_8 = Maybe.just(str)
    maybe_9 = Maybe.just(str)
    maybe_10 = Maybe.just(str)
    maybe_11 = Maybe.just(str)
    maybe_12 = Maybe.just(str)
    # __eq__ reports true if its argument is a Maybe of the same type with the same value.
    assert maybe_0.__eq__(maybe_0)
    assert maybe_1

# Generated at 2022-06-25 23:53:50.526399
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    list_0 = ['q', 'q', 'q']
    list_1 = ['q', 'q', 'q']
    maybe_0 = Maybe.just(list_0)
    maybe_1 = Maybe.just(list_0)
    maybe_2 = Maybe.just(list_1)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    lazy_2 = maybe_2.to_lazy()
    assert (maybe_0 == maybe_1 or maybe_0 != maybe_1)
    assert (lazy_0 == lazy_1 or lazy_0 != lazy_1)
    assert (lazy_0 == lazy_2 or lazy_0 != lazy_2)
    assert (maybe_0 == maybe_2 or maybe_0 != maybe_2)


# Generated at 2022-06-25 23:53:55.480683
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(1, False)
    maybe_1 = Maybe((1,), True)
    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1


# Generated at 2022-06-25 23:54:03.778783
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe(1, False)
    assert maybe.filter(lambda x: x == 1) == Maybe(1, False)
    assert maybe.filter(lambda x: x != 1) == Maybe(None, True)
    assert maybe.filter(lambda x: True) == Maybe(1, False)
    assert maybe.filter(lambda x: False) == Maybe(None, True)

    maybe = Maybe(None, True)
    assert maybe.filter(lambda x: x == 1) == Maybe(None, True)
    assert maybe.filter(lambda x: x != 1) == Maybe(None, True)
    assert maybe.filter(lambda x: True) == Maybe(None, True)
    assert maybe.filter(lambda x: False) == Maybe(None, True)


# Generated at 2022-06-25 23:54:10.524062
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_1 = False
    dict_0 = {bool_1: bool_1}
    maybe_0 = Maybe.just(dict_0)
    maybe_1 = maybe_0.filter(lambda x: bool(x))
    maybe_2 = Maybe.nothing().filter(lambda x: bool(x))
    maybe_3 = maybe_0.filter(lambda x: bool(x))


# Generated at 2022-06-25 23:54:18.621790
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(bool_0, bool_0)
    maybe_2 = maybe_0.map(lambda val: val)
    bool_3 = maybe_0 == maybe_1
    bool_4 = maybe_1 == maybe_2
    assert bool_3.value == bool_4.value
    bool_5 = maybe_0 == maybe_2
    assert bool_5.value != bool_4.value


# Generated at 2022-06-25 23:54:32.181096
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    bool_0 = True
    bool_1 = False
    str_0 = "gu"
    float_0 = float()

    maybe_0 = Maybe(float_0, True)
    maybe_1 = Maybe(float_0, True)

    assert maybe_0 == maybe_1, "maybe_0 != maybe_1"

    maybe_0 = Maybe(float_0, True)
    maybe_1 = Maybe(float_0, False)

    assert maybe_0 != maybe_1, "maybe_0 == maybe_1"

    maybe_0 = Maybe(float_0, True)
    maybe_1 = Maybe(str_0, True)

    assert maybe_0 != maybe_1, "maybe_0 == maybe_1"

    maybe_0 = Maybe(float_0, True)

# Generated at 2022-06-25 23:54:35.918023
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_case_0() # no assert

# Generated at 2022-06-25 23:54:47.946560
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    int_0 = 0
    int_1 = 1
    tuple_0 = (int_1, int_0)
    maybe_0 = Maybe.just(bool_0)
    maybe_0 = maybe_0.filter(int_1.__eq__)
    maybe_0 = maybe_0.filter(bool.__eq__)
    maybe_0 = maybe_0.filter(int_1.__eq__)
    maybe_0 = maybe_0.filter(int_0.__eq__)
    maybe_0 = maybe_0.filter(int_1.__eq__)
    maybe_0 = maybe_0.filter(int_1.__eq__)
    maybe_0 = maybe_0.filter(int_1.__eq__)

# Generated at 2022-06-25 23:54:51.162224
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    bool_1 = bool_0
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe.just(dict_0)
    maybe_1 = maybe_0.filter(bool_1)


# Generated at 2022-06-25 23:54:55.384270
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    bool_1 = True
    lazy_0.value()


# Generated at 2022-06-25 23:55:03.215667
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe.just(dict_0)
    def filterer_1(arg_0):
        return arg_0.get(bool_0)
    # When
    maybe_1 = maybe_0.filter(filterer_1)
    # Then
    assert maybe_0.filter(filterer_1) == Maybe.just(dict_0)


# Generated at 2022-06-25 23:55:11.027612
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    str_0 = "b"
    bool_0 = False
    tuple_0 = (int_0, )
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_1 = maybe_0.filter(lambda x: 1)
    assert maybe_1 == Maybe.just(False)
    maybe_2 = maybe_0.filter(lambda x: x)
    assert maybe_2 == Maybe.nothing()


# Generated at 2022-06-25 23:55:15.065396
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:55:23.527385
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(bool)
    maybe_1 = Maybe.nothing()
    maybe_0_instance = maybe_0.filter(lambda x: x)
    maybe_1_instance = maybe_1.filter(lambda x: x)
    assert isinstance(maybe_0_instance, Maybe)
    assert isinstance(maybe_1_instance, Maybe)
    assert maybe_0_instance.is_nothing == False
    assert maybe_1_instance.is_nothing == True
    assert maybe_0_instance.value == bool
    assert maybe_1_instance == Maybe.nothing()


# Generated at 2022-06-25 23:55:31.019276
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(1, True)
    dict_0 = {maybe_0: maybe_0}
    maybe_1 = Maybe(dict_0, True)
    bool_0 = True
    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.filter(lambda value: value == bool_0)
    maybe_4 = maybe_3.filter(lambda value: value is int)

# Generated at 2022-06-25 23:55:39.381724
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    @do
    def do_test():
        def test_case_0():
            bool_0 = False
            dict_0 = {bool_0: bool_0}
            maybe_0 = Maybe(dict_0, bool_0)
            actual = maybe_0
            expected = maybe_0
            return actual, expected

        def test_case_1():
            int_0 = 12
            dict_0 = {int_0: int_0}
            maybe_0 = Maybe(dict_0, False)
            def func_0(bool_0):
                return int_0
            maybe_expected = Maybe(dict_0, False)
            actual = maybe_0.filter(func_0)
            expected = maybe_expected
            return actual, expected

        def test_case_2():
            dict_0 = { }
           

# Generated at 2022-06-25 23:55:47.268028
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    set_0 = {True, False}
    dict_0 = {True: set_0}
    maybe_0 = Maybe.just(dict_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_0.to_lazy()
    lazy_0 == lazy_1


# Generated at 2022-06-25 23:55:55.746533
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def f1():
        return 2
    maybe_0 = Maybe(f1, True)
    try:
        assert maybe_0.to_lazy() == Lazy(f1)
        assert maybe_0.to_lazy() == Lazy(f1)
        assert maybe_0.to_lazy() == Lazy(f1)
        assert maybe_0.to_lazy() == Lazy(f1)
        assert maybe_0.to_lazy() == Lazy(f1)
    except AssertionError:
        raise AssertionError('Caught AssertionError')


# Generated at 2022-06-25 23:56:04.145939
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(maybe_0, bool_0)
    lazy_0 = maybe_1.to_lazy()
    lazy_1 = lazy_0.map(lambda value: value)
    lazy_2 = lazy_1.map(lambda value: value)
    lazy_3 = lazy_2.map(lambda value: value)
    lazy_4 = lazy_3.map(lambda value: value)
    lazy_5 = lazy_4.map(lambda value: value)
    lazy_6 = lazy_5.map(lambda value: value)
    lazy_7 = lazy_6.map(lambda value: value)

# Generated at 2022-06-25 23:56:08.743315
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create Maybe[int] instance
    maybe_0 = Maybe(1, False)

    # Create Lazy monad
    maybe_0_to_lazy = maybe_0.to_lazy()

    # Evaluate Lazy monad
    maybe_0_to_lazy = maybe_0.to_lazy().get_value()


# Generated at 2022-06-25 23:56:20.346526
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def lazy_function():
        from pymonet.either import Right
        from pymonet.box import Box
        from pymonet.lazy import Lazy
        from pymonet.monad_try import Try
        from pymonet.validation import Validation

        def function_0() -> Try:
            from pymonet.monad_try import Try
            try:
                return Try(int('string'), is_success=True)
            except Exception as e:
                return Try(e, is_success=False)

        def function_1(arg_0: Try) -> Validation:
            if not arg_0.is_success:
                return Validation.failure(arg_0.value)
            return Validation.success(arg_0.value)


# Generated at 2022-06-25 23:56:22.327511
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    bool_1 = True
    bool_0 = False
    maybe_0 = Maybe(bool_1, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:56:26.438584
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = maybe_0.to_lazy()
    assert not maybe_1.is_nothing
    assert maybe_1.value() == dict_0


# Generated at 2022-06-25 23:56:30.748093
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    test_func = lambda: "test"

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(test_func).to_lazy() == Lazy(test_func)


# Generated at 2022-06-25 23:56:38.776746
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Maybe, Lazy

    def _(i: int) -> int:
        return i + 3

    def _2(i: int) -> int:
        return i * 2

    assert Maybe.just(1).map(_).map(_2).to_lazy() == Lazy(lambda: 8)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    assert Maybe.just(Maybe.just(1)).to_lazy() == Lazy(lambda: Maybe.just(1))



# Generated at 2022-06-25 23:56:40.915693
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(7).to_lazy().value() == 7
    assert Maybe.nothing().to_lazy().value() == None


# Generated at 2022-06-25 23:56:52.153132
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    str_0 = str()
    str_1 = str()
    str_2 = str()
    str_3 = str()
    str_4 = str()
    str_5 = str()
    str_6 = str()
    str_7 = str()
    str_8 = str()
    str_9 = str()
    str_10 = str()
    str_11 = str()
    str_12 = str()
    str_13 = str()
    str_14 = str()
    str_15 = str()
    str_16 = str()
    str_17 = str()
    str_18 = str()
    str_19 = str()
    str_20 = str()
    str_21 = str()

# Generated at 2022-06-25 23:56:56.475892
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    assert maybe_0.to_lazy().fnc().keys() == [bool_0]


# Generated at 2022-06-25 23:57:01.868998
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create maybe with value True
    maybe_0: Maybe[bool] = Maybe.just(True)

    # Create lazy object from maybe
    lazy_0: Lazy[Callable[[], bool]] = maybe_0.to_lazy()

    # Check that lazy object returns same value as maybe
    assert lazy_0.force() == maybe_0.value


# Generated at 2022-06-25 23:57:04.248138
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(123).to_lazy().run() == 123
    assert Maybe.nothing().to_lazy().run() is None


# Generated at 2022-06-25 23:57:07.457501
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = maybe_0.to_lazy()



# Generated at 2022-06-25 23:57:12.132922
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    bool_1 = lazy_0.is_lazy()


# Generated at 2022-06-25 23:57:16.628716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    string_0 = "!dlrow olleH"
    bool_0 = False
    maybe_0 = Maybe(string_0, bool_0)
    maybe_1 = Maybe(None, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()



# Generated at 2022-06-25 23:57:18.527209
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:57:28.003079
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.helpers.value_strings import get_dict_string
    from pymonet.helpers.value_strings import get_bool_string
    from pymonet.helpers.value_strings import get_str_string

    key_0 = 'key_0'
    value_0 = 'val_0'
    value_1 = 'val_1'

    dict_0 = {key_0: value_0}
    dict_1 = {key_0: value_1}
    bool_0 = False
    bool_1 = True

    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(dict_0, bool_1)

    # if self.is_nothing:
    #     return Lazy(lambda: None)
    # return Lazy(lambda: self.value

# Generated at 2022-06-25 23:57:37.857304
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # bool_0, bool_1, bool_2, bool_3 are bool
    bool_0 = False
    bool_1 = True
    bool_2 = True
    bool_3 = False
    # num_0, num_1, num_2, num_3 are int with value 0
    num_0 = 0
    num_1 = 0
    num_2 = 0
    num_3 = 0
    # str_0, str_1, str_2, str_3 are str with value  ''
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    # list_0, list_1, list_2, list_3 are lists with values []
    list_0 = []
    list_1 = []

# Generated at 2022-06-25 23:57:55.282279
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    bool_1 = False
    int_0 = 0
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0
    str_0 = ''
    str_1 = ''
    str_2 = ''
    str_3 = ''
    str_4 = ''
    str_5 = ''
    str_6 = ''
    str_7 = ''
    str_8 = ''
    str_9 = ''
    str_10 = ''
    str_11 = ''
    str_12 = ''
    str_13 = ''
    str_14 = ''
    str_15 = ''
    str_

# Generated at 2022-06-25 23:58:03.548290
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_case_3():
        list_2 = list()
        int_0 = -12
        maybe_0 = Maybe.just(list_2)
        lazy_0 = maybe_0.to_lazy()
        int_1 = lazy_0.__value__(int_0)
        lazy_1 = maybe_0.to_lazy()
        int_2 = lazy_1.__value__(int_0)
        assert int_1 == int_2

    def test_case_4():
        int_0 = 0
        maybe_0 = Maybe.nothing()
        lazy_0 = maybe_0.to_lazy()
        int_1 = lazy_0.__value__(int_0)
        maybe_1 = Maybe.just(int_1)
        list_0 = list()
        maybe_

# Generated at 2022-06-25 23:58:11.134988
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    generator_0 = ((x_0 for x_0 in (maybe_0, )) for x_0 in (bool_0, ))
    lazy_1 = lazy_0.sequence(generator_0)
    lazy_2 = lazy_1.flatten()


# Generated at 2022-06-25 23:58:16.270235
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    dict_0 = {0: (1, 2, 3)}
    maybe_0 = Maybe(dict_0, True)
    maybe_1 = Maybe.just((1, 2, 3))
    lazy_0 = maybe_1.to_lazy()
    lazy_1 = maybe_0.to_lazy()
    lazy_0.force()
    lazy_1.force()



# Generated at 2022-06-25 23:58:18.440684
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe(True, True)
    lazy = maybe.to_lazy()
    assert lazy.get() is True


# Generated at 2022-06-25 23:58:27.226166
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    bool_1 = True
    # maybe_0 = Maybe.nothing()
    # maybe_1 = Maybe.just(bool_0)
    # maybe_2 = Maybe.just(bool_1)
    # maybe_3 = Maybe.just(bool_1)
    # maybe_4 = Maybe.just(bool_0)
    # maybe_5 = Maybe.nothing()
    # maybe_6 = Maybe.nothing()
    # maybe_7 = Maybe.just(bool_0)
    # maybe_8 = Maybe.just(bool_1)
    # maybe_9 = Maybe.nothing()
    # maybe_10 = Maybe.nothing()
    # maybe_11 = Maybe.just(bool_0)
    # maybe_12 = Maybe.just(bool_1)
    # maybe_13 = Maybe.nothing()

# Generated at 2022-06-25 23:58:30.804843
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # AssertionError: Maybe.to_lazy() is not None!
    assert Maybe.to_lazy() is not None



# Generated at 2022-06-25 23:58:40.690789
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just("i")
    maybe_1 = Maybe.just("k")
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.just("f")
    maybe_4 = Maybe.just("k")
    maybe_5 = Maybe.just("r")
    maybe_6 = Maybe.just("h")
    maybe_7 = Maybe.nothing()
    maybe_8 = Maybe.nothing()
    maybe_9 = Maybe.just("n")
    maybe_10 = Maybe.nothing()
    maybe_11 = Maybe.nothing()
    maybe_12 = Maybe.nothing()
    maybe_13 = Maybe.just("i")
    maybe_14 = Maybe.nothing()
    maybe_15 = maybe_4.map(lambda x: x + "60k")
    maybe_16 = Maybe.just("q")


# Generated at 2022-06-25 23:58:46.009672
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    dict_0 = dict()
    bool_0 = bool()
    # maybe_0 = Maybe(dict_0, bool_0)

    maybe_0 = Maybe.just(dict_0)
    lazy_0 = maybe_0.to_lazy()
    # lazy_0 = Lazy(lambda: dict_0)
    assert lazy_0.value() == dict_0, "Assertion error"

test_Maybe_to_lazy()



# Generated at 2022-06-25 23:58:57.148952
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()
    dict_0 = dict()

# Generated at 2022-06-25 23:59:12.077506
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    Maybe.nothing().to_lazy()
    Maybe.just(set()).to_lazy()


# Generated at 2022-06-25 23:59:13.557878
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    dict_0 = {}
    maybe_0 = Maybe(dict_0, False)
    Lazy(None)

# Generated at 2022-06-25 23:59:15.310229
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(10)
    try:
        assert maybe_0.to_lazy().value() == 10
    except:
        assert False



# Generated at 2022-06-25 23:59:16.086355
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass



# Generated at 2022-06-25 23:59:22.827239
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    # Test case 0
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    result_0 = maybe_0.to_lazy()
    Lazy(lambda: None)
    # Test case 1
    bool_1 = True
    dict_1 = {bool_1: bool_1}
    maybe_1 = Maybe(dict_1, bool_1)
    result_1 = maybe_1.to_lazy()
    Lazy(lambda: {})


# Generated at 2022-06-25 23:59:33.200745
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()

    def func_0(func_0_0: Callable[[Union[float, int]], bool], func_0_1: bool):
        bool_1 = bool_0 or bool_0 or bool_0 or bool_0 or bool_0 or bool_0
        bool_2 = bool_0 or bool_0 or bool_0 or bool_0 or bool_0 or bool_0
        bool_3 = bool_0
        return bool_3
    bool_4 = bool_0 and bool_0
    bool_5 = bool_0 and bool_0
    bool_6 = bool_0



# Generated at 2022-06-25 23:59:37.416987
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.pfunctor import Functor

    maybe_0 = Maybe(1, False)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Functor)
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:59:38.853878
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_case_0()

if __name__ == '__main__':
    test_Maybe_to_lazy()

# Generated at 2022-06-25 23:59:47.545753
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    bool_1 = True
    logic_0 = Logic(bool_0)
    logic_1 = Logic(bool_1)
    maybe_0 = Maybe(logic_0, bool_1)
    lazy_0 = Lazy(lambda: maybe_0)
    lazy_1 = lazy_0.flat_map(lambda x: Lazy(lambda: maybe_0.to_lazy()))
    lazy_2 = lazy_1.flat_map(lambda x: x)
    lazy_3 = lazy_2.flat_map(lambda x: x)
    lazy_4 = lazy_3.flat_map(lambda x: x)
    lazy_5 = lazy_4.flat_map(lambda x: x)
    lazy_6 = lazy_5.flat_map(lambda x: x)
    lazy

# Generated at 2022-06-25 23:59:49.520198
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Maybe.just(0).to_lazy()
    bool_0 = isinstance(lazy_0, Lazy)
    assert bool_0 is True



# Generated at 2022-06-26 00:00:19.048390
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-26 00:00:22.586188
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()


# Generated at 2022-06-26 00:00:26.855314
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    dict_0 = {'a': 'a'}
    maybe_0 = Maybe(dict_0, False)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy(lambda: dict_0)


# Generated at 2022-06-26 00:00:28.725888
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert  Maybe.just(5).to_lazy().get() == 5

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 00:00:32.473963
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_0.value()



# Generated at 2022-06-26 00:00:35.780447
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy.pure(1)
    assert Maybe.nothing().to_lazy() == None


# Generated at 2022-06-26 00:00:40.323550
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    dict_0 = {'6U5Dg1': {'fWpgH9'}}
    maybe_0 = Maybe(dict_0, True)
    baz = maybe_0.to_lazy()
    dict_0 = {'6U5Dg1': {'fWpgH9'}}
    maybe_0 = Maybe(dict_0, True)
    baz = maybe_0.to_lazy()


# Generated at 2022-06-26 00:00:43.761596
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(bool())
    maybe_1 = Maybe.nothing()

    assert maybe_0.to_lazy().eval() == bool()

    assert maybe_1.to_lazy().eval() is None


# Generated at 2022-06-26 00:00:48.335187
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe(None, False)
    maybe_0_to_lazy_0 = maybe_0.to_lazy()
    maybe_0_to_lazy_0_1 = maybe_0_to_lazy_0.value()
    assert maybe_0_to_lazy_0_1 == None


# Generated at 2022-06-26 00:00:51.040482
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    value = Maybe.to_lazy(dict_0, bool_0)
    maybe_0 = Maybe.just(value)


# Generated at 2022-06-26 00:01:50.509629
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def func():
        return 5
    lazy = Maybe.just(func).to_lazy()
    assert lazy.value() == 5


# Generated at 2022-06-26 00:02:00.450495
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Test cases
    def f1(void_0):
        bool_0 = bool(void_0)
        bool_1 = bool(bool_0)

        bool_2 = bool_1
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_2
        bool_2 = bool_

# Generated at 2022-06-26 00:02:02.044282
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe(False, True)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_0.to_lazy()
    assert lazy_0 == lazy_1
    assert type(lazy_0) == type(maybe_0.to_lazy())


# Generated at 2022-06-26 00:02:06.517183
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.may_be import Maybe
    from pymonet.lazy import Lazy
    f = lambda : 4
    maybe = Maybe.just(f)
    assert maybe.to_lazy().val is f, "Should be true"

    maybe = Maybe.nothing()
    assert maybe.to_lazy().val is None, "Should be true"



# Generated at 2022-06-26 00:02:09.535238
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    dict_0 = {bool_0: bool_0}
    maybe_0 = Maybe(dict_0, bool_0)
    result_0 = maybe_0.to_lazy()
    lazy_0 = Lazy.just(dict_0)
    assert result_0.eval() == lazy_0.eval()


# Generated at 2022-06-26 00:02:16.969346
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.functions import identity
    from pymonet.functions import compose
    from pymonet.functions import __

    from pymonet.lazy import Lazy

    from pymonet.monad import Maybe
    from pymonet.monad import already_monadified

    from pymonet.monad_try import Try
    from pymonet.monad_try import already_monadified as already_monadified_try

    from pymonet.applicative import Applicative
    from pymonet.applicative import already_applicative

    from pymonet.functor import Functor
    from pymonet.functor import already_functor

    from pymonet.fantasy_land import functor as functor_fantasy_land
    from pymonet.fantasy_land import applicative

# Generated at 2022-06-26 00:02:22.918051
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '{}'
    int_0 = -20
    tuple_0 = (2, 3)
    list_0 = []
    dict_0 = {tuple_0: list_0}
    maybe_0 = Maybe(dict_0, False)
    lazy_0 = maybe_0.to_lazy()
    try:
        val = lazy_0.value
    except Exception as e:
        assert False, e
    assert dict_0 == val



# Generated at 2022-06-26 00:02:25.925934
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    bool_0 = True
    try_0 = Maybe.just(bool_0)
    lazy_0 = try_0.to_lazy()


# Generated at 2022-06-26 00:02:28.739933
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()

    assert lazy.value() == 1

    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()

    assert lazy.value() is None


# Generated at 2022-06-26 00:02:31.941538
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Maybe[str].to_lazy() = Lazy[str]
    maybe_0 = Maybe(3, False)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.__class__ == Maybe[T]
