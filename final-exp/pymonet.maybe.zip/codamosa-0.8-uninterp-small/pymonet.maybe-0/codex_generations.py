

# Generated at 2022-06-25 23:53:10.970084
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_1 = 'N}H3c!^19f$v(Nw!'
    str_0 = '0,U6Us4`6)h[P*O(@'
    bool_0 = True
    maybe_0 = Maybe(str_1, bool_0)
    maybe_1 = Maybe(str_0, bool_0)
    bool_1 = maybe_1.__eq__(maybe_0)
    assert bool_1 is False


# Generated at 2022-06-25 23:53:16.101138
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'H1>'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = 'f'
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    bool_2 = maybe_0 == maybe_1
    str_2 = '@Wa'
    bool_4 = True
    maybe_2 = Maybe(str_2, bool_4)
    bool_5 = maybe_0 == maybe_2
    assert bool_2
    assert bool_5


# Generated at 2022-06-25 23:53:28.177005
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test data
    str_0 = '1.0'
    bool_0 = False
    str_1 = ''
    bool_1 = True
    str_2 = '1.0'
    bool_2 = False
    str_3 = '1.0'
    bool_3 = True
    str_4 = '1.0'
    bool_4 = True
    str_5 = '1.0'
    bool_5 = True
    str_6 = '1.0'
    bool_6 = False
    str_7 = '1.0'
    bool_7 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = Maybe(str_1, bool_1)
    maybe_2 = Maybe(str_2, bool_2)
    maybe_3 = Maybe

# Generated at 2022-06-25 23:53:33.250199
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'vD^7xu8}=gVr'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = 'S*?_=E+0:wqj'
    bool_1 = True
    maybe_1 = Maybe(str_1, bool_1)
    bool_0 = maybe_0 == maybe_1
    assert maybe_0.value == str_0


# Generated at 2022-06-25 23:53:38.897828
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Yc-;Og(J4*4$|s4t'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0.value, str)
    assert lazy_0.value == 'Yc-;Og(J4*4$|s4t'


# Generated at 2022-06-25 23:53:45.603675
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'z1:^nnA>M^ro'
    bool_0 = True
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = 'z1:^nnA>M^ro'
    bool_1 = True
    maybe_1 = Maybe(str_1, bool_1)
    var_0 = maybe_0.__eq__(maybe_1)


# Generated at 2022-06-25 23:53:51.587169
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'jHPn/1:^nnA>M^ro'
    bool_0 = False
    bool_1 = bool_0
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = Maybe(str_0, bool_1)
    assert (maybe_0 == maybe_1)


# Generated at 2022-06-25 23:54:02.128007
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = ':^K#fNGG#>].J|'
    maybe_0 = Maybe.just(str_0)
    str_1 = ':^K#fNGG#>].J|'
    maybe_1 = Maybe.just(str_1)
    str_2 = ':^K#fNGG#>].J|'
    maybe_2 = Maybe.just(str_2)
    str_3 = '~TzE($eJy[^bf9s)'
    maybe_3 = Maybe.just(str_3)
    assert maybe_0 == maybe_1
    assert maybe_0.__eq__(maybe_2)
    assert maybe_0.__eq__(maybe_3) is False


# Generated at 2022-06-25 23:54:11.304980
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'P^ee99Rp}#j`H{`<]`'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    str_1 = 'P^ee99Rp}#j`H{`<]`'
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)

    bool_2 = bool_0 == bool_1

    bool_3 = maybe_0 == maybe_1

    assert (bool_2 == bool_3)


# Generated at 2022-06-25 23:54:22.237794
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = 'jHPn/1:^nnA>M^ro'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = 'jHPn/1:^nnA>M^ro'
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    assert maybe_0 == maybe_1
    str_2 = 'jHPn/1:^nnA>M^ro'
    bool_2 = False
    maybe_2 = Maybe(str_2, bool_2)
    str_3 = 'I/Hv3qrj24#'
    bool_3 = True
    maybe_3 = Maybe(str_3, bool_3)
    assert maybe_2 != maybe_3

# Generated at 2022-06-25 23:54:30.158151
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def _function(x):
        return False
    maybe_0 = Maybe.just(Maybe.just(None).get_or_else(True))
    bool_0 = maybe_0.filter(_function).is_nothing
    assert bool_0 == True


# Generated at 2022-06-25 23:54:38.726890
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'jHPn/1:^nnA>M^ro'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.map(lambda x: x + 'AA')
    maybe_2 = maybe_1.map(lambda x: x + 'BC')
    bool_1 = True
    maybe_3 = Maybe(str_0, bool_1)
    maybe_4 = maybe_3.filter(lambda x: len(x) > 1)
    bool_2 = maybe_4.is_nothing
    bool_3 = maybe_1 == maybe_2
    str_1 = maybe_2.get_or_else('jHPn/1:^nnA>M^roAABC')

# Generated at 2022-06-25 23:54:43.104860
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = 'lUz:1,VGy^3q0d'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:54:52.142199
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'N&'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = '_&F0FY'
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    def filterer(value: str) -> bool:
        return value == '_&F0FY'
    maybe_value_0 = maybe_1.filter(filterer)
    maybe_value_1 = maybe_0.filter(filterer)
    # Check if maybe_value_0 is equal to maybe_1
    assert maybe_value_0 == maybe_1
    # Check if maybe_value_1 is equal to Maybe.nothing()
    assert maybe_value_1 == Maybe.nothing()


# Generated at 2022-06-25 23:54:55.822225
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '6%G$+dgT1T'
    bool_0 = True
    maybe_0 = Maybe(str_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:55:01.884568
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just('')
    assert maybe_0.filter(lambda v: True) == Maybe.just('')
    maybe_1 = Maybe.just('')
    assert maybe_1.filter(lambda v: False) == Maybe.nothing()
    assert maybe_1.filter(lambda v: True) == Maybe.just('')


# Generated at 2022-06-25 23:55:08.599180
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test Maybe.to_lazy method.
    """
    str_0 = 'k/Ot'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.to_lazy()
    str_1 = maybe_1.value()


# Generated at 2022-06-25 23:55:12.922669
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = 'jHPn/1:^nnA>M^ro'
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get() is maybe_0.value


# Generated at 2022-06-25 23:55:23.765552
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_0 = 'b'
    var_1 = 'a'
    maybe_0 = Maybe(var_0, var_1)
    var_2 = False
    var_3 = 'c'
    var_4 = False
    maybe_1 = Maybe(var_2, var_3)
    var_5 = 'z'
    maybe_2 = Maybe(var_4, var_5)
    var_6 = maybe_1.filter(lambda x: x)
    var_7 = maybe_0.filter(maybe_2.ap)
    var_8 = maybe_2.filter(lambda x: x)
    var_9 = maybe_2.filter(lambda x: x)
    var_10 = maybe_2.filter(lambda x: x)

# Generated at 2022-06-25 23:55:29.582434
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'd$"r'
    maybe_0 = Maybe.just(str_0)
    maybe_1 = maybe_0.filter(lambda x: x == 'd$"r')
    assert maybe_1 == Maybe.just(str_0)


# Generated at 2022-06-25 23:55:37.657958
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 'test_value'
    monad = Maybe.just(test_value)
    lazy = monad.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == test_value

    monad = Maybe.nothing()
    lazy = monad.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == None


# Generated at 2022-06-25 23:55:50.320903
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    assert Maybe.just(None).filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda x: x) == Maybe.just(None)
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)
    assert Maybe.just(False).filter(lambda x: x) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()

    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()

# Generated at 2022-06-25 23:56:00.307826
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    def test_mapper(val):
        return val.lower()

    def test_filterer(val):
        return val == 'B'

    assert Maybe.just(None).filter(test_filterer).to_box() == Box(None)
    assert Maybe.just(3).filter(test_filterer).to_box() == Box(None)
    assert Maybe.just('A').filter(test_filterer).to_box() == Box(None)

# Generated at 2022-06-25 23:56:09.127544
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    var_0 = Maybe.just(11)
    var_1 = Maybe.nothing()

    var_2 = var_0.to_lazy()
    var_2 = var_2.get()

    var_3 = var_1.to_lazy()
    var_3 = var_3.get()

    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = False
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = True
    bool_8 = True
    bool_9 = True
    bool_10 = True

    if (var_1.is_nothing):
        bool_0 = True
    else:
        bool_0 = False
    if (var_0.is_nothing):
        bool_1

# Generated at 2022-06-25 23:56:12.833497
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    _x = Maybe.just(1)
    _y = _x.to_lazy()
    _z = _y.value()
    assert _z == 1


# Generated at 2022-06-25 23:56:23.106453
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy().value() == 1
    assert Maybe.nothing().to_lazy().value() == None

    if bool_0:
        assert Lazy(lambda: None).value() == var_0
        assert Lazy(lambda: 1).value() == 1
        # assert Lazy(lambda: 2).value() == 1 # Fails
        if bool_0:
            assert Lazy(lambda: 1).value() == 1
        else:
            assert Lazy(lambda: None).value() == var_0

    if bool_0:
        assert Lazy(lambda: 1).value() == 1
        assert Lazy(lambda: 1).value() == 1
    else:
        assert Lazy(lambda: None).value() == var_0


# Generated at 2022-06-25 23:56:25.277820
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    var_0 = Maybe.just(1)
    result_0 = var_0.to_lazy()
    bool_0 = True


# Generated at 2022-06-25 23:56:29.193510
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create Maybe<Integer> monad with value 3
    maybe = Maybe.just(3)
    assert maybe.value == 3
    # Convert Maybe to Lazy
    lazy_monad = maybe.to_lazy()
    assert lazy_monad._value() == 3


# Generated at 2022-06-25 23:56:34.822302
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_0 = Maybe.just(1).filter(lambda x: x > 0)  # Maybe[1]
    var_1 = Maybe.just(1).filter(lambda x: x < 0)  # Maybe[None]

    if type(var_0) == Maybe and var_0.get_or_else(0) == 1 and var_1 != Maybe and var_1.get_or_else(0) == 0:
        return True
    return False



# Generated at 2022-06-25 23:56:38.922430
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(0)
    maybe_0 = Maybe.just(-1)
    maybe_0 = Maybe.just(-2)


# Generated at 2022-06-25 23:56:46.015412
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: a & 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: not a & 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: not a & 1) == Maybe.nothing()


# Generated at 2022-06-25 23:56:52.230874
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3

    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)

    maybe_3 = maybe_0.filter(lambda x: x > 1)
    maybe_4 = maybe_1.filter(lambda x: x > 1)
    maybe_5 = maybe_2.filter(lambda x: x > 1)

    assert maybe_3 == Maybe.nothing()
    assert maybe_4 == Maybe.just(2)
    assert maybe_5 == Maybe.just(3)


# Generated at 2022-06-25 23:57:03.371425
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.just(int_0)
    if maybe_int_0 != maybe_int_1:
        raise AssertionError('test_Maybe_filter failed')
    int_1 = 2
    maybe_int_2 = maybe_int_0.filter(lambda int_2: int_2 == int_1)
    if not maybe_int_2.is_nothing:
        raise AssertionError('test_Maybe_filter failed')
    maybe_int_0 = Maybe.nothing()
    maybe_int_1 = maybe_int_0.filter(lambda int_1: int_1 == int_0)

# Generated at 2022-06-25 23:57:07.032895
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1

    Maybe_0 = Maybe.just(int_0)
    lazy_0 = Maybe_0.to_lazy()
    assert lazy_0.value() == 1


# Generated at 2022-06-25 23:57:09.886666
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:14.377771
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2

    # test filter with True result
    maybe = Maybe.just(int_1)
    maybe = maybe.filter(lambda x: x == 1)
    maybe1 = Maybe.just(int_1)

    assert maybe == maybe1



# Generated at 2022-06-25 23:57:21.284577
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # define mapper function
    def add_one(x: int) -> int:
        return x + 1

    def filterer(x: int) -> bool:
        return x > 2

    # initialize Maybe monad and call map
    maybe_0 = Maybe.just(int_0)
    result_0 = maybe_0.map(add_one)
    result_0 = result_0.filter(filterer)

    # initialize Maybe monad and call bind
    maybe_1 = Maybe.just(int_0)
    result_1 = maybe_1.bind(lambda x: Maybe.just(add_one(x)))
    result_1 = result_1.filter(filterer)

    assert result_0 == result_1



# Generated at 2022-06-25 23:57:31.488682
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test for method filter when maybe is not empty and filterer returns True
    v1 = Maybe.just(3)
    v2 = v1.filter(lambda x: True)
    assert type(v2) == Maybe
    assert v1 == v2
    assert not v2.is_nothing
    assert v2.value == 3
    # Test for method filter when maybe is not empty and filterer returns False
    v1 = Maybe.just(3)
    v2 = v1.filter(lambda x: False)
    assert type(v2) == Maybe
    assert v2.is_nothing
    assert v2.value == None
    # Test for method filter when maybe is empty and filterer returns True or False
    v1 = Maybe.nothing()
    v2 = v1.filter(lambda x: True)
    assert type

# Generated at 2022-06-25 23:57:38.692162
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    def add_two(value):
        return value + 2

    assert isinstance(Maybe.just(add_two).ap(Maybe.just(2)).to_lazy(), Functor)
    assert Maybe.just(add_two).ap(Maybe.just(2)).to_lazy() == Lazy(lambda: add_two(2))
    assert isinstance(Maybe.nothing().to_lazy(), Functor)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:41.382082
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()
    maybe_0 = maybe_0.filter(lambda x: not x)
    maybe_1 = maybe_1.filter(lambda x: not x)
    assert maybe_0 == Maybe.nothing()
    assert maybe_1 == Maybe.nothing()


# Generated at 2022-06-25 23:57:52.305479
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from __init__ import assert_equal

    # Testing method filter of class Maybe
    assert_equal(Maybe.just(int_0).filter(lambda x: False), Maybe.nothing())
    assert_equal(Maybe.just(int_0).filter(lambda x: True), Maybe.just(int_0))
    assert_equal(Maybe.just(int_0).filter(lambda x: False), Maybe.nothing())
    assert_equal(Maybe.just(int_0).filter(lambda x: True), Maybe.just(int_0))
    

# Generated at 2022-06-25 23:57:56.122292
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 4) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x > 14) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 4) == Maybe.nothing()


# Generated at 2022-06-25 23:58:02.882326
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Create Maybe some instance
    maybe_0 = Maybe.just(1)

    # Check filter result for Maybe some instance
    assert maybe_0.filter(lambda elem: elem == 1) == Maybe.just(1)

    # Create Maybe some instance
    maybe_1 = Maybe.nothing()

    # Check filter result for Maybe some instance
    assert maybe_1.filter(lambda elem: True) == Maybe.nothing()

    # Create Maybe some instance
    maybe_2 = Maybe.just(1)

    # Check filter result for Maybe some instance
    assert maybe_2.filter(lambda elem: False) == Maybe.nothing()



# Generated at 2022-06-25 23:58:07.687932
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    import pymonet.maybe as maybe

    # Create Maybe[int] with value 0
    maybe_int_0 = maybe.Maybe.just(0)

    # Create Maybe[int] with value 1
    maybe_int_1 = maybe.Maybe.just(1)

    # Create empty Maybe[int]
    maybe_int_empty = maybe.Maybe.nothing()

    # Filter values which are bigger than 0 and append this values to list
    maybe_int_filter_0 = [
        maybe_int_0.filter(lambda val: val > 0),
        maybe_int_1.filter(lambda val: val > 0),
        maybe_int_empty.filter(lambda val: val > 0)
    ]

    # Filter values which are bigger than 1 and append this values to list

# Generated at 2022-06-25 23:58:12.806700
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    # Test case 0
    test_Maybe0 = Maybe(1, False)
    test_Lazy0 = test_Maybe0.to_lazy()

    assert test_Maybe0 == test_Lazy0.value()


# Generated at 2022-06-25 23:58:17.965885
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Maybe(1, False).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.__repr__() == 'Lazy(callable_object=<function Maybe.to_lazy.<locals>.<lambda> at 0x06A67A70>)'


# Generated at 2022-06-25 23:58:24.721940
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    <code>
    result = int_0.filter(lambda x: x > 2)
    </code>

    <code>
    assert result == Maybe.nothing()
    </code>
    <code>
    result = int_0.filter(lambda x: x > 0)
    </code>

    <code>
    assert result == Maybe.just(1)
    </code>
    """
    result = int_0.filter(lambda x: x > 2)
    assert result == Maybe.nothing()


# Generated at 2022-06-25 23:58:28.109123
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(int_0).filter(lambda x: x == int_0) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(lambda x: x == -1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == int_0) == Maybe.nothing()


# Generated at 2022-06-25 23:58:33.182890
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pytest

    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(10)
    expected_0 = Lazy(lambda: 10)
    assert maybe_0.to_lazy() == expected_0


# Generated at 2022-06-25 23:58:38.161816
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_test_1 = Maybe.just(1)
    maybe_test_2 = Maybe.nothing()
    print("test_Maybe_to_lazy")
    print("maybetest1", maybe_test_1.to_lazy())
    print("maybetest2", maybe_test_2.to_lazy())


# Generated at 2022-06-25 23:58:52.824738
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int_0 = Maybe.just(1)
    maybe_int_1 = Maybe.nothing()

    def filterer_0(value):
        return True

    def filterer_1(value):
        return False

    assert maybe_int_0.filter(filterer_0) is not maybe_int_0
    assert maybe_int_0.filter(filterer_1) is not maybe_int_0
    assert maybe_int_1.filter(filterer_0) is not maybe_int_1
    assert maybe_int_1.filter(filterer_1) is not maybe_int_1

    assert maybe_int_0.filter(filterer_0) == Maybe.just(1)
    assert maybe_int_0.filter(filterer_1) == Maybe.nothing()
   

# Generated at 2022-06-25 23:58:54.925600
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    instance = Maybe.just(1)
    assert instance.to_lazy().value() == 1


# Generated at 2022-06-25 23:59:01.246100
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Case 0:
    try:
        # Arrange
        int_0 = 1

        # Act
        maybe_monad_0 = Maybe.just(int_0)
        lazy_monad_0 = maybe_monad_0.to_lazy()

        # Assert
        assert lazy_monad_0.get_value() == int_0
    except:
        raise AssertionError()


# Generated at 2022-06-25 23:59:08.039217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda int_1: int_1 < 2)
    maybe_2 = maybe_0.filter(lambda int_1: int_1 > 2)
    maybe_3 = Maybe.nothing()
    maybe_4 = maybe_3.filter(lambda int_1: True)
    assert maybe_1 != maybe_2
    assert maybe_4.is_nothing



# Generated at 2022-06-25 23:59:15.359486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_box_int_0 = Maybe.just(1)
    maybe_lazy_int_0 = maybe_box_int_0.to_lazy()
    maybe_boxed_int_0 = maybe_lazy_int_0.value()

    assert maybe_lazy_int_0 == maybe_lazy_int_0 == Maybe.just(1)
    assert maybe_boxed_int_0 == maybe_boxed_int_0 == Maybe.just(1)
    assert maybe_lazy_int_0 == maybe_boxed_int_0
    assert maybe_boxed_int_0 == maybe_lazy_int_0
    assert maybe_lazy_int_0.value() == Maybe.just(1)


# Generated at 2022-06-25 23:59:18.576438
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)

    def filter_function(obj):
        return obj > 0

    maybe_0 = maybe_0.filter(filter_function)

    assert maybe_0 == Maybe.just(1)



# Generated at 2022-06-25 23:59:26.933485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    import pymonet.maybe
    def filterer(x): return True
    def filterer(x): return False
    def filterer(x): return x > 0
    # No input, check type of output
    result = pymonet.maybe.Maybe.just(int_0).filter(filterer)
    assert isinstance(result, pymonet.maybe.Maybe)
    # Check empty Maybe
    result = pymonet.maybe.Maybe.nothing().filter(filterer)
    assert result == pymonet.maybe.Maybe.nothing()
    # Check Maybe with negative value
    result = pymonet.maybe.Maybe.just(-1).filter(filterer)
    assert result == pymonet.maybe.Maybe.nothing()
    # Check Maybe with 0 value
    result = pymonet.maybe.Maybe.just

# Generated at 2022-06-25 23:59:37.624019
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print("Test filter:", end="")

    # Setup
    int_0 = 1
    list_0 = [int_0, 2, 3, 4]
    int_1 = 5
    maybe_0 = Maybe.just(int_0)
    result_0 = maybe_0.filter(
        lambda value: value in list_0
    )
    expected_0 = Maybe.just(int_0)

    maybe_1 = Maybe.just(int_1)
    result_1 = maybe_1.filter(
        lambda value: value in list_0
    )
    expected_1 = Maybe.nothing()

    maybe_2 = Maybe.nothing()
    result_2 = maybe_2.filter(
        lambda value: value in list_0
    )
    expected_2 = Maybe.nothing()

    # Exercise

# Generated at 2022-06-25 23:59:40.922827
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-25 23:59:43.894485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just('1').filter(lambda x: x in '123') == Maybe.just(
        '1'
    )



# Generated at 2022-06-25 23:59:54.806906
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_int_0 = Maybe.just(int_0)
    maybe_lazy_int_0 = maybe_int_0.to_lazy()
    lazy_int_0 = maybe_lazy_int_0.value
    int_1 = lazy_int_0()
    int_0 = int_1
    return int_0


# Generated at 2022-06-26 00:00:00.470202
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test is not empty Maybe and filter returns True
    value = Maybe.just(10).filter(lambda x: x % 2 == 0)
    assert value == Maybe.just(10)

    # Test is not empty Maybe and filter returns False
    value = Maybe.just(1).filter(lambda x: x % 2 == 0)
    assert value == Maybe.nothing()

    # Test is empty Maybe
    value = Maybe.nothing().filter(lambda x: x % 2 == 0)
    assert value == Maybe.nothing()


# Generated at 2022-06-26 00:00:12.168189
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = Maybe.just(1)
    int_2 = Maybe.just(2)
    int_3 = Maybe.just(3)
    empty = Maybe.nothing()

    assert int_1.filter(lambda x: x == 1) == Maybe.just(1)
    assert int_1.filter(lambda x: x > 1) == Maybe.nothing()
    assert empty.filter(lambda x: x == 1) == Maybe.nothing()

    assert int_1.filter(lambda x: x == 1).get_or_else(int_2) == Maybe.just(1)
    assert int_1.filter(lambda x: x > 1).get_or_else(int_2) == Maybe.just(2)

# Generated at 2022-06-26 00:00:21.754536
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Case 0
    int_0 = 1
    maybe_int_0 = Maybe.just(int_0)
    filterer_0 = lambda x: x == int_0
    result_0 = maybe_int_0.filter(filterer_0)
    expected_result_0 = maybe_int_0
    condition_0 = result_0 == expected_result_0
    assert condition_0, "filter_case_0: results don't match"

    # Case 1
    int_1 = 1
    maybe_int_1 = Maybe.just(int_1)
    filterer_1 = lambda x: x != int_1
    result_1 = maybe_int_1.filter(filterer_1)
    expected_result_1 = Maybe.nothing()
    condition_1 = result_1 == expected_result

# Generated at 2022-06-26 00:00:26.691832
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing() and \
        Maybe.just(0).filter(lambda x: True) == Maybe.just(0) and \
        Maybe.just(0).filter(lambda x: False) == Maybe.nothing()
    return True


# Generated at 2022-06-26 00:00:35.737492
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    for int_0 in range(64):
        int_1 = rng_int()
        boolean_0 = rng_boolean()
        if boolean_0:
            maybe_0 = Maybe.nothing()
        else:
            maybe_0 = Maybe.just(int_1)

        maybe_1 = maybe_0.filter(lambda  int_2: int_2 > int_0)

        if not maybe_0.is_nothing:
            if maybe_0.value > int_0:
                assert maybe_1.value == maybe_0.value
            else:
                assert maybe_1.is_nothing
        else:
            assert maybe_0.is_nothing == maybe_1.is_nothing


# Generated at 2022-06-26 00:00:39.677829
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_int_0 = Maybe.just(int_0)
    lazy_maybe_int_0 = maybe_int_0.to_lazy()

    assert maybe_int_0 is not lazy_maybe_int_0
    assert lazy_maybe_int_0.value() is int_0

# Test compatibility with other monads

# Generated at 2022-06-26 00:00:41.144934
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = Maybe.just(6)
    assert int_0.filter(lambda value: value < 10) == Maybe.just(6)


# Generated at 2022-06-26 00:00:50.583967
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = Maybe.just(1).filter(lambda value: value == 1)
    int_2 = Maybe.just(2).filter(lambda value: value == 1)
    int_1_empty = Maybe.nothing().filter(lambda value: value == 1)

    int_1_checked = isinstance(int_1, Maybe) and int_1.get_or_else(None) == 1
    int_2_checked = isinstance(int_2, Maybe) and int_2.get_or_else(None) is None
    int_1_empty_checked = isinstance(int_1_empty, Maybe) and int_1_empty.get_or_else(None) is None
    return int_1_checked and int_2_checked and int_1_empty_checked


# Generated at 2022-06-26 00:00:58.092093
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def some_if_more_then_3(value):
        return value > 3
    maybe = Maybe.just(10)
    value = 10
    assert maybe.filter(some_if_more_then_3) == Maybe.just(value), "Filter function for Maybe doesn't work. Test failed!"
    maybe = Maybe.just(1)
    assert maybe.filter(
        some_if_more_then_3
    ) == Maybe.nothing(), "Filter function for Maybe doesn't work. Test failed!"
    maybe = Maybe.nothing()
    assert maybe.filter(
        some_if_more_then_3
    ) == Maybe.nothing(), "Filter function for Maybe doesn't work. Test failed!"



# Generated at 2022-06-26 00:01:22.871373
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    (Maybe.just(1)
         .filter(lambda x: x < 2)
         .filter(lambda x: x > -1)
         .filter(lambda x: x == 1)
         .get_or_else(None)
    ) == 1

    (Maybe.just(1)
         .filter(lambda x: x < 0)
         .filter(lambda x: x > -1)
         .filter(lambda x: x == 1)
         .get_or_else(None)
    ) == None

    (Maybe.nothing()
         .filter(lambda x: x < 2)
         .filter(lambda x: x > -1)
         .filter(lambda x: x == 1)
         .get_or_else(None)
    ) == None



# Generated at 2022-06-26 00:01:30.666609
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = 1
    maybe_int_1 = Maybe.just(int_1)
    maybe_int_2 = Maybe.nothing()
    # test case when Maybe is not empty and filterer returns True
    assert maybe_int_1.filter(lambda x: x > 0) == Maybe.just(int_1)
    # test case when Maybe is not empty and filterer returns False
    assert maybe_int_1.filter(lambda x: x < 0) == Maybe.nothing()
    # test case when Maybe is empty and filterer returns True
    assert maybe_int_2.filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-26 00:01:34.745044
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Testing method filter')
    assert(Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing())
    print('Testing method filter - passed')



# Generated at 2022-06-26 00:01:43.857260
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    def pred(value):
        return value == 2
    maybe_0 = Maybe.just(2)
    maybe_1 = maybe_0.filter(pred)
    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.filter(pred)
    int_1 = maybe_1.get_or_else(False)
    maybe_4 = Maybe.just(1)
    maybe_5 = maybe_4.filter(pred)
    int_2 = maybe_5.get_or_else(True)
    int_3 = maybe_3.get_or_else(True)
    def pred_0(value):
        return value == 1
    maybe_6 = Maybe.just(1)
    maybe_7 = maybe_6.filter(pred_0)
    int_4 = maybe

# Generated at 2022-06-26 00:01:46.985262
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(1)
    maybe_1 = maybe_0.filter(lambda value: value > 0)
    assert (maybe_0 != maybe_1)


# Generated at 2022-06-26 00:01:49.623163
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    lazy = maybe_0.to_lazy()
    assert lazy.get_value() == 1


# Generated at 2022-06-26 00:01:53.469805
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = Maybe.just(int_0).filter(lambda x: x != 1)
    int_1 = Maybe.just(int_0 + 1).filter(lambda x: x != 1)
    assert int_0 == Maybe.nothing()
    assert int_1 == Maybe.just(2)


# Generated at 2022-06-26 00:02:02.603278
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def assert_equal(expected: Maybe[int], actual: Maybe[int]) -> None:
        if expected != actual:
            raise AssertionError(f'expected: {expected} actual: {actual}')

    int_1 = 1

    assert_equal(
        Maybe.just(int_1).filter(lambda x: x == 1),
        Maybe.just(int_1)
    )

    assert_equal(
        Maybe.just(int_1).filter(lambda x: x == 2),
        Maybe.nothing()
    )

    assert_equal(
        Maybe.nothing().filter(lambda x: x == 1),
        Maybe.nothing()
    )


# Generated at 2022-06-26 00:02:10.848882
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.maybe import Maybe

    # condition for filter
    is_even = lambda value: value % 2 == 0

    # test with None
    maybe_none = Maybe.nothing()
    maybe_none_filtered = maybe_none.filter(is_even)

    assert maybe_none == maybe_none_filtered, 'Filter for Maybe should not change instance when value is None'

    # test with even number
    maybe_int_0 = Maybe.just(2)
    maybe_int_0_filtered = maybe_int_0.filter(is_even)

    assert maybe_int_0 == maybe_int_0_filtered, 'Filter for Maybe should not change instance when condition is True'

    # test with odd number
    maybe_int_1 = Maybe.just(3)
    maybe_int_1_filtered = maybe

# Generated at 2022-06-26 00:02:14.982038
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    l0 = Maybe.just(1).to_lazy()
    l1 = Maybe.nothing().to_lazy()

    assert type(l0) == Lazy
    assert type(l1) == Lazy
    assert l0.value() == 1
    assert l1.value() == None


# Generated at 2022-06-26 00:02:41.923447
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    pass

# Generated at 2022-06-26 00:02:48.850989
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(x):
        return x % 2 == 0

    assert Maybe.just(10).filter(is_even).get_or_else(21) == 10
    assert Maybe.just(11).filter(is_even).get_or_else(21) == 21
    assert Maybe.nothing().filter(is_even).get_or_else(21) == 21

    print("test_Maybe_filter: OK")


# Generated at 2022-06-26 00:02:51.032886
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get_value() == 1



# Generated at 2022-06-26 00:02:53.213494
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    x = Maybe.just(1)
    y = x.filter(lambda x: x > 0)
    assert y == Maybe.just(1)


# Generated at 2022-06-26 00:02:56.354921
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_of_int = Maybe.just(int_0)
    lazy = maybe_of_int.to_lazy()
    assert lazy() == int_0
    assert lazy.__class__.__name__ == "Lazy"


# Generated at 2022-06-26 00:03:01.559523
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    nothing = Maybe.nothing()
    just = Maybe.just(1)

    # when just filter
    def filter_t(x):
        return True if x > 0 else False
    assert just.filter(filter_t) == just

    # when just not filter
    def filter_f(x):
        return False if x > 0 else True
    assert just.filter(filter_f) == nothing

    # when nothing
    assert nothing.filter(filter_t) == nothing
