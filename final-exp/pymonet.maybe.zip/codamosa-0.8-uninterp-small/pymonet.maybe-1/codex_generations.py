

# Generated at 2022-06-25 23:53:10.289120
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_filter_0(mapper: Any) -> bool:
        return True
    maybe_0 = Maybe.just(1)
    maybe_0_copy_0 = maybe_0.filter(test_filter_0)
    maybe_1 = Maybe.nothing()
    maybe_1_copy_0 = maybe_1.filter(test_filter_0)
    # Assert maybe_0_copy_0.is_nothing == False
    # Assert maybe_1_copy_0.is_nothing == True


# Generated at 2022-06-25 23:53:13.418560
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    callable_0 = lambda arg: False
    maybe_1 = maybe_0.filter(callable_0)


# Generated at 2022-06-25 23:53:17.098267
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()
    assert lazy.value() == 1

    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    assert lazy.value() is None



# Generated at 2022-06-25 23:53:28.304942
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_1 = True
    maybe_1 = Maybe(object_1, bool_1)
    object_2 = module_0.object()
    bool_2 = False
    maybe_2 = Maybe(object_2, bool_2)

    # not equal
    assert maybe_0 != maybe_1
    assert maybe_0 != maybe_2
    assert maybe_1 != maybe_2

    # equal to self
    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1
    assert maybe_2 == maybe_2


# Generated at 2022-06-25 23:53:31.406403
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    object_0 = module_0.object()
    bool_0 = True
    maybe_0 = Maybe(object_0, bool_0)
    bool_1 = False
    maybe_1 = maybe_0.filter(lambda _: bool_1)


# Generated at 2022-06-25 23:53:36.913029
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_1 = False
    maybe_1 = Maybe(object_1, bool_1)
    object_2 = module_0.object()
    bool_2 = True
    maybe_2 = Maybe(object_2, bool_2)
    assert (maybe_0 == maybe_1) == False
    assert (maybe_0 == maybe_2) == False
    assert (maybe_1 == maybe_2) == False


# Generated at 2022-06-25 23:53:46.501142
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0);
    object_1 = module_0.object()
    bool_1 = False
    maybe_1 = Maybe(object_1, bool_1);
    object_2 = module_0.object()
    bool_2 = False
    maybe_2 = Maybe(object_2, bool_2);
    bool_3 = maybe_0.__eq__(maybe_1);
    if (bool_3):
        if (maybe_1.__eq__(maybe_2)):
            if (maybe_2.__eq__(maybe_0)):
                bool_4 = True
                if bool_4:
                    print(bool_4)
        else:
            bool_4 = False
           

# Generated at 2022-06-25 23:53:51.157729
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-25 23:53:57.530309
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_1 = False
    maybe_1 = Maybe(object_1, bool_1)
    assert maybe_0 == maybe_1



# Generated at 2022-06-25 23:54:03.256674
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_0 = Maybe.just(3).to_lazy()
    maybe_1 = Maybe.nothing().to_lazy()

    assert maybe_0.value() == 3
    assert maybe_1.value() is None


# Generated at 2022-06-25 23:54:11.768757
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(int_0) == Maybe.nothing()
    assert Maybe.just(int_0) == Maybe.just(int_0)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(int_0) == Maybe.just(int_0)


# Generated at 2022-06-25 23:54:14.790987
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(
        lambda i: i == 3
    ) == Maybe.just(3)


# Generated at 2022-06-25 23:54:16.306671
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    test_case_0()
    assert Maybe.just(42) == Maybe.just(42)


# Generated at 2022-06-25 23:54:27.276304
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # sould return successfully Lazy object
    #
    #     test_Maybe_to_lazy :: Maybe[Any] -> Lazy[Function0[Any]]
    #     test_Maybe_to_lazy maybe =
    #         case maybe of
    #             Nothing => Lazy(value=lambda: None)
    #             Just({ value }) => Lazy(value=lambda: value)
    #
    rv = Maybe.just(3).to_lazy()
    assert isinstance(rv, Lazy)
    assert rv.value() == 3
    assert Maybe.nothing().to_lazy().value() == None


# Generated at 2022-06-25 23:54:31.615304
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_0)
    assertion_0 = maybe_0 == maybe_1
    assert assertion_0


# Generated at 2022-06-25 23:54:33.036077
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    Maybe.just(1).__eq__(Maybe.just(1))


# Generated at 2022-06-25 23:54:44.711628
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    # case 0
    # Set up
    data = 3
    mapper = lambda x: x == 3
    expected_result = Maybe.just(data)

    # Run
    maybe = Maybe.just(data)
    result = maybe.filter(mapper)

    # Assert
    assert expected_result == result

    # case 1
    # Set up
    data = 3
    mapper = lambda x: x == 6
    expected_result = Maybe.nothing()

    # Run
    maybe = Maybe.just(data)
    result = maybe.filter(mapper)

    # Assert
    assert expected_result == result

    #

# Generated at 2022-06-25 23:54:47.634524
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    box_0 = Maybe.just(int_0)
    box_1 = Maybe.just(int_0)
    assert box_0 == box_1


# Generated at 2022-06-25 23:54:49.717743
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(9) == Maybe.just(9)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-25 23:54:58.753068
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(14)
    maybe_1 = maybe_0.filter(lambda val: val % 2 == 0)
    assert maybe_1 == Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda val: val % 2 != 0)
    assert maybe_2 == Maybe.just(14)
    maybe_3 = Maybe.nothing()
    maybe_4 = maybe_3.filter(lambda val: val % 2 == 0)
    assert maybe_4 == Maybe.nothing()
    maybe_5 = maybe_3.filter(lambda val: val % 2 != 0)
    assert maybe_5 == Maybe.nothing()


# Generated at 2022-06-25 23:55:03.984183
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)

    maybe_0.to_lazy()


# Generated at 2022-06-25 23:55:10.478484
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Preconditions
    value = Maybe.just(3)
    filterer = lambda x: x > 2
    expected_value = Maybe.just(3)
    # Test action
    actual_value = value.filter(filterer)
    # Assertions
    assert actual_value == expected_value


# Generated at 2022-06-25 23:55:14.876397
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    class_0 = Maybe.something(int_0).filter(lambda m0: m0 == int_0)
    assert class_0.value == int_0
    class_1 = Maybe.nothing().filter(lambda m1: m1 == int_0)
    assert class_1.is_nothing


# Generated at 2022-06-25 23:55:22.952949
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    case_0 = Maybe.just(3)
    case_1 = Maybe.just(2)
    case_2 = Maybe.nothing()

    case_0_result = case_0.filter(lambda v: v >= 3)
    case_1_result = case_1.filter(lambda v: v >= 3)
    case_2_result = case_2.filter(lambda v: v >= 3)

    assert case_0_result == Maybe.just(3)
    assert case_1_result == Maybe.nothing()
    assert case_2_result == Maybe.nothing()


# Generated at 2022-06-25 23:55:29.997436
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    def f_0(x_0: int) -> bool:
        return x_0 <= 3
    maybe_1 = maybe_0.filter(f_0)
    assert maybe_1.is_nothing==False
    assert maybe_1.value==int_0



# Generated at 2022-06-25 23:55:33.434775
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_1 = 3
    m_1 = Maybe.just(int_1)
    int_2 = 3
    m_2 = Maybe.just(int_2)
    assert m_1 == m_2


# Generated at 2022-06-25 23:55:34.792639
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    monad = Maybe.just(int_0)
    monad_lazy = monad.to_lazy()
    assert int_0 == monad_lazy()


# Generated at 2022-06-25 23:55:36.853448
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(int_0) == Maybe.just(int_0)
    assert Maybe.just(int_0) != Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-25 23:55:38.748242
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_1 = Maybe.just(int_0)
    int_2 = Maybe.just(int_0)
    assert int_1 == int_2


# Generated at 2022-06-25 23:55:42.085133
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(3)
    actual = m.__eq__(m)
    assert actual == True


# Generated at 2022-06-25 23:55:56.447164
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_0)
    maybe_3 = Maybe.just(int_0)
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.nothing()
    maybe_7 = Maybe.nothing()
    maybe_8 = Maybe.just(str)
    maybe_9 = Maybe.just(str)
    maybe_10 = maybe_0
    assert (maybe_0 == maybe_1)
    assert (maybe_0 == maybe_2)
    assert (maybe_1 == maybe_2)
    assert (maybe_0 == maybe_3)

# Generated at 2022-06-25 23:55:59.389284
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-25 23:56:02.442317
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
        # Test: int_0 is not equal True
        assert Maybe(int_0, False) != True
        # Test: Nothing is equal Nothing
        assert Maybe(3, False) == Maybe(3, False)
        assert Maybe(3, True) == Maybe(3, True)

# Generated at 2022-06-25 23:56:13.483947
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_2 = Maybe.just(3)
    maybe_3 = Maybe.nothing(int_0)
    maybe_4 = Maybe.just(2)
    maybe_1 = Maybe.just((maybe_0, maybe_3))
    maybe_5 = Maybe.nothing((maybe_0, maybe_3))
    maybe_6 = Maybe.just((maybe_0, maybe_4))
    maybe_7 = Maybe.nothing((maybe_0, maybe_4))
    maybe_8 = Maybe.nothing(maybe_3)
    bool_0 = maybe_0 != maybe_2
    bool_1 = maybe_0 == maybe_2
    bool_2 = maybe_1 == maybe_4
    bool_4 = maybe_5 != maybe_6
    bool

# Generated at 2022-06-25 23:56:21.114916
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    User story: I expect that method filter of Maybe class returns new Maybe with the same value
    when filterer returns True and empty Maybe when filterer returns False.
    """
    def filterer(x: int) -> bool:
        return x == 3

    assert Maybe.just(3).filter(filterer).is_nothing == False
    assert Maybe.just(3).filter(filterer).value == 3
    assert Maybe.just(4).filter(filterer).is_nothing
    assert Maybe.nothing().filter(filterer).is_nothing


# Generated at 2022-06-25 23:56:29.708361
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = 3
    int_2 = 4

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.just(int_1)
    maybe_int_2 = Maybe.just(int_2)
    maybe_nothing_0 = Maybe.nothing()
    maybe_nothing_1 = Maybe.nothing()

    assert maybe_int_0 == maybe_int_1

    assert not maybe_int_0 == maybe_int_2

    assert maybe_int_0 != maybe_int_2

    assert maybe_nothing_0 == maybe_nothing_1

    assert not maybe_nothing_0 == maybe_int_0

    assert not maybe_nothing_0 == maybe_int_2

    assert maybe_int_0 != maybe_nothing_1

    assert maybe_int

# Generated at 2022-06-25 23:56:35.306158
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x:x>3) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x:x<3) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x:x==3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: True) == Maybe.just(3)
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-25 23:56:41.335962
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    for i in range(0, 100):
        maybe_0 = Maybe.just(int_0)
        maybe_1 = maybe_0.filter(lambda int_0: int_0 == 1)
        assert maybe_1 == Maybe.just(int_0), 'AssertionError: 6'


# Generated at 2022-06-25 23:56:44.623195
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    success = Maybe.just(int_0).to_lazy()
    assert success.force() == int_0
    failure = Maybe.nothing().to_lazy()
    assert failure.force() == None



# Generated at 2022-06-25 23:56:46.395707
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-25 23:57:03.321625
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) == Maybe.just(3)

    assert Maybe.nothing() != Maybe.just(3)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)

    assert Maybe.nothing() == Left(None)
    assert Maybe.just(3) == Left(None)

    assert Maybe.nothing() == Box(None)
    assert Maybe.just(3) == Box(None)

    assert Maybe.nothing() == Try(None, is_success=False)
    assert Maybe.just(3) == Try

# Generated at 2022-06-25 23:57:14.784527
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    import unittest

    class Maybe___eq__(unittest.TestCase):
        def test_case_0(self):
            maybe_0 = Maybe.just(3)
            maybe_1 = Maybe.just(3)
            maybe_2 = Maybe.just(3)
            self.assertTrue(maybe_0 == maybe_1 == maybe_2)
            maybe_3 = Maybe.just(5)
            self.assertFalse(maybe_0 == maybe_3)
            maybe_4 = Maybe.nothing()
            maybe_5 = Maybe.nothing()
            maybe_6 = Maybe.nothing()
            self.assertTrue(maybe_4 == maybe_5 == maybe_6)
            self.assertFalse(maybe_0 == maybe_4)
            self.assertFalse(maybe_3 == maybe_5)

    unittest.main

# Generated at 2022-06-25 23:57:17.499378
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    test_case_0()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-25 23:57:20.105628
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3

    # init Maybe
    maybe_0 = Maybe.just(int_0)

    # run test
    assert maybe_0 == maybe_0, "False (maybe_0) failed"


# Generated at 2022-06-25 23:57:30.195158
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = Maybe.just(1)
    int_1 = Maybe.just(2)
    str_2 = Maybe.just("3")

    print("Maybe.__eq__(Maybe) -> Boolean")
    print("\tassert True == int_0.__eq__(int_0))")
    print("\tassert False == int_0.__eq__(int_1))")
    print("\tassert False == int_0.__eq__(str_2))")

# Generated at 2022-06-25 23:57:33.011986
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-25 23:57:36.737742
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    expected_0 = Maybe.just(int_0)
    expected_1 = Maybe.just(int_0)

    actual_0 = expected_0.__eq__(expected_1)

    assert(actual_0 == True)


# Generated at 2022-06-25 23:57:43.542874
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = 4
    int_0_monad = Maybe.just(int_0)
    int_1_monad = Maybe.just(int_1)
    int_0_empty_monad = Maybe.nothing()

    def int_greater_than_0(value):
        return value > int_0

# Test case 1
    result = int_0_monad.filter(int_greater_than_0)

    # assert equal
    assert int_0_empty_monad == result

# Test case 2
    result = int_1_monad.filter(int_greater_than_0)

    # assert equal
    assert int_1_monad == result


# Generated at 2022-06-25 23:57:54.316424
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    int_1 = 9
    int_2 = 8
    int_3 = 8
    int_5 = 6
    int_6 = 2
    int_7 = 3
    int_9 = 5
    str_0 = 'Python is fun'
    bool_0 = bool(0)
    bool_1 = bool(1)
    bool_2 = bool(0)
    bool_3 = bool(1)
    bool_4 = bool(0)
    bool_5 = bool(1)
    bool_6 = bool(1)
    int_list_0 = [int_7, int_3, int_6, int_2, int_7, int_6, int_7, int_6, int_9, int_9]

# Generated at 2022-06-25 23:57:59.113724
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_0)

# Generated at 2022-06-25 23:58:18.643796
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = 2
    int_2 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    maybe_3 = Maybe.nothing()
    maybe_4 = Maybe.nothing()
    assert (maybe_0 == maybe_1) == False
    assert (maybe_0 == maybe_2) == True
    assert (maybe_0 == maybe_3) == False
    assert (maybe_3 == maybe_4) == True


# Generated at 2022-06-25 23:58:22.823436
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.nothing()
    m3 = Maybe.just(2)
    assert m1 == Maybe.just(1)
    assert m2 == Maybe.nothing()
    assert m1 != m2
    assert m1 != m3


# Generated at 2022-06-25 23:58:29.666682
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = Maybe.just(int_0)
    int_2 = Maybe.just(int_0)
    int_3 = Maybe.nothing()
    int_4 = Maybe.nothing()
    int_5 = Maybe.just(None)
    assert int_1 == int_2
    assert int_3 == int_4
    assert int_1 != int_3
    assert int_1 != int_4
    assert int_2 != int_3
    assert int_2 != int_4
    assert int_3 != int_1
    assert int_3 != int_2
    assert int_4 != int_1
    assert int_4 != int_2
    assert int_1 != int_5
    assert int_2 != int_5
    assert int_3 != int_5

# Generated at 2022-06-25 23:58:35.983947
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = 3
    assert Maybe.just(int_0).__eq__(Maybe.just(int_1)) == True
    assert Maybe.just(int_0).__eq__(Maybe.nothing()) == False
    assert Maybe.nothing().__eq__(Maybe.just(int_0)) == False
    assert Maybe.nothing().__eq__(Maybe.nothing()) == True


# Generated at 2022-06-25 23:58:39.898932
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3
    array_0 = (1, 2, 3)
    maybe_0 = Maybe(int_0, False)
    maybe_1 = Maybe(array_0, False)
    maybe_1.filter(lambda array_0: array_0)
    maybe_0.filter(lambda int_0: int_0)


# Generated at 2022-06-25 23:58:42.918784
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(4).to_lazy() == Lazy(lambda : 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-25 23:58:48.177341
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(3)
    maybe_2 = Maybe.just(2)
    maybe_3 = Maybe.nothing()

    assert maybe_1 == Maybe.just(3)
    assert maybe_1 != Maybe.just(2)
    assert maybe_2 == Maybe.just(2)
    assert maybe_2 != Maybe.just(3)
    assert maybe_3 == Maybe.nothing()
    assert maybe_3 != Maybe.just(2)
    assert maybe_3 != Maybe.just(3)


# Generated at 2022-06-25 23:58:56.129479
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print("Running test_Maybe___eq__")

    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just("foo") == Maybe.just("foo")
    assert Maybe.just(None) == Maybe.just(None)

    assert Maybe.just(3) != Maybe.just("3")
    assert Maybe.just("foo") != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()

    print("Done test_Maybe___eq__")


# Generated at 2022-06-25 23:59:03.730696
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(int_0) == Maybe.just(int_0)
    assert Maybe.just(float(int_0)) == Maybe.just(float(int_0))
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(int_0) == Maybe(int_0, is_nothing=False)
    assert Maybe.just(float(int_0)) == Maybe(float(int_0), is_nothing=False)
    assert Maybe.nothing() == Maybe(is_nothing=True)


# Generated at 2022-06-25 23:59:12.666850
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # example of using filter method - we have maybe of string and we would like to filter the string
    # which have length less then 10
    maybe_string = Maybe.just('string')
    maybe_filtered = maybe_string.filter(lambda string: len(string) < 10)
    assert isinstance(maybe_filtered, Maybe)
    assert maybe_filtered.get_or_else(None) == 'string'

    # example of using filter method - we have maybe of string and we would like to filter the string
    # which have length less then 3
    maybe_string = Maybe.just('string')
    maybe_filtered = maybe_string.filter(lambda string: len(string) < 3)
    assert isinstance(maybe_filtered, Maybe)
    assert maybe_filtered.get_or_else(None) is None

# Generated at 2022-06-25 23:59:23.517678
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_0)


# Generated at 2022-06-25 23:59:32.384374
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    val0 = Maybe.just(int_0)
    val1 = Maybe.just(int_0)
    val2 = Maybe.just(int_0)
    val3 = Maybe.nothing()
    val4 = Maybe.nothing()

    if not(val0 == val1):
        raise Exception('Failed : test_Maybe___eq__')

    if not(val0 == val2):
        raise Exception('Failed : test_Maybe___eq__')

    if not(val1 == val2):
        raise Exception('Failed : test_Maybe___eq__')

    if not(val3 == val4):
        raise Exception('Failed : test_Maybe___eq__')


# Generated at 2022-06-25 23:59:35.620420
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-25 23:59:39.008915
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    int_0 = 3
    int_1 = 3
    int_2 = 2

    # Exercise
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    maybe_3 = Maybe.nothing()

    # Verify
    assert maybe_0 == maybe_1
    assert maybe_0 != maybe_2
    assert maybe_0 != maybe_3



# Generated at 2022-06-25 23:59:43.894829
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 3
    maybe_of_int_0 = Maybe.just(int_0)
    value_of_maybe_of_int_0 = maybe_of_int_0.to_lazy()

    assert isinstance(value_of_maybe_of_int_0.get_or_none, type(int_0))
    assert value_of_maybe_of_int_0.get_or_none == int_0



# Generated at 2022-06-25 23:59:50.690520
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 3
    int_1 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    assert maybe_0 == maybe_1
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.nothing()
    assert maybe_2 == maybe_3
    maybe_4 = maybe_0
    assert maybe_0 == maybe_4
    assert maybe_4 == maybe_0
    maybe_5 = Maybe.just(int_0)
    assert maybe_0 == maybe_5
    assert maybe_5 == maybe_0
    assert maybe_1 == maybe_5
    assert maybe_5 == maybe_1


# Generated at 2022-06-25 23:59:55.977300
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    try_0 = Maybe.just(lambda: 3).to_lazy()
    assert isinstance(try_0, Lazy)
    try_1 = Maybe.nothing().to_lazy()
    assert isinstance(try_1, Lazy)


# Generated at 2022-06-25 23:59:56.822645
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-26 00:00:03.386151
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success
    from pymonet.either import Right
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.box import Box

    try:
        Maybe.just(int_0).to_lazy()
    except TypeError:
        assert True
        return
    assert False



# Generated at 2022-06-26 00:00:10.794891
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Unit test for method __eq__ of class Maybe
    # when parameters are equal
    int_0 = 3
    int_1 = int_0
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)

    assert maybe_0 == maybe_1

    # Unit test for method __eq__ of class Maybe
    # when parameters are not equal
    int_1 = 4

    assert maybe_0 != maybe_1


# Generated at 2022-06-26 00:00:29.015463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    bool_1 = False
    maybe_1 = Maybe(object_0, bool_1)
    bool_2 = True
    maybe_2 = Maybe(object_0, bool_2)
    bool_3 = False
    maybe_3 = Maybe(object_0, bool_3)
    bool_4 = False
    maybe_4 = Maybe(object_0, bool_4)
    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1
    assert maybe_2 == maybe_2
    assert maybe_3 == maybe_3
    assert maybe_4 == maybe_4
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_0

# Generated at 2022-06-26 00:00:31.371106
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(1)
    object_0 = object()
    bool_0 = maybe_0 == object_0


# Generated at 2022-06-26 00:00:39.459835
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(int)
    value_0 = maybe_0.to_lazy()
    value_1 = maybe_0.to_lazy()

    # AssertionError: Maybe(value=<class 'int'>, is_nothing=False)
    # AssertionError: Lazy(value=<function Maybe_to_lazy.<locals>.<lambda> at 0x7f5c6a41f8c8>)
    # AssertionError: Lazy(value=<function Maybe_to_lazy.<locals>.<lambda> at 0x7f5c6a41f9d8>)
    assert value_0 == value_1


# Generated at 2022-06-26 00:00:42.332012
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = True
    maybe_0 = Maybe(object_0, bool_0)
    bool_0 = True
    maybe_1 = Maybe(object_0, bool_0)
    bool_0 = maybe_0.__eq__(maybe_1)
    bool_1 = True
    assert bool_0 == bool_1


# Generated at 2022-06-26 00:00:51.399206
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_1 = False
    maybe_1 = Maybe(object_1, bool_1)
    bool_2 = maybe_0 == maybe_1
    assert bool_2, 'maybe_0 == maybe_1'
    bool_0 = True
    maybe_0 = Maybe(object_0, bool_0)
    bool_2 = maybe_0 == maybe_1
    assert not bool_2, 'maybe_0 == maybe_1'
    object_1 = module_0.object()
    bool_1 = True
    maybe_1 = Maybe(object_1, bool_1)
    bool_2 = maybe_0 == maybe_1

# Generated at 2022-06-26 00:00:59.832030
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    object_1 = module_0.object()
    object_2 = module_0.object()
    object_3 = module_0.object()
    object_4 = module_0.object()
    int_0 = 0
    str_0 = 'A'
    object_5 = module_0.object()
    object_6 = module_0.object()
    object_7 = module_0.object()
    object_8 = module_0.object()
    object_9 = module_0.object()
    object_10 = module_0.object()
    object_11 = module_0.object()
    object_12 = module_0.object()
    bool_0 = False
    bool_1 = False
    bool_2 = False
    bool_3 = False

# Generated at 2022-06-26 00:01:07.535034
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    object_1 = module_0.object()
    object_0 == object_1
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    object_0 == object_1
    bool_1 = False
    maybe_1 = Maybe(object_0, bool_1)
    object_2 = module_0.object()
    object_0 == object_2
    bool_2 = False
    maybe_2 = Maybe(object_0, bool_2)
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_2
    assert maybe_0 != maybe_2


# Generated at 2022-06-26 00:01:17.412449
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_0 = True
    maybe_1 = Maybe(object_1, bool_0)
    object_2 = module_0.object()
    bool_0 = False
    maybe_2 = Maybe(object_2, bool_0)
    object_2 = module_0.object()
    bool_0 = True
    maybe_3 = Maybe(object_2, bool_0)
    object_3 = module_0.object()
    object_2 = module_0.object()
    object_1 = module_0.object()
    object_0 = module_0.object()

    # assert True
    maybe_0_copy

# Generated at 2022-06-26 00:01:22.469496
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)

    object_1 = module_0.object()
    bool_1 = False
    maybe_1 = Maybe(object_1, bool_1)

    bool_2 = maybe_0 == maybe_1

    assert (bool_2 == bool_0)


# Generated at 2022-06-26 00:01:31.370621
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    test case for Maybe.__eq__ method.
    sn.None can be used as last parameter
    """
    object_0 = module_0.object()
    bool_0 = False
    m = Maybe(object_0, bool_0)
    bool_0 = False
    object_1 = module_0.object()
    maybe_0 = Maybe(object_1, bool_0)
    maybe_1 = m.__eq__(maybe_0)
    bool_0 = False
    bool_0 = True
    object_1 = module_0.object()
    maybe_0 = Maybe(object_1, bool_0)
    maybe_1 = m.__eq__(maybe_0)
    bool_0 = False
    bool_0 = False
    object_1 = module_0.object()
    maybe

# Generated at 2022-06-26 00:01:52.862515
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    bool_1 = True
    maybe_1 = Maybe(object_0, bool_1)
    assert maybe_0.is_nothing == bool_0 and maybe_1.is_nothing == bool_1 and maybe_0 == maybe_0 and not maybe_0 == maybe_1


# Generated at 2022-06-26 00:01:58.271923
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
	from pymonet.monet import Maybe

	# First object
	object_0 = object()
	bool_0 = False
	maybe_0 = Maybe(object_0, bool_0)

	# Second object
	object_1 = object()
	bool_1 = False
	maybe_1 = Maybe(object_1, bool_1)

	# First test
	assert maybe_0 == maybe_0

	# Second test
	assert not maybe_0 == maybe_1


# Generated at 2022-06-26 00:02:06.711659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = {'a': 'b', 'c': 'd'}
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = {}
    bool_1 = True
    maybe_1 = Maybe(object_1, bool_1)
    assert (maybe_0 == maybe_0) == True
    assert (maybe_1 == maybe_0) == False
    assert (maybe_0 == maybe_1) == False
    assert (maybe_0 == None) == False
    assert (maybe_1 == None) == False


# Generated at 2022-06-26 00:02:11.430468
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    object_0 = module_0.object()
    bool_0 = False
    lazy_0 = Maybe(object_0, bool_0).to_lazy()
try:
    import builtins as module_0
    import builtins as module_1
    import builtins as module_2
    import builtins as module_3
    import builtins as module_4
    import builtins as module_5
except ImportError:
    import re
    import builtins as module_1
    import builtins as module_2
    import builtins as module_3
    import builtins as module_4
    import builtins as module_5


# Generated at 2022-06-26 00:02:12.257389
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-26 00:02:16.098462
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    bool_1 = False
    maybe_1 = Maybe(object_0, bool_1)
    bool_2 = True
    maybe_2 = Maybe(object_0, bool_2)
    bool_3 = True
    maybe_3 = Maybe(None, bool_3)
    assert maybe_0 == maybe_1
    assert not maybe_1 == maybe_2
    assert not maybe_2 == maybe_3
    assert maybe_3 == maybe_3

# Generated at 2022-06-26 00:02:20.463318
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.nothing()
    bool_0 = maybe_0 == maybe_1
    maybe_2 = Maybe.just(2)
    bool_1 = maybe_0 == maybe_2
    maybe_3 = Maybe.just(2)
    bool_2 = maybe_2 == maybe_3


# Generated at 2022-06-26 00:02:24.049927
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    maybe_1 = Maybe(object_0, bool_0)
    bool_1 = maybe_0 == maybe_1
    assert bool_1



# Generated at 2022-06-26 00:02:31.274832
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    bool_1 = False
    maybe_1 = Maybe(object_0, bool_1)
    bool_2 = True
    maybe_2 = Maybe(object_0, bool_2)
    bool_3 = False
    maybe_3 = Maybe(module_0.object(), bool_3)
    bool_4 = True
    maybe_4 = Maybe(module_0.object(), bool_4)
    assert maybe_0 == maybe_1
    assert maybe_0 != maybe_2
    assert maybe_0 == maybe_3
    assert maybe_0 != maybe_4


# Generated at 2022-06-26 00:02:35.388903
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    object_0 = module_0.object()
    bool_0 = False
    maybe_0 = Maybe(object_0, bool_0)
    object_1 = module_0.object()
    bool_1 = True
    maybe_1 = Maybe(object_1, bool_1)
    assert not maybe_0 == maybe_1
