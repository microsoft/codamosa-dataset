

# Generated at 2022-06-25 23:53:11.550536
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    maybe_1 = Maybe(int_0, bool_0)
    var_0 = maybe_0 == maybe_1
    assert var_0 == True, "AssertionError: expected True, but got %s" % var_0
    int_1 = int_0
    bool_1 = False
    maybe_2 = Maybe(int_1, bool_1)
    var_1 = maybe_0 == maybe_2
    assert var_1 == False, "AssertionError: expected False, but got %s" % var_1


# Generated at 2022-06-25 23:53:16.792613
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    int_1 = -8459518
    int_2 = -3172
    def filterer_0(val_0):
        bool_0 = val_0 > int_1
        return bool_0
    maybe_1 = maybe_0.filter(filterer_0)
    bool_1 = not maybe_1.is_nothing
    if bool_1:
        int_3 = maybe_1.value
        bool_1 = int_3 == int_2
    assert bool_1


# Generated at 2022-06-25 23:53:22.228265
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    int_1 = -3172
    bool_1 = True
    maybe_1 = Maybe(int_1, bool_1)
    var_0 = maybe_0.__eq__(maybe_1)


# Generated at 2022-06-25 23:53:28.574543
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 3172
    bool_0 = False
    maybe_0 = Maybe(int_0, bool_0)
    func_0 = lambda x: False
    maybe_1 = maybe_0.filter(func_0)
    int_1 = maybe_1.get_or_else(3172)
    int_2 = 3172
    assert int_1 == int_2


# Generated at 2022-06-25 23:53:38.365177
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def helper(_arg_0):
        not_arg_0 = not _arg_0
        return not_arg_0

    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    var_0 = maybe_0.filter(helper)
    var_1 = Maybe(int_0, bool_0)
    result_0 = var_0 == var_1
    var_2 = maybe_0.filter(helper)
    var_3 = Maybe(int_0, False)
    result_1 = var_2 == var_3


# Generated at 2022-06-25 23:53:43.571402
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    def func_0(int_0):
        return int_0 < 0
    maybe_1 = maybe_0.filter(func_0)
    int_1 = maybe_1.value
    assert int_1 == int_0


# Generated at 2022-06-25 23:53:51.413238
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    var_0 = maybe_0.filter(lambda m: Box(m).map(lambda m: m < 0).extract())
    var_1 = var_0.to_box().map(lambda m: m * -1).extract()
    assert isinstance(var_0, Maybe)
    assert isinstance(var_1, int) and var_1 == 3172


# Generated at 2022-06-25 23:54:02.297163
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    var_1 = Maybe(False, False)
    var_2 = Maybe(False, False)
    var_3 = Maybe(False, True)
    var_4 = Maybe(True, True)
    var_5 = Maybe(True, False)
    assert var_1 != var_2, "Maybe::__eq__"
    assert var_1 != var_3, "Maybe::__eq__"
    assert var_1 != var_4, "Maybe::__eq__"
    assert var_1 != var_5, "Maybe::__eq__"
    assert var_2 != var_1, "Maybe::__eq__"
    assert var_2 != var_3, "Maybe::__eq__"
    assert var_2 != var_4, "Maybe::__eq__"

# Generated at 2022-06-25 23:54:08.797405
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = 1
    bool_0 = True
    maybe_0 = Maybe(int_1, bool_0)
    maybe_1 = maybe_0.filter(lambda x: x >= 1)
    if maybe_1.is_nothing:
        return maybe_0
    else:
        return maybe_1


# Generated at 2022-06-25 23:54:14.705203
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    maybe_0 = Maybe(None, True)

    maybe_1 = Maybe.just(None)

    assert maybe_0 == maybe_1

    maybe_2 = Maybe(None, True)

    maybe_3 = Maybe(None, False)

    assert maybe_2 == maybe_3


# Generated at 2022-06-25 23:54:30.650719
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("0")
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    print("1")
    maybe_1 = Maybe(int_0, not bool_0)
    lazy_1 = maybe_1.to_lazy()
    print("2")
    int_2 = -3172
    float_2 = float(int_2)
    maybe_2 = Maybe(float_2, bool_0)
    lazy_2 = maybe_2.to_lazy()
    print("3")
    maybe_3 = Maybe(None, bool_0)
    lazy_3 = maybe_3.to_lazy()


# Generated at 2022-06-25 23:54:34.726606
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda n: n > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda n: n < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n > 0) == Maybe.nothing()



# Generated at 2022-06-25 23:54:46.819493
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -3172
    bool_0 = True
    int_1 = -3172
    bool_1 = True
    int_2 = -3172
    bool_2 = False
    int_3 = -3172
    bool_3 = False
    def filterer_0(arg_0: int) -> bool:
        return arg_0 != int_0
    maybe_0 = Maybe(int_0, bool_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.just(int_2)
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.just(int_3)
    maybe_1 = maybe_1.filter(filterer_0)
   

# Generated at 2022-06-25 23:54:52.894871
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Case 1: when Maybe is not empty then returns copy of itself
    Case 2: when Maybe is empty then returns empty Maybe

    :return: True if tests is passed
    :rtype: Boolean
    """
    int_2 = 3
    int_3 = 3
    bool_2 = True
    bool_3 = True
    maybe_2 = Maybe(int_2, bool_2)
    maybe_3 = Maybe(int_3, bool_3)
    def fun_2(x_3):
        return False

    maybe_4 = maybe_2.filter(fun_2)
    return maybe_4 == maybe_3


# Generated at 2022-06-25 23:54:57.720575
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 2044
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get_or_else(None) == 2044


# Generated at 2022-06-25 23:55:10.631968
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy

    def func():
        return 11

    def mapper(x):
        return x + 10

    int_0 = 10
    lazy_0 = lazy.Lazy(func)
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    maybe_1 = maybe_0.to_lazy()
    lazy_1 = maybe_1.value
    bool_1 = lazy_1.is_equal(lazy_0)
    int_1 = maybe_0.get_or_else(11)
    bool_2 = bool_1 and int_1 == 10

    int_2 = 10
    lazy_2 = lazy.Lazy(func)
    bool_3 = False
    maybe_2 = Maybe(int_2, bool_3)
   

# Generated at 2022-06-25 23:55:15.407623
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from typing import Callable

    i = 1
    f1: Callable[[int], bool] = lambda v: v > 0

    maybe: Maybe[int] = Maybe.just(i)
    maybe_0: Maybe[int] = maybe.filter(f1)

    ret = maybe_0.get_or_else(0)
    assert ret == i


# Generated at 2022-06-25 23:55:21.925598
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = True
    int_0 = -3172
    maybe_0 = Maybe(int_0, bool_0)
    filterer = lambda x: x == -3172
    maybe_1 = maybe_0.filter(filterer)
    int_1 = -3172
    bool_1 = False
    maybe_2 = Maybe(int_1, bool_1)
    assert maybe_1 == maybe_2


# Generated at 2022-06-25 23:55:28.388612
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = -3172
    maybe_0 = Maybe(int_0, False)
    test_value = maybe_0.to_lazy()

    assert test_value.is_instance_of(Lazy)
    # result of function is the same Maybe value
    assert test_value.get() == int_0



# Generated at 2022-06-25 23:55:37.728818
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -2693
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)

    int_1 = -2693
    bool_1 = True
    maybe_1 = Maybe(int_1, bool_1)

    int_2 = -2693
    bool_2 = True
    maybe_2 = Maybe(int_2, bool_2)

    int_3 = -2693
    bool_3 = True
    maybe_3 = Maybe(int_3, bool_3)

    int_4 = -2693
    bool_4 = True
    maybe_4 = Maybe(int_4, bool_4)

    int_5 = -2693
    bool_5 = True
    maybe_5 = Maybe(int_5, bool_5)

    int_6 = -26

# Generated at 2022-06-25 23:55:44.860897
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -3172
    bool_0 = False
    maybe_0 = Maybe.just(int_0)
    def filterer(value: int) -> bool:
        return value < 0
    value_0 = maybe_0.filter(filterer)
    assert value_0 == Maybe.just(int_0)


# Generated at 2022-06-25 23:55:54.698765
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 2617
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)

    def func_0( maybe_0 = maybe_0):
        return maybe_0

    try:
        maybe_1 = Maybe.filter(func_0)
    except:
        assert False

    int_1 = -89738
    bool_1 = False
    maybe_1 = Maybe(int_1, bool_1)

    def func_1( maybe_1 = maybe_1):
        return maybe_1

    try:
        maybe_2 = Maybe.filter(func_1)
    except:
        assert False



# Generated at 2022-06-25 23:55:57.979550
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    assert maybe_0.filter(lambda val: val > -1) == Maybe(int_0, False)


# Generated at 2022-06-25 23:56:00.873070
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 5
    bool_0 = False
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == 5

# Generated at 2022-06-25 23:56:10.427402
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    int_0 = -3172
    bool_0 = False
    lazy_0 = Maybe(int_0, bool_0).to_lazy()
    assert not isinstance(lazy_0, Try)
    assert isinstance(lazy_0, Lazy)
    int_1 = lazy_0.get()
    assert int_1 == int_0
    int_2 = int_0 * 3
    bool_1 = lazy_0.is_success()
    assert not bool_1
    bool_2 = isinstance(int_1, int)
    assert bool_2
    bool_3 = isinstance(int_2, int)
    assert bool_3


# Generated at 2022-06-25 23:56:21.308819
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    expected_0 = maybe_0.to_lazy()

    int_1 = -27
    bool_1 = True
    maybe_1 = Maybe(int_1, bool_1)
    expected_1 = maybe_1.to_lazy()

    int_2 = 3671
    bool_2 = True
    maybe_2 = Maybe(int_2, bool_2)
    expected_2 = maybe_2.to_lazy()

    int_3 = -2061
    bool_3 = True
    maybe_3 = Maybe(int_3, bool_3)
    expected_3 = maybe_3.to_lazy()

    int_4 = 9962
    bool_4

# Generated at 2022-06-25 23:56:30.131590
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter method.
    """
    from random import randint, choice

    class TestClass:
        def __init__(self, value: int) -> None:
            self.value = value

        def __eq__(self, other):
            return isinstance(other, TestClass) \
                and self.value == other.value

        def __hash__(self):
            return hash(self.value)

    test_object = TestClass(randint(0, 1000000))
    bool_0 = bool(randint(0, 1))
    maybe_0 = Maybe(test_object, bool_0)
    str_0 = ['', None][randint(0, 1)]
    bool_1 = bool(randint(0, 1))
    maybe_1 = Maybe(str_0, bool_1)


# Generated at 2022-06-25 23:56:32.874593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 4) == Maybe.nothing()


# Generated at 2022-06-25 23:56:40.253278
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = lazy.Lazy(lambda: maybe_0.value)
    maybe_0_lazy = maybe_0.to_lazy()
    assert lazy_0.get_or_else(None) == maybe_0_lazy.get_or_else(None)


# Generated at 2022-06-25 23:56:49.399624
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test 0
    int_0 = -3172
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    lambda_0 = lambda x: x >= -1000
    maybe_1 = maybe_0.filter(lambda_0)
    lambda_1 = lambda x: x >= -1000
    assert maybe_1 == maybe_0.filter(lambda_1)

    # Test 1
    int_1 = -3172
    bool_1 = True
    maybe_2 = Maybe(int_1, bool_1)
    lambda_2 = lambda x: x >= -1000
    maybe_3 = maybe_2.filter(lambda_2)
    int_2 = -3172
    bool_2 = True
    maybe_4 = Maybe(int_2, bool_2)

# Generated at 2022-06-25 23:56:53.749725
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    case_0 = Maybe.just(int_0)
    case_1 = Maybe.nothing()

    result_0 = case_0.to_lazy().force()
    result_1 = case_1.to_lazy().force()

    assert result_0 == int_0
    assert result_1 == None

    return


# Generated at 2022-06-25 23:56:56.162110
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(2)
    assert(a.filter(lambda x: x > 10) == Maybe.nothing())


# Generated at 2022-06-25 23:57:04.138428
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    Maybe(5, False).to_lazy() == Lazy(lambda: 5)
    Maybe(5, False).to_lazy().value == 5
    Maybe(5, False).to_lazy().force() == 5
    Maybe(None, True).to_lazy() == Lazy(lambda: None)
    Maybe(None, True).to_lazy().value == None
    Maybe(None, True).to_lazy().force() == None

    test_case_0()



# Generated at 2022-06-25 23:57:15.479284
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_case_0():
        int_0 = 5
        bool_0 = False
        maybe_0 = Maybe.nothing()
        maybe_0 = maybe_0.filter(lambda x: str(x) == "")
        maybe_1 = Maybe.just(int_0)
        maybe_1 = maybe_1.filter(lambda x: bool_0)
        maybe_2 = Maybe.just(int_0)
        maybe_2 = maybe_2.filter(lambda x: not bool_0)
        bool_0 = maybe_0.is_nothing
        bool_1 = isinstance(maybe_1, Maybe)
        bool_2 = isinstance(maybe_2, Maybe)
        bool_3 = maybe_1.is_nothing
        bool_4 = maybe_2.is_nothing

# Generated at 2022-06-25 23:57:23.047498
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = Maybe.just(5)
    assert(test_value.filter(lambda x: x > 5) == Maybe.nothing())
    assert(test_value.filter(lambda x: x < 6) == Maybe.just(5))
    assert(test_value.filter(lambda x: x < 5) == Maybe.nothing())
    assert(test_value.filter(lambda x: x > 4) == Maybe.just(5))
    assert(test_value.filter(lambda x: x > 10) == Maybe.nothing())
    assert(test_value.filter(lambda x: x < 0) == Maybe.nothing())
    assert(test_value.filter(lambda x: x < 10) == Maybe.just(5))


# Generated at 2022-06-25 23:57:30.152528
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    input_0: Maybe[int] = Maybe(5, False)
    result_0 = input_0.to_lazy()
    assert result_0.run() == 5

    input_1: Maybe[str] = Maybe("", False)
    result_1 = input_1.to_lazy()
    assert result_1.run() == ""

    input_2: Maybe[int] = Maybe(None, True)
    result_2 = input_2.to_lazy()
    assert result_2.run() == None



# Generated at 2022-06-25 23:57:34.167280
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Arrange
    int_0 = 5
    maybe_0 = Maybe.just(int_0)

    # Act
    result_0 = maybe_0.to_lazy()

    # Assert
    assert result_0.value() == 5


# Generated at 2022-06-25 23:57:38.691773
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = 10
    mapper = lambda x: x <= 5
    excepted_true_result = Maybe.just(test_value)
    excepted_false_result = Maybe.nothing()

    assert Maybe.just(test_value).filter(mapper) == excepted_true_result
    assert Maybe.nothing().filter(mapper)  == excepted_false_result


# Generated at 2022-06-25 23:57:45.088409
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 7
    float_0 = float(0.5)

    int_1 = int(int_0)
    float_1 = float(float_0)

    maybe_0 = Maybe.just(int_1)
    maybe_1 = Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda value_0: (value_0) >= (int_0))

    assert maybe_2.is_nothing is bool_0
    assert maybe_2 == maybe_1

    maybe_2 = maybe_0.filter(lambda value_0: (value_0) != (int_1))

    assert maybe_2.is_nothing is bool_0
    assert maybe_2 == maybe_1


# Generated at 2022-06-25 23:57:49.546935
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 7
    int_1 = 9

    bool_0 = True

    maybe_0 = Maybe.just(7)
    maybe_1 = Maybe.just(bool_0)

    maybe_2 = maybe_0.filter(lambda int_0: bool_0)

    assert maybe_2 == Maybe.just(7)


# Generated at 2022-06-25 23:57:57.566862
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 2
    maybe_0 = Maybe.just(5).filter(lambda int_0: Maybe.just(int_0 * 2))
    int_1 = Maybe.just('1').filter(lambda int_0: Maybe.just(int_0 * 2)).get_or_else('2')
    if int_0 is None:
        pass
    def case_0():
        maybe_0 = Maybe.nothing().filter(lambda int_0: Maybe.just(int_0 * 2))


# Generated at 2022-06-25 23:58:01.765627
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # None case
    assert Maybe.nothing().filter(lambda x: x < 3) == Maybe.nothing()
    # True case
    assert Maybe.just(5).filter(lambda x: x < 8) == Maybe.just(5)
    # False case
    assert Maybe.just(5).filter(lambda x: x < 3) == Maybe.nothing()


# Generated at 2022-06-25 23:58:04.557217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x + 2 == 7) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x + 2 != 7) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x + 2 == 7) == Maybe.nothing()



# Generated at 2022-06-25 23:58:07.655307
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x == 4) == Maybe.just(4)
    assert Maybe.just(5).filter(lambda x: x == 4) == Maybe.nothing()


# Generated at 2022-06-25 23:58:15.745063
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    str_0 = "string"

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = maybe_int_0.filter(lambda x: x % 2 == 0)
    assert_equal(maybe_int_1, Maybe.nothing())

    maybe_int_2 = maybe_int_0.filter(lambda x: x % 2 == 1)
    assert_equal(maybe_int_2, maybe_int_0)


# Generated at 2022-06-25 23:58:20.747585
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    assert Maybe.just(int_0).filter(lambda value: value != int_0) == Maybe.nothing()
    assert Maybe.just(int_0).filter(lambda value: value == int_0) == Maybe.just(int_0)
    assert Maybe.nothing().filter(lambda value: value == int_0) == Maybe.nothing()


# Generated at 2022-06-25 23:58:24.650510
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 2) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-25 23:58:33.228437
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test the filter function of Maybe class

    :returns: None

    """

    print("\n--- Test Maybe filter ---\n")
    print("Should be True: ", Maybe.just(5).filter(lambda x: x % 2 == 0).is_nothing)
    print("Should be False: ", Maybe.just(5).filter(lambda x: x % 2 == 1).is_nothing)
    print("Should be True: ", Maybe.nothing().filter(lambda x: x % 2 == 0).is_nothing)
    print("Should be False: ", Maybe.nothing().filter(lambda x: x % 2 == 1).is_nothing)



# Generated at 2022-06-25 23:58:40.377557
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 5
    m_0 = Maybe.just(int_0)
    l_0 = m_0.to_lazy()
    assert isinstance(l_0, Maybe)
    assert isinstance(l_0, Lazy)
    assert l_0.lazy_function() == int_0
    assert isinstance(l_0, Maybe)
    assert isinstance(l_0.lazy_function(), int)
    assert isinstance(l_0.lazy_function(), int)


# Generated at 2022-06-25 23:58:43.817762
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(int_0).filter(lambda x: x == int_0) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(lambda x: x - 1 != int_0) == Maybe.nothing()


# Generated at 2022-06-25 23:58:51.864991
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test 0 unit tests 0 assertions
    assert Maybe.just(int_0).filter(lambda x: x == 0) == Maybe.nothing()
    # Test 1 unit tests 0 assertions
    assert Maybe.just(int_0).filter(lambda x: x == 5) == Maybe.just(int_0)
    # Test 2 unit tests 0 assertions
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-25 23:59:00.312546
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    int_1 = 10
    any_0 = Maybe.just(int_0).filter(lambda x: x < int_1)
    any_1 = Maybe.just(int_1).filter(lambda x: x < int_0)
    any_2 = any_1.filter(lambda x: x < int_0)
    assert any_0.get_or_else(None) == int_0
    assert any_1.get_or_else(None) == None
    assert any_2.get_or_else(None) == None


# Generated at 2022-06-25 23:59:03.729697
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    def filterer(value):
        return True

    mock = Mock()

    m = Maybe.just(int_0)

    m.filter(filterer)

    assert m.value == int_0


# Generated at 2022-06-25 23:59:06.866155
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_maybe = Maybe.just(2)

    assert int_maybe.filter(lambda _: True) == int_maybe
    assert int_maybe.filter(lambda _: False) == Maybe.nothing()


# Generated at 2022-06-25 23:59:10.364981
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value > 5

    mb = Maybe.just(5).filter(filterer)
    assert mb == Maybe.nothing()

    mb = Maybe.just(6).filter(filterer)
    assert mb == Maybe.just(6)


# Generated at 2022-06-25 23:59:15.623724
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import unittest

    class TestMaybeToLazy(unittest.TestCase):
        def test_to_lazy_not_empty(self):
            maybe_0 = Maybe.just(5)

            lazy = Maybe.to_lazy(maybe_0)()

            assert lazy == 5

        def test_to_lazy_empty(self):
            maybe_0 = Maybe.nothing()

            lazy = Maybe.to_lazy(maybe_0)()

            assert lazy is None

    unittest.main()

# Unit test method to_try of class Maybe

# Generated at 2022-06-25 23:59:22.984162
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print("filter")
    maybe_result = Maybe.just(1).filter(lambda x: x < 2)
    assert isinstance(maybe_result, Maybe)
    assert maybe_result.is_nothing is False
    assert maybe_result.value == 1

    maybe_result = Maybe.just(1).filter(lambda x: x > 2)
    assert isinstance(maybe_result, Maybe)
    assert maybe_result.is_nothing is True
    assert maybe_result.is_nothing

    maybe_result = Maybe.nothing().filter(lambda x: x > 2)
    assert isinstance(maybe_result, Maybe)
    assert maybe_result.is_nothing is True
    assert maybe_result.is_nothing



# Generated at 2022-06-25 23:59:26.332582
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5

    assert Maybe.just(int_0).filter(lambda v: int_0 == v) == Maybe.just(int_0)
    assert Maybe.nothing().filter(lambda v: int_0 == v) == Maybe.nothing()


# Generated at 2022-06-25 23:59:32.151915
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    x = Maybe.just(5).filter(lambda x: x < 3)
    assert x == Maybe.nothing()
    assert x == Maybe(None, True)
    x = Maybe.just(5).filter(lambda x: x < 10)
    assert x == Maybe.just(5)
    assert x == Maybe(5, False)
    assert x.value == 5


# Generated at 2022-06-25 23:59:34.652142
# Unit test for method to_lazy of class Maybe

# Generated at 2022-06-25 23:59:46.543771
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(5)
    actual_0 = maybe_0.filter(lambda x: x == 5)
    expected_0 = Maybe.just(5)
    assert actual_0 == expected_0

    maybe_1 = Maybe.nothing()
    actual_1 = maybe_1.filter(lambda x: x == 5)
    expected_1 = Maybe.nothing()
    assert actual_1 == expected_1

    maybe_2 = Maybe.just(6)
    actual_2 = maybe_2.filter(lambda x: x == 7)
    expected_2 = Maybe.nothing()
    assert actual_2 == expected_2


# Generated at 2022-06-25 23:59:49.564524
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    maybe_1 = Maybe.just(int_0)

    def filterer(argument_0):
        return argument_0 is not None

    maybe_2 = maybe_1.filter(
        filterer
    )

    maybe_3 = maybe_1.filter(
        filterer
    )

    assert maybe_2 == maybe_3


# Generated at 2022-06-25 23:59:59.190351
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    int_1 = 6
    m_int_0 = Maybe.just(int_0)
    m_int_1 = Maybe.just(int_1)
    m_int_2 = Maybe.nothing()
    
    assert m_int_0.filter(lambda x: 5 < x) == m_int_1
    assert m_int_1.filter(lambda x: 5 < x) == m_int_1
    assert m_int_2.filter(lambda x: 5 < x) == m_int_2
    int_2 = 3
    int_3 = 4
    m_int_3 = Maybe.just(int_2)
    m_int_4 = Maybe.just(int_3)
    m_int_5 = Maybe.nothing()
    assert m_int_3.filter

# Generated at 2022-06-26 00:00:04.936702
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # assert Maybe.just(1).filter(lambda x: x == 1).get_or_else(0) == 1
    assert Maybe.just(1).filter(lambda x: False).get_or_else(0) == 0
    assert Maybe.just(1).filter(lambda x: True).get_or_else(0) == 1
    assert Maybe.nothing().filter(lambda x: True).get_or_else(0) == 0

# Generated at 2022-06-26 00:00:10.355261
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy
    from pymonet.maybe import Maybe

    assert Maybe.just(10).to_lazy() == lazy.Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == lazy.Lazy(lambda: None)


# Generated at 2022-06-26 00:00:14.739717
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box

    assert Box(Maybe.just(2).filter(lambda x: x >= 2)) == Box(Maybe.just(2))
    assert Box(Maybe.just(1).filter(lambda x: x >= 2)) == Box(Maybe.nothing())


# Generated at 2022-06-26 00:00:19.877264
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import inspect
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    assert inspect.isclass(Maybe)
    assert inspect.isfunction(Maybe.just)
    assert hasattr(Maybe, 'just')
    assert inspect.isfunction(Maybe.nothing)
    assert hasattr(Maybe, 'nothing')
    assert inspect.isfunction(Maybe.map)
    assert hasattr(Maybe, 'map')
    assert inspect.isfunction(Maybe.bind)
    assert hasattr(Maybe, 'bind')
    assert inspect.isfunction(Maybe.ap)
    assert hasattr(Maybe, 'ap')
    assert inspect.isfunction(Maybe.filter)
    assert hasattr(Maybe, 'filter')
    assert inspect.isfunction(Maybe.get_or_else)

# Generated at 2022-06-26 00:00:22.695146
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    i = Maybe.just(5)
    l = i.to_lazy()
    assert l.eval(5) == 5
    assert i != l


# Generated at 2022-06-26 00:00:32.649406
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import unittest

    class MaybeTestCase(unittest.TestCase):


        def test_0(self):
            Maybe.just("foo").to_lazy().force()
        def test_1(self):
            Maybe.just("foo").to_lazy().force()
        def test_2(self):
            Maybe.just("foo").to_lazy().force()
        def test_3(self):
            Maybe.just("foo").to_lazy().force()
        def test_4(self):
            Maybe.just("foo").to_lazy().force()
        def test_5(self):
            Maybe.just("foo").to_lazy().force()
        def test_6(self):
            Maybe.just("foo").to_lazy().force()

# Generated at 2022-06-26 00:00:41.054775
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 5
    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.nothing()

    assert maybe_int_0.to_lazy().run() == int_0
    assert maybe_int_1.to_lazy().run() is None


# Generated at 2022-06-26 00:00:56.782430
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = Maybe.just(5).to_lazy()
    assert isinstance(int_0, Lazy) and int_0.value() == 5

    int_1 = Maybe.just(6).to_lazy()
    assert isinstance(int_1, Lazy) and int_1.value() == 6

    int_none = Maybe.nothing().to_lazy()
    assert isinstance(int_none, Lazy) and int_none.value() == None


if __name__ == "__main__":
    test_Maybe_to_lazy()

# Generated at 2022-06-26 00:01:00.957496
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda value: value == 5).get_or_else(-1) == 5
    assert Maybe.just(5).filter(lambda value: value == 6).get_or_else(-1) == -1
    assert Maybe.nothing().filter(lambda value: value == 5).get_or_else(-1) == -1


# Generated at 2022-06-26 00:01:03.861212
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy_0 = Maybe.just("test").to_lazy()
    assert lazy_0.value() == "test"

    lazy_0 = Maybe.nothing().to_lazy()
    assert lazy_0.value() is None


# Generated at 2022-06-26 00:01:05.966229
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    try:
        maybe_0 = Maybe.just(int_0)
        maybe_0.filter(bool)
    except:
        return False
    return True


# Generated at 2022-06-26 00:01:09.382538
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 5
    maybe_int_0 = Maybe.just(int_0)
    assert maybe_int_0.to_lazy() == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:01:22.235774
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Assert method filter of Maybe.just returns Maybe.nothing when argument is False
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)

    # Assert method filter of Maybe.just returns Maybe.just when argument is True
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()

    # Assert method filter of Maybe.nothing returns Maybe.nothing when argument is False
    assert Maybe.nothing().filter(lambda x: x != 1) == Maybe.nothing()

    # Assert method filter of Maybe.nothing returns Maybe.nothing when argument is True
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-26 00:01:31.167981
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5

    # in this case we are creating Maybe with int_0, we are mapping it to a int and then applying a filter
    # to it which will return 0 or 1, so if we make the filter return 1 then the Maybe will be passed to the next
    # function in the pipe. At the end we are getting the value from the Maybe and asserting that the value equals
    # the initial int_0 value
    int_1 = Maybe.just(int_0).map(lambda t: 1).filter(lambda m: m == 0).get_or_else(0)
    assert int_1 == int_0

    # in this case the filter is returning 0, so the Maybe is filtered out and we are just returning the default_value
    # which is 0
    int_2 = Maybe.just(int_0).map(lambda t: 1).filter

# Generated at 2022-06-26 00:01:36.807682
# Unit test for method filter of class Maybe
def test_Maybe_filter():
        maybe_5 = Maybe(5, False)
        maybe_none = Maybe(None, True)

        # Test filter with predicate that return True
        assert maybe_5.filter(lambda x: x > 2) == Maybe.just(5)

        # Test filter with predicate that return False
        assert maybe_5.filter(lambda x: x > 10) == Maybe.nothing()

        # Test filter with predicate that return False
        assert maybe_none.filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-26 00:01:41.040272
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda _: True) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()



# Generated at 2022-06-26 00:01:50.273483
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda int_0: True)
    bool_0 = maybe_1 is maybe_0
    assert bool_0 == True
    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.filter(lambda int_0: True)
    bool_1 = maybe_3 is maybe_2
    assert bool_1 == True
    maybe_4 = Maybe.just(int_0)
    maybe_5 = maybe_4.filter(lambda int_0: False)
    bool_2 = maybe_5.is_nothing
    assert bool_2 == True
    maybe_6 = Maybe.nothing()
    maybe_7 = maybe_6.filter(lambda int_0: False)

# Generated at 2022-06-26 00:02:05.281911
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def filterer(x):
        return x > 0

    for monad in [Maybe.just(1), Maybe.just(0), Maybe.nothing()]:
        assert monad.filter(filterer) == Maybe.just(1)


# Generated at 2022-06-26 00:02:09.171861
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_ = Maybe.just(1).filter(lambda x: x < 2)
    assert maybe_ == Maybe.just(1)
    maybe_ = Maybe.just(10).filter(lambda x: x < 2)
    assert maybe_ == Maybe.nothing()
    maybe_ = Maybe.nothing().filter(lambda x: x < 2)
    assert maybe_ == Maybe.nothing()


# Generated at 2022-06-26 00:02:15.333067
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, True).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(2, True).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(3, True).filter(lambda x: x % 2 == 0) == Maybe.nothing()

    assert Maybe(1, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(2, False).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe(3, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-26 00:02:16.786531
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = 5
    maybe = Maybe(value, False)

    res = maybe.to_lazy()

    assert value == res.value()


# Generated at 2022-06-26 00:02:25.562521
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    int_1 = 4
    int_2 = 2
    int_3 = 4
    int_4 = 6
    int_5 = 4
    int_6 = 2
    int_7 = 4
    int_8 = 8
    int_9 = 4
    int_10 = 2
    int_11 = 4
    int_12 = 10
    int_13 = 4
    int_14 = 2
    int_15 = 4

    monad_0 = Maybe.just(int_0)
    monad_1 = Maybe.just(int_1)
    monad_2 = Maybe.just(int_2)
    monad_3 = Maybe.just(int_3)
    monad_4 = Maybe.just(int_4)

# Generated at 2022-06-26 00:02:30.099548
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 5
    maybe1 = Maybe.just(int_0)
    maybe2 = Maybe.nothing()
    maybe1 = maybe1.filter(lambda int_0: int_0 == 5)
    maybe2 = maybe2.filter(lambda int_0: int_0 == 5)
    assert maybe1 == Maybe.just(5)
    assert maybe2 == Maybe.nothing() and maybe2.is_nothing
    return True


# Generated at 2022-06-26 00:02:34.201144
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-26 00:02:45.540303
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_1 = Maybe.just(1)
    maybe_6 = Maybe.just(6)
    maybe_none = Maybe.nothing()

    # Check filter with function returning True for all passed values
    def filter_all(x: int) -> bool:
        return True

    # Check filter with function which returning False when passed value is 1
    def filter_1(x: int) -> bool:
        if x == 1:
            return False
        return True

    # Check filter with function which returns True only when passed value is 1
    def filter_not_1(x: int) -> bool:
        if x == 1:
            return True
        return False

    assert maybe_1.filter(filter_all) == Maybe.just(1)

    assert maybe_none.filter(filter_all) == Maybe.nothing()

    assert maybe_none

# Generated at 2022-06-26 00:02:52.246834
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_some = Maybe.just(5)
    maybe_some_nothing = maybe_some.filter(lambda x: False)
    maybe_some_some = maybe_some.filter(lambda x: True)
    maybe_none = Maybe.nothing()
    maybe_none_something = maybe_none.filter(lambda x: True)
    maybe_none_nothing = maybe_none.filter(lambda x: False)

    assert isinstance(maybe_some, Maybe) and isinstance(maybe_some_nothing, Maybe) and isinstance(maybe_some_some, Maybe)
    assert isinstance(maybe_none, Maybe) and isinstance(maybe_none_something, Maybe) and isinstance(maybe_none_nothing, Maybe)
    assert maybe_some_nothing.is_nothing == maybe_none_nothing.is_nothing == maybe_none.is_nothing

# Generated at 2022-06-26 00:02:54.917488
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Setup
    maybe = Maybe.just(10)

    # Exercise
    result = maybe.to_lazy()

    # Verify
    assert result.unwrap() == 10

    # Cleanup - None

    # Teardown - None
