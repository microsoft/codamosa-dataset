

# Generated at 2022-06-25 23:53:13.014369
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def maybe_filter(value, filterer):
        return Maybe(value, is_nothing=filterer(value))

    int_0 = 5
    int_1 = 5
    bool_0 = True
    bool_1 = True
    bool_2 = True
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = True
    bool_7 = True
    bool_8 = True
    bool_9 = True
    bool_10 = True
    bool_11 = True
    bool_12 = True
    bool_13 = True
    bool_14 = True
    bool_15 = True
    bool_16 = True
    bool_17 = True
    bool_18 = True
    bool_19 = True
    bool_20 = True
    bool_21 = True
   

# Generated at 2022-06-25 23:53:24.814829
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case: simple mapping value by function
    function_0 = lambda num: num > 0
    bool_0 = True
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = maybe_0.filter(function_0)
    assert type(maybe_0) == Maybe
    assert maybe_1.get_or_else(None) == maybe_0.get_or_else(None)

    function_1 = lambda num: num > 10
    bool_1 = True

# Generated at 2022-06-25 23:53:31.072182
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    bool_0 = True
    maybe_1 = Maybe(bytes_0, bool_0)
    bool_0 = True
    maybe_2 = Maybe(bytes_0, bool_0)
    assert maybe_0 == maybe_1

    maybe_2 = Maybe.nothing()
    assert not maybe_0 == maybe_2



# Generated at 2022-06-25 23:53:35.539226
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\x07\x00'
    bytes_1 = b'\x00\x00'
    maybe_0 = Maybe.just(bytes_0)
    maybe_1 = Maybe.nothing()
    assert maybe_0.filter(lambda x: x != bytes_1) == Maybe.just(bytes_0)
    assert maybe_1.filter(lambda x: x != bytes_1) == Maybe.nothing()


# Generated at 2022-06-25 23:53:43.651314
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    assert maybe_0.to_lazy() == Maybe.just(bytes_0).to_lazy()



# Generated at 2022-06-25 23:53:52.859038
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_case_0():
        bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
        bool_0 = True
        maybe_0 = Maybe(bytes_0, bool_0)

        def filterer(value):
            return True

        assert maybe_0.filter(filterer) == maybe_0


    def test_case_1():
        bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
        bool_0 = True
        maybe_0 = Maybe(bytes_0, bool_0)



# Generated at 2022-06-25 23:53:56.331176
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l', True)
    maybe_1 = Maybe(b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l', True)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:54:02.498790
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.unbox() == bytes_0


# Generated at 2022-06-25 23:54:13.630001
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bytes_1 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_1, bool_0)
    def function_0(value):
        boolean_0 = False
        if value is None:
            boolean_0 = True
        return boolean_0
    maybe_1 = maybe_0.filter(function_0)
    assert isinstance(maybe_1, Maybe)
    assert maybe_1.get_

# Generated at 2022-06-25 23:54:18.450543
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:54:35.188286
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    from pymonet.monad_try import Try

    monad_0 = Maybe(1, False)
    monad_1 = Maybe(2, False)
    monad_2 = Maybe(1, True)
    monad_3 = Maybe(Try(True, is_success=True), False)
    monad_4 = Maybe(Try(False, is_success=True), False)
    assert monad_0 == monad_1
    assert monad_0 != monad_2
    assert monad_1 != monad_2
    assert monad_2 != monad_3
    assert monad_3 == monad_4



# Generated at 2022-06-25 23:54:47.291133
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    int_0 = 7093
    bool_0 = False
    int_1 = int_0 + int_0
    str_0 = str(int_1)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)
    str_0 = str(str_0)

# Generated at 2022-06-25 23:54:52.361561
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = maybe_0
    maybe_1 = Maybe(bytes_0, bool_0)
    assert maybe_0 == maybe_1 == maybe_0


# ___

# Generated at 2022-06-25 23:55:03.809628
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = Maybe.just(bytes_0)
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.just(None)

    filterer_0 = bytes_0._copy()
    filterer_1 = maybe_0._filter(lambda maybe_0: len(maybe_0) > 23)
    filterer_2 = maybe_0._filter(lambda maybe_0: len(maybe_0) < 24)

# Generated at 2022-06-25 23:55:11.466588
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_value = Lazy(lambda: "hello")
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == lazy_value


# Generated at 2022-06-25 23:55:22.240467
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    bytes_1 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_1 = True
    maybe_1 = Maybe(bytes_1, bool_1)
    assert maybe_0.__eq__(maybe_1) == True

# Generated at 2022-06-25 23:55:32.041232
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = Maybe(bytes_0, bool_0)
    # Expected result
    bool_1 = True
    # Execute code under test
    bool_2 = maybe_0 == maybe_1
    # Verify results
    assert bool_1 == bool_2



# Generated at 2022-06-25 23:55:38.547516
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.force() == b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'


# Generated at 2022-06-25 23:55:51.151332
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(b'\x07:\xb7\xaf\xd8\x83zN\x94\x9f\xc8\x17\xe6\x12\xdf\xdf\x02\x16\x19\xc9X\xd2\x86\x9f\xdc&%')
    maybe_1 = Maybe.just(b'\x07:\xb7\xaf\xd8\x83zN\x94\x9f\xc8\x17\xe6\x12\xdf\xdf\x02\x16\x19\xc9X\xd2\x86\x9f\xdc&%')
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.nothing()

# Generated at 2022-06-25 23:55:58.061378
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = Maybe(bytes_0, bool_0)
    bool_1 = maybe_0.__eq__(maybe_1)
    assert bool_1 == True



# Generated at 2022-06-25 23:56:15.553176
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\x07:\xb7\xaf\xd8\x83zN\x94\x9f\xc8\x17\xe6\x12\xdf\xdf\x02\x16\x19\xc9X\xd2\x86\x9f\xdc&%'
    maybe_0 = Maybe.just(bytes_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    # Check lazy value
    lazy_value_0 = lazy_0.unwrap()
    lazy_value_1 = lazy_1.unwrap()
    assert lazy_value_0 == bytes_0
    assert lazy_value_1 == None
    # Check lazy execute

# Generated at 2022-06-25 23:56:22.190150
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("Testing Maybe.to_lazy")
    val = b'value'
    nothing = Maybe.nothing()
    just_maybe = Maybe.just(val)
    lazy_from_nothing = nothing.to_lazy()
    lazy_from_just = just_maybe.to_lazy()
    assert lazy_from_nothing.get_lazy().call() == None
    assert lazy_from_just.get_lazy().call() == val
    print("Done testing Maybe.to_lazy")


# Generated at 2022-06-25 23:56:22.853800
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-25 23:56:25.877996
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(bytes_0).to_lazy() == Lazy(lambda: bytes_0)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:56:32.224272
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(b'\x07:\xb7\xaf\xd8\x83zN\x94\x9f\xc8\x17\xe6\x12\xdf\xdf\x02\x16\x19\xc9X\xd2\x86\x9f\xdc&%')
    lazy_0 = maybe_0.to_lazy()
    assert (lazy_0.value() == maybe_0.value)

# Generated at 2022-06-25 23:56:43.481673
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation, Success, Failure
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # TODO: add tests for case when Maybe and default_value are instances of Maybe, Right, Left, Validation and etc.
    # TODO: add test for correct initialization of new Maybe with shallow copying of value
    # TODO: add test for correct initialization of new Maybe when default_value is Neither, Nothing, None and etc.


# Generated at 2022-06-25 23:56:51.200659
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.try_ import Try
    from pymonet.box import Box
    from pymonet.validation import Validation

    res_0 = Maybe.just(lambda: 1).to_lazy()
    res_1 = Maybe.nothing().to_lazy()
    res_2 = Maybe.just(lambda: 1).to_lazy().run()
    res_3 = Maybe.nothing().to_lazy().run()

    assert isinstance(res_0, Lazy)
    assert isinstance(res_1, Lazy)
    assert res_2 == 1
    assert res_3 is None


# Generated at 2022-06-25 23:57:01.543768
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\x07:\xb7\xaf\xd8\x83zN\x94\x9f\xc8\x17\xe6\x12\xdf\xdf\x02\x16\x19\xc9X\xd2\x86\x9f\xdc&%'
    maybe_0 = Maybe.just(bytes_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, maybe_0.to_lazy().__class__)
    assert maybe_0.value == lazy_0.value()
    assert maybe_0 == lazy_0.to_maybe()


# Generated at 2022-06-25 23:57:03.475150
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    return Maybe.just(None).filter(lambda x: x == True) == Maybe.nothing()


# Generated at 2022-06-25 23:57:14.923727
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(bytes_0)
    res_0 = maybe_0.filter(lambda val: val == bytes_0)
    assert isinstance(res_0, Maybe)
    assert res_0 == maybe_0
    maybe_1 = Maybe.nothing()
    res_1 = maybe_1.filter(lambda val: val == bytes_0)
    assert isinstance(res_1, Maybe)
    assert res_1 == Maybe.nothing()

# Generated at 2022-06-25 23:57:29.652224
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    bytes_0 = b'\x9d\xf5\x1f\x0c\xbc\xeb\xb5\xbf\x8a\x9c\xdd\xe2\x82*\x12\xc2\xce\x81q\xd3\xab\xcf\x0c\x04\xfc\x8a\xc0\x0e\xaa\x12\xcf\x02\xd7\n\x14'
    bytes_1 = b'4\xd4\x83\x8b\x9e\x7f\x06\xcc\x8b\xbc\xc6\x15^\x03\xdd\x0b\xad\xf3\x0b+'

# Generated at 2022-06-25 23:57:35.343736
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    lambda_0 = lambda value: bool_0
    maybe_0 = Maybe(bytes_0, bool_0)

    assert maybe_0.filter(lambda_0) == maybe_0


# Generated at 2022-06-25 23:57:42.629660
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    def filterer(arg_0):
        return bool(arg_0)
    maybe_1 = maybe_0.filter(filterer)
    bool_1 = True
    bool_2 = maybe_1.is_nothing
    assert bool_1 == bool_2
    bool_1 = maybe_0.is_nothing
    bool_2 = maybe_0.is_nothing
    assert bool_1 == bool_2


# Generated at 2022-06-25 23:57:51.431553
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    bytes_0 = b'\x8f\xaa\x0e\xde\x7f\x15\x9f\x83\xdf\x8b\xdd\xbb\xb6\xc2\xef\x8d\x81\x1c\xf7\x8cHG\x1d\x92'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-25 23:57:55.948874
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_0.to_lazy()


# Generated at 2022-06-25 23:57:58.664742
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(True, False)
    def func_0(arg_0):
        return (arg_0)
    maybe_5 = maybe_0.filter(func_0)


# Generated at 2022-06-25 23:58:02.918791
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # returns Maybe[A] | Maybe[None]
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just('abc').filter(lambda x: True) == Maybe.just('abc')
    assert Maybe.just('abc').filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-25 23:58:13.602878
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    list_0 = []
    for i in range(7):
        list_0.append(i)
    tup_0 = tuple(list_0)
    int_0 = tup_0.count(3)
    int_1 = len(tup_0)
    int_2 = int_1 + int_0
    int_3 = int_2 * int_2
    int_4 = int_3 / 2
    int_5 = int_4 + int_0
    list_1 = []
    for i in range(3):
        list_1.append(i)
    list_2 = []
    for i in range(6):
        list_2.append(i)
    list_3 = []
    for i in range(5):
        list_3.append(i)
    dict_0

# Generated at 2022-06-25 23:58:23.100013
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'fLlj0e1S7OI'
    str_1 = 'OdH4z4Za9oZ'
    str_2 = 'rN7Vy8NNr5U'
    dict_2 = {
        str_0: 12,
        str_1: 12,
        str_2: 44,
    }
    print('Method filter of class Maybe')
    def func_0(str_3):
        str_3 = str_3.strip()
        return False

    maybe_0 = Maybe(dict_2, False)
    maybe_1 = maybe_0.filter(func_0)
    assert maybe_1.is_nothing == True
    print('Test pass.')


# Generated at 2022-06-25 23:58:32.176523
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    mapper = lambda _arg_0: maybe_0.bind(lambda _arg_1: maybe_0.ap(maybe_0.fmap(lambda _arg_2: maybe_0.fmap(lambda _arg_3: maybe_0.fmap(lambda _arg_4: Maybe.just(_arg_4))))))
    assert maybe_0.filter(mapper) == Maybe.just(bytes_0)


# Generated at 2022-06-25 23:58:47.454913
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)

    def filterer_0(argument_0: bytes) -> bool:
        return len(argument_0) == 24

    assert maybe_0.filter(filterer_0) == maybe_0


# Generated at 2022-06-25 23:58:59.246682
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    string_0 = 'MAYBE_TEST'

    maybe_0 = Maybe.just(bytes_0)

    # Test filter with custom function
    def custom_filterer (value):
        return value in (bytes_0, bool_0)

    maybe_1 = maybe_0.filter(custom_filterer)

    # test filter with lambda
    maybe_2 = maybe_1.filter(lambda value: value not in (bytes_0, bool_0))

    maybe_3 = Maybe.nothing()

# Generated at 2022-06-25 23:59:05.794120
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    bytes_1 = lazy_0.value()
    assert bytes_1 == bytes_0


# Generated at 2022-06-25 23:59:10.288997
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    assert maybe_0.to_lazy() == Lazy(lambda: bytes_0)


# Generated at 2022-06-25 23:59:13.241965
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_list import List
    def filter_(value):
        return value > 2

    list_0 = List(1, 2, 3, 4)
    assert (list_0.filter(filter_) == List(3, 4))



# Generated at 2022-06-25 23:59:15.476928
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_list_0 = Maybe.just(0)

    def test_formatter(test_value):
        return test_value

    assert maybe_list_0.filter(test_formatter) == Maybe.just(0)



# Generated at 2022-06-25 23:59:20.906660
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy

    # Provide input parameters for test case if needed
    nb_to_power_2 = lambda n: n**2

    input_0 = lazy.Lazy(lambda: 1)

    # Execute method under test
    output_0 = input_0.to_lazy()

    # Check results of test case
    assert isinstance(output_0, lazy.Lazy) == True
    assert output_0.get_value() == 1



# Generated at 2022-06-25 23:59:30.943713
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    import pymonet.exceptions as exceptions
    bytes_0 = b'\xac\x8a\x84j\x9a\xf6\xae[\xf3D\x13R\x16\x95\x8c-\xbb\xdf'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    bool_1 = True
    maybe_1 = Maybe(bytes_0, bool_1)
    bool_2 = True
    maybe_2 = Maybe(bytes_0, bool_2)
    bool_3 = True
    maybe_3 = Maybe(bytes_0, bool_3)
    bool_4 = True
    maybe_4 = Maybe(bytes_0, bool_4)
    bool_5 = True

# Generated at 2022-06-25 23:59:39.846908
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    bool_1 = False
    bytes_0 = b'\x7f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff'
    maybe_0 = Maybe(bytes_0, bool_0)
    bool_2 = True
    bytes_1 = b'\x7f\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff'
    maybe_1 = Maybe.just(bytes_1)
    maybe

# Generated at 2022-06-25 23:59:47.037958
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value_0):
        return False

    def filterer2(value_0):
        return True
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)

    assert maybe_0.filter(filterer) == Maybe.nothing()
    assert maybe_0.filter(filterer2) == Maybe.just(bytes_0)


# Generated at 2022-06-26 00:00:13.833654
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'y0\xef0Rx\x9b\x1cZ\xac\x7f\xf8\x0fF\xde\xda\xdc\x02\xa7\x11\xed\xb8\x16u\x0e\x80\xb7c\x9a\xec\x86'
    maybe_0 = Maybe.just(str_0)
    function_0 = lambda str_0: len(str_0) >= 32
    maybe_1 = maybe_0.filter(function_0)


# Generated at 2022-06-26 00:00:23.471533
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = maybe_0.filter(lambda item: item==b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l')
    assert maybe_1 == maybe_0


# Generated at 2022-06-26 00:00:27.116108
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 10
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get() == int_0


# Generated at 2022-06-26 00:00:29.838689
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    assert Maybe.just(bytes_0).filter(
        lambda value: len(value)) != Maybe.nothing()
    maybe_0 = Maybe(bytes_0, bool_0)
    assert maybe_0.filter(lambda value: bool_0) != Maybe.nothing()


# Generated at 2022-06-26 00:00:39.425232
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = Maybe.just(bytes_0)
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.nothing()
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.just(bytes_0)
    maybe_6 = Maybe.just(bytes_0)
    maybe_7 = Maybe.nothing()
    maybe_8 = Maybe.just(bytes_0)

    def func_0(x_0, x_1):
        return x_0 ** x_1


# Generated at 2022-06-26 00:00:43.586725
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == bytes_0
    assert lazy_0.is_forced() is False
    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1.value() is None
    assert lazy_1.is_forced() is False


# Generated at 2022-06-26 00:00:51.668825
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    lazy_0_result = lazy_0.value()
    assert lazy_0_result == bytes_0
    lazy_1 = maybe_1.to_lazy()
    lazy_1_result = lazy_1.value()
    assert lazy_1_result == None


# Generated at 2022-06-26 00:00:58.571297
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    maybe_0 = Maybe.just(bytes_0)
    maybe_1 = Maybe.nothing()
    maybe_1 = maybe_1.filter(lambda val: val is not None)

    if maybe_0 != Maybe.just(bytes_0):
        raise AssertionError('Test #0 failed')

    if maybe_1 != Maybe.nothing():
        raise AssertionError('Test #1 failed')



# Generated at 2022-06-26 00:01:04.436210
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # This is simple unit test for this method.
    # You can do better.
    #
    # For example test with more arguments, compare result with other implementation,
    # check if method throws exception in some case.
    #
    # For example:
    #
    # assert method_under_test(args) == expected_result
    #

    assert Maybe.just(1).to_lazy().run() == 1
    assert Maybe.nothing().to_lazy().run() is None


# Generated at 2022-06-26 00:01:11.480833
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    filter_0 = lambda bytes_1: bytes_1.__contains__(bytes_0)
    maybe_0.filter(filter_0)



# Generated at 2022-06-26 00:01:53.469460
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    string_1 = "abcd"
    maybe_0 = Maybe.just(string_1)

    def f_0(value_0: str) -> bool:
        return value_0[0] == 'a'

    maybe_1 = maybe_0.filter(f_0)
    assert maybe_1.value == string_1


# Generated at 2022-06-26 00:02:04.055260
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == bytes_0
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = False
    maybe_0 = Maybe(bytes_0, bool_0)
    lazy_0 = maybe_

# Generated at 2022-06-26 00:02:10.274728
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Preconditions.
    def filterer_func(value):
        return value == None
    def some_func(value):
        return value

    # Postconditions.
    def cb_0(value):
        assert value == None
    def cb_1(value):
        assert value == None

    # Init.
    maybe_0 = Maybe.nothing()
    maybe_0.filter(filterer_func).bind(cb_0)
    maybe_1 = Maybe.just(None)
    maybe_1.filter(filterer_func).bind(cb_1)


# Generated at 2022-06-26 00:02:14.142922
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(34.10798, False)
    maybe_0.filter(lambda x: x > 0.0)
    maybe_1 = Maybe(34, False)
    maybe_0 = Maybe(True, False)
    maybe_1 = maybe_0.filter(lambda x: x)
    assert maybe_1.value == maybe_0.value


# Generated at 2022-06-26 00:02:19.525901
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    bytes_0 = b'#e\xc5\x01\xe8\x1b\x05\x85\x98\x8e\x0f\x9f\x00\x8e\xc1\xcf\xa2\x86'
    bool_0 = False
    maybe_0 = Maybe(bytes_0, bool_0)

    maybe_0.to_lazy() == Lazy(lambda: bytes_0)


# Generated at 2022-06-26 00:02:24.431175
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    maybe_1 = maybe_0.filter(bool)
    assert maybe_0 == maybe_1



# Generated at 2022-06-26 00:02:25.221096
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass



# Generated at 2022-06-26 00:02:34.268068
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    def my_filterer(value):
        return value > 2

    def my_filterer_1(value):
        return value > 1

    # test with empty maybe
    result = Maybe.nothing().filter(my_filterer)
    assert result == Maybe.nothing()

    # test without empty maybe
    result = Maybe.just(2).filter(my_filterer)
    assert result == Maybe.nothing()
    assert result != Maybe.just(2)

    result = Maybe.just(3).filter(my_filterer)
    assert result == Maybe.just(3)
    assert result != Maybe.nothing()

    result = Maybe.just(2).filter(my_filterer_1)
    assert result == Maybe.just(2)
    assert result != Maybe.nothing()



# Generated at 2022-06-26 00:02:37.060235
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value % 2 == 0
    return Maybe.just(1).filter(filterer)


# Generated at 2022-06-26 00:02:46.228216
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xc5y\xa0\xb7\x89$7\xfb\r\xf7\x000\xc1\xd5\xbf\xc9\xa2.l'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)