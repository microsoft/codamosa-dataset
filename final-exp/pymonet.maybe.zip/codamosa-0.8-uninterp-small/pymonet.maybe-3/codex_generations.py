

# Generated at 2022-06-25 23:53:08.593759
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def check_filterer(i: int) -> bool:
        return i == 2
    assert Maybe.just(2).filter(check_filterer).is_nothing == False
    assert Maybe.just(3).filter(check_filterer).is_nothing == True
    assert Maybe.nothing().filter(check_filterer).is_nothing == True


# Generated at 2022-06-25 23:53:11.509670
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(False, False)
    maybe_1 = Maybe(False, False)
    if maybe_0 == maybe_1:
        print("Test 0 OK")
    else:
        print("Test 0 FAILED")


# Generated at 2022-06-25 23:53:14.661825
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe

    m = Maybe.just(True)
    assert m.filter(lambda x: x) == Maybe.just(True)
    assert m.filter(lambda x: not x) == Maybe.nothing()


test_Maybe_filter()


# Generated at 2022-06-25 23:53:23.945645
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Box
    from pymonet import Either
    from pymonet import Lazy
    from pymonet import Try
    from pymonet import Validation

    lazy_0 = Maybe(
        Maybe.just(0),
        False,
    ).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 0

    lazy_1 = Maybe(
        Maybe.nothing(),
        True,
    ).to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == None



# Generated at 2022-06-25 23:53:31.766436
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # test case 0
    str_0 = "Hello"
    maybe_0 = Maybe.just(str_0)
    maybe_1 = Maybe.just(str_0)
    bool_0 = maybe_0.__eq__(maybe_1)

    # test case 1
    str_0 = "Hello"
    maybe_0 = Maybe.just(str_0)
    maybe_1 = Maybe.nothing()
    bool_0 = maybe_0.__eq__(maybe_1)

    # test case 2
    str_0 = "Hello"
    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.nothing()
    bool_0 = maybe_0.__eq__(maybe_1)


# Generated at 2022-06-25 23:53:34.821059
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)
    maybe_0 = maybe_0.filter(lambda bool_0: bool_0)
    assert maybe_0 == Maybe.just(bool_0)



# Generated at 2022-06-25 23:53:46.428605
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """

    """
    maybe_0 = Maybe.just(True)
    assert maybe_0.filter(lambda x: x) == maybe_0
    assert maybe_0.filter(lambda x: x) != Maybe.just(False)
    assert maybe_0.filter(lambda x: x) != Maybe.nothing()

    maybe_1 = Maybe.just(False)
    assert maybe_1.filter(lambda x: x) == Maybe.nothing()
    assert maybe_1.filter(lambda x: x) != Maybe.just(False)
    assert maybe_1.filter(lambda x: x) != Maybe.just(True)

    maybe_2 = Maybe.nothing()
    assert maybe_2.filter(lambda x: x) == Maybe.nothing()
    assert maybe_2.filter(lambda x: x) != Maybe.just(False)


# Generated at 2022-06-25 23:53:52.458742
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    actual = Maybe.just(3) == Maybe.just(3)
    assert actual == True

    actual = Maybe.just(3) == Maybe.nothing()
    assert actual == False

    actual = Maybe.nothing() == Maybe.nothing()
    assert actual == True

    actual = Maybe.just(3) == Maybe.just(5)
    assert actual == False


# Generated at 2022-06-25 23:53:55.366283
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(1)


# Generated at 2022-06-25 23:53:59.766734
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-25 23:54:08.745412
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Given: it is empty Maybe
    left = Maybe.nothing()

    # When: call to_lazy method
    left_lazy = left.to_lazy()

    # Then: result is lazy monad with empty Maybe
    assert left_lazy() == None

# Generated at 2022-06-25 23:54:14.374213
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value

    maybe = Maybe.just(True)
    assert maybe.filter(filterer).value is True

    maybe2 = Maybe.nothing()
    assert maybe2.filter(filterer).is_nothing is True



# Generated at 2022-06-25 23:54:18.952477
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_case_0():
        bool_0 = False
        maybe_0 = Maybe(bool_0, bool_0)
        bool_1 = not bool_0
        maybe_1 = Maybe(bool_0, bool_1)
        assert maybe_0 == maybe_1
    test_case_0()



# Generated at 2022-06-25 23:54:31.998759
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    bool_1 = True
    maybe_1 = Maybe.just(bool_1)
    bool_2 = True
    maybe_2 = Maybe.just(bool_2)
    bool_3 = False
    maybe_3 = Maybe.just(bool_3)

    # Exercise
    obj_1 = maybe_1 == maybe_1
    obj_2 = maybe_1 == maybe_2
    obj_3 = maybe_1 == maybe_3
    obj_4 = maybe_1 == bool_1
    obj_5 = maybe_1 == maybe_1.value

    # Verify
    assert obj_1 is True
    assert obj_2 is True
    assert obj_3 is False
    assert obj_4 is False
    assert obj_5 is False


# Generated at 2022-06-25 23:54:35.877864
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-25 23:54:40.778318
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() != Maybe.just(0)


# Generated at 2022-06-25 23:54:50.590134
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe(None, not None)
    maybe_1 = Maybe(Lazy(lambda: (),), not None)
    maybe_2 = Maybe(Lazy(lambda: ()), not None)
    maybe_3 = Maybe(Lazy(lambda: (),), not None)
    maybe_4 = Maybe(None, not None)
    maybe_5 = Maybe(None, not None)

    assert maybe_0.to_lazy() != maybe_1.to_lazy()
    assert maybe_2.to_lazy() == maybe_3.to_lazy()
    assert maybe_4.to_lazy() == maybe_5.to_lazy()


# Generated at 2022-06-25 23:55:02.194659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(True, True)
    maybe_1 = Maybe(None, True)
    maybe_2 = Maybe(None, False)
    maybe_3 = Maybe(True, False)
    maybe_4 = Maybe(True, True)
    maybe_5 = Maybe(None, True)
    maybe_6 = Maybe(None, False)
    maybe_7 = Maybe(True, False)
    maybe_8 = Maybe(True, True)
    maybe_9 = Maybe(None, True)
    maybe_10 = Maybe(None, False)
    maybe_11 = Maybe(True, False)
    maybe_12 = Maybe(True, True)
    maybe_13 = Maybe(None, True)
    maybe_14 = Maybe(None, False)
    maybe_15 = Maybe(True, False)

# Generated at 2022-06-25 23:55:12.880300
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    arg_maybe_0 = Maybe.just(1)
    arg_obj_1 = Maybe.just("")
    arg_maybe_2 = Maybe.just("")
    arg_obj_3 = Maybe.just("")
    arg_maybe_4 = Maybe.just("")
    arg_maybe_5 = Maybe.nothing()
    arg_maybe_6 = Maybe.nothing()
    with pytest.raises(AttributeError):
        Maybe.__eq__(arg_maybe_0, arg_obj_1)
    with pytest.raises(AttributeError):
        Maybe.__eq__(arg_maybe_2, arg_obj_3)
    with pytest.raises(AttributeError):
        Maybe.__eq__(arg_maybe_4, arg_maybe_5)

# Generated at 2022-06-25 23:55:23.716834
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0_0 = Maybe(bool, bool)
    bool_0 = False
    bool_1 = False
    maybe_0_1 = Maybe(bool_0, bool_1)
    assert not maybe_0_0 == maybe_0_1
    bool_2 = False
    maybe_0_2 = Maybe(bool_1, bool_2)
    assert not maybe_0_0 == maybe_0_2
    bool_3 = False
    maybe_0_3 = Maybe(bool_2, bool_3)
    assert not maybe_0_0 == maybe_0_3
    bool_4 = False
    maybe_0_4 = Maybe(bool_3, bool_4)
    assert not maybe_0_0 == maybe_0_4
    bool_5 = False

# Generated at 2022-06-25 23:55:30.281770
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(True) == Maybe.just(True)

    # Maybe.just(False) == Maybe.just(True)
    assert Maybe.just(False) != Maybe.just(True)

    # Maybe.just(False) != Maybe.nothing()
    assert Maybe.just(False) != Maybe.nothing()

    # Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-25 23:55:38.950677
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    if Maybe.just(None).filter(lambda x: x is None) != Maybe.nothing():
        raise AssertionError
    if Maybe.just(True).filter(lambda x: x) != Maybe.just(True):
        raise AssertionError
    if Maybe.just(True).filter(lambda x: not x) != Maybe.nothing():
        raise AssertionError
    if Maybe.just(None).filter(lambda x: x is not None) != Maybe.nothing():
        raise AssertionError
    if Maybe.just(False).filter(lambda x: not x) != Maybe.just(False):
        raise AssertionError
    if Maybe.nothing().filter(lambda x: x) != Maybe.nothing():
        raise AssertionError
    if Maybe.nothing().filter(lambda x: not x) != Maybe.nothing():
        raise

# Generated at 2022-06-25 23:55:40.744365
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    pass # Nothing to test



# Generated at 2022-06-25 23:55:52.131182
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Maybe.__eq__(Maybe(1, False), Maybe(1, True)) == False
    Maybe.__eq__(Maybe(1, False), Maybe(1, False)) == True
    Maybe.__eq__(Maybe(1, False), Maybe(2, False)) == False
    Maybe.__eq__(Maybe(1, False), Maybe(2, True)) == False
    Maybe.__eq__(Maybe(1, True), Maybe(2, False)) == False
    Maybe.__eq__(Maybe(1, True), Maybe(1, False)) == False
    Maybe.__eq__(Maybe(1, True), Maybe(1, True)) == True
    Maybe.__eq__(Maybe(1, True), Maybe(2, True)) == True
    """

# Generated at 2022-06-25 23:55:57.606403
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Invoke method filter of class with parameters and check result.

    """
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()


# Generated at 2022-06-25 23:56:05.197107
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    true_value = True
    false_value = False
    true_maybe = Maybe.just(true_value)
    false_maybe = Maybe.just(false_value)
    another_false_maybe = Maybe.just(false_value)
    nothing_maybe = Maybe.nothing()
    another_nothing_maybe = Maybe.nothing()
    empty_maybe = Maybe.nothing()
    another_empty_maybe = Maybe.nothing()

    # test for true_maybe
    assert true_maybe == true_maybe
    assert not true_maybe == false_maybe
    assert not true_maybe == nothing_maybe
    assert not true_maybe == empty_maybe

    # test for false_maybe
    assert not false_maybe == true_maybe
    assert false_maybe == false_maybe
    assert false_maybe == another_false_maybe
    assert not false_

# Generated at 2022-06-25 23:56:16.530909
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = Maybe.just(11).__eq__(Maybe.just(11))
    bool_1 = Maybe.just(11).__eq__(Maybe.nothing())
    bool_2 = Maybe.nothing().__eq__(Maybe.just(11))
    bool_3 = Maybe.nothing().__eq__(Maybe.nothing())
    bool_4 = Maybe.just(11).__eq__(Maybe.just(12))
    bool_5 = Maybe.just(11).__eq__(True)
    bool_6 = Maybe.just(11).__eq__(None)

    assert bool_0 == True
    assert bool_1 == False
    assert bool_2 == False
    assert bool_3 == True
    assert bool_4 == False
    assert bool_5 == False
    assert bool_6 == False



# Generated at 2022-06-25 23:56:24.731598
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    obj_0 = Maybe
    obj_1 = Maybe
    obj_2 = Maybe
    obj_3 = Maybe
    obj_4 = Maybe
    obj_5 = Maybe
    obj_6 = Maybe
    obj_7 = Maybe
    obj_8 = Maybe
    obj_9 = Maybe
    obj_10 = Maybe
    obj_11 = Maybe

    assert (obj_0.just(obj_1.just(obj_2).value).__eq__(obj_3.just(obj_4.just(obj_5).value)) == (obj_6.just(obj_7.just(obj_8).value).__eq__(obj_9.just(obj_10.just(obj_11).value))))



# Generated at 2022-06-25 23:56:31.347428
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = True
    bool_1 = False
    Maybe_0 = Maybe.just(bool_0)
    Try_0 = Maybe_0.filter((lambda bool_0: bool_0))
    bool_0 = (lambda bool_0: bool_0)(bool_0)
    Maybe_0 = Maybe.just(bool_0)
    bool_0 = (lambda bool_0: bool_0)()
    bool_0 = True
    bool_0 = True
    assert bool_0 is Try_0.value



# Generated at 2022-06-25 23:56:35.850097
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = Maybe.just(False).filter(lambda x: x)
    assert bool_0 == Maybe.nothing()

    bool_0 = Maybe.just(True).filter(lambda x: x)
    assert bool_0 == Maybe.just(True)

    bool_0 = Maybe.nothing().filter(lambda x: x)
    assert bool_0 == Maybe.nothing()


# Generated at 2022-06-25 23:56:49.059463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_1 = Maybe(bool_0, bool_0)
    assert maybe_0 == maybe_1
    bool_1 = True
    maybe_1 = Maybe(bool_0, bool_1)
    assert not maybe_0 == maybe_1
    bool_2 = True
    int_0 = 0
    maybe_2 = Maybe(int_0, bool_2)
    assert not maybe_0 == maybe_2
    bool_3 = True
    int_1 = 1
    maybe_3 = Maybe(int_1, bool_3)
    assert maybe_2 == maybe_3
    bool_4 = True
    int_2 = 2
    maybe_4 = Maybe(int_2, bool_4)
    assert not maybe_

# Generated at 2022-06-25 23:56:51.465016
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(False, False)
    maybe_1 = Maybe(True, True)
    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1
    assert not(maybe_0 == maybe_1)


# Generated at 2022-06-25 23:56:57.922647
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(5)
    maybe_1 = Maybe.nothing()
    res_0 = maybe_0.filter(lambda x: x>3)
    res_1 = maybe_1.filter(lambda x: x<10)
    assert isinstance(res_0, Maybe)
    assert res_1 is Maybe.nothing()
    assert res_0 is Maybe.just(5)


# Generated at 2022-06-25 23:57:09.632016
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    if not Maybe.just(False) == Maybe.just(False):
        raise AssertionError("Maybe.just(False) is not equal to Maybe.just(False).")
    if Maybe.just(True) != Maybe.just(True):
        raise AssertionError("Maybe.just(False) is not equal to Maybe.just(False).")
    if Maybe.just(True) == Maybe.just(False):
        raise AssertionError("Maybe.just(False) is equal to Maybe.just(False).")
    if Maybe.just(1) == Maybe.nothing():
        raise AssertionError("Maybe.just(1) is equal to Maybe.nothing().")
    if Maybe.nothing() != Maybe.nothing():
        raise AssertionError("Maybe.nothing() is not equal to Maybe.nothing().")

# Generated at 2022-06-25 23:57:16.453379
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    true = True
    false = False

    maybe = Maybe.just(true)
    maybe = maybe.filter(lambda x: x)
    assert maybe.get_or_else(false) == true

    maybe = Maybe.just(false)
    maybe = maybe.filter(lambda x: x)
    assert maybe.get_or_else(false) == false

    maybe = Maybe.nothing()
    maybe = maybe.filter(lambda x: x)
    assert maybe.get_or_else(false) == false



# Generated at 2022-06-25 23:57:18.638684
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(2)
    assert maybe == Maybe(2, not bool(2))
    assert maybe != Maybe(1, not bool(1))


# Generated at 2022-06-25 23:57:25.028133
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.utils import _is_even

    assert isinstance(Maybe.just(1).filter(_is_even), Maybe)
    assert Maybe.just(1).filter(_is_even) == Maybe.nothing()

    assert isinstance(Maybe.just(2).filter(_is_even), Maybe)
    assert Maybe.just(2).filter(_is_even) == Maybe.just(2)

    assert isinstance(Maybe.nothing().filter(_is_even), Maybe)
    assert Maybe.nothing().filter(_is_even) == Maybe.nothing()



# Generated at 2022-06-25 23:57:32.258281
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(2, False) != Maybe(1, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(2, True) != Maybe(1, True)


# Generated at 2022-06-25 23:57:38.137786
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe(lambda x : x + 1, False)
    maybe_1 = maybe_0.to_lazy()
    maybe_2 = maybe_1.map(lambda x : x(1))
    maybe_3 = maybe_2.to_box()

    maybe_4 = maybe_2.to_box()
    maybe_5 = maybe_4.end()

    assert maybe_5 == 2
    assert maybe_3 == 2


# Generated at 2022-06-25 23:57:44.795717
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(3)


# Generated at 2022-06-25 23:58:01.540859
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('Test for eq started')
    maybe_0 = Maybe.just(False)
    maybe_1 = Maybe.just(False)
    maybe_2 = Maybe.just(True)
    maybe_3 = Maybe.nothing()
    maybe_4 = Maybe.nothing()

    if maybe_0 != maybe_1:
        raise AssertionError
    if maybe_0 == maybe_2:
        raise AssertionError
    if maybe_0 == maybe_3:
        raise AssertionError
    if maybe_3 != maybe_4:
        raise AssertionError
    if maybe_3 == maybe_0:
        raise AssertionError

    print(maybe_0)
    print(maybe_1)
    print(maybe_2)
    print(maybe_3)
    print(maybe_4)


# Generated at 2022-06-25 23:58:08.485287
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.typeclass import Functor

    def bool_0_to_bool_1(bool_0):
        bool_1 = bool_0
        return bool_1

    def bool_1_to_bool_2(bool_1):
        bool_2 = bool_1
        return bool_2

    maybe_bool_0 = Maybe(bool_0_to_bool_1, False)
    maybe_bool_1 = maybe_bool_0.map(bool_1_to_bool_2)
    assert Functor[Maybe].map(maybe_bool_1, bool_1_to_bool_2) == maybe_bool_0


# Generated at 2022-06-25 23:58:13.829370
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just("Maybe")
    lazy = maybe.to_lazy()
    unit_testing.assert_equals("Maybe", lazy.evaluate())

    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    unit_testing.assert_equals(None, lazy.evaluate())


# Generated at 2022-06-25 23:58:16.704804
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(lambda x: x * 2)

    assert maybe.to_lazy() == Lazy(lambda: lambda x: x * 2)


# Generated at 2022-06-25 23:58:26.016120
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(True, True)
    maybe_1 = Maybe(None, True)
    maybe_2 = Maybe(True, True)
    maybe_3 = Maybe(False, False)
    maybe_4 = Maybe(False, True)
    maybe_5 = Maybe(None, True)
    maybe_6 = Maybe(True, False)
    maybe_7 = Maybe(True, False)
    maybe_8 = Maybe(False, False)
    maybe_9 = Maybe(None, False)
    maybe_10 = Maybe(True, True)
    maybe_11 = Maybe(True, False)
    assert maybe_0 == maybe_2
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_5
    assert maybe_3 == maybe_7
    assert maybe_4 == maybe_0
    assert maybe_6

# Generated at 2022-06-25 23:58:33.573897
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe

    just_0 = Maybe.just(False)
    assert just_0.filter(lambda x: not x).to_box().value == False
    just_1 = Maybe.just(True)
    assert just_1.filter(lambda x: not x).to_box().is_nothing == True
    nothing_0 = Maybe.nothing().filter(lambda x: not x)
    assert nothing_0.to_box().is_nothing == True


# Generated at 2022-06-25 23:58:43.213713
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(True)
    maybe_0_1 = maybe_0.filter(lambda x: x)
    maybe_0_2 = maybe_0.filter(lambda x: not x)

    assert maybe_0_1.get_or_else(None)
    assert not maybe_0_2.get_or_else(None) is True

    maybe_1 = Maybe.just(None)
    maybe_1_1 = maybe_1.filter(lambda x: x)
    maybe_1_2 = maybe_1.filter(lambda x: not x)

    assert not maybe_1_1.get_or_else(None)
    assert not maybe_1_2.get_or_else(None)

    maybe_2 = Maybe.nothing()

# Generated at 2022-06-25 23:58:49.917209
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(None)
    maybe_1 = maybe_0.filter(lambda x: False)
    assert maybe_1 == Maybe.nothing()
    maybe_0 = Maybe.just(None)
    maybe_1 = maybe_0.filter(lambda x: True)
    assert maybe_1 == Maybe.just(None)
    maybe_0 = Maybe.just(bool())
    maybe_1 = maybe_0.filter(lambda x: True)
    assert maybe_1 == Maybe.just(bool())
    maybe_0 = Maybe.just(bool())
    maybe_1 = maybe_0.filter(lambda x: False)
    assert maybe_1 == Maybe.nothing()
    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(lambda x: True)

# Generated at 2022-06-25 23:58:56.878611
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    try:
        bool_0 = False
        maybe_0 = Maybe(bool_0, bool_0)
        maybe_1 = maybe_0.__eq__(maybe_0)
        bool_1 = maybe_0.is_nothing
        bool_2 = maybe_0.is_nothing
        bool_3 = False
    except:
        bool_3 = False
    assert (bool_1 == bool_2 and bool_3)



# Generated at 2022-06-25 23:59:01.088057
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(0, True)
    assert maybe_0 == Maybe.nothing()
    assert maybe_0 != Maybe.just(0)

    maybe_1 = Maybe.just(0)
    assert maybe_1 == Maybe.just(0)
    assert maybe_1 != Maybe.nothing()



# Generated at 2022-06-25 23:59:09.106219
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.nothing()

    assert maybe.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-25 23:59:16.210040
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(None)
    maybe_1 = Maybe.just(False)
    maybe_2 = Maybe.just(True)

    def func0(value):
        return isinstance(value, bool)

    value_None_0 = maybe_0.filter(func0)
    value_None_1 = maybe_1.filter(func0)
    value_True_0 = maybe_2.filter(func0)
    value_True_1 = Maybe.nothing().filter(func0)

    assert value_None_0.is_nothing
    assert value_None_0 == Maybe.nothing()
    assert value_None_1.is_nothing
    assert value_None_1 == Maybe.nothing()
    assert value_True_0.is_nothing
    assert value_True_0 == Maybe.nothing()

# Generated at 2022-06-25 23:59:20.754244
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    bool_1 = True
    maybe_0 = Maybe(bool_0, False)
    maybe_2 = Maybe(bool_0, False)
    maybe_3 = Maybe(bool_1, True)
    assert maybe_0 == maybe_2
    assert maybe_3 == Maybe.nothing()
    assert maybe_0 != maybe_3
    assert maybe_2 != maybe_3


# Generated at 2022-06-25 23:59:24.127335
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def value():
        return 5

    maybe = Maybe.just(value)
    assert isinstance(maybe.to_lazy(), Lazy)
    assert maybe.to_lazy().value().__call__() == value()



# Generated at 2022-06-25 23:59:34.378661
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.validation import Validation

    maybe_0 = Maybe(0, False)
    validation_0 = maybe_0.to_lazy()
    validation_1 = validation_0.map(lambda x: x)
    validation_2 = validation_1.map(lambda x: x)
    validation_3 = validation_2.map(lambda x: x)
    validation_4 = validation_3.map(lambda x: Validation.failure(x))
    validation_4.map(lambda x: x)
    x = "".join(str(x) for x in validation_4._messages)
    x = validation_3.map(lambda x: Validation.failure(x))
    validation_5 = x.map(lambda x: x)
    x = "".join(validation_0._messages)

# Generated at 2022-06-25 23:59:38.844661
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x == 10) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x > 5) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x < 20) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x > 0) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x < 30) == Maybe.just(10)


# Generated at 2022-06-25 23:59:42.725593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 3 == 0) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 3 == 0) == Maybe.nothing()


# Generated at 2022-06-25 23:59:45.957841
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-25 23:59:52.367495
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Call to_lazy method of class Maybe with empty Maybe
    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    # Assert that previous value do not stored in lazy
    assert lazy.value() is None
    # Assert that reference of lazy value is not previous value
    assert lazy.value() is not None
    # Assert that previous value stored in lazy
    assert lazy.value() == None

    # Call to_lazy method of class Maybe with not empty Maybe
    maybe = Maybe.just(True)
    lazy = maybe.to_lazy()
    # Assert that previous value stored in lazy
    assert lazy.value() == maybe.value
    # Assert that reference of lazy value is not previous value
    assert lazy.value() is not maybe.value

#

# Generated at 2022-06-26 00:00:01.603278
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    maybe_0 = Maybe(1, False)
    maybe_1 = Maybe(2, False)
    maybe_2 = Maybe(2, True)

    maybe_0_0 = Maybe(None, True)
    maybe_0_1 = Maybe(1, False)
    maybe_0_2 = Maybe(2, False)
    maybe_0_3 = Maybe(3, True)

    # When
    result_0 = maybe_0.__eq__(maybe_1)
    result_1 = maybe_0.__eq__(maybe_2)
    result_2 = maybe_0.__eq__(maybe_0_0)
    result_3 = maybe_0.__eq__(maybe_0_1)
    result_4 = maybe_0.__eq__(maybe_0_2)
    result_

# Generated at 2022-06-26 00:00:10.795966
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:00:13.373436
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = bool(0)
    maybe_0 = Maybe(bool_0, bool_0)
    lazy_1 = maybe_0.to_lazy()
    lazy_1_value = lazy_1.value()

    if bool_0:
        assert lazy_1_value == False
    else:
        assert lazy_1_value == None


# Generated at 2022-06-26 00:00:19.383539
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    boolean_func = lambda: 3

    maybe_0 = Maybe.just(boolean_func)
    lazy_0 = maybe_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0 == Lazy(boolean_func)



# Generated at 2022-06-26 00:00:24.799993
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_a = Maybe.just('a')
    maybe_b = maybe_a.filter(lambda x: x == 'a')

    assert maybe_a == maybe_b

    maybe_c = maybe_a.filter(lambda x: x == 'b')

    assert maybe_c != maybe_a
    assert maybe_c.is_nothing


# Generated at 2022-06-26 00:00:31.584026
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Setting up the test case
    maybe_0 = Maybe.just([])

    # Testing the method to_lazy of class Maybe
    lazy_0 = maybe_0.to_lazy()
    lazy_0_0 = lazy_0.value

    # Checking the result
    if (maybe_0 is maybe_0) and (maybe_0.value == []):
        status = 'Ok'
    else:
        status = 'Fail'

    # Printing the result
    print('status:', status)

    # Returning the result
    return status



# Generated at 2022-06-26 00:00:34.885004
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    global bool_0
    bool_0 = False
    maybe_0 = Maybe(bool_0, bool_0)
    assert maybe_0.to_lazy() is not None



# Generated at 2022-06-26 00:00:42.565347
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    bool_1 = True
    maybe__1 = Maybe.just(bool_0)
    maybe__2 = maybe__1.filter(mapper=bool)
    assert maybe__2 == Maybe(bool_0, bool_0)
    maybe__3 = maybe__1.filter(mapper=lambda x: x)
    assert maybe__3 == Maybe.nothing()
    maybe__4 = Maybe.nothing()
    maybe__5 = maybe__4.filter(mapper=bool)
    assert maybe__5 == Maybe.nothing()
    bool_2 = not bool_0
    maybe__6 = maybe__1.filter(mapper=lambda x: bool_2)
    assert maybe__6 == Maybe(bool_0, bool_0)
    bool_3 = not bool_2

# Generated at 2022-06-26 00:00:48.773903
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import unittest

    def test_cases():
        bool_0 = False
        Maybe_0 = Maybe(bool_0, bool_0)
        Maybe_1 = Maybe_0.to_lazy()

        from pymonet.monad_try import Try

        result = Maybe_0.to_try()
        expected = Try(bool_0, is_success=False)
        assert result == expected

        result = Maybe_1.run()
        expected = bool_0
        assert result == expected



# Generated at 2022-06-26 00:00:52.120738
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_0.get() == None
    assert lazy_1.get() == 1


# Generated at 2022-06-26 00:01:00.759881
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    bool_1 = True
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_1 = Maybe(bool_0, bool_1)
    maybe_2 = Maybe(bool_0, bool_0)
    maybe_3 = Maybe(bool_1, bool_1)
    maybe_4 = Maybe(bool_0, bool_0)
    maybe_5 = Maybe(bool_1, bool_1)
    maybe_6 = Maybe(bool_0, bool_0)
    maybe_7 = Maybe(bool_1, bool_1)
    maybe_8 = Maybe(bool_0, bool_0)
    maybe_9 = Maybe(bool_1, bool_1)
    maybe_10 = Maybe(bool_0, bool_0)

# Generated at 2022-06-26 00:01:23.331714
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value_0 = 3.8545069586693
    bool_0 = False
    maybe_0 = Maybe(value_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == value_0
    value_1 = "k&9(*2"
    bool_1 = True
    maybe_1 = Maybe(value_1, bool_1)
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == value_1
    float_0 = 0.2997
    float_1 = 9.0
    int_0 = 18
    float_

# Generated at 2022-06-26 00:01:32.459024
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    input_1 = False
    input_2 = True
    mapper_bool_to_maybe_bool_0 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_1 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_2 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_3 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_4 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_5 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_bool_6 = lambda boolean: Maybe.just(boolean)
    mapper_bool_to_maybe_

# Generated at 2022-06-26 00:01:36.713147
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    val_0 = Maybe.just(2)
    val_1 = Maybe.nothing()
    val_0_filter = val_0.filter(lambda a: a == 1)
    val_1_filter = val_1.filter(lambda a: a == 0)
    assert val_0_filter == Maybe.nothing()
    assert val_1_filter == Maybe.nothing()



# Generated at 2022-06-26 00:01:39.328854
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_0.filter(lambda x: bool_0)



# Generated at 2022-06-26 00:01:45.415469
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    def test_1():
        maybe_0: Maybe[int] = Maybe.nothing()

        def expected_result_0():
            return lambda : None

        lazy_0: Lazy[Callable] = maybe_0.to_lazy()
        try:
            assert lazy_0.resolve() == expected_result_0()
        except AssertionError as e:
            print(lazy_0.resolve(), expected_result_0(), sep='\n', end='\n\n')
            raise e



# Generated at 2022-06-26 00:01:50.830089
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.just(0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_1, Lazy)
    assert lazy_0() == None
    assert lazy_1() == 0


# Generated at 2022-06-26 00:01:56.180447
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Checking with empty Maybe
    maybe_0 = Maybe.nothing()
    assert(maybe_0.to_lazy() == Lazy(lambda: None))
    # Checking with not empty Maybe
    int_0 = 0
    maybe_1 = Maybe(int_0, False)
    assert(maybe_1.to_lazy() == Lazy(lambda: int_0))



# Generated at 2022-06-26 00:02:01.911831
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    MaybeA = Maybe.just(True)
    MaybeB = MaybeA.filter(lambda x: x)
    MaybeC = MaybeA.filter(lambda x: not x)
    MaybeD = Maybe(1, True).filter(lambda x: x)

    assert MaybeB.value is True
    assert MaybeC.is_nothing
    assert MaybeD.is_nothing



# Generated at 2022-06-26 00:02:05.160494
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    maybe_0 = Maybe.just(3)
    box_0 = maybe_0.filter(lambda x: (x > 3))
    assert box_0.is_empty()



# Generated at 2022-06-26 00:02:09.354164
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # ================== Initialization ==================
    value = 0
    value_expected = 0
    maybe = Maybe(value, False)
    is_even = lambda x: x % 2 == 0
    # ================== Action ==================
    maybe_filtered = maybe.filter(is_even)
    # ================== Asserting ==================
    assert value_expected == maybe_filtered.value


# Generated at 2022-06-26 00:02:24.760364
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    
    assert Maybe.just(Box(6)).to_lazy() == Lazy(lambda: Box(6))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:02:28.131168
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    maybe_0 = Maybe.nothing()

    assert(maybe_0.to_lazy().call() is None)

    maybe_1 = Maybe.just(bool_0)

    assert(maybe_1.to_lazy().call() is bool_0)


# Generated at 2022-06-26 00:02:33.295666
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for Maybe.to_lazy.

    :returns: True when Maybe.to_lazy works correctly, in other case False
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    assert Maybe.just(100).to_lazy().value() == 100
    assert Maybe.nothing().to_lazy().value() == None
    return True


# Generated at 2022-06-26 00:02:45.234551
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(None)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy(lambda: maybe_0.value)
    assert lazy_0.force() == maybe_0.value

    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1 == Lazy(lambda: maybe_1.value)
    assert lazy_1.force() == maybe_1.value
    assert maybe_1.value is None

    bool_a = False
    bool_b = True
    maybe_2 = Maybe(bool_a, bool_b)
    lazy_2 = maybe_2.to_lazy()

# Generated at 2022-06-26 00:02:48.000564
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(1)
    assert maybe_0.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-26 00:02:52.503159
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def foo():
        return 41

    lazy = Maybe.just(foo).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == foo()


# Generated at 2022-06-26 00:02:54.235038
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = False
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_0.to_lazy()


# Generated at 2022-06-26 00:02:56.892428
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: None)
    lazy_1 = Maybe.nothing().to_lazy()

    assert lazy_0 == lazy_1

