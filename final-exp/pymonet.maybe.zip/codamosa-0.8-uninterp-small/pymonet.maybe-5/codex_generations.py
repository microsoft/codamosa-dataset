

# Generated at 2022-06-25 23:53:10.676300
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Should be Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x + 1) \
        .filter(lambda x: x == 2) == Maybe.just(2)

    # Should be Maybe.just(2)
    assert Maybe.just(2).map(lambda x: x + 1) \
        .filter(lambda x: x == 2) == Maybe.just(2)

    # Should be Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)

    # Should be Maybe.nothing()
    assert Maybe.just(2).map(lambda x: x + 1) \
        .filter(lambda x: x == 1) == Maybe.nothing()

    # Should be Maybe.nothing()

# Generated at 2022-06-25 23:53:17.213521
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    $ python
    $ >>> from pymonet.monad.maybe import Maybe
    $ >>> Maybe.just(True).filter(lambda x: x).get_or_else(False)
    True
    $ >>> Maybe.just(False).filter(lambda x: x).get_or_else(False)
    False
    $ >>> Maybe.filter(bool_0, bool_0).get_or_else(False)
    False
    $ >>>
    """
    bool_0 = False
    bool_1 = True
    test_bool_0 = bool_0
    test_bool_1 = bool_1
    maybe_0 = Maybe.just(test_bool_0)
    maybe_1 = Maybe.just(test_bool_1)

# Generated at 2022-06-25 23:53:29.155985
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(True)
    maybe_1 = Maybe.just(False)
    maybe_2 = Maybe.just(None)
    maybe_3 = Maybe.nothing()
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.just({})
    assert maybe_0 == Maybe(True, False)
    assert maybe_1 == Maybe(False, False)
    assert maybe_2 == Maybe(None, False)
    assert maybe_3 == Maybe(None, True)
    assert maybe_3 == maybe_4
    assert maybe_0 != Maybe(False, False)
    assert maybe_0 != Maybe(None, False)
    assert maybe_0 != Maybe(None, True)
    assert maybe_0 != maybe_1
    assert maybe_0 != None
    assert maybe_2 != maybe_5

# Unit

# Generated at 2022-06-25 23:53:35.885233
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-25 23:53:46.320776
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)
    int_0 = 0
    bool_1 = False
    maybe_1 = Maybe.just(bool_1)
    maybe_2 = Maybe(int_0, bool_1)
    maybe_3 = Maybe.just(int_0)
    maybe_4 = Maybe(int_0, bool_0)
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_0
    assert maybe_2 == maybe_3
    assert maybe_3 == maybe_2
    assert maybe_4 == maybe_4
    bool_2 = False
    maybe_5 = Maybe(bool_2, bool_2)
    bool_3 = False
    maybe_6 = Maybe(bool_3, bool_3)
    int_1 = 0
   

# Generated at 2022-06-25 23:53:51.826548
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)
    bool_1 = True
    maybe_1 = Maybe.just(bool_1)
    assert maybe_0 == maybe_0
    assert maybe_1 == maybe_1
    assert maybe_0 != maybe_1



# Generated at 2022-06-25 23:53:58.404380
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = Maybe.nothing() == Maybe.nothing()
    bool_1 = Maybe.just(10) == Maybe.nothing()
    bool_2 = Maybe.nothing() == Maybe.just(10)
    bool_3 = Maybe.just(10) == Maybe.just(10)
    bool_4 = Maybe.just(10) == Maybe.just(20)


# Generated at 2022-06-25 23:54:05.169224
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = True
    bool_1 = False
    bool_2 = True

# Generated at 2022-06-25 23:54:12.332495
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe.just(False)
    maybe_1 = Maybe.just(True)
    maybe_2 = Maybe.just(False)
    maybe_3 = Maybe.nothing()
    maybe_4 = Maybe.nothing()

    assert maybe_0 == maybe_0
    assert not maybe_1 == maybe_0
    assert maybe_0 == maybe_2
    assert maybe_3 == maybe_3
    assert maybe_3 == maybe_4



# Generated at 2022-06-25 23:54:16.907598
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    maybe_0 = Maybe(0, True)
    maybe_1 = Maybe(0, True)
    expected_result_0: bool = True
    # Exercise
    actual_result_0 = maybe_0 == maybe_1
    # Verify
    assert actual_result_0 == expected_result_0


# Generated at 2022-06-25 23:54:22.909822
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda v: v != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v != 1) == Maybe.nothing()



# Generated at 2022-06-25 23:54:32.835613
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    maybe_0 = Maybe(bool_0, bool_0)
    string_0 = 'False'
    result_0 = maybe_0.filter(lambda x: x == string_0)
    bool_1 = True
    maybe_1 = Maybe(string_0, bool_1)
    result_1 = maybe_1.filter(lambda x: x == string_0)
    assert Maybe.just(result_1) == Maybe.just(result_0)


# Generated at 2022-06-25 23:54:36.383678
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda v: v % 2 == 0) == Maybe.nothing()
    assert Maybe.just(6).filter(lambda v: v % 2 == 0) == Maybe.just(6)


# Generated at 2022-06-25 23:54:39.475711
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0() # where bool_0 == False
    test_case_1() # where bool_0 == True


# Generated at 2022-06-25 23:54:43.369367
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(2)
    assert maybe.filter(lambda x: x > 1).get_or_else(1) == 2
    assert maybe.filter(lambda x: x < 1).get_or_else(1) == 1



# Generated at 2022-06-25 23:54:52.309153
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)

    assert maybe_0.filter(lambda val: val is False).get_or_else(None) == bool_0

# Generated at 2022-06-25 23:55:03.724414
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from tests.test_helpers import remove_whitespace
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    maybe_0 = Maybe(None, True)

    # removing whitespace and newlines
    # checking that true is equal to False
    # removing whitespace and newlines
    # checking that true is equal to False
    assert remove_whitespace(maybe_0) == remove_whitespace(Maybe(None, True))

    # checking that Maybe.to_lazy results in Maybe.to_lazy when Maybe is empty
    assert remove_whitespace(maybe_0.to_lazy()) == remove_whitespace(Maybe(None, True).to_lazy())

    # removing whitespace and newlines
    # checking that true is equal to False
    # removing whitespace

# Generated at 2022-06-25 23:55:09.934118
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Method to_lazy of class Maybe.

    :return:
    """
    m1 = Maybe.just(1)
    assert m1.to_lazy().run() == 1

    m2 = Maybe.nothing()
    assert m2.to_lazy().run() == None



# Generated at 2022-06-25 23:55:14.933431
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda b: b == True) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda b: b == False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda b: b == True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda b: b == False) == Maybe.nothing()


# Generated at 2022-06-25 23:55:21.043715
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 2
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda arg0 : arg0 > 1)
    assert maybe_1 == Maybe.just(2)
    bool_0 = True
    maybe_2 = maybe_1.filter(lambda arg0 : arg0 > 2)
    assert maybe_2 == Maybe.nothing()


# Generated at 2022-06-25 23:55:30.519157
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Method filter of Maybe should return new instance of Maybe with value when
    filterer return True, in other case return None

    :return:
    """
    assert Maybe.just("hello").filter(lambda string: len(string) == 5) == Maybe("hello", False)
    assert Maybe.just("hello").filter(lambda string: len(string) == 6) == Maybe(None, True)



# Generated at 2022-06-25 23:55:33.958831
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe_0 = Maybe.just(1)
    lazy_0 = Lazy(lambda: 1)
    assert lazy_0 == maybe_0.to_lazy()


# Generated at 2022-06-25 23:55:36.148413
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(False)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value()


# Generated at 2022-06-25 23:55:37.429367
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() == None


# Generated at 2022-06-25 23:55:46.388152
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    maybe_0 = Maybe(bool_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == bool_0

# Generated at 2022-06-25 23:55:57.607182
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    maybe_0 = Maybe(1, False)
    maybe_1 = Maybe(None, None)
    box_0 = maybe_0.to_box()
    box_1 = Maybe.just(1).to_box()
    either_0 = maybe_0.to_either()
    either_1 = Maybe.nothing().to_either()
    lazy_0 = Maybe.just(1).to_lazy()
    lazy_1 = Maybe.nothing().to_lazy()
    try_0 = Maybe.just(1).to_try

# Generated at 2022-06-25 23:56:03.685004
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import identity
    from pymonet.lazy import Lazy

    true_0 = True
    maybe_0 = Maybe.just(true_0)
    lazy_0 = maybe_0.to_lazy()
    maybe_1 = maybe_0.map(identity)
    lazy_1 = maybe_1.to_lazy()
    if (maybe_0 == maybe_1):
        print("OK")
    else:
        print("KO")
    if (lazy_0 == lazy_1):
        print("OK")
    else:
        print("KO")


# Generated at 2022-06-25 23:56:07.875566
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(100)
    maybe_lazy_0 = maybe_0.to_lazy()
    maybe_lazy_1 = maybe_lazy_0.to_lazy()
    assert maybe_lazy_0 == maybe_lazy_1



# Generated at 2022-06-25 23:56:16.922592
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    maybe_none = Maybe.nothing()
    assert maybe_1.filter(lambda x: x==1) == Maybe.just(1)
    assert maybe_1.filter(lambda x: x==2) == Maybe.nothing()
    assert maybe_none.filter(lambda: True) == Maybe.nothing()
    assert maybe_2.filter(lambda x: x==1) == Maybe.nothing()
    assert maybe_2.filter(lambda x: x==2) == Maybe.just(2)


# Generated at 2022-06-25 23:56:24.271931
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # prepare data for test
    bool_0 = False
    bool_1 = True
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_1 = Maybe(bool_1, bool_0)

    # do assert
    assert maybe_0.filter(lambda: bool_0) == maybe_0.nothing()
    assert maybe_0.filter(lambda: bool_1) == maybe_0.nothing()
    assert maybe_1.filter(lambda: bool_0) == maybe_0.nothing()
    assert maybe_1.filter(lambda: bool_1) == maybe_1



# Generated at 2022-06-25 23:56:28.052431
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert_equal(
        Maybe.just(1).to_lazy(),
        Lazy(lambda: 1)
    )



# Generated at 2022-06-25 23:56:32.308557
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    JustInt = Maybe.just(100)
    Nothing = Maybe.nothing()

    JustIntAfterFilter = JustInt.filter(lambda int_: int_ < 10)
    assert JustIntAfterFilter == Maybe.nothing()

    NothingAfterFilter = Nothing.filter(lambda int_: int_ < 10)
    assert NothingAfterFilter == Maybe.nothing()


# Generated at 2022-06-25 23:56:36.160529
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(2)
    maybe_1 = maybe_0.filter(lambda x : x == 2)
    assert(isinstance(maybe_1, Maybe))
    assert(maybe_1.is_nothing == False)
    assert(maybe_1.value == 2)



# Generated at 2022-06-25 23:56:47.499201
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_100 = 100
    int_0 = 0
    bool_true = True
    bool_false = False

    # create new maybe
    maybe_0 = Maybe.just(int_0)
    maybe_100 = Maybe.just(int_100)

    # check type
    assert isinstance(maybe_0, Maybe)
    assert isinstance(maybe_100, Maybe)

    # check values
    assert maybe_0.value == int_0
    assert maybe_100.value == int_100

    # create possibly new values
    maybe_new_0 = maybe_0.filter(lambda a: a > 0)
    maybe_new_100 = maybe_100.filter(lambda a: a > 0)

    # check type
    assert isinstance(maybe_new_0, Maybe)

# Generated at 2022-06-25 23:56:50.167967
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Some
    some_int = Maybe.just(100)
    test_case_1(some_int)
    # Nothing
    nothing_int = Maybe.nothing()
    test_case_2(nothing_int)


# Generated at 2022-06-25 23:56:52.413122
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 23:56:57.016170
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    int_0 = 100

    # assert method to_lazy with value
    assert Maybe.just(int_0).to_lazy().get() == int_0

    # assert method to_lazy with None
    assert Maybe.nothing().to_lazy().get() is None


# Generated at 2022-06-25 23:57:00.798655
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda:1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:06.592969
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    n = 100
    def filterer(x: Maybe[int]) -> bool:
        return x > 10

    assert Maybe.just(n).filter(filterer) == Maybe.just(n)
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()

if __name__ == "__main__":
    test_case_0()
    test_Maybe_filter()

# Generated at 2022-06-25 23:57:17.156654
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_case_0():
        int_0 = 100
        maybe_0 = Maybe.just(int_0)
        maybe_1 = maybe_0.filter(lambda int_1: int_1 > 0)
        assert maybe_1 == Maybe.just(int_0)
        maybe_2 = maybe_0.filter(lambda int_1: int_1 < 0)
        assert maybe_2 == Maybe.nothing()

    def test_case_1():
        string_0 = 'test'
        maybe_0 = Maybe.just(string_0)
        maybe_1 = maybe_0.filter(lambda string_1: string_1 != '')
        assert maybe_1 == Maybe.just(string_0)
        maybe_2 = maybe_0.filter(lambda string_1: string_1 == '')
        assert maybe_

# Generated at 2022-06-25 23:57:25.514628
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(
        Maybe.just(100).filter(lambda x: x > 10).get_or_else(None) == 100
    )

    assert(
        Maybe.just(100).filter(lambda x: x < 10).get_or_else(None) is None
    )

    assert(
        Maybe.nothing().filter(lambda x: x > 10).get_or_else(None) is None
    )



# Generated at 2022-06-25 23:57:27.774993
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_case_0()
    test_case_1()   
    test_case_2()


# Generated at 2022-06-25 23:57:32.641896
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    result_to_lazy_0 = Maybe.just(20).to_lazy()
    assert isinstance(result_to_lazy_0, Lazy)
    result_to_lazy_1 = Maybe.nothing().to_lazy()
    assert isinstance(result_to_lazy_1, Lazy)


# Generated at 2022-06-25 23:57:41.491223
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Valid
    integer_value_0 = Valid(500)
    integer_value_1 = Valid(100)
    integer_value_2 = Valid(100)
    integer_value_3 = Valid(1000)

    res_0 = integer_value_0.filter(lambda x: x > 200)
    assert res_0 == Valid(500)

    res_1 = integer_value_1.filter(lambda x: x > 200)
    assert res_1 == Valid(None)

    res_2 = integer_value_2.filter(lambda x: x > 100)
    assert res_2 == Valid(None)

    res_3 = integer_value_3.filter(lambda x: x < 500)
    assert res_3 == Valid(None)


# Generated at 2022-06-25 23:57:43.383807
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_case_0()
    assert Maybe.just(42).to_lazy().evaluate() == 42
    assert Maybe.nothing().to_lazy().evaluate() == None


# Generated at 2022-06-25 23:57:52.704455
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    val = 100
    m_int_0 = Maybe.just(val)
    m_none_0 = Maybe.nothing()
    m_none_1 = Maybe.nothing()
    # m_int_0.to_lazy() == m_none_0.to_lazy()
    assert m_int_0.to_lazy().get() == val
    assert m_none_0.to_lazy().get() is None
    assert m_none_1.to_lazy().get() is None
    # assert m_int_0.to_lazy().is_success()
    # assert m_none_0.to_lazy().is_failure()


# Generated at 2022-06-25 23:57:56.816857
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_a = Maybe.just(int_0)
    maybe_a_filtered = maybe_a.filter(lambda x: x > 0)

    assert maybe_a_filtered == Maybe.just(int(int_0))
    assert maybe_a != maybe_a_filtered


# Generated at 2022-06-25 23:58:01.990807
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_cases = [
        (Maybe.just(int), Maybe.just(int)) for int in [i for i in range(0, 11)]
    ]

    def filterer(value):
        def is_even(value):
            return True if value % 2 == 0 else False

        return is_even(value)

    for maybe, expected in test_cases:
        result = maybe.filter(filterer)
        assert result == expected


# Generated at 2022-06-25 23:58:12.089273
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100

    assert Maybe.just(int_0).filter(lambda x: True) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(int_0).filter(lambda x: x > 200) == Maybe.nothing()
    assert Maybe.just(int_0).filter(lambda x: x < 200) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(lambda x: 3 < x < 200) == Maybe.just(int_0)

# Generated at 2022-06-25 23:58:21.225182
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Success case
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.eval() == maybe_0.value

    # Success case
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.eval() == maybe_0.value

    # Success case
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.eval() == maybe_0.value


# Generated at 2022-06-25 23:58:26.425704
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:58:38.119936
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    test the method filter of class Maybe for when Maybe is nothing, empty and not empty
    """
    print("Testing filter method of Maybe")

    # Test for when Maybe is nothing
    print("testing for nothing: ")
    test_not_nothing = Maybe.nothing()
    test_yes_nothing = Maybe.nothing()
    if test_yes_nothing.filter(lambda x: x > 100) == test_not_nothing.filter(lambda x: x > 100):
        print("Passed test for nothing")

    # Test for when Maybe is empty
    print("testing for empty: ")
    test_not_empty = Maybe(10, False)
    test_yes_empty = Maybe(10, False)

# Generated at 2022-06-25 23:58:39.860230
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(int_0).filter(lambda a: a>= 100)
    assert a.value == int_0


# Generated at 2022-06-25 23:58:41.632514
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).to_lazy().call() == \
        Lazy(lambda y: 10).call()


# Generated at 2022-06-25 23:58:45.066552
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(1).to_lazy() == Lazy(lambda: 1))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))
    test_case_0()



# Generated at 2022-06-25 23:58:48.522086
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(100)
    maybe_1 = maybe_0.filter(lambda x : x == 100)
    maybe_1 = maybe_0.filter(lambda x : x < 100)
    this = maybe_1.get_or_else(0)
    assert maybe_1.get_or_else(0) == 0
    pass


# Generated at 2022-06-25 23:58:52.125581
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    maybe_result_0 = maybe_0.to_lazy()

    assert maybe_result_0 is not None


# Generated at 2022-06-25 23:58:57.656307
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Test case 0
    def test_case_0(lazy: Lazy) -> bool:
        assert lazy.get() == int_0

    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    test_case_0(lazy_0)

# Generated at 2022-06-25 23:59:04.911216
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    int_0 = 100

    m_0 = Maybe.just(int_0)
    assert isinstance(m_0, Maybe)

    l_0 = m_0.to_lazy()
    assert isinstance(l_0, Lazy)

    int_1 = l_0()
    assert isinstance(int_1, int)
    assert int_1 == int_0


# Generated at 2022-06-25 23:59:07.145831
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe = Maybe.just(int_0)
    result = maybe.filter(lambda i: i % 2 == 0)
    assert result == maybe



# Generated at 2022-06-25 23:59:14.973735
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    assert maybe_0.to_lazy()().value == int_0



# Generated at 2022-06-25 23:59:16.952128
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-25 23:59:21.789721
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()

    default_value = 200

    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()

    assert lazy_0.avalue() == maybe_0.value
    assert lazy_1.avalue() == default_value



# Generated at 2022-06-25 23:59:26.970752
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    val_0 = 100
    val_1 = -10
    m_val_0 = Maybe.just(val_0)

    lazy_1 = Lazy(lambda: val_1)
    lazy_2 = m_val_0.to_lazy()

    assert lazy_1.value == lazy_2.value

    assert val_0 == lazy_1.value()


# Generated at 2022-06-25 23:59:37.624216
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # int_0 divisible by 2
    int_1 = 100
    int_2 = 99
    int_3 = 101
    int_4 = 0

    assert_that(Maybe.nothing().filter(lambda x: x % 2 == 0), is_(Maybe.nothing()))
    assert_that(Maybe.just(int_0).filter(lambda x: x % 2 == 0), is_(Maybe.just(int_1)))

    assert_that(Maybe.just(int_0).filter(lambda x: x % 2 == 0), is_(
        Maybe.just(int_1).filter(lambda x: x % 2 == 0)))
    assert_that(Maybe.just(int_0).filter(lambda x: x % 2 == 0), is_not(
        Maybe.just(int_1).filter(lambda x: x % 2 == 0)))


# Generated at 2022-06-25 23:59:46.388820
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 11
    int_1 = 23
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.just(int_1)
    bool_0 = True
    bool_1 = False
    maybe_0 = maybe_0.filter((lambda x: ((x == int_0) if bool_1 else (x != int_0)) if bool_1 else (x != int_0)))
    if maybe_0.is_nothing or maybe_0.get_or_else(0) != int_1:
        raise RuntimeError("")
    maybe_0 = maybe_0.filter((lambda x: ((x == int_0) if bool_1 else (x != int_0)) if bool_1 else (x != int_0)))

# Generated at 2022-06-25 23:59:49.103395
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just(100)
    assert m.to_lazy().value()() == 100
    assert m.to_lazy().value() is not 100

    m = Maybe.nothing()
    assert m.to_lazy().value()() is None


# Generated at 2022-06-25 23:59:51.374245
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe(100, is_nothing = False)
    assert maybe.to_lazy().force() == 100

    maybe = Maybe.nothing()
    assert maybe.to_lazy().force() == None


# Generated at 2022-06-26 00:00:00.711772
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 10
    int_1 = 100
    int_2 = 1000
    int_3 = 10000
    maybe = Maybe.just(int_0)
    maybe = maybe.filter(lambda v: v < int_1)
    if maybe != Maybe.just(int_0):
        raise AssertionError()
    maybe = Maybe.just(int_0)
    maybe = maybe.filter(lambda v: v > int_1)
    if maybe != Maybe.nothing():
        raise AssertionError()
    maybe = Maybe.just(int_0)
    maybe = maybe.filter(lambda v: v < int_1).filter(lambda v: v > int_2)
    if maybe != Maybe.nothing():
        raise AssertionError()
    maybe = Maybe.just(int_0)
    maybe = maybe.filter

# Generated at 2022-06-26 00:00:07.116679
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    maybe = Maybe.just(1)
    result = maybe.to_lazy()
    assert isinstance(result, Lazy)

    maybe = Maybe.nothing()
    result = maybe.to_lazy()
    assert isinstance(result, Lazy)


# Generated at 2022-06-26 00:00:25.495629
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_1 = 99
    int_2 = 50
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda parameter_0: (parameter_0>int_1)and(parameter_0<int_2))
    assert (maybe_2 == Maybe.just(int_0))


# Generated at 2022-06-26 00:00:27.835444
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just("Test").to_lazy().value() == "Test"
    assert Maybe.nothing().to_lazy().value() is None


# Generated at 2022-06-26 00:00:33.392497
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Case 1:
    ma = Maybe.just(1)
    assert ma.filter(lambda x: x == 1) == Maybe.just(1)
    assert ma.filter(lambda x: x == 2) == Maybe.nothing()

    # Case 2:
    ma = Maybe.nothing()
    assert ma.filter(lambda x: x == 1) == Maybe.nothing()
    assert ma.filter(lambda x: x == 2) == Maybe.nothing()

# Generated at 2022-06-26 00:00:41.290992
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Unit test for method filter of class Maybe')
    assert Maybe.just(2).filter(lambda x: x >= 0) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 0) == Maybe.nothing()



# Generated at 2022-06-26 00:00:47.802512
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda x: x > 0)
    assert maybe_1 != None
    maybe_2 = maybe_1.filter(lambda x: x > 1)
    assert maybe_2 != None
    maybe_3 = maybe_2.filter(lambda x: x > 100)
    assert maybe_3 == None
    maybe_4 = maybe_3.filter(lambda x: x > 100)
    assert maybe_4 == None


# Generated at 2022-06-26 00:00:50.143665
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    may = Maybe.just(100)
    may = may.filter(lambda x: x % 2 == 0)
    assert(may == Maybe.nothing())


# Generated at 2022-06-26 00:00:55.863580
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_1 = 9000
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda a1: a1 != int_1)
    assert maybe_1.is_nothing
    assert maybe_1 == Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda a1: a1 == int_1)
    assert not maybe_2.is_nothing
    assert maybe_2 == Maybe.just(int_0)


# Generated at 2022-06-26 00:01:04.472560
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # test case 1
    bool_F = False
    maybe_F = Maybe.just(bool_F)
    maybe_F2 = maybe_F.filter(lambda x: x == True)
    assert maybe_F2 == Maybe.nothing()

    # test case 2
    bool_T = True
    maybe_T = Maybe.just(bool_T)
    maybe_T2 = maybe_T.filter(lambda x: x == True)
    assert maybe_T2 == Maybe.just(bool_T)

    # test case 3
    maybe_e = Maybe.nothing()
    maybe_e2 = maybe_e.filter(lambda x: x == True)
    assert maybe_e2 == Maybe.nothing()

    # test case 4
    str_ = "Hey, I'm in Maybe"

# Generated at 2022-06-26 00:01:07.466778
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    class X:
        int_0: int

    x_0 = X()
    x_0.int_0 = 100
    maybe_0 = Maybe.just(x_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get() == x_0


# Generated at 2022-06-26 00:01:17.363130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    left_value = 10
    right_value = 20
    expected_return_value = Maybe.just(left_value)
    actual_return_value = Maybe.just(right_value).filter(lambda value: value == left_value)
    assert expected_return_value == actual_return_value

    right_value = 20
    expected_return_value = Maybe.nothing()
    actual_return_value = Maybe.just(right_value).filter(lambda value: value == left_value)
    assert expected_return_value == actual_return_value

    left_value = 10
    expected_return_value = Maybe.nothing()
    actual_return_value = Maybe.nothing().filter(lambda value: value == left_value)
    assert expected_return_value == actual_return_value


# Generated at 2022-06-26 00:01:32.686622
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100;
    assert type(Maybe.just(int_0).to_lazy()) == Lazy
    assert Maybe.just(int_0).to_lazy() == Lazy(lambda: 100)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:01:34.998553
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_int_0 = Maybe.just(int_0)
    assert maybe_int_0.to_lazy().force() == int_0


# Generated at 2022-06-26 00:01:44.105782
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0()
    int_0 = 100

    def test_case_0():
        int_0 = 100

        def test_case_0():
            int_0 = 100
            int_1 = 101
            maybe_box_0 = Maybe.just(Maybe.just(int_0))
            maybe_box_1 = maybe_box_0.bind(lambda int_1 : Maybe.just(int_1))
            maybe_box_2 = maybe_box_1.filter(lambda int_1 : int_1 == int_0)
            maybe_box_3 = maybe_box_2.filter(lambda int_1 : int_1 == int_0)
            maybe_box_4 = maybe_box_3.bind(lambda int_1 : Maybe.just(int_1))
            int_2 = maybe_box_

# Generated at 2022-06-26 00:01:46.864579
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(100)
    lazy_0 = maybe_0.to_lazy()

    assert lazy_0.value() == 100


# Generated at 2022-06-26 00:01:51.683708
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100

    def function_1():
        return int_0

    result = Maybe.just(int_0).to_lazy().force()
    assert result == int_0

    result = Maybe.just(int_0).to_lazy()
    assert result.force() == int_0

    result = Maybe.nothing().to_lazy()
    assert result.force() == None


# Generated at 2022-06-26 00:01:55.701871
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_1 = 200
    maybe_0 = Maybe.just(int_0)
    boolean_0 = maybe_0.filter(lambda x: x == int_0)
    boolean_1 = maybe_0.filter(lambda x: x != int_1)



# Generated at 2022-06-26 00:02:02.108683
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(7)
    b = Maybe.just(10)
    assert a.filter(lambda x: x < 8) == Maybe.just(7)
    assert a.filter(lambda x: x > 8) == Maybe.nothing()
    assert b.filter(lambda x: x > 8) == Maybe.just(10)
    assert b.filter(lambda x: x > 30) == Maybe.nothing()


# Generated at 2022-06-26 00:02:09.030425
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    filtered_maybe_0 = Maybe.just(100).filter(lambda x: x > 50)
    filtered_maybe_1 = Maybe.just(100).filter(lambda x: x < 50)
    filtered_maybe_2 = Maybe.nothing().filter(lambda x: x == -1)

    assert isinstance(filtered_maybe_0, Maybe)
    assert filtered_maybe_0 == Maybe.just(100)

    assert isinstance(filtered_maybe_1, Maybe)
    assert filtered_maybe_1 == Maybe.nothing()

    assert isinstance(filtered_maybe_2, Maybe)
    assert filtered_maybe_2 == Maybe.nothing()


# Generated at 2022-06-26 00:02:12.841690
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    fn_test_case = "Maybe_to_lazy"
    print('START TEST: %s' % fn_test_case)
    a = Maybe.just(3)
    b = a.map(lambda x: x*2)
    c = b.map(lambda x: x/2)
    print(a)
    print(b)
    print(c)

# Generated at 2022-06-26 00:02:14.140134
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual_result_0 = Maybe.just(int_0).filter(lambda value: value < 80)
    expected_result_0 = Maybe.nothing()

    assert actual_result_0 == expected_result_0


# Generated at 2022-06-26 00:02:48.621831
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x >= 10) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x <= 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x >= 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x <= 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x <= 0) == Maybe.nothing()

# Generated at 2022-06-26 00:02:52.541515
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    maybe_0 = Maybe.just(int_0)
    lazy_1 = maybe_0.to_lazy()



# Generated at 2022-06-26 00:02:57.073662
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda param_0: param_0 == 100)
    assert(maybe_1 == Maybe.just(int_0))
    maybe_2 = maybe_1.filter(lambda param_0: param_0 == 0)
    assert(maybe_2 == Maybe.nothing())
