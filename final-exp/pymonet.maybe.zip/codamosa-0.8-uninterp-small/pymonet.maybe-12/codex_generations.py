

# Generated at 2022-06-25 23:53:10.083067
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    bool_1 = maybe_0.__eq__(maybe_0)
    assert bool_1 == False


# Generated at 2022-06-25 23:53:14.384348
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_0.unwrap()



# Generated at 2022-06-25 23:53:23.223862
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = Maybe.just('\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        ')
    bool_1 = maybe_1 == maybe_0
    assert bool_1 is True

# Generated at 2022-06-25 23:53:27.908066
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:53:35.872991
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(4, False)
    maybe_1 = Maybe(4, True)
    maybe_2 = Maybe(3, False)
    maybe_3 = Maybe(3, True)
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.just(0)
    maybe_7 = Maybe.nothing()
    maybe_8 = Maybe.nothing()
    maybe_9 = Maybe.just(1)
    maybe_10 = Maybe.nothing()
    maybe_11 = Maybe.nothing()
    maybe_12 = Maybe.just(4)
    maybe_13 = Maybe.nothing()
    maybe_14 = Maybe.nothing()
    maybe_15 = Maybe.just(3)
    assert maybe_0 == Maybe.just(4)
    assert not maybe_0 == Maybe.just

# Generated at 2022-06-25 23:53:37.103900
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert 1 == 1


b = Maybe(2, 1)

# Generated at 2022-06-25 23:53:43.269701
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    args = (maybe_0, )
    result = Maybe(str_0, bool_0).__eq__(*args)
    assert result



# Generated at 2022-06-25 23:53:47.811092
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)


# Generated at 2022-06-25 23:53:55.768943
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('\nTest filter\n')
    def test_case_1():
        list_0 = []
        maybe_0 = Maybe(list_0, bool(0))
        def fun_0(val):
            return bool(len(val))
        maybe_1 = maybe_0.filter(fun_0)
        bool_0 = bool(None)
        #assert bool_0 == maybe_0.is_nothing
        bool_1 = bool(None)
        #assert bool_1 == maybe_1.is_nothing
        def test_case_2():
            maybe_0 = Maybe(list_0, bool(1))
            def fun_1(val):
                return bool(len(val))
            maybe_1 = maybe_0.filter(fun_1)
            bool_0 = bool(None)
            bool_

# Generated at 2022-06-25 23:53:59.469573
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 3).get_or_else(10) == 5
    assert Maybe.just(5).filter(lambda x: x > 5).get_or_else(10) == 10


# Generated at 2022-06-25 23:54:03.359542
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0()


# Generated at 2022-06-25 23:54:13.444311
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'a'
    bool_0 = True
    maybe_0 = Maybe(str_0, bool_0)
    bool_1 = True
    maybe_1 = maybe_0.filter(lambda str_0: bool_1)
    bool_2 = bool_1

    def test_func(str_0):
        bool_0 = False
        return bool_0

    bool_3 = True
    maybe_2 = maybe_1.filter(test_func)
    bool_4 = (maybe_2.value == str_0)
    bool_5 = False
    assert not maybe_0.is_nothing
    assert bool_4 == bool_2
    assert maybe_2.is_nothing == bool_5


# Generated at 2022-06-25 23:54:17.938449
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    # Test 1
    assert maybe_0.to_lazy() == Lazy(None)


# Generated at 2022-06-25 23:54:30.987663
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    expected = False
    actual = Maybe.just('a') == Maybe.just('a')
    assert(expected == actual)
    actual = Maybe.just('a') == Maybe.just('b')
    assert(expected == actual)
    expected = True
    actual = Maybe.just('a') == Maybe.just('a')
    assert(expected == actual)
    actual = Maybe.nothing() == Maybe.nothing()
    assert(expected == actual)
    assert(expected == actual)
    expected = False
    assert(expected == actual)
    actual = Maybe.just('a') == Maybe.nothing()
    assert(expected == actual)
    actual = Maybe.nothing() == Maybe.just('b')
    assert(expected == actual)


# Generated at 2022-06-25 23:54:37.935970
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe.just(str_0)
    str_1 = str_0
    bool_1 = len(str_1) > 0
    maybe_1 = maybe_0.filter(bool_1)
    str_2 = str_1
    bool_2 = bool_0
    maybe_2 = Maybe(str_2, bool_2)
    assert (maybe_1 == maybe_2)



# Generated at 2022-06-25 23:54:46.217746
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just('8')
    maybe_1 = maybe_0.filter(lambda str_0: str_0 > '2')
    maybe_2 = maybe_0.filter(lambda str_0: str_0 <= '8')
    assert maybe_1.value == '8'
    assert maybe_2.value == '8'
    maybe_0 = Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda str_0: str_0 <= '8')
    assert maybe_0 == maybe_2

test_case_0()
test_Maybe_filter()

# Generated at 2022-06-25 23:54:53.740810
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    assert maybe_0.to_lazy() is not None


# Generated at 2022-06-25 23:55:04.936091
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Test: Maybe class method filter')
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    str_2 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_2 = False
    maybe_

# Generated at 2022-06-25 23:55:12.038113
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    def function_0(str_0):
        return Maybe.just(str_0)
    Maybe.filter(maybe_0, function_0)

# Generated at 2022-06-25 23:55:19.457562
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = True
    maybe_0 = Maybe(str_0, bool_0)

    def pred(x):
        return str(x).__eq__(str_0)

    bool_1 = maybe_0.filter(pred)
    assert bool_1.is_nothing == bool_0 and bool_1.value == str_0


# Generated at 2022-06-25 23:55:35.694403
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from tests.test_maybe import test_case_0
    from pymonet.monad import Monad
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    maybe_0 = test_case_0()
    maybe_1 = Maybe(None, True)
    maybe_2 = Maybe(None, False)
    maybe_3 = Maybe(None, True)
    maybe_4 = Maybe(maybe_3, True)
    maybe_5 = Maybe(maybe_2, True)
    maybe_6 = Maybe(maybe_3, True)
    maybe_7 = Maybe(maybe_3, True)
    maybe_8 = Maybe(maybe_3, True)
    maybe_9 = Maybe(maybe_3, True)

    assert maybe_0 != maybe_1
    assert maybe_1 == maybe_1
   

# Generated at 2022-06-25 23:55:45.996679
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    str_2 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_2 = False

# Generated at 2022-06-25 23:55:52.503093
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.filter(lambda string_0: not bool_0)
    assert maybe_1 == Maybe(str_0, bool_0)


# Generated at 2022-06-25 23:56:00.631047
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    try:
        maybe_1 = maybe_0.to_lazy()
        maybe_2 = Maybe('\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        ', False)
    except TypeError:
        assert False, 'Expected defined instance of Maybe, got None'



# Generated at 2022-06-25 23:56:05.832399
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.filter(lambda x: 'r' == x)
    str_1 = maybe_1.value
    assert(str_1 == str_0)



# Generated at 2022-06-25 23:56:13.429442
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.to_lazy()
    maybe_2 = maybe_1.f.value
    maybe_3 = maybe_2()
    assert maybe_3 == str_0


# Generated at 2022-06-25 23:56:21.447864
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    result_0: Lazy = maybe_0.to_lazy()
    print('result_0:', result_0.memoize())


if __name__ == '__main__':
    test_case_0()
    test_Maybe_to_lazy()

# Generated at 2022-06-25 23:56:29.283272
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = \
        maybe_0.filter(lambda value: False)
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_2 = Maybe(str_1, bool_1)
    assert maybe_1 == maybe_2


# Generated at 2022-06-25 23:56:33.148821
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)


# Generated at 2022-06-25 23:56:39.078197
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)
    print(maybe_1.to_lazy())


# Generated at 2022-06-25 23:56:58.359551
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    def lambda0(maybe_value: str) -> bool:
        return maybe_value.find('\n') == -1

    maybe_1 = maybe_0.filter(lambda0)

    if isinstance(maybe_1, Maybe):
        assert maybe_1 == Maybe.nothing(), "FAIL. Expecting maybe_1 to be Maybe. Just nothing."
    else:
        assert False, "FAIL. Expecting maybe_1 to be Maybe. Just nothing."

# Execute tests.
test_Maybe_filter()

# Generated at 2022-06-25 23:57:01.816710
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('test_case_0').to_lazy().run() == 'test_case_0'
    assert Maybe.nothing().to_lazy().run() is None


# Generated at 2022-06-25 23:57:09.836788
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = True
    bool_1 = False
    maybe_0 = Maybe(str_0, bool_0)
    filterer = lambda A: (0, A)
    maybe_1 = maybe_0.filter(filterer)
    maybe_2 = Maybe(0, bool_1)
    assert maybe_1 == maybe_2


# Generated at 2022-06-25 23:57:13.948666
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just('Hello Python')
    str_0 = maybe_0.filter(lambda x: len(x) == 6)

    assert isinstance(str_0, Maybe)
    assert str_0.get_or_else(None) is None


# Generated at 2022-06-25 23:57:21.437264
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    assert lazy_0.to_string() == 'Lazy(Function)'
    str_1 = '\n    Returns True when errors list are empty.\n\n    :returns: True for empty errors list\n    :rtype: Boolean\n    '
    bool_1 = True


# Generated at 2022-06-25 23:57:29.596308
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Asserts
    from pymonet.utils import ignore
    from pymonet.boolean import any_of

    # Arrange
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    assert maybe_0.filter(ignore) == maybe_0
    maybe_1 = Maybe.nothing()
    assert maybe_1.filter(ignore) == maybe_0


# Generated at 2022-06-25 23:57:36.327723
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    def filterer(input):
        return bool(input)
    maybe_0 = Maybe.just(str_0)
    maybe_1 = maybe_0.filter(filterer)
    bool_1 = maybe_1.get_or_else(True)
    assert bool_1 is False


# Generated at 2022-06-25 23:57:42.832487
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Initialize Mock Objects
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    test_Maybe_filter_value = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    maybe_0 = maybe_0.filter(lambda value: (value == test_Maybe_filter_value))
    assert maybe_0 == maybe_0


# Generated at 2022-06-25 23:57:43.592566
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 23:57:52.614001
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    resul_0 = lazy_0.map(lambda _input: len(_input))
    unit_test_resul_0 = resul_0.value() # Maybe.to_lazy.resul_0
    
    assert unit_test_resul_0 == len(str_0)


# Generated at 2022-06-25 23:58:10.435398
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe(0, 0.0)
    assert isinstance(maybe, Maybe)
    assert maybe == maybe
    assert maybe != 0
    assert maybe != 0.0


# Generated at 2022-06-25 23:58:20.797183
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # Test with boolean value
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    int_0 = len(str_0)
    int_1 = len(str_1)
    assert int_0 == int_1

    # Test with boolean value
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '

# Generated at 2022-06-25 23:58:27.400450
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    def filterer(x):
        if(x == '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '):
            return True
        return False
    assert(maybe_0.filter(filterer) == Maybe.just(str_0))


# Generated at 2022-06-25 23:58:31.915302
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(5, False)
    filtered_maybe_0 = maybe_0.filter(lambda elem: elem > 5)

    assert filtered_maybe_0 == Maybe.nothing()


# Generated at 2022-06-25 23:58:37.681558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n    Returns True when errors list are empty.\n\n    :returns: True for empty errors list\n    :rtype: Boolean\n    '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    test_0 = maybe_0.to_lazy()
    assert test_0.run() == maybe_0.value



# Generated at 2022-06-25 23:58:43.254457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    def filterer(x):
        return True if x is not None else False

    maybe_1 = maybe_0.filter(filterer)
    maybe_1.get_or_else(None)


# Generated at 2022-06-25 23:58:49.411334
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    def filterer(x):
        return False

    assert maybe_0.filter(filterer) == Maybe.nothing()
    str_1 = 'hello'
    bool_1 = False
    maybe_1 = Maybe(str_1, bool_1)

    def filterer_1(x):
        return True

    assert maybe_1.filter(filterer_1) == Maybe.just('hello')


# Generated at 2022-06-25 23:58:56.078472
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    bool_1 = bool_0
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = Maybe(str_0, bool_1)
    assert maybe_0 == maybe_1



# Generated at 2022-06-25 23:59:07.105198
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_0.filter(bool) == Maybe(str_0, bool_0)
    bool_0 = True
    maybe_0 == Maybe(str_0, bool_0)
    bool_0 = False
    maybe_0 == Maybe.nothing()
    bool_0 = True
    maybe_0 == Maybe.nothing()
    bool_0 = False
    str_1 = 'message'
    maybe_1 = Maybe(str_1, bool_0)
    maybe_1.filter(bool) == Maybe(str_1, bool_0)
   

# Generated at 2022-06-25 23:59:14.972912
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    maybe_0 = Maybe(str_0, False)
    lazy_0 = maybe_0.to_lazy()
    func_0 = lazy_0.value
    str_1 = func_0()
    lazy_1 = lazy_0.to_lazy()
    func_1 = lazy_1.value
    str_2 = func_1()
    assert str_1 == str_2
    maybe_1 = Maybe(str_1, True)
    lazy_2 = maybe_1.to_lazy()
    func_2 = lazy_2.value
    str_3 = func_2()

# Generated at 2022-06-25 23:59:38.450456
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0()

# Generated at 2022-06-25 23:59:40.227160
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    method_0 = Maybe(
        True,
        None
    )

    function_0 = method_0.filter(method_0)


# Generated at 2022-06-25 23:59:44.177496
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:59:49.076514
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    mapper_0 = lambda argument_0: argument_0 in 'Try'
    maybe_1 = maybe_0.filter(mapper_0)
    maybe_1 = maybe_0.filter(mapper_0)
    assert maybe_1.value == str_0
    mapper_1 = lambda argument_0: argument_0 in '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_2 = Maybe

# Generated at 2022-06-25 23:59:54.343722
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe.just(str_0)
    maybe_0 = maybe_0.to_lazy()
    assert isinstance(maybe_0, Lazy)
    result = maybe_0.exec_with_default()
    assert "Returns True when errors list are empty." in result
    str_0 = 'Method returns new Validation monad in case of errors list is empty.'
    bool_0 = True
    maybe_0 = Maybe.just(str_0)
    maybe_0 = maybe_0.to_lazy()
    assert isinstance(maybe_0, Lazy)

# Generated at 2022-06-26 00:00:03.599435
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = 'Returns True when errors list are empty.'

    def filterer(arg_0):
        return str_1 == arg_0

    result_0 = maybe_0.filter(filterer)
    str_2 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_1 = Maybe(str_2, bool_1)
    assert result_0 == maybe_1

# Unit

# Generated at 2022-06-26 00:00:14.783197
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_lazy()
    lazy_0 = maybe_0.to_l

# Generated at 2022-06-26 00:00:25.148177
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_Something():
        str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
        bool_0 = False
        maybe_0 = Maybe.just(str_0)
        lazy_0 = maybe_0.to_lazy()
        bool_1 = bool(lazy_0.value() == str_0)
        bool_2 = bool(maybe_0 == lazy_0.value())
        return bool_1, bool_2

    test_Something()


# Generated at 2022-06-26 00:00:35.348321
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    
    maybe_0 = Maybe.nothing()
    assert isinstance(maybe_0, Maybe)
    assert maybe_0.is_nothing
    maybe_1 = maybe_0.filter(lambda e: e)
    assert isinstance(maybe_1, Maybe)
    assert maybe_1 == Maybe.nothing()
    maybe_2 = Maybe.just(0)
    assert isinstance(maybe_2, Maybe)
    assert not maybe_2.is_nothing
    maybe_3 = maybe_2.filter(lambda e: e == 1)
    assert isinstance(maybe_3, Maybe)
    assert maybe_3 == Maybe.nothing()
    maybe_4 = maybe_2.filter(lambda e: e == 0)
    assert isinstance(maybe_4, Maybe)
    assert maybe_4 == Maybe.just(0)
    maybe_5

# Generated at 2022-06-26 00:00:40.769843
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    maybe_0 = Maybe.just(bool_0)
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    def f_0(x):
        return len(x) > len(str_0)
    maybe_1 = maybe_0.filter(f_0)
    bool_2 = maybe_1.is_nothing
    assert bool_2


# Generated at 2022-06-26 00:01:11.733684
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    with pytest.raises(TypeError):
        assert Maybe.just('g_0').filter((1,2,3)) == Maybe.just('g_0')



# Generated at 2022-06-26 00:01:16.351598
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lambda_0 = lambda x: ' ' in x
    maybe_1 = maybe_0.filter(lambda_0)
    assert maybe_1 == Maybe(str_0, False)


# Generated at 2022-06-26 00:01:22.129555
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = "['The following fields are invalid:', 'username', 'email']"
    bool_0 = True
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()

    assert lazy_0.__len__() == 2
    assert lazy_0.__contains__('username') == True
    assert lazy_0.__contains__('email') == True


# Generated at 2022-06-26 00:01:30.762287
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    str_1 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_0 = Maybe(str_0, bool_0)
    maybe_1 = Maybe(str_1, bool_1)
    mapper = lambda v: v[::-1]
    maybe_1 = maybe_1.map(mapper)
    assert maybe_0.to_lazy() == maybe_1.to_lazy()


# Generated at 2022-06-26 00:01:34.296146
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)


# Generated at 2022-06-26 00:01:38.668844
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    lazy_0 = maybe_0.to_lazy()


# Generated at 2022-06-26 00:01:45.797962
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    Maybe_filter_arg0 = Maybe('\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        ', False)
    Maybe_filter_filterer = lambda Maybe_filter_arg1: lambda Maybe_filter_arg2: Maybe()

    Maybe_filter_expect_bool_0 = True
    Maybe_filter_expect_bool_1 = Maybe_filter_arg0.filter(Maybe_filter_filterer) == Maybe_filter_expect_bool_0
    assert Maybe_filter_expect_bool_1



# Generated at 2022-06-26 00:01:51.600744
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)

    def filterer_0(str_1):
        return bool_0

    maybe_1 = maybe_0.filter(filterer_0)
    assert maybe_1 == Maybe.just(str_0)



# Generated at 2022-06-26 00:01:58.155917
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    from pymonet.lazy import Lazy
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy) == True
    str_1 = lazy_0.value()
    assert str_1 == str_0


# Generated at 2022-06-26 00:02:07.496592
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_0 = False
    maybe_0 = Maybe(str_0, bool_0)
    str_1 = maybe_0.filter(lambda t: t.isspace())
    str_2 = '\n        Returns True when errors list are empty.\n\n        :returns: True for empty errors list\n        :rtype: Boolean\n        '
    bool_1 = False
    maybe_1 = Maybe(str_2, bool_1)
    assert str_1 == maybe_1
