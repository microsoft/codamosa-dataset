

# Generated at 2022-06-25 23:53:07.289624
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(13)
    m = maybe.filter(lambda x: x % 2 == 0)
    assert m == Maybe.nothing()



# Generated at 2022-06-25 23:53:15.260515
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    float_1 = -1325.522
    Maybe_0 = Maybe(float_0, True)
    Maybe_1 = Maybe(float_1, False)
    Maybe_2 = Maybe(float_1, False)
    Maybe_3 = Maybe(float_0, True)
    Maybe_4 = Maybe(float_1, True)
    Maybe_5 = Maybe(float_1, True)
    Maybe_6 = Maybe(float_0, False)
    Maybe_7 = Maybe(float_0, False)
    Maybe_8 = Maybe(float_0, True)
    Maybe_9 = Maybe(float_1, False)
    Maybe_10 = Maybe(float_1, False)
    assert Maybe_0 == Maybe_3
    assert Maybe_1 == Maybe_2
    assert Maybe

# Generated at 2022-06-25 23:53:27.746039
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = True
    str_0 = "true"
    bool_1 = bool_0
    bool_0 = not bool_0
    assert bool_0 != bool_1, "`(not bool_0)` returns unexpected result"
    bool_0 = not bool_0
    bool_1 = not bool_1
    assert bool_0 != bool_1, "`(not bool_1)` returns unexpected result"
    bool_0 = True
    str_1 = "False"
    bool_1 = bool_0
    bool_0 = not bool_0
    assert bool_0 != bool_1, "`(not bool_0)` returns unexpected result"
    bool_0 = not bool_0
    bool_1 = not bool_1

# Generated at 2022-06-25 23:53:35.757190
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -0.01625022854421676
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    bool_1 = bool(lazy_0)
    assert bool_1
    float_1 = lazy_0.get()
    assert isinstance(float_1, float)
    assert float_1 == float_0
    float_2 = -0.01625022854421676
    bool_2 = True
    maybe_1 = Maybe(float_2, bool_2)
    lazy_1 = maybe_1.to_lazy()
    bool_3 = bool(lazy_1)
    assert bool_3
    float_3 = lazy_1.get()

# Generated at 2022-06-25 23:53:42.824620
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """

    """
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(lambda value:value)
    assert not maybe_1.is_nothing
    assert maybe_0 == maybe_0
    assert maybe_1.get_or_else(1) is float_0



# Generated at 2022-06-25 23:53:52.438050
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -2856.69845791276
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    dict_0 = dict()
    dict_0[0] = 49.077015791060305
    dict_0[1] = '84+2CjU:O6^v'
    dict_0[2] = 'K(`O&l"W'
    dict_0[3] = 'Y-&WE](<jZ!H"1S_=g&J~$q3s,t:%c'
    dict_0[4] = '|r*93E>a/'
    dict_0[5] = '-h1[0<~dujm(#o^P'

# Generated at 2022-06-25 23:53:58.357342
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-25 23:54:04.614569
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    bool_1 = True
    maybe_1 = Maybe(float_0, bool_1)

    def filterer_0(value_0):
        bool_0 = bool()
        bool_0 = abs(value_0) < 0.0
        return bool_0

    maybe_0_1 = maybe_0.filter(filterer_0)
    maybe_1_2 = maybe_1.filter(filterer_0)
    assert maybe_0_1 == Maybe.nothing()
    assert maybe_1_2 == Maybe.nothing()



# Generated at 2022-06-25 23:54:09.781608
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_0 = maybe_0.to_lazy()
    assert maybe_0.eval() == float_0


# Generated at 2022-06-25 23:54:11.755555
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:54:20.764226
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    _maybe_0 = Maybe.just(None)
    _maybe_1 = Maybe.just(None)
    assert _maybe_0 == _maybe_1
    _maybe_2 = Maybe.nothing()
    _maybe_3 = Maybe.nothing()
    assert _maybe_2 == _maybe_3
    _maybe_4 = Maybe.just(None)
    _maybe_5 = Maybe.nothing()
    assert not (_maybe_4 == _maybe_5)



# Generated at 2022-06-25 23:54:33.398821
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    tuple_0 = (0.0, 1.0)
    maybe_1 = Maybe(tuple_0, bool_0)
    str_0 = "7.c;#EG2V7F5y5SJ$"
    str_1 = "7.c;#EG2V7F5y5SJ$"
    bool_1 = maybe_0 == maybe_1
    bool_2 = maybe_0 == str_0
    bool_3 = maybe_1 == str_1
    assert bool_1 is True
    assert bool_2 is False
    assert bool_3 is False


# Generated at 2022-06-25 23:54:38.672593
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    float_1 = float_0
    maybe_0 = Maybe(float_0, True)
    maybe_1 = Maybe(float_0, True)
    eq_result = maybe_0 == maybe_1

    assert eq_result is True


# Generated at 2022-06-25 23:54:49.183453
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = True
    dict_0 = dict()
    dict_0['key'] = dict_0
    dict_0['value'] = dict_0['key']
    tuple_0 = (dict_0['key'], )
    tuple_1 = (dict_0['key'], dict_0['value'])
    set_0 = {tuple_0}
    set_1 = {tuple_1}
    set_0 = set_0.union(set_1)
    list_0 = list(set_0)
    list_1 = list(set_1)
    list_0.extend(list_1)
    tuple_2 = (dict_0['value'], )
    tuple_3 = (tuple_2,)
    set_2 = set(list_0)

# Generated at 2022-06-25 23:54:54.269752
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = 1325.522
    bool_1 = True
    maybe_1 = Maybe(float_1, bool_1)
    assert maybe_0.__eq__(maybe_1)


# Generated at 2022-06-25 23:54:59.760200
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = -1325.522
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:55:07.845839
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # assert not Maybe.just(123.456).to_lazy().is_exception

    assert Maybe.nothing().to_lazy().is_success
    assert Maybe.nothing().to_lazy().get_value()() is None

    assert Maybe.just(123.456).to_lazy().is_success
    assert Maybe.just(123.456).to_lazy().get_value()() == 123.456


# Generated at 2022-06-25 23:55:19.213099
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = -1325.522
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    float_2 = -1325.522
    bool_2 = False
    maybe_2 = Maybe(float_2, bool_2)
    float_3 = -1325.522
    bool_3 = False
    maybe_3 = Maybe(float_3, bool_3)
    float_4 = -1325.522
    bool_4 = False
    maybe_4 = Maybe(float_4, bool_4)
    float_5 = -1325.522
    bool_5 = False

# Generated at 2022-06-25 23:55:31.603283
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0: float
    int_0: int
    float_1: float
    bool_0: bool
    bool_1: bool
    maybe_0: Maybe[float]
    maybe_1: Maybe[float]

    float_0 = 100.0
    int_0 = 0
    float_1 = float_0
    bool_0 = True
    bool_1 = False
    maybe_0 = Maybe(float_0, bool_1)
    maybe_1 = Maybe(float_1, bool_1)

    assert maybe_0.__eq__(maybe_0)

    float_1 = float_0 + 0.1
    maybe_1 = Maybe(float_1, bool_1)
    assert maybe_0.__eq__(maybe_1) == False


# Generated at 2022-06-25 23:55:39.695311
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = False
    str_0 = "abcd"
    bool_1 = True
    maybe_0 = Maybe(str_0, bool_0)
    maybe_0_copy = Maybe(str_0, bool_0)
    maybe_0_same_reference = maybe_0
    maybe_1 = Maybe(str_0, bool_1)
    maybe_1_different_reference = Maybe(str_0, bool_1)
    str_1 = "bca"

    assert (maybe_0 == maybe_0_copy)
    assert (maybe_0 == maybe_0_same_reference)
    assert (not (maybe_0 == maybe_1))
    assert (not (maybe_1 == maybe_1_different_reference))
    assert (maybe_1.is_nothing)

# Generated at 2022-06-25 23:55:44.764310
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe(float_0, False)
    assert(maybe.to_lazy().run() == float_0)
    print("Case 0 PASSED!")
    print("\n")


# Generated at 2022-06-25 23:55:54.284359
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = Maybe.just(3.14)
    from pymonet.lazy import Lazy

    assert value.to_lazy() == Lazy(lambda: 3.14), 'Maybe.to_lazy fails for Some(3.14)'
    assert value.to_lazy().get() == 3.14, 'Maybe.to_lazy fails for Some(3.14)'

    value = Maybe.nothing()
    assert value.to_lazy() == Lazy(lambda: None), 'Maybe.to_lazy fails for None'
    assert value.to_lazy().get() is None, 'Maybe.to_lazy fails for None'


# Generated at 2022-06-25 23:55:57.937839
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_value = Maybe.just(123.456)
    maybe_value_to_lazy = maybe_value.to_lazy()
    assert isinstance(maybe_value_to_lazy, Lazy)


# Generated at 2022-06-25 23:56:03.773771
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def adder(a, b):
        return a + b

    maybe_float = Maybe.just(123.456)
    lazy_result = maybe_float.to_lazy()
    assert(lazy_result.get_or_else(adder(1, 2)) == maybe_float.value == 123.456)
    maybe_float = Maybe.nothing()
    lazy_result = maybe_float.to_lazy()
    assert(lazy_result.get_or_else(adder(1, 2)) is None)


# Generated at 2022-06-25 23:56:06.058042
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    maybe_0.to_lazy()


# Generated at 2022-06-25 23:56:10.428707
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # arrange
    box_0 = Maybe.just(123.456)

    # act
    lazy_0 = box_0.to_lazy()

    # assert
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 123.456

# Generated at 2022-06-25 23:56:15.254993
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456

    maybe_box_float = Maybe.just(float_0)
    try:
        maybe_box_float.to_lazy()
        assert False, 'unit test failed'
    except NotImplementedError:
        assert True, 'unit test passed'


# Generated at 2022-06-25 23:56:17.415119
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().value() == 1
    assert Maybe.nothing().to_lazy().value() is None


# Generated at 2022-06-25 23:56:21.307018
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value == Lazy(float_0)



# Generated at 2022-06-25 23:56:23.930082
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    value_0 = Maybe.just(float_0)
    thing_0 = value_0.to_lazy()
    return thing_0.value()


# Generated at 2022-06-25 23:56:28.224517
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(123).to_lazy() == Lazy(lambda: 123)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:56:32.960789
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Setup
    float_0 = 123.456
    may0 = Maybe.just(float_0)
    float_2 = float_0 + float_0
    # Test
    may1 = may0.to_lazy()
    float_3 = may1.value()
    # Assertion
    assert float_2 == float_3


# Generated at 2022-06-25 23:56:36.690357
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Case 0
    maybe = Maybe.just(123.456)
    assert maybe.to_lazy().call() == 123.456

    # Case 1
    maybe = Maybe.nothing()
    assert maybe.to_lazy().call() == None


# Generated at 2022-06-25 23:56:47.539090
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    float_123_456 = 123.456

    # test nothing
    # to_box
    assert type(Maybe.nothing().to_box()) == Box
    assert Maybe.nothing().to_box().get_or_else(None) is None

    # to_either
    assert type(Maybe.nothing().to_either()) == Left
    assert Maybe.nothing().to_either().is_left() is True
    assert Maybe.nothing().to_either().get_or_else(None) is None

    # to_lazy
    assert type(Maybe.nothing().to_lazy()) == Lazy

# Generated at 2022-06-25 23:56:50.590014
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 123
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.is_lazy
    assert lazy_0.get() == int_0


# Generated at 2022-06-25 23:57:02.081522
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # case_0: check that method to_lazy returns Lazy with function returning 123.456
    case_0 = Maybe.just(123.456)
    assert case_0.to_lazy().is_instance_of(Lazy)
    assert case_0.is_instance_of(Maybe)
    assert case_0.is_nothing == False
    assert case_0.value == 123.456
    assert case_0.to_lazy().value() == 123.456
    assert case_0.to_lazy().is_instance_of(Lazy)
    assert case_0.is_instance_of(Maybe)
    assert case_0.is_nothing == False
    assert case_0.value == 123.456


# Generated at 2022-06-25 23:57:10.900170
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Maybe)
    assert lazy_0.get_or_else(None) == maybe_0.get_or_else(None)
    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_1, Maybe)
    assert lazy_1.get_or_else(None) == maybe_1.get_or_else(None)


# Generated at 2022-06-25 23:57:14.618352
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Given
    float_0 = 123.456

    # When
    result_0 = Maybe.just(float_0).to_lazy()

    # Then
    assert result_0 == Lazy(lambda: float_0)


# Generated at 2022-06-25 23:57:16.518084
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('test').to_lazy() == Lazy(lambda: 'test')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:19.293685
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    assert(Maybe.just(float_0).to_lazy().get() == 123.456)
    assert(Maybe.nothing().to_lazy().get() == None)


# Generated at 2022-06-25 23:57:24.864763
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(123.456)
    Lazy_obj = maybe.to_lazy()
    assert Lazy_obj.value() == 123.456



# Generated at 2022-06-25 23:57:28.847363
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(float_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy([float_0]()), "maybe to lazy failed"


# Generated at 2022-06-25 23:57:33.062701
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.utils import eq

    _1 = Maybe.just(1)
    assert eq(_1.to_lazy(), Lazy(lambda: 1))

    _nothing = Maybe.nothing()
    assert eq(_nothing.to_lazy(), Lazy(lambda: None))


# Generated at 2022-06-25 23:57:40.848413
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.just(float_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    lazy_2 = maybe_2.to_lazy()
    maybe_3 = lazy_0.to_maybe()
    maybe_4 = lazy_1.to_maybe()
    maybe_5 = lazy_2.to_lazy().to_maybe()
    assert maybe_0 == maybe_3
    assert maybe_1 == maybe_4
    assert maybe_2 == maybe_5


# Generated at 2022-06-25 23:57:50.898192
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456

    # Call method to_lazy of class Maybe with float_0 as argument
    maybe_result = Maybe.just(float_0).to_lazy()

    # Assert maybe_result is Lazy
    assert maybe_result.__class__ == pymonet.lazy.Lazy

    # Call method to_lazy of class Maybe with float_0 as argument
    maybe_result = Maybe.just(float_0).to_try()
    # Assert maybe_result is Try
    assert maybe_result.__class__ == pymonet.monad_try.Try

    # Assert maybe_result equals to Try(float_0, is_success=True)
    assert maybe_result == pymonet.monad_try.Try(float_0, is_success=True)





# Generated at 2022-06-25 23:57:55.779291
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Arrange
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)

    # Act
    lazy_0 = maybe_0.to_lazy()

    # Assert
    assert lazy_0.false_func == None
    assert lazy_0.true_func() == float_0
    assert lazy_0.is_false == False


# Generated at 2022-06-25 23:58:03.904638
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    a = Maybe(123.456, False).to_lazy()
    assert a.apply() == Maybe(123.456, False).value
    assert a.apply() == Maybe(123.456, False).get_or_else(None)
    assert 123.456 == Maybe(123.456, False).get_or_else(None)
    assert a.apply() == Maybe(123.456, False).get_or_else(None)
    assert a.apply() == Maybe(123.456, False).to_box().value
    assert a.apply() == Maybe(123.456, False).to_box().get_or_else(None)
    assert 123.456 == Maybe(123.456, False).to_box().get_or_else(None)
    assert a.apply() == Maybe(123.456, False).to_box

# Generated at 2022-06-25 23:58:15.062939
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    float_0_box = Maybe.just(float_0)

    float_0_lazy = float_0_box.to_lazy()

    float_0_1 = float_0_lazy.get_value()

    assert float_0_1 == float_0

    empty_box = Maybe.nothing()

    empty_lazy = empty_box.to_lazy()

    empty_box_1 = empty_lazy.get_value()

    assert empty_box_1 is None

    float_0_box = Maybe.just(321.456)

    float_0_lazy = float_0_box.to_lazy()

    float_0_1 = float_0_lazy.get_value()

    assert float_0_1 == float_0

    empty_

# Generated at 2022-06-25 23:58:19.120998
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe(float_0, False).to_lazy() == Lazy(lambda: float_0)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:58:24.347210
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    expected_result = 123.456
    float_maybe = Maybe.just(123.456)
    float_lazy = float_maybe.to_lazy()
    actual_result = float_lazy.force()
    if expected_result == actual_result:
        print("test case 0 for method to_lazy in class Maybe passed")
    else:
        print("test case 0 for method to_lazy in class Maybe failed")

# Generated at 2022-06-25 23:58:40.378435
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # create Maybe instance with float value
    maybe_float_0 = Maybe(float_0)

    # create Lazy instance with function returning value of Maybe instance
    lazy_float_0 = maybe_float_0.to_lazy()

    # create Lazy instance with function returning value of Maybe instance
    lazy_float_1 = Maybe(float_0).to_lazy()

    # create Maybe instance with value of Lazy instance
    maybe_float_2 = Maybe.just(lazy_float_1)

    # result of comparing two Maybe instances
    are_identical_0 = maybe_float_0 == maybe_float_2

    # result of comparing two Lazy instances
    are_identical_1 = lazy_float_0 == lazy_float_1

    # result of comparing result of function from Lazy instance and value of Maybe instance
    are

# Generated at 2022-06-25 23:58:43.416010
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    assert Maybe.just(float_0).to_lazy().get_or_else(None) == float_0
    assert Maybe.nothing().to_lazy().get_or_else(None) is None

# Generated at 2022-06-25 23:58:46.198944
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    Maybe_0 = Maybe.just(float_0)
    Lazy_0 = Maybe_0.to_lazy()
    assert Lazy_0 == Lazy(lambda: float_0)


# Generated at 2022-06-25 23:58:48.339274
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(4).to_lazy() == Lazy.of(4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-25 23:58:51.916195
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(2, False).to_lazy() == Lazy(lambda: 2)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:59:02.869561
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    assert maybe_0 == maybe_0
    assert maybe_0.is_nothing == False
    maybe_0_value = maybe_0.get_or_else(None)
    assert float_0 == maybe_0_value
    maybe_1 = Maybe.nothing()
    maybe_1_lazy = maybe_1.to_lazy()
    maybe_1_lazy_value = maybe_1_lazy.get_or_else(None)
    assert maybe_1_lazy_value == None
    maybe_0_lazy = maybe_0.to_lazy()
    maybe_0_lazy_value = maybe_0_lazy.get_or_else(None)

# Generated at 2022-06-25 23:59:12.332853
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    try:
        float_0 = 123.456
        Maybe_0 = Maybe(float_0, False)
        result = Maybe_0.to_lazy()
        assert type(result) is Lazy and result.is_computed == False and result.value() == 123.456 and result.exception is None, str(Exception(result))

    except AttributeError:
        raise AssertionError(str(AttributeError(0)))

    except NotImplementedError:
        raise AssertionError(str(NotImplementedError(0)))

    except TypeError:
        raise AssertionError(str(TypeError(0)))

    except ValueError:
        raise AssertionError(str(ValueError(0)))

    except AssertionError:
        raise AssertionError(str(AssertionError(0)))

   

# Generated at 2022-06-25 23:59:13.834934
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy().get().value == 2
    assert Maybe.nothing().to_lazy().get().value is None


# Generated at 2022-06-25 23:59:21.827245
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("\ntest_Maybe_to_lazy")
    float_0 = 123.456
    test_case_0 = Maybe.just(float_0)
    test_case_1 = Maybe.just(float_0)
    test_case_2 = Maybe.nothing()
    test_case_3 = Maybe.just(float_0)
    test_case_4 = Maybe.nothing()
    result_0 = test_case_0.to_lazy()
    expected_result_0 = Maybe.just(float_0).to_lazy()
    result_1 = test_case_1.to_lazy()
    expected_result_1 = Maybe.just(float_0).to_lazy()
    result_2 = test_case_2.to_lazy()
    expected_result_2 = Maybe.nothing

# Generated at 2022-06-25 23:59:24.246941
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = 3
    maybe = Maybe.just(value)
    lazy = maybe.to_lazy()
    result = lazy.value()
    assert result == value



# Generated at 2022-06-25 23:59:34.047381
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe(float_0, False)
    lazy_0 = maybe_0.to_lazy()
    float_1 = lazy_0.value()
    assert float_0 == float_1


# Generated at 2022-06-25 23:59:36.474072
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    assert maybe_0.to_lazy().get() == float_0



# Generated at 2022-06-25 23:59:38.456560
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def func():
        return float_0
    float_0 = 123.456
    maybe_float_0 = Maybe.just(float_0)
    assert maybe_float_0.to_lazy() == Lazy(func)


# Generated at 2022-06-25 23:59:41.455613
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)
    maybe_1 = maybe_0.to_lazy()
    str_0 = maybe_1.get()
    assert str_0 == '123.456'


# Generated at 2022-06-25 23:59:49.796745
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.either import Right

    assert isinstance(Maybe.just(123).to_lazy(), Lazy)
    assert isinstance(Maybe.just(123).to_lazy().map(lambda x: x+1), Lazy)
    assert isinstance(Maybe.just(123).to_lazy().map(lambda x: x+1).bind(lambda x: Lazy(lambda: x+2)), Lazy)
    assert isinstance(Maybe.just(123).to_lazy().ap(Lazy(lambda: lambda y: y+1)), Lazy)
    assert isinstance(Maybe.nothing().to_lazy(), Lazy)

# Generated at 2022-06-25 23:59:55.855149
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Create Maybe(value)
    float_0 = 123.456
    maybe_0 = Maybe.just(float_0)

    # Call method to_lazy on Maybe(value)
    maybe_1 = maybe_0.to_lazy()

    # Assert that method call return_value is Success(value)
    float_1 = maybe_1.get_or_else(0.0)
    assert maybe_1 != None
    assert float_1 != None


# Generated at 2022-06-25 23:59:58.176975
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(123.456)
    assert isinstance(maybe.to_lazy(), Lazy)


# Generated at 2022-06-26 00:00:01.602646
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(32, False).to_lazy() == Lazy(lambda: 32)
    assert Maybe(float_0, False).to_lazy() == Lazy(lambda: float_0)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:00:13.391597
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from typing import Callable

    from pymonet.lazy import Lazy

    def to_lazy():
        def to_lazy_0(maybe_float: Maybe[float]) -> Maybe[Lazy[float]]:
            return maybe_float.map(
                lambda float_1: Lazy.compute_lazy(float_1),
            )

        def to_lazy_1(maybe_float: Maybe[float]) -> Maybe[float]:
            return to_lazy_0(maybe_float).map(
                lambda lazy_float: lazy_float.value,
            )


# Generated at 2022-06-26 00:00:15.321157
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Lazy(lambda: float_0) == Maybe.just(float_0).to_lazy()

# Generated at 2022-06-26 00:00:31.624084
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.try_ import Try
    from pymonet.either import Left
    from pymonet.either import Right
    from pymonet.applicative import Applicative
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from functools import reduce

    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.to_lazy()
    assert isinstance(maybe_1, Lazy)
    # Test str()

# Generated at 2022-06-26 00:00:40.791304
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.util import T, invoke_zero_arity
    # Create Lazy monad for number 1325.522
    lazy_0 = Lazy.pure(1325.522)
    # Create Maybe monad for number 1325.522
    maybe_0 = Maybe.pure(1325.522)
    # Transform Maybe into Lazy monad
    lazy_1 = maybe_0.to_lazy()
    # Check if transformed Maybe and Lazy are same
    assert lazy_0 == lazy_1
    # Invoke Lazy monad
    lazy_2 = invoke_zero_arity(lazy_1)
    # Check if Lazy invocation result is correct
    assert isinstance(lazy_2, T) and lazy_2 == 1325.522
    # Create Maybe monad with

# Generated at 2022-06-26 00:00:43.394862
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2.2).to_lazy().force() == 2.2
    assert Maybe.nothing().to_lazy().force() is None


# Generated at 2022-06-26 00:00:49.321393
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method of Maybe.

    :returns: None
    :rtype: None
    """

    from pymonet.lazy import Lazy

    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = Lazy(lambda: float_0)
    assert maybe_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:00:57.829374
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.list import cons
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    my_list_0 = cons(Try.success(2), None)
    my_list_1 = cons(Try.success(1), my_list_0)
    my_list_2 = cons(Try.success(3), my_list_1)
    my_validation_0 = Validation.success(my_list_2)
    my_validation_1 = my_validation_0.map(lambda x: x.map(lambda x: x.map(lambda x: x.map(lambda x: x.map(lambda x: x.get_or_else(1))))))

# Generated at 2022-06-26 00:01:05.192195
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(-38.0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == -38.0
    int_0 = -8388608
    lazy_1 = Maybe.just(int_0).to_lazy()
    assert lazy_1.value() == -8388608
    lazy_2 = Maybe.nothing().to_lazy()
    assert lazy_2.value() is None
    float_0 = 4134865.0
    lazy_3 = Maybe.just(float_0).to_lazy()
    assert lazy_3.value() == 4134865.0


# Generated at 2022-06-26 00:01:15.498114
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    string_0 = "`Eb`,z"
    string_1 = "ygV\u0014"
    string_2 = "wb^g"
    boolean_0 = False
    maybe_0 = Maybe(string_0, boolean_0)
    boolean_1 = True
    maybe_1 = Maybe(string_1, boolean_1)
    boolean_2 = True
    maybe_2 = Maybe(string_2, boolean_2)
    maybe_2.to_lazy()
    boolean_3 = False
    maybe_3 = Maybe(string_0, boolean_3)
    boolean_4 = True
    maybe_4 = Maybe(string_2, boolean_4)
    boolean_5 = True
    maybe_5 = Maybe(string_1, boolean_5)
    maybe_5.to_lazy()


# Generated at 2022-06-26 00:01:17.979486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('a').to_lazy().get_unsafe() == 'a'
    assert Maybe.nothing().to_lazy().get_unsafe() is None


# Generated at 2022-06-26 00:01:21.178076
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.to_lazy()



# Generated at 2022-06-26 00:01:28.986490
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -2127.15695176
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = Lazy(lambda: float_0)
    assert lazy_0.__eq__(lazy_1)

    float_1 = -1325.522
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    lazy_2 = maybe_1.to_lazy()
    lazy_3 = Lazy(lambda: None)
    assert lazy_2.__eq__(lazy_3)



# Generated at 2022-06-26 00:01:45.591760
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    value = lazy_0.value()
    assert value == float_0


# Generated at 2022-06-26 00:01:48.847704
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import sys
    import io
    import unittest
    import unittest.mock
    import pymonet.lazy
    test_Maybe_0 = Maybe(1, False)
    _ = test_Maybe_0.to_lazy()
    return _


# Generated at 2022-06-26 00:01:57.964219
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -12.3
    str_0 = 'st'
    str_2 = 'r'
    str_1 = str_0 + str_2
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    dict_0 = {}
    str_tuple = tuple()
    str_dict = dict_0
    int_0 = hash((float_0, str_1))
    # lazy_0 = Lazy(lambda: int_0)
    bool_0 = isinstance(lazy_0, Maybe)
    bool_1 = isinstance(lazy_0, Lazy)
    bool_2 = isinstance(lazy_0, Maybe)
    bool_3 = isinstance(bool_2, Maybe)

# Generated at 2022-06-26 00:02:08.201198
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from functools import reduce

    maybe_0 = Maybe(str(0), bool(0))
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == maybe_0.value

    maybe_1 = Maybe(str(1), bool(1))
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.get() == maybe_1.value

    maybe_2 = Maybe(str(2), bool(2))
    lazy_2 = maybe_2.to_lazy()
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.get() == maybe_2.value

# Generated at 2022-06-26 00:02:15.298340
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = -1363
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.__eq__(Lazy(lambda: int_0))
    int_0 = 660
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.__eq__(Lazy(lambda: int_0))
    int_0 = -1154
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.__eq__(Lazy(lambda: int_0))


# Generated at 2022-06-26 00:02:19.407900
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 42.00
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = 42.00
    bool_1 = False
    lazy_0 = maybe_0.to_lazy()
    bool_2 = lazy_0.is_success()
    try:
        lazy_0.get_or_else()
        lazy_0.map(
            my_f
        )
        lazy_0.flat_map(
            my_f
        )
        bool_3 = lazy_0.is_failure()
    except:
        bool_3 = False
    assert (bool_1 == bool_2) and (bool_3 == bool_1)


# Generated at 2022-06-26 00:02:21.913526
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1325.522
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.to_lazy()



# Generated at 2022-06-26 00:02:29.693882
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    f = lambda x: x * x
    g = lambda x: x + x

    lazy_0 = Maybe(10, False).to_lazy()
    assert isinstance(lazy_0, Lazy)

    assert lazy_0.map(f) == Lazy(lambda: f(10))
    assert lazy_0.map(g) == Lazy(lambda: g(10))

    lazy_1 = Maybe(None, True).to_lazy()
    assert isinstance(lazy_1, Lazy)

    assert lazy_1.map(f) == Lazy(lambda: None)
    assert lazy_1.map(g) == Lazy(lambda: None)


# Generated at 2022-06-26 00:02:35.572888
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(11.01, False).to_lazy() == Lazy(lambda: 11.01)
    assert Maybe(False, False).to_lazy() == Lazy(lambda: False)
    assert Maybe('a', False).to_lazy() == Lazy(lambda: 'a')
    assert Maybe(11, False).to_lazy() == Lazy(lambda: 11)
    assert Maybe(2.0, False).to_lazy() == Lazy(lambda: 2.0)

# Generated at 2022-06-26 00:02:39.927238
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(3.0)
    maybe_1 = Maybe.nothing()

    assert callable(maybe_0.to_lazy().value)
    assert callable(maybe_1.to_lazy().value)

    assert 3.0 == maybe_0.to_lazy().value()
    assert maybe_1.to_lazy().value() is None
