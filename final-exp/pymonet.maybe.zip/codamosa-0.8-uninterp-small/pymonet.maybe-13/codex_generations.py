

# Generated at 2022-06-25 23:53:10.251428
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xe6\x0fP\x8c\x90SB'
    bytes_1 = b'\xe6\x0fP\x8c\x90SB'
    bool_0 = True
    bytes_2 = b'\xfc\x93\xa9\xcd\x15'
    maybe_0 = Maybe(bytes_2, bool_0)
    maybe_1 = maybe_0.filter(lambda x: x == bytes_1)


# Generated at 2022-06-25 23:53:14.216804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bytes_0 = b'\xe6\x0fP\x8c\x90SB'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    var_0 = maybe_0.filter(lambda var_0: var_0.isalnum())
    var_1 = maybe_0.to_try()


# Generated at 2022-06-25 23:53:23.070560
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xab\xbd\x1c\n\xa7\x8c\xe3\xef\xdd'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    bytes_1 = b'\xab\xbd\x1c\n\xa7\x8c\xe3\xef\xdd'
    bool_1 = True
    maybe_1 = Maybe(bytes_1, bool_1)
    assert maybe_0.__eq__(maybe_1) == True


# Generated at 2022-06-25 23:53:33.247988
# Unit test for method filter of class Maybe

# Generated at 2022-06-25 23:53:36.629059
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(100) == Maybe.just(100)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(100)
    assert Maybe.just(100) != Maybe.nothing()
    assert Maybe.just(100).__eq__(None) is False
    assert Maybe.nothing().__eq__(None) is False



# Generated at 2022-06-25 23:53:44.030893
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bytes_0 = b'\xe6\x0fP\x8c\x90SB'
    bool_0 = True
    maybe_1 = Maybe(bytes_0, bool_0)
    lazy_1 = maybe_1.to_lazy()
    func_1 = lambda :lazy_1.value
    bytes_1 = func_1()
    assert bytes_1 is not None
    assert bytes_1 == maybe_1.value



# Generated at 2022-06-25 23:53:50.763137
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bytes_0 = b'\xe6\x0fP\x8c\x90SB'
    bool_0 = True
    maybe_0 = Maybe(bytes_0, bool_0)
    bytes_1 = b'\xe6\x0fP\x8c\x90SB'
    bool_1 = True
    maybe_1 = Maybe(bytes_1, bool_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:54:02.227016
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.curry import curry
    from pymonet.monad_list import MonadList
    from pymonet.monad_try import Try
    from pymonet.monad_writer import MonadWriter

    bytes_0 = b'\x01\x00'
    bool_0 = True
    maybe_0 = MonadList([(bytes_0, bool_0)])
    maybe_1 = Maybe(bytes_0, bool_0)
    maybe_2 = Try(bytes_0, bool_0)
    either_0 = maybe_0.__eq__(maybe_1)
    either_1 = maybe_0.__eq__(maybe_2)
    either_2 = maybe_1.__eq__(maybe_2)
    bool_1 = False
    bool_2 = False

# Generated at 2022-06-25 23:54:09.964999
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    test_Maybe_set_up()
    test_Maybe__init__9()
    test_Maybe__init__7()

    maybe_8 = Maybe(int_2, (int_1 == int_3))
    maybe_9 = Maybe(int_2, (int_1 == int_3))

    if (maybe_8 == maybe_9):
        var_0 = True
    else:
        var_0 = False



# Generated at 2022-06-25 23:54:11.542684
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    return Maybe(0, True) == Maybe(0, True)


# Generated at 2022-06-25 23:54:19.114671
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(0)
    maybe_1 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_0.evaluate() == 0
    assert lazy_1.evaluate() == 1
    maybe_0.is_nothing
    maybe_1.is_nothing


# Generated at 2022-06-25 23:54:22.065190
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_value_0 = Maybe.just(bool_0);
    result = maybe_value_0.filter(lambda value: value);
    assert result == Maybe.just(bool_0)


# Generated at 2022-06-25 23:54:28.312221
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m0 = Maybe.just(100)
    m1 = Maybe.nothing()
    result0 = m0.to_lazy()()
    result1 = m1.to_lazy()()
    assert result0 == 100
    assert result1 == None


# Generated at 2022-06-25 23:54:38.101941
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # bool_0 is true
    bool_0 = True
    # bool_1 is false
    bool_1 = False
    # maybe_0 is Maybe(2, False)
    maybe_0 = Maybe.just(2)
    # maybe_1 is Maybe(None, True)
    maybe_1 = Maybe.nothing()
    # Assert maybe_0 equals Maybe(2, False)
    assert maybe_0 == Maybe.just(2)
    # Assert maybe_1 equals Maybe(None, True)
    assert maybe_1 == Maybe.nothing()
    # Assert maybe_0.filter(lambda x: x == 2) equals Maybe(2, False)
    assert maybe_0.filter(lambda x: x == 2) == Maybe.just(2)
    # Assert maybe_0.filter(lambda x: x == 3) equals Maybe

# Generated at 2022-06-25 23:54:48.752552
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test 0
    # Initialization of Maybe with value 2
    maybe_0 = Maybe.just(2)
    # Filtering value of Maybe with lambda x : x > 1, it should return new Maybe with value 2
    maybe_1 = maybe_0.filter(lambda x : x > 1)
    # Filtering value of Maybe with lambda x : x > 5, it should return new Maybe with None
    maybe_2 = maybe_0.filter(lambda x : x > 5)
    # Test 1
    # Initialization of Maybe with value 8
    maybe_3 = Maybe.just(8)
    # Filtering value of Maybe with lambda x : x > 1, it should return new Maybe with value 8
    maybe_4 = maybe_3.filter(lambda x : x > 1)
    # Filtering value of Maybe with lambda x : x > 10, it should

# Generated at 2022-06-25 23:54:58.089427
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When Maybe is not empty and filterer returns True
    assert Maybe.just(True).filter(lambda x: x).get_or_else(True) == True

    # When Maybe is not empty and filterer returns False
    assert Maybe.just(True).filter(lambda x: not x).get_or_else(True) == True

    # When Maybe is empty and filterer returns True
    assert Maybe.nothing().filter(lambda x: x).get_or_else(True) == True

    # When Maybe is empty and filterer returns False
    assert Maybe.nothing().filter(lambda x: not x).get_or_else(True) == True


# Generated at 2022-06-25 23:55:03.896097
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Some test
    x = Maybe(10, False)
    y = x.to_lazy()
    z = y.value()

    assert z == 10
    assert x == y

    # Nothing test
    x = Maybe.nothing()
    y = x.to_lazy()
    z = y.value()

    assert z == None
    assert x == y


# Generated at 2022-06-25 23:55:13.835020
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(1)
    maybe_1 = Maybe.nothing()

    def filterer_0(value):
        bool_0 = value > 0
        return bool_0

    maybe_2 = maybe_0.filter(filterer_0)
    assert maybe_2 is not maybe_0
    bool_1 = maybe_2.get_or_else(False)
    assert bool_1 == True

    def filterer_1(value):
        bool_0 = value > 2
        return bool_0

    maybe_2 = maybe_0.filter(filterer_1)
    assert maybe_2 is not maybe_0
    bool_1 = maybe_2.is_nothing
    assert bool_1 == True

    maybe_2 = maybe_1.filter(filterer_0)

# Generated at 2022-06-25 23:55:19.312234
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    bool_0 = Maybe[int].just(5) == Maybe[int].just(5)
    bool_1 = Maybe[int].just(3) == Maybe[int].just(5)
    bool_2 = Maybe[int].just(3) == Maybe[int].nothing()
    bool_3 = Maybe[int].nothing() == Maybe[int].nothing()


# Generated at 2022-06-25 23:55:22.192206
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(bool_0, bool_1)
    maybe_1 = Maybe(bool_0, bool_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:55:31.315885
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(100)
    b = Maybe.just(100)
    assert (a == b) == True
    b = Maybe.just(200)
    assert (a == b) == False
    a = Maybe.nothing()
    assert (a == b) == False
    b = Maybe.nothing()
    assert (a == b) == True


# Generated at 2022-06-25 23:55:36.867092
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 100
    int_1 = 100
    int_2 = 200
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    assert maybe_0.__eq__(maybe_1)
    assert not maybe_0.__eq__(maybe_2)
    assert not maybe_1.__eq__(maybe_2)


# Generated at 2022-06-25 23:55:44.001442
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Initialize monad
    maybe = Maybe.just(1)
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    # Initialize monad
    maybe = Maybe.just(2)
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.just(2)
    # Initialize monad
    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-25 23:55:52.162265
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_source = Maybe.just(100)
    maybe_filter_positive = lambda i: i > 0
    maybe_filter_negative = lambda i: i < 0
    maybe_result_positive = maybe_source.filter(maybe_filter_positive)
    maybe_result_negative = maybe_source.filter(maybe_filter_negative)
    assert isinstance(maybe_result_positive, Maybe)
    assert maybe_result_positive == Maybe.just(100)
    assert isinstance(maybe_result_negative, Maybe)
    assert maybe_result_negative == Maybe.nothing()


# Generated at 2022-06-25 23:55:56.215056
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    justMaybe = Maybe.just(2)
    assert justMaybe.filter(lambda x : x % 2 == 0) == Maybe.just(2)
    assert justMaybe.filter(lambda x : x % 2 == 1) == Maybe.nothing()



# Generated at 2022-06-25 23:56:04.322766
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    filter
    """
    int_0 = 0
    int_1 = 1
    int_minus_1 = -1
    int_max_value = sys.maxsize
    int_min_value = -sys.maxsize - 1

    int_None = None

    string_empty = ""
    string_0 = "0"
    string_1 = "1"
    string_None = None

    # Create collection for testing

# Generated at 2022-06-25 23:56:08.553081
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(100)
    maybe = maybe.filter(lambda x: x % 2 == 0)
    assert maybe == Maybe.just(100)
    maybe = maybe.filter(lambda x: x % 2 == 1)
    print(maybe)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-25 23:56:11.811562
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert isinstance(Maybe.just(1).to_lazy(), Lazy)
    assert isinstance(Maybe.nothing().to_lazy(), Lazy)



# Generated at 2022-06-25 23:56:18.115731
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = 1
    int_2 = 2
    maybe_int_1 = Maybe.just(int_1)
    maybe_int_2 = Maybe.just(int_2)
    is_gt_0 = lambda x: x > 0
    assert maybe_int_2.filter(is_gt_0) == maybe_int_2
    assert maybe_int_2.filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-25 23:56:24.200651
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_case_1():
        assert Maybe.just(41).filter(lambda a: a == 41) == Maybe.just(41)
    def test_case_2():
        assert Maybe.just(42).filter(lambda a: a == 41) == Maybe.nothing()
    def test_case_3():
        assert Maybe.nothing().filter(lambda a: a == 41) == Maybe.nothing()

    test_case_1()
    test_case_2()
    test_case_3()



# Generated at 2022-06-25 23:56:32.874227
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 100

    # Test to_lazy for empty Maybe
    maybe_0 = Maybe.nothing().to_lazy()
    if maybe_0 != Lazy(lambda: None):
        raise AssertionError()

    # Test to_lazy for not empty Maybe
    maybe_1 = Maybe.just(int_0).to_lazy()
    if maybe_1 != Lazy(lambda: int_0):
        raise AssertionError()


# Generated at 2022-06-25 23:56:41.009948
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # create two instance of Maybe with the same value
    maybe_0 = Maybe.just(100)
    maybe_1 = Maybe.just(100)
    # instances are equal
    assert maybe_0 == maybe_1

    maybe_0 = Maybe.just(100)
    maybe_1 = Maybe.nothing()
    # instances are not equal
    assert maybe_0 != maybe_1

    maybe_0 = Maybe.nothing()
    maybe_1 = Maybe.nothing()
    # instances are equal
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:56:45.059236
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 1) == Maybe.nothing()


# Generated at 2022-06-25 23:56:52.527122
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # test 1:
    m_0 = Maybe.just(5)
    def filterer(x):
        return x % 2 == 0

    print('Test 1')
    m_1 = m_0.filter(filterer)
    print(m_1 == Maybe.nothing())

    # test 2:
    m_0 = Maybe.just(6)
    print('Test 2')
    m_2 = m_0.filter(filterer)
    print(m_2 == m_0)

    # test 3:
    def filterer0(x):
        if x % 2 == 0:
            return True
        elif x % 2 == 1:
            return False
        else:
            raise ValueError('test')
    print('Test 3')

# Generated at 2022-06-25 23:56:57.497105
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    boolean_0 = maybe_0.filter(lambda x: x < 50)
    if boolean_0.is_nothing:
        int_1 = 43
    else:
        int_1 = maybe_0.value
    assert int_1 != int_0


# Generated at 2022-06-25 23:57:02.190180
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    m = Maybe.just(10)
    assert isinstance(m.to_lazy(), Lazy)

    m = Maybe.nothing()
    assert isinstance(m.to_lazy(), Lazy)


# Generated at 2022-06-25 23:57:10.250390
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # create Lazy monad
    lazy_maybe = Maybe.just(100).to_lazy()
    assert lazy_maybe.is_nothing == False

    # take value wrapped in Fucntion
    value = lazy_maybe.value
    assert value == 100

    # create type which can't be casted to int
    class NonCastable:
        pass

    # create Maybe monad with NonCastable value
    lazy_maybe = Maybe.just(NonCastable()).to_lazy()
    assert lazy_maybe.is_nothing == True


# Generated at 2022-06-25 23:57:12.688037
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().force() == 1
    assert Maybe.nothing().to_lazy().force() == None


# Generated at 2022-06-25 23:57:15.814485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from random import randint
    from pymonet.monad_maybe import Maybe

    int_0 = randint(-10000, 10000)
    assert Maybe.just(int_0).filter(lambda value: value >= 0) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(lambda value: value < 0) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda value: True) == Maybe.nothing()



# Generated at 2022-06-25 23:57:23.813087
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    empty_Maybe = Maybe.nothing()
    x = empty_Maybe.filter(lambda x: x % 2 == 0)
    print('Maybe.filter():', x)
    assert(x.is_nothing == True)

    not_empty_Maybe = Maybe.just({'value': 100})
    x = not_empty_Maybe.filter(lambda x: x['value'] % 2 == 0)
    print('Maybe.filter():', x)
    assert(x.value.get('value') == 100)

    not_empty_Maybe = Maybe.just({'value': 101})
    x = not_empty_Maybe.filter(lambda x: x['value'] % 2 == 0)
    print('Maybe.filter():', x)
    assert(x.is_nothing == True)


# Generated at 2022-06-25 23:57:32.002832
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    int_1 = 10
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.to_lazy()
    assert maybe_1.get() == int_0
    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.to_lazy()
    assert maybe_3.get() == None


# Generated at 2022-06-25 23:57:40.101303
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100

    maybe_0 = Maybe.just(int_0)
    maybe_0_result = maybe_0.filter(lambda x: x == 100)

    assert maybe_0_result == Maybe.just(int_0)

    maybe_0_result = maybe_0.filter(lambda x: x == 101)

    assert maybe_0_result == Maybe.nothing()

    maybe_0_result = maybe_0.filter(lambda x: x == 100)

    assert maybe_0_result == Maybe.just(int_0)

    maybe_0_result = maybe_0.filter(lambda x: x == 101)

    assert maybe_0_result == Maybe.nothing()


# Generated at 2022-06-25 23:57:45.735130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_filter(i):
        # type: (int) -> bool
        return i < 3

    int_0 = 100
    int_1 = 1
    int_2 = 2
    int_3 = 3

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.just(int_1)
    maybe_int_2 = Maybe.just(int_2)
    maybe_int_3 = Maybe.just(int_3)

    maybe_none = Maybe.nothing()

    assert int_0 == maybe_int_0.filter(test_filter).get_or_else(int_0)
    assert int_1 == maybe_int_1.filter(test_filter).get_or_else(int_0)

# Generated at 2022-06-25 23:57:55.323014
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    t = Maybe.just(100)
    t1 = Maybe.just(100)
    t2 = Maybe.just(200)
    t3 = Maybe.just('100')
    t4 = Maybe.nothing()
    t5 = Maybe.nothing()

    assert t == t1
    assert t1 == t
    assert not t == t2
    assert not t2 == t
    assert not t == t3
    assert not t3 == t
    assert t4 == t5
    assert t5 == t4
    assert not t == t4
    assert not t4 == t
    assert not t4 == t3
    assert not t3 == t4
    assert not t3 == t2
    assert not t2 == t3



# Generated at 2022-06-25 23:58:03.029297
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def is_even(number):
        return number % 2 == 0

    _even_or_nothing = Maybe(100, False)
    even_or_nothing = _even_or_nothing.filter(
        is_even)

    assert isinstance(even_or_nothing, Maybe)
    assert even_or_nothing == Maybe(100, False)

    _even_or_nothing = Maybe(101, False)
    even_or_nothing = _even_or_nothing.filter(
        is_even)

    assert isinstance(even_or_nothing, Maybe)
    assert even_or_nothing == Maybe(None, True)



# Generated at 2022-06-25 23:58:13.784485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 10
    int_1 = 20

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.just(int_1)

    maybe_int_2 = Maybe.nothing()

    assert maybe_int_0.filter(lambda x: x == int_0) == maybe_int_0, 'Maybe_filter_test_1'
    assert maybe_int_1.filter(lambda x: x == int_0) != maybe_int_1, 'Maybe_filter_test_2'
    assert maybe_int_2.filter(lambda x: x == int_0) != maybe_int_2, 'Maybe_filter_test_3'

# Generated at 2022-06-25 23:58:16.269652
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.filter()
    assert maybe_1 == maybe_1


# Generated at 2022-06-25 23:58:22.407158
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 5
    maybe_int_0 = Maybe.just(int_0)
    maybe_lazy_int_0 = maybe_int_0.to_lazy()

    maybe_int_1 = Maybe.nothing()
    maybe_lazy_int_1 = maybe_int_1.to_lazy()

    assert int_0 == maybe_lazy_int_0()
    assert maybe_lazy_int_1() is None


# Generated at 2022-06-25 23:58:27.721946
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # test with empty Maybe and lambda returning True
    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: True) == Maybe.nothing(), "test_Maybe_filter_0"

    # test with not empty Maybe and lambda returning True
    maybe = Maybe.just(42)
    assert maybe.filter(lambda x: True) == Maybe.just(42), "test_Maybe_filter_1"

    # test with not empty Maybe and lambda returning False
    maybe = Maybe.just(42)
    assert maybe.filter(lambda x: False) == Maybe.nothing(), "test_Maybe_filter_2"



# Generated at 2022-06-25 23:58:37.949834
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Create instance of class Maybe with value and call __eq__ method
    assert Maybe.just(100) == Maybe.just(100)
    # Create instance of class Maybe without value and call __eq__ method
    assert Maybe.nothing() == Maybe.nothing()
    # Create instance of class Maybe with value and call __eq__ method
    assert Maybe.just(100) != Maybe.just(200)
    # Create instance of class Maybe with value and call __eq__ method
    assert Maybe.just(100) != Maybe.nothing()
    # Create instance of class Maybe with value and call __eq__ method
    assert Maybe.nothing() != Maybe.just(100)



# Generated at 2022-06-25 23:58:42.635940
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(100).to_lazy().get() == 100
    assert Maybe.nothing().to_lazy().get() == None
    return True


# Generated at 2022-06-25 23:58:49.620329
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Test method to_lazy of class Maybe"""
    # Right case
    int_0 = Maybe.just(1)
    int_1 = int_0.to_lazy()
    if int_1.value() != 1:
        message = "test_Maybe_to_lazy: Right test case failed!"
        raise AssertionError(message)

    # Left case
    int_1 = Maybe.nothing()
    int_2 = int_1.to_lazy()
    if int_2.value() is not None:
        message = "test_Maybe_to_lazy: Left test case failed!"
        raise AssertionError(message)

if __name__ == '__main__':
    test_case_0()

    # Unit tests
    test_Maybe_to_lazy()

# Generated at 2022-06-25 23:58:55.459670
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_1 = 200
    box_0 = Maybe.just(int_0)
    box_1 = Maybe.just(int_1)
    box_2 = box_0.filter(lambda v0: v0 == 100)
    box_3 = box_1.filter(lambda v0: v0 == 100)


# Generated at 2022-06-25 23:59:06.580566
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filter function.

    :returns: None
    """
    int_null: Maybe[int] = Maybe.nothing()
    int_0: Maybe[int] = Maybe.just(100)
    int_1: Maybe[int] = Maybe.just(101)
    int_2: Maybe[int] = Maybe.just(102)
    bool_null: Maybe[bool] = Maybe.nothing()
    bool_0: Maybe[int] = Maybe.just(False)
    bool_1: Maybe[int] = Maybe.just(True)

    def check_greater_100(value: int) -> bool:
        return value > 100
    result_int_null = int_null.filter(check_greater_100)
    result_int_0 = int_0.filter(check_greater_100)


# Generated at 2022-06-25 23:59:09.424220
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(int_0).filter(lambda x: int_0 > x) == Maybe.nothing()
    assert Maybe.just(int_0).filter(lambda x: int_0 <= x) == Maybe.just(int_0)



# Generated at 2022-06-25 23:59:13.063782
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_int_0 = Maybe.just(int_0)
    def predicate(x):
        return x == int_0
    predicate(int_0)
    maybe_int_1 = maybe_int_0.filter(predicate)
    assert maybe_int_0 is maybe_int_1


# Generated at 2022-06-25 23:59:17.029015
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # test_case_0
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get_value() == 100
    # test_case_1
    int_1 = None
    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1.get_value() is None

# Generated at 2022-06-25 23:59:21.246062
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(int_0) == Maybe.just(int_0)
    assert Maybe.just(int_0) != Maybe.just(int_1)
    assert Maybe.just(int_0) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(int_0)


# Generated at 2022-06-25 23:59:24.286489
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just(20)
    lazy = m.to_lazy()
    assert lazy.get() == 20
    m = Maybe.nothing()
    lazy = m.to_lazy()
    assert lazy.get() == None


# Generated at 2022-06-25 23:59:34.195434
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    def test_0():
        maybe_int_0 = Maybe.just(100)
        def filterer(a):
            return a < 100

        maybe_int_1 = maybe_int_0.filter(filterer)
        assert maybe_int_1.is_nothing
        return maybe_int_1

    def test_1():
        maybe_int_0 = Maybe.just(100)
        def filterer(a):
            return a >= 100

        maybe_int_1 = maybe_int_0.filter(filterer)
        assert not maybe_int_1.is_nothing
        assert maybe_int_1 == maybe_int_0
        return maybe_int_1

    test_0()
    test_1()


# Generated at 2022-06-25 23:59:41.025526
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    x = Maybe.just(5)
    x_default = Maybe.nothing()

    # Test case 1
    # in this case maybe is not empty, so in Lazy should be function
    # which returns value of previous maybe
    result_case_1 = x.to_lazy()
    assert isinstance(result_case_1, Lazy)
    assert result_case_1.value() == 5

    # Test case 2
    # in this case maybe is empty, so in Lazy should be function
    # which returns None
    result_case_2 = x_default.to_lazy()
    assert isinstance(result_case_2, Lazy)
    assert result_case_2.value() is None
    assert result_case_2

# Generated at 2022-06-25 23:59:45.173687
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # case 1:
    int_0 = 100
    maybe_int_0 = Maybe.just(int_0)
    maybe_int_0_new = maybe_int_0.filter(lambda x: x == int_0)

    assert maybe_int_0 == maybe_int_0_new


# Generated at 2022-06-25 23:59:49.136294
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(100)
    assert m1.filter(lambda x: x > 50) == Maybe.just(100)
    assert m1.filter(lambda x: x < 50) == Maybe.nothing()
    m2 = Maybe.nothing()
    assert m2.filter(lambda _: True) == Maybe.nothing()
    assert m2.filter(lambda _: False) == Maybe.nothing()


# Generated at 2022-06-25 23:59:58.581647
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_max = 100

    # empty maybe should be empty after filter with any filterer
    maybe_0 = Maybe.nothing().filter(lambda x: x == int_0)
    assert maybe_0.is_nothing

    # not empty maybe should be empty after filter if filterer returns False
    maybe_0 = Maybe.just(int_0).filter(lambda x: x != int_0)
    assert maybe_0.is_nothing

    # not empty maybe should be equal to itself after filter if filterer returns True
    maybe_0 = Maybe.just(int_0).filter(lambda x: x == int_0)
    assert maybe_0 == Maybe.just(int_0)

    # not empty maybe should be equal to itself after filter if filterer returns True

# Generated at 2022-06-26 00:00:00.761321
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(100).to_lazy() == Lazy(lambda: 100)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:00:11.690589
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just(1)
    assert hasattr(m, '__class__')
    assert hasattr(m, '__eq__')
    assert hasattr(m, 'value')
    assert hasattr(m, 'is_nothing')
    assert not m.is_nothing
    assert m.to_lazy().__class__.__name__ == 'Lazy'
    m = Maybe.nothing()
    assert isinstance(m, Maybe)
    assert hasattr(m, '__class__')
    assert hasattr(m, '__eq__')
    assert hasattr(m, 'is_nothing')
    assert m.is_nothing
    assert m.to_lazy().__class__.__name__ == 'Lazy'

# Generated at 2022-06-26 00:00:18.699015
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 100
    int_1 = 100
    int_2 = 200
    maybe_a = Maybe.just(int_0)
    maybe_b = Maybe.just(int_1)
    maybe_c = Maybe.just(int_2)
    maybe_d = Maybe.nothing()
    maybe_e = Maybe.nothing()
    result_a = maybe_a.__eq__(maybe_b)
    result_b = maybe_a.__eq__(maybe_c)
    result_c = maybe_a.__eq__(maybe_d)
    result_d = maybe_d.__eq__(maybe_e)
    result_e = maybe_a.__eq__(int_0)
    expected_a = True
    expected_b = False
    expected_c = False

# Generated at 2022-06-26 00:00:23.322215
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    filterer = lambda x: x == 0
    maybe_1 = maybe_0.filter(filterer)
    # assertion:
    assert maybe_1 == Maybe.just(int_0)


# Generated at 2022-06-26 00:00:25.102124
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(int_0, False) == Maybe(int_0, False)



# Generated at 2022-06-26 00:00:32.221312
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test that Maybe filter returns default_value when maybe is empty.
    """
    int_0 = 100

    def condition(x):
        return x > 100

    maybe_int = Maybe.just(int_0)
    default_int = 1
    result = maybe_int.filter(condition).get_or_else(default_int)
    assert result == default_int

    maybe_none = Maybe.nothing()
    default_int = 2
    result = maybe_none.filter(condition).get_or_else(default_int)
    assert result == default_int


# Generated at 2022-06-26 00:00:42.091520
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # 1. Create maybe with value
    value = 10
    assert Maybe.just(value).filter(lambda x: x > value).get_or_else(None) is None
    assert Maybe.just(value).filter(lambda x: x < value).get_or_else(None) is None

    maybe_value = Maybe.just(value)
    maybe_value_result = maybe_value.filter(lambda x: x == value)

    assert maybe_value == maybe_value_result
    assert maybe_value.value == maybe_value_result.value

    # 2. Filter for empty maybe
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-26 00:00:51.391962
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_int_0 = Maybe.just(int_0)
    lazy_maybe_int_0_0 = maybe_int_0.to_lazy()
    lazy_maybe_int_0_1 = maybe_int_0.to_lazy()
    maybe_int_0_0 = lazy_maybe_int_0_0()
    maybe_int_0_1 = lazy_maybe_int_0_1()
    assert maybe_int_0_0 == lazy_maybe_int_0_0()
    assert maybe_int_0_1 == lazy_maybe_int_0_1()
    assert maybe_int_0 == maybe_int_0_0
    assert maybe_int_0 == maybe_int_0_1
    print("[test_Maybe_to_lazy] Successfully.")

# Generated at 2022-06-26 00:00:59.794024
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_10 = 10
    int_0__Maybe = Maybe.just(int_0)
    int_1__Maybe = Maybe.just(int_1)
    int_2__Maybe = Maybe.just(int_2)
    int_3__Maybe = Maybe.just(int_3)
    int_4__Maybe = Maybe.just(int_4)
    int_5__Maybe = Maybe.just(int_5)
    int_6__Maybe = Maybe.just(int_6)
    int_7__Maybe = Maybe.just

# Generated at 2022-06-26 00:01:04.435323
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100


    maybe_0 = Maybe.just(int_0)
    lazy_1 = maybe_0.to_lazy()
    assert lazy_1.value == int_0
    lazy_2 = Maybe.nothing().to_lazy()
    assert lazy_2.is_nothing
    assert lazy_2.value() == None



# Generated at 2022-06-26 00:01:11.478516
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    maybe_int_0 = Maybe.just(int_0)

    maybe_int_0_filtered = maybe_int_0.filter(lambda x: x > 10)
    assert maybe_int_0_filtered == Maybe.just(int_0)

    maybe_int_0_filtered = maybe_int_0.filter(lambda x: x > 100)
    assert maybe_int_0_filtered == Maybe.nothing()


# Generated at 2022-06-26 00:01:15.709352
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 100
    int_1 = 100
    maybe_0 = Maybe(int_0, False)
    maybe_1 = Maybe(int_1, False)
    equality_result = maybe_0.__eq__(maybe_1)
    assert equality_result == True
    equality_result = maybe_1.__eq__(maybe_0)
    assert equality_result == True


# Generated at 2022-06-26 00:01:25.706090
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    int_4 = 5
    int_5 = 6
    int_6 = 7
    int_7 = 8
    int_8 = 9
    int_9 = 10
    int_10 = 11
    int_11 = 12
    int_12 = 13
    int_13 = 14
    int_14 = 15
    int_15 = 16
    int_16 = 17
    int_17 = 18
    int_18 = 19
    int_19 = 20
    int_20 = 21
    int_21 = 22
    int_22 = 23
    int_23 = 24
    int_24 = 25
    int_25 = 26
    int_26 = 27
    int_27 = 28

# Generated at 2022-06-26 00:01:29.158911
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    test = Maybe.just(int_0)
    result = test.filter(lambda x: x == 0)
    expected_result = Maybe.nothing()

    assert result == expected_result
    assert type(result) is Maybe
    assert result.is_nothing is True


# Generated at 2022-06-26 00:01:33.251452
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(100) == Maybe.just(100)
    assert Maybe.just(100) != Maybe.just(200)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(100) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(100)
    assert Maybe.just(100) != None


# Generated at 2022-06-26 00:01:37.887527
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    result = [1, 2, 3]
    m_result = Maybe.just(result)
    m_lazy_result = m_result.to_lazy()
    assert isinstance(m_lazy_result, Lazy)
    assert m_lazy_result.get_value() == result


# Generated at 2022-06-26 00:01:45.334455
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_var = Maybe.just(100)

    filterer = lambda x: x > 10

    actual_result = int_var.filter(filterer)
    expected_result = Maybe.just(100)
    assert actual_result == expected_result, "x.filter(filterer) = {} != {} = x".format(actual_result, expected_result)

    pass



# Generated at 2022-06-26 00:01:50.738229
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Just
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_0)
    assert maybe_0 == maybe_1

    # Nothing
    maybe_2 = Maybe.nothing()
    maybe_3 = Maybe.nothing()
    assert maybe_2 == maybe_3

    # Just != Nothing
    assert maybe_0 != maybe_2
    assert maybe_1 != maybe_3


# Generated at 2022-06-26 00:02:01.178119
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 100
    int_1 = int_0
    int_2 = int_0
    # assert int_0 is int_1
    # assert int_0 is int_2
    # assert int_1 is int_2
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_0)
    maybe_2 = Maybe.just(int_0)
    # assert maybe_0 is maybe_1
    # assert maybe_0 is maybe_2
    # assert maybe_1 is maybe_2
    maybe_3 = Maybe.just(int_1)
    maybe_4 = Maybe.just(int_2)
    # assert maybe_0 is maybe_3
    # assert maybe_0 is maybe_4
    # assert maybe_1 is maybe_3
    # assert maybe_

# Generated at 2022-06-26 00:02:09.790043
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Validation, Success, Fail

    maybe_int_0 = Maybe.just(1)
    maybe_int_1 = Maybe.just(2)
    maybe_int_2 = Maybe.just(3)
    maybe_int_3 = Maybe.nothing()

    filter_result_0 = maybe_int_0.filter(lambda int_val: int_val == 1)
    filter_result_1 = maybe_int_1.filter(lambda int_val: int_val == 1)
    filter_result_2 = maybe_int_2.filter(lambda int_val: int_val == 1)
    filter_result_3 = maybe_int_3.filter(lambda int_val: True)

    assert isinstance(filter_result_0, Maybe) and isinstance(filter_result_1, Maybe)

# Generated at 2022-06-26 00:02:17.311457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from random import randint

    int_0 = randint(0, 100)
    int_1 = randint(0, 100)
    int_2 = randint(0, 100)
    int_3 = randint(0, 100)

    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    maybe_3 = Maybe.nothing()

    assert maybe_0.filter(lambda x: x == int_0) == Maybe.just(int_0)
    assert maybe_0.filter(lambda x: x != int_0) == Maybe.nothing()

    assert maybe_1.filter(lambda x: x == int_0) == Maybe.nothing()

# Generated at 2022-06-26 00:02:22.373185
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: (a > 0)) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: (a < 0)) != Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: (a < 0)) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: (a > 0)) == Maybe.nothing()



# Generated at 2022-06-26 00:02:30.541550
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100
    int_0_maybe = Maybe.just(int_0)
    def is_zero(x):
        return x == 0
    int_0_maybe_filtered_on_zero = int_0_maybe.filter(is_zero)
    int_0_maybe_filtered_on_zero_get_or_else_result = int_0_maybe.filter(is_zero).get_or_else(0)
    print(int_0_maybe_filtered_on_zero)
    assert int_0_maybe_filtered_on_zero != None
    assert int_0_maybe_filtered_on_zero.is_nothing == True
    assert int_0_maybe_filtered_on_zero_get_or_else_result == 0

# Generated at 2022-06-26 00:02:33.559236
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 100
    maybe_0 = Maybe.just(int_0)
    assert isinstance(maybe_0.to_lazy(), Lazy)


# Generated at 2022-06-26 00:02:39.224208
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Create lazy object with function returning 100
    lazy_fn = lambda: 100
    maybe_100 = Maybe.just(100)

    # Test that lazy object created by Maybe are equals (in sense of returne values)
    lazy_fn_test = maybe_100.to_lazy()
    print(lazy_fn_test)
    assert lazy_fn() == lazy_fn_test()


# Generated at 2022-06-26 00:02:40.743147
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1))

# Generated at 2022-06-26 00:02:50.068012
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    def return_true():
        return True

    def return_false():
        return False

    assert Maybe.just(int_0).filter(return_true) == Maybe.just(int_0)
    assert Maybe.just(int_0).filter(return_false) == Maybe.nothing()
    assert Maybe.nothing().filter(return_true) == Maybe.nothing()


# Generated at 2022-06-26 00:02:53.328266
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 100

    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda val: val != 99)

    assert maybe_1 == Maybe.just(100), "Failed Maybe.filter"


# Generated at 2022-06-26 00:03:01.720536
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.maybe import Maybe

    m_str = Maybe.just("string")
    m_str_empty = Maybe.nothing()

    assert m_str.filter(lambda st: len(st) > 3).get_or_else("") == "string", 'test_Maybe_filter not passed.'
    assert m_str.filter(lambda st: len(st) <= 3).get_or_else("") == "", 'test_Maybe_filter not passed.'

    assert m_str_empty.filter(lambda st: len(st) > 3).get_or_else("") == "", 'test_Maybe_filter not passed.'
    assert m_str_empty.filter(lambda st: len(st) <= 3).get_or_else("") == "", 'test_Maybe_filter not passed.'
