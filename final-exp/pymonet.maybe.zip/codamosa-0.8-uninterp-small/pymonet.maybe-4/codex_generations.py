

# Generated at 2022-06-25 23:53:10.163733
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    tuple_0 = ()
    bool_0 = False
    maybe_0 = Maybe(tuple_0, bool_0)

    def filterer(argument_0: tuple, argument_1: str, argument_2: int, argument_3: float, argument_4: bool) -> bool:
        return argument_3 != argument_2 != argument_1 != 0.0 != False
    maybe_1 = maybe_0.filter(filterer)


# Generated at 2022-06-25 23:53:13.878949
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    tuple_1 = ()
    bool_0 = True
    maybe_0 = Maybe(tuple_1, bool_0)
    tuple_2 = ()
    bool_0 = True
    maybe_1 = Maybe(tuple_2, bool_0)
    bool_1 = maybe_0 == maybe_1
    assert bool_1



# Generated at 2022-06-25 23:53:17.148578
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    tuple_0 = ()
    bool_0 = True
    maybe_0 = Maybe(tuple_0, bool_0)
    value = maybe_0.to_lazy()
    assert value == ()



# Generated at 2022-06-25 23:53:23.324578
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != 1
    assert Maybe(1, True) != ()


# Generated at 2022-06-25 23:53:33.247493
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    tuple_0 = ()
    bool_0 = True
    maybe_0 = Maybe(tuple_0, bool_0)
    bool_1 = False
    maybe_1 = Maybe(tuple_0, bool_1)
    bool_2 = True
    maybe_2 = Maybe(tuple_0, bool_2)
    bool_3 = False
    maybe_3 = Maybe(tuple_0, bool_3)
    bool_4 = True
    maybe_4 = Maybe(tuple_0, bool_4)
    bool_5 = True
    maybe_5 = Maybe(tuple_0, bool_5)
    bool_6 = True
    maybe_6 = Maybe(tuple_0, bool_6)
    bool_7 = False
    maybe_7 = Maybe(tuple_0, bool_7)


# Generated at 2022-06-25 23:53:37.010284
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(1)
    assert m == Maybe.just(1)
    assert m != Maybe.just(2)
    assert m != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-25 23:53:43.381400
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    tuple_0 = ()
    maybe_0 = Maybe(tuple_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = Lazy(maybe_0.get_or_else(tuple_0))
    assert lazy_0 == lazy_1


# Generated at 2022-06-25 23:53:47.254070
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()
    assert (isinstance(lazy_0, Lazy))



# Generated at 2022-06-25 23:53:52.332942
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    tuple_0 = ()
    bool_0 = True
    maybe_0 = Maybe(tuple_0, bool_0)
    tuple_1 = ()
    bool_1 = True
    maybe_1 = Maybe(tuple_1, bool_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:54:02.790336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def filterer(value):
        return isinstance(value, int)

    def mapper(value):
        if not isinstance(value, int):
            raise ValueError('value must be an int')
        return value

    tuple_0 = (
        Maybe.just(1),
        Maybe.just(2),
        Maybe.just('a'),
        Maybe.just(0.0),
        Maybe.just(1 + 2j),
        Maybe.nothing(),
        Maybe.nothing(),
    )

    # Type of first argument in filter(Maybe[A], Function(A) -> Boolean) must be Maybe[A]
    # Function(A) -> Boolean must not return None

# Generated at 2022-06-25 23:54:11.809992
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 4) == Maybe.nothing()


# Generated at 2022-06-25 23:54:19.719162
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test import monad_test

    def predicate(value):
        return value > 0

    maybe = Maybe(1, False)
    maybe_2 = Maybe(1, True)

    monad_test(
        maybe.filter(predicate),
        Maybe(1, False),
        Maybe(1, True)
    )

    monad_test(
        maybe_2.filter(predicate),
        Maybe(1, True),
        Maybe(1, True)
    )


# Generated at 2022-06-25 23:54:33.193142
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 0
    print("Test case 0")
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    def func_0(value_0: int) -> bool:
        return True
    str_0 = "Some(1)"
    str_1 = str(maybe_0.filter(func_0))
    assert str_0 == str_1

    # Test case 1
    print("Test case 1")
    int_0 = 1
    maybe_0 = Maybe.nothing()
    def func_0(value_0: int) -> bool:
        return False
    str_0 = "None"
    str_1 = str(maybe_0.filter(func_0))
    assert str_0 == str_1

    # Test case 2
    print("Test case 2")
    int_

# Generated at 2022-06-25 23:54:40.047801
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    maybe_1 = lazy_0.get()
    assert maybe_0 == maybe_1
    maybe_2 = Maybe.nothing()
    lazy_1 = maybe_2.to_lazy()
    maybe_3 = lazy_1.get()
    assert maybe_2 == maybe_3


# Generated at 2022-06-25 23:54:50.554457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    test_case_0 checks that filter of Maybe[int], which is NotEmpty, works correctly.
    test_case_1 checks that filter of Maybe[int], which is Empty, works correctly.
    test_case_1 checks that filter of Maybe[int], which is NotEmpty, with False filterer works correctly.
    """
    # test_case_0
    int_0 = 1
    maybe_0 = Maybe.just(int_0)

    maybe_1 = maybe_0.filter(lambda x: True)
    assert maybe_1 is not maybe_0 and maybe_1 == maybe_0, f'test_case_0 failed: maybe_1: {maybe_1} and maybe_0: {maybe_0} are not equal'

    # test_case_1
    maybe_

# Generated at 2022-06-25 23:54:53.788152
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Maybe[1]
    maybe = Maybe.just(1)
    # Maybe[]
    result = maybe.filter(lambda x: x == 0)
    assert(result == Maybe.nothing())


# Generated at 2022-06-25 23:55:03.170130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    success_1 = Maybe.just(0).filter(lambda x: x == 0)
    assert(isinstance(success_1, Maybe))
    assert(not success_1.is_nothing)
    assert(success_1.value == 0)

    failure_1 = Maybe.just(0).filter(lambda x: x == 1)
    assert(isinstance(failure_1, Maybe))
    assert(failure_1.is_nothing)

    failure_2 = Maybe.nothing().filter(lambda x: x == 1)
    assert(isinstance(failure_2, Maybe))
    assert(failure_2.is_nothing)


# Generated at 2022-06-25 23:55:13.238988
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Create new Int
    int_0 = 1

    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = Maybe.just(int_0 + 1)
    maybe_int_2 = Maybe.just(int_0 + 2)
    maybe_int_2 = maybe_int_2.filter(lambda x: x > 0)

    # Create the list of Maybe
    maybe_int_list = [maybe_int_0, maybe_int_1, maybe_int_2]

    # Iterate the list of Maybe
    for maybe_int in maybe_int_list:
        # Check if Maybe is empty
        if not maybe_int.is_nothing:
            # Log the value of Maybe
            print(maybe_int.value)



# Generated at 2022-06-25 23:55:18.695576
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    str_0 = ''
    str_1 = ''
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_1.to_lazy()
    lazy_1 = maybe_0.to_lazy()
    assert lazy_1._function() == int_0


# Generated at 2022-06-25 23:55:20.624426
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:55:35.760643
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_1 = Maybe.just(7)
    maybe_2 = Maybe.just(0)
    maybe_3 = Maybe.nothing()

    assert maybe_1.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_1.filter(lambda x: True) == Maybe.just(7)

    assert maybe_2.filter(lambda x: x % 2 == 0) == Maybe.just(0)
    assert maybe_2.filter(lambda x: True) == Maybe.just(0)

    assert maybe_3.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_3.filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-25 23:55:38.021363
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-25 23:55:40.984718
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_0.filter(lambda x_0: x_0 == int_0)
    maybe_0.filter(lambda x_0: x_0 == int_1)
    maybe_0.filter(lambda x_0: x_0 == int_2)


# Generated at 2022-06-25 23:55:52.324677
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from __pymonet_functions import add_1
    from __pymonet_functions import is_even
    from pymonet.action import Action
    from pymonet.validation import Validation
    from pymonet.box import Box

    # Case 0: Maybe.just(Integer).filter(Function(Integer) -> Integer) -> Maybe[Integer]
    def test_case_0():
        m1 = Maybe.just(0)
        m2 = m1.filter(is_even)
        assert m2 == Maybe.just(0)

    test_case_0()

    # Case 1: Maybe.just(Integer).filter(Function(Integer) -> Validation[String]) -> Maybe[Integer]
    def test_case_1():
        m1 = Maybe.just(0)

# Generated at 2022-06-25 23:55:56.388179
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_1 = Maybe.just(1)
    assert(maybe_1.to_lazy().eval() == 1)

    maybe_2 = Maybe.nothing()
    assert(maybe_2.to_lazy().eval() is None)



# Generated at 2022-06-25 23:56:00.347683
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    testing function filter
    """
    assert Maybe.just(0).filter(lambda x: x < 4) == Maybe.just(0)
    assert Maybe.just(0).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 4) == Maybe.nothing()



# Generated at 2022-06-25 23:56:03.845585
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_just = Maybe.just(int_0)
    maybe_just_no = Maybe.just(int_0)

    maybe_just.filter(lambda x: isinstance(x, int)).is_nothing
    maybe_just_no.filter(lambda x: isinstance(x, str)).is_nothing



# Generated at 2022-06-25 23:56:07.302281
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-25 23:56:09.079047
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-25 23:56:14.570082
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    maybe = maybe.filter(lambda x: 0 < x < 5)
    assert maybe == Maybe.just(1)
    maybe = Maybe.just(1)
    maybe = maybe.filter(lambda x: x < 0)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-25 23:56:26.442341
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = 4
    int_4 = 5

    print('Unit test for method filter of class Maybe')
    print('Unit test for simple value of Maybe')
    maybe_0 = Maybe.just(int_0)
    print('Unit test for function without exception')
    maybe_1 = maybe_0.filter(lambda v: (v == int_0))
    print(maybe_1)
    assert maybe_1 == Maybe.just(int_0)
    print('Unit test for function with exception')
    maybe_2 = maybe_0.filter(lambda v: (v != int_0))
    assert maybe_2 == Maybe.nothing()
    print('Unit test for method filter of class Maybe completed')



# Generated at 2022-06-25 23:56:28.909341
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy().get() == 5
    assert Maybe.nothing().to_lazy().get() is None



# Generated at 2022-06-25 23:56:39.918570
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_int_0 = Maybe.just(int_0)
    maybe_int_1 = maybe_int_0.filter(lambda x: x == 0)
    assert maybe_int_1 == Maybe(None, True)

    maybe_int_2 = maybe_int_0.filter(lambda x: x == 1)
    assert maybe_int_2 == Maybe(1, False)

    int_3 = 3
    maybe_int_3 = Maybe.just(int_3)
    maybe_int_4 = maybe_int_3.filter(lambda x: x == 0)
    assert maybe_int_4 == Maybe(None, True)

    maybe_int_5 = maybe_int_3.filter(lambda x: x == 3)
    assert maybe_int_5 == Maybe(3, False)

   

# Generated at 2022-06-25 23:56:43.195565
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    lazy_0 = Lazy(lambda: int_0)
    assert maybe_0.to_lazy() == lazy_0


# Generated at 2022-06-25 23:56:51.490474
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Given
    int_0 = 1
    int_1 = 2
    int_2 = 3
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    maybe_nothing = Maybe.nothing()
    expected_1 = Lazy(lambda: int_1)
    expected_2 = Lazy(lambda: int_2)
    expected_nothing = Lazy(lambda: None)

    # When
    lazy_1 = maybe_1.to_lazy()
    lazy_2 = maybe_2.to_lazy()
    lazy_nothing = maybe_nothing.to_lazy()

    # Then
    assert lazy_1 == expected_1
    assert lazy_2 == expected_2
    assert lazy_nothing == expected_nothing

test_Maybe_to_lazy()

# Generated at 2022-06-25 23:56:53.230830
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    Maybe.just(10).filter(lambda x: x % 2 == 0)
    Maybe.just(10).filter(lambda x: x % 2 != 0)
    Maybe.nothing().filter(lambda x: x % 2 == 0)


# Generated at 2022-06-25 23:56:58.897699
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # User story Nr. 9
    # In order to prevent computing a value unless needed, as a lazy user
    # I want to have a lazy Maybe monad
    value = 1
    maybe = Maybe.just(value)
    lazy = maybe.to_lazy()
    assert not lazy.is_evaluated()
    assert lazy.get_value() == value
    assert lazy.is_evaluated()


# Generated at 2022-06-25 23:57:10.649235
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe(int_0, False)
    lazy_0 = maybe_0.to_lazy()

    assert lazy_0._is_equal(Lazy(lambda: 1))

    int_1 = 1
    maybe_1 = Maybe(1, False)
    lazy_1 = maybe_1.to_lazy()

    assert lazy_1._is_equal(Lazy(lambda: 1))

    int_2 = 1
    maybe_2 = Maybe(1, False)
    lazy_2 = maybe_2.to_lazy()

    assert lazy_2._is_equal(Lazy(lambda: 1))

    float_0 = 0.0
    maybe_3 = Maybe(0.0, False)
    lazy_3 = maybe_3.to_lazy()

    assert lazy

# Generated at 2022-06-25 23:57:17.997895
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("\n*** test_Maybe_to_lazy ***")
    int_0 = 1
    int_1 = 2

    def get_int_0() -> int:
        return int_0

    def get_int_1() -> int:
        return int_1

    maybe_int_1 = Maybe.just(int_0)
    assert maybe_int_1.to_lazy().value() == int_0

    maybe_int_2 = Maybe.nothing()
    assert maybe_int_2.to_lazy().value() == None


# Generated at 2022-06-25 23:57:21.631717
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()

    assert lazy_0.is_nothing == False

    int_1 = 2
    maybe_1 = Maybe.just(int_1)

    assert maybe_1 == maybe_0



# Generated at 2022-06-25 23:57:36.485817
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2

    # create Maybe from int_0 value
    maybe_int_0 = Maybe.just(int_0)

    # create Maybe from int_1 value
    maybe_int_1 = Maybe.just(int_1)

    def filterer_0(value: int) -> bool:
        return value == int_0

    maybe_int_0_test_0: Maybe[int] = maybe_int_0.filter(filterer_0)
    assert maybe_int_0_test_0 == Maybe.just(int_0)

    def filterer_1(value: int) -> bool:
        return value == int_1

    maybe_int_0_test_1: Maybe[int] = maybe_int_0.filter(filterer_1)

# Generated at 2022-06-25 23:57:40.213164
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    assert Maybe.just(5).to_lazy() == Lazy(lambda : 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda : None)
    Maybe.just(5).to_lazy().get()



# Generated at 2022-06-25 23:57:42.952228
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m: Maybe[int] = Maybe(1, False)
    actual_result: Lazy = m.to_lazy()
    expected_result: Lazy = Lazy(lambda: 1)
    assert actual_result == expected_result



# Generated at 2022-06-25 23:57:48.473099
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    res_0 = Maybe.just(5).filter(lambda x: x > 3)
    assert res_0.is_nothing == False and res_0.value == 5

    res_1 = Maybe.just(1).filter(lambda x: x > 3)
    assert res_1.is_nothing == True

    res_2 = Maybe.nothing().filter(lambda x: x > 3)
    assert res_2.is_nothing == True


# Generated at 2022-06-25 23:57:58.745694
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_error import MonadError

    lazy_0 = Maybe.just(1).to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert isinstance(lazy_0.monad_error, MonadError)
    assert lazy_0.monad_error.is_success()
    lazy_value_0 = lazy_0.get_value()
    assert callable(lazy_value_0)
    assert lazy_value_0() == 1
    lazy_1 = Maybe.nothing().to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert isinstance(lazy_1.monad_error, MonadError)
    assert not lazy_1.monad_error.is_success()

# Generated at 2022-06-25 23:57:59.929780
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    Maybe(1, False).filter(lambda x: x == 1)

# Generated at 2022-06-25 23:58:03.451002
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = Maybe.just(1)
    was_called = False
    def filterer(x):
        nonlocal was_called
        was_called = True

        return x == 1

    result = value.filter(filterer)

    assert(result.is_nothing == False)
    assert(was_called == True)

# Generated at 2022-06-25 23:58:14.405084
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    import pytest

    # define different filterers
    # filterer with positive number is_even
    def filterer_0(x):
        return x % 2 == 0

    # filterer with negative number is_odd
    def filterer_1(x):
        return x % 2 != 0

    # create int Box with negative number and make sure that we got Nothing
    int_box_with_negative_number = Maybe.just(-5)
    assert Maybe.just(-5).filter(filterer_0) == Maybe.nothing()

    # create int Box with negative number and make sure that we got Box with
    # negative number
    int_box_with_negative_number = Maybe.just(5)
    assert Maybe.just(5).filter(filterer_1) == Maybe.just(5)

    # create int

# Generated at 2022-06-25 23:58:22.407214
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad import monad_filter
    from pymonet.functor import functor_filter
    from pymonet.monad import monad_map
    from pymonet.monad import monad_ap
    from pymonet.monad import monad_bind
    from pymonet.applicative import applicative_ap

    monad_filter(Maybe)
    functor_filter(Maybe, Maybe)
    monad_map(Maybe)
    monad_ap(Maybe)
    monad_bind(Maybe)
    applicative_ap(Maybe)

test_Maybe_filter()

# Generated at 2022-06-25 23:58:25.131037
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    result_0 = Maybe.just(test_case_0).to_lazy()
    result_1 = Maybe.just(test_case_0).to_lazy().value
    assert result_0.value == result_1


# Generated at 2022-06-25 23:58:36.524531
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test for not empty Maybe
    int_0 = Maybe.just(1)
    assert int_0.filter(lambda x: x == 1) == Maybe.just(1)
    assert int_0.filter(lambda x: x == 0) == Maybe.nothing()

    # Test for empty Maybe
    int_1 = Maybe.nothing()
    assert int_1.filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-25 23:58:39.973736
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_1 = Maybe.just(1)
    int_1.filter(lambda x: x == 1)
    int_1.filter(lambda x: x != 1)
    int_2 = Maybe.nothing()
    int_2.filter(lambda x: x == 1)


# Generated at 2022-06-25 23:58:43.335080
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda value: value) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda value: value) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value) == Maybe.nothing()


# Generated at 2022-06-25 23:58:45.952241
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    def pred_0(value):
        return value > 10
    maybe_1 = maybe_0.filter(pred_0)
    assert not maybe_1.is_nothing
    assert maybe_1.value == None


# Generated at 2022-06-25 23:58:48.708621
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-25 23:58:51.916872
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:58:57.039804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda int_1: int_1 > 0)

    assert maybe_1.get_or_else() == maybe_0.get_or_else()


# Generated at 2022-06-25 23:59:01.557196
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(1)
    m2 = m1.filter(lambda l: l == 1)
    m3 = m1.filter(lambda l: l == 2)

    assert m1 == Maybe.just(1)
    assert m2 == Maybe.just(1)
    assert m3 == Maybe.nothing()



# Generated at 2022-06-25 23:59:06.001617
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    maybe = Maybe.just(1)
    filterer = lambda x: x == 1

    # act
    actual = maybe.filter(filterer)

    # assert
    Maybe.just(1).should.equal(actual)



# Generated at 2022-06-25 23:59:09.188849
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    monad_0 = Maybe(int_0, True) # Create Maybe with value int_0
    lazy_0 = monad_0.to_lazy()
    print("Expected result : ", "Maybe(None)")
    print("Real result     : ", lazy_0)

# Generated at 2022-06-25 23:59:25.968335
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    :description: Test Maybe with int value
    :param: invalid_value, enum with invalid values
    :param: valid_value, enum with valid values
    :param: filterer, function to test
    :type: TestValue, TestValue, Function
    """
    int_0 = 1
    int_1 = -1
    maybe_int_0 = Maybe[int](int_0, False)
    maybe_int_1 = Maybe[int](int_1, True)
    def filterer(val):
        if val < 0:
            return False
        else:
            return True

    assert (maybe_int_0.filter(filterer) == Maybe[int](int_0, False))
    assert (maybe_int_1.filter(filterer) == Maybe.nothing())


# Generated at 2022-06-25 23:59:32.106356
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Setup
    test_case = "Maybe.to_lazy for not empty Maybe"
    maybe = Maybe(int_0, False)
    expected_lazy = Lazy(lambda: int_0)

    # Exercise
    lazy = maybe.to_lazy()

    # Verify
    assert(lazy == expected_lazy), test_case


# Generated at 2022-06-25 23:59:40.808076
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # test case 0
    list_Maybe_0 = Maybe.just(int_0)
    # test case 1
    list_Maybe_1 = Maybe.nothing()
    # test case 2
    list_Maybe_2 = Maybe.just(int_0)
    test_list_list_Maybe_0 = list([list_Maybe_0])
    test_list_list_Maybe_1 = list([list_Maybe_1])
    test_list_list_Maybe_2 = list([list_Maybe_2])
    for list_Maybe in test_list_list_Maybe_0:
        list_Maybe.filter(lambda x: True)
    for list_Maybe in test_list_list_Maybe_1:
        list_Maybe.filter(lambda x: True)

# Generated at 2022-06-25 23:59:45.284204
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(5)

    assert maybe.filter(lambda x: x == 1) == Maybe.nothing()
    assert maybe.filter(lambda x: x == 5) == Maybe.just(5)

    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-25 23:59:50.202447
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Case when maybe contains something
    maybe_1 = Maybe.just(1)
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.force() == 1

    # Case when maybe contains nothing
    maybe_2 = Maybe.nothing()
    lazy_2 = maybe_2.to_lazy()
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.force() is None


# Generated at 2022-06-25 23:59:53.663281
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(2)
    maybe_0 = maybe_0.filter(lambda a: a > 2)
    assert isinstance(maybe_0, Maybe)
    assert maybe_0.is_nothing


# Generated at 2022-06-26 00:00:02.329847
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    import random

    items = [1, 2, 3, 4, 5]
    expected_items = items
    random.shuffle(items)
    maybe = Maybe.just(items[0])
    random.shuffle(items)
    maybe2 = Maybe.just(items[0])
    random.shuffle(items)
    maybe3 = Maybe.just(items[0])
    p = maybe.filter(lambda v: v % 2 == 0)
    q = maybe2.filter(lambda v: v % 2 == 0)
    r = maybe3.filter(lambda v: v % 2 == 0)
    if (p.is_nothing):
        assert(p.value == None)
        assert(not maybe in expected_items)
        assert(maybe2 in expected_items)
        assert(maybe3 in expected_items)

# Generated at 2022-06-26 00:00:12.796893
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.utils import equal

    maybe_value_1: Maybe[int] = Maybe.just(0)
    assert equal(
        maybe_value_1.filter(lambda x: x == 0),
        Maybe.just(0)
    )
    maybe_value_2: Maybe[int] = Maybe.just(0)
    assert equal(
        maybe_value_2.filter(lambda x: x != 0),
        Maybe.nothing()
    )
    maybe_value_3: Maybe[int] = Maybe.nothing()
    assert equal(
        maybe_value_3.filter(lambda x: x != 0),
        Maybe.nothing()
    )


# Generated at 2022-06-26 00:00:23.422096
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 10
    int_2 = 2
    int_3 = 20
    int_4 = -1
    int_5 = -10

    f_0_0 = lambda int_0_0: int_0_0 > 0

    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.just(int_2)
    maybe_3 = Maybe.just(int_3)
    maybe_4 = Maybe.just(int_4)
    maybe_5 = Maybe.just(int_5)

    maybe_6 = maybe_0.filter(f_0_0)

    maybe_7 = maybe_1.filter(f_0_0)


# Generated at 2022-06-26 00:00:26.690278
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m = Maybe.just(1)
    l = m.to_lazy()
    assert l == Lazy(lambda: 1)



# Generated at 2022-06-26 00:00:45.453069
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    lazy_0 = Maybe.just(int_0).to_lazy()
    int_1 = lazy_0.value

    assert int_1 == int_0


# Generated at 2022-06-26 00:00:53.478292
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    str_0 = 'abc'

    int_1 = Maybe.just(int_0)
    res_0 = int_1.filter(lambda x: False)

    int_2 = Maybe.just(int_0)
    res_1 = int_2.filter(lambda x: True)

    res_2 = res_0.filter(lambda x: True)

    res_3 = str_1.filter(lambda x: True)

    assert res_0 == Maybe.nothing()
    assert res_1 == int_2
    assert res_2 == Maybe.nothing()
    assert res_3 == Maybe.nothing()

    str_1 = Maybe.nothing()



# Generated at 2022-06-26 00:00:58.419812
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_1 = 1
    int_2 = 2
    int_3 = 3
    maybe_int_1 = Maybe.just(int_1)
    lazy_func = maybe_int_1.to_lazy()
    assert maybe_int_1.map(lambda x: x + int_2).get_or_else(0) == int_3
    assert lazy_func.get() == int_1


# Generated at 2022-06-26 00:01:06.789781
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monoid import Monoid
    from pymonet.lazy import Lazy

    def test_case_0():
        int_0 = 1
        maybe_0 = Maybe.just(int_0)
        monoid_0 = Monoid(lambda left, right: left * right)

        lazy_0 = maybe_0.to_lazy()
        assert isinstance(lazy_0, Lazy)
        assert lazy_0.handle_monoid_error(None, monoid_0.handle_error) == int_0

    def test_case_1():
        maybe_0 = Maybe.nothing()
        monoid_0 = Monoid(lambda left, right: left * right)

        lazy_0 = maybe_0.to_lazy()
        assert isinstance(lazy_0, Lazy)
       

# Generated at 2022-06-26 00:01:11.635112
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    assert Maybe.just(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-26 00:01:15.072861
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-26 00:01:18.548867
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    initial_value = Maybe.just(5)
    expected_result = Maybe.just(5)

    actual_result = Maybe(initial_value.value, False).filter(lambda value: value == initial_value.value)

    assert expected_result == actual_result


# Generated at 2022-06-26 00:01:28.179006
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.try_ import Try
    from pymonet.validation import Validation

    default_value = 1
    maybe_int_0 = Maybe.just(2)
    maybe_int_1 = Maybe.just("1")
    maybe_int_2 = Maybe.just("2")
    maybe_none_0 = Maybe.nothing()

    assert maybe_int_0.filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert maybe_int_0.filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert maybe_int_1.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_

# Generated at 2022-06-26 00:01:31.553145
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert isinstance(Maybe.just(1).filter(lambda x: x == 1), Maybe)
    assert isinstance(Maybe.just(1).filter(lambda x: x == 2), Maybe)
    assert isinstance(Maybe.nothing().filter(lambda x: x == 1), Maybe)


# Generated at 2022-06-26 00:01:40.493751
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Create monad Maybe[None]
    # Check if monad is empty
    assert Maybe.nothing().is_nothing == True
    # Check if monad contains None
    assert Maybe.nothing().get_or_else(None) == None
    # Create monad Maybe[A]
    # Check if monad is not empty
    assert Maybe.just(0).is_nothing == False
    # Check if monad contains 0
    assert Maybe.just(0).get_or_else(None) == 0
    # Check if monad contains None when filter returns False
    assert Maybe.just(0).filter(lambda x: x == 1).get_or_else(None) == None
    # Check if monad contains 0 when filter returns True

# Generated at 2022-06-26 00:02:16.503932
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(1)
    maybe_1 = maybe_0.to_lazy()

    int_0 = maybe_1.value()

    maybe_2 = Maybe.nothing()
    maybe_3 = maybe_2.to_lazy()

    int_1 = maybe_3.value()



# Generated at 2022-06-26 00:02:22.059834
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    maybe_1 = maybe_0.filter(lambda value: value is not 0)
    maybe_2 = maybe_1.filter(lambda value: value is not 0)
    assert maybe_0.value == int_0
    assert maybe_2 == maybe_1
    assert maybe_2 == maybe_0
    assert maybe_1 == maybe_0
    assert maybe_0 == maybe_0


# Generated at 2022-06-26 00:02:30.098573
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.monad_writer import Writer
    from pymonet.monad_state import State

    X = TypeVar('X')

    class MyMonad(Monad[X]):
        """
        MyMonad is simply wrapper around string value.
        """

        def __init__(self, value: str) -> None:
            self.value = value

        @classmethod
        def unit(cls, value: X) -> 'MyMonad[X]':
            return MyMonad(str(value))


# Generated at 2022-06-26 00:02:37.485483
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = Maybe.just(1).filter(lambda value: True)
    result_ = int_0
    assert isinstance(result_, Maybe)
    assert result_ == Maybe.just(1)
    int_1 = Maybe.just(1).filter(lambda value: False)
    result_ = int_1
    assert isinstance(result_, Maybe)
    assert result_ == Maybe.nothing()
    int_2 = Maybe.nothing().filter(lambda value: True)
    result_ = int_2
    assert isinstance(result_, Maybe)
    assert result_ == Maybe.nothing()
    int_3 = Maybe.nothing().filter(lambda value: False)
    result_ = int_3
    assert isinstance(result_, Maybe)
    assert result_ == Maybe.nothing()


# Generated at 2022-06-26 00:02:40.171857
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Test case 0
    value_0 = Maybe.just(1).to_lazy().get()
    assert value_0 == 1

    value_1 = Maybe.nothing().to_lazy().get()
    assert value_1 is None


# Generated at 2022-06-26 00:02:47.077865
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(5, False)
    res_0 = maybe_0.filter(lambda x: x == 5)
    assert res_0.is_nothing == False
    assert res_0.value == 5
    res_1 = maybe_0.filter(lambda x: x != 5)
    assert res_1.is_nothing == True
    assert res_1.value == None


# Generated at 2022-06-26 00:02:57.074878
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 0
    int_1 = 1
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_None = Maybe.nothing()
    filterer_0 = lambda x: x == 0
    filterer_1 = lambda x: x == 1
    assert maybe_0.filter(filterer_0).value == int_0
    assert maybe_1.filter(filterer_0).is_nothing
    assert maybe_None.filter(filterer_0).is_nothing
    assert maybe_0.filter(filterer_1).is_nothing
    assert maybe_1.filter(filterer_1).value == int_1
    assert maybe_None.filter(filterer_1).is_nothing


# Generated at 2022-06-26 00:02:58.777558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(int_0, False).to_lazy() == Lazy(lambda: int_0)



# Generated at 2022-06-26 00:03:00.768891
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = Maybe.just(1).filter(lambda a: a > 0)
    expected = Maybe.just(1)
    assert value == expected
