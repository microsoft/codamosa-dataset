

# Generated at 2022-06-25 23:53:09.402245
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_0 = Maybe(1, False)
    assert maybe_0.__eq__(Maybe(1, False))

    maybe_0 = Maybe(1, True)
    assert maybe_0.__eq__(Maybe(None, True))

    maybe_0 = Maybe(1, False)
    assert maybe_0.__eq__(Maybe(1, True)) == False

    maybe_0 = Maybe(1, True)
    assert maybe_0.__eq__(Maybe(1, False)) == False

    maybe_0 = Maybe(1, False)
    assert maybe_0.__eq__(Maybe(0, False)) == False

    maybe_0 = Maybe(1, True)
    assert maybe_0.__eq__(Maybe(1, False)) == False



# Generated at 2022-06-25 23:53:16.554869
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1656.5
    float_1 = float_0
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = Maybe(float_1, bool_0)
    bool_1 = maybe_0 == maybe_1
    bool_2 = Maybe.nothing() == Maybe.just('foo')
    bool_3 = maybe_1 == Maybe.just(float_0)
    bool_4 = Maybe.nothing() == Maybe.nothing()
    bool_5 = Maybe.just('foo') == Maybe.just('foo')
    bool_6 = Maybe.just(float_1) == Maybe.just(float_0)
    bool_7 = maybe_0 == Maybe.just(float_1)
    var_0 = maybe_0 == Maybe.nothing()
    bool_

# Generated at 2022-06-25 23:53:20.001582
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('string').to_lazy()._value() == 'string' and Maybe.nothing().to_lazy()._value() == None


# Generated at 2022-06-25 23:53:30.958617
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box

    float_0 = 2668.37

    maybe_0 = Maybe(float_0, True)
    maybe_1 = Maybe(float_0, True)
    assert maybe_0.__eq__(maybe_1)

    maybe_2 = maybe_0.map(lambda var_0: var_0 * var_0)
    maybe_3 = maybe_1.map(lambda var_1: var_1 * var_1)
    assert maybe_2.__eq__(maybe_3)


# Generated at 2022-06-25 23:53:34.604002
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0
    maybe_2 = Maybe(float_0, bool_0)
    assert (maybe_1 == maybe_2) == (maybe_0 == maybe_2)


# Generated at 2022-06-25 23:53:41.687163
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_var = Maybe.just(21)
    assert test_var.filter(lambda x: x % 2 == 1) == Maybe.just(21), test_var
    assert test_var.filter(lambda x: x % 2 == 0) == Maybe.nothing(), test_var


# Generated at 2022-06-25 23:53:49.125970
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = 1
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    another_0 = maybe_0
    another_1 = Maybe(float_0, bool_0)
    test_1 = maybe_0.__eq__(another_0)
    test_2 = maybe_0.__eq__(another_1)
    assert test_1 == True
    assert test_2 == False


# Generated at 2022-06-25 23:54:01.525098
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = -1656.5
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    float_2 = -1656.5
    bool_2 = True
    maybe_2 = Maybe(float_2, bool_2)
    float_3 = -1656.5
    bool_3 = False
    maybe_3 = Maybe(float_3, bool_3)
    float_4 = -1656.5
    bool_4 = False
    maybe_4 = Maybe(float_4, bool_4)
    float_5 = -1656.5
    bool_5 = True

# Generated at 2022-06-25 23:54:08.958463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = -1656.5
    bool_1 = True
    maybe_1 = Maybe(float_1, bool_1)
    var_1 = maybe_0.__eq__(maybe_1)
    assert var_1 == True, var_1


# Generated at 2022-06-25 23:54:15.382166
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = 1656.5
    bool_0 = True
    bool_1 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = Maybe(float_0, bool_1)
    bool_2 = maybe_0.__eq__(maybe_1)
    assert(bool_2 == False)



# Generated at 2022-06-25 23:54:25.577512
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: True) == Maybe.just(3)
    assert Maybe.just(str_0).filter(lambda x: len(str_0) <= 5) == Maybe.just(str_0)


# Generated at 2022-06-25 23:54:36.421091
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Create instance of Maybe with None
    var_0 = Maybe.nothing()

    # Call method to_lazy of var_0
    result_1 = var_0.to_lazy()

    # Call method call_or_val of result_1
    result_2 = result_1.call_or_val()

    # Assert that result_2 is None
    assert(result_2 is None)

    # Create instance of Maybe with value 'string'
    var_1 = Maybe.just('string')

    # Call method to_lazy of var_1
    result_3 = var_1.to_lazy()

    # Call method call_or_val of result_3
    result_4 = result_3.call_or_val()

    # Assert that result_4 is 'string'

# Generated at 2022-06-25 23:54:42.305582
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Testing for simple case
    str_0 = 'string'
    var_0 = Maybe.just(str_0)
    var_1 = var_0.to_lazy()
    # Testing for simple case
    var_2 = Maybe.nothing()
    var_3 = var_2.to_lazy()


# Generated at 2022-06-25 23:54:46.774094
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    var_1 = Maybe.just(2)
    var_2 = var_1.filter(lambda var_3: var_3 + 1)
    var_4 = test_Maybe_filter.__annotations__['return']
    assert isinstance(var_2, var_4)



# Generated at 2022-06-25 23:54:55.255246
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    str_0 = 'string'
    var_0 = None

    maybe_0 = Maybe.just(str_0)
    maybe_1 = Maybe.just(var_0)
    maybe_2 = Maybe.nothing()

    assert maybe_0.to_lazy().value() == str_0
    assert maybe_1.to_lazy().value() == var_0
    assert maybe_2.to_lazy().value() == var_0


# Generated at 2022-06-25 23:55:08.853490
# Unit test for method filter of class Maybe

# Generated at 2022-06-25 23:55:17.940885
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.function import Function

    maybe_0 = Maybe.just('string')
    maybe_1 = Maybe.nothing()

    assert isinstance(maybe_0.to_lazy(), Lazy)
    assert isinstance(maybe_1.to_lazy(), Lazy)

    val_0 = maybe_0.to_lazy().eval_lazy()
    val_1 = maybe_1.to_lazy().eval_lazy()

    assert Function.is_value_equals(val_0, 'string')
    assert Function.is_value_equals(val_1, None)


# Generated at 2022-06-25 23:55:26.804941
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'string'
    var_0 = None
    var_1 = Maybe.just(str_0)
    var_2 = Maybe.nothing()
    var_3 = Maybe.just(var_0)
    def func_1(arg_0):
        str_0 = 'string'
        var_0 = arg_0 is None
        return not var_0
    var_4 = var_1.filter(func_1)
    var_5 = var_2.filter(func_1)
    var_6 = var_3.filter(func_1)


# Generated at 2022-06-25 23:55:32.281621
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-25 23:55:36.721649
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    Maybe.just(3).filter(lambda x: x == 5) == Maybe.just(3)
    Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    Maybe.nothing().filter(lambda x: x == 5) == Maybe.nothing()
    Maybe.nothing().filter(lambda x: x == 3) == Maybe.nothing()


# Generated at 2022-06-25 23:55:46.330941
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    global str_0
    assert Maybe.just(str_0).filter(lambda x: x == 'string') == Maybe.just(str_0)
    assert Maybe.just(str_0).filter(lambda x: False) == Maybe.nothing()

    def test_case_0():
        str_0 = 'string'


# Generated at 2022-06-25 23:55:50.827542
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'string'

    maybe_0 = Maybe.just(str_0)

    maybe_1 = maybe_0.filter(lambda str_0: str_0 == 'string')

    assert maybe_1 == Maybe.just(str_0)



# Generated at 2022-06-25 23:55:56.688981
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(1)

    assert isinstance(maybe_0.to_lazy(), Lazy)

    maybe_0 = Maybe.nothing()

    assert isinstance(maybe_0.to_lazy(), Lazy) and maybe_0.to_lazy().get() is None



# Generated at 2022-06-25 23:56:03.058584
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Case 0
    result = Maybe.just(2).filter(lambda a: a > 1)
    assert result == Maybe.just(2)
    assert result.filter(lambda a: a > 0) == Maybe.just(2)
    assert result.filter(lambda a: a > 3) == Maybe.nothing()
    # Case 1
    result = Maybe.just(2).filter(lambda a: a < 0)
    assert result == Maybe.nothing()
    # Case 2
    result = Maybe.nothing()
    assert result.filter(lambda a: a > 3) == Maybe.nothing()


# Generated at 2022-06-25 23:56:08.114309
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = 'string'
    m_str_0 = Maybe.just(str_0)
    m_str_1 = Maybe.nothing()
    # Test for not empty Maybe
    assert m_str_0.to_lazy().value() == str_0
    # Test for empty Maybe
    assert m_str_1.to_lazy().value() is None


# Generated at 2022-06-25 23:56:19.704396
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def func():
        from pymonet.box import Box
        from pymonet.maybe import Maybe
        from pymonet.monad_try import Try

        maybe_int = Maybe.just(12)
        assert maybe_int.filter(lambda value: value > 10) == Maybe.just(12)
        assert maybe_int.filter(lambda value: value > 20) == Maybe.nothing()
        assert maybe_int.filter(lambda value: value < 10) == Maybe.nothing()

        maybe_str = Maybe.just(str_0)
        assert maybe_str.filter(lambda value: value == str_0) == Maybe.just(str_0)
        assert maybe_str.filter(lambda value: value == 'qwerty') == Maybe.nothing()

        maybe_box = Maybe.just(Box(12))
        assert maybe_box

# Generated at 2022-06-25 23:56:25.688521
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'string'
    some = Maybe.just(str_0)
    assert some.filter(lambda a: a == str_0).get_or_else(None) == str_0
    assert some.filter(lambda a: a != str_0).get_or_else(None) is None
    nothing = Maybe.nothing()
    assert nothing.filter(lambda a: type(a) == str).get_or_else(None) is None
    assert nothing.filter(lambda a: type(a) == int).get_or_else(None) is None
    test_case_0()


# Generated at 2022-06-25 23:56:28.310825
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:56:31.462591
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    str_0 = 'string'
    maybe_0 = Maybe(str_0, False)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.get() == maybe_0.value


# Generated at 2022-06-25 23:56:33.522041
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() is None


# Generated at 2022-06-25 23:56:45.203426
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = 0.0
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    func_0 = lambda x: x > 0.0
    maybe_1 = maybe_0.filter(func_0)
    assert maybe_1 == Maybe.nothing()

    float_0 = 4.206
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(func_0)
    assert maybe_1 == Maybe.just(4.206)


# Generated at 2022-06-25 23:56:46.202028
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-25 23:56:52.333400
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(int)
    var_0 = maybe_0.filter(lambda x: x == int)
    assert isinstance(var_0, Maybe) and var_0 == Maybe(int, False)

    maybe_1 = Maybe.just(int)
    var_0 = maybe_1.filter(lambda x: x != int)
    assert isinstance(var_0, Maybe) and var_0 == Maybe(None, True)

    maybe_2 = Maybe.just(int)
    var_0 = maybe_2.filter(lambda x: x == str)
    assert isinstance(var_0, Maybe) and var_0 == Maybe(None, True)



# Generated at 2022-06-25 23:57:03.475747
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Local variables
    float_0 = 1254.7
    float_1 = -2767.0
    bool_0 = False
    float_2 = float_1
    maybe_0 = Maybe.just(float_2)
    maybe_1 = Maybe.just(float_1)
    maybe_2 = maybe_1.filter(lambda x: x > float_0)

    assert maybe_0 == maybe_2

    bool_1 = True
    maybe_3 = Maybe(float_1, bool_1)
    maybe_4 = maybe_3.filter(lambda x: x > float_0)
    bool_2 = maybe_4.is_nothing

    assert bool_2

    bool_3 = False
    maybe_5 = Maybe(float_2, bool_3)

# Generated at 2022-06-25 23:57:04.573728
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_case_0()


# Generated at 2022-06-25 23:57:08.565174
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 1455.15
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    var_0.force()


# Generated at 2022-06-25 23:57:14.521350
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    string_0 = "asd"
    bool_0 = True
    maybe_0 = Maybe(string_0, bool_0)
    maybe_0_0 = maybe_0.filter(test_Maybe_filter)

    assert isinstance(maybe_0_0, Maybe)
    assert not maybe_0_0.is_nothing
    assert maybe_0_0.value == string_0


# Generated at 2022-06-25 23:57:17.437609
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1456.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)

    var_0 = maybe_0.filter(lambda arg_0: arg_0 > -0.5)
    assert var_0.is_nothing == False



# Generated at 2022-06-25 23:57:21.909679
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 5.67439
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    assert isinstance(var_0, Maybe)
    assert var_0.is_nothing == bool_0
    assert isinstance(var_0.value, float)
    assert var_0.value == float_0



# Generated at 2022-06-25 23:57:24.792443
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1067.68
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()



# Generated at 2022-06-25 23:57:36.118406
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:57:41.355466
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(Maybe.nothing())
    assert maybe_1.is_nothing
    maybe_2 = Maybe.just('B')
    maybe_3 = maybe_2.filter(Maybe.just('B'))
    assert not maybe_3.is_nothing
    assert maybe_3.value == 'B'
    maybe_4 = maybe_2.filter(Maybe.nothing())
    assert maybe_4.is_nothing


# Generated at 2022-06-25 23:57:45.392001
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test for method to_lazy of class Maybe
    """
    string_0 = \
        "function excising"
    maybe_0 = Maybe.just(string_0)
    var_1 = maybe_0.to_lazy()
    var_2 = var_1.get_or_else(None)


# Generated at 2022-06-25 23:57:55.656221
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -0.00
    str_0 = 'a'
    list_0 = []
    bool_0 = False
    float_1 = float('-nan')
    tuple_0 = (float_1,)
    set_0 = {tuple_0}
    float_2 = float('-inf')
    set_1 = {(float_2, set_0)}
    none_0 = None
    tuple_1 = (str_0, none_0)
    tuple_2 = (None, str_0)
    float_3 = float('-nan')
    set_2 = {tuple_0}
    float_4 = float('-inf')
    set_3 = {(float_4, set_2)}
    str_1 = 'a'
    none_1 = None
    tuple_3

# Generated at 2022-06-25 23:58:03.848416
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(lambda a: a < 3 - 3)
    assert maybe_1.value == float_0

    maybe_1 = maybe_0.filter(lambda a: a <= float_0)
    assert maybe_1.value == float_0

    maybe_2 = maybe_1.filter(lambda a: a >= float_0)
    assert maybe_2.value == float_0

    maybe_3 = maybe_2.filter(lambda a: a == float_0)
    assert maybe_3.value == float_0

    float_1 = float_0 + float_0
    maybe_1 = maybe_0.filter(lambda a: a < float_1)

# Generated at 2022-06-25 23:58:15.016248
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1231.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)

    def filterer(arg_0):
        return arg_0 < 1.0

    bool_1 = bool_0
    float_1 = float_0
    maybe_1 = maybe_0.filter(filterer)
    if bool_1:
        assert ((maybe_1.get_or_else(None)) == float_1)
    else:
        assert (maybe_1.is_nothing)

    bool_2 = False
    maybe_2 = Maybe(float_1, bool_2)

    def filterer(arg_0):
        return arg_0 < 1.0

    bool_3 = bool_2
    float_2 = float_1
    maybe_3

# Generated at 2022-06-25 23:58:24.761316
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -0.2
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    bool_1 = isinstance(maybe_0, Maybe)
    if bool_1:
        var_0 = maybe_0.filter(lambda arg_0: arg_0 >= 0)
    int_0 = 5
    str_0 = "Rndom_String"
    var_1 = Maybe.just(str_0)
    var_2 = var_1.filter(lambda arg_0: len(str_0) == int_0)
    maybe_1 = Maybe(float_0, bool_0)
    var_3 = maybe_1.filter(lambda arg_0: arg_0 / 0)


# Generated at 2022-06-25 23:58:27.541481
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -461.1
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    assert maybe_0.filter(lambda var_0: var_0) == Maybe.just(float_0)



# Generated at 2022-06-25 23:58:32.913418
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    assert var_0.unwrap()() == float_0


# Generated at 2022-06-25 23:58:33.845334
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-25 23:58:48.928696
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    try:
        for i in range(0, 10):
            test_case_0()
    except:
        return False
    return True



# Generated at 2022-06-25 23:59:00.731414
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    class Box(Generic[T]):
        def __init__(self, value: T) -> None:
            self.value = value

        def __eq__(self, other: object) -> bool:
            if isinstance(other, Box):
                return self.value == other.value
            return False

        def __repr__(self) -> str:
            return "Box(%s)" % repr(self.value)

    bool_0 = True
    bool_1 = False
    bool_2 = True
    bool_3 = False
    bool_4 = False
    bool_5 = True
    bool_6 = False
    maybe_0 = Maybe(bool_1, bool_1)
    int_0 = maybe_0.filter(bool)
    bool_7 = bool_2
    bool_8 = bool_6


# Generated at 2022-06-25 23:59:10.479151
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = bool(0)
    int_0 = int()
    float_0 = float(0)
    bool_1 = bool(0)
    if int_0 >= 0 and int_0 <= 0:
        bool_1 = bool(0)
    else:
        bool_1 = bool(1)
    bool_2 = bool(1)
    if float_0 > float_0:
        bool_2 = bool(1)
    else:
        bool_2 = bool(0)
    str_0 = str('')
    if bool_2 is False:
        str_0 = str('')
    else:
        str_0 = str('b')
    if bool_0 is str_0:
        bool_0 = bool(0)
    else:
        bool_0 = bool(1)

# Generated at 2022-06-25 23:59:14.253674
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 0.898989898989899
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    var_1 = var_0.run()
    var_2 = var_1 == float_0
    assert var_2 is True


# Generated at 2022-06-25 23:59:17.109171
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -4.8
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    var_1 = maybe_0.to_lazy().value()


# Generated at 2022-06-25 23:59:20.988313
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_0 = False
    float_0 = -1656.5
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(lambda x: float_0.is_integer())
    bool_1 = maybe_1.is_nothing
    assert bool_1 == bool_0


# Generated at 2022-06-25 23:59:24.363461
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    assert var_0.is_lazy


# Generated at 2022-06-25 23:59:26.709754
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:59:30.754625
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-25 23:59:39.695996
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -35.866
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    def test_filter(val):
        return val >= 0
    maybe_1 = maybe_0.filter(test_filter)
    assert isinstance(maybe_1, Maybe)
    assert maybe_1.is_nothing == True
    float_1 = -11.4
    bool_1 = True
    maybe_2 = Maybe(float_1, bool_1)
    maybe_3 = maybe_2.filter(test_filter)
    assert maybe_3.is_nothing == False
    assert maybe_3.value == float_1
    bool_2 = False
    maybe_4 = Maybe(float_0, bool_2)
    maybe_5 = maybe_4.filter(test_filter)

# Generated at 2022-06-25 23:59:57.347700
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    Lazy_0 = maybe_0.to_lazy()
    var_0 = Lazy_0.force()
    var_1 = Lazy_0.force()
    assert var_0 == var_1


# Generated at 2022-06-26 00:00:08.451708
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -979.248
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = float_0
    def filterer(arg0):
        return arg0 > float_1
    maybe_1 = maybe_0.filter(filterer)

    maybe_2 = Maybe.nothing()
    float_2 = float_1
    def filterer_2(arg0):
        return arg0 > float_2
    maybe_3 = maybe_2.filter(filterer_2)

    assert isinstance(maybe_1, Maybe)
    assert isinstance(maybe_1.get_or_else(None), float)
    assert float_1 == maybe_1.get_or_else(None)
    assert isinstance(maybe_3, Maybe)


# Generated at 2022-06-26 00:00:09.468471
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass


# Generated at 2022-06-26 00:00:17.714118
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test functional method filter.

    :returns: testing result
    :rtype: Boolean
    """
    def check_not_divisible_by(var_0, var_1):
        """
        Check division by 2 and remainder is not 0.

        :param var_0: number to check
        :type var_0: Integer
        :param var_1: number for division
        :type var_1: Integer
        :returns: True when division and remainder is not 0, in other case False
        :rtype: Boolean
        """
        return (var_0 / var_1) % 2 != 0

    bool_0 = True
    var_0 = check_not_divisible_by(9, 3)
    maybe_0 = Maybe(var_0, bool_0)

# Generated at 2022-06-26 00:00:28.555888
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = -1656.5
    bool_1 = True
    maybe_1 = Maybe(float_1, bool_1)
    maybe_2 = maybe_1.filter(lambda x: isinstance(x, int))
    var_0 = maybe_0 == maybe_1
    var_1 = maybe_2.is_nothing
    var_2 = maybe_2.get_or_else(None)
    bool_2 = bool_0
    bool_3 = bool_1
    bool_4 = bool_2
    bool_5 = bool_3
    bool_6 = bool_4
    bool_7 = bool_5
    bool_8 = bool_6
    bool

# Generated at 2022-06-26 00:00:38.522434
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -939555.496314618
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(lambda x: x - 3.2 <= 0)
    maybe_2 = Maybe(float_0, bool_0)
    maybe_3 = maybe_2.filter(lambda x: x + 8.10 <= 0)
    bool_1 = False
    maybe_4 = Maybe(float_0, bool_1)
    maybe_5 = maybe_4.filter(lambda x: x + 8.10 <= 0)
    bool_2 = False
    maybe_6 = Maybe(float_0, bool_2)
    maybe_7 = maybe_6.filter(lambda x: x - 3.2 <= 0)
    bool_3 = False


# Generated at 2022-06-26 00:00:44.517445
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    float_0 = 50.6
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    maybe_0 = maybe_0.filter(lambda arg_0: arg_0 > 59.5)
    var_0 = maybe_0.to_either()
    var_1 = maybe_0.to_validation()
    var_2 = var_1.to_either()
    var_3 = maybe_0.to_box()
    var_4 = var_3.to_either()
    var_5 = var_1.to_try()
    var_6 = var_5.to_try()
    var_7 = var_5.to_either()

# Generated at 2022-06-26 00:00:48.490991
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(lambda var_0: var_0 > 0)
    maybe_1.is_nothing


# Generated at 2022-06-26 00:00:50.889501
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -8.993929
    bool_0 = True
    instance_0 = Maybe(float_0, bool_0)
    result_0 = instance_0.to_lazy()


# Generated at 2022-06-26 00:00:54.423918
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()

    if not ((lazy_0.value != float_0)):
        raise RuntimeError



# Generated at 2022-06-26 00:01:33.924368
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = Maybe(float_0, bool_0)
    float_1 = 1819.76
    float_2 = float_1
    float_3 = float_2
    float_5 = 1819.76
    float_6 = float_5
    float_7 = float_6
    float_8 = float_7
    float_10 = 1819.76
    float_11 = float_10
    float_12 = float_11
    maybe_2 = maybe_1.filter(lambda x: x == float_8)
    maybe_3 = maybe_2.filter(lambda x: x != float_12)



# Generated at 2022-06-26 00:01:37.276107
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = 36.1
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    lazy_0 = maybe_0.to_lazy()
    var_0 = lazy_0.value()



# Generated at 2022-06-26 00:01:43.816727
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe.just(float_0)
    result_0 = maybe_0.filter(lambda val: val > -2.0)
    assert result_0.is_nothing
    assert result_0.is_nothing == bool_0
    maybe_0 = Maybe.just(float_0)
    result_1 = maybe_0.filter(lambda val: val > -2.0)
    assert result_1.is_nothing
    assert result_1.is_nothing == bool_0


# Generated at 2022-06-26 00:01:53.344859
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def func_inner_0(value: float) -> bool:
        return value > 0.0

    def func_inner_1(value: float) -> bool:
        return value > 50.0

    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = maybe_0.filter(func_inner_1)
    value_0 = maybe_0.filter(func_inner_0)
    bool_1 = bool_0
    bool_2 = not bool_1
    bool_3 = bool_2
    bool_4 = bool_3
    bool_5 = not bool_4

    # Assertions

# Generated at 2022-06-26 00:01:58.388197
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    str_0 = 'Hello'
    maybe_0 = Maybe(str_0, False)
    maybe_2 = maybe_0.filter(lambda item: item != 'Hello')
    float_0 = -1656.5
    bool_0 = True
    maybe_1 = Maybe(float_0, bool_0)
    maybe_3 = maybe_1.filter(lambda item: item != -1656.5)



# Generated at 2022-06-26 00:02:03.454690
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -10.4
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()
    assert not (var_0.value() is maybe_0.value)


# Generated at 2022-06-26 00:02:06.125140
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    var_0 = maybe_0.to_lazy()


# Generated at 2022-06-26 00:02:11.864266
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    float_0 = -1656.5
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_0.get_or_else(8)
    lazy_0 = maybe_0.to_lazy()

    maybe_1 = Maybe.just(1656.5)
    maybe_1.get_or_else(8)
    lazy_1 = maybe_1.to_lazy()

    maybe_2 = Maybe.nothing()
    maybe_2.get_or_else(8)
    lazy_2 = maybe_2.to_lazy()

    float_2 = -8
    maybe_3 = Maybe.just(float_2)
    bool_3 = maybe_3.is_nothing
    float_3 = -8
    float_4 = maybe_3.get

# Generated at 2022-06-26 00:02:17.544801
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test 'just' case
    int_0 = 0
    bool_0 = True
    maybe_0 = Maybe(int_0, bool_0)
    maybe_1 = maybe_0.filter(lambda a: bool_0)
    assert maybe_1.is_nothing == False
    assert maybe_1.value == int_0

    # Test 'nothing' case
    bool_0 = True
    maybe_0 = Maybe(None, bool_0)
    maybe_1 = maybe_0.filter(lambda a: bool_0)
    assert maybe_1.is_nothing == True


# Generated at 2022-06-26 00:02:26.339373
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = float()
    float_1 = float(97)
    float_2 = float(24)
    float_3 = float(94)
    float_4 = float()
    float_5 = float(48)
    int_0 = int()
    int_1 = int(2)
    int_2 = int(3)
    int_3 = int()
    int_4 = int(1)
    bool_0 = bool()
    bool_1 = bool(0)
    bool_2 = bool(0)
    bool_3 = bool()
    bool_4 = bool(0)
    str_0 = str()
    str_1 = str(32)
    str_2 = str()
    str_3 = str(33)
    maybe_0 = Maybe.nothing()