

# Generated at 2022-06-25 23:53:12.302864
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = 2112.85
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    def func_0(arg_0: float) -> bool:
        return arg_0 < float(503.088)
    maybe_1 = maybe_0.filter(func_0)
    float_1 = float_0 ** float(0.5)
    bool_1 = bool_0 and float_1 == float(2112.85) ** float(0.5) and func_0(float_1)
    assert maybe_1 == Maybe(float_1, bool_1)


# Generated at 2022-06-25 23:53:19.640710
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = 2112.85
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    def filterer(arg_0):
        return (arg_0) < (float_0)

    maybe_0 = maybe_0.filter(filterer)
    assert maybe_0 == maybe_0


test_case_0()
test_Maybe_filter()

# Generated at 2022-06-25 23:53:26.106132
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = 2112.85
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = 786.46
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    bool_2 = maybe_0 == maybe_1
    assert bool_2 == False



# Generated at 2022-06-25 23:53:31.024404
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functools import is_even
    maybe_0 = Maybe(2112.85, True)
    maybe_0.filter(lambda n: n % 2 == 0) | is_even() | test_0_0()
    maybe_1 = Maybe("", True)
    maybe_1.filter(lambda n: n.find("") == 0) | test_0_1()


# Generated at 2022-06-25 23:53:36.861679
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    import random
    import math

    list_0 = [0,1,2,3]
    maybe_0 = Maybe.just(random.choice(list_0))
    def filterer_0(value_0: int) -> bool:
        return (abs(math.sin(value_0))) > 1.0
    maybe_0 = maybe_0.filter(filterer_0) # Maybe[A] -> Maybe[A]
    maybe_0_value = maybe_0.get_or_else(None)
    test_function(maybe_0_value is None, "test_Maybe_filter_0")


# Generated at 2022-06-25 23:53:46.499262
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = 4422.67627721856
    float_1 = 6342.661159121663
    bool_0 = False
    bool_1 = True
    maybe_0 = Maybe(float_0, bool_0)
    maybe_1 = Maybe(float_1, bool_1)
    maybe_2 = Maybe(float_0, bool_1)
    maybe_3 = Maybe(float_1, bool_0)
    maybe_4 = Maybe(float_0, bool_0)
    maybe_5 = Maybe(float_1, bool_0)
    maybe_6 = Maybe(float_1, bool_1)
    assert maybe_0.__eq__(maybe_4)
    assert maybe_1.__eq__(maybe_6)
    assert maybe_2.__eq__(maybe_2)

# Generated at 2022-06-25 23:53:55.441071
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    # case 0
    float_0 = 2112.85
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = 2112.85
    bool_1 = True
    maybe_1 = Maybe(float_1, bool_1)
    tuple_0 = (maybe_0, maybe_1)
    bool_2 = (maybe_0 == maybe_1)
    bool_3 = bool_2

    assert(
        bool_3
    )

    # case 1
    maybe_2 = Maybe.just(42)
    maybe_3 = Maybe.nothing()
    tuple_1 = (maybe_2, maybe_3)
    bool_4 = (maybe_2 == maybe_3)
    bool_5 = not bool_4


# Generated at 2022-06-25 23:54:00.818459
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    float_0 = 0.0
    bool_0 = False
    maybe_0 = Maybe(float_0, bool_0)
    float_1 = 19.7123
    bool_1 = False
    maybe_1 = Maybe(float_1, bool_1)
    bool_2 = maybe_0 == maybe_1
    bool_2 = not bool_2
    assert bool_2


# Generated at 2022-06-25 23:54:12.794921
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    from pymonet.functor import Functor, functor_law_identity, functor_law_composition

    maybe_functor = Functor(Maybe)

    # Applicative identity: fmap id = id
    left_law_identity = functor_law_identity(maybe_functor)
    result_left_identity = left_law_identity.run()
    assert result_left_identity.is_success, str(result_left_identity)

    # Applicative homomorphism: fmap (f . g) = (fmap f) . (fmap g)
    left_law_composition = functor_law_composition(maybe_functor)
    result_left_composition = left_law_composition.run()

# Generated at 2022-06-25 23:54:23.961075
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    float_0 = -211.411
    float_1 = 0.0
    bool_0 = True
    maybe_0 = Maybe(float_0, bool_0)
    def filterer_0(value: float) -> bool:
        return value < float_1

    maybe_1 = maybe_0.filter(filterer_0)
    assert maybe_1.get_or_else(float_0) == float_0
    str_0 = 'U6'
    bool_1 = False
    maybe_2 = Maybe(str_0, bool_1)
    def filterer_1(value: str) -> bool:
        return value == str_0

    maybe_3 = maybe_2.filter(filterer_1)
    assert maybe_3.get_or_else('gnxV7') == str

# Generated at 2022-06-25 23:54:31.905319
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    maybe_0 = Maybe.just(bool_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == bool_0, 'Test for Maybe.to_lazy failed - 0'


# Generated at 2022-06-25 23:54:39.672970
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_writer import Writer
    from pymonet.validation import Validation

    str_0 = "pymonet"
    str_1 = ""
    maybe_0 = Maybe.just(str_0)
    maybe_1 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    lazy_1 = maybe_1.to_lazy()
    # (Lazy[Function() -> (A | None)]).value()
    assert lazy_0.value() == str_0
    assert lazy_1.value() is None
    # (Maybe[A | None]).to_lazy().get_or_else(B)
    assert lazy_0.get_or_else(str_1) == str_0
    assert lazy

# Generated at 2022-06-25 23:54:48.752601
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.samples.test_Maybe_filter import Maybe_filter_test_cases

    for filter_test_case in Maybe_filter_test_cases.cases:
        in_0: Maybe[Callable[[int], bool]] = filter_test_case.in_0
        in_1: int = filter_test_case.in_1
        expected_result: Maybe[int] = filter_test_case.expected_result

        maybe_0: Maybe[int] = Maybe(in_1, False)

        actual_result: Maybe[int] = maybe_0.filter(in_0)

        assert(expected_result == actual_result)



# Generated at 2022-06-25 23:54:51.545641
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:54:52.217661
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    pass

# Generated at 2022-06-25 23:55:03.689573
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test_utils import is_a_Maybe, is_a_Maybe_of, nothing_of, is_a_Maybe_of_nothing, is_a_Maybe_of_nothing_or_str
    from pymonet.monad_test_utils import is_a_Maybe_of_int

    def filter_func(val):
        if val > 10:
            return True
        return False

    def filter_func2(val):
        if val < 100:
            return True
        return False

    # Data.maybe.helper.filter :: (a -> Boolean) -> Maybe a -> Maybe a
    # filter(predicate, m) is equivalent to m.filter(predicate)
    assert filter(filter_func, Maybe.nothing()) \
        == Maybe.nothing() \
        and is_a_Maybe

# Generated at 2022-06-25 23:55:08.860086
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-25 23:55:15.163702
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_case_1():
        maybe_1 = Maybe.just('Test')
        lazy_1 = maybe_1.to_lazy()
        assert lazy_1.evaluate() == 'Test'
    def test_case_2():
        maybe_2 = Maybe.nothing()
        lazy_2 = maybe_2.to_lazy()
        assert lazy_2.evaluate() is None
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 23:55:19.927966
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda a: a).to_box().unbox() == True
    assert Maybe.just(False).filter(lambda a: a).to_box().unbox() == None
    assert Maybe.nothing().filter(lambda a: a).to_box().unbox() == None


# Generated at 2022-06-25 23:55:23.478833
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(bool) == Maybe.nothing()
    assert Maybe.just(1).filter(bool) == Maybe.just(1)
    assert Maybe.just(0).filter(bool) == Maybe.nothing()


# Generated at 2022-06-25 23:55:31.991884
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    string_0 = "string_0"
    maybe_0 = Maybe.just(string_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy(lambda: string_0)


# Generated at 2022-06-25 23:55:36.495800
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Define test value and filterer
    test_value = None
    filterer = lambda x: False
    expected_value = Maybe.nothing()
    # Create Maybe with test value
    maybe_1 = Maybe.just(test_value)
    # Call filter method and assert
    assert maybe_1.filter(filterer) == expected_value



# Generated at 2022-06-25 23:55:40.920558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    def function_to_lazy_0() -> None:
        return

    maybe_0 = Maybe.just(function_to_lazy_0)

    assert maybe_0.to_lazy().value() == function_to_lazy_0


# Generated at 2022-06-25 23:55:52.282410
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor_tools import identity
    from pymonet.functor_tools import bool_to_int

    maybe_0 = Maybe.just(True)
    maybe_1 = maybe_0.filter(lambda value: value)
    maybe_2 = maybe_0.filter(lambda value: not value)
    maybe_3 = maybe_2.filter(lambda value: identity(value))
    maybe_4 = maybe_2.filter(lambda value: bool_to_int(value))
    maybe_5 = Maybe.nothing().filter(lambda value: identity(value))
    maybe_6 = maybe_5.filter(lambda value: bool_to_int(value))
    maybe_7 = Maybe.nothing().filter(lambda value: bool_to_int(value))

# Generated at 2022-06-25 23:56:01.992194
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy_list import LazyList
    from pymonet.operators import add2

    num_0 = 3
    num_1 = 5
    maybe_0 = Maybe.just(num_0)
    lazy_0 = maybe_0.to_lazy()
    num_2 = lazy_0.value()

    maybe_1 = Maybe.just(num_1)
    lazy_1 = maybe_1.to_lazy()
    num_3 = lazy_1.value()

    num_4 = num_2 * num_3

    list_0 = maybe_0.to_lazy().map(add2).ap(maybe_1.to_lazy().map(add2)).value()
    lazy_2 = maybe_0.to_lazy

# Generated at 2022-06-25 23:56:05.877314
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x < 0) == Maybe.just(0)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-25 23:56:11.046307
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2).get_or_else('else') == 'else'


# Generated at 2022-06-25 23:56:21.914290
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m_0 = Maybe.just(6)
    m_1 = Maybe.just(6)
    m_2 = Maybe.just(6)
    m_3 = Maybe.just(6)
    m_4 = Maybe.nothing()
    m_5 = Maybe.nothing()
    m_6 = Maybe.nothing()
    m_7 = Maybe.nothing()
    b_0 = m_4.filter(lambda x: x % 2 == 0)
    b_1 = m_5.filter(lambda x: x % 2 == 0)
    b_2 = m_6.filter(lambda x: x % 2 == 0)
    b_3 = m_7.filter(lambda x: x % 2 == 0)
    assert (b_0.is_nothing) == True
    assert (b_1.is_nothing) == True

# Generated at 2022-06-25 23:56:31.218460
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.utils import equals
    from pymonet.either import Left, Right

    assert Maybe.just(0).filter(lambda value: True) == Maybe.just(0)
    assert Maybe.just(0).filter(lambda value: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: False) == Maybe.nothing()
    assert Maybe.just("test").filter(lambda value: value == "test") == Maybe.just("test")
    assert Maybe.just("test").filter(lambda value: value == "test_1") == Maybe.nothing()
    assert Maybe.just("test").filter(lambda value: "test" == "test") == Maybe.just("test")

# Generated at 2022-06-25 23:56:38.922558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    ## Should return Lazy[function] with result of Lazy[function] when Maybe is not empty
    result_0 = Maybe.just(None).to_lazy().call()
    result_1 = Maybe.just(None).to_lazy().call()
    assert result_0 == result_1
    ## Should return Lazy[function] in other case
    result_0 = Maybe.nothing().to_lazy().call()
    assert result_0 is None


# Generated at 2022-06-25 23:56:48.417586
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(49, False).filter(lambda x: x < 50) == Maybe.just(49)
    assert Maybe(50, False).filter(lambda x: x < 50) == Maybe.nothing()
    assert Maybe(1, True).filter(lambda x: x < 50) == Maybe.nothing()


# Generated at 2022-06-25 23:56:59.464324
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Unit test for method filter of class Maybe')
    maybe_0 = Maybe.just(0)
    maybe_1 = maybe_0.filter(lambda mapper: mapper == 0)

    assert maybe_1.is_nothing == False
    assert maybe_1 == Maybe.just(0)

    maybe_0 = Maybe.just(0)
    maybe_1 = maybe_0.filter(lambda mapper: mapper > 0)

    assert maybe_1.is_nothing == True
    assert maybe_1 == Maybe.nothing()

    maybe_0 = Maybe.nothing()
    maybe_1 = maybe_0.filter(lambda mapper: mapper > 0)

    assert maybe_1.is_nothing == True
    assert maybe_1 == Maybe.nothing()


# Generated at 2022-06-25 23:57:01.119351
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    functional_test_case_0_Maybe_filter()


# Generated at 2022-06-25 23:57:08.565703
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 10

    maybe_0 = Maybe.just(10)
    maybe_1 = Maybe.nothing()

    result_0 = maybe_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.value() == 10

    result_1 = maybe_1.to_lazy()
    assert isinstance(result_1, Lazy)
    assert result_1.value() == None



# Generated at 2022-06-25 23:57:17.069705
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer_0(x: int) -> bool:
        return x == 5
    maybe_0 = Maybe.just(1)
    maybe_0 = maybe_0.filter(filterer_0)
    assert isinstance(maybe_0, Maybe)
    assert maybe_0.is_nothing == True
    assert maybe_0.value == None
    maybe_1 = Maybe.just(5)
    maybe_1 = maybe_1.filter(filterer_0)
    assert isinstance(maybe_1, Maybe)
    assert maybe_1.is_nothing == False
    assert maybe_1.value == 5



# Generated at 2022-06-25 23:57:19.503546
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    maybe_0 = Maybe(bool_0, bool_0)

    assert maybe_0.to_lazy() == Lazy(lambda : bool_0)


# Generated at 2022-06-25 23:57:22.406522
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(0).to_lazy() == Lazy(lambda: 0)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-25 23:57:32.557020
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just(None)
    maybe_1 = maybe_0.filter(lambda x: False)
    assert maybe_1 == Maybe.nothing()
    maybe_2 = Maybe.just("Functoids are the monoids of function composition.")
    maybe_3 = maybe_2.filter(lambda x: x == "Functoids are the monoids of function composition.")
    assert maybe_3 == Maybe.just("Functoids are the monoids of function composition.")
    maybe_4 = Maybe.just("Functoids are the monoids of function composition.")
    maybe_5 = maybe_4.filter(lambda x: x == "Functoids are the monads of function composition.")
    assert maybe_5 == Maybe.nothing()
    maybe_6 = Maybe.just(None)

# Generated at 2022-06-25 23:57:35.056708
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    expected = Maybe.nothing()
    assert (Maybe.just(True).filter(lambda x: x) == expected)



# Generated at 2022-06-25 23:57:38.257200
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Maybe.just(1).to_lazy()
    assert lazy == Lazy(lambda: 1)
    lazy = Maybe.nothing().to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:51.816977
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    with pytest.raises(TypeError):
        Maybe.filter(None, '')


# Generated at 2022-06-25 23:58:00.737232
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    class Dummy(Functor[Maybe], Monad[Maybe], Applicative[Maybe]):
        def __init__(self, value):
            self.value = value

        def _fmap(self, mapper):
            return Maybe.just(mapper(self.value))

        def _return(self, value):
            return Maybe.just(value)

        def _bind(self, mapper):
            return mapper(self.value)

        def _ap(self, applicative):
            return applicative.map(self.value)

        def _pure(self, value):
            return Maybe.just(value)


# Generated at 2022-06-25 23:58:03.298570
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = 5;
    maybe = Maybe.just(value)
    assert maybe == maybe.filter(lambda x: x == value)
    assert maybe != maybe.filter(lambda x: x != value)
    assert Maybe.nothing() == Maybe.nothing().filter(lambda x: False)


# Generated at 2022-06-25 23:58:05.815087
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe(42, False)
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe(42, False)
    assert maybe.filter(lambda x: x % 2 != 0) == Maybe.nothing()



# Generated at 2022-06-25 23:58:08.605958
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).to_lazy().force() == 10
    assert Maybe.nothing().to_lazy().force() == None


# Generated at 2022-06-25 23:58:19.939477
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def less_than_three_0(value_0):
        return value_0 < 3
    int_0 = 1
    maybe_1 = Maybe.just(int_0)
    maybe_2 = maybe_1.filter(less_than_three_0)
    assert maybe_2 == Maybe(1, False)
    int_1 = 4
    maybe_3 = Maybe.just(int_1)
    maybe_4 = maybe_3.filter(less_than_three_0)
    assert maybe_4 == Maybe(None, True)
    int_2 = 0
    maybe_5 = Maybe.nothing()
    maybe_6 = maybe_5.filter(less_than_three_0)
    assert maybe_6 == Maybe(None, True)
    int_3 = -1

# Generated at 2022-06-25 23:58:24.037187
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    bool_mapper = lambda x: bool(x)
    elem = 0

    maybe_elem = Maybe.just(elem)
    maybe_elem_0 = maybe_elem.filter(bool_mapper)

    assert maybe_elem_0 == Maybe.nothing()


# Generated at 2022-06-25 23:58:28.148707
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe.just(True).filter(lambda x: x)
    expected = Maybe.just(True)
    assert result == expected
    result = Maybe.just(True).filter(lambda x: not x)
    expected = Maybe.nothing()
    assert result == expected
    result = Maybe.nothing().filter(lambda x: x)
    expected = Maybe.nothing()
    assert result == expected



# Generated at 2022-06-25 23:58:37.633046
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("string").filter(lambda v: 1 == 1) == Maybe.just("string")
    assert Maybe.just("string").filter(lambda v: 1 == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: 1 == 1) == Maybe.nothing()

    assert Maybe.just("string").filter(lambda v: 1 == 1).is_nothing == False
    assert Maybe.just("string").filter(lambda v: 1 == 2).is_nothing == True
    assert Maybe.nothing().filter(lambda v: 1 == 1).is_nothing == True



# Generated at 2022-06-25 23:58:46.124879
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.nothing().filter(lambda x: x) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: x!=None) == Maybe.nothing())
    assert(Maybe.just(1).filter(lambda x: x) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x!=1) == Maybe.nothing())
    assert(Maybe.just("dds").filter(lambda x: x =="dds") == Maybe.just("dds"))
    assert(Maybe.just("ds").filter(lambda x: x =="dds") == Maybe.nothing())
    assert(Maybe.just("dds").filter(lambda x: x !="dds") == Maybe.nothing())
    assert(Maybe.just("ds").filter(lambda x: x !="dds") == Maybe.just("ds"))

# Generated at 2022-06-25 23:59:10.766501
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 1) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Unit tests for method map of class Maybe

# Generated at 2022-06-25 23:59:17.185694
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(True, True)
    maybe_1 = maybe_0.filter(lambda x: x)
    assert isinstance(maybe_1, Maybe)
    assert maybe_1.is_nothing == True
    assert maybe_1 == Maybe(None, True)

    maybe_2 = Maybe(0, False)
    maybe_3 = maybe_2.filter(lambda x: x < 1)
    assert isinstance(maybe_3, Maybe)
    assert maybe_3.is_nothing == False
    assert maybe_3 == Maybe(0, False)

    maybe_4 = Maybe('test', False)
    maybe_5 = maybe_4.filter(lambda x: x == 'test')
    assert isinstance(maybe_5, Maybe)
    assert maybe_5.is_nothing == False

# Generated at 2022-06-25 23:59:23.296859
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test simple case when value of Maybe is the same as default value
    maybe_0 = Maybe.just(5)
    assert maybe_0.filter(lambda x: x > 3) == Maybe.just(5)
    # Test case when Maybe is empty
    maybe_1 = Maybe.nothing()
    assert maybe_1.filter(lambda x: x > 3) == maybe_1
    # Test case when value of Maybe is not the same as default value
    maybe_2 = Maybe.just(1)
    assert maybe_2.filter(lambda x: x > 3) == maybe_1



# Generated at 2022-06-25 23:59:26.895841
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing())


# Generated at 2022-06-25 23:59:28.392336
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-25 23:59:33.526249
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe(0, False)
    assert maybe_0.filter(lambda x: x > 0) == Maybe.nothing()
    maybe_1 = Maybe(0, False)
    assert maybe_1.filter(lambda x: x > -1) == maybe_1



# Generated at 2022-06-25 23:59:37.708552
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    input_0 = 5
    maybe_0 = Maybe(input_0, False)
    input_1 = False
    input_2 = None
    def mapper_2(input_2_0: int) -> bool:
        pass
    maybe_0.filter(mapper_2)


# Generated at 2022-06-25 23:59:46.466165
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_0 = Maybe(True, True).to_lazy()
    # Check the result of Maybe.to_lazy
    assert isinstance(lazy_0, Lazy), 'Wrong Maybe.to_lazy method (0)'
    # Check the function Either.get_or_else
    assert lazy_0.value() is None, 'Wrong Maybe.to_lazy method (1)'

    lazy_1 = Maybe(True, False).to_lazy()
    # Check the result of Maybe.to_lazy
    assert isinstance(lazy_1, Lazy), 'Wrong Maybe.to_lazy method (2)'
    # Check the function Either.get_or_else
    assert lazy_1.value(), 'Wrong Maybe.to_lazy method (3)'



# Generated at 2022-06-25 23:59:52.255101
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_0 = Maybe.just([])
    maybe_1 = maybe_0.filter(lambda x: False)
    maybe_2 = Maybe.just(True)
    maybe_3 = maybe_2.filter(lambda x: x)
    maybe_4 = Maybe.nothing()
    maybe_5 = maybe_4.filter(lambda x: True)
    maybe_6 = maybe_3.filter(lambda x: False)

    assert maybe_1.is_nothing and \
        not maybe_3.is_nothing and \
        maybe_3.value and \
        maybe_5.is_nothing and \
        maybe_6.is_nothing
test_Maybe_filter()

# Generated at 2022-06-25 23:59:53.704392
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    _: Maybe[int] = Maybe.nothing()

# Generated at 2022-06-26 00:00:18.660400
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from random import randint
    from pymonet.lazy import Lazy

    """
    Map function when Maybe is empty
    """
    maybe_0 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.result_function() == None

    """
    Map function when Maybe is not empty
    """
    maybe_1 = Maybe.just(randint(0, 100))
    lazy_1 = maybe_1.to_lazy()
    assert maybe_1.get_or_else(None) == lazy_1.result_function()


# Generated at 2022-06-26 00:00:22.114154
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(7)
    maybe_1 = Maybe.nothing()

    assert maybe_0.to_lazy().get() == 7
    assert maybe_1.to_lazy().get() is None


# Generated at 2022-06-26 00:00:28.513378
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    t = Maybe.just(1)
    lazy = t.to_lazy()
    assert isinstance(lazy, Lazy)
    assert 1 == lazy.value()

    t = Maybe.nothing()
    lazy = t.to_lazy()
    assert isinstance(lazy, Lazy)
    assert None == lazy.value()


# Generated at 2022-06-26 00:00:31.154565
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Test function Maybe.to_lazy."""
    maybe_0 = Maybe(int(), True)
    assert maybe_0.to_lazy().force() == None


# Generated at 2022-06-26 00:00:36.160099
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    maybe_0 = Maybe(bool_0, bool_0)

    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: bool_0)

    res_maybe_0 = maybe_0.to_lazy()

    assert lazy_0 == res_maybe_0



# Generated at 2022-06-26 00:00:41.394374
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    global bool_0
    bool_0 = True
    global maybe_0
    maybe_0 = Maybe(bool_0, bool_0)
    global lazy_0
    lazy_0 = maybe_0.to_lazy()
    global bool_1
    bool_1 = bool_0
    global lazy_1
    lazy_1 = lazy_0
    bool_2 = bool_1
    lazy_2 = lazy_1
    assert(bool_0 == bool_2)
    assert(lazy_0 == lazy_2)


# Generated at 2022-06-26 00:00:45.455855
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Case 0: empty Maybe
    maybe_0 = Maybe.nothing()
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0() == None
    # Case 1:
    maybe_1 = Maybe.just(88)
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1() == 88

# Generated at 2022-06-26 00:00:48.179274
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    # Successfully case:
    maybe_0 = Maybe.just(True)
    lazy_0 = maybe_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == True

    # Fail case:
    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == None



# Generated at 2022-06-26 00:00:50.888373
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:00:55.944535
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Lazy

    def __common_0(x: int, y: int) -> int:
        return x * y

    lazy_0: Lazy[Callable[[int, int], int] or None] = Maybe(__common_0, False).to_lazy()
    lazy_1: Lazy[Callable[[int, int], int] or None] = Maybe.nothing().to_lazy()


# Generated at 2022-06-26 00:01:39.952904
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    import pytest

    maybe_0 = Maybe.nothing()
    assert maybe_0.to_lazy() == Lazy(lambda: None)

    maybe_1 = Maybe.just(1)

    assert maybe_1.to_lazy() == Lazy(lambda: 1)
    assert pytest.raises(TypeError, maybe_1.to_lazy, 1)
    assert pytest.raises(TypeError, maybe_1.to_lazy, "1")
    assert pytest.raises(TypeError, maybe_1.to_lazy, [1])
    assert pytest.raises(TypeError, maybe_1.to_lazy, [None])
    assert pytest.raises(TypeError, maybe_1.to_lazy, [])

# Generated at 2022-06-26 00:01:49.098058
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from nose.tools import assert_equal, assert_raises

    maybe_0 = Maybe(1, False)
    assert_equal(
        maybe_0.to_lazy(),
        Lazy(lambda: 1)
    )

    maybe_1 = Maybe(1, False)
    assert_equal(
        maybe_1.to_lazy().map(lambda x: x + 1),
        Lazy(lambda: 2)
    )

    maybe_2 = Maybe(1, False)
    assert_equal(
        maybe_2.to_lazy().bind(lambda x: Lazy(lambda: x + 1)),
        Lazy(lambda: 2)
    )

    maybe_3 = Maybe(1, False)

# Generated at 2022-06-26 00:01:52.979465
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_0 = Maybe(10, True)
    assert maybe_0 == Lazy(lambda: None)

    maybe_1 = Maybe(10, False)
    assert maybe_1 == Lazy(lambda: 10)


# Generated at 2022-06-26 00:01:55.111564
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    bool_0 = True
    maybe_0 = Maybe(bool_0, bool_0)
    maybe_0.to_lazy()


# Generated at 2022-06-26 00:02:02.977179
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("TEST: test_Maybe_to_lazy")
    value_0 = 123
    maybe_0 = Maybe.just(value_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0.value() == value_0
    assert lazy_0.to_maybe() == maybe_0
    maybe_1 = Maybe.nothing()
    lazy_1 = maybe_1.to_lazy()
    assert lazy_1.value() is None
    assert lazy_1.to_maybe() == maybe_1
    print("PASS")



# Generated at 2022-06-26 00:02:06.674947
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # arranges
    int_0 = 0
    bool_0 = False
    maybe_0 = Maybe(int_0, bool_0)
    
    # acts
    maybe_1 = maybe_0.to_lazy()
    
    # asserts
    assert int_0


# Generated at 2022-06-26 00:02:11.222781
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation

    maybe_0 = Maybe(1, False)
    lazy_0 = maybe_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get_value() == 1
    assert isinstance(lazy_0.get_value(), int)

    maybe_1 = Maybe(1, True)
    lazy_1 = maybe_1.to_lazy()

    assert lazy_1.get_value() is None


# Generated at 2022-06-26 00:02:16.658425
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.func_tools import identity

    int_0 = 1
    maybe_0 = Maybe.just(int_0)

    lazy_0 = Lazy(lambda: int_0)
    lazy_2 = maybe_0.to_lazy()

    assert lazy_0 == lazy_2

    lazy_6 = maybe_0.to_lazy().map(identity)
    lazy_7 = maybe_0.to_lazy().map(identity)

    assert lazy_6 == lazy_7


# Generated at 2022-06-26 00:02:18.415249
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # assert test_case_0
    maybe_0 = Maybe.just(1)
    maybe_0.to_lazy()


# Generated at 2022-06-26 00:02:21.795021
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def method_0():
        return 3
    value_0 = Maybe(method_0, False)
    value_1 = value_0.to_lazy()
    assert 3 == value_1.value()
