

# Generated at 2022-06-25 23:53:10.635095
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    dict_1 = dict_0
    maybe_0 = Maybe.just(dict_1)
    bool_0 = maybe_0 == Maybe.nothing()
    bool_1 = maybe_0 == Maybe.just(dict_1)
    bool_2 = maybe_0 == Maybe.just(dict_0)
    assert_equals(False, bool_0)
    assert_equals(True, bool_1)
    assert_equals(False, bool_2)



# Generated at 2022-06-25 23:53:15.428000
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    m = Maybe.nothing().to_lazy()
    assert isinstance(
        m,
        Lazy
    )
    assert m.is_nothing
    assert m.value(
    ) is None
    maybe = Maybe.just(1)
    m = maybe.to_lazy()
    assert isinstance(
        m,
        Lazy
    )
    assert not m.is_nothing
    assert m.value(
    ) == 1

# Generated at 2022-06-25 23:53:27.196503
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)

    Maybe.filter(maybe_0, Maybe.filter)

    Maybe.filter(maybe_0, None)

    dict_1 = {}
    bool_1 = True
    maybe_1 = Maybe(dict_1, bool_1)
    Maybe.filter(maybe_1, Maybe.filter)

    Maybe.filter(maybe_1, Maybe.filter)
    dict_2 = {}
    bool_2 = True
    maybe_2 = Maybe(dict_2, bool_2)

    Maybe.filter(maybe_2, Maybe.filter)

    Maybe.filter(maybe_2, Maybe.filter)



# Generated at 2022-06-25 23:53:30.460435
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe.just(dict_0)
    bool_2 = maybe_0 == maybe_1
    assert bool_2 is True


# Generated at 2022-06-25 23:53:39.476762
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_func_0(Maybe.just(10))
    test_func_1(Maybe.just(0))
    test_func_2(Maybe.nothing())
    test_func_3(Maybe.just(0))
    test_func_4(Maybe.just(0))
    test_func_5(Maybe.just(0))
    test_func_6(Maybe.just(0))
    dict_0 = {}
    dict_0['0'] = 0
    dict_0['1'] = 0
    dict_0['2'] = 0
    dict_0['3'] = 0
    dict_0['4'] = 0
    dict_0['5'] = 0
    dict_0['6'] = 0
    dict_0['7'] = 0
    dict_0['8'] = 0

# Generated at 2022-06-25 23:53:43.608382
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    dict_1 = {}
    bool_1 = True
    maybe_1 = Maybe(dict_1, bool_1)
    assert maybe_0 == maybe_1


# Generated at 2022-06-25 23:53:52.838066
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    dict_1 = dict()
    dict_2 = {'a': 1}
    maybe_0 = Maybe(dict_0, True)
    maybe_1 = Maybe(dict_1, True)
    maybe_2 = Maybe(dict_2, True)
    maybe_3 = Maybe(dict_0, False)
    maybe_4 = Maybe(dict_2, False)
    maybe_5 = Maybe(dict_1, False)
    maybe_6 = Maybe(dict_1, False)
    maybe_7 = Maybe(dict_1, False)
    maybe_8 = Maybe(dict_2, False)
    maybe_9 = Maybe(dict_1, False)
    maybe_10 = Maybe(dict_2, False)
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_

# Generated at 2022-06-25 23:53:58.023725
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    maybe_0 = Maybe(dict_0, bool_0)
    expect = Maybe(dict_0, bool_0)
    actual = maybe_0.__eq__(expect)

    assert_equal(actual, True)


# Generated at 2022-06-25 23:54:01.901451
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    dict_0 = {}
    bool_0 = True
    bool_1 = bool_0
    maybe_0 = Maybe(dict_0, bool_0)
    maybe_1 = Maybe(dict_0, bool_0)
    bool_2 = maybe_0 == maybe_1
    assert True == bool_2


# Generated at 2022-06-25 23:54:13.311621
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Left
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.try_ import Try
    from pymonet.validation import Validation
    either_0 = Left(None)
    lazy_0 = Lazy(lambda: [])
    box_0 = Box(lambda: [])
    try_0 = Try(None, is_success=False)
    validation_0 = Validation.success(None)
    maybe_0 = Maybe.just(lazy_0)
    maybe_1 = Maybe.just(box_0)
    # AssertionError: Maybe({}, False).__eq__(None)
    # AssertionError: Maybe({}, False).__eq__(7)
    # AssertionError: Maybe({}, False).__

# Generated at 2022-06-25 23:54:19.766837
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)


# Generated at 2022-06-25 23:54:26.664334
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe filter method.

    :returns: None
    :rtype: None
    """

    def _filterer(value):
        return value == 0

    assert Maybe.just(0).filter(_filterer) == Maybe.just(0)
    assert Maybe.nothing().filter(_filterer) == Maybe.nothing()

# Generated at 2022-06-25 23:54:29.305999
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_int_0 = Maybe.just(1)
    maybe_int_1 = Maybe.just(1)
    assert maybe_int_0 == maybe_int_1


# Generated at 2022-06-25 23:54:38.663853
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    a = Maybe.just(3)
    b = Maybe.nothing()
    abs = lambda x: x if x > 0 else -x

    assert Maybe.just(3) == a.filter(lambda x: x % 2 == 1)
    assert Maybe.nothing() == a.filter(lambda x: x % 2 == 0)
    assert Maybe.nothing() == b.filter(lambda x: x % 2 == 1)
    assert Maybe.nothing() == b.filter(lambda x: x % 2 == 0)

# Generated at 2022-06-25 23:54:40.388463
# Unit test for method __eq__ of class Maybe

# Generated at 2022-06-25 23:54:50.845153
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad_identity import Identity
    from pymonet.monad_io import IO, bind, read_text_file

    test = Maybe.just(1)
    test = test.filter(lambda x: x == 1)
    assert test == Maybe.just(1)
    test = test.filter(lambda x: x == 2)
    assert test == Maybe.nothing()

    test = Maybe.just(1)
    test = test.filter(lambda x: x == 2)
    assert test == Maybe.nothing()

    test = Maybe.nothing()
    test = test.filter(lambda x: x == 2)
    assert test == Maybe.nothing()

    test = Maybe.just(5)
    test = test.filter(lambda x: x == 5)
   

# Generated at 2022-06-25 23:55:01.179224
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Just testing if to_lazy method works as expected
    """

    int_1 = 1
    int_2 = 2

    # some monad
    some_maybe = Maybe.just(int_1)

    # nothing monad
    nothing_maybe = Maybe.nothing()

    # some validation
    some_lazy = some_maybe.to_lazy()

    assert callable(some_lazy.evaluate())

    # nothing validation
    nothing_lazy = nothing_maybe.to_lazy()

    assert callable(nothing_lazy.evaluate())

    assert some_lazy.evaluate() == int_1
    assert nothing_lazy.evaluate() == None


# Generated at 2022-06-25 23:55:03.766072
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy().get() == 1
    assert Maybe(None, True).to_lazy().get() is None
    return 0



# Generated at 2022-06-25 23:55:09.973064
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_to_lazy_1 = Maybe(1, True).to_lazy()
    assert maybe_to_lazy_1() == None
    maybe_to_lazy_2 = Maybe(1, False).to_lazy()
    assert maybe_to_lazy_2() == 1


# Generated at 2022-06-25 23:55:16.775819
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m_int_0 = Maybe(1, False)
    m_int_0_filtered = m_int_0.filter(lambda x: x > 5)
    m_int_1 = Maybe(1, True)
    m_int_2 = Maybe(2, True)
    assert m_int_0_filtered == Maybe.nothing()
    assert m_int_0_filtered != m_int_1
    assert m_int_0_filtered != m_int_2


# Generated at 2022-06-25 23:55:30.725231
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    maybe_0 = Maybe.just(int_0)
    maybe_1 = Maybe.just(int_1)
    maybe_2 = Maybe.nothing()

    result_0 = maybe_0.to_lazy().force()
    result_1 = maybe_1.to_lazy().force()
    result_2 = maybe_2.to_lazy().force()

    assert(result_0 == int_0)
    assert(result_1 == int_1)
    assert(result_2 is None)


# Generated at 2022-06-25 23:55:33.724513
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)


# Generated at 2022-06-25 23:55:35.503828
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_Maybe = Maybe.just(1)
    assert int_Maybe.to_lazy() == Lazy(lambda: 1)

    str_Maybe = Maybe.nothing()
    assert str_Maybe.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:55:37.003777
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    b = Maybe(int_0, False)
    c = b.to_lazy()
    assert c.get == 1


# Generated at 2022-06-25 23:55:40.643871
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    int_0 = 1
    maybe = Maybe(int_0, False)
    lazy = maybe.to_lazy()
    result = lazy.get()

    assert result == int_0


# Generated at 2022-06-25 23:55:47.320521
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int_0 = Maybe.just(0)
    filtered_maybe_0 = maybe_int_0.filter(lambda x: x > 1)
    assert Maybe.nothing() == filtered_maybe_0

    maybe_int_1 = Maybe.just(1)
    filtered_maybe_1 = maybe_int_1.filter(lambda x: x > 0)
    assert maybe_int_1 == filtered_maybe_1



# Generated at 2022-06-25 23:55:52.199247
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    int_1 = 1
    b_0 = True
    b_1 = False

    maybe_0 = Maybe.just(1)
    maybe_0_to_lazy = maybe_0.to_lazy()

    assert maybe_0_to_lazy.value() == 1


# Generated at 2022-06-25 23:55:56.603222
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(2)
    assert a.filter(lambda x: x < 2) == Maybe.nothing()
    assert a.filter(lambda x: x < 3) == Maybe.just(2)
    return "test_Maybe_filter passed successfully"


# Generated at 2022-06-25 23:56:00.228494
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.force() == int_0


# Generated at 2022-06-25 23:56:05.371634
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    maybe_0 = Maybe.just(int_0)
    try:
        maybe_0.filter(lambda x: x > 0)
        maybe_0.filter(lambda x: x < 0)
        maybe_0.filter(lambda x: x == 1)
    except AttributeError as inst:
        print(inst)
    try:
        Maybe.nothing().filter(lambda x: x > 0)
        Maybe.nothing().filter(lambda x: x < 0)
    except AttributeError as inst:
        print(inst)


# Generated at 2022-06-25 23:56:23.613060
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    _0_1 = Maybe.just(1)
    _1_1 = Maybe.just(1)
    _0_2 = Maybe.just(2)
    _1_none = Maybe.nothing()
    _2_none = Maybe.nothing()

    print(f'_0_1: {_0_1}, _1_1: {_1_1}, _0_2: {_0_2}, _1_none: {_1_none}, _2_none: {_2_none}')
    print('_0_1 == _0_1: ', _0_1 == _0_1)
    print('_0_1 == _1_1: ', _0_1 == _1_1)
    print('_0_1 == _0_2: ', _0_1 == _0_2)
   

# Generated at 2022-06-25 23:56:25.597723
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    result = Maybe.just(1).to_lazy()
    assert result.get() == 1
    assert result.get() == 1
    assert result.get() == 1


# Generated at 2022-06-25 23:56:32.832135
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Prepare
    int_0 = 1
    bool_1 = bool(int_0)
    maybe_int_0 = Maybe.just(int_0)
    bool_2 = bool(int_0)
    bool_3 = bool(int_0)
    bool_4 = bool(int_0)
    bool_5 = bool(int_0)

    # Process
    result_0 = maybe_int_0.filter(bool_2)

    # Verify
    assert bool_3 == True
    assert bool_4 == True
    assert bool_5 == True


# Generated at 2022-06-25 23:56:40.581749
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    int_0 = 1
    int_maybe_0 = Maybe.just(int_0)
    int_1 = 1
    int_maybe_1 = Maybe.just(int_1)
    int_2 = 2
    int_maybe_2 = Maybe.just(int_2)
    assert int_maybe_0 == int_maybe_1
    assert int_maybe_1 != int_maybe_2
    assert int_maybe_0 != int_2
    assert int_maybe_0 == int_1


# Generated at 2022-06-25 23:56:49.657187
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box

    def mapper(value):
        return value + 1

    def add_one(value):
        return value + 1

    maybe_1: Maybe[int] = Maybe.just(int_0)
    maybe_2: Maybe[Box[int]] = Maybe.just(Box(int_0))
    maybe_3: Maybe[int] = Maybe.nothing()
    maybe_4: Maybe[Box[int]] = Maybe.nothing()

    lazy1 = maybe_1.to_lazy()
    lazy2 = maybe_2.to_lazy()
    lazy3 = maybe_3.to_lazy()
    lazy4 = maybe_4.to_lazy()

    assert Box(int_0) == Box(lazy1.value())

# Generated at 2022-06-25 23:56:56.833920
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from random import random
    from src.pymonet.monad_try import Try

    int_0 = int(random()*100)

    maybe_0 = Maybe(int_0, False)

    tuple_0 = maybe_0.to_lazy()

    assert tuple_0.value() == int_0

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 23:57:07.460469
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybes_0 = Maybe.just(int_0).filter(lambda value: value == 1)
    maybes_1 = Maybe.just(int_0).filter(lambda value: value == 2)
    assert isinstance(maybes_0, Maybe) and (isinstance(maybes_0.value, int) and maybes_0.value == 1) and not maybes_0.is_nothing
    assert isinstance(maybes_1, Maybe) and maybes_1.value is None and maybes_1.is_nothing
    maybes_2 = Maybe.nothing().filter(lambda value: value == 2)
    assert isinstance(maybes_2, Maybe) and maybes_2.value is None and maybes_2.is_nothing


# Generated at 2022-06-25 23:57:14.619078
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    maybe = Maybe.just(1).filter(lambda x: x == 1)
    assert maybe == Maybe.just(1)

    maybe = Maybe.just(1).filter(lambda x: x == 2)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-25 23:57:22.325552
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 1
    def test_Maybe_filter_case_1():
        try:
            int_0 = 1
            int_1 = int_0
            int_0

            int_2 = Maybe[int].just(int_1)
            int_1

            int_3 = int_2.filter((lambda x: x > 0))
            int_3

            int_4 = int_3.value
        except Exception:
            return False
        return True

    # Test case 2

# Generated at 2022-06-25 23:57:25.765594
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe_0 = Maybe.just(int_0)
    lazy_0 = maybe_0.to_lazy()
    assert lazy_0 == Lazy(lambda: 1)


# Generated at 2022-06-25 23:57:45.349533
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given

    box = Maybe(1, is_nothing=False)

    # When

    result = box.filter(lambda i: i == 1)

    # Then

    assert Maybe(1, is_nothing=False) == result

# Generated at 2022-06-25 23:57:47.316366
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:51.859290
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import Lazy

    assert(Maybe.just(1).to_lazy()) == Lazy(lambda: 1)
    assert(Maybe.nothing().to_lazy()) == Lazy(lambda: None)


# Generated at 2022-06-25 23:57:54.227845
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(10)
    result = maybe.filter(lambda value: value > 5)
    assert result == Maybe.just(10), "Error filter"



# Generated at 2022-06-25 23:57:58.368473
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1

    val_0 = int_0
    val_1 = Maybe.just(val_0)
    val_2 = val_1.to_lazy()

    val_3 = val_2.value()
    val_4 = val_3 == val_0
    assert val_4



# Generated at 2022-06-25 23:58:00.212494
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe(1, False)
    lazy = maybe.to_lazy()
    assert lazy.value() == 1


# Generated at 2022-06-25 23:58:02.289096
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    if Maybe.just(1).to_lazy() == Maybe.just(1).value():
        return True
    else:
        return False


# Generated at 2022-06-25 23:58:04.709268
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe_value = Lazy(lambda: 2)
    maybe = Maybe.just(maybe_value)
    if maybe.map(lambda maybe_value: maybe_value):
        return True
    else:
        return False


# Generated at 2022-06-25 23:58:11.135279
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def get_int():
        return 1

    big_int = Maybe.just(get_int)
    int_0 = big_int.to_lazy()
    result = [int_0.value(), int_0.value()]
    expected_result = [1, 1]
    assert result == expected_result


# Generated at 2022-06-25 23:58:16.269236
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Setup
    int_0 = 1
    int_1 = 2
    maybe_empty = Maybe.nothing()
    maybe_with_value = Maybe.just(int_0)
    # Exercise and verify
    assert maybe_with_value.to_lazy().force() == int_0
    assert maybe_empty.to_lazy().force() == None


# Generated at 2022-06-25 23:59:07.750017
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    negative_lambda = lambda x: x < 0

    # positive case 1
    m = Maybe.just(int_0)
    assert m.filter(negative_lambda) == m

    # positive case 2
    m = Maybe.nothing()
    assert m.filter(negative_lambda) == m


# Generated at 2022-06-25 23:59:11.812408
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # test case 1
    m_1 = Maybe.just(1)
    l_1 = m_1.to_lazy()
    assert(l_1.get() == 1)

    # test case 2
    m_2 = Maybe.nothing()
    l_2 = m_2.to_lazy()
    assert(l_2.get() == None)


# Generated at 2022-06-25 23:59:13.769523
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(3).filter(lambda value: value >= 3)
    assert(type(m) == Maybe)
    assert(m == Maybe.just(3))


# Generated at 2022-06-25 23:59:16.257132
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    Maybe_int_0 = Maybe.just(int_0)
    Maybe_int_1 = Maybe_int_0.filter(lambda value: value == int_0)
    assert Maybe_int_1 == Maybe_int_0
    Maybe_int_2 = Maybe_i

# Generated at 2022-06-25 23:59:24.899790
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Validation
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    maybe_a = Maybe.just(5)

    actual = maybe_a.filter(lambda x: x > 4)
    assert actual == Maybe.just(5)

    actual = maybe_a.filter(lambda x: x < 4)
    assert actual == Maybe.nothing()

    maybe_b = Maybe.just('hola')
    maybe_c = Maybe.just(Maybe.just(['hola']))
    maybe_d = Maybe.just(Validation.success(None))
    maybe_e = Maybe.just(Left('exception'))

# Generated at 2022-06-25 23:59:35.339498
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1
    int_1 = 2
    bool_0 = False
    bool_1 = True
    str_0 = 'str'
    str_1 = 'str_1'
    str_2 = 'str_2'
    str_3 = 'str_3'
    str_4 = 'str_4'
    str_5 = 'str_5'
    str_6 = 'str_6'
    str_7 = 'str_7'
    str_8 = 'str_8'
    str_9 = 'str_9'

    # Test case 0
    u_0 = Maybe.just(int_1)
    u_1 = Maybe.just(int_0)
    u_2 = u_0.to_lazy()
    u_3 = u_1.to_lazy()

# Generated at 2022-06-25 23:59:37.579192
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    int_0 = 1

    Maybe_0 = Maybe.just(int_0)
    Lazy_0 = Maybe_0.to_lazy()
    Tuple_0 = Lazy_0.run()
    Bool_0 = Tuple_0 == (int_0,)
    return Bool_0

# Generated at 2022-06-25 23:59:39.656584
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_0 = Maybe.just(1)
    lazy_0 = maybe_0.to_lazy()

    print(lazy_0.value().value())


# Generated at 2022-06-25 23:59:42.562907
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_case = Maybe(1, False)
    test_case.filter(lambda a: False if a == 1 else True)

    assert test_case.filter(lambda a: False if a == 1 else True) == Maybe.nothing()

# Generated at 2022-06-25 23:59:48.974934
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int = Maybe.just(1)
    maybe_str = Maybe.just("str")
    maybe_none = Maybe.nothing()
    assert maybe_int.filter(lambda x: x == 1) == Maybe.just(1)
    assert maybe_int.filter(lambda x: x != 1) == Maybe.nothing()
    assert maybe_str.filter(lambda x: x == "str") == Maybe.just("str")
    assert maybe_str.filter(lambda x: x != "str") == Maybe.nothing()
    assert maybe_none.filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-26 00:01:01.126123
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m_int_just_0 = Maybe.just(0)
    m_int_just_0_2 = m_int_just_0.filter(lambda x: x > 2)
    m_int_just_0_3 = m_int_just_0.filter(lambda x: x < 1)
    m_int_nothing = Maybe.nothing()
    m_int_nothing_2 = m_int_nothing.filter(lambda x: x > 2)
    m_int_nothing_3 = m_int_nothing.filter(lambda x: x < 1)

    assert m_int_just_0_2 == Maybe.nothing()
    assert m_int_just_0_3 == Maybe.just(0)
    assert m_int_nothing_2 == Maybe.nothing()

# Generated at 2022-06-26 00:01:04.049126
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy_Maybe = Maybe.just(1).to_lazy()
    lazy_int_0 = lazy_Maybe.value()
    assert lazy_Maybe == Maybe.just(1).to_lazy(), "Lazy Maybe with mapper function."

# Generated at 2022-06-26 00:01:06.033951
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(
        lambda: 1
    ).to_lazy().force()() == 1
    assert Maybe.nothing().to_lazy().force()() is None


# Generated at 2022-06-26 00:01:12.096114
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Create Maybe class
    maybe_class = Maybe(int_0, False)

    # Create function with condition
    new_func = lambda a: a == int_0

    # Apply filter method
    filter_func = maybe_class.filter(new_func)

    # Assert
    assert filter_func == maybe_class


# Generated at 2022-06-26 00:01:17.620730
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    int_3 = -1
    maybe_0 = Maybe.just(1)
    maybe_1 = Maybe.nothing()
    maybe_2 = maybe_0.filter(lambda a: a > 0)
    maybe_3 = maybe_1.filter(lambda a: a > 0)
    maybe_4 = maybe_2.filter(lambda a: a > 0)

    if maybe_2 == Maybe.just(1) and maybe_3 == Maybe.nothing() and maybe_4 == Maybe.just(1):
        assert True
    else:
        assert False


# Generated at 2022-06-26 00:01:21.399078
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    input_data = 2
    expected = Just(2)
    actual = Just(input_data).filter(lambda x : x == 2)
    assert expected == actual

    actual = Just(input_data).filter(lambda x : x == 1)
    assert Nothing() == actual

# Generated at 2022-06-26 00:01:25.047560
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

# Generated at 2022-06-26 00:01:27.921795
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_10 = Maybe.just(10)
    assert(maybe_10.to_lazy().force() == 10)

    maybe_none = Maybe.nothing()
    assert(maybe_none.to_lazy().force() == None)


# Generated at 2022-06-26 00:01:31.329486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    val = Maybe.just(3)
    from pymonet.lazy import Lazy
    assert isinstance(val.to_lazy(), Lazy)
    assert val.to_lazy().force() == 3
    val = Maybe.nothing()
    assert val.to_lazy().force() is None


# Generated at 2022-06-26 00:01:36.665012
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # try to pass
    maybe_0 = Maybe.just(5)
    def filterer(value):
        return value % 2 == 0
    maybe_1 = maybe_0.filter(filterer)
    assert maybe_1 == Maybe.nothing()
    # try to pass
    maybe_2 = Maybe.just(4)
    maybe_3 = maybe_2.filter(filterer)
    assert maybe_3 == Maybe.just(4)


# Generated at 2022-06-26 00:02:49.216985
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print("---------------------------------------------------------------")
    print("test_Maybe_to_lazy start")
    Maybe.just(1).to_lazy().get()
    Maybe.nothing().to_lazy().get()
    print("test_Maybe_to_lazy end")
    print("---------------------------------------------------------------")


# Generated at 2022-06-26 00:02:54.157956
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    assert Maybe.just(int_0).filter(
        lambda value: value == int_0
    ) == Maybe.just(int_0)

    assert Maybe.just(int_0).filter(
        lambda value: value == int_1
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda value: value == int_0
    ) == Maybe.nothing()


# Generated at 2022-06-26 00:02:58.641849
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    int_0 = 1
    str_0 = "foo"
    assert(Maybe.just(int_0).filter(lambda x: True) == Maybe.just(int_0))
    assert(Maybe.just(str_0).filter(lambda x: False) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: True) == Maybe.nothing())

# Generated at 2022-06-26 00:03:01.626263
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_maybe = Maybe.just(1).map(lambda x: Maybe.just(x + 1))
    assert maybe_maybe.filter(lambda x: True) == maybe_maybe
    assert maybe_maybe.filter(lambda x: False) == Maybe.nothing()
