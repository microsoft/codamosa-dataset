

# Generated at 2022-06-24 00:18:43.615730
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_5 = Maybe.just(5)
    maybe_null = Maybe.nothing()
    assert maybe_5.map(lambda x: x + 2) == Maybe.just(7)
    assert maybe_5.map(lambda x: None) == Maybe.just(None)
    assert maybe_null.map(lambda x: None) == Maybe.nothing()


# Generated at 2022-06-24 00:18:48.268843
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe.just(10).bind(lambda x: Try(x)) == Try(10)
    assert Maybe.nothing().bind(lambda x: Try(x)) == Try(None, False)


# Generated at 2022-06-24 00:18:56.383026
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()
    result = Maybe.just(lambda x: x ** 2).ap(Maybe.just(4))
    assert isinstance(result, Maybe)
    assert result == Maybe(16, False)



# Generated at 2022-06-24 00:18:57.815977
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:19:01.454088
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just("test")
    maybe_2 = Maybe.just("test")
    maybe_3 = Maybe.just("test2")
    maybe_4 = Maybe.nothing()
    assert maybe_1 == maybe_2
    assert not maybe_1 == maybe_3
    assert not maybe_1 == maybe_4
    assert not maybe_4 == maybe_1


# Generated at 2022-06-24 00:19:03.679780
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(3).to_either() == \
        pymonet.either.Right(3)

    assert Maybe.nothing().to_either() == \
        pymonet.either.Left(None)


# Generated at 2022-06-24 00:19:07.896846
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def to_box():
        return Maybe.just("hello")
    assert isinstance(to_box(), Maybe)
    assert to_box().to_box().value == "hello"

    def to_box_empty():
        return Maybe.nothing()
    assert isinstance(to_box_empty(), Maybe)
    assert to_box_empty().to_box().value is None


# Generated at 2022-06-24 00:19:14.195606
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe(1, False).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe(None, True).filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:19:20.264900
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(
        Maybe.just(1)
    ) == Maybe.just(2)
    assert Maybe.just(2).ap(
        Maybe.nothing()
    ) == Maybe.nothing()
    assert Maybe.nothing().ap(
        Maybe.nothing()
    ) == Maybe.nothing()


# Generated at 2022-06-24 00:19:26.667522
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(1) == Maybe.just(1))
    assert(Maybe.just(1) != Maybe.just(2))
    assert(Maybe.nothing() == Maybe.nothing())
    assert(Maybe.nothing() == Maybe.just(None))
    assert(Maybe.just(1) != Maybe.nothing())


# Generated at 2022-06-24 00:19:30.971749
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def func(x):
        if x == 1:
            return Maybe.nothing()
        return Maybe.just(x + 1)
    assert Maybe.just(1).bind(func) == Maybe.nothing()
    assert Maybe.just(2).bind(func) == Maybe.just(3)
    assert Maybe.nothing().bind(func) == Maybe.nothing()


# Generated at 2022-06-24 00:19:32.390718
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(None, True) == Maybe.nothing()

# Generated at 2022-06-24 00:19:38.691347
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe1 = Maybe(1, False)
    maybe2 = Maybe(1, False).filter(lambda x: x == 1)
    maybe3 = Maybe(2, False).filter(lambda x: x == 1)
    maybe4 = Maybe(1, True)
    maybe5 = Maybe(2, True)
    assert maybe1 != maybe2
    assert maybe1 != maybe3
    assert maybe1 != maybe4
    assert maybe1 != maybe5
    assert maybe2 != maybe3
    assert maybe2 != maybe4
    assert maybe2 != maybe5
    assert maybe3 != maybe4
    assert maybe3 != maybe5
    assert maybe4 != maybe5

    assert maybe4 is Maybe.nothing() or maybe4.value is None
    assert maybe5 is Maybe.nothing() or maybe5.value is None

    assert maybe2.value == 1
    assert maybe

# Generated at 2022-06-24 00:19:41.823987
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test constructor of class Maybe.
    """
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:19:49.155298
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    just_fn = Maybe.just(lambda a: a + 1)
    just_val = Maybe.just(2)
    nothing_fn = Maybe.nothing()
    nothing_val = Maybe.nothing()

    assert just_fn.bind(just_val) == Maybe.just(3)
    assert nothing_fn.bind(just_val) == Maybe.nothing()
    assert just_fn.bind(nothing_val) == Maybe.nothing()
    assert nothing_fn.bind(nothing_val) == Maybe.nothing()



# Generated at 2022-06-24 00:19:53.435369
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(3, False).bind(lambda x: Maybe(x * 2, False)) == \
        Maybe(6, False)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 2, True)) == \
        Maybe(None, True)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 2, False)) == \
        Maybe(None, True)



# Generated at 2022-06-24 00:19:55.316250
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(4) == Maybe(4, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:19:59.997980
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Maybe_to_Either test.
    """

    assert Maybe.just(11).to_either() == Maybe.just(11).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()



# Generated at 2022-06-24 00:20:06.512423
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    # Another type
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(2)



# Generated at 2022-06-24 00:20:14.809385
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Check if Maybe.bind returns Maybe
    test = Maybe.just(1).bind(lambda x: Maybe.just(x * 2))
    assert isinstance(test, Maybe)
    assert test == Maybe.just(2)

    # Check if Maybe.bind works fine with Maybe.nothing
    test = Maybe.nothing().bind(lambda x: Maybe.just(x * 2))
    assert isinstance(test, Maybe)
    assert test == Maybe.nothing()

    # Check if Maybe.bind works fine with Maybe.nothing and mapper function
    test = Maybe.nothing().bind(lambda x: Maybe.just(x * 2))
    assert isinstance(test, Maybe)
    assert test == Maybe.nothing()



# Generated at 2022-06-24 00:20:19.779008
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:20:22.064287
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right
    assert Maybe.just(lambda x: x.split()).ap(Right('Test string')) == Maybe.just(['Test', 'string'])
    assert Maybe.nothing().ap(Right('Test string')) == Maybe.nothing()


# Generated at 2022-06-24 00:20:24.965387
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 3) == Maybe.just(6)
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * 3) == Maybe.nothing()



# Generated at 2022-06-24 00:20:26.662013
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:20:29.360949
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    m = Maybe.just(3)
    result = m.to_either()

    assert result == Right(3)

    m = Maybe.nothing()
    result = m.to_either()
    assert result == Left(None)

# Generated at 2022-06-24 00:20:34.774371
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:20:41.619966
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    validation = Maybe.just(100).to_validation()
    assert validation == Validation.success(100)

    validation = Maybe.just(100).map(lambda x: x + 1).to_validation()
    assert validation == Validation.success(101)

    validation = Maybe.just(100).bind(lambda x: Maybe.just(x + 1)).to_validation()
    assert validation == Validation.success(101)

    validation = Maybe.just([1, 2, 3, 4]).ap(Maybe.just(lambda x: sum(x))).to_validation()
    assert validation == Validation.success(10)

    validation = Maybe.nothing().to_validation()
    assert validation == Validation.success(None)


# Generated at 2022-06-24 00:20:45.963297
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    def f(x):
        return x + 1

    assert Maybe.just(1).to_lazy().map(f).value() == 2
    assert Maybe.nothing().to_lazy().map(f).value() == None


# Generated at 2022-06-24 00:20:48.947106
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.nothing() == Maybe(None, True)

# Unit tests for map method of class Maybe

# Generated at 2022-06-24 00:20:57.298831
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    m = Maybe.just(1)
    assert m.to_lazy() == Lazy(lambda: 1)
    assert m.to_try() == Try(1, True)
    assert m.to_validation() == Validation.success(1)
    assert m.to_box() == Box(1)
    assert m.to_either() == Right(1)

    m = Maybe.nothing()
    assert m.to_lazy() == Lazy(lambda: None)
    assert m.to_try() == Try(None, False)
    assert m.to_validation

# Generated at 2022-06-24 00:21:03.403684
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:06.682156
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:08.582440
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-24 00:21:11.341557
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Either.right(1)
    assert Maybe.nothing().to_either() == Either.left(None)


# Generated at 2022-06-24 00:21:15.005301
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:20.143025
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('text') == Maybe.just('text')
    assert not Maybe.just('text') == Maybe.just('text1')
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just('text') == Maybe.nothing()



# Generated at 2022-06-24 00:21:22.527434
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    f = lambda x: x * 2
    m = Maybe.just(3)
    mf = Maybe.just(f)
    assert m.ap(mf).is_nothing == False
    assert m.ap(mf).value == 6
    assert Maybe.nothing().ap(mf).is_nothing == True
    assert Maybe.nothing().ap(mf).value == None


# Generated at 2022-06-24 00:21:24.423585
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:21:30.987465
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:21:34.647414
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just(1)
    assert maybe == Maybe(1, False)
    assert maybe.value == 1
    assert maybe.is_nothing == False

    maybe = Maybe.nothing()
    assert maybe == Maybe(None, True)
    assert maybe.is_nothing == True



# Generated at 2022-06-24 00:21:40.004260
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test for constructor of class Maybe.

    :returns: True when test finished without errors
    :rtype: Boolean
    """

    return Maybe.just(10).value == 10



# Generated at 2022-06-24 00:21:43.304038
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    # Check successfull
    assert Maybe.just(1).to_validation() == Validation.success(1)

    # Check empty
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:48.070628
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just(3).ap(
        Box(lambda x, y: x + y)
    ).value == 6

    assert Maybe.just(3).ap(
        Lazy(lambda: lambda x, y: x + y)
    ).value == 6

    assert Maybe.nothing().ap(
        Box(lambda x, y: x + y)
    ).to_box().value is None

    assert Maybe.nothing().ap(
        Lazy(lambda: lambda x, y: x + y)
    ).to_lazy().get_value() is None

# Generated at 2022-06-24 00:21:51.177726
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("test") == Maybe.just("test")
    assert Maybe.just("test") != Maybe.just("tests")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just("test")


# Generated at 2022-06-24 00:21:53.669887
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(1, False).bind(lambda x: Maybe(x + 2, False)) == Maybe(3, False)
    assert Maybe.nothing().bind(lambda x: Maybe(x + 2, False)) == Maybe.nothing()

# Generated at 2022-06-24 00:21:59.316160
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:22:02.317490
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(Box(1)).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:22:08.226822
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:22:12.086226
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    test_box = Box('test')

    assert Maybe.just(test_box).to_box() == test_box


# Generated at 2022-06-24 00:22:16.721725
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

# Generated at 2022-06-24 00:22:19.276459
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1).to_box() == Box(1)



# Generated at 2022-06-24 00:22:21.097779
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(5).value == 5
    assert Maybe.nothing().is_nothing



# Generated at 2022-06-24 00:22:25.776303
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just('value')
    assert m.to_lazy().force() == 'value'

Maybe.nothing.to_lazy = lambda self: self


# Generated at 2022-06-24 00:22:29.313239
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:22:37.626043
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = 'value'
    maybe_value_not_none = Maybe.just(value)
    maybe_value_none = Maybe.nothing()

    assert maybe_value_not_none.filter(lambda x:True) == maybe_value_not_none
    assert maybe_value_not_none.filter(lambda x:False) == Maybe.nothing()
    assert maybe_value_none.filter(lambda x:True) == Maybe.nothing()
    assert maybe_value_none.filter(lambda x:False) == Maybe.nothing()


# Generated at 2022-06-24 00:22:41.017265
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(4).to_box() == Box(4)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:22:42.719062
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1

# Generated at 2022-06-24 00:22:44.181716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    container = Maybe.just(8)
    assert container.to_lazy().eval() == 8


# Generated at 2022-06-24 00:22:46.716349
# Unit test for method map of class Maybe
def test_Maybe_map():

    expected = Maybe.just(2)
    actual = Maybe.just(1).map(lambda x: x + 1)

    assert expected == actual

    expected = Maybe.nothing()
    actual = Maybe.nothing().map(lambda x: x + 1)

    assert expected == actual


# Generated at 2022-06-24 00:22:55.300932
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def __eq__(obj1, obj2):
        return obj1 == obj2

    assert __eq__(1, 1)
    assert __eq__([], [])
    assert __eq__(Maybe.just(1), Maybe.just(1))
    assert __eq__(Maybe.just("a"), Maybe.just("a"))
    assert __eq__(Maybe.just([]), Maybe.just([]))
    assert __eq__(Maybe.nothing(), Maybe.nothing())
    assert __eq__(Maybe.just(1), Maybe.just("1")) is False
    assert __eq__(Maybe.just("a"), Maybe.just("b")) is False
    assert __eq__(Maybe.just(1), Maybe.nothing()) is False
    assert __eq__(Maybe.nothing(), Maybe.just(1)) is False
    assert __eq__

# Generated at 2022-06-24 00:22:59.927337
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Unit test for method to_box of class Maybe.

    :returns: Nothing
    :rtype: Nothing
    """
    from pymonet.box import Box

    assert Maybe(42, False).to_box() == Box(42)
    assert Maybe(None, True).to_box() == Box(None)
    assert Maybe(42, True).to_box() == Box(None)



# Generated at 2022-06-24 00:23:02.713250
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test function for method to_either of class Maybe.
    """
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:23:04.201956
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:23:09.880551
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    :returns: True when test passed, otherwise raises AssertionError
    :rtype: Boolean
    """
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy, LazyException
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, ValidationException

    def get_value(x):
        return 1

    def raise_error(x):
        raise Exception()

    def change_value(x):
        return x + 1

    def try_to_change_value(x):
        try:
            return x + 1
        except (TypeError, ValueError):
            return x


# Generated at 2022-06-24 00:23:16.217534
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just('string') == Maybe.just('string')
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:23:18.653067
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:23:21.665839
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(True).to_box() == Box(True)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:23:30.273141
# Unit test for constructor of class Maybe
def test_Maybe():
    from hypothesis import given
    from hypothesis.strategies import integers, text

    just_int = Maybe.just(integers())
    just_str = Maybe.just(text())
    nothing_int = Maybe.nothing()
    nothing_str = Maybe.nothing()

    assert just_int.value == integers()
    assert just_str.value == text()

    @given(integers())
    def test_just(integer):
        assert Maybe.just(integer) == Maybe(integer, False)

    @given(integers())
    def test_nothing(integer):
        nothing = Maybe.nothing()
        assert nothing == Maybe(integer, True)

    @given(integers())
    def test_map(integer):
        assert Maybe.nothing().map(lambda x: x*2) == Maybe.nothing()

# Generated at 2022-06-24 00:23:32.025404
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    m = Maybe.just(2)
    b = m.to_box()

    assert b.value == 2

# Generated at 2022-06-24 00:23:36.714889
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    two_plus_two = Maybe.just(2).bind(lambda x: Maybe.just(x + 2))
    two_plus_undefined = Maybe.nothing().bind(lambda x: Maybe.just(x + 2))

    assert two_plus_two == Maybe.just(4)
    assert two_plus_undefined == Maybe.nothing()


# Generated at 2022-06-24 00:23:40.766405
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Test for method get_or_else from Maybe class.
    """
    assert Maybe.just(42).get_or_else(6) == 42
    assert Maybe.nothing().get_or_else(6) == 6


# Generated at 2022-06-24 00:23:42.170364
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(2).to_try() == Try(2, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:23:47.710706
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe1 = Maybe.just(1)
    assert maybe1.filter(lambda x: False) == Maybe.nothing()
    assert maybe1.filter(lambda x: True) == maybe1
    maybe2 = Maybe.nothing()
    assert maybe2.filter(lambda x: False) == maybe2
    assert maybe2.filter(lambda x: True) == maybe2



# Generated at 2022-06-24 00:23:52.809454
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(None, True).to_validation() == Validation.success(None)
    assert Maybe(1, False).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:23:57.771164
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_one(x):
        return x + 1

    m_add_one = Maybe.just(add_one)

    assert Maybe.just(0).ap(m_add_one) == Maybe.just(1)
    assert Maybe.nothing().ap(m_add_one) == Maybe.nothing()



# Generated at 2022-06-24 00:24:01.204263
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(2).to_try() == Try(2, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:24:04.597193
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)

    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:11.683819
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    monad = Maybe.just(
        Maybe.just(
            Maybe.just(10).map(lambda x: x * 2)
        ).bind(lambda x: x)
    ).bind(lambda x: x)
    assert isinstance(monad, Maybe)
    assert monad == Maybe.just(20)


# Generated at 2022-06-24 00:24:17.078242
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(12).get_or_else(4) == 12
    assert Maybe.nothing().get_or_else(4) == 4



# Generated at 2022-06-24 00:24:19.952689
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    maybe = Maybe.just(1)
    is_even = lambda x: x % 2 == 0

    # when
    result = maybe.filter(is_even)

    # then
    assert result == Maybe.nothing()

# Generated at 2022-06-24 00:24:23.617372
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    fun = lambda x: x + 1
    just_fun = Maybe.just(fun)
    just_one = Maybe.just(1)
    assert just_fun.ap(just_one) == Maybe.just(2)



# Generated at 2022-06-24 00:24:27.350297
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(10).bind(lambda x: Maybe.just(x * 5)) == Maybe.just(50)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()


# Generated at 2022-06-24 00:24:33.777862
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    def test_success():
        assert Maybe.just(1).to_try() == Try(1, is_success=True)

    def test_failure():
        assert Maybe.nothing().to_try() == Try(None, is_success=False)

    test_success()
    test_failure()


# Generated at 2022-06-24 00:24:38.010632
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.nothing().bind(lambda _: Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda x: Maybe.just(x * 2)) == Maybe.just(4)

# Generated at 2022-06-24 00:24:42.668476
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:24:45.163077
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # Validations should be equal
    assert Maybe.just(7).to_validation() == Validation.success(7)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:56.122492
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe(3, False)
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 2)) == Maybe(3, False)
    assert Maybe.just(1).ap(Maybe.just(lambda x: x + 2)) == Maybe(3, False)
    assert Maybe.just(1).get_or_else(1) == 1
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.just(1).filter(lambda x: x % 2 == 1) == Maybe(1, False)
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe(None, True)
    assert Maybe.just(1).to_either()

# Generated at 2022-06-24 00:25:00.167965
# Unit test for constructor of class Maybe
def test_Maybe():
    monad = Maybe.just(5)

    # Check constructing of Maybe with value
    assert monad.value == 5
    assert monad.is_nothing is False
    assert monad == Maybe(5, False)

    # Check constructing of Maybe without value
    monad = Maybe.nothing()

    assert monad.is_nothing is True
    assert monad == Maybe(None, True)


# Generated at 2022-06-24 00:25:05.810837
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.just('a').get_or_else('b') == 'a'
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.nothing().get_or_else('a') == 'a'



# Generated at 2022-06-24 00:25:10.706583
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe_with_value = Maybe.just(5)
    maybe_with_nothing = Maybe.nothing()
    from pymonet.box import Box
    assert maybe_with_value.to_box() == Box(5)
    assert maybe_with_nothing.to_box() == Box(None)


# Generated at 2022-06-24 00:25:13.185539
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(1) == 42
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:25:20.461198
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    
    """
    # Test Maybe.to_either() where Maybe is empty
    maybe = Maybe.nothing()
    expected_either = (False, None)
    actual_either = (maybe.to_either().is_success, maybe.to_either().get_value())
    assert expected_either == actual_either

    # Test Maybe.to_either() where Maybe is not empty
    maybe = Maybe.just(23)
    expected_either = (True, 23)
    actual_either = (maybe.to_either().is_success, maybe.to_either().get_value())
    assert expected_either == actual_either


# Generated at 2022-06-24 00:25:25.131387
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert (
        Maybe.just(10).to_lazy() ==
        Lazy(lambda: 10)
    )
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:25:28.431027
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:25:33.253473
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box().map(lambda number: number + 1) == \
        Maybe.just(2).to_box()
    assert Maybe.nothing().to_box().map(lambda number: number + 1) == \
        Maybe.nothing().to_box()


# Generated at 2022-06-24 00:25:37.299552
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    result = Maybe.just(42).to_lazy()
    del result.value
    assert result == Lazy(lambda: 42)
    result = Maybe.nothing().to_lazy()
    del result.value
    assert result == Lazy(lambda: None)


# Generated at 2022-06-24 00:25:40.852466
# Unit test for method map of class Maybe
def test_Maybe_map():

    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(1).map(lambda x: x / 0) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * 5) == Maybe.nothing()



# Generated at 2022-06-24 00:25:44.135336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 0) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-24 00:25:46.380296
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(6) == 5
    assert Maybe.nothing().get_or_else(6) == 6


# Generated at 2022-06-24 00:25:56.784318
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def run_test(monad_A, monad_B, expected_result):
        result = (monad_A == monad_B)
        assert expected_result == result, \
            "expected {0}, actual {1}".format(expected_result, result)
    # case for same Nothing
    run_test(Maybe.nothing(), Maybe.nothing(), True)
    # case for same Just
    run_test(Maybe.just('x'), Maybe.just('x'), True)
    # case for different Just
    run_test(Maybe.just('x'), Maybe.just('y'), False)
    # case for Just and Nothing
    run_test(Maybe.just('x'), Maybe.nothing(), False)
    # case for Nothing and Just
    run_test(Maybe.nothing(), Maybe.just('x'), False)

# Unit test

# Generated at 2022-06-24 00:25:59.763991
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert str(Maybe(10, False).to_lazy()) == "<Lazy: <function Maybe.<locals>.<lambda> at 0x[0-9a-fA-F]+>>"
    assert str(Maybe.nothing().to_lazy()) == "<Lazy: <function Maybe.<locals>.<lambda> at 0x[0-9a-fA-F]+>>"


# Generated at 2022-06-24 00:26:01.730302
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:26:03.972355
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda: 2) == Maybe.just(2)



# Generated at 2022-06-24 00:26:07.564651
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('123').value == '123'
    assert Maybe.just('123').is_nothing == False

    assert Maybe.nothing().value == None
    assert Maybe.nothing().is_nothing == True



# Generated at 2022-06-24 00:26:14.622330
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def foo():
        print('foo')
        return 'foo'

    res1 = (
        Maybe(foo, False)
        .to_lazy()
        .bind(lambda x: x())
    )
    assert res1 == Try(foo(), True)

    def bar():
        print('bar')
        return 'bar'

    res2 = (
        Maybe(None, True)
        .to_lazy()
    )
    assert res2 == Lazy(lambda: None)



# Generated at 2022-06-24 00:26:18.896780
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:26:21.477721
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:26:27.408225
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test of empty constructor of Maybe.

    :returns: Boolean result (True when test was passed, in other case False)
    :rtype: Boolean
    """
    maybe = Maybe.just('Some')
    maybe_nothing = Maybe.nothing()

    return maybe.get_or_else(None) == 'Some' and maybe_nothing.get_or_else(None) is None

# Unit tests for class Maybe

# Generated at 2022-06-24 00:26:31.964365
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("string") == Maybe.just("string")
    assert Maybe.just("string") != Maybe.nothing()
    assert Maybe.just("string") != Maybe.just("another string")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just("string")


# Generated at 2022-06-24 00:26:34.321499
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(1, True).to_try() == Try(None, False)

# Generated at 2022-06-24 00:26:37.110713
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert (Maybe(1, False).map(lambda x: x + 1)) == Maybe(2, False)
    assert (Maybe(None, True).map(lambda x: 1)) == Maybe(None, True)



# Generated at 2022-06-24 00:26:39.145165
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:26:43.275736
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(42)
    assert maybe.to_lazy().value() == 42
    assert maybe.to_lazy().value() == maybe.value

    maybe = Maybe.nothing()
    assert maybe.to_lazy().value() is None
    assert maybe.to_lazy().value() is maybe.value



# Generated at 2022-06-24 00:26:46.157291
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative

    def binary(x):
        def binary_inner(y):
            return 2 * x + 2 * y
        return Applicative(binary_inner)

    assert Maybe.just(3).ap(binary(2)) == Maybe(6, False)
    assert Maybe.nothing().ap(binary(2)) == Maybe.nothing()


# Generated at 2022-06-24 00:26:58.078489
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    def div(x, y):
        if y == 0:
            return Try(None, is_success=False)
        return Try(x / y)

    def raise_error(x, y):
        raise Exception("msg")

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).map(lambda x: div(x, 0)).to_try() == Try(None, is_success=False)
    assert Maybe.just(1).map(lambda x: div(x, 1)).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:27:01.745595
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(10, False).to_validation() == Validation.success(10)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:09.314359
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    v1 = Try(1, True)
    v2 = Try(2, True)
    v3 = Try(None, False)

    assert Maybe(v1, False).to_try() == v1
    assert Maybe(v2, False).to_try() == v2
    assert Maybe(v3, False).to_try() == v3
    assert Maybe(None, True).to_try() == v3

# Generated at 2022-06-24 00:27:12.670952
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == (Left(None))
    assert Maybe.just(None).to_either() == (Right(None))
    assert Maybe.just('test').to_either() == (Right('test'))



# Generated at 2022-06-24 00:27:14.556492
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:27:20.178385
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:27:31.719618
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy, LazyMonad

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(1.1).to_lazy() == Lazy(lambda: 1.1)
    assert Maybe.just('a').to_lazy() == Lazy(lambda: 'a')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just([]).to_lazy() == Lazy(lambda: [])
    assert Maybe.just({}).to_lazy() == Lazy(lambda: {})
    assert Maybe.just(LazyMonad(lambda: 1)).to_lazy() == Lazy(lambda: LazyMonad(lambda: 1))

# Generated at 2022-06-24 00:27:37.015353
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()



# Generated at 2022-06-24 00:27:39.752308
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(None, True).to_try() == Try(None, False)



# Generated at 2022-06-24 00:27:46.568987
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.lazy import Lazy

    maybe_value = Maybe.just(1).bind(lambda x: Maybe.just(2 * x))
    assert maybe_value == Maybe.just(2)

    maybe_value = Maybe.nothing().bind(lambda x: Maybe.just(x))
    assert maybe_value == Maybe.nothing()

    maybe_value = Maybe.nothing().bind(lambda x: Lazy(lambda: Maybe.just(x)))
    assert maybe_value == Maybe.nothing()

    maybe_value = Maybe.just(1).bind(lambda x: Lazy(lambda: Maybe.just(2 * x)))
    assert maybe_value == Maybe.just(2)

# Generated at 2022-06-24 00:27:52.286919
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test map method of class Maybe.

    :returns: Nothing
    :rtype: Nothing
    """

    def inc(num):
        return num + 1

    def is_negative(num):
        return num < 0

    test_number = 100
    test_maybe_number = Maybe.just(test_number)
    assert test_maybe_number.map(inc) == Maybe.just(test_number + 1)
    assert test_maybe_number.map(is_negative) == Maybe.just(False)

    test_maybe_number = Maybe.nothing()
    assert test_maybe_number.map(inc) == Maybe.nothing()
    assert test_maybe_number.map(is_negative) == Maybe.nothing()


# Generated at 2022-06-24 00:28:02.064540
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right

    assert Maybe.just(lambda v: v + 1) \
        .ap(Right(8)) \
        == Right(9), \
        'test_Maybe_ap(): Maybe with lambda add 1 and right monad with 8 is right monad with 9'

    assert Maybe.just(lambda v: v + 1) \
        .ap(Left('error')) \
        == Maybe.nothing(), \
        'test_Maybe_ap(): Maybe with lambda add 1 and left monad with error is Nothing'

    assert Maybe.nothing() \
        .ap(Right(8)) \
        == Maybe.nothing(), \
        'test_Maybe_ap(): Nothing and right monad with 8 is Nothing'


# Generated at 2022-06-24 00:28:06.163555
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(
        42
    ).to_lazy().evaluate() == 42
    assert Maybe.nothing().to_lazy().evaluate() == None


# Generated at 2022-06-24 00:28:10.240340
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(3) == Maybe.just(3).to_validation()
    assert Validation.success(None) == Maybe.nothing().to_validation()


# Generated at 2022-06-24 00:28:13.788173
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe(10, False).to_lazy() == Lazy(lambda: 10)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:28:17.176331
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(20).get_or_else(10) == 20
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-24 00:28:19.207107
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Right(None)


# Generated at 2022-06-24 00:28:22.325804
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:28:24.575017
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:28:31.797438
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    def sum(a):
        return lambda b: a + b

    assert Maybe.just(1).ap(Box(sum)).value == 2
    assert Maybe.just(1).ap(Box(None)).value is None
    assert Maybe.nothing().ap(Box(None)).value is None
    assert Maybe.nothing().ap(Box(sum)).value is None


# Generated at 2022-06-24 00:28:35.182268
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    not_empty_maybe = Maybe.just(1)
    assert not_empty_maybe.to_try() == Try(1, True)

    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_try() == Try(None, False)

# Generated at 2022-06-24 00:28:41.955628
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Unit test to get_or_else method of Maybe

    :returns: exit code
    :rtype: Integer
    """
    import sys

    # Test empty Maybe
    assert Maybe.nothing().get_or_else(10) == 10

    # Test Maybe with value
    assert Maybe.just(1).get_or_else(10) == 1

    return 0

