

# Generated at 2022-06-24 00:18:47.988465
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:18:49.789576
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(num):
        return num % 2 == 0

    assert Maybe.just(2).filter(is_even) == Maybe.just(2)

# Generated at 2022-06-24 00:18:53.973210
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test map method of Maybe monad.
    """
    assert Maybe.just(2).map(lambda x: x * x) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()


# Generated at 2022-06-24 00:18:57.280149
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:02.971905
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.validation import Validation

    def f(a: str) -> Maybe[int]:
        return Maybe.just(len(a))

    assert Maybe.just(1).bind(f) == Maybe.just(1)
    assert Maybe.nothing().bind(f) == Maybe.nothing()
    assert Maybe.just('Yes').bind(f) == Maybe.just(3)
    assert Maybe.just('No').bind(f) == Maybe.just(2)
    assert Maybe.just('Maybe').bind(f) == Maybe.just(5)
    assert Maybe.just(Validation.success(4)).bind(f) == Maybe.just(4)
    assert Maybe.just(Validation.failure(['No data!'])).bind(f) == Maybe.nothing()


# Generated at 2022-06-24 00:19:07.620851
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x % 2 == 0) == Maybe.just(0)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-24 00:19:14.514457
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:19:17.764496
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_maybe import Maybe
    from operator import add

    assert Maybe(1, False).map(add(2)) == Maybe(3, False)
    assert Maybe(None, True).map(add(2)) == Maybe(None, True)


# Generated at 2022-06-24 00:19:24.594440
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe.just(1)
    assert Validation.success(1) == maybe.to_validation()
    assert Validation.success(1).to_either() == maybe.to_validation().to_either()

    maybe = Maybe.nothing()
    assert Validation.success(None) == maybe.to_validation()
    assert Validation.success(None).to_either() == maybe.to_validation().to_either()


# Generated at 2022-06-24 00:19:29.314280
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(2) == 3
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.just(3).get_or_else('a') == 3
    assert Maybe.nothing().get_or_else('a') == 'a'


# Generated at 2022-06-24 00:19:32.940758
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != ""
    assert Maybe.nothing() != ""


# Generated at 2022-06-24 00:19:36.889106
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    #Arrange
    from pymonet.box import Box
    from pymonet.either import Right
    maybe_unit = Box(1)
    expected = Right(1)
    #Act
    actual = maybe_unit.to_either()
    #Assert
    assert expected == actual


# Generated at 2022-06-24 00:19:41.502329
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try, Success, Failure

    assert Maybe(1, False).to_try() == Success(1)
    assert Maybe(1, True).to_try() == Failure(None)
    assert Maybe("a", False).to_try() == Success("a")
    assert Maybe("a", True).to_try() == Failure(None)
    assert Maybe([1], False).to_try() == Success([1])
    assert Maybe([1], True).to_try() == Failure(None)



# Generated at 2022-06-24 00:19:46.403584
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:19:49.693460
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(
        lambda x: Maybe.just(x + 1)
    ) == Maybe.just(3)

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x + 1)
    ) == Maybe.nothing()



# Generated at 2022-06-24 00:19:55.964636
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    mb = Maybe.just(5)

    # Act
    mb1 = mb.filter(lambda v: v % 2 == 0)
    mb2 = mb.filter(lambda v: v % 2 == 1)

    # Assert
    assert mb1 == Maybe.nothing()
    assert mb2 == Maybe.just(5)

    # Arrange
    mb = Maybe.nothing()

    # Act
    mb1 = mb.filter(lambda v: v % 2 == 0)
    mb2 = mb.filter(lambda v: v % 2 == 1)

    # Assert
    assert mb1 == Maybe.nothing()
    assert mb2 == Maybe.nothing()



# Generated at 2022-06-24 00:20:01.119929
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x >= 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x >= 2) == Maybe.nothing()



# Generated at 2022-06-24 00:20:11.092944
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def inc(n):
        return n + 1


# Generated at 2022-06-24 00:20:13.606672
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(input_): return input_ < 3

    assert Maybe.just(1).filter(filterer) == Maybe.just(1)
    assert Maybe.just(5).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()


test_Maybe_filter()

# Generated at 2022-06-24 00:20:15.557427
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda b: b).value == True
    assert Maybe.just(True).filter(lambda b: not b).is_nothing == True
    assert Maybe.nothing().filter(lambda b: b).is_nothing == True
    assert Maybe.nothing().filter(lambda b: not b).is_nothing == True



# Generated at 2022-06-24 00:20:20.949069
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert Maybe.just(1).__eq__(Maybe.just("1")) is False
    assert Maybe.nothing().__eq__(Maybe.just("1")) is False


# Generated at 2022-06-24 00:20:23.629462
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just("foo").to_box() == Box("foo")
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:20:26.207037
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Make test for Maybe ap method.

    :returns: None
    """
    # arrange
    maybe_func = Maybe.just(lambda val: val + 1)
    maybe_val = Maybe.just(1)
    expected = Maybe.just(2)

    # act
    actual = maybe_func.ap(maybe_val)

    # assert
    assert expected == actual


# Generated at 2022-06-24 00:20:29.455455
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    from pymonet.either import Right
    from pymonet.either import Either

    assert Maybe.just(4).to_either() == Right(4)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.nothing().to_either() == Either.left(None)



# Generated at 2022-06-24 00:20:36.647916
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(None)


# Unit tests for method just of class Maybe

# Generated at 2022-06-24 00:20:43.244526
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_just = Maybe.just(0)
    maybe_nothing = Maybe.nothing()

    def mapper(x):
        return x + 1

    assert isinstance(maybe_just.map(mapper), Maybe)
    assert isinstance(maybe_nothing.map(mapper), Maybe)
    assert maybe_just.map(mapper) == Maybe.just(1)
    assert maybe_nothing.map(mapper) == Maybe.nothing()


# Generated at 2022-06-24 00:20:49.037441
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    def test_function():
        return Maybe.just(5)
    assert test_function().to_lazy() == Lazy(test_function)

# Generated at 2022-06-24 00:20:54.763527
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from .either import Either

    assert Maybe.just(lambda x: x+1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(lambda x: x+1).ap(Either.right(1)) == Either.right(2)
    assert Maybe.just(lambda x: x + 1).ap(Either.left(1)) == Either.right(None)



# Generated at 2022-06-24 00:20:56.290692
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(4).get_or_else(10) == 4
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-24 00:21:00.256013
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:21:03.827061
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # Arrange
    from pymonet.box import Box

    maybe = Maybe.just(5)

    # Act
    actual = maybe.to_box()

    # Assert
    assert actual == Box(5)


# Generated at 2022-06-24 00:21:09.265527
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x + 2).ap(Box(1)) == Maybe.just(3)
    assert Maybe.nothing().ap(Box(1)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:12.227093
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-24 00:21:14.556902
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:22.386371
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    :returns: True when test is successfully otherwise False
    :rtype: Boolean
    """
    from pymonet.maybe import Maybe
    from pymonet.mona import Monad

    maybe = Maybe.just('test')
    assert maybe.get_or_else(None) == 'test'
    maybe = Maybe.nothing()
    assert maybe.get_or_else(None) == None
    assert isinstance(maybe, Monad)
    return True


# Generated at 2022-06-24 00:21:25.942507
# Unit test for method map of class Maybe
def test_Maybe_map():
    result = Maybe.just(5).map(lambda x: x + 1)
    assert result == Maybe.just(6)
    result = Maybe.just(5).map(lambda x: x - 1)
    assert result == Maybe.just(4)


# Generated at 2022-06-24 00:21:29.435297
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()



# Generated at 2022-06-24 00:21:36.644773
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1).bind(
        lambda x: Maybe.just(2)
    ) == Maybe.nothing()
    assert Try.just(1).bind(
        lambda x: Maybe.just(x).filter(lambda x: x == 1)
    ) == Try.just(1)


# Generated at 2022-06-24 00:21:40.254940
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:21:44.269504
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x+1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x+1).map(lambda x: x+2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x+1) == Maybe.nothing()


# Generated at 2022-06-24 00:21:46.390769
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Tests
    assert_equal(Maybe.just(lambda x: x * 10).ap(Maybe.nothing()), Maybe.nothing())
    assert_equal(
        Maybe.just(lambda x: x * 10).ap(Maybe.just(1)),
        Maybe.just(10)
    )



# Generated at 2022-06-24 00:21:48.428308
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert (Maybe.just(1).bind(lambda x: Maybe.just(x + 1))) == Maybe.just(2)


# Generated at 2022-06-24 00:21:52.206047
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(7)
    assert Maybe.just(5) == Maybe.just(7) == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(5)


# Generated at 2022-06-24 00:22:00.660678
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    """

    def sum_two(number: int) -> int:
        """
        Sum two to given number and returns result.

        :param number: number to sum two
        :type number: int
        :returns: sum result
        :rtype: int
        """
        return number + 2

    assert Maybe.just(2).bind(sum_two) == Maybe.just(4)
    assert Maybe.nothing().bind(sum_two) == Maybe.nothing()



# Generated at 2022-06-24 00:22:06.843534
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else('A') == 'A'
    assert Maybe.just(1).get_or_else('A') == 1



# Generated at 2022-06-24 00:22:11.246392
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.just(2).get_or_else(1) == 2


# Generated at 2022-06-24 00:22:14.454732
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Perform unit tests for Maybe.to_validation().
    """
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:22:17.394567
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(False).filter(lambda v: v).is_nothing
    assert Maybe.just(True).filter(lambda v: v) == Maybe.just(True)


# Generated at 2022-06-24 00:22:23.125582
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe(1, False).to_try() == Try(1, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:22:25.025264
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(0) == 10
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-24 00:22:27.380425
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test Maybe.to_lazy
    """
    from pymonet.lazy import Lazy

    assert Maybe.just('test').to_lazy() == Lazy(lambda: 'test')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:22:33.756365
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(7).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(8)

    assert Maybe.just([1, 2, 3]).bind(lambda x: Maybe.just(x[0])) == Maybe.just(1)

    assert Maybe.just([1, 2, 3]).bind(lambda x: Maybe.just(x[1])) == Maybe.just(2)


# Generated at 2022-06-24 00:22:41.107568
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10

    assert Maybe.just(5).map(lambda x: x + 1) == Maybe.just(6)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-24 00:22:46.335156
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    f = lambda x: x > 0
    assert(maybe.filter(f) == Maybe.just(1))
    f = lambda x: x < 0
    assert(maybe.filter(f) == Maybe.nothing())



# Generated at 2022-06-24 00:22:51.836858
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_value = Maybe.just(42)
    assert isinstance(maybe_value, Maybe)
    assert maybe_value == Maybe.just(42)
    assert not isinstance(maybe_value, Maybe[None])
    assert isinstance(maybe_value, Maybe[int])

    maybe_empty = Maybe.nothing()
    assert isinstance(maybe_empty, Maybe)
    assert isinstance(maybe_empty, Maybe[None])
    assert isinstance(maybe_empty, Maybe[int])
    assert maybe_empty == Maybe.nothing()
    assert maybe_empty == Maybe.just(None)



# Generated at 2022-06-24 00:22:54.202964
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:22:59.343195
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    my_maybe1 = Maybe.just(4)
    assert my_maybe1.filter(lambda a: a >= 5) == Maybe.nothing()

    my_maybe2 = Maybe.just(4)
    assert my_maybe2.filter(lambda a: a < 5) == Maybe.just(4)

    my_maybe3 = Maybe.nothing()
    assert my_maybe3.filter(lambda a: a == 5) == Maybe.nothing()



# Generated at 2022-06-24 00:23:05.272683
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    just_maybe = Maybe.just('just')
    nothing_maybe = Maybe.nothing()
    assert just_maybe.get_or_else('nothing') == 'just'
    assert nothing_maybe.get_or_else('nothing') == 'nothing'



# Generated at 2022-06-24 00:23:07.585696
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(3)) == Maybe.just(4)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:23:10.306350
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    box_with_value: Box[int] = Maybe.just(10).to_box()
    assert box_with_value.value == 10
    box_with_none: Box[None] = Maybe.nothing().to_box()
    assert box_with_none.value is None


# Generated at 2022-06-24 00:23:12.178862
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v % 2 == 0).get_or_else(0) == 0
    assert Maybe.just(2).filter(lambda v: v % 2 == 0).get_or_else(0) == 2


# Generated at 2022-06-24 00:23:17.836317
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe_just_to_try = Maybe.just(5).to_try()
    maybe_nothing_to_try = Maybe.nothing().to_try()

    assert isinstance(maybe_just_to_try, Try)
    assert maybe_just_to_try.is_success
    assert maybe_just_to_try.value == 5

    assert isinstance(maybe_nothing_to_try, Try)
    assert not maybe_nothing_to_try.is_success
    assert maybe_nothing_to_try.value is None



# Generated at 2022-06-24 00:23:21.286276
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(10, False).filter(lambda x: x % 2 == 0) == Maybe(10, False)
    assert Maybe(10, False).filter(lambda x: x % 2 == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:23:24.217713
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Unit test for method get_or_else of class Maybe.
    """
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just(1).get_or_else(0) == 1


# Generated at 2022-06-24 00:23:27.598694
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:23:37.201364
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test that bind function works as expected.
    """

    from pymonet.functor.functor import Functor

    class MyFunctor(Functor):
        @classmethod
        def fmap(cls, mapper: Callable[[int], int], value: int) -> 'Maybe[int]':
            if value % 2 == 0:
                return Maybe.just(mapper(value))
            return Maybe.nothing()

    assert Maybe.just(4).bind(lambda v: MyFunctor.fmap(lambda x: x * 2, v)) == Maybe.just(8)
    assert Maybe.just(5).bind(lambda v: MyFunctor.fmap(lambda x: x * 2, v)) == Maybe.nothing()


# Generated at 2022-06-24 00:23:41.896182
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(20) == Maybe.just(20)
    assert Maybe.just(20) != Maybe.just(30)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(20) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(20)


# Generated at 2022-06-24 00:23:44.359102
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(7).to_either() == Right(7)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:49.793505
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """__eq__ method should returns [True] if self and other are equal
    self and other must be equal for all of the follows:
    * self.is_nothing == other.is_nothing
    * self.value == other.value
    * self.is_nothing == True or self.value == other.value
    else [False]
    """
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(0) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(0) != Maybe.nothing()
    assert Maybe.just(0) == Maybe(0, False)


# Generated at 2022-06-24 00:23:50.953409
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    box = Box('test')
    value = box.to_maybe()

    assert box == value.to_box()

# Generated at 2022-06-24 00:23:53.903310
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(5)
    assert 6 == maybe.map(
        lambda value: value + 1
    ).to_box().map(
        lambda value: value + 1
    ).get()



# Generated at 2022-06-24 00:24:01.566785
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy, LazyValueError

    def raise_error():
        return 1 / 0

    lazy_func = Maybe.just(lambda: 1 / 0)

    assert lazy_func.to_lazy().take_now() == Lazy(lambda: 1 / 0).take_now()
    try:
        lazy_func.to_lazy().take_now()()
    except LazyValueError as e:
        assert isinstance(e, LazyValueError)
    else:
        assert False

# Generated at 2022-06-24 00:24:04.264864
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(4).get_or_else(5) == 4)
    assert(Maybe.nothing().get_or_else(5) == 5)


# Generated at 2022-06-24 00:24:09.414005
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.monad import Monad

    assert Maybe.just(23).to_validation() == Validation.success(23)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Monad(Maybe.just(23)).to_validation() == Validation.success(23)
    assert Monad(Maybe.nothing()).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:15.376361
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(100).to_try() == Try(100, is_success=True)
    assert Maybe.just(100).to_try().map(lambda x: x * 3) == Try(300, is_success=True)
    assert Maybe.just(100).to_try().get_or_else(0) == 100
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.nothing().to_try().map(lambda x: x * 3) == Try(None, is_success=False)
    assert Maybe.nothing().to_try().get_or_else(0) == 0


# Generated at 2022-06-24 00:24:18.484504
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * x) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()


# Generated at 2022-06-24 00:24:29.310972
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_int_1 = Maybe(1, False)
    maybe_int_2 = Maybe(2, False)
    maybe_int_3 = Maybe(1, False)
    maybe_float_1 = Maybe(1.0, False)
    maybe_float_2 = Maybe(2.0, False)
    maybe_float_3 = Maybe(1.0, False)
    maybe_nothing = Maybe.nothing()
    maybe_nothing_1 = Maybe.nothing()

    assert maybe_int_1 == maybe_int_1
    assert maybe_int_2 == maybe_int_2
    assert maybe_int_3 == maybe_int_3
    assert maybe_float_1 == maybe_float_1
    assert maybe_float_2 == maybe_float_2
    assert maybe_float_3 == maybe_float_3
    assert maybe

# Generated at 2022-06-24 00:24:32.341753
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:24:35.250137
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(None) == 42
    assert Maybe.just(None).get_or_else(42) == None
    assert Maybe.nothing().get_or_else(42) == 42



# Generated at 2022-06-24 00:24:40.859956
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    monad = Maybe(1, False)
    assert monad.to_try() == Try(1, is_success=True)

    monad = Maybe.nothing()
    assert monad.to_try() == Try(None, is_success=False)

    monad = Maybe(Lazy(lambda: 1), False)
    assert monad.to_try() == Try(1, is_success=True)

    monad = Maybe(Lazy(lambda: 1/0), False)
    assert monad.to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:43.232867
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try().value == 5
    assert Maybe.nothing().to_try().is_success == False

if __name__ == '__main__':
    test_Maybe_to_try()

# Generated at 2022-06-24 00:24:45.375635
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:24:50.422371
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    maybe_some_try = Try(lambda: 5, is_success=True)

    assert isinstance(maybe_some_try, Try)
    assert maybe_some_try.is_success

    maybe_none_try = Try(lambda: 5 / 0, is_success=True)

    assert isinstance(maybe_none_try, Try)
    assert not maybe_none_try.is_success



# Generated at 2022-06-24 00:24:54.337275
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(6).map(lambda x: x * 7) \
           == Maybe.just(42)
    assert Maybe.nothing().map(lambda x: x * 7) \
           == Maybe.nothing()



# Generated at 2022-06-24 00:24:56.608226
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-24 00:24:57.884890
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x+1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x+1) == Maybe.nothing()


# Generated at 2022-06-24 00:25:00.726894
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    import pytest
    # Case 1: value is empty
    result = Maybe.nothing().to_validation()
    expected = Validation.success(None)
    assert result == expected


# Generated at 2022-06-24 00:25:08.754435
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test method to_lazy of class Maybe.

    :returns: True if test passed, else raise AssertionError
    :rtype: bool
    """
    from pymonet.lazy import Lazy

    def f():
        return 42

    m = Maybe.just(f)
    assert m.to_lazy() == Lazy(f)

    m = Maybe.nothing()
    assert m.to_lazy() == Lazy(lambda: None)

    return True

# Generated at 2022-06-24 00:25:11.470587
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.nothing() == Maybe(None, True)


# Unit tests for method bind for not empty Maybe

# Generated at 2022-06-24 00:25:17.458303
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
# Test end


# Generated at 2022-06-24 00:25:19.238713
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(5, False)
    assert isinstance(m, Maybe)


# Generated at 2022-06-24 00:25:24.391551
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(10).to_lazy() == \
        Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == \
        Lazy(lambda: None)


# Generated at 2022-06-24 00:25:27.688454
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert maybe.get_or_else(2) == 1
    maybe = Maybe.nothing()
    assert maybe.get_or_else(2) == 2


# Generated at 2022-06-24 00:25:35.445466
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right

    # Test 1:
    right1 = Maybe.just(1).to_either()
    right2 = Maybe.just(2).to_either()
    assert right1 == right2

    # Test 2:
    right1 = Maybe.just(1).to_either()
    right2 = Right(2)
    assert right1 != right2

    # Test 3:
    right1 = Maybe.nothing().to_either()
    right2 = Right(None)
    assert right1 == right2

    # Test 4:
    right1 = Maybe.nothing().to_either()
    right2 = Maybe.just(4).to_either()
    assert right1 != right2



# Generated at 2022-06-24 00:25:37.922834
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2), "Maybe.ap()"
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:25:42.224718
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x <= 10) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x <= 10) == Maybe.nothing()


# Generated at 2022-06-24 00:25:52.044226
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    value, default_value = 1, 2

    def fail_mapper(value):
        return value / 0

    def success_mapper(value):
        return value + 1

    assert Maybe(value, False).to_try() == Try(value, True)
    assert Maybe(None, True).to_try() == Try(None, False)
    assert Maybe(value, False).map(success_mapper).to_try() == Try(value + 1, True)
    assert Maybe(value, False).map(fail_mapper).to_try() == Try(None, False)
    assert Maybe(None, True).map(fail_mapper).to_try() == Try(None, False)
    assert Maybe(value, False).map(fail_mapper).get_or_else

# Generated at 2022-06-24 00:25:55.056959
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:56.771632
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:26:01.237460
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0



# Generated at 2022-06-24 00:26:11.259593
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind.

    :returns: 'Test for bind method of Maybe class has been passed.' as string
    :rtype: String
    """
    from random import randint

    def multiply(value):
        return value * 2

    def divide(value):
        return value / 2

    def divide_and_multiply(value):
        return Maybe.just(value).map(divide).map(multiply)

    assert Maybe.just(
        (Maybe.just(
            randint(0, 10)).bind(divide_and_multiply))
    ).get_or_else(None) == randint(0, 10)

    return 'Test for bind method of Maybe class has been passed.'

# Generated at 2022-06-24 00:26:12.042751
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(42).map(lambda x: x + 1) == Maybe.just(43)



# Generated at 2022-06-24 00:26:14.617810
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:26:23.827106
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    f = lambda x: x + 1
    m = lambda x: x - 1

    # ap over Box
    assert Maybe.just(f).ap(Box(8)) == Box(9)
    assert Maybe.nothing().ap(Box(8)) == Box(None)

    # ap over Either
    assert Maybe.just(f).ap(Right(8)) == Right(9)
    assert Maybe.just(f).ap(Left(8)) == Left(8)

    # ap over Try

# Generated at 2022-06-24 00:26:26.902396
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:26:31.421520
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(2).to_try() == Try(2, is_success=True)
    assert Maybe.just(1).to_try() != Try(2, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:26:35.187335
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(5).to_try() == Try(5, is_success=True)


# Generated at 2022-06-24 00:26:40.494795
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Test for not empty maybe
    maybe_lazy = Maybe.just(1).to_lazy()
    assert isinstance(maybe_lazy, Lazy)
    assert maybe_lazy.value() == Maybe.just(1).value

    # Test for empty maybe
    maybe_lazy = Maybe.nothing().to_lazy()
    assert isinstance(maybe_lazy, Lazy)
    assert maybe_lazy.value() is Maybe.nothing().value



# Generated at 2022-06-24 00:26:43.194755
# Unit test for method map of class Maybe
def test_Maybe_map():
    """ Unit test for method map of class Maybe """

    # Test map when Maybe is empty
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe.nothing()

    # Test map when Maybe is not empty
    assert Maybe(10, False).map(lambda x: x + 1) == Maybe.just(11)


# Generated at 2022-06-24 00:26:45.417708
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe(1, False).filter(lambda x: x > 1) == Maybe.nothing()

# Generated at 2022-06-24 00:26:47.786256
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:55.199236
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(6) != Maybe.just(9)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:27:01.979003
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_list import List
    from pymonet.monad_list import _concat

    maybe_list = Maybe.just(List([1, 2, 3, 4]))
    maybe_list2 = Maybe.just(List([5, 6, 7, 8]))

    assert maybe_list.ap(maybe_list2) == Maybe.just(
        List.of(1, 2, 3, 4).ap(List.of(5, 6, 7, 8))
    )
    assert maybe_list.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(maybe_list2) == Maybe.nothing()



# Generated at 2022-06-24 00:27:05.549565
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:27:08.327669
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box.unit(None)
    assert Maybe.just(1).to_box().is_instance(Box)


# Generated at 2022-06-24 00:27:11.754775
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(4, False).to_box() == Box(4)
    assert Maybe(None, True).to_box() == Box(None)



# Generated at 2022-06-24 00:27:14.727932
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """

    :return: void
    :rtype: None
    """
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:27:21.731578
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x % 2) == Maybe.just(4)
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()

    from pymonet.box import Box

    assert Maybe.just(4).filter(lambda _: True).to_box() == Box(4)



# Generated at 2022-06-24 00:27:25.089386
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:27:28.980572
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    success = True
    success = success and Maybe.just(1) == Maybe.just(1)
    success = success and Maybe.nothing() == Maybe.nothing()
    assert success, 'test Maybe__eq__() failed'



# Generated at 2022-06-24 00:27:32.897837
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:27:37.849311
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:27:39.638456
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(3).to_box() == Box(3)



# Generated at 2022-06-24 00:27:42.760981
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(12).to_try() == Try(12, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:27:49.828880
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor
    from pymonet.maybe import Maybe

    m1 = Maybe.just(lambda x: x + 10).map(Functor)
    m2 = Maybe.just(6)
    assert m1.ap(m2) == Maybe.just(16)

    m1 = Maybe.just(lambda x: x + 10).map(Functor)
    m2 = Maybe.nothing()
    assert m1.ap(m2) == Maybe.nothing()

    m1 = Maybe.nothing().map(Functor)
    m2 = Maybe.just(6)
    assert m1.ap(m2) == Maybe.nothing()

    m1 = Maybe.nothing().map(Functor)
    m2 = Maybe.nothing()
    assert m1.ap(m2) == Maybe.nothing()



# Generated at 2022-06-24 00:27:53.660370
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-24 00:27:57.491310
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(32).to_lazy() == Lazy(lambda: 32)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:28:03.423275
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(9)
    assert m.filter(lambda x: x % 3 == 0) == Maybe.just(9)
    m = Maybe.just(10)
    assert m.filter(lambda x: x % 3 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-24 00:28:09.756603
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Tests for method get_or_else of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    m = Maybe(10, False)
    assert(m.get_or_else(0) == 10)
    m = Maybe(None, True)
    assert(m.get_or_else(0) == 0)



# Generated at 2022-06-24 00:28:14.230406
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:28:25.364231
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    for val in range(2):
        for is_success in range(2):
            for is_postive in range(2):
                if is_postive == 1:
                    value = val
                else:
                    value = val - 1
                func = lambda x: x if x >= 0 else None
                if is_success == 0:
                    maybe = Maybe.nothing()
                    try_ = Try(value, is_success=False)
                    validation = Validation.failure(value)
                else:
                    maybe = Maybe.just(value)
                    try_ = Try(value, is_success=True)
                    if value >= 0:
                        validation = Validation.success(value)
                   

# Generated at 2022-06-24 00:28:27.375031
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.typed_monad import filter_test_impl
    filter_test_impl(Maybe)

# Generated at 2022-06-24 00:28:33.916701
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.just(Box(2)).to_either() == Right(Box(2))


# Generated at 2022-06-24 00:28:36.314057
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy().force() == 2
    assert Maybe.nothing().to_lazy().force() is None


# Generated at 2022-06-24 00:28:40.406245
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(-1) == 10
    assert Maybe.nothing().get_or_else(-1) == -1


# Generated at 2022-06-24 00:28:43.178563
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    a = Maybe.just(1)
    assert a.get_or_else(2) == 1

    b = Maybe.nothing()
    assert b.get_or_else(2) == 2


# Generated at 2022-06-24 00:28:45.749574
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)

