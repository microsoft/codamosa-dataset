

# Generated at 2022-06-24 00:18:46.857714
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(100) == Maybe(100, False)

# Generated at 2022-06-24 00:18:51.212109
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    x = Lazy(lambda: 5)
    x = Maybe.just(x).to_lazy()
    assert x.is_lazy
    assert x.value() == 5

    x = Lazy(lambda: None)
    x = Maybe.nothing().to_lazy()
    assert x.is_lazy
    assert x.value() is None


# Generated at 2022-06-24 00:18:53.832020
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:18:56.637493
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda n: n + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda n: n + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:18:58.793500
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():

    assert Maybe.just(5).get_or_else(None) == 5
    assert Maybe.nothing().get_or_else(None) == None


# Generated at 2022-06-24 00:19:03.363634
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.maybe import Maybe as m

    def func(x):
        return x + 2

    def bind_func(x):
        return m.just(func(x))

    assert m.just(4).bind(bind_func) == m.just(6), "m.just(4).bind(bind_func) == m.just(6)"
    assert m.nothing().bind(bind_func) == m.nothing(), "m.nothing().bind(bind_func) == m.nothing()"



# Generated at 2022-06-24 00:19:06.586425
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:19:11.770771
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    from pymonet.monad_lazy import MonadLazy
    from pymonet.monad_control import MonadMaybe
    from pymonet.monad_failure import MonadMaybeFailure

    assert isinstance(Maybe('1', False), MonadMaybeFailure)
    assert isinstance(Maybe('1', False), MonadMaybe)
    assert isinstance(Maybe('1', False), MonadLazy)
    assert isinstance(Maybe('1', False), Monad)
    assert isinstance(Maybe('1', False), Applicative)
    assert isinstance(Maybe('1', False), Functor)
    assert isinstance(Maybe('1', False), object)


# Unit test

# Generated at 2022-06-24 00:19:17.029395
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    def plus(x, y):
        return x + y

    maybe: Maybe[Callable[[int, int], int]] = Maybe.just(plus)
    assert maybe.map(lambda x: x(5, 7)) == Maybe.just(12)
    assert maybe.ap(Maybe.just(5)) == Maybe.just(5)
    assert maybe.ap(Maybe.just(7)) == Maybe.just(7)

# Generated at 2022-06-24 00:19:23.829501
# Unit test for constructor of class Maybe
def test_Maybe():
    # Check None value
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)

    # Check some values
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.just(1) == Maybe(1, False)

    assert Maybe('text', False) == Maybe.just('text')
    assert Maybe.just('text') == Maybe('text', False)

    assert Maybe(lambda x: x, False) == Maybe.just(lambda x: x)
    assert Maybe.just(lambda x: x) == Maybe(lambda x: x, False)



# Generated at 2022-06-24 00:19:27.018325
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(5, False).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:19:30.218300
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    m = Maybe.just('a')
    assert m.get_or_else('b') == 'a'

    m = Maybe.nothing()
    assert m.get_or_else('b') == 'b'



# Generated at 2022-06-24 00:19:34.787226
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    m = Maybe.just(1)
    assert m.to_box().value == 1

    m = Maybe.nothing()
    assert m.to_box().value is None


# Generated at 2022-06-24 00:19:43.377457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Empty Maybe:
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    # Not empty Maybe:
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)

    assert Maybe.just(False).filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just([1, 2, 3, 4]).filter(lambda x: len(x) > 2) == Maybe.nothing()
    assert Maybe.just((1, 2, 3, 4)).filter(lambda x: len(x) > 2) == Maybe.nothing()
    assert Maybe.just("test-string").filter(lambda x: len(x) > 4) == Maybe.nothing()



# Generated at 2022-06-24 00:19:47.422581
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:19:54.358368
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    _maybe = Maybe.just(2)
    _box = _maybe.to_box()
    _box_maybe = Maybe.just(Box(2))
    _box_nothing = Maybe.just(Box(None))
    _nothing = Maybe.nothing()
    _nothing_box = Maybe.just(Box(None))
    assert _box == Box(2)
    assert _nothing_box == _box_maybe
    assert _nothing == _nothing_box
    assert _nothing.to_box() == _box_nothing


# Generated at 2022-06-24 00:19:56.808405
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(None) == 5
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:20:02.659280
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from .test_helper import get_old_Maybe
    from .test_helper import maybe_filter_test

    maybe_filter_test(
        Map=Maybe,
        get_old_Maybe=get_old_Maybe,
        get_new_Maybe=Maybe.just,
        get_nothing=Maybe.nothing()
    )

# Generated at 2022-06-24 00:20:04.929181
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(5).to_validation() == 5
    assert Maybe.nothing().to_validation() is None


# Generated at 2022-06-24 00:20:07.315848
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(None, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)


# Generated at 2022-06-24 00:20:11.091905
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # GIVEN
    maybe = Maybe.just(1)

    # THEN
    maybe_boxed = maybe.to_box()

    # WHEN
    assert maybe.is_nothing == maybe_boxed.is_nothing
    assert maybe.value == maybe_boxed.value

# Generated at 2022-06-24 00:20:13.896699
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(None, True).to_box() == Box(None)
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe("hello", False).to_box() == Box("hello")



# Generated at 2022-06-24 00:20:16.388994
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, False)
    assert Maybe.just(1).to_try() == Try(1, True)


# Generated at 2022-06-24 00:20:24.533300
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test Maybe.to_try() method.

    :return: nothing
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Maybe(None, True).to_try() == Try(None, is_success=False)
    assert Maybe(123, False).to_try() == Try(123, is_success=True)

# Generated at 2022-06-24 00:20:30.052706
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just("abc") == Maybe.just("abc")
    assert Maybe.just("abc") != Maybe.nothing()
    assert Maybe.nothing().is_nothing
    assert Maybe.just("test").value == "test"
    assert Maybe.nothing().value == None



# Generated at 2022-06-24 00:20:31.981333
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:20:36.818050
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe[int](0, False).bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe[int](0, False).bind(lambda v: Maybe.just(v + 1)) == Maybe.just(1)
    assert Maybe.nothing().bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda v: Maybe.just(v + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:20:39.236044
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:20:41.917879
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(True).map(lambda x: not x) == Maybe.just(False)
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-24 00:20:43.990825
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:20:46.490691
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(1, True).to_try() == Try(None, False)


# Generated at 2022-06-24 00:20:49.370133
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad_test_helpers import assert_validation, assert_not_validation

    assert_validation(
        monad)
    assert_not_validation(
        Maybe.nothing())


# Generated at 2022-06-24 00:20:51.137668
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:20:55.362074
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1).__eq__(Maybe.just(1)) is True
    assert Maybe.just(1).__eq__(Maybe.just(2)) is False
    assert Maybe.nothing().__eq__(Maybe.nothing()) is True
    assert Maybe.just(1).__eq__(Maybe.nothing()) is False
    assert Maybe.nothing().__eq__(Maybe.just(1)) is False
    assert Maybe.just(1).__eq__(1) is False


# Generated at 2022-06-24 00:21:03.400548
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test for method bind.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_either import Left, Right
    from pymonet.monad_try import Try

    def transformer(x):
        """
        Transformer function

        :param x: value to transform
        :type x: int
        :returns: Left with x or Right with x
        :rtype: Either[int]
        """
        if x % 2 == 0:
            return Left(x)
        return Right(x)

    mapper = lambda y: Maybe.just(y + 1)
    assert Maybe.just(2).bind(mapper) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x + 3) == Maybe.just(5)

# Generated at 2022-06-24 00:21:06.303206
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(True)
    assert Maybe.just(False).get_or_else(True) == False


# Generated at 2022-06-24 00:21:12.006784
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.box import Box

    assert Maybe.just(1).bind(lambda x: Box(x)) == Box(1)
    assert Maybe.just(1).bind(lambda x: Box(x)) == Box(1)
    assert Maybe.nothing().bind(lambda x: Box(x)) == Box(None)
    assert Maybe.just(1).bind(lambda x: Box(x)).bind(lambda x: Box(x)) == Box(1)


# Generated at 2022-06-24 00:21:14.888640
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test constructor of class Maybe.
    """
    assert Maybe.just('test')
    assert Maybe.nothing()
    assert Maybe.just('test') != Maybe.nothing()
    assert Maybe.just('test') == Maybe.just('test')


# Generated at 2022-06-24 00:21:22.038245
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit test for constructor of class Maybe.

    :returns: True if test passed, else False
    :rtype: Boolean
    """
    return Maybe.just(1) == Maybe.just(1) and not Maybe.just(1) == Maybe.just(2) \
        and Maybe.nothing() == Maybe.nothing() \
        and Maybe.just(1).to_box().value == 1


# Generated at 2022-06-24 00:21:25.522503
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(None, True) == Maybe(None, True)

    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(None, True) != Maybe(None, False)

    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(None, True) != Maybe(None, False)

    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(None, True) != Maybe(None, False)


# Generated at 2022-06-24 00:21:29.384195
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:21:31.611576
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == \
           Maybe.nothing().to_either() == Right(1) == Left(None)

# Generated at 2022-06-24 00:21:34.608205
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(4).to_try() == Try(4, True)
    assert Try.empty().to_maybe().to_try() == Try(None, False)


# Generated at 2022-06-24 00:21:40.515332
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() is Try(None, is_success=False)
    assert Maybe.just(1).to_try() is Try(1, is_success=True)


# Generated at 2022-06-24 00:21:43.834415
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(4).to_try() == Try(4, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:21:46.009554
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test to_box method of Maybe.
    """
    from pymonet.box import Box

    assert Maybe(10, False).to_box() == Box(10)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:21:49.098313
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:52.164952
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:21:58.027337
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Not(Maybe.nothing() == Maybe.just(1))
    assert Maybe.just(1) == Maybe.just(1)
    assert Not(Maybe.just(None) == Maybe.just(1))
    assert Not(Maybe.just(1) == None)



# Generated at 2022-06-24 00:22:01.146196
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either().right is True
    assert Maybe.just(1).to_either().value == 1
    assert Maybe.nothing().to_either().left is True


# Generated at 2022-06-24 00:22:06.884373
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('value').get_or_else('another value') == 'value'
    assert Maybe.nothing().get_or_else('value') == 'value'

# Generated at 2022-06-24 00:22:08.550852
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():

    from pymonet.monad_try import Try

    maybe = Maybe.just('foo')
    assert maybe.to_try() == Try('foo', True)

    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, False)


# Generated at 2022-06-24 00:22:13.936608
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_3(x):
        return x+3

    assert Maybe.just(add_3).ap(Maybe.just(2)) == Maybe.just(5)

    assert Maybe.just(add_3).ap(Maybe.nothing()) == Maybe.nothing()

    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()



# Generated at 2022-06-24 00:22:16.126410
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(2, False).to_lazy() == Lazy(lambda: 2)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:22:19.920211
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(2).ap(Maybe.just(lambda x: x**2)) == Maybe.just(4)
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(2).ap(Maybe.nothing()).is_nothing == True



# Generated at 2022-06-24 00:22:26.968175
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try

    def mapper(value):
        if value == 1:
            return Try.success(3)
        return Try.failure(None)

    assert Maybe.just(1).bind(mapper).is_success
    assert Maybe.just(2).bind(mapper).is_failure
    assert Maybe.nothing().bind(mapper).is_failure


# Generated at 2022-06-24 00:22:32.969038
# Unit test for method map of class Maybe
def test_Maybe_map():
    def double(arg: int) -> int:
        return arg * 2

    assert Maybe.just(5).map(double) == Maybe.just(10)
    assert Maybe.just(5).map(None) == Maybe.nothing()
    assert Maybe.nothing().map(None) == Maybe.nothing()



# Generated at 2022-06-24 00:22:35.427857
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(None, True).to_validation() == Validation.success(None)
    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(True, False).to_validation() == Validation.success(True)

# Generated at 2022-06-24 00:22:40.034361
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(1)
    assert m.filter(lambda v: v == 0) == Maybe.nothing()
    assert m.filter(lambda v: v == 1) == Maybe.just(1)
    assert m.filter(lambda v: v > 1) == Maybe.nothing()


# Generated at 2022-06-24 00:22:45.186257
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1) != Maybe(1, True)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe(1, True)

# Generated at 2022-06-24 00:22:49.299182
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Box(2)) == Maybe.just(3)


# Generated at 2022-06-24 00:22:52.780597
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative

    assert Maybe.just(lambda x: x + 1).ap(Applicative.pure(4)) == \
        Maybe.just(4).map(lambda x: x + 1)

# Generated at 2022-06-24 00:22:57.194098
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert(Maybe.just(1).to_validation() == Validation.success(1))
    assert(Maybe.just(None).to_validation() == Validation.success(None))
    assert(Maybe.nothing().to_validation() == Validation.success(None))


# Generated at 2022-06-24 00:23:00.534963
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(5)
    assert Maybe.just(4) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)



# Generated at 2022-06-24 00:23:05.899215
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # 1. Test for not empty maybe
    from pymonet.lazy import Lazy

    maybe = Maybe.just(2)
    lazy = maybe.to_lazy()

    # We expect to have Lazy instance
    assert isinstance(lazy, Lazy)
    # And value inside to be 2
    assert lazy.value() == 2

    # 2. Test for empty maybe
    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()

    # We expect to have Lazy instance
    assert isinstance(lazy, Lazy)
    # And value inside to be None
    assert lazy.value() is None


# Generated at 2022-06-24 00:23:10.110870
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:23:17.505200
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    validation = Maybe.just(5).to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value == 5

    validation = Maybe.nothing().to_validation()
    assert isinstance(validation, Validation)
    assert validation.is_success
    assert validation.value is None

# Generated at 2022-06-24 00:23:21.187919
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    r = Maybe.nothing().get_or_else(1)

    assert r == 1, 'test_Maybe test_get_or_else fail'
    print('test_Maybe_get_or_else ok')


# Generated at 2022-06-24 00:23:25.199512
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-24 00:23:26.904096
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(3).to_either() == Right(3)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:23:32.524513
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe. Expected result is result of mapper function.

    :returns: None
    :rtype: None
    """
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 1)) == \
           Maybe.just(3)

    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == \
           Maybe.nothing()



# Generated at 2022-06-24 00:23:36.164590
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.failure(None) == Maybe.nothing().to_validation()
    assert Validation.success(1) == Maybe.just(1).to_validation()


# Generated at 2022-06-24 00:23:45.567355
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.just(1)
    assert isinstance(maybe, Maybe)
    assert isinstance(maybe.map(lambda x: x + 2), Maybe)
    assert maybe.map(lambda x: x + 2).value == 3
    assert isinstance(maybe.map(lambda x: x + 2).map(lambda y: y + 5), Maybe)
    assert maybe.map(lambda x: x + 2).map(lambda y: y + 5).value == 8
    assert Maybe.nothing().map(lambda x: x + 2).is_nothing
    maybe = Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x + 2).is_nothing
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()

# Generated at 2022-06-24 00:23:52.265493
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test method to_try of class Maybe.

    :return: dict with information about method to_try of class Maybe
    """
    from pymonet.monad_try import Try

    assert Maybe.just(3).to_try() == Try(3)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    return {"status": 1}



# Generated at 2022-06-24 00:23:59.284753
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    print("testing method to_try of class Maybe")

    test_case1 = Maybe.nothing().to_try()
    assert isinstance(test_case1, Try)
    assert test_case1 == Try(None, False)

    test_case2 = Maybe.just("result").to_try()
    assert isinstance(test_case2, Try)
    assert test_case2 == Try("result", True)

    print("method to_try passed all tests\n")


# Generated at 2022-06-24 00:24:04.400864
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:24:13.941567
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def ap_test(first, second):
        return lambda x: second(first(x))

    assert(
        Maybe.just(lambda x: x).ap(
            Maybe.just(lambda x: x + 3)
        ) == Maybe.just(ap_test(
            lambda x: x,
            lambda x: x + 3
        )(1))
    )
    assert(
        Maybe.nothing().ap(
            Maybe.just(lambda x: x + 3)
        ) == Maybe.nothing()
    )
    assert(
        Maybe.just(lambda x: x).ap(
            Maybe.nothing()
        ) == Maybe.nothing()
    )

# Generated at 2022-06-24 00:24:17.118050
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    # Example 1
    res1 = Maybe.just(lambda x: x + 1).ap(Maybe.just(1))

    assert res1 == Maybe.just(2)

    # Example 2
    res2 = Maybe.nothing().ap(Maybe.just(1))

    assert res2 == Maybe.nothing()


if __name__ == '__main__':
    test_Maybe_ap()

# Generated at 2022-06-24 00:24:20.580509
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:24:26.001492
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    value = 25

    result = Just(plus_five).ap(Just(value))
    assert result == Just(30)

    result = Just(plus_five).ap(Nothing())
    assert result == Nothing()

    result = Nothing().ap(Just(value))
    assert result == Nothing()

    result = Nothing().ap(Nothing())
    assert result == Nothing()



# Generated at 2022-06-24 00:24:28.842749
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just('value').to_validation() == Validation.success('value')

# Generated at 2022-06-24 00:24:33.903993
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    def test_function_1():
        return Maybe.just(1).to_validation() == Validation.success(1)

    def test_function_2():
        return Maybe.nothing().to_validation() == Validation.success(None)

    assert test_function_1()
    assert test_function_2()

# Generated at 2022-06-24 00:24:37.766911
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:24:41.282613
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:24:44.683146
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:24:49.730507
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(123).to_validation() == Validation.success(123)
    assert Maybe.just("test").to_validation() == Validation.success("test")


# Generated at 2022-06-24 00:24:52.036197
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:24:57.700261
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1).__eq__(1) == False
    assert Maybe.just(1).value == 1
    assert Maybe.just(1).is_nothing == False
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().value == None
    assert Maybe.nothing().is_nothing == True

test_Maybe()


# Generated at 2022-06-24 00:25:01.206661
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x != 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x == 0) == Maybe.just(0)
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:25:04.756113
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(7).to_box() == Box(7)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:25:10.060419
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import unit

    assert(
        unit(4).bind(lambda a: unit(5).bind(lambda b: unit(6))).to_lazy() ==
        Lazy(lambda: 4).bind(lambda a: Lazy(lambda: 5).bind(lambda b: Lazy(lambda: 6)))
    )



# Generated at 2022-06-24 00:25:13.263925
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from random import randint

    maybe_value = Maybe.just(randint(0, 10))
    lazy_value = maybe_value.to_lazy()
    assert maybe_value == Maybe.just(lazy_value.evaluate())

# Generated at 2022-06-24 00:25:16.897014
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:25:19.637437
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either

    assert Maybe.just(42).to_either() == Either(42)
    assert Maybe.nothing().to_either() == Either(None)



# Generated at 2022-06-24 00:25:24.088131
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:30.049812
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    def run(value=None, expected=None):
        result = Maybe.just(value).to_validation()
        if expected != result:
            raise ValueError(f'Maybe.just({value}).to_validation() is equal to {result} instead of {expected}')

    run(1, Validation.success(1))
    run('test', Validation.success('test'))
    run(None, Validation.success(None))


# Generated at 2022-06-24 00:25:36.010174
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:25:44.694330
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either().__eq__(Right(1))
    assert Maybe.just(1000).to_either().__eq__(Right(1000))
    assert Maybe.just(None).to_either().__eq__(Right(None))
    assert Maybe.just("test").to_either().__eq__(Right("test"))
    assert Maybe.just(True).to_either().__eq__(Right(True))
    assert Maybe.just([]).to_either().__eq__(Right([]))
    assert Maybe.just({}).to_either().__eq__(Right({}))
    assert Maybe.just({'test': 1}).to_either().__eq__(Right({'test': 1}))
    assert Maybe.nothing().to_either().__

# Generated at 2022-06-24 00:25:49.046750
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    maybe_value = Maybe.just(5)
    expected_result = Lazy(lambda: maybe_value.value)

    # Act
    actual_result = maybe_value.to_lazy()

    # Assert
    assert actual_result == expected_result



# Generated at 2022-06-24 00:25:58.918561
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test of bind

    :returns: None
    """
    import unittest

    class TestBindMethod(unittest.TestCase):
        def test_when_empty_Then_return_empty_maybe(self):
            mapper = lambda x: Maybe.just(x)
            maybe = Maybe.nothing()
            self.assertEqual(
                maybe.bind(mapper),
                Maybe.nothing()
            )

        def test_when_not_empty_Then_call_function_with_previous_value_and_return_result(self):
            mapper = lambda x: Maybe.just(x + 1)
            maybe = Maybe.just(2)
            self.assertEqual(
                maybe.bind(mapper),
                Maybe.just(3)
            )


# Generated at 2022-06-24 00:26:01.452554
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('foo') == Maybe('foo', False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:04.610472
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just("a1").to_box() == Box("a1")
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:26:14.654849
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def filterer_function(value):
        return value > 10

    maybe1 = Maybe.just(30)
    maybe2 = Maybe.just(5)
    maybe3 = Maybe.nothing()
    maybe_unit_test_result1 = maybe1.filter(filterer_function)
    maybe_unit_test_result2 = maybe2.filter(filterer_function)
    maybe_unit_test_result3 = maybe3.filter(filterer_function)
    assert isinstance(maybe_unit_test_result1, Maybe)
    assert isinstance(maybe_unit_test_result2, Maybe)
    assert isinstance(maybe_unit_test_result3, Maybe)

# Generated at 2022-06-24 00:26:18.615827
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(4).to_validation() == Validation.success(4)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:26:21.795330
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) != None
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()



# Generated at 2022-06-24 00:26:24.187848
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    mapper = lambda x: x * 2
    assert Maybe.nothing().ap(Maybe.just(mapper)).is_nothing
    assert Maybe.just(mapper).ap(Maybe.nothing()).is_nothing
    assert Maybe.just(mapper).ap(Maybe.just(3)).value == 6



# Generated at 2022-06-24 00:26:25.962316
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(5).get_or_else(3) == 5)


# Generated at 2022-06-24 00:26:29.028058
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy

    assert isinstance(Maybe.just(2).to_lazy(), pymonet.lazy.Lazy), 'Maybe.to_lazy is not lazy'



# Generated at 2022-06-24 00:26:32.761969
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:26:36.018596
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(5, True).to_validation() == Validation.success(None)
    assert Maybe(5, False).to_validation() == Validation.success(5)



# Generated at 2022-06-24 00:26:40.793624
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Either.from_(1)
    assert Maybe.nothing().to_either() == Either.from_(None)


# Generated at 2022-06-24 00:26:45.322963
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)

    maybe = Maybe.just(1)
    assert maybe.to_box() == Box(1)

# Generated at 2022-06-24 00:26:48.066122
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:26:50.633428
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method: bind.
    """
    assert Maybe.just(4) == Maybe.just(4).bind(lambda x: Maybe.just(x + 1))
    assert Maybe.nothing() == Maybe.just("str").bind(lambda x: Maybe.nothing())
    assert Maybe.nothing() == Maybe.nothing().bind(lambda x: Maybe.just(x + 1))



# Generated at 2022-06-24 00:26:54.424250
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def add_some(a: int) -> Maybe[int]:
        return Maybe.just(a + 1)

    assert Maybe.nothing().bind(add_some) == Maybe.nothing()
    assert Maybe.just(1).bind(add_some) == Maybe.just(2)


# Generated at 2022-06-24 00:26:57.402911
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(123) != Maybe.just(42)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:27:01.533759
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    mapper = lambda x: 2 * x
    assert Maybe.just(mapper).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just(mapper).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:27:06.733219
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(3).to_validation() == Validation.success(3)

# Generated at 2022-06-24 00:27:11.677953
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(42, False).to_lazy() == Lazy(lambda: 42)
    assert Maybe(None, False).to_lazy() == Lazy(lambda: None)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:27:13.567427
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Given
    value = 1
    maybe_with_value = Maybe.just(value)
    # When
    result = maybe_with_value.map(lambda x: x + 5)
    # Then
    assert result.to_lazy().get()() == 6


# Generated at 2022-06-24 00:27:21.731169
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Executes method bind of class Maybe.

    :returns: None
    :rtype: None
    """
    def fn(value):
        def inner_fn(x):
            return value + x

        return inner_fn

    maybe_just = Maybe.just(2)
    assert maybe_just.bind(fn(3)) == Maybe.just(5)

    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.bind(fn(3)) == Maybe.nothing()


# Generated at 2022-06-24 00:27:23.401745
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(None, True) is Maybe.nothing()
    assert Maybe(10, False) is Maybe.just(10)


# Unit tests for map method of class Maybe

# Generated at 2022-06-24 00:27:33.093409
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def f1(x: int) -> int:
        return x + 1

    def f2(x: int) -> bool:
        return x > 0

    def f3(x: bool) -> int:
        return 1 if x else 0


# Generated at 2022-06-24 00:27:34.892900
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:27:38.512787
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def test_mapper(x: int) -> int:
        return x + 1

    def test_maybe_mapper(x: Maybe[int]) -> Maybe[int]:
        return x.map(test_mapper)

    # Test with normal value
    actual_result = Maybe.just(0).bind(
        test_maybe_mapper
    )
    assert 1 == actual_result.get_or_else(
        None
    )

    # Test with empty value
    actual_result = Maybe.nothing().bind(
        test_maybe_mapper
    )
    assert None is actual_result.get_or_else(
        None
    )



# Generated at 2022-06-24 00:27:40.838640
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:27:45.217433
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    If Maybe is empty, to_either method should transform Maybe to Either with Left monad and None value.
    If Maybe is not empty, to_either method should transform Maybe to Either with Right monad and value of Maybe.
    """
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe("hello", False).to_either() == Right("hello")
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:27:50.327662
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pymonet.monad_try as mt
    assert Maybe.just(5).to_try() == mt.Try(5, is_success=True)
    assert Maybe.nothing().to_try() == mt.Try(None, is_success=False)


# Generated at 2022-06-24 00:27:54.238715
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).value == 1
    assert Maybe.just(1).is_nothing == False

    assert Maybe.nothing().is_nothing == True


# Generated at 2022-06-24 00:27:57.621017
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # GIVEN
    maybe = Maybe.just(10)
    other = Maybe.nothing()

    # THEN
    assert maybe.get_or_else(20) == 10
    assert other.get_or_else(20) == 20



# Generated at 2022-06-24 00:28:01.376471
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    TEST Maybe.ap for Maybe[Int -> Int] and Maybe[Int]
    """

    def plus1(x):
        return x + 1

    actual = Maybe.just(plus1)
    actual = actual.ap(Maybe.just(1))
    expected = Maybe.just(2)
    assert actual == expected


# Generated at 2022-06-24 00:28:08.391670
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    import pytest

    from pymonet.either import Right

    assert (Maybe(None, True)).to_either() == Right(None)
    assert (Maybe(1, False)).to_either() == Right(1)
    assert (Maybe("test", False)).to_either() == Right("test")


# Generated at 2022-06-24 00:28:13.422324
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Right(x + 1)) == Right(2)
    assert Maybe.nothing().bind(lambda x: Right(x + 1)) == Left(None)
    assert Maybe.just(1).bind(lambda x: Box(x + 1)) == Box(2)
    assert Maybe.nothing().bind(lambda x: Box(x + 1)) == Box(None)

# Generated at 2022-06-24 00:28:17.243132
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:28:22.995492
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

# Generated at 2022-06-24 00:28:24.771256
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    if Maybe(1, False).to_validation() != Validation.success(1):
        raise AssertionError()



# Generated at 2022-06-24 00:28:28.908029
# Unit test for method map of class Maybe
def test_Maybe_map():
    @functools.lru_cache(maxsize=128)
    def functions_fib(arg):
        if arg == 0:
            return 0
        elif arg == 1:
            return 1
        else:
            return functions_fib(arg - 1) + functions_fib(arg - 2)

    def test_value():
        for number in range(0, 100):
            maybe_1 = Maybe.just(number)
            assert maybe_1.map(functions_fib).value == functions_fib(number)

    def test_value_nothing():
        maybe_1 = Maybe.just(None)
        assert maybe_1.map(functions_fib) == Maybe.nothing()

    test_value()
    test_value_nothing()


# Generated at 2022-06-24 00:28:36.496659
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe
    from pymonet.applicative import Applicative

    def plus(x: int) -> int:
        return x + 10

    class Ap(Applicative):
        @classmethod
        def ap(cls, a: Maybe[Callable[[int], int]]) -> int:
            return a.get_or_else(lambda x: x)(10)

    class Ap1(Applicative):
        @classmethod
        def ap(cls, a: Maybe[Callable[[str], str]]) -> str:
            return a.get_or_else(lambda x: x)("abc")


# Generated at 2022-06-24 00:28:40.443290
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert(Maybe.just(2).get_or_else(3) == 2)
    assert(Maybe.nothing().get_or_else(3) == 3)


# Generated at 2022-06-24 00:28:45.885676
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(4).map(lambda x: x + 3) == Maybe.just(7)
    assert Maybe.nothing().map(lambda x: x + 3) == Maybe.nothing()
