

# Generated at 2022-06-24 00:18:45.708550
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Test for get_or_else method of Maybe.
    """
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.just(True).get_or_else(False) == True
    assert Maybe.nothing().get_or_else(None) == None
    assert Maybe.nothing().get_or_else("") == ""



# Generated at 2022-06-24 00:18:48.241061
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert isinstance(Maybe.just(1).to_box(), Box)
    assert Maybe.just(1).to_box().get_or_else(0) == 1



# Generated at 2022-06-24 00:18:54.113434
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Given
    maybe = Maybe.just(lambda x: x + 2)
    applicative = Maybe.just(2)

    # When
    actual = maybe.ap(applicative)

    # Then
    assert_that(actual, equal_to(Maybe.just(4)))


# Generated at 2022-06-24 00:18:56.680384
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(123)
    assert maybe.to_box() == 123
    assert maybe.to_box() == Box(123)

    maybe = Maybe.nothing()
    assert maybe.to_box() == None
    assert maybe.to_box() == Box(None)


# Generated at 2022-06-24 00:19:02.659982
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x*x) == Maybe.just(9)
    assert Maybe.just(3).map(lambda x: x*'k') == Maybe.just('kkk')
    assert Maybe.nothing().map(lambda x: x*x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x*'k') == Maybe.nothing()

    assert Maybe.just(3).map(lambda x: x*x).is_nothing == False
    assert Maybe.just(3).map(lambda x: x*'k').is_nothing == False
    assert Maybe.nothing().map(lambda x: x*x).is_nothing == True
    assert Maybe.nothing().map(lambda x: x*'k').is_nothing == True


# Generated at 2022-06-24 00:19:04.944497
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    assert m1 == m2
    m3 = Maybe.just(2)
    assert m1 != m3
    m4 = Maybe.nothing()
    m5 = Maybe.nothing()
    assert m4 == m5
    assert m1 != m4


# Generated at 2022-06-24 00:19:10.932261
# Unit test for constructor of class Maybe
def test_Maybe():
    def square(val):
        return val * val

    # construction
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1.2) == Maybe(1.2, False)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.nothing() == Maybe(None, True)

    # map
    assert Maybe.just(1).map(square) == Maybe.just(1)
    assert Maybe.nothing().map(square) == Maybe.nothing()

    # bind
    assert Maybe.just(1).bind(square) == Maybe.just(1)
    assert Maybe.nothing().bind(square) == Maybe.nothing()

    # ap
    assert Maybe.just(square).ap(Maybe.just(1)) == Maybe.just(1)

# Generated at 2022-06-24 00:19:14.422145
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:19:20.228050
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Testing Maybe.to_box method

    :returns: void
    :rtype: None
    """
    x = 1
    y = None
    assert(Maybe.just(x).to_box() == Box(x))
    assert(Maybe.nothing().to_box() == Box(y))


# Generated at 2022-06-24 00:19:23.541251
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:19:33.150513
# Unit test for constructor of class Maybe
def test_Maybe():
    from test.test_utils import expect_value_with_message

    expect_value_with_message(
        Maybe(None, True).is_nothing,
        True,
        "Maybe() should initialize a Maybe object with attribute is_nothing True"
    )

    expect_value_with_message(
        Maybe.just('a').is_nothing,
        False,
        "Maybe() should initialize a Maybe object with attribute is_nothing False"
    )

    expect_value_with_message(
        Maybe.just('a').value,
        'a',
        "Maybe.just should return a Maybe object with attribute value 'a'"
    )

    expect_value_with_message(
        Maybe.nothing().is_nothing,
        True,
        "Maybe.nothing() should initialize a Maybe object with attribute is_nothing True"
    )



# Generated at 2022-06-24 00:19:38.314682
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    val = Maybe(2, False)
    assert val == val.filter(lambda x: x % 2 == 0)

    assert val.value == 2

    val = val.filter(lambda x: x % 2 == 1)
    assert isinstance(val, Maybe)
    assert val.is_nothing

    assert isinstance(val, Functor)
    assert isinstance(val, Applicative)

# Generated at 2022-06-24 00:19:41.137608
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(9)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:19:42.701622
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe.just(5)
    assert m.value == 5
    assert not m.is_nothing
    n = Maybe.nothing()
    assert n.is_nothing


# Generated at 2022-06-24 00:19:47.430806
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x > 0).get_or_else(6) == 5
    assert Maybe(5, False).filter(lambda x: x < 0).get_or_else(6) == 6
    assert Maybe(5, True).filter(lambda _: True).get_or_else(6) == 6


# Generated at 2022-06-24 00:19:54.353745
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative

    def double(x: int) -> int:
        return x * 2

    def inc(x: int) -> int:
        return x + 1

    assert Maybe.just(double).ap(Maybe.just(10)) == Maybe.just(inc).ap(Maybe.just(10)) == Maybe.just(20)
    assert Maybe.just(double).ap(Maybe.nothing()) == Maybe.just(double).ap(Maybe.just(10)) == Maybe.nothing()
    assert Maybe.jus

# Generated at 2022-06-24 00:19:56.267164
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(5, False).to_lazy().value() == 5
    assert Maybe.nothing().to_lazy().value() is None


# Generated at 2022-06-24 00:19:59.429408
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:05.263927
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(42).to_validation().is_success
    assert not Maybe.just(42).to_validation().is_fail
    assert Maybe.nothing().to_validation().is_success
    assert not Maybe.nothing().to_validation().is_fail
    assert Maybe.just(42).to_validation().value == 42
    assert Maybe.nothing().to_validation().value is None


# Generated at 2022-06-24 00:20:07.624236
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(40).to_lazy() == Lazy(lambda: 40)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:20:10.696260
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    just = Maybe.just(1)
    nothing = Maybe.nothing()
    assert just.get_or_else(2) == 1
    assert nothing.get_or_else(2) == 2

# Generated at 2022-06-24 00:20:12.589277
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:20:15.091723
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """Test for method get_or_else of class Maybe."""
    # Given
    value = Maybe.just('a')
    default_value = 'b'

    # When
    result = value.get_or_else(default_value)

    # Then
    assert result == 'a'

    # Given
    value = Maybe.nothing()
    default_value = 'b'

    # When
    result = value.get_or_else(default_value)

    # Then
    assert result == 'b'


# Generated at 2022-06-24 00:20:17.105421
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:19.636427
# Unit test for method to_either of class Maybe

# Generated at 2022-06-24 00:20:23.965893
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe([1, 2, 3, 4, 5]).filter(lambda x: len(x) > 3) == Maybe([1, 2, 3, 4, 5])
    assert Maybe([1, 2, 3, 4, 5]).filter(lambda x: len(x) > 10) == Maybe.nothing()

# Generated at 2022-06-24 00:20:28.261816
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:20:34.591945
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    func = lambda: 'value'
    maybe = Maybe.just(func)
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force()() == func()  # In fact we run func in func


# Generated at 2022-06-24 00:20:38.128477
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    def test_value():
        from pymonet.box import Box
        from pymonet.either import Maybe
        assert Maybe.just(1).to_box() == Box(1)
    test_value()

    def test_none():
        from pymonet.box import Box
        from pymonet.either import Maybe
        assert Maybe.nothing().to_box() == Box(None)
    test_none()


# Generated at 2022-06-24 00:20:40.351771
# Unit test for method map of class Maybe
def test_Maybe_map():
    # GIVEN
    m: Maybe[int] = Maybe.just(2)

    # WHEN
    result = m.map(lambda x: x * 2)

    # THEN
    assert result == Maybe.just(4)


# Generated at 2022-06-24 00:20:42.851371
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Try(1, is_success=True) == Maybe.just(1).to_try()
    assert Try(None, is_success=False) == Maybe.nothing().to_try()


# Generated at 2022-06-24 00:20:46.689575
# Unit test for method map of class Maybe
def test_Maybe_map():
    def f(x: int) -> int:
        return x + 2

    maybe_int = Maybe.just(5)

    assert maybe_int.map(f) == Maybe.just(7)


# Generated at 2022-06-24 00:20:48.573192
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == 1
    assert Maybe.nothing().to_box() == None


# Generated at 2022-06-24 00:20:51.925277
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2), 'Failed on Maybe.just(lambda x: x + 1)'
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing(), 'Failed on Maybe.nothing()'



# Generated at 2022-06-24 00:20:54.624505
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    from pymonet.either import Left, Right

    assert Maybe.just("1").to_either() == Right("1")
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:00.518805
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda value: value == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda value: value == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda value: value == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:21:03.142443
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(10, False) == Maybe.just(10)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-24 00:21:08.671096
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda a: a + 1).ap(Maybe.just(3)) == Maybe.just(4)
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.just(lambda a: a + 1).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:21:12.972842
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_nothing = Maybe.nothing()
    maybe_not_nothing = Maybe.just(4)
    assert maybe_nothing.map(lambda x: x * 2) == Maybe.nothing()
    assert maybe_not_nothing.map(lambda x: x * 2) == Maybe.just(8)


# Generated at 2022-06-24 00:21:14.297058
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(3) == 2
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-24 00:21:18.798324
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1) == Maybe.just(1)

    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:21:21.973194
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('A').get_or_else('Z') == 'A'
    assert Maybe.nothing().get_or_else('Z') == 'Z'


# Generated at 2022-06-24 00:21:24.363933
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:21:28.705887
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:21:30.987502
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    value = 4
    maybe_value = Maybe.just(value)
    assert maybe_value.to_box() == Box(value)


# Generated at 2022-06-24 00:21:33.035019
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """Test if Maybe.to_either return Right when Maybe is not empty, in other case Left."""
    from pymonet.either import Left, Right

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:21:37.465585
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.just([1, 2]).to_validation() == Validation.success([1, 2])
    assert Maybe.just('str').to_validation() == Validation.success('str')
    assert Maybe.just({'key1': 1, 'key2': 2}).to_validation() == Validation.success({'key1': 1, 'key2': 2})
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:21:41.542720
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Arrange
    maybe = Maybe.just(1)
    default_value = 2

    # Act
    result = maybe.get_or_else(default_value)

    # Assert
    assert result == 1

# Generated at 2022-06-24 00:21:43.787986
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:21:47.441843
# Unit test for constructor of class Maybe
def test_Maybe():
    instance1 = Maybe.just(1)
    assert instance1 == Maybe.just(1)
    assert instance1.value == 1
    assert not instance1.is_nothing

    instance2 = Maybe.nothing()
    assert instance2 == Maybe.nothing()
    assert instance2.is_nothing
    assert not instance2.value



# Generated at 2022-06-24 00:21:51.000741
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Validation.success(None) == Maybe.nothing().to_validation()
    assert Validation.success(5) == Maybe.just(5).to_validation()


# Generated at 2022-06-24 00:21:53.550687
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:22:00.504876
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_odd(n):
        if n % 2:
            return True
        return False

    assert Maybe.just(1).filter(is_odd) == Maybe.just(1)
    assert Maybe.just(2).filter(is_odd) == Maybe.nothing()
    assert Maybe.nothing().filter(is_odd) == Maybe.nothing()

# Unit tests for method map of class Maybe

# Generated at 2022-06-24 00:22:10.627969
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.list import List
    from pymonet.monad_try import Try

    maybe = Maybe.just(10)
    try_ = maybe.to_try()

    assert isinstance(try_, Try)
    assert try_.is_success
    assert try_.get_value() == 10

    maybe = Maybe.nothing()
    try_ = maybe.to_try()

    assert isinstance(try_, Try)
    assert not try_.is_success
    assert try_.get_value(None) is None



# Generated at 2022-06-24 00:22:15.118192
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # test when Maybe is empty
    try_from_maybe = Maybe.nothing().to_try()
    assert try_from_maybe == Try(None, is_success=False)

    # test when Maybe is not empty
    maybe = Maybe.just(2)
    try_from_maybe = maybe.to_try()
    assert try_from_maybe == Try(2, is_success=True)



# Generated at 2022-06-24 00:22:21.848000
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe('a', is_nothing=False).to_try() == \
        Try('a', is_success=True)
    assert Maybe(None, is_nothing=False).to_try() == \
        Try(None, is_success=True)
    assert Maybe(None, is_nothing=True).to_try() == \
        Try(None, is_success=False)


# Generated at 2022-06-24 00:22:32.794587
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe

    :return: nothing
    """

    def test_case_1():
        """
        Create empty Maybe with the nothing and check that the method to_try return not successfully Try with None.

        :return: nothing
        """
        # arrange
        maybe = Maybe.nothing()
        # act
        maybe = maybe.to_try()
        # assert
        assert maybe.is_success is False
        assert maybe.value == None

    def test_case_2():
        """
        Create Maybe with the value and check that the method to_try return successfull Try with this value.

        :return: nothing
        """
        # arrange
        maybe = Maybe.just('value')
        # act
        maybe = maybe.to_try()
        # assert
        assert maybe.is_success

# Generated at 2022-06-24 00:22:34.384577
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:22:36.240364
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just('ab').map(lambda value: value * 2) == Maybe.just('abab')
    assert Maybe.nothing().map(lambda value: value * 2) == Maybe.nothing()


# Unit tests for method bind of class Maybe

# Generated at 2022-06-24 00:22:45.791601
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind in Maybe monad.
    """
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.validation import Validation
    from pymonet.functor import Functor

    def f(x):
        return Functor.of(Try, lambda: x)

    def g(x):
        return Functor.of(Either, lambda: x)

    def h(x):
        return Functor.of(Validation, lambda: x)

    test_list = [
        (Maybe(2, False), 4),
        (Maybe("", True), None),
        (Maybe.nothing(), None)
    ]

    def add_one(x: int) -> Maybe[int]:
        if x % 2 == 0:
            return Maybe.just

# Generated at 2022-06-24 00:22:50.413327
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # arrange
    maybe_box_1 = Maybe.just(1)
    maybe_box_2 = Maybe.just(2)
    maybe_nothing = Maybe.nothing()

    def add(a: int) -> Maybe[int]:
        return Maybe.just(a + 1)

    # act
    result_maybe = Maybe.just(1).bind(add)
    result_nothing = Maybe.nothing().bind(add)

    # assert
    assert result_maybe == Maybe.just(2)
    assert result_nothing == Maybe.nothing()


# Generated at 2022-06-24 00:22:53.829644
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:22:57.010962
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test if to_lazy method returns object of type Lazy.
    """
    from pymonet.lazy import Lazy

    assert isinstance(Maybe.just(10).to_lazy(), Lazy)



# Generated at 2022-06-24 00:22:59.538178
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 3) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 3) == Maybe.nothing()


# Generated at 2022-06-24 00:23:02.574819
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe(0, False).filter(lambda x: x == 0) == Maybe.just(0)
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:23:05.989232
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    just_monad = Maybe.just(10)
    nothing_monad = Maybe.nothing()

    assert just_monad.filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert just_monad.filter(lambda x: x > 5) == just_monad
    assert nothing_monad.filter(lambda x: x > 5) == nothing_monad


# Generated at 2022-06-24 00:23:12.116111
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pytest

    from pymonet.lazy import Lazy
    from pymonet.functors import Functor
    from pymonet.monad import Monad

    # TODO: Remove code duplication
    assert isinstance(Maybe.just(1).to_lazy(), Lazy)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(1).to_lazy().get_value() == 1
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy().get_value() == None
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_l

# Generated at 2022-06-24 00:23:17.655449
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).__eq__(Maybe(1, False))
    assert Maybe.just([]).__eq__(Maybe([], False))
    assert Maybe.just("1").__eq__(Maybe("1", False))
    assert Maybe.just({}).__eq__(Maybe({}, False))
    assert Maybe.nothing().__eq__(Maybe(None, True))



# Generated at 2022-06-24 00:23:21.624123
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe_just = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    assert maybe_just.to_either() == Right(1)
    assert maybe_nothing.to_either() == Left(None)


# Generated at 2022-06-24 00:23:24.134003
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Given
    value = Box(2)
    # When
    actual = value.to_either()
    # Then
    expected = Right(2)
    assert actual == expected



# Generated at 2022-06-24 00:23:26.665927
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(5).to_either() == Right(5)



# Generated at 2022-06-24 00:23:28.946633
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:23:39.538600
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative
    from pymonet.maybe import Maybe

    def add(x):
        return lambda y: x + y

    def successful_function(x):
        return lambda y: x * y * y

    def unsuccessful_function(x):
        return None

    def successful_function2(x):
        return lambda y: x / y

    def empty_function(x):
        return []

    maybe_applicative = Applicative(successful_function)
    another_maybe_applicative = Applicative(successful_function2)

    assert Maybe(23).ap(maybe_applicative) == Maybe.nothing()
    assert Maybe.just(2).ap(maybe_applicative) == Maybe.just(4)
    assert Maybe.just(23).ap(another_maybe_applicative)

# Generated at 2022-06-24 00:23:43.300836
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:51.876723
# Unit test for constructor of class Maybe
def test_Maybe():
    # Check Maybe.__init__ method
    assert Maybe(12, False)
    assert Maybe(None, True)

    # Check Maybe.just method
    assert Maybe.just(12)
    assert Maybe.just('test')
    assert Maybe.just(True)
    assert Maybe.just(False)
    assert Maybe.just(None)
    assert Maybe.just([])
    assert Maybe.just([1, 2, 3])
    assert Maybe.just((1, 2, 3))
    assert Maybe.just({})
    assert Maybe.just({1: 1, 2: 2, 3: 3})
    assert Maybe.just(set())
    assert Maybe.just(set([1, 2, 3]))
    assert Maybe.just(Maybe.just(12))
    assert Maybe.just(Maybe.just('test'))

    # Check Maybe.

# Generated at 2022-06-24 00:23:54.489097
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:59.114272
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert (Maybe.just(5).to_try() == Try(5, True))
    assert (Maybe.nothing().to_try() == Try(None, False))


# Unit tests for method to_box of class Maybe

# Generated at 2022-06-24 00:24:04.983852
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe
    """

    assert Maybe.just('value') == Maybe.just('value')
    assert Maybe.just('value') != Maybe.just('another_value')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('value')
    assert Maybe.nothing() != Maybe.just('another_value')



# Generated at 2022-06-24 00:24:10.136697
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():

    assert Maybe.just(100).to_validation() == Validation.success(100)

    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:24:11.904873
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:24:17.109463
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test bind method of class Maybe.
    """
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    def to_Try(value):
        return Try(value, is_success=True)

    def to_Validation(value):
        from pymonet.monad_validation import Validation

        return Validation.success(value)

    assert Maybe.just(1).bind(to_Try) == to_Try(1)
    assert Maybe.nothing().bind(to_Try) == Try(None, is_success=False)

    assert Maybe.just(1).bind(to_Validation) == to_Validation(1)
    assert Maybe.nothing().bind(to_Validation) == Validation.success(None)



# Generated at 2022-06-24 00:24:19.680222
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:24:26.827679
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    mapper = lambda x: x + 1
    assert Maybe.just(mapper).ap(Maybe.just(1)).get_or_else(None) == 2
    assert Maybe.just(mapper).ap(Maybe.nothing()).get_or_else(None) is None
    assert Maybe.nothing().ap(Maybe.just(1)).get_or_else(None) is None
    assert Maybe.nothing().ap(Maybe.nothing()).get_or_else(None) is None


# Generated at 2022-06-24 00:24:30.898602
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(123).to_lazy() == Lazy(lambda: 123)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:24:37.099615
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    sample = Maybe.just(12)
    double_sample = Maybe.just(24)
    assert sample.filter(lambda x: x == 12) == sample
    assert sample.filter(lambda x: x == 24) == Maybe.nothing()
    assert sample.filter(lambda x: x == 24) == Maybe.nothing()
    assert sample.filter(lambda x: x == 12).filter(lambda x: x == 24) == Maybe.nothing()
    assert sample.filter(lambda x: x == 12).filter(lambda x: x == 12) == sample



# Generated at 2022-06-24 00:24:47.066012
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left

    f = lambda x: Maybe.just(x +1)
    g = lambda x: Maybe.just(x -1)

    bind_func = Maybe.just(2).bind(f).bind(g)
    assert bind_func == Maybe.just(2)

    bind_func = Maybe.just(2).bind(f).bind(g).bind(lambda x: Maybe.nothing())
    assert bind_func == Maybe.nothing()

    bind_func = Maybe.nothing().bind(f).bind(g)
    assert bind_func == Maybe.nothing()

    bind_func = Maybe.nothing().bind(f).bind(g).bind(lambda x: Maybe.nothing())
    assert bind_func == Maybe.nothing()


# Generated at 2022-06-24 00:24:50.340350
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert (Maybe.just(3).to_box() == Box(3))
    assert (Maybe.nothing().to_box() == Box(None))

# Generated at 2022-06-24 00:24:54.574605
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe(1, False).value == 1
    assert Maybe.nothing().is_nothing is True


# Generated at 2022-06-24 00:25:02.043800
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m = Maybe.just(lambda x: x * x)
    assert m.ap(Maybe.just(2)) == Maybe.just(4)
    assert m.ap(Maybe.nothing()) == Maybe.nothing()

    # Check all possible combinations
    expected_result = lambda x: lambda y: x * y
    expected_value = 4
    for maybe_m in [Maybe.just(expected_result), Maybe.nothing()]:
        for maybe_x in [Maybe.just(expected_value), Maybe.nothing()]:
            assert maybe_m.ap(maybe_x) == Maybe.just(expected_result(expected_value)) or \
                   maybe_m.ap(maybe_x) == Maybe.nothing()


# Generated at 2022-06-24 00:25:09.339438
# Unit test for method map of class Maybe
def test_Maybe_map():
    print(Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4))
    print(Maybe.just(2).map(lambda x: x + 2) == Maybe.just(3))
    print(Maybe.just(2).map(lambda x: x + 2) == Maybe.nothing())
    print(Maybe.nothing().map(lambda x: x + 2))


# Generated at 2022-06-24 00:25:13.263509
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    either = Maybe.just(5).to_either()
    assert(isinstance(either, Right))
    assert(either.value == 5)

    either = Maybe.nothing().to_either()
    assert(isinstance(either, Left))
    assert(either.value is None)


# Generated at 2022-06-24 00:25:19.621579
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(val: int) -> int:
        return val + 1

    assert Maybe.just(add).ap(Maybe.just(9)) == Maybe.just(add(9))
    assert Maybe.nothing().ap(Maybe.just(9)) == Maybe.nothing()
    assert Maybe.just(add).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:25:24.783502
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    m_1 = Maybe.just(1)
    m_2 = Maybe.nothing()
    assert m_1.to_lazy() == Lazy(lambda: 1)
    assert m_2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:25:28.424955
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:32.626057
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) != Maybe.nothing()
    assert Maybe(1, True) == Maybe.nothing()


# Generated at 2022-06-24 00:25:35.693152
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:37.887089
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_boxed_just = Maybe.just(
        Box.just(5).map
    )
    assert maybe_boxed_just.ap(Maybe.just(5)) == Just(Box(25))


# Generated at 2022-06-24 00:25:41.715109
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # Check that Box monad is created with value when Maybe is not empty
    assert Maybe.just(21).to_box() == Box(21)
    # Check that Box monad is created with None when Maybe is empty
    assert Maybe.nothing().to_box() == Box(None)

# Unit teset for method to_lazy of class Maybe

# Generated at 2022-06-24 00:25:47.907369
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from unittest import TestCase, main

    from pymonet.either import Right

    class TestMaybe(TestCase):
        def test_Maybe_ap(self):
            maybe = Maybe.just(lambda item: item + 1)
            self.assertEqual(maybe.ap(Maybe.just(1)), Maybe.just(2))
            self.assertEqual(maybe.ap(Maybe.nothing()), Maybe.nothing())
            self.assertEqual(Maybe.nothing().ap(Maybe.just(1)), Maybe.nothing())
            self.assertEqual(Maybe.nothing().ap(Maybe.nothing()), Maybe.nothing())
            self.assertEqual(maybe.ap(Right(1)), Maybe.just(2))

    main()



# Generated at 2022-06-24 00:25:50.714763
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:55.152253
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda num: num % 2 == 0).is_nothing
    assert Maybe.just(2).filter(lambda num: num % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda num: num % 2 == 0).is_nothing



# Generated at 2022-06-24 00:25:58.261356
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert(Maybe.just(lambda x: x + 3).ap(Maybe.just(2)) == Maybe.just(5))
    assert(Maybe.just(lambda x: x + 3).ap(Maybe.nothing()) == Maybe.nothing())


# Generated at 2022-06-24 00:26:02.194178
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation().is_success == True
    assert Maybe.just(3).to_validation().is_success == True
    assert Maybe.nothing().to_validation().value == None
    assert Maybe.just(3).to_validation().value == 3


# Generated at 2022-06-24 00:26:10.019825
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    value = Maybe.just(1)
    def mapper(x):
        if x > 5:
            return Maybe.nothing()
        return Maybe.just(x + 1)
    assert value.bind(mapper) == Maybe.just(2)
    assert value.bind(mapper).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(3)
    assert value.bind(lambda x: Maybe.just(x + 100)).bind(mapper) == Maybe.nothing()



# Generated at 2022-06-24 00:26:12.186504
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:26:13.273584
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    
    

# Generated at 2022-06-24 00:26:20.279904
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:24.001797
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-24 00:26:26.305102
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:29.893879
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # noinspection PyProtectedMember
    unit = Maybe._unit(1)
    assert isinstance(unit, Maybe)
    assert isinstance(unit.to_try(), Try)

# Generated at 2022-06-24 00:26:34.858115
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    """
    Kind a unit test for method to_box of class Maybe.
    """
    assert Box(3) == Maybe.just(3).to_box()
    assert Box(None) == Maybe.nothing().to_box()


# Generated at 2022-06-24 00:26:37.149305
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:26:39.662146
# Unit test for method map of class Maybe
def test_Maybe_map():
    def plus_one(a: int) -> int:
        return a + 1

    assert Maybe.just(1).map(plus_one) == Maybe.just(2)
    assert Maybe.nothing().map(plus_one) == Maybe.nothing()


# Generated at 2022-06-24 00:26:46.889481
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    is_even = lambda x: x % 2 == 0
    is_empty = Maybe.nothing()
    is_not_empty = Maybe.just(2)

    # WHEN
    is_empty_filter = is_empty.filter(is_even)
    is_not_empty_filter = is_not_empty.filter(is_even)

    # THEN
    assert is_empty_filter.is_nothing
    assert is_not_empty_filter == is_not_empty

# Unit testing for method get_or_else of class Maybe

# Generated at 2022-06-24 00:26:53.726084
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    monad = Maybe.just(10)
    try_monad = monad.to_try()
    assert try_monad == Try(10)

    monad = Maybe.nothing()
    try_monad = monad.to_try()
    assert try_monad == Try(None, is_success=False)


# Generated at 2022-06-24 00:26:56.694408
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert (Maybe.just(1).to_validation() == Validation.success(1))
    assert (Maybe.nothing().to_validation() == Validation.success(None))


# Generated at 2022-06-24 00:27:02.398607
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:27:04.655921
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(
        lambda x: x + 1
    ) == Maybe.just(2)

    assert Maybe.nothing().map(
        lambda x: x
    ) == Maybe.nothing()



# Generated at 2022-06-24 00:27:07.346171
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:27:11.664173
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("Stark") == Maybe("Stark", False)
    assert Maybe.just("Stark").value == "Stark"
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:27:13.991194
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:27:19.882817
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda v: v + 10) == Maybe.just(20)
    assert Maybe.nothing().map(lambda v: v + 10) == Maybe.nothing()


# Generated at 2022-06-24 00:27:28.569120
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    monad_1 = Maybe.just(lambda x: x * 2)
    monad_2 = Maybe.just(2)
    result_monad = monad_1.ap(monad_2)
    assert result_monad == Maybe.just(4)

    monad_3 = Maybe.just(lambda x: x * 2)
    monad_4 = Maybe.nothing()
    result_monad2 = monad_3.ap(monad_4)
    assert result_monad2 == Maybe.nothing()



# Generated at 2022-06-24 00:27:31.474744
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:36.642576
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:27:42.870440
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Maybe.just(1).to_box().to_either()
    assert Maybe.just(None).to_either() == Maybe.just(None).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()

    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:45.381736
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just("A").to_box() == Box("A")
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:27:51.868640
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe(10, False)
    lazy = maybe.to_lazy()
    assert lazy == Lazy(lambda: 10)
    assert lazy.get() == 10

    maybe = Maybe(None, True)
    lazy = maybe.to_lazy()
    assert lazy == Lazy(lambda: None)
    assert lazy.get() is None

    maybe = Maybe(10, False)
    lazy = maybe.to_lazy().map(lambda x: x + 10)
    assert lazy == Lazy(lambda: 20)
    assert lazy.get() == 20

    maybe = Maybe(None, True)
    lazy = maybe.to_lazy().map(lambda x: x + 10)
    assert lazy == Lazy(lambda: None)
    assert lazy.get() is None



# Generated at 2022-06-24 00:27:55.978654
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None)
    assert Maybe.just(1).to_try() == Try(1)



# Generated at 2022-06-24 00:28:02.130810
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: x * 5, False).ap(Maybe(1, False)) == Maybe(5, False)
    assert Maybe(lambda x: x * 5, False).ap(Maybe(None, True)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(lambda x: x * 5, False)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(None, True)) == Maybe(None, True)
    print('test passed test_Maybe_ap')


# Generated at 2022-06-24 00:28:09.590829
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_object_1 = Maybe.just(1)
    maybe_object_2 = Maybe.just(2)
    maybe_none_1 = Maybe.nothing()
    maybe_none_2 = Maybe.nothing()

    assert maybe_object_1 == Maybe.just(1)
    assert maybe_object_1 != maybe_object_2
    assert maybe_object_2 != maybe_none_1
    assert maybe_none_1 == maybe_none_2



# Generated at 2022-06-24 00:28:13.815621
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(28) == Maybe(28, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:28:16.391622
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:28:20.635334
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:28:23.692412
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:28:30.164452
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(None) == Maybe.nothing().to_validation()
    assert Validation.success(42) == Maybe.just(42).to_validation()


# Generated at 2022-06-24 00:28:32.538763
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)



# Generated at 2022-06-24 00:28:35.000472
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:28:41.971087
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    def f(value):
        return Maybe.just(value + 1)

    def g(value):
        return Maybe.just(value + 1)

    # Test for empty Maybe monad
    assert Maybe.nothing().bind(f).bind(g) == Maybe.nothing()
    # Test for not empty Maybe monad
    assert Maybe.just(1).bind(f).bind(g) == Maybe.just(3)

