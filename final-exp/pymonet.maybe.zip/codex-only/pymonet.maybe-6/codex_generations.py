

# Generated at 2022-06-24 00:18:47.407974
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe = Maybe.just(3)
    assert maybe.to_either() == Right(3)

    maybe = Maybe.nothing()
    assert maybe.to_either() == Left(None)


# Generated at 2022-06-24 00:18:52.007416
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # when
    result = Maybe.just(True).to_box()
    # then
    assert result.value == True


# Generated at 2022-06-24 00:18:58.988700
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def inc(x):
        return x + 1

    def inc2(x, y):
        return x + y

    assert Maybe.just(inc).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(inc).ap(Maybe.just(1)).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(inc2).ap(Maybe.just(1)).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(inc).ap(Maybe.nothing()).ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(inc).ap(Maybe.just(1)).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:19:01.411702
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test Maybe.to_lazy.

    :returns: None
    :rtype: NoneType
    """
    assert Maybe.just(10).to_lazy().eval() == 10
    assert Maybe.nothing().to_lazy().eval() is None


# Generated at 2022-06-24 00:19:07.267713
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)  # returns successfully Try with previous value when Maybe is not empty
    assert Maybe.nothing().to_try() == Try(None, is_success=False)  # othercase not successfully Try with None


# Generated at 2022-06-24 00:19:13.035905
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:15.695318
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:19.523117
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:23.060350
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe(2, True).map(lambda x: x + 1) == Maybe(None, True)



# Generated at 2022-06-24 00:19:28.022282
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # GIVEN
    m1 = Maybe.just(lambda x: x + 1)
    m2 = Maybe.just(2)
    m3 = Maybe.nothing()

    # WHEN
    result = m1.ap(m2)
    result2 = m1.ap(m3)

    # THEN
    assert result == Maybe.just(3)
    assert result2 == Maybe.nothing()

# Generated at 2022-06-24 00:19:36.751311
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe = Maybe.just(1)
    expected = Lazy(lambda: 1)
    assert maybe.to_lazy() == expected

    maybe = Maybe.nothing()
    expected = Lazy(lambda: None)
    assert maybe.to_lazy() == expected



# Generated at 2022-06-24 00:19:38.601379
# Unit test for constructor of class Maybe
def test_Maybe():
    no_nil = Maybe(1, False)
    nil = Maybe(None, True)

    assert no_nil == no_nil
    assert no_nil != nil


# Generated at 2022-06-24 00:19:44.644261
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Check Maybe.ap method.
    """
    # Initial data:
    fn_mapper = lambda x: x * 3
    maybe_f = Maybe.just(fn_mapper)
    maybe_a = Maybe.just(7)

    # checking result:
    assert maybe_f.ap(maybe_a) == Maybe.just(21)

    # Initial data:
    fn_mapper = lambda x: x * 3
    maybe_f = Maybe.just(fn_mapper)
    maybe_a = Maybe.nothing()

    # checking result:
    assert maybe_f.ap(maybe_a) == Maybe.nothing()

    # Initial data:
    fn_mapper = lambda x: x * 3
    maybe_f = Maybe.nothing()
    maybe_a = Maybe.just(7)

    # checking result

# Generated at 2022-06-24 00:19:48.093993
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

#Unit test for method map of class Maybe

# Generated at 2022-06-24 00:19:53.279183
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x ** 2) == Maybe.just(25)
    assert Maybe.just("test").map(lambda x: len(x)) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x ** 2) == Maybe.nothing()


# Generated at 2022-06-24 00:19:55.157224
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:19:58.147824
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:20:03.205151
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x + 3) == Maybe.just(5)
    assert Maybe.just(15).map(lambda x: x / 5) == Maybe.just(3)


# Generated at 2022-06-24 00:20:08.775911
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10) == Maybe.just(
        10).filter(lambda x: x > 5)
    assert Maybe.nothing() == Maybe.just(
        5).filter(lambda x: x > 10)



# Generated at 2022-06-24 00:20:13.741207
# Unit test for method ap of class Maybe
def test_Maybe_ap():

    assert Maybe.just((lambda x: x * 2)).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just((lambda x: x * 2)).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:20:15.813324
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(Box('one')) == Maybe.just(Box('one'))
    assert Maybe.just(Box('one')) != Maybe.just(Box('two'))
    assert Maybe.nothing() != Maybe.just(Box('two'))



# Generated at 2022-06-24 00:20:21.936060
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    lazy1 = Maybe.just(3).to_lazy()
    assert isinstance(lazy1, Lazy)
    assert lazy1.value() == 3

    lazy2 = Maybe.nothing().to_lazy()
    assert isinstance(lazy2, Lazy)
    assert lazy2.value() is None

    lazy3 = Box(3).to_maybe().to_lazy()
    assert isinstance(lazy3, Lazy)
    assert lazy3.value() is 3

    lazy4 = Box(None).to_maybe().to_lazy()
    assert isinstance(lazy4, Lazy)
    assert lazy4.value() is None



# Generated at 2022-06-24 00:20:24.913782
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x: int) -> int:
        return x + 10

    v = Maybe(5, False)
    u = Maybe(add, False)

    assert u.ap(v) == 15
    assert u.ap(Maybe.nothing()) == 15



# Generated at 2022-06-24 00:20:26.443008
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(20).to_try() == Try(value=20, is_success=True)
    assert Maybe.nothing().to_try() == Try(value=None, is_success=False)

# Generated at 2022-06-24 00:20:29.170634
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe.just(1)
    assert maybe.to_validation() == Validation.success(1)

    maybe = Maybe.nothing()
    assert maybe.to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:20:35.381290
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just('Hello World').to_try() == Try('Hello World', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:20:38.534234
# Unit test for constructor of class Maybe
def test_Maybe():
    @pytest.fixture(scope='class')
    def test_def():
        class TestDef:
            UnitTest = Maybe(Just(1), True)

        return TestDef()

    class TestClass:
        def test_constructor(self, test_def):
            assert test_def.UnitTest.value == Just(1)

    TestClass().test_constructor(test_def=test_def)


# Generated at 2022-06-24 00:20:42.731277
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from assertpy import assert_that

    from pymonet.validation import Validation

    assert_that(Maybe.just(2).to_validation()).is_equal_to(Validation.success(2))
    assert_that(Maybe.nothing().to_validation()).is_equal_to(Validation.success(None))


# Generated at 2022-06-24 00:20:52.405590
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # test for empty maybe
    assert Maybe.nothing().ap(Maybe.just(lambda v: v.upper())) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

    # test for not empty maybe
    assert Maybe.just(lambda v: v.upper()).ap(Maybe.just(3)) == \
        Maybe.just(3).map(lambda v: v.upper()) == Maybe.just(3).map(lambda x: lambda v: v.upper()(x))
    assert Maybe.just(lambda v: v.upper()).ap(Maybe.nothing()) == \
        Maybe.nothing()

    # test with other monads

# Generated at 2022-06-24 00:20:56.027315
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    try_nothing = Try(None, is_success=False)
    try_test = Try(1, is_success=True)
    try_result = Maybe.nothing().to_try()
    assert try_result == try_nothing
    assert Maybe.just(1).to_try() == try_test

# Generated at 2022-06-24 00:21:00.849340
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:21:10.383698
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just_1 = Maybe.just(1)
    just_2 = Maybe.just(2)
    just_1_clone = Maybe.just(1)
    nothing_1 = Maybe.nothing()
    nothing_2 = Maybe.nothing()

    assert just_1 == just_1
    assert just_1 == just_1_clone
    assert not just_1 == just_2
    assert just_1 != just_2
    assert not just_1 != just_1
    assert nothing_1 == nothing_1
    assert nothing_1 == nothing_2
    assert not nothing_1 == just_1
    assert nothing_1 != just_1
    assert not nothing_1 != nothing_1



# Generated at 2022-06-24 00:21:12.984605
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert(Maybe.just(5).to_box() == Box(5))
    assert(Maybe.nothing().to_box() == Box(None))


# Generated at 2022-06-24 00:21:16.354071
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either of class Maybe.

    :return:
    """
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:21:22.489852
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def func(*args):
        return Maybe.nothing()

    def func_success(value):
        return Maybe.just(value)

    assert Maybe.just(1).bind(func_success) == Maybe.just(1)
    assert Maybe.nothing().bind(func_success) == Maybe.nothing()
    assert Maybe.just(1).bind(func) == Maybe.nothing()


# Generated at 2022-06-24 00:21:32.728728
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x*2) == Maybe(2, False)
    assert Maybe(2, False).map(lambda x: x**2) == Maybe(4, False)
    assert Maybe(None, False).map(
        lambda x: x[0]) == Maybe.nothing()
    assert Maybe(None, False).map(lambda x: x *
                                  2) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x *
                             2) == Maybe.just(2)
    assert Maybe.just(2).map(lambda x: x **
                             2) == Maybe.just(4)
    assert Maybe.just(None).map(
        lambda x: x[0]) == Maybe.nothing()

# Generated at 2022-06-24 00:21:35.022259
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, is_nothing=False)
    assert Maybe.nothing() == Maybe(None, is_nothing=True)


# Generated at 2022-06-24 00:21:40.547729
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(2) == 2
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:21:42.515796
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit tests for method to_either of class Maybe.
    """
    from pymonet.either import Left, Right
    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:49.184167
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.nothing().get_or_else(None) is None
    assert Maybe.nothing().get_or_else(None) is None
    assert Maybe.nothing().get_or_else(None) is None


# Generated at 2022-06-24 00:21:52.901501
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    >>> Just(lambda x: x + 1).ap(Just(2)) == Just(3)
    True
    >>> Just(lambda x: x + 1).ap(Nothing()) == Nothing()
    True
    >>> Nothing().ap(Just(2)) == Nothing()
    True
    """



# Generated at 2022-06-24 00:21:57.309558
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(False) != Maybe.just(True)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:21:59.192517
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(56) == Maybe.just(56)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:22:03.713546
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # when Maybe is empty
    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, is_success=False)

    # when Maybe is not empty
    maybe = Maybe.just(1)
    assert maybe.to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:22:07.863808
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:14.151003
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe[int].just(3) == Maybe.just(3)
    assert Maybe.just(3).value == 3
    assert Maybe.just(3).is_nothing is False
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().is_nothing is True
    try:
        Maybe.nothing().value
        pytest.fail("Should be raised AttributeError")
    except AttributeError:
        pass



# Generated at 2022-06-24 00:22:20.768048
# Unit test for method map of class Maybe
def test_Maybe_map():
    # GIVEN
    maybe_empty: Maybe[int] = Maybe.nothing()
    maybe_not_empty: Maybe[int] = Maybe.just(23)

    # WHEN
    mapped_maybe_empty = maybe_empty.map(lambda value: value + 30)
    mapped_maybe_not_empty = maybe_not_empty.map(lambda value: value + 30)

    # THEN
    assert mapped_maybe_empty.__eq__(Maybe.nothing())
    assert mapped_maybe_not_empty.__eq__(Maybe.just(53))


# Generated at 2022-06-24 00:22:26.094873
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(6, False).filter(
        lambda x: x > 5
    ) == Maybe(6, False)
    assert Maybe('', True).filter(
        lambda x: x > 5
    ) == Maybe(None, True)



# Generated at 2022-06-24 00:22:30.677256
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(10).bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.just(20)

    assert Maybe.just(10).bind(
        lambda x: Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x * 2)
    ) == Maybe.nothing()


# Generated at 2022-06-24 00:22:38.516916
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x * x)).bind(lambda x: Maybe.just(x + 1)).value == 26
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()).bind(lambda x: Maybe.just(x + 1)).is_nothing
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)).is_nothing
    assert Maybe.just(1).filter(lambda x: x > 5).is_nothing
    assert Maybe.just(1).filter(lambda x: x > -5).value == 1


# Generated at 2022-06-24 00:22:44.040829
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.monad_applicative import MonadApplicative

    # Test for constructor
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(1, True) == Maybe.nothing()

    # Check if Maybe is Monad, Applicative and Functor
    assert isinstance(Maybe, Monad)
    assert isinstance(Maybe, MonadApplicative)
    assert isinstance(Maybe, Functor)



# Generated at 2022-06-24 00:22:45.765800
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(3) == 2
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-24 00:22:47.138696
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-24 00:22:49.489961
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * x) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()



# Generated at 2022-06-24 00:22:55.385315
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    result = Maybe(2, False).to_validation()
    assert isinstance(result, Validation)
    assert result
    assert result.value == 2

    result = Maybe(None, True).to_validation()
    assert isinstance(result, Validation)
    assert not result.has_failures()
    assert result.value is None


# Generated at 2022-06-24 00:23:00.006706
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # given
    just_value = Maybe(10, False)
    nothing_value = Maybe(None, True)

    # when
    just_validation = just_value.to_validation()
    nothing_validation = nothing_value.to_validation()

    # then
    assert just_validation == Validation.success(10)
    assert nothing_validation == Validation.success(None)


# Generated at 2022-06-24 00:23:03.812449
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    some_number = 2
    some_mapper = lambda number: number + 3
    assert Maybe.just(some_number).bind(
        lambda number: Maybe.just(some_mapper(number))
    ) == Maybe.just(5)
    assert Maybe.nothing().bind(
        lambda number: Maybe.just(some_mapper(number))
    ) == Maybe.nothing()



# Generated at 2022-06-24 00:23:06.816209
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    """
    from pymonet.lazy import Lazy

    maybe1 = Maybe.just(1)
    maybe2 = Maybe.nothing()

    assert maybe1.to_lazy().get()() == 1
    assert maybe2.to_lazy().get()() is None


# Generated at 2022-06-24 00:23:09.664011
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe([1, 2, 3, 4]).to_lazy().get_or_else(lambda: [1]).value == [1, 2, 3, 4]
    assert Maybe.nothing().to_lazy().get_or_else(lambda: [1]).value == [1]


# Generated at 2022-06-24 00:23:15.597635
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, True)



# Generated at 2022-06-24 00:23:24.410166
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def fn_0() -> Maybe[str]:
        return Maybe.just('test')

    def fn_1() -> Maybe[str]:
        return Maybe.nothing()

    assert Maybe.just(2).bind(fn_0).get_or_else('') == 'test'
    assert Maybe.just(2).bind(fn_1).get_or_else('') == ''
    assert Maybe.nothing().bind(fn_0).get_or_else('') == ''
    assert Maybe.nothing().bind(fn_1).get_or_else('') == ''


# Generated at 2022-06-24 00:23:26.664849
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(123).to_box() == Box(123)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:23:29.215147
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Box(3) == Maybe(3, False).to_box()
    assert Box(None) == Maybe(None, True).to_box()



# Generated at 2022-06-24 00:23:31.428614
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(10).to_box() == Box(10)



# Generated at 2022-06-24 00:23:33.652886
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(0) == 5
    assert Maybe.nothing().get_or_else(0) == 0



# Generated at 2022-06-24 00:23:37.018764
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(10)) == Maybe.just(20)
    assert Maybe.nothing().ap(Maybe.just(10)) == Maybe.nothing()



# Generated at 2022-06-24 00:23:42.865077
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():

    from pymonet.validation import Validation

    result = Maybe.nothing().to_validation()

    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value is None

    result = Maybe.just(1).to_validation()

    assert isinstance(result, Validation)
    assert result.is_success()
    assert result.value == 1



# Generated at 2022-06-24 00:23:45.956234
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

    # test if the value is not copied
    a = Maybe.just(2)
    b = a
    b.value = 1
    assert a == b



# Generated at 2022-06-24 00:23:53.908119
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(9.9) == Maybe.just(9.9)
    assert Maybe.just('string') == Maybe.just('string')

    assert Maybe.just(10) != Maybe.just(9.9)
    assert Maybe.just(9.9) != Maybe.just('string')
    assert Maybe.just('string') != Maybe.just(10)

    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(9.9)
    assert Maybe.nothing() != Maybe.nothing()


# Generated at 2022-06-24 00:23:57.331613
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Just(lambda x: x + 1).ap(Just(1)) == Just(2)
    assert Just(lambda x: x + 1).ap(Nothing) == Nothing
    assert Just(lambda x: x + 1).ap(Just(1)).ap(Just(1)) == Just(3)
    assert Just(lambda x: x + 1).ap(Just(1)).ap(Nothing) == Nothing
    assert Just(lambda x: x + 1).ap(Nothing).ap(Just(1)) == Nothing
    assert Just(lambda x: x + 1).ap(Nothing).ap(Nothing) == Nothing

# Generated at 2022-06-24 00:24:01.800125
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-24 00:24:04.856304
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-24 00:24:06.965904
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:09.448332
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    m = Maybe.just(1)
    assert m.to_either() == Right(1)

    m = Maybe.nothing()
    assert m.to_either() == Left(None)



# Generated at 2022-06-24 00:24:11.479325
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:24:17.800011
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(100).to_validation() == Validation.success(100)


# Generated at 2022-06-24 00:24:21.617761
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:24:27.017046
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of class Maybe.
    """
    def square(x):
        return x*x

    assert Maybe.just(5).map(square) == Maybe.just(25)
    assert Maybe.just(5).map(square).value == Maybe.just(25).value
    assert Maybe.nothing().map(square) == Maybe.nothing()



# Generated at 2022-06-24 00:24:32.778913
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Test for non None value
    maybe = Maybe.just(1)

    lazy = maybe.to_lazy()
    assert lazy.value == Lazy.unit(1).value

    # Test for None
    maybe = Maybe.nothing()

    lazy = maybe.to_lazy()
    assert lazy.value == Lazy.unit(None).value


# Generated at 2022-06-24 00:24:33.517870
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False)



# Generated at 2022-06-24 00:24:39.387563
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:24:46.081260
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_is_nothing = Maybe.nothing()
    assert maybe_is_nothing.filter(
        lambda x: x > 0
    ).is_nothing

    maybe_is_something = Maybe.just(0)
    assert maybe_is_something.filter(
        lambda x: x > 0
    ).is_nothing

    maybe_is_something = Maybe.just(10)
    assert maybe_is_something.filter(
        lambda x: x > 0
    ) == Maybe.just(10)



# Generated at 2022-06-24 00:24:48.134783
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:24:54.962205
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    empty_maybe = Maybe.nothing()
    assert(empty_maybe.to_validation() == Validation.success(None))
    string_maybe = Maybe.just('string')
    assert(string_maybe.to_validation() == Validation.success('string'))
    bool_maybe = Maybe.just(True)
    assert(bool_maybe.to_validation() == Validation.success(True))


# Generated at 2022-06-24 00:24:59.349087
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(5, False).map(lambda x: x + 5).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).map(lambda x: x + 5).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-24 00:25:01.998153
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:25:05.536325
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just('abc').to_either() == Right('abc')
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:25:10.068060
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe_value = Maybe.just(1)
    assert maybe_value.to_either() == Right(1)

    maybe_value = Maybe.nothing()
    assert maybe_value.to_either() == Left(None)


# Generated at 2022-06-24 00:25:14.200049
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:25:17.262351
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either of class Maybe.

    str, bool -> str
    """
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:25:21.424393
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    value = 10
    non_value = 'w'
    assert Maybe(value, False).to_validation() == Validation.success(value)
    assert Maybe(non_value, False).to_validation() == Validation.success(non_value)
    assert Maybe(value, True).to_validation() == Validation.success(None)
    assert Maybe(non_value, True).to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:25:28.127210
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy_maybe_nothing = Maybe.nothing().to_lazy()
    lazy_maybe_something = Maybe.just(1).to_lazy()

    assert isinstance(lazy_maybe_something, Lazy)
    assert Lazy.unit(1) == lazy_maybe_something
    assert Lazy.unit(None) == lazy_maybe_nothing

# Generated at 2022-06-24 00:25:31.698649
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda x: x ** 2) == Maybe(100, False)
    assert Maybe(10, False).map(lambda x: None) == Maybe(None, False)
    assert Maybe(None, True).map(lambda x: None) == Maybe(None, True)


# Generated at 2022-06-24 00:25:35.056258
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test for Maybe.map
    """
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:42.755871
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.boolean import Boolean
    from pymonet.boolean import true
    from pymonet.boolean import false
    maybe_0 = Maybe(1, True)
    maybe_1 = Maybe(1, True)
    maybe_2 = Maybe(1, False)
    maybe_3 = Maybe(2, True)
    maybe_4 = Maybe(2, False)
    assert maybe_0 == maybe_1
    assert maybe_1 == maybe_0
    assert maybe_0 != maybe_2
    assert maybe_2 != maybe_0
    assert maybe_0 == maybe_3
    assert maybe_3 == maybe_0
    assert maybe_0 != maybe_4
    assert maybe_4 != maybe_0



# Generated at 2022-06-24 00:25:44.977391
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x * x) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()


# Generated at 2022-06-24 00:25:47.653980
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:25:51.602481
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe_value = Maybe(3, False)
    assert maybe_value.to_either() == Right(3)
    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.to_either() == Left(None)


# Generated at 2022-06-24 00:25:54.499274
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:25:56.046106
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(2, False).to_either() == Right(2)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:26:01.783056
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test constructor with empty Maybe
    test = Maybe(None, True)
    assert test.is_nothing is True

    # Test constructor with not empty Maybe
    test = Maybe('test', False)
    assert test.is_nothing is False
    assert test.value == 'test'



# Generated at 2022-06-24 00:26:11.003829
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try, Failure
    from pymonet.maybe import Maybe

    assert Maybe.just(12).to_try() == Try(12, True)
    assert Maybe.nothing().to_try() == Try(None, False)

    def test():
        return int('asd')

    try:
        test()
    except ValueError as e:
        assert Maybe.just(12).to_try().recover(lambda: Try(12, False)) == Try(12, True)
        assert Maybe.nothing().to_try().recover(lambda: Try(12, False)) == Try(12, False)



# Generated at 2022-06-24 00:26:15.739394
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # pylint: disable=assignment-from-no-return,unidiomatic-typecheck
    assert type(Maybe.just(1).to_box()) == type(Box(1))
    assert Maybe.just(1).to_box() == Box(1)
    assert type(Maybe.nothing().to_box()) == type(Box(None))
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:18.682364
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:21.296530
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:26:24.021306
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test bind for Maybe for empty Maybe and for not empty Maybe.

    :returns: Nothing
    :rtype: None
    """
    assert Maybe.just(1).bind(
        lambda x: Maybe.just(x ** 2)
    ) == Maybe.just(1) ** 2



# Generated at 2022-06-24 00:26:26.309040
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:26:28.018706
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Check map of empty Maybe
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()

    # Check map of not empty Maybe
    assert Maybe.just(3).map(lambda x: x * 2) == Maybe.just(6)



# Generated at 2022-06-24 00:26:32.551586
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(2, False).to_try() == Try(2, is_success=True)
    assert Maybe(None, False).to_try() == Try(None, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:26:35.799500
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:26:38.805729
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe(10, False)
    assert Maybe(10, False) != Maybe(10, True)
    assert Maybe(10, False) != Maybe(11, False)
    assert Maybe(10, True) == Maybe(10, True)


# Generated at 2022-06-24 00:26:41.771819
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    m = Maybe.just(42)

    assert m.to_either() == Right(42)

    m = Maybe.nothing()

    assert m.to_either() == Left(None)


# Generated at 2022-06-24 00:26:46.230618
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just('Hello').get_or_else('World') == 'Hello'
    assert Maybe.nothing().get_or_else('Hello') == 'Hello'



# Generated at 2022-06-24 00:26:54.013041
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just('abc').map(lambda x: x.upper()) == Maybe.just('ABC')
    assert Maybe.nothing().map(lambda x: x.upper()) != Maybe.just('ABC')
    assert Maybe.just('abc').map(lambda x: x.upper()) != Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x.upper()) == Maybe.nothing()


# Generated at 2022-06-24 00:26:55.932638
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(1, False).get_or_else(10) == 1
    assert Maybe.nothing().get_or_else(10) == 10

# Generated at 2022-06-24 00:26:57.843166
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """tests Maybe.to_try method"""
    assert Maybe.just(1).to_try() == Try(1, True)



# Generated at 2022-06-24 00:27:01.967597
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe = Maybe.just(1).to_either()
    assert maybe.value == 1
    assert maybe.is_right

    maybe = Maybe.nothing().to_either()
    assert maybe.value is None
    assert maybe.is_left


# Generated at 2022-06-24 00:27:05.518358
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Tests for method `get_or_else` of class Maybe.
    """
    from pymonet.utils import is_nothing

    maybe = Maybe.just('boom')
    maybe = maybe.map(lambda v: v + '!')

    assert maybe.get_or_else('bam') == 'boom!'

    maybe = maybe.map(is_nothing)

    assert maybe.get_or_else('bam') == 'bam'

# Generated at 2022-06-24 00:27:15.293932
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    def to_either(value: int) -> Either[int, str]:
        """
        Function converts int to either.

        :param value:
        :returns: if value is even Right(value) else  Left(value)
        """
        if value % 2 == 0:
            return Right(value)
        return Left(value)

    assert Maybe.just(12).bind(to_either) == Either.right(12)
    assert Maybe.just(13).bind(to_either) == Either.left(13)
    assert Maybe.nothing().bind(to_either) == Maybe.nothing()


# Generated at 2022-06-24 00:27:19.214975
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:27:25.480738
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_just_1 = Maybe.just(1)
    maybe_just_2 = Maybe.just(2)
    maybe_nothing_1 = Maybe.nothing()
    maybe_nothing_2 = Maybe.nothing()
    assert maybe_just_1 == maybe_just_1
    assert maybe_just_2 == maybe_just_2
    assert maybe_nothing_1 == maybe_nothing_1
    assert maybe_nothing_2 == maybe_nothing_2
    assert maybe_just_1 != maybe_just_2
    assert maybe_just_2 != maybe_nothing_1
    assert maybe_nothing_1 != maybe_just_1
    assert maybe_nothing_1 != maybe_nothing_2
    assert maybe_just_1 != maybe_nothing_1
    assert maybe_nothing_1 != maybe_just_2


# Generated at 2022-06-24 00:27:29.086256
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda a: a * 2) == Maybe.just(10)
    assert Maybe.nothing().map(lambda a: a * 2) == Maybe.nothing()


# Generated at 2022-06-24 00:27:37.781748
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative

    def add(x):
        def f(y):
            return x + y
        return f

    assert Maybe.just(add).ap(Maybe.just(5)).get_or_else(0) == Maybe.just(add(5)).get_or_else(0)
    assert Maybe.just(add).ap(Maybe.nothing()).get_or_else(0) == Maybe.nothing().get_or_else(0)
    assert Maybe.nothing().ap(Maybe.just(5)).get_or_else(0) == Maybe.nothing().get_or_else(0)



# Generated at 2022-06-24 00:27:40.494601
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(2).to_lazy() == Lazy(lambda: 2))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-24 00:27:42.941547
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:27:47.413061
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    print("Start test method to_try")

    import pymonet.monad_try as mt

    try:
        assert mt.Try(1).to_maybe() == Maybe.just(1)
        assert mt.Try(None, is_success=False).to_maybe() == Maybe.nothing()
        print("\tTest success")
    except Exception as e:
        print("\tException raised:", e)
    print()


# Generated at 2022-06-24 00:27:49.358239
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(None, True).to_try() == Try(None, False)


# Generated at 2022-06-24 00:28:00.931256
# Unit test for constructor of class Maybe
def test_Maybe():
    def test_Maybe_map():
        a = Maybe.nothing()
        b = a.map(lambda x: x * x)
        assert b.is_nothing
        assert b == a

    def test_Maybe_just():
        b = Maybe.just(1974)
        assert not b.is_nothing
        assert b.value == 1974

    def test_Maybe_bind():
        a = Maybe.nothing()
        b = a.bind(lambda x: Maybe.just(x * x))
        assert b.is_nothing
        assert b == a

    def test_Maybe_ap():
        a = Maybe.nothing()
        b = Maybe.just(lambda x: x * x)
        c = a.ap(b)
        assert c.is_nothing
        assert c == a

    def test_Maybe_filter():
        a

# Generated at 2022-06-24 00:28:08.506831
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # return copy of self when filterer returns True
    number = Maybe.just(42)
    assert number.filter(lambda x: x > 0) == number

    # return empty Maybe when filterer returns False
    assert number.filter(lambda x: x < 0) == Maybe.nothing()

    # return empty Maybe when self is empty
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-24 00:28:11.710853
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(42).map(lambda value: value + 2) == Maybe.just(44)
    assert Maybe.nothing().map(lambda value: value + 2) == Maybe.nothing()



# Generated at 2022-06-24 00:28:14.968147
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(10, False).to_box() == Box(10)
    assert Maybe(None, False).to_box() == Box(None)


# Generated at 2022-06-24 00:28:19.235406
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:28:23.716043
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    maybe_zero = Maybe.just(0)
    maybe_one = Maybe.just(1)

    can_be_one = lambda value: Maybe.just(value) if value == 1 else Maybe.nothing()
    cant_be_two = lambda value: Maybe.just(value) if value == 2 else Maybe.nothing()

    assert maybe_zero.bind(can_be_one) == Maybe.nothing()
    assert maybe_zero.bind(cant_be_two) == Maybe.nothing()

    assert maybe_one.bind(can_be_one) == Maybe.just(1)
    assert maybe_one.bind(cant_be_two) == Maybe.nothing()


# Generated at 2022-06-24 00:28:34.674732
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # Test for not empty Maybe with not empty Maybe
    succ_succ = Maybe.just(lambda value: value + 1).ap(Maybe.just(1))
    assert succ_succ == Maybe.just(2)
    # Test for not empty Maybe with empty Maybe
    succ_fail = Maybe.just(lambda value: value + 1).ap(Maybe.nothing())
    assert succ_fail == Maybe.nothing()
    # Test for empty Maybe with not empty Maybe
    fail_succ = Maybe.nothing().ap(Maybe.just(1))
    assert fail_succ == Maybe.nothing()
    # Test for empty Maybe with empty Maybe
    fail_fail = Maybe.nothing().ap(Maybe.nothing())
    assert fail_fail == Maybe.nothing()


# Generated at 2022-06-24 00:28:40.317769
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.applicative import Applicative

    def double_func(n: int) -> int:
        return n * 2

    applicative = Applicative(Box(double_func))

    box = Maybe.just(2).ap(applicative)
    assert box.value == 4

    box = Maybe.nothing().ap(applicative)
    assert box.value is None



# Generated at 2022-06-24 00:28:46.515572
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1).__eq__('A') == False
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.nothing().__eq__('A') == False
