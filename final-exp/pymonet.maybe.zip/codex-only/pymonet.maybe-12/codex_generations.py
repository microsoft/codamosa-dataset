

# Generated at 2022-06-24 00:18:46.982710
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:18:53.517415
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    test_maybe_1 = Maybe.just(1)
    test_maybe_2 = Maybe.just(2)

    assert test_maybe_1.map(lambda x: x * 2) == test_maybe_2
    assert test_maybe_1.bind(lambda x: Maybe.just(x * 2)) == test_maybe_2
    assert test_maybe_1.bind(lambda _: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * 2)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda _: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:18:57.565252
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    mb = Maybe.just(1)
    assert mb.get_or_else(0) == 1

    mb = Maybe.nothing()
    assert mb.get_or_else(0) == 0


# Generated at 2022-06-24 00:19:00.353470
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # preparation
    applicative = Maybe.just(lambda x: x.upper())
    maybe = Maybe.just('hi')

    # execution
    actual = maybe.ap(applicative)

    # verification
    assert actual == Maybe.just('HI')


# Generated at 2022-06-24 00:19:10.485196
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    def test_filter(functor: Functor, filter_func: Callable[[T], bool], expected: Union[Maybe[T], Maybe[None]]):
        result = functor.filter(filter_func)
        assert result == expected, \
            "Test failed: \n\tfunctor: \t{0} \n\tfilter_func: \t{1} \n\texpected: \t{2} \n\tresult: \t\t{3}".format(
                functor, filter_func, expected, result)

    test_filter(
        Maybe.just(1),
        lambda x: x > 0,
        Maybe.just(1)
    )

# Generated at 2022-06-24 00:19:14.731129
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(10)
    assert maybe.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-24 00:19:18.385788
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(5).to_try() == Try(5)

# Generated at 2022-06-24 00:19:20.072110
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method of Maybe class.

    :returns: None
    :rtype: None
    """
    value = 5
    x = Maybe.just(value).to_lazy()
    result = x.value()
    assert result == value


# Generated at 2022-06-24 00:19:27.606468
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Maybe.just(2).ap(Maybe.just(lambda x: x * x)) == Maybe.just(4)
    assert Maybe.just(2).ap(Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(2).ap(Try(lambda x: x * x, is_success=True)) == Try.from_value(4)
    assert Maybe.just(2).ap(Try(None, is_success=False)) == Try(None, is_success=False)

    assert Maybe.just(2).ap(Left(lambda x: x * x)) == Left(None)
    assert Maybe.just(2).ap(Right(lambda x: x * x)) == Right

# Generated at 2022-06-24 00:19:30.815744
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:19:35.844189
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:19:43.131531
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda n: Maybe.just(n+1)) == Maybe.just(3)
    assert Maybe.just(4).bind(lambda n: Maybe.just(n+1)) == Maybe.just(5)
    assert Maybe.nothing().bind(lambda n: Maybe.just(n+1)) == Maybe.nothing()


# Generated at 2022-06-24 00:19:46.703396
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(4)
    # maybe = Maybe.nothing()

    assert maybe.filter(lambda value: value > 3) == Maybe.just(4)

# Generated at 2022-06-24 00:19:49.322045
# Unit test for method map of class Maybe
def test_Maybe_map():
    def _func(val):
        return val + 5

    assert Maybe.just(3).map(_func) == Maybe.just(8)
    assert Maybe.nothing().map(_func) == Maybe.nothing()



# Generated at 2022-06-24 00:19:55.987545
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just('some string') == Maybe('some string', False)
    assert Maybe.just(1.5) == Maybe(1.5, False)
    assert Maybe.just(()) == Maybe((), False)

    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:19:59.573380
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert (Maybe.just(5).to_box() == Box(5))
    assert (Maybe.nothing().to_box() == Box(None))



# Generated at 2022-06-24 00:20:03.397816
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    a = Maybe.just(1)
    b = Maybe.nothing()

    assert a.to_validation() == Validation.success(1)
    assert b.to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:06.333995
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet import Maybe, Validation

    value = Maybe.just(1)
    validation = value.to_validation()

    assert validation == Validation.success(1)



# Generated at 2022-06-24 00:20:15.287001
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """

    Unit test for method to_lazy of class Maybe

    """
    def unit_test_Maybe_to_lazy_with_critical_value_empty_Maybe():
        """

        Unit test for method to_lazy function of class Maybe
        with critical value empty Maybe
        Expected result: Lazy[Function() -> None]

        """
        from pymonet.lazy import Lazy
        from pymonet.maybe import Maybe

        maybe = Maybe.nothing()
        result = maybe.to_lazy()
        assert not maybe.is_nothing, "The argument to_lazy passed to Maybe is not a empty Maybe"
        assert isinstance(result, Lazy), "The lazy returned by to_lazy function has a wrong type"

# Generated at 2022-06-24 00:20:20.972435
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(value):
        return value % 2 == 0

    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.just(3).filter(is_even) == Maybe.nothing()
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()


# Generated at 2022-06-24 00:20:22.421065
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:20:26.873532
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(1)

    assert maybe.to_box() == Box(1)


# Generated at 2022-06-24 00:20:29.150616
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    result = Maybe.just('Hello').to_lazy()

    assert isinstance(result, Lazy)
    assert result.value() == 'Hello'



# Generated at 2022-06-24 00:20:34.736952
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(3, False).to_either() == Right(3)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:20:37.128286
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:20:44.849777
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    nothing = Maybe.nothing()
    assert nothing.get_or_else('default') == 'default'
    to_test = 'some'
    just = Maybe.just(to_test)
    assert just.get_or_else('default') == to_test

    assert just.to_either() == Right(to_test)
    assert nothing.to_either() == Left(None)
    assert just.to_box() == Box([to_test])
    assert nothing.to_box() == Box(None)



# Generated at 2022-06-24 00:20:47.594263
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:51.904945
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    :return: bool if test passed or not
    :rtype: bool
    """
    from pymonet.box import Box

    assert Maybe.just(10).to_box() == Box(10)

    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:20:54.335233
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:20:57.843910
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad import Maybe

    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:21:05.014652
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    with pytest.raises(TypeError):
        maybe = Maybe(2, False)
        maybe.to_validation()
    assert Maybe.nothing().to_validation().is_success() == True
    assert Maybe.nothing().to_validation().value == None
    assert Maybe.just(5).to_validation().is_success() == True
    assert Maybe.just(5).to_validation().value == 5


# Generated at 2022-06-24 00:21:14.888892
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe.just(3).to_try() == Try(3) == Try(3, is_success=True)
    assert Maybe.just(Lazy(lambda: 3)).to_try() == Try(Lazy(lambda: 3)) == Try(Lazy(lambda: 3), is_success=True)
    assert Maybe.just(Box(3)).to_try() == Try(Box(3)) == Try(Box(3), is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(3).to_try() != Try(3, is_success=False)
    assert Maybe.nothing().to_try()

# Generated at 2022-06-24 00:21:24.279578
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(2, False) == Maybe(3, False) is False
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) == Maybe(1, False) is False
    assert Maybe(1, False) == Maybe(2, False) is False
    assert Maybe(1, True) == Maybe(2, True) is False
    assert Maybe(1, True) == Maybe(2, False) is False
    assert Maybe(1, False) == Maybe(2, True) is False


# Generated at 2022-06-24 00:21:36.549503
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x + 5)) == Maybe.just(8)
    assert Maybe.just('abc').bind(lambda x: Maybe.just(x.upper())) == Maybe.just('ABC')
    assert Maybe.just('abc').bind(lambda x: Maybe.just(x[0])) == Maybe.just('a')
    assert Maybe.just('abc').bind(lambda x: Maybe.just(x[0:1])) == Maybe.just('a')
    assert Maybe.just('abc').bind(lambda x: Maybe.just('b')) == Maybe.just('b')
    assert Maybe.nothing().bind(lambda x: Maybe.just('b')) == Maybe.nothing()
    assert Maybe.just('abc').bind(lambda x: Maybe.nothing()) == Maybe.nothing()

# Unit

# Generated at 2022-06-24 00:21:46.978908
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    def compare_result_to_expected_result(actual: 'Maybe[int]', expected: 'Try[int]') -> bool:
        return actual.to_try() == expected

    def create_examples():
        return [
            {"actual": Maybe.just(1), "expected": Try(1, is_success=True)},
            {"actual": Maybe.nothing(), "expected": Try(None, is_success=False)},
        ]

    examples = create_examples()

    # test
    for example in examples:
        if not compare_result_to_expected_result(example["actual"], example["expected"]):
            raise Exception(
                "actual: " + str(example["actual"].to_try()) + " but expected: " + str(example["expected"]))



# Generated at 2022-06-24 00:21:49.861704
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:53.728103
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(1)
    b = Maybe.just(2)
    c = Maybe.nothing()
    assert a != b
    assert b != c
    assert a != c
    assert a == Maybe.just(1)
    assert c == Maybe.nothing()
    assert b == Maybe.just(2)


# Generated at 2022-06-24 00:21:59.167864
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:22:01.908418
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()


# Generated at 2022-06-24 00:22:04.102251
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    double = lambda i: i * 2
    left = Maybe.just(double)
    right = Maybe.just(10)
    assert left.ap(right) == Maybe.just(20)


# Generated at 2022-06-24 00:22:07.796470
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:22:12.576326
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # Arrange
    # Act
    # Assert
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:22:21.849305
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe.nothing()
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert not Maybe(1, True) == Maybe.just(1)
    assert not Maybe(1, False) == Maybe.nothing()
    assert not Maybe(1, True) == Maybe(2, True)
    assert not Maybe(1, False) == Maybe(2, False)
    assert not Maybe(1, True) == Maybe(1, False)
    assert not Maybe(1, False) == Maybe(1, True)


# Generated at 2022-06-24 00:22:26.408417
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == (1 >> Right)
    assert Maybe.nothing().to_either() == Left(None)

# Generated at 2022-06-24 00:22:30.120898
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x, y: x + y).ap(Box(5)).ap(Box(5)) == Box(10)
    assert Maybe.just(lambda x, y: x + y).ap(Maybe.just(5)).ap(Maybe.just(5)) == Maybe.just(10)
    assert Maybe.just(lambda x, y: x + y).ap(Box.nothing()).ap(Box.nothing()) == Box.nothing()
    assert Maybe.nothing().ap(Maybe.just(lambda x, y: x + y)).ap(Maybe.just(5)) == Maybe.nothing()


# Generated at 2022-06-24 00:22:35.131888
# Unit test for method map of class Maybe
def test_Maybe_map():
    foo = lambda x: x + 10
    assert Maybe.just(1).map(foo) == Maybe.just(11)
    assert Maybe.nothing().map(foo) == Maybe.nothing()



# Generated at 2022-06-24 00:22:39.547741
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:22:46.183036
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    val = Maybe.just(lambda x: x * 2)
    maybe = Maybe.just(10)
    assert maybe.ap(val) == Maybe.just(20)

    maybe = Maybe.nothing()
    assert maybe.ap(val) == Maybe.nothing()



# Generated at 2022-06-24 00:22:52.788841
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(Box(1)).to_box() == Box(1)
    assert Maybe.just(Left(1)).to_box() == Box(1)
    assert Maybe.just(Right(1)).to_box() == Box(1)
    assert Maybe.just(Lazy(lambda: 1)).to_box() == Box(1)
    assert Maybe.just(Try(1, is_success=True)).to_box() == Box(1)

# Generated at 2022-06-24 00:22:56.884226
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Test Maybe.to_lazy()."""
    m = Maybe.just(42)
    l = m.to_lazy()
    assert l.value() == 42

    m = Maybe.nothing()
    l = m.to_lazy()
    assert l.value() is None


# Generated at 2022-06-24 00:23:00.579596
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(30).bind(lambda x: Maybe.just(x + 30)) == Maybe.just(60)
    assert Maybe.just(30).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(30)) == Maybe.nothing()


# Generated at 2022-06-24 00:23:03.021316
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:23:05.439327
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe(2, False).ap(Box(lambda num: num * 2)) == Maybe(4, False)
    assert Maybe(2, True).ap(Box(lambda num: num * 2)) == Maybe(None, True)


# Generated at 2022-06-24 00:23:10.379752
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(9) == 5
    assert Maybe.nothing().get_or_else(9) == 9


# Unit tests for method map of class Maybe

# Generated at 2022-06-24 00:23:17.537080
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: 2 * x).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just(lambda x: 2 * x).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.just(lambda x: None).ap(Maybe.just(3)) == Maybe.just(None)

# Generated at 2022-06-24 00:23:25.649822
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(2).value == 2
    assert Maybe.just(2).is_nothing is False
    assert Maybe.just(2).to_box().get_value() == 2
    assert Maybe.nothing().is_nothing is True
    assert Maybe.nothing().get_value() is None
    assert Maybe.nothing().to_box().get_value() is None


# Generated at 2022-06-24 00:23:27.531334
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    val = Maybe.just(1)
    assert val.to_lazy().get() == 1
    val = Maybe.nothing()
    assert val.to_lazy().get() is None

# Generated at 2022-06-24 00:23:31.766434
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == \
        Right(1)
    assert Maybe.just(None).to_either() == \
        Right(None)
    assert Maybe.nothing().to_either() == \
        Left(None)
    assert Maybe.just([]).to_either() == \
        Right([])


# Generated at 2022-06-24 00:23:41.322491
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def run_test(value: str, is_nothing: bool, is_equal: bool) -> bool:
        return Maybe(value, is_nothing) == Maybe(value, is_nothing) == is_equal

    print('test_Maybe___eq__')
    assert run_test('test1', False, True)
    assert run_test('test2', True, True)
    assert run_test('test1', False, True) and run_test('test2', True, True)
    assert run_test('test1', False, True) and run_test('test3', True, True)
    assert run_test('test2', True, True) and run_test('test3', False, False)



# Generated at 2022-06-24 00:23:49.953423
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Right, Left

    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 5)) == Maybe.just(7)
    assert Maybe.just(2).bind(lambda x: Lazy(lambda: x + 5)) == Lazy(lambda: 7)
    assert Maybe.just(2).bind(lambda x: Box(x + 5)) == Box(7)
    assert Maybe.just(2).bind(lambda x: Right(x + 5)) == Right(7)
    assert Maybe.just(2).bind(lambda x: Left(x + 5)) == Left(7)
    assert Maybe.just(2).bind(lambda x: (x + 5)) == 7

# Generated at 2022-06-24 00:23:58.435223
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    def double(value):
        return 2*value

    def increment(value):
        return value + 1

    def divide(a, b):
        if b == 0:
            return 0
        return a/b

    # Test for empty Maybe
    nothing_maybe = Maybe.nothing()
    assert nothing_maybe.bind(double) == Maybe.nothing()
    assert nothing_maybe.bind(increment) == Maybe.nothing()

    # Test for not empty Maybe
    # Test for one function
    maybe = Maybe.just(2)
    assert maybe.bind(double) == Maybe.just(4)
    assert maybe.bind(increment) == Maybe.just(3)

    # Test for functions chain
    chain = maybe.bind(double).bind(increment).bind(double)
    assert chain == Maybe.just(12)

    #

# Generated at 2022-06-24 00:24:01.121922
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe('abcd').to_try() == Try('abcd', True)
    assert Maybe(None).to_try() == Try(None, False)

# Generated at 2022-06-24 00:24:05.191205
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-24 00:24:11.721293
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: True) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-24 00:24:21.929108
# Unit test for method map of class Maybe
def test_Maybe_map():
    import unittest
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    class TestMaybeMap(unittest.TestCase):

        def test_map_for_empty_Maybe(self):
            test_maybe = Maybe.nothing()
            f = lambda x: x*2

            res_maybe = test_maybe.map(f)

            expected_maybe = Maybe.nothing()

            self.assertEqual(
                res_maybe,
                expected_maybe
            )

        def test_map_for_non_empty_Maybe(self):
            test_maybe = Maybe.just(2)
            f = lambda x: x*2

            res

# Generated at 2022-06-24 00:24:25.756659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:24:28.626670
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:24:32.276780
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(20).get_or_else(40) == 20
    assert Maybe.nothing().get_or_else(None) == None


# Generated at 2022-06-24 00:24:34.703025
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Maybe.just(1).to_validation(), Validation)
    assert isinstance(Maybe.nothing().to_validation(), Validation)



# Generated at 2022-06-24 00:24:42.256031
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: 2 * x * 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()



# Generated at 2022-06-24 00:24:45.341111
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(100).to_try() == Try(100, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:24:51.738008
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.just(None).get_or_else(0) is None
    value = 0

    def f():
        nonlocal value
        value += 1
        return value

    assert Maybe.nothing().get_or_else(f()) == 1
    assert Maybe.nothing().get_or_else(f()) == 1



# Generated at 2022-06-24 00:24:55.109456
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(True).get_or_else(False) == Maybe.just(True).value
    assert Maybe.nothing().get_or_else(False) == Maybe.nothing().get_or_else(None)



# Generated at 2022-06-24 00:24:57.951310
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    val = Maybe.just(42)
    box = val.to_box()
    assert box.value == 42

    val = Maybe.nothing()
    box = val.to_box()
    assert box.value is None


# Generated at 2022-06-24 00:25:02.476977
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def f(x):
        return Maybe.just(x)

    def g(y):
        return Maybe.nothing()

    res1 = f(10).to_either()
    res2 = g(10).to_either()

    expected1 = Right(10)
    expected2 = Left(None)

    assert(res1 == expected1)
    assert(res2 == expected2)



# Generated at 2022-06-24 00:25:09.598587
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_with_value = Maybe.just(1).filter(lambda x: x % 2 == 0)
    maybe_with_none = Maybe.just(3).filter(lambda x: x % 2 == 0)
    nothing = Maybe.nothing()
    assert maybe_with_none == Maybe.nothing()
    assert nothing == Maybe.nothing()
    assert maybe_with_value == Maybe.just(1)


# Generated at 2022-06-24 00:25:18.491403
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_add = Maybe.just(lambda a: lambda b: a + b)
    maybe_1_with_add = Maybe.just(1).ap(maybe_add)
    maybe_2_with_add = Maybe.just(2).ap(maybe_add)

    assert maybe_1_with_add.value(2) == 3
    assert maybe_1_with_add.value(3) == 4
    assert maybe_2_with_add.value(1) == 3
    assert maybe_2_with_add.value(2) == 4

    maybe_nothing_with_add = Maybe.nothing().ap(maybe_add)
    assert maybe_nothing_with_add.is_nothing


# Generated at 2022-06-24 00:25:23.996797
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(1).to_box() == Maybe.just(1)


# Generated at 2022-06-24 00:25:31.018566
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    def test_normal_value():
        val_maybe = Maybe.just(1)
        val_validation = val_maybe.to_validation()

        assert val_validation.is_success()
        assert val_validation.get() == 1

    def test_empty_value():
        val_maybe = Maybe.nothing()
        val_validation = val_maybe.to_validation()

        assert val_validation.is_success()
        assert val_validation.get() is None

    test_normal_value()
    test_empty_value()



# Generated at 2022-06-24 00:25:36.938345
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x > 1) == Maybe(2, False)
    assert Maybe(1, False).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe(1, True).filter(lambda x: x > 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:39.262993
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:25:45.656120
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(3, False).ap(Maybe(lambda x: x + 1, False)).equals(Maybe(4, False))
    assert Maybe(3, False).ap(Maybe(lambda x: x + 1, True)).equals(Maybe(None, True))
    assert Maybe(lambda x: x + 1, False).ap(Maybe(3, False)).equals(Maybe(4, False))
    assert Maybe(lambda x: x + 1, True).ap(Maybe(3, False)).equals(Maybe(None, True))


# Generated at 2022-06-24 00:25:48.108315
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1)


# Generated at 2022-06-24 00:25:51.991377
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test methods of Maybe.
    """
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:25:54.961382
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(5, False).to_try() == Try(5, True)
    assert Maybe(None, True).to_try() == Try(None, False)

# Generated at 2022-06-24 00:26:02.608923
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == \
        Maybe.to_either(Maybe.nothing()) == \
        Maybe.nothing().to_either().to_try().get_or_else(False) == \
        Maybe.to_either(Maybe.nothing()).to_try().get_or_else(False) == \
        Maybe.to_either(Maybe.nothing()).to_try().is_success() == \
        Maybe.to_either(Maybe.nothing()).to_try().is_failure() == False

# Generated at 2022-06-24 00:26:06.434168
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    nothing_maybe = Maybe.nothing()
    assert nothing_maybe.to_box() == Box(None)

    just_maybe = Maybe.just(1)
    assert just_maybe.to_box() == Box(1)

# Generated at 2022-06-24 00:26:09.143918
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:26:16.420260
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failed

    # just
    assert(Try(None, is_success=True) == Maybe.just(None).to_try())
    assert(Try(True, is_success=True) == Maybe.just(True).to_try())
    assert(Try([1], is_success=True) == Maybe.just([1]).to_try())
    assert(Try({'a': 1}, is_success=True) == Maybe.just({'a': 1}).to_try())

    # nothing
    assert(Failed(None) == Maybe.nothing().to_try())

    # equal
    maybe = Maybe.just('test')
    m = maybe.to_try()
    assert(m is not maybe)

# Generated at 2022-06-24 00:26:19.588361
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-24 00:26:21.794970
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(5)
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)

    assert lazy.value() == 5


# Generated at 2022-06-24 00:26:23.966352
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:26:28.295926
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(4) != Maybe.nothing()
    assert Maybe.just(4) != Maybe.just(5)
    assert Maybe.nothing() != Maybe.just(5)



# Generated at 2022-06-24 00:26:34.231112
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # Given
    success = Maybe.just(1)
    failure = Maybe.nothing()

    # When
    success_result = success.to_try()
    failure_result = failure.to_try()

    # Then
    assert success_result == Try(1, is_success=True)
    assert failure_result == Try(None, is_success=False)



# Generated at 2022-06-24 00:26:37.646056
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import is_success

    assert is_success(Maybe.just(1).to_validation())
    assert not is_success(Maybe.nothing().to_validation())


# Generated at 2022-06-24 00:26:43.115809
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    # Test for Maybe.nothing()
    test_maybe = Maybe.nothing()

    def test_maybe_to_either(monad: Either):
        assert monad == Left(None)

    test_maybe_to_either(test_maybe.to_either())

    # Test for Maybe.just(1)
    test_maybe = Maybe.just(1)

    def test_maybe_to_either(monad: Either):
        assert monad == Right(1)

    test_maybe_to_either(test_maybe.to_either())


# Generated at 2022-06-24 00:26:51.422725
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    If Maybe is empty return new empty Maybe, in other case
    takes mapper function and returns new instance of Maybe
    with result of mapper.

    :param mapper: function to call with Maybe value
    :type mapper: Function(A) -> B
    :returns: Maybe[B | None]
    """
    assert Maybe.just(20).map(lambda x: x + 1) == Maybe.just(21), 'Should be new Item with 21'
    assert Maybe.just(20).map(lambda x: None) == Maybe.nothing(), 'Should be empty Maybe'
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing(), 'Should be empty Maybe'



# Generated at 2022-06-24 00:26:55.889769
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box

    box = Box(34)
    assert (Maybe.just(34)) == (Maybe.just(34))
    assert not (Maybe.nothing()) == (Maybe.just(34))
    assert (Maybe.just(box)) == (Maybe.just(box))
    assert not (Maybe.just(box)) == (Maybe.nothing())



# Generated at 2022-06-24 00:26:59.037431
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert (Maybe.just(2).to_try() ==
            Try(2, is_success=True))
    assert (Maybe.nothing().to_try() ==
            Try(None, is_success=False))

# Generated at 2022-06-24 00:27:00.736383
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    func = lambda x: x + 3
    assert Maybe.just(1).ap(Maybe.just(func)) == Maybe.just(4)



# Generated at 2022-06-24 00:27:02.788717
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just (1)
    l = m.to_lazy()
    assert l.value() == 1


if __name__ == '__main__':
    test_Maybe_to_lazy()

# Generated at 2022-06-24 00:27:08.422619
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:27:12.496934
# Unit test for method map of class Maybe
def test_Maybe_map():
    def increment(a: int) -> int:
        return a + 1
    assert Maybe.just(1).map(increment) == Maybe.just(2)
    assert Maybe.nothing().map(increment) == Maybe.nothing()



# Generated at 2022-06-24 00:27:18.577326
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:27:21.374054
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:27:24.585123
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    dummy_func = lambda x: x + 1
    assert \
        Maybe.just(dummy_func).ap(Maybe.just(1)) == \
        Maybe.just(2)
    assert \
        Maybe.just(dummy_func).ap(Maybe.nothing()) == \
        Maybe.nothing()
    assert \
        Maybe.nothing().ap(Maybe.nothing()) == \
        Maybe.nothing()


# Generated at 2022-06-24 00:27:28.064711
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:27:33.100928
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.monad_test import test_monad_constructor

    test_monad_constructor(
        maybe = lambda value: Maybe.just(value),
        nothing = lambda: Maybe.nothing()
    )


# Generated at 2022-06-24 00:27:38.098672
# Unit test for method map of class Maybe
def test_Maybe_map():
    def f(a):
        return a**2

    assert Maybe(2, False).map(f) == Maybe(4, False)
    assert Maybe(None, True).map(f) == Maybe(None, True)



# Generated at 2022-06-24 00:27:40.429845
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:43.454455
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for Maybe class method to_try
    """
    from pymonet.monad_try import Try

    try_1 = Try(1, True)
    maybe_1 = Maybe.just(1)

    assert maybe_1.to_try() == try_1

# Generated at 2022-06-24 00:27:46.717089
# Unit test for method map of class Maybe
def test_Maybe_map():
    """ Maybe.map(Function(A) -> B) -> Maybe[B | None] """
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(0).map(lambda x: 2 / x) == Maybe.nothing()



# Generated at 2022-06-24 00:27:49.679269
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():

    maybe = Maybe.just(123)
    assert maybe.to_box().value == 123
    assert maybe.to_box().is_nothing is False

    maybe = Maybe.nothing()
    assert maybe.to_box().value == None
    assert maybe.to_box().is_nothing is True


# Generated at 2022-06-24 00:27:53.660742
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    m = Maybe.just(5)
    assert Lazy(lambda: 5) == m.to_lazy()

# Generated at 2022-06-24 00:27:59.516278
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just('something')
    assert maybe.value == 'something'
    assert maybe.is_nothing == False

    maybe = Maybe.nothing()
    assert maybe.is_nothing == True



# Generated at 2022-06-24 00:28:02.874132
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert maybe.get_or_else(None) == 1

    maybe = Maybe.nothing()
    assert maybe.get_or_else(None) == None


# Generated at 2022-06-24 00:28:07.100863
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:28:12.067386
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m1 = Maybe.just(0)
    m2 = Maybe.nothing()

    assert isinstance(m1.to_lazy(), Lazy)
    assert m1.to_lazy().value() == 0
    assert isinstance(m2.to_lazy(), Lazy)
    assert m2.to_lazy().value() is None

# Generated at 2022-06-24 00:28:16.114005
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:28:20.582475
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    actual = Maybe.just(10).to_validation()
    expected = Validation.success(10)
    assert actual == expected

    actual = Maybe.nothing().to_validation()
    expected = Validation.success(None)
    assert actual == expected


# Generated at 2022-06-24 00:28:24.043004
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Lazy, Maybe

    assert Lazy(lambda: 'foo') == Maybe.just('foo').to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-24 00:28:26.643149
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:28:34.172972
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1).value == 1
    assert Maybe.just(1).is_nothing is False
    assert Maybe.nothing().is_nothing is True
    assert Maybe.nothing().value is None



# Generated at 2022-06-24 00:28:38.817479
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(1) == Maybe.just(1)
    assert maybe is True
    maybe = Maybe.just(1) == Maybe.just(2)
    assert maybe is False
    maybe = Maybe.just(1) == Maybe.nothing()
    assert maybe is False
    maybe = Maybe.nothing() == Maybe.nothing()
    assert maybe is True



# Generated at 2022-06-24 00:28:42.658752
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-24 00:28:45.861621
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

