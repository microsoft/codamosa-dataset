

# Generated at 2022-06-24 00:18:48.047172
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    f = lambda x: x > 0
    assert Maybe.just(5).filter(f) == Maybe.just(5)
    assert Maybe.just(-5).filter(f) == Maybe.nothing()
    assert Maybe.nothing().filter(f) == Maybe.nothing()

# Generated at 2022-06-24 00:18:53.436012
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(6) != Maybe.just(4)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:18:59.726298
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print('Filter')
    maybe_box_with_value = Maybe.just(Box(3))
    maybe_box_with_none_value = Maybe.nothing()
    maybe_box_with_value_after_filter = maybe_box_with_value.filter(lambda x: x.value != 3)
    maybe_box_with_value_after_filter_2 = maybe_box_with_value.filter(lambda x: x.value == 3)
    maybe_box_with_none_value_after_filter = maybe_box_with_none_value.filter(lambda x: x.value != 3)

    assert maybe_box_with_value_after_filter.is_nothing
    assert not maybe_box_with_value_after_filter_2.is_nothing and maybe_box_with_value_after_filter_2.value

# Generated at 2022-06-24 00:19:05.296117
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:19:07.940391
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:19:15.590222
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative
    from pymonet.optional import Optional
    from pymonet.either import Left, Right

    m = Maybe.just(lambda x: x * 2)
    assert(
        isinstance(m.ap(Maybe.just(1)), Maybe) and
        m.ap(Maybe.just(1)) == Maybe.just(2)
    )

    m = Maybe.just(lambda x: x * 2)
    assert(
        m.ap(Maybe.nothing()) == Maybe.nothing()
    )

    m = Maybe.nothing()
    assert(
        isinstance(m.ap(Maybe.just(1)), Maybe) and
        m.ap(Maybe.just(1)) == Maybe.nothing()
    )

    m = Maybe.nothing()

# Generated at 2022-06-24 00:19:17.496898
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:19:23.238723
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y

    result = Maybe.just(1).ap(Maybe.just(add(2)))
    expected = Maybe.just(3)
    assert result == expected

    result = Maybe.nothing().ap(Maybe.just(lambda x: x + 1))
    expected = Maybe.nothing()
    assert result == expected

    result = Maybe.just(1).ap(Maybe.nothing())
    expected = Maybe.nothing()
    assert result == expected



# Generated at 2022-06-24 00:19:25.397300
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    maybe = Maybe.just(1)
    assert maybe.to_try() == Try(1, True)
    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, False)


# Generated at 2022-06-24 00:19:33.117286
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    Test Maybe.ap method

    :returns: Nothing
    """
    # Test works when Maybe is empty
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

    # Test works when Maybe is empty
    assert Maybe.nothing().ap(Maybe.just(10)) == Maybe.nothing()

    # Test works when Maybe is not empty
    assert Maybe.just(lambda x: x * 10).ap(Maybe.nothing()) == Maybe.nothing()

    # Test works when Maybe is not empty
    assert Maybe.just(lambda x: x * 10).ap(Maybe.just(10)) == Maybe.just(100)



# Generated at 2022-06-24 00:19:39.153487
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet import Monad, do
    from pymonet.monad_try import MonadTry
    from pymonet.validation import Validation, ValidationError

    with do(Maybe, lambda m: m.bind(lambda x: Maybe.just(x + 2))) \
            as (r1, r2, r3, r4, r5, r6, r7):
        r1, _ = yield Maybe.just(1)
        r2, _ = yield Maybe.just(2)
        r3, _ = yield Maybe.nothing()
        r4, _ = yield Maybe.just(2)
        r5, _ = yield Maybe.just(3)
        r6, _ = yield Maybe.nothing()
        r7, _ = yield Maybe.just(2.5)
        # r1, _ = yield Monad

# Generated at 2022-06-24 00:19:45.917995
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('python').value == 'python'
    assert Maybe.nothing().value == None
    assert Maybe.just('Haskell').is_nothing == False
    assert Maybe.nothing().is_nothing == True
    assert Maybe.just('Lisp') == Maybe.just('Lisp')
    assert Maybe.just('OCaml') != Maybe.nothing()
    assert Maybe.just('Racket') != Maybe.just('Clojure')
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:19:49.575016
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:19:51.675459
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None) is not True


# Generated at 2022-06-24 00:19:53.403846
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)



# Generated at 2022-06-24 00:19:57.555379
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    def add_two(value):
        return Maybe.just(value + 2)

    def multiply_two(value):
        return Maybe.just(value * 2)

    value = Maybe.just(5).bind(add_two).bind(multiply_two).get_or_else(0)
    assert value == 14

# Generated at 2022-06-24 00:20:01.952392
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad import assert_equals
    from pymonet.lazy import Lazy

    maybe = Maybe.just(10).to_lazy()

    assert_equals(maybe, Lazy(lambda: 10))


# Generated at 2022-06-24 00:20:04.600158
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just(10).get_or_else(0) == 10



# Generated at 2022-06-24 00:20:08.412156
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(3)
    assert Maybe.just(4) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-24 00:20:11.479984
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(True).to_either() == Right(True)



# Generated at 2022-06-24 00:20:15.706730
# Unit test for constructor of class Maybe
def test_Maybe():
    # Testing constructor of Maybe
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.just(5).is_nothing == False
    assert Maybe.just(5).value == 5
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing().is_nothing == True
    assert Maybe.nothing().is_just == False
    assert Maybe.nothing().value is None


# Generated at 2022-06-24 00:20:18.460262
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.just(10).to_box() != Box(11)

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.nothing().to_box() != Box(11)


# Generated at 2022-06-24 00:20:23.271296
# Unit test for method map of class Maybe
def test_Maybe_map():
    # empty Maybe
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe.nothing()

    class Empty:
        pass
    # custom type not empty Maybe
    assert Maybe(Empty(), False).map(lambda x: x + 1) == Maybe.nothing()

    # not empty Maybe
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe.just(2)

    # empty Maybe with custom type
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    # not empty Maybe with custom type
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)


# Generated at 2022-06-24 00:20:28.931004
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    m1 = Maybe(1, is_nothing=False)
    assert m1.get_or_else(None) == 1

    m2 = Maybe(1, is_nothing=True)
    assert m2.get_or_else(2) == 2



# Generated at 2022-06-24 00:20:36.503900
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-24 00:20:43.548084
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    from pymonet.either import Either

    unit_result = Maybe(2, False).to_either()
    assert isinstance(unit_result, Either)
    assert unit_result.is_right
    assert unit_result.value == 2

    empty_result = Maybe.nothing().to_either()
    assert isinstance(empty_result, Either)
    assert empty_result.is_left
    assert empty_result.value is None


# Generated at 2022-06-24 00:20:52.444913
# Unit test for method map of class Maybe
def test_Maybe_map():
    class Foo:
        pass

    foo = Foo()
    foo2 = Foo()
    foo3 = Foo()
    foo.bar = foo2
    foo2.bar = foo3
    # maybe.map(Function(A) -> B)
    maybe_int = Maybe.just(1).map(lambda x: x + 1)
    assert maybe_int == Maybe.just(2)
    maybe_str = Maybe.just('test').map(lambda x: x + 'test')
    assert maybe_str == Maybe.just('testtest')
    maybe_foo = Maybe.just(foo).map(lambda x: x.bar)
    assert maybe_foo == Maybe.just(foo2)
    maybe_foo2 = Maybe.just(foo2).map(lambda x: x.bar)

# Generated at 2022-06-24 00:20:56.480060
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.just('abc').get_or_else('def') == 'abc'
    assert Maybe.just(None).get_or_else(10) is None
    assert Maybe.nothing().get_or_else(10) == 10
    assert Maybe.nothing().get_or_else('abc') == 'abc'


# Generated at 2022-06-24 00:21:00.020707
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:08.008696
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe_null = Maybe.nothing()
    assert maybe_null.map(lambda x: x + 100) == Maybe.nothing()

    maybe_with_int = Maybe.just(10)
    assert maybe_with_int.map(lambda x: x + 100) == Maybe.just(110)

    maybe_with_str = Maybe.just("test")
    assert maybe_with_str.map(lambda x: x + "a") == Maybe.just("testa")



# Generated at 2022-06-24 00:21:11.931620
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert(Maybe.just(1).to_try() == Try(1, is_success=True))
    assert(Maybe.nothing().to_try() == Try(None, is_success=False))


# Generated at 2022-06-24 00:21:15.244130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just("white christmas")
    maybe.filter(lambda s: s.startswith("white")).get_or_else("not a white christmas") == "white christmas"
    maybe.filter(lambda s: s.startswith("black")).get_or_else("not a white christmas") == "not a white christmas"
    Maybe.nothing().filter(lambda s: s.startswith("black")).get_or_else("not a white christmas") == "not a white christmas"



# Generated at 2022-06-24 00:21:21.698415
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(None) == 5
    assert Maybe.nothing().get_or_else(8) == 8
    assert Maybe.just(3).get_or_else('string') == 3
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just(None).get_or_else(10) == None

# Generated at 2022-06-24 00:21:23.957111
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:21:28.905248
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:21:30.950323
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from nose.tools import * # type: ignore
    from pymonet.box import Box

    assert_equal(
        Maybe.just(5).to_box(),
        Box(5)
    )
    assert_equal(
        Maybe.nothing().to_box(),
        Box(None)
    )


# Generated at 2022-06-24 00:21:32.625801
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, Right, Left
    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:36.021960
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor

    from pymonet.box import Box

    assert Maybe.just(
        lambda x: x + 2
    ).ap(
        Box(3)
    ) == Box(5)

    assert Maybe.just(
        lambda x: x + 2
    ).ap(
        Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.just(
        lambda x: x + 2
    ).ap(
        Functor.of(lambda x: x + 2)
    ) == Functor.of(5)


# Generated at 2022-06-24 00:21:43.747166
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(123).map(lambda a: a + 1) == Maybe.just(124)
    assert Maybe.just('test string').map(lambda a: a.capitalize()) == Maybe.just('Test string')
    assert Maybe.just((1, 2, 3)).map(lambda a: a[0]) == Maybe.just(1)
    assert Maybe.nothing().map(lambda a: a + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:21:46.170665
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(10, False).to_lazy() == Lazy(lambda: 10)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:21:48.869116
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:21:52.288237
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Maybe(1, False).to_either() == \
        Right(1)

    assert Maybe(1, True).to_either() == \
        Left(None)


# Generated at 2022-06-24 00:22:02.909644
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import test_functor_identity
    from pymonet.functor import test_functor_composition

    def test_data():
        return [
            (Maybe.just(1), lambda value: value == 1),
            (Maybe.just(1), lambda value: value == 2),
            (Maybe.nothing(), lambda value: value == 2)
        ]

    def filterer(maybe, filterer_func):
        return maybe.filter(filterer_func)

    test_functor_identity(test_data, filterer)
    test_functor_composition(test_data, filterer, lambda a: lambda b: b - a, lambda a, b: a == b - 4)



# Generated at 2022-06-24 00:22:04.387771
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:22:07.709088
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)


# Generated at 2022-06-24 00:22:16.978394
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    result = Maybe.just(5).bind(
        lambda n: n * n if n > 2 else Try(None, False)
    )
    expected = Maybe.just(25)
    assert result == expected

    result = Maybe.just(1).bind(
        lambda n: n * n if n > 2 else Try(None, False)
    )
    expected = Maybe.nothing()
    assert result == expected

    result = Maybe.nothing().bind(
        lambda n: n * n if n > 2 else Try(None, False)
    )
    expected = Maybe.nothing()
    assert result == expected

    result = Maybe.just(4).bind(
        lambda n: n * n if n > 2 else Right(None)
    )


# Generated at 2022-06-24 00:22:20.311504
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(6)


# Generated at 2022-06-24 00:22:24.977471
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:22:30.936771
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_list import List

    assert Maybe.just(5).bind(lambda x: Maybe.just(2 ** x)) == Maybe.just(32)
    assert Maybe.just(5).bind(List.from_iterable) == List.from_iterable((5,))
    assert Maybe.just(5).bind(List.from_iterable).bind(Maybe.just) == Maybe.just(5)
    assert Maybe.nothing().bind(lambda x: Maybe.just(2 ** x)) == Maybe.nothing()


# Generated at 2022-06-24 00:22:36.604186
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def f(x):
        return Maybe.just(x + 2)

    assert Maybe.just(5).bind(f) == Maybe.just(7)
    assert Maybe.nothing().bind(f) == Maybe.nothing()


# Generated at 2022-06-24 00:22:39.382158
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:22:44.306002
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    def f():
        print('I executed')
        return 'Hello'
    maybe = Maybe.just(f)

    assert  maybe.to_lazy() == Lazy(f)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:22:50.339423
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.constant import Just
    from pymonet.maybe import Maybe

    x = Maybe.just('some string')
    assert x.to_validation() == Validation.success('some string')

    y = Maybe.nothing()
    assert y.to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:22:57.493510
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), "Equality test for Maybe.just failed"
    assert Maybe.nothing() == Maybe.nothing(), "Equality test for Maybe.nothing failed"
    assert Maybe.just(1) != Maybe.just(2), "Inequality test for Maybe.just failed"
    assert Maybe.just(1) != None, "Inequality test for Maybe.just failed"
    assert Maybe.just(1) != Maybe.nothing(), "Inequality test for Maybe.just failed"



# Generated at 2022-06-24 00:23:04.714562
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, True).to_either() == Left(None)
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe(1, True).to_box() == Box(None)
    assert Maybe(1, False).to_box() == Box(1)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:23:09.989242
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(2, False).to_try() == Try(2, True)
    assert Maybe(None, True).to_try() == Try(None, False)

# Generated at 2022-06-24 00:23:18.598357
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :return: nothing
    """

    # to_lazy returns right function when Maybe is not empty
    some_value = 5
    maybe = Maybe.just(some_value)
    lazy = maybe.to_lazy()
    assert lazy.eval() == some_value

    # to_lazy returns right None when Maybe is empty
    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    assert lazy.eval() is None


# Unit tests for method to_try of class Maybe

# Generated at 2022-06-24 00:23:21.613380
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # GIVEN
    maybe = Maybe.just(5)

    # WHEN
    try_ = maybe.to_try()

    # THEN
    assert try_ == Try(5, is_success=True)

# Generated at 2022-06-24 00:23:24.774819
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    from pymonet.box import Box

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(Box(1)).to_either() == Maybe.just(Box(1)).value.to_either()



# Generated at 2022-06-24 00:23:27.573340
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:23:31.533280
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(4).map(lambda x: x + 2) == Maybe.just(6)
    assert Maybe.just(4).map(lambda x: x - 2) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()



# Generated at 2022-06-24 00:23:42.092590
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    maybe_box = Maybe.just(Box(1))
    maybe_box_result = maybe_box \
        .filter(lambda x: True) \
        .map(lambda x: x.get_or_else(lambda: 0) + 10) \
        .get_or_else(0)
    assert maybe_box_result == 11

    maybe_box = Maybe.just(Box(1))
    maybe_box_result = maybe_box \
        .filter(lambda x: False) \
        .map(lambda x: x.get_or_else(lambda: 0) + 10) \
        .get_or_else(0)
    assert maybe_box_result == 0

    maybe_nothing = Maybe.nothing()
    maybe_nothing_result = maybe_nothing \
        .filter

# Generated at 2022-06-24 00:23:44.048220
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    value = 123

    maybe = Maybe.just(value)
    assert maybe.to_box() == Box(value)

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)



# Generated at 2022-06-24 00:23:46.580413
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """Test method ap of class Maybe."""
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:23:52.330907
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-24 00:23:55.551783
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():

    # not empty Maybe
    assert Maybe(1, False).to_validation().value == 1

    # empty Maybe
    assert Maybe(1, True).to_validation().value == None

# Generated at 2022-06-24 00:23:57.059372
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert isinstance(Maybe.just(1).to_box(), Box)

# Generated at 2022-06-24 00:24:00.818946
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe = Maybe.just(1)

    assert maybe.to_either() == Right(1)

    maybe = Maybe.nothing()

    assert maybe.to_either() == Left(None)


# Generated at 2022-06-24 00:24:08.624407
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    class TestObject:
        pass

    test_obj = TestObject()

    just_none = Maybe.just(None)
    just_test_obj = Maybe.just(test_obj)
    just_1 = Maybe.just(1)
    just_1_copy = Maybe.just(1)
    just_2 = Maybe.just(2)
    nothing = Maybe.nothing()

    assert just_none == just_none
    assert just_test_obj == just_test_obj
    assert not just_test_obj == just_test_obj
    assert just_1 == just_1
    assert just_1 == just_1_copy
    assert just_1 != just_2
    assert nothing == nothing



# Generated at 2022-06-24 00:24:14.089310
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe.nothing()
    assert Maybe.nothing() != Maybe(1, True)
    assert Maybe.nothing() != 1
    assert Maybe(1, False) != 1
    assert Maybe(1, True) != None



# Generated at 2022-06-24 00:24:17.371094
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x * 2).value == 10
    assert Maybe.nothing().map(lambda x: x * 2).is_nothing is True


# Generated at 2022-06-24 00:24:19.888305
# Unit test for method map of class Maybe
def test_Maybe_map():
    def square(x):
        return x ** 2

    assert Maybe.just(2).map(square) == Maybe.just(4)
    assert Maybe.nothing().map(square) == Maybe.nothing()



# Generated at 2022-06-24 00:24:26.290955
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for Maybe.filter method.

    :return: void
    :rtype: None
    """
    def is_positive(value):
        return value > 0

    assert Maybe.just(1).filter(is_positive) == Maybe.just(1)
    assert Maybe.just(-1).filter(is_positive) == Maybe.nothing()
    assert Maybe.nothing().filter(is_positive) == Maybe.nothing()



# Generated at 2022-06-24 00:24:33.158454
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x > 0, 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0, 1) == Maybe.just(1)



# Generated at 2022-06-24 00:24:38.915281
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # start with empty Maybe
    maybe_box = Maybe(None, True).to_box()
    assert maybe_box.is_empty()

    # start with not empty Maybe
    maybe_box = Maybe(10, False).to_box()
    assert maybe_box.value == 10


# Generated at 2022-06-24 00:24:39.886231
# Unit test for method map of class Maybe
def test_Maybe_map():
    pass



# Generated at 2022-06-24 00:24:43.944448
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(1, False).to_validation() == Validation.success(1)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:46.523380
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:48.688636
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    value = 15
    m = Maybe.just(value)
    assert isinstance(m.to_validation(), Validation(value, []))

    m = Maybe.nothing()
    assert isinstance(m.to_validation(), Validation(None, []))

# Generated at 2022-06-24 00:24:55.184281
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def is_positive(number):
        return Maybe.just(1 <= number)
    assert Maybe.just(2).bind(is_positive) == Maybe.just(True)
    assert Maybe.just(-1).bind(is_positive) == Maybe.just(False)
    assert Maybe.nothing().bind(is_positive) == Maybe.nothing()

# Generated at 2022-06-24 00:24:59.531382
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x - 1) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:04.883021
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(7, False).get_or_else(None) == 7
    assert Maybe(None, True).get_or_else(None) == None
    assert Maybe(7, True).get_or_else(None) == None
    assert Maybe(None, False).get_or_else(None) == None

# Generated at 2022-06-24 00:25:12.110357
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x > 5) == Maybe.just(10)
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-24 00:25:21.370224
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Case 1: when Maybe is empty
    result = Maybe.nothing().bind(lambda value: Maybe.just(value + 1))
    assert result == Maybe.nothing()

    # Case 2: when Maybe is not empty and bind function is pure
    result = Maybe.just(1).bind(lambda value: Maybe.just(value + 1))
    assert result == Maybe.just(2)

    # Case 3: when Maybe is not empty and bind function is not pure
    result = Maybe.just(1).bind(lambda value: Maybe.just(value * value))
    assert result == Maybe.just(1)

    # Case 4: when Maybe is not empty and bind function returns None
    result = Maybe.just(1).bind(lambda value: Maybe.nothing())
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:25:26.701957
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pymonet.monad_try
    assert Maybe.just(42).to_try() == pymonet.monad_try.Try(42, True)
    assert Maybe.nothing().to_try() == pymonet.monad_try.Try(None, False)


# Generated at 2022-06-24 00:25:29.938886
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:25:41.640253
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def test_for_just_second_value_ok():
        def adder(a):
            return lambda b: a + b
        assert Maybe.just(1).ap(Maybe.just(2)) == Maybe.just(3)

    def test_for_nothing_second_value_ok():
        def adder(a):
            return lambda b: a + b
        assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()

    def test_for_second_nothing_value_ok():
        def adder(a):
            return lambda b: a + b
        assert Maybe.just(1).ap(Maybe.nothing()) == Maybe.nothing()

    test_for_just_second_value_ok()
    test_for_nothing_second_value_ok()
    test_for_second_nothing_value_

# Generated at 2022-06-24 00:25:47.448749
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(3-1, False)
    assert Maybe(2, True) == Maybe(3-1, True)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, False) != Maybe(None, True)
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, True) != Maybe.just(None)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.just(3) != Maybe(3, False)
    assert Maybe(None, False) != Maybe.nothing()


# Generated at 2022-06-24 00:25:54.048505
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1)\
        .bind(lambda x: Maybe.just(x+1)) == Maybe.just(2)

    assert Maybe.just(1)\
        .bind(lambda x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.nothing()\
        .bind(lambda x: Maybe.just(x+1)) == Maybe.nothing()

    assert Maybe.nothing()\
        .bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:25:57.703231
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either

    maybe = Maybe.just(1)
    assert maybe.to_either() == Either.right(1)

    maybe = Maybe.nothing()
    assert maybe.to_either() == Either.left(None)


# Generated at 2022-06-24 00:26:00.322598
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Given
    maybe = Maybe.just(20)
    mapper = lambda x: Maybe.just(x * 5)

    # When
    result = maybe.bind(mapper)

    # Then
    assert result == Maybe.just(100)


# Generated at 2022-06-24 00:26:04.752350
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:26:14.760242
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    result_1 = Maybe.just(1) == Maybe.just(1)
    assert result_1 is True, f'result_1 = {result_1}'
    result_2 = Maybe.just(1) == Maybe.just(2)
    assert result_2 is False, f'result_2 = {result_2}'

    result_3 = Maybe.nothing() == Maybe.nothing()
    assert result_3 is True, f'result_3 = {result_3}'
    result_4 = Maybe.just(1) == Maybe.nothing()
    assert result_4 is False, f'result_4 = {result_4}'
    result_5 = Maybe.nothing() == Maybe.just(1)
    assert result_5 is False, f'result_5 = {result_5}'

    result

# Generated at 2022-06-24 00:26:17.725014
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("test").filter(lambda x: x == "test") == Maybe.just("test")
    assert Maybe.just("test").filter(lambda x: x == "test1") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == "test") == Maybe.nothing()


# Generated at 2022-06-24 00:26:22.747280
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.test_utils import assert_equal

    assert_equal(
        Maybe.just(1).filter(lambda x: x == 1),
        Maybe.just(1)
    )

    assert_equal(
        Maybe.just(1).filter(lambda x: x == 2),
        Maybe.nothing()
    )

    assert_equal(
        Maybe.just(1).filter(lambda x: x == 0),
        Maybe.nothing()
    )

    assert_equal(
        Maybe.nothing().filter(lambda x: True),
        Maybe.nothing()
    )

# Generated at 2022-06-24 00:26:25.677329
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(45) == 3
    assert Maybe.nothing().get_or_else(45) == 45



# Generated at 2022-06-24 00:26:31.422311
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # Given
    maybe = Maybe.just("value")
    # When
    validation = maybe.to_validation()
    # Then
    assert validation.is_success
    assert validation.value == "value"

    # Given
    maybe = Maybe.nothing()
    # When
    validation = maybe.to_validation()
    # Then
    assert validation.is_success
    assert validation.value is None



# Generated at 2022-06-24 00:26:40.097688
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    mock_try_success_constructor = MagicMock(
        name='success_constructor',
        return_value=MagicMock(name='Success')
    )
    mock_try_failure_constructor = MagicMock(
        name='failure_constructor',
        return_value=MagicMock(name='Failure')
    )
    with patch('pymonet.maybe.Maybe.to_try',
               return_value=mock_try_success_constructor) as patched_to_try:
        res = Maybe(3, False).to_try()
        patched_to_try.assert_called_once_with(3, True)
        assert res == mock_try_success_constructor


# Generated at 2022-06-24 00:26:42.223082
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(2) == 5
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:26:48.104691
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert (Maybe.just(1).to_validation() == Validation.success(1))
    assert (Maybe.nothing().to_validation() == Validation.success(None))


# Generated at 2022-06-24 00:26:57.164665
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(lambda x: x+1).ap(Box(2)) == Box(3)
    assert Maybe.nothing().ap(Box(2)) == Box(None)
    assert Maybe.just(lambda x: x+1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.just(lambda x: x+1).ap(Right(2)) == Right(3)
    assert Maybe.nothing().ap(Right(2)) == Right(None)
    assert Maybe.just

# Generated at 2022-06-24 00:26:59.573040
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:02.352204
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy
    assert isinstance(
        Maybe.just(1).to_lazy(),
        lazy.Lazy
    )
    assert isinstance(
        Maybe.nothing().to_lazy(),
        lazy.Lazy
    )

# Generated at 2022-06-24 00:27:04.816654
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # Unit test for method to_try of class Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just('value').to_try() == Try('value', is_success=True)


# Generated at 2022-06-24 00:27:07.826130
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.success('x') == Maybe.just('x').to_validation()
    assert Validation.success(None) == Maybe.nothing().to_validation()


# Generated at 2022-06-24 00:27:12.857273
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('Hello') == Maybe.just('Hello')
    assert Maybe.just('Hello') != Maybe.just('World')
    assert Maybe.just('Hello') != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('Hello')



# Generated at 2022-06-24 00:27:15.894159
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just(1) != Maybe.just('a')
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just('a') != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just('a')

# Generated at 2022-06-24 00:27:20.777536
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:27:29.388078
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # given
    maybe_just_number = Maybe.just(22)
    maybe_nothing = Maybe.nothing()
    maybe_just_string = Maybe.just("foo")
    # then
    assert maybe_just_number == Maybe.just(22)
    assert maybe_just_string == Maybe.just("foo")
    assert maybe_nothing == Maybe.nothing()

    assert maybe_just_number != Maybe.just("foo")
    assert maybe_nothing != Maybe.just("foo")
    assert maybe_just_number != Maybe.nothing()
    assert maybe_just_number != Maybe.just(20)


# Generated at 2022-06-24 00:27:35.203584
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    result = Maybe.just(5).to_try()
    expected = Try(5, is_success=True)
    assert result == expected
    result = Maybe.nothing().to_try()
    expected = Try(None, is_success=False)
    assert result == expected


# Generated at 2022-06-24 00:27:39.288390
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just("Test").to_validation() == Validation.success("Test")
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:41.890465
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:27:44.404695
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)
    assert maybe.get_or_else(2) == 1

    maybe = Maybe.nothing()
    assert maybe.get_or_else(2) == 2

# Generated at 2022-06-24 00:27:50.985062
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Test to_validation method of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:54.054781
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:28:00.967022
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either

    assert Maybe(None, True).to_either() == Either(None, False)
    assert Maybe(1, True).to_either() == Either(None, False)
    assert Maybe(None, False).to_either() == Either(None, True)
    assert Maybe(1, False).to_either() == Either(1, True)


# Generated at 2022-06-24 00:28:04.577682
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(10)
    lazy = maybe.to_lazy()
    assert lazy == Lazy(lambda: 10)

# Generated at 2022-06-24 00:28:08.785734
# Unit test for constructor of class Maybe
def test_Maybe():
    # constructor of Maybe returns Maybe object with specific value and None with boolean value is_nothingt
    assert Maybe(True, False) == Maybe.just(True)
    assert Maybe.just(True) == Maybe.just(True)


# Generated at 2022-06-24 00:28:11.184070
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)



# Generated at 2022-06-24 00:28:15.448131
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test for create not empty Maybe
    assert Maybe.just(1) == Maybe(1, False)
    # Test for create empty Maybe
    assert Maybe.nothing() == Maybe(None, True)
    # Test for create Maybe with empty value
    assert Maybe.just(None) == Maybe(None, False)


# Generated at 2022-06-24 00:28:20.133121
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(3).to_try() == Try(3, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:28:23.993646
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe.just(10)
    assert Validation.success(10) == maybe.to_validation()
    maybe = Maybe.nothing()
    assert Validation.success(None) == maybe.to_validation()


# Generated at 2022-06-24 00:28:27.954418
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def f():
        nonlocal t

        t += 1
        return t

    t = 0
    lazy_1 = Maybe.just(f).to_lazy()
    lazy_2 = Maybe.just(f).to_lazy()

    assert lazy_1.evaluate() == 1
    assert lazy_2.evaluate() == 1

# Generated at 2022-06-24 00:28:31.070051
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:28:33.092972
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just(1).to_lazy()
    assert lazy.eval() == 1
    lazy = Maybe.nothing().to_lazy()
    assert lazy.eval() is None

# Generated at 2022-06-24 00:28:37.849249
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    :returns: nothing if unit test was successful
    :rtype: None
    """
    from pymonet.monad_test_helper import MonadTestHelper
    from pymonet import maybe

    test_class = maybe.Maybe(4, False)
    monad_test_helper = MonadTestHelper('Maybe', test_class)
    monad_test_helper.assert_filter(
        [
            (lambda x: True, maybe.Maybe(4, False)),
            (lambda x: False, maybe.Maybe(None, True))
        ]
    )



# Generated at 2022-06-24 00:28:41.957211
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test Maybe to_try method.

    :return:
    """
    from pymonet.monad_try import Try

    m1 = Maybe.just(1)
    assert(m1.to_try() == Try(1, is_success=True))
    assert(Maybe.nothing().to_try() == Try(None, is_success=False))



# Generated at 2022-06-24 00:28:51.193625
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.boolean_wrapper import BooleanWrapper

    assert Maybe(True, False) == Maybe(True, False)
    assert Maybe(True, True) == Maybe(True, True)
    assert Maybe(True, False) != Maybe(True, True)
    assert Maybe(BooleanWrapper(True), False) == Maybe(BooleanWrapper(True), False)
    assert Maybe(BooleanWrapper(True), False) != Maybe(BooleanWrapper(True), True)
    assert Maybe(BooleanWrapper(True), False) != Maybe(BooleanWrapper(False), False)
    assert Maybe(True, False).is_nothing is False
    assert Maybe(None, True).is_nothing is True
    assert isinstance(Maybe.just(1), Maybe)
    assert isinstance(Maybe.nothing(), Maybe)

# Unit test