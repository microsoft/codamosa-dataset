

# Generated at 2022-06-24 00:18:47.417474
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(lambda: 0) == 5
    assert Maybe.nothing().get_or_else(lambda: 5) == 5

# Generated at 2022-06-24 00:18:52.283809
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == \
           Left(None)
    assert Maybe.just(1).to_either() == \
           Right(1)


# Generated at 2022-06-24 00:18:56.368163
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left
    from pymonet.validation import Validation
    def double(x):
        return Left(x + x)

    assert Maybe.just(2).bind(double).is_nothing

    def is_even(x):
        return Validation.success(x % 2 == 0)

    result = Maybe.just(2).bind(is_even)
    assert isinstance(result, Validation)
    assert result.value is True


# Generated at 2022-06-24 00:18:58.871026
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(3).to_either() == Right(3)


# Generated at 2022-06-24 00:19:04.578086
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # given
    just_maybe = Maybe.just(1)
    nothing_maybe = Maybe.nothing()

    # when
    just_lazy = just_maybe.to_lazy()
    nothing_lazy = nothing_maybe.to_lazy()

    # then
    print(just_lazy)
    print(nothing_lazy)
    assert isinstance(just_lazy, Lazy)
    assert isinstance(nothing_lazy, Lazy)
    assert just_lazy.value() == 1
    assert nothing_lazy.value() is None
    assert just_lazy.is_successful()
    assert not nothing_lazy.is_successful()

# Generated at 2022-06-24 00:19:07.565815
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m1 = Maybe.just(lambda x: x + 1)
    m2 = Maybe.just(2)
    assert m1.ap(m2) == Maybe.just(3)
    assert m1.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(m1) == Maybe.nothing()


# Generated at 2022-06-24 00:19:19.275205
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1.0, True)
    assert Maybe(1, False) == Maybe(1.0, False)
    assert Maybe(1, True) == Maybe('1', True)
    assert Maybe(1, False) == Maybe('1', False)
    assert Maybe(1, True) == Maybe(True, True)
    assert Maybe(1, False) == Maybe(True, False)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1.0, True) != Maybe(1.0, False)

# Generated at 2022-06-24 00:19:23.971657
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-24 00:19:25.602714
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 6) == Maybe.just(11)
    assert Maybe.nothing().map(lambda x: x + 6) == Maybe.nothing()


# Generated at 2022-06-24 00:19:29.560563
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(1, False).to_try() == Try(value=1, is_success=True)
    assert Maybe(1, True).to_try() == Try(value=None, is_success=False)


# Generated at 2022-06-24 00:19:32.277697
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-24 00:19:37.683418
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.nothing().get_or_else(None) is None
    print('test_Maybe_get_or_else okay.')


# Generated at 2022-06-24 00:19:42.842079
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just('str').get_or_else(0) == 'str'
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:19:44.661623
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert isinstance(Maybe.just(5).to_validation(), Validation)
    assert isinstance(Maybe.nothing().to_validation(), Validation)

if __name__ == '__main__':
    test_Maybe_to_validation()

# Generated at 2022-06-24 00:19:53.260504
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.nothing() == Maybe(None, True)

    Just5 = Maybe(5, False)
    assert Maybe.just(5) == Just5
    assert Just5 == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(7)
    assert Maybe.just(7) != Maybe.just(5)
    assert Maybe.just(7) != Maybe.just(7.2)
    assert Maybe.just(7.2) != Maybe.just(7)
    assert Maybe.just(7.2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(7.2)
    assert Maybe

# Generated at 2022-06-24 00:19:57.749221
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just('a')
    b = Maybe.just('b')
    c = Maybe.just('a')
    d = Maybe.nothing()
    e = Maybe.nothing()
    assert a == c
    assert b != c
    assert d == e
# End of unit test for method __eq__ of class Maybe


# Generated at 2022-06-24 00:20:00.139484
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:20:03.204626
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(2, False).get_or_else(None) == 2
    assert Maybe(None, True).get_or_else(None) == None


# Generated at 2022-06-24 00:20:06.160172
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:20:09.230467
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:20:11.892996
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just(42)
    assert isinstance(m.to_lazy(), Lazy)
    assert m.to_lazy().run() == 42


# Generated at 2022-06-24 00:20:18.122967
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2)\
        .bind(lambda v: Maybe.just(v ** 2)) == Maybe.just(4)
    assert Maybe.just(2)\
        .bind(lambda v: Maybe.nothing()).is_nothing
    assert Maybe.just(2)\
        .bind(lambda _: Maybe.nothing()).is_nothing
    assert Maybe.nothing().bind(Maybe.just) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda _: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda _: Maybe.just(None)) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda _: Maybe.just(None)) == Maybe.nothing()


# Generated at 2022-06-24 00:20:20.838575
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.just(10.0)
    assert Maybe.just(10.0) != Maybe.just(10)

# Unit tests for method Maybe.map

# Generated at 2022-06-24 00:20:24.430845
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(None) == 10
    assert Maybe.nothing().get_or_else(20) == 20
    assert Maybe.just(10).get_or_else(20) == 10
    assert Maybe.nothing().get_or_else(None) is None


# Generated at 2022-06-24 00:20:31.347236
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    validation_success = Maybe(2, False).to_validation()
    assert isinstance(validation_success, Validation)
    assert validation_success.value == 2
    assert validation_success.is_success

    validation_failure = Maybe.nothing().to_validation()
    assert isinstance(validation_failure, Validation)
    assert validation_failure.value is None
    assert validation_failure.is_success


# Generated at 2022-06-24 00:20:40.616810
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Box(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Box(None)) == Maybe.nothing()
    assert Maybe.nothing().ap(Box(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Box(None)) == Maybe.nothing()



# Generated at 2022-06-24 00:20:42.681561
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(5, False).to_either() == Right(5)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:20:52.094229
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from hypothesis import given, assume
    from hypothesis.strategies import integers, lists, none
    from pymonet.box import Box

    @given(integers())
    def test_to_box(value):
        assume(value is not None)
        assert Maybe.just(value).to_box() == Box(value)
        assert Maybe.nothing().to_box() == Box(None)

    @given(none(), lists(integers()))
    def test_to_box(value):
        assert Maybe.just(value).to_box() == Box(value)
        assert Maybe.nothing().to_box() == Box(None)

    test_to_box()


# Generated at 2022-06-24 00:20:54.766287
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:21:01.154709
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert (
            Maybe.just(2).bind(
                lambda x: Maybe.just(x + 1)
            ) == Maybe.just(3)
        )
    assert (
            Maybe.just(2).bind(
                lambda x: Maybe.nothing()
            ) == Maybe.nothing()
        )
    assert (
            Maybe.nothing().bind(
                lambda x: Maybe.just(x + 1)
            ) == Maybe.nothing()
        )


# Generated at 2022-06-24 00:21:07.333766
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    result = Maybe.just(12).to_either()
    assert isinstance(result, Right)
    assert not isinstance(result, Left)
    assert result.value == 12

    result = Maybe.nothing().to_either()
    assert isinstance(result, Left)
    assert not isinstance(result, Right)
    assert result.value is None


# Generated at 2022-06-24 00:21:09.584623
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def get_value():
        return 1

    assert Maybe.just(get_value()).to_lazy().get_value() == 1
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:21:15.414694
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_one(x):
        return x + 1
    m1 = Maybe(add_one, False)
    m2 = Maybe(1, False)
    m3 = Maybe(None, False)
    m4 = Maybe(None, True)

    assert m1.ap(m2) == Maybe.just(2)
    assert m2.ap(m1) == Maybe.just(2)
    assert m1.ap(m3) == Maybe.just(None)
    assert m1.ap(m4) == Maybe.nothing()



# Generated at 2022-06-24 00:21:26.633448
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    def inc(x: int) -> int: return x + 1
    def add(x: int, y: int) -> int: return x + y
    def nothing_maybe(x: int) -> 'Maybe[int]': return Maybe.nothing()

    assert Maybe.just(1).map(inc) == Maybe.just(2)
    assert Maybe.just(1).map(inc).map(inc) == Maybe.just(3)
    assert Maybe.nothing().map(inc) == Maybe.nothing()

    assert Maybe.just(1).bind(lambda x: Maybe.just(add(x, 1))) == Maybe.just(2)
    assert Maybe.just(1).bind(nothing_maybe) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:29.217391
# Unit test for constructor of class Maybe
def test_Maybe():
    for _ in range(10):
        arg = random.randint(0, 100)
        maybe1 = Maybe.just(arg)
        maybe2 = Maybe(arg, False)
        assert maybe1 is not None and maybe1 == maybe2

    maybe1 = Maybe.nothing()
    maybe2 = Maybe(None, True)
    assert maybe1 is not None and maybe1 == maybe2



# Generated at 2022-06-24 00:21:32.466839
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 3).ap(Maybe.just(2)) == Maybe.just(6)
    assert Maybe.just(lambda x: x * 3).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:21:34.760465
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:21:36.829781
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

# Unit tests for method map of class Maybe

# Generated at 2022-06-24 00:21:40.248512
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = Maybe.just(11)
    assert value.filter(lambda x: x > 10) == Maybe.just(11)
    value = Maybe.just(6)
    assert value.filter(lambda x: x > 10) == Maybe.nothing()
    value = Maybe.nothing()
    assert value.filter(lambda x: x > 10) == Maybe.nothing()
    value = Maybe.just(11)
    assert value.filter(lambda x: x > 1000) == Maybe.nothing()


# Generated at 2022-06-24 00:21:43.569442
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.eq import Eq
    from pymonet.box import Box

    assert Maybe(2, False).ap(Box(lambda a: 2 * a)) == Box(4)
    assert Maybe(2, True).ap(Box(lambda a: 2 * a)) == Maybe.nothing()

# Generated at 2022-06-24 00:21:46.023233
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    a = Maybe(1, False)
    def f(x):
        return Maybe(x + 1, False)
    assert a.bind(f) == Maybe.just(2)


# Generated at 2022-06-24 00:21:52.592645
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Test when Maybe is not empty
    def is_even(num):
        return num % 2 == 0

    def double(num):
        return num * 2

    assert Maybe.just(1).bind(is_even).bind(double) == Maybe.nothing()
    assert Maybe.just(2).bind(is_even).bind(double) == Maybe.just(4)

    # Test when Maybe is empty
    assert Maybe.nothing().bind(is_even) == Maybe.nothing()
    assert Maybe.nothing().bind(double) == Maybe.nothing()


# Generated at 2022-06-24 00:22:01.676384
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(2, True)
    assert Maybe(1, False) == Maybe(2, False)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, False) != 1



# Generated at 2022-06-24 00:22:06.966118
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:10.628029
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:22:12.967409
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1).is_nothing == False
    assert Maybe.nothing().is_nothing == True


# Generated at 2022-06-24 00:22:15.308941
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:22:17.516268
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(7).to_try() == Try(7, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:22:20.917421
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    for i in [3, 4, None]:
        def filterer(x): return x != 3
        mocker = Mock(return_value=i)
        maybe = Maybe.just(i)
        assert maybe.filter(filterer) == Maybe.just(i)
        maybe = Maybe.nothing()
        assert maybe.filter(filterer) == Maybe.nothing()

# Generated at 2022-06-24 00:22:28.642674
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    maybe = Maybe.just(2)
    result = maybe.bind(lambda x: Maybe.just(1 + x))
    assert Maybe.just(3) == result
    assert not Maybe.nothing() == result

    maybe = Maybe.nothing()
    result = maybe.bind(lambda x: Maybe.just(1 + x))
    assert Maybe.nothing() == result
    assert Maybe.nothing() == Maybe.just(result.value)


# Generated at 2022-06-24 00:22:31.380584
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just([1, 2, 3]).bind(list) == Maybe.just([1, 2, 3])
    assert Maybe.nothing().bind(list) == Maybe.nothing()



# Generated at 2022-06-24 00:22:39.236501
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit test for constructor of class Maybe.
    """

    assert Maybe.nothing() == Maybe.nothing()  # pylint: disable=no-member
    assert Maybe.nothing() != Maybe.just(value='1')  # pylint: disable=no-member
    assert Maybe.nothing().is_nothing
    assert Maybe.just(value='1') != Maybe.nothing()  # pylint: disable=no-member
    assert not Maybe.just(value='1').is_nothing
    assert Maybe.just(value='1') == Maybe.just(value='1')  # pylint: disable=no-member
    assert Maybe.just(value='1').value == '1'  # pylint: disable=no-member



# Generated at 2022-06-24 00:22:42.755250
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)



# Generated at 2022-06-24 00:22:46.722659
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    # Test for box
    assert Maybe.just(Box(4)).to_box() == Box(Box(4))

    # Test for empty box
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:22:47.862842
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(4).get_or_else(None) == 4
    assert Maybe.nothing().get_or_else(4) == 4



# Generated at 2022-06-24 00:22:52.190491
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    try1 = Try(None, is_success=False)
    try2 = Try(5, is_success=True)
    try3 = Maybe.nothing().to_try()
    try4 = Maybe.just(5).to_try()

    assert try1 == try3
    assert try2 == try4



# Generated at 2022-06-24 00:22:57.743778
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def f(x: int) -> int:
        return x + x

    def g(x: int) -> int:
        return x * x

    r1 = Maybe.just(f).ap(Maybe.just(g).ap(Maybe.just(1)))
    r2 = Maybe.just(f).ap(Maybe.just(g(1)))
    r3 = Maybe.just(f(g(1)))

    assert r1 == r2 == r3

# Generated at 2022-06-24 00:23:00.397234
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:23:08.967052
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe("Success").to_validation() == Validation.success("Success")
    assert Maybe("Success").to_validation().is_success() == True
    assert Maybe("Success").to_validation().is_failure() == False
    assert Maybe("Success").to_validation().is_valid_success("Success") == True
    assert Maybe("Success").to_validation().is_valid_failure("Success") == False
    assert Maybe("Success").to_validation().is_success("Success") == True
    assert Maybe("Success").to_validation().is_failure("Success") == False
    assert Maybe("Success").to_validation().get_success() == "Success"
    assert Maybe("Success").to_validation().get_failure() == []


# Generated at 2022-06-24 00:23:13.419763
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(
        Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)
    )
    assert(
        Maybe.just(3).filter(lambda x: x == 2) == Maybe.nothing()
    )
    assert(
        Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()
    )


# Generated at 2022-06-24 00:23:16.285816
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert isinstance(Maybe.just(3).to_box(), Box)
    assert isinstance(Maybe.nothing().to_box(), Box)


# Generated at 2022-06-24 00:23:20.651281
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:23:24.738752
# Unit test for constructor of class Maybe
def test_Maybe():
    # define test object
    nothing = Maybe.nothing()
    some = Maybe.just('Hello World!')

    assert nothing == Maybe(None, True)
    assert some == Maybe('Hello World!', False)
    assert nothing.is_nothing == True
    assert some.is_nothing == False
    assert some.value == 'Hello World!'


# Generated at 2022-06-24 00:23:27.170667
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Success, Failure
    assert(Maybe.just(0).to_try() == Success(0))
    assert(Maybe.nothing().to_try() == Failure(None))

# Generated at 2022-06-24 00:23:30.876514
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just('Hello, World!').to_try() == Try('Hello, World!', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:23:35.422108
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(10)

# Unit test method to_box of class Maybe

# Generated at 2022-06-24 00:23:37.157818
# Unit test for constructor of class Maybe
def test_Maybe():
    val = 'foo'
    maybe = Maybe.just(val)
    assert maybe.value == val



# Generated at 2022-06-24 00:23:42.176803
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    import pytest

    temp_function = lambda x: x * 2
    # Success case
    assert Maybe(5, False).to_either().right_map(temp_function).value == 10
    # Nothing case
    assert Maybe(None, True).to_either().left_get_or_else(0) == None


# Generated at 2022-06-24 00:23:47.432771
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()

# Unit tests for method map of class Maybe

# Generated at 2022-06-24 00:23:48.967415
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:23:50.512963
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.nothing() == Maybe(None, True)

# Unit tests for method Maybe.map

# Generated at 2022-06-24 00:23:53.191457
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(10) != 10



# Generated at 2022-06-24 00:23:58.601600
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test when filter returns false
    assert Maybe.nothing().filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x > 10) == Maybe.nothing()

    # Test when filter returns true
    assert Maybe.just(10).filter(lambda x: x == 10) == Maybe.just(10)



# Generated at 2022-06-24 00:24:03.196741
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.just(None).to_try() == Try(None, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:24:06.360892
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:24:12.359363
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test for method to_try of class Maybe.

    :returns: nothing
    :rtype: None
    """
    from pymonet.monad_try import Try

    # basic scenario
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

    # test to string
    assert str(Maybe.just(1).to_try()) == str(Try(1, is_success=True))
    assert str(Maybe.nothing().to_try()) == str(Try(None, is_success=False))


# Generated at 2022-06-24 00:24:20.078339
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit test for Maybe.map.

    :returns: None
    """

    # Test for empty Maybe
    if Maybe.nothing().map(lambda x: x + x) != Maybe.nothing():
        raise RuntimeError("Maybe.map function is broken")

    # Test for not empty Maybe
    if Maybe.just(1).map(lambda x: x + x) != Maybe.just(2):
        raise RuntimeError("Maybe.map function is broken")


# Generated at 2022-06-24 00:24:22.107348
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert isinstance(Maybe.just(5).to_validation(), Validation)



# Generated at 2022-06-24 00:24:31.245948
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    """
    Maybe[A -> B] -> Maybe[A] -> Maybe[B]

    :param applicative: applicative contains function
    :type applicative: Maybe[A -> B]
    :returns: new Maybe with result of contains function
    :rtype: Maybe[B]
    """
    assert Maybe.just(lambda x: f"{x[0]}({x[1]})").ap(Maybe.just(['Hello', 'World'])) == Maybe.just('Hello(World)')
    assert Maybe.nothing().ap(Maybe.just('World')) == Maybe.nothing()
    


# Generated at 2022-06-24 00:24:35.175417
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(None, is_nothing=True) == Maybe.nothing()

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()

# Generated at 2022-06-24 00:24:37.233685
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('asd').get_or_else('default_value') == 'asd'
    assert Maybe.nothing().get_or_else('default_value') == 'default_value'

# Generated at 2022-06-24 00:24:43.419991
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(10, False) != Maybe(20, False)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe(None, False) != Maybe(None, True)


# Generated at 2022-06-24 00:24:49.123109
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left

    assert(Maybe.nothing().to_either() == Left(None))
    assert(Maybe.just(10).to_either() == Maybe.just(10).to_box().to_either())



# Generated at 2022-06-24 00:24:51.943830
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe = Maybe.just(10)
    assert maybe.to_try() == Try(10, is_success=True)

    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:24:56.317979
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """ testing for filter method """
    x = Maybe.just(4)
    y = x.filter(lambda x: x % 2 == 0)

    assert y == Maybe.just(4)
    x = Maybe.just(3)
    y = x.filter(lambda x: x % 2 == 0)
    assert y == Maybe.nothing()


# Generated at 2022-06-24 00:24:58.846808
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)



# Generated at 2022-06-24 00:25:02.682848
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(6)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:25:08.799263
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just('to_try').to_try() == Try('to_try', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:25:15.096561
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    box = Maybe.just("hi").to_box()
    assert isinstance(box, Box), "box should be instance of Box"
    assert box == Box("hi"), "get value should be equals to \"hi\""

    empty_box = Maybe.nothing().to_box()
    assert isinstance(empty_box, Box), "empty_box should be instance of Box"
    assert empty_box == Box(None), "get value should be equals to None"


# Generated at 2022-06-24 00:25:24.915273
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import unittest

    from pymonet.monad_try import Try

    class Test(unittest.TestCase):

        def test_should_return_try_with_value(self):
            maybe = Maybe.just("value")
            result = maybe.to_try()
            self.assertTrue(result.is_success())
            self.assertEqual(result, Try("value", True))

        def test_should_return_try_with_none(self):
            maybe = Maybe.nothing()
            result = maybe.to_try()
            self.assertFalse(result.is_success())
            self.assertEqual(result, Try(None, False))

    Test().test_should_return_try_with_value()
    Test().test_should_return_try_with_none()


# Generated at 2022-06-24 00:25:28.546692
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:25:31.414418
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(5, False).ap(Maybe(lambda x: x + 1, False)) == Maybe(6, False)
    assert Maybe(None, True).ap(Maybe(lambda x: x + 1, True)) == Maybe(None, True)


# Generated at 2022-06-24 00:25:35.098576
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x == 3) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe.nothing().filter(lambda x: x == 8) == Maybe.nothing()


# Generated at 2022-06-24 00:25:38.188843
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:25:44.210166
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Validation.success(1).to_maybe() == Validation.success(1).to_maybe()
    assert Validation.failure([1]).to_maybe() == Validation.failure([1]).to_maybe()
    assert Validation.failure([1]).to_maybe() != Validation.success(1).to_maybe()
    assert Validation.success(1).to_maybe() != Validation.failure([1]).to_maybe()


# Generated at 2022-06-24 00:25:46.812918
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just('a') == Maybe('a', False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:25:50.372256
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # arrange
    from pymonet.monad_try import Try

    # act
    maybe = Maybe.just(10).to_try()

    # assert
    assert maybe == Try(10, is_success=True)



# Generated at 2022-06-24 00:25:58.419939
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x == 6) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 6) == Maybe.nothing()

    assert Maybe.just(5).filter(lambda x: x == 5).get_or_else(10) == 5
    assert Maybe.just(5).filter(lambda x: x == 6).get_or_else(10) == 10
    assert Maybe.nothing().filter(lambda x: x == 6).get_or_else(10) == 10


# Generated at 2022-06-24 00:26:03.836211
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    # Arrange
    m = Maybe.just("test")

    # Act
    result = m.filter(lambda s: s == "test")

    # Assert
    assert result == Maybe.just("test")

    # Arrange
    m = Maybe.just("test")

    # Act
    result = m.filter(lambda s: s != "test")

    # Assert
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:26:06.889875
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:09.596759
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
        >>> one = Maybe.just(1)
    """
    assert one.ap(one) == Maybe.just(1)



# Generated at 2022-06-24 00:26:14.170089
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x ** 2)) == Maybe.just(1)
    assert Maybe.just(1).bind(lambda x: Maybe.just(x ** 2)).bind(lambda x: Maybe.just(x ** 3)) == Maybe.just(1)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x ** 2)) == Maybe.nothing()


# Generated at 2022-06-24 00:26:18.821229
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    expected = Validation.success(1)
    result = Maybe.just(1).to_validation()
    assert result == expected


# Generated at 2022-06-24 00:26:21.121757
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:24.677393
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)
    assert Try(1).to_maybe().to_either() == Right(1)
    assert Try(1, is_success=False).to_maybe().to_either() == Left(None)



# Generated at 2022-06-24 00:26:28.930547
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # Test for not empty Maybe
    assert Maybe.just(1).to_try() == Try(1, is_success=True)

    # Test for empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:26:30.788426
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Left

    assert Box(1) == Maybe.just(1).to_box()
    assert Box(None) == Maybe.nothing().to_box()


# Generated at 2022-06-24 00:26:34.186765
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(3)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:26:36.484683
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:38.359531
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    x = Maybe.just(1)
    assert 1 == x.get_or_else(0)
    y = Maybe.nothing()
    assert 0 == y.get_or_else(0)


# Generated at 2022-06-24 00:26:40.502819
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:42.560854
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:26:47.866394
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4) == box(4) == just(4)
    assert Maybe.just(4) != Maybe.just(5) != box(5) != just(5)
    assert Maybe.just(4) != Maybe.nothing() == nothing()
    assert Maybe.nothing() == Maybe.nothing() == nothing()



# Generated at 2022-06-24 00:26:53.187545
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe(2, False).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe(1, True).filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:27:00.807535
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test with is_nothing = True
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, True) == Maybe(None, False)
    assert Maybe(None, True) == Maybe(10, True)
    assert Maybe(None, True) == Maybe(10, False)
    assert Maybe(None, True) == Maybe.just(10)
    # Test with is_nothing = False
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(100)
    assert Maybe.just(10) != Maybe(10, True)
    assert Maybe.just(10) != Maybe(10, False)
    assert Maybe.just(10) != Maybe.nothing()



# Generated at 2022-06-24 00:27:03.159619
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # Given
    maybe = Maybe.just(2)

    # When
    actual_result = maybe.to_box()

    # Then
    assert actual_result == Box(2)

# Unit tests for method map of class Maybe

# Generated at 2022-06-24 00:27:05.025750
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda x: x + 2) == Maybe.just(12)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()



# Generated at 2022-06-24 00:27:07.742190
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Lazy(lambda: 3 < 2) == Maybe.just(3 < 2).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-24 00:27:11.329268
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(100) == 1
    assert Maybe.nothing().get_or_else(100) == 100


# Generated at 2022-06-24 00:27:14.953319
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left
    from pymonet.box import Box

    assert Maybe('value1').to_either() == Right('value1')
    assert Maybe(Box(10)).to_either() == Right(Box(10))
    assert Maybe.nothing().to_either() == Left(None)

# Generated at 2022-06-24 00:27:16.829936
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:27:21.374379
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_maybe import Maybe

    assert Maybe.just(True).bind(lambda v: Maybe.just(v)) == Maybe.just(True)
    assert Maybe.just("a").bind(lambda v: Maybe.just(v)) == Maybe.just("a")
    assert Maybe.just(True).bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda v: Maybe.just(v)) == Maybe.nothing()


# Generated at 2022-06-24 00:27:31.052515
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.functor import Functor
    from pymonet.lambda_ import _
    from pymonet.monad_try import Try

    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def throws(value):
        raise Exception("Oops!")

    assert Functor(Maybe.just(1).bind(lambda x: Maybe.just(add_one(x)))) == Functor(Maybe.just(2))
    assert Functor(Maybe.just(1).bind(lambda x: Maybe.nothing())) == Functor(Maybe.nothing())
    assert Functor(Maybe.nothing().bind(lambda x: Maybe.just(add_one(x)))) == Functor(Maybe.nothing())

# Generated at 2022-06-24 00:27:34.730388
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:27:36.335402
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(True, False).to_validation() == Validation.success(True)
    assert Maybe(None, True).to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:27:39.047978
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # given
    maybe = Maybe.just(10)
    # when
    result = maybe.to_box()
    # then
    assert result.is_success() is True
    assert result.value == maybe.value



# Generated at 2022-06-24 00:27:42.977774
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:27:45.793278
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # check for not empty Maybe
    assert Maybe.just(100).get_or_else(200) == 100
    # check for empty Maybe
    assert Maybe.nothing().get_or_else(200) == 200


# Generated at 2022-06-24 00:27:49.856759
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit tests for Maybe.

    :returns: None
    :rtype: None
    """
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:27:54.054910
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(0) == 5
    assert Maybe.nothing().get_or_else(0) == 0



# Generated at 2022-06-24 00:28:00.733677
# Unit test for method to_either of class Maybe

# Generated at 2022-06-24 00:28:04.760352
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x+1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:28:09.094679
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.just(2).get_or_else(1) != 1
    assert Maybe.nothing().get_or_else(1) == 1
    assert Maybe.nothing().get_or_else(1) != 2



# Generated at 2022-06-24 00:28:10.415269
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)

# Generated at 2022-06-24 00:28:17.205588
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x / 2).ap(Maybe.just(2)) == Maybe.just(1)
    assert Maybe.just(lambda x: x ** 2).ap(Maybe.just(5)) == Maybe.just(25)
    assert Maybe.just(lambda x: x[:2]).ap(Maybe.just('abcd')) == Maybe.just('ab')
    assert Maybe.just(lambda x: x[:2]).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just('abcd')) == Maybe.nothing()


# Generated at 2022-06-24 00:28:19.663340
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, True) == Maybe.nothing()
    assert Maybe(1, False) == Maybe.just(1)


# Generated at 2022-06-24 00:28:24.420550
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test  functionality of method map for class Maybe.
    """
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:28:26.875204
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(4)
    assert Maybe.just(2).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()


# Generated at 2022-06-24 00:28:30.489582
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Box(1) == Maybe(1, False).to_box()
    assert Box(None) == Maybe(None, True).to_box()
    assert Box(None) == Maybe(1, True).to_box()


# Generated at 2022-06-24 00:28:35.464263
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # A = Integer, B = Float
    maybe_of_not_empty = Maybe.just(2)
    maybe_of_empty = Maybe.nothing()

    # Applicative of Fucntion(Integer) -> Float
    applicative_of_not_empty = Maybe.just(4.4)
    applicative_of_empty = Maybe.nothing()

    assert maybe_of_not_empty.ap(applicative_of_not_empty) == Maybe.just(8.8)
    assert maybe_of_not_empty.ap(applicative_of_empty) == Maybe.nothing()
    assert maybe_of_empty.ap(applicative_of_not_empty) == Maybe.nothing()
    assert maybe_of_empty.ap(applicative_of_empty) == Maybe.nothing()


# Generated at 2022-06-24 00:28:40.050926
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:28:43.023951
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just(1)
    assert not maybe.is_nothing
    assert maybe.value == 1

    maybe = Maybe.nothing()
    assert maybe.is_nothing


# Generated at 2022-06-24 00:28:45.191913
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-24 00:28:48.762011
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)