

# Generated at 2022-06-24 00:18:50.722470
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Test to_validation method of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:18:54.315937
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.just(1).to_validation().is_success == True


# Generated at 2022-06-24 00:18:57.833995
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just('foo').to_try() == Try('foo', is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:19:03.508042
# Unit test for constructor of class Maybe
def test_Maybe():
    empty_maybe_1 = Maybe.nothing()
    empty_maybe_2 = Maybe.nothing()
    assert empty_maybe_1 == empty_maybe_2

    maybe_1 = Maybe.just(10)
    maybe_2 = Maybe.just(10)
    assert maybe_1 == maybe_2

    assert maybe_1 != empty_maybe_1
    assert maybe_1 != empty_maybe_2

    assert empty_maybe_1.to_either().is_left()
    assert not empty_maybe_1.to_either().is_right()
    assert empty_maybe_1.to_either().left() == None

    assert not empty_maybe_1.to_try().is_success()
    assert empty_maybe_1.to_try().is_failure()
    assert empty_maybe_1.to_try().value == None

# Generated at 2022-06-24 00:19:06.512078
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe = Maybe.just(1)
    either = maybe.to_either()
    assert either.either(lambda x: x, lambda y: y) == 1
    maybe = Maybe.nothing()
    either = maybe.to_either()
    assert either.either(lambda x: x, lambda y: y) == None


# Generated at 2022-06-24 00:19:08.384681
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:19:13.126622
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('abc') == Maybe.just('abc')
    assert Maybe.just(123) != Maybe.just('abc')
    assert Maybe.just(123) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:19:18.268911
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(
        lambda value: Maybe.just(value + 1)
    ) == Maybe.just(2)

    assert Maybe.just(1).bind(
        lambda value: Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().bind(
        lambda value: Maybe.just(value + 1)
    ) == Maybe.nothing()



# Generated at 2022-06-24 00:19:20.624806
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:19:27.017942
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just("string").map(lambda s: s.upper()) == Maybe.just("STRING")
    assert Maybe.just("string").map(len) == Maybe.just(6)
    assert Maybe.nothing().map(len) == Maybe.nothing()
    assert Maybe.nothing().map(lambda s: s.upper()) == Maybe.nothing()



# Generated at 2022-06-24 00:19:34.109173
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) is 1
    assert Maybe.just(1).get_or_else('') is 1
    assert Maybe.just(1).get_or_else(True) is 1
    assert Maybe.just(1).get_or_else(None) is 1

    assert Maybe.nothing().get_or_else(2) is 2
    assert Maybe.nothing().get_or_else('') is ''
    assert Maybe.nothing().get_or_else(True) is True
    assert Maybe.nothing().get_or_else(None) is None


# Generated at 2022-06-24 00:19:39.317676
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    def foo():
        return 'bar'

    assert Maybe.just('baz').to_lazy() == Lazy(lambda: 'baz')
    try:
        foo()
        assert False
    except Exception:
        assert True
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert foo() == 'bar'



# Generated at 2022-06-24 00:19:43.424143
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def f(x): return x
    a_plus_b = Maybe.just(f)
    a = Maybe.just(1)

    assert a_plus_b.ap(a) == Maybe.just(f(1))


# Generated at 2022-06-24 00:19:48.209520
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    value = Maybe.just(7)
    assert value.to_box().value == 7
    value = Maybe.just(-7)
    assert value.to_box().value == -7
    value = Maybe.just(None)
    assert value.to_box().value == None
    assert Maybe.nothing().to_box().value == None


# Generated at 2022-06-24 00:19:52.846697
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(10).to_try() == Try(10, is_success=True)

# Generated at 2022-06-24 00:19:54.918885
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box().is_present() == True
    assert Maybe(None, True).to_box().is_empty() == True



# Generated at 2022-06-24 00:19:59.579783
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()


# Generated at 2022-06-24 00:20:05.757249
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe.just(10)
    assert maybe.to_validation() == Validation.success(10)
    assert maybe.to_validation() is not Validation.success(10)

    maybe = Maybe.nothing()
    assert maybe.to_validation() == Validation.success(None)
    assert maybe.to_validation() is not Validation.success(None)


# Generated at 2022-06-24 00:20:10.955886
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe1 = Maybe.just(20)
    maybe2 = Maybe.just(20)
    maybe3 = Maybe.just(40)
    maybe4 = Maybe.nothing()
    maybe5 = Maybe.nothing()
    
    assert (maybe1 == maybe2) == True
    assert (maybe1 == maybe3) == False
    assert (maybe1 == maybe4) == False
    assert (maybe4 == maybe5) == True

# Generated at 2022-06-24 00:20:12.831734
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    _maybe = Maybe.just(3)
    _try = _maybe.to_try()

    assert _try.get() == 3


# Generated at 2022-06-24 00:20:15.178520
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(1)

    assert maybe.get_or_else(None) == 1

    maybe = Maybe.nothing()

    assert maybe.get_or_else(None) is None


# Generated at 2022-06-24 00:20:19.811930
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just(3).to_box() == Box(3)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:20:23.970540
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_positive(x): return x > 0
    try:
        assert Maybe.just(None).filter(is_positive) == Maybe.nothing()
        assert Maybe.just(-1).filter(is_positive) == Maybe.nothing()
        assert Maybe.just(0).filter(is_positive) == Maybe.nothing()
        assert Maybe.just(1).filter(is_positive) == Maybe(1, False)
        assert Maybe.nothing().filter(is_positive) == Maybe.nothing()
    except:
        print("ERROR: test_Maybe_filter")
        raise

# Generated at 2022-06-24 00:20:28.007327
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:20:34.877617
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:20:37.813705
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda value: value + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda value: value + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:20:46.864616
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monoid import Id as Identity
    from pymonet.monad_list import List

    # List with one element
    maybe_list_with_one_element = Maybe.just(List.pure(1))

    # filterer return True
    filterer = lambda x: x == 1

    # expected
    expected = Maybe.just(List.pure(1))

    # actual
    actual = maybe_list_with_one_element.filter(filterer)

    # check
    assert expected == actual

    # List with one element
    maybe_list_with_one_element = Maybe.just(List.pure(3))

    # filterer return True
    filterer = lambda x: x == 1

    # expected
    expected = Maybe.nothing()

    # actual
    actual = maybe_list_

# Generated at 2022-06-24 00:20:50.682333
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(1)
    b = Maybe.nothing()
    assert a.filter(lambda x: x > 0) == Maybe.just(1)
    assert a.filter(lambda x: x > 1) == Maybe.nothing()
    assert b.filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-24 00:20:56.546807
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Left(None) == Maybe.nothing().to_either()
    assert Right(10) == Maybe.just(10).to_either()
    assert Right(None) == Maybe.just(None).to_either()


# Generated at 2022-06-24 00:20:59.694563
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    value = Maybe.just(1).to_box()
    assert value.value == 1

    value = Maybe.nothing().to_box()
    assert value.value is None



# Generated at 2022-06-24 00:21:03.709531
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def mapper(x):
        return x + 2
    assert Maybe.just(7).ap(Maybe.just(mapper)) == Maybe.just(9)
    assert Maybe.nothing().ap(Maybe.just(mapper)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:08.784345
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(4).bind(lambda n: Maybe.just(n * n)) == Maybe.just(16)
    assert Maybe.just(4).bind(lambda n: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda n: Maybe.just(n * n)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:12.369252
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != 2



# Generated at 2022-06-24 00:21:13.124989
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:21:16.552181
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(3).to_either() == Either.right(3)
    assert Maybe.nothing().to_either() == Either.left(None)


# Generated at 2022-06-24 00:21:21.597565
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = "value"
    maybe_value = Maybe.just(value)
    maybe_other_value = Maybe.just("other_value")
    lazy_value = maybe_value.to_lazy()
    lazy_other_value = maybe_other_value.to_lazy()
    lazy_none = Maybe.nothing().to_lazy()

    assert lazy_value.get() == value
    assert lazy_other_value.get() == "other_value"
    assert lazy_none.get() == None

    assert isinstance(lazy_value, Lazy)

# Generated at 2022-06-24 00:21:23.625425
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.either import Left

    assert Maybe(5, False) == Maybe.just(5)
    assert Maybe(5, True) == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()



# Generated at 2022-06-24 00:21:31.570605
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe1 = Maybe(1, False)
    maybe2 = Maybe.nothing()

    try1 = Try(1, is_success=True)
    try2 = Try(None, is_success=False)

    assert maybe1.to_try() == try1
    assert maybe2.to_try() == try2


# Generated at 2022-06-24 00:21:34.256365
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Right(None)



# Generated at 2022-06-24 00:21:42.713526
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x + 1).get_or_else(4) == 4
    assert Maybe.just('abc').map(lambda x: x + 'def').get_or_else(4) == 'abcdef'
    assert Maybe.just('abc').map(lambda x: x[-1]).get_or_else(10) == 'c'
    assert Maybe.nothing().map(lambda x: x + 1).get_or_else(5) == 5
    assert Maybe.nothing().map(lambda x: x + 'abc').get_or_else(10) == 10


# Generated at 2022-06-24 00:21:47.089625
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test to_box method.

    >>> from pymonet.maybe import Maybe
    >>> from pymonet.box import Box
    >>> Maybe.just(Box(1)) == Box(1)
    False
    >>> Maybe.just(Box(1)).to_box() == Box(1)
    True
    >>> Maybe.nothing().to_box() == Box(None)
    True
    """

# Generated at 2022-06-24 00:21:50.355437
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:21:55.253292
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(1)


# Generated at 2022-06-24 00:22:00.157597
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Test for Maybe to_try method.

    :returns: true when test passed
    :rtype: boolean
    """
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try.success(1)
    assert Maybe.nothing().to_try() == Try.failure(None)
    return True



# Generated at 2022-06-24 00:22:08.332880
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5).__eq__(Maybe.nothing()) is False
    assert Maybe.nothing().__eq__(Maybe.just(5)) is False



# Generated at 2022-06-24 00:22:12.809413
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:22:14.697045
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe(10, False).to_try() == Try(10, is_success=True)

# Generated at 2022-06-24 00:22:17.051042
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:22:19.569457
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(5).to_validation() == \
        Validation.success(5)
    assert Maybe.nothing().to_validation() == \
        Validation.success(None)


# Generated at 2022-06-24 00:22:21.849948
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:22:27.734931
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:22:29.232017
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:22:33.383207
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:22:36.559733
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    unit_value = 'unit_value'

    assert(Maybe.just(unit_value).get_or_else(None) == unit_value)
    assert(Maybe.nothing().get_or_else(unit_value) == unit_value)


# Generated at 2022-06-24 00:22:39.335470
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe: Maybe[str] = Maybe.just("World")

    assert maybe.to_lazy() == Lazy(lambda: "World")



# Generated at 2022-06-24 00:22:42.860206
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    just_maybe = Maybe.just(5)
    assert just_maybe.to_try() == Try(5, True)
    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_try() == Try(None, False)


# Generated at 2022-06-24 00:22:46.096503
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert (Maybe.just(1).to_either() == Right(1))
    assert (Maybe.nothing().to_either() == Left(None))



# Generated at 2022-06-24 00:22:50.255896
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-24 00:22:53.729505
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('value').to_validation() == Validation.success('value')
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:22:56.142082
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y
    assert Maybe.just(1).ap(Maybe.just(add)) == Maybe.just(2)



# Generated at 2022-06-24 00:22:58.134628
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:02.343229
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filtering Maybe.

    :returns: true if test passed, in other case false
    :rtype: bool
    """
    return Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2) \
        and Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing() \
        and Maybe.nothing().filter(lambda x: x > 20) == Maybe.nothing()


# Generated at 2022-06-24 00:23:05.450076
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Given
    maybe_ = Maybe.just(1)
    maybe_1 = Maybe.nothing()

    # When
    lazy_ = maybe_.to_lazy()
    lazy_1 = maybe_1.to_lazy()

    # Then
    assert lazy_.get() == 1
    assert lazy_1.get() is None



# Generated at 2022-06-24 00:23:07.669892
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of class Maybe

    :return: None
    """
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()



# Generated at 2022-06-24 00:23:11.889693
# Unit test for method map of class Maybe
def test_Maybe_map():

    assert Maybe.just(2).map(lambda x: x ** 2) == Maybe.just(4)
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.just(3).map(lambda x: x / 2) == Maybe.just(1.5)
    assert Maybe.just(3).map(lambda x: x * 2) == Maybe.just(6)
    assert Maybe.just(3).map(lambda x: x).map(lambda x: x) == Maybe.just(3)


# Generated at 2022-06-24 00:23:15.803323
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(3)
    assert Maybe.nothing().bind(lambda _: Maybe.just(1)) == Maybe.nothing()

# Generated at 2022-06-24 00:23:22.984790
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor

    assert Maybe.just(lambda x: x + 3).ap(Functor.just(3)) == Maybe.just(6)
    assert Maybe.nothing().ap(Functor.just(2)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 3).ap(Functor.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Functor.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:23:25.913256
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x * x) == Maybe.just(9)
    assert Maybe.just("Python").map(lambda x: x[::-1]) == Maybe.just("nohtyP")


# Generated at 2022-06-24 00:23:30.479248
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-24 00:23:35.550104
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert (
        Maybe.just(1).filter(lambda n: n > 0) == Maybe.just(1)
    )
    assert (
        Maybe.just(0).filter(lambda n: n > 0) == Maybe.nothing()
    )
    assert (
        Maybe.nothing().filter(lambda n: n > 0) == Maybe.nothing()
    )


# Generated at 2022-06-24 00:23:41.068475
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()
    assert Maybe.just(None).map(lambda x: x * 2) == Maybe.nothing()
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()


# Generated at 2022-06-24 00:23:42.882649
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe = Maybe.just(1)
    assert maybe.to_box() == Box(1)

    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)



# Generated at 2022-06-24 00:23:48.227004
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either of class Maybe.
    """
    from pymonet.either import Either

    maybe = Maybe.just(5)
    assert maybe.to_either() == Either.right(5)
    maybe = Maybe.nothing()
    assert maybe.to_either() == Either.left(None)


# Generated at 2022-06-24 00:23:52.196190
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test case for method bind.

    :returns: None
    """
    from pymonet import _, is_even

    def ensure_is_even(value: int) -> Maybe[int]:
        return Maybe.just(value) if is_even(value) else Maybe.nothing()

    assert Maybe.just(1).bind(ensure_is_even) == Maybe.nothing()
    assert Maybe.just(2).bind(ensure_is_even) == Maybe.just(2)

# Unit tests for method ap of class Maybe

# Generated at 2022-06-24 00:23:55.722923
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(5)



# Generated at 2022-06-24 00:24:00.412724
# Unit test for constructor of class Maybe
def test_Maybe():
    m = Maybe(1, False)
    assert m.value == 1
    assert m.is_nothing is False
    assert Maybe.just(1).value == 1
    assert Maybe.just(1).is_nothing is False
    assert Maybe.nothing().value is None
    assert Maybe.nothing().is_nothing is True


# Generated at 2022-06-24 00:24:05.522203
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    fn = Maybe.just(0).to_lazy().value
    assert fn() == 0

    fn = Maybe.nothing().to_lazy().value
    assert fn() is None

    assert Maybe.just(0).to_lazy() == Lazy(lambda: 0)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:24:09.493818
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(0, True) == Maybe.nothing()
    assert Maybe(1, False) == Maybe.just(1)

# Generated at 2022-06-24 00:24:11.274482
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:21.563171
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    from pymonet.either import Right, Left

    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(4) != Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(10) == 10
    assert Maybe.nothing() != 0
    assert Maybe.just(10) != Right(10)
    assert Maybe.nothing() != Left(10)

    # unit test for method __ne__
    assert Maybe.just(10) != Maybe.just(4)
    assert Maybe.just(10) != 10
    assert Maybe.nothing() != 10



# Generated at 2022-06-24 00:24:24.658583
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert \
        Maybe(42, False).map(lambda x: x * 2) == Maybe(84, False) and \
        Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-24 00:24:27.933115
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(4) == 5
    assert Maybe.nothing().get_or_else(4) == 4



# Generated at 2022-06-24 00:24:34.053152
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4).__eq__(Maybe.just(4))
    assert Maybe.just(4).__eq__(Maybe.just(4.0))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert not Maybe.nothing().__eq__(Maybe.just(None))
    assert not Maybe.just(4).__eq__(Maybe.nothing())



# Generated at 2022-06-24 00:24:43.933499
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Given
    from pymonet.either import Left, Right
    maybe = Maybe.just(None)
    expected_result = Right(None)
    # When
    result = maybe.to_either()
    # Then
    assert result == expected_result
    # Given
    maybe = Maybe.just(1)
    expected_result = Right(1)
    # When
    result = maybe.to_either()
    # Then
    assert result == expected_result
    # Given
    maybe = Maybe.nothing()
    expected_result = Left(None)
    # When
    result = maybe.to_either()
    # Then
    assert result == expected_result


# Generated at 2022-06-24 00:24:48.515124
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:24:51.791278
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:55.141866
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.box import Box

    assert(Box(2).to_maybe().get_or_else(1) == 2)
    assert(Box(None).to_maybe().get_or_else(1) == 1)



# Generated at 2022-06-24 00:25:00.204792
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just("{}".format(x))) == Maybe.just("1")
    assert Maybe.just("abc").bind(lambda x: Maybe.just("{}_{}".format(x, x))) == Maybe.just("abc_abc")
    assert Maybe.nothing().bind(lambda x: Maybe.just("{}".format(x))) == Maybe.nothing()
    assert Maybe.just(2).bind(lambda x: Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:25:02.208780
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:25:10.112090
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > -2) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x > -2) == Maybe.nothing()


# Generated at 2022-06-24 00:25:13.303484
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(5, False).bind(lambda x: Maybe(x + 2, False)) == Maybe(7, False)
    assert Maybe(None, True).bind(lambda x: Maybe(x + 2, False)) == Maybe(None, True)


# Generated at 2022-06-24 00:25:15.925084
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(20) == 1
    assert Maybe.nothing().get_or_else(20) == 20


# Generated at 2022-06-24 00:25:20.490822
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != [1]


# Generated at 2022-06-24 00:25:25.131588
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    m_1 = Maybe.just(5)
    assert m_1.get_or_else(3) == 5
    m_2 = Maybe.nothing()
    assert m_2.get_or_else(3) == 3

test_Maybe_get_or_else()

# Generated at 2022-06-24 00:25:28.964065
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()
    assert Maybe.just(None).map(lambda x: x * 2) == Maybe.nothing()


# Generated at 2022-06-24 00:25:31.181579
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(0).get_or_else(-1) == 0
    assert Maybe.nothing().get_or_else(-1) == -1


# Generated at 2022-06-24 00:25:36.972913
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-24 00:25:39.629428
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    f = lambda x: Maybe.just(x+2)

    assert Maybe.just(2).bind(f) == Maybe.just(4)
    assert Maybe.nothing().bind(f) == Maybe.nothing()



# Generated at 2022-06-24 00:25:42.295637
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe = Maybe.just(4)
    assert maybe.get_or_else(-1) == 4
    maybe = Maybe.nothing()
    assert maybe.get_or_else(-1) == -1


# Generated at 2022-06-24 00:25:45.150086
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(2, True)
    assert Maybe(1, False) != Maybe(2, False)


# Generated at 2022-06-24 00:25:48.781566
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just('value').filter(lambda value: value == 'value') == Maybe.just('value')
    assert Maybe.nothing().filter(lambda value: False) == Maybe.nothing()
    assert Maybe.just('value').filter(lambda value: False) == Maybe.nothing()

# Generated at 2022-06-24 00:25:52.427414
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)

# Generated at 2022-06-24 00:25:54.433416
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(2).bind(lambda a: Maybe.just(a + 4)) == Maybe.just(6)
    assert Maybe.nothing().bind(lambda a: Maybe.just(a + 4)) == Maybe.nothing()


# Generated at 2022-06-24 00:25:58.918192
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just(1).bind(lambda x: Maybe.just(x + x))
    assert result == Maybe.just(2)

    result = Maybe.just(1).bind(lambda x: Maybe.nothing())
    assert result == Maybe.nothing()

    result = Maybe.nothing().bind(lambda x: Maybe.just(x))
    assert result == Maybe.nothing()



# Generated at 2022-06-24 00:26:00.531572
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)



# Generated at 2022-06-24 00:26:11.380287
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # GIVEN
    maybe = Maybe.just(5)
    mapper = lambda x: Maybe.just(x + 2)

    # WHEN
    result = maybe.bind(mapper)

    # THEN
    expected = Maybe.just(7)
    assert result == expected

    # GIVEN
    maybe = Maybe.just(5)

    # WHEN
    result = maybe.bind(lambda x:
                        Maybe.nothing())

    # THEN
    expected = Maybe.nothing()
    assert result == expected

    # GIVEN
    maybe = Maybe.nothing()
    mapper = lambda x: Maybe.just(x + 2)

    # WHEN
    result = maybe.bind(mapper)

    # THEN
    expected = Maybe.nothing()
    assert result == expected



# Generated at 2022-06-24 00:26:17.075864
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Test for method to_validation of class Maybe.
    """
    from pymonet.validation import Validation

    val1 = Maybe.just(1)
    exp_val1 = Validation.success(1)
    assert val1.to_validation() == exp_val1

    val2 = Maybe.nothing()
    exp_val2 = Validation.success(None)
    assert val2.to_validation() == exp_val2

    print('test_Maybe_to_validation ok!')
test_Maybe_to_validation()


# Generated at 2022-06-24 00:26:22.186000
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 5) == Maybe.nothing()



# Generated at 2022-06-24 00:26:24.619410
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(8).bind(lambda x: Maybe.just(x * 10)) == Maybe.just(80)



# Generated at 2022-06-24 00:26:28.095084
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:32.982292
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit tests for method to_lazy of class Maybe.

    :returns: nothing
    :rtype: None
    """
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:26:38.988960
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    with pytest.raises(AttributeError):
        Maybe.just(3).ap()
    def test_func(x):
        return x ** 2
    assert Maybe.just(test_func).ap(Maybe.just(3)) == Maybe.just(9)
    assert Maybe.just(test_func).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:26:43.037234
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    empty_maybe = Maybe(None, True)
    maybe_value = Maybe(5, False)

    def add_1(number):
        return number + 1

    applicative_add_1 = Maybe(add_1, False)
    assert empty_maybe.ap(applicative_add_1) == Maybe.nothing()
    assert maybe_value.ap(empty_maybe) == Maybe.nothing()
    assert maybe_value.ap(applicative_add_1) == Maybe.just(6)


# Generated at 2022-06-24 00:26:44.892715
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(1) == Maybe.just(1))
    assert(Maybe.nothing() == Maybe.nothing())
    assert(Maybe.just(1) != Maybe.just(2))
    assert(Maybe.just(1) != Maybe.nothing())
    assert(Maybe.nothing() != Maybe.just(1))


# Generated at 2022-06-24 00:26:47.580137
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    maybe = Maybe.just(1)
    from pymonet.box import Box

    assert maybe.to_box() == Box(1)



# Generated at 2022-06-24 00:26:55.147286
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Try.success(1) != Maybe.just(1)
    assert Try.failure(1) != Maybe.just(1)


# Generated at 2022-06-24 00:26:59.609862
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left
    from pymonet.monad_try import Try, handle_error

    expected = Try(0, is_success=True)

    @handle_error
    def handle_value(value) -> 'Either[int, int]':
        return Left(10)

    actual = Maybe.just(None).bind(handle_value).to_try()

    assert actual == expected

# Generated at 2022-06-24 00:27:00.797378
# Unit test for constructor of class Maybe
def test_Maybe():
    a = Maybe(None, True)
    assert a is not None



# Generated at 2022-06-24 00:27:03.125792
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    f = lambda e: Maybe.just(e + 1)
    assert Maybe.just(1).bind(f) == Maybe.just(2)
    assert Maybe.nothing().bind(f) == Maybe.nothing()



# Generated at 2022-06-24 00:27:05.394992
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda val: val < 12) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda val: val > 12) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda val: val > 12) == Maybe.nothing()

# Generated at 2022-06-24 00:27:12.225013
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing())
    assert(Maybe.just(1).filter(lambda x: x == 1).filter(lambda x: x == 2) == Maybe.nothing())
    assert(Maybe.just(1).filter(lambda x: x == 2).filter(lambda x: x == 2) == Maybe.nothing())


# Generated at 2022-06-24 00:27:16.277037
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe(1, False).to_box().map(lambda x: x + 1) == Box(2)
    assert Maybe.nothing().to_box().map(lambda x: x + 1) == Box(None)


# Generated at 2022-06-24 00:27:19.816442
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    maybe = Maybe.just(1)
    assert maybe.bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)



# Generated at 2022-06-24 00:27:24.453040
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just('test').bind(lambda x: Maybe.just(x == 'test')) == Maybe.just(True)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x == 'test')) == Maybe.nothing()



# Generated at 2022-06-24 00:27:29.382460
# Unit test for constructor of class Maybe
def test_Maybe():
    nothing_maybe = Maybe.nothing()
    just_maybe = Maybe.just(10)

    assert nothing_maybe.is_nothing
    assert not hasattr(nothing_maybe, 'value')
    assert not just_maybe.is_nothing
    assert hasattr(just_maybe, 'value')
    assert just_maybe.value == 10



# Generated at 2022-06-24 00:27:35.502758
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(5)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-24 00:27:37.704325
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(3, False).get_or_else(9) == 3
    assert Maybe(None, True).get_or_else(9) == 9


# Generated at 2022-06-24 00:27:39.832406
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-24 00:27:42.690169
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:27:44.588879
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(2).to_box() == Box(2)


# Generated at 2022-06-24 00:27:50.889291
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.test_utils import assert_just_nothing, assert_eq

    def mult_two(value):
        return Maybe.just(value * 2)

    def mult_two_and_fail(value):
        return Maybe.just(value * 2) if value % 2 == 0 else Maybe.nothing()

    assert_just_nothing(Maybe.just(3).bind(mult_two), Maybe.just(6))
    assert_just_nothing(Maybe.just(4).bind(mult_two), Maybe.just(8))
    assert_just_nothing(Maybe.nothing().bind(mult_two), Maybe.nothing())
    assert_just_nothing(Maybe.just(3).bind(mult_two_and_fail), Maybe.nothing())

# Generated at 2022-06-24 00:28:01.303507
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Maybe.just(lambda x: 3 * x).ap(Maybe.just(5)) == Maybe.just(15)
    assert Maybe.just(lambda x: 3 * x).ap(Box(5)) == Maybe.just(15)
    assert Maybe.just(lambda x: 3 * x).ap(Validation.success(5)) == Maybe.just(15)
    assert Maybe.just(lambda x: 3 * x).ap(Try(5, is_success=True)) == Maybe.just(15)
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe.nothing().ap(Box(5)) == Maybe.nothing()
    assert Maybe.nothing().ap

# Generated at 2022-06-24 00:28:08.872619
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.try_ import Try
    try1 = Try(1, is_success=True)
    try2 = Try(2, is_success=True)
    m1 = Maybe.just(try1)
    m2 = Maybe.just(try2)
    print(m1.to_validation())
    print(m2.to_validation())

# Generated at 2022-06-24 00:28:13.062515
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:28:20.787915
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.just(32)
    result = maybe.map(lambda x: x * 2)
    assert result == Maybe.just(64)
    result = maybe.map(lambda x: x ** 2)
    assert result == Maybe.just(1024)
    maybe = Maybe.nothing()
    result = maybe.map(lambda x: x * 2)
    assert result == Maybe.nothing()
    result = maybe.map(lambda x: x ** 2)
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:28:24.253721
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(1).to_lazy() == Lazy(lambda: 1))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))



# Generated at 2022-06-24 00:28:34.406942
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).value == 1
    assert Maybe.just(1).is_nothing == False
    assert Maybe.nothing().value == None
    assert Maybe.nothing().is_nothing == True
    assert Maybe(1, False).__eq__(Maybe.just(1))
    assert Maybe(None, True).__eq__(Maybe.nothing())
    assert Maybe(1, False).__eq__(Maybe(1, False))
    assert Maybe(None, True).__eq__(Maybe(None, True))
    assert Maybe(1, False).__eq__(Maybe(2, False)) == False
    assert Maybe(1, False).__eq__(Maybe(None, True)) == False


# Generated at 2022-06-24 00:28:37.208249
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('test').get_or_else('') == 'test'
    assert Maybe.nothing().get_or_else('') == ''



# Generated at 2022-06-24 00:28:41.927579
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from nose.tools import assert_equals

    assert_equals(
        Maybe.just(1).to_lazy(),
        Lazy(lambda: 1)
    )

    assert_equals(
        Maybe.nothing().to_lazy(),
        Lazy(lambda: None)
    )


# Generated at 2022-06-24 00:28:46.336596
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Maybe.just(1).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()

