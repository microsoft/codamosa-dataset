

# Generated at 2022-06-24 00:18:46.746737
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    expected = Maybe.just(Validation.success(1))
    result = Maybe.just(1).to_validation()

    assert expected == result

# Generated at 2022-06-24 00:18:48.952544
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-24 00:18:57.795498
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Validation
    from pymonet.box import Box

    m1 = Maybe.just(lambda x: x + 1)
    m2 = Maybe.just(2)

    assert m1.ap(m2) == Maybe.just(3)
    assert m1.ap(m2).to_box() == Box(3)
    assert m1.ap(m2).to_validation() == Validation.success(3)
    success_validation = Validation.success(2)
    assert m1.ap(success_validation).to_box() == Box(3)
    assert m1.ap(success_validation).to_validation() == Validation.success(3)

    m1 = Maybe.just(lambda x: x + 1)
    m2 = Maybe.nothing()

   

# Generated at 2022-06-24 00:19:04.636522
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(1).filter(
        lambda x: x == 1
    )
    assert m == Maybe.just(1)

    m = Maybe.just('aaa').filter(
        lambda x: x == 'aaa'
    )
    assert m == Maybe.just('aaa')

    m = Maybe.just(0.0).filter(
        lambda x: x == 0.0
    )
    assert m == Maybe.just(0.0)

    m = Maybe.just(True).filter(
        lambda x: x is True
    )
    assert m == Maybe.just(True)

    m = Maybe.just([]).filter(
        lambda x: x == []
    )
    assert m == Maybe.just([])

    m = Maybe.just({'a': 'a', 'b': 'b'}).filter

# Generated at 2022-06-24 00:19:08.995849
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :returns: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    def foo():
        return 3

    lazy_obj = Lazy(foo)
    maybe_obj = Maybe.just(2)

    assert(maybe_obj.to_lazy() == lazy_obj)

    maybe_obj = Maybe.nothing()

    assert(maybe_obj.to_lazy().eval() is None)



# Generated at 2022-06-24 00:19:12.014994
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:19:15.504512
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:19:19.966308
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-24 00:19:23.154531
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().eval() == 1



# Generated at 2022-06-24 00:19:29.818162
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(10).filter(lambda x: x > 5)
    assert isinstance(m, Maybe)
    assert m == Maybe.just(10)

    m = Maybe.just(10).filter(lambda x: x > 15)
    assert isinstance(m, Maybe)
    assert m == Maybe.nothing()

    m = Maybe.nothing().filter(lambda x: x > 5)
    assert isinstance(m, Maybe)
    assert m == Maybe.nothing()


# Generated at 2022-06-24 00:19:32.249154
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    maybe_10 = Maybe.just(10)
    maybe_5 = Maybe.just(5)

    mapper = lambda x: Maybe.just(x + 5)
    mapped_maybe = maybe_10.bind(mapper)

    assert mapped_maybe == maybe_5

# Unit test of method map of class Maybe

# Generated at 2022-06-24 00:19:38.034999
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True), "Maybe.Nothing() should be Maybe(None, True)"
    assert Maybe.just(1) == Maybe(1, False), "Maybe.Nothing() should be Maybe(None, True)"
    assert Maybe.nothing() is not Maybe.nothing(), "Maybe.Nothing() should be unique"
    assert Maybe.just(1) is not Maybe.just(1), "Maybe.Nothing() should be unique"

# Unit tests for map function of class Maybe

# Generated at 2022-06-24 00:19:41.285507
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    actual = Maybe.just(2).to_validation()
    expected = Validation.success(2)
    assert actual == expected


# Generated at 2022-06-24 00:19:43.961501
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1).is_nothing is False
    assert Maybe.just(1).value == 1


# Generated at 2022-06-24 00:19:47.109544
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:19:50.969817
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe.
    """
    from pymonet.either import Left, Right
    m = Maybe.just("something")
    assert m.to_either() == Right("something")
    m = Maybe.nothing()
    assert m.to_either() == Left(None)


# Generated at 2022-06-24 00:19:53.055859
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # for not empty Maybe
    assert Maybe.just(42).to_try() == Try(42, is_success=True)

    # for empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:19:56.213180
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-24 00:19:59.380022
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(12, False).to_try() == Try(12)
    assert Maybe.nothing().to_try() == Try(None, False)



# Generated at 2022-06-24 00:20:03.584106
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    just = Maybe.just(1)
    nothing = Maybe.nothing()
    assert just.to_try() == Try(1)
    assert nothing.to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:20:08.834188
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)
    

# Generated at 2022-06-24 00:20:11.520929
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe('test').map(str.upper) == Maybe.just('TEST')
    assert Maybe(None).map(str.upper) == Maybe.nothing()


# Generated at 2022-06-24 00:20:13.658921
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:20:18.668805
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor

    assert Maybe.just(lambda x: x).ap(Maybe.just(6)) == Functor.just(6)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(6)) == Functor.just(12)
    assert Maybe.nothing().ap(Maybe.just(6)) == Functor.just(None)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Functor.just(None)
    assert Maybe.nothing().ap(Maybe.nothing()) == Functor.just(None)



# Generated at 2022-06-24 00:20:20.266292
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-24 00:20:24.360268
# Unit test for method map of class Maybe
def test_Maybe_map():
    result = Maybe.just(1).map(lambda x: x + 1)

    assert isinstance(result, Maybe)
    assert result.value == 2
    assert isinstance(Maybe.nothing().map(lambda x: x + 1), Maybe)
    assert Maybe.nothing().map(lambda x: x + 1).is_nothing == True



# Generated at 2022-06-24 00:20:29.070821
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-24 00:20:36.623956
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.maybe import Maybe

    assert Maybe.just([lambda x: x + 2]).ap(Maybe.just(1)) == Maybe.just(3)
    assert Maybe.just([lambda x: x + 2]).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:20:41.958997
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-24 00:20:46.259867
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe_one = Maybe.just(lambda x: x + 1)
    assert maybe_one.ap(Maybe.just(1)) == Maybe.just(2)
    assert maybe_one.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(10)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:20:49.813451
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:20:53.210333
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:20:56.138787
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    monad = Maybe.just(1)
    assert monad.get_or_else(0) == 1
    monad = Maybe.nothing()
    assert monad.get_or_else(0) == 0

# Generated at 2022-06-24 00:20:59.940612
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(lambda x: x * 2)
    assert maybe.to_lazy() == Lazy(maybe.value)


# Generated at 2022-06-24 00:21:09.048894
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for Maybe class.

    :type actual: Boolean
    """
    expected = Maybe.just(11)
    actual = Maybe.just(11).filter(lambda x: True)
    assert expected == actual

    expected = Maybe.nothing()
    actual = Maybe.just(11).filter(lambda x: False)
    assert expected == actual

    expected = Maybe.nothing()
    actual = Maybe.nothing().filter(lambda x: True)
    assert expected == actual

    expected = Maybe.nothing()
    actual = Maybe.nothing().filter(lambda x: False)
    assert expected == actual



# Generated at 2022-06-24 00:21:13.158902
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add1(x):
        return x + 1

    def add2(x):
        return x + 2

    assert Maybe.just(add1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(add1).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:21:15.926974
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(Box(5)).filter(lambda x: x.value > 2) == Maybe.just(Box(5))
    assert Maybe.just(5).filter(lambda x: x > 8) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-24 00:21:19.495367
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just("test").get_or_else("default") == "test"
    assert Maybe.nothing().get_or_else("default") == "default"


# Generated at 2022-06-24 00:21:20.683060
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(20, is_nothing=False).to_lazy() == Lazy(lambda: 20)
    assert Maybe(None, is_nothing=True).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:21:29.160114
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Either
    from pymonet.lazy import Lazy

    def lazy_fib(n):
        def fib(n, curr, next):
            if n == 0:
                return curr
            else:
                return fib(n - 1, next, curr + next)
        return fib(n, 1, 1)

    assert Maybe.just(10).to_lazy() == Lazy(lambda: lazy_fib(10))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:21:32.083970
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:34.481961
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.just(11).filter(lambda x: x % 2 == 1) == Maybe.just(11)
    assert Maybe.just(None).filter(lambda x: x % 2 == 1) == Maybe.nothing()

# Generated at 2022-06-24 00:21:41.890720
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # bind in Maybe call mapper and return new Maybe with result of mapper.
    # If Maybe is empty return new empty Maybe
    m = Maybe.just('Hello world').bind(lambda x: Maybe.just(x.split()))
    assert m == Maybe.just(['Hello', 'world'])
    m = Maybe.nothing().bind(lambda x: Maybe.just(x.split()))
    assert m == Maybe.nothing()


# Generated at 2022-06-24 00:21:43.835322
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:21:45.358428
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('hi').to_validation() == Validation.success('hi')
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:48.336621
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(value):
        return value % 2 == 0

    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.just(1).filter(is_even) == Maybe.nothing()
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()


# Generated at 2022-06-24 00:21:55.722319
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def bind_mapper(x):
        if x > 5:
            return Right(x)
        else:
            return Left(x)

    assert Maybe.just(6).bind(bind_mapper) == Right(6)
    assert Maybe.just(3).bind(bind_mapper) == Left(3)
    assert Maybe.nothing().bind(bind_mapper) == Maybe.nothing()

    def bind_mapper_try(x):
        if x > 5:
            return Try(x)
        else:
            return Try(x, is_success=False)

    assert Maybe.just(6).bind(bind_mapper_try) == Try(6)


# Generated at 2022-06-24 00:21:59.708962
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)

    assert Maybe.just(42).to_validation() == Validation.success(42)


# Generated at 2022-06-24 00:22:04.519278
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    left = Maybe.just('a')
    right = Maybe.just('a')
    assert left == right
    left = Maybe.just('b')
    assert left != right
    assert left != None
    left = Maybe.nothing()
    right = Maybe.nothing()
    assert left == right
    assert left != Maybe.just('c')
    assert Maybe.just('d') != Maybe.nothing()

# Unit tests for method just of class Maybe

# Generated at 2022-06-24 00:22:10.451216
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test method __eq__ of class Maybe.

    :returns: None
    """
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(2)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)



# Generated at 2022-06-24 00:22:13.773357
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(10)) == Maybe.just(20)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(10)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:22:16.626710
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    # success Try
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    # fail Try
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:22:18.905507
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just('foo').to_box() == Box('foo')
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:22:23.776479
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.just(10).to_lazy().get() == 10
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy().get() is None



# Generated at 2022-06-24 00:22:25.885946
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(12).filter(lambda x: x > 10) == Maybe.just(12)
    assert Maybe.just(12).filter(lambda x: x < 10) == Maybe.nothing()

# Generated at 2022-06-24 00:22:28.118226
# Unit test for constructor of class Maybe
def test_Maybe():
    Maybe(1, is_nothing=False)
    Maybe(None, is_nothing=True)

# Unit tests for method Maybe.just

# Generated at 2022-06-24 00:22:29.859487
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box().value == 1
    assert Maybe.nothing().to_box().value is None


# Generated at 2022-06-24 00:22:37.800420
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # filter with empty maybe
    maybe = Maybe.nothing()
    res = maybe.filter(lambda x: x > 4)
    assert res == Maybe.nothing()

    # filter with not empty maybe
    maybe = Maybe.just(3)
    res = maybe.filter(lambda x: x > 4)
    assert res == Maybe.nothing()

    # filter with not empty maybe and correct result
    maybe = Maybe.just(5)
    res = maybe.filter(lambda x: x > 4)
    assert res == Maybe.just(5)


# Generated at 2022-06-24 00:22:40.639460
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:22:50.004713
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    m = Maybe.just(10)
    # act
    filtered_m = m.filter(lambda x: x > 5)
    # assert
    assert isinstance(filtered_m, Maybe)
    assert filtered_m.is_nothing == False
    assert filtered_m.value == 10
    # act
    filtered_m = m.filter(lambda x: x > 15)
    # assert
    assert isinstance(filtered_m, Maybe)
    assert filtered_m.is_nothing == True
    # act
    filtered_m = Maybe.nothing().filter(lambda x: x > 15)
    # assert
    assert isinstance(filtered_m, Maybe)
    assert filtered_m.is_nothing == True


# Generated at 2022-06-24 00:22:53.730561
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda num: num * 4) == Maybe.just(8)
    assert Maybe.nothing().map(lambda num: num * 4) == Maybe.nothing()


# Generated at 2022-06-24 00:22:59.833514
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Execute test for method filter of class Maybe. Check that filterer returns False,
    we should have empty maybe as result, all other cases should return new maybe with same value.

    :returns: None
    """
    from pymonet.functions import identity

    assert Maybe.just(3).filter(lambda a: a > 5).to_box() == Box(None), 'Maybe.filter: Not empty maybe and filterer returns False should return empty maybe'
    assert Maybe.nothing().filter(identity).to_box() == Box(None), 'Maybe.filter: Empty maybe should return empty maybe'



# Generated at 2022-06-24 00:23:06.435915
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just(1).bind(lambda x: Maybe.just(x + 1))
    assert result == Maybe.just(2)

    result = Maybe.nothing().bind(lambda x: Maybe.just(x + 1))
    assert result == Maybe.nothing()

    result = Maybe.just(1).bind(lambda x: Maybe.nothing())
    assert result == Maybe.nothing()

test_Maybe_bind()


# Generated at 2022-06-24 00:23:08.387857
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(1, False).get_or_else(2) == 1
    assert Maybe(1, True).get_or_else(2) == 2


# Generated at 2022-06-24 00:23:10.029619
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:23:15.959931
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:23:20.207630
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == \
           Right(1)

    assert Maybe(None, True).to_either() == \
           Left(None)


# Generated at 2022-06-24 00:23:23.210690
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(5, False).get_or_else(None) == 5
    assert Maybe(None, True).get_or_else(None) is None
    assert Maybe(None, True).get_or_else(0) == 0


# Generated at 2022-06-24 00:23:27.709948
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe(42, False) == Maybe.just(42)
    assert Maybe.just(42) == Maybe.just(42)

    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(42) != 42
    assert Maybe.just(42) != Maybe(42, True)

# Generated at 2022-06-24 00:23:33.283492
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    The test checks if Maybe is converted to Either correctly
    """
    from pymonet.either import Left, Right

    m1 = Maybe.just(2)
    result1 = m1.to_either()
    m2 = Maybe.nothing()
    result2 = m2.to_either()
    is_correct1 = isinstance(result1, Right) and result1.value == 2
    is_correct2 = isinstance(result2, Left) and result2.value is None
    assert is_correct1 and is_correct2



# Generated at 2022-06-24 00:23:36.259332
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(3).to_validation() == Validation.success(3)


# Generated at 2022-06-24 00:23:40.283994
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('123') == Maybe.just('123')
    assert Maybe.just('123') != Maybe.just('124')
    assert Maybe.just('124') != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:23:44.462593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    assert maybe.filter(lambda x: x != 1) == Maybe.nothing()
    maybe = Maybe.just(1)
    assert maybe.filter(lambda x: x == 1) == Maybe.just(1)
    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:23:49.463620
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def check_Maybe_failure(maybe, result):
        assert maybe.get_or_else(None) is None
        assert maybe.to_either() == Right(None)
        assert maybe.to_box() == Box(None)
        assert maybe.to_lazy() == Lazy(lambda: None)
        assert maybe.to_try() == Try(None, success=False)
        assert maybe.to_validation() == Validation.success(None)
        assert maybe.map(result) == Maybe.nothing()
        assert maybe.bind(result) == Maybe.nothing()
        assert maybe

# Generated at 2022-06-24 00:23:50.819916
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(4).to_lazy().force() == 4
    assert Maybe.nothing().to_lazy().force() is None


# Generated at 2022-06-24 00:23:55.846557
# Unit test for method map of class Maybe
def test_Maybe_map():
    NoneType = type(None)

# Generated at 2022-06-24 00:24:00.904758
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != 1


# Generated at 2022-06-24 00:24:02.065203
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:24:06.741337
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test function for Maybe.to_lazy method.

    :return: None
    :rtype: NoneType
    """
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-24 00:24:09.005085
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either, Right, Left

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)


# Generated at 2022-06-24 00:24:12.672627
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from random import choice, randint

    maybe_ = Maybe.just(randint(1, 10))
    assert maybe_.get_or_else(choice([None, "test"])) == maybe_.value

    maybe_ = Maybe.nothing()
    assert maybe_.get_or_else(choice([None, "test"])) is None or maybe_.get_or_else(choice([None, "test"])) == "test"

# Generated at 2022-06-24 00:24:17.173863
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    result = Maybe.just(1).to_either()
    print(result)


if __name__ == "__main__":
    test_Maybe_to_either()

# Generated at 2022-06-24 00:24:23.001959
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    assert Lazy(lambda: Maybe.just(5)).to_lazy().value() == Lazy(lambda: 5)
    assert Lazy(lambda: Maybe.nothing()).to_lazy().value() == Lazy(lambda: None)

    assert Lazy(lambda: Maybe.just(5)).to_maybe().to_lazy().value() == Lazy(lambda: 5)
    assert Lazy(lambda: Maybe.nothing()).to_maybe().to_lazy().value() == Lazy(lambda: None)


# Generated at 2022-06-24 00:24:26.406546
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(2).to_try() == Try(2)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:29.184353
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:24:34.665380
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(4, False).filter(lambda x: x % 2 == 0) == Maybe(4, False)
    assert Maybe(4, False).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(3, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-24 00:24:38.536867
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:24:42.063126
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().run().result == Maybe.just(1).value  # type: ignore
    assert Maybe.nothing().to_lazy().run().result == Maybe.nothing().value  # type: ignore


# Generated at 2022-06-24 00:24:45.850180
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    import pytest

    result = Maybe.just(lambda x: x + 1).ap(Maybe.just(1))
    assert result == Maybe.just(2)

    result = Maybe.nothing().ap(Maybe.just(1))
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:24:48.451882
# Unit test for constructor of class Maybe
def test_Maybe():
    x = Maybe(1, False)
    assert x.value == 1
    assert x.is_nothing == False

    y = Maybe(None, True)
    assert y.is_nothing

    with pytest.raises(AttributeError):
        _ = y.value



# Generated at 2022-06-24 00:24:56.663239
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test for default constructor
    just_maybe = Maybe.just(123)
    assert just_maybe.value == 123
    assert not just_maybe.is_nothing

    nothing_maybe = Maybe.nothing()
    assert nothing_maybe.is_nothing

    # Test for __eq__
    assert just_maybe == Maybe.just(123)
    assert not just_maybe == Maybe.just(456)
    assert just_maybe != Maybe.just(456)
    assert nothing_maybe == Maybe.nothing()
    assert not nothing_maybe == Maybe.just(123)
    assert nothing_maybe != Maybe.just(123)



# Generated at 2022-06-24 00:25:00.308861
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    val = Maybe.nothing().to_validation()
    assert isinstance(val, Validation.Success)
    assert val.value is None

    val = Maybe.just(5).to_validation()
    assert isinstance(val, Validation.Success)
    assert val.value == 5



# Generated at 2022-06-24 00:25:06.800597
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def equals(m1: Maybe[int], m2: Maybe[int]) -> bool:
        return m1 == m2

    assert equals(Maybe.just(2), Maybe.nothing()) == False
    assert equals(Maybe.just(2), Maybe.just(3)) == False
    assert equals(Maybe.just(3), Maybe.just(3)) == True
    assert equals(Maybe.nothing(), Maybe.nothing()) == True


# Generated at 2022-06-24 00:25:10.704693
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:12.089308
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(5, False).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:25:19.747010
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_identity import Identity
    ident = Maybe.just(Identity(5))
    result = ident.bind(lambda a: Maybe.just(Identity(a.value * 2)))
    result2 = ident.bind(lambda a: Maybe.just(Identity(a.value / 0)))
    assert result == Maybe.just(Identity(10))
    assert result2 == Maybe.nothing()


# Generated at 2022-06-24 00:25:23.755845
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:25:26.764209
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:25:30.080829
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(f)


# Generated at 2022-06-24 00:25:35.439824
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:25:41.904450
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.pair import Pair
    from pymonet.box import Box

    assert Maybe.just(2).ap(
        Maybe.just(lambda x: x + 5)
    ) == Maybe.just(7)

    assert Maybe.just(2).ap(
        Maybe.nothing()
    ) == Maybe.nothing()

    assert Maybe.nothing().ap(
        Maybe.just(lambda x: x + 5)
    ) == Maybe.nothing()

    assert Maybe.just(
        Pair(lambda x: x + 5, 2)
    ).ap(Box(lambda f, x: f(x))) == Maybe.just(7)

# Generated at 2022-06-24 00:25:44.562700
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just("test").to_try() == Try("test", is_success=True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-24 00:25:48.894341
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.just(1)

    def mapper_one_plus(a):
        return a + 1

    maybe = maybe.map(mapper_one_plus)

    assert maybe == Maybe.just(2)

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:55.356217
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test method from Maybe to Box.
    """
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box

    mb = Maybe.just(1)
    b = Box(1)

    assert mb.to_box() == b, "Test fail"

    mb = Maybe.nothing()
    b = Box(None)

    assert mb.to_box() == b, "Test fail"


# Generated at 2022-06-24 00:25:58.060171
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either

    assert Maybe.just(5).to_either() == Either.right(5)
    assert Maybe.nothing().to_either() == Either.left(None)



# Generated at 2022-06-24 00:26:01.129807
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(2).to_either().left_value is None
    assert Maybe.just(2).to_either().right_value == 2
    assert Maybe.nothing().to_either().right_value is None
    assert Maybe.nothing().to_either().left_value is None


# Generated at 2022-06-24 00:26:03.823247
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:08.961344
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.just(3).get_or_else(4) == 3
    assert Maybe.nothing().get_or_else(5) == 5
    assert Maybe.nothing().get_or_else(6) == 6



# Generated at 2022-06-24 00:26:17.045894
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # pymonet.maybe.Nothing().bind(lambda x: pymonet.maybe.Nothing()) == pymonet.maybe.Nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    # pymonet.maybe.Nothing().bind(lambda x: pymonet.maybe.just(2 * x)) == pymonet.maybe.Nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(2 * x)) == Maybe.nothing()
    # pymonet.maybe.just(1).bind(lambda x: pymonet.maybe.Just(2 * x)) == pymonet.maybe.Just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.just(2 * x)) == Maybe.just(2)
    # pymonet.maybe.just(1).bind

# Generated at 2022-06-24 00:26:20.687200
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:26:24.530392
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:26:30.788872
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.just(5).map(lambda x: x) == Maybe.just(5)
    assert Maybe.just(5).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-24 00:26:34.275830
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else('sdg') == 'sdg'
    assert Maybe.just(12).get_or_else('sdg') == 12



# Generated at 2022-06-24 00:26:37.683268
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.just(10).to_box().map(lambda x: x + 1) == Box(11)


# Generated at 2022-06-24 00:26:43.746954
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    value = "hello"

    def maybe_to_try():
        return Maybe.just(value).to_try()

    assert maybe_to_try() == Try(value, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


if __name__ == '__main__':
    test_Maybe_to_try()

# Generated at 2022-06-24 00:26:49.881923
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def get_maybe_value(maybe):
        return maybe.to_lazy().evaluate()

    def get_lazy_value(lazy):
        return lazy.evaluate()

    assert get_maybe_value(Maybe.just(1)) == get_lazy_value(Lazy(lambda: 1))
    assert get_maybe_value(Maybe.nothing()) == get_lazy_value(Lazy(lambda: None))


# Generated at 2022-06-24 00:26:52.687347
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:26:55.388909
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_list import List

    list_from_maybe = List([1, 2, 3]).bind(
        lambda x: Maybe.just(
            x + 1
        )
    )

    assert list_from_maybe == List([2, 3, 4])

    assert List([1, 2, 3]).bind(
        lambda x: Maybe.bind(
            x + 1
        )
    ) == List([1, 2, 3])

# Generated at 2022-06-24 00:27:01.843048
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Arrange
    from pymonet.point import Point

    # Act
    maybe_point = Maybe.just(Point(1, 3))
    maybe_mapped = maybe_point.map(lambda point: point.mul_by(Point(1, 2)))

    # Assert
    assert maybe_mapped == Maybe.just(Point(1, 6))



# Generated at 2022-06-24 00:27:03.893284
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:27:05.015721
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:27:07.108579
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:27:11.680046
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(1)
    maybe_3 = Maybe.just(2)

    assert maybe_1 == maybe_2
    assert maybe_2 == maybe_1
    assert maybe_1 != maybe_3



# Generated at 2022-06-24 00:27:13.703355
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.nothing()

# Generated at 2022-06-24 00:27:17.463447
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Maybe.just(3).to_either() == Right(3)
    assert Maybe.nothing().to_either() == Left(None)

    box = Box(3)
    assert Maybe.just(box).to_either() == Right(box)



# Generated at 2022-06-24 00:27:18.807018
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)


# Generated at 2022-06-24 00:27:21.852112
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(111) == 42
    assert Maybe.nothing().get_or_else(111) == 111
    assert Maybe.nothing().get_or_else(None) == None
    assert Maybe.just(None).get_or_else(111) == None


# Generated at 2022-06-24 00:27:27.091907
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()
    lazy_value = lazy.force()

    assert 1 == lazy_value
    assert isinstance(lazy_value, int)

    maybe2 = Maybe.nothing()
    lazy2 = maybe2.to_lazy()
    lazy_value2 = lazy2.force()

    assert lazy_value2 is None
    assert isinstance(lazy_value2, type(None))

    try_value = Try(lambda: 1 / 0, is_success=True).to_maybe().to_lazy().force()
    assert isinstance(try_value, int) == True
    assert try_

# Generated at 2022-06-24 00:27:34.591614
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("Hello!").filter(lambda s: True) == Maybe.just("Hello!")
    assert Maybe.just("Hello!").filter(lambda s: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda s: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda s: False) == Maybe.nothing()
    assert Maybe.just("Hey!").filter(lambda s: s[0] == 'H') == Maybe.just("Hey!")
    assert Maybe.just("Hello!").filter(lambda s: s[0] == 'h') == Maybe.nothing()
    assert Maybe.just("Hello!").filter(lambda s: s[0] == 'l') == Maybe.nothing()

# Generated at 2022-06-24 00:27:39.251021
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)


# Generated at 2022-06-24 00:27:41.457449
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-24 00:27:45.486125
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def double(value):
        return 2 * value

    def bind_func(value):
        return Maybe.just(double(value))

    assert Maybe.nothing().bind(bind_func) == Maybe.nothing()
    assert Maybe.just(1).bind(bind_func) == Maybe.just(double(1))
    assert Maybe.just(None).bind(bind_func) == Maybe.nothing()

# Generated at 2022-06-24 00:27:49.343553
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(2).to_either() == Either.right(2)
    assert Maybe.nothing().to_either() == Either.left(None)



# Generated at 2022-06-24 00:27:55.370396
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation.
    """

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:28:03.717244
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    # Define TestClass to check calling of __init__ and other methods
    class TestClass(Functor):
        def __init__(self, value: str) -> None:
            self._value = value
            self._called_map = False
            self._called_init = False

        def __eq__(self, other: object) -> bool:
            if not isinstance(other, TestClass):
                return False
            return self._value == other._value and \
                self._called_init == other._called_init and \
                self._called_map == other._called_map

        @classmethod
        def nothing(cls) -> 'Maybe[None]':
            return Maybe.nothing()


# Generated at 2022-06-24 00:28:06.936142
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(6)



# Generated at 2022-06-24 00:28:13.120156
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) != 1


# Generated at 2022-06-24 00:28:17.231994
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 2) == Maybe.just(7)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-24 00:28:20.082002
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    m = Maybe.just(123)
    assert m.to_either() == Right(123)

    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:28:26.400554
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_zero = Maybe.just(0)
    maybe_one = Maybe.just(1)
    maybe_not_empty = Maybe.just(2)
    maybe_empty = Maybe.nothing()

    assert maybe_zero != maybe_one and maybe_one != maybe_not_empty
    assert maybe_zero != maybe_not_empty and maybe_zero != maybe_empty and maybe_one != maybe_empty

    assert maybe_empty != maybe_zero and maybe_empty != maybe_one and maybe_empty != maybe_not_empty

test_Maybe___eq__()



# Generated at 2022-06-24 00:28:34.478172
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(None, False).bind(lambda x: Maybe(x * 2, False)) == Maybe(2, False)
    assert Maybe(None, False).bind(lambda x: Maybe(x * 0, True)) == Maybe(None, True)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 2, False)) == Maybe(None, True)
    assert Maybe(None, True).bind(lambda x: Maybe(x * 0, True)) == Maybe(None, True)


# Generated at 2022-06-24 00:28:38.110612
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe = Maybe.just(lambda a: a + 1)
    assert maybe.ap(Maybe.just(1)) == Maybe.just(2)
    assert maybe.ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()

# Generated at 2022-06-24 00:28:40.655729
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:28:47.357800
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    is_even = lambda x: x % 2 == 0
    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.just(1).filter(is_even) == Maybe.nothing()

    assert Maybe.just('a').filter(is_even) == Maybe.nothing()
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()

