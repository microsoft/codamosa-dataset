

# Generated at 2022-06-24 00:18:41.820559
# Unit test for constructor of class Maybe
def test_Maybe():
    input_num = 10
    maybe = Maybe.just(input_num)
    assert maybe.value == input_num
    assert maybe.is_nothing == False

    assert maybe == Maybe.just(input_num)
    assert maybe != Maybe.nothing()


# Generated at 2022-06-24 00:18:47.809807
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:18:57.479129
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box().is_empty
    assert Maybe.just(1).to_box().is_empty is False
    assert Maybe.just(1).to_box().get() == 1
    assert Maybe.just(1).to_box().get_or('default') == 1
    assert Maybe.nothing().to_box().get_or('default') == 'default'
    assert Maybe.nothing().to_box().map(lambda x: x) is Maybe.nothing()
    assert Maybe.just(1).to_box().map(lambda x: x + 1) is Maybe.just(2)
    assert Maybe.just(1).to_box().map(lambda x: None).to_box().is_empty
    assert Maybe.nothing().to_box().bind(lambda x: Maybe.just(x)) is Maybe.nothing()

# Generated at 2022-06-24 00:18:59.201998
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:19:00.985315
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('value').get_or_else('default') == 'value'
    assert Maybe.nothing().get_or_else('default') == 'default'


# Generated at 2022-06-24 00:19:01.903970
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just('test').bind(lambda s: Maybe.just(s.upper())) == Maybe.just('TEST')



# Generated at 2022-06-24 00:19:03.673290
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:19:05.578082
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pymonet.lazy as lazy

    assert Maybe.just(2).to_lazy() == lazy.Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == lazy.Lazy(lambda: None)


# Generated at 2022-06-24 00:19:11.194771
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad_try import Try
    from pymonet.monad_box import Box
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Either
    from pymonet.monad_validation import Validation

    def test_func(value: Any) -> Any:
        return value


# Generated at 2022-06-24 00:19:17.652988
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either of class Maybe.

    :returns: Nothing
    :rtype: None
    :raises AssertionError: if test failed
    """
    from pymonet.either import Right

    m = Maybe.just(1)
    assert m.to_either() == Right(1)

    m = Maybe.nothing()
    assert m.to_either() != Right(1)


# Generated at 2022-06-24 00:19:18.785958
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)



# Generated at 2022-06-24 00:19:25.103755
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # For true case when Maybe is not empty
    assert Maybe.just(2) == Maybe.just(2)
    # For false case when Maybe is not empty
    assert not Maybe.just(3) == Maybe.just(4)
    # For true case when Maybe is empty
    assert Maybe.nothing() == Maybe.nothing()
    # For false case when Maybe is empty
    assert not Maybe.nothing() == Maybe.just(3)



# Generated at 2022-06-24 00:19:27.397692
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:19:29.733083
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(5).to_either() == \
        Maybe.nothing().to_either() == \
        Maybe.just("some").to_either()

# Generated at 2022-06-24 00:19:31.446675
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(5) == 5
    assert Maybe.nothing().get_or_else(5) == 5



# Generated at 2022-06-24 00:19:40.697166
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    m1 = Maybe.just(None)
    assert isinstance(m1.to_try(), Maybe)
    assert m1.to_try().get_or_else(None) == None
    assert m1.to_try().is_nothing == True

    m2 = Maybe.just(1)
    assert isinstance(m2.to_try(), Maybe)
    assert m2.to_try().get_or_else(2) == 1
    assert m2.to_try().is_nothing == False

    m3 = Maybe.nothing()
    assert isinstance(m3.to_try(), Maybe)
    assert m3.to_try().get_or_else(2) == 2
    assert m3.to_try().is_nothing == True

# Generated at 2022-06-24 00:19:44.875183
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:19:53.400673
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.just(4)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Maybe.just(5)
    assert Maybe.just(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map

# Generated at 2022-06-24 00:19:56.377279
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:19:57.748724
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    pass



# Generated at 2022-06-24 00:20:01.316423
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe.just(2+2)
    yield lambda: maybe == Maybe.just(4)

    maybe = Maybe.nothing()
    yield lambda: maybe == Maybe.nothing()


# Generated at 2022-06-24 00:20:05.165856
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1) \
        .bind(lambda a: Maybe.just(a + 1)) == Maybe.just(2)

    assert Maybe.nothing() \
        .bind(lambda a: Maybe.just(a + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:20:14.324592
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(1, False).to_lazy()() == 1
    assert Maybe(1, False).to_try() == Try(1, is_success=True)
    assert Maybe(1, False).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:20:19.611857
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Maybe.just(2).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

# Generated at 2022-06-24 00:20:23.972992
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test constructor of class Maybe.

    Test:
        * empty Maybe monad
        * non-empty Maybe monad

    Asserts:
        * empty maybe is None type and has is_nothing == True
        * filled maybe is not None and has is_nothing == False
    """
    from pymonet.monad_test import test_monad_constructor

    test_monad_constructor(
        Maybe,
        [
            Maybe.nothing(),
            Maybe.just(1)
        ],
        [
            None,
            1
        ]
    )


# Generated at 2022-06-24 00:20:26.535129
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(100, True)
    assert Maybe(2, False) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, False)

# Generated at 2022-06-24 00:20:28.139822
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(None, True) == (Maybe.nothing())
    assert Maybe(5, False) == (Maybe.just(5))


# Generated at 2022-06-24 00:20:35.951167
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(8).bind(lambda x: Maybe.just(x * 10)) == Maybe.just(80)
    assert Maybe.just(8).bind(lambda x: Maybe.just(x * 0)) == Maybe.just(0)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * 10)) == Maybe.nothing()
    assert Maybe.just(10).bind(lambda x: Maybe.just(x // 0)) == Maybe.nothing()


# Generated at 2022-06-24 00:20:40.890211
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    _1 = Maybe.just(1)
    assert _1.to_lazy().value() == 1

    _none = Maybe.nothing()
    assert _none.to_lazy().value() == None


# Generated at 2022-06-24 00:20:45.471322
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def test_function(value):
        return Maybe.just(value + 1)

    assert Maybe.just(1).bind(test_function) == Maybe.just(2)
    assert Maybe.nothing().bind(test_function) == Maybe.nothing()



# Generated at 2022-06-24 00:20:48.332382
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:51.999707
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Run unit test for method to_validation of class Maybe.

    :return: None
    """
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:54.935523
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(5, False).bind(lambda x: Maybe(x + 20, False)) == Maybe(25, False)
    assert Maybe.nothing().bind(lambda x: Maybe(x + 20, False)) == Maybe.nothing()



# Generated at 2022-06-24 00:21:01.674272
# Unit test for method map of class Maybe
def test_Maybe_map():
    print("Unit test for method map of class Maybe")

    # test is_nothing + map
    box1 = Maybe(None, True)
    box2 = box1.map(lambda x: x + 1)
    assert box1 == box2

    # test is_not_nothing + map
    box1 = Maybe(1, False)
    box2 = box1.map(lambda x: x + 1)
    assert box1 != box2
    assert box2.value == box1.value + 1

    print('    ok')


# Generated at 2022-06-24 00:21:07.149694
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    maybe = Maybe.just(5)
    assert maybe.to_either() == Right(5)

    maybe = Maybe.nothing()
    assert maybe.to_either() == Left(None)


# Generated at 2022-06-24 00:21:08.432498
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(10) == Maybe(10, False)



# Generated at 2022-06-24 00:21:10.027471
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('value') == Maybe.just('value')



# Generated at 2022-06-24 00:21:12.125627
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    func = lambda x: x.value
    box_func = Maybe.just(func)

    assert box_func.to_box().map(2)

# Generated at 2022-06-24 00:21:17.201877
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    unit_test = Maybe.just(10)
    assert unit_test.to_try() == Try(10, is_success=True)

    unit_test = Maybe.nothing()
    assert unit_test.to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:21:22.556219
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Setup
    value = 2
    expected = Maybe.just(value)

    # Exercise
    actual = Maybe.just(value).filter(lambda x: x > 1)

    # Verify
    assert expected == actual


# Generated at 2022-06-24 00:21:26.409849
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.validation import Success, Failure

    success = Success(lambda x: x + 1)
    failure = Failure([])
    just = Maybe.just(1)

    assert just.ap(success) == Maybe.just(2)
    assert just.ap(failure) == Maybe.nothing()



# Generated at 2022-06-24 00:21:28.128499
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(3) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:21:33.129043
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.monad_maybe import Maybe
    from pymonet.builder import maybe_builder

    assert maybe_builder.just(3) == Maybe.just(3)
    assert maybe_builder.nothing() == Maybe.nothing()
    assert maybe_builder.just(3) == Maybe(3, False)
    assert maybe_builder.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:21:36.579215
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:21:37.961540
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(None) == 1
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:21:39.158916
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe = Maybe.just(1)
    assert isinstance(maybe.to_try(), __import__('pymonet.monad_try').Try)

# Generated at 2022-06-24 00:21:42.340319
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: x * 2, False).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe(lambda x: x * 2, False).ap(Maybe.just(None)) == Maybe.just(None)
    assert Maybe(lambda x: x * 2, False).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe(lambda x: x * 2, False).ap(Maybe.nothing()) == Maybe.just(None)


# Generated at 2022-06-24 00:21:45.259331
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert (Maybe.just(1).to_try() == Try(1))
    assert (Maybe.nothing().to_try() == Try(None, is_success=False))


# Generated at 2022-06-24 00:21:47.918302
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:21:55.517372
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.nothing().to_either() == Either.left(Box(None))
    assert Maybe.just(2).to_either() == Either.right(Box(2))

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(2).to_box() == Box(2)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(2).to_lazy()

# Generated at 2022-06-24 00:22:01.540918
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def fold(value1, value2):
        return value1 + value2

    assert Maybe.just(fold).ap(Maybe.just(1)) == Maybe.just(1)
    assert Maybe.just(fold).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:22:07.862969
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(42).to_try() == Try(42, is_success=True)


# Generated at 2022-06-24 00:22:15.526612
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x+1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x+1).ap(Maybe.just(2)) == Maybe.just(3)

    assert Maybe.just(lambda x: x+1).ap(Box(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x+1).ap(Box(2)) == Maybe.just(3)

    assert Maybe.nothing().ap(Box(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:22:24.788212
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def square_root(number):
        try:
            return Maybe.just(math.sqrt(number))
        except ValueError:
            return Maybe.nothing()

    m = Maybe.just(9)
    assert m.bind(square_root) == Maybe.just(3)
    assert square_root(-9) == Maybe.nothing()

    def to_box(number):
        try:
            return Box(number)
        except ValueError:
            return Box(None)

    m = Maybe.just(9)
    assert m.bind(to_box) == Box(9)
    assert to_box(-9) == Box(None)


# Generated at 2022-06-24 00:22:27.783278
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter method
    """
    def filterer(value):
        return value < 5

    assert Maybe.just(1).filter(filterer).get_or_else(None) == 1
    assert Maybe.just(6).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()


# Generated at 2022-06-24 00:22:31.314313
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:39.411812
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value_1 = "value_1"
    value_2 = "value_2"
    # Test when all fields are the same
    m1 = Maybe.just(value_1)
    m2 = Maybe.just(value_1)
    assert m1 == m2
    # Test when values are different
    m1 = Maybe.just(value_1)
    m2 = Maybe.just(value_2)
    assert not m1 == m2
    # Test when one Maybe is empty
    m1 = Maybe.nothing()
    m2 = Maybe.just(value_1)
    assert not m1 == m2
    # Test when both Maybe are empty
    m1 = Maybe.nothing()
    m2 = Maybe.nothing()
    assert m1 == m2



# Generated at 2022-06-24 00:22:43.404496
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.functor import Functor
    my_functor = Functor(None)
    assert Maybe(1, False).bind(lambda x: my_functor.map(x * 10)).value == \
        10
    assert Maybe(None, True).bind(lambda x: my_functor.map(x * 10)) == \
        Maybe(None, True)



# Generated at 2022-06-24 00:22:46.945542
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(5, False).bind(lambda a: Maybe(a * 5, False)).value == 25
    assert Maybe(None, True).bind(lambda a: Maybe(a * 5, False)).is_nothing == True




# Generated at 2022-06-24 00:22:49.394690
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:22:53.729754
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:22:56.632450
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(1, True).to_validation() == Validation.success(None)
    assert Maybe(1, False).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:22:59.506791
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10) == Maybe.just(10).filter(lambda x: x % 2 == 0)
    assert Maybe.nothing() == Maybe.just(10).filter(lambda x: x % 2 == 1)


# Generated at 2022-06-24 00:23:05.983365
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test to_box method.

    :returns: None
    """
    from pymonet.box import Box

    # Test empty Maybe
    maybe = Maybe.nothing()
    assert maybe.to_box() == Box(None)

    # Test empty Maybe
    maybe = Maybe.just(3)
    assert maybe.to_box() == Box(3)


# Generated at 2022-06-24 00:23:08.744996
# Unit test for constructor of class Maybe
def test_Maybe():
    # maybe with not empty value
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just('some value') == Maybe('some value', False)
    # empty maybe
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:23:16.209220
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.functor import Functor

    maybe: Maybe[int] = Maybe.just(1)
    maybe2: Maybe[int] = maybe.map(lambda x: x + 1)
    assert isinstance(maybe2, Maybe)
    assert isinstance(maybe2, Functor)
    assert maybe2 == Maybe.just(2)

    maybe_nothing: Maybe[int] = Maybe.nothing()
    maybe2: Maybe[int] = maybe_nothing.map(lambda x: x + 1)
    assert isinstance(maybe2, Maybe)
    assert isinstance(maybe2, Functor)
    assert maybe2 == Maybe.nothing()



# Generated at 2022-06-24 00:23:18.476106
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-24 00:23:22.523735
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter method.

    :returns: None
    :rtype: None
    """

    result = Maybe.just(2).filter(lambda el: el == 2)
    expected_result = Maybe.just(2)

    assert result == expected_result


# Generated at 2022-06-24 00:23:26.034281
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad_val import MonadVal

    assert isinstance(Maybe.just(1).get_or_else(2), MonadVal)
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

# Generated at 2022-06-24 00:23:31.253331
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right

    # empty Maybe
    assert Maybe.nothing().bind(lambda x: Right(x)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Left(x)) == Maybe.nothing()

    # not empty Maybe
    assert Maybe.just(1).bind(lambda x: Right(x)) == Right(1)
    assert Maybe.just(1).bind(lambda x: Left(x)) == Left(1)

# Generated at 2022-06-24 00:23:34.924627
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    print("test_Maybe_to_either")
    maybe = Maybe.just('text to be printed')
    assert isinstance(maybe.to_either(), Either)

    maybe = Maybe.nothing()
    assert isinstance(maybe.to_either(), Either)


# Generated at 2022-06-24 00:23:39.338451
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(42).to_try() == \
        Try(42, is_success=True)
    assert Maybe.nothing().to_try() == \
        Try(None, is_success=False)


# Generated at 2022-06-24 00:23:43.899718
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet import maybe

    maybe_10 = maybe.Maybe.just(10)
    validation_10 = maybe_10.to_validation()
    assert validation_10 == Validation.success(10)
    maybe_None = maybe.Maybe.nothing()
    validation_None = maybe_None.to_validation()
    assert validation_None == Validation.success(None)

# Generated at 2022-06-24 00:23:48.572981
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()
    assert Maybe.just('foo').map(lambda x: x) == Maybe.just('foo')
    assert Maybe.just('foo').map(lambda x: x + 'bar') == Maybe.just('foobar')



# Generated at 2022-06-24 00:23:50.121845
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda a: Maybe.just(a + 1)) == Maybe.just(2), "Should be Maybe.just(2)"



# Generated at 2022-06-24 00:23:51.635181
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)

# Generated at 2022-06-24 00:23:53.218178
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:23:58.601225
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # GIVEN
    justMaybe = Maybe.just(1)
    nothingMaybe = Maybe.nothing()
    defaultValue = 123

    # WHEN
    resultJust = justMaybe.get_or_else(defaultValue)
    resultNothing = nothingMaybe.get_or_else(defaultValue)

    # THEN
    assert resultJust == 1
    assert resultNothing == 123

# Generated at 2022-06-24 00:24:02.125052
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x).ap(Maybe.just(2)) == Maybe.just(2)
    assert Maybe.just(lambda x: x).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:24:06.160731
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe(5, False).to_try() == Try(5, is_success=True)
    assert Maybe(None, True).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:24:10.262352
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe = Maybe.just(1)
    assert(maybe.ap(Maybe.just((lambda x: x + 10))) == Maybe.just(11))


# Generated at 2022-06-24 00:24:12.013694
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:24:16.104069
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:24:26.102478
# Unit test for method __eq__ of class Maybe

# Generated at 2022-06-24 00:24:28.929817
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:24:32.192251
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x+1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()


# Generated at 2022-06-24 00:24:35.967325
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:24:38.749844
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x % 2 == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:24:44.439288
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    import pytest

    assert Maybe.just(42).get_or_else('def') == 42
    assert Maybe.nothing().get_or_else('def') == 'def'

    with pytest.raises(AttributeError) as err:
        Maybe.nothing().value
    assert 'is_nothing' in err.value.args[0]


# Generated at 2022-06-24 00:24:49.483183
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Check for method bind of class Maybe

    :returns: None
    """
    def func(x):
        return Maybe.just(x)
    assert Maybe.just(10).bind(func) == Maybe.just(10)
    assert Maybe.nothing().bind(func) == Maybe.nothing()



# Generated at 2022-06-24 00:24:53.844846
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda n: n == 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda n: n != 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n == 2) == Maybe.nothing()



# Generated at 2022-06-24 00:24:57.737843
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():

    def _test(maybe: Maybe, expected: 'Try[T]') -> None:
        assert maybe.to_try() == expected

    _test(Maybe.just(1), Try(1, True))
    _test(Maybe.just(None), Try(None, True))
    _test(Maybe.nothing(), Try(None, False))


# Generated at 2022-06-24 00:24:59.761802
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == \
        Right(1)

    assert Maybe.nothing().to_either() == \
        Left(None)



# Generated at 2022-06-24 00:25:05.087664
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """ unit testing for Maybe.__eq__ method """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-24 00:25:09.471094
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    result = Maybe.just(5).get_or_else(10)  # 5
    assert result == 5

    result = Maybe.nothing().get_or_else(10)  # 5
    assert result == 10


# Generated at 2022-06-24 00:25:12.401839
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test Maybe is not empty
    assert Maybe.just(5) == Maybe(5, False)

    # Test Maybe is empty
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:25:16.793241
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) == Maybe.just(1)


# Generated at 2022-06-24 00:25:19.306611
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:25:23.715458
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(10).map(lambda x: x + 5) == Maybe.just(15)
    assert Maybe.nothing().map(lambda x: x + 5) == Maybe.nothing()


# Generated at 2022-06-24 00:25:28.141737
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(2).to_try() == Try(2, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:25:33.926933
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Maybe.just(2).bind(lambda x: Maybe.just(x + 21)) == Maybe.just(23)
    assert Maybe.just(2).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 21)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(2).bind(lambda x: Box(x + 21)) == Maybe.just(23)
    assert Maybe.just(2).bind(lambda x: Box(None))

# Generated at 2022-06-24 00:25:37.964597
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    f = lambda a: a + 1
    assert Maybe.just(f).ap(Maybe.just(1)) == Maybe.just(f(1))
    assert Maybe.just(f).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:25:39.798830
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:25:48.435235
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 2)) == \
           Maybe.just(3)

    assert Maybe.just(None).bind(lambda x: Maybe.just(x + 2)) == \
           Maybe.just(2)

    assert Maybe.just(None).bind(lambda x: Maybe.just(None)) == \
           Maybe.just(None)

    assert Maybe.just(None).bind(lambda x: Maybe.nothing()) == \
           Maybe.nothing()

    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 2)) == \
           Maybe.nothing()

    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == \
           Maybe.nothing()


# Generated at 2022-06-24 00:25:50.467294
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe = Maybe.just(1)
    assert maybe.to_either() == Right(1)

# Generated at 2022-06-24 00:25:53.263054
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(2, False).to_box() == Box(2)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:25:58.954290
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x % 2 == 0) == Maybe(2, False)
    assert Maybe(2, False).filter(lambda x: x % 2 != 0) == Maybe(None, True)
    assert Maybe(2, True).filter(lambda x: x % 2 == 0) == Maybe(None, True)
    assert Maybe(1, True).filter(lambda x: x % 2 == 0) == Maybe(None, True)



# Generated at 2022-06-24 00:26:01.499011
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just('something').to_box() == Box('something')
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:07.971032
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    import pytest

    # Test when Maybe is empty
    assert Maybe.nothing().to_lazy().eval() is None

    # Test when Maybe is not empty
    assert Maybe.just(1).to_lazy().eval() == 1

    # Test when Maybe is not empty and we can use additional parameters
    assert Maybe.just(lambda x: x + 1).to_lazy().eval(1) == 2


# Generated at 2022-06-24 00:26:12.460220
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    assert Maybe.just(None).map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:26:16.254064
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.just(None) != Maybe.nothing()



# Generated at 2022-06-24 00:26:23.116174
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.list import List

    assert str(Maybe.just(10).to_lazy()) == 'Lazy(function: <function Maybe_to_lazy.<locals>.<lambda> at 0x0000020D64B7E158>)'
    assert str(Maybe.nothing().to_lazy()) == 'Lazy(function: <function Maybe_to_lazy.<locals>.<lambda> at 0x0000020D64B7E1E0>)'

# Generated at 2022-06-24 00:26:26.758553
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:30.623968
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box().is_value
    assert Maybe(None, True).to_box().is_value
    assert Maybe(1, False).to_box().value == 1
    assert Maybe(None, True).to_box().value == None

# Generated at 2022-06-24 00:26:35.410712
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    succeeded_result = Maybe(1, False).to_try()
    failed_result = Maybe.nothing().to_try()
    assert succeeded_result == Try(1, is_success=True)
    assert failed_result == Try(None, is_success=False)



# Generated at 2022-06-24 00:26:39.337785
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:26:46.135707
# Unit test for method map of class Maybe
def test_Maybe_map():
    from pymonet.monad_maybe import Maybe

    assert Maybe(2, False).map(lambda x: x * 2) == Maybe(4, False)
    assert Maybe(2, False).map(lambda x: x) == Maybe(2, False)
    assert Maybe(2, False).map(lambda x: None) == Maybe(None, True)
    assert Maybe(None, True).map(lambda x: 2) == Maybe(None, True)
    assert Maybe(None, True).map(lambda x: None) == Maybe(None, True)


# Generated at 2022-06-24 00:26:53.306392
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m = Maybe.just(lambda x: x * x)
    assert(
        m.ap(Maybe.just(3)) ==
        Maybe.just(9)
    )

    m = Maybe.nothing()
    assert(
        m.ap(Maybe.just(3)) ==
        Maybe.nothing()
    )


# Generated at 2022-06-24 00:26:57.605327
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.just(2).to_box().map(lambda x: x+1) == Box(3)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.nothing().to_box().map(lambda x: x+2) == Box(None)


# Generated at 2022-06-24 00:27:02.821449
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Run unit tests for Maybe map function.

    :returns: True when test passes
    :rtype: Boolean
    """

# Generated at 2022-06-24 00:27:07.540569
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    # it('should return not successfull when maybe is nothing', () => {
    #   expect(Maybe.nothing().toTry().isSuccess).to.be.false;
    # });

    # it('should return successfull when maybe is just', () => {
    #   expect(Maybe.just(1).toTry().isSuccess).to.be.true;
    # });

    # it('should return not successfull with value of nothing when maybe is nothing', () => {
    #   expect(Maybe.nothing().toTry().value).to.be.undefined;
    # });

    # it('should return successfull with value of just when maybe is just', () => {
    #   expect(Maybe.just(1).toTry().value).to.equal(1);
    # });
    assert not Maybe.nothing().to_try().is_success

# Generated at 2022-06-24 00:27:11.795389
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:27:16.506911
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(
        filterer=lambda result: result % 2 == 0
    ) == Maybe.nothing()

    assert Maybe.just(2).filter(
        filterer=lambda result: result % 2 == 0
    ) == Maybe.just(2)

    assert Maybe.nothing().filter(
        filterer=lambda result: result % 2 == 0
    ) == Maybe.nothing()



# Generated at 2022-06-24 00:27:19.814386
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-24 00:27:26.983680
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 2).ap(Maybe.just(3)) == Maybe.just(5)
    assert Maybe.nothing().ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 2).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:27:30.016279
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:27:36.997708
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = 'test'

    maybe_filterer_returns_True = Maybe[str].just(test_value).filter(lambda test_value: True)
    maybe_filterer_returns_False = Maybe[str].just(test_value).filter(lambda test_value: False)

    assert maybe_filterer_returns_True.value == test_value
    assert maybe_filterer_returns_False.is_nothing


# Generated at 2022-06-24 00:27:39.831703
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda n: n + 2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda n: n + 2) == Maybe.nothing()


# Generated at 2022-06-24 00:27:46.989313
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :returns: True if its all ok
    :rtype: Boolean
    """
    from pymonet.tests.test_monad_base import _test_empty_monad
    from pymonet.tests.testable_monad import TestableMonad

    maybe = Maybe.just(2)
    maybe_empty = Maybe.nothing()

    test_monad = TestableMonad(
        monad=Maybe, unit=Maybe.just,
        empty=Maybe.nothing, monad_type=int
    )

    return maybe.filter(lambda x: x % 2 == 0) \
        .to_validation().is_success and \
        maybe.filter(lambda x: x % 2 == 1) \
        .to_validation().is_success and \
        maybe

# Generated at 2022-06-24 00:27:49.177134
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Maybe.just(5).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 5


# Generated at 2022-06-24 00:27:58.605700
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 10) == Maybe.just(15)
    assert Maybe.just(5).map(lambda x: x * x) == Maybe.just(25)
    assert Maybe.just(5).map(lambda x: x) == Maybe.just(5)
    assert Maybe.nothing().map(lambda x: x * x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-24 00:28:01.955310
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """Test Maybe.to_try() method."""
    assert Maybe("foo", False).to_try() == Try("foo", is_success=True)
    assert Maybe("bar", True).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:28:07.984329
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe(5, False).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:28:11.665644
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x * x) == Maybe.just(9)
    assert Maybe.something(2).map(lambda x: x / 0) == Maybe.something(float("inf"))


# Generated at 2022-06-24 00:28:18.484376
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try, Failure

    # Not empty Maybe
    actual = Maybe.just(1).to_try()
    expected = Try(1, is_success=True)
    assert actual == expected

    # Empty Maybe
    actual = Maybe.nothing().to_try()
    expected = Try(None, is_success=False)
    assert actual == expected



# Generated at 2022-06-24 00:28:22.995492
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)



# Generated at 2022-06-24 00:28:25.085257
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.to_box.__code__.co_argcount == 1
    assert Maybe.to_box(Maybe.just(1)).value == Box(1).value
    assert Maybe.to_box(Maybe.nothing()).value == Box(None).value


# Generated at 2022-06-24 00:28:27.092804
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:28:33.405973
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    result = Maybe.just(1).to_try()
    expected = Try(1, True)
    assert result == expected
    result = Maybe.nothing().to_try()
    expected = Try(None, False)
    assert result == expected


# Generated at 2022-06-24 00:28:36.483005
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(7).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(8)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:28:40.158547
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """An empty Maybe should not be a filter."""
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

