

# Generated at 2022-06-24 00:18:48.046843
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    """

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-24 00:18:53.183263
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:18:55.034899
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-24 00:18:57.108245
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:18:59.226196
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe_1 = Maybe.just(10)
    assert maybe_1.get_or_else(None) == 10

    maybe_2 = Maybe.nothing()
    assert maybe_2.get_or_else(20) == 20



# Generated at 2022-06-24 00:19:04.708821
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = Maybe.just(5)
    expected_result = Lazy(lambda: 5)
    actual_result = value.to_lazy()

    assert expected_result == actual_result


# Generated at 2022-06-24 00:19:08.408017
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    input1 = Maybe(123, False)
    result1 = input1.to_validation()
    assert result1.value == 123 and result1.is_success

    input2 = Maybe(None, True)
    result2 = input2.to_validation()
    assert result2.value is None and result2.is_success


if __name__ == '__main__':
    test_Maybe_to_validation()

# Generated at 2022-06-24 00:19:12.755722
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert(Maybe.just(0).to_validation() == Validation.success(0))
    assert(Maybe.nothing().to_validation() == Validation.success(None))


# Generated at 2022-06-24 00:19:17.181472
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    import pymonet.maybe as mb

    assert mb.Maybe.just(lambda x: x + 1).ap(mb.Maybe.just(1)) == mb.Maybe.just(2)
    assert mb.Maybe.nothing().ap(mb.Maybe.just(1)) == mb.Maybe.nothing()


# Generated at 2022-06-24 00:19:22.602195
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert (
        Maybe.just(3).to_validation()
        ==
        Validation.success(3)
    )

    assert (
        Maybe.nothing().to_validation()
        ==
        Validation.success(None)
    )

    print(Maybe.just(3).to_validation())
    print(Maybe.nothing().to_validation())



# Generated at 2022-06-24 00:19:26.542638
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:19:35.268457
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.functor_spec import functor_identity, functor_composition
    from pymonet.applicative_spec import applicative_identity, applicative_homomorphism, applicative_composition
    from pymonet.monad_spec import monad_left_identity, monad_right_identity, monad_associativity

    just_1 = Maybe.just(1)
    nothing = Maybe.nothing()

    assert str(just_1.value) == '1'
    assert nothing.is_nothing == True

    # functor laws
    assert functor_identity(just_1)
    assert functor_composition(just_1)

    # applicative laws
    assert applicative_identity(just_1)
    assert applicative_homomorphism(just_1)
   

# Generated at 2022-06-24 00:19:41.830172
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    import pymonet.box
    assert Maybe(1, False).to_box() == pymonet.box.Box(1)
    assert Maybe(1, True).to_box() == pymonet.box.Box(None)


# Generated at 2022-06-24 00:19:46.710475
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x == 5) == Maybe(5, False)
    assert Maybe(5, False).filter(lambda x: x == 10) == Maybe.nothing()
    assert Maybe(5, True).filter(lambda x: x == 5) == Maybe.nothing()


# Generated at 2022-06-24 00:19:51.523287
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    nothing = Maybe.nothing()
    assert nothing.get_or_else(3) == 3
    assert nothing.get_or_else(lambda: 3)() == 3
    assert nothing.get_or_else(lambda x: x + 1)(3) == 4
    assert nothing.get_or_else('c') == 'c'
    assert nothing.get_or_else(None) is None

    just3 = Maybe.just(3)
    assert just3.get_or_else(4) == 3
    assert just3.get_or_else(lambda: 4)() == 3
    assert just3.get_or_else(lambda x: x + 1)(4) == 3
    assert just3.get_or_else('c') == 3
    assert just3.get_or_else(None) == 3



# Generated at 2022-06-24 00:19:53.176332
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).map(lambda x: x * 2).to_lazy().value() == 20
    assert Maybe.nothing().map(lambda x: x * 2).to_lazy().value() == None


# Generated at 2022-06-24 00:19:54.994426
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    result = Maybe.just(lambda x: x * 2).ap(Maybe.just(3))
    assert result == Maybe.just(6)



# Generated at 2022-06-24 00:20:05.931582
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Create instance of Maybe and call bind.

    :returns: None
    """
    monad = Maybe.just(42)
    assert monad.bind(lambda x: Maybe.just(x * 2)) == Maybe.just(84)
    assert monad.bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(10)) == Maybe.nothing()

    # We can create complex bind chains
    chain = Maybe.just(10) \
        .bind(lambda x: Maybe.just(x + 1)) \
        .bind(lambda x: Maybe.just(x * 2))

    assert chain == Maybe.just(22)

    # In some cases we need to create bind chain with nothing
    # In this case we must return nothing from mapper function
    chain = Maybe

# Generated at 2022-06-24 00:20:12.143519
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe = Maybe(1, False)
    assert maybe == Maybe(1, False)
    assert maybe != Maybe(1, True)
    assert maybe != Maybe(2, False)
    assert maybe != Maybe(2, True)
    assert maybe.value == 1
    assert maybe.is_nothing is False
    assert repr(maybe) == 'Maybe(value=1, is_nothing=False)'
    assert str(maybe) == 'Maybe(value=1, is_nothing=False)'

# Tests for method just

# Generated at 2022-06-24 00:20:15.089328
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    print("Testing Maybe.to_validation()...")
    from pymonet.validation import Validation

    maybe_1 = Maybe.just(5)
    assert maybe_1.to_validation() == Validation.success(5)

    maybe_2 = Maybe.just(None)
    assert maybe_2.to_validation() == Validation.success(None)

    maybe_3 = Maybe.nothing()
    assert maybe_3.to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:20:18.822445
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.assert_utils import assert_equals, assert_not_equals, assert_true, assert_false
    assert_equals(Maybe.just(1).get_or_else(0), 1)
    assert_equals(Maybe.nothing().get_or_else(0), 0)
    assert_true(Maybe.just(False).get_or_else(True))
    assert_false(Maybe.nothing().get_or_else(False))



# Generated at 2022-06-24 00:20:22.622220
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:27.830665
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(3).to_either() == Right(3)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:20:30.988034
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.just(1) != Maybe.just('test')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(lambda x: x) != Maybe.just(None)


# Generated at 2022-06-24 00:20:35.227469
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:20:38.609688
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # GIVEN
    maybe_lambda = Maybe.just(lambda x: x*2)
    maybe_int = Maybe.just(10)

    # WHEN
    result = maybe_lambda.ap(maybe_int)

    # THEN
    assert result == Maybe.just(20)

# Generated at 2022-06-24 00:20:42.771670
# Unit test for constructor of class Maybe
def test_Maybe():
    # Check constructor with value
    maybe: Maybe[int] = Maybe(10, False)
    assert not maybe.is_nothing
    assert maybe.value == 10

    # Check constructor without value
    maybe: Maybe[int] = Maybe(None, True)
    assert maybe.is_nothing
    assert maybe.value == None


# Generated at 2022-06-24 00:20:47.747669
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """Unit test for method to_either of class Maybe"""

    # in case of empty maybe
    assert Maybe.nothing().to_either() == Maybe.nothing()

    # in case of not empty maybe
    assert Maybe.just("123").to_either() == Maybe.just("123")



# Generated at 2022-06-24 00:20:52.089433
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a_ = Maybe(10, False)
    b_ = Maybe(10, False)
    c_ = Maybe(20, False)
    d_ = Maybe(10, True)

    assert a_ == b_
    assert a_ != c_
    assert a_ != d_



# Generated at 2022-06-24 00:20:59.163963
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test constructor
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe(None, True)

    # Test just
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10).is_nothing == False
    assert Maybe.just(10).value == 10

    # Test nothing
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().is_nothing == True

    # Test equality
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.just(10) != Maybe.just(10.1)

# Generated at 2022-06-24 00:21:03.311937
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x * 2)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x * 2)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:08.448165
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.just(None).bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:16.111179
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(None).to_try() == Try(None, is_success=True)
    assert Maybe.just('str').to_try() == Try('str', is_success=True)
    assert Maybe.just([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=True)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)



# Generated at 2022-06-24 00:21:20.657860
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    actual = Maybe.just(0) \
        .bind(lambda x: Maybe.just(x + 1)) \
        .bind(lambda x: Maybe.just(x + 2))

    assert actual == Maybe.just(3)



# Generated at 2022-06-24 00:21:23.844127
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()



# Generated at 2022-06-24 00:21:33.247734
# Unit test for constructor of class Maybe
def test_Maybe():
    # Just constructor
    maybe = Maybe.just(1)
    assert maybe.value == 1
    assert not maybe.is_nothing

    # Nothing constuctor
    maybe = Maybe.nothing()
    assert maybe.value is None
    assert maybe.is_nothing

    # Alternative Just constructor
    maybe = Maybe(1, False)
    assert maybe.value == 1
    assert not maybe.is_nothing

    # Alternative Nothing constructor
    maybe = Maybe(None, True)
    assert maybe.value is None
    assert maybe.is_nothing



# Generated at 2022-06-24 00:21:40.130868
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(17, False) == Maybe.just(17)
    assert Maybe(17, False).get_or_else(0) == 17
    assert Maybe(17, False).get_or_else(0) == 17
    assert Maybe(17, False).to_validation() == Validation.success(17)
    assert Maybe(17, False).to_validation().get_or_else(0) == 17
    assert Maybe(True, False).to_validation().is_success()
    assert Maybe(True, True).to_validation().is_success()
    assert Maybe(17, False).to_validation().is_success()
    assert Maybe(None, True).to_validation().get_or_else(0) == 0

# Generated at 2022-06-24 00:21:42.740730
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x * 2) == Maybe.just(6)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()



# Generated at 2022-06-24 00:21:49.052610
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(100)
    assert maybe.filter(lambda value: value < 100) == Maybe.nothing()
    assert maybe.filter(lambda value: value == 100) == Maybe.just(100)
    assert maybe.filter(lambda value: value > 100) == Maybe.nothing()

    maybe = Maybe.nothing()
    assert maybe.filter(lambda value: value < 100) == Maybe.nothing()
    assert maybe.filter(lambda value: value == 100) == Maybe.nothing()
    assert maybe.filter(lambda value: value > 100) == Maybe.nothing()



# Generated at 2022-06-24 00:21:51.441693
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just('string').to_try() == Try('string', True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:22:01.067726
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    first_maybe_with_value_one = Maybe.just(1)
    second_maybe_with_value_one = Maybe.just(1)
    maybe_with_value_two = Maybe.just(2)
    first_maybe_with_nothing = Maybe.nothing()
    second_maybe_with_nothing = Maybe.nothing()

    assert first_maybe_with_value_one == second_maybe_with_value_one
    assert first_maybe_with_value_one != maybe_with_value_two
    assert first_maybe_with_value_one != first_maybe_with_nothing
    assert first_maybe_with_nothing == second_maybe_with_nothing


# Generated at 2022-06-24 00:22:07.824921
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(None, False).to_either() == \
        Right(None)
    assert Maybe(1, False).to_either() == \
        Right(1)
    assert Maybe(None, True).to_either() == \
        Left(None)



# Generated at 2022-06-24 00:22:13.828185
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    maybe_just = Maybe.just(1)
    assert isinstance(maybe_just.to_try(), Try)
    assert maybe_just.to_try().value == 1

    maybe_nothing = Maybe.nothing()
    assert isinstance(maybe_nothing.to_try(), Try)
    assert maybe_nothing.to_try().is_success is False

# Generated at 2022-06-24 00:22:16.642151
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def concat_to_a(val):
        return Maybe.just('a' + str(val))

    assert Maybe.just(1).bind(concat_to_a) == Maybe.just('a1')
    assert Maybe.nothing().bind(concat_to_a) == Maybe.nothing()



# Generated at 2022-06-24 00:22:19.482130
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(2)
    assert maybe.filter(lambda x: x%2 == 0) == Maybe.just(2)
    assert maybe.filter(lambda x: x%2 == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:22:20.865007
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:22:25.776017
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:22:28.681783
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:22:34.774809
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :returns: Void
    :rtype: None
    """

    # Positive cases
    assert Maybe.just(123).filter(lambda x: x > 100) == Maybe.just(123)
    assert Maybe.just("abc").filter(lambda x: len(x) > 2) == Maybe.just("abc")

    # Negative cases
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just("a").filter(lambda x: len(x) > 2) == Maybe.nothing()

    # Empty case
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()

# Generated at 2022-06-24 00:22:41.141311
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_with_value = Maybe.just(5)
    maybe_without_value = Maybe.nothing()

    assert not maybe_with_value.is_nothing and maybe_without_value.is_nothing
    assert maybe_with_value.value == 5
    assert maybe_without_value.value is None



# Generated at 2022-06-24 00:22:46.007820
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(4).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(5)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:22:47.994864
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(None) == 2
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-24 00:22:54.901362
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(11)
    x = maybe.filter(lambda x: x % 2 == 0)
    assert isinstance(x, Maybe)
    assert x == Maybe.nothing()

    maybe = Maybe.just(10)
    x = maybe.filter(lambda x: x % 2 == 0)
    assert isinstance(x, Maybe)
    assert x == Maybe.just(10)

    maybe = Maybe.nothing()
    x = maybe.filter(lambda x: x % 2 == 0)
    assert isinstance(x, Maybe)
    assert x == Maybe.nothing()



# Generated at 2022-06-24 00:22:59.002964
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test for method __eq__ of class Maybe.

    :return: None
    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:23:04.709393
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(7)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:23:11.466164
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)



# Generated at 2022-06-24 00:23:16.075213
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    value = 1
    maybe = Maybe.just(value)
    assert maybe.value == value
    assert not maybe.is_nothing
    # assert maybe == Maybe.just(1)
    assert maybe.to_box() == Box(value)


# Generated at 2022-06-24 00:23:21.382208
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just('Python') == Maybe('Python', False)
    assert Maybe.just(None) == Maybe(None, False)

    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:23:23.431557
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_one = Maybe.just(1)
    maybe_nothing = Maybe.nothing()
    assert maybe_one.value == 1 and \
        maybe_one.is_nothing is False and \
        maybe_nothing.is_nothing is True


# Generated at 2022-06-24 00:23:32.160828
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert (Maybe.just(None).to_either() == Right(None))
    assert (Maybe.just(False).to_either() == Right(False))
    assert (Maybe.just(True).to_either() == Right(True))
    assert (Maybe.just(10).to_either() == Right(10))
    assert (Maybe.just(2.5).to_either() == Right(2.5))
    assert (Maybe.just('a').to_either() == Right('a'))
    assert (Maybe.just('abc').to_either() == Right('abc'))
    assert (Maybe.just([]).to_either() == Right([]))
    assert (Maybe.just([1]).to_either() == Right([1]))

# Generated at 2022-06-24 00:23:36.494202
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    # Given
    maybe_2 = Maybe.just(2)
    add_1 = Box(lambda x: x + 1)

    # When
    result = maybe_2.ap(add_1)

    # Then
    assert result == Maybe.just(3)


# Generated at 2022-06-24 00:23:41.239295
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def add_ten(x: int) -> Maybe[int]:
        return Maybe.just(x + 10)

    assert Maybe.just(1).bind(add_ten) == Maybe.just(11)
    assert Maybe.nothing().bind(add_ten) == Maybe.nothing()


# Generated at 2022-06-24 00:23:43.027842
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:23:46.431466
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(4) == Maybe(4, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:23:48.377643
# Unit test for method map of class Maybe
def test_Maybe_map():
    maybe = Maybe.just(3)

    def mapper(value):
        return value * 2

    assert maybe.map(mapper) == Maybe.just(6)



# Generated at 2022-06-24 00:23:51.445189
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def sum(a: int, b: int) -> int:
        return a + b

    assert Maybe.just(sum).ap(Maybe.just(1)).ap(Maybe.just(2)) == Maybe.just(3), 'Wrong Maybe.ap'
    assert Maybe.just(sum).ap(Maybe.nothing()).ap(Maybe.just(2)) == Maybe.nothing(), 'Wrong Maybe.ap'

# Generated at 2022-06-24 00:23:53.338495
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(11) == 11
    assert Maybe.just(3).get_or_else(11) == 3



# Generated at 2022-06-24 00:23:59.114547
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Unit test for method get_or_else of class Maybe.
    """
    # when maybe3 is just(value)
    maybe3 = Maybe.just(3)
    assert maybe3.get_or_else(8) == 3

    # when maybe3 is nothing
    maybe3 = Maybe.nothing()
    assert maybe3.get_or_else(8) == 8



# Generated at 2022-06-24 00:24:03.283508
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Try.success(5).to_maybe().to_try() == Try.success(5)
    assert Try.failure("hoop").to_maybe().to_try() == Try("hoop", is_success=False)

# Generated at 2022-06-24 00:24:07.042282
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe('1', False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe('1', True)


# Unit tes for method just of class Maybe

# Generated at 2022-06-24 00:24:10.901204
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("test") == Maybe("test", False)
    assert Maybe.just("test") != Maybe("test", True)
    assert Maybe.just("test") == Maybe("test", False)
    assert Maybe.just("test") != Maybe("TEST", False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe(None, False)


# Generated at 2022-06-24 00:24:21.888870
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(5).bind(lambda v: v + 1) == Maybe.just(6)
    assert Maybe.nothing().bind(lambda v: v + 1) == Maybe.nothing()

    assert Maybe.just(5).bind(lambda v: Maybe.just(v + 1)) == Maybe.just(6)
    assert Maybe.nothing().bind(lambda v: Maybe.just(v + 1)) == Maybe.nothing()

    assert Maybe.just(5).bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda v: Maybe.nothing()) == Maybe

# Generated at 2022-06-24 00:24:27.984559
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    def mapper(value):
        if value == 5:
            return Maybe.nothing()
        return Maybe.just(value)

    maybe = Maybe.just(5)
    result = maybe.bind(mapper)

    assert result == Maybe.nothing()

    maybe = Maybe.just(3)
    result = maybe.bind(mapper)

    assert result == Maybe.just(3)



# Generated at 2022-06-24 00:24:31.295793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(42).to_either() == Right(42)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:24:34.336149
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import Lazy

    # Test with not empty Maybe, lambda returns 2
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)

    # Test with empty Maybe, function returning None
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:24:38.247460
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:24:41.941504
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:24:43.698737
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    foo = Maybe.just(100)
    bar = Maybe.just(100)
    assert foo == bar



# Generated at 2022-06-24 00:24:49.148911
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def func(v: int) -> Maybe[int]:
        return Maybe.just(v + 1)

    assert Maybe.just(1).bind(func).value == 2
    assert Maybe.nothing().bind(func).is_nothing



# Generated at 2022-06-24 00:24:53.163174
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else("default") == 42
    assert Maybe.nothing().get_or_else("default") == "default"


# Generated at 2022-06-24 00:24:57.621463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just("aaa") == Maybe.just("aaa")
    assert Maybe.just("aaa") != Maybe.just("bbb")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just("aaa") != Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()

# Generated at 2022-06-24 00:25:03.927717
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    a = Maybe(10, False)
    assert isinstance(a.to_lazy(), Lazy)
    assert a.to_lazy().value() == 10
    a = Maybe(None, True)
    assert isinstance(a.to_lazy(), Lazy)
    assert a.to_lazy().value() == None

# Generated at 2022-06-24 00:25:06.868446
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(7).to_try() == Try(7)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:25:10.799634
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)



# Generated at 2022-06-24 00:25:16.463505
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x ** 2).ap(Maybe.just(10)) == Maybe.just(100)
    assert Maybe.just(lambda x: x ** 2).ap(Maybe(None, True)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe.just(10)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(None, True)) == Maybe(None, True)

# Generated at 2022-06-24 00:25:25.986619
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    nothing_maybe = Maybe.nothing()
    assert nothing_maybe.__eq__(nothing_maybe)

    just_null = Maybe.just(None)
    assert just_null.__eq__(just_null)

    just_empty_string = Maybe.just('')
    assert just_empty_string.__eq__(just_empty_string)

    just_string = Maybe.just('string')
    assert just_string.__eq__(just_string)

    assert not just_string.__eq__(None)

    assert not just_string.__eq__(just_null)
    assert not just_null.__eq__(just_string)

    assert not just_string.__eq__(just_empty_string)
    assert not just_empty_string.__eq__(just_string)

    assert not just_

# Generated at 2022-06-24 00:25:29.981718
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test successfully bind method of class Maybe.
    """
    def mapper(value):
        if value > 2:
            return Maybe.just(value)
        return Maybe.nothing()
    maybe = Maybe.just(3)
    assert mapper(3) == maybe.bind(mapper)



# Generated at 2022-06-24 00:25:41.371755
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy, to_list

    lazy = (
        Maybe.just(1)
        .map(lambda x: x + 1)
        .map(lambda x: x ** 2)
        .to_lazy()
    )
    assert to_list(lazy) == [4]

    lazy = (
        Maybe.just(1)
        .map(lambda x: x + 1)
        .map(lambda x: x ** 2)
        .map(lambda x: None)
        .to_lazy()
    )
    assert to_list(lazy) == [None]


# Generated at 2022-06-24 00:25:44.343036
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert(Maybe.just(1).to_try() == Try(1, is_success=True))
    assert(Maybe.nothing().to_try() == Try(None, is_success=False))



# Generated at 2022-06-24 00:25:54.043699
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None)

    assert Maybe.just(5).to_either() == Right(5)

    assert Maybe.just(5).to_either().get_or_else(10) == 5
    assert Maybe.nothing().to_either().get_or_else(10) == 10

    assert Maybe.just(5).to_either().map(lambda x: x + 1) == Right(6)
    assert Maybe.nothing().to_either().map(lambda x: x + 1) == Left(None)

    assert Maybe.just(5).to_either().bind(lambda x: Right(x + 1)) == Right(6)
    assert Maybe.nothing().to_either().bind(lambda x: Right(x + 1)) == Left(None)


# Generated at 2022-06-24 00:25:55.038971
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:25:57.818793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:26:00.148401
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:02.244360
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:26:08.606074
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    maybe = Maybe.just(1)
    validation = Validation.success(1)
    assert maybe.to_validation() == validation

    maybe = Maybe.nothing()
    validation = Validation.success(None)
    assert maybe.to_validation() == validation



# Generated at 2022-06-24 00:26:13.326718
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Case 1: test bind method for empty Maybe
    Nothing1 = Maybe.nothing()
    Nothing2 = Nothing1.bind(lambda x: x)
    assert Nothing1 is Nothing2

    # Case 2: test bind method for notempty Maybe
    JustM = Maybe.just('Monet')
    JustMonet = JustM.bind(lambda x: x)
    assert JustM is JustMonet


# Generated at 2022-06-24 00:26:15.434063
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:26:18.503860
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)

if __name__ == '__main__':
    test_Maybe_to_validation()

# Generated at 2022-06-24 00:26:20.241548
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:26:21.869796
# Unit test for constructor of class Maybe
def test_Maybe():

    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:26.551285
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 3) == Maybe.just(4)
    assert Maybe.just(1).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: 1 + 3) == Maybe.nothing()



# Generated at 2022-06-24 00:26:29.127942
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:26:35.889755
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(10).map(lambda x: x + 10) == Maybe.just(20)
    assert Maybe.just(10).map(lambda x: x - 10) == Maybe.just(0)
    assert Maybe.just(10).map(lambda x: x * 10) == Maybe.just(100)
    assert Maybe.just(10).map(lambda x: x / 10) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()



# Generated at 2022-06-24 00:26:42.040236
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try, TryError

    # Arrange
    maybe = Maybe.just(1)
    expected = Lazy(lambda: 1)

    # Act
    actual = maybe.to_lazy()

    # Assert
    assert actual == expected


# Generated at 2022-06-24 00:26:48.256072
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_box import Box

    assert Maybe.just(Box('1')).filter(
        lambda v: v == Box('1')
    ) == Maybe.just(Box('1'))

    assert Maybe.just(Box('1')).filter(
        lambda v: v == Box('2')
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda v: v == Box('2')
    ) == Maybe.nothing()


# Generated at 2022-06-24 00:26:52.893630
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    result_1 = Maybe(3, False)\
        .ap(Maybe(lambda x: x + 2, False))

    result_2 = Maybe.just(3)\
        .ap(Maybe.just(lambda x: x + 2))

    assert result_1 == result_2



# Generated at 2022-06-24 00:26:56.858466
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test case for method to_either of Maybe.
    """

    from pymonet.either import Either
    from pymonet.box import Box

    assert Maybe.just('one').to_either() == Box.just('one').to_either()
    assert Maybe.nothing().to_either() == Either.right(None)



# Generated at 2022-06-24 00:27:01.381994
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just('a').get_or_else('b') == 'a'
    assert Maybe.nothing().get_or_else('b') == 'b'


# Generated at 2022-06-24 00:27:03.892900
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: float(x)) == Maybe.just(1.0)
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-24 00:27:12.267796
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    result = Maybe.just(6).bind(
        lambda number: Maybe.just(number / 2)
    )
    assert result == Maybe.just(3)
    assert result != Maybe.just(5)
    assert result != Maybe.nothing()

    result = Maybe.just(3).bind(
        lambda number: Maybe.just(number + 5)
    )
    assert result == Maybe.just(8)
    assert result != Maybe.just(9)
    assert result != Maybe.nothing()

    result = Maybe.nothing().bind(
        lambda number: Maybe.just(number)
    )
    assert result == Maybe.nothing()
    assert result != Maybe.just(None)


# Generated at 2022-06-24 00:27:19.083629
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    m = Maybe.just(10)
    t = m.to_try()
    assert t.is_failure
    assert t.cause == None
    assert t.value == 10

    m = m.map(lambda x: 10/0)
    t = m.to_try()
    assert t.is_failure
    assert t.cause is not None
    assert t.value == None



# Generated at 2022-06-24 00:27:21.926629
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 1) == Maybe.just(3)
    assert Maybe.just(4).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:27:25.113297
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:27:28.672251
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(21)) == Maybe.just(42)
    assert Maybe.just(None).ap(Maybe.just(42)) == Maybe.nothing()

# Generated at 2022-06-24 00:27:31.558903
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:27:34.881184
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe(5, False)
    validated_value = maybe.to_validation()
    assert isinstance(validated_value, Validation)
    assert validated_value.is_success()
    assert validated_value.value == 5

    maybe = Maybe.nothing()
    validated_value = maybe.to_validation()
    assert isinstance(validated_value, Validation)
    assert validated_value.is_success()
    assert validated_value.value is None

# Generated at 2022-06-24 00:27:37.233541
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:41.897200
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x % 2 == 0) == Maybe.just(0)
    assert Maybe.just(0).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:27:45.860272
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x).ap(Maybe.just(2)) == Maybe.just(2)
    assert Maybe.just(lambda x: x).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:27:50.649900
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.just(0) != Maybe.nothing()


# Generated at 2022-06-24 00:28:01.156476
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x+5)) == Maybe.just(8)
    assert Maybe.just(3).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x+5)) == Maybe.nothing()

    def bind(x: int) -> Maybe[int]:
        return Maybe.just(x+5)
    assert Maybe.just(3).bind(bind) == Maybe.just(8)
    assert Maybe.nothing().bind(bind) == Maybe.nothing()

    def bind(x: int) -> Maybe[int]:
        return Maybe.nothing()
    assert Maybe.just(3).bind(bind) == Maybe.nothing()
    assert Maybe.nothing().bind(bind) == Maybe.nothing()


# Generated at 2022-06-24 00:28:07.441664
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from operator import add

    assert Maybe.just(add).ap(Maybe.just(5)).value == 10

    assert Maybe.nothing().ap(Maybe.just(5)).is_nothing
    assert Maybe.just(add).ap(Maybe.nothing()).is_nothing
    assert Maybe.nothing().ap(Maybe.nothing()).is_nothing


# Generated at 2022-06-24 00:28:10.710525
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(10).to_either() == Right(10)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:28:12.570210
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('value') == Maybe.just('value')



# Generated at 2022-06-24 00:28:16.987892
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    m1 = Maybe.just(4)
    m2 = Maybe.just(4)
    m3 = Maybe.just(5)
    m4 = Maybe.nothing()
    m5 = Maybe.nothing()

    # Then
    assert m1 == m2
    assert m1 != m3
    assert m1 != m4
    assert m4 == m5



# Generated at 2022-06-24 00:28:21.093213
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = Maybe.just(1)
    nothing = Maybe.nothing()
    assert value == Maybe.just(1)
    assert not value == Maybe.nothing()
    assert nothing == Maybe.nothing()
    assert not nothing == Maybe.just(2)



# Generated at 2022-06-24 00:28:25.710403
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

# Unit tests for method just of class Maybe

# Generated at 2022-06-24 00:28:28.582710
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)

    assert Maybe.just('abc').map(lambda x: x + 'd') == Maybe.just('abcd')

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:28:32.229883
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 2) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x[2]) == Maybe.nothing()


# Generated at 2022-06-24 00:28:33.350595
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:28:38.221150
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.either import Left, Right

    assert Maybe.just(lambda x: x + 10).ap(Maybe.just(2)) == Maybe.just(12)
    assert Maybe.just(lambda x: x + 50).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:28:41.214134
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(4).get_or_else(3) == 4
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-24 00:28:48.441468
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just([1]).to_lazy() == Lazy(lambda: [1])
    assert Maybe.just([]).to_lazy() == Lazy(lambda: [])
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
