

# Generated at 2022-06-24 00:18:49.425760
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    def test_filterer(value):
        return value is not None

    m = Maybe.just(Box(2))
    assert m.filter(test_filterer) == Maybe.just(Box(2))

    m = Maybe.just(Box(None))
    assert m.filter(test_filterer) == Maybe.nothing()



# Generated at 2022-06-24 00:18:54.486920
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor

    def functor_value(value):
        return Functor.pure(value + "World")

    assert Maybe.just("Hello").ap(functor_value()).value == "HelloWorld"
    assert Maybe.nothing().ap(functor_value()).is_nothing



# Generated at 2022-06-24 00:18:58.256959
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    try:
        assert Maybe.just(1).to_box() == Box(1)
    except:
        print("test_Maybe_to_box - FAIL")
    else:
        print("test_Maybe_to_box - SUCCESS")


# Generated at 2022-06-24 00:19:00.991503
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:19:02.823097
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Maybe.just(1).to_box()
    assert Maybe.nothing().to_box() == Maybe.nothing().to_box()

# Generated at 2022-06-24 00:19:05.401312
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x + 1 == 2) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x + 1 == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x + 1 == 3) == Maybe.nothing()



# Generated at 2022-06-24 00:19:08.032807
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # GIVEN
    a = 1
    b = 2

    # WHEN
    result = Maybe.just(a).bind(lambda a: Maybe.just(a + b))

    # THEN
    assert result == Maybe.just(a + b)



# Generated at 2022-06-24 00:19:12.709529
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just(5).to_either() == Right(5)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:19:15.734394
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe = Maybe.just(3)

    # When
    result = maybe.filter(lambda x: x > 2)

    # Then
    assert result == Maybe.just(3)


# Generated at 2022-06-24 00:19:20.282642
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-24 00:19:23.904443
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(7).to_try() == Try(value=7, is_success=True)
    assert Maybe.nothing().to_try() == Try(value=None, is_success=False)



# Generated at 2022-06-24 00:19:27.059561
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:31.257434
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(-1).to_try() == Try(-1, is_success=True)


# Generated at 2022-06-24 00:19:34.908043
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(1, False).get_or_else(2) == 1
    assert Maybe(None, True).get_or_else(2) == 2


# Generated at 2022-06-24 00:19:43.282236
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 4) == Maybe.just(8)
    assert Maybe.just(2).map(lambda x: x / 0) == Maybe.nothing()
    assert Maybe.just(None).map(lambda x: x[1]) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x * 5) == Maybe.nothing()


# Generated at 2022-06-24 00:19:47.908861
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.applicative import Applicative

    maybe_applicative = Maybe(lambda arg: arg+arg, False)
    result = maybe_applicative.ap(Maybe.just(10))

    assert result == Maybe.just(20)
    assert isinstance(result, Applicative)


# Generated at 2022-06-24 00:19:52.337002
# Unit test for method map of class Maybe
def test_Maybe_map():
    def f(x: int) -> int:
        return x + 1

    assert Maybe.just(5).map(f) == Maybe.just(6)
    assert Maybe.nothing().map(f) == Maybe.nothing()
    assert Maybe.nothing().map(f).map(f) == Maybe.nothing()
    assert Maybe.nothing().map(f).map(f).map(f) == Maybe.nothing()


# Generated at 2022-06-24 00:19:56.032536
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    result = Maybe.just(12) == Maybe.just(12)
    assert result == True
    result = Maybe.just(12) == Maybe.just(13)
    assert result == False
    result = Maybe.nothing() == Maybe.nothing()
    assert result == True
    result = Maybe.nothing() == Maybe.just(12)
    assert result == False
    result = Maybe.nothing() == Maybe.just(None)
    assert result == False


# Generated at 2022-06-24 00:20:00.369406
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test map function of Maybe
    """
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()



# Generated at 2022-06-24 00:20:02.901210
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(3).to_box() == Box(3)


# Generated at 2022-06-24 00:20:06.556947
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test for method to_box of class Maybe.
    """

    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)

test_Maybe_to_box()



# Generated at 2022-06-24 00:20:11.731001
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just('str').filter(lambda x: x == 'strr') == Maybe.nothing()
    assert Maybe.just('str').filter(lambda x: x == 'str') == Maybe.just('str')
    assert Maybe.just('str').filter(lambda x: x == 'str') != Maybe.just('strr')
    assert Maybe.just('str').filter(lambda x: x == 'str') != Maybe.nothing()

# Generated at 2022-06-24 00:20:13.387565
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    assert m1 == m2
    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    assert m1 != m2


# Generated at 2022-06-24 00:20:16.204219
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.box import Box

    success = Maybe.just(1).bind(lambda x: Box(x))
    assert success == Box(1)

    failure = Maybe.nothing().bind(lambda x: Box(x))
    assert failure == Box(None)



# Generated at 2022-06-24 00:20:23.319259
# Unit test for method map of class Maybe
def test_Maybe_map():
    def mapper(x):
        return x * 2

    result = Maybe.just(2).map(mapper)
    assert result == Maybe.just(4)

    result = Maybe.nothing().map(mapper)
    assert result == Maybe.nothing()



# Generated at 2022-06-24 00:20:31.993679
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    test_value_int = Maybe.just(1)
    test_value_empty = Maybe.nothing()

    def bind_function(value):
        return Maybe.just(value + 1)

    def bind_function_for_nothing(value):
        return Maybe.nothing()

    assert test_value_int.bind(bind_function) == Maybe.just(2)
    assert test_value_int.bind(bind_function_for_nothing) == Maybe.nothing()
    assert test_value_empty.bind(bind_function_for_nothing) == Maybe.nothing()
    assert test_value_empty.bind(bind_function) == Maybe.nothing()



# Generated at 2022-06-24 00:20:35.976414
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:20:40.205202
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

# Generated at 2022-06-24 00:20:44.917632
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def mapper(a): return Maybe.just(a + 1)

    # Test for empty Maybe
    assert Maybe.just(None).bind(mapper) == Maybe.nothing()

    # Test for not empty Maybe
    assert Maybe.just(1).bind(mapper) == Maybe.just(2)


# Generated at 2022-06-24 00:20:49.083620
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.monad_try import Try

    assert Maybe.just(10).to_try() == Try(10, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:20:52.443820
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:20:55.331732
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(2).to_validation() == Validation.success(2)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:00.216493
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.just(1).to_either() == Maybe.just(1).to_either()


# Generated at 2022-06-24 00:21:03.142718
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just("test").get_or_else("default") == "test"
    assert Maybe.nothing().get_or_else("default") == "default"

# Generated at 2022-06-24 00:21:13.960816
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import SuccessfulTry
    from pymonet.monad_try import FailedTry
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert isinstance(Maybe.just(1).to_try(), SuccessfulTry)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert isinstance(Maybe.nothing().to_try(), FailedTry)



# Generated at 2022-06-24 00:21:17.776329
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(30).get_or_else(10) == 30
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-24 00:21:21.243971
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(42, False).to_validation() == Validation.success(42)
    assert Maybe(None, True).to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:21:24.283274
# Unit test for method map of class Maybe
def test_Maybe_map():
    value = 'test'
    data = Maybe.just(value)
    assert data.map(lambda v: v.upper()) == Maybe.just(value.upper())
    empty_value = Maybe.nothing()
    assert empty_value.map(lambda v: v.upper()) == Maybe.nothing()
    assert empty_value.map(lambda v: v.upper()).value is None


# Generated at 2022-06-24 00:21:28.881199
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(7) == 5
    assert Maybe.nothing().get_or_else(7) == 7

# Generated at 2022-06-24 00:21:33.532343
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def ap_list(list_to_append):
        def append_to_list(list_value):
            list_value.append(list_to_append)
        return append_to_list

    result = Maybe.just([1, 2, 3]).ap(Maybe.just(ap_list(4)))

    assert result == Maybe.just([1, 2, 3, 4])

# Generated at 2022-06-24 00:21:35.566867
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:21:45.951451
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try, SuccessException

    maybe = Maybe(5, False)
    assert maybe.to_try() == Try(5, is_success=True)

    maybe = Maybe(None, True)
    assert maybe.to_try() == Try(None, is_success=False)

    maybe = Maybe.nothing()
    assert maybe.to_try() == Try(None, is_success=False)

    maybe = Maybe.just("hi")
    assert maybe.to_try() == Try("hi", is_success=True)

    maybe = Maybe(5, False)
    #assert maybe.to_try() == Try(None, is_success=True)

# Generated at 2022-06-24 00:21:48.651041
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-24 00:21:52.974488
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(
        lambda x: Maybe.just(x + 1)) == Maybe.just(2)

    assert Maybe.nothing().bind(
        lambda x: Maybe.just(x + 1)) == Maybe.nothing()

    assert Maybe.just(1).bind(
        lambda x: Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:21:59.030623
# Unit test for constructor of class Maybe
def test_Maybe():
    # Init Box with value=123
    box = Maybe.just(123)
    assert(isinstance(box, Maybe))
    # Init Box with value=None
    nothing = Maybe.nothing()
    assert(isinstance(box, Maybe))
    assert(box.value == 123)
    assert(nothing.get_or_else(123) == 123)


# Generated at 2022-06-24 00:22:02.681001
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def test_1():
        assert Maybe.just(1).to_either() == Right(1)

    def test_2():
        assert Maybe.nothing().to_either() == Left(None)

    test_1()
    test_2()


# Generated at 2022-06-24 00:22:05.108409
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    def assert_maybe_to_either(expected, maybe):
        assert expected == maybe.to_either()

    assert_maybe_to_either(Right(1), Maybe.just(1))
    assert_maybe_to_either(Left(None), Maybe.nothing())



# Generated at 2022-06-24 00:22:13.854373
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.functor_test import add_test
    from pymonet.instances import Box

    def two_to_string(x: int) -> Box[str]:
        return Box(str(x))

    add_test(
        expected=Box('2'),
        actual=Maybe.just(2).bind(two_to_string),
        message='Maybe bind test'
    )


if __name__ == '__main__':
    test_Maybe_bind()

# Generated at 2022-06-24 00:22:15.427355
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:22:21.455935
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    maybe_list = [
        Maybe.just(1),
        Maybe.nothing()
    ]
    expected_list = [
        1,
        None
    ]
    assert [maybe.get_or_else(None)
            for maybe in maybe_list] == expected_list



# Generated at 2022-06-24 00:22:32.512565
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Tests method bind of class Maybe.
    """
    from pymonet.monad_maybe import Maybe

    def divide(a, b):
        if b == 0:
            return Maybe.nothing()
        return Maybe.just(a / b)

    def test_valid(a, b):
        return lambda :divide(a, b)

    def is_even(x):
        return x % 2 == 0

    maybe1 = Maybe.just(2)
    maybe2 = Maybe.nothing()

    assert Maybe.just(-2).bind(test_valid(-2, -1)).filter(is_even).get_or_else(False) == True
    assert Maybe.nothing().bind(test_valid(-2, -1)).filter(is_even).get_or_else(False) == False

# Generated at 2022-06-24 00:22:37.800378
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:22:40.324330
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(True, False).to_validation() == Validation.success(True)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:42.928737
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:45.831637
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(7) == 3
    assert Maybe.nothing().get_or_else(7) == 7



# Generated at 2022-06-24 00:22:48.916425
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:22:58.846327
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()

    assert Maybe.just(lambda x: x + 1).ap(Box(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Right(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Lazy(lambda: 1)) == Maybe.just(2)

# Generated at 2022-06-24 00:23:05.954203
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:23:08.455458
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(3).to_validation() == Validation.success(3)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:23:11.543469
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:23:13.883189
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(3) == 1
    assert Maybe.nothing().get_or_else(3) == 3


# Generated at 2022-06-24 00:23:20.445813
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(10, False).map(lambda x: x + 10) == Maybe.just(20)
    assert Maybe(10, False).map(lambda x: x * 10) == Maybe.just(100)
    assert Maybe(10, False).map(lambda x: x / 10) == Maybe.just(1)
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()
    assert Maybe.just(None).map(lambda x: x + 10) == Maybe.just(None)
    assert Maybe.just(None).map(lambda x: x + 10) == Maybe.just(None)

# Generated at 2022-06-24 00:23:22.502022
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:23:29.029022
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe(1, False)
    assert Maybe(1, False) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1).get_or_else('other') == 1
    assert Maybe.nothing().get_or_else('other') == 'other'


# Generated at 2022-06-24 00:23:31.596696
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("1") == Maybe("1", False)
    assert Maybe.nothing() == Maybe(None, True)
# End of unit test

# Testing Just method

# Generated at 2022-06-24 00:23:42.139246
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    class A:
        def __eq__(self, other):
            return isinstance(other, A) and self.value == other.value

        def __init__(self, value):
            self.value = value

    class B(A):
        pass

    maybe = Maybe.just(A(10))
    assert(maybe.filter(lambda x: isinstance(x, A)).get_or_else(None) == A(10))
    assert(maybe.filter(lambda x: isinstance(x, B)).get_or_else(None) is None)
    assert(Maybe.nothing().filter(lambda x: isinstance(x, A)).get_or_else(None) is None)

    maybe = Maybe.just(10)

# Generated at 2022-06-24 00:23:46.572388
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(0) != '0'

    assert Maybe.just('str') == Maybe.just('str')


# Generated at 2022-06-24 00:23:52.781269
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: None) == Maybe.just(None)



# Generated at 2022-06-24 00:23:56.730712
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    test method Maybe.to_validation
    """
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:24:04.356179
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor

    a = Maybe(Functor(lambda x: x), False)
    b = Maybe.nothing()

    assert a.filter(lambda v: v.val(1) == 1) == Maybe.just(Functor(lambda x: x))
    assert a.filter(lambda v: v.val(1) == 2) == Maybe.nothing()

    assert b.filter(lambda v: v.val(1) == 1) == Maybe.nothing()
    assert b.filter(lambda v: v.val(1) == 2) == Maybe.nothing()

# Generated at 2022-06-24 00:24:13.657519
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # given
    maybe_just = Maybe.just(1)
    maybe_nothing = Maybe.nothing()
    # when
    maybe_just_validation = maybe_just.to_validation()
    maybe_nothing_validation = maybe_nothing.to_validation()
    # then
    assert maybe_just_validation.is_success == True
    assert maybe_nothing_validation.is_success == True
    assert maybe_just_validation.get_or_else(-1) == 1
    assert maybe_nothing_validation.get_or_else(-1) == None


# Generated at 2022-06-24 00:24:17.709669
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Box(1) == Maybe(1, False).to_box()
    assert Box(None) == Maybe(None, True).to_box()


# Generated at 2022-06-24 00:24:24.021532
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Test method to_either of class Maybe.

    :returns: True if method test failed else False
    :rtype: Boolean
    """
    from pymonet.either import Left, Right
    maybe_none = Maybe.nothing()
    maybe_some_value = Maybe.just(5)
    return Left(None) != maybe_none.to_either() or Right(5) != maybe_some_value.to_either()



# Generated at 2022-06-24 00:24:29.147272
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.validation import Nel

    m1 = Maybe.just(3)
    assert m1.to_validation() == Validation.success(3)

    m2 = Maybe.nothing()
    assert m2.to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:32.396800
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    result = Maybe.just(2).get_or_else(3)
    assert result == 2

    result = Maybe.nothing().get_or_else(3)
    assert result == 3


# Generated at 2022-06-24 00:24:36.386821
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def sum(x):
        return x + 1

    assert Maybe.just(3).ap(Maybe.just(sum)) == Maybe.just(4)
    assert Maybe.just(3).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(sum)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:24:38.883693
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 3) is Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x < 3) is Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x > 3) is Maybe.nothing()



# Generated at 2022-06-24 00:24:42.860272
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0



# Generated at 2022-06-24 00:24:45.882257
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y

    apply_func = Maybe.just(add(1))
    assert apply_func.ap(Maybe.just(2)) == Maybe.just(3)
    assert apply_func.ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:24:48.451339
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(0) == Maybe(0, False)
    assert Maybe.just('foo') == Maybe('foo', False)
    assert Maybe.just(None) == Maybe(None, False)

    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:24:52.134125
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.just('something').to_either() == Right('something')
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:24:56.810030
# Unit test for constructor of class Maybe
def test_Maybe():
    value = 1
    is_nothing = True
    maybe = Maybe(value, is_nothing)
    assert maybe.is_nothing == is_nothing
    assert maybe.value == value

    is_nothing = False
    maybe = Maybe(value, is_nothing)
    assert maybe.is_nothing == is_nothing
    assert maybe.value == value


# Generated at 2022-06-24 00:25:01.918567
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:25:11.734925
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.functor_test_class import FunctorTestClass

    assert Maybe.just(FunctorTestClass('test')) == Maybe.just(FunctorTestClass('test'))
    assert Maybe.just(FunctorTestClass('test')) != Maybe.just(FunctorTestClass('test2'))
    assert Maybe.just(FunctorTestClass('test')) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(FunctorTestClass(1)) != Maybe.just(1)
    assert Maybe.just(FunctorTestClass(True)) != Maybe.just(True)
    assert Maybe.just(FunctorTestClass(1.0)) != Maybe.just(1.0)
    assert Maybe.just(FunctorTestClass('1')) != Maybe.just('1')
    assert Maybe

# Generated at 2022-06-24 00:25:17.020725
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:25:20.437271
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:25:31.180850
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Maybe.just(lambda a: a + 1).ap(Maybe.just(2)) == 3
    assert Maybe.just(lambda a: a + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda a: a + 1).ap(Try.success(2)) == 3
    assert Maybe.just(lambda a: a + 1).ap(Try.failure(None)) == None
    assert Maybe.just(lambda a: a + 1).ap(Lazy(lambda: 2)) == 3
   

# Generated at 2022-06-24 00:25:37.251295
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda a: a + 3).ap(Maybe.just(5)) == Maybe.just(8)
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe.just(lambda a: a + 3).ap(Maybe.nothing()) == Maybe.nothing()

# Tests for method bind of class Maybe

# Generated at 2022-06-24 00:25:41.715513
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert(Maybe.just(lambda a: a + 2).ap(Maybe.just(1)) == Maybe.just(3))
    assert(Maybe.just(lambda a: a + 2).ap(Maybe.nothing()) == Maybe.nothing())
    assert(Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing())
    assert(Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing())

# Generated at 2022-06-24 00:25:44.735162
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    """
    assert Maybe.just(0).to_lazy().force() == 0
    assert Maybe.nothing().to_lazy().force() is None

# Generated at 2022-06-24 00:25:51.465049
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Given
    nothing = Maybe.nothing()
    just_none = Maybe.just(None)
    just_2 = Maybe.just(2)
    # When
    res_nothing = nothing.get_or_else(1)
    res_just_none = just_none.get_or_else(1)
    res_just_2 = just_2.get_or_else(1)
    # Then
    assert res_nothing == 1
    assert res_just_none == None
    assert res_just_2 == 2



# Generated at 2022-06-24 00:25:54.755291
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:25:57.223066
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe(42, False).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:26:03.772832
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test they are equal
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.just(1)
    assert maybe_one == maybe_two

    # Test they are not equal
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.just(2)
    assert maybe_one != maybe_two

    # Test one of them is empty
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.nothing()
    assert maybe_one != maybe_two

    # Test all of them are empty
    maybe_one = Maybe.nothing()
    maybe_two = Maybe.nothing()
    assert maybe_one == maybe_two



# Generated at 2022-06-24 00:26:08.897915
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Apply mapper lambda x: x * 2 to Maybe with value 1.

    :returns: True when test will be passed, otherwise exception
    """
    maybe = Maybe.just(1)
    result = maybe.map(lambda x: x * 2)

    assert result == Maybe.just(2)


# Generated at 2022-06-24 00:26:15.951334
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When Maybe is not empty and filterer returns True
    def test_Maybe_filter1():
        assert Maybe.just(5).filter(lambda val: val > 3) == Maybe.just(5)

    # When Maybe is empty
    def test_Maybe_filter2():
        assert Maybe.nothing().filter(lambda val: val > 3) == Maybe.nothing()

    # When Maybe is not empty and filterer returns False
    def test_Maybe_filter3():
        assert Maybe.just(2).filter(lambda val: val > 3) == Maybe.nothing()

    test_Maybe_filter1()
    test_Maybe_filter2()
    test_Maybe_filter3()



# Generated at 2022-06-24 00:26:18.538588
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:23.966850
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test with 'Nothing' monads
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, True) != Maybe(1, False)
    assert Maybe(None, True) != Maybe(1, True)

    # Test with 'Just monads'
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(None, True)
    assert Maybe(1, False) != Maybe(None, False)
    assert Maybe(1, False) != Maybe(2, False)

# Generated at 2022-06-24 00:26:28.638470
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.nothing().bind(lambda x: Maybe.just(x)) == Maybe.nothing()
    assert Maybe.just(3).bind(lambda x: Maybe.just(x * 2)) == Maybe.just(6)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:26:32.407322
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.just(2).to_box() != Box(1)


# Generated at 2022-06-24 00:26:34.405018
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(123).to_box().value == 123
    assert Maybe.nothing().to_box().value == None



# Generated at 2022-06-24 00:26:38.994343
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pytest
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    with pytest.raises(TypeError):
        Maybe.just(Try(1, is_success=True)).to_try()



# Generated at 2022-06-24 00:26:48.804485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.either import Either
    from pymonet.box import Box

    assert Maybe.just("").filter(lambda x: True) == Maybe.just("")
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.just("").filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(123).filter(lambda x: x == 123) == Maybe.just(123)
    assert Maybe.just(123).filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-24 00:26:51.730530
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(2)
    assert maybe.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-24 00:26:54.093967
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:26:54.979510
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    pass


# Generated at 2022-06-24 00:26:59.148617
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(42).map(lambda x: x + 1) == Maybe.just(43)
    assert Maybe.just(42).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()


# Generated at 2022-06-24 00:27:00.931374
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:02.687746
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pytest
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:27:04.654360
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just('test').to_lazy() == Lazy(lambda: 'test')
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:27:12.404148
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x < 4) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 4).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).filter(lambda x: x < 4) == Maybe.just(2)

# Generated at 2022-06-24 00:27:14.955064
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test():
        print('Hello')

    assert Maybe.just(test).to_lazy().get()() == test()
    assert Maybe.nothing().to_lazy().get()() is None


# Generated at 2022-06-24 00:27:18.875099
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(2, False).ap(Maybe(lambda x: 2*x, False)) == Maybe(4, False)
    assert Maybe(2, True).ap(Maybe(lambda x: 2*x, False)) == Maybe(None, True)
    assert Maybe(2, False).ap(Maybe(lambda x: 2*x, True)) == Maybe(None, True)


# Generated at 2022-06-24 00:27:25.243664
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    def mapper(value):
        return Maybe.just(value + 1)

    def mapper2(value):
        return Try.just(value + 1)

    def mapper3(value):
        return Validation.success(value + 1)

    assert Maybe.just(1).bind(mapper) == Maybe.just(2)
    assert Maybe.just(1).bind(mapper2) == Maybe.just(2)
    assert Maybe.just(1).bind(mapper3) == Maybe.just(2)
    assert Maybe.just(1).bind(mapper3).bind(mapper3) == Maybe.just(3)
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()
   

# Generated at 2022-06-24 00:27:29.759211
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit testing for method to_either of class Maybe
    """
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:27:33.939821
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    m = Maybe.nothing()
    assert m.get_or_else(10) == 10

    assert Maybe.just(40).get_or_else(10) == 40



# Generated at 2022-06-24 00:27:36.642341
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(10).to_either() == Maybe.just(10).to_box().to_either()
    assert Maybe.nothing().to_either() == Maybe.nothing().to_box().to_either()



# Generated at 2022-06-24 00:27:40.636048
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.just(5).to_box() != Box(6)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.nothing().to_box() != Box(6)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:27:43.048224
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:44.952766
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(42).get_or_else(0) == 42
    assert Maybe.nothing().get_or_else(0) == 0

# Generated at 2022-06-24 00:27:50.789846
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():  # pragma: no cover
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)

# Generated at 2022-06-24 00:27:52.224356
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe(10, False)



# Generated at 2022-06-24 00:27:57.877692
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0
    assert Maybe.just('Foo').get_or_else('Bar') == 'Foo'
    assert Maybe.nothing().get_or_else('Bar') == 'Bar'


# Generated at 2022-06-24 00:28:00.698137
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('one').to_validation() == Validation.success('one')
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:28:04.697444
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)

# Generated at 2022-06-24 00:28:08.881482
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just('5')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-24 00:28:11.076957
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When
    nothing = Maybe.nothing()
    just = Maybe.just(1)

    # Then
    assert just.filter(lambda value: value == 1) == just
    assert nothing.filter(lambda value: value == 1) == nothing
    assert just.filter(lambda value: value == 2) == nothing


# Generated at 2022-06-24 00:28:13.820624
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Unit test for contructor of class Maybe
    """

    assert Maybe.just("hello") == Maybe('hello', False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:28:17.761749
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just("Hello").to_box() == Box("Hello")
    assert Maybe.just([1, 2, 3]).to_box() == Box([1, 2, 3])


# Generated at 2022-06-24 00:28:25.692127
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != None
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-24 00:28:30.683624
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test for method to_box of class Maybe.
    """
    from pymonet.box import Box
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:28:35.374635
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe.
    """
    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)



# Generated at 2022-06-24 00:28:40.888541
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Should return Left(None)
    assert Maybe.nothing().to_either() == Left(None)

    # Should return Right(1)
    assert Maybe.just(1).to_either() == Right(1)



# Generated at 2022-06-24 00:28:46.290836
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Maybe(5, False).to_try() == Try(5, is_success=True)
    assert Maybe(5, True).to_try() == Try(None, is_success=False)
    assert Maybe(Lazy(lambda: 11), False).to_try().run() == Try(11, is_success=True)
