

# Generated at 2022-06-24 00:18:47.644748
# Unit test for method map of class Maybe
def test_Maybe_map():
    just = Maybe.just(2)
    nothing = Maybe.nothing()
    assert just.map(lambda x: x + 1) == Maybe.just(3)
    assert nothing.map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:18:56.424060
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert isinstance(Maybe.just(None).to_try(), Try)
    assert Maybe.just(None).to_try().is_success
    assert Maybe.just(None).to_try().value is None

    assert isinstance(Maybe.just(1).to_try(), Try)
    assert Maybe.just(1).to_try().is_success
    assert Maybe.just(1).to_try().value == 1

    assert isinstance(Maybe.nothing().to_try(), Try)
    assert not Maybe.nothing().to_try().is_success
    assert Maybe.nothing().to_try().value is None


# Generated at 2022-06-24 00:18:58.624789
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    maybe = Maybe.just(43)
    validation = maybe.to_validation()
    assert validation.value == maybe.value

    maybe = Maybe.nothing()
    validation = maybe.to_validation()
    assert validation.value == maybe.value

# Generated at 2022-06-24 00:19:00.528114
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box().value == Maybe.just(5).value
    assert Maybe.nothing().to_box().value == Maybe.nothing().value


# Generated at 2022-06-24 00:19:06.016380
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(2) == 10
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:19:07.966679
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:19:14.557232
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: True) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-24 00:19:18.369190
# Unit test for method to_either of class Maybe

# Generated at 2022-06-24 00:19:20.761289
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(42) == 5
    assert Maybe.nothing().get_or_else(42) == 42



# Generated at 2022-06-24 00:19:24.775005
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    fa = Maybe.just(lambda x: x*2)
    fb = Maybe.just(lambda x: x+10)

    assert fa.ap(fb) == Maybe.just(lambda x: x*2+10)
    assert fb.ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:19:30.157522
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just('a').to_validation() == Validation.success('a'), \
        'Maybe.just().to_validation() should be Validation.success(Maybe.just().value)'

    assert Maybe.nothing().to_validation() == Validation.success(None), \
        'Maybe.nothing().to_validation() should be Validation.success(None)'

# Generated at 2022-06-24 00:19:38.323986
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(100).filter(lambda x: True) == Maybe.just(100)
    assert Maybe.just(50).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(100).filter(lambda x: x > 0) == Maybe.just(100)
    assert Maybe.just(100).filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-24 00:19:40.668278
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(23).bind(lambda x: Maybe.just(str(x))) == Maybe.just('23')
    assert Maybe.nothing().bind(lambda x: Maybe.just(str(x))) == Maybe.nothing()



# Generated at 2022-06-24 00:19:42.802441
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    maybe = Maybe(1, is_nothing=False)
    assert maybe.to_either() == Right(1)
    maybe_none = Maybe(None, is_nothing=True)
    assert maybe_none.to_either() == Left(None)


# Generated at 2022-06-24 00:19:44.183405
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    value = Maybe.just(5)
    nothing = Maybe.nothing()
    assert value.get_or_else(0) == 5
    assert nothing.get_or_else(0) == 0


# Generated at 2022-06-24 00:19:48.209155
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_true = Maybe.just(0)
    assert maybe_true == Maybe.just(0)
    assert maybe_true == Maybe.just(0)
    maybe_false_1 = Maybe.nothing()
    maybe_false_2 = Maybe.just(0)
    assert maybe_false_1 != maybe_false_2


# Generated at 2022-06-24 00:19:51.974769
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(0).to_box() == Box(0)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:19:56.427462
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe(1, False)
    maybe2 = Maybe(1, False)

    assert maybe1 == maybe2
    
    maybe3 = Maybe(2, False)
    maybe4 = Maybe(2, True)
    maybe5 = Maybe(1, True)
    maybe6 = Maybe(1, False)

    assert not maybe1 == maybe3
    assert not maybe1 == maybe4
    assert not maybe1 == maybe5
    assert maybe1 == maybe6


# Generated at 2022-06-24 00:20:06.954623
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    t_monad = Maybe.just(1)
    f_monad = Maybe.nothing()

    assert t_monad.to_either() == Box(1)
    assert f_monad.to_either() == Box(None)

    assert isinstance(t_monad.to_either(), Lazy)
    assert isinstance(f_monad.to_either(), Lazy)

    assert t_monad.to_either() == Try(1, is_success=True)
    assert f_monad.to_either() == Try(None, is_success=False)

# Generated at 2022-06-24 00:20:10.385436
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # false
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    # false
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-24 00:20:15.713551
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe(2, is_nothing=False).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(4)
    assert Maybe(2, is_nothing=True).bind(lambda x: Maybe.just(x + 2)) == Maybe.nothing()


# Generated at 2022-06-24 00:20:20.968493
# Unit test for constructor of class Maybe
def test_Maybe():
    def test_is_instance_of():
        maybe = Maybe.just(5)
        assert isinstance(maybe, Maybe) is True

    def test_is_nothing():
        maybe = Maybe.just(5)
        assert maybe.is_nothing is False

        maybe = Maybe.nothing()
        assert maybe.is_nothing is True

    def test_constructor():
        maybe = Maybe.just(5)
        assert maybe.value == 5

        maybe = Maybe.nothing()
        assert maybe.value is None

    test_is_instance_of()
    test_is_nothing()
    test_constructor()


# Generated at 2022-06-24 00:20:23.434429
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    maybe = Maybe.just("a")
    assert(maybe.to_validation() == Validation.success("a"))

    maybe = Maybe.nothing()
    assert(maybe.to_validation() == Validation.success(None))


# Generated at 2022-06-24 00:20:27.338880
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(10, False).to_try() == Try(10, True)
    assert Maybe.nothing().to_try() == Try(None, False)

# Generated at 2022-06-24 00:20:28.974999
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert isinstance(Maybe.nothing().to_box(), Maybe)
    assert str(Maybe.nothing().to_box()) == str(Box(None))


# Generated at 2022-06-24 00:20:34.808656
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-24 00:20:36.927993
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(2) == Maybe(2, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:20:40.812217
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.just(1).to_try().map(lambda x: x + 1) == Try(2, True)
    assert Maybe.nothing().to_try() == Try(None, False)
    assert Maybe.nothing().to_try().map(lambda x: x + 1) == Try(None, False)

# Generated at 2022-06-24 00:20:45.702752
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(None) != Maybe.just(1)


# Generated at 2022-06-24 00:20:48.958795
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    v = Maybe(None, True)
    assert v.to_box() == Box(None)

    v = Maybe(42, False)
    assert v.to_box() == Box(42)


# Generated at 2022-06-24 00:20:52.254983
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(2)
    assert a.filter(lambda x: x == 2).value == 2
    assert Maybe.just(2).filter(lambda x: x == 3).is_nothing
    assert Maybe.nothing().filter(lambda x: x == 2).is_nothing



# Generated at 2022-06-24 00:20:56.211944
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(4.5) == Maybe.just(4.5)

    assert Maybe.just('test1') != Maybe.just('test2')
    assert Maybe.just(True) != Maybe.just(False)
    assert Maybe.just(2) != Maybe.just(4)

    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:21:00.849319
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda v: v == 2) == Maybe.nothing()

    assert Maybe.just(1).filter(lambda v: v == 2) == Maybe.nothing()

    assert Maybe.just(2).filter(lambda v: v == 2) == Maybe.just(2)



# Generated at 2022-06-24 00:21:03.230760
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(1)
    assert Maybe.just(1) == m



# Generated at 2022-06-24 00:21:08.028280
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: x + 1, False).ap(Maybe.just(4)) == Maybe.just(5)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(4)) == Maybe.nothing()


# Generated at 2022-06-24 00:21:09.818084
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.nothing().to_validation() == Validation.success(None)
    assert Maybe.just(1).to_validation() == Validation.success(1)

# Generated at 2022-06-24 00:21:13.137963
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(2, False).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:21:15.905980
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    import pytest
    from pymonet.validation import Validation
    def test_with_just():
        maybe = Maybe.just(1)
        assert maybe.to_validation() == Validation.success(1)
    def test_with_nothing():
        maybe = Maybe.nothing()
        assert maybe.to_validation() == Validation.success(None)
    test_with_just()
    test_with_nothing()



# Generated at 2022-06-24 00:21:19.494733
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)



# Generated at 2022-06-24 00:21:23.351068
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Testing Maybe constructor

    :returns: None
    :raises: AssertionError
    """
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1) != Maybe(1, True)



# Generated at 2022-06-24 00:21:32.961173
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.validation import Validation

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: type(x) == int) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: type(x) == float) == Maybe.nothing()


# Generated at 2022-06-24 00:21:34.378353
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    assert Maybe.just('python').to_box() == Box('python')
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:21:42.048561
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe(lambda x: 3 * x, False).ap(Maybe(lambda y: 2 * y, False)) == Maybe(6, False)
    assert Maybe(lambda x: 3 * x, False).ap(Maybe(None, True)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(lambda y: 2 * y, False)) == Maybe(None, True)
    assert Maybe(None, True).ap(Maybe(None, True)) == Maybe(None, True)

# Generated at 2022-06-24 00:21:44.960209
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.is_nothing
    maybe_just = Maybe.just(1)
    assert maybe_just.value == 1
    assert not maybe_just.is_nothing



# Generated at 2022-06-24 00:21:49.632622
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Testing to_validation method.

    :return: True if test passed otherwise False
    :rtype: Boolean
    """
    from pymonet.validation import Validation

    assert Maybe(5, False).to_validation() == Validation.success(5)
    assert Maybe(None, True).to_validation() == Validation.success(None)
    return True


# Generated at 2022-06-24 00:21:52.288811
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just("some").to_try() == Try("some", is_success=True)

    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:21:55.732439
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    result = Maybe.just(1).to_lazy().get_value()
    expected = 1
    assert (result == expected)



# Generated at 2022-06-24 00:22:01.445807
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    maybe_with_value_type = Maybe.just(1)
    maybe_without_value_type = Maybe.nothing()

    # Test for
    #   * Maybe with value
    #   * Maybe without value
    assert maybe_with_value_type.to_try() == Try(1, True)
    assert maybe_without_value_type.to_try() == Try(None, False)



# Generated at 2022-06-24 00:22:08.448719
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    m1 = Maybe.just(4)
    m2 = Maybe.nothing()

    a1 = m1.to_either()
    a2 = m2.to_either()

    assert a1 == Right(4)
    assert a2 == Left(None)


# Generated at 2022-06-24 00:22:13.228111
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test for method .bind of Maybe monad.
    """
    assert Maybe.just(2).bind(lambda item: Maybe.just(item ** 2)) == Maybe.just(4)
    assert Maybe.nothing().bind(lambda item: Maybe.just(item)) == Maybe.nothing()

# Generated at 2022-06-24 00:22:16.068592
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try

    assert Maybe.just(lambda x: x + 1).ap(Try.pure(2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Try.pure(2)) == Maybe.nothing()



# Generated at 2022-06-24 00:22:21.397193
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else('Not Nothing') == 'Not Nothing'
    assert Maybe.just('Hello').get_or_else('Not Nothing') == 'Hello'


# Generated at 2022-06-24 00:22:26.237445
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(8) == 3
    assert Maybe.nothing().get_or_else(8) == 8



# Generated at 2022-06-24 00:22:35.244959
# Unit test for method map of class Maybe
def test_Maybe_map():
    def add_2(n: int) -> int:
        return n + 2

    def divide_2(n: int) -> float:
        return n / 2

    def raise_exception(n: int) -> int:
        raise TypeError('Some error')

    assert Maybe.just(1).map(add_2) == Maybe.just(3)

    assert Maybe.just(1).map(divide_2) == Maybe.just(0.5)

    assert Maybe.just(1).map(raise_exception) == Maybe.nothing()

    assert Maybe.nothing().map(add_2) == Maybe.nothing()



# Generated at 2022-06-24 00:22:42.395409
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.just(1).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:22:45.453108
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Unit test for method to_validation of class Maybe
    """
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:22:49.981489
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe[int].just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:22:54.115509
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print('> test_Maybe_to_lazy')
    m = Maybe.just(1).to_lazy()
    assert m() == 1
    m = Maybe.nothing().to_lazy()
    assert m() is None


# Generated at 2022-06-24 00:22:56.927558
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:23:00.614993
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Test that maybe.bind works.

    :return: None
    :rtype: None
    """
    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:23:03.578916
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(5, False) == Maybe.just(5)



# Generated at 2022-06-24 00:23:07.622011
# Unit test for constructor of class Maybe
def test_Maybe():
    from pymonet.test.test_helpers import test
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    test([
        ('nothing', Maybe.nothing(), Maybe.nothing()),
        ('just', Maybe.just(1), Maybe.just(1))
    ])


# Generated at 2022-06-24 00:23:09.568124
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right

    assert Maybe.just(22).to_either() == Right(22)
    assert Maybe.nothing().to_either() != Right(22)


# Generated at 2022-06-24 00:23:15.212471
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:23:19.639396
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(5) == Maybe(5, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:23:20.261792
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    pass

# Generated at 2022-06-24 00:23:26.336984
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just('x') == Maybe.just('x').map(lambda x: x)
    assert Maybe.just(2) == Maybe.just(1).map(lambda x: x + 1)
    assert Maybe.nothing() == Maybe.nothing().map(lambda x: x + 1)
    Maybe.just(21).map(print)
    assert Maybe.just(10) == Maybe.just(7).map(lambda x: x + 3)
    assert Maybe.nothing() == Maybe.just(None).map(lambda x: x + 3)


# Generated at 2022-06-24 00:23:29.750385
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(23).map(lambda x: x * 2) == Maybe.just(46)
    assert Maybe.just(23).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: 2) == Maybe.nothing()


# Generated at 2022-06-24 00:23:33.909797
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    with Box(lambda x: x + 1) as box:
        assert Maybe.just(1).ap(box).get_or_else(None) == 2

    with Box(lambda x: x + 1) as box:
        assert Maybe.nothing().ap(box).get_or_else(None) is None

# Generated at 2022-06-24 00:23:41.111088
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    import pytest
    from pymonet.monad_try import Try

    # valid Maybe
    maybe_unit = Maybe.just(5)
    try_unit = Try(5, is_success=True)
    assert try_unit == maybe_unit.to_try()

    # empty Maybe
    maybe_unit = Maybe.nothing()
    try_unit = Try(None, is_success=False)
    assert try_unit == maybe_unit.to_try()


# Generated at 2022-06-24 00:23:44.492407
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m1 = Maybe.just(lambda x: x + 10)
    m2 = Maybe.just(5)
    assert m1.ap(m2) == Maybe.just(15)
    m1 = Maybe.nothing()
    m2 = Maybe.just(5)
    assert m1.ap(m2) == Maybe.nothing()
    m1 = Maybe.just(lambda x: x + 10)
    m2 = Maybe.nothing()
    assert m1.ap(m2) == Maybe.nothing()

# Generated at 2022-06-24 00:23:46.559849
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(0).to_validation() == Validation.success(0)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:23:52.486340
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('test').to_validation() == Validation.success('test')
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:23:57.389977
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    # Given
    some = Maybe.just(1)
    nothing = Maybe.nothing()

    # When
    some_box = some.to_box()
    nothing_box = nothing.to_box()

    # Then
    assert some_box.value == some.value
    assert nothing_box.value == nothing.value



# Generated at 2022-06-24 00:23:59.421975
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:24:02.250503
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.nothing()
    
    assert maybe_1.to_lazy().get() == 1
    assert maybe_2.to_lazy().get() == None

# Generated at 2022-06-24 00:24:04.640921
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(42, False) == Maybe(42, False)
    assert Maybe(42, True) != Maybe(43, True)



# Generated at 2022-06-24 00:24:11.070452
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x + 1) == Maybe.just(3)
    assert Maybe.just(None).map(lambda x: x) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x) == Maybe.nothing()


# Generated at 2022-06-24 00:24:19.106886
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.validation import Validation

    assert Maybe.just(3).get_or_else(4) == 3
    assert Maybe.nothing().get_or_else('nope') == 'nope'
    # assert  Maybe.just(Validation.success(5)).get_or_else(Validation.success(4)) == Validation.success(5)


# Generated at 2022-06-24 00:24:23.315385
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()



# Generated at 2022-06-24 00:24:29.268608
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # GIVEN
    maybe12: Maybe[int] = Maybe.just(12)
    def mapper(x: int) -> Maybe[int]:
        if x < 14:
            return Maybe.just(x*2)
        else:
            return Maybe.nothing()

    # WHEN
    result = maybe12.bind(mapper)

    # THEN
    assert result == Maybe.just(24)



# Generated at 2022-06-24 00:24:32.444798
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:24:34.417404
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe(None, True).map(lambda x: x + 1) == Maybe(None, True)



# Generated at 2022-06-24 00:24:39.473321
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    just = Maybe.just(1)
    assert just.to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:24:45.055880
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.

    :returns: None, unit test
    :rtype: None
    """
    from pymonet.list import List

    def func(value: List[int]) -> Maybe[List[int]]:
        return Maybe.just(value.reverse())

    assert len(Maybe.just(List(1, 2, 3)).bind(func)) == 3



# Generated at 2022-06-24 00:24:50.187205
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    # Case when Maybe is not empty
    maybe = Maybe.just(1)
    assert maybe.to_either() == Right(1)

    # Case when Maybe is empty
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:24:52.575199
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    test1 = Maybe.just(lambda x: x + 1)
    test2 = Maybe.nothing()
    assert test1.ap(Maybe.just(1)) == Maybe.just(2)
    assert test1.ap(Maybe.nothing()) == Maybe.nothing()
    assert test2.ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:24:56.236580
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from .either import Left, Right

    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.just(123).to_either() == Right(123)
    assert Maybe.nothing().to_either() == Left(None)



# Generated at 2022-06-24 00:25:00.230838
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    try_m = Try(1)
    assert Maybe.just(1).bind(Try) == try_m

    validation_m = Validation.success(1)
    assert Maybe.just(1).bind(Validation.success) == validation_m


# Generated at 2022-06-24 00:25:04.882808
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(6)

    assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()



# Generated at 2022-06-24 00:25:08.950001
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Unit test for method map of class Maybe
    assert Maybe.just(12).map(lambda x: x + 1) == Maybe.just(13)

    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:25:14.856112
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    value = 1
    maybe = Maybe.just(value)
    expected = maybe.to_either().then(
        lambda x: x + 1,
        lambda: value
    ).get_value()
    actual = maybe.map(lambda x: x + 1).to_either().then(
        lambda x: x,
        lambda: value
    ).get_value()
    assert actual == expected



# Generated at 2022-06-24 00:25:19.339948
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:25:23.715002
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:25:27.393981
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(10).bind(lambda a: Maybe.just(a**2)) == Maybe.just(100)
    assert Maybe.nothing().bind(lambda a: Maybe.just(a**2)) == Maybe.nothing()



# Generated at 2022-06-24 00:25:31.659158
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).get_or_else(None) == 2
    assert Maybe.just(3).filter(lambda x: x % 2 == 0).get_or_else(None) is None
    assert Maybe.nothing().filter(lambda x: x is None).get_or_else(None) is None


# Generated at 2022-06-24 00:25:34.653061
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:25:38.751480
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    :returns: None if test passed
    :raises: AssertionError if test failed
    """
    assert Maybe.just(3).filter(lambda v: v % 2 == 0) == \
           Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v % 2 == 0) == \
           Maybe.nothing()

test_Maybe_filter()

# Generated at 2022-06-24 00:25:41.673643
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(3)



# Generated at 2022-06-24 00:25:45.991548
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    def f(x: int) -> Maybe[int]:
        if x == 2:
            return Maybe.just(x)
        return Maybe.nothing()

    assert f(1).to_try() == Try(None, is_success=False)
    assert f(2).to_try() == Try(2, is_success=True)


# Generated at 2022-06-24 00:25:56.376356
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.functor import Functor

    def t(value: int) -> int:
        return value * 2

    def f(value: int) -> bool:
        return value % 2 == 0

    mapper = lambda value: value * 2
    maybe = Maybe.just(2)
    assert maybe.map(mapper) == Maybe.just(4)
    assert maybe.map(lambda value: None) == Maybe.nothing()
    assert maybe.map(mapper).map(mapper) == Maybe.just(8)

    maybe = Maybe.nothing()

# Generated at 2022-06-24 00:26:00.988703
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(1).to_box() == Box(1)


# Generated at 2022-06-24 00:26:04.458593
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 3) == Maybe(6, False)

    assert Maybe.nothing().map(lambda x: x * 3) == Maybe(None, True)



# Generated at 2022-06-24 00:26:08.800261
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:11.746038
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Test method get_or_else of class Maybe
    """
    assert Maybe.just(10).get_or_else(100) == 10
    assert Maybe.nothing().get_or_else(100) == 100



# Generated at 2022-06-24 00:26:15.557623
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():

    # Given
    m = Maybe.just(1)
    empty_m = Maybe.nothing()

    # When
    v = m.get_or_else(2)
    empty_v = empty_m.get_or_else(2)

    # Then
    assert v == 1
    assert empty_v == 2



# Generated at 2022-06-24 00:26:17.110162
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:23.362378
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.list import List

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just([1, 2]) == Maybe.just([1, 2])
    assert Maybe.just(List.just(1)) == Maybe.just(List.just(1))
    assert Maybe.just(List.just(1)) != Maybe.just(List.just(2))
    assert Maybe.just(List.just(1)) != Maybe.just(List.nothing())
    assert Maybe.just(List.just(1)) != Maybe.just(List.just([1, 2]))


# Generated at 2022-06-24 00:26:27.662963
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(2).map(lambda x: x ** 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-24 00:26:30.185529
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x > 0) == Maybe(5, False)
    assert Maybe(0, False).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe(-5, False).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe(-5, True).filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-24 00:26:34.434055
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(100, False).to_box() == Box(100)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:26:38.640503
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # given
    from pymonet.maybe import Maybe

    # then
    assert Maybe.just(lambda x: x*2).ap(Maybe.just(2)) == Maybe.just(4)
    assert Maybe.just(lambda x: x*2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:26:43.746254
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.lazy import Lazy

    mb_lazy_plus_two = Maybe.just(lambda x: x + 2)
    assert mb_lazy_plus_two.ap(Lazy(lambda: 2)) == Maybe.just(4)
    mb_lazy_plus_two = Maybe.nothing()
    assert mb_lazy_plus_two.ap(Lazy(lambda: 2)) == Maybe.nothing()



# Generated at 2022-06-24 00:26:46.382349
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation, Failure

    def to_validation_test(x: Maybe[int], y: Validation):
        return x.to_validation() == y

    assert to_validation_test(Maybe.just(2), Validation.success(2))
    assert to_validation_test(Maybe.nothing(), Validation.success(None))


# Generated at 2022-06-24 00:26:52.686311
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.lazy import Lazy

    assert Maybe.just(lambda x: x + 1).ap(Lazy(lambda: 2)) == Maybe.just(3)
    assert Maybe.nothing().ap(Lazy(lambda: 2)) == Maybe.nothing()


# Generated at 2022-06-24 00:27:00.949574
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    def mapper(value):
        if value:
            return Maybe.just(value)
        return Maybe.nothing()

    assert Maybe.just("result").bind(mapper) == Maybe.just("result")
    assert Maybe.just("").bind(mapper) == Maybe.nothing()
    assert Maybe.nothing().bind(mapper) == Maybe.nothing()

    def mapper_try(value):
        if value:
            return Try("result")
        return Try("", success=False)

    assert Maybe.just("").bind(mapper_try) == Maybe.nothing()
    assert Maybe.just("result").bind(mapper_try) == Maybe.just("result")

# Generated at 2022-06-24 00:27:07.595763
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    maybe_with_value = Maybe.just(5)
    maybe_empty = Maybe.nothing()

    assert maybe_with_value.to_box() == Box(5)
    assert maybe_empty.to_box() == Box(None)


# Generated at 2022-06-24 00:27:11.500104
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:14.796990
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right
    from pymonet.box import Box

    maybe = Box(1)

    assert maybe.to_either() == Right(1)

    maybe = Box()

    assert maybe.to_either() == Left(None)



# Generated at 2022-06-24 00:27:20.461902
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad import Identity
    f = lambda x: x ** 2
    id = Identity(f)
    result = Maybe.just(3).ap(id)
    assert isinstance(result, Maybe)
    assert result == Maybe.just(9)

# Generated at 2022-06-24 00:27:23.851164
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2

# Generated at 2022-06-24 00:27:29.807025
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.identity import Identity
    from pymonet.box import Box

    assert Identity(lambda x: x * 2).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(lambda x: x * 2).ap(Box(2)) == Maybe.just(4)



# Generated at 2022-06-24 00:27:36.506758
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.nothing().to_either() == Left(None), "test_Maybe_to_either: Should be Nothing."
    assert Maybe.just(1).to_either() == Right(1), "test_Maybe_to_either: Should be Just(1)."
    assert Maybe.just(1).to_either() == Maybe.just(1).to_box().to_either(), "test_Maybe_to_either: Should be Just(1)."


# Generated at 2022-06-24 00:27:41.497545
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just("qwerty") == Maybe.just("qwerty")
    assert not (Maybe.just("qwerty") == Maybe.just("qwert"))
    assert Maybe.just("qwerty") == Maybe.just("qwerty")
    assert Maybe.nothing() == Maybe.nothing()
    assert not (Maybe.nothing() == Maybe.just("qwerty"))



# Generated at 2022-06-24 00:27:43.234905
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(None, True) == Maybe.nothing()


# Generated at 2022-06-24 00:27:45.129916
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:27:50.574146
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(a):
        return lambda b: a + b
    a = Maybe.just(2)
    b = Maybe.just(10)
    assert Maybe.just(add(2)).ap(b) == Maybe.just(12)
    assert Maybe.nothing().ap(b) == Maybe.nothing()



# Generated at 2022-06-24 00:27:54.238590
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else(2) == 2
    assert Maybe.just(1).get_or_else(2) == 1


# Generated at 2022-06-24 00:27:59.961270
# Unit test for method map of class Maybe
def test_Maybe_map():
    result = Maybe.just(2).map(lambda x: x * 2)
    assert result == Maybe(4, False)

    result = Maybe.nothing().map(lambda x: x * 2)
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:28:04.379282
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Right('')) == Maybe.just('').to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

# Generated at 2022-06-24 00:28:11.186866
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    # :)
    assert Maybe.just(123).to_box() == Box(123)
    assert Maybe.nothing().to_box() == Box(None)

    # :(
    assert Maybe.just(123).to_box() != Box(456)
    assert Maybe.just(123).to_box() != Box(None)
    assert Maybe.nothing().to_box() != Box(456)


# Generated at 2022-06-24 00:28:13.918658
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Given
    maybe = Maybe.just(10)

    # When
    result = maybe.map(lambda x: x ** 2)

    # Then
    assert result == Maybe.just(100)


# Generated at 2022-06-24 00:28:15.937710
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(None, True).is_nothing
    assert Maybe(10, False).value == 10


# Generated at 2022-06-24 00:28:21.870307
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.monad import Monad, Applicative, Functor
    from pymonet.validation import Validation
    from pymonet.applicative import Applicative
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.box import Box
    from pymonet.identity import Identity
    from pymonet.lazy import Lazy
    import pytest

    assert isinstance(Maybe.just('string').to_validation(), Validation)
    assert isinstance(Maybe.just('string').to_validation(), Applicative)
    assert isinstance(Maybe.just('string').to_validation(), Functor)
    assert isinstance(Maybe.just('string').to_validation(), Monad)
    assert Maybe.just('string').to_validation().value

# Generated at 2022-06-24 00:28:23.052839
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)


# Generated at 2022-06-24 00:28:25.138174
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    mb = Maybe.just(1)
    assert mb == mb.to_either()
    assert Maybe.just(1) == Maybe.just(1).to_either()
    assert Maybe.nothing() == Maybe.nothing().to_either()



# Generated at 2022-06-24 00:28:28.876207
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:28:36.469755
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    import pytest
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from operator import mul

    def test_with_int_value():
        def multiply_by_3(value):
            return value * 3
        value = Maybe.just(3)
        result = value.ap(Lazy(multiply_by_3))
        assert result == Maybe.just(9)

    def test_with_string_value():
        def concat_with_str(char):
            return '{0}{1}'.format('wow', char)
        value = Maybe.just('a')
        result = value.ap(Lazy(concat_with_str))
        assert result == Maybe.just('wowa')

    def test_with_value_None():
        value = Maybe.nothing()


# Generated at 2022-06-24 00:28:40.441807
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:28:46.602603
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    a = Maybe.just(5)
    assert a.to_try() == Try(5, is_success=True)

    b = Maybe.nothing()
    assert b.to_try() == Try(None, is_success=False)
