

# Generated at 2022-06-24 00:18:48.071693
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    def get_value() -> Maybe[int]:
        """
        Get some value.

        :returns: Maybe[Int] with value or empty Maybe
        """
        if random.random() > 0.5:
            return Maybe.just(3)
        return Maybe.nothing()

    m = get_value()
    assert m.get_or_else(0) == 3 or m.get_or_else(0) == 0, "Method get_or_else of Maybe class returned incorrect value."



# Generated at 2022-06-24 00:18:51.942326
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(123).to_lazy() == Lazy(lambda: 123)

# Generated at 2022-06-24 00:18:53.620669
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just('test').to_box() == Box('test')
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:18:56.420339
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda value: value) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda value: False) == Maybe.nothing()


# Generated at 2022-06-24 00:18:58.391740
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # return non empty Maybe
    assert Maybe.just(1).to_either() == Right(1)
    # return empty Maybe
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:19:01.695517
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda a: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda a: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: False) == Maybe.nothing()



# Generated at 2022-06-24 00:19:06.167639
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:19:08.345233
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(11).to_validation() == Validation.success(11)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:19.438709
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def non_strict_equal(a, b):
        # Class for non strict equal comparator
        class NonStrictEqual:
            def __eq__(self, other):
                return True
        # Represent any value as non strict equal comparator
        return NonStrictEqual()
    # Test case 1:
    m1 = Maybe.just(1)
    n1 = Maybe.just(non_strict_equal(1, 1))
    # Test case 2:
    m2 = Maybe.just(non_strict_equal(1, 1))
    n2 = Maybe.just(1)
    # Test case 3:
    m3 = Maybe.just(non_strict_equal(1, 1))
    n3 = Maybe.just(non_strict_equal(1, 1))
    # Check test cases
   

# Generated at 2022-06-24 00:19:23.026244
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:19:29.387109
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def get_user():
        return Maybe.just(User("John"))

    def get_role_name(user: User) -> Maybe[str]:
        if user.role_id == 2:
            return Maybe.just("Admin")
        return Maybe.nothing()

    assert Maybe.just(User(2)) \
        .bind(get_user) \
        .bind(get_role_name) == Maybe.just("Admin")


# Generated at 2022-06-24 00:19:34.118865
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left

    assert Maybe(10, False).bind(lambda v: Maybe.just(v * 2)) == Maybe.just(20)
    assert Maybe(10, False).bind(lambda v: Maybe.nothing()) == Maybe.nothing()
    assert Maybe(None, True).bind(lambda v: Maybe.nothing()) == Maybe.nothing()

    assert Maybe(10, False).bind(lambda v: Left(v * 2)) == Maybe.nothing()



# Generated at 2022-06-24 00:19:40.058888
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    print('test_Maybe_to_lazy')
    my_monad = Maybe.just(10)
    my_monad_lazy = my_monad.to_lazy()
    assert my_monad_lazy.evaluate() == 10
    my_monad = Maybe.nothing()
    my_monad_lazy = my_monad.to_lazy()
    assert my_monad_lazy.evaluate() is None


# Generated at 2022-06-24 00:19:43.464601
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:19:51.953196
# Unit test for method ap of class Maybe
def test_Maybe_ap(): # pragma: no cover
    """
    Unit test for method ap of class Maybe.

    :returns: success
    :rtype: Boolean
    """
    from pymonet.either import Either, Left, Right

    def func(i): # pragma: no cover
        return i * 2

    m_just_func = Maybe.just(func)

    m_empty_func = Maybe.nothing()

    assert m_just_func.ap(Maybe.just(2)) == Maybe.just(4)
    assert m_empty_func.ap(Maybe.just(2)) == Maybe.nothing()

    assert m_just_func.ap(Maybe.nothing()) == Maybe.nothing()
    assert m_empty_func.ap(Maybe.nothing()) == Maybe.nothing()

    return True


# Generated at 2022-06-24 00:19:56.405500
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # Given
    maybe_1 = Maybe.just(1)
    expected_1 = Try(1, is_success=True)
    # When
    result_1 = maybe_1.to_try()
    # Then
    assert result_1 == expected_1

    # Given
    maybe_2 = Maybe.nothing()
    expected_2 = Try(None, is_success=False)
    # When
    result_2 = maybe_2.to_try()
    # Then
    assert result_2 == expected_2


# Generated at 2022-06-24 00:20:05.165848
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Define assert method
    def assert_method(act_value, exp_value):
        assert act_value == exp_value, 'value is not correct'
    # Create instance of Maybe
    maybe = Maybe.just(21)
    # Define expected value
    exp_value = maybe.to_either()
    # Get actual value with to_either method
    act_value = maybe.to_either()
    # Call assert method
    assert_method(act_value, exp_value)
    print('test_Maybe_to_either is OK')
test_Maybe_to_either()


# Generated at 2022-06-24 00:20:07.878538
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just('value') == Maybe('value', False)
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-24 00:20:11.653625
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(lambda x: x + 1).bind(lambda f: Maybe((f(3), f(5)))) == Maybe.just((4, 6))
    assert Maybe.nothing().bind(lambda f: Maybe((f(3), f(5)))) == Maybe.nothing()


# Generated at 2022-06-24 00:20:15.096915
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)



# Generated at 2022-06-24 00:20:20.662338
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-24 00:20:24.631048
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.functor import Functor
    from pymonet.monad_maybe import Maybe

    functor = Functor(Maybe.just, Maybe.nothing)
    func = functor(lambda x: x + 5)
    assert func(Maybe.just(5)) == Maybe.just(10)
    assert func(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:20:25.777504
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(123).to_box() == Box(123)



# Generated at 2022-06-24 00:20:29.011219
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import Lazy

    def lazy_function(x):
        return lambda: x

    maybe_result = Maybe.just(5)
    lazy_result = Lazy(lazy_function(5))

    assert maybe_result.to_lazy() == lazy_result



# Generated at 2022-06-24 00:20:38.734834
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.validation import Validation

    maybe_just = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    assert maybe_just == Maybe.just(1)
    assert maybe_nothing == Maybe.nothing()
    assert maybe_just != Maybe.just(2)
    assert maybe_nothing != Maybe.just(2)
    assert maybe_just != maybe_nothing
    assert maybe_just != None
    assert maybe_nothing != None
    assert maybe_just != Left(None)
    assert maybe_nothing != Left(None)
    assert maybe_just != Right(None)
    assert maybe_nothing != Right(None)

# Generated at 2022-06-24 00:20:41.609527
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(2) == 1
    assert Maybe.nothing().get_or_else(2) == 2


# Generated at 2022-06-24 00:20:46.208773
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    maybe = Maybe.just(1)
    expected = Lazy(lambda: 1)

    # When
    actual = maybe.to_lazy()

    # Then
    assert expected == actual


# Generated at 2022-06-24 00:20:50.055284
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Unit test for method to_box of class Maybe.
    """
    from pymonet.box import Box

    m = Maybe.just(1)
    assert m.to_box() == Box(1)

    m = Maybe.nothing()
    assert m.to_box() == Box(None)



# Generated at 2022-06-24 00:20:56.700031
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # arrange
    applicative_maybe = Maybe.just(lambda x: x + 1)
    tested_maybe = Maybe.just(5)

    # act
    result = tested_maybe.ap(applicative_maybe)

    # assert
    assert result == Maybe.just(6)


# Generated at 2022-06-24 00:21:02.783562
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    just_maybe = Maybe.just(1)
    nothing_maybe = Maybe.nothing()

    def test_function(value: int) -> Maybe[int]:
        return Maybe.just(value + 1)

    assert Maybe.bind(just_maybe, test_function) == Maybe.just(2)
    assert Maybe.bind(nothing_maybe, test_function) == Maybe.nothing()
    assert Maybe.bind(test_function, Maybe.just(2)) == Maybe.just(3)


# Generated at 2022-06-24 00:21:06.065700
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.just(10).to_try() == Try(10)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:21:09.935941
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def _fail():
        raise Exception()

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(_fail)


# Generated at 2022-06-24 00:21:12.945425
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy().value() == None
    assert Maybe.just(1).to_lazy().value() == 1
    assert Maybe.just(2).to_lazy().value() == 2


# Generated at 2022-06-24 00:21:15.621557
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    maybe = Maybe.just(lambda x: x*2)
    maybe_ = maybe.ap(Maybe.just(2))
    assert maybe_.value == 4

# Generated at 2022-06-24 00:21:18.629743
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:21:22.638859
# Unit test for method map of class Maybe
def test_Maybe_map():
    def mapper(value):
        return value + 1
    assert Maybe.just(1).map(mapper) == Maybe.just(2)
    assert Maybe.nothing().map(mapper) == Maybe.nothing()


# Generated at 2022-06-24 00:21:29.462833
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    f = lambda x: x * 2
    result = Maybe(f, False).ap(Maybe.just(2))
    assert result == Maybe.just(4)

    result = Maybe.nothing().ap(Maybe.just(2))
    assert result == Maybe.nothing()

    result = Maybe(f, False).ap(Maybe.nothing())
    assert result == Maybe.nothing()


# Generated at 2022-06-24 00:21:30.996848
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(123).to_either() == Right(123)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:40.260678
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    import pytest

    # test for empty Maybe
    maybe_empty = Maybe.nothing()

    assert maybe_empty.ap(Maybe.just(lambda x: x)) == Maybe.nothing()
    assert maybe_empty.ap(Maybe.just(lambda x: None)) == Maybe.nothing()

    # test for not empty Maybe
    maybe_value = Maybe.just(10)

    assert maybe_value.ap(Maybe.just(lambda x: x + 100)) == Maybe.just(110)
    assert maybe_value.ap(Maybe.just(lambda x: None)) == Maybe.just(None)
    assert maybe_value.ap(Maybe.nothing()) == Maybe.nothing()

    with pytest.raises(ValueError):
        assert Maybe.just(lambda x: None).ap(Maybe.just(10))

# Generated at 2022-06-24 00:21:44.307607
# Unit test for method map of class Maybe
def test_Maybe_map():
    """ Test map function of Maybe class. """
    assert Maybe.just(5).map(lambda x: x * 2) == Maybe.just(10)
    assert Maybe.just(5).map(lambda x: x ** 2) == Maybe.just(25)
    assert Maybe.just(5).map(lambda x: x * 0) == Maybe.just(0)
    assert Maybe.just(10).map(lambda x: x - 5) == Maybe.just(5)
    assert Maybe.just(10).map(lambda x: x / 2) == Maybe.just(5)
    assert Maybe.just(3).map(lambda x: x * 3 * 2 * 1) == Maybe.just(18)
    assert Maybe.just(10).map(lambda x: 2 ** x) == Maybe.just(1024)
    assert Maybe.just(2).map

# Generated at 2022-06-24 00:21:47.293914
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    m = Maybe.just(2)
    new_m = m.bind(lambda x: Maybe.just(x + 1))
    assert new_m.value == 3

    m = Maybe.nothing()
    new_m = m.bind(lambda x: Maybe.just(x + 1))
    assert new_m.value is None

# Generated at 2022-06-24 00:21:50.957452
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe('test', False).to_box() == Box('test')
    assert Maybe(None, True).to_box() == Box(None)



# Generated at 2022-06-24 00:21:53.756024
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(None) == Maybe(None, False)
    assert Maybe.nothing() == Maybe.just(None) == Maybe(None, True)



# Generated at 2022-06-24 00:22:00.071392
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test():
        assert Maybe.just(0).filter(lambda v: not v) == Maybe.just(0)
        assert Maybe.just(1).filter(lambda v: not v) == Maybe.nothing()
        assert Maybe.nothing().filter(lambda v: not v) == Maybe.nothing()
    
    test()


# Generated at 2022-06-24 00:22:06.798456
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(1).get_or_else(0) == 1
    assert Maybe.nothing().get_or_else(0) == 0


# Generated at 2022-06-24 00:22:13.414793
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit testing for the Maybe.to_either method.
    """
    assert Maybe.just(1).to_either() == Either.right(1)
    assert Maybe.nothing().to_either() == Either.left(None)
    assert isinstance(Maybe.just(1).to_either(), Either)
    assert isinstance(Maybe.nothing().to_either(), Either)


# Generated at 2022-06-24 00:22:20.989168
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def plus_one(x: int) -> Maybe[int]:
        if x > 0:
            return Maybe.just(x + 1)
        return Maybe.nothing()

    assert Maybe.bind(plus_one, Maybe.just(0)) == Maybe.nothing()
    assert Maybe.bind(plus_one, Maybe.just(3)) == Maybe.just(4)
    assert Maybe.bind(plus_one, Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:22:25.603806
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1


# Generated at 2022-06-24 00:22:29.576858
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda a: a + 4) == Maybe.just(6)
    assert Maybe.just([]).map(lambda l: l + [2, 3]) == Maybe.just([2, 3])
    assert Maybe.nothing().map(lambda l: l) == Maybe.nothing()



# Generated at 2022-06-24 00:22:36.390185
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    result0 = Maybe.nothing() == Maybe.nothing()
    assert result0

    result1 = Maybe.just(10) == Maybe.just(10)
    assert result1

    result2 = Maybe.nothing() != Maybe.just(10)
    assert result2

    result3 = Maybe.just(10) != Maybe.nothing()
    assert result3

# Generated at 2022-06-24 00:22:43.809413
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either, Left, Right
    from pymonet.maybe import Maybe
    from pymonet.assertion import assert_that

    # Test with empty Maybe
    result = Maybe.nothing().to_either()
    assert_that(result).is_instance_of(Either)
    assert_that(result.is_left()).is_true()

    # Test with not empty Maybe
    result = Maybe.just(10).to_either()
    assert_that(result).is_instance_of(Either)
    assert_that(result.is_right()).is_true()
    assert_that(result.get_or_else(None)).is_equal_to(10)

# Generated at 2022-06-24 00:22:46.479573
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x ** 2) == Maybe.just(4)
    assert Maybe.just(3).map(lambda x: x ** 2) == Maybe.just(9)
    assert Maybe.nothing().map(lambda x: x ** 2) == Maybe.nothing()


# Generated at 2022-06-24 00:22:48.747423
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just('1') == Maybe('1', False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:22:56.065754
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe

    :returns: Nothing
    :rtype: None
    """
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    def get_value(value=None) -> Try:
        if value:
            return Try(value, is_success=True)
        return Try(None, is_success=False)

    assert Maybe.just(5).bind(get_value) == Maybe.just(5)
    assert Maybe.nothing().bind(get_value) == Maybe.nothing()


# Generated at 2022-06-24 00:22:59.119759
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:23:05.239438
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box

    assert Maybe.just(10).to_lazy().value() == 10
    assert Maybe.nothing().to_lazy().value() is None
    assert Maybe.just(Box(10)).to_lazy().value().value() == 10

# Generated at 2022-06-24 00:23:12.121734
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(None)

# Generated at 2022-06-24 00:23:17.878872
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test method map of class Maybe.

    :returns: True if everything is ok, otherwise raises AssertionError
    :rtype: Boolean
    :raises: AssertionError
    """
    assert Maybe.just(7).map(lambda x: x + 1) == Maybe.just(8)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    return True


# Generated at 2022-06-24 00:23:21.334563
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:25.650351
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(1)
    empty_maybe_1 = Maybe.nothing()
    empty_maybe_2 = Maybe.nothing()

    assert maybe_1 == maybe_2
    assert empty_maybe_1 == empty_maybe_2
    assert empty_maybe_1 != maybe_2


# Generated at 2022-06-24 00:23:28.658403
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just("hello").to_lazy() == Lazy(lambda: "hello")
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:23:39.292450
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test method filter of class Maybe.
    """
    from pymonet.list import List, Cons, Nil

    def is_even(num):
        return num % 2 == 0

    list_of_numbers1 = List(Cons(1, Cons(2, Cons(3, Cons(4, Nil())))))
    list_of_numbers2 = List(Cons(2, Cons(4, Cons(6, Cons(8, Nil())))))
    list_of_numbers3 = List(Cons(1, Cons(3, Cons(5, Cons(7, Nil())))))

    list_of_maybes1 = List.fmap(list_of_numbers1, Maybe.just)
    list_of_maybes2 = List.fmap(list_of_numbers2, Maybe.just)
    list_

# Generated at 2022-06-24 00:23:44.429175
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def gt3(n):
        return n > 3

    def lt8(n):
        return n < 8

    a = Maybe.just(4)
    b = Maybe.just(10)

    assert Maybe.just(4) == a.filter(gt3)
    assert Maybe.nothing() == b.filter(gt3)
    assert Maybe.just(4) == a.filter(gt3).filter(lt8)


# Generated at 2022-06-24 00:23:46.390700
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:23:51.715497
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.monad import Monad

    # Arrange
    maybe = Maybe.just(lambda x: x + 1)
    maybe2 = Maybe.just(1)
    try_ = Try(2, is_success=True)
    try_failure = Try(None, is_success=False)

    # Act
    maybe_result = maybe.ap(Monad.to_monad(1))
    maybe2_result = maybe2.ap(Monad.to_monad(2))
    try_result = maybe.ap(try_)
    try_result_failure = maybe.ap(try_failure)

    # Assert
    assert maybe_result == Maybe.just(2)
    assert maybe2_result == Maybe.just(3)

# Generated at 2022-06-24 00:23:57.518001
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Left, Right

    assert Maybe.just(12).bind(lambda x: Right("Right")) == Right("Right")
    assert Maybe.just(12).bind(lambda x: Left("Left")) == Left("Left")
    assert Maybe.nothing().bind(lambda x: Right("Right")) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Left("Left")) == Maybe.nothing()



# Generated at 2022-06-24 00:24:02.307052
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    empty_maybe = Maybe.nothing()
    assert empty_maybe.to_validation() == Validation.success(None)

    not_empty_maybe = Maybe.just("some")
    assert not_empty_maybe.to_validation() == Validation.success("some")



# Generated at 2022-06-24 00:24:09.244060
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    class M(Maybe[int], Functor[int], Applicative[int]):
        def __init__(self, value: int, is_nothing: bool):
            super().__init__(value, is_nothing)

    assert M.just(1).filter(lambda x: x == 1) == M.just(1)
    assert M.just(1).filter(lambda x: x == 2) == M.nothing()
    assert M.nothing().filter(lambda x: x == 1) == M.nothing()



# Generated at 2022-06-24 00:24:14.271939
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Test Maybe.map method.

    :returns: None
    """

    def mapper(value: int) -> str:
        """
        Mapper function for test.

        :param value: int
        :type value: int
        :returns: value converted to str
        :rtype: str
        """
        return str(value)
    assert Maybe.just(5).map(mapper) == Maybe.just('5')
    assert Maybe.nothing().map(mapper) == Maybe.nothing()



# Generated at 2022-06-24 00:24:16.489786
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:24:23.112582
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    """
    Unit test for method to_either of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.string import Str
    from pymonet.either import Left
    from pymonet.either import Right

    maybe_str = Maybe.just(Str('test'))
    assert maybe_str.to_either() == Right(Str('test'))

    maybe_empty_str = Maybe.nothing()
    assert maybe_empty_str.to_either() == Left(None)


# Generated at 2022-06-24 00:24:27.983409
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-24 00:24:32.511560
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe_just = Maybe.just(1)
    assert maybe_just.to_either() == Right(1)
    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.to_either() == Left(None)

# Generated at 2022-06-24 00:24:36.738049
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert not Maybe(1, True) == None
    assert not Maybe(1, True) == Maybe(2, True)
    assert not Maybe(1, True) == Maybe(2, False)
    assert not Maybe(1, True) == Maybe(1, False)


# Generated at 2022-06-24 00:24:41.189136
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(3).to_try() == Try(3, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:24:47.399359
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:24:51.789650
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-24 00:24:54.454778
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:24:57.343256
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """Tests to_try method of Maybe class."""

    assert Maybe[int](1, False).to_try() == Try(1, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:25:01.799156
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try

    assert Maybe.just(2).to_try() == Try(2, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:25:06.260233
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:25:11.688232
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe: Maybe[int] = Maybe.just(1)
    maybe1: Maybe[int] = Maybe.nothing()

    assert maybe == Maybe.just(1)
    assert maybe != Maybe.just(2)
    assert maybe != Maybe.nothing()
    assert maybe != 1
    assert maybe1 == Maybe.nothing()


# Generated at 2022-06-24 00:25:20.269656
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    # taking the function which is inside the Maybe,
    # and applying it to the applicative. [Maybe[Fn(B)]] ap [Maybe[B]]
    assert Maybe.just(lambda x: x + 5).ap(Maybe.just(5)) == Maybe.just(10)

    # empty Maybe ap to anything is empty Maybe
    assert Maybe.nothing().ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe.just(lambda x: x + 5).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:25:23.853339
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-24 00:25:29.211056
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Function to test Maybe's to_validation function

    :returns: None
    :rtype: None
    """
    # assert True # remove this line!
    from pymonet.validation import Validation
    assert Maybe.just(5).to_validation() == Validation.success(5)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:25:31.779117
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # given
    maybe = Maybe.just(1)
    expected_result = Validation.success(1)

    # when
    result = maybe.to_validation()

    # then
    assert expected_result == result

# Generated at 2022-06-24 00:25:33.940677
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(10, False).to_box() == Box(10)
    assert Maybe(None, True).to_box() == Box(None)


# Generated at 2022-06-24 00:25:35.224808
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy().evaluate() == 1


# Generated at 2022-06-24 00:25:39.227083
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test empty Maybe
    maybe = Maybe.nothing()
    assert maybe.is_nothing
    assert not hasattr(maybe, 'value')

    # Test not empty Maybe
    value = 5
    maybe = Maybe.just(value)
    assert not maybe.is_nothing
    assert hasattr(maybe, 'value')
    assert maybe.value == value


# Generated at 2022-06-24 00:25:46.297615
# Unit test for constructor of class Maybe
def test_Maybe():
    # Given
    f = lambda x: x**2
    # When
    just_predicate = Maybe.just(f)
    nothing_predicate = Maybe.nothing()
    just_value = just_predicate.value
    nothing_value = nothing_predicate.value
    just_is_nothing = just_predicate.is_nothing
    nothing_is_nothing = nothing_predicate.is_nothing
    # Then
    assert just_value(2) == f(2)
    assert nothing_value is None
    assert just_is_nothing is False
    assert nothing_is_nothing is True



# Generated at 2022-06-24 00:25:48.944532
# Unit test for constructor of class Maybe
def test_Maybe():
    # Test Maybe.just function
    assert Maybe.just(1) == Maybe(1, False)

    # Test Maybe.nothing function
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:25:52.907021
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functions import add

    f = Maybe.just(add)
    v = Maybe.just(1)

    assert f.ap(v) == Maybe.just(2)
    assert f.ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:25:56.375839
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(1).to_try() == Try(1, True)
    assert Maybe.nothing().to_try() == Try(None, False)


# Generated at 2022-06-24 00:26:03.884714
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.identity import Identity

    def add(a):
        return lambda b: a + b

    assert Maybe.just(add).ap(Maybe.just(Box('abc'))) == Maybe.just(add('abc'))
    assert Maybe.just(add).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(Box('abc'))) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(add).ap(Maybe.just(Identity('abc'))) == Maybe.just(add('abc'))
    assert Maybe.just(add).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing

# Generated at 2022-06-24 00:26:07.514483
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just("foo") == Maybe("foo", False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:26:14.895703
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for method bind of class Maybe.
    """
    try:
        from pymonet.validation import Validation
        print("Unit test for method bind of class Maybe:", end="")
        assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
        assert Maybe.nothing().bind(lambda x: Maybe.just(x + 1)) == Maybe.nothing()
        assert Maybe.just(1).bind(lambda x: Maybe.just(x)) == Maybe.just(1)
        print(" OK")
    except AssertionError:
        print(" FAILED")


# Generated at 2022-06-24 00:26:15.988875
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:17.828423
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(3).get_or_else(2) == 3
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:26:20.126375
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either

    assert Maybe.just(5).to_either() == Either.right(5)
    assert Maybe.nothing().to_either() == Either.left(None)



# Generated at 2022-06-24 00:26:29.841593
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_try import Try
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe

    m = Maybe.just(lambda x: x % 2 == 0)
    assert m.ap(Maybe.just(2)) == Maybe.just(True)
    assert m.ap(Maybe.just(3)) == Maybe.just(False)
    assert m.ap(Maybe.nothing()) == Maybe.nothing()

    m = Maybe.just(Try.success)
    assert m.ap(Maybe.just(1)) == Maybe.just(Try.success(1))
    assert m.ap(Maybe.nothing()) == Maybe.nothing()

    m = Maybe.just(List.unit)
    assert m.ap(Maybe.just(1)) == Maybe.just(List.unit(1))

# Generated at 2022-06-24 00:26:34.192796
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just('some value').to_either() == \
               Right('some value')
    assert Maybe.nothing().to_either() == \
               Left(None)


# Generated at 2022-06-24 00:26:37.301029
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    a = Maybe.just(1)
    b = Maybe.nothing()

    assert a.to_validation() == Validation.success(1)
    assert b.to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:26:39.585585
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x < 10) == Maybe.just(5)


# Generated at 2022-06-24 00:26:41.723840
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10).value == 10
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) != Maybe.nothing()


# Generated at 2022-06-24 00:26:44.920805
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe('Text', False).map(lambda x: x + 'And more text') == Maybe.just('TextAnd more text')
    assert Maybe.just([1, 2, 3]).map(lambda x: sum(x)) == Maybe.just(6)


# Generated at 2022-06-24 00:26:50.387854
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Right(None)
    assert Maybe.just(1).to_either().to_either() == Right(1)
    assert Maybe.nothing().to_either().to_either() == Right(None)


# Generated at 2022-06-24 00:26:54.673780
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(4).get_or_else(None) == 4
    assert Maybe.nothing().get_or_else(None) == None


# Generated at 2022-06-24 00:26:57.310976
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(5).map(lambda x: x + 2) == Maybe.just(7)



# Generated at 2022-06-24 00:26:59.074140
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(5).to_box() == Box(5)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:27:01.281794
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    """
    Test for Maybe.get_or_else method.
    """
    maybe = Maybe.just(1)
    assert maybe.get_or_else(None) == 1

    maybe = Maybe.nothing()
    assert maybe.get_or_else(None) == None



# Generated at 2022-06-24 00:27:03.860379
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    actual = Maybe.just("test")
    expected = Right("test")
    assert actual.to_either() == expected

    actual = Maybe.nothing()
    expected = Left(None)
    assert actual.to_either() == expected


# Generated at 2022-06-24 00:27:05.586323
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:27:07.992815
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()



# Generated at 2022-06-24 00:27:12.267763
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert(Maybe.just(5).to_lazy().value() == 5)
    assert(Maybe.just(5).to_lazy().value() == 5)
    assert(Maybe.nothing().to_lazy().value() == None)


# Generated at 2022-06-24 00:27:15.139341
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert (Maybe.just(4).to_either() ==
            Right(4))

    assert (Maybe.nothing().to_either() ==
            Left(None))


# Generated at 2022-06-24 00:27:23.408038
# Unit test for method map of class Maybe
def test_Maybe_map():
    one_plus_two_plus_three = Maybe.just(1).bind(lambda x: Maybe.just(x + 2)).bind(lambda x: Maybe.just(x + 3))
    assert one_plus_two_plus_three == Maybe.just(6)

    one_plus_two = Maybe.just(1).map(lambda x: x + 2)
    assert one_plus_two == Maybe.just(3)

    nothing_plus_two = Maybe.nothing().map(lambda x: x + 2)
    assert nothing_plus_two == Maybe.nothing()

    one_plus_nothing = Maybe.just(1).bind(lambda x: Maybe.nothing())
    assert one_plus_nothing == Maybe.nothing()


# Generated at 2022-06-24 00:27:28.416193
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('Pymonet') == Maybe.just('Pymonet')
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:27:31.324884
# Unit test for method map of class Maybe
def test_Maybe_map():
    mapper = lambda x: x.upper()
    maybe = Maybe.just("foo")
    assert maybe.map(mapper) == Maybe(mapper("foo"), False)



# Generated at 2022-06-24 00:27:34.281083
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:27:39.832063
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

test_Maybe___eq__()



# Generated at 2022-06-24 00:27:41.739241
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(
        10
    ).to_box() == Box(10)

    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:27:44.253724
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Right, Left

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-24 00:27:50.728891
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # Test for empty Maybe
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

    # Test for not empty Maybe
    assert Maybe.just(5).to_try() == Try(5, is_success=True)

# Generated at 2022-06-24 00:27:55.325279
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(9).bind(lambda v: Maybe(v + 1, False)) == Maybe.just(10)
    assert Maybe.nothing().bind(lambda v: Maybe(v + 1, False)) == Maybe.nothing()



# Generated at 2022-06-24 00:28:00.463157
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_filter = Maybe.just(10).filter(lambda x: x < 11)
    assert maybe_filter == Maybe.just(10)

    maybe_filter1 = Maybe.just(10).filter(lambda x: x < 9)
    assert maybe_filter1 == Maybe.nothing()

    maybe_filter2 = Maybe.nothing().filter(lambda x: x < 11)
    assert maybe_filter2 == Maybe.nothing()



# Generated at 2022-06-24 00:28:03.015192
# Unit test for constructor of class Maybe
def test_Maybe():
    val1 = Maybe(1, False)
    val2 = Maybe(None, True)
    assert val1 == val2



# Generated at 2022-06-24 00:28:10.349333
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(3).bind(lambda x: Maybe.just(x + 2)) == Maybe.just(5)
    assert Maybe.just(3).bind(lambda x: Maybe(x + 2, False)) == Maybe.just(5)
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe(x + 2, True)) == Maybe.nothing()


# Generated at 2022-06-24 00:28:19.050799
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filter of Maybe.
    """
    def filter_function_1(value):
        return value < 0
    def filter_function_2(value):
        return value == -1

    assert Maybe.just(1).filter(filter_function_1) == Maybe.nothing(), 'Test filter of Maybe with filter_function_1'
    assert Maybe.just(-1).filter(filter_function_1) == Maybe.just(-1), 'Test filter of Maybe with filter_function_1'
    assert Maybe.nothing().filter(filter_function_1) == Maybe.nothing(), 'Test filter of Maybe with filter_function_1'

    assert Maybe.just(1).filter(filter_function_2) == Maybe.nothing(), 'Test filter of Maybe with filter_function_2'

# Generated at 2022-06-24 00:28:24.398194
# Unit test for method map of class Maybe
def test_Maybe_map():
    # Test empty Maybe
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    # Test not empty Maybe
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)



# Generated at 2022-06-24 00:28:26.300466
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe(5, False).to_validation() == Validation.success(5)
    assert Maybe(None, True).to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:28:31.032544
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    # Given
    from pymonet.either import Left, Right

    # When
    result = Maybe.just(1).to_either()
    result2 = Maybe.nothing().to_either()

    # Then
    assert result == Right(1)
    assert result2 == Left(None)


# Generated at 2022-06-24 00:28:34.972392
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    print ('test_Maybe_to_box')
    assert Maybe.just(2).to_box() == Box(2)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:28:40.239279
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(5).bind(lambda x: Maybe.just(x+2)) == Maybe.just(7)
    assert Maybe.just(5).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.just(x+2)) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda x: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:28:44.692707
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    from pymonet.monad_try import Try

    # Given
    maybe = Maybe.just(2)

    # When
    value = maybe.get_or_else(1)

    # Then
    assert value == 2

    # When
    value = maybe.get_or_else(1)
    print(value)

    # Then
    assert value == 2

