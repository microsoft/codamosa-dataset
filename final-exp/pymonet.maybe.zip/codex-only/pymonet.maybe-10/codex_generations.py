

# Generated at 2022-06-24 00:18:44.618344
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().value() == 1
    assert Maybe.nothing().to_lazy().value() is None


# Generated at 2022-06-24 00:18:45.719175
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe('a', False).to_box() == Box('a')
    assert Maybe('a', True).to_box() == Box(None)



# Generated at 2022-06-24 00:18:47.540217
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-24 00:18:53.038364
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try, TryError

    assert Maybe(1, False).to_try() == Try(1, True)
    assert Maybe(1, True).to_try() == Try(TryError(), False)


# Generated at 2022-06-24 00:18:55.410929
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(8).get_or_else(2) == 8
    assert Maybe.nothing().get_or_else(2) == 2



# Generated at 2022-06-24 00:18:56.806442
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)


# Generated at 2022-06-24 00:19:01.763172
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(12) == Maybe.just(12)
    assert Maybe.just(12) != Maybe.just(11)
    assert Maybe.just(12) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe(None, False)
    assert Maybe.just(12) != Maybe(12, True)


# Generated at 2022-06-24 00:19:04.609338
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(42, False).get_or_else(42) == 42
    assert Maybe(None, True).get_or_else(42) == 42
    assert Maybe(42, False).get_or_else(None) == 42
    assert Maybe(None, True).get_or_else(None) is None


# Generated at 2022-06-24 00:19:07.354766
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2)\
        .map(lambda value: value ** 2)\
        .map(lambda value: value + 1)\
        == Maybe.just(5)
    assert Maybe.nothing()\
        .map(lambda value: value ** 2)\
        == Maybe.nothing()


# Generated at 2022-06-24 00:19:12.878270
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    >>> from pymonet.box import Box
    >>> from pymonet.maybe import Maybe
    >>> Maybe.nothing().to_box() == Box(None)
    True
    >>> Maybe.just(0).to_box() == Box(0)
    True
    """



# Generated at 2022-06-24 00:19:15.238474
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:19:18.332768
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe(None, True).to_either() == Left(None)



# Generated at 2022-06-24 00:19:21.755729
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(3).map(lambda x: x + 1) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:19:27.424760
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    import pytest
    from pymonet.monad_maybe import Maybe
    from pymonet.applicative import Applicative
    m1 = Maybe(9, True)
    m2 = Maybe.just(lambda x: x + 10)
    m3 = m1.ap(m2)
    assert isinstance(m3, Applicative)
    assert isinstance(m3, Maybe)
    assert m3 == Maybe(None, True)
    m1 = Maybe.just(12)
    m2 = Maybe.just(lambda x: x + 10)
    m3 = m1.ap(m2)
    assert isinstance(m3, Applicative)
    assert isinstance(m3, Maybe)
    assert m3 == Maybe(22, False)


# Generated at 2022-06-24 00:19:30.886729
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test for method to_box of class Maybe

    :return: None
    """

    assert Maybe.nothing().to_box().is_empty()
    assert Maybe.just(1).to_box().get_or_else(0) == 1


# Generated at 2022-06-24 00:19:35.845727
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    assert Maybe.just(42).to_validation() == Validation.success(42)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:19:37.937878
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(1).to_lazy() == Lazy(lambda: 1))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))



# Generated at 2022-06-24 00:19:44.289702
# Unit test for method map of class Maybe
def test_Maybe_map():
    """ Test for map method of Maybe class"""
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x ** 2) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: 5) == Maybe.just(5)
    assert Maybe.just(2).map(lambda x: x / 0) == Maybe.just(float('inf'))
    assert Maybe.just(None).map(lambda x: x + 2) == Maybe.nothing()
    assert Maybe.just(2).map(lambda x: None) == Maybe.nothing()

    assert Maybe.just('2').map(lambda x: int(x)) == Maybe.just(2)
    assert Maybe.just('2').map(lambda x: x + '2')

# Generated at 2022-06-24 00:19:48.773051
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe(1, False).to_either() == Right(1)
    assert Maybe('a', False).to_either() == Right('a')
    assert Maybe(1.0, False).to_either() == Right(1.0)
    assert Maybe(None, True).to_either() == Left(None)



# Generated at 2022-06-24 00:19:54.334757
# Unit test for method map of class Maybe
def test_Maybe_map():

    def add_one(x: int) -> int:
        return x + 1

    def add_one_raise_error(x: int) -> int:
        raise Exception

    some_one = Maybe.just(1)
    some_string = Maybe.just("some string")
    nothing = Maybe.nothing()

    assert some_one.map(add_one) == Maybe.just(2)
    assert some_string.map(add_one_raise_error) == Maybe.just("some string")
    assert nothing.map(add_one) == Maybe.nothing()



# Generated at 2022-06-24 00:19:58.778324
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != 1



# Generated at 2022-06-24 00:20:03.350851
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(10).map(lambda x: x + 1) == Maybe.just(11)
    assert Maybe.just(10).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 10) == Maybe.nothing()


# Generated at 2022-06-24 00:20:09.650396
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def foo():
        return 'foo'
    assert Maybe(foo(), False).to_lazy() == Lazy(foo)
    assert Maybe('bar', False).to_lazy() == Lazy(lambda: 'bar')
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:20:19.343480
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def square(x):
        return x * x

    square_maybe = Maybe.just(square)
    
    assert Maybe.just(2).bind(square) == Maybe.just(4)
    assert Maybe.nothing().bind(square) == Maybe.nothing()

    assert Maybe.just(2).ap(square_maybe) == Maybe.just(4)
    assert Maybe.nothing().ap(square_maybe) == Maybe.nothing()

    assert Maybe.just(2).filter(lambda x: Even(x)) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda x: Even(x)) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: Even(x)) == Maybe.nothing()


# Generated at 2022-06-24 00:20:28.533680
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_1(x):
        return x + 1

    def multiply_by_10(x):
        return x * 10

    maybe_value = Maybe(2, False)
    applicative = Maybe(add_1, False)
    result1 = maybe_value.ap(applicative)
    assert result1.value == 3
    assert not result1.is_nothing
    applicative = Maybe(multiply_by_10, False)
    result2 = maybe_value.ap(applicative)
    assert result2.value == 20
    assert not result2.is_nothing
    maybe_value = Maybe(None, True)
    result3 = maybe_value.ap(applicative)
    assert result3.value is None
    assert result3.is_nothing



# Generated at 2022-06-24 00:20:38.365507
# Unit test for method filter of class Maybe
def test_Maybe_filter():  # noqa: D103
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    # Create not empty Maybe
    maybe = Maybe.just(2)

    # Check that Maybe filter return correct Maybe monad
    assert maybe.filter(lambda t: t == 2) == Maybe.just(2)
    assert maybe.filter(lambda t: t != 2) == Maybe.nothing()

    # Check that Maybe filter return not empty Maybe if Maybe is not empty
    assert maybe.filter(lambda t: t == 2).is_nothing is False

    # Check that Maybe filter return empty Maybe if Maybe is empty
    assert Maybe.nothing().filter(lambda t: t == 2).is_

# Generated at 2022-06-24 00:20:41.919065
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe(1, False).map(lambda x: x + 1) == Maybe(2, False)
    assert Maybe(1, False).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: None) == Maybe.nothing()



# Generated at 2022-06-24 00:20:46.000022
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)


# Generated at 2022-06-24 00:20:48.965584
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    t1 = Maybe.just(2)
    t2 = t1.get_or_else(4)
    assert t2 == 2

    t3 = Maybe.nothing()
    t4 = t3.get_or_else(4)
    assert t4 == 4


# Generated at 2022-06-24 00:20:51.794277
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)

# Generated at 2022-06-24 00:20:54.162498
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(1).to_try() == Try(1, is_success=True)

# Generated at 2022-06-24 00:20:58.346551
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just(5).to_try() == Try(5, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:21:02.797710
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe(23, False) == Maybe(23, False)
    assert Maybe(23, False) != Maybe(42, False)



# Generated at 2022-06-24 00:21:06.825266
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just("value").to_lazy() == Lazy(lambda: "value")
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:21:09.935216
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(2).map(lambda x: x * 3) == Maybe(6, False)
    assert Maybe.nothing().map(lambda x: x * 3) == Maybe(None, True)


# Generated at 2022-06-24 00:21:15.743573
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    """
    Test for method to_validation of class Maybe

    :returns: None
    :rtype: None
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(10).to_validation() == Validation.success(10)
    assert Maybe.nothing().to_validation() == Validation.success(None)

# Generated at 2022-06-24 00:21:21.253660
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x != 2) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-24 00:21:25.424008
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just("Hello").to_box() == Box("Hello")
    assert Maybe.just((1, 2)).to_box() == Box((1, 2))
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:21:32.154288
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, True) == Maybe(10, True)
    assert Maybe(10, False) == Maybe(10, False)
    assert Maybe(10, True) == Maybe(15, True)
    assert Maybe(10, False) == Maybe(15, False)
    assert Maybe(10, True) != Maybe(10, False)
    assert Maybe(10, True) != Maybe(15, False)
    assert Maybe(10, False) != Maybe(15, True)
    assert Maybe(10, True) != Maybe(10.0, True)
    assert Maybe(10, False) != Maybe(10.0, False)



# Generated at 2022-06-24 00:21:39.533065
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    @dataclass
    class P:
        x: int
        y: int

    @dataclass
    class Q:
        p: P

    def getP(q: Q) -> Maybe[P]:
        if q.p.x > 10:
            return Maybe.nothing()
        return Maybe.just(q.p)

    def getX(p: P) -> Maybe[int]:
        if p.x == 0:
            return Maybe.nothing()
        return Maybe.just(p.x)

    test_result = Maybe.bind(getQ(Q(P(0, 0))), lambda v: getX(v))
    expected_result = Maybe.nothing()
    assert test_result == expected_result


# Generated at 2022-06-24 00:21:42.198145
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.just(8).to_either() == Right(8)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:21:44.479980
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:21:47.440796
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    """
    Test Maybe to_box method.
    """
    # empty Maybe
    assert Maybe.nothing().to_box() == Box(None)
    # not empty Maybe
    assert Maybe.just(77).to_box() == Box(77)


# Generated at 2022-06-24 00:21:49.588127
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1

# Generated at 2022-06-24 00:21:51.913104
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe(1, False).to_box() == Box(1)
    assert Maybe(1, True).to_box() == Box(None)


# Generated at 2022-06-24 00:21:58.360281
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:22:02.972610
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert(
        Maybe.just(Box.success(5)).to_either() == Either.right(Box.success(5))
    )
    assert(
        Maybe.nothing().to_either() == Either.left(None)
    )



# Generated at 2022-06-24 00:22:05.715429
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:22:11.790556
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just('test').to_validation() == Validation.success('test')
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:22:19.338055
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    """
    tests for method ap of class Maybe

    :return: None
    :rtype: NoneType
    """
    assert Maybe.just(lambda x: x + 1).ap(Maybe.just(2)) == Maybe.just(3)
    assert Maybe.just(lambda x: x + 1).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing()


# Generated at 2022-06-24 00:22:21.557040
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    maybe = Maybe.just(Box(None))

    assert maybe.to_box() == Box(maybe)
    assert not Maybe.nothing().to_box()



# Generated at 2022-06-24 00:22:27.415464
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.either import Right, Left

    assert Maybe(10, False).bind(lambda x: Right(x + 1)) == Right(11)
    assert Maybe(10, True).bind(lambda x: Right(x + 1)) == Left(None)

# Generated at 2022-06-24 00:22:33.033067
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(3)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:22:34.406935
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just('test').to_either() == Right('test')
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:22:36.459685
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try
    assert Maybe.just(True).to_try() == Try(True, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:22:41.070622
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)

    assert maybe.to_lazy() == Lazy(lambda: 1)
    assert maybe.to_lazy().value() == 1

    maybe = Maybe.nothing()

    assert maybe.to_lazy() == Lazy(lambda: None)
    assert maybe.to_lazy().value() is None

# Generated at 2022-06-24 00:22:44.252854
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() is None



# Generated at 2022-06-24 00:22:46.906878
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(10).to_box() == Box(10)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:22:49.910840
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.just(None).to_box() == Box(None)
    assert Maybe.nothing().to_box() == Box(None)



# Generated at 2022-06-24 00:22:54.813483
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert(Maybe.just(lambda x: x * 2).ap(Maybe.just(2)) == Maybe.just(4))
    assert(Maybe.nothing().ap(Maybe.just(2)) == Maybe.nothing())
    assert(Maybe.just(None).ap(Maybe.just(2)) == Maybe.nothing())



# Generated at 2022-06-24 00:22:58.564144
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():

    from pymonet.either import Right, Left

    assert Maybe.just("str").to_either() == Right("str"), "function test_Maybe_to_either failed"

    assert Maybe.nothing().to_either() == Left(None), "function test_Maybe_to_either failed"



# Generated at 2022-06-24 00:23:00.998090
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert isinstance(Maybe.just('test').to_validation(), Validation)
    assert isinstance(Maybe.nothing().to_validation(), Validation)



# Generated at 2022-06-24 00:23:05.636358
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-24 00:23:09.331541
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Given
    maybe = Maybe.just('foo')
    expected = 'foo'

    # When
    actual = maybe.to_lazy().value()

    # Then
    assert expected == actual

    # Given
    maybe = Maybe.nothing()
    expected = None

    # When
    actual = maybe.to_lazy().value()

    # Then
    assert expected == actual



# Generated at 2022-06-24 00:23:12.874670
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    assert Maybe.just("test").to_try() == Try("test", is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:23:18.362048
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    maybe = Maybe.just(1)
    assert maybe.to_either().is_right() is True
    assert maybe.to_either().is_left() is False
    assert maybe.to_either().get_or_else() == 1
    assert maybe.to_either().get_or_else(1) == 1
    assert maybe.to_either().get_or_else_with(lambda: 1) == 1
    assert maybe.to_either().map(lambda x: x).get_or_else() == 1

# Generated at 2022-06-24 00:23:21.755881
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    assert Maybe.just(2).to_either() == Right(2)
    assert Maybe.just(None).to_either() == Right(None)
    assert Maybe.nothing().to_either() == Left(None)


# Generated at 2022-06-24 00:23:24.327210
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert (Right(1).to_maybe()) == Maybe.just(1)
    assert (Left(1).to_maybe()) == Maybe.nothing()


# Generated at 2022-06-24 00:23:26.190258
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(15).get_or_else(5) == 15
    assert Maybe.nothing().get_or_else(5) == 5

# Generated at 2022-06-24 00:23:31.200510
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    # given
    def add_one(x):
        return Maybe.just(x + 1)

    def not_add_one(x):
        return Maybe.nothing()

    # contract
    assert Maybe.just("10").to_validation().match(
        lambda v: v == "10",
        lambda v: "None"
    ) == "10"
    assert Maybe.nothing().to_validation().match(
        lambda v: v == "10",
        lambda v: "None"
    ) == "None"
    assert Maybe.just("10").map(add_one).to_validation().match(
        lambda v: v == "11",
        lambda v: "None"
    ) == "11"

# Generated at 2022-06-24 00:23:36.587763
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert (Maybe.just(1).map(lambda x: x+1)) == \
           Maybe.just(2), 'Maybe.map(lambda x: x+1) should be equal to Maybe.just(2)'
    assert (Maybe.nothing().map(lambda x: x+1)) == \
           Maybe.nothing(), 'Maybe.map(lambda x: x+1) should be equal to Maybe.nothing()'


# Generated at 2022-06-24 00:23:45.840371
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet import Validation
    from pymonet.validation import success, failure

    assert Maybe.just(12).to_validation() == Validation.success(12)
    assert Maybe.just(12).map(lambda x: x * 2).to_validation() == success(24)
    assert Maybe.just(12).bind(lambda x: Maybe.just(x * 2)).to_validation() == success(24)
    assert Maybe.just(12).ap(Maybe.just(lambda x: x * 2)).to_validation() == success(24)
    assert Maybe.just(12).filter(lambda x: x < 15).to_validation() == success(12)
    assert Maybe.just(12).filter(lambda x: x < 8).to_validation() == failure([])
    assert Maybe.nothing().to_

# Generated at 2022-06-24 00:23:49.927067
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.monad_maybe import Maybe
    def add(a: int) -> int: return a + 10

    def square_root(a: int) -> int: return math.sqrt(a)

    assert Maybe.just(add).ap(Maybe.just(4)) == Maybe.just(add(4))
    assert Maybe.just(add).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(square_root).ap(Maybe.just(4)) == Maybe.just(math.sqrt(4))
    assert Maybe.just(square_root).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:23:51.446162
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.nothing().get_or_else('value') == 'value'
    assert Maybe.just('value').get_or_else('another_value') == 'value'


# Generated at 2022-06-24 00:23:58.124178
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(5).map(lambda x: x + 3) == Maybe.just(8)
    assert Maybe.just(5).map(lambda x: x * 3) == Maybe.just(15)
    assert Maybe.just(5).map(lambda x: x - 3) == Maybe.just(2)
    assert Maybe.just(5).map(lambda x: x / 2) == Maybe.just(5 / 2)
    assert Maybe.nothing().map(lambda x: x + 3) == Maybe.nothing()


# Generated at 2022-06-24 00:24:02.702723
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    m1 = Maybe.just(lambda x: x + 2)
    applicative = Maybe.just(3)
    assert m1.ap(applicative) == Maybe.just(5)

    m2 = Maybe.nothing()
    assert m2.ap(applicative) == Maybe.nothing()



# Generated at 2022-06-24 00:24:06.848910
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    actual = Maybe(123).to_try()
    expected = Try(123, is_success=True)
    assert actual == expected
    actual = Maybe.nothing().to_try()
    expected = Try(None, is_success=False)
    assert actual == expected


# Generated at 2022-06-24 00:24:10.440795
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe([100]).to_try() == Try([100], is_success=True)
    assert Maybe([100].pop()).to_try() == Try(None, is_success=False)
    assert Maybe(100).to_try() == Try(100, is_success=True)
    assert Maybe(None).to_try() == Try(None, is_success=True)

# Generated at 2022-06-24 00:24:12.465344
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy().lazy_value()() == 1
    assert Maybe(1, True).to_lazy().lazy_value()() is None



# Generated at 2022-06-24 00:24:18.618788
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    """
    Unit test for method to_try of class Maybe.

    """
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_try() == Try(None, is_success=False)
    assert Maybe.just(True).to_try() == Try(True, is_success=True)

# Generated at 2022-06-24 00:24:22.561567
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    assert Maybe.just(1).to_validation() == Validation(success=True, value=1)
    assert Maybe.nothing().to_validation() == Validation(success=True, value=None)

test_Maybe_to_validation()


# Generated at 2022-06-24 00:24:27.166181
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just("ok") == Maybe("ok", False)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just("ok").get_or_else("not ok") == "ok"
    assert Maybe.nothing().get_or_else("not ok") == "not ok"


# Generated at 2022-06-24 00:24:36.099494
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(42).map(lambda x: x + 1) == Maybe.just(43)
    assert Maybe.just(42).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()
    assert Maybe.just("42").map(int) == Maybe.just(42)
    assert Maybe.just("42").map(int).map(str) == Maybe.just("42")
    assert Maybe.just("42").map(lambda x: int(x)).map(lambda x: x + 1) == Maybe.just(43)
    assert Maybe.just("42").map(lambda x: int(x)).map(lambda x: None) == Maybe.nothing()


# Generated at 2022-06-24 00:24:37.530684
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    m = Maybe.just(3)
    assert id(m.to_lazy().resolve()) == id(m.value)

# Generated at 2022-06-24 00:24:45.915898
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    my_validation_success = Maybe.just(5).to_validation()
    my_validation_failure = Maybe.nothing().to_validation()

    assert isinstance(my_validation_success, Validation)
    assert my_validation_success.is_success()
    assert my_validation_success.value == 5

    assert isinstance(my_validation_failure, Validation)
    assert my_validation_failure.is_success()
    assert my_validation_failure.value == None


# Generated at 2022-06-24 00:24:51.487342
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    from pymonet.monad_try import Try

    assert Maybe.just(1).bind(lambda x: Maybe.just(x + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda _x: Maybe.just(2)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda _x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().bind(lambda _x: Maybe.nothing()) == Maybe.nothing()

    assert Maybe.just(1).bind(lambda x: Try(x + 2)) == Try(3, is_success=True)

# Generated at 2022-06-24 00:24:54.537850
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(42).to_either() == Right(42)


# Generated at 2022-06-24 00:25:04.660264
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    from pymonet.monad_try import Try

    # boolean = True
    assert Maybe(True, is_nothing=False).to_try() == Try(True, is_success=True)

    # boolean = False
    assert Maybe(False, is_nothing=False).to_try() == Try(False, is_success=True)

    # number = 5
    assert Maybe(5, is_nothing=False).to_try() == Try(5, is_success=True)

    # number = 0
    assert Maybe(0, is_nothing=False).to_try() == Try(0, is_success=True)

    # string = 'pymonet'
    assert Maybe('pymonet', is_nothing=False).to_try() == Try(
        'pymonet', is_success=True)

    # string = ''

# Generated at 2022-06-24 00:25:09.541841
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda v: v > 1) == Maybe.just(2)
    assert Maybe.just(0).filter(lambda v: v > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v > 1) == Maybe.nothing()



# Generated at 2022-06-24 00:25:13.143796
# Unit test for method map of class Maybe
def test_Maybe_map():
    """
    Unit test for method map of class Maybe.
    """
    assert Maybe.just(2).map(lambda x: x + 2) == Maybe.just(4)
    assert Maybe.nothing().map(lambda x: x + 2) == Maybe.nothing()


# Generated at 2022-06-24 00:25:16.590487
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(2).get_or_else(1) == 2
    assert Maybe.nothing().get_or_else(1) == 1



# Generated at 2022-06-24 00:25:19.669795
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy().value() == 5

# Generated at 2022-06-24 00:25:24.478234
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    # Arrange
    maybe = Maybe(1, False)

    def mapper(x):
        return Maybe(2, False)

    # Act
    maybe_result = maybe.bind(mapper)

    # Assert
    assert maybe_result == Maybe(2, False)

# Generated at 2022-06-24 00:25:27.777268
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Left, Right

    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(1).to_either() == Right(1)


# Generated at 2022-06-24 00:25:33.290783
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(2, False) != Maybe(1, False)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != 1
    assert Maybe(1, False) != ["1"]
    assert Maybe(1, False) != {"1": 1}



# Generated at 2022-06-24 00:25:37.655826
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe(1, False) != Maybe.just(2)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(2, True) == Maybe.nothing()
    assert Maybe(None, False) == Maybe.just(None)



# Generated at 2022-06-24 00:25:41.471803
# Unit test for method map of class Maybe
def test_Maybe_map():
    def mapper(val: str) -> str:
        return ''.join(reversed(val))
    # Test not empty Maybe
    assert Maybe.just('abc').map(mapper) == Maybe.just('cba')
    # Test empty Maybe
    assert Maybe.nothing().map(mapper) == Maybe.nothing()


# Generated at 2022-06-24 00:25:44.944563
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    assert Maybe.just(1).bind(lambda value: Maybe.just(value + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda value: Maybe.just(value)) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda value: Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:25:47.998629
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.just('hello').get_or_else(10) == 'hello'
    assert Maybe.nothing().get_or_else(10) == 10



# Generated at 2022-06-24 00:25:51.194358
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    func = lambda b: Maybe(b, False)
    assert Maybe.just(1).bind(func) == Maybe.just(1)
    assert Maybe.nothing().bind(func) == Maybe.nothing()



# Generated at 2022-06-24 00:25:53.626142
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(42).to_box() == Box(42)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:25:57.310909
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = 1
    maybe = Maybe.just(value)
    assert maybe.to_lazy().get() == value
    assert maybe.to_lazy() == maybe.to_lazy()
    assert maybe.to_lazy().get_or(None) == value



# Generated at 2022-06-24 00:26:01.785933
# Unit test for constructor of class Maybe
def test_Maybe():
    def _box(value: int) -> Maybe[int]:
        return Maybe.just(value)

    assert _box(5) == Maybe.just(5)
    assert _box(0) == Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()
    assert _box(0) != Maybe.nothing()
    assert Maybe.just(0) != Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(0)
    assert Maybe.just(5) != _box(5)
    assert _box(5).value == 5
    assert Maybe.nothing().is_nothing is True
    assert _box(0).is_nothing is False



# Generated at 2022-06-24 00:26:06.435598
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():

    from pymonet.box import Box

    test_cases = (
        (2, Maybe.just(2)),
        (None, Maybe.nothing())
    )

    for expected, maybe in test_cases:
        assert maybe.to_box().value == expected


# Generated at 2022-06-24 00:26:09.901066
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    from pymonet.box import Box

    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:12.847593
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    from pymonet.box import Box

    assert Maybe.just(lambda x: x * 2).ap(Box(3)) == Maybe.just(6)
    assert Maybe.nothing().ap(Box(3)) == Maybe.nothing()



# Generated at 2022-06-24 00:26:20.509103
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    assert Maybe.just(lambda x: x * 2).ap(Maybe.just(3)) == Maybe.just(6)
    assert Maybe.just(lambda x: x * 2).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe(None, True).ap(Maybe.just(3)) == Maybe.nothing()
    assert Maybe(None, True).ap(Maybe.nothing()) == Maybe.nothing()



# Generated at 2022-06-24 00:26:22.384676
# Unit test for method to_box of class Maybe
def test_Maybe_to_box():
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Box(None)


# Generated at 2022-06-24 00:26:25.174274
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():

    assert Maybe(1, False).to_validation() == Validation(1, [])
    assert Maybe(None, True).to_validation() == Validation(None, [])


# Generated at 2022-06-24 00:26:35.585880
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_list import MonadList
    from pymonet.monad_dict import MonadDict
    from pymonet.lazy import Lazy

    def f():
        return 42

    assert MonadList.of([1, 2, 3]).to_lazy() \
        == Lazy(lambda: MonadList.of([1, 2, 3]))

    assert MonadDict({1: 2, 3: 4}).to_lazy() \
        == Lazy(lambda: MonadDict({1: 2, 3: 4}))

    assert Try(f, is_success=True).to_lazy() \
        == Lazy(lambda: Try(f(), is_success=True))


# Generated at 2022-06-24 00:26:43.552258
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    """
    Unit test for bind method of class Maybe.

    :returns: assertion error when test failed
    :rtype: AssertionError
    """
    assert Maybe.just(1).bind(lambda a: None) == Maybe.nothing()
    assert Maybe.just(1).bind(lambda a: Maybe.just(a + 1)) == Maybe.just(2)
    assert Maybe.nothing().bind(lambda a: Maybe.just(a + 1)) == Maybe.nothing()


# Generated at 2022-06-24 00:26:46.048473
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()


# Generated at 2022-06-24 00:26:47.986238
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just('Hello').to_lazy()
    assert lazy._f() == 'Hello'

# Generated at 2022-06-24 00:26:50.187523
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    assert Maybe.just('test').to_lazy() == Lazy(lambda: 'test')



# Generated at 2022-06-24 00:26:55.370728
# Unit test for method bind of class Maybe
def test_Maybe_bind():

    # sum of 2 and 3 is 5
    def sum_of_two_and_three(value):
        return value + 2 + 3

    maybe_5 = Maybe.just(5)
    assert maybe_5.bind(sum_of_two_and_three) == Maybe.just(10)

    maybe_none = Maybe.nothing()
    assert maybe_none.bind(sum_of_two_and_three) == Maybe.nothing()



# Generated at 2022-06-24 00:26:58.269168
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)



# Generated at 2022-06-24 00:27:04.833664
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    import pytest

    def add2(x):
        return x + 2

    def add2_and_return_Nothing_if_negative(x):
        if x < 0:
            return Maybe.nothing()
        return Maybe.just(x + 2)

    assert Maybe.nothing().bind(add2_and_return_Nothing_if_negative) == \
        Maybe.nothing()

    assert Maybe.just(2).bind(add2_and_return_Nothing_if_negative) == \
        Maybe.just(4)

    assert Maybe.just(-3).bind(add2_and_return_Nothing_if_negative) == \
        Maybe.nothing()


# Generated at 2022-06-24 00:27:09.897753
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(10)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-24 00:27:13.280706
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m = Maybe.just(5)
    assert m.to_lazy() == Lazy(lambda: 5)
    m = Maybe.nothing()
    assert m.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:27:20.341945
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    def div2(value: int) -> Maybe[int]:
        return Maybe.just(value // 2)

    assert Maybe.just(5).bind(div2) == Maybe.just(2)
    assert Maybe.just(5).bind(div2).bind(div2) == Maybe.just(1)
    assert Maybe.nothing().bind(div2) == Maybe.nothing()



# Generated at 2022-06-24 00:27:25.201487
# Unit test for method bind of class Maybe
def test_Maybe_bind():
    five = lambda x: Maybe.just(x + 1)

    assert(
        Maybe.just(2).bind(five) == Maybe.just(3)
    )

    assert(
        Maybe.nothing().bind(five) == Maybe.nothing()
    )


# Generated at 2022-06-24 00:27:29.432010
# Unit test for method to_try of class Maybe
def test_Maybe_to_try():
    assert Maybe(True, True).to_try() == Try(None, is_success=False)
    assert Maybe(True, False).to_try() == Try(True, is_success=True)


if __name__ == "__main__":
    test_Maybe_to_try()

# Generated at 2022-06-24 00:27:34.610332
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    value = Maybe.just(10)
    assert value.to_validation() == Validation.success(10)

    value = Maybe.nothing()
    assert value.to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:27:36.383155
# Unit test for constructor of class Maybe
def test_Maybe():
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe(None, True)


# Generated at 2022-06-24 00:27:38.190274
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy().value() == 2
    assert Maybe.nothing().to_lazy().value() is None



# Generated at 2022-06-24 00:27:40.889597
# Unit test for method map of class Maybe
def test_Maybe_map():
    def to_2(argument):
        return argument * argument

    maybe_of_2 = Maybe.just(2)
    maybe_of_4 = maybe_of_2.map(to_2)
    assert maybe_of_4 == Maybe.just(4)

    maybe_of_nothing = Maybe.nothing()
    maybe_of_nothing_2 = maybe_of_nothing.map(to_2)
    assert maybe_of_nothing_2 == Maybe.nothing()



# Generated at 2022-06-24 00:27:43.650153
# Unit test for constructor of class Maybe
def test_Maybe():
    maybe_a = Maybe.just('a')
    maybe_b = Maybe.just('b')
    maybe_none = Maybe.nothing()

    assert maybe_a == maybe_a
    assert isinstance(maybe_a, Maybe)
    assert maybe_a != None
    assert maybe_none != maybe_b



# Generated at 2022-06-24 00:27:47.699688
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add_one(x):
        return x + 1
    assert Maybe.just(add_one).ap(Maybe.just(1)) == Maybe.just(2)
    assert Maybe.just(add_one).ap(Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.just(1)) == Maybe.nothing()
    assert Maybe.nothing().ap(Maybe.nothing()) == Maybe.nothing()

# Generated at 2022-06-24 00:27:49.136759
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(10).to_lazy().value() == Lazy(lambda: 10).value()



# Generated at 2022-06-24 00:27:56.015606
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    def add(x):
        return lambda y: x + y

    assert Maybe(add, False).ap(Maybe.just(5)) == Maybe.just(7)
    assert Maybe(None, True).ap(Maybe.just(5)) == Maybe.nothing()
    assert Maybe(add, False).ap(Maybe.nothing()) == Maybe.nothing()


# Generated at 2022-06-24 00:27:59.923949
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe(1, False).get_or_else(2) == 1
    assert Maybe(None, True).get_or_else(2) == 2


# Generated at 2022-06-24 00:28:03.119506
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """Test
    """
    assert str(Maybe.just(1).to_lazy().value()) == '1'

    assert str(Maybe.nothing().to_lazy().value()) == 'None'

# Generated at 2022-06-24 00:28:07.822047
# Unit test for method to_validation of class Maybe
def test_Maybe_to_validation():
    from pymonet.validation import Validation

    assert Maybe.just(1).to_validation() == Validation.success(1)
    assert Maybe.nothing().to_validation() == Validation.success(None)


# Generated at 2022-06-24 00:28:11.520750
# Unit test for constructor of class Maybe
def test_Maybe():
    """
    Test of normal case.

    :returns: bool: True when test is successfull, otherwise False
    """
    return Maybe.just(1) == Maybe(1, False) and \
           Maybe.nothing() == Maybe(None, True)

# Generated at 2022-06-24 00:28:18.321721
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    # Arrange
    just = Maybe.just(1)  # type: Maybe
    nothing = Maybe.nothing()  # type: Maybe

    # Act
    just_result = just.get_or_else(0)  # type: int
    nothing_result = nothing.get_or_else(0)  # type: int

    # Assert
    assert just_result == 1
    assert nothing_result == 0



# Generated at 2022-06-24 00:28:23.788744
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(12).get_or_else('test_value') == 12
    assert Maybe.nothing().get_or_else('test_value') == 'test_value'


# Generated at 2022-06-24 00:28:26.553876
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just('Some')
    assert Maybe.just('Some') != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-24 00:28:32.614867
# Unit test for method to_either of class Maybe
def test_Maybe_to_either():
    from pymonet.either import Either, Left, Right

    assert isinstance(Maybe.just(2).to_either(), Either)
    assert isinstance(Maybe.just(2).to_either(), Right)
    assert Maybe.just(2).to_either().value == 2
    assert isinstance(Maybe.nothing().to_either(), Either)
    assert isinstance(Maybe.nothing().to_either(), Left)
    assert Maybe.nothing().to_either().value == None


# Generated at 2022-06-24 00:28:35.818095
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(10).get_or_else(12) == 10
    assert Maybe.just('test').get_or_else('default') == 'test'
    assert Maybe.nothing().get_or_else(12) == 12
    assert Maybe.nothing().get_or_else('default') == 'default'


# Generated at 2022-06-24 00:28:40.914805
# Unit test for method ap of class Maybe
def test_Maybe_ap():
    wrapped = Maybe.just(lambda x: x + 2)
    assert wrapped.ap(Maybe.just(10)) == Maybe.just(12)

    wrapped = Maybe.nothing()
    assert wrapped.ap(Maybe.just(10)) == wrapped


# Generated at 2022-06-24 00:28:43.263492
# Unit test for method get_or_else of class Maybe
def test_Maybe_get_or_else():
    assert Maybe.just(5).get_or_else(10) == 5
    assert Maybe.nothing().get_or_else(10) == 10


# Generated at 2022-06-24 00:28:50.683917
# Unit test for method map of class Maybe
def test_Maybe_map():
    assert Maybe.just(1).map(lambda x: x * 2) == Maybe.just(2)
    assert Maybe.just(1).map(lambda x: x ** 2) == Maybe.just(1)
    assert Maybe.just(2).map(lambda x: x * 2) == Maybe.just(4)
    assert Maybe.just(3).map(lambda x: x ** 2) == Maybe.just(9)
    assert Maybe.just(None).map(lambda x: x * 2) == Maybe.just(None)
    assert Maybe.nothing().map(lambda x: x * 2) == Maybe.nothing()
