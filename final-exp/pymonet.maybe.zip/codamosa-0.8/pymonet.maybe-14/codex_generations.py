

# Generated at 2022-06-12 05:11:07.265522
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe(1, True)


# Generated at 2022-06-12 05:11:15.335041
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert not (Maybe(1, False) == Maybe(2, False))
    assert not (Maybe(1, False) == Maybe(1, True))
    assert not (Maybe(1, True) == Maybe(2, True))
    assert Maybe(1, True) == Maybe(1, True)
    assert not (Maybe(1, True) == 2)
    assert not (Maybe(1, True) == 'string')
    assert not (Maybe(1, True) == Maybe.just(1))
    assert Maybe(1, False) == Maybe.just(1)


# Generated at 2022-06-12 05:11:23.522142
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    test_data = [
        {
            "method": Maybe.just(1).filter,
            "expected": Maybe.just(1),
            "params": [lambda value: True],
            "description": "should return Maybe with value 1",
        },
        {
            "method": Maybe.just(1).filter,
            "expected": Maybe.nothing(),
            "params": [lambda value: False],
            "description": "should return nothing",
        },
        {
            "method": Maybe.nothing().filter,
            "expected": Maybe.nothing(),
            "params": [lambda value: True],
            "description": "should return empty Maybe",
        },
    ]

    for data in test_data:
        actual = data.get("method")(*data.get("params"))
        expected = data.get

# Generated at 2022-06-12 05:11:36.171259
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from tests.helpers import draw_str

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.just([1, 2, 3]) == Maybe.just([1, 2, 3])
    assert Maybe.just({1, 2, 3}) != Maybe.just({1, 2, 3})

    assert Maybe.nothing() != [1, 2, 3]
    assert Maybe.nothing() != "Hello!"

    draw_str(
        "Testing __eq__ of Maybe...",
        "OK",
        "Error. Not equal values"
    )


# Generated at 2022-06-12 05:11:41.792569
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe(2, False).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:11:47.689926
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.just(0) == Maybe.just(0)


# Generated at 2022-06-12 05:11:53.875861
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Box(1)
    assert Maybe.nothing() == Maybe.just(1)
    assert Maybe.just(0) == Maybe.nothing()


# Generated at 2022-06-12 05:12:01.524864
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    maybe: Maybe[int] = Maybe.just(10)

    # Act
    result: Maybe[int] = maybe.filter(lambda value: value % 2 == 0)

    # Assert
    assert Maybe.just(10) == result

    # Arrange
    maybe: Maybe[int] = Maybe.just(11)

    # Act
    result: Maybe[int] = maybe.filter(lambda value: value % 2 == 0)

    # Assert
    assert Maybe.nothing() == result

    # Arrange
    maybe: Maybe[int] = Maybe.nothing()

    # Act
    result: Maybe[int] = maybe.filter(lambda value: value % 2 == 0)

    # Assert
    assert Maybe.nothing() == result


# Generated at 2022-06-12 05:12:06.437846
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda val: val == 1) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda val: val == 2) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda val: val == 1) == Maybe.nothing())


# Generated at 2022-06-12 05:12:10.753840
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)



# Generated at 2022-06-12 05:12:25.145682
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 42) == Lazy(lambda: 42)
    assert Lazy(lambda: 42) != Lazy(lambda: 13)
    assert Lazy(lambda: 42).get() == 42
    assert Maybe(42, False).to_lazy() == Lazy(lambda: 42)
    assert Maybe(42, False).to_lazy() != Lazy(lambda: 13)
    assert Maybe(42, False).to_lazy().get() == 42
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(None, True).to_lazy() != Lazy(lambda: 13)
    assert Maybe(None, True).to_lazy().get() is None


# Generated at 2022-06-12 05:12:30.169752
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:12:33.871946
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual = Maybe.just(42).filter(lambda x: x == 42)
    expected = Maybe.just(42)
    assert actual == expected

    actual = Maybe.just(42).filter(lambda x: x > 42)
    expected = Maybe.nothing()
    assert actual == expected

    actual = Maybe.nothing().filter(lambda x: x > 42)
    expected = Maybe.nothing()
    assert actual == expected

# Generated at 2022-06-12 05:12:36.375243
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.test.helpers import assert_equals

    maybe = Maybe.just(0)
    assert_equals(maybe.filter(lambda x: x < 5), Maybe.just(0))
    assert_equals(maybe.filter(lambda x: x > 5), Maybe.nothing())



# Generated at 2022-06-12 05:12:39.577981
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = 10
    maybe_value = Maybe.just(value)
    lazy_value = maybe_value.to_lazy()
    assert lazy_value.get() == value


# Generated at 2022-06-12 05:12:45.241300
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:12:52.594877
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 'some value'
    assert Maybe.just(value) == Maybe.just(value)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(value)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just(value) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.just(value)
    assert Maybe.just(value) != Maybe.just(None)


# Generated at 2022-06-12 05:12:57.696798
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer_test(value: int):
        return value > 1

    just = Maybe.just(2)
    nothing = Maybe.nothing()

    assert just.filter(filterer_test) == Maybe.just(2)
    assert nothing.filter(filterer_test) == Maybe.nothing()



# Generated at 2022-06-12 05:13:03.897921
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    maybe_a = Maybe[int](123, False)
    maybe_b = Maybe[int](123, False)
    maybe_c = Maybe[str]('123', False)

    # Then
    assert (maybe_a == maybe_b) is True
    assert (maybe_a == maybe_c) is False
    assert (maybe_a == 123) is False
    assert (maybe_a == '123') is False


# Generated at 2022-06-12 05:13:13.298936
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    maybe_with_positive_value = Maybe.just(5)
    maybe_with_negative_value = Maybe.just(-5)
    maybe_with_zero_value = Maybe.just(0)
    empty_maybe = Maybe.nothing()

    def less_zero(value):
        return value < 0

    # when
    result_of_maybe_with_positive_value = maybe_with_positive_value.filter(less_zero)
    result_of_maybe_with_negative_value = maybe_with_negative_value.filter(less_zero)
    result_of_maybe_with_zero_value = maybe_with_zero_value.filter(less_zero)
    result_of_empty_maybe = empty_maybe.filter(less_zero)

    # then
    assert result_of_maybe_with_

# Generated at 2022-06-12 05:13:23.427951
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_equals(val_str, val_bool):
        assert (Maybe.just(val_str) == Maybe.just(val_str)) == val_bool

    test_equals('1', True)
    test_equals('2', False)
    test_equals(1, False)
    test_equals(None, False)


# Generated at 2022-06-12 05:13:27.774253
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:13:34.054552
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:13:39.837780
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.just('test') != Maybe.just('another')
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)


# Generated at 2022-06-12 05:13:44.540846
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.nothing()
    assert not Maybe.just(1) == Maybe.just(2)


# Generated at 2022-06-12 05:13:49.993157
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    m = Maybe.just(5)
    filterer = lambda x: x > 2

    # Act
    new_m = m.filter(filterer)

    # Assert
    assert isinstance(new_m, Maybe)
    assert new_m == m


# Generated at 2022-06-12 05:13:54.682248
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe[int](1, False) == Maybe[int](1, False)
    assert Maybe[int](1, False) != Maybe[int](1, True)
    assert Maybe[int](1, False) != Maybe[int](2, False)
    assert Maybe[int](1, False) != Maybe[str]('Hey', False)
    assert Maybe[int](1, False) != (1, False)



# Generated at 2022-06-12 05:14:05.738489
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test():
        return 'success'

    assert Maybe.just(1) == Maybe.just(1).to_lazy().value()
    assert Maybe.just(1).to_lazy().value() == Maybe.just(1).to_lazy().to_box().value
    assert Maybe.just(1).to_lazy().value() == Maybe.just(1).to_lazy().to_either().value
    assert Maybe.just(1).to_lazy().value() == Maybe.just(1).to_lazy().to_try().value
    assert Maybe.just(1).to_lazy().value() == Maybe.just(1).to_lazy().to_validation().value

# Generated at 2022-06-12 05:14:11.649035
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Create maybe with test value
    maybe = Maybe.just("test")

    # check case when value of maybe is the same
    assert maybe == Maybe.just("test")

    # check case when value of maybe different
    assert not maybe == Maybe.just("test1")

    # check case when value of maybe is None
    assert not maybe == Maybe.nothing()



# Generated at 2022-06-12 05:14:17.394009
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    maybe = Maybe.just(10)

    # WHEN
    actual = maybe.filter(lambda a: a >= 10)

    # THEN
    assert actual == Maybe.just(10)

    # WHEN
    actual = maybe.filter(lambda a: a >= 15)

    # THEN
    assert actual == Maybe.nothing()



# Generated at 2022-06-12 05:14:26.392632
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just({'name': 'Alice'}) == Maybe.just({'name': 'Alice'})
    assert Maybe.just(Functor(lambda f: f(1))) == Maybe.just(Functor(lambda f: f(1)))
    assert Maybe.just(Try(1)) == Maybe.just(Try(1))

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:14:30.460983
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:14:35.941032
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(2)
    assert maybe.to_lazy() == Lazy(lambda: 2)
    maybe = Maybe.just(3)
    assert maybe.to_lazy() == Lazy(lambda: 3)
    maybe = Maybe.nothing()
    assert maybe.to_lazy() == Lazy(lambda: None)
    maybe = Maybe.nothing()
    assert maybe.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:14:37.931106
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:41.951886
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(10, False).filter(lambda x: x % 2 == 0) == Maybe.just(10)
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:14:49.089569
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda v: v) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda v: not v) == Maybe.nothing()
    assert Maybe.just(False).filter(lambda v: not v) == Maybe.just(False)
    assert Maybe.just(False).filter(lambda v: v) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v) == Maybe.nothing()


# Generated at 2022-06-12 05:14:59.014281
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_reflexivity():
        maybe_instance = Maybe.just(1)
        assert(maybe_instance == maybe_instance)
    def test_symmetry():
        maybe_instance_1 = Maybe.just(1)
        maybe_instance_2 = Maybe.just(1)
        assert(maybe_instance_1 == maybe_instance_2)
        assert(maybe_instance_2 == maybe_instance_1)
    def test_transitivity():
        maybe_instance_1 = Maybe.just(1)
        maybe_instance_2 = Maybe.just(1)
        maybe_instance_3 = Maybe.just(1)
        assert(maybe_instance_1 == maybe_instance_2)
        assert(maybe_instance_2 == maybe_instance_3)
        assert(maybe_instance_1 == maybe_instance_3)

# Generated at 2022-06-12 05:15:10.373781
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x <= 2) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x <= 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x <= 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x <= 2) == Maybe.nothing()


# Generated at 2022-06-12 05:15:15.735384
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.box import Box

    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(10) == Try(10, True)
    assert Maybe.just(10) != Try(10, False)
    assert Maybe.nothing() == Try(None, False)

    assert Maybe.just(10) == Box(10)
    assert Maybe.just(10) != Box(None)
    assert Maybe.nothing() == Box(None)

    assert Maybe.just(10) == Right(10)
    assert Maybe.just(10) != Left(10)
    assert Maybe.nothing() == Left

# Generated at 2022-06-12 05:15:21.523187
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, True) != None
    assert Maybe(1, False) != None
    assert Maybe(1, True) != []
test_Maybe___eq__()



# Generated at 2022-06-12 05:15:35.151810
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x < 10) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 3).is_nothing
    assert Maybe.nothing().filter(lambda x: x < 10).is_nothing


# Generated at 2022-06-12 05:15:38.936305
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:15:48.889784
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('str') == Maybe.just('str')
    assert Maybe.just([1, 2, 3]) == Maybe.just([1, 2, 3])
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('str_1') != Maybe.just('str_2')
    assert Maybe.just([1, 2, 3]) != Maybe.just([1, 2, 4])
    assert Maybe.nothing() != Maybe.just(1)

    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:15:52.471109
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    class FakeMaybe:
        pass

    maybe = Maybe.just(1)
    assert maybe == maybe
    assert maybe != FakeMaybe

    maybe = Maybe.nothing()
    assert maybe == maybe
    assert maybe != Maybe.just(1)



# Generated at 2022-06-12 05:15:55.155950
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:15:58.705633
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(12) == Maybe.just(12)
    assert Maybe.just(3) != Maybe.just(5)
    assert Maybe.just(7) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:16:02.985233
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    val = 2
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2), "test_Maybe_to_lazy failed"
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None), "test_Maybe_to_lazy failed"



# Generated at 2022-06-12 05:16:08.647131
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    maybe = Maybe.just(10)
    assert maybe.filter(is_even) == Maybe.just(10)
    maybe = Maybe.just(11)
    assert maybe.filter(is_even) == Maybe.nothing()
    maybe = Maybe.nothing()
    assert maybe.filter(is_even) == Maybe.nothing()


# Generated at 2022-06-12 05:16:13.208056
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:16:17.288785
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:16:42.439681
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test implementaion of __eq__ method of Maybe class.

    :returns: Nothing
    :rtype: None

    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:16:45.976816
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:16:47.412390
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)



# Generated at 2022-06-12 05:16:51.768771
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:17:01.659298
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_eq_1 = Maybe.just(['a', 'b', 'c'])
    maybe_eq_2 = Maybe.just(['a', 'b', 'c'])
    maybe_eq_3 = Maybe.just([1, 2, 3])
    maybe_eq_4 = Maybe.nothing()
    maybe_eq_5 = Maybe.nothing()
    assert maybe_eq_1 == maybe_eq_1
    assert maybe_eq_1 == maybe_eq_2
    assert maybe_eq_1 != maybe_eq_3
    assert maybe_eq_1 != maybe_eq_4
    assert maybe_eq_4 == maybe_eq_4
    assert maybe_eq_4 == maybe_eq_5


# Generated at 2022-06-12 05:17:06.464382
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just([1, 2]) != Maybe.just([1, 2])
    assert Maybe.just(None) != Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:17:10.243907
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:17:13.285190
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:17.906199
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)

    assert Maybe(True, False) == Maybe(True, False)
    assert Maybe(True, False) != Maybe(False, False)
    assert Maybe(True, False) != Maybe(True, True)


# Generated at 2022-06-12 05:17:23.384825
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test method to_lazy of class Maybe.
    """
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:46.429276
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:17:50.142465
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:17:51.598340
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(1) == Maybe(1, False)
    assert maybe is True

# Generated at 2022-06-12 05:17:55.877125
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def foo():
        return 42

    maybe = Maybe(foo, False)
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 42


# Generated at 2022-06-12 05:18:00.505310
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:18:04.553224
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(1)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:18:06.417008
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:18:11.403943
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test that method __eq__ works correctly.
    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert not (Maybe.just(1) == None)
    assert not (Maybe.nothing() == None)

    assert not (Maybe.just(1) == Maybe.just(2))
    assert not (Maybe.just(1) == Maybe.nothing())
    assert not (Maybe.nothing() == Maybe.just(1))

# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:18:15.639930
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:18:18.564534
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:18:46.884047
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet import Matcher

    assert Maybe(1, False).filter(lambda x: x > 0) == Maybe(1, False)
    assert Maybe(1, False).filter(lambda x: x < 0) == Maybe(None, True)
    assert Maybe(None, True).filter(lambda x: x < 0) == Maybe(None, True)

    assert Matcher(Maybe(1, False)).matches(lambda x: x > 0)
    assert Matcher(Maybe(1, False)).matches(lambda x: x < 0)
    assert not Matcher(Maybe(None, True)).matches(lambda x: x < 0)



# Generated at 2022-06-12 05:18:51.903634
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe('a', False) == Maybe('a', False)
    assert Maybe(None, True) == Maybe(None, True)


# Generated at 2022-06-12 05:18:53.895514
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    m = Maybe.just(1)
    assert m.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:18:59.134742
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()



# Generated at 2022-06-12 05:19:03.752995
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: isinstance(x, int)) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: isinstance(x, str)) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: isinstance(x, int)) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: isinstance(x, str)) == Maybe.nothing()


# Generated at 2022-06-12 05:19:10.904645
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:19:19.919763
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) == Box(1)
    assert Maybe.nothing() == Box(None)

    assert Maybe.just(1) == Lazy(lambda: 1)
    assert Maybe.nothing() == Lazy(lambda: None)

    assert Maybe.just(1) == Try(1, is_success=True)
    assert Maybe.nothing() == Try(None, is_success=False)

    assert Maybe.just(1) == Validation.success(1)
   

# Generated at 2022-06-12 05:19:24.049580
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(2, False).filter(lambda x: x % 2 == 0) == Maybe(2, False)


# Generated at 2022-06-12 05:19:24.340630
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    pass

# Generated at 2022-06-12 05:19:30.807044
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_list import List

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert List.return_value(3).to_lazy() == Lazy(lambda: 3)
    assert List.return_value(3).to_lazy().get() == 3


# Generated at 2022-06-12 05:19:55.452178
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(123, False) == Maybe(123, False)
    assert Maybe(123, False) != Maybe(456, False)
    assert Maybe(123, False) != Maybe(123, True)
    assert Maybe(123, True) == Maybe(123, True)
    assert Maybe(123, False) != Maybe(456, True)



# Generated at 2022-06-12 05:19:59.181245
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:20:03.055285
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m_zero = Maybe.nothing().to_lazy()
    assert m_zero == Lazy(lambda: None)

    m_something = Maybe.just(1).to_lazy()
    assert m_something == Lazy(lambda: 1)

# Generated at 2022-06-12 05:20:06.322761
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:20:08.667557
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() == None



# Generated at 2022-06-12 05:20:20.095285
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Check filter for notnothing Maybe

    def check_filter(maybe: Maybe[int], expected: Maybe[int], filterer: Maybe[int]):
        assert maybe.filter(lambda x: x % 2 == 0) == expected

    maybe = Maybe.just(4)
    expected = Maybe.just(4)
    filterer = Maybe.just(4)
    check_filter(maybe, expected, filterer)

    maybe = Maybe.just(4)
    expected = Maybe.just(4)
    filterer = Maybe.just(2)
    check_filter(maybe, expected, filterer)

    maybe = Maybe.just(4)
    expected = Maybe.nothing()
    filterer = Maybe.nothing()
    check_filter(maybe, expected, filterer)

    maybe = Maybe.just(5)


# Generated at 2022-06-12 05:20:26.999293
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def add_a(value):
        return Maybe.just(value + 'a')
    def add_b(value):
        return Maybe.just(value + 'b')
    def add_c(value):
        return Maybe.just(value + 'c')
    def filter_a(value):
        return 'a' in value

    assert Maybe.just('1').filter(filter_a) == Maybe.nothing()
    assert Maybe.just('a').filter(filter_a) == Maybe.just('a')
    assert Maybe.just('ab').filter(filter_a) == Maybe.just('ab')

    assert Maybe.just('1').filter(filter_a).filter(filter_a) == Maybe.nothing()

# Generated at 2022-06-12 05:20:32.119338
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda value: value > 0) == Maybe(1, False)
    assert Maybe(1, False).filter(lambda value: value < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value != 0) == Maybe.nothing()



# Generated at 2022-06-12 05:20:34.907934
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:40.113395
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    result = Maybe.just(42).to_lazy()
    assert isinstance(result, Lazy)
    assert isinstance(result.value(), int)