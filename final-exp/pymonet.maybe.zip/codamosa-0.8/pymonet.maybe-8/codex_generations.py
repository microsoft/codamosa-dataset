

# Generated at 2022-06-12 05:11:08.662660
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:11:17.877153
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(2, True) == Maybe(2, True)
    assert Maybe(1, False) != 3
    assert Maybe(1, True) != None
    assert Maybe(1, False) != []
    assert Maybe(1, False) != []
    assert Maybe(1, False) != {}
    assert Maybe(1, True) != {}


# Generated at 2022-06-12 05:11:24.117807
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    import pytest

    m = Maybe.just(4)
    m_lazy = m.to_lazy()
    assert isinstance(m_lazy, Lazy)
    assert m_lazy.force() == m.value
    with pytest.raises(TypeError):
        assert m_lazy.force() == 4

    m = Maybe.nothing()
    m_lazy = m.to_lazy()
    assert isinstance(m_lazy, Lazy)
    assert m_lazy.force() is None
    with pytest.raises(TypeError):
        assert m_lazy.force() is 'None'


# Generated at 2022-06-12 05:11:30.042515
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:11:35.998347
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) == Maybe(1, False)
    assert Maybe.nothing() == Maybe.nothing() == Maybe(None, True)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe(1, True)
    assert Maybe.nothing() != Maybe(None, False)


# Generated at 2022-06-12 05:11:42.697164
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(5)
    res1 = m.filter(lambda x: x == 10)
    res2 = m.filter(lambda x: x == 5)
    assert res1.is_nothing
    assert not res2.is_nothing


# Generated at 2022-06-12 05:11:50.037227
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    @staticmethod
    def is_even(x):
        return x % 2 == 0

    some_even = Maybe.just(8)
    some_odd = Maybe.just(3)

    assert some_odd.filter(is_even).is_nothing is True
    assert some_even.filter(is_even).value == 8
    assert some_even.filter(is_even).is_nothing is False



# Generated at 2022-06-12 05:11:52.882252
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    >>> test_Maybe___eq__()
    True
    """
    return Maybe.just(1) == Maybe.just(1)


# Generated at 2022-06-12 05:11:55.632306
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:12:07.105280
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy, value
    from pymonet.either import Left, Right

    # Test for empty Maybe
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    # Test for not empty Maybe
    # with value that is int
    maybe_int = Maybe.just(5)
    lazy_int = Lazy(lambda: 5)
    assert maybe_int.to_lazy() == lazy_int
    assert (lazy_int == maybe_int.to_lazy())
    assert lazy_int.value() == 5
    assert (Lazy(lambda: None) == Maybe.nothing().to_lazy())

    # with value that is float
    maybe_float = Maybe.just(5.0)
    lazy_float = Lazy(lambda: 5.0)

# Generated at 2022-06-12 05:12:23.808799
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Maybe.just(3).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

    try:
        assert Lazy(lambda: None) == Maybe.just(3).to_lazy()
    except AssertionError:
        pass
    else:
        raise AssertionError('Maybe.to_lazy failed')

    try:
        assert Lazy(lambda: 3) == Maybe.nothing().to_lazy()
    except AssertionError:
        pass
    else:
        raise AssertionError('Maybe.to_lazy failed')


# Generated at 2022-06-12 05:12:34.713933
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1.0)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just('a') != Maybe.just('b')
    assert Maybe.just(lambda x: x) == Maybe.just(lambda x: x)
    assert Maybe.just([]) == Maybe.just([])
    assert Maybe.just([1, 2]) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:12:40.021947
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    m3 = Maybe.just(3)
    assert m1 == m1
    assert m1 != "string"
    assert m1 == m2
    assert m1 != m3
    assert m1 != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:44.336069
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe(10, False)
    assert Maybe(10, True) == Maybe(10, True)

    assert Maybe(10, False) != Maybe(10, True)
    assert Maybe(10, True) != Maybe(10, False)


# Generated at 2022-06-12 05:12:47.700779
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:12:55.249727
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_case_for_two_empty_Monads():
        result = Maybe.nothing() == Maybe.nothing()
        assert result
        result = Maybe.nothing() == Maybe.just(2)
        assert not result

    def test_case_for_two_not_empty_Monads():
        result = Maybe.just(1) == Maybe.just(1)
        assert result
        result = Maybe.just(1) == Maybe.just(2)
        assert not result
        result = Maybe.just(1) == Maybe.nothing()
        assert not result

    test_case_for_two_empty_Monads()
    test_case_for_two_not_empty_Monads()



# Generated at 2022-06-12 05:13:00.664390
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    s = Maybe(2, False).filter(lambda x: x % 2 == 0)
    assert(s.value == 2)

    s = Maybe(3, False).filter(lambda x: x % 2 == 0)
    assert(s.is_nothing)

    s = Maybe(None, True).filter(lambda x: x % 2 == 0)
    assert(s.is_nothing)



# Generated at 2022-06-12 05:13:04.468437
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:13:09.278705
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 4) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x == 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 4) == Maybe.nothing()



# Generated at 2022-06-12 05:13:15.023881
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    val1 = Maybe.just(5)
    val2 = Maybe.just(5)
    val3 = Maybe.just(3)
    val4 = Maybe.nothing()
    val5 = Maybe.nothing()
    assert val1 == val2
    assert not (val1 == val3)
    assert not (val1 == val4)
    assert val4 == val5

# Generated at 2022-06-12 05:13:25.492980
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)


# Generated at 2022-06-12 05:13:28.641272
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)


# Generated at 2022-06-12 05:13:31.538034
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # Arrange
    def even(x: int) -> bool:
        return x % 2 == 0

    maybe = Maybe.just(1)

    # Act
    result = maybe.filter(even)

    # Assert
    expected = Maybe.nothing()
    assert result == expected


# Generated at 2022-06-12 05:13:37.480404
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value): return value % 2 == 0

    maybe = Maybe.nothing()

    assert maybe.filter(filterer) == Maybe.nothing()

    maybe = Maybe.just(2)

    assert maybe.filter(filterer) == Maybe.just(2)

    maybe = Maybe.just(3)

    assert maybe.filter(filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:13:41.222217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(_is_odd) == Maybe.just(1)
    assert Maybe.just(2).filter(_is_odd) == Maybe.nothing()
    assert Maybe.nothing().filter(_is_odd) == Maybe.nothing()



# Generated at 2022-06-12 05:13:45.262249
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # test with notempty Maybe
    assert Maybe.just(20).filter(lambda x: x > 10) == Maybe.just(20)
    # test with empty Maybe
    assert Maybe.just(50).filter(lambda x: x > 10) == Maybe.just(50)


# Generated at 2022-06-12 05:13:49.677991
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:54.038944
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe.just(1)
    maybe2 = Maybe.just(2)
    maybe3 = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    assert maybe1 == maybe1
    assert maybe1 != maybe2
    assert maybe1 == maybe3
    assert maybe1 != maybe_nothing



# Generated at 2022-06-12 05:14:00.655557
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe

    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-12 05:14:02.390066
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Just(1) == Just(1)


# Generated at 2022-06-12 05:14:14.450336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda value: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: False) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda value: True) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda value: False) == Maybe.nothing()



# Generated at 2022-06-12 05:14:18.564417
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:14:22.617984
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)


# Generated at 2022-06-12 05:14:27.136491
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda value: value < 5) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda value: value >= 5) == Maybe.just(10)
    assert Maybe.nothing().filter(lambda value: value < 5) == Maybe.nothing()


# Generated at 2022-06-12 05:14:31.293641
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing().__class__ == Maybe.nothing().__class__
    assert Maybe.just(lambda: 1) != Maybe.nothing()
    assert Maybe.just(2) != None



# Generated at 2022-06-12 05:14:37.341083
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def func(a):
        return a + 2

    a = Maybe.just(2)

    assert Maybe.just(2) == Maybe.just(2), "Maybe(2) is not equal to Maybe(2)"
    assert Maybe.nothing() == Maybe.nothing(), "Maybe.nothing() is not equal to Maybe.nothing()"
    assert Maybe.nothing() == a.map(func), "Maybe.nothing() is not equal to a.map(lambda a: a + 2)"
    assert Maybe.just(4) == a.map(func), "Maybe.just(4) is not equal to a.map(lambda a: a + 2)"



# Generated at 2022-06-12 05:14:45.439802
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, False) != Maybe(None, True)
    assert Maybe(None, True) != Maybe(1, False)
    assert Maybe(None, True) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(2, False)



# Generated at 2022-06-12 05:14:49.598478
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe(1, False)
    m2 = Maybe(1, False)
    m3 = Maybe.just(1)
    assert m1 == m2
    assert m1 == m3
    assert m2 == m3


# Generated at 2022-06-12 05:14:55.878017
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # __eq__ is correct for empty Maybe
    assert Maybe.nothing() == Maybe.nothing()

    # __eq__ is correct for empty Maybe
    assert not Maybe.just('str') == Maybe.nothing()

    # __eq__ is correct for nonempty Maybe
    assert Maybe.just(42) == Maybe.just(42)

    # __eq__ is correct for nonempty Maybe
    assert not Maybe.just(42) == Maybe.just(42.42)



# Generated at 2022-06-12 05:14:59.710544
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:15:18.588767
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(1)

# Unit tests for method just

# Generated at 2022-06-12 05:15:31.043659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2.0) == Maybe.just(2.0)
    assert Maybe.just("PyMonet") == Maybe.just("PyMonet")
    assert Maybe.just(True) == Maybe.just(True)

    assert Maybe.just(1) == Maybe(1, False)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(1.0)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just("PyMonet")
    assert Maybe.just(1) != Maybe.just(True)

    assert Maybe.just(1) != None

# Generated at 2022-06-12 05:15:33.940814
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(3)


# Generated at 2022-06-12 05:15:41.227996
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # for not empty Maybes
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    # for empty Maybes
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    # test for None values
    assert Maybe.just(1) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.just(None)


# Generated at 2022-06-12 05:15:45.857229
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just(1) == Maybe.nothing()


# Generated at 2022-06-12 05:15:50.313715
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("test") == Maybe.just("test")
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just("test") == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just("test")
    assert not Maybe.just("test") == Maybe.just("test1")


# Generated at 2022-06-12 05:15:56.613249
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    lazy = Maybe.just(2).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get_value() == 2
    lazy = Maybe.nothing().to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get_value() is None


# Generated at 2022-06-12 05:15:59.128069
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()



# Generated at 2022-06-12 05:16:07.204932
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x > 0).value == 1, \
        'Maybe[1] filter False should return Maybe[1]'
    assert Maybe(1, False).filter(lambda x: x < 0).is_nothing, \
        'Maybe[1] filter True should return Maybe[None]'
    assert Maybe(1, True).filter(lambda x: x > 0).is_nothing, \
        'Maybe[None] filter False should return Maybe[None]'
    assert Maybe(1, True).filter(lambda x: x < 0).is_nothing, \
        'Maybe[None] filter True should return Maybe[None]'

# Generated at 2022-06-12 05:16:12.960158
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.just([])
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-12 05:16:32.353760
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1), \
        'Maybe.just(1).to_lazy() == Lazy(lambda: 1)'
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None), \
        'Maybe.nothing.to_lazy() == Lazy(lambda: None)'



# Generated at 2022-06-12 05:16:38.562364
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x < 2) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 2 == Maybe.nothing())

# Generated at 2022-06-12 05:16:42.310039
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: a == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: a == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a == 1) == Maybe.nothing()

# Generated at 2022-06-12 05:16:46.904807
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just('abc') == Maybe.just('abc')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(7)
    assert Maybe.just('abc') != Maybe.just('cba')
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-12 05:16:51.050457
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:16:58.313845
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    m3 = Maybe.just(2)
    m4 = Maybe.nothing()
    m5 = Maybe.nothing()
    # Then
    eq_(True, m1 == m2)
    eq_(False, m1 == m3)
    eq_(True, m4 == m5)
    eq_(False, m3 == m4)



# Generated at 2022-06-12 05:17:06.407131
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(227).filter(lambda x: x % 2 == 0) != Maybe.just(227)
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).to_box() == Box(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).to_box() == Box(None)
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).to_validation() == Validation.success(2)

# Generated at 2022-06-12 05:17:13.335598
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(2)
    filtered_maybe = maybe.filter(lambda x: x % 2 == 0)
    assert filtered_maybe == Maybe.just(2)

    maybe = Maybe.just(3)
    filtered_maybe = maybe.filter(lambda x: x % 2 == 0)
    assert filtered_maybe == Maybe.nothing()

    maybe = Maybe.nothing()
    filtered_maybe = maybe.filter(lambda x: x % 2 == 0)
    assert filtered_maybe == Maybe.nothing()

# Generated at 2022-06-12 05:17:18.889439
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Try.unit(5).to_lazy() == Lazy(lambda: 5)
    assert Try.failure(None).to_lazy() == Lazy(lambda: None)

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.failure([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:28.612831
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    assert Maybe.just(42) == Maybe.just(42)
    assert Try(42, is_success=True) == Maybe.just(42)
    assert Right(42) == Maybe.just(42)

    assert Maybe.nothing() == Maybe.nothing()
    assert Try(None, is_success=False) == Maybe.nothing()

    assert not Maybe.just(42) == Maybe.just(24)
    assert not Maybe.just(42) == Maybe.just(None)
    assert not Maybe.just(42) == Maybe.nothing()


# Generated at 2022-06-12 05:17:57.880530
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

# Generated at 2022-06-12 05:18:02.178956
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right, Left

    assert (Maybe.just(2).filter(lambda x: x == 2)) == Maybe.just(2)
    assert (Maybe.nothing().filter(lambda x: x == 2)) == Maybe.nothing()


# Generated at 2022-06-12 05:18:05.203045
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.nothing() != Maybe.just(11)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:18:08.554361
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test(expected_result, filtered):
        assert Maybe.just(filtered) \
            .filter(
                lambda x: x % 2 == 0
            ) \
            .get_or_else(None) == expected_result
    yield test, 10, 10
    yield test, None, 5

# Generated at 2022-06-12 05:18:14.251183
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(1) == Maybe.just(1))
    assert(Maybe.just(1) != Maybe.just(2))
    assert(Maybe.nothing() == Maybe.nothing())
    assert(Maybe.just(1) != Maybe.nothing())
    assert(Maybe.nothing() != Maybe.just(1))


# Generated at 2022-06-12 05:18:18.085255
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(42)
    assert Maybe.just(4) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-12 05:18:22.208275
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(None, True)
    assert Maybe(1, False) != Maybe('1', False)
    assert Maybe(1, False) != Maybe(None, False)
    assert Maybe(1, False) != Maybe(1, True)



# Generated at 2022-06-12 05:18:26.737062
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2) == Maybe.just(5)
    assert Maybe.just(2).filter(lambda x: x % 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2) == Maybe.nothing()


# Generated at 2022-06-12 05:18:31.456703
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    f = lambda x: x > 5
    assert Maybe.just(3).filter(f).is_nothing
    assert Maybe.just(3).filter(f).get_or_else(20) == 20
    assert Maybe.just(7).filter(f).get_or_else(20) == 7
    assert Maybe.nothing().filter(f).is_nothing


# Generated at 2022-06-12 05:18:34.478782
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert not (Maybe.just(1) == Maybe.nothing())
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:19:03.227625
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def _test_Maybe_to_lazy_helper(value: int) -> str:
        return 'Hello, World!'

    lazy: Lazy[Callable[[], str]] = Maybe.just(42).to_lazy()
    assert lazy.extract() == 42

    lazy: Lazy[Callable[[], str]] = Maybe.nothing().to_lazy()
    assert lazy.extract() is None



# Generated at 2022-06-12 05:19:08.396700
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)

# Generated at 2022-06-12 05:19:13.201674
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

# Generated at 2022-06-12 05:19:17.778592
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) == Maybe(2, True)

test_Maybe___eq__()



# Generated at 2022-06-12 05:19:22.489429
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-12 05:19:32.474641
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int = Maybe.just(1)

    assert maybe_int.filter(lambda it: it < 5) == Maybe.just(1)
    assert maybe_int.filter(lambda it: it > 5) == Maybe.nothing()

    maybe_str = Maybe.just('1')

    assert maybe_str.filter(lambda it: it < '5') == Maybe.just('1')
    assert maybe_str.filter(lambda it: it > '5') == Maybe.nothing()

    maybe_int = Maybe.nothing()

    assert maybe_int.filter(lambda it: it < 5) == Maybe.nothing()
    assert maybe_int.filter(lambda it: it > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:19:36.980242
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(10, False).filter(lambda x: x % 2 == 0) == Maybe(10, False)
    assert Maybe(11, True).filter(lambda x: x % 2 == 0) == Maybe(11, True)
    assert Maybe(11, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:19:46.300264
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(6) == Maybe.just(6)
    assert Maybe.just(7) == Maybe.just(7)
    assert Maybe.just(8) == Maybe.just(8)
    assert Maybe.just(9) == Maybe.just(9)
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just('b') == Maybe.just('b')

# Generated at 2022-06-12 05:19:52.002922
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe(1, False)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:19:57.405735
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(4)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:20:50.795493
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    monad1 = Maybe.just('test')
    monad2 = Maybe.just('test')
    monad3 = Maybe.just(10)
    monad4 = Maybe.nothing()
    monad5 = Maybe.nothing()

    assert monad1 == monad2
    assert monad2 == monad1
    assert not monad1 == monad3
    assert not monad1 == monad4
    assert monad4 == monad5
    assert not monad5 == monad1
    assert monad1 != monad3 != monad4 != monad5 != monad2 != monad1
    assert not monad5 == monad1
    assert monad1 != monad3 != monad4 != monad5 != monad2 != monad1

# Unit tests for methods of class Maybe

# Generated at 2022-06-12 05:20:54.097591
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)

# Generated at 2022-06-12 05:20:59.592566
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:21:05.013463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.just(2)
    maybe_one_two = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    assert maybe_one == maybe_one_two
    assert maybe_two != maybe_one_two
    assert maybe_one != maybe_nothing
    assert maybe_nothing != maybe_one

