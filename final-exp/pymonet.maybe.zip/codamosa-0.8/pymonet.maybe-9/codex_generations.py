

# Generated at 2022-06-12 05:11:05.487384
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Tests for method filter of class Maybe
    """
    # Test not empty Maybe
    assert Maybe.just(4).filter(lambda x: x > 2) == Maybe.just(4)
    # Test empty Maybe
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()
    # Test non empty Maybe with function which returns False
    assert Maybe.just(4).filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-12 05:11:08.725784
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    empty_maybe = Maybe.nothing()
    not_empty_maybe = Maybe.just(123)

    # Exercise and verify
    assert empty_maybe == Maybe.nothing()
    assert not_empty_maybe == Maybe.just(123)
    assert not_empty_maybe != Maybe.just(124)
    assert empty_maybe != Maybe.just('foo')


# Generated at 2022-06-12 05:11:19.503993
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_unit_test import monad_unit_test


# Generated at 2022-06-12 05:11:23.363606
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(10)
    m2 = Maybe.just(10)
    m3 = Maybe.just(12)
    assert m == m2
    assert not m == m3
    assert not m == 12
    assert not m == None


# Generated at 2022-06-12 05:11:35.377788
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(3, True) == Maybe(3, True)
    assert Maybe(4, True) == Maybe(4, True)

    assert Maybe(1, True) == Maybe(1, False) is False
    assert Maybe(1, True) == Maybe(2, True) is True
    assert Maybe(1, True) == Maybe(2, False) is False
    assert Maybe(1, False) == Maybe(1, True) is False
    assert Maybe(1, False) == Maybe(3, False) is False
    assert Maybe(1, False) == Maybe(3, True) is False


# Generated at 2022-06-12 05:11:38.889403
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(2)
    filtered = maybe.filter(lambda x: x % 2 == 0)
    assert isinstance(filtered, Maybe)
    assert filtered == Maybe.just(2)
    maybe = Maybe.nothing()
    filtered = maybe.filter(lambda x: x % 2 == 0)
    assert isinstance(filtered, Maybe)
    assert filtered == Maybe.nothing()


# Generated at 2022-06-12 05:11:50.612539
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    result = Maybe.just(1).to_lazy().value()
    assert result == 1

    result = Maybe.nothing().to_lazy().value()
    assert result is None

    result = Maybe(Try(1), False).to_lazy().value()
    assert result == 1

    result = Maybe(Try(1), True).to_lazy().value()
    assert result is None

    result = Lazy(lambda: 1).to_maybe()
    assert isinstance(result, Maybe)
    assert result.value == 1

    result = Lazy(lambda: None).to_maybe()
    assert result.is_nothing == True

# Generated at 2022-06-12 05:11:57.670394
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def return_true():
        return True

    assert Maybe.just(3).filter(return_true) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x == 5) == Maybe.nothing()
    assert Maybe.nothing().filter(return_true) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 3) == Maybe.nothing()

# Generated at 2022-06-12 05:12:01.834971
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda value: value == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda value: value == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:06.958124
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

# Generated at 2022-06-12 05:12:18.288844
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe_just_one = Maybe.just(1)
    maybe_nothing = Maybe.nothing()

    # When and Then
    assert maybe_just_one.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_just_one.filter(lambda x: x % 2 == 1) == Maybe.just(1)
    assert maybe_nothing.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_nothing.filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:26.379169
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test with number
    assert Maybe.just(5).filter(lambda x: x > 0) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 0) == Maybe.nothing()

    # Test with object
    class UserTest:
        def __init__(self, name: str) -> None:
            self.name = name

        def __eq__(self, other: object) -> bool:
            return isinstance(other, UserTest) and self.name == other.name

    user = UserTest('Alex')
    assert Maybe.just(user).filter(lambda user: user.name) == Maybe.just(user)

    user = UserTest('')
    assert Maybe.just(user).filter(lambda user: user.name) == Maybe.nothing()

    assert Maybe.just(user).filter

# Generated at 2022-06-12 05:12:31.715729
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()

# Generated at 2022-06-12 05:12:36.784107
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('foo') == Maybe.just('foo')
    assert Maybe.just('foo') != Maybe.just('bar')
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just('')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:12:40.866043
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x < 15) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x > 15) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 15) == Maybe.nothing()


# Generated at 2022-06-12 05:12:47.116055
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert_that(Maybe.just(1) == Maybe.just(1), equal_to(True))
    assert_that(Maybe.just(1) == Maybe.just(2), equal_to(False))
    assert_that(Maybe.nothing() == Maybe.nothing(), equal_to(True))
    assert_that(Maybe.nothing() == Maybe.just(2), equal_to(False))



# Generated at 2022-06-12 05:12:49.638275
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:57.181400
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just(2) == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(2)
    assert not Maybe.just(2) == Maybe.just(3)
    assert not Maybe.just(2) == 3
    assert not Maybe.just(2) == None
    assert not Maybe.nothing() == None


# Generated at 2022-06-12 05:13:00.535891
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(1) == Maybe.just(1)) == True
    assert(Maybe.nothing() == Maybe.nothing()) == True
    assert(Maybe.just(1) == Maybe.nothing()) == False


# Generated at 2022-06-12 05:13:01.804284
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)



# Generated at 2022-06-12 05:13:08.812740
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:13:14.871116
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:13:19.230979
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()


# Generated at 2022-06-12 05:13:24.130949
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:13:27.612736
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.just(123) != Maybe.just(456)
    assert Maybe.just(123) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:32.585866
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:13:35.740196
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()


# Generated at 2022-06-12 05:13:45.997905
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.exceptions import Failure
    from pymonet.functools import compose

    print('Test method filter of class Maybe:')

    def is_odd(value):
        return value % 2 == 1

    @compose(is_odd, lambda value: value.value)
    def is_odd_and_value_is_even(maybe):
        return maybe

    @compose(is_odd, lambda value: value.value)
    def is_odd_and_value_is_odd(maybe):
        return maybe

    def test_case(expected_result, maybe, filterer) -> None:
        print('\tTest case:')
        print('\t\tInput values: maybe = ', maybe, ', filterer = ', filterer)

# Generated at 2022-06-12 05:13:54.117191
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result_with_false = Maybe.just(1).filter(lambda x: False)
    result_with_true = Maybe.just(2).filter(lambda x: True)
    result_maybe_nothing = Maybe.nothing().filter(lambda x: True)
    result_maybe_nothing2 = Maybe.nothing().filter(lambda x: False)
    assert result_maybe_nothing == Maybe.nothing()
    assert result_maybe_nothing2 == Maybe.nothing()
    assert result_with_false == Maybe.nothing()
    assert result_with_true == Maybe.just(2)

# Generated at 2022-06-12 05:14:03.061396
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    class TestException(Exception):
        pass

    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)

    try:
        Maybe.nothing().filter(lambda x: x % 2 == 0).get_or_else(None)
        raise TestException
    except TestException:
        assert False
    else:
        assert True



# Generated at 2022-06-12 05:14:18.743420
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test for empty Maybe
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe[int](None, True)
    assert Maybe.nothing() != Maybe[int](None, False)
    assert Maybe.nothing() != Maybe.just(1)
    # Test for not empty Maybe
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe[int](1, False)
    assert Maybe.just(1) != Maybe[int](1, True)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:14:26.248541
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x < 3) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()



# Generated at 2022-06-12 05:14:31.890906
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Arrange
    maybe_one = Maybe.just('value')
    maybe_two = Maybe.just('value')
    maybe_three = Maybe.nothing()
    maybe_four = Maybe.nothing()

    # Assert
    assert maybe_one == maybe_two
    assert maybe_three == maybe_four
    assert maybe_one != maybe_three
    assert maybe_two != maybe_three
    assert maybe_one != maybe_four
    assert maybe_two != maybe_four


# Generated at 2022-06-12 05:14:35.904961
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:39.270299
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe(10, False)
    assert Maybe("abc", False) == Maybe("abc", False)
    assert Maybe("abc", True) == Maybe("abc", True)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe("abc", False) != Maybe("cba", False)
    assert Maybe("abc", False) != Maybe("abc", True)
    assert Maybe("abc", True) != Maybe("cba", True)


# Generated at 2022-06-12 05:14:43.512388
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:14:52.178666
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet import Maybe

    Maybe.just(5).__eq__(Maybe.just(5)) == True
    Maybe.just(5).__eq__(Maybe.maybe(5)) == True
    Maybe.just(5).__eq__(Maybe.just(10)) == False
    Maybe.nothing().__eq__(Maybe.nothing()) == True
    Maybe.nothing().__eq__(Maybe.just(None)) == False
    Maybe.nothing().__eq__(Maybe.just(5)) == False

test_Maybe___eq__()


# Generated at 2022-06-12 05:14:57.741933
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad import Monad
    from pymonet.functor import Functor

    assert Functor.laws(lambda x: Maybe.just(x), lambda x: x + 1, lambda x: x + 2)(Monad.laws)


if __name__ == "__main__":
    test_Maybe_filter()

# Generated at 2022-06-12 05:14:59.669721
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    actual = Maybe.just(1).to_lazy()
    expected = Lazy(lambda: 1)

    assert actual == expected


# Generated at 2022-06-12 05:15:06.332543
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)


# Generated at 2022-06-12 05:15:30.612615
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x > 0) == Maybe.just(2)
    assert Maybe(2, False).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:15:33.895575
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def even(x):
        return x % 2 == 0

    assert Maybe.just(4).filter(even) == Maybe.just(4)
    assert Maybe.just(3).filter(even) == Maybe.nothing()


# Generated at 2022-06-12 05:15:37.546925
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:42.725650
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:15:48.929505
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_a = Maybe.just(123)
    maybe_b = Maybe.just(123)
    maybe_c = Maybe.just(321)
    maybe_d = Maybe.just(321)
    maybe_e = Maybe.nothing()
    maybe_f = Maybe.nothing()

    assert maybe_a == maybe_b
    assert maybe_c == maybe_d
    assert maybe_e == maybe_f


# Generated at 2022-06-12 05:15:50.837298
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    See tests.py
    """
    from tests import test_Maybe_filter
    test_Maybe_filter(Maybe)



# Generated at 2022-06-12 05:15:58.285593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    nothing = Maybe.filter(
        Maybe.just(4),
        lambda x: (x == 4)
    )
    assert nothing == Maybe.just(4)

    something = Maybe.filter(
        Maybe.just(4),
        lambda x: (x == 3)
    )
    assert something == Maybe.nothing()

    something = Maybe.filter(
        Maybe.nothing(),
        lambda x: (x == 3)
    )
    assert something == Maybe.nothing()

if __name__ == '__main__':
    test_Maybe_filter()

# Generated at 2022-06-12 05:16:04.431694
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(10)
    m2 = Maybe.just(20)
    m3 = Maybe.just(10)
    m4 = Maybe.nothing()

    assert m1 == m3
    assert m1 != m2
    assert m4 != m3
    assert isinstance(m1, Maybe) and isinstance(m2, Maybe) and isinstance(m3, Maybe)
    assert isinstance(m4, Maybe)



# Generated at 2022-06-12 05:16:08.113210
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(None) == Maybe.nothing()



# Generated at 2022-06-12 05:16:13.502108
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # For not None
    actual = Maybe.just(1).to_lazy()
    expected = Lazy(lambda: 1)
    assert actual == expected

    # For None
    actual = Maybe.nothing().to_lazy()
    expected = Lazy(lambda: None)
    assert actual == expected


# Generated at 2022-06-12 05:17:02.667758
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # Given
    def filterer(value): return value is not None

    # When
    res1 = Maybe.nothing().filter(
        filterer=filterer
    )

    res2 = Maybe.just(
        value=None
    ).filter(
        filterer=filterer
    )

    res3 = Maybe.just(
        value=1
    ).filter(
        filterer=filterer
    )

    # Then
    assert res1.value is None, \
        'Should be true when filter returns False and Maybe is empty'
    assert res2.value is None, \
        'Should be true when filter returns False and Maybe is not empty'
    assert res3.value == 1, \
        'Should be true when filter returns True and Maybe is not empty'



# Generated at 2022-06-12 05:17:07.764286
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = "value"
    result = Maybe.just(value).to_lazy()
    assert isinstance(result, Lazy)
    assert result.call() == value
    assert Maybe.nothing().to_lazy().call() is None


# Generated at 2022-06-12 05:17:14.746281
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter.

    :returns: None
    """
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:17:20.013602
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    val = Maybe.just(1).filter(lambda x: x == 1)
    assert val == Maybe.just(1)

    val = Maybe.just(1).filter(lambda x: x != 1)
    assert val == Maybe.nothing()

    val = Maybe.nothing().filter(lambda x: x == 1)
    assert val == Maybe.nothing()

# Generated at 2022-06-12 05:17:25.308079
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 123
    maybe = Maybe.just(value)

    assert maybe == maybe
    assert Maybe.nothing() == Maybe.nothing()

    maybe_copy = Maybe.just(value)

    assert maybe == maybe_copy
    assert maybe_copy == maybe



# Generated at 2022-06-12 05:17:27.207176
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:17:30.540163
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)



# Generated at 2022-06-12 05:17:35.728392
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test Maybe.filter.

    :returns: True if test passed, throws error if test didn't pass
    :rtype: Boolean
    """
    assert Maybe.just(10).filter(
        lambda x: x == 10
    ) == Maybe.just(10)
    assert Maybe.just(10).filter(
        lambda x: x == 20
    ) == Maybe.nothing()
    assert Maybe.nothing().filter(
        lambda x: x
    ) == Maybe.nothing()


# Generated at 2022-06-12 05:17:41.087203
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.just(10) == Maybe.just(10)) == True
    assert (Maybe.just(10) == Maybe.nothing()) == False
    assert (Maybe.nothing() == Maybe.nothing()) == True
    assert (Maybe.nothing() == Maybe.just(10)) == False


# Generated at 2022-06-12 05:17:45.785806
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(1)
    nothing = Maybe.nothing()

    assert maybe == maybe, 'Maybe(1) == Maybe(1)'
    assert not nothing == maybe, 'Maybe(None) != Maybe(1)'
    assert nothing == nothing, 'Maybe(None) == Maybe(None)'


# Generated at 2022-06-12 05:19:11.666055
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # if when filterer returns True return copy of value
    assert Maybe.just(2).filter(lambda x: x > 0) == Maybe.just(2)
    # if when filterer returns True return copy of value
    assert Maybe.just(2).filter(lambda x: x > 10) == Maybe.nothing()
    # if Maybe is empty return empty Maybe
    assert Maybe.nothing().filter(lambda x: 10) == Maybe.nothing()


# Generated at 2022-06-12 05:19:14.889422
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:19:18.192352
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(6) != Maybe.just(5)
    assert Maybe.just(5) != Maybe.nothing()


# Generated at 2022-06-12 05:19:25.867821
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe(1, True)



# Generated at 2022-06-12 05:19:30.222575
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:19:34.918175
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def some_func():
        return 2 + 2

    assert Lazy(some_func) == Maybe.just(2 + 2).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-12 05:19:37.924708
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:19:41.961590
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()

# Generated at 2022-06-12 05:19:48.294931
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(4) != Maybe.just(3)
    assert Maybe.nothing() != Maybe.just(3)


# Generated at 2022-06-12 05:19:49.712817
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Test with empty Maybe
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    # Test with not empty Maybe
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)