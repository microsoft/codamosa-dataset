

# Generated at 2022-06-12 05:11:06.587684
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just('Test')
    expected = Lazy(lambda: 'Test')
    actual = maybe.to_lazy()
    assert expected == actual

    maybe = Maybe.nothing()
    expected = Lazy(lambda: None)
    actual = maybe.to_lazy()
    assert expected == actual
    

# Generated at 2022-06-12 05:11:09.932871
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def even(x: int) -> bool:
        return x % 2 == 0

    assert Maybe.just(2).filter(even) == Maybe.just(2)
    assert Maybe.just(1).filter(even) == Maybe.nothing()
    assert Maybe.nothing().filter(even) == Maybe.nothing()



# Generated at 2022-06-12 05:11:15.102520
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.unittest.monad_test import (
        method_test,
        method_test_with_cases,
    )

    cases = [
        (
            "test_Maybe_filter",
            (
                lambda: Maybe.just(2),
                (lambda x: x == 3, ),
                (lambda x: x == 2, ),
            ),
            (Maybe.nothing(), Maybe.just(2)),
        ),
    ]
    method_test_with_cases(cases, Maybe.filter)
    method_test(Maybe.just, Maybe.nothing(), Maybe.just(2), Maybe.filter, (lambda x: x == 2, ), (lambda x: x == 3, ), None)


# Generated at 2022-06-12 05:11:20.348774
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.just(5).to_lazy().force() == 5
    assert Maybe.just(True).to_lazy().force()


# Generated at 2022-06-12 05:11:23.606476
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:11:29.678905
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(x):
        return x % 2 == 0

    assert Maybe(2, False).filter(filterer) == Maybe(2, False)
    assert Maybe(1, False).filter(filterer) == Maybe(1, False).bind(lambda x: Maybe.nothing())



# Generated at 2022-06-12 05:11:34.301486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:11:39.106777
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe('test', False) == Maybe('test', False)
    assert Maybe(None, True) != Maybe('test', False)
    assert Maybe('test', False) != Maybe(None, True)
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, False) != Maybe(None, True)


# Generated at 2022-06-12 05:11:45.852354
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    maybe_1_copy = Maybe.just(1)

    assert maybe_1 == maybe_1_copy
    assert maybe_1 != maybe_2
    assert maybe_1 != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:11:55.500711
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)

# Generated at 2022-06-12 05:12:03.005293
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Maybe A, is empty
    assert Maybe.nothing() == Maybe.nothing()

    # Maybe A, is not empty
    assert Maybe.just(1) == Maybe.just(1) and \
           Maybe.just(1) != Maybe.just(2) and \
           Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:12:09.881472
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_func = lambda a: a > 100
    maybe_empty = Maybe.just(None)
    maybe_value = Maybe.just(365)
    maybe_false = Maybe.just(-1)
    assert maybe_empty.filter(test_func) == Maybe.nothing()
    assert maybe_value.filter(test_func) == Maybe.just(365)
    assert maybe_false.filter(test_func) == Maybe.nothing()

# Generated at 2022-06-12 05:12:22.413286
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
        1. Create Maybe[1].
        2. Create Maybe[2].
        3. Create Maybe[1].
        4. Create Maybe[None].
        5. Create Maybe[None].
        6. Assert Maybe[1] is not equal to Maybe[2].
        7. Assert Maybe[1] is equal to Maybe[1].
        8. Assert Maybe[None] is equal to Maybe[None].
    :return:
    """

    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    maybe_1_2 = Maybe.just(1)
    maybe_none = Maybe.nothing()
    maybe_none_2 = Maybe.nothing()
    assert maybe_1 != maybe_2
    assert maybe_1 == maybe_1_2
    assert maybe_none == maybe_none

# Generated at 2022-06-12 05:12:28.214901
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(20, False) == Maybe(20, False)
    assert Maybe.just(20) == Maybe.just(20)
    assert Maybe.just(20) != Maybe.just(30)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(20) != Maybe.nothing()

# Unit tests for method map of class Maybe

# Generated at 2022-06-12 05:12:34.092115
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy_value = Maybe.just(1).to_lazy()
    assert lazy_value.__class__.__name__ == 'Lazy'
    assert lazy_value.value() == 1
    lazy_value = Maybe.nothing().to_lazy()
    assert lazy_value.__class__.__name__ == 'Lazy'
    assert lazy_value.value() is None



# Generated at 2022-06-12 05:12:37.943148
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just('5')
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:42.738800
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.nothing() != Maybe.just(42)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-12 05:12:47.267763
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:12:53.390722
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(100)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)


# Unit tests for method just

# Generated at 2022-06-12 05:12:56.544133
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()



# Generated at 2022-06-12 05:13:03.841642
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:13:08.285482
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(3).to_lazy(
    ) == Lazy(lambda: 3)

    assert Maybe.nothing().to_lazy(
    ) == Lazy(lambda: None)


# Generated at 2022-06-12 05:13:11.555530
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_example():
        return "lazy"

    example = Maybe.just(lazy_example).to_lazy()
    assert isinstance(example, Lazy) and example.value()() == "lazy"


# Generated at 2022-06-12 05:13:15.992217
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:22.886943
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Failure, Success

    assert Failure(Exception("exception")) != Success(1)
    assert Failure(Exception("exception")) == Failure(Exception("exception"))
    assert Success("test") == Success("test")
    assert Success("test") != Success("test2")
    assert Success(1) != Success("test2")
    assert Success(1) != Success("1")
    assert Success("test") != Success("Test")


# Generated at 2022-06-12 05:13:25.830016
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:13:29.734659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not (Maybe.just(1) == Maybe.just(2))
    assert Maybe.nothing() == Maybe.nothing()
    assert not (Maybe.nothing() == Maybe.just(1))
    assert not (Maybe.just(1) == Maybe.nothing())


# Generated at 2022-06-12 05:13:38.437240
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    just = Maybe.just(1)
    nothing = Maybe.nothing()
    int_filterer = lambda x: x == 1
    nothing_filterer = lambda x: x == None
    expected_just = Maybe.just(1)
    expected_nothing = Maybe.nothing()

    actual_just = just.filter(int_filterer)
    actual_nothing = nothing.filter(int_filterer)

    assert actual_just == expected_just
    assert actual_nothing == expected_nothing

# Generated at 2022-06-12 05:13:46.039253
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('') == Maybe.just('')
    assert Maybe.just('') == Maybe.just('')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:13:51.336432
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(10, False).filter(lambda x: x % 2 == 0).value == 10
    assert Maybe(9, False).filter(lambda x: x % 2 == 0).is_nothing == True
    assert Maybe(10, True).filter(lambda x: x % 2 == 0).is_nothing == True


# Generated at 2022-06-12 05:13:58.877148
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)



# Generated at 2022-06-12 05:14:02.353443
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: True) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-12 05:14:13.957144
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    maybe_foo = Maybe.just(1)
    maybe_bar = Maybe.just(1)
    maybe_baz = Maybe.just(2)
    maybe_spam = Maybe.nothing()
    maybe_ham = Maybe.nothing()

    # When
    foo_eq_foo = maybe_foo == maybe_bar
    foo_eq_baz = maybe_foo == maybe_baz
    foo_eq_spam = maybe_foo == maybe_spam
    spam_eq_spam = maybe_spam == maybe_ham
    equal_dict = maybe_foo == {'value': 1, 'is_nothing': False}
    equal_other = maybe_foo == Maybe

    # Then
    assert foo_eq_foo == True
    assert foo_eq_baz == False
    assert foo_eq_spam

# Generated at 2022-06-12 05:14:21.908764
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just('') == Maybe.just('')
    assert Maybe.just('1') != Maybe.just('')
    assert Maybe.just([]) != Maybe.just([1])
    assert Maybe.just({}) == Maybe.just({})
    assert Maybe.just(None) == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:14:28.086379
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 'some value'
    maybe1 = Maybe.just(value)
    maybe2 = Maybe.just(value)
    maybe3 = Maybe.just(value)
    assert maybe1 == maybe2
    assert maybe2 == maybe1
    assert maybe2 == maybe3
    assert maybe1 == maybe3
    assert Maybe.nothing() == Maybe.nothing()
    assert maybe1 != Maybe.nothing()
    assert maybe1 != Maybe.nothing()


# Generated at 2022-06-12 05:14:32.928626
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(10)



# Generated at 2022-06-12 05:14:37.515208
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-12 05:14:43.124350
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(2) == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:14:50.480863
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(7)
    assert Maybe.just(7) != Maybe.just(5)
    assert Maybe.just(7) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(7)



# Generated at 2022-06-12 05:14:57.157989
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy

    from pymonet.util_monad import Just

    assert Lazy(lambda: 10) == Just(10).to_lazy()
    assert Lazy(lambda: None) == Just(None).to_lazy()
    assert Lazy(lambda: 10) == Just(10).to_maybe().to_lazy()
    assert Lazy(lambda: None) == Nothing().to_lazy()


# Generated at 2022-06-12 05:15:08.052645
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe(1, False)
    maybe_2 = Maybe(1, False)
    maybe_3 = Maybe(2, False)
    none_1 = Maybe.nothing()
    none_2 = Maybe.nothing()
    assert maybe_1 == maybe_2
    assert maybe_1 != maybe_3
    assert none_1 == none_2
    assert none_1 != maybe_1
    assert None != maybe_1

# Unit test method to_box

# Generated at 2022-06-12 05:15:17.063767
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe(5, False) == Maybe.just(5)
    assert Maybe(5, False) != Maybe(42, True)
    assert Maybe(5, False) != Maybe.just(42)
    assert Maybe(5, False) != Maybe(42, False)
    assert Maybe(5, True) != Maybe(42, False)


# Generated at 2022-06-12 05:15:21.394995
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    JustInt = Maybe.just(10)
    JustBool = Maybe.just(True)
    Nothing = Maybe.nothing()

    assert JustInt == JustInt
    assert JustBool == JustBool
    assert Nothing == Nothing
    assert JustInt != JustBool
    assert JustBool != Nothing
    assert JustInt != Nothing
    assert JustInt != 10
    assert JustInt != None
    assert Nothing != 10
    assert Nothing == None



# Generated at 2022-06-12 05:15:32.994636
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad import Monad
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    # Create instances of Maybe
    m1 = Maybe.nothing()
    m2 = Maybe.nothing()
    m3 = Maybe(1, False)
    m4 = Maybe(2, False)

    # Test instances of Maybe with instances of Functor and Applicative
    assert isinstance(m1, Monad)
    assert isinstance(m2, Monad)
    assert isinstance(m3, Monad)
    assert isinstance(m4, Monad)
    assert isinstance(m1, Functor)
    assert isinstance(m2, Functor)
    assert isinstance(m3, Functor)
    assert isinstance(m4, Functor)
    assert isinstance

# Generated at 2022-06-12 05:15:39.089763
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_one = Maybe.nothing()
    maybe_two = Maybe.just(1)
    maybe_three = Maybe.just(2)

    assert maybe_one == Maybe.nothing()
    assert maybe_two == Maybe.just(1)
    assert maybe_three == Maybe.just(2)
    assert maybe_three != Maybe.just(1)
    assert maybe_one != maybe_three


# Generated at 2022-06-12 05:15:47.044683
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    # Test case where Maybe is empty
    assert Maybe.just(None).to_lazy == Lazy(lambda: None)

    # Test case where Maybe is not empty
    print(Maybe.just(None).to_lazy.value)
    assert Maybe.just(None).to_lazy.value() == None



# Generated at 2022-06-12 05:15:53.187817
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(12).filter(lambda v: v % 2 == 0) == Maybe.just(12)
    assert Maybe.just(13).filter(lambda v: v % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:15:57.662292
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != 'test'


# Generated at 2022-06-12 05:16:05.193656
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Assert filter method of Maybe class returns new instance of Maybe with the same value when filter return True
    and empty Maybe when filter return False
    """
    maybe_ = Maybe.just(10)
    assert maybe_.filter(lambda x: x == 10) == Maybe.just(10)
    assert maybe_.filter(lambda x: x == 15) != Maybe.just(10)

    maybe_ = Maybe.nothing()
    assert maybe_.filter(lambda x: x == 10) == Maybe.nothing()
    assert maybe_.filter(lambda x: x == 15) == Maybe.nothing()


# Generated at 2022-06-12 05:16:08.250017
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 5) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x < 5) == Maybe.nothing()

# Generated at 2022-06-12 05:16:16.686807
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert isinstance(Box(1).to_maybe().to_lazy(), Lazy)

# Generated at 2022-06-12 05:16:24.722203
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(42) == Maybe.just(42))
    assert(Maybe.just(42) != Maybe.just(43))
    assert(Maybe.nothing() == Maybe.nothing())
    assert(Maybe.nothing() != Maybe.just(42))
    assert(Maybe.just(42) != 'fake_maybe')
    assert(Maybe.just(42) != 'fake_maybe')
    assert(Maybe.just(42) != 'fake_maybe')
    assert(Maybe.just(42) != 'fake_maybe')


# Generated at 2022-06-12 05:16:29.920722
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:16:33.226591
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:16:39.420530
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(12)
    b = Maybe.just(12)
    assert a == b

    c = Maybe.nothing()
    d = Maybe.nothing()
    assert c == d

    e = Maybe.just(12)
    f = Maybe.nothing()
    assert not e == f



# Generated at 2022-06-12 05:16:45.912948
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just("str") != Maybe.just("str1")
    assert Maybe.just("str") == Maybe.just("str")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)


# Generated at 2022-06-12 05:16:49.358877
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:16:59.964896
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    nothing_left = Maybe.nothing()
    nothing_right = Maybe.nothing()
    just_left = Maybe.just(2)
    just_right = Maybe.just(2)
    not_just_left = Maybe.just(1)
    not_just_right = Maybe.just(4)

    assert nothing_left == nothing_right
    assert just_left == just_right
    assert not nothing_left == just_left and not nothing_right == just_right
    assert not just_left == not_just_left and not just_right == not_just_right
    assert not nothing_left == not_just_left and not nothing_right == not_just_right



# Generated at 2022-06-12 05:17:01.853196
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:17:09.183723
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda val: val == 1) == Maybe.just(1)

    assert Maybe.just('1').filter(lambda val: val == 1) == Maybe.nothing()

    assert Maybe.just('1').filter(lambda val: val == '1') == Maybe.just('1')

    assert Maybe.nothing().filter(lambda val: val == 1) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda val: val == '1') == Maybe.nothing()


# Generated at 2022-06-12 05:17:20.873173
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('test_Maybe___eq__')
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.just(123) != Maybe.just(456)
    assert Maybe.just(123) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(123)

    print('test_Maybe___eq__ finished successfully')


# Generated at 2022-06-12 05:17:29.618923
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    print("Test for filter function of Maybe monad")
    print("If Maybe is empty return new empty Maybe")
    assert Maybe.nothing().filter(
        lambda _: True
    ) == Maybe.nothing()
    print("If Maybe is not empty and filterer returns True, return copy of self")
    assert Maybe.just(2).filter(
        lambda x: x == 2
    ) == Maybe.just(2)
    print("If Maybe is not empty and filterer returns False, return new empty Maybe")
    assert Maybe(2, False).filter(
        lambda x: x == 1
    ) == Maybe.nothing()

# Generated at 2022-06-12 05:17:34.133908
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    :returns: True if test is passed and False otherwise
    :rtype: Boolean
    """
    return Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1) and \
        Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:17:39.195550
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just(1) != Maybe.just("a")
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:17:45.044243
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(10).filter(lambda x: x>10)
    assert maybe == Maybe.nothing()

    maybe = Maybe.just(10).filter(lambda x: x<10)
    assert maybe == Maybe.just(10)

    maybe = Maybe.nothing().filter(lambda _x: False)
    assert maybe == Maybe.nothing()

if __name__ == "__main__":
    test_Maybe_filter()

# Generated at 2022-06-12 05:17:50.059605
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe(1, False) == Maybe(1, False)) == True
    assert (Maybe(1, True) == Maybe(1, True)) == True
    assert (Maybe(1, True) == Maybe(2, True)) == True
    assert (Maybe(1, False) == Maybe(2, False)) == False
    assert (Maybe(1, False) == Maybe(1, True)) == False
    assert (Maybe(1, True) == Maybe(2, False)) == False



# Generated at 2022-06-12 05:17:53.355130
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:17:55.825794
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    maybe = Maybe(2, False)
    filterer = lambda x: x > 2

    # act
    result = maybe.filter(filterer)

    # assert
    assert result == Maybe.nothing()

# Generated at 2022-06-12 05:18:00.409532
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-12 05:18:03.741506
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    x = Maybe.just(42)
    assert Maybe.just(42) == x.filter(lambda x: x % 42 == 0)
    assert Maybe.nothing() == x.filter(lambda x: x % 43 == 0)



# Generated at 2022-06-12 05:18:16.821481
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)


# Generated at 2022-06-12 05:18:20.232678
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1) == Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-12 05:18:29.657609
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 2) != Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) != Maybe.just(2)
    assert Maybe.just(1).filter(lambda x: x == 2) != Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-12 05:18:32.676317
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:18:36.607805
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, False) == Maybe(None, False)
    assert Maybe(None, False) == Maybe(None, False)
    assert Maybe(None, False) != Maybe(None, True)


# Generated at 2022-06-12 05:18:47.788085
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test case 1: Given empty Maybe instance, when filter with any function, then empty Maybe
    maybe_instance = Maybe.nothing()
    assert maybe_instance.filter(lambda _: True) == Maybe.nothing()

    # Test case 2: Given empty Maybe instance, when filter with any function, then empty Maybe
    maybe_instance = Maybe.nothing()
    assert maybe_instance.filter(lambda _: False) == Maybe.nothing()

    # Test case 3: Given not empty Maybe instance, when filterer returns True, then copy of self
    maybe_instance = Maybe.just(5)
    assert maybe_instance.filter(lambda _: True) == maybe_instance

    # Test case 4: Given not empty Maybe instance, when filterer returns False, then empty Maybe
    maybe_instance = Maybe.just(5)

# Generated at 2022-06-12 05:18:53.889679
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual = Maybe.just(1).filter(lambda x: x > 0)
    expected = Maybe.just(1)
    assert actual == expected
    actual = Maybe.just(1).filter(lambda x: x == 2)
    expected = Maybe.nothing()
    assert actual == expected
    actual = Maybe.nothing().filter(lambda x: True)
    expected = Maybe.nothing()
    assert actual == expected


# Generated at 2022-06-12 05:18:55.101173
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)


# Generated at 2022-06-12 05:18:58.500540
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:19:01.830471
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(2)
    other = Maybe.just(2)
    assert maybe == other
    other = Maybe.just(1)
    assert maybe != other
    other = Maybe.nothing()
    assert maybe != other

# Generated at 2022-06-12 05:19:18.337864
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1).__eq__(Maybe.just(2)) is False
    assert Maybe.just(1).__eq__(1) is False
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing().__eq__(Maybe.just(1)) is False


# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:19:29.659021
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    assert Maybe.just(42).to_lazy() == Try.just(42).to_lazy()
    assert Maybe.nothing().to_lazy() == Try.nothing().to_lazy()

    assert Maybe.just(42).to_lazy() == Box.just(42).to_lazy()
    assert Maybe.nothing().to_lazy() == Box.nothing().to_lazy()


# Generated at 2022-06-12 05:19:36.605696
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    def some_func():
        return 2 + 2

    def some_func_error():
        raise ValueError('Error!')

    x = Lazy(some_func)
    y = Maybe.just(x)
    z = Maybe.nothing()

    assert y.to_lazy().fetch() == x.fetch()
    assert z.to_lazy().fetch() is None



# Generated at 2022-06-12 05:19:40.030531
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.just(20) == Maybe.just(20)) is True
    assert (Maybe.just(20) == 20) is False

    assert (Maybe.nothing() == 20) is False

    assert (Maybe.nothing() == Maybe.nothing()) is True
    assert (Maybe.nothing() == Maybe.just(20)) is False


# Generated at 2022-06-12 05:19:43.411194
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert (Maybe.just(5) == Maybe.just(6)) == False

    assert Maybe.nothing() == Maybe.nothing()
    assert (Maybe.nothing() == Maybe.just(5)) == False


# Generated at 2022-06-12 05:19:50.780270
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    box1 = Maybe.just(1)
    box2 = Maybe.just(2)
    box3 = Maybe.just(1)
    box4 = Maybe.nothing()
    box5 = Maybe.nothing()

    assert box1 == box3
    assert box4 == box5
    assert box1 != box2
    assert box1 != box4
    assert box2 != box4



# Generated at 2022-06-12 05:19:56.735710
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    func = lambda x: x < 10
    assert Maybe.just(1).filter(func).get_or_else(None) == 1
    assert Maybe.just(10).filter(func).get_or_else(None) is None
    assert Maybe.nothing().filter(func).get_or_else(None) is None


# Generated at 2022-06-12 05:19:59.674535
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert None == Maybe.nothing()
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(4)


# Generated at 2022-06-12 05:20:03.385416
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    A = Maybe.just(3)
    B = Maybe.just(3)
    C = Maybe.just(2)
    X = Maybe.nothing()
    Y = Maybe.nothing()

    assert A == B
    assert not (A == C)
    assert X == Y


# Generated at 2022-06-12 05:20:08.911113
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try

    success_try = Try.unit(1)
    success_maybe = Maybe.just(1)
    failure_try = Try.failure(1)
    failure_maybe = Maybe.nothing()

    assert success_maybe == success_maybe
    assert not success_maybe == failure_maybe
    assert success_try == success_maybe
    assert not failure_try == failure_maybe

# Generated at 2022-06-12 05:20:25.145093
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Test method __eq__ of class Maybe.

    :returns: Nothing
    :rtype: None
    """

    print("=== test_Maybe___eq__ ===")

    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(43) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

    print("=== Done ===")


# Generated at 2022-06-12 05:20:29.187018
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)
    assert Maybe('a', False).to_lazy() == Lazy(lambda: 'a')



# Generated at 2022-06-12 05:20:30.258368
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:20:34.154026
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    four = Maybe.just(4)
    nothing = Maybe.nothing()

    assert four.to_lazy() == Lazy(lambda: 4)
    assert nothing.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:36.637271
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(6) == Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(6) != Maybe.nothing()



# Generated at 2022-06-12 05:20:42.375157
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not (Maybe.just(1) == Maybe.just(2))
    assert Maybe.nothing() == Maybe.nothing()
    assert not (Maybe.nothing() == Maybe.just(1))



# Generated at 2022-06-12 05:20:46.925725
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(2).filter(lambda value: value == 2) == Maybe.just(2))
    assert(Maybe.just(2).filter(lambda value: value == 5) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda value: value == 2) == Maybe.nothing())



# Generated at 2022-06-12 05:20:49.807964
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(None) == Maybe.nothing()

# Generated at 2022-06-12 05:20:53.897042
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda value: value == 1).is_nothing == False
    assert Maybe.just(1).filter(lambda value: value == 2).is_nothing == True
    assert Maybe.nothing().filter(lambda value: value == 1).is_nothing == True

# Generated at 2022-06-12 05:21:00.922189
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just('')
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just('') != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(1.1)
    assert Maybe.just(1) == Maybe.just(1)

