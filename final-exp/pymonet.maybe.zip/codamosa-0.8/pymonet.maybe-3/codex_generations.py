

# Generated at 2022-06-12 05:11:10.999085
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-12 05:11:16.780388
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.nothing()


# Generated at 2022-06-12 05:11:20.012238
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:11:23.488678
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:11:29.680824
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("1").filter(lambda x: x == "1") == Maybe.just("1")
    assert Maybe.just("1").filter(lambda x: x == "2") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == "1") == Maybe.nothing()



# Generated at 2022-06-12 05:11:33.524884
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda a: a < 5) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda a: a >= 5) == Maybe.just(10)



# Generated at 2022-06-12 05:11:37.735221
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Arrange
    result1 = Maybe.just('test')
    result2 = Maybe.just('test')
    result3 = Maybe.just('test1')
    result4 = Maybe.nothing()

    # Assert
    assert result1 == result2
    assert result1 != result3
    assert result1 != result4


# Generated at 2022-06-12 05:11:45.690019
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Empty Maybe
    value = Maybe.nothing()
    assert value.filter(lambda a: a % 2 == 0) == value
    assert value.filter(lambda a: a % 2 != 0) == value

    # Not empty Maybe
    value = Maybe.just(2)
    assert value.filter(lambda a: a % 2 == 0) == Maybe.just(2)
    assert value.filter(lambda a: a % 2 != 0) == Maybe.nothing()



# Generated at 2022-06-12 05:11:51.889789
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    from pymonet.either import Left, Right

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(Left(1)) == Maybe.just(Left(1))
    assert Maybe.just('a') == Box('a')



# Generated at 2022-06-12 05:11:58.022088
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try

    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(3)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(None) != Try(None, True)



# Generated at 2022-06-12 05:12:04.408208
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just(1).to_lazy()
    assert lazy.eval() == Maybe.just(1).value
    lazy = Maybe.nothing().to_lazy()
    assert lazy.eval() == Maybe.nothing().value


# Generated at 2022-06-12 05:12:09.211287
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:12:15.090336
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just("") != Maybe.nothing()
    assert Maybe.just("") != Maybe("", False)


# Generated at 2022-06-12 05:12:22.411996
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), 'Test failed'
    assert Maybe.just(2) == Maybe.just(2), 'Test failed'
    assert Maybe.nothing() == Maybe.nothing(), 'Test failed'
    assert Maybe.nothing() != Maybe.just(1), 'Test failed'
    assert Maybe.just(2) != Maybe.nothing(), 'Test failed'
    assert Maybe.just(1) != Maybe.just(2), 'Test failed'



# Generated at 2022-06-12 05:12:31.167805
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_test.test_utils import eq_test

    eq_test(
        Maybe.just(5),
        Maybe.just(5),
        True,
        True
    )

    eq_test(
        Maybe.just(5),
        Maybe.just(6),
        True,
        False
    )

    eq_test(
        Maybe.nothing(),
        Maybe.nothing(),
        True,
        True
    )

    eq_test(
        Maybe.nothing(),
        Maybe.just(5),
        True,
        False
    )


# Generated at 2022-06-12 05:12:35.195780
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:12:39.146123
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:43.982142
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(124) != Maybe.just(123)
    assert Maybe.just(124) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(123)


# Generated at 2022-06-12 05:12:47.803113
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:53.951400
# Unit test for method filter of class Maybe
def test_Maybe_filter():
        assert Maybe(True, False) != Maybe.just(True)
        assert Maybe.just(True).filter(lambda x: x) == Maybe.nothing()
        assert Maybe.just(0).filter(lambda x: x) != Maybe.just(0)
        assert Maybe.just(0).filter(lambda x: x) == Maybe.nothing()
        assert Maybe.just(1).filter(lambda x: x) == Maybe.just(1)
        assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()

# Generated at 2022-06-12 05:12:59.225589
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get_or_else(0) == 1
    assert Maybe.nothing().to_lazy().get_or_else(0) == 0


# Generated at 2022-06-12 05:13:04.412822
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    result = Maybe.just(1).to_lazy()
    assert result.value() == 1
    assert not result.is_none()
    assert result.is_some()

    result = Maybe.nothing().to_lazy()
    assert result.value() == None
    assert result.is_none()
    assert not result.is_some()


# Generated at 2022-06-12 05:13:13.415959
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (
        Maybe(1, False) == Maybe(1, False)
    ) == True, 'Maybe should be equal when has the same value and is not empty'

    assert (
        Maybe(1, False) == Maybe(1, True)
    ) == False, 'Maybe should not be equal if one of then is empty'

    assert (
        Maybe(1, True) == Maybe(1, False)
    ) == False, 'Maybe should not be equal if one of then is empty'

    assert (
        Maybe(1, False) == Maybe(2, False)
    ) == False, 'Maybe should not be equal if values is not the same'

    assert (
        Maybe(1, True) == Maybe(2, True)
    ) == True, 'Maybe should be equal if both of then is empty'

# Generated at 2022-06-12 05:13:17.341035
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.
    """

    result = Maybe.just(1) == Maybe.just(1)

    assert result is True

    result = Maybe.just(1) == Maybe.just(2)

    assert result is False

    result = Maybe.nothing() == Maybe.nothing()

    assert result is True

    result = Maybe.nothing() == Maybe.just(1)

    assert result is False



# Generated at 2022-06-12 05:13:22.540727
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """Unit test for method filter of class Maybe."""
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:13:28.406201
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from .monad_try import Try

    def foo_function():
        def bar_function():
            def baz_function():
                return 1

            return Try.success(baz_function())

        return bar_function()

    def foo_function_2():
        return 2

    monad = foo_function()
    assert monad.map(lambda x: x()).to_lazy().strict() == foo_function_2()



# Generated at 2022-06-12 05:13:33.138713
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:35.794144
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: Maybe.just(1).get_or_else(None))



# Generated at 2022-06-12 05:13:37.573137
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1) == Maybe.just(1).to_lazy().get()



# Generated at 2022-06-12 05:13:41.668077
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x > 3) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x > 3) == Maybe.nothing()



# Generated at 2022-06-12 05:13:52.915793
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(2, True) != Maybe(2, False)

    assert Maybe(1, False) != Maybe(1, True)


# Generated at 2022-06-12 05:13:58.714874
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(3) != Maybe.nothing()


# Generated at 2022-06-12 05:14:02.591885
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_maybe import Maybe

    assert type(Maybe.just(True) == Maybe.just(True)) is bool
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.just(False)

    assert Maybe.nothing() == Maybe.nothing()

    assert not (Maybe.just(True) == Maybe.just(False))
    assert not (Maybe.just(False) == Maybe.just(True))
    assert not (Maybe.just(True) == Maybe.nothing())
    assert not (Maybe.nothing() == Maybe.just(False))


# Generated at 2022-06-12 05:14:14.401971
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe(1, False) == Maybe(2, False)) == False
    assert (Maybe(1, False) == Maybe(1, False)) == True
    assert (Maybe(1, False) == Maybe(None, True)) == False
    assert (Maybe(1, False) == Maybe(None, False)) == False
    assert (Maybe(1, False) == Maybe(1, True)) == False
    assert (Maybe(1, False) == Maybe(None, False)) == False
    assert (Maybe(1, True) == Maybe(1, True)) == True
    assert (Maybe(1, True) == Maybe(None, True)) == True
    assert (Maybe(1, True) == Maybe(None, False)) == False
    assert (Maybe(None, True) == Maybe(None, True)) == True

# Generated at 2022-06-12 05:14:18.180684
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(2)



# Generated at 2022-06-12 05:14:24.194508
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe.just(2).filter(lambda x: x == 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 5) == Maybe.nothing()



# Generated at 2022-06-12 05:14:27.892117
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:14:32.714177
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    one = Maybe.just(1)
    assert one.filter(lambda x: x == 1) == Maybe.just(1)
    assert one.filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:14:38.078518
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda v: v < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:14:43.219314
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:14:55.043113
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)



# Generated at 2022-06-12 05:15:00.396220
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test function for filter of class Maybe.
    """
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:15:08.262987
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe.just('value1')
    maybe2 = Maybe.just('value2')
    maybe3 = Maybe.just('value1')
    maybe4 = Maybe.nothing()
    maybe5 = Maybe.just(None)
    maybe6 = Maybe.nothing()

    assert maybe1 != maybe2
    assert maybe1 == maybe3
    assert maybe4 != maybe5
    assert maybe4 == maybe6

    # check for identity
    assert maybe1 is not maybe3



# Generated at 2022-06-12 05:15:19.652181
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("abc") == Maybe.just("abc")
    assert Maybe.just("abc") == Maybe("abc", False)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe("abc", False) != Maybe("def", False)
    assert Maybe("abc", False) != Maybe("abc", True)
    assert Maybe("abc", True) != Maybe("def", True)
    assert Maybe("abc", False) != "abc"
    assert Maybe("abc", True) != "abc"
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.just(123) == Maybe(123, False)
    assert Maybe.just(123) != Maybe.just(321)
    assert Maybe.just(123) != Maybe(321, False)
    assert Maybe

# Generated at 2022-06-12 05:15:31.819401
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x % 2 == 1) == Maybe.nothing()

    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x % 2 == 1) == Maybe.just(3)

    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 1) == Maybe.nothing()

    # Test for Maybe[Try]

# Generated at 2022-06-12 05:15:37.846273
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert (
        Maybe.just(1).filter(lambda x: x % 2 == 0)
        ==
        Maybe.nothing()
    )
    assert (
        Maybe.just(2).filter(lambda x: x % 2 == 0)
        ==
        Maybe.just(2)
    )
    assert (
        Maybe.nothing().filter(lambda x: True)
        ==
        Maybe.nothing()
    )


# Generated at 2022-06-12 05:15:46.569839
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda _: True) == Maybe.just(1)
    assert Maybe.just(None).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda _: True) == Maybe.just(None)


# Generated at 2022-06-12 05:15:52.158018
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    m1 = Maybe.just(3)
    assert m1.to_lazy() == Lazy(lambda: 3)
    assert m1.to_lazy().get() == Lazy(lambda: 3).get()
    m2 = Maybe.nothing()
    assert m2.to_lazy() == Lazy(lambda: None)
    assert m2.to_lazy().get() == Lazy(lambda: None).get()



# Generated at 2022-06-12 05:15:55.682004
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:15:59.822914
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:16:26.027326
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Box(1)
    assert Maybe.nothing() != Box(1)
    assert Maybe.nothing() != Box(None)



# Generated at 2022-06-12 05:16:31.308474
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:16:38.242268
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:16:40.864441
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:16:45.806414
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)
    assert maybe.get_or_else(None) == 1
    assert maybe.is_nothing == False

    lazy_maybe = maybe.to_lazy()
    assert lazy_maybe == Lazy(lambda: 1)



# Generated at 2022-06-12 05:16:52.564120
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    :returns: Nothing
    :rtype: Nothing
    """
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:16:58.019603
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.nothing()
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just(1) == None
    assert not Maybe.nothing() == None



# Generated at 2022-06-12 05:17:06.252283
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :returns: True when all tests are successfull, otherwise raises AssertionError
    :rtype: Boolean
    """
    # Create some objects to compare in tests
    nothing = Maybe.nothing()
    some = Maybe.just(1)
    another_some = Maybe.just(1)
    different_some = Maybe.just(2)
    another_different_some = Maybe.just(2)

    # Compare empty maybes, should be equal
    assert nothing == nothing
    assert not nothing == some
    # Compare maybes with same values, should be equal
    assert some == some
    assert some == another_some
    assert not some == nothing
    assert not some == different_some
    # Compare maybes with different values, should be not equal

# Generated at 2022-06-12 05:17:10.748979
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:17:14.477250
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(6).to_lazy() == Lazy(lambda: 6)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:58.734715
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Given
    from pymonet.lazy import Lazy

    # When
    maybe = Maybe(1, False)
    lazy = maybe.to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


# Generated at 2022-06-12 05:18:04.293409
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() != Maybe.just(0)
    try:
        Maybe.just(1) == Maybe.nothing()
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 05:18:11.106784
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just("1")
    assert Maybe.just(1) != Maybe.just([1])
    assert Maybe.just(1) != Maybe.just({"a": 1})
    assert Maybe.just(1) != Maybe.just(True)
    assert Maybe.just(1) != Maybe.just((1, 2, 3))
    assert Maybe.just(1) != Maybe.just({1, 2, 3})



# Generated at 2022-06-12 05:18:20.388876
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(10, True) == Maybe.nothing()
    assert Maybe(0, True) == Maybe.nothing()
    assert Maybe(0.5, True) == Maybe.nothing()
    assert Maybe(True, True) == Maybe.nothing()
    assert Maybe(False, True) == Maybe.nothing()
    assert Maybe('test', True) == Maybe.nothing()

    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(10, True) == Maybe(10, True)
    assert Maybe(0, True) == Maybe(0, True)
    assert Maybe(0.5, True) == Maybe(0.5, True)
    assert Maybe(True, True) == Maybe(True, True)
    assert Maybe(False, True) == Maybe(False, True)

# Generated at 2022-06-12 05:18:23.872037
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)

    def odd(value):
        if value % 2 == 0:
            return True
        return False

    assert maybe.filter(odd) == Maybe.nothing()


# Generated at 2022-06-12 05:18:28.022752
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda num: num % 2 == 0) == Maybe.just(42)
    assert Maybe.just(42).filter(lambda num: num % 2 != 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda num: num % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:18:34.135281
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    class TestClass(object):
        pass
    test_class_1 = TestClass()
    test_class_2 = TestClass()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(test_class_1) == Maybe.just(test_class_1)
    assert Maybe.just(test_class_1) != Maybe.just(test_class_2)



# Generated at 2022-06-12 05:18:36.062798
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    input_value = 123

    result = Maybe.just(input_value).to_lazy().force()

    expected = input_value

    assert result == expected


# Generated at 2022-06-12 05:18:41.501502
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pytest
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy().evaluate() == 5
    assert Maybe.nothing().to_lazy().evaluate() is None
    assert Maybe.nothing().to_lazy().evaluate() == Maybe.nothing().to_lazy().evaluate()


# Generated at 2022-06-12 05:18:47.147514
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just_five = Maybe.just(5)
    just_five_copy = Maybe.just(5)
    just_four = Maybe.just(4)
    nothing = Maybe.nothing()
    assert just_five == just_five_copy
    assert just_five != just_four
    assert just_five != nothing


# Generated at 2022-06-12 05:19:27.586280
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-12 05:19:37.916585
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.monad_list import List

    res_list = List.unfold(1, lambda v: v + 1 < 5, lambda v: v + 1)
    res_lazy = Lazy(lambda: 1)
    res_try = Try(1, True)
    res_validation_success = Validation.success(1)
    res_validation_failure = Validation.failure([1])
    res_box = Box(1)

    expected_true = True
    expected_false = False

    is_right = Maybe.just(1) == Maybe.just(1)

# Generated at 2022-06-12 05:19:43.511773
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :return: None
    """

    my_mapper_func = lambda x: x > 5

    assert Maybe.just(1).filter(my_mapper_func).is_nothing
    assert Maybe.just(7).filter(my_mapper_func).get_or_else(None) == 7
    assert Maybe.nothing().filter(my_mapper_func).is_nothing



# Generated at 2022-06-12 05:19:49.201898
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != Maybe.nothing() and \
           Maybe.nothing() == Maybe.nothing() and \
           Maybe.just(1) == Maybe.just(1) and \
           Maybe.just(1) != 1 and \
           Maybe.nothing() != 1



# Generated at 2022-06-12 05:19:53.392307
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert isinstance(Maybe.just(3), Maybe)
    assert isinstance(Maybe.nothing(), Maybe)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:19:58.097057
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    # Arrange
    test_value = 42
    test_maybe = Maybe.just(test_value)

    # Act
    lazy_result = test_maybe.to_lazy()

    # Assert
    assert lazy_result.call() == test_value



# Generated at 2022-06-12 05:20:02.350240
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe('a', False) == Maybe.just('a')
    assert Maybe.just('a') == Maybe('a', False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.nothing()


# Generated at 2022-06-12 05:20:06.646913
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for Maybe.to_lazy method.

    """
    assert repr(Maybe.nothing().to_lazy()) == 'Lazy(<function Maybe.nothing.<locals>.<lambda> at 0x105585378>)'
    assert repr(Maybe.just(3).to_lazy()) == 'Lazy(<function Maybe.just.<locals>.<lambda> at 0x105585668>)'
    assert Maybe.just(4).to_lazy().value() == 4
    assert Maybe.nothing().to_lazy().value() is None


# Generated at 2022-06-12 05:20:12.038735
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

if __name__ == '__main__':
    test_Maybe___eq__()
    print('Done')

# Generated at 2022-06-12 05:20:15.760194
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:21:01.339097
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
