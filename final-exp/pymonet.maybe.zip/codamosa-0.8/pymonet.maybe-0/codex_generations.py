

# Generated at 2022-06-12 05:11:09.402697
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('Testing method __eq__ of class Maybe: ', end='')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)

    print('Ok')



# Generated at 2022-06-12 05:11:14.196205
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-12 05:11:19.063781
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:11:23.488459
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 2 + 2)

    maybe_result = Maybe.just(4) \
        .to_lazy() \
        .bind(lambda lazy: lazy.to_maybe())

    assert maybe_result == maybe_result


# Generated at 2022-06-12 05:11:29.679330
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:11:34.039172
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (
        Maybe.just(1) == Maybe.just(1)
    )
    assert (
        Maybe.just(1) != Maybe.just(2)
    )



# Generated at 2022-06-12 05:11:37.247260
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:11:50.456662
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test_helper import lst_to_maybe

    assert lst_to_maybe([1, 2, 3]).filter(
        lambda x: x == 1
    ) == Maybe.just(1)
    assert lst_to_maybe([1, 2, 3]).filter(
        lambda x: x == 2
    ) == Maybe.just(2)
    assert lst_to_maybe([1, 2, 3]).filter(
        lambda x: x == 3
    ) == Maybe.just(3)

    assert lst_to_maybe([]).filter(
        lambda x: x == 1
    ) == Maybe.nothing()
    assert lst_to_maybe([1, 2, 3]).filter(
        lambda x: x == 4
    ) == Maybe.nothing()



# Generated at 2022-06-12 05:11:53.233379
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:55.892583
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:12:04.675927
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:12:08.268533
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    instance = Maybe.just(1)
    result = instance == Maybe.just(1)
    assert result

    instance = Maybe.nothing()
    result = instance == Maybe.nothing()
    assert result


# Generated at 2022-06-12 05:12:14.255354
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.validation import Validation

    def validate(value):
        if value < 10:
            return Validation.success(value)
        return Validation.failure([])

    maybe = Maybe.just(8).bind(lambda x: Validation.success(x).to_maybe())
    maybe2 = Maybe.just(8).bind(lambda x: validate(x))

    assert maybe == maybe2



# Generated at 2022-06-12 05:12:19.740188
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:12:23.557527
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != None
    assert Maybe.nothing() != None
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:29.245274
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(10)
    assert maybe.to_lazy() == Lazy(lambda: 10)
    assert maybe.to_lazy().value() == 10
    assert maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert maybe.nothing().to_lazy().value() is None

# Generated at 2022-06-12 05:12:32.725257
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:35.310039
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(7).filter(lambda x: x > 5) == Maybe.just(7)


# Generated at 2022-06-12 05:12:39.863430
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(7) == Maybe.just(7)
    assert Maybe.just(7) != Maybe.just(8)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(7) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(7)


# Generated at 2022-06-12 05:12:44.726688
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(None)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:12:52.749041
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:55.932929
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    with pytest.raises(TypeError):
        Maybe.nothing().to_lazy()

# Generated at 2022-06-12 05:12:59.574136
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.just(2) != Maybe.nothing()


# Generated at 2022-06-12 05:13:02.516743
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:13:07.704493
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:13:10.328091
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just(1).to_lazy()
    assert lazy.evaluate() == 1
    lazy = Maybe.nothing().to_lazy()
    assert lazy.evaluate() is None



# Generated at 2022-06-12 05:13:15.324413
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:13:19.705314
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:13:24.596661
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:13:31.212141
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter.
    """
    # When Maybe is not empty and filterer returns True, then return copy of Maybe
    maybe_1 = Maybe.just(2)
    assert maybe_1.filter(lambda value: value == 2) == Maybe.just(2)

    # When Maybe is not empty and filterer returns False, then return empty Maybe
    assert maybe_1.filter(lambda value: value < 2) == Maybe.nothing()

    # When Maybe is empty, then return empty Maybe
    assert Maybe.nothing().filter(lambda value: value == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:13:40.729272
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:13:43.549101
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe

    assert Maybe.just(None).__eq__(Maybe.just(None)) == True
    assert Maybe.just(None).__eq__(Maybe.nothing()) == False


# Generated at 2022-06-12 05:13:46.976194
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.just(1) == Maybe.just(1))
    assert (Maybe.just(1) != Maybe.just(2))
    assert (Maybe.nothing() == Maybe.nothing())


# Generated at 2022-06-12 05:13:56.045836
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    value_1 = 5
    is_nothing_1 = False
    maybe_1 = Maybe(value_1, is_nothing_1)

    def filterer_1(value):
        return value >= 0
    def filterer_2(value):
        return value < 0

    def filterer_3(value):
        return value == 5

    # when
    result_1 = maybe_1.filter(filterer_1)
    result_2 = maybe_1.filter(filterer_2)
    result_3 = maybe_1.filter(filterer_3)

    # then
    assert result_1 == Maybe.just(value_1)
    assert result_2 == Maybe.nothing()
    assert result_3 == Maybe.just(value_1)

# Generated at 2022-06-12 05:14:03.921472
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test that filter method returns copied Maybe if option is not empty and filterer returns True,
    in other case returns empty Maybe.

    :returns: None
    :rtype: None
    """
    def filterer(value):
        return value > 0

    assert Maybe.just(1).filter(filterer) == Maybe.just(1)
    assert Maybe.just(-1).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()



# Generated at 2022-06-12 05:14:08.914977
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:14:20.502550
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def assert_functor_laws(instance: Functor, t: TypeVar):
        """
        Assert functor laws for given Functor (identity and composition)

        :param instance: any Functor
        :type instance: Functor
        :param t: generic type of functor
        :type t: TypeVar
        :raises AssertionError: if some of functor laws breaks
        """


# Generated at 2022-06-12 05:14:28.298759
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), 'Maybe.just(1) is not equal to Maybe.just(1)'
    assert Maybe.just(1) == Maybe.just(1), 'Maybe.just(1) is not equal to Maybe.just(1)'
    assert Maybe.nothing() == Maybe.nothing(), 'Maybe.nothing() is not equal to Maybe.nothing()'
    assert Maybe.nothing() != Maybe.just(1), 'Maybe.nothing() is equal to Maybe.just(1)'


# Generated at 2022-06-12 05:14:33.174727
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)

# Unit tests for method __init__ of class Maybe

# Generated at 2022-06-12 05:14:38.633615
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) != Maybe.just(24)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-12 05:14:53.605977
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    value = 1

    # When
    maybe = Maybe.just(value)
    result = maybe.filter(lambda x: x == 1)

    # Then
    assert result == Maybe.just(value)

    # When
    maybe = Maybe.nothing()
    result = maybe.filter(lambda x: x == 1)

    # Then
    assert result == Maybe.nothing()

    # When
    maybe = Maybe.just(value)
    result = maybe.filter(lambda x: x != 1)

    # Then
    assert result == Maybe.nothing()



# Generated at 2022-06-12 05:14:54.793446
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    pass


# Generated at 2022-06-12 05:14:58.008697
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe.nothing()


# Generated at 2022-06-12 05:15:09.834920
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(2).__eq__(Maybe.just(2))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert Maybe.just(2).__eq__(Box(2))
    assert Maybe.nothing().__eq__(Left(None))
    assert Maybe.just(2).__eq__(Lazy(lambda: 2))
    assert Maybe.nothing().__eq__(Try(None, False))
    assert Maybe.just(2).__eq__(Validation.success(2))
    assert Maybe.nothing().__eq__(Validation.success(None))

# Generated at 2022-06-12 05:15:20.294398
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.curry import curry
    from pymonet.monad_try import Try
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    @curry
    def add_one(x: int) -> int:
        return x + 1

    assert Maybe.just(1).to_lazy().map(add_one) == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy().map(add_one) == Lazy(lambda: None)


# Generated at 2022-06-12 05:15:32.241956
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Failure
    from pymonet.lazy import Lazy
    from pymonet.validation import Invalid

    assert Maybe(1, False).__eq__(Maybe(1, False))
    assert not Maybe(1, False).__eq__(Maybe(2, False))

    assert Maybe(1, False).__eq__(Maybe.just(1))
    assert not Maybe(1, False).__eq__(Maybe.just(2))
    assert Maybe(1, False).__eq__(Maybe.just(1)) == Maybe.just(1).__eq__(Maybe(1, False))

    assert Maybe(1, False).__eq__(1) == False
    assert Maybe(1, False).__eq__("string") == False

# Generated at 2022-06-12 05:15:37.051934
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(1, True)


# Generated at 2022-06-12 05:15:42.663073
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print("test_Maybe___eq__", end=" -> ")

    assert Maybe.just("test") == Maybe.just("test")
    assert Maybe.just("test") != Maybe.just("test2")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just("test")

    print("OK")



# Generated at 2022-06-12 05:15:47.275969
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:15:52.373983
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.nothing() is False
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) == Maybe.just(2) is False
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:16:03.267757
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.just(42).to_lazy() == Lazy(lambda: 42)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)


# Generated at 2022-06-12 05:16:09.905573
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x % 2 == 0) == Maybe.just(42)
    assert Maybe.just(41).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just("").filter(lambda x: x != "") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just("string").filter(lambda x: x == "string") == Maybe.just("string")
    assert Maybe.just("").filter(lambda x: x == "") == Maybe.nothing()

# Generated at 2022-06-12 05:16:14.519387
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda i: i < 0) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda i: i == 3) == Maybe.just(3)
    assert Maybe.nothing().filter(lambda i: i < 0) == Maybe.nothing()


# Generated at 2022-06-12 05:16:18.087267
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:16:23.913057
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1) == Maybe.just(1).filter(lambda x: x == 1)
    assert Maybe.just(1) != Maybe.just(1).filter(lambda x: x == 2)
    assert Maybe.nothing() == Maybe.nothing().filter(lambda x: x == 1)
    assert Maybe.nothing().filter(lambda x: x == 1) != Maybe.just(1)


# Generated at 2022-06-12 05:16:29.380015
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    f = lambda x: x > 2
    assert Maybe.nothing().filter(f) == Maybe.nothing()
    assert Maybe.just(1).filter(f) == Maybe.nothing()
    assert Maybe.just(3).filter(f) == Maybe.just(3)



# Generated at 2022-06-12 05:16:32.993515
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:16:38.617788
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functions import identity

    assert Maybe.just(10).filter(identity) == Maybe.just(10)
    assert Maybe.just(0).filter(identity) == Maybe.nothing()


# Generated at 2022-06-12 05:16:43.378337
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x < 2) == Maybe.just(1)
    assert Maybe(3, False).filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe(None, True).filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-12 05:16:48.287389
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe(2, False).filter(lambda x: x < 2) == Maybe.nothing()
    assert Maybe(2, False).filter(lambda x: x == 2) == Maybe(2, False)
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-12 05:17:05.127693
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x <= 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x < 20) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 5) == Maybe.nothing()


# Generated at 2022-06-12 05:17:13.764024
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :returns: Nothing
    :rtype: Nothing
    """

    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1 + 2) == Maybe.just(1 + 2).to_lazy()
    assert Lazy(lambda: 'test') == Maybe.just('test').to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()
    assert Lazy(lambda: [1, 2, 3]) == Maybe.just([1, 2, 3]).to_lazy()


# Generated at 2022-06-12 05:17:18.354226
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-12 05:17:29.702031
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_iter import MonadIter
    from pymonet.box import Box

    # test for empty list of MonadIter
    for x in MonadIter([]):
        assert x == Maybe.nothing()

    # test for empty generator of MonadIter
    for x in MonadIter(({x: x} for x in [])):
        assert x == Maybe.nothing()

    # test for not empty list of MonadIter
    for x in MonadIter([1, 2, 3]):
        assert x == Maybe.just(1)

    # test for not empty generator of MonadIter

# Generated at 2022-06-12 05:17:34.558669
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method Maybe.to_lazy of Maybe class.

    :return: None
    :rtype: None
    """

    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:17:41.288608
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method.

    :returns: Nothing
    :rtype: None
    :raises AssertionError: raise AssertionError if test failed
    """
    lazy = Maybe.just(1).to_lazy()
    assert lazy.force() == 1
    lazy = Maybe.nothing().to_lazy()
    assert lazy.force() is None



# Generated at 2022-06-12 05:17:46.246361
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 1) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:17:51.744597
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test for method filter of class Maybe.

    >>> test_Maybe_filter()
    (2, 2)
    """
    maybe_1 = Maybe(1, False).filter(lambda x: x % 2 == 0)
    maybe_2 = Maybe(2, False).filter(lambda x: x % 2 == 0)

    return maybe_1.is_nothing, maybe_2.value

# Generated at 2022-06-12 05:17:55.629401
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:18:00.081295
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x:x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x:x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x:x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:18:28.759812
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    pass
    # assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    # assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    # assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:18:33.861308
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    :return:
    """
    def filterer(val):
        return val == "filter"

    some = Maybe.just("filter")
    assert some.filter(filterer) == Maybe.just("filter")

    nothing = Maybe.nothing()
    assert nothing.filter(filterer) == Maybe.nothing()

    some_not = Maybe.just("filter1")
    assert some_not.filter(filterer) == Maybe.nothing()

# Generated at 2022-06-12 05:18:36.536586
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    import pytest

    assert Maybe.just(1).to_lazy().force() == 1
    assert Maybe.nothing().to_lazy().force() is None
    with pytest.raises(RuntimeError):
        Maybe(1, False).to_lazy().force()

# Generated at 2022-06-12 05:18:40.973468
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just('foo')
    assert maybe.filter(lambda val: val == 'foo') == Maybe.just('foo')
    assert maybe.filter(lambda val: val == 'bar') == Maybe.nothing()

    maybe = Maybe.nothing()
    assert maybe.filter(lambda val: val == 'foo') == Maybe.nothing()



# Generated at 2022-06-12 05:18:51.713605
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test for method filter of class Maybe
    """
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: 1 == 2) == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1).filter(lambda x: x)
    assert Maybe.nothing() == Maybe.nothing().filter(lambda x: x)


# Generated at 2022-06-12 05:18:54.777442
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:19:01.735754
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.just(Box(10)).to_lazy() == Lazy(lambda: Box(10))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:19:13.696380
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Fix filter method of method filter of class Maybe.
    """
    maybe_number = Maybe.just(2)
    maybe_number_filter = maybe_number.filter(lambda value: value % 2 == 0)
    maybe_number_filter_fail = maybe_number.filter(lambda value: value % 2 == 1)

    assert isinstance(maybe_number_filter, Maybe) and \
        not maybe_number_filter.is_nothing and \
        maybe_number_filter.value == 2

    assert isinstance(maybe_number_filter_fail, Maybe) and \
        maybe_number_filter_fail.is_nothing

    maybe_string = Maybe.just('string')
    maybe_string_filter = maybe_string.filter(lambda value: len(value) > 5)

# Generated at 2022-06-12 05:19:20.658719
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    a = Maybe.just(1)
    b = Maybe.just(2)
    c = Maybe.just(3)
    d = Maybe.just(4)
    assert (a.filter(
        lambda x: x > 2).get_or_else(0) == 0)
    assert (b.filter(
        lambda x: x > 2).get_or_else(0) == 0)
    assert (c.filter(
        lambda x: x > 2).get_or_else(0) == 3)
    assert (d.filter(
        lambda x: x > 2).get_or_else(0) == 4)

# Generated at 2022-06-12 05:19:24.626421
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def test_func():
        return 3
    assert Maybe.just(2).to_lazy() == Lazy(test_func)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:14.472415
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    func = Maybe.just(
        lambda x: x + 2
    ).to_lazy().value()
    assert(func(2) == 4)

# Generated at 2022-06-12 05:20:19.549402
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for filter method of Maybe
    """
    assert Maybe(5, False).filter(lambda x: True).value == 5
    assert Maybe(5, False).filter(lambda x: x % 2 == 0).is_nothing
    assert Maybe(5, True).filter(lambda x: True).is_nothing


# Generated at 2022-06-12 05:20:23.066424
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    maybe = Maybe.just(5)
    lazy = maybe.to_lazy()

    assert lazy == Lazy(lambda: 5)



# Generated at 2022-06-12 05:20:30.009093
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def return_42():
        return 42

    assert Maybe.just(7).to_lazy() == Lazy(lambda: 7)
    assert Maybe.just(return_42).to_lazy() == Lazy(return_42)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:34.263181
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 7).to_box() == Box(10)
    assert Maybe.just(5).filter(lambda x: x > 7).to_box() == Box(None)
    assert Maybe.nothing().filter(lambda x: x > 7).to_box() == Box(None)


# Generated at 2022-06-12 05:20:38.333305
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:20:45.256892
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    is_empty_method = Maybe.just(2).filter(lambda x: x % 2 == 0)
    is_not_empty_method = Maybe.just(2).filter(lambda x: x % 2 == 1)

    # THEN
    assert is_empty_method == Maybe.nothing()
    assert is_not_empty_method == Maybe.just(2)



# Generated at 2022-06-12 05:20:50.583342
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functions import odd
    from pymonet.functions import is_true

    assert Maybe.just(3).filter(odd) == Maybe.just(3)
    assert Maybe.just(2).filter(odd) == Maybe.nothing()
    assert Maybe.just(True).filter(is_true) == Maybe.just(True)
    assert Maybe.just(False).filter(is_true) == Maybe.nothing()


# Generated at 2022-06-12 05:20:55.665777
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(
        lambda value: value > 1
    ) == Maybe.just(2)

    assert Maybe.just(2).filter(
        lambda value: value > 2
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda value: True
    ) == Maybe.nothing()


# Generated at 2022-06-12 05:21:03.849465
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: isinstance(x, int)) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: isinstance(x, str)) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
