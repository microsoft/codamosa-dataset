

# Generated at 2022-06-12 05:11:12.122531
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try

    assert Maybe.just(1).filter(lambda x: x % 2 == 0).get_or_else(2) == 2
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).get_or_else(3) == 2
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).get_or_else(3) == 3
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).to_try() == Try(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0).to_try() == Try(None, False)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).to_try() == Try(None, False)



# Generated at 2022-06-12 05:11:17.207144
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 0) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:11:20.890336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:11:27.424729
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test method filter of Maybe.

    :return: None
    :rtype: None
    """
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:11:31.434323
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.
    """

    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(1)
    maybe_3 = Maybe.just(2)
    maybe_4 = Maybe.nothing()
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.just(3)

    assert maybe_1 == maybe_1
    assert maybe_1 == maybe_2
    assert maybe_4 == maybe_4
    assert maybe_4 == maybe_5
    assert maybe_1 != maybe_3
    assert maybe_1 != maybe_4
    assert maybe_1 != maybe_6


# Generated at 2022-06-12 05:11:37.360345
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (
        Maybe.just(8) ==
        Maybe.just(8)
    ) == True

    assert (
        Maybe.nothing() ==
        Maybe.nothing()
    ) == True

    assert (
        Maybe.just(8) ==
        Maybe.nothing()
    ) == False

    assert (
        Maybe.nothing() ==
        Maybe.just(8)
    ) == False



# Generated at 2022-06-12 05:11:50.444675
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.nothing()
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(False) == Maybe(False, False)
    assert Maybe.just(False) != Maybe.just(True)
    assert Maybe.just(False) != Maybe(True, False)
    assert Maybe.just(False) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe.just(False)
    assert Maybe(False, False) != Maybe(True, False)
    assert Maybe(False, False) != Maybe.nothing()
    assert Maybe(False, False) == Maybe(False, False)

# Generated at 2022-06-12 05:11:54.817160
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monoid import Monoid

    assert Maybe.just(2).filter(lambda value: value > 1) == Maybe.just(2)
    assert Monoid.get_monoid_unit(Maybe).filter(lambda value: value > 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda value: value > 3) == Maybe.nothing()


# Generated at 2022-06-12 05:11:57.944417
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Maybe.just(10).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

# Generated at 2022-06-12 05:12:02.520492
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    my_maybe = Maybe.just(1)
    assert my_maybe == Maybe.just(1)
    assert not my_maybe == Maybe.just(None)

    my_maybe_nothing = Maybe.nothing()
    assert my_maybe_nothing == Maybe.nothing()
    assert not my_maybe_nothing == Maybe.nothing(2)



# Generated at 2022-06-12 05:12:10.234540
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:12:14.982554
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Compare two empty Maybes
    assert Nothing == Nothing

    # Compare two not empty Maybes
    assert Just('1') == Just('1')

    # Compare empty Maybe with not empty
    assert Nothing != Just('2')


# Generated at 2022-06-12 05:12:21.603806
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)

# Test for method just of class Maybe

# Generated at 2022-06-12 05:12:28.122962
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('unit test for method __eq__ of class Maybe')

    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    m3 = Maybe.just(1)

    mn1 = Maybe.nothing()
    mn2 = Maybe.nothing()

    assert m1 == m1
    assert m1 != m2
    assert m1 == m3

    assert mn1 == mn1
    assert mn1 != mn2



# Generated at 2022-06-12 05:12:32.873951
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 0) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-12 05:12:39.745789
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe(2, False)
    lazy = maybe.to_lazy()

    assert isinstance(
        lazy,
        Lazy
    )

    assert lazy.get() == 2

    assert lazy.get() == 2

    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()

    assert isinstance(
        lazy,
        Lazy
    )

    assert lazy.get() is None

    assert lazy.get() is None

# Generated at 2022-06-12 05:12:51.209154
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Arrange
    maybe_a = Maybe.just('a')
    maybe_b = Maybe.just('b')
    maybe_a_1 = Maybe.just('a')
    maybe_none = Maybe.nothing()

    # Act first
    result_eq_1 = maybe_a.__eq__(maybe_b)
    result_eq_2 = maybe_a.__eq__(maybe_a_1)
    result_eq_3 = maybe_none.__eq__(maybe_a)
    result_eq_4 = maybe_a_1.__eq__(maybe_b)

    # Assert first
    assert result_eq_1 == False
    assert result_eq_2 == True
    assert result_eq_3 == False
    assert result_eq_4 == False


# Generated at 2022-06-12 05:12:54.881766
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    just_maybe = Maybe(10, False)
    lazy_just_maybe = just_maybe.to_lazy()
    lazy_maybe = Maybe.nothing()
    assert lazy_just_maybe.value() == 10
    assert lazy_maybe.value() == None

# Generated at 2022-06-12 05:12:59.788264
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filt(x: int) -> bool: return x % 2 == 0

    assert Maybe.just(8).filter(filt) == Maybe.just(8)
    assert Maybe.nothing().filter(filt) == Maybe.nothing()
    assert Maybe.just(7).filter(filt) == Maybe.nothing()


# Generated at 2022-06-12 05:13:05.166702
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    some1 = Maybe.just(1)
    some2 = Maybe.just(1)
    some3 = Maybe.just(2)
    nothing1 = Maybe.nothing()
    nothing2 = Maybe.nothing()
    assert some1 == some2
    assert some1 != some3
    assert nothing1 == nothing2
    assert some1 != nothing1


# Generated at 2022-06-12 05:13:22.741881
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    def is_even(x):
        return x % 2 == 0

    # True cases
    assert Maybe.just(2).filter(is_even).to_box() == Box(2)
    assert Maybe.just(88).filter(is_even).to_box() == Box(88)
    assert Maybe.just(19876).filter(is_even).to_box() == Box(19876)

    # False cases
    assert Maybe.just(5).filter(is_even).to_box() == Box(None)
    assert Maybe.just(999).filter(is_even).to_box() == Box(None)
    assert Maybe.just(93).filter(is_even).to_box() == Box(None)

    # False for None

# Generated at 2022-06-12 05:13:26.090408
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    value = Maybe.just('a')
    assert value.to_lazy().value() == 'a'

    value = Maybe.nothing()
    assert value.to_lazy().value() is None



# Generated at 2022-06-12 05:13:30.420747
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    mx3 = Maybe.just(3)
    m_3 = Maybe.just(3)
    m_nothing = Maybe.nothing()
    empty_list = []

    assert mx3 == m_3
    assert not mx3 == empty_list
    assert m_nothing == m_nothing
    assert not m_nothing == mx3
    assert not mx3 == m_nothing


# Generated at 2022-06-12 05:13:35.418980
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor


# Generated at 2022-06-12 05:13:38.745761
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-12 05:13:40.889041
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:13:52.315019
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :returns: None
    :rtype: None
    """
    import unittest

    class TestMaybe(unittest.TestCase):
        """
        Class for testing Maybe.map method
        """

        def test_filter(self):
            """
            Unit test for Maybe.filter method.

            :returns: None
            :rtype: None
            """
            from random import seed
            from random import randint

            is_passed = True

            seed(23)
            for _ in range(100):
                rand_int = randint(0, 100)
                maybe_int = Maybe.just(rand_int)
                maybe_int_filter = maybe_int.filter(lambda v: v % 2 == 0)

# Generated at 2022-06-12 05:13:58.071363
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:14:01.905395
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:14:04.513105
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just("3")
    assert Maybe.just(3) != Maybe.nothing()


# Generated at 2022-06-12 05:14:13.860243
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:14:17.644679
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("1") == Maybe.just("1")
    assert Maybe.just("1") != Maybe.just("2")
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:21.706283
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    maybe_maybe = Maybe(Maybe.just(1), False)
    maybe_int = Maybe(1, False)
    maybe_nothing = Maybe.nothing()

    # Assertions
    assert maybe_maybe == Maybe.just(Maybe.just(1))
    assert maybe_int == Maybe.just(1)
    assert maybe_nothing == Maybe.nothing()


# Generated at 2022-06-12 05:14:31.772495
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda value: value > 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda value: value < 0) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda value: value == 0) == Maybe.just(0)
    assert Maybe.just(1).filter(lambda value: value > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda value: value < 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda value: value == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value == 0)

# Generated at 2022-06-12 05:14:43.879262
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('Unit test for method __eq__ of class Maybe')

    def test_func(a: Maybe[T], b: Maybe[T], expectation):
        solution = a == b
        print('Test: a == b')
        print('a = ' + str(a.value) + ' b = ' + str(b.value))
        print('solution = ' + str(solution) + ' expectation = ' + str(expectation))
        assert solution == expectation, 'test__eq__ is failed'

    test_func(Maybe.just(1), Maybe.just(1), True)
    test_func(Maybe.just(1), Maybe.nothing(), False)
    test_func(Maybe.just(1), Maybe.just(2), False)
    test_func(Maybe.nothing(), Maybe.just(1), False)
    test_

# Generated at 2022-06-12 05:14:48.869129
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value > 10

    assert Maybe.just(15).filter(filterer) == Maybe.just(15)
    assert Maybe.just(5).filter(filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:14:52.697043
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def check(expected, value):
        m = Maybe.just(value)
        assert m == expected

    check(Maybe.just(1), 1)
    check(Maybe.just(2), 2)
    check(Maybe.nothing(), None)



# Generated at 2022-06-12 05:14:58.736013
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just_a = Maybe.just('a')
    just_b = Maybe.just('b')
    nothing_a = Maybe.nothing()
    nothing_b = Maybe.nothing()
    assert just_a == just_a
    assert just_a != just_b
    assert nothing_a == nothing_b
    assert just_a != nothing_a
    assert nothing_a != just_a


# Generated at 2022-06-12 05:15:03.489746
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:04.969718
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:15:19.325654
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:22.880091
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1).is_nothing() == False


# Generated at 2022-06-12 05:15:28.365302
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 0) == Maybe.nothing()

# Generated at 2022-06-12 05:15:34.370511
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Maybe.just(1), 'Not equal Maybe instances'
    assert Maybe.just(1) != Maybe.just(2), 'Not equal Maybe instances'
    assert Maybe.nothing() == Maybe.nothing(), 'Not equal Maybe instances'
    assert Maybe.nothing() == Maybe.just(None), 'Not equal Maybe instances'
    assert Maybe.just(None) != Maybe.just(2), 'Not equal Maybe instances'



# Generated at 2022-06-12 05:15:40.230501
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual = Maybe.nothing().filter(lambda x: False)
    expected = Maybe.nothing()
    assert actual == expected

    actual = Maybe.nothing().filter(lambda x: True)
    expected = Maybe.nothing()
    assert actual == expected

    actual = Maybe.just(2).filter(lambda x: False)
    expected = Maybe.nothing()
    assert actual == expected

    actual = Maybe.just(2).filter(lambda x: True)
    expected = Maybe.just(2)
    assert actual == expected

    actual = Maybe.just(2).filter(lambda x: x > 1)
    expected = Maybe.just(2)
    assert actual == expected

    actual = Maybe.just(1).filter(lambda x: x > 1)
    expected = Maybe.nothing()
    assert actual == expected



# Generated at 2022-06-12 05:15:48.846210
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('string') == Maybe.just('string')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('string') != Maybe.just('other')
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('string') != Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('string')
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:15:51.475276
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False) == Maybe.just(5)
    assert Maybe(5, False) != Maybe.just(4) != Maybe.just(6)

# Generated at 2022-06-12 05:15:59.901534
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_list import List
    from pymonet.monad_set import Set

    maybe = Maybe.just(4)

    list_of_maybe = List(maybe, Maybe.nothing())
    list_of_maybe = list_of_maybe.filter(lambda x:x.is_nothing)
    assert list_of_maybe == List(Maybe.nothing())

    set_of_maybe = Set(maybe, Maybe.nothing())
    set_of_maybe = set_of_maybe.filter(lambda x:x.is_nothing)
    assert set_of_maybe == Set(Maybe.nothing())



# Generated at 2022-06-12 05:16:06.250063
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), "Should be equal"
    assert Maybe.nothing() == Maybe.nothing(), "Should be equal"
    assert Maybe.just(1) != Maybe.just(2), "Should not be equal"
    assert Maybe.just(1) != Maybe.nothing(), "Should not be equal"
    assert Maybe.nothing() != Maybe.just(1), "Should not be equal"
test_Maybe___eq__()



# Generated at 2022-06-12 05:16:09.986991
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-12 05:16:44.930636
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe
    """

# Generated at 2022-06-12 05:16:48.335948
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-12 05:16:52.765149
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:16:56.379539
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:02.595693
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe([1, 2, 3]).filter(lambda x: True) == Maybe.just([1, 2, 3])
    assert Maybe([1, 2, 3]).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just([1, 2, 3]).filter(lambda x: True) == Maybe.just([1, 2, 3])
    assert Maybe.just([1, 2, 3]).filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:17:06.361547
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just(Box(1)).map(lambda x: x.value).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:17:09.092308
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(100).to_lazy() == Lazy(lambda: 100)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:13.581856
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:17:19.264971
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2)\
        .map(lambda x: x * 2)\
        .filter(lambda x: x > 5)\
        == Maybe.just(6)

    assert Maybe.nothing()\
        .map(lambda x: x * 2)\
        .filter(lambda x: x > 5)\
        == Maybe.nothing()



# Generated at 2022-06-12 05:17:28.191325
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe

    :returns: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Lazy(lambda: 2) == Maybe.just(2).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()
    print('Maybe to_lazy method: ok')



# Generated at 2022-06-12 05:18:18.122457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda v: True) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda v: v > 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda v: v > 1) == Maybe.just(2)


# Generated at 2022-06-12 05:18:21.919743
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(5)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != "a"


# Generated at 2022-06-12 05:18:29.299133
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just('1')
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just([1])
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just('2')
    assert Maybe.nothing() != Maybe.just([2])


# Generated at 2022-06-12 05:18:32.477593
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:18:36.192687
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    x = 10
    maybe_with_value = Maybe.just(x)
    maybe_empty = Maybe.nothing()

    def filterer(v):
        return v < 15

    assert maybe_with_value.filter(filterer) == Maybe.just(x)
    assert maybe_empty.filter(filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:18:40.353968
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:18:45.647417
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(100, False).filter(lambda x: x == 100) == Maybe.just(100)
    assert Maybe(100, False).filter(lambda x: x != 100) == Maybe.nothing()
    assert Maybe(100, True ).filter(lambda x: x != 100) == Maybe.nothing()


# Generated at 2022-06-12 05:18:49.097756
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    laz = Lazy(lambda: 1).to_maybe().to_lazy()
    assert laz == Lazy(lambda: 1)

# Generated at 2022-06-12 05:18:56.539679
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # When Maybe is empty
    assert Maybe(None, True) == Maybe(None, True) == Maybe.nothing()

    # When Maybe is not empty
    assert Maybe(10, False) == Maybe(10, False) == Maybe.just(10)

    # When Maybe is empty and other is not empty
    assert Maybe(None, True) != Maybe(10, False)

    # When Maybe is not empty and other is empty
    assert Maybe(10, False) != Maybe(None, True)

    # When Maybe is not empty and other is empty
    assert Maybe(10, False) != Maybe(20, False)


# Generated at 2022-06-12 05:19:03.109212
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Maybe(Box(2), False).filter(lambda x: x > 0) == Maybe(Box(2), False)
    assert Maybe(Box(2), False).filter(lambda x: x < 0) == Maybe(Box(None), True)
    assert Maybe(Box(None), True).filter(lambda x: True) == Maybe(Box(None), True)



# Generated at 2022-06-12 05:20:38.528050
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.nothing() is False
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:20:49.460051
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def _test_functor(functor: Functor):
        assert functor.map(lambda x: x + 1).value() == 4
        assert functor.map(lambda x: x + 2).value() == 5

    def _test_applicative(applicative: Applicative):
        assert applicative.ap(Lazy(lambda: 3)).value() == 13
        assert applicative.ap(Lazy(lambda: 20)).value() == 30

    assert Lazy(Maybe.just(3).to_lazy().value) == Lazy(lambda: Maybe.just(3))


# Generated at 2022-06-12 05:20:53.947788
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False) and \
        Maybe(2, False) != Maybe(2, True) and \
        Maybe(3, True) != Maybe(3, False) and \
        Maybe(4, True) == Maybe(4, True)


# Generated at 2022-06-12 05:21:01.015889
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_cases = [
        (Maybe.just(1), lambda x: True),
        (Maybe.just(1), lambda x: False),
        (Maybe.nothing(), lambda x: True),
        (Maybe.nothing(), lambda x: False)
    ]
    for case in test_cases:
        actual_result = case[0].filter(case[1])
        expected_result = Maybe.nothing() if case[0].is_nothing or not case[1](case[0].value) else case[0]
        assert actual_result == expected_result, "expected " + str(expected_result) + " got " + str(actual_result)
