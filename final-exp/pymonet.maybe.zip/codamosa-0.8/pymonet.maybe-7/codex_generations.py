

# Generated at 2022-06-12 05:11:06.645954
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x == 6) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 5) == Maybe.nothing()
test_Maybe_filter()

# Generated at 2022-06-12 05:11:10.007268
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(3, False) == Maybe(3, False)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:11:14.329169
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:23.078663
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5.5) == Maybe.just(5.5)
    assert Maybe.just('string') == Maybe.just('string')
    assert Maybe.just([1, 2, 3]) == Maybe.just([1, 2, 3])
    assert Maybe.just((1, 2)) == Maybe.just((1, 2))
    assert Maybe.just({'a': 1}) == Maybe.just({'a': 1})

    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5.0) != Maybe.just(5.5)
    assert Maybe.just('sad') != Maybe.just('sadness')
    assert Maybe.just([1, 2]) != Maybe.just

# Generated at 2022-06-12 05:11:26.966255
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:11:32.692733
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(42)
    m2 = Maybe.just(42)
    m3 = Maybe.just(1)
    assert m1 == m2
    assert m1 != m3

    m4 = Maybe.nothing()
    m5 = Maybe.nothing()
    assert m4 == m5
    assert m1 != m4


# Generated at 2022-06-12 05:11:36.336625
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:11:45.082599
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def test():
        data = Maybe.just(123)
        result = data.to_lazy()
        assert result.force() == 123
        assert isinstance(result, Lazy)

        data = Maybe.nothing()
        result = data.to_lazy()
        assert result.force() == None
        assert isinstance(result, Lazy)

    test()



# Generated at 2022-06-12 05:11:50.853925
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != 1
    assert Maybe(1, True) != 1


# Generated at 2022-06-12 05:11:54.541279
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:01.547960
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)


# Generated at 2022-06-12 05:12:05.665575
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:11.410240
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    m1 = Maybe.just(1)
    algorithm = lambda x: x == 1

    # When
    m1_result = m1.filter(algorithm)

    # Then
    assert m1_result == m1

    # Given
    m2 = Maybe.just(2)

    # When
    m2_result = m2.filter(algorithm)

    # Then
    assert m2_result == Maybe.nothing()


# Generated at 2022-06-12 05:12:15.977355
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x > 0).get_or_else(None) == 1
    assert Maybe(1, False).filter(lambda x: x > 1).get_or_else(None) is None


# Generated at 2022-06-12 05:12:20.170937
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()



# Generated at 2022-06-12 05:12:25.145820
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(2, False)


# Generated at 2022-06-12 05:12:34.092176
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When Maybe is empty and filterer returns True
    from pymonet.box import Box

    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()

    # When Maybe is empty and filterer returns False
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()

    # When Maybe is not empty and filterer returns True
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)

    # When Maybe is not empty and filterer returns False
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()


# Generated at 2022-06-12 05:12:35.768000
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:12:44.138123
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    class TestClass:
        pass

    test_object_1 = TestClass()
    test_object_2 = TestClass()

    # test 1
    assert Maybe.just(1) == Maybe.just(1)

    # test 2
    assert Maybe.just(1) != Maybe.just(2)

    # test 3
    assert Maybe.just(1) != Maybe.nothing()

    # test 4
    assert Maybe.nothing() == Maybe.nothing()

    # test 5
    assert Maybe.just(test_object_1) == Maybe.just(test_object_1)

    # test 6
    assert Maybe.nothing() != Maybe.just(test_object_1)

    # test 7
    assert Maybe.just(test_object_1) != Maybe.just(test_object_2)

# Generated at 2022-06-12 05:12:54.162599
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test function with example of using filter.

    :returns: None
    """
    def is_even(value):
        """
        Function to filter list with even numbers.

        :param value: number to check
        :type value: int
        :returns: True if value is even number
        :rtype: bool
        """
        return value % 2 == 0
    some_list = [i for i in range(10)]
    filtered_list = Maybe.just(some_list).\
        filter(lambda l: len(l) > 0).\
        bind(lambda l: Maybe.just(list(filter(is_even, l)))).\
        map(lambda l: l[0])
    print('First even number from list: {}'.format(filtered_list.value))


# Generated at 2022-06-12 05:13:00.365173
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = Maybe(2, False)

    assert Lazy(lambda: 2) == value.to_lazy()

# Generated at 2022-06-12 05:13:07.555416
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(0, True) == Maybe(1, True)
    assert Maybe(0, False) == Maybe(0, False)
    assert Maybe(0, False) != Maybe(1, False)
    assert Maybe(1, True) != Maybe(0, True)
    assert Maybe(0, False) != Maybe(1, True)
    assert Maybe(0, True) != Maybe(1, False)
    assert Maybe(0, False) != None


# Generated at 2022-06-12 05:13:14.871007
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_a = Maybe(42, False)
    assert maybe_a == Maybe(42, False)
    assert not maybe_a == Maybe(42, True)
    assert not maybe_a == Maybe(43, False)
    assert not maybe_a == Maybe(43, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.nothing() == Maybe(0, False)
    assert not Maybe.just(0) == Maybe.nothing()
    assert Maybe.just(0) == Maybe.just(0)


# Generated at 2022-06-12 05:13:26.139418
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe(10, False).to_lazy() == Lazy(lambda: 10)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(10, False).to_lazy().value() == 10
    assert Maybe(None, True).to_lazy().value() == None

    assert Maybe(10, False).to_lazy().map(lambda value: value + 10) == Lazy(lambda: 20)
    assert Maybe(None, True).to_lazy().map(lambda value: value + 10) == Lazy(lambda: None)


# Generated at 2022-06-12 05:13:28.524007
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    Maybe.nothing() == Maybe.nothing() == Maybe.nothing() == Maybe.just(1) == Maybe.just(2) == Maybe.just(3)


# Generated at 2022-06-12 05:13:30.944063
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:13:34.789796
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(55) == Maybe.just(55)
    assert Maybe.just(55) != Maybe.just(44)
    assert Maybe.just(55) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:41.445484
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just_1 = Maybe.just(1)
    just_2 = Maybe.just(2)
    just_3 = Maybe.just(3)
    nothing = Maybe.nothing()

    assert just_1 != just_2
    assert just_1 != nothing
    assert nothing != just_1
    assert just_1 == Maybe.just(1)
    assert just_2 == Maybe.just(2)
    assert just_3 == Maybe.just(3)
    assert nothing == Maybe.nothing()

# Generated at 2022-06-12 05:13:44.864032
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:13:46.627404
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Hope that instances will be equal
    assert(Maybe.just(False) == Maybe.just(False))
    # Hope that instances will not be equal
    assert(Maybe.just(False) != Maybe.just(True))


# Generated at 2022-06-12 05:13:58.069502
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:14:02.758826
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda n: n % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda n: n % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda n: n % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:14:07.104345
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, is_nothing=False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, is_nothing=True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:14:10.457594
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.maybe(True, 123, 456) == Maybe.maybe(True, 123, 456)
    assert Maybe.maybe(True, 123, 456) != Maybe.maybe(True, 123, False)

# Generated at 2022-06-12 05:14:14.641803
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()


# Generated at 2022-06-12 05:14:18.781239
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-12 05:14:25.653030
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(11)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.just(10) != (10, 11)



# Generated at 2022-06-12 05:14:30.655189
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)


# Generated at 2022-06-12 05:14:36.963208
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just({'1': 1}) == Maybe.just({'1': 1})
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just([1, 2, 3]) == Maybe.just([1, 2, 3])
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.just('2')
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:14:41.753704
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:14:56.386529
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.nothing().to_lazy().get() is None


# Generated at 2022-06-12 05:15:08.301553
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Tests for method __eq__ of class Maybe with wrong arguments
    assert type(11) != Maybe.nothing()
    assert Maybe.nothing() != type(11)
    assert 11 != Maybe.nothing()
    assert Maybe.nothing() != 11

    from pymonet.other_monads import Lazy

    assert type(11) != Lazy.unit(11)
    assert Lazy.unit(11) != type(11)
    assert 11 != Lazy.unit(11)
    assert Lazy.unit(11) != 11

    # Tests for method __eq__ of class Maybe with valid arguments
    assert Maybe.just(11) == Maybe.just(11)
    assert Maybe.just(11) != Maybe.just(22)
    assert Maybe.just(11) == Maybe.nothing()
    assert Maybe.just(11) != Maybe.nothing()

# Generated at 2022-06-12 05:15:15.252753
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    maybe = Maybe.just(2)
    # When
    res = maybe.filter(lambda _: _ == 2)
    # Then
    assert res == Maybe.just(2)

    # Given
    maybe = Maybe.just(2)
    # When
    res = maybe.filter(lambda _: _ != 2)
    # Then
    assert res == Maybe.nothing()



# Generated at 2022-06-12 05:15:21.860987
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(42, False) == Maybe(42, False)
    assert Maybe('foo', False) == Maybe('foo', False)
    assert not Maybe(42, False) == Maybe(42, True)
    assert not Maybe(42, False) == Maybe('42', False)
    assert not Maybe(True, False) == Maybe(True, True)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, True) == Maybe(None, True)
    assert not Maybe(None, True) == Maybe(None, False)
    assert not Maybe(42, False) == Maybe(None, False)
    assert not Maybe(None, True) == None


# Generated at 2022-06-12 05:15:29.000486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import Lazy

    lazy_value = Maybe.just(Lazy(lambda: 2 + 2))
    assert lazy_value.to_lazy() == Lazy(lambda: Lazy(lambda: 2 + 2))
    lazy_value = Maybe.nothing()
    assert lazy_value.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:15:36.044412
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet import _
    from operator import add, truediv

    maybe = Maybe(8, False)

    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert maybe == Maybe.just(8)
    assert Maybe.just(5) != Maybe.just(6)



# Generated at 2022-06-12 05:15:41.592177
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(None, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(None, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)



# Generated at 2022-06-12 05:15:49.524790
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just(1)
    assert(maybe == maybe)

    maybe_with_same_value = Maybe.just(1)
    assert(maybe == maybe_with_same_value)

    maybe_with_other_value = Maybe.just(2)
    assert(maybe != maybe_with_other_value)

    empty_maybe = Maybe.nothing()
    assert(empty_maybe == empty_maybe)
    assert(empty_maybe != maybe)
    assert(empty_maybe != maybe_with_same_value)


# Generated at 2022-06-12 05:15:59.861995
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.functools import even

    # test1
    x = Maybe.just(10)
    r = x.filter(even)
    assert r == Maybe.just(10)

    # test2
    x = Maybe.just(10)
    r = x.filter(lambda x: False)
    assert r == Maybe.nothing()

    # test3
    x = Maybe.just(11)
    r = x.filter(even)
    assert r == Maybe.nothing()

    # test4
    x = Maybe.nothing()
    r = x.filter(even)
    assert r == Maybe.nothing()

    # test5
    x = Try.success(10)
    r = x.to_maybe().filter(even)

# Generated at 2022-06-12 05:16:05.928558
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method of Maybe class.

    :returns: assert result of to_lazy method
    :rtype: None
    """
    def test():
        return 5

    m = Maybe.just(test)
    assert m.to_lazy().maybe_value()() == 5

    m = Maybe.nothing()
    assert m.to_lazy().maybe_value()() is None


# Generated at 2022-06-12 05:16:23.960475
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(0)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:16:29.818935
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-12 05:16:34.442905
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 'value'
    result_1 = Maybe.just(value)
    result_2 = Maybe.just(value)
    result_3 = Maybe.nothing()
    result_4 = Maybe.nothing()
    true_value = Maybe.just(value) == Maybe.just(value) and Maybe.nothing() == Maybe.nothing()
    assert true_value
    assert result_1 == result_2
    assert result_3 == result_4


# Generated at 2022-06-12 05:16:38.834906
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 1
    just = Maybe.just(value)
    nothing = Maybe.nothing()
    assert just == Maybe.just(value)
    assert nothing == Maybe.nothing()
    assert nothing != just


# Generated at 2022-06-12 05:16:45.134536
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe(1, True)
    assert Maybe(1, True) == Maybe.nothing()


# Generated at 2022-06-12 05:16:50.901153
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    m = Maybe.just(10)
    l = m.to_lazy()
    assert l == Lazy(lambda: 10)
    m = Maybe.nothing()
    l = m.to_lazy()
    assert l == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:02.067671
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    try:
        assert Maybe.just(1) == Maybe.just(2)
        raise Exception("Nothing happened")
    except AssertionError:
        assert True
    try:
        assert Maybe.just(None) == Maybe.just(2)
        raise Exception("Nothing happened")
    except AssertionError:
        assert True
    try:
        assert Maybe.just(1) == Maybe.just(1)
        assert True
    except Exception:
        raise Exception("Nothing happened")
    try:
        assert Maybe.nothing() == Maybe.nothing()
        assert True
    except Exception:
        raise Exception("Nothing happened")
    try:
        assert Maybe.just(1) == Maybe.nothing()
        raise Exception("Nothing happened")
    except AssertionError:
        assert True

# Generated at 2022-06-12 05:17:08.694385
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x > 0) == Maybe(1, False)
    assert Maybe(1, False).filter(lambda x: x < 0) == Maybe(None, True)
    assert Maybe(1, True).filter(lambda x: x > 0) == Maybe(None, True)
    assert Maybe(1, True).filter(lambda x: x < 0) == Maybe(None, True)



# Generated at 2022-06-12 05:17:13.478327
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:17:18.815305
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functors.functor_lazy import FunctorLazy
    m = Maybe.just(42)
    l = m.to_lazy()
    assert l == Lazy(lambda: 42)
    assert l.value == 42


# Generated at 2022-06-12 05:17:35.008207
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-12 05:17:39.642144
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe(15, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(15, False).to_lazy() == Lazy(lambda: 15)



# Generated at 2022-06-12 05:17:46.608982
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    # Assertion is True when Maybe with value is transformed to Lazy monad,
    # and transformed Lazy returns proper value
    assert Maybe.just(2) \
        .to_lazy() \
        .get() == 2

    # Assertion is True when Maybe with None is transformed to Lazy monad,
    # and transformed Lazy returns proper value
    assert Maybe.nothing() \
        .to_lazy() \
        .get() == None


# Generated at 2022-06-12 05:17:57.465286
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)  # when boxes with same value
    assert Maybe(2, True) == Maybe(2, True)  # when boxes with same nothingness
    assert Maybe(None, True) == Maybe(None, True)  # when empty boxes
    assert Maybe(2, False) != Maybe(3, False)  # when different values
    assert Maybe(2, False) != Maybe(2, True)  # when different nothingnesses
    assert Maybe(None, True) != Maybe(2, False)  # when one box is empty
    assert Maybe(None, True) != Maybe(2, True)  # when different empty boxes
    assert Maybe(None, True) != Maybe(None, False)  # when different empty boxes
    assert Maybe(2, False) != 2  # when right hand is not Maybe

#

# Generated at 2022-06-12 05:18:02.180640
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()



# Generated at 2022-06-12 05:18:07.524431
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(None)
    assert Maybe.just(3) != Maybe.just(None)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:18:12.193056
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = Maybe.just('value')
    other_value = Maybe.just('other_value')
    assert Maybe.nothing() == Maybe.nothing()
    assert value != Maybe.nothing()
    assert value != other_value
    assert value == Maybe.just('value')


# Generated at 2022-06-12 05:18:15.962153
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m_1 = Maybe.just(1)
    m_2 = Maybe.just(1)
    assert m_1 == m_2

    m_1 = Maybe.nothing()
    m_2 = Maybe.nothing()
    assert m_1 == m_2



# Generated at 2022-06-12 05:18:19.834589
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)

# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:18:24.639667
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:18:41.728120
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(10).filter(lambda x: x > 5) == Maybe.just(10)
    assert Maybe.just(5).filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:18:53.888674
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(0.0) == Maybe.just(0.0)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just('string') == Maybe.just('string')
    assert Maybe.just(()) == Maybe.just(())
    assert Maybe.just([]) == Maybe.just([])
    assert Maybe.just({}) == Maybe.just({})

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(0.1234) != Maybe.just(0.5678)
    assert Maybe

# Generated at 2022-06-12 05:19:00.321071
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)
    assert maybe.filter(lambda x: x == 1) == Maybe.just(1)
    assert maybe.filter(lambda x: x == 2) == Maybe.nothing()

    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: x == 1) == Maybe.nothing()
    assert maybe.filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-12 05:19:11.516550
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(0, False) == Maybe(0, False)
    assert Maybe(1, False) == Maybe(1, False)

    assert Maybe(0, True) == Maybe(0, True)
    assert Maybe(1, True) == Maybe(1, True)

    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(2, False) != Maybe(2, True)

    assert Maybe(0, True) != Maybe(1, True)
    assert Maybe(0, False) != Maybe(1, False)

    assert Maybe(0, True) != Maybe(0, False)
    assert Maybe(1, False) != Maybe(1, True)

    assert Maybe(0, True) != 0
    assert Maybe(0, False) != 0
    assert Maybe(1, True) != 1

# Generated at 2022-06-12 05:19:19.054524
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: x).get_or_else(None) is True
    assert Maybe.just(False).filter(lambda x: x).get_or_else(None) is None
    assert Maybe.just(True).filter(lambda x: not x).get_or_else(None) is None
    assert Maybe.just(False).filter(lambda x: not x).get_or_else(None) is True
    assert Maybe.nothing().filter(lambda x: x).get_or_else(None) is None
    assert Maybe.nothing().filter(lambda x: x).get_or_else(True) is True


# Generated at 2022-06-12 05:19:25.040638
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x > 4) == Maybe.just(5)

    assert Maybe(0, False).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe(5, True).filter(lambda x: x > 4) == Maybe.nothing()



# Generated at 2022-06-12 05:19:35.837440
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int = Maybe.just(0)
    maybe_str = Maybe.just('')
    maybe_none = Maybe.nothing()

    assert maybe_int.filter(lambda x: x % 2 == 0).get_or_else(1) == 0
    assert maybe_int.filter(lambda x: x % 2 != 0).get_or_else(1) == 1
    assert maybe_str.filter(lambda x: x == '').get_or_else('1') == ''
    assert maybe_str.filter(lambda x: x != '').get_or_else('1') == '1'
    assert maybe_none.filter(lambda x: x is None).get_or_else('1') is None
    assert maybe_none.filter(lambda x: x is not None).get_or_else('1') == '1'



# Generated at 2022-06-12 05:19:39.731464
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != None
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:19:45.117306
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert not Maybe.just(1).__eq__(Maybe.just(0))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert not Maybe.nothing().__eq__(Lazy(lambda: None))
    assert not Maybe.just(1).__eq__(Lazy(lambda: 1))
    assert not Maybe.just(1).__eq__(Lazy(lambda: 0))


# Generated at 2022-06-12 05:19:48.396613
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    x = Maybe.just(10)
    y = x.to_lazy()
    assert y.value() == x.value

# Generated at 2022-06-12 05:20:05.036152
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:20:11.418358
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.utils import eq
    from pymonet.utils import identity

    def filterer(x): return x % 2 == 0

    assert eq(Maybe.nothing().filter(filterer), Maybe.nothing())
    assert eq(Maybe.just(1).filter(filterer), Maybe.nothing())
    assert eq(Maybe.just(2).filter(filterer), Maybe.just(2))



# Generated at 2022-06-12 05:20:15.904342
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(44).filter(lambda x: x == 44) == Maybe.just(44)
    assert Maybe.just(55).filter(lambda x: x == 44) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 44) == Maybe.nothing()


# Generated at 2022-06-12 05:20:19.719038
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:20:22.442627
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:20:30.228575
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe("abc", False) == Maybe("abc", False)
    assert Maybe("abc", False) != Maybe("xyz", False)
    assert Maybe("abc", False) != Maybe("abc", True)
    assert Maybe("abc", True) == Maybe("abc", True)
    assert Maybe("abc", True) != Maybe("xyz", True)
    assert Maybe("abc", True) != Maybe("xyz", False)


# Generated at 2022-06-12 05:20:34.112885
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

# Generated at 2022-06-12 05:20:39.632066
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(6)


# Generated at 2022-06-12 05:20:45.410026
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test case for method filter of class Maybe.

    :returns: None
    :rtype: None
    """
    assert Maybe.nothing().filter(lambda x: True).is_nothing
    assert Maybe.just(5).filter(lambda x: True).value == 5
    assert Maybe.just(5).filter(lambda x: False).is_nothing


# Generated at 2022-06-12 05:20:55.622975
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def get_value(value: int) -> int:  # type: ignore
        """
        Function that returns None.

        :param value: value used to check
        :type value: int
        :returns: value
        :rtype: int
        """
        return value

    # check with value
    validation = Validation.success(Maybe.just(1))
    validation.bind(lambda x: Lazy(get_value(x.value)))
    assert isinstance(validation.value.value, int)
    assert validation.value.value == 1

    # check with None
    validation = Validation.success(Maybe.nothing())
    validation.bind(lambda x: Lazy(get_value(x.value)))