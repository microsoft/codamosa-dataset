

# Generated at 2022-06-12 05:11:05.466176
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    result = Maybe(2, False) == Maybe(2, False)
    assert result

    result = Maybe(1, False) == Maybe(2, False)
    assert not result


# Generated at 2022-06-12 05:11:09.059503
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)


# Generated at 2022-06-12 05:11:13.669095
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe[int].just(1) == Maybe[int].just(1)
    assert Maybe[int].nothing() == Maybe[int].nothing()
    assert Maybe[int].just(1) != Maybe[int].just(2)
    assert Maybe[int].nothing() != Maybe[int].just(1)


# Generated at 2022-06-12 05:11:18.704592
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:11:23.364249
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:11:31.033974
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def is_equal(value1, value2):
        return Maybe.just(value1) == Maybe.just(value2)

    assert (
        is_equal(just(True), just(True)) and
        is_equal(just(0), just(0)) and
        is_equal(just(""), just("")) and
        is_equal(just(""), just(""))
    )


# Generated at 2022-06-12 05:11:35.024625
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1)

    assert maybe.is_nothing is False
    assert maybe.value == 1
    assert maybe.filter(lambda x: x > 0) == maybe
    assert maybe.filter(lambda x: x < 0).is_nothing
    assert maybe.filter(lambda x: x > 0) == maybe



# Generated at 2022-06-12 05:11:36.647081
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    value = Maybe(1, False)

    # When
    result = value.filter(lambda x: x == 1).value

    # Then
    assert result == 1



# Generated at 2022-06-12 05:11:43.069173
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(6).filter(lambda x: x > 5) == Maybe.just(6)
    assert Maybe.just(6).filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:11:45.138026
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:11:58.840318
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Successful case
    maybe_a = Maybe.just(1)
    maybe_b = Maybe.just(1)
    verify(maybe_a == maybe_b).is_equal(True)
    # Unsuccessful case
    maybe_a = Maybe.just(1)
    maybe_b = Maybe.just(2)
    verify(maybe_a == maybe_b).is_equal(False)
    # Successful case
    maybe_a = Maybe.nothing()
    maybe_b = Maybe.nothing()
    verify(maybe_a == maybe_b).is_equal(True)
    # Unsuccessful case
    maybe_a = Maybe.nothing()
    maybe_b = Maybe.just(1)
    verify(maybe_a == maybe_b).is_equal(False)



# Generated at 2022-06-12 05:12:03.150971
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:12:06.108837
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != 1


# Generated at 2022-06-12 05:12:09.556218
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 10
    assert Maybe.just(value) == Maybe.just(value)
    assert Maybe.just(value) == Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:14.882659
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:12:20.356607
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()


# Generated at 2022-06-12 05:12:24.202109
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy() == Maybe.just(5).to_lazy()
    assert Maybe.just(5).to_lazy().value() == 5
    assert Maybe.nothing().to_lazy() == Maybe.nothing().to_lazy()
    assert Maybe.nothing().to_lazy().value() is None



# Generated at 2022-06-12 05:12:33.563148
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method Maybe.__eq__(self, other)
    """
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-12 05:12:39.017899
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    class TestFunctor(Functor[Maybe]):
        def map(self, mapper: Callable[['Maybe[U]'], U]) -> 'Maybe[U]':
            return mapper(Maybe.just(None))

    class TestMonad(Monad[Maybe]):
        def unit(self, value: T) -> 'Maybe[T]':
            return Maybe.just(value)

        def bind(self, mapper: Callable[[T], 'Maybe[U]']) -> Union['Maybe[U]', 'Maybe[None]']:
            return Maybe.just(None).bind(mapper)

    class TestFilter(TestFunctor, TestMonad):
        pass

    assert TestFilter().filter(lambda x: True) == Maybe.just

# Generated at 2022-06-12 05:12:42.049424
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)



# Generated at 2022-06-12 05:12:51.959099
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:56.696967
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 0) == Maybe.just(2)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:13:06.417062
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(None)
    maybe_2 = Maybe.just(None)
    maybe_3 = Maybe(None, False)
    maybe_4 = Maybe(None, False)
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.nothing()
    maybe_7 = Maybe.just(1)
    maybe_8 = Maybe.just(1)
    maybe_9 = Maybe.just(2)
    maybe_10 = Maybe.just(2)
    assert maybe_1 == maybe_2
    assert maybe_3 == maybe_4
    assert maybe_5 == maybe_6
    assert maybe_7 == maybe_8
    assert maybe_9 == maybe_10



# Generated at 2022-06-12 05:13:10.402628
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("foo").filter(lambda x: len(x) > 1) == Maybe.just("foo")
    assert Maybe.just("F").filter(lambda x: len(x) > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == "foo") == Maybe.nothing()

# Generated at 2022-06-12 05:13:15.843379
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda n: n % 2 == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda n: n % 2 == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda n: n % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:13:18.554722
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    actual = Maybe(2, False).to_lazy()
    expected = Lazy(lambda: 2)
    assert actual == expected

# Generated at 2022-06-12 05:13:21.361781
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy().evaluate() == Lazy(lambda: 5).evaluate()

# Generated at 2022-06-12 05:13:24.025973
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(1)
    m1 = m.filter(lambda val: val > 0)
    m2 = m.filter(lambda val: val < 0)

    assert m1 == Maybe.just(1)
    assert m2 == Maybe.nothing()

# Generated at 2022-06-12 05:13:28.844665
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :return: None
    :rtype: None
    """
    result = Maybe.just(5).filter(lambda x: x < 5)

    assert result == Maybe.nothing()

    result = Maybe.just(5).filter(lambda x: x == 5)

    assert result == Maybe.just(5)


# Generated at 2022-06-12 05:13:34.320292
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    maybe = Maybe.just(1)

    # Act
    lazy = maybe.to_lazy()

    # Assert
    assert(isinstance(lazy, Lazy))
    assert(lazy.run() == 1)


# Generated at 2022-06-12 05:13:42.264376
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_a = Maybe.just('a')
    maybe_a_copy = Maybe.just('a')
    assert maybe_a == maybe_a_copy
    assert not maybe_a == Maybe.just('b')
    assert maybe_a == Maybe.nothing().bind(lambda _: maybe_a)
    assert not maybe_a == Maybe.nothing()


# Unit tests for method just classmethod of class Maybe

# Generated at 2022-06-12 05:13:45.603754
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-12 05:13:49.569925
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda _: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda _: False) == Maybe.nothing()


# Generated at 2022-06-12 05:13:56.706683
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :return: Nothing
    :rtype: None
    """
    from pymonet.functors.functor import Functor
    from pymonet.applicatives.applicative import Applicative

    class TestFunctor(Functor[T], Maybe[T]):
        pass

    class TestApplicative(Applicative[T], TestFunctor):
        pass

    test_monad = TestFunctor(1, False)
    assert test_monad == TestFunctor(1, False)
    assert test_monad == TestApplicative(1, False)
    assert test_monad != TestFunctor(2, False)
    assert test_monad != TestApplicative(2, False)
    assert test_monad != TestFunctor(2, True)
   

# Generated at 2022-06-12 05:14:02.758315
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, True).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe(1, False).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe(1, False).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe(1, False).filter(lambda x: x == 1) == Maybe.just(1)



# Generated at 2022-06-12 05:14:08.385787
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:14:13.276724
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(True, False).filter(lambda v: v) == Maybe.just(True)
    assert Maybe(True, False).filter(lambda v: not v) == Maybe.nothing()
    assert Maybe(None, True).filter(lambda v: True) == Maybe.nothing()



# Generated at 2022-06-12 05:14:19.268983
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(1)
    b = Maybe.nothing()
    assert a.__eq__(Maybe.just(1)) is True
    assert a.__eq__(Maybe.just(2)) is False
    assert b.__eq__(Maybe.nothing()) is True
    assert b.__eq__(Maybe.just(1)) is False
    assert a.__eq__(b) is False



# Generated at 2022-06-12 05:14:24.694267
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, True)


# Generated at 2022-06-12 05:14:28.008488
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x % 3 == 0) == Maybe.just(3)

# Generated at 2022-06-12 05:14:39.225957
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    is_correct = True

    assert is_correct == (Maybe.just(1) == Maybe.just(1))
    assert is_correct == (Maybe.just("") == Maybe.just(""))
    assert is_correct == (Maybe.just(None) == Maybe.just(None))
    assert is_correct == (Maybe.nothing() == Maybe.nothing())


# Generated at 2022-06-12 05:14:43.076528
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:49.599426
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result = Maybe.just(10).filter(lambda x: x < 10)
    assert result == Maybe.nothing()

    result = Maybe.just(10).filter(lambda x: x == 10)
    assert result == Maybe.just(10)

    result = Maybe.nothing().filter(lambda x: x == 10)
    assert result == Maybe.nothing()


# Generated at 2022-06-12 05:14:53.294661
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    def lazy_factory() -> int:
        """
        :returns: 10
        :rtype: int
        """
        return 10
    result = Maybe.just(10).to_lazy()
    assert result == Lazy(lazy_factory)

# Generated at 2022-06-12 05:14:57.061279
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Lazy

    assert Maybe(3, False).to_lazy() == Lazy(lambda: 3)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:15:04.374626
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # given
    maybe = Maybe.just(10)
    # when
    filtered_maybe = maybe.filter(lambda x: x == 10)
    # then
    assert filtered_maybe == Maybe.just(10)

    # given
    maybe = Maybe.just(10)
    # when
    filtered_maybe = maybe.filter(lambda x: x == 20)
    # then
    assert filtered_maybe == Maybe.nothing()


# Generated at 2022-06-12 05:15:09.721729
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    test Maybe.filter method
    """
    def filterer(x):
        return x == 2
    assert Maybe.just(1).filter(filterer) == Maybe.nothing()
    assert Maybe.just(2).filter(filterer) == Maybe.just(2)
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:15:14.844836
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: a > 0) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda a: a > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:15:19.288433
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

# Unit test method map of class Maybe

# Generated at 2022-06-12 05:15:22.880532
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just = Maybe.just(3)
    nothing = Maybe.nothing()

    assert just == just
    assert not just == nothing
    assert not nothing == just
    assert nothing == nothing



# Generated at 2022-06-12 05:15:31.852812
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:39.901964
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    :returns: True if test passes, raises AssertionError otherwise
    :rtype: Boolean
    """
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0

    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.just(2).filter(is_odd) == Maybe.nothing()

    assert Maybe.nothing().filter(is_even) == Maybe.nothing()

    return True


# Generated at 2022-06-12 05:15:47.796076
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Check correct behaviour
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.just(1) == Maybe.just(1)

    # Check wrong behaviour
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('test') != Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just('test')
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:15:50.334260
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just(42).to_lazy()
    assert lazy.get() == 42

# Generated at 2022-06-12 05:15:52.697526
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    value = 1
    maybe = Maybe.just(value)
    other = Maybe.just(value)

    # When
    result = maybe.__eq__(other)

    # Then
    assert result


# Generated at 2022-06-12 05:15:55.399718
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just("test") != Maybe.nothing()


# Generated at 2022-06-12 05:15:58.959109
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:16:01.200926
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(12)
    assert m == m
    assert m == Maybe.just(12)



# Generated at 2022-06-12 05:16:05.587412
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(None, True) == Maybe(None, True)
    # value is different
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(None, True) != Maybe(None, True)


# Generated at 2022-06-12 05:16:12.716587
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe(1, False) is False
    assert Maybe(1, False) == Maybe(1, True) is False
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) == Maybe(2, False) is False
    assert Maybe(1, False) != Maybe(1, False) is False



# Generated at 2022-06-12 05:16:24.288319
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert (Maybe.just(0).filter(lambda x: x > 0) != Maybe.just(0))

    assert Maybe.just(12).filter(lambda x: x < 100) == Maybe.just(12)
    assert (Maybe.just(12).filter(lambda x: x < 100) != Maybe.just(10))



# Generated at 2022-06-12 05:16:30.225378
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert (Maybe.just(1) == Maybe.just(1)) is True
    assert (Maybe.just(2) == Maybe.just(1)) is False
    assert (Maybe.just(1) == Maybe.nothing()) is False
    assert (Maybe.nothing() == Maybe.nothing()) is True



# Generated at 2022-06-12 05:16:33.459937
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:16:38.026619
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:16:43.720299
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    function_to_call = lambda x: x > 3

    # failed filter
    assert (Maybe.just(1).filter(function_to_call)) == (Maybe.nothing())

    # successful filter
    assert (Maybe.just(5).filter(function_to_call)) == (Maybe.just(5))

    # empty filter
    assert (Maybe.nothing().filter(function_to_call)) == (Maybe.nothing())

# Generated at 2022-06-12 05:16:47.845963
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x == 4) == Maybe.just(4)
    assert Maybe.just(5).filter(lambda x: x == 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 4) == Maybe.nothing()


# Generated at 2022-06-12 05:16:52.614177
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0).value == 4
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:16:57.218552
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0).value == 1
    assert Maybe.just(1).filter(lambda x: x < 0).is_nothing
    assert Maybe.nothing().filter(lambda x: x < 0).is_nothing


# Generated at 2022-06-12 05:17:02.468697
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(30).filter(lambda x: x > 10) == Maybe.just(30)
    assert Maybe.just(30).filter(lambda x: x > 40) == Maybe.nothing()
    assert Maybe.just("look").filter(lambda x: len(x) > 4) == Maybe.just("look")
    assert Maybe.nothing().filter(lambda x: x > 10) == Maybe.nothing()

# Generated at 2022-06-12 05:17:08.306589
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Assert conversion from Maybe to Lazy.

    :returns: None
    """
    from pymonet.lazy import Lazy

    from pymonet.box import Box

    assert Lazy(lambda: Box(2)) == Maybe.just(2).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-12 05:17:27.894053
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(23).filter(lambda x: x < 24) == Maybe.just(23)
    assert Maybe.just(23).filter(lambda x: x < 99) == Maybe.just(23)
    assert Maybe.just(23).filter(lambda x: x > 99) == Maybe.nothing()
    assert Maybe.just(23).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 99) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 99) == Maybe.nothing()



# Generated at 2022-06-12 05:17:33.892657
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    Defines Maybe[int] and passed filterer which allows even numbers and checks that
    filterer returns correct Maybe values.
    """
    from test_monads import test_Maybe_filter_int, test_Maybe_filter_string

    maybe = Maybe.just(10)
    test_Maybe_filter_int(maybe)
    maybe = Maybe.just(11)
    test_Maybe_filter_int(maybe)
    test_Maybe_filter_string(maybe)

# Generated at 2022-06-12 05:17:38.070716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5) \
        .to_lazy() \
        .eval() == 5

    assert Maybe.nothing() \
        .to_lazy() \
        .eval() is None


# Generated at 2022-06-12 05:17:41.956332
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.just(0).filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-12 05:17:47.467328
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(4)
    assert m1.filter(lambda x: x < 5) == Maybe.just(4)
    m2 = Maybe.just(4)
    assert m2.filter(lambda x: x < 4) != Maybe.just(4)
    m3 = Maybe.nothing()
    assert m3.filter(lambda x: x < 5) == Maybe.nothing()

# Generated at 2022-06-12 05:17:52.605736
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().get() == 1
    assert Maybe.just(1).to_lazy().map(lambda x: x + 1).get() == 2
    assert Maybe.nothing().to_lazy().get() is None
    assert Maybe.nothing().to_lazy().map(lambda x: x + 1).get() is None


# Generated at 2022-06-12 05:17:56.580407
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe.nothing()
    assert Maybe(1, False) != None


# Generated at 2022-06-12 05:18:00.359634
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:18:08.916457
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()

    assert Maybe.just('x').filter(lambda x: x == 'x') == Maybe.just('x')
    assert Maybe.just('y').filter(lambda x: x == 'x') == Maybe.nothing()

    assert Maybe.just(None).filter(lambda x: x is None) == Maybe.just(None)
    assert Maybe.just(None).filter(lambda x: x is False) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()

# Generated at 2022-06-12 05:18:14.013943
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:18:27.935166
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:18:31.540464
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), 'Maybe should be equal'
    assert Maybe.nothing() == Maybe.nothing(), 'Maybe should be equal'
    assert Maybe.just(1) != Maybe.nothing(), 'Maybe should not be equal'



# Generated at 2022-06-12 05:18:34.316106
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(-1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()

if __name__ == "__main__":
    test_Maybe_filter()

# Generated at 2022-06-12 05:18:38.033129
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda value: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: True) == Maybe.nothing()

    assert Maybe.just(2).filter(lambda value: value > 1) == Maybe.just(2)
    assert Maybe.just(1).filter(lambda value: value > 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda value: value > 2) == Maybe.nothing()


# Generated at 2022-06-12 05:18:45.033073
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy

    lazy1 = Maybe(10, False).to_lazy()
    lazy2 = Maybe(None, True).to_lazy()
    assert isinstance(lazy1, Lazy)
    assert isinstance(lazy2, Lazy)
    assert lazy1.value() == 10
    assert lazy2.value() is None


# Generated at 2022-06-12 05:18:49.713825
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.just(1).filter(lambda x: x > 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 3) == Maybe.nothing()



# Generated at 2022-06-12 05:18:53.610085
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(10)
    assert maybe.filter(lambda x: x % 2 == 0) == Maybe.just(10)
    assert maybe.filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:18:59.238549
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(None, True)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe(1, False) != Maybe(2, False)



# Generated at 2022-06-12 05:19:04.518983
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False).__eq__(Maybe(1, False))
    assert Maybe(1, True).__eq__(Maybe(1, True))
    assert Maybe(1, False).__eq__(Maybe(1, True))
    assert not Maybe(1, False).__eq__(Maybe(2, False))
    assert not Maybe(1, False).__eq__(Maybe(2, True))
    assert not Maybe(1, False).__eq__(None)


# Generated at 2022-06-12 05:19:09.253594
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != True


# Generated at 2022-06-12 05:19:21.772335
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:19:27.746106
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(x):
        return x % 2 == 0

    assert Maybe.just(1).filter(is_even).is_nothing == True
    assert Maybe.just(2).filter(is_even).is_nothing == False
    assert Maybe.just(2).filter(is_even).value == 2
    assert Maybe.nothing().filter(is_even).is_nothing == True



# Generated at 2022-06-12 05:19:32.474068
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x < 2) == Maybe.nothing()


# Generated at 2022-06-12 05:19:34.819547
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert isinstance(Maybe.just(10).to_lazy(), Lazy)
    assert isinstance(Maybe.nothing().to_lazy(), Lazy)

# Generated at 2022-06-12 05:19:38.440957
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x == 'a') == Maybe.nothing()
    assert Maybe.just('a').filter(lambda x: x == 'a') == Maybe.just('a')
    assert Maybe.just('b').filter(lambda x: x == 'a') == Maybe.nothing()


# Generated at 2022-06-12 05:19:41.524635
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    result = Maybe.just(10) \
        .filter(lambda value: value == 10) \
        .filter(lambda value: True) \
        .filter(lambda value: False)

    assert result == Maybe.nothing()

# Generated at 2022-06-12 05:19:48.290086
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """Tests for method filter of class Maybe."""
    assert Maybe.just(1).filter(lambda x: x < 2) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-12 05:19:55.640591
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    result_of_filter_empty_maybe = Maybe.nothing().filter(lambda value: True)
    result_of_filter_not_empty_maybe = Maybe.just(10).filter(lambda value: value > 5)
    result_of_filter_not_empty_non_satisfied_maybe = Maybe.just(10).filter(lambda value: value > 15)

    empty_maybe_should_return_empty_maybe = Maybe.nothing() == result_of_filter_empty_maybe
    not_empty_maybe_should_return_copy_of_maybe = Maybe.just(10) == result_of_filter_not_empty_maybe
    non_satisfied_not_empty_maybe_should_return_empty_maybe = Maybe.nothing() == result_of_filter_not_empty_non_satisfied_maybe

    assert empty_

# Generated at 2022-06-12 05:19:58.920791
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x == 5) == Maybe.just(5)

    assert Maybe.nothing().filter(lambda x: x > 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 3) == Maybe.nothing()


# Generated at 2022-06-12 05:20:03.635083
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(None).filter(lambda x: True) == Maybe.just(None)
    assert Maybe.just(None).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: 1 <= x <= 5) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:20:19.378902
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for filter method of Maybe class.
    """
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:20:24.503287
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe

    maybe_1 = Maybe.just(1)

    assert maybe_1.filter(lambda x: x > 1) == Maybe.nothing()
    assert maybe_1.filter(lambda x: x < 1) == Maybe.nothing()
    assert maybe_1.filter(lambda x: x == 1) == Maybe.just(1)

    maybe_nothing = Maybe.nothing()

    assert maybe_nothing.filter(None) == Maybe.nothing()


# Generated at 2022-06-12 05:20:31.945114
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0).to_box() == Box(None)
    assert Maybe.just(1).filter(lambda x: x % 2 == 1).to_box() == Box(1)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).to_box() == Box(None)
    assert Maybe.nothing().filter(lambda x: x % 2 == 1).to_box() == Box(None)



# Generated at 2022-06-12 05:20:37.100635
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(2)
    filter_result = maybe.filter(lambda v: v % 2 == 0)
    assert filter_result == Maybe.just(2)

    filter_result = maybe.filter(lambda v: 0 > v)
    assert filter_result == Maybe.nothing()

    filter_result = maybe.filter(lambda v: 0 > v, Maybe.just(Lazy(lambda: 3)))
    assert filter_result == Maybe.just(Lazy(lambda: 3))


# Generated at 2022-06-12 05:20:40.479665
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)


# Generated at 2022-06-12 05:20:44.397446
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    m = Maybe.just(1)

    # WHEN
    result = m.filter(lambda x: x < 3)

    # THEN
    assert result == Maybe(1, False)
    assert result.value == 1


# Generated at 2022-06-12 05:20:46.926081
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe = Maybe.just(1).to_lazy()
    assert isinstance(maybe, Lazy)



# Generated at 2022-06-12 05:20:51.936344
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    m1 = Maybe.just(None)
    m2 = Maybe.just(1)
    m3 = Maybe.nothing()

    assert m1.filter(lambda v: True) is Maybe.just(None)
    assert m1.filter(lambda v: False) is Maybe.nothing()

    assert m2.filter(lambda v: True) is Maybe.just(1)
    assert m2.filter(lambda v: False) is Maybe.nothing()

    assert m3.filter(lambda v: True) is Maybe.nothing()
    assert m3.filter(lambda v: False) is Maybe.nothing()


# Generated at 2022-06-12 05:20:55.163593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(None).filter(lambda x: x is None) == Maybe.just(None)
    assert Maybe.just(None).filter(lambda x: x is not None) == Maybe.nothing()

# Generated at 2022-06-12 05:21:06.175568
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # if Maybe is empty and filterer returns True
    func_that_returns_true = lambda x: True
    maybe = Maybe.nothing()
    assert maybe.filter(func_that_returns_true) == Maybe.nothing()

    # if Maybe is empty and filterer returns False
    func_that_returns_false = lambda x: False
    maybe = Maybe.nothing()
    assert maybe.filter(func_that_returns_false) == Maybe.nothing()

    # if Maybe is not empty and filterer returns True
    func_that_returns_true = lambda x: True
    maybe = Maybe.just(1)
    assert maybe.filter(func_that_returns_true) == Maybe.just(1)

    # if Maybe is not empty and filterer returns False
    func_that_returns_false