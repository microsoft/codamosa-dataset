

# Generated at 2022-06-12 05:11:05.525564
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 1).is_nothing
    assert Maybe.just(1).filter(lambda x: x % 2 == 1) == Maybe.just(1)

# Generated at 2022-06-12 05:11:11.187135
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert_that(
        Maybe.just(42),
        equal_to(Maybe.just(42))
    )
    assert_that(
        Maybe.just('hello'),
        not_(equal_to(Maybe.just('world')))
    )
    assert_that(
        Maybe.nothing(),
        equal_to(Maybe.nothing())
    )
    assert_that(
        Maybe.nothing(),
        not_(equal_to(Maybe.just('world')))
    )


# Unit tests for classmethods of class Maybe

# Generated at 2022-06-12 05:11:16.210695
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    x = Lazy(lambda: 2)
    y = Maybe.just(3)
    assert y.map(lambda a: a + 2).fmap(lambda a: a * 2).to_lazy() == x



# Generated at 2022-06-12 05:11:23.105456
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Monad.unit(Try).bind(Maybe.just(1).to_lazy()).__class__ == Try(1, True)
    assert Monad.unit(Validation).bind(Maybe.just(1).to_lazy()).__class__ == Validation.success(1)



# Generated at 2022-06-12 05:11:32.365375
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(None).filter(lambda x: x is None) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x < 10) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 5) == Maybe.nothing()
    assert Maybe.just("").filter(lambda x: x == "") == Maybe.nothing()

# Generated at 2022-06-12 05:11:36.739287
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:11:46.130108
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    some = Maybe.just(2)
    assert some.filter(lambda a: a % 2 == 0).get_or_else(1) == 2
    assert some.filter(lambda a: a % 2 == 1).get_or_else(0) == 0
    none = Maybe.nothing()
    assert none.filter(lambda a: a % 2 == 0).get_or_else(0) == 0
    assert some.filter(lambda a: a % 2 == 1).get_or_else(1) == 1



# Generated at 2022-06-12 05:11:53.126798
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def check_maybe(value: Any, is_nothing: bool) -> bool:
        return Maybe(value, is_nothing) == Maybe(value, is_nothing)
    assert check_maybe(2, False)
    assert not check_maybe(2, True)
    assert check_maybe(None, True)
    assert not check_maybe(None, False)
    assert check_maybe("some text", False)
    assert not check_maybe("some text", True)


# Generated at 2022-06-12 05:11:59.012208
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.test_util import assert_comparable

    assert_comparable(
        Maybe.just(1).filter(lambda x: x < 10),
        Maybe.nothing()
    )

    assert_comparable(
        Maybe.just(10).filter(lambda x: x < 10),
        Maybe.just(10)
    )

    assert_comparable(
        Maybe.nothing().filter(lambda x: x < 10),
        Maybe.nothing()
    )

# Generated at 2022-06-12 05:12:02.133458
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x == 4) == Maybe.just(4)
    assert Maybe.just(4).filter(lambda x: x == 5) == Maybe.nothing()


# Generated at 2022-06-12 05:12:09.801377
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:12:15.708150
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert(Maybe.just(1) == Maybe.just(1))
    assert(Maybe.just(2) != Maybe.just(1))
    assert(Maybe.nothing() == Maybe.nothing())
    assert(Maybe.nothing() != Maybe.just(1))
    assert(Maybe.just(1) != Maybe.nothing())


# Generated at 2022-06-12 05:12:18.992645
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    x = Maybe(1, False)

    f = x.to_lazy().value()

    assert f() == 1



# Generated at 2022-06-12 05:12:23.847555
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe.just(10)
    assert Maybe.just(10) == Maybe.just(10)
    assert not Maybe.just(10) == Maybe.just([])
    assert Maybe(None, False) == Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(None)
    assert not Maybe.just(None) == Maybe.just([])



# Generated at 2022-06-12 05:12:34.760580
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad import Monad
    from pymonet.maybe import Maybe, Box, Just, Nothing

    assert Maybe(42, False) == Just(42)
    assert Box(42) == Just(42)
    assert Just(42) == Just(42)
    assert Just(42) == Maybe(42, False)
    assert Maybe(42, False) == Maybe(42, False)
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) == Maybe(42, False)
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe

# Generated at 2022-06-12 05:12:40.676350
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    mv = Maybe.just(2)

    res = mv.filter(lambda x: x % 2 != 0)
    assert res == Maybe.nothing()

    res = mv.filter(lambda x: x % 2 == 0)
    assert res == Maybe.just(2)

    mv = Maybe.nothing()
    res = mv.filter(lambda x: x % 2 != 0)
    assert res == Maybe.nothing()



# Generated at 2022-06-12 05:12:52.078856
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()

    assert Maybe.just(1).map(lambda x: x + 1) == Maybe.just(2)
    assert Maybe.nothing().map(lambda x: x + 1) == Maybe.nothing()

    assert Maybe.just(1).ap(Maybe.just(lambda x: x + 1)) == Maybe.just

# Generated at 2022-06-12 05:12:57.558489
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:13:06.416474
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(2, False) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(2, True) != Maybe(1, True)
    assert Maybe(2, True) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(2, False) != Maybe(2, True)



# Generated at 2022-06-12 05:13:11.602425
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1) == Maybe.just(1).filter(lambda a: a == 1)
    assert Maybe.nothing() == Maybe.just(1).filter(lambda a: a == 2)
    assert Maybe.nothing() == Maybe.just(1).filter(lambda a: False)
    assert Maybe.nothing() == Maybe.nothing().filter(lambda a: a == 1)

# Unit tests for method get_or_else of class Maybe



# Generated at 2022-06-12 05:13:18.080386
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    def div(x, y):
        return x / y

    def call():
        return div(1, 0)

    assert Maybe.just(div(1, 0)).to_lazy().call() == 1

    assert Maybe.just(call()).to_lazy().call() == 1

    assert Maybe.just(div(2, 1)).to_lazy().call() == 2



# Generated at 2022-06-12 05:13:22.887267
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.functions import _

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:27.325898
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()

    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)

    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:13:32.230614
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe(2, False) != Maybe(0, False)


# Generated at 2022-06-12 05:13:36.161067
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:13:37.605240
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:39.612078
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:13:43.074945
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:13:47.759113
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    import pytest

    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Left(1)
    assert Maybe(1, True) == Box(None)
    assert Maybe(1, False) == Box(1)
    assert Maybe(1, False) == Lazy(lambda: 1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.nothing() is False
    assert Maybe.just(1) == Lazy(lambda: 1)



# Generated at 2022-06-12 05:13:53.243442
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(15) == Maybe.just(15)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(15) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(15)
    assert Maybe.just(15) != Maybe.just(16)
    assert Maybe.just(15) != Maybe.just(14)


# Generated at 2022-06-12 05:14:04.611713
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.

    :returns: nothing
    :rtype: None
    """
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:14:16.543696
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Maybe.just(8).filter(lambda x: x % 2 == 0) == Maybe.just(8)
    assert Maybe.just(9).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()

    assert type(Maybe.just(8).filter(lambda x: x % 2 == 0).to_box()) == Box
    assert type(Maybe.just(8).filter(lambda x: x % 2 == 0).to_either()) == Right

# Generated at 2022-06-12 05:14:23.174217
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """    
    unit test for method __eq__ of class Maybe.
    """
    from pymonet.box import Box

    nothing = Maybe.nothing()
    assert nothing == nothing
    assert not nothing == Box(1)

    just_value = Maybe.just(1)
    assert just_value == just_value
    assert not just_value == Box(1)
    assert not just_value == nothing

    just_None = Maybe.just(None)
    assert just_None == just_None
    assert not just_None == Box(None)
    assert not just_None == nothing
    assert not just_None == just_value


# Generated at 2022-06-12 05:14:25.500449
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Maybe.just(3).to_lazy()



# Generated at 2022-06-12 05:14:29.528567
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Maybe
    from pymonet.monad_try import Try

    maybe = Maybe.just(Try.success(Lazy(lambda: 1)))
    assert maybe.to_lazy().get() == 1

# Generated at 2022-06-12 05:14:37.565114
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    import pytest

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)

    # Unit test with Maybe type
    assert Maybe.just(1) != Maybe.just(2)

    # Unit test with Box type
    assert Maybe.just(1) != Box(1)

    # Unit test with Either type
    assert Maybe.nothing() != Either.right(1)

    # Unit test with Try type
    assert Maybe.just(1) != Try.success(1)

    # Unit test with Validation type

# Generated at 2022-06-12 05:14:41.547637
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(5)
    m2 = Maybe.nothing()

    assert m1 != m2
    assert m1 == Maybe.just(5)
    assert m2 == Maybe.nothing()



# Generated at 2022-06-12 05:14:45.095457
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:14:50.118116
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('str') == Maybe.just('str')
    assert Maybe.just('str') != Maybe.just('')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just('')



# Generated at 2022-06-12 05:14:52.833346
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe.just(10)
    maybe2 = Maybe.just(10)
    maybe3 = Maybe.just(15)

    assert maybe1 == maybe2
    assert not maybe1 == maybe3



# Generated at 2022-06-12 05:15:02.227665
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(None, False) != Maybe(None, True)
    assert Maybe(None, True) != Maybe(1, False)


# Generated at 2022-06-12 05:15:11.939893
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3.14) == Maybe.just(3.14)
    assert Maybe.just('3') == Maybe.just('3')
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(True) != Maybe.just(False)
    assert Maybe.just(True) != Maybe.just(None)
    assert Maybe.just(True) != Maybe.just(3)
    assert Maybe.just(True) != Maybe.just(3.14)
    assert Maybe.just(True) != Maybe.just('3')
    assert Maybe.just

# Generated at 2022-06-12 05:15:18.367317
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda _: True).get_or_else(3) == 1
    assert Maybe.just(1).filter(lambda _: False).get_or_else(3) == 3
    assert Maybe.nothing().filter(lambda _: True).get_or_else(3) == 3
    assert Maybe.nothing().filter(lambda _: False).get_or_else(3) == 3



# Generated at 2022-06-12 05:15:20.498166
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    import pytest

    assert Maybe(1, False) == Maybe.just(1)



# Generated at 2022-06-12 05:15:30.897704
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just(2).map(lambda x: x ** 2).filter(lambda x: x > 3) == Maybe.just(4)
    assert Maybe.just(2).map(lambda x: x ** 2).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:15:36.725923
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    maybe: Maybe[int] = Maybe.just(1)
    assert maybe.to_lazy() == Lazy(lambda: 1)
    assert maybe.to_lazy().value() == 1

    maybe: Maybe[int] = Maybe.nothing()
    assert maybe.to_lazy() == Lazy(lambda: None)
    assert maybe.to_lazy().value() is None



# Generated at 2022-06-12 05:15:39.457256
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(10)



# Generated at 2022-06-12 05:15:46.118744
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe(5, False)

    maybe_none = maybe.filter(lambda x: x == 4)

    assert maybe_none.is_nothing
    assert maybe_none.get_or_else(None) is None

    maybe_some = maybe.filter(lambda x: x == 5)

    assert not maybe_some.is_nothing
    assert maybe_some.get_or_else(None) is 5


# Generated at 2022-06-12 05:15:49.043459
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(12) == Maybe.just(12)
    assert not (Maybe.just(12) == Maybe.just(8))
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:15:51.733394
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    nothing = Maybe.nothing()
    assert nothing == Maybe.nothing()

    some = Maybe.just(0)
    assert some == Maybe.just(0)

    assert some != Maybe.just(1)
    assert some != Maybe.nothing()


# Generated at 2022-06-12 05:16:06.596118
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.nothing() != None
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-12 05:16:10.833227
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:16:18.876470
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value1 = 1
    value2 = 'a'
    value3 = {'1': 1, '2': 2}
    assert Maybe.just(value1) == Maybe.just(value1)
    assert Maybe.just(value2) == Maybe.just(value2)
    assert Maybe.just(value3) == Maybe.just(value3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(value1) != Maybe.just(value2)
    assert Maybe.just(value1) != Maybe.just(value3)
    assert Maybe.just(value1) != Maybe.nothing()
    assert Maybe.just(value2) != Maybe.nothing()
    assert Maybe.just(value3) != Maybe.nothing()


# Generated at 2022-06-12 05:16:26.995438
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.just(4) != Maybe.nothing()
    assert Maybe.just([]) != []
    assert Maybe.just(Maybe.just(4)) == Maybe.just(Maybe.just(4))
    assert Maybe.just([1,2]) == Maybe.just([1,2])
    assert Maybe.just([1,2]) != Maybe.just([1,2,3])
    assert Maybe.just([1,2]) != [1,2]
    assert Maybe.just(Maybe.just([])) == Maybe.just(Maybe.just([]))

# Generated at 2022-06-12 05:16:33.278445
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda v: v == 5) == Maybe.just(5)
    assert Maybe(5, False).filter(lambda v: v == 4) == Maybe.nothing()
    assert Maybe(5, True).filter(lambda v: v == 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v == 4) == Maybe.nothing()



# Generated at 2022-06-12 05:16:38.669302
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:16:44.603794
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.nothing() != 1
    assert Maybe.just(6) != 7


# Generated at 2022-06-12 05:16:48.803384
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != 2
    assert 2 != Maybe.nothing()



# Generated at 2022-06-12 05:16:54.854839
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(8).filter(lambda x: x == 8) == Maybe(8, False)
    assert Maybe.just(8).filter(lambda x: x == 5) == Maybe(None, True)
    assert Maybe.nothing().filter(lambda x: x) == Maybe(None, True)
    assert Maybe.nothing().filter(lambda x: x == 5) == Maybe(None, True)

# Generated at 2022-06-12 05:17:01.445953
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try

    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(42) != Try.success(42)
    assert Maybe.nothing() != Try.failure(None)



# Generated at 2022-06-12 05:17:14.659029
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe.just(Box(5)).to_lazy() == Lazy(lambda: Box(5))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:17:19.412420
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:17:27.221400
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Box(1)
    assert Maybe.nothing() == Box(None)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:17:29.669827
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not (Maybe.just(1) == Maybe.nothing())
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:17:37.556626
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) == Maybe.just(0)
    assert Maybe.just(None) == Maybe.just(True)
    assert Maybe.just(None) == Maybe.just(False)
    assert Maybe.just(None) == Maybe.just('')
    assert Maybe.just(None) == Maybe.just(object)
    assert Maybe.just(None) == Maybe.just(lambda : 100)
    assert Maybe.just(None) == Maybe.just(lambda x: x)
    assert Maybe.just(None) == Maybe.just(lambda x, y: x)
    assert Maybe.just(None) == Maybe.just(lambda x, y=None: x)
    assert Maybe.just(None) == Maybe.just(lambda x, *args: x)


# Generated at 2022-06-12 05:17:40.312897
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()

# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:17:48.644173
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just({}) == Maybe.just({})
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:52.222649
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:56.922259
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:18:02.049673
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = 10
    maybe = Maybe[int](test_value, False)
    assert maybe.filter(lambda value: value < test_value + 1) == maybe
    assert maybe.filter(lambda value: value == test_value + 1) == Maybe.nothing()
    assert maybe.filter(lambda value: False) == Maybe.nothing()

# Generated at 2022-06-12 05:18:22.744217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()



# Generated at 2022-06-12 05:18:32.560010
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Maybe.just(1).filter(lambda x: x % 2 == 0).to_box() == Box(None)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).to_box() == Box(None)
    assert Maybe.just(2).filter(lambda x: x % 2 == 0).to_box() == Box(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe

# Generated at 2022-06-12 05:18:41.482456
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.writer import Writer
    from pymonet.writer.writer import identity

    maybe = Maybe(42, False)

    assert maybe.to_lazy() == Lazy(lambda: 42)

    maybe = maybe.bind(lambda x: Writer(x, 'is number'))

    assert maybe.to_lazy() == Lazy(lambda: Writer(42, 'is number'))

    maybe = maybe.bind(lambda x: Writer(x, 'is number one more time'))

    assert maybe.to_lazy() == Lazy(lambda: Writer(42, 'is number one more time'))

    maybe = maybe.bind(Writer.fmap(lambda x: x * 2))


# Generated at 2022-06-12 05:18:45.889857
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert repr(Maybe(1, False).to_lazy()) == 'Lazy monad: Function() -> 1'
    assert repr(Maybe(None, True).to_lazy()) == 'Lazy monad: Function() -> None'


# Generated at 2022-06-12 05:18:54.221404
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    # Case with empty Maybe and returns True (filter returns same Maybe)
    m = Maybe.nothing()
    assert m.filter(lambda x: True) == Maybe.nothing()

    # Case with not empty Maybe and returns True (filter returns same Maybe)
    m = Maybe.just(2)
    assert m.filter(lambda x: True) == Maybe.just(2)

    # Case with not empty Maybe and returns False (filter returns empty Maybe)
    m = Maybe.just(2)
    assert m.filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:19:02.188382
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(42, False) == Maybe(42, False)
    assert Maybe(24, True) == Maybe(24, True)
    assert Maybe(24, False) == Maybe(24, False)
    assert Maybe(42, True) == Maybe(42, True)
    assert Maybe(24, True) != Maybe(42, True)
    assert Maybe(24, False) != Maybe(42, False)
    assert Maybe(24, True) != Maybe(42, False)
    assert Maybe(24, False) != Maybe(42, True)



# Generated at 2022-06-12 05:19:07.462826
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:19:15.125240
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_a = Maybe.just(1)
    maybe_b = Maybe.just(2)
    maybe_c = Maybe.nothing()
    assert maybe_a == Maybe.just(1)
    assert maybe_a != Maybe.just(2)
    assert maybe_b != Maybe.just(1)
    assert maybe_b != Maybe.just(3)
    assert maybe_c == Maybe.nothing()
    assert maybe_a != maybe_b
    assert maybe_b != maybe_c
    assert maybe_a != maybe_c


# Generated at 2022-06-12 05:19:21.157620
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Arrange
    just_2 = Maybe.just(2)
    just_3 = Maybe.just(3)
    just_2_again = Maybe.just(2)
    nothing = Maybe.nothing()

    # Act

    # Assert
    assert maybe_not_equal(just_2, just_3)
    assert maybe_not_equal(just_2, nothing)
    assert maybe_not_equal(nothing, just_3)
    assert maybe_equal(just_2, just_2_again)
    assert maybe_equal(nothing, nothing)



# Generated at 2022-06-12 05:19:32.521752
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_with_proper_value = Maybe.just(1)
    maybe_with_proper_value.filter(lambda v: v > 0).get_or_else(2) == maybe_with_proper_value.get_or_else(2)
    maybe_with_proper_value.filter(lambda v: v > 0).to_box() == maybe_with_proper_value.to_box()
    maybe_with_proper_value.filter(lambda v: v > 0).to_either() == maybe_with_proper_value.to_either()
    maybe_with_proper_value.filter(lambda v: v > 0).to_try().is_success() == maybe_with_proper_value.to_try().is_success()

# Generated at 2022-06-12 05:20:14.195456
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def _filterer(x: int) -> bool:
        return x < 2

    assert Maybe.just(1).filter(_filterer) == Maybe.just(1)
    assert Maybe.just(3).filter(_filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(_filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:20:18.225164
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-12 05:20:22.062832
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()

# Generated at 2022-06-12 05:20:24.468774
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)



# Generated at 2022-06-12 05:20:30.629889
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    value = 1
    maybe = Maybe.just(value)
    lazy = Lazy(lambda: 1)
    assert maybe.to_lazy() == lazy

    maybe = Maybe.nothing()
    lazy = Lazy(lambda: None)
    assert maybe.to_lazy() == lazy

# Generated at 2022-06-12 05:20:36.040610
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(2, False)


# Generated at 2022-06-12 05:20:39.245548
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(5).to_lazy().evaluate() == 5
    assert Maybe.nothing().to_lazy().evaluate() is None

# Generated at 2022-06-12 05:20:44.145217
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:47.576594
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:20:53.743445
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just('3') == Maybe.just('3')
    assert Maybe.just(3) != Maybe.just('3')
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)
    assert Maybe.just(3) == Maybe.just(3)
