

# Generated at 2022-06-12 05:11:08.033089
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(2)
    assert Maybe.just('test1') != Maybe.just('test')


# Generated at 2022-06-12 05:11:11.297135
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:11:15.439699
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:11:20.567850
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('value').__eq__(Maybe.just('value'))
    assert Maybe.just('value').__eq__(Maybe.just('other value')) == False
    assert Maybe.nothing().__eq__(Maybe.just('value')) == False
    assert Maybe.just('value').__eq__(Maybe.nothing()) == False
    assert Maybe.nothing().__eq__(Maybe.nothing())


# Generated at 2022-06-12 05:11:23.645265
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("a") == Maybe.just("a")
    assert Maybe.just("a") != Maybe.just("b")
    assert Maybe.just("a") != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:31.034270
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filter method of Maybe class.
    """
    assert Maybe.just(1).filter(lambda _: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()



# Generated at 2022-06-12 05:11:34.836680
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_with_false = Maybe.just(False)
    maybe_with_true = Maybe.just(True)

    assert(maybe_with_true.filter(bool) == maybe_with_true)
    assert(maybe_with_false.filter(bool) == Maybe.nothing())
    assert(maybe_with_true == Maybe.just(True))
    assert(maybe_with_false == Maybe.just(False))

# Generated at 2022-06-12 05:11:40.371506
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not (Maybe.just(1) == Maybe.just(2))
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert not (Maybe.nothing() == Maybe(None, False))
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe(None, True)
    assert not (Maybe.nothing() == Maybe(None, False))


# Generated at 2022-06-12 05:11:43.691769
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # create function that returns True when actual value is NotImplemented
    filterer = lambda x: x is NotImplemented

    # create Maybe that contains NotImplemented
    maybe = Maybe.just(NotImplemented)
    assert maybe.filter(filterer).value is NotImplemented

    # create Maybe that contains None
    maybe = Maybe.just(None)
    assert maybe.filter(filterer).is_nothing == True

# Generated at 2022-06-12 05:11:50.522909
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(10)
    m2 = Maybe.just(10)
    m3 = Maybe.just(20)
    m4 = Maybe.nothing()
    m5 = Maybe.nothing()

    assert (m1 == m2)
    assert (m1 != m3)
    assert (m4 == m5)
    assert (m1 != m4)

    assert (m1 != m3)



# Generated at 2022-06-12 05:12:01.371724
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test import TestException
    from pymonet.monad_test_util import TestUtil

    def filterer(x):
        return x == 42

    maybe = Maybe.just(42)
    TestUtil.test_object_method(
        test_case=TestUtil,
        maybe=maybe,
        method_name='filter',
        method_arguments=[filterer],
        expected_to_be_same=maybe,
        expected_f_to_be_called=False,
        expected_to_be_called_times=0,
        expected_f_called_with=None,
        test_name='Run Maybe.filter with filterer which always will return True'
    )

    maybe = Maybe.nothing()

# Generated at 2022-06-12 05:12:09.514418
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_lazy import test_Lazy_unit
    from pymonet.monad_lazy import Lazy
    from pymonet.maybe import Maybe

    test_Lazy_unit(Lazy(lambda: 1), lambda: 1, lambda: None)

    assert(Maybe.nothing().to_lazy().map(lambda x: x + 1).value() == None)
    assert(Maybe.just(2).to_lazy().map(lambda x: x + 1).value() == 3)



# Generated at 2022-06-12 05:12:14.406172
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, False).to_lazy() == Lazy(lambda: None)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:12:19.898572
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:12:24.411156
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # empty Maybe
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()

    # not empty Maybe
    assert Maybe.just(2).filter(lambda a: a == 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda a: a < 2) == Maybe.nothing()



# Generated at 2022-06-12 05:12:32.584472
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # None and true
    assert Maybe.nothing() == Maybe.nothing()

    # None and false
    assert not Maybe.nothing() == Maybe.just(1)

    # None and none
    assert Maybe.nothing() == Maybe.just(None)

    # True and true
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(True) == Maybe.just(True)

    # True and false
    assert not Maybe.just(1) == Maybe.just(True)
    assert not Maybe.just(1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:36.928610
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    test_first = Maybe.just(lambda x: x * 2)
    assert test_first.to_lazy() == Lazy(lambda: lambda x: x * 2)
    test_second = Maybe.nothing()
    assert test_second.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:12:44.737872
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # when Maybe is empty and filterer returns False, return default_value
    result = Maybe.nothing().filter(lambda x: False)
    assert result == Maybe.nothing()

    # when Maybe is empty and filterer returns True, return default_value
    result = Maybe.nothing().filter(lambda x: True)
    assert result == Maybe.nothing()

    # when Maybe is not empty and filterer returns False, return default_value
    result = Maybe.just(1).filter(lambda x: False)
    assert result == Maybe.nothing()

    # when Maybe is not empty and filterer returns True, return stored value
    result = Maybe.just(2).filter(lambda x: True)
    assert result == Maybe.just(2)

    # when Maybe is not empty and filterer returns x*3 > 2, return stored value
    result

# Generated at 2022-06-12 05:12:53.147128
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda val: val == True) \
        == Maybe.just(True)
    assert Maybe.just(True).filter(lambda val: val == False) \
        == Maybe.nothing()
    assert Maybe.just(False).filter(lambda val: val == True) \
        == Maybe.nothing()
    assert Maybe.just(False).filter(lambda val: val == False) \
        == Maybe.just(False)
    assert Maybe.nothing().filter(lambda val: True) \
        == Maybe.nothing()
    assert Maybe.nothing().filter(lambda val: False) \
        == Maybe.nothing()



# Generated at 2022-06-12 05:12:57.838749
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x % 2 == 0) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda x: x % 2 != 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()



# Generated at 2022-06-12 05:13:08.187025
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()



# Generated at 2022-06-12 05:13:11.933953
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != 1


# Generated at 2022-06-12 05:13:17.144295
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(2) != Maybe.nothing()


# Generated at 2022-06-12 05:13:25.875572
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    import pytest

    m1 = Maybe.just({1: 1})
    m2 = Maybe.just({1: 1})

    assert m1.__eq__(m2)

    m3 = Maybe.nothing()
    m4 = Maybe.nothing()

    assert m3.__eq__(m4)

    assert not m3.__eq__(m1)
    assert not m2.__eq__(m4)
    assert not m1.__eq__(m4)

    with pytest.raises(TypeError):
        m1.__eq__(None)



# Generated at 2022-06-12 05:13:27.891184
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_a = Maybe.just(1)
    maybe_b = Maybe.just(1)
    assert maybe_a == maybe_b


# Generated at 2022-06-12 05:13:31.011967
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_odd(x):
        return x % 2 == 1

    assert Maybe.just(1).filter(is_odd) == Maybe.just(1)
    assert Maybe.just(2).filter(is_odd) == Maybe.nothing()
    assert Maybe.nothing().filter(is_odd) == Maybe.nothing()

# Generated at 2022-06-12 05:13:36.677181
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe.just(10)
    maybe2 = Maybe.just(12)
    maybe3 = Maybe.just(10)
    maybe4 = Maybe.nothing()
    maybe5 = Maybe.nothing()

    assert maybe1 != maybe2
    assert maybe1 == maybe3
    assert maybe4 != maybe2
    assert maybe4 == maybe5



# Generated at 2022-06-12 05:13:46.976801
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just([1, 2, 3, 4])
    m = m.filter(lambda x: len(x) < 10)
    m = m.filter(lambda x: len(x) % 2 == 0)
    assert m == Maybe.just([1, 2, 3, 4])

    m = Maybe.just([1, 2, 3, 4])
    m = m.filter(lambda x: len(x) > 10)
    m = m.filter(lambda x: len(x) % 2 == 0)
    assert m == Maybe.nothing()

    m = Maybe.just([1, 2, 3, 4])
    m = m.filter(lambda x: len(x) > 10)
    m = m.filter(lambda x: len(x) % 2 == 0)

# Generated at 2022-06-12 05:13:52.217268
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:13:57.391883
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    test_maybe = Maybe.just('Hello')
    lazy_maybe = test_maybe.to_lazy()
    assert lazy_maybe.is_instance(Lazy)
    assert lazy_maybe.eval() == 'Hello'

# Generated at 2022-06-12 05:14:03.634687
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)



# Generated at 2022-06-12 05:14:08.756047
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False).__eq__(Maybe(1, False))
    assert Maybe(1, True).__eq__(Maybe(1, True))
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)



# Generated at 2022-06-12 05:14:14.004248
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:14:17.796133
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)

    # Exercise
    result = m1 == m2

    # Verify
    assert result



# Generated at 2022-06-12 05:14:20.605072
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe(1, False)

    assert Maybe.nothing().__eq__(Maybe(None, True))



# Generated at 2022-06-12 05:14:30.539236
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Test when we have different type of parameters
    assert not (Maybe.just(1) == 1)

    # Test when we have same values
    assert Maybe.just(1) == Maybe.just(1)

    # Test when we have different class type and same value
    assert not (Maybe.just(1) == Some(1))

    # Test when we have same class type and nothing and some
    assert not (Maybe.just(1) == Maybe.nothing())

    # Test when we have same class type and nothing and empty
    assert Maybe.nothing() == Maybe.nothing()

    # Test when we have same class type and some and empty
    assert not (Maybe.just(1) == Maybe.just(2))



# Generated at 2022-06-12 05:14:33.539240
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.just(4)
    assert Maybe.just(5) != Maybe.nothing()


# Generated at 2022-06-12 05:14:40.884213
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(None) == Maybe.just(1)
    assert Maybe(1, False).filter(lambda x: x < 2) == Maybe.just(1)
    assert Maybe(1, False).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe(1, True).filter(lambda x: x < 1) == Maybe.nothing()


# Generated at 2022-06-12 05:14:47.344603
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet import Lazy

    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, True)

    assert Maybe(1, False) != 1
    assert Maybe(1, False) != Lazy(lambda: 1)



# Generated at 2022-06-12 05:14:51.744792
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)
    assert maybe.to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:14:59.983941
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()

# Generated at 2022-06-12 05:15:05.028020
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:15:07.506239
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.either import Right
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:15:13.198514
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:15:20.030234
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(0).filter(lambda x: x % 2 == 0) == Maybe.just(0)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:15:32.008776
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    assert maybe.to_lazy().eval() == 1

    maybe = Maybe.just(4)
    assert maybe.to_lazy().eval() == 4

    maybe = Maybe.nothing()
    assert maybe.to_lazy().eval() == None

    maybe = Maybe.just([1, 2, 3])
    assert maybe.to_lazy().eval() == [1, 2, 3]

    maybe = Maybe.just({'a': 1, 'b': 2, 'c': 3})
    assert maybe.to_lazy().eval() == {'a': 1, 'b': 2, 'c': 3}

    maybe = Maybe.just({'a': {'b': 1}, 'c': 2})

# Generated at 2022-06-12 05:15:37.185804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0).get_or_else(4) == 4
    assert Maybe.just(4).filter(lambda x: x % 2 == 0).get_or_else(4) == 4
    assert Maybe.nothing().filter(lambda x: x % 2 == 0).get_or_else(4) == 4



# Generated at 2022-06-12 05:15:48.528432
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    not_empty_maybe = Maybe.just(Box(5))
    empty_maybe = Maybe.nothing()
    lazy_not_empty_maybe = not_empty_maybe.to_lazy()
    lazy_empty_maybe = empty_maybe.to_lazy()

    assert lazy_not_empty_maybe == Lazy(lambda: Box(5))
    assert lazy_empty_maybe == Lazy(lambda: None)
    assert lazy_not_empty_maybe.value == Box(5)
    assert lazy_empty_maybe.value == None


# Generated at 2022-06-12 05:15:59.378034
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    """
    from pymonet.chain import Chain
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy
    lazy = Maybe.nothing().to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() is None
    assert Maybe.just(None).to_lazy().value() is None
    assert Maybe.just([1, 2, 3, 4]).to_lazy().value() == [1, 2, 3, 4]
    assert Maybe.just(5).to_lazy().value() == 5
    assert isinstance(Maybe.just(Chain([4, 5, 6, 7])).to_lazy(), Lazy)

# Generated at 2022-06-12 05:16:02.486354
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe(1, False).to_lazy()
    assert Lazy(lambda: None) == Maybe(None, True).to_lazy()


# Generated at 2022-06-12 05:16:15.799240
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:16:19.600325
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    assert maybe.to_lazy().evaluate() == 1

    maybe = Maybe.just(1)
    assert maybe.to_lazy().map(lambda x: x + 1).evaluate() == 2

    maybe = Maybe.nothing()
    assert maybe.to_lazy().evaluate() is None

    maybe = Maybe.nothing()
    assert maybe.to_lazy().map(lambda x: x + 1).evaluate() is None



# Generated at 2022-06-12 05:16:24.552460
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1).filter(lambda a: a > 0)
    assert maybe == Maybe.just(1)

    maybe = Maybe.just('a').filter(lambda a: a > 0)
    assert maybe == Maybe.nothing()

    maybe = Maybe.nothing().filter(lambda a: a > 0)
    assert maybe == Maybe.nothing()



# Generated at 2022-06-12 05:16:31.308841
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:16:36.587100
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(lambda x: x + 1).map(lambda x: x(1)).to_lazy().get() == 2
    assert Maybe.nothing().map(lambda x: x + 1).to_lazy().get() == None

# Generated at 2022-06-12 05:16:46.165807
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.lazy import Lazy

    # Test for empty Maybe
    assert Maybe.nothing().filter(
        lambda x: x > 1
    ) == Maybe.nothing()

    # Test for not empty Maybe with filter which returns False for value
    assert Maybe.just(1).filter(
        lambda x: x > 1
    ) == Maybe.nothing()

    # Test for not empty Maybe with filter which returns True for value
    assert Maybe.just(2).filter(
        lambda x: x > 1
    ) == Maybe.just(2)

    # Test for not empty Maybe with lazy filter which returns False for value
    assert Maybe.just(1).filter(
        Lazy(lambda x: x > 1)
    ) == Maybe.nothing()

    # Test for not empty Maybe with lazy filter which returns True for value

# Generated at 2022-06-12 05:16:51.149434
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x == 5) == Maybe.just(5)
    assert Maybe(5, False).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe(5, True).filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:16:54.853762
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """Unit test."""
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x == 3) == Maybe.nothing()


# Generated at 2022-06-12 05:17:00.729718
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    test_value = 2
    filterer = lambda x: x % 2 == 0

    assert Maybe.nothing().filter(filterer) == Maybe.nothing()
    assert Maybe.just(test_value).filter(filterer) == Maybe.just(test_value)
    assert Maybe.just(test_value + 1).filter(filterer) == Maybe.nothing()



# Generated at 2022-06-12 05:17:03.310034
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try

    maybe = Maybe.just(123)
    expected = Try(123, True)
    assert maybe.to_lazy().run_lazy() == expected


# Generated at 2022-06-12 05:17:16.797488
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try

    assert Try.unit(2).to_maybe().to_lazy().get() == 2
    assert Try.unit(None).to_maybe().to_lazy().get() == None

    assert Try.failure(ValueError('err')).to_maybe().to_lazy().get() == None



# Generated at 2022-06-12 05:17:21.585539
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe('Pymonet', False).to_lazy() == Lazy(lambda: 'Pymonet')
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:17:29.336643
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    maybe_some: Maybe[int] = Maybe.just(1)
    lazy_some: Lazy[Callable[[], int]] = maybe_some.to_lazy()
    assert lazy_some.value() == 1

    maybe_none: Maybe[None] = Maybe.nothing()
    lazy_none: Lazy[Callable[[], None]] = maybe_none.to_lazy()
    assert lazy_none.value() == None

# Generated at 2022-06-12 05:17:32.429755
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    value = 2
    lazy = Maybe[int](value, False).to_lazy()
    assert Lazy(lambda: value) == lazy



# Generated at 2022-06-12 05:17:40.529131
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for Maybe.filter method
    """
    assert Maybe.just(1).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:17:49.611444
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def double(x):
        return x * 2

    test_mapper = Maybe.just(double)

    assert test_mapper.filter(lambda x: x % 2 == 0).get_or_else(None) is not None
    assert test_mapper.filter(lambda x: x % 2 == 0).get_or_else(None)(4) == 8
    assert test_mapper.filter(lambda x: x % 2 == 1).get_or_else(None) is None
    assert test_mapper.filter(lambda x: x % 2 == 1).get_or_else(lambda : double)(4) == 8
    assert test_mapper.filter(lambda _: False).get_or_else(lambda : double)(4) == 8



# Generated at 2022-06-12 05:17:56.582317
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_just = Maybe.just('value')
    assert maybe_just.filter(lambda value: value == 'value') == Maybe.just('value')
    assert maybe_just.filter(lambda value: value == 'something') == Maybe.nothing()

    maybe_nothing = Maybe.nothing()
    assert maybe_nothing.filter(lambda value: value == 'value') == Maybe.nothing()
    assert maybe_nothing.filter(lambda value: value == 'something') == Maybe.nothing()



# Generated at 2022-06-12 05:18:02.486804
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(Box(1), False).to_lazy() == Lazy(lambda: Box(1))
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:18:05.501458
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(10).to_lazy() == Lazy(lambda: 10))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))

# Generated at 2022-06-12 05:18:09.095600
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(x: int) -> bool:
        return x == 5
    assert Maybe(5, False).filter(filterer) == Maybe.just(5)
    assert Maybe(5, True).filter(filterer) == Maybe.nothing()
    assert Maybe(6, False).filter(filterer) == Maybe.nothing()


# Generated at 2022-06-12 05:18:23.318220
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    assert Maybe.just(4).filter(lambda x: x > 2) == Maybe.just(4)
    assert Maybe.just(4).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(Box(5)).filter(lambda x: x == 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 5) == Maybe.nothing()



# Generated at 2022-06-12 05:18:32.909524
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.either import Either

    maybe = Maybe.just(1)
    assert maybe.to_lazy() == Lazy(lambda: 1)
    assert maybe.to_lazy().get() == 1
    assert maybe.to_lazy().get() == Lazy(lambda: 1).get()
    assert maybe.to_try() == Try(1, is_success=True)
    assert maybe.to_box() == Box(1)
    assert maybe.to_validation() == Validation.success(1)
    assert maybe.to_either() == Either.right(1)
    assert maybe.to_lazy().get

# Generated at 2022-06-12 05:18:37.173189
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(16)
    n = Maybe.just(13)

    def filterer(x):
        return x % 2 == 0

    assert m.filter(filterer) == Maybe.just(16)

    assert n.filter(filterer) == Maybe.nothing()



# Generated at 2022-06-12 05:18:43.036719
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    just_value = Maybe.just(3)
    nothing = Maybe.nothing()

    assert just_value.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert just_value.filter(lambda x: x % 2 == 1) == Maybe.just(3)
    assert nothing.filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:18:53.234246
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    nothing = Maybe.nothing()
    just_num = Maybe.just(1)
    just_str = Maybe.just('test')
    just_list = Maybe.just([])
    just_dict = Maybe.just({})

    # When Maybe is empty
    assert nothing.filter(lambda num: num == 1) is Maybe.nothing()

    # When Maybe is not empty
    assert just_num.filter(lambda num: num == 1) == Maybe(1, False)

    assert just_str.filter(lambda num: num == 1) is Maybe.nothing()

    assert just_list.filter(lambda num: num == 1) is Maybe.nothing()

    assert just_dict.filter(lambda num: num == 1) is Maybe.nothing()

# Generated at 2022-06-12 05:18:55.721954
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:19:00.927505
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda n: n == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda n: n == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:19:07.965328
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Maybe.just(Try.success('Lazy')).to_lazy() == \
        Lazy(lambda: Try.success('Lazy'))
    assert Maybe.just(Try.failure(None)).to_lazy() == \
        Lazy(lambda: Try.failure(None))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:19:14.203919
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_with_value = Maybe.just(2)
    maybe_without_value = Maybe.nothing()

    assert maybe_with_value.filter(lambda x: x == 2) == Maybe.just(2)
    assert maybe_with_value.filter(lambda x: x == 3) == Maybe.nothing()
    assert maybe_without_value.filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:19:19.723903
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.just(None).filter(lambda x: x is None) == Maybe.just(None)

# Generated at 2022-06-12 05:19:39.334187
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test method filter of class Maybe.

    :return: None
    """
    value = Maybe.just(3)
    assert value.filter(lambda x: True) == Maybe.just(3)
    assert value.filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:19:45.503781
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # When value is empty
    assert Maybe.nothing().filter(
        lambda x: x > 2
    ) == Maybe.nothing()

    # When value is not empty and filterer return False
    assert Maybe.just(1).filter(
        lambda x: x > 2
    ) == Maybe.nothing()

    # When value is not empty and filterer return True
    assert Maybe.just(3).filter(
        lambda x: x > 2
    ) == Maybe.just(3)

    # When value is not empty and filterer is None
    assert Maybe.just(3).filter(
        None
    ) == Maybe.nothing()



# Generated at 2022-06-12 05:19:50.919041
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    maybe = Maybe.just(5)
    assert maybe.to_lazy() == Lazy(lambda: 5)
    assert Lazy(Try.unit(5)) == Lazy(lambda: 5)



# Generated at 2022-06-12 05:20:02.677148
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def is_even_filterer(x: int) -> bool:
        return x % 2 == 0

    # Test filter on empty Maybe
    assert Maybe.nothing().filter(is_even_filterer) == Maybe.nothing()

    # Test filter on not empty Maybe
    assert Maybe.just(1).filter(is_even_filterer) == Maybe.nothing()
    assert Maybe.just(1).to_either().filter(is_even_filterer) == Right(Maybe.nothing())

# Generated at 2022-06-12 05:20:08.910956
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functions import identity

    # Test for empty Maybe
    assert Maybe.nothing().filter(identity) == Maybe.nothing()

    # Test for not empty Maybe
    assert Maybe.just(1).filter(identity) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)



# Generated at 2022-06-12 05:20:14.473099
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(1).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:20:19.550159
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value < 100

    assert Maybe.just(10).filter(filterer) == Maybe.just(10)
    assert Maybe.just(101).filter(filterer) == Maybe.nothing()
    assert Maybe.nothing().filter(filterer) == Maybe.nothing()



# Generated at 2022-06-12 05:20:21.670775
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:20:29.627844
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Lazy(lambda: 10) == Lazy(Maybe.just(10).to_lazy())
    assert Lazy(lambda: None) == Lazy(Maybe.nothing().to_lazy())



# Generated at 2022-06-12 05:20:31.453566
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()



# Generated at 2022-06-12 05:20:48.999875
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe_just_1 = Maybe.just(1)
    maybe_nothing = Maybe.nothing()
    assert maybe_just_1.to_lazy().force() == 1
    assert maybe_nothing.to_lazy().force() == None


# Generated at 2022-06-12 05:20:52.535607
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    origin = Maybe.just(2)
    assert origin.filter(lambda e: e % 2 == 0) == Maybe.just(2)
    assert origin.filter(lambda e: e % 2 != 0) == Maybe.nothing()


# Generated at 2022-06-12 05:20:54.204681
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:21:01.247054
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # partition_by_even = lambda num: num % 2 == 0
    partition_by_even = lambda num: bool(num % 2)
    assert Maybe.just(2).filter(partition_by_even) == Maybe.just(2)
    assert Maybe.just(1).filter(partition_by_even) == Maybe.nothing()
    assert Maybe.nothing().filter(partition_by_even) == Maybe.nothing()

