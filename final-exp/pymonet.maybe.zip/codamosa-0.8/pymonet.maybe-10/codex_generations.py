

# Generated at 2022-06-12 05:11:07.557515
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.just(0) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:11:10.316045
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('test') == Maybe.just('test')
    assert Maybe.just('test') != Maybe.just('not_test')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('test') != Maybe.nothing()


# Generated at 2022-06-12 05:11:11.929920
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:18.787897
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(True, False).filter(lambda value: value) == Maybe.just(True)
    assert Maybe.nothing().filter(lambda value: value) == Maybe.nothing()
    assert Maybe(False, False).filter(lambda value: value) == Maybe.nothing()
    assert Maybe(True, True).filter(lambda value: value) == Maybe.nothing()
    assert Maybe(None, True).filter(lambda value: value) == Maybe.nothing()



# Generated at 2022-06-12 05:11:24.157793
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test filter method of Maybe.

    :return: no return
    """
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:11:29.090423
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('Hello') == Maybe.just('Hello')
    assert Maybe.just('Hello') != Maybe.just('World')
    assert Maybe.nothing() != Maybe.just('World')
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:11:35.905992
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Testing method filter

    :return: Nothing
    """
    assert Maybe.just(1).filter(lambda v: v == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda v: v == 1) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda v: v == 0) == Maybe.just(0)
    assert Maybe.nothing().filter(lambda v: v == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:11:48.493162
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = 5
    def filterer(x):
        return x > 3
    mapper = lambda x: x + 1
    assert Maybe.just(value) \
        .filter(filterer) \
        .map(mapper) \
        .get_or_else(0) == value + 1

    assert Maybe.just(value) \
        .filter(lambda x: x < 3) \
        .map(mapper) \
        .get_or_else(0) == 0

    assert Maybe.nothing() \
        .filter(filterer) \
        .map(mapper) \
        .get_or_else(0) == 0


# Generated at 2022-06-12 05:11:52.937791
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.just('s') != Maybe.nothing()


# Generated at 2022-06-12 05:12:01.329931
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    func_lt_10 = lambda x: x < 10

    maybe_ten = Maybe.just(10)
    assert maybe_ten.filter(func_lt_10) == Maybe.nothing()

    maybe_ten = Maybe.just(10)
    assert maybe_ten.filter(func_lt_10) == Maybe.nothing()

    maybe_ten = Maybe.nothing()
    assert maybe_ten.filter(func_lt_10) == Maybe.nothing()

    maybe_none = Maybe.just(None)
    assert maybe_none.filter(func_lt_10) == Maybe.nothing()

    maybe_none = Maybe.just(None)
    assert maybe_none.filter(func_lt_10) == Maybe.nothing()

    maybe_none = Maybe.nothing()

# Generated at 2022-06-12 05:12:10.655502
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try, is_valid

    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert is_valid(Maybe.just(0))
    assert not is_valid(Maybe.nothing())



# Generated at 2022-06-12 05:12:14.255099
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(2, True) == Maybe(2, True)



# Generated at 2022-06-12 05:12:20.171385
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(
        lambda _: True
    ) == Maybe.just(True)

    assert Maybe.just(True).filter(
        lambda _: False
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda _: True
    ) == Maybe.nothing()



# Generated at 2022-06-12 05:12:24.580265
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), "Should return True"
    assert Maybe.nothing() == Maybe.nothing(), "Should return True"
    assert Maybe.just(1) != Maybe.just(2), "Should return False"
    assert Maybe.nothing() != Maybe.just(2), "Should return False"
    assert Maybe.just(1) != Maybe.nothing(), "Should return False"


# Generated at 2022-06-12 05:12:34.335601
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    m1: Maybe[int] = Maybe.just(1)
    m2: Maybe[int] = Maybe.just(1)
    m3: Maybe[int] = Maybe.just(2)

    # Exercise
    m4: Maybe[int] = Maybe.nothing()
    m5: Maybe[int] = Maybe.nothing()

    # Verify
    assert m1 == m1
    assert m1 == m2
    assert m2 == m1
    assert m1 != m3
    assert m3 != m1

    assert m4 == m4
    assert m4 == m5
    assert m5 == m4

    assert m1 != m4
    assert m4 != m1



# Generated at 2022-06-12 05:12:39.000894
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-12 05:12:42.049791
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != 1
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != None


# Generated at 2022-06-12 05:12:46.231060
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:51.730090
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != 1


# Generated at 2022-06-12 05:12:56.036414
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) == Maybe(2, True)
    assert Maybe(1, True) != Maybe(1, False)



# Generated at 2022-06-12 05:13:06.719969
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert(Maybe.just(1).to_lazy() == Lazy(lambda: 1))
    assert(Maybe.nothing().to_lazy() == Lazy(lambda: None))



# Generated at 2022-06-12 05:13:11.788714
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != 1
    assert Maybe.just(1) != 1
    assert Maybe.just(1) != '1'


# Generated at 2022-06-12 05:13:19.609296
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_some = Maybe.just(2)
    maybe_none = Maybe.nothing()

    assert maybe_some.filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert maybe_some.filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert maybe_none.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_none.filter(lambda x: x % 2 == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:13:23.584572
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe1 = Maybe.just('value')
    maybe2 = Maybe.just('value')
    maybe3 = Maybe.just('other_value')
    assert maybe1 == maybe2
    assert maybe1 != maybe3


# Generated at 2022-06-12 05:13:27.929346
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)



# Generated at 2022-06-12 05:13:33.081371
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(2)
    assert m.filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert m.filter(lambda x: x % 2 != 0) == Maybe.nothing()


# Generated at 2022-06-12 05:13:36.160749
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(True).to_lazy() == Lazy(lambda: True)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:13:40.307558
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    test_Maybe_filter.
    """
    value = Maybe.just(1).filter(lambda x: x > 5)
    assert value == Maybe.nothing()
    value = Maybe.just(1).filter(lambda x: x < 5)
    assert value == Maybe.just(1)


# Generated at 2022-06-12 05:13:46.179736
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :returns: True if it's ok, raises AssertionError otherwise
    :rtype: Boolean
    """
    m1 = Maybe.just(5)
    m2 = Maybe.just(5)
    m3 = Maybe.nothing()
    assert m1 == m2
    assert m3 == m3
    assert m1 != m3
    return True


# Generated at 2022-06-12 05:13:50.665397
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.nothing()


# Generated at 2022-06-12 05:14:07.645644
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:14:13.375428
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def f(value):
        return value.value == 3

    assert Maybe(3, False).__eq__(Maybe(3, False))
    assert Maybe(3, False).__eq__(Maybe.just(3))
    assert Maybe(3, False).filter(f).__eq__(Maybe.just(3).filter(f))


# Generated at 2022-06-12 05:14:16.946732
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1), 'Maybe.__eq__ failed'
    assert Maybe.just(1) != Maybe.just(2), 'Maybe.__eq__ failed'
    assert Maybe.just(1) != Maybe.nothing(), 'Maybe.__eq__ failed'
    assert Maybe.nothing() == Maybe.nothing(), 'Maybe.__eq__ failed'


# Generated at 2022-06-12 05:14:19.840705
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda value: value % 2 == 0) == Maybe.just(4)
    assert Maybe.just(5).filter(lambda value: value % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:14:25.603428
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:14:28.038716
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(3, False).to_lazy().force() == 3
    assert Maybe.nothing().to_lazy().force() is None

# Generated at 2022-06-12 05:14:31.490942
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(4).to_lazy() == Lazy(lambda: 4)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:14:43.680502
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.just(3)
    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Try(4, is_success=True) == Maybe.just(4)
    assert Try(4, is_success=False) == Maybe.nothing()
    assert Left('err') == Maybe.nothing()
    assert Right(3) == Maybe.just(3)
    assert Box(None) == Maybe.nothing()

# Generated at 2022-06-12 05:14:50.479406
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda value: value == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda value: value == 2) != Maybe.just(1)
    assert Maybe.just(1).filter(lambda value: value == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda value: value == 1) == Maybe.nothing()

# Generated at 2022-06-12 05:14:57.570685
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    assert m1 == m2

    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    assert m1 != m2

    m1 = Maybe.nothing()
    m2 = Maybe.nothing()
    assert m1 == m2

    m1 = Maybe.nothing()
    m2 = Maybe.just(1)
    assert m1 != m2



# Generated at 2022-06-12 05:15:11.101384
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(3).to_lazy().force() == 3
    assert Maybe.nothing().to_lazy().force() is None

# Generated at 2022-06-12 05:15:16.098500
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:15:20.361639
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe
    from math import sqrt
    assert Maybe.just(4).filter(lambda x: x > 3) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: x > 3) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x > 3) == Maybe.nothing()

# Generated at 2022-06-12 05:15:24.673793
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(8).filter(lambda x: x == 8) == Maybe.just(8)
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:15:31.372517
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(None, False).to_lazy() == Lazy(lambda: None)
    assert Maybe(1, True).to_lazy() == Lazy(lambda: None)
    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:15:36.533670
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(12345, False).filter(lambda x: True) == Maybe(12345, False)
    assert Maybe(12345, False).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:15:42.045075
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("yes").filter(lambda v: True) == Maybe.just("yes")
    assert Maybe.just("yes").filter(lambda v: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: False) == Maybe.nothing()


# Generated at 2022-06-12 05:15:47.463606
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box

    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()



# Generated at 2022-06-12 05:15:51.812072
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:15:57.752026
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-12 05:16:09.850105
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:16:16.520370
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test that True return when filterer returns True
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    # Test that False return when filterer returns False
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    # Test that False return when Maybe is Nothing
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:16:24.192730
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # case 1:
    maybe_value = Maybe(1, False)
    assert maybe_value.filter(lambda x: x > 0) == Maybe(1, False)
    # case 2:
    maybe_value = Maybe(1, False)
    assert maybe_value.filter(lambda x: x < 0) == Maybe.nothing()
    # case 3:
    maybe_value = Maybe.nothing()
    assert maybe_value.filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:16:34.287525
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    maybe_1 = Maybe.just(1)
    maybe_3 = Maybe.just(3)
    maybe_None = Maybe.nothing()

    # Act
    result_1 = maybe_1.filter(lambda x: x < 2)
    result_2 = maybe_1.filter(lambda x: x > 2)
    result_3 = maybe_1.filter(lambda x: x < 2 and x > 2)
    result_None = maybe_None.filter(lambda x: x < 2)

    # Assert
    assert result_1 == Maybe.just(1)
    assert result_2 == Maybe.nothing()
    assert result_3 == Maybe.nothing()
    assert result_None == Maybe.nothing()



# Generated at 2022-06-12 05:16:44.751324
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    value = Maybe.just(10).filter(lambda x: x > 5).get_or_else(None)
    assert value == 10

    value = Maybe.just(10).filter(lambda x: x < 5).get_or_else(None)
    assert value is None

    value = Maybe.just(10).filter(lambda x: x > 5).map(lambda x: x * 2).get_or_else(None)
    assert value == 20

    value = Maybe.just(10).filter(lambda x: x < 5).map(lambda x: x * 2).get_or_else(None)
    assert value is None

    value = Maybe.nothing().filter(lambda _: True).get_or_else(None)
    assert value is None

# Generated at 2022-06-12 05:16:53.119816
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x >= 10) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x < 10) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x >= 5) == Maybe.just(5)

    assert Maybe.nothing().filter(lambda x: x >= 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x >= 5) == Maybe.nothing()


# Generated at 2022-06-12 05:17:01.743929
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.errors import LazyException

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

    lazy = Maybe.just(1).to_lazy()
    assert lazy.force() == 1

    lazy = Maybe.nothing().to_lazy()
    try:
        lazy.force()
        raise Exception('Maybe.to_lazy should raise LazyException')
    except LazyException as e:
        assert e.empty



# Generated at 2022-06-12 05:17:04.767938
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)
    assert Maybe.just(3).to_lazy().value() == 3


# Generated at 2022-06-12 05:17:16.026537
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation, ValidationError

    assert Maybe.just(2).filter(lambda v: v == 2) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda v: v == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v == 2) == Maybe.nothing()

    assert Maybe.just(2).map(lambda v: v + 1) == Maybe.just(3)
    assert Maybe.just(2).map(lambda v: None) == Maybe.nothing()
    assert Maybe.nothing().map(lambda v: v + 1) == Maybe.nothing()



# Generated at 2022-06-12 05:17:21.185726
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1))
    assert(Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing())
    assert(Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing())

# Generated at 2022-06-12 05:17:42.062083
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(10, False).to_lazy() == Lazy(lambda: 10)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:17:50.834496
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success
    from pymonet.validation import Invalid
    from pymonet.validation import Valid
    from pymonet.validation import Validation

    # Empty maybe
    print("Test Maybe.filter() with empty Maybe")
    maybe = Maybe.nothing()
    def filterer(value):
        return True
    assert maybe.filter(filterer) == Maybe.nothing()
    print("Ok")

    # Nonempty maybe and filterer function returns False
    print("Test Maybe.filter() with nonempty Maybe and filterer function returns False")
    maybe = Maybe.just('a')
    def filterer(value):
        return False

# Generated at 2022-06-12 05:17:57.117677
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(5).filter(lambda x: x % 2 == 0 and x < 5)
    assert maybe == Maybe.nothing()

    maybe = Maybe.just(5).filter(lambda x: x % 2 == 0 and x < 6)
    assert maybe == Maybe.just(5)

    maybe = Maybe.nothing().filter(lambda x: x % 2 == 0 and x < 6)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-12 05:18:01.807975
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:18:04.552789
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()

# Generated at 2022-06-12 05:18:08.373558
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:18:10.786138
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:18:19.004486
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy, LazyException

    # When Maybe is empty
    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.is_thunk()
    try:
        # When Maybe is empty, Lazy should throw exception
        lazy.value()
        assert False
    except LazyException:
        assert True

    # When Maybe is not empty
    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.is_thunk()
    assert lazy.value() == 1


# Generated at 2022-06-12 05:18:20.819806
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy().result() == 1
    assert Maybe.nothing().to_lazy().result() is None


# Generated at 2022-06-12 05:18:28.852125
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet import Lazy

    def not_empty_maybe_to_lazy_test():
        maybe = Maybe.just(5)
        lazy = maybe.to_lazy()

        assert isinstance(lazy, Lazy)
        assert lazy() == 5

    def empty_maybe_to_lazy_test():
        maybe = Maybe.nothing()
        lazy = maybe.to_lazy()

        assert isinstance(lazy, Lazy)
        assert lazy() is None

    not_empty_maybe_to_lazy_test()
    empty_maybe_to_lazy_test()



# Generated at 2022-06-12 05:19:09.255016
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda value: value > 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda value: value > 2) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda value: value > 2) == Maybe.just(3)


# Generated at 2022-06-12 05:19:14.249939
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x != 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x != 3) == Maybe.nothing()



# Generated at 2022-06-12 05:19:19.530175
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Maybe is empty
    try:
        Maybe.nothing().filter(lambda x: x > 3)
        assert False
    except AttributeError:
        assert True
    # Maybe is not empty and filter returns True
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    # Maybe is not empty and filter returns False
    assert Maybe.just(5).filter(lambda x: x <= 3) == Maybe.nothing()


test_Maybe_filter()

# Generated at 2022-06-12 05:19:25.504793
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.maybe import Maybe

    assert Maybe.just(5).filter(lambda v: v % 2 == 0) == Maybe.nothing()
    assert Maybe.just(6).filter(lambda v: v % 2 == 0) == Maybe.just(6)
    assert Maybe.nothing().filter(lambda v: v % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:19:31.107051
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(None).to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:19:38.253161
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.
    """
    test_if_filter = Maybe.just(1).filter(lambda x: x == 1)
    assert test_if_filter == Maybe.just(1)
    test_if_not_filter = Maybe.just(1).filter(lambda x: x == 2)
    assert test_if_not_filter == Maybe.nothing()
    test_if_empty_filter = Maybe.nothing().filter(lambda x: x == 1)
    assert test_if_empty_filter == Maybe.nothing()


# Generated at 2022-06-12 05:19:44.189267
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    def is_even(x):
        return x % 2 == 0
    # When
    maybe = Maybe.just(2).filter(is_even)
    # Then
    assert maybe == Maybe.just(2)
    # When
    maybe = Maybe.just(3).filter(is_even)
    # Then
    assert maybe == Maybe.nothing()
    # When
    maybe = Maybe.nothing().filter(is_even)
    # Then
    assert maybe == Maybe.nothing()

# Generated at 2022-06-12 05:19:50.542946
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x == 2) == Maybe.just(2)



# Generated at 2022-06-12 05:19:55.080502
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(1, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:20:01.946840
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_maybe import Maybe

    assert Maybe.just(None).filter(lambda x: True) == Maybe.just(None)
    assert Maybe.just(None).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: True) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:20:47.726727
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test_helper import f, g

    maybe_1 = Maybe.just(1)
    assert maybe_1.filter(g) == Maybe.nothing()
    assert maybe_1.filter(f) == maybe_1
    assert maybe_1.filter(lambda x: x == 1) == Maybe.just(1)
    assert maybe_1.filter(lambda x: x == 2) == Maybe.nothing()
    maybe_2 = Maybe.nothing()
    assert maybe_2.filter(f) == Maybe.nothing()
    assert maybe_2.filter(g) == Maybe.nothing()


# Generated at 2022-06-12 05:20:51.265055
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:20:56.089008
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(6).filter(lambda x: x % 2 == 0) == Maybe.just(6)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:21:00.267391
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda a: a % 3 == 1) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda a: a % 3 == 2) == Maybe.nothing()