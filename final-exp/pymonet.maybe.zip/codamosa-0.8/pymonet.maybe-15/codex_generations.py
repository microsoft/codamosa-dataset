

# Generated at 2022-06-12 05:11:13.324834
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    class Person:
        def __init__(self, age: int, height: int):
            self.age = age
            self.height = height

    def test_filterer(person):
        return person.age >= 18 and person.height >= 50

    assert Maybe.just(Person(age=17, height=50)).filter(test_filterer) == Maybe.nothing()
    assert Maybe.just(Person(age=20, height=50)).filter(test_filterer) == Maybe.just(Person(age=20, height=50))
    assert Maybe.just(Person(age=18, height=49)).filter(test_filterer) == Maybe.nothing()

# Generated at 2022-06-12 05:11:17.876742
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 0) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()



# Generated at 2022-06-12 05:11:20.819501
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-12 05:11:28.656843
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(2)
    assert m1 == m2

    m1 = Maybe.nothing()
    m2 = Maybe.nothing()
    assert m1 == m2

    m1 = Maybe.just(1)
    m2 = Maybe.nothing()
    assert m1 != m2

    m1 = Maybe.just(1)
    assert m1 == m1

    m1 = Maybe.nothing()
    assert m1 == m1



# Generated at 2022-06-12 05:11:33.945482
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_positive(number):
        return number > 0

    assert Maybe.just(1).filter(is_positive) == Maybe.just(1)
    assert Maybe.just(0).filter(is_positive) == Maybe.nothing()
    assert Maybe.nothing().filter(is_positive) == Maybe.nothing()



# Generated at 2022-06-12 05:11:37.773040
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(12).filter(lambda x: x % 2 == 0) == Maybe.just(12)
    assert Maybe.just(12).filter(lambda x: x % 2 == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: 1 == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:11:50.363592
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_maybe import Maybe

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(0) == Maybe.just(0)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just('10') == Maybe.just('10')
    assert Maybe.just([1, 2, 3]) == Maybe.just([1, 2, 3])
    assert Maybe.just((1, 2, 3)) == Maybe.just((1, 2, 3))
    assert Maybe.just(['1', '2', '3']) == Maybe.just(['1', '2', '3'])

    assert Maybe.just(0) != Maybe.just(1)
    assert Maybe.just(0) != Maybe.just('0')

# Generated at 2022-06-12 05:11:54.257814
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)


# Generated at 2022-06-12 05:11:58.134330
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()

# Generated at 2022-06-12 05:12:05.852338
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :return: True if test passed, in other case raise AssertionError
    :rtype: Boolean
    """
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just('foo') == Maybe.just('foo')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('foo') != Maybe.just(5)
    assert Maybe.just('foo') != Maybe.nothing()
    return True

test_Maybe___eq__()

# Generated at 2022-06-12 05:12:15.651957
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(8) == Maybe.just(8)
    assert Maybe.just(8) != Maybe.just(4)
    assert Maybe.just(8) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)


# Generated at 2022-06-12 05:12:22.120135
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    assert Maybe(2, False).filter(is_even) == Maybe(2, False)
    assert Maybe(2, False).filter(is_even).filter(is_even) == Maybe(2, False)
    assert Maybe(1, False).filter(is_even) == Maybe.nothing()



# Generated at 2022-06-12 05:12:26.616682
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-12 05:12:34.187989
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import test_Box_filter
    from pymonet.either import test_Either_filter
    from pymonet.lazy import test_Lazy_filter
    from pymonet.monad_try import test_Try_filter
    from pymonet.validation import test_Validation_filter
    test_Box_filter(Maybe)
    test_Either_filter(Maybe)
    test_Lazy_filter(Maybe)
    test_Try_filter(Maybe)
    test_Validation_filter(Maybe)


# Generated at 2022-06-12 05:12:38.424061
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: x).bind(lambda x: Maybe.just(4)) == Maybe.just(4)
    assert Maybe.just(True).filter(lambda x: x).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.just(False).filter(lambda x: x).bind(lambda x: Maybe.just(4)) == Maybe.nothing()
    assert Maybe.just(False).filter(lambda x: x).bind(lambda x: Maybe.nothing()) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()



# Generated at 2022-06-12 05:12:41.431878
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda n: n >= 0) == Maybe.just(1)
    assert Maybe.just(-1).filter(lambda n: n >= 0) == Maybe.nothing()

# Generated at 2022-06-12 05:12:44.281622
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()

# Generated at 2022-06-12 05:12:48.975676
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()

# Generated at 2022-06-12 05:12:52.750146
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_func(x):
        return x

    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()

    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)



# Generated at 2022-06-12 05:12:59.062353
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :returns: Nothing
    :rtype: None
    """
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:13:10.360157
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    value = 10
    maybe = Maybe.just(value)
    filtered_maybe = maybe.filter(lambda v: v > 0)
    assert Maybe.just(value) == filtered_maybe
    filtered_maybe = maybe.filter(lambda v: v < 0)
    assert Maybe.nothing() == filtered_maybe
    nothing_maybe = Maybe.nothing()
    filtered_nothing_maybe = nothing_maybe.filter(lambda v: v > 0)
    assert Maybe.nothing() == filtered_nothing_maybe


# Generated at 2022-06-12 05:13:16.194902
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    _1 = Maybe.just(1)
    _2 = Maybe.just(2)
    n = Maybe.nothing()
    n2 = Maybe.nothing()

    assert _1 == _1
    assert _1 != _2
    assert _1 != n
    assert n == n2
    assert n != _1
    assert n != _2


# Generated at 2022-06-12 05:13:24.409416
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() != Maybe(None, False)
    assert Maybe.nothing() != Maybe(1, False)
    assert Maybe.nothing() != Maybe(1, True)


# Generated at 2022-06-12 05:13:28.161201
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    fm = Maybe.nothing()
    assert fm.filter(lambda x: x > 3) == Maybe.nothing()

    fm = Maybe.just(9)
    assert fm.filter(lambda x: x > 3) == Maybe.just(9)


# Generated at 2022-06-12 05:13:32.117517
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()


# Generated at 2022-06-12 05:13:38.350922
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """

    :returns:
    :rtype:
    """
    # Case 1: empty Maybe to Lazy
    maybe = Maybe.nothing()
    lazy = maybe.to_lazy()
    assert lazy.get() is None

    # Case 2: not empty Maybe to Lazy
    maybe = Maybe.just(1)
    lazy = maybe.to_lazy()
    assert lazy.get() == 1



# Generated at 2022-06-12 05:13:42.886549
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)



# Generated at 2022-06-12 05:13:47.891820
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:13:52.644180
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x > 10) == Maybe.nothing()



# Generated at 2022-06-12 05:13:58.393584
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)


# Generated at 2022-06-12 05:14:10.953642
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(-1) != Maybe.just(1)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:17.747333
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    def filterer(value: int) -> bool:
        return value % 2 == 0

    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)

    # Act

    # Assert
    assert maybe_1.filter(filterer) == Maybe.nothing()
    assert maybe_2.filter(filterer) == maybe_2


# Generated at 2022-06-12 05:14:21.273265
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:14:26.211042
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(41)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)
    assert Maybe.just(42) != Maybe.nothing()



# Generated at 2022-06-12 05:14:30.340315
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(4)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:34.052828
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) != Maybe.just(24)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(24)


# Generated at 2022-06-12 05:14:40.829028
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)


# Generated at 2022-06-12 05:14:46.334898
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """unit test for method __eq__ of class Maybe
    """
    assert Maybe.just(9) == Maybe.just(9)
    assert Maybe.just(9) != Maybe.just(8)
    assert Maybe.just(9) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
# end def test_Maybe___eq__


# Generated at 2022-06-12 05:14:50.479808
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:15:00.341209
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    # Not empty Maybe
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe('a', False) == Maybe('a', False)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) == Maybe('1', False)
    assert Maybe(1, False) == Maybe.just('1')
    assert Maybe.just(1) == Maybe.just(1)

    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe(1, False) != Maybe.nothing()

    # Empty Maybe
    assert Maybe.nothing() == Maybe.nothing()

# Generated at 2022-06-12 05:15:23.719516
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:15:30.094336
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(
        lambda x: x > 3
    ) == Maybe.just(5)

    assert Maybe.just(5).filter(
        lambda x: x < 3
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        lambda x: x < 3
    ) == Maybe.nothing()

# Generated at 2022-06-12 05:15:33.382682
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(4).to_lazy()
    assert maybe == Lazy(lambda: 4)
    assert maybe.get() == 4



# Generated at 2022-06-12 05:15:38.579992
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m = Maybe.just(
        value=lambda x: x + 3
    )

    assert m.filter(
        filterer=lambda fn: fn(2) == 4
    ) == Maybe.just(
        value=lambda x: x + 3
    )

    assert m.filter(
        filterer=lambda fn: fn(3) == 4
    ) == Maybe.nothing()

    assert Maybe.nothing().filter(
        filterer=lambda fn: fn(3) == 4
    ) == Maybe.nothing()


# Generated at 2022-06-12 05:15:42.146537
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:46.379080
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(1)
    m2 = Maybe.just(1)
    m3 = Maybe.just(2)
    assert m1 == m1
    assert m1 == m2
    assert m1 != m3

# Generated at 2022-06-12 05:15:50.422708
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:15:54.906275
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:15:57.320427
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(0) != Maybe.nothing()


# Generated at 2022-06-12 05:16:01.979022
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)

    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:16:27.872352
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Maybe.nothing().to_lazy(), Lazy)
    assert isinstance(Maybe.just(5).to_lazy(), Lazy)



# Generated at 2022-06-12 05:16:31.308315
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just(1.0) != Maybe.just('1.0')



# Generated at 2022-06-12 05:16:39.074857
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(True) != Maybe.just(False)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != 1
    assert Maybe.nothing() != None

# Generated at 2022-06-12 05:16:41.606902
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:16:51.968205
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Given
    value = 1
    maybe = Maybe.just(value)
    filterer = lambda x: x > 1

    # When
    result = maybe.filter(
        filterer
    )

    # Then
    assert result == Maybe.nothing()

    # Given
    value = 2
    maybe = Maybe.just(
        value
    )

    # When
    result = maybe.filter(
        filterer
    )

    # Then
    assert result == Maybe.just(
        value
    )

    # Given
    maybe = Maybe.nothing()

    # When
    result = maybe.filter(
        filterer
    )

    # Then
    assert result == Maybe.nothing()



# Generated at 2022-06-12 05:16:55.871755
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-12 05:17:02.312687
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Tests Maybe filter method.

    :return: list of all assertations
    :rtype: list of all unit tests
    """
    assert Maybe.just(2).filter(lambda i: i % 2 == 0) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda i: i % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda i: i % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:17:06.412237
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:09.134208
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(32, False).to_lazy().force() == 32
    assert Maybe(None, True).to_lazy().force() is None


# Generated at 2022-06-12 05:17:14.981211
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert (
        Maybe(None, True) ==
        Maybe(None, True)
    )

    assert (
        Maybe(10, False) ==
        Maybe(10, False)
    )

    assert Not(
        Maybe(10, True) ==
        Maybe(10, False)
    )

    assert Not(
        Maybe(10, False) ==
        Maybe(9, False)
    )


# Generated at 2022-06-12 05:17:40.484198
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try

    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x > 7) == Maybe.nothing()
    assert Try.success(5).filter(lambda x: x > 3) == Try.success(5)
    assert Try.success(5).filter(lambda x: x > 7) == Try.failure(nil)
    assert Try.failure(TypeError()).filter(lambda x: x > 3) == Try.failure(TypeError())


# Generated at 2022-06-12 05:17:43.703816
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # GIVEN
    maybe = Maybe.just(4)
    # WHEN
    result = maybe.filter(lambda x: x == 4)
    # THEN
    assert result == Maybe.just(4)

# Generated at 2022-06-12 05:17:46.817815
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    lazy = Maybe.just(1).to_lazy()
    assert lazy.evaluate() == 1

    lazy = Maybe.nothing().to_lazy()
    assert lazy.evaluate() is None

# Generated at 2022-06-12 05:17:51.934991
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe('a', False).filter(lambda x: True) == Maybe('a', False)
    assert Maybe('a', False).filter(lambda x: False) == Maybe.nothing()
    assert Maybe('a', True).filter(lambda x: True) == Maybe.nothing()
    assert Maybe('a', True).filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:17:57.466132
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(5)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:18:02.177188
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just('hello').filter(lambda s: len(s) == 5) == Maybe.just('hello')
    assert Maybe.just('hi').filter(lambda s: len(s) == 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda s: len(s) == 5) == Maybe.nothing()

# Generated at 2022-06-12 05:18:07.524815
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test method to_lazy of class Maybe.

    :returns: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:18:16.234387
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def __eq__(self, other):
        return isinstance(other, Maybe) and \
            self.is_nothing == other.is_nothing and \
            (self.is_nothing or self.value == other.value)

    assert __eq__(Maybe.just(1), Maybe.just(1))
    assert __eq__(Maybe.just(1), Maybe.just(1))
    assert __eq__(Maybe.nothing(), Maybe.nothing())
    assert not __eq__(Maybe.nothing(), Maybe.just(1))
    assert not __eq__(Maybe.just(1), Maybe.just(2))


# Generated at 2022-06-12 05:18:19.081935
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Nothing.filter(lambda x: x < 10) == Nothing

    assert Just(44).filter(lambda x: x < 10) == Nothing
    assert Just(1).filter(lambda x: x < 10) == Just(1)


# Generated at 2022-06-12 05:18:29.056766
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_success(first, second):
        return first == second, 'Must return True, but return False'

    def test_failure(first, second):
        return first != second, 'Must return False, but return True'

    def test_failure_with_isinstance(first, second):
        return first == second and isinstance(first, Maybe), 'Return True, but Maybe not instance'

    def test_success_with_isinstance(first, second):
        return first != second or isinstance(first, Maybe), 'Return False, but Maybe is instance'


# Generated at 2022-06-12 05:18:55.431817
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != 'string'
    assert Maybe.nothing() != 'string'


# Generated at 2022-06-12 05:19:02.144407
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    nothing = Maybe.nothing()
    maybe_1 = Maybe.just(1)
    maybe_5 = Maybe.just(5)

    assert nothing.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_1.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_5.filter(lambda x: x % 2 == 0) == Maybe.just(5)


# Generated at 2022-06-12 05:19:10.596480
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.test.test_util import assert_equal, assert_not_equal

    maybe = Maybe.just(1)
    assert_equal(Maybe.just(1), Maybe.just(1))
    assert_equal(Maybe.nothing(), Maybe.nothing())
    assert_not_equal(Maybe.just(1), Maybe.nothing())
    assert_not_equal(Maybe.nothing(), Maybe.just(1))
    assert_not_equal(Maybe.just(1), Maybe.just(2))


# Generated at 2022-06-12 05:19:16.175910
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2).__eq__(Maybe.just(2)) is True
    assert Maybe.just(2).__eq__(Maybe.just(3)) is False
    assert Maybe.nothing().__eq__(Maybe.nothing()) is True
    assert Maybe.nothing().__eq__(Maybe.just(2)) is False
    assert Maybe.just(2).__eq__(Maybe.nothing()) is False

# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:19:19.160891
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:19:23.426020
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(5, False).to_lazy() == Lazy(lambda: 5)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:19:28.297858
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m = Maybe.just(122)
    mm = Maybe.just(122)
    mmm = Maybe.just(123)
    assert m == mm
    assert mm == m
    assert not m == mmm
    assert mmm != m
    assert m != Maybe.nothing()


# Generated at 2022-06-12 05:19:30.904995
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    result = Maybe.just(1).to_lazy()
    assert result.force() == 1

    result = Maybe.nothing().to_lazy()
    assert result.force() is None

# Generated at 2022-06-12 05:19:40.119270
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test Maybe.to_lazy method

    :returns: Nothing
    :rtype: Nothing
    """
    from pymonet.lazy import Lazy
    def test_case_one():
        """
        Test case one

        :returns: Nothing
        :rtype: Nothing
        """
        lazy = Maybe.just(20).to_lazy()
        assert lazy.call() == Lazy(lambda: 20).call()

    def test_case_second():
        """
        Test case one

        :returns: Nothing
        :rtype: Nothing
        """
        lazy = Maybe.nothing().to_lazy()
        assert lazy.call() == Lazy(lambda: None).call()

    test_case_one()
    test_case_second()



# Generated at 2022-06-12 05:19:44.683012
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m = Maybe.just(5)
    lazy_m = m.to_lazy()
    assert isinstance(lazy_m, Lazy)
    assert lazy_m.value == 5

    m = Maybe.nothing()
    lazy_m = m.to_lazy()
    assert isinstance(lazy_m, Lazy)
    assert lazy_m.value() is None


# Generated at 2022-06-12 05:20:13.480696
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.nothing() != Maybe.just(33)


# Generated at 2022-06-12 05:20:18.093206
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(1) == Maybe.nothing()


# Generated at 2022-06-12 05:20:22.255438
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:20:27.650415
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(0).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.just(6).filter(lambda x: x > 5) == Maybe.just(6)
    assert Maybe.nothing().filter(lambda x: x > 5) == Maybe.nothing()


# Generated at 2022-06-12 05:20:33.655332
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.test.test_utils import assert_monad

    assert_monad(
        Maybe.just(5),
        Maybe.nothing(),
        lambda value: Maybe.just(value),
        lambda m1, m2: m1.filter(lambda value: value > 3) == m2.filter(lambda value: value > 3)
    )


# Generated at 2022-06-12 05:20:37.889737
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, False)



# Generated at 2022-06-12 05:20:41.579696
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:20:49.426156
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)


# Generated at 2022-06-12 05:20:57.703960
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monoid import Monoid
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)
    assert Maybe.just(SumMonoid(10)).to_lazy() == Lazy(lambda: SumMonoid(10))
    assert Maybe.just(ProductMonoid(10)).to_lazy() == Lazy(lambda: ProductMonoid(10))
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:21:01.956525
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)
    lazy = Lazy(lambda: 1)
    assert maybe.to_lazy() == lazy

    maybe = Maybe.nothing()
    lazy = Lazy(lambda: None)
    assert maybe.to_lazy() == lazy