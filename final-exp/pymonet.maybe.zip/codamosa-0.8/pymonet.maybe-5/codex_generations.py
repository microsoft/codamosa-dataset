

# Generated at 2022-06-12 05:11:06.083614
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(0).filter(lambda x: x > 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:11:10.413082
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(4, False).filter(lambda a: isinstance(a, int)) == Maybe(4, False)
    assert Maybe(4, False).filter(lambda a: a < 0) == Maybe(None, True)
    assert Maybe(None, True).filter(lambda a: True) == Maybe(None, True)
    assert Maybe(None, True).filter(lambda a: False) == Maybe(None, True)

# Generated at 2022-06-12 05:11:14.777284
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:18.366176
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)


# Generated at 2022-06-12 05:11:22.176596
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Test to_lazy method of Maybe monad.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:11:28.874680
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe(5, False) == Maybe(6, False)
    assert Maybe(5, True) == Maybe(6, True)
    assert Maybe(5, False) == Maybe(6, True)
    assert Maybe(5, True) == Maybe(6, False)



# Generated at 2022-06-12 05:11:34.993102
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def zero_or_more(i: int) -> bool:
        return i >= 0

    assert(Maybe.just(2).filter(zero_or_more) == Maybe.just(2))
    assert(Maybe.just(-3).filter(zero_or_more) == Maybe.nothing())
    assert(Maybe.nothing().filter(zero_or_more) == Maybe.nothing())


# Generated at 2022-06-12 05:11:37.585604
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_not_empty = Maybe.just(1)
    maybe_empty = Maybe.nothing()

    assert maybe_not_empty.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert maybe_not_empty.filter(lambda x: x % 2 != 0) == maybe_not_empty
    assert maybe_empty.filter(lambda x: x % 2 == 0) == maybe_empty


# Generated at 2022-06-12 05:11:43.414827
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe.just(42).filter(lambda value: value < 10) == Maybe.nothing())
    assert(Maybe.just(42).filter(lambda value: value == 42) == Maybe.just(42))
    assert(Maybe.nothing().filter(lambda value: value < 10) == Maybe.nothing())


# Generated at 2022-06-12 05:11:45.891017
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) == Maybe.just(5) == Maybe.nothing().map(lambda x: 5).get_or_else(6)


# Generated at 2022-06-12 05:11:53.222502
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    _ = lambda x: x
    assert Maybe.just(15).to_lazy() == Lazy(_(15))
    assert Maybe.nothing().to_lazy() == Lazy(_(None))



# Generated at 2022-06-12 05:11:56.869198
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:12:01.788648
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(value):
        return value >= 3

    assert(Maybe.just(4).filter(filterer) == Maybe.just(4))
    assert(Maybe.just(2).filter(filterer) == Maybe.nothing())
    assert(Maybe.nothing().filter(filterer) == Maybe.nothing())

test_Maybe_filter()


# Generated at 2022-06-12 05:12:08.844896
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(None, True) == Maybe.nothing()
    assert Maybe(None, True) != Maybe(None, False)
    assert Maybe(None, False) != Maybe.nothing()
    assert Maybe.just(False) == Maybe.just(False)
    assert Maybe.just(False) != Maybe.just(True)
    assert Maybe.just(False) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(False)



# Generated at 2022-06-12 05:12:13.148378
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    maybe = Maybe.just(1)

    assert maybe.to_lazy() == Lazy(lambda: 1)

    maybe = Maybe.nothing()

    assert maybe.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:12:17.822308
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:12:21.950796
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:26.401715
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:12:29.190380
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(42, False) == Maybe(42, False) and \
        Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:12:34.236654
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:12:40.903611
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda v: v < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v < 0) == Maybe.nothing()

# Generated at 2022-06-12 05:12:45.037115
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:12:51.399308
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just('42') != Maybe.just(42)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-12 05:12:59.550132
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 1

    maybe_1 = Maybe.just(value)
    maybe_2 = Maybe.just(value)
    assert maybe_1 == maybe_2

    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.nothing()
    assert maybe_1 == maybe_2

    maybe_1 = Maybe.just(value)
    maybe_2 = Maybe.nothing()
    assert not maybe_1 == maybe_2

    maybe_1 = Maybe.nothing()
    maybe_2 = Maybe.just(value)
    assert not maybe_1 == maybe_2


# Generated at 2022-06-12 05:13:01.523507
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:13:06.515636
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: a > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: a < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: True) == Maybe.nothing()

# Generated at 2022-06-12 05:13:09.419270
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    maybe = Maybe.just(1)

    # act
    result = maybe.filter(lambda x: x == 1)

    # assert
    assert result == Maybe.just(1)



# Generated at 2022-06-12 05:13:14.362469
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:13:25.590070
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe.just('5') == Maybe.just('5')
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5.0) == Maybe.just(5.0)
    assert Maybe.just(True) == Maybe.just(True)
    assert Maybe.just(None) == Maybe.just(None)

    assert Maybe.just(5) != Maybe.just('5')
    assert Maybe.just(5) != Maybe.just(5.0)
    assert Maybe.just(5) != Maybe.just(True)
    assert Maybe.just(5) != Maybe.just(None)

    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.nothing() != Maybe.just(5)
    assert Maybe.nothing() != Maybe.just('5')

# Generated at 2022-06-12 05:13:31.452229
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(5, False).filter(lambda x: x < 10) == Maybe.just(5)
    assert Maybe(5, False).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x < 10) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 10) == Maybe.nothing()


# Generated at 2022-06-12 05:13:39.219092
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)


# Generated at 2022-06-12 05:13:41.825294
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    maybe_empty = Maybe.nothing()
    maybe_not_empty = Maybe.just(2)
    # assert
    assert maybe_empty.filter(lambda x: x < 2) == Maybe.nothing()
    assert maybe_not_empty.filter(lambda x: x < 3) == Maybe.just(2)
    assert maybe_not_empty.filter(lambda x: x > 3) == Maybe.nothing()


# Generated at 2022-06-12 05:13:53.202893
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(3, False) == Maybe(3, False)
    assert Maybe(3, True) == Maybe(3, True)

    assert Maybe(3, False) != Maybe(4, False)
    assert Maybe(3, False) != Maybe(3, True)
    assert Maybe(3, True) != Maybe(4, True)

    from pymonet.box import Box

    assert Maybe(3, False) == Box(3)
    assert Maybe(3, True) == Box(None)

    from pymonet.either import Right, Left

    assert Maybe(3, False) == Right(3)
    assert Maybe(3, True) == Left(None)

    from pymonet.lazy import Lazy

    assert Maybe(3, False) == Lazy(lambda: 3)

# Generated at 2022-06-12 05:14:00.707469
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """Unit test for method filter of class Maybe"""

    assert Maybe.just(None).filter(lambda a: True) == Maybe.just(None)
    assert Maybe.just(None).filter(lambda a: False) == Maybe.nothing()

    assert Maybe.just(42).filter(lambda a: True) == Maybe.just(42)
    assert Maybe.just(42).filter(lambda a: False) == Maybe.nothing()



# Generated at 2022-06-12 05:14:03.874495
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(1) != Maybe.just(2)



# Generated at 2022-06-12 05:14:10.353695
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe(5, True) != Maybe(5, False)
    assert Maybe(5, False) != Maybe(6, False)
    assert Maybe(7, True) != Maybe(6, True)
    assert Maybe(7, False) != Maybe.nothing()


# Generated at 2022-06-12 05:14:14.598971
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:14:20.683876
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.monad_maybe import Maybe

    assert Maybe.just(None) == Maybe.just(None)
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just('a') != Maybe.just('b')
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:14:25.984178
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Unit test for method to_lazy of class Maybe.
    """
    from pymonet.lazy import Lazy

    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:14:31.076120
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Test for method filter for class Maybe

    :raises: assert error when test fail
    """

    assert Maybe.just("test").filter(lambda a: a == "test") == Maybe.just("test")
    assert Maybe.just("test").filter(lambda a: a == "test2") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a == "test") == Maybe.nothing()

# Generated at 2022-06-12 05:14:42.742491
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    m1 = Maybe.just(5)
    m2 = Maybe.just(6)
    m3 = Maybe.just(5)

    # Then
    assert m1 != m2
    assert m1 == m3
    assert m1 != None
    assert m1 == m1



# Generated at 2022-06-12 05:14:49.652687
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # for all
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()

    # for nothing
    assert Maybe.nothing().filter(lambda _: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda _: True) == Maybe.nothing()



# Generated at 2022-06-12 05:14:57.117993
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2).filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 2).filter(lambda x: x == 1).filter(lambda x: x == 2) == Maybe.nothing()

# Generated at 2022-06-12 05:15:03.596800
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from unittest import TestCase

    # Given
    maybe = Maybe.just(1)
    expected_lazy = Lazy(lambda: 1)

    # When
    lazy = maybe.to_lazy()

    # Then
    TestCase.assertEqual(TestCase(), lazy, expected_lazy)



# Generated at 2022-06-12 05:15:08.253489
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(5)



# Generated at 2022-06-12 05:15:11.264871
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(10, False) == Maybe.just(10)
    assert Maybe(20, True) == Maybe.nothing()


# Generated at 2022-06-12 05:15:21.078142
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def test_helper(first_value, second_value, expected_result):
        first_maybe = Maybe.just(first_value)
        second_maybe = Maybe.just(second_value)
        assert first_maybe.__eq__(second_maybe) == expected_result

    test_helper(1, 2, False)
    test_helper(1, 1, True)
    test_helper("a", "b", False)
    test_helper("a", "a", True)
    test_helper([1, 2], [2, 3], False)
    test_helper([1, 2], [1, 2], True)
    test_helper((1, 2), (2, 3), False)
    test_helper((1, 2), (1, 2), True)

# Generated at 2022-06-12 05:15:24.498557
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()


# Generated at 2022-06-12 05:15:35.619107
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Method filter must return Maybe[None] when filter returns False,
    in other case, return Maybe[A]
    """
    from pymonet.monad_maybe import Maybe

    def div(m, n):
        if n == 0:
            return Maybe.nothing()
        return Maybe.just(m / n)
    assert Maybe.just(5).bind(lambda x: div(x, 2)) == Maybe.just(2.5)
    assert Maybe.just(4).filter(lambda x: x % 2 == 0) == Maybe.just(4)
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()


# Generated at 2022-06-12 05:15:47.558770
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(None).filter(lambda x: x is None) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x is None) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x != 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(0.0).filter(lambda x: x is 0.0) == Maybe.just(0.0)
    assert Maybe.just(0.0).filter(lambda x: x == 0.0) == Maybe.just(0.0)
    assert Maybe.just("some string").filter(lambda x: x is "some string") == Maybe.just("some string")

# Generated at 2022-06-12 05:16:02.604804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.nothing().filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(False).filter(lambda x: x) == Maybe.nothing()
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)

# Generated at 2022-06-12 05:16:06.490643
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe(None, True).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:16:12.228754
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert(Maybe(
        10,
        False
    ).filter(
        lambda x: x > 0
    ) == Maybe(
        10,
        False
    ))
    assert(Maybe(
        -10,
        False
    ).filter(
        lambda x: x > 0
    ) == Maybe(
        None,
        True
    ))


# Generated at 2022-06-12 05:16:16.192078
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(42).filter(lambda x: x < 10) == Maybe.nothing()
    assert Maybe.just(42).filter(lambda x: x > 10) == Maybe.just(42)
    assert Maybe.nothing().filter(lambda x: x < 10) == Maybe.nothing()

# Generated at 2022-06-12 05:16:22.997530
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    m0 = Maybe.just(10)
    m1 = Maybe.nothing()

    a = m0.to_lazy()
    b = m1.to_lazy()

    assert isinstance(a, Lazy)
    assert isinstance(b, Lazy)
    assert a.__eval__() == 10
    assert b.__eval__() == None



# Generated at 2022-06-12 05:16:27.880432
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:16:31.017082
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:16:37.471494
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda num: num % 2 == 0) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda num: num % 2 != 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda num: num % 2 == 0) == Maybe.nothing()

# Generated at 2022-06-12 05:16:43.456664
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert 1 == Maybe.just(1)
    assert Maybe.just(2) == 2
    assert Maybe.nothing() == None
    assert None != Maybe.just(1)


# Generated at 2022-06-12 05:16:50.328643
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Given
    instance_of_maybe = Maybe(10, False)
    instance_of_maybe_2 = Maybe(10, False)
    instance_of_maybe_3 = Maybe(9, False)
    instance_of_maybe_4 = Maybe(10, True)

    # Then
    assert instance_of_maybe == instance_of_maybe_2
    assert instance_of_maybe != instance_of_maybe_3
    assert instance_of_maybe != instance_of_maybe_4



# Generated at 2022-06-12 05:17:06.085661
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != '1'



# Generated at 2022-06-12 05:17:10.610452
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-12 05:17:15.073350
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(8) == Maybe.just(8)
    assert Maybe.just(8) != Maybe.just(5)
    assert Maybe.just(8) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(8)


# Generated at 2022-06-12 05:17:16.738391
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(1)
    b = Maybe.just(1)
    assert a == b



# Generated at 2022-06-12 05:17:25.754547
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) == Maybe(10, False)
    assert Maybe(1, True) == Maybe(10, True)

    assert Maybe(1, True) == Maybe.nothing()
    assert Maybe(1, False) == Maybe.just(1)

    assert Maybe.just(1) != Maybe.just(10)
    assert Maybe.nothing() != Maybe.nothing()


# Generated at 2022-06-12 05:17:29.562474
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:17:31.918921
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe(1, False).to_lazy().f() == 1
    assert Maybe(None, True).to_lazy().f() == None


# Generated at 2022-06-12 05:17:35.581443
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:17:39.741842
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert isinstance(Maybe.just(1).filter(lambda x: x < 2), Maybe[int])
    assert isinstance(Maybe.nothing().filter(lambda x: x < 2), Maybe[None])


# Generated at 2022-06-12 05:17:44.268357
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()



# Generated at 2022-06-12 05:18:18.084637
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    x_maybe = Maybe.just(1)
    y_maybe = Maybe.just(2)
    assert x_maybe.filter(lambda x: x == 1) == x_maybe
    assert x_maybe.filter(lambda x: x != 1) != x_maybe
    assert x_maybe.filter(lambda x: x != 1).filter(lambda x: x == 1) != x_maybe
    assert x_maybe.filter(lambda x: x == 1).filter(lambda x: x != 1) != x_maybe
    assert y_maybe.filter(lambda x: x == 1) != x_maybe
    assert y_maybe.filter(lambda x: x == 2) == y_maybe
    assert y_maybe.filter(lambda x: x == 1).map(lambda x: x * 2) != y_maybe

# Generated at 2022-06-12 05:18:20.847176
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:18:25.084133
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(1, False)



# Generated at 2022-06-12 05:18:29.016282
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(12) == Maybe.just(12)
    assert Maybe.just(12) != Maybe.just(13)
    assert Maybe.just(12) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(12)


# Generated at 2022-06-12 05:18:32.236477
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy

    func = lambda x: x * 2

    maybe = Maybe.just(10)
    lazy = maybe.map(func).to_lazy()

    assert lazy.value() == 20


# Generated at 2022-06-12 05:18:35.456703
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda value: value > 0) == Maybe.just(1)
    assert Maybe(1, False).filter(lambda value: value < 0) == Maybe.nothing()
    assert Maybe(0, False).filter(lambda value: value == 0) == Maybe.just(0)

# Generated at 2022-06-12 05:18:41.177025
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet import is_equal

    assert is_equal(Maybe.just(1), Maybe.just(1)) == True
    assert is_equal(Maybe.just(1), Maybe.just(2)) == False
    assert is_equal(Maybe.just(1), Maybe.nothing()) == False
    assert is_equal(Maybe.nothing(), Maybe.nothing()) == True
    assert is_equal(Maybe[int].just(1), Maybe[int].nothing()).value == False


# Generated at 2022-06-12 05:18:48.386816
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    def empty_maybe():
        return Maybe.nothing()

    def not_empty_maybe():
        return Maybe.just("data")

    assert empty_maybe() == empty_maybe()
    assert not_empty_maybe() == not_empty_maybe()
    assert empty_maybe() != not_empty_maybe()
    assert empty_maybe() != "empty_maybe"
    assert not_empty_maybe() != "not_empty_maybe"


# Generated at 2022-06-12 05:18:52.861295
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(1)
    b = Maybe.just(1)
    assert a == b
    c = Maybe.just(2)
    assert a != c
    assert a != None
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:18:58.131024
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x % 2 == 0) == Maybe.just(2)
    assert Maybe.just(3).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x % 2 == 0) == Maybe.nothing()



# Generated at 2022-06-12 05:19:54.273384
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    m1 = Maybe.just(1)
    m2 = Maybe.just(0)
    m3 = Maybe.nothing()
    assert m1.filter(lambda x: x > 0) == Maybe.just(1)
    assert m1.filter(lambda x: x < 0) == Maybe.nothing()
    assert m2.filter(lambda x: x > 0) == Maybe.nothing()
    assert m2.filter(lambda x: x < 0) == Maybe.nothing()
    assert m3.filter(lambda x: x > 0) == Maybe.nothing()
    assert m3.filter(lambda x: x < 0) == Maybe.nothing()
    assert m3.filter(lambda x: False) is m3
    assert m3.filter(lambda x: True) is m3


# Generated at 2022-06-12 05:20:01.105792
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.

    :return: Nothing
    :rtype: None
    """
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(2, True) != Maybe(1, False)
    assert Maybe(1, True) != Maybe(1, False)


# Generated at 2022-06-12 05:20:03.898686
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != 1
    assert Maybe.nothing() != 1


# Generated at 2022-06-12 05:20:08.343143
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:20:19.844027
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    """
    Box monad should be return value or throw exception
    """
    from pymonet.lazy import attempt

    assert Maybe.just(42).to_lazy().evaluate() == 42
    assert Maybe.just(42.42).to_lazy().evaluate() == 42.42
    assert Maybe.just('Test').to_lazy().evaluate() == 'Test'
    assert attempt(lambda: Maybe.just(['a', 'b', 'c']).to_lazy().evaluate()) == ['a', 'b', 'c']
    assert Maybe.just({'a': 1, 'b': 2}).to_lazy().evaluate() == {'a': 1, 'b': 2}
    assert Maybe.nothing().to_lazy().evaluate() is None
    assert Maybe.just(True).to_lazy().evaluate() is True
   

# Generated at 2022-06-12 05:20:25.314613
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # When we compare Maybe.just(5) and Maybe.just(5), we expect True
    assert Maybe.just(5) == Maybe.just(5)
    # When we compare Maybe.nothing() and Maybe.nothing(), we expect True
    assert Maybe.nothing() == Maybe.nothing()
    # When we compare Maybe.just(5) and Maybe.nothing(), we expect False
    assert Maybe.just(5) != Maybe.nothing()
    # When we compare Maybe.nothing() and Maybe.just(5), we expect False
    assert Maybe.nothing() != Maybe.just(5)



# Generated at 2022-06-12 05:20:30.382737
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x > 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-12 05:20:34.875166
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 3) == Maybe.nothing()

# Unit tests for method get_or_else of class Maybe

# Generated at 2022-06-12 05:20:40.910541
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != None
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:20:42.374368
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)