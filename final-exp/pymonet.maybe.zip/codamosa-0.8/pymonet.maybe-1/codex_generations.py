

# Generated at 2022-06-12 05:11:05.535980
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != 1



# Generated at 2022-06-12 05:11:07.652830
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:11:11.573322
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(
        lambda value: value % 2 == 0
    ) == Maybe.just(2)
    assert Maybe.just(3).filter(
        lambda value: value % 2 == 0
    ) == Maybe.nothing()
    assert Maybe.nothing().filter(
        lambda value: value % 2 == 0
    ) == Maybe.nothing()


# Generated at 2022-06-12 05:11:17.924795
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:11:24.454720
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    import operator

    def add(a, b):
        return a + b

    add_lazy = Maybe.just(operator.add).ap(Lazy(lambda: 1)).ap(Lazy(lambda: 1))
    assert add_lazy == Lazy(lambda: add(1, 1))
    assert add_lazy.to_maybe().get_or_else(2) == 2
    assert add_lazy.run() == 2
    assert add_lazy.to_maybe() == Maybe.just(2)
    assert add_lazy.to_maybe() == Maybe.just(add(1, 1))
    assert str(add_lazy) == str(Lazy(lambda: add(1, 1)))



# Generated at 2022-06-12 05:11:34.616697
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_true = Maybe.just(True)
    maybe_false = Maybe.just(False)
    maybe_empty = Maybe.nothing()

    assert maybe_true.filter(lambda a: a) == Maybe.just(True)
    assert maybe_true.filter(lambda a: not a) == Maybe.nothing()
    assert maybe_false.filter(lambda a: a) == Maybe.nothing()
    assert maybe_false.filter(lambda a: not a) == Maybe.just(False)
    assert maybe_empty.filter(lambda a: a) == Maybe.nothing()
    assert maybe_empty.filter(lambda a: not a) == Maybe.nothing()



# Generated at 2022-06-12 05:11:36.515369
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(40) == Maybe.just(40)
    assert Maybe.just(12) != Maybe.just(40)
    assert Maybe.just(40) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:11:50.364265
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(2, True) == Maybe(2, True)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe(2, True) != Maybe(2, False)
    assert Maybe(2, False) != Maybe(2, 3)
    assert Maybe(2, True) != Maybe(3, False)
    assert Maybe(2, False) != Maybe(2, 3, 4)
    assert Maybe(2, True) != Maybe(3, False, 5)
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(3)


# Generated at 2022-06-12 05:11:55.649308
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(7) == Maybe.just(7)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(7) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(7)
    assert Maybe.just(7) != Maybe.just(8)
    assert Maybe.just(7) == Maybe.just(7.0)



# Generated at 2022-06-12 05:12:00.275716
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 3) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 3) == Maybe.just(5)
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:12:05.703594
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_try import Try, Success, Failure

    assert Maybe.just("test").to_lazy() == Lazy(lambda: "test")

# Generated at 2022-06-12 05:12:10.503391
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()

# Unit tests for method just and nothing of class Maybe

# Generated at 2022-06-12 05:12:14.046229
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:17.880097
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:12:19.289330
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Maybe.just(1).to_lazy()
    assert Lazy(lambda: None) == Maybe.nothing().to_lazy()


# Generated at 2022-06-12 05:12:25.116548
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe_1 = Maybe.just(1)
    maybe_2 = Maybe.just(2)
    maybe_3 = Maybe.just(1)
    maybe_4 = Maybe.just(None)
    maybe_5 = Maybe.nothing()
    maybe_6 = Maybe.nothing()

    assert maybe_1 == maybe_3
    assert maybe_1 != maybe_2
    assert maybe_1 != maybe_4
    assert maybe_1 != maybe_5
    assert maybe_5 == maybe_6
    assert maybe_5 != maybe_1



# Generated at 2022-06-12 05:12:34.801756
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(0).to_lazy().eval() == 0
    assert Maybe.just(1).to_lazy().eval() == 1
    assert Maybe.nothing().to_lazy().eval() is None
    assert Maybe.just(7).to_lazy().map(lambda value: value + 1).eval() == 8
    assert Maybe.nothing().to_lazy().map(lambda value: value + 1).eval() is None
    assert Maybe.just(7).to_lazy().bind(lambda value: Maybe.just(value + 1)).eval() == 8
    assert Maybe.nothing().to_lazy().bind(lambda value: Maybe.just(value + 1)).eval() is None


# Generated at 2022-06-12 05:12:37.944386
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(9).to_lazy() == Lazy(lambda: 9)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:12:41.816786
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:12:46.076471
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(43)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:12:52.556942
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda a: a == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda a: a == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:12:56.544272
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(42) != Maybe.just(14)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)



# Generated at 2022-06-12 05:12:59.380618
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:13:02.079125
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe.just(6).filter(lambda x: x % 2 == 0) == Maybe.just(6)

# Generated at 2022-06-12 05:13:09.768804
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    first_just = Maybe.just(1)
    second_just = Maybe.just(2)
    assert first_just != second_just
    assert first_just.filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert first_just.filter(lambda x: x % 2 == 1) == first_just
    assert second_just.filter(lambda x: x % 2 == 0) == second_just
    assert second_just.filter(lambda x: x % 2 == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:13:15.222815
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    just_value = Maybe.just(1)
    another_value = Maybe.just(1)
    value = Maybe.just(2)
    nothing = Maybe.nothing()

    assert (just_value == another_value) == True
    assert (just_value == value) == False
    assert (just_value == nothing) == False


# Generated at 2022-06-12 05:13:17.952555
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False).__eq__(Maybe.just(1))
    assert not Maybe(1, False).__eq__(Maybe.just(2))



# Generated at 2022-06-12 05:13:25.829539
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe(1, False).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Lazy(lambda: 1).is_equivalent_to(Maybe(1, False).to_lazy())
    assert Maybe.nothing().to_lazy().is_equivalent_to(Lazy(lambda: None))



# Generated at 2022-06-12 05:13:30.239360
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, True)


# Generated at 2022-06-12 05:13:32.401846
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def positive_mapper(x):
        return x > 0
    assert Maybe.just(1).filter(positive_mapper) == Maybe.just(1)
    assert Maybe.just(0).filter(positive_mapper) == Maybe.nothing()



# Generated at 2022-06-12 05:13:39.996811
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-12 05:13:46.409386
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert Maybe.just(1).__eq__(Maybe.just(2)) is False
    assert Maybe.just(1).__eq__(Maybe.nothing()) is False
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert Maybe.nothing().__eq__(Maybe.just(1)) is False
    assert Maybe.nothing().__eq__(None) is False



# Generated at 2022-06-12 05:13:52.873231
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(4, False).filter(lambda x: x == 4) == Maybe(4, False)
    assert Maybe(4, False).filter(lambda x: x == 3) == Maybe.nothing()
    assert Maybe(4, True).filter(lambda x: x == 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 4) == Maybe.nothing()



# Generated at 2022-06-12 05:14:03.806623
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet import Just, Nothing, Maybe

    assert Nothing().filter(lambda x: x == "value") == Nothing()
    assert Just("value").filter(lambda x: x == "value") == Just("value")
    assert Just("value").filter(lambda x: x == "value1") == Nothing()
    assert Just("value").filter(lambda x: x == "val") == Nothing()
    assert Maybe.just("value").filter(lambda x: x == "value") == Maybe.just("value")
    assert Maybe.just("value").filter(lambda x: x == "value1") == Maybe.nothing()
    assert Maybe.just("value").filter(lambda x: x == "val") == Maybe.nothing()



# Generated at 2022-06-12 05:14:08.068856
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:14:10.560116
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:14:17.494933
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe(3, False)
    b = Maybe(3, False)
    c = Maybe(2, False)
    d = Maybe(None, True)
    e = Maybe(None, True)
    f = Maybe(3, True)

    assert a == b
    assert not a == c
    assert not a == d
    assert not a == f
    assert d == e
    assert not d == f

# Generated at 2022-06-12 05:14:20.793888
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, True) == Maybe(5, True)
    assert Maybe(5, False) != Maybe(3, False)
    assert Maybe(5, True) != Maybe(3, True)


# Generated at 2022-06-12 05:14:23.712816
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(2, False) != Maybe(2, True)
    assert Maybe("a", False) != Maybe("b", False)
    assert Maybe("a", False) != Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)


# Generated at 2022-06-12 05:14:26.144720
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:14:33.776962
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x < 4) == Maybe.nothing()
    assert Maybe.just(4).filter(lambda x: x < 5) == Maybe.just(4)
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:14:37.615846
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe(None, True)
    m2 = Maybe(None, True)
    m3 = Maybe(1, False)
    assert m1 == m2
    assert m1 != m3


# Generated at 2022-06-12 05:14:42.001891
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:14:46.178373
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just("string") == Maybe.nothing() is False
    assert Maybe.just("string") == Maybe.just("string") is True
    assert Maybe.nothing() == Maybe.nothing() is True
    assert Maybe.just("string") == "string" is False


# Generated at 2022-06-12 05:14:52.835961
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():

    def verify(left: Maybe[T], right: Maybe[T], expected):
        assert left == right == expected

    verify(Maybe.just(1), Maybe.just(1), True)
    verify(Maybe.just(1), Maybe.just(2), False)
    verify(Maybe.just(1), Maybe.nothing(), False)
    verify(Maybe.nothing(), Maybe.just(1), False)
    verify(Maybe.nothing(), Maybe.nothing(), True)



# Generated at 2022-06-12 05:15:01.314886
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Arrange
    maybe_one = Maybe.just(1)
    maybe_two = Maybe.just(2)
    maybe_tree = Maybe.just(3)
    maybe_empty_one = Maybe.nothing()
    maybe_empty_two = Maybe.nothing()
    # Act
    result_one = maybe_one.filter(lambda x: x % 2 == 1)
    result_two = maybe_two.filter(lambda x: x % 2 == 1)
    result_tree = maybe_tree.filter(lambda x: x % 2 == 1)
    result_empty_one = maybe_empty_one.filter(lambda x: x % 2 == 1)
    result_empty_two = maybe_empty_two.filter(lambda x: x % 2 == 1)
    # Assert
    assert result_one == maybe_one

# Generated at 2022-06-12 05:15:08.401921
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    def call_value(value):
        return value

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_lazy().map(call_value) == Lazy(lambda: 1).map(call_value)


# Unit test method bind of class Maybe

# Generated at 2022-06-12 05:15:14.095024
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()


# Generated at 2022-06-12 05:15:20.901366
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.just(10) == Maybe(10, False)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)
    assert Maybe.just(10) != Maybe.just(11)
    assert Maybe.just(10) != Maybe(11, False)
    assert Maybe.nothing() != Maybe(None, False)
    assert Maybe.nothing() != Maybe(None, False)


# Generated at 2022-06-12 05:15:28.423970
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    actual = Maybe.just(10).filter(lambda x: x > 9)
    expected = Maybe.just(10)
    assert actual == expected

    actual = Maybe.just(9).filter(lambda x: x > 9)
    expected = Maybe.nothing()
    assert actual == expected

    actual = Maybe.nothing().filter(lambda x: x > 9)
    expected = Maybe.nothing()
    assert actual == expected



# Generated at 2022-06-12 05:15:38.097304
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just(3) == Maybe(3, False)
    assert Maybe.just(3) != Maybe(3, True)
    assert Maybe.nothing() == Maybe(None, True)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()


# Unit tests for method map of class Maybe

# Generated at 2022-06-12 05:15:43.265517
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-12 05:15:47.891121
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(10).filter(lambda x: x > 15) == Maybe.nothing()
    assert Maybe.just(16).filter(lambda x: x > 15) == Maybe.just(16)
    assert Maybe(16, True).filter(lambda x: x > 15) == Maybe.nothing()

# Generated at 2022-06-12 05:15:51.475198
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x % 2) == Maybe.nothing()
    assert Maybe.just(2).filter(lambda x: x % 2) == Maybe.just(2)



# Generated at 2022-06-12 05:15:55.156830
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:15:58.705482
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)



# Generated at 2022-06-12 05:16:02.287171
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(2, False)


# Generated at 2022-06-12 05:16:08.567802
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # case of empty Maybe
    assert Maybe.nothing().filter(lambda x: x < 0) == Maybe.nothing()
    # case of not empty Maybe with filterer returns False
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    # case of not empty Maybe with filterer returns True
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)


# Generated at 2022-06-12 05:16:13.149108
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:16:16.691295
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)



# Generated at 2022-06-12 05:16:29.819496
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.just(5) != Maybe.nothing
    assert Maybe.nothing == Maybe.nothing


# Generated at 2022-06-12 05:16:36.033542
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.monad_or import Or
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    assert Maybe.just(3).to_lazy() == Lazy(lambda: 3)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(3).to_box() == Box(3)
    assert Maybe.nothing().to_box() == Box(None)
    assert Maybe.just(3).to_either() == Right(3)
    assert Maybe.nothing().to_either() == Left(None)
    assert Maybe.just(3).to_try() == Try(3, is_success=True)
    assert Maybe.nothing().to_try() == Try(None, is_success=False)

# Generated at 2022-06-12 05:16:40.763969
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    value = 'test'
    maybe_left = Maybe.just(value)
    maybe_right = Maybe.just(value)
    assert maybe_left == maybe_right
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:16:46.109656
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(None, True) == Maybe(None, True)
    assert Maybe(2, False) != Maybe(None, True)
    assert Maybe(None, True) != Maybe(2, False)
    assert Maybe(2, False) != 2
    None


# Generated at 2022-06-12 05:16:56.747378
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, True) == Maybe.nothing()
    assert Maybe(1, True) == Nothing()
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(1, False) == Box(1)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, False) != Maybe.nothing()
    assert Maybe(1, False) != Nothing()
    assert Maybe(1, True) != Maybe.just(1)
    assert Maybe(1, True) != Box(1)

# Static unit test for method nothing of class Maybe

# Generated at 2022-06-12 05:17:00.443223
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(6)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:17:03.861118
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x > 0) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 0) == Maybe.nothing()

# Generated at 2022-06-12 05:17:08.502933
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def test_filterer(value):
        return value == "filter"

    assert Maybe.just("filter").filter(test_filterer) == Maybe.just("filter")
    assert Maybe.just("not filter").filter(test_filterer) == Maybe.nothing()



# Generated at 2022-06-12 05:17:13.715415
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("pymonet").filter(lambda x: len(x) == 7) == Maybe.just("pymonet")
    assert Maybe.just("pymonet").filter(lambda x: len(x) == 8) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: len(x) == 7) == Maybe.nothing()


# Generated at 2022-06-12 05:17:20.176593
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe.
    """
    assert Maybe(4, False).filter(lambda x: True) == Maybe(4, False)
    assert Maybe(4, False).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: False) == Maybe.nothing()


# Generated at 2022-06-12 05:17:42.628822
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Setup
    maybe1 = Maybe.just(5)
    maybe2 = Maybe.nothing()
    maybe3 = Maybe.just(5)

    # Exercise
    result1 = maybe1 == maybe2
    result2 = maybe2 == maybe3
    result3 = maybe1 == maybe3

    # Verify
    assert result1 == False
    assert result2 == True
    assert result3 == False



# Generated at 2022-06-12 05:17:46.651678
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:17:49.972884
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) and \
           Maybe.just(2) != Maybe.just(1) and \
           Maybe.nothing() == Maybe.nothing() and \
           Maybe.nothing() != Maybe.just(1) and \
           Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:17:53.316277
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('a') == Maybe.just('a')
    assert Maybe.just('a') != Maybe.just('b')
    assert Maybe.just('b') != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:17:57.218243
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # not equal to Maybe[None] and Maybe[Integer]=Maybe[2]
    assert Maybe.nothing() != Maybe.just(1)
    # equal to Maybe[None] and Maybe[None]
    assert Maybe.nothing() == Maybe.nothing()
    # equal to Maybe[Integer]=Maybe[2] and Maybe[Integer]=Maybe[2]
    assert Maybe.just(1) == Maybe.just(1)


# Generated at 2022-06-12 05:18:01.902870
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:18:09.330929
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.functor import Functor

    m = Maybe.just(2)

    m = Functor.box(m).filter(lambda i: i == 2)
    assert m == Maybe.just(2)

    m = Functor.box(m).filter(lambda i: i == 3)
    assert m == Maybe.nothing()

    n = Functor.box(Maybe.nothing())
    assert n == n.filter(lambda x: True)
    assert n == n.filter(lambda x: False)

    m = Functor.box(Maybe.just(3))
    assert m == m.filter(lambda x: True)
    assert Maybe.nothing() == m.filter(lambda x: False)



# Generated at 2022-06-12 05:18:15.149355
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just([])
    assert Maybe.just(1) != DifferenceMaybe(True)


# Generated at 2022-06-12 05:18:19.795768
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just("PyMonet") == Maybe.just("PyMonet")
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe("PyMonet", False) == Maybe("PyMonet", False)


test_Maybe___eq__()



# Generated at 2022-06-12 05:18:29.534546
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_test import test_monad_lazy

    monad_test = test_monad_lazy(Lazy, Maybe)
    monad_test(
        assert_equal=Maybe.just('test'),
        assert_not_equal=Maybe.just('test'),
        assert_functor_identity_s='test',
        assert_functor_composition_s='test',
        assert_applicative_identity_s='test',
        assert_applicative_homomorphism='test',
        assert_applicative_interchange='test',
        assert_monad_left_identity='test',
        assert_monad_right_identity='test'
    )

# Generated at 2022-06-12 05:18:48.050591
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(4) == Maybe.just(4)
    assert Maybe.just(4) != Maybe.nothing()



# Generated at 2022-06-12 05:18:53.752217
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda x: x > 2) == Maybe.just(5)
    assert Maybe.just(3).filter(lambda x: x > 2) == Maybe.just(3)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()

# Generated at 2022-06-12 05:19:02.793101
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(5, False) == Maybe(5, False)
    assert Maybe(5, False) != Maybe(3, False)
    assert Maybe(5, True) != Maybe(3, True)
    assert Maybe(5, False) != Maybe(None, True)
    assert Maybe(5, False) != Maybe(None, False)
    assert Maybe(5, False) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(None) != Maybe.just(None)
    assert Maybe.just(4) == Maybe(4, False)


# Generated at 2022-06-12 05:19:09.150555
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(1).filter(lambda x: x == 2) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x == 2) == Maybe.nothing()


# Generated at 2022-06-12 05:19:14.501534
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('hello') == Maybe.just('hello')
    assert Maybe.just(lambda x: x) == Maybe.just(lambda x: x)
    assert Maybe.just({'hello': 'world'}) == Maybe.just({'hello': 'world'})
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:19:18.103485
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1.0) == Maybe.just(1.0)
    assert Maybe.just(1) != Maybe.just(0)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:19:21.181458
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) and \
        Maybe.just(1) != Maybe.nothing()

# Generated at 2022-06-12 05:19:25.142920
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:19:27.787944
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:19:37.146339
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.just('str') == Maybe.just('str')
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(0) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()
    assert Maybe.just('') != Maybe.nothing()
    assert Maybe.just('str') != Maybe.nothing()
    assert Maybe.just(['a', 'b']) != Maybe.nothing()

    assert Maybe.just(5) != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(3)
    assert Maybe.just('a') != Maybe.just('b')


# Generated at 2022-06-12 05:19:58.497174
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe(2, False).filter(lambda x: x > 1) == Maybe(2, False)
    assert Maybe(1, True).filter(lambda x: x > 1) == Maybe.nothing()



# Generated at 2022-06-12 05:20:03.254125
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Case: two not empty Maybes with same value
    assert(Maybe.just(1) == Maybe.just(1))

    # Case: two Maybes with same value, but one of them is empty
    assert(Maybe.just(1) != Maybe.nothing())

    # Case: two Maybe with different values
    assert(Maybe.just(1) != Maybe.just(2))


# Generated at 2022-06-12 05:20:08.343545
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    l = Lazy(lambda: 5)
    m = Maybe.just(5)
    v = Validation.success(5)
    assert l == m
    assert m == v
    assert l == v


# Generated at 2022-06-12 05:20:12.560560
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:20:19.014340
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe("123", False) == Maybe("123", False)
    assert Maybe(True, False) == Maybe(True, False)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe(1, False)
    assert Maybe(1, False) != Maybe("123", False)
    assert Maybe(1, False) != Maybe.nothing()



# Generated at 2022-06-12 05:20:22.227582
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.just(23) != Maybe.just(42)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe(None, True)



# Generated at 2022-06-12 05:20:26.850569
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(1)


# Generated at 2022-06-12 05:20:31.991628
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3) == Maybe.just(3)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(3) != Maybe.nothing()
    assert Maybe.just(3) != Maybe.just(4)
    assert Maybe.nothing() != Maybe.just(4)



# Generated at 2022-06-12 05:20:34.803582
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(1, False).filter(lambda x: x == 1) == Maybe(1, False)
    assert Maybe.nothing().filter(lambda x: x == 1) == Maybe.nothing()


# Generated at 2022-06-12 05:20:47.158002
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(125).to_lazy() == Lazy(lambda: 125)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(1).to_either() == Right(1)
    assert Maybe.nothing().to_either() == Maybe.nothing().to_either()
    assert Maybe.just(1).to_box() == Box(1)
    assert Maybe.nothing().to_box() == Maybe.nothing().to_box()
    assert Maybe.just(1).to_try() == Try(1, is_success=True)
