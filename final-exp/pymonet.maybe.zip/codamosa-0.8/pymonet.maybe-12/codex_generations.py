

# Generated at 2022-06-12 05:11:06.845792
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:11:12.382377
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    one = Maybe.just(1)
    none = Maybe.nothing()

    assert one.filter(lambda x: x == 1) == Maybe.just(1)
    assert one.filter(lambda x: x == 0) == Maybe.nothing()
    assert one.filter(lambda x: x == 0).filter(lambda x: x == 1) == Maybe.nothing()

    assert none.filter(lambda x: x == 0) == Maybe.nothing()
    assert none.filter(lambda x: x == 0).filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:11:22.092926
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    m = Maybe.nothing()
    assert m.filter(lambda x: x > 2).is_nothing
    m = Maybe.just(3)
    assert m.filter(lambda x: x > 2).value == 3

    m = Maybe.nothing()
    assert m.filter(lambda x: x < 2).is_nothing
    m = Maybe.just(1)
    assert m.filter(lambda x: x < 2).value == 1

    m = Maybe.nothing()
    assert Try(None).__eq__(m.to_try())
    m = Maybe.just(4)
    assert Try

# Generated at 2022-06-12 05:11:29.736988
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)


# Generated at 2022-06-12 05:11:36.613166
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(2, False) == Maybe(2, False)
    assert Maybe(2, True) == Maybe(2, True)
    assert Maybe(2, False) != Maybe('a', False)
    assert Maybe(2, False) != Maybe('a', True)
    assert Maybe(2, True) != Maybe(2, False)


# Generated at 2022-06-12 05:11:39.176855
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    Maybe(12, False) == Maybe(12, False)


# Generated at 2022-06-12 05:11:44.000089
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(5) == Maybe.just(5)
    assert Maybe.just(5) != Maybe.just(4)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)


# Generated at 2022-06-12 05:11:50.735404
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(None) != Maybe.nothing()


# Generated at 2022-06-12 05:11:55.647464
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()

    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)

    assert Maybe.just(1) != Maybe.nothing()
    assert not Maybe.just(1) != Maybe.just(1)



# Generated at 2022-06-12 05:12:01.062872
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    lazy1 = Maybe.just('value').to_lazy()
    assert isinstance(lazy1, Lazy)
    assert lazy1.get() == 'value'

    lazy2 = Maybe.nothing().to_lazy()
    assert isinstance(lazy2, Lazy)
    assert lazy2.get() is None



# Generated at 2022-06-12 05:12:10.195254
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    def _identity(value):
        return value

    maybe_value = Maybe.just(2)
    lazy_result = maybe_value.to_lazy()
    lazy_action = lazy_result.map(_identity)
    assert maybe_value == Functor.of(type(maybe_value), lazy_action())

# Generated at 2022-06-12 05:12:16.795528
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    :returns: null
    :rtype: null
    """
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(2).filter(lambda x: x < 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()



# Generated at 2022-06-12 05:12:25.960383
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe(1, True)

    assert Maybe.just(1) == Maybe.just(1).to_box()
    assert Maybe.just(1) == Maybe.just(1).to_lazy()
    assert Maybe.just(1) == Maybe.just(1).to_try()
    assert Maybe.just

# Generated at 2022-06-12 05:12:30.124355
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(True).to_lazy() == Lazy(lambda: True)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:12:32.296067
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    assert Maybe.just(3).to_lazy().get() == 3
    assert Maybe.nothing().to_lazy().get() is None



# Generated at 2022-06-12 05:12:41.987337
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Maybe.just(5).filter(lambda x: x < 10 and x > 4) == Maybe.just(5)
    assert Maybe.just(10).filter(lambda x: x < 10 and x > 4) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x < 10 and x > 4) == Maybe.nothing()

    assert Maybe.just(5).map(lambda x: x < 10 and x > 4) == Box(True)
    assert Maybe.just(10).map(lambda x: x < 10 and x > 4) == Box(False)

# Generated at 2022-06-12 05:12:46.180141
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    maybe = Maybe.just(1)
    assert maybe.to_lazy() == Lazy(lambda: 1)

    maybe = Maybe.nothing()
    assert maybe.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:12:52.359837
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    def filterer(a):
        return a > 10

    # Test normal case
    result = Maybe.just(18).filter(filterer)
    assert isinstance(result, Maybe)
    assert not result.is_nothing
    assert result.value == 18

    # Test with empty Maybe
    result = Maybe.nothing().filter(filterer)
    assert isinstance(result, Maybe)
    assert result.is_nothing


# Generated at 2022-06-12 05:12:57.082993
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:13:00.409042
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:13:08.812872
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_int = Maybe.just(5)
    is_five = lambda x: x == 5
    assert maybe_int.filter(is_five).is_nothing == False
    assert maybe_int.filter(is_five).value == 5

    maybe_none = Maybe.nothing()
    assert maybe_none.filter(is_five).is_nothing == True


# Generated at 2022-06-12 05:13:10.840982
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:13:17.652546
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert not Maybe.just(1) == Maybe.just(2)
    assert Maybe.just(1) == Maybe.just("1")
    assert Maybe.nothing() == Maybe.nothing()
    assert not Maybe.just(1) == Maybe.nothing()
    assert not Maybe.nothing() == Maybe.just(1)

# Unit tests for method just of class Maybe

# Generated at 2022-06-12 05:13:19.871346
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(3).__eq__(Maybe.just(3))
    assert Maybe.nothing().__eq__(Maybe.nothing())



# Generated at 2022-06-12 05:13:26.658553
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from .lazy import Lazy

    assert Maybe.just(5).filter(lambda x: x > 1) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda x: x > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.just(5).filter(lambda x: x > 10) == Maybe.nothing()
    assert Maybe.just(Lazy(lambda: 5)).filter(lambda x: x.get() > 1) == Maybe.just(Lazy(lambda: 5))
    assert Maybe.just(Lazy(lambda: 5)).filter(lambda x: x.get() > 5) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x.get() > 1) == Maybe.nothing()
    assert Maybe.just

# Generated at 2022-06-12 05:13:33.396067
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) == None
    assert None == Maybe.just(1)
    assert Maybe.nothing() == None
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:13:37.619118
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)


# Generated at 2022-06-12 05:13:43.948238
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet.constructors import Just, Nothing
    from pymonet.test.test_utils import assert_maybe_eq

    assert_maybe_eq(Just(1) == Just(1), True)
    assert_maybe_eq(Just(1) == Just(2), False)
    assert_maybe_eq(Just(1) == Nothing(), False)
    assert_maybe_eq(Nothing() == Nothing(), True)
    assert_maybe_eq(Nothing() == Just(1), False)



# Generated at 2022-06-12 05:13:47.641707
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(3, False).filter(lambda x: x % 2 == 0) == Maybe.nothing()
    assert Maybe(4, False).filter(lambda x: x % 2 == 0) == Maybe.just(4)



# Generated at 2022-06-12 05:13:52.784296
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(0, is_nothing=False).filter(lambda x: x != 0) == Maybe.nothing()
    assert Maybe(1, is_nothing=False).filter(lambda x: x != 0) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda x: x != 0) == Maybe.nothing()


# Generated at 2022-06-12 05:14:01.959890
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1) and Maybe.just(2) == Maybe.just(2) and \
        Maybe.nothing() == Maybe.nothing() and Maybe.just(1) != Maybe.just(2) and Maybe.just(1) != Maybe.nothing() and \
        Maybe.nothing() != Maybe.just(2)


# Generated at 2022-06-12 05:14:05.469350
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(2) != Maybe.nothing()

# Generated at 2022-06-12 05:14:09.668876
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Maybe.just(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:14:13.908555
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:14:19.772385
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(10) == Maybe.just(10) == Maybe[int](10, is_nothing=False)
    assert Maybe.nothing() == Maybe.nothing() == Maybe[int](None, is_nothing=True)
    assert Maybe.just(10) != Maybe.just(20)
    assert Maybe.just(10) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(10)


# Generated at 2022-06-12 05:14:25.603246
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:14:35.274005
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe.just(1)
    assert Maybe(1, True) == Maybe.nothing()
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, True) != Maybe(2, True)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.nothing() != Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:14:43.266107
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(2)
    m2 = Maybe.just(2)
    m3 = Maybe.just(3)
    m4 = Maybe.nothing()
    m5 = Maybe.nothing()

    assert not m1.__eq__(m3)
    assert not m1.__eq__(m4)
    assert not m4.__eq__(m1)
    assert m1.__eq__(m2)
    assert m4.__eq__(m5)

# Generated at 2022-06-12 05:14:46.334269
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(2) == Maybe.just(2)


# Generated at 2022-06-12 05:14:51.278553
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(42) == Maybe.just(42)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(42) != Maybe.just(24)
    assert Maybe.just(42) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(42)


# Generated at 2022-06-12 05:15:00.197590
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(3).filter(lambda v: v == 3) == Maybe.just(3)
    assert Maybe.just(3).filter(lambda v: v == 2) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda v: v == 5) == Maybe.nothing()

    assert Maybe.nothing().filter(lambda v: v == 3) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v == 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda v: v == 5) == Maybe.nothing()


# Generated at 2022-06-12 05:15:04.614758
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda n: n > 10) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda n: n > 0) == Maybe.just(1)



# Generated at 2022-06-12 05:15:08.451001
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    from pymonet.lazy import Lazy

    assert Maybe.just(5).to_lazy() == Lazy(lambda: 5)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:15:19.798362
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.monad_test_utils import assert_monad_maybe_law, assert_maybe_identity_law
    from pymonet.monad import Monad

    for i in range(10):
        maybe = Maybe.just(i)
        maybe_result = maybe.filter(lambda x: x % 2 == 0)
        assert((maybe_result == Maybe.just(i) and i % 2 == 0) or
               (maybe_result == Maybe.nothing() and i % 2 != 0))

    maybe = Maybe.nothing()
    assert maybe.filter(lambda x: True) == maybe

    func_a_b = lambda a: Maybe.just(a + 1)
    assert_maybe_identity_law(func_a_b, Maybe.just(5))

# Generated at 2022-06-12 05:15:23.374424
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)


# Generated at 2022-06-12 05:15:28.479913
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:15:33.852989
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    assert Maybe.just(10).filter(lambda n: n == 10) == Maybe.just(10)
    assert Maybe.just(10).filter(lambda n: n == 11) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n == 10) == Maybe.nothing()



# Generated at 2022-06-12 05:15:37.496835
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)
    assert Maybe.just(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:15:45.380956
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    """
    Unit test for method filter of class Maybe

    :returns: None
    :rtype: None
    """
    def is_even(value):
        return value % 2 == 0

    assert Maybe.just(2).filter(is_even) == Maybe.just(2)
    assert Maybe.just(1).filter(is_even) == Maybe.nothing()
    assert Maybe.nothing().filter(is_even) == Maybe.nothing()


# Generated at 2022-06-12 05:15:49.983245
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # arrange
    x = Maybe.just(1)
    y = Maybe.nothing()

    # act
    result = x.filter(lambda value: value == 1)
    result_none = y.filter(lambda value: value == 1)

    # assert
    assert result == Maybe.just(1)
    assert result_none == Maybe.nothing()

# Generated at 2022-06-12 05:15:56.368865
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a = Maybe.just(None)
    b = Maybe.just(1)
    c = Maybe.just(2)
    d = Maybe.just(2)
    assert a != b
    assert b != c
    assert c == d



# Generated at 2022-06-12 05:16:02.516202
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # given

    # when
    just_value = Maybe.just("value")
    nothing_value = Maybe.nothing()
    maybe_list = [maybe_value for maybe_value in [just_value, nothing_value]]

    # then
    assert just_value != None
    assert just_value == maybe_list[0]
    assert just_value != maybe_list[1]
    assert nothing_value == maybe_list[1]
    assert nothing_value != maybe_list[0]


# Generated at 2022-06-12 05:16:07.075463
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    a: Maybe[int] = Maybe.just(1)
    b: Maybe[int] = Maybe.just(1)
    assert a == b
    b = Maybe.just(2)
    assert a != b
    b = Maybe.nothing()
    assert a != b
    a = Maybe.nothing()
    assert a == b


# Generated at 2022-06-12 05:16:11.359278
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(3)


# Generated at 2022-06-12 05:16:19.488878
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from hypothesis import given
    from hypothesis.strategies import integers
    from hypothesis.strategies import booleans

    @given(integers(), integers())
    def inner_test_Maybe___eq__(first, second):
        assert Maybe.just(first) == Maybe.just(second) == (first == second)

    inner_test_Maybe___eq__()

    @given(integers(), booleans())
    def inner_test_Maybe___eq__(second, is_nothing):
        assert Maybe.just(None) == Maybe(None, is_nothing) == is_nothing

    inner_test_Maybe___eq__()


# Generated at 2022-06-12 05:16:24.424367
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: True) == Maybe.just(True)
    assert Maybe.just(True).filter(lambda x: False) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()
    assert Maybe.just(True).not_empty
    assert not Maybe.nothing().not_empty



# Generated at 2022-06-12 05:16:34.238255
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda n: n % 2 == 0) == \
        Maybe.nothing()
    assert Maybe.just(5).filter(lambda n: n % 2 == 1) == \
        Maybe.just(5)
    assert Maybe.just(6).filter(lambda n: n % 2 == 0) == \
        Maybe.just(6)
    assert Maybe.just(6).filter(lambda n: n % 2 == 1) == \
        Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n % 2 == 0) == \
        Maybe.nothing()
    assert Maybe.nothing().filter(lambda n: n % 2 == 1) == \
        Maybe.nothing()


# Generated at 2022-06-12 05:16:39.173771
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(11) == Maybe.just(11)
    assert Maybe.just(22) != Maybe.just(11)
    assert Maybe.just(22) != Maybe.nothing()

test_Maybe___eq__()



# Generated at 2022-06-12 05:16:42.349499
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(123) == Maybe.just(123)
    assert Maybe.just(123) != Maybe.just(321)
    assert Maybe.just(123) != Maybe.nothing()



# Generated at 2022-06-12 05:16:47.897694
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe = Maybe.just(1).filter(lambda x: x > 2)
    assert maybe == Maybe.nothing()
    maybe = Maybe.just(1).filter(lambda x: x < 2)
    assert maybe == Maybe.just(1)
    maybe = Maybe.nothing().filter(lambda x: x < 2)
    assert maybe == Maybe.nothing()


# Generated at 2022-06-12 05:16:53.419986
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(True).filter(lambda x: x).is_nothing == False
    assert Maybe.just(False).filter(lambda x: x).is_nothing == True

# Generated at 2022-06-12 05:16:59.823467
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    # Test empty Maybe
    assert Maybe.nothing().filter(lambda x: x is not None) == Maybe.nothing()

    # Test Maybe with value and filterer returning True
    assert Maybe.just(True).filter(lambda x: x) == Maybe.just(True)

    # Test Maybe with value and filterer returning False
    assert Maybe.just(True).filter(lambda x: False) == Maybe.nothing()

# Generated at 2022-06-12 05:17:02.817920
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:17:07.863244
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just("option").filter(lambda x: x == "option") == Maybe.just("option")
    assert Maybe.just("option").filter(lambda x: x == "opt") == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: True) == Maybe.nothing()


# Generated at 2022-06-12 05:17:17.663105
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.
    """
    from tests.helper import method_test_wrapper
    from collections import namedtuple

    def unit_test(method_under_test, l_value, r_value, expected):
        """
        Unit test function for testing method __eq__ of class Maybe.

        :param method_under_test: tested method
        :type method_under_test: Method
        :param l_value: left value for comparison
        :type l_value: Any
        :param r_value: right value for comparison
        :type r_value: Any
        :param expected: expected result of comparison
        :type expected: bool
        """
        assert method_under_test(l_value, r_value) == expected


# Generated at 2022-06-12 05:17:23.230955
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        print('f')
        return 42

    maybe = Maybe.just(f)
    lazy = maybe.to_lazy()

    assert isinstance(lazy, Lazy) is True
    assert lazy.value() == f()


# Generated at 2022-06-12 05:17:29.413097
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    try:
        from pymonet.lazy import Lazy
        assert (Maybe(None, True).to_lazy() == Lazy(lambda: None))
        assert (Maybe.just(10).to_lazy() == Lazy(lambda: 10))
        print("test_Maybe_to_lazy: ok")
    except Exception as e:
        print("test_Maybe_to_lazy: fail")
        print(e)
        assert False

# Generated at 2022-06-12 05:17:37.199306
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert Maybe.just(2).__eq__(Maybe.just(2))
    assert Maybe.just(3).__eq__(Maybe.just(3))
    assert Maybe.nothing().__eq__(Maybe.nothing())
    assert Maybe.just(1).__eq__(Maybe.just(1))
    assert Maybe.just(2).__eq__(Maybe.just(2))
    assert Maybe.just(3).__eq__(Maybe.just(3))
    assert not Maybe.nothing().__eq__(Maybe.just(1))
    assert not Maybe.nothing().__eq__(Maybe.just(2))
    assert not Maybe.nothing().__eq__(Maybe.just(3))



# Generated at 2022-06-12 05:17:46.610054
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    from pymonet.lazy import Lazy

    assert Maybe.just(3).filter(lambda x: x < 3) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x > 3) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.nothing().filter(None) == Maybe.nothing()
    assert Maybe.just(3).filter(Lazy(lambda: True)) == Maybe.just(3)
    assert Maybe.just(3).filter(Lazy(lambda: False)) == Maybe.nothing()


# Generated at 2022-06-12 05:17:48.916268
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    val = Maybe.just(1)
    val_copy = Maybe.just(1)
    nothing = Maybe.nothing()
    assert val == val_copy
    assert val != nothing
    assert nothing == nothing



# Generated at 2022-06-12 05:17:56.386088
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just('test')
    maybe_two = Maybe.just('test')
    maybe_three = Maybe.just('test_test')
    maybe_four = Maybe.nothing()

    assert maybe == maybe_two
    assert maybe != maybe_three
    assert maybe_four == Maybe.nothing()



# Generated at 2022-06-12 05:18:06.458216
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    maybe = Maybe.just([1, 2, 3])
    assert maybe == Maybe.just([1, 2, 3])
    assert not maybe == Maybe.just([1, 2, 4])
    assert maybe == Maybe.just([1, 2, 3])
    assert not maybe == Maybe.just([1, 2, 4])

    maybe = Maybe.just('abc')
    assert maybe == Maybe.just('abc')
    assert not maybe == Maybe.just('abd')
    assert maybe == Maybe.just('abc')
    assert not maybe == Maybe.just('abd')

    maybe = Maybe.just(3 * 3 * 3)
    assert maybe == Maybe.just(27)
    assert not maybe == Maybe.just(26)
    assert maybe == Maybe.just(27)
    assert not maybe == Maybe.just(26)


# Generated at 2022-06-12 05:18:08.522443
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():

    m = Maybe.just(4).to_lazy()
    assert m.eval() == 4

    m = Maybe.nothing().to_lazy()
    assert m.eval() is None

# Generated at 2022-06-12 05:18:19.160643
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert not Maybe(1, False) == Maybe(2, False)
    assert Maybe(1, True) == Maybe(None, True)
    assert not Maybe(1, False) == Maybe(None, True)

    assert Maybe(None, True) == None
    assert None == Maybe(None, True)
    assert Maybe(1, False) != None
    assert None != Maybe(1, False)
    assert Maybe(None, False) != None
    assert None != Maybe(None, False)
    assert Maybe(1, True) != 1
    assert 1 != Maybe(1, True)
    assert Maybe(1, False) == 1
    assert 1 == Maybe(1, False)
    assert Maybe(1, True) != "1"

# Generated at 2022-06-12 05:18:25.027393
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just('hello').__eq__(Maybe.just('hello')) == True
    assert Maybe.just('hello').__eq__(Maybe.just('world')) == False
    assert Maybe.just('hello').__eq__(Maybe.nothing()) == False
    assert Maybe.nothing().__eq__(Maybe.nothing()) == True
    assert Maybe.nothing().__eq__(Maybe.just('hello')) == False



# Generated at 2022-06-12 05:18:27.583119
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:18:30.861764
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()


# Generated at 2022-06-12 05:18:34.856087
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    print('test Maybe.__eq__')
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    print('passed')


# Generated at 2022-06-12 05:18:39.855722
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe(1, False) == Maybe(1, False)
    assert Maybe(1, True) == Maybe(1, True)
    assert Maybe(1, True) != Maybe(1, False)
    assert Maybe(1, False) != Maybe(2, False)
    assert Maybe(1, False) != Maybe(1, True)
    print("test_Maybe__eq__ - OK")

# Generated at 2022-06-12 05:18:45.032904
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)



# Generated at 2022-06-12 05:18:52.730963
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    # Positive cases
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    # Negative cases
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(2)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() != Maybe.nothing()

# Generated at 2022-06-12 05:18:55.477151
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(2)
    assert Maybe.just(1) == Maybe.nothing()



# Generated at 2022-06-12 05:19:01.019615
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != None

test_Maybe___eq__()



# Generated at 2022-06-12 05:19:06.514021
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    """
    Unit test for method __eq__ of class Maybe.
    """
    from pymonet.utils import create_mapper_for_args_of_method
    unit_test_for_args_of_method(Maybe, Maybe.__eq__, create_mapper_for_args_of_method, test_name='test_Maybe___eq__')


# Generated at 2022-06-12 05:19:12.015797
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != 1


# Generated at 2022-06-12 05:19:17.857305
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    m1 = Maybe.just(5)
    m2 = Maybe.nothing()
    m3 = Maybe.just(5)
    m4 = Maybe.just(4)

    assert m1 == m1
    assert m1 == m3
    assert m1 != m2
    assert m1 != m4
    assert m2 == m2
    assert m2 != m3
    assert m2 != m4
    assert m3 == m3
    assert m3 != m2
    assert m3 != m4
    assert m4 == m4
    assert m4 != m2
    assert m4 != m3



# Generated at 2022-06-12 05:19:23.880085
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.nothing() is False
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) == Maybe.just(2) is False

    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() == Maybe.just(1) is False



# Generated at 2022-06-12 05:19:29.799262
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    import unit_test.asserts as asserts
    from pymonet.monad_maybe import Maybe

    asserts.assert_equals(
        asserts.TYPE_UNIT,
        Maybe(10, False),
        Maybe.just(10)
    )
    asserts.assert_equals(
        asserts.TYPE_UNIT,
        Maybe(None, True),
        Maybe.nothing()
    )

# Generated at 2022-06-12 05:19:34.529770
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(1)



# Generated at 2022-06-12 05:19:40.954160
# Unit test for method filter of class Maybe
def test_Maybe_filter():

    assert(
        Maybe.just(1).filter(lambda v: v < 0) ==
        Maybe.nothing()
    )

    assert(
        Maybe.just(2).filter(lambda v: v < 0) ==
        Maybe.nothing()
    )

    assert(
        Maybe.just(-1).filter(lambda v: v < 0) ==
        Maybe.just(-1)
    )

    assert(
        Maybe.just(-2).filter(lambda v: v < 0) ==
        Maybe.just(-2)
    )

    assert(
        Maybe.nothing().filter(lambda v: v < 0) ==
        Maybe.nothing()
    )


# Generated at 2022-06-12 05:19:50.196163
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(10) == Maybe.just(10)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:19:55.341485
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(4).filter(lambda x: x > 2) == Maybe.just(4)
    assert Maybe.just(1).filter(lambda x: x > 2) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 2) == Maybe.nothing()



# Generated at 2022-06-12 05:19:59.481709
# Unit test for method to_lazy of class Maybe
def test_Maybe_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    maybe = Maybe.just(1)

    # When
    lazy = maybe.to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy() == 1



# Generated at 2022-06-12 05:20:02.986364
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 3) == Maybe.nothing()
    assert Maybe.just(3).filter(lambda x: x == 3) == Maybe.just(3)
    assert Maybe.nothing().filter(lambda x: x == 3) == Maybe.nothing()

# Generated at 2022-06-12 05:20:08.831088
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.just(2)
    assert Maybe.just('str') == Maybe.just('str')
    assert Maybe.just(None) != Maybe.just(None)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.nothing() != Maybe.just(None)
    assert Maybe.just(1) != Maybe.nothing()



# Generated at 2022-06-12 05:20:13.054870
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(2) != Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:20:16.444937
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda x: x == 1) == Maybe.just(1)
    assert Maybe.just(2).filter(lambda x: x == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:20:20.009028
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.nothing() == Maybe.nothing()
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.just(1) != Maybe.just(2)


# Generated at 2022-06-12 05:20:22.539499
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(1) == Maybe.just(1)
    assert Maybe.just(1) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()



# Generated at 2022-06-12 05:20:28.159662
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(5).filter(lambda a: a > 0) == Maybe.just(5)
    assert Maybe.just(5).filter(lambda a: a < 0) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda a: a > 0) == Maybe.nothing()


# Generated at 2022-06-12 05:20:38.868176
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(1).filter(lambda v: v != 1) == Maybe.nothing()
    assert Maybe.just(1).filter(lambda v: v == 1) == Maybe.just(1)
    assert Maybe.nothing().filter(lambda v: v == 1) == Maybe.nothing()



# Generated at 2022-06-12 05:20:44.492204
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe(2, False).filter(lambda x: x == 2) == Maybe(2, False)
    assert Maybe(2, False).filter(lambda x: x != 2) == Maybe(None, True)
    assert Maybe(None, True).filter(lambda x: x != 2) == Maybe(None, True)

# Generated at 2022-06-12 05:20:46.283959
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    from pymonet_test.monet_maybe_test import test_Maybe__eq__

    test_Maybe__eq__()

# Generated at 2022-06-12 05:20:49.603833
# Unit test for method __eq__ of class Maybe
def test_Maybe___eq__():
    assert Maybe.just(2) == Maybe.just(2)
    assert Maybe.just(2) != Maybe.just(3)
    assert Maybe.just(2) != Maybe.nothing()
    assert Maybe.nothing() == Maybe.nothing()


# Generated at 2022-06-12 05:20:54.050907
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    assert Maybe.just(2).filter(lambda x: x > 1) == Maybe.just(2)
    assert Maybe.just(0).filter(lambda x: x > 1) == Maybe.nothing()
    assert Maybe.nothing().filter(lambda x: x > 1) == Maybe.nothing()


# Generated at 2022-06-12 05:21:02.391730
# Unit test for method filter of class Maybe
def test_Maybe_filter():
    maybe_zero = Maybe.just(0)
    maybe_one = Maybe.just(1)
    maybe_none = Maybe.nothing()

    assert maybe_zero.filter(lambda x: x == 0) == maybe_zero
    assert maybe_zero.filter(lambda x: x == 1) == Maybe.nothing()

    assert maybe_one.filter(lambda x: x == 1) == maybe_one
    assert maybe_one.filter(lambda x: x == 0) == Maybe.nothing()

    assert maybe_none.filter(lambda x: x == 0) == Maybe.nothing()
