

# Generated at 2022-06-20 23:50:50.868520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.vault import VaultLib

    vault_secrets = VaultLib([(b"vault_key", b"vault_key")])
    vault_secrets.open_file("/path/to/file")
    loader = AnsibleLoader(stream="", vault_secrets=vault_secrets)
    assert loader.file_name == ""

# Generated at 2022-06-20 23:50:54.631521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO

    stream = BytesIO("""
    ---
    - hosts: test
      tasks:
        - action: ping
    """)

    loader = AnsibleLoader(stream, file_name='test_AnsibleLoader_file_name')
    loader.get_single_data()
    assert loader.file_name == 'test_AnsibleLoader_file_name'

# Generated at 2022-06-20 23:51:03.624848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys,os
    my_pwd = os.path.abspath(os.path.dirname(__file__))

    sample_file = my_pwd + "/loader_fixtures/sample.yaml"

    with open(sample_file) as f:
        l = AnsibleLoader(f, file_name=sample_file)
        sample_list = l.get_single_data()
        assert sample_list == [{'apiVersion': 'v1', 'kind': 'Pod'}, {'apiVersion': 'v1', 'kind': 'Service'}]



# Generated at 2022-06-20 23:51:13.898008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '\n'.join((
        '---',
        'foo:1',
        'bar:2',
        'ansible_user:3',
        'ansible_password: 4',
        '...',
        '# vim:syntax=ansible',
        '# vim:ft=ansible',
        '# vim:ft=yaml',
        '---',
        'foo:5',
        'bar:6',
        'baz:7'
    ))
    loader = AnsibleLoader(stream)
    for i, doc in enumerate(loader.get_single_data()):
        if i == 0:
            assert doc == {'foo': 1, 'bar': 2, 'ansible_user': 3, 'ansible_password': 4}

# Generated at 2022-06-20 23:51:23.226138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    try:
        yaml.CLoader = AnsibleLoader  # pylint: disable=no-member,attribute-defined-outside-init
    except AttributeError:
        yaml.Loader = AnsibleLoader


if HAS_LIBYAML:
    class AnsibleDumper(object):
        """
        Wrapper around yaml.safe_dump() to force allow_unicode=True
        """
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def __getattr__(self, name):
            def caller(*args, **kwargs):
                import yaml
                self.kwargs['allow_unicode'] = True
                return getattr(yaml, name)(*args, **kwargs)
            return caller

# Generated at 2022-06-20 23:51:26.229468
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = 'foo: [ bar baz ]'
    loader = AnsibleLoader(stream)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:51:31.884548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test_AnsibleFoo():
        pass

    # right now, just ensure it doesn't blow up on this test class
    AnsibleLoader(None).construct_yaml_obj(None, None, yaml_tag='tag:yaml.org,2002:str',
                                           data='test_AnsibleFoo: !ansible/test_AnsibleFoo')

# Generated at 2022-06-20 23:51:32.440404
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

# Generated at 2022-06-20 23:51:33.543270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-20 23:51:37.226131
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Basic test to make sure the class can be instantiated.  Potentially more
    # extensive tests could be written.
    AnsibleLoader('test')


__all__ = ['AnsibleLoader']

# Generated at 2022-06-20 23:51:49.631008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml
    import sys

# Generated at 2022-06-20 23:51:51.528516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-20 23:52:03.402364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedFile
    import sys

    if sys.version < '3':
        basestring = (str, unicode)  # pylint: disable=undefined-variable


# Generated at 2022-06-20 23:52:11.548313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    for key in AnsibleConstructor._get_yaml_loader_cls.func_globals:  # pylint: disable=no-member
        if key.startswith('Ansible'):
            loader_class = AnsibleConstructor._get_yaml_loader_cls.func_globals[key]  # pylint: disable=no-member
            if key == 'AnsibleLoader':
                continue
            if key == 'AnsibleDictLoader':
                continue
            if key == 'AnsibleSafeLoader':
                continue
            assert issubclass(loader_class, AnsibleLoader)

# Generated at 2022-06-20 23:52:23.451003
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    # Test string that has no type info in it
    test_string = 'this is a test string'
    test_stream = io.StringIO(test_string)
    result = AnsibleLoader(test_stream)

    assert result is not None

    # Test string that has an empty dict in it
    test_string = '{}'
    test_stream = io.StringIO(test_string)
    result = AnsibleLoader(test_stream)

    assert result is not None

    # Check to make sure that it is an empty dict
    assert isinstance(result, dict)
    assert result == {}

    # Test string that has an empty list in it
    test_string = '[]'
    test_stream = io.StringIO(test_string)
    result = AnsibleLoader(test_stream)

    assert result

# Generated at 2022-06-20 23:52:25.371877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, vault_secrets={"password": "TestPass"})
    assert loader

# Generated at 2022-06-20 23:52:26.040588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:52:28.690233
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Testing the constructor of class AnsibleLoader
    """
    ansible_loader = AnsibleLoader("")
    assert ansible_loader is not None

# Generated at 2022-06-20 23:52:31.354271
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.dataloader
    ansible.parsing.dataloader.AnsibleLoader
#
# unit test end
#

# Generated at 2022-06-20 23:52:37.915294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    test1 = io.BytesIO(b'{"test1": ["test2", "test3"]}')
    loader = AnsibleLoader(test1)
    result = loader.get_single_data()
    assert result == {"test1": ["test2", "test3"]}
    test1.close()

    test2 = io.BytesIO(b'{"test1": { "test2": "test3" } }')
    loader = AnsibleLoader(test2)
    result = loader.get_single_data()
    assert result == {"test1": {"test2": "test3"}}
    test2.close()

# Generated at 2022-06-20 23:52:42.152708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_instance = AnsibleLoader(None)
    assert class_instance

# Generated at 2022-06-20 23:52:43.154962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:52:54.945954
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    data = """
    - name: test-yaml-1
      hosts: localhost
      tasks:
      - debug: msg="hello world"
    """

    def test_basic_load(data):
        """
        Basic Yaml parsing test
        """
        yaml_obj = DataLoader().load(data)
        assert isinstance(yaml_obj, list)

        return yaml_obj

    def test_constructor_type(data):
        """
        Check that the AnsibleConstructor is used as the default constructor
        """
        yaml_obj = test_basic_load(data)

# Generated at 2022-06-20 23:53:05.765292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    # probably a better way to do this, but this was the first thing that worked
    test_file_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(os.path.join(test_file_path, '../'))
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.parsing.yaml.loader

    test_yaml = '''key: "{{ test_var }}"'''
    loader = ansible.parsing.yaml.loader.AnsibleLoader(test_yaml)
    data = loader.get_single_data()
    assert data == {'key': AnsibleUnicode('{{ test_var }}')}

# Generated at 2022-06-20 23:53:12.430990
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml_str = """
    foo: baz
    bar:
     - 1
     - 2
     - 3
    nested:
     foo: bar
    """

    data = yaml.load(yaml_str, Loader=AnsibleLoader)

    assert data.get('foo') == 'baz'
    assert len(data.get('bar')) == 3
    assert data.get('nested').get('foo') == 'bar'

    # more tests for discussion in issue #24362
    yaml_str2 = """
    foo:
      - bar
      - baz
    """
    data = yaml.load(yaml_str2, Loader=AnsibleLoader)
    assert len(data.get('foo')) == 2


# Generated at 2022-06-20 23:53:23.761373
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import yaml
    loader = AnsibleLoader(sys.stdin)

    # Test that our custom constructor class is registered
    assert loader.yaml_impl.Constructor is AnsibleConstructor

    # Test that our custom resolver class is registered
    assert loader.yaml_impl.resolver is loader

    # Test that our custom resolver class is registered
    assert isinstance(loader.composer, AnsibleConstructor) is True

    # Test that we can load a basic yaml variable with a complex value
    doc = loader.get_single_data()
    assert doc == dict(complex_variable=dict(key="value"))

    # Test that we can get a list of data from a yaml stream
    doc = loader.get_data()

# Generated at 2022-06-20 23:53:32.896382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleSequence
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    import re

    # Test with no vault_id_regex
    loader = AnsibleLoader(stream='a: b\nc: d')
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    loader = AnsibleLoader(stream='- a\n- b')
    assert isinstance(loader.get_single_data(), AnsibleSequence)

    # Test with a vault_id_regex
    loader = AnsibleLoader(stream='a: b\nc: d', vault_secrets=['vault_secret'])

# Generated at 2022-06-20 23:53:36.749533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    yaml = StringIO(u"""
foo:
  - 1
  - 2
bar:
  - 3
  - 4
""")

    data = AnsibleLoader(yaml, file_name='test').get_single_data()
    assert data == dict(foo=[1, 2], bar=[3, 4])

# Generated at 2022-06-20 23:53:48.417558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile

    testfile = '''
    # This is a comment
    name: steve
    job: sir
    tools: [hammer, saw, wrench]
    silly: !!python/object/apply:subprocess.call arguments: [['/bin/false']]
    '''

    fd, fname = tempfile.mkstemp(suffix='yml')
    os.write(fd, testfile)
    os.close(fd)


# Generated at 2022-06-20 23:53:49.461677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None) is not None

# Generated at 2022-06-20 23:54:05.713767
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():          # pylint: disable=too-many-return-statements
    loader = AnsibleLoader('foo')
    if hasattr(loader, 'construct_yaml_null'):
        if loader.construct_yaml_null(None) != ():
            return False
    else:
        if hasattr(loader, 'construct_yaml_null'):
            return False
    if loader.construct_yaml_bool(None) != ():
        return False
    if loader.construct_yaml_str(None) != ():
        return False
    if loader.construct_yaml_int(None) != ():
        return False
    if loader.construct_yaml_float(None) != ():
        return False
    if loader.construct_yaml_binary(None) != ():
        return False

# Generated at 2022-06-20 23:54:17.620126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.vault import VaultLib

    vault_secrets_1 = VaultLib([])
    vault_secrets_2 = VaultLib([])
    loader = AnsibleLoader(None, vault_secrets=vault_secrets_1)
    assert loader.vault_secrets is vault_secrets_1
    loader.vault_secrets = vault_secrets_2
    assert loader.vault_secrets is vault_secrets_2

    assert isinstance(loader.construct_yaml_int(0, 0), int)
    assert isinstance(loader.construct_yaml_float(0, 0), float)

# Generated at 2022-06-20 23:54:18.356962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:54:27.915005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable

    l = AnsibleLoader(None)

    (data, errors) = l.get_single_data()
    assert data == None
    assert type(errors) == list

    l2 = AnsibleLoader(None, file_name='testfile.yml')
    (data2, errors2) = l2.get_single_data()
    assert data2 == None
    assert type(errors2) == list

    l3 = AnsibleLoader(None, vault_secrets={'vault_password': 'secret'})
    (data3, errors3) = l3.get_single_data()
    assert data3 == None
    assert type(errors3) == list

# Generated at 2022-06-20 23:54:35.568260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.utils import AnsibleSequence

    loader = AnsibleLoader('')

    assert isinstance(loader.construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(''), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(''), AnsibleSequence)
    assert isinstance(loader.construct_yaml_omap(''), AnsibleSequence)
    assert isinstance(loader.construct_yaml_set(''), AnsibleSequence)

# Generated at 2022-06-20 23:54:44.495812
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    {% raw %}{% set foo = 'bar' %}{% endraw %}
    - hosts: all
      gather_facts: no
      tasks:
        - shell: cat /etc/ansible/hosts
          register: hosts_content
        - debug:
            {% raw %}msg: "{{ hosts_content.stdout_lines }}"{% endraw %}
    """

    data = data.encode('utf-8')

    loader = AnsibleLoader(data, file_name='<string>')

    for item in loader:
        pass

# Generated at 2022-06-20 23:54:48.433370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    data = '''
        - hosts: all
          vars:
            key1: "{{ lookup('env','PASSWORD') }}"
            key2: "{{ 'password' | password_hash('sha512') }}"
        '''

    data = io.StringIO(data)
    yaml = AnsibleLoader(data)

    result = None
    for item in yaml:
        result = item

    assert result is not None
    assert result['vars']['key1'] == '{{ lookup(\'env\',\'PASSWORD\') }}'
    assert result['vars']['key2'] == '{{ \'password\' | password_hash(\'sha512\') }}'

# Generated at 2022-06-20 23:54:49.940020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: implement test for class AnsibleLoader
    pass

# Generated at 2022-06-20 23:54:58.952360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    # Nothing to do, the class AnsibleLoader must be instantiated with a non-empty stream

    ## TODO: Add unit tests for the constructor of the class AnsibleLoader
    #os.system("python -c 'from ansible.parsing.yaml.constructor import AnsibleLoader; print(AnsibleLoader)'")
    #os.system("python -c 'from ansible.parsing.yaml.constructor import AnsibleLoader; print(AnsibleLoader)'")
    #os.system("python -c 'from ansible.parsing.yaml.constructor import AnsibleLoader; print(AnsibleLoader)'")
    #os.system("python -c 'from ansible.parsing.yaml.constructor import AnsibleLoader; print(AnsibleLoader)'")

# Generated at 2022-06-20 23:55:00.191515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:55:14.520326
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    >>> from ansible.parsing.yaml.loader import AnsibleLoader
    >>> loader = AnsibleLoader(None)
    >>> loader
    <ansible.parsing.yaml.loader.AnsibleLoader object at 0x7f2b05344dd0>
    '''

# Generated at 2022-06-20 23:55:20.901555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.vars import combine_vars
    data = {
        'a': {
            'b': '{{ c }}',
            'c': 2,
        },
        'b': {
            'd': '{{ a }}',
        },
        'c': {
            'e': '{{ a.b + b.d.c }}',
            'f': '{{ b.d["c"] }}',
        }
    }
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == combine_vars(data)

# Generated at 2022-06-20 23:55:26.730047
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader('what')
    assert loader.stream is 'what'

    import copy
    loader = AnsibleLoader('what', 'where')
    assert loader.stream is 'what'
    assert loader.file_name is 'where'
    assert loader.vault_secrets is None
    assert loader.vault_secrets is not copy.copy(loader.vault_secrets)

# Generated at 2022-06-20 23:55:30.634982
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-public-methods
    loader = AnsibleLoader(None)
    assert loader.__class__.__module__ == 'ansible.parsing.yaml.loader'



# Generated at 2022-06-20 23:55:40.676356
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime

    # Create a new instance of the AnsibleLoader
    loader = AnsibleLoader(None)

    # These should all be AnsibleConstructor, not Resolver
    assert (type(loader.construct_yaml_bool) == type(Resolver.construct_yaml_bool))
    assert (type(loader.construct_yaml_int) == type(Resolver.construct_yaml_int))
    assert (type(loader.construct_yaml_map) == type(Resolver.construct_yaml_map))
    assert (type(loader.construct_yaml_seq) == type(Resolver.construct_yaml_seq))
    assert (type(loader.construct_undefined) == type(Resolver.construct_undefined))


# Generated at 2022-06-20 23:55:47.324333
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.text.converters import to_bytes
    import yaml
    from io import StringIO, BytesIO


# Generated at 2022-06-20 23:55:54.784027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - hosts: all
      vars:
        var1: value
        var2: "{{ var1 }}"
    """
    yaml_loader = AnsibleLoader(yaml_str)
    yaml_data = yaml_loader.get_single_data()
    assert type(yaml_data) == list
    assert len(yaml_data) == 1
    assert type(yaml_data[0]) == dict
    assert len(yaml_data[0]) == 2

# Generated at 2022-06-20 23:56:04.219702
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    yaml.add_constructor(u'!vault', lambda loader, node: AnsibleVaultEncryptedUnicode(loader.construct_scalar(node)))


# Generated at 2022-06-20 23:56:06.932283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
- hosts: localhost
  tasks:
    - name: task 1
      ping:
    - name: task 2
      ping:
'''
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_data()
    assert ansible_loader.data is not None

# Generated at 2022-06-20 23:56:13.019725
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    tags:
      - yaml
      - ansible
      - loader
    '''
    with open('test_data/yaml/constructor/test_data.yml', 'r') as f:
        loader = AnsibleLoader(f)
        data = loader.get_single_data()
        assert data == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-20 23:56:44.075851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This function tests the AnsibleLoader class
    '''
    from yaml.reader import ReaderError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:56:48.344003
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleParserError

    # Loading a non-existent dictionary should fail with an AnsibleParserError
    al = AnsibleLoader(file_name="/does/not/exist.yaml")
    try:
        data = al.get_single_data()
    except AnsibleParserError as e:
        assert "Unable to read" in e.message

# Generated at 2022-06-20 23:56:50.804267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - hosts: all
      gather_facts: false
      tasks:
        - name: test
          ping:
    """
    result = list(AnsibleLoader(yaml_str))
    assert result is not None and isinstance(result, list)

# Generated at 2022-06-20 23:56:54.803246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader
    except NameError:
        pytest.skip("libyaml is not installed")
    # Empty content
    content = ''
    loader = AnsibleLoader(content)
    assert list(loader) == []
    # Simple data
    content = 'True\n'
    loader = AnsibleLoader(content)
    assert next(loader)
    # Complex data
    content = '{test: 1}\n'
    loader = AnsibleLoader(content)
    assert dict(next(loader)) == {'test': 1}

# Generated at 2022-06-20 23:57:00.363281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
       - include: test.yml
         name: test1
       - include: test.yml
         name: test2
    '''
    l = AnsibleLoader(data)
    d = l.get_single_data()
    assert len(d) == 2
    assert d[0]['include'] == 'test.yml'

# Generated at 2022-06-20 23:57:03.658305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/etc/ansible/hosts', 'r')
    loader = AnsibleLoader(stream=stream)
    print(loader)
    stream.close()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:57:06.206954
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # AnsibleLoader.__init__()
    assert AnsibleLoader

# Run module as a standalone test unit
if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:57:13.000284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    yaml_str = u"""
    ---
    - name: test
      hosts: all
      tasks:
        - debug: var=hostvars[inventory_hostname]
    """

    # Parse without vault, we expect a dict
    data = AnsibleLoader(StringIO(yaml_str)).get_single_data()
    assert isinstance(data, dict)

    # Parse with vault, we expect an object
    data = AnsibleLoader(StringIO(yaml_str), vault_secrets=VaultLib()).get_single_data()
    assert isinstance(data, object)

# Generated at 2022-06-20 23:57:23.071783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
- hosts: localhost
  tasks:
  - debug:
      msg: "{{ test_variable }}"
    vars:
      test_variable: hello world!
"""
    loader = AnsibleLoader(data)
    parsed = loader.get_single_data()
    assert(parsed['tasks'][0]['debug']['msg'] == "{{ test_variable }}")

    # Test vault-encrypted data

# Generated at 2022-06-20 23:57:26.299544
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader,Reader)
    assert isinstance(loader,Scanner)
    assert isinstance(loader,Parser)
    assert isinstance(loader,Composer)
    assert isinstance(loader,AnsibleConstructor)
    assert isinstance(loader,Resolver)

# Generated at 2022-06-20 23:58:12.219148
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """

    :return:
    """
    # assert yaml.load('''
    # ---
    # a: 1
    # ''') == {'a': 1}
    print("test case is empty")
    return None

# Generated at 2022-06-20 23:58:19.296046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleVaultEncryptedUnicode, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader

    for test_me in ('filled_seq.yml', 'filled_map.yml', 'empty.yml', 'unicode_map.yml'):
        with open('test/units/parsing/yaml/loader/%s' % test_me) as f:
            data = AnsibleLoader(f.read(), file_name='test/units/parsing/yaml/loader/%s' % test_me).get_single_data()

            if test_me in ('empty.yml', 'unicode_map.yml'):
                assert data is None


# Generated at 2022-06-20 23:58:24.779048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    datastring = '''
    - hosts: all
      vars:
        var1: 1
        var2: 2
    '''
    loader = AnsibleLoader(datastring)
    data = loader.get_single_data()
    assert data is not None, 'AnsibleLoader is not loaded'
    assert data.get('hosts') == "all", 'AnsibleLoader is not loaded for \'hosts\' attribute'
    assert data['vars']['var1'] == 1, 'AnsibleLoader is not loaded for \'var1\' attribute'
    assert data['vars']['var2'] == 2, 'AnsibleLoader is not loaded for \'var2\' attribute'

# Generated at 2022-06-20 23:58:26.032986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader('test')
    assert isinstance(obj, AnsibleLoader)
    assert isinstance(obj, Resolver)

# Generated at 2022-06-20 23:58:36.472840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import load

    # load should succeed if no vault password is provided

# Generated at 2022-06-20 23:58:46.485529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This function is called when AnsibleLoader is imported
    # We do nothing and return
    return

if HAS_LIBYAML:
    from ansible.compat.tests import unittest

    class TestLoaderMethods(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_AnsibleLoader_ctor_with_options(self):
            # Create an AnsibleLoader with some extra context
            loader = AnsibleLoader(None, "test_AnsibleLoader_ctor_with_options",
                                   vault_secrets=["test1", "test2"])
            self.assertEqual(loader.file_name, "test_AnsibleLoader_ctor_with_options")

# Generated at 2022-06-20 23:58:48.552744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # FIXME: shouldn't we test the case when the global HAS_LIBYAML is set to true?
    test_AnsibleLoader_without_libyaml()


# Generated at 2022-06-20 23:58:54.125276
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_pass = '$ANSIBLE_VAULT;1.1;AES256'
    vault_pass_bytes = bytes(vault_pass, 'ascii')
    vault_secrets = [VaultSecret('default', vault_pass_bytes, True)]


# Generated at 2022-06-20 23:58:57.293138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = AnsibleLoader(file_name="foo", vault_secrets=None)
    assert stream.vault_secrets == None

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:59:07.803685
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-21 00:00:35.842195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # should be able to instantiate
    assert AnsibleLoader(None)

# Generated at 2022-06-21 00:00:42.849455
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # noqa
    '''`constructor` AnsibleLoader class'''

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    loader = AnsibleLoader('')

    def check_type(instance, expected_type):
        '''`function` used to check an immutable value'''

        assert isinstance(instance, expected_type)
        if isinstance(instance, list) or isinstance(instance, tuple) or isinstance(instance, set):
            for item in instance:
                check_type(item, expected_type)

    def check_mapping(instance, keys, values):
        '''`function` used to check an immutable `dict`'''

        assert isinstance(instance, AnsibleMapping)

        assert isinstance(instance.keys(), AnsibleSequence)

# Generated at 2022-06-21 00:00:45.932967
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
        ---
        hostsfile: /home/my_hosts
        ...
        '''.strip()
    from io import StringIO
    ansible_loader = AnsibleLoader(StringIO(yaml_str))
    assert ansible_loader.get_single_data() == {'hostsfile': '/home/my_hosts'}