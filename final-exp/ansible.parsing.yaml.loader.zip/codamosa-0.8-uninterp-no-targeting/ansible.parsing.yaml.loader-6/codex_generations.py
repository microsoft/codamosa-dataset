

# Generated at 2022-06-20 23:50:49.565211
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    a = '''a: 1
b:
  c: 3
  d: 4'''

    b = loader.load(a)
    assert isinstance(b, dict)
    assert b['a'] == 1
    assert b['b']['c'] == 3
    assert b['b']['d'] == 4



# Generated at 2022-06-20 23:50:54.880380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string = '''
    - hosts: localhost
      vars:
        var1: foo
      tasks:
      - name: test-parsing
        debug: msg="parsed_var1={{ var1 }}"
    '''
    loader = AnsibleLoader(test_string)
    assert isinstance(loader, Resolver)



# Generated at 2022-06-20 23:51:01.975341
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")

    # AnsibleLoader should be an instance of Reader, Scanner, Parser, Composer, AnsibleConstructor and Resolver
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-20 23:51:06.565958
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a_loader = AnsibleLoader(None, file_name='not_a_real_file.yml')
    assert a_loader.current_file_name == 'not_a_real_file.yml'

# TODO: add test cases for __init__ when vault_secrets is not None

# Generated at 2022-06-20 23:51:14.458516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import StringIO
    test_data_yaml = """
---
- a: 1
- b: 2
- c:
  - d: 3
  - e: 4
- f: 5
- g: 6
- h: 7
- i: 8
- j: 9
- k: 10
- l: 11
- n: 12
"""
    print("\nReading using the ansible loader")
    data = AnsibleConstructor(StringIO.StringIO(test_data_yaml))
    print(data)
    print("\nCreating yaml using dumper")
    yaml_string = AnsibleConstructor.yaml_dumper(data)
    print(yaml_string)

# Generated at 2022-06-20 23:51:15.510195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('abc')

# Generated at 2022-06-20 23:51:24.122980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest

    from ansible.vars.unsafe_proxy import UnsafeProxy

    data = """
---
# foo
    '''
    bar
    ''':
    - 1
    - 2
    - 3
        """

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_AnsibleLoader_constructor(self):
            result = AnsibleLoader(io.StringIO(data), file_name='<string>').get_single_data()
            self.assertIsInstance(result, dict)
            self.assertEqual(result.get('foo bar'), [1, 2, 3])

# Generated at 2022-06-20 23:51:25.081836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:51:25.641738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:36.604277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
    ---
    - hosts: localhost
      tasks:
        - user:
            # test
            name: root
            # test
            password: abc
            # test
            update_password: always
            # test
            shell: /bin/bash
            # test
    ...
    '''

    results = AnsibleLoader(data, 'test.yml').get_single_data()
    assert results == {u'hosts': u'localhost',
                       u'tasks': [{u'user': {u'password': u'abc',
                                             u'shell': u'/bin/bash',
                                             u'update_password': u'always',
                                             u'name': u'root'}}]}

# Generated at 2022-06-20 23:51:40.597419
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:49.830190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import unittest

    import ansible.parsing.yaml.loader

    sys.path.append(os.path.dirname(__file__))

    # Bypass the test if AnsibleLoader fails to be imported (case of no libyaml)
    try:
        ansible.parsing.yaml.loader.AnsibleLoader
        ansible.parsing.yaml.loader.test_AnsibleLoader
    except AttributeError:
        return

    class TestAnsibleLoader(unittest.TestCase):
        ''' Check constructor of AnsibleLoader class '''

        def test_AnsibleLoader_init(self):
            ''' Check AnsibleLoader constructor '''

            from ansible.parsing.yaml.loader import AnsibleLoader

            loader = Ansible

# Generated at 2022-06-20 23:51:52.151579
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Ensure AnsibleLoader initialization works as expected
    :return: nothing
    """
    assert AnsibleLoader('') is not None

# Generated at 2022-06-20 23:51:56.892136
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    sample = AnsibleLoader({'name':'Sam', 'age':'28', 'is_old_enough_to_vote':True})
    assert sample.get_single_data() == {'age':28, 'is_old_enough_to_vote':True, 'name':'Sam'}

# Generated at 2022-06-20 23:52:08.088736
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Create an instance of AnsibleLoader
    yaml_str = """---
- hosts: all
  tasks:
   - debug:
       msg: this is a test
  vars:
   testing: True
"""
    from io import StringIO
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    stream = StringIO(yaml_str)
    l = AnsibleLoader(stream, 'mytest', vault_secrets=[])

    # Use the Parser base class to parse the YAML
    l.get_single_data()
    assert l.get_single_data()

# Generated at 2022-06-20 23:52:15.101387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.vars import combine_vars

    class TestAnsibleLoader(AnsibleLoader):
        pass

    data = u"""\
        test_dict:
          - key: value
            key2: value2
        test_list:
          - item1
          - item2
          - item3
        test_string: hello world
        test_integer: 42
        """

    vault_secrets = dict(vault_password='12345')

    my_loader = TestAnsibleLoader(data, file_name='myfile.yml', vault_secrets=vault_secrets)
    got = my_loader.get_single_data()


# Generated at 2022-06-20 23:52:20.554444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import load, FullLoader
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    data = load('''
        foo:
            - {name: first}
            - {name: second}
        bar: 42
    ''', Loader=AnsibleLoader)
    assert data['bar'] == 42
    assert data['foo'][1]['name'] == 'second'
    loader = AnsibleLoader('foo: 42', file_name='test')
    assert loader.file_name == 'test'
    loader.file_name = 'foo'
    assert loader.file_name == 'foo'

# Generated at 2022-06-20 23:52:28.154831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' AnsibleLoader is a subclass of AnsibleConstructor. This test
        class checks if the methods of AnsibleConstructor are called
        properly for the superclass AnsibleLoader.
    '''
    import StringIO
    from yaml import YAMLError

    from ansible.parsing.yaml.constructor import BaseConstructor

    # Test as subclass of AnsibleConstructor
    try:
        stream = StringIO.StringIO('[1, 2, 3]')
        loader = AnsibleLoader(stream)
        stream.close()
    except YAMLError:
        raise AssertionError('Failed to create AnsibleLoader instance.')
    else:
        assert isinstance(loader, BaseConstructor)

    # Test as subclass of BaseConstructor

# Generated at 2022-06-20 23:52:32.412667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
- debug:
    msg: "{{ test_var }}"
- name: this is a test
  command: whoami
  """
    yaml_dict = {'command': 'whoami', 'name': 'this is a test'}
    AnsibleLoader(yaml_str)

# Generated at 2022-06-20 23:52:33.365515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO
    assert True

# Generated at 2022-06-20 23:52:39.873269
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-20 23:52:49.854291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "---\nplaybook_path_list: [a, b, c]\n...\n"
    file_name = "test_file"
    vault_secrets = ['test_vault_1', 'test_vault_2']
    ansible_loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert ansible_loader._file_name == file_name
    assert ansible_loader._vault_secrets == vault_secrets
    assert ansible_loader.get_single_data() == {'playbook_path_list': ['a', 'b', 'c']}

# Generated at 2022-06-20 23:52:55.962505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        assert issubclass(AnsibleLoader, Resolver)
    else:
        # yaml.reader.Reader does not exist in python3
        assert issubclass(AnsibleLoader, Scanner)

    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)


# Generated at 2022-06-20 23:53:06.362574
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test of AnsibleLoader setup
    # Test with YAML which needs to be resolved
    # In init_compose_document, Resolver is initialized.
    # Then, in __init__ of Resolver, AnsibleLoader.__init__ is called again
    # This causes "if HAS_LIBYAML" branch to be executed again.
    # The same code is executed in both branches.
    yaml_str = r'''
    This step installs the latest version of docker if it is not already installed.
    If the version of docker installed is an older version, this version is :
    - installed
    - enabled
    - started
    '''
    print("\nTest of AnsibleLoader setup")
    AnsibleLoader(yaml_str)

# Generated at 2022-06-20 23:53:18.060515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import io


# Generated at 2022-06-20 23:53:23.465462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
       test_AnsibleLoader.__name__
    except AttributeError:
       test_AnsibleLoader.__name__ = "PyYAML_AnsibleLoader_UnitTest"

    dummy_stream = None

    loader = AnsibleLoader(dummy_stream)

    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-20 23:53:30.699596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = '''---
        - hosts: 127.0.0.1
          tasks:
            - name: test1
              debug: var='{{test_var}}'
              with_items: 1
              register: test1
            - debug: var='{{test1.results}}'
              failed_when: item.rc > 1
    '''

    result = AnsibleLoader(yaml_string).get_single_data()
    assert len(result) == 1
    assert result[0]['hosts'] == '127.0.0.1'
    assert result[0]['tasks']

# Generated at 2022-06-20 23:53:34.832188
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Test():
        def __init__(self, file_name=None, vault_secrets=None):
            self.file_name = file_name
            self.vault_secrets = vault_secrets
    loader = AnsibleLoader('dummy', Test)

    assert loader.file_name == Test.file_name
    assert loader.vault_secrets == Test.vault_secrets

# Generated at 2022-06-20 23:53:46.839086
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import time
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    stream = 'foo'
    file_name = 'bar'
    vault_secrets = []

    loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert loader._file_name is 'bar'
    assert loader._vault_secrets is vault_secrets
    assert loader._vault.secrets is vault_secrets

    loader._vault.extract_secret(file_name)
    assert loader._vault._secrets_used == {}
    loader._vault.extract_secret('baz')
    assert len(loader._vault._secrets_used) == 1
    assert loader._vault._secrets_used['baz'] > time.time() - 2

    loader._vault

# Generated at 2022-06-20 23:53:52.573525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    stream = '''
    - test1:
      - 1
      - 2
      - 3
    - test2: Hello World
    '''
    l = AnsibleLoader(stream)
    assert(l.get_data() == [{'test1':[1,2,3]}, {'test2':'Hello World'}])

# Generated at 2022-06-20 23:54:04.383497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import pdb; pdb.set_trace()
    pass

# Generated at 2022-06-20 23:54:11.610637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.vars import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.parsing.dataloader import DataLoader

    dataloader = DataLoader()
    my_playbook_name = "my_playbook"
    my_var_man = VariableManager()
    my_var_man.set_variable("my_playbook_name", my_playbook_name)
    my_var_man.set_variable("my_playbook_name_hash", "a1bc")
    dataloader.set_vault_secrets({"vault_password": b"password"})


# Generated at 2022-06-20 23:54:24.925568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes

    # Example from http://yaml.org/type/binary.html
    bin_yaml = u"""
    # ASCII art
    --- |
          \//||\/||
          // ||  ||__
    """

    try:
        AnsibleLoader(bin_yaml).get_single_data()
    except AnsibleParserError as e:
        assert 'found unacceptable key' in to_bytes(e)
    else:
        assert False, "should have thrown a parse error!"  # or raised

    # make sure the dumper works too if libyaml is not installed

# Generated at 2022-06-20 23:54:28.606222
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    data = b'{"key": "value"}'

    loader = AnsibleLoader(stream = io.BytesIO(data))

    assert data == loader.get_single_data()


# Generated at 2022-06-20 23:54:30.616484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    p = AnsibleLoader(open('/tmp/test.yml','r'))
    p.get_single_data()

# Generated at 2022-06-20 23:54:36.783078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile

    data = dict(
        yaml_file_path=os.path.join(tempfile.gettempdir(), 'ansible.yml'),
        content=dict(
            foo=dict(
                bar=42
            ),
        ),
    )

    import yaml
    with open(data['yaml_file_path'], 'wb') as out:
        yaml.dump(data['content'], out)

    with open(data['yaml_file_path'], 'rb') as inp:
        data['loaded'] = yaml.load(inp)
        assert data['loaded'] == data['content']

# Generated at 2022-06-20 23:54:48.127133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
    ---                                                                                                                                                                                                                      
    - hosts: localhost
      gather_facts: false
      connection: local

      tasks:
        - name: test tasks
          blockinfile:
            dest: /tmp/test
            block: |
              # I am a comment
              # I am a comment
              # I am a comment
              # I am a comment
              # I am a comment
              foo: bar
    '''

    loader = AnsibleLoader(data)
    yaml_data = loader.get_single_data()

# Generated at 2022-06-20 23:54:52.034201
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleDumper, AnsibleConstructor)

# Generated at 2022-06-20 23:55:00.148064
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = """
- hosts: all
  tasks:
    - name: task1
      debug:
        msg: Hello World!
    - name: task2
      debug:
        msg: Hello World!
"""
    l = AnsibleLoader(None, 'fake.yaml')
    l.add_constructor('!include', AnsibleConstructor._construct_include)
    l.add_constructor('!import', AnsibleConstructor._construct_include)
    l.add_constructor('!include_vars', AnsibleConstructor._construct_include_vars)
    l.add_constructor('!vars', AnsibleConstructor._construct_vars)
    l.add_constructor('!vault', AnsibleConstructor._construct_vault)

# Generated at 2022-06-20 23:55:01.108644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader


# Generated at 2022-06-20 23:55:33.753543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    pytestmark = pytest.mark.skipif(sys.version_info < (2, 7), reason='unittest.skipUnless is not available before 2.7')

    # vault_secret is not needed when testing for constructor
    loader = AnsibleLoader(None, file_name="dummy")
    # Test for __init__ method
    assert loader.file_name == "dummy"
    assert loader.vault_secrets == []

    # Test for __init__ method with arguments set
    loader = AnsibleLoader(None, file_name="dummy", vault_secrets=['secret'])
    assert loader.file_name == "dummy"
    assert loader.vault

# Generated at 2022-06-20 23:55:36.803226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader as yaml_loader
    loader = yaml_loader.AnsibleLoader(None)
    assert isinstance(loader, yaml_loader.AnsibleLoader)

# Generated at 2022-06-20 23:55:45.195026
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.parsing.yaml.constructor import AnsibleConstructor

    class TestAnsibleLoader(unittest.TestCase):

        def test_AnsibleLoader(self):
            AnsibleConstructor('')

        def test_get_single_data(self):
            """ Test get_single_data method """
            self.assertRaises(
                AssertionError,
                AnsibleConstructor('/dev/null').get_single_data
            )

        def test_construct_yaml_map(self):
            """ Test construct_yaml_map method """
            stream = open('/dev/null')

# Generated at 2022-06-20 23:55:56.359431
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import os
    import tempfile

    # Create a temporary file
    fd, path = tempfile.mkstemp()
    temp_file = os.fdopen(fd, 'w')

    # Write some text to it

# Generated at 2022-06-20 23:56:05.471199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.path import makedirs_safe

    # !vault |
    #          $ANSIBLE_VAULT;1.1;AES256
    #          643163653933316237303536373730663338346234306337623037633835663263346161376337
    #          3662323765333264363662376232616563343331666137340a6136386633626431653539376332
    #          343334306130303831623366316132316661333830366262393233333762313736306565343331

# Generated at 2022-06-20 23:56:12.967022
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.constructor import _get_yaml_loader
    loader = _get_yaml_loader()
    data = '''
- name: test
  src: http://example.com/file.tar.gz
  dest: /tmp/random_dir_with_spaces/file.tar.gz
'''
    d = yaml.load(data, Loader=loader)
    assert d[0]['src'] == 'http://example.com/file.tar.gz'

# Generated at 2022-06-20 23:56:16.294009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- 1
- 2
- 3
'''
    loader = AnsibleLoader(stream)
    assert [ item for item in loader ] == [1, 2, 3]


# Generated at 2022-06-20 23:56:23.125108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader

    class AnsibleLoaderTest(AnsibleLoader):
        def __init__(self, file_name=None, vault_secrets=None):
            super(AnsibleLoaderTest, self).__init__(stream=None, file_name=file_name, vault_secrets=vault_secrets)

    loader = AnsibleLoaderTest()
    assert loader is not None
    ansible_loader = AnsibleLoader(stream=None)
    assert ansible_loader is not None

# Generated at 2022-06-20 23:56:29.521434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    import sys

    from ansible.parsing.yaml.dumper import AnsibleDumper

    class OurLoader(AnsibleLoader):

        def compose_node(self, parent, index):
            # we will assign the loaded tag below in construct_yaml_map/seq so just default to None
            node = Composer.compose_node(self, parent, index)
            return node

        def construct_yaml_map(self, node):
            data = AnsibleMapping()
            yield data
            value = self.construct_mapping(node)
            data.update(value)
            data.ansible_pos = self.line_col(node.start_mark)

# Generated at 2022-06-20 23:56:40.060032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-20 23:57:29.258587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib  # import VaultLib to initialize library
    from ansible.plugins.loader import vault_loader

    # initialize vault lib at first
    VaultLib()


# Generated at 2022-06-20 23:57:39.722270
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:57:50.099171
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = 'test.yml'
    vault_secrets = []
    test_stream = [
        "string: \"{{ lookup( 'foo', bar=False ) }}\"",
        "list:",
        "- string1",
        "- \"{{ lookup( 'foo', bar=False ) }}\"",
        "- string3",
        "dict:",
        "  key: value"
    ]

    test_obj = AnsibleLoader(test_stream, file_name=file_name, vault_secrets=[])
    res = test_obj.get_single_data()

    assert res['string'] == '{{ lookup( \'foo\', bar=False ) }}'
    assert res['list'] == ['string1', '{{ lookup( \'foo\', bar=False ) }}', 'string3']

# Generated at 2022-06-20 23:57:52.060108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        loader = Parser.__init__
    else:
        loader = Parser.__init__
    assert loader



# Generated at 2022-06-20 23:57:54.497808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    load = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    # pylint: disable=protected-access
    assert load._parser._resolver is load

# Generated at 2022-06-20 23:58:04.178587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    loader = AnsibleLoader(None)

    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')
    assert hasattr(loader, 'construct_mapping')
    assert hasattr(loader, 'construct_scalar')
    assert hasattr(loader, 'construct_undefined')
    assert hasattr(loader, 'add_constructor')
    assert hasattr(loader, 'add_multi_constructor')
    assert hasattr(loader, 'resolve')
    assert hasattr(loader, 'descend_resolver')
    assert hasattr(loader, 'ascend_resolver')
    assert hasattr(loader, 'check_data_under')

# Generated at 2022-06-20 23:58:05.049793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' Test creation of AnsibleLoader object '''

    assert AnsibleLoader('TestStream')

# Generated at 2022-06-20 23:58:07.528112
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "!!str 'test'"
    yaml.load(data, Loader=AnsibleLoader)

# Generated at 2022-06-20 23:58:09.881002
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    t = AnsibleLoader(None)  # pylint: disable=too-many-function-args
    assert t.file_name is None
    assert t.stream is None
    assert t.vault_secrets is None

# Generated at 2022-06-20 23:58:14.368604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fname = '../tests/test_data/vault/unused.yml'  # file is not used
    stream = open('../tests/test_data/vault/vault-id.yml').read()
    yaml = AnsibleLoader(stream, file_name=fname, vault_secrets={'vault_password_file': '../tests/test_data/vault/vault-password'})
    data = yaml.get_single_data()
    assert '$ANSIBLE_VAULT' not in data.get('secret')

# Generated at 2022-06-20 23:59:54.159812
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest
    from ansible.module_utils.six import text_type

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(io.StringIO("some: var"))

        def test_constructor(self):
            self.assertEqual(self.loader.stream.read(), text_type("some: var"))
            self.assertEqual(self.loader.file_name, None)
            self.assertEqual(self.loader.vault_secrets, None)

# Generated at 2022-06-21 00:00:04.717221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import sys
    import unittest
    from io import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    class TestAnsibleLoader(unittest.TestCase):

        # Test for AnsibleLoader class instantiation
        def test_AnsibleLoader_init(self):
            with self.assertRaises(TypeError):
                AnsibleLoader()  # pylint: disable=no-value-for-parameter

        # Test that AnsibleLoader behaves correctly with vault-encrypted data
        def test_AnsibleLoader_vault(self):
            vault = VaultLib([])
            vault_data = vault.encrypt('hunter2')

            y

# Generated at 2022-06-21 00:00:12.818355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    # test that AnsibleLoader passes the right values to AnsibleConstructor
    loader = AnsibleLoader(None, file_name='/path/to/file', vault_secrets=['my-vault', 'another-vault'])
    assert loader.filename == '/path/to/file'
    assert loader.vault_secrets == ['my-vault', 'another-vault']
    # test that vault_secrets can be a simple string
    loader = AnsibleLoader(None, file_name='/path/to/file', vault_secrets='my-vault')
    assert loader.vault_secrets == ['my-vault']
    # test that vault_secrets can be a regex

# Generated at 2022-06-21 00:00:15.188371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Code to test class constructor
    # Create an instance of the class
    x = AnsibleLoader(stream="some stream")
    assert x

# Generated at 2022-06-21 00:00:16.200992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_constructor_loader()

# Generated at 2022-06-21 00:00:24.333274
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.text.formatters import json

    assert isinstance(AnsibleLoader, object)

    data = '''
    foo: "{{ foo.bar }}"
    '''
    loader = AnsibleLoader(data, file_name='/tmp/foo')
    assert isinstance(loader, object)

    d = loader.get_single_data()
    assert isinstance(d, object)

    print(json.dumps(d))

# Generated at 2022-06-21 00:00:32.629078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if HAS_LIBYAML:
        base = AnsibleLoader
    else:
        from ansible.parsing.yaml.constructor import AnsibleConstructor
        from ansible.parsing.yaml.loader import AnsibleLoader
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser

        base = Reader
    assert issubclass(AnsibleLoader, base)

    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert has

# Generated at 2022-06-21 00:00:33.630864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-21 00:00:37.146509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    class FakeStream(io.StringIO):
        def close(self):
            pass

    stream = FakeStream('{ foo: bar }')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['foo'] == 'bar'

# Generated at 2022-06-21 00:00:44.048138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader("null:")
    (k, v) = loader.get_single_data()
    assert k is None
    assert v is None

    loader = AnsibleLoader("foo")
    (k, v) = loader.get_single_data()
    assert k is None
    assert v == 'foo'

    loader = AnsibleLoader("42")
    (k, v) = loader.get_single_data()
    assert k is None
    assert v == 42

    loader = AnsibleLoader("1.23")
    (k, v) = loader.get_single_data()
    assert k is None
    assert v == 1.23

    loader = AnsibleLoader("{foo: bar}")
    (k, v)