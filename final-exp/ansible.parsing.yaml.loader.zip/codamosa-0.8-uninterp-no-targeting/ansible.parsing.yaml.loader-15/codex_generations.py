

# Generated at 2022-06-20 23:50:41.671169
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:50:44.064050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():               # pylint: disable=no-self-use, unused-argument
    ''' AnsibleLoader() protocol '''
    return True

# Generated at 2022-06-20 23:50:52.241461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.json import ansible_module_common_convert_exception_to_string
    from ansible.module_utils._text import to_bytes, to_text
    path = os.path.join('lib', 'ansible', 'parsing', 'yaml', 'tests')
    loader = AnsibleLoader(open(os.path.join(path, 'test_constructor.yml')),
                           vault_secrets={"vault_password": "vault_password"})
    assert loader.get_single_data() == {'a': u'foo', 'b': 3}

# Generated at 2022-06-20 23:50:53.365568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:50:58.691463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = '''
    ---
    - hosts: all
      gather_facts: False
      tasks:
      - name: test
        command: /bin/false
        changed_when: False
    '''
    loader = AnsibleLoader(test_data)
    playbook = loader.get_single_data()
    assert playbook[0]['hosts'] == 'all'
    assert playbook[0]['tasks'][0]['name'] == 'test'
    assert playbook[0]['tasks'][0]['command'] == '/bin/false'

# Generated at 2022-06-20 23:51:07.935515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    loader = AnsibleLoader(str(''))
    assert isinstance(loader.construct_object(None, None), AnsibleUnicode)
    assert isinstance(loader.construct_sequence(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnsafeText)
    assert isinstance(loader.construct_yaml_seq(None), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(None), dict)

# Generated at 2022-06-20 23:51:11.462723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('test/unit/module_utils/common/test_yaml.yaml')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert 2 == len(loader.constructor_prefix)
    assert data is not None

# vim: set et sts=4:

# Generated at 2022-06-20 23:51:18.084220
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class DummyLoader:

        def __init__(self):
            pass

        def get_single_data(self):
            return None

    dl = DummyLoader()
    assert dl
    al = AnsibleLoader(dl, file_name='/tmp/test_loader.yaml')
    assert al
    assert al.get_single_data() is None
    assert al.file_name == '/tmp/test_loader.yaml'

# Generated at 2022-06-20 23:51:25.214807
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    yaml_str = u"$ANSIBLE_VAULT;1.1;AES256\n3132333435363738393031323334353637383930313233343536373839303132333435363738393031323334353637383930313233343536373839303132333435363738393031323334353637383930\n"
    loader = yaml.Loader(yaml_str)
    loader.add_constructor(u'!vault', AnsibleConstructor.construct_yaml_str)
    result = loader.get_single_

# Generated at 2022-06-20 23:51:36.895995
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = '''
    ---
    - string
    - string
    -
      - string
      - string
    -
      -
        - string
        - string
      -
        - string
        - string
    '''

    loader = AnsibleLoader(stream)
    results = list(loader.get_single_data())

    assert results == [
        'string',
        'string',
        [
            'string',
            'string',
        ],
        [
            [
                'string',
                'string',
            ],
            [
                'string',
                'string',
            ],
        ],
    ]
    assert isinstance(results[0], AnsibleUnicode)

# Generated at 2022-06-20 23:51:49.286540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = [
        '---',
        '---',
    ]
    try:
        stream = open('/home/yinw/github/ansible/lib/ansible/vault/init.py','r')
    except Exception:
        print('open file failed')
    ansible_loader = AnsibleLoader(stream)
    # print(ansible_loader.stream)
    # print(ansible_loader.file_name)
    # print(ansible_loader.vault_secrets)

    # ansible_loader.update(stream)
    # print(ansible_loader.parser)
    # print(ansible_loader.parser.stream)

    # ansible_loader.update()
    # ansible_loader.update()
    # ansible_loader.update()


# Generated at 2022-06-20 23:52:01.128699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser, ParserError
    from yaml.resolver import Resolver
    from io import BytesIO
    l = AnsibleLoader('')
    assert isinstance(l, Reader)
    assert isinstance(l, Scanner)
    assert isinstance(l, Parser)
    assert isinstance(l, Composer)
    assert isinstance(l, AnsibleConstructor)
    assert isinstance(l, Resolver)
    # Test loading of YAML file and catching of errors
    yaml_string = '{key: val'
    f = BytesIO(yaml_string)    
    with pytest.raises(ParserError):
        AnsibleLoader

# Generated at 2022-06-20 23:52:11.119501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.constants as C

    # test allowed_include_primitives
    loader = AnsibleLoader('')
    allowed_include_primitives = C.DEFAULT_ALLOWED_INCLUDE_PRIMITIVES
    assert allowed_include_primitives == loader.allowed_include_primitives

    # test a empty string
    loader = AnsibleLoader('', file_name='memory')
    data = loader.get_single_data()
    assert data is None

    # test a valid yaml string
    loader = AnsibleLoader('foo: bar', file_name='memory')
    data = loader.get_single_data()
    assert data['foo'] == 'bar'

    # test a invalid yaml string
    loader = AnsibleLoader('foo: :bar', file_name='memory')

# Generated at 2022-06-20 23:52:18.855780
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test AnsibleLoader constructor
    """

    # Create a AnsibleLoader instance
    aloader = AnsibleLoader([])

    # Test __init__ and subclass methods from superclasses
    assert aloader.anchors == {}
    assert aloader.constructed_objects == []
    assert aloader.file_name == None
    assert aloader.vault_secrets == None
    assert aloader.resolver == Resolver.DEFAULT_RESOLVER

# Generated at 2022-06-20 23:52:25.577604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class MockStream(object):
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def read(self, num=None):
            if num is None:
                r = self.data[self.pos:]
            else:
                r = self.data[self.pos:self.pos + num]
            self.pos += len(r)
            return r

    s = MockStream("test: 1")
    # This will raise an exception if the __init__ methods
    # are not called correctly
    l = AnsibleLoader(s)
    assert l.get_data() == 'test: 1'

# Generated at 2022-06-20 23:52:35.264442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import ansible.parsing.yaml.loader
    print(ansible.parsing.yaml.loader)
    print(sys.modules['ansible.parsing.yaml.loader'])

    assert sys.modules['ansible.parsing.yaml.loader'] == ansible.parsing.yaml.loader
    assert ansible.parsing.yaml.loader.HAS_LIBYAML == HAS_LIBYAML
    assert issubclass(ansible.parsing.yaml.loader.AnsibleLoader, Parser)
    assert isinstance(ansible.parsing.yaml.loader.AnsibleLoader, AnsibleConstructor)
    assert isinstance(ansible.parsing.yaml.loader.AnsibleLoader, Resolver)

# Generated at 2022-06-20 23:52:39.115355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # these values are required to allow us to instantiate without throwing an error
    stream = ''
    file_name = 'test_file_name'
    vault_secrets = dict()

    assert AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-20 23:52:49.156500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-argument
    def _check_AnsibleLoader(stream, file_name=None, vault_secrets=None):
        return AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

    assert _check_AnsibleLoader('')
    assert _check_AnsibleLoader('', file_name='test_file')
    assert _check_AnsibleLoader('', vault_secrets={'test_file': {'vault_password': 'test vault password'}})
    assert _check_AnsibleLoader('', None, {'test_file': {'vault_password': 'test vault password'}})

# Generated at 2022-06-20 23:52:59.541010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == "__main__":
    import sys
    import os
    import unittest
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_AnsibleLoader(self):
            self.assertTrue(basic)
            self.assertTrue(AnsibleModule)

    unittest.main(verbosity=2)

# Generated at 2022-06-20 23:53:03.024931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''{
        "foo": [1, 2, 3],
        "bar": {
            "baz": 4
        }
    }'''
    AnsibleLoader(data).get_data()

# Generated at 2022-06-20 23:53:09.294013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

# Generated at 2022-06-20 23:53:21.262867
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  import StringIO

# Generated at 2022-06-20 23:53:21.852444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:31.489162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = { "vault_pass": "test" }
    filename = 'test'
    yaml_loader = AnsibleLoader(filename, file_name=filename, vault_secrets=vault_secrets)

    # test AnsibleConstructor.__init__
    assert yaml_loader.file_name == filename
    assert yaml_loader.vault_secrets == vault_secrets

    # test AnsibleConstructor.construct_yaml_obj

# Generated at 2022-06-20 23:53:32.637190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:53:37.363806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_snippet = """
- hosts: all
  vars:
    answer: 42
  tasks:
  - debug:
      msg: "The Answer is {{ answer }}"
    """

    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = AnsibleLoader(yaml_snippet).get_single_data()
    assert isinstance(data[0]['vars']['answer'], int)
    assert isinstance(data[0]['tasks'][0]['debug']['msg'], AnsibleUnicode)

# Generated at 2022-06-20 23:53:48.220607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This function will not be called except when running unit test with Python
    yaml = '''
a: 1
b:
  c: 3
  d: 4
'''
    # Create an AnsibleLoader instance, it will parse and load yaml into variable
    loader = AnsibleLoader(yaml)
    # Get variable
    variable = loader.get_single_data()
    #
    variable_a = variable['a']
    variable_b = variable['b']
    variable_b_c = variable_b['c']
    variable_b_d = variable_b['d']
    #
    assert variable_a == 1
    assert variable_b_c == 3
    assert variable_b_d == 4



# Generated at 2022-06-20 23:53:56.794137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText, AnsibleSequence, AnsibleMapping
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping


# Generated at 2022-06-20 23:54:06.379015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import load

    data = b'''\
    base:
      image: ubuntu:trusty
      sudo: yes
      volumes:
        - /srv:/srv
    test:
      extends: base
      command: sleep 30
    '''

    loader = AnsibleLoader(data)
    yaml = load(data, Loader=loader)

    for item in yaml:
        assert yaml[item]['sudo'] == True
        assert yaml[item]['volumes'] == ['/srv:/srv']
        if item == 'test':
            assert yaml[item]['command'] == 'sleep 30'
        else:
            assert 'command' not in yaml[item]

# Generated at 2022-06-20 23:54:08.159440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ans_load = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert ans_load is not None

# Generated at 2022-06-20 23:54:18.817610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Constructor of class AnsibleLoader - unit test

    The constructor of the class cannot be tested.
    """
    assert True

# Generated at 2022-06-20 23:54:23.437718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import examplestrings as strings
    loader = AnsibleLoader(strings.ansible_loader_string)
    data = loader.get_single_data()
    assert data == strings.ansible_loader_python, "The string was not properly loaded. "

# Generated at 2022-06-20 23:54:27.765931
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:54:33.075840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    my_str = b"---\nfoo: bar\n"
    result = AnsibleLoader(my_str).get_single_data()
    assert result == dict(foo=u'bar')
    assert isinstance(result['foo'], AnsibleUnicode)

# Generated at 2022-06-20 23:54:33.607541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-20 23:54:45.320361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    test_dict = {'a': 1, 'b': 2}
    test_string = """
    - a: 1
      b: 2
    """

    test_AnsibleMapping = AnsibleLoader(test_string).get_single_data() # pylint: disable=no-value-for-parameter
    assert isinstance(test_AnsibleMapping, AnsibleMapping)
    assert test_AnsibleMapping == test_dict

    test_AnsibleSequence = AnsibleLoader(test_string).get_single_data() # pylint: disable=no-value-for-parameter
    assert isinstance(test_AnsibleSequence, AnsibleSequence)
    assert test_Ansible

# Generated at 2022-06-20 23:54:45.929402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:54:55.836799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import yaml

    def _round_trip(text, expected):
        loader = AnsibleLoader(text)
        data = loader.get_single_data()
        assert data == expected, 'Round trip from {0} to {1} failed'.format(expected, data)

        yaml_text = yaml.dump(data)
        loader = AnsibleLoader(yaml_text)
        data = loader.get_single_data()
        assert data == expected, 'Round trip from {0} to {1} failed as yaml text: {2}'.format(expected, data, yaml_text)

    _round_trip("""
        - shell: echo 'hello world'
          args:
              warn: false
    """, [{"shell": "echo 'hello world'", "args": {"warn": False}}])

   

# Generated at 2022-06-20 23:55:06.836512
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.vault import VaultLib
    import io
    vault_id = 'vaultsecret'
    vault_pass = '-secret-'
    test_vault_pass = VaultLib(vault_pass.encode('utf-8'))
    test_vault_pass.decrypt(vault_id.encode('utf-8'))
    config = {'xyz': 'secret', 'abc': 'secret2'}
    test_yaml = "xyz: {{ lookup('vault', '" + vault_id + "') }}\nabc: {{ lookup('vault', '" + vault_id + "') }}\n"
    stream

# Generated at 2022-06-20 23:55:16.831243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_password = '$ANSIBLE_VAULT;1.1;AES256\n...\n'
    vault_secret = 'unicode_passphrase'

    test_file_name = os.path.join(os.path.dirname(__file__), 'data', 'encrypted_data.yml')
    vault_file_name = os.path.join(os.path.dirname(__file__), 'data', 'vault.yml')

    vault_secret_file = vault_file_name


# Generated at 2022-06-20 23:55:39.300354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import inspect

    if not HAS_LIBYAML:
        assert inspect.getmro(AnsibleLoader) == (AnsibleLoader, Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver, object)
    else:
        assert inspect.getmro(AnsibleLoader) == (AnsibleLoader, Parser, AnsibleConstructor, Resolver, object)

# Generated at 2022-06-20 23:55:46.566665
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    import os
    import sys
    import json
    import pytest
    import yaml

    with pytest.raises(yaml.YAMLError):
        with open(os.path.join(os.path.dirname(__file__), 'load', 'test.yml')) as stream:
            AnsibleLoader(stream)

    with open(os.path.join(os.path.dirname(__file__), 'load', 'test.yml')) as stream:
        data = AnsibleLoader(stream).get_single_data()
    print(data)
    assert data


# Generated at 2022-06-20 23:55:57.594190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader(None, file_name='/dev/null', vault_secrets=[VaultLib(password='password')])

    base_yaml_object = AnsibleBaseYAMLObject()
    assert base_yaml_object.__class__.__module__ == 'ansible.parsing.yaml.objects'
    assert base_yaml_object.__class__.__name__ == 'AnsibleBaseYAMLObject'

    encrypted_unico = AnsibleVaultEncryptedUnicode()
    assert encrypted_unico.__class__.__

# Generated at 2022-06-20 23:55:59.201155
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader is not None

# Generated at 2022-06-20 23:56:05.435594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import Parser
    if sys.version_info[0] < 3 and sys.version_info[1] < 2:
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, AnsibleConstructor)
    else:
        assert issubclass(AnsibleLoader, (Parser, AnsibleConstructor))

# Generated at 2022-06-20 23:56:09.216970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #def __init__(self, stream, file_name=None, vault_secrets=None):
    stream = '''a:
    b: 1
    c:
      d: 2
      e: 3'''
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert False == loader.is_vault_secret
    assert data['a']['b'] == 1
    assert data['a']['c']['d'] == 2
    assert data['a']['c']['e'] == 3


# Generated at 2022-06-20 23:56:15.359096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    raw_data = '''
      ---
      foo: [bar, baz]
      baz: quux
      hooray:
        - item1
        - item2
        - item3
      null: ~
      '''

    # if we can load the data, then the test has succeeded
    AnsibleLoader(raw_data).get_single_data()

# Generated at 2022-06-20 23:56:24.651484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test for checking that the AnsibleLoader class is not breaking
    '''
    class DummyStream:
        def __init__(self):
            self.data = '''
            - hosts: all
              vars:
                var1:
                - 1
                - 2
              tasks:
                - debug:
                     msg: '{{ var1 }}'
            '''
            self.pos = 0

        def read(self, size=0):
            data = self.data[self.pos:self.pos+size]
            self.pos += size
            if self.pos > len(self.data):
                return ''
            return data

    class AnsibleLoaderTest(AnsibleLoader):
        pass

    stream = DummyStream()
    loader = AnsibleLoaderTest(stream)

# Generated at 2022-06-20 23:56:34.776500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '../'))

    import ansible.parsing.yaml.loader as loader
    import ansible
    import os

    # Prepare the AnsibleLoader object
    vault_secret_file = os.path.join(os.path.dirname(__file__), '../../../test/vault.key')
    vault_secrets = [ vault_secret_file ] if os.path.exists(vault_secret_file) else []
    loader = loader.AnsibleLoader(open(ansible.__file__), vault_secrets=vault_secrets)

    # Check the attributes of class AnsibleLoader
    assert loader.vault_secrets is not None

# Generated at 2022-06-20 23:56:36.993444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    assert isinstance(AnsibleLoader('foo'), AnsibleConstructor)

# Generated at 2022-06-20 23:57:15.490793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - foo:
        bar: foobar
        baz:
          - foobaz
          - foobiz
    """

    for fname in ['/etc/ansible/group_vars/all', '/etc/ansible/host_vars/localhost']:
        al = AnsibleLoader(yaml_str, file_name=fname)
        data = al.get_single_data()

        assert(data[0]['foo']['bar'] == 'foobar')
        assert(data[0]['foo']['baz'][0] == 'foobaz')
        assert(data[0]['foo']['baz'][1] == 'foobiz')



# Generated at 2022-06-20 23:57:22.994135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.parsing.yaml.dumper import AnsibleDumper

    source_str = '''
    - my_package:
        name: git
    '''
    source_stream = io.StringIO(source_str)
    c = AnsibleLoader(file_name='test/file', stream=source_stream)
    dumper = AnsibleDumper(css='nested', dlevel=0)
    result  = dumper.represent_dict(c.get_single_data())
    assert result == '''- my_package:\n  name: git\n'''

# Generated at 2022-06-20 23:57:23.503565
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:57:27.652929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fake_yaml = '''
foo:
  - 1
  - 2
'''
    # Create our own loader
    loader = AnsibleLoader(fake_yaml, file_name='test')
    # Load the yaml
    data = loader.get_single_data()
    # Verify it was loaded correctly
    assert data['foo'] == [1, 2]
    # Verify AnsibleConstructor worked
    assert 'filename' in data



# Generated at 2022-06-20 23:57:39.304840
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test the loader class.
    '''
    data = '''
---
- hosts: localhost
  gather_facts: false
  vars:
    package: apache2
  tasks:
  - name: Ensure apache is at the latest version
    apt: pkg={{ package }} state=latest update_cache=yes
    tags:
      - install
      - foo
      - bar
  - debug: var=ansible_distribution
  '''

    results = AnsibleLoader(data).get_single_data()

    if len(results) != 3:
        print("Expected 3 fields from test data")
        raise Exception("Expected 3 fields from test data")


# Generated at 2022-06-20 23:57:49.531291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = [('$ANSIBLE_VAULT;1.1;AES256', None)]
    vault = VaultLib(vault_secrets)

# Generated at 2022-06-20 23:57:53.873771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # now for the loader class itself..
    # basic load of a dictionary with a string and int
    yaml = """
foo: 1
bar: blah
"""
    data = AnsibleLoader(yaml).get_single_data()
    assert data.get('foo') == 1
    assert data.get('bar') == 'blah'

    # duplicated keys should be skipped, with warning
    yaml = """
foo: 1
bar: blah
foo: 3
"""
    data = AnsibleLoader(yaml).get_single_data()
    assert data.get('foo') == 3
    assert data.get('bar') == 'blah'

    # testing vault encrypted text

# Generated at 2022-06-20 23:57:54.756060
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    pass

# Generated at 2022-06-20 23:58:04.855668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    ---
    [ 1, 2, 3, 4 ]
    ---
    { "a" : "b" }
    '''

    stream = AnsibleLoader(data).get_single_data()
    assert type(stream) == list
    assert stream == [1,2,3,4]

    stream = AnsibleLoader(data).get_single_data()
    assert type(stream) == dict
    assert stream == { 'a' : 'b' }

    data = '''
    ---
    foo
    '''

    stream = AnsibleLoader(data).get_single_data()
    assert type(stream) == str
    assert stream == 'foo'


# Generated at 2022-06-20 23:58:11.954872
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    - hosts: localhost
      vars:
        var1: 'ansible'
      tasks:
        - name: test
          debug:
            msg: "hello {{ var1 }}"
    """
    loader = AnsibleLoader(data, vault_secrets=None)
    playbook = loader.get_single_data()
    assert playbook
    assert playbook['hosts'] == 'localhost'
    assert playbook['vars']['var1'] == 'ansible'
    assert playbook['tasks'][0]['debug']['msg'] == 'hello ansible'


# Generated at 2022-06-20 23:59:25.294813
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(list())

# Generated at 2022-06-20 23:59:26.069495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-20 23:59:27.773854
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:59:31.192554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    # pylint: disable=unused-variable
    if sys.version_info >= (2, 7):
        loader = AnsibleLoader(stream=None)
        assert loader

# Generated at 2022-06-20 23:59:37.970928
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects


# Generated at 2022-06-20 23:59:42.551354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    # pylint: disable=protected-access
    assert loader.class_name_for_tag('tag:yaml.org,2002:str') == 'str'
    assert loader.class_name_for_tag('tag:yaml.org,2002:python/str') == 'str'
    assert loader.class_name_for_tag('tag:yaml.org,2002:int') == 'int'
    assert loader.class_name_for_tag('tag:yaml.org,2002:python/int') == 'int'
    assert loader.class_name_for_tag('tag:yaml.org,2002:float') == 'float'
    assert loader.class_name_for_tag('tag:yaml.org,2002:python/float') == 'float'
    assert loader

# Generated at 2022-06-20 23:59:50.954258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=bare-except
    data = '''
    - hosts: test
      remote_user: user
    '''
    try:
        loader = AnsibleLoader(data)
        loader.get_single_data()
    except:
        raise AssertionError('AnsibleLoader should accept a single string')

    try:
        loader = AnsibleLoader(data, 'test')
        loader.get_single_data()
    except:
        raise AssertionError('AnsibleLoader should accept a filename')

    try:
        loader = AnsibleLoader(data, vault_secrets={})
        loader.get_single_data()
    except:
        raise AssertionError('AnsibleLoader should accept a vault password')


# Generated at 2022-06-20 23:59:57.281330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.clean import clean

    # Create AnsibleLoader, which will be used to do test
    loader = AnsibleLoader(sys.stdin)
    test_dict = { 'a': 1, 'b': 2, 'c': { 'c1': 1, 'c2': 2, 'c3': [ 1, 2, 3, 4 ]}, 'd': { 'd1' : { 'd11': 1 }}}

    # test _prepare_lookup_list()
    loader._prepare_lookup_list(test_dict)
    assert loader._lookup_list == [ 'a', 'b', 'c', 'd' ]

    # test _deepcopy_dict()
    test_dict_copy = loader

# Generated at 2022-06-21 00:00:07.354697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import textwrap
    from ansible.module_utils.six import StringIO

    if sys.version_info[0] > 2:
        from ansible.module_utils.six.moves import builtins
        builtin_module = builtins.__name__
    else:
        import __builtin__
        builtin_module = __builtin__.__name__

    def test_load(s, expected):
        ''' ensures that the yaml string s parses to expected in AnsibleLoader '''
        yaml = AnsibleLoader(s)
        data = list(yaml)
        assert data == expected, "expected %s but got %s" % (expected, data)


# Generated at 2022-06-21 00:00:08.916134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' AnsibleLoader class is deprecated and will be removed in version 2.12 '''
    pass