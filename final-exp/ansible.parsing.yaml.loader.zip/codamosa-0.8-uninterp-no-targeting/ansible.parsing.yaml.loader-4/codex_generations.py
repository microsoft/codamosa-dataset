

# Generated at 2022-06-20 23:50:49.637326
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, file_name='test_file_name')
    assert (loader.file_name == 'test_file_name')

    loader = AnsibleLoader(None, vault_secrets=[AnsibleVaultEncryptedUnicode(b'1234', b'567')])
    assert (loader.vault_secrets[0].vault_id == '567')
    assert (loader.vault_secrets[0].vault_secret == b'1234')

# Generated at 2022-06-20 23:50:57.009962
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from io import BytesIO
    except ImportError:
        from cStringIO import StringIO as BytesIO

    stream = BytesIO("""
[{"a": 1}, [1, 2, 3]]
    """.encode("utf-8"))
    loader = AnsibleLoader(stream)
    ansible_data = loader.get_single_data()
    assert isinstance(ansible_data, list)
    assert len(ansible_data) == 2
    assert ansible_data[0]['a'] == 1
    assert ansible_data[1] == [1, 2, 3]

# Generated at 2022-06-20 23:51:08.250967
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #import doctest
    #doctest.testmod(extraglobs={'AnsibleLoader':AnsibleLoader})
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnicode
    # use the custom class

# Generated at 2022-06-20 23:51:18.573815
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestVarsModule:
        def __init__(self):
            self.ansible_vars = {
                'test': {
                    'test1': 'test1',
                    'test2': ['test2'],
                }
            }

        def get_vars(self, loader, path, entities):
            return self.ansible_vars

    tvm = TestVarsModule()

    # Constructor works
    al = AnsibleLoader(None, '/path/to/file', vault_secrets=None)

    # The setattr below is needed as we can't easily access the 'vars'
    # property of the constructor object
    setattr(al, '_AnsibleConstructor__vars', tvm)

    # Test the vault text path

# Generated at 2022-06-20 23:51:20.178908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    sys.stderr.write('test_AnsibleLoader: FIXME - implement test\n')

# Generated at 2022-06-20 23:51:23.907016
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader(None, vault_secrets=None)
    assert isinstance(l, Parser)
    assert isinstance(l, AnsibleConstructor)


# pylint: disable=unused-argument

# Generated at 2022-06-20 23:51:25.268138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)

# Generated at 2022-06-20 23:51:28.135178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO('---\nkey2: val')
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_single_data()

# Generated at 2022-06-20 23:51:39.737644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    loader = AnsibleLoader(io.BytesIO((
        '- { a: 1, b: 2 }\n'
        '- b: 3\n'
        '  a: 2\n'
    ).encode()), vault_secrets=None)
    loader.get_single_data() == [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}]


    # make sure our noop constructors are skipped
    loader = AnsibleLoader(io.BytesIO((
        '!include foo.yml\n'
        '- { a: 1, b: 2 }\n'
    ).encode()), file_name='bar.yml', vault_secrets=None)


# Generated at 2022-06-20 23:51:49.629976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader('[1, 2]')
    assert l.get_single_data() == [1, 2]

    l = AnsibleLoader('''
    ---
    - 1
    - 2
    ''')
    assert l.get_single_data() == [1, 2]

    l = AnsibleLoader('123')
    assert l.get_single_data() == 123

    l = AnsibleLoader('123.45')
    assert l.get_single_data() == 123.45

    l = AnsibleLoader('123.45e+2')
    assert l.get_single_data() == 12345

    l = AnsibleLoader('123.45e-2')
    assert l.get_single_data() == 1.2345


# Generated at 2022-06-20 23:52:04.337732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.module_utils.six import binary_type, text_type

    yaml_str = text_type('''
        ---
        foo:
          - bar
          - !!python/str "baz"
          - !!python/unicode "qux"
          - 1
          - 1.1
          - !!float "2.0"
          - !!python/unicode |
            foo
            bar
            baz
            qux
            xyzzy
        ''')

    yaml_ds = AnsibleLoader(yaml_str).get_single_data()

    assert isinstance(yaml_ds, AnsibleMapping)
    foo_seq = yaml_ds['foo']

# Generated at 2022-06-20 23:52:13.242813
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

# Generated at 2022-06-20 23:52:18.396489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
- ansible_ssh_user: john
  hosts:
    - server1
- hosts:
    - server2
    - server3
'''

    loader = AnsibleLoader(data)
    assert loader is not None

# Generated at 2022-06-20 23:52:26.507983
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-20 23:52:35.726610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.constants import DEFAULT_VAULT_PASSWORD_FILE
    from ansible.errors import AnsibleParserError
    import tempfile
    import os

    # Verify that AnsibleLoader requires a stream
    try:
        AnsibleLoader()
        assert False
    except TypeError:
        assert True

    # Verify that AnsibleLoader works with a string
    yaml = '''
    - 1
    - 2
    - 3
    '''
    loader = AnsibleLoader(yaml)
    data = loader.get_single_data()
    assert data == [1, 2, 3]

    # Verify that AnsibleLoader works with a file
    yaml = '''
    - 4
    - 5
    - 6
    '''

# Generated at 2022-06-20 23:52:47.412637
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:52:58.798000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest
    from ansible.plugins.loader import construct_yaml_map_unicode_charref

    class TestAnsibleLoader(unittest.TestCase):
        ansible_loader = AnsibleLoader(io.BytesIO(b'{}'))

        def test_construct_yaml_map_unicode_charref(self):
            # This test covers the case where construct_yaml_map_unicode_charref
            # is called with an empty node
            node = dict()

            if sys.version_info < (3,):
                with self.assertRaises(KeyError):
                    self.ansible_loader.construct_yaml_map_unicode_charref(node)
            else:
                with self.assertRaises(TypeError):
                    self.ans

# Generated at 2022-06-20 23:53:03.485560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ansible_loader is subclass of Parser, this test execute initialization of
    # Parser.__init__
    ansible_loader = AnsibleLoader(None)
    assert(isinstance(ansible_loader, (Parser,)))
    assert(isinstance(ansible_loader, (AnsibleConstructor,)))

# Generated at 2022-06-20 23:53:09.563922
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string = '''
    ---
    - hosts: all
      gather_facts: false
      tasks:
        - name: test
          debug: msg="Hello World"
    '''

    result = {
        'hosts': 'all',
        'gather_facts': 'false',
        'tasks': [
            {
                'name': 'test',
                'debug': {'msg': 'Hello World'},
            },
        ],
    }

    yaml = AnsibleLoader(test_string)
    assert result == yaml

# Generated at 2022-06-20 23:53:21.448288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import yaml
    if sys.version_info.major < 3:
        from codecs import open
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Load encrypted strings from a YAML file and then try to reload it
    for ext in ('yml', 'yaml'):
        plaintext = u"String without encryption"

# Generated at 2022-06-20 23:53:27.708861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader.__init__

# Generated at 2022-06-20 23:53:29.044449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-20 23:53:36.613856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import wrap_var

# Generated at 2022-06-20 23:53:37.992045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-20 23:53:49.412997
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    # Raw data
    yaml_data = u"""
    foo:
        baz:
            - "abcd"
            - "1234"
        bar:
            - 1
            - 2
    """
    # Load data with AnsibleLoader
    loader = AnsibleLoader(yaml_data)
    # Check values of 'bar' and 'baz'
    assert loader.get_single_data().keys() == ['foo']
    assert loader.get_single_data()['foo'].keys() == ['baz', 'bar']
    assert loader.get_single_data()['foo']['baz'] == [u'abcd', u'1234']
    assert loader.get_single_data()['foo']['bar'] == [1, 2]
    # Check if the loader has some problem


# Generated at 2022-06-20 23:53:55.491891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO

    stream = StringIO.StringIO(
        "%YAML 1.2\n"
        "---\n"
        "a: 1"
    )
    try:
        AnsibleLoader(stream)
        assert False
    except Exception as e:
        if sys.version_info[0] == 2 and sys.version_info[1] <= 6:
            assert "version indicator not found" in str(e)
        else:
            assert "did not find expected <document start>" in str(e)

# Generated at 2022-06-20 23:54:06.421598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    stream = ""
    loader = AnsibleLoader(stream)
    assert issubclass(loader.construct_yaml_bool, type(AnsibleVaultEncryptedUnicode))

# Generated at 2022-06-20 23:54:18.497264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # assert on the class variables
    assert AnsibleLoader.anchor_templates
    assert AnsibleLoader.block_style_dicts
    assert AnsibleLoader.file_name
    assert AnsibleLoader.file_name
    assert AnsibleLoader.vault_secrets
    # create object for AnsibleLoader class
    ansible_loader = AnsibleLoader('')
    # assert instance variables
    assert ansible_loader.file_name
    assert isinstance(ansible_loader.reader, Reader)
    assert isinstance(ansible_loader.stream, Reader)
    assert isinstance(ansible_loader.resolver, Resolver)
    assert isinstance(ansible_loader.constructor, AnsibleConstructor)
    assert isinstance(ansible_loader.parser, Parser)

# Generated at 2022-06-20 23:54:23.870825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

    assert hasattr(loader, 'elastic_version')
    assert hasattr(loader, 'elastic_timezone')
    assert hasattr(loader, 'ansible_host')
    assert hasattr(loader, 'ansible_verbosity')
    assert hasattr(loader, 'ansible_version')
    assert hasattr(loader, 'ansible_version_string')

# Generated at 2022-06-20 23:54:24.545679
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:54:46.707361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.module_utils.common.yaml import HAS_LIBYAML, Parser, AnsibleLoader

    # input text for parsing
    text = "---\n- hosts: localhost\n  tasks:\n\t- debug: {var: my_var}\n"
    # use AnsibleLoader class to parse text
    my_loader = AnsibleLoader(text)

    # get data from loader object in python dict format
    data = my_loader.get_single_data()
    assert isinstance(data, dict)

    # get first value of "tasks" key in data dict
    first_task = data['tasks'][0]
    assert isinstance(first_task, dict)

    # get host value from first_task dict
    host = first_task['debug']['var']

# Generated at 2022-06-20 23:54:49.990080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load_all("""\
---
- type: dict
  name: dict
  value: dict
- type: list
  name: list
  value: list
""", Loader=AnsibleLoader)

# Generated at 2022-06-20 23:54:52.596772
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "foo: bar\n"
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}

# Generated at 2022-06-20 23:54:54.150813
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:55:01.028359
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleVaultEncryptedUnicode


# Generated at 2022-06-20 23:55:12.429053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # create vault secrets
    vault_secrets = [u'a'*10]
    # create vault password
    vault_password = u'b'*10
    # create cipher text
    vault_encrypted_data = u'VSqLDQ2XfOd8RZJhAiLmEzVtPRp8tMItm7rqr3gYaX0='
    # create vault object
    vault = VaultLib(vault_secrets)
    # encrypt data
    vault_encrypted_data = vault.encrypt(vault_password)
    # decrypt data
    vault_decrypted_data = vault.decrypt(vault_password)

# Generated at 2022-06-20 23:55:21.192364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Unit test for class AnsibleLoader"""
    import yaml

# Generated at 2022-06-20 23:55:32.516736
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.vault import VaultLib

    vault_pass = 'secret'

    vault = VaultLib([('default', vault_pass)])

    yaml_data = to_bytes("""
    ---
    foo: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          393537333437336530333565323434323934616232MzQ2ODQ5OAAAAdQBXYXJuaW5nLT5WYXVsdCBpcyBhIHBhdXNlIG9mIHByb2
          yKwfti8zvgL6U/Ak6Mk=
          bar
    """)

    # The above YAML data is actually a ciphertext, which should

# Generated at 2022-06-20 23:55:42.285669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import sys
    import tempfile

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    fixtures_path = os.path.join(os.path.dirname(__file__), 'loader_fixtures')

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(loader.load_inventory_from_folder(fixtures_path))

    fd, tmpsrc = tempfile.mkstemp()
    tmpsrc += '.yml'
    os.close(fd)

    # Add vault secret to variable manager and files
    variable_manager

# Generated at 2022-06-20 23:55:47.325296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    content = "---\n- hosts: ehlo\n  tasks: []\n"
    stream = io.StringIO(content)
    loader = AnsibleLoader(stream)
    result = loader.get_single_data()
    assert result == [
        {
            "tasks": [],
            "hosts": "ehlo",
        }
    ]

# Generated at 2022-06-20 23:56:12.619671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Unit test for constructor of class AnsibleLoader
    d = AnsibleLoader(None)
    assert isinstance(d, AnsibleLoader)
    assert isinstance(d, Resolver)

# Generated at 2022-06-20 23:56:23.326356
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    # plain
    data = AnsibleLoader(None).get_single_data('[1,2,3]')
    assert isinstance(data, list)
    assert len(data) == 3
    assert data[0] == 1
    assert data[1] == 2
    assert data[2] == 3

    # ansible mapping
    data = AnsibleLoader(None).get_single_data('{a: b}')
    assert isinstance(data, AnsibleMapping)
    assert len(data.items()) == 1
    assert data['a'] == 'b'

    # ansible sequence
    data = AnsibleLoader(None).get_single_data('[a, b]')

# Generated at 2022-06-20 23:56:29.664599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class DumbFile(object):
        def __init__(self, data):
            self.data = data

        def read(self):
            return self.data

        def readline(self):
            return self.data

    fh = DumbFile("""
        ---
        - hosts: all
          tasks:
            - debug:
                var: test_variable
                verbosity: 1
    """)
    a_loader = AnsibleLoader(fh)
    data = a_loader.get_single_data()
    assert 'hosts' in data
    assert 'tasks' in data
    assert 'debug' in data.get('tasks')[0]
    assert 'var' in data.get('tasks')[0].get('debug')

# Generated at 2022-06-20 23:56:31.296335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b"foo")
    assert loader is not None

# Generated at 2022-06-20 23:56:41.354524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    # test single string constructor
    yaml_string_single_string = "string\n"
    yaml_stream                = StringIO.StringIO( yaml_string_single_string )
    loader                     = AnsibleLoader( yaml_stream )
    assert loader.get_single_data() == "string"

    # test single object constructor
    yaml_string_single_object = '{a: 1, b: 2}\n'
    yaml_stream               = StringIO.StringIO( yaml_string_single_object )
    loader                    = AnsibleLoader( yaml_stream )
    assert loader.get_single_data() == { 'a': 1, 'b': 2 }

    # test single string constructor

# Generated at 2022-06-20 23:56:47.829449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-argument
    from ansible.module_utils.common.yaml_loader import AnsibleLoader

    env = dict(
        a='123',
        b='ABC',
        c='true',
        d='false',
        e='null',
    )
    assert AnsibleLoader(
        '{a}:{b}:{c}:{d}:{e}:{missing}', vault_secrets=env
    ).get_single_data() == '123:ABC:true:false:null:'

# Generated at 2022-06-20 23:56:49.281565
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Run the AnsibleLoader constructor'''
    assert AnsibleLoader('{}') is not None


# Generated at 2022-06-20 23:56:51.272322
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = '''
    - hosts: localhost
      tasks:
        - name: test task
          debug: msg="hello"
          tags: test
    '''
    AnsibleLoader(content)

# Generated at 2022-06-20 23:56:57.442686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = open(os.path.join(os.path.dirname(__file__), 'data', 'constructor', 'simple-list.yaml'), 'r')
    loader = AnsibleLoader(stream)

    assert type(loader) == AnsibleLoader
    content = loader.get_single_data()

    assert content[0] == 'a'
    assert content[1] == 'b'
    assert content[2] == 'c'

# Generated at 2022-06-20 23:56:58.427132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Testing of class AnsibleLoader

# Generated at 2022-06-20 23:57:43.862946
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader is not None

# Generated at 2022-06-20 23:57:50.664436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile

    fd, fname = tempfile.mkstemp(text=True)
    with os.fdopen(fd, 'w') as f:
        f.write('''
---
a:
  - b
c:
  - d
        ''')

    loader = AnsibleLoader(open(fname))
    data = loader.get_single_data()
    assert data == {'a': ['b'], 'c': ['d']}
    assert loader.file_name == fname

    os.unlink(fname)

# Generated at 2022-06-20 23:57:52.268325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
        stream = "1"
        file_name = "ansible"
        vault_secrets = ["test"]
        AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-20 23:57:54.707472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # AnsibleLoader class was introduced in version 2.0
    pass

# Generated at 2022-06-20 23:58:00.092919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data1 = """
    ---
    foo: 1
    bar:
        bam: 3
        baz: [ 1, 2, 3]
    """
    import StringIO
    loader = AnsibleLoader(StringIO.StringIO(data1))
    data = loader.get_single_data()
    assert data['foo'] == 1
    assert data['bar']['baz'][2] == 3

# Generated at 2022-06-20 23:58:02.097750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '{"key":val}'
    assert isinstance(AnsibleLoader(stream), AnsibleLoader)

# Generated at 2022-06-20 23:58:11.572600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=R0914
    test_data = """
---
- hosts: localhost

  connection: local

  tasks:
    - debug:
        msg: "{{ item }}"
      with_items:
        - foo
        - bar
"""

    test_data_unicode = u"""
---
- hosts: localhost

  connection: local

  tasks:
    - debug:
        msg: "{{ item }}"
      with_items:
        - foo
        - bar
"""

    loader = AnsibleLoader(test_data, file_name="dummy_file")
    loader = AnsibleLoader(test_data_unicode, file_name="dummy_file")
    loader = AnsibleLoader(test_data_unicode, file_name=u"dummy_file")

    assert 'tasks'

# Generated at 2022-06-20 23:58:12.482311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# pylint: disable=unused-argument

# Generated at 2022-06-20 23:58:19.336129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)
    assert loader
    assert loader.yaml_constructors
    assert loader.yaml_multi_constructors
    assert loader.add_implicit_resolver
    assert loader.resolve
    assert loader.construct_document
    assert loader.construct_object
    assert loader.construct_scalar
    assert loader.construct_yaml_str
    assert loader.construct_yaml_seq
    assert loader.construct_yaml_map
    assert loader.construct_yaml_int
    assert loader.construct_yaml_float
    assert loader.construct_yaml_bool
    assert loader.check_data_is_scalar
    assert loader.check_data_is_seq
    assert loader.check_data_is_map

# Generated at 2022-06-20 23:58:22.032622
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.config.data import ConfigData
    config_data = ConfigData()
    config_data.parse()
    loader = AnsibleLoader("", vault_secrets=config_data.vault_secrets)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-21 00:00:05.599493
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create a dictionary loader
    loader = AnsibleLoader(None)

    # Test if the Reader, Scanner, Parser, Composer, Resolver and AnsibleConstructor are correctly constructured
    assert_Reader = isinstance(loader, Reader)
    assert_Scanner = isinstance(loader, Scanner)
    assert_Parser = isinstance(loader, Parser)
    assert_Composer = isinstance(loader, Composer)
    assert_Resolver = isinstance(loader, Resolver)
    assert_AnsibleConstructor = isinstance(loader, AnsibleConstructor)

    assert assert_Reader and assert_Scanner and assert_Parser and assert_Composer and assert_Resolver and assert_AnsibleConstructor

# Generated at 2022-06-21 00:00:13.476230
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # py27,py34
    import os, sys, inspect

    currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    parentdir = os.path.dirname(currentdir)
    # grandparentdir = os.path.dirname(parentdir)
    # sys.path.insert(0, grandparentdir)
    # sys.path.insert(0, parentdir)

    from ansible.parsing.yaml.constructor import AnsibleLoader

    # Test one-shot options
    test_file = os.path.join(parentdir, '../playbooks/test_playbook.yml')
    loader = AnsibleLoader(open(test_file), file_name=test_file, vault_secrets=[])
    all_data = loader

# Generated at 2022-06-21 00:00:24.744463
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-21 00:00:26.970767
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This function is used for testing the constructor of class AnsibleLoader.

    :return:
    '''
    reader = AnsibleLoader('string')
    assert reader is not None

# Generated at 2022-06-21 00:00:34.128620
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-21 00:00:36.155834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader('dummy')
    assert a.file_name is None
    assert a.vault_secrets is None

# Generated at 2022-06-21 00:00:37.729517
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # make sure we can initialize AnsibleLoader
    data = b'{foo: bar}'
    AnsibleLoader(data)

# Generated at 2022-06-21 00:00:39.706202
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    y = yaml.load('[1, 2, 3]', Loader=AnsibleLoader)
    assert(y[0] == 1)

# Generated at 2022-06-21 00:00:40.029222
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-21 00:00:43.926751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml