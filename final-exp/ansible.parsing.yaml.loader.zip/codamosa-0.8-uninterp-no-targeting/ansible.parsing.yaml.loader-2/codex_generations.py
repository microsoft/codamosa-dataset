

# Generated at 2022-06-20 23:50:54.438283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.inventory.host import Host
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = []
    for secret in ['foo','bar','baz']:
        vault_secrets.append(VaultSecret(secret, 'dummy_secret_file'))
    vault_secrets = VaultLib(vault_secrets)

    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(foo="bar", baz="blerg")
    variable_manager.options_vars = ["my_var=my_val"]
    variable_manager.set_host_variable(Host('127.0.0.1'), 'ansible_connection', 'local')

    prefix

# Generated at 2022-06-20 23:50:54.961737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleConstructor

# Generated at 2022-06-20 23:51:06.922729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.vault import VaultLib

    foo = '''
- hosts: 127.0.0.1
  gather_facts: true
  tasks:
    - debug: msg="hello world"
    - include: foo.yml
'''

    # Test the AnsibleLoader class without vault
    a = AnsibleLoader(foo)
    a.get_single_data()
    assert a.data[0]['tasks'][1]['include'] == 'foo.yml'

    # Test the AnsibleLoader class with vault
    vault_pass = 'vault_password'
    vault_secrets = [ (VaultLib.get_vault_secret(vault_pass)) ]

# Generated at 2022-06-20 23:51:14.931032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

# Generated at 2022-06-20 23:51:23.444723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader('')
    assert loader is not None
    assert loader.file_name is None
    assert loader.vault_secrets == []
    assert loader.construct_yaml_str('val') == 'val'
    assert loader.construct_yaml_str(u'val') == u'val'
    if HAS_LIBYAML:
        assert isinstance(loader.construct_yaml_str(AnsibleVaultEncryptedUnicode(u'val')), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:51:25.779112
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser) or issubclass(AnsibleLoader, Reader)

# Generated at 2022-06-20 23:51:37.444196
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib

    vault = VaultLib(['mysecret'])


# Generated at 2022-06-20 23:51:38.914554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=W0613
    AnsibleLoader('')

# Generated at 2022-06-20 23:51:49.287259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (3,):
        import __builtin__
        builtin_open = __builtin__.open
    else:
        import builtins
        builtin_open = builtins.open

    # This is needed to make the 'open' context manager work in Python 2.6
    class open():
        def __init__(self, file, mode=None):
            self.file = file
            self.mode = mode
        def __enter__(self):
            return open(self.file, self.mode)
        def __exit__(self, exc_type, exc_val, exc_tb):
            self.file.close()
            return False

    test_data = open(__file__, 'rb')
    loader = AnsibleLoader(test_data)

# Generated at 2022-06-20 23:51:59.169671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    - hosts: all
      gather_facts: no
      tasks:
      - name: test
        debug: msg="hello world"
        tags: always
        ignore_errors: yes
    """
    data = AnsibleLoader(data, vault_secrets=[{'password': 'secret', 'identity': 'secret'}]).get_single_data()
    assert(data[0]['tasks'][0]['debug']['msg'] == "hello world")
    assert(data[0]['tasks'][0]['tags'] == ['always'])
    assert(data[0]['tasks'][0]['ignore_errors'] == True)


# Generated at 2022-06-20 23:52:04.089790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name="test_file_name")
    assert loader.file_name == "test_file_name"

# Generated at 2022-06-20 23:52:07.360153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    test_loader = AnsibleLoader(None)
    assert hasattr(test_loader, 'add_constructor')



# Generated at 2022-06-20 23:52:14.656507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    import ansible.parsing.yaml.loader

    ansible_loader = ansible.parsing.yaml.loader.AnsibleLoader(None, 'test_file', None)

    assert ansible_loader.file_name == 'test_file'
    assert ansible_loader.vault_secrets == None

    assert builtins not in ansible_loader.yaml_constructors.values()
    assert ansible_loader.yaml_constructors['tag:yaml.org,2002:null'].obj == None
    assert ansible_loader.yaml_constructors['tag:yaml.org,2002:bool'].obj == True

# Generated at 2022-06-20 23:52:25.209054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import yaml

    class TestAnsibleLoader(object):
        def __init__(self, content, vault_password_file=None, file_name=None, vault_secrets=None):
            self.content = content
            self.file_name = file_name
            self.vault_secrets = vault_secrets
            self.vault_password_file = vault_password_file

        def __call__(self):
            return self.content

    loader_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 23:52:26.162878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    pass

# Generated at 2022-06-20 23:52:35.538994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    sample = '''
---
- hosts: localhost
  gather_facts: False
  tasks:
    - debug:
        msg: Hello from AnsibleLoader unit test
  name: AnsibleLoader
'''
    sample_obj = AnsibleLoader(sample)
    assert isinstance(sample_obj, AnsibleLoader)
    sample_data = sample_obj.get_single_data()
    assert isinstance(sample_data, list)
    assert len(sample_data) == 1
    assert isinstance(sample_data[0], AnsibleBaseYAMLObject)

# Generated at 2022-06-20 23:52:47.156324
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import six
    import yaml

    yaml_str = '''
- name: hello
  connection: network_cli
  hosts: localhost
  gather_facts: no
    '''

    if hasattr(yaml, '__with_libyaml__'):
        yaml.warnings({'YAMLLoadWarning': False})

    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data[0].get('name') == 'hello'
    assert isinstance(data, list)


# Generated at 2022-06-20 23:52:48.659348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader("test")
    assert hasattr(instance, 'dispatch')

# Generated at 2022-06-20 23:52:53.952516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('../../tests/yaml/loader/constructor/pass2.yml') as f:
        data = f.read()

    assert AnsibleLoader(data).get_single_data() == {
        'a': 'b',
        'c': 'd',
        'e': 'f',
        'g': 'h',
    }

# Generated at 2022-06-20 23:53:05.326135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-branches,too-many-locals
    from ansible.module_utils.common.yaml import AnsibleLoader

    # test 'with_items' in a playbook
    yaml_str = """
    - hosts: localhost
      gather_facts: no
      tasks:
        - shell: echo "{{item}}"
          with_items:
            - one
            - two
    """
    data = AnsibleLoader(yaml_str).get_single_data()
    assert data[0]['hosts'] == 'localhost'
    assert data[0]['tasks'][0]['with_items'][0] == 'one'
    assert data[0]['tasks'][0]['with_items'][1] == 'two'

    # test 'with_items'

# Generated at 2022-06-20 23:53:21.971551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string_one = '''
    ---
    - hosts: localhost
    '''

    test_string_two = '''
    ---
    - hosts: localhost
      tasks:
        - name: 'do this'
    '''

    test_string_three = '''
    - hosts: localhost
      tasks:
        - name: 'do this'
    '''

    # valid test
    test_yaml_1 = AnsibleLoader(test_string_one)
    assert isinstance(test_yaml_1, AnsibleLoader)

    # valid test
    test_yaml_2 = AnsibleLoader(test_string_two)
    assert isinstance(test_yaml_2, AnsibleLoader)

    # invalid test

# Generated at 2022-06-20 23:53:23.449255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:53:26.325582
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b'{ "k1": { "k2": { "k3": "v3" } } }', vault_secrets=['foo'])
    loader.get_single_data()

# Generated at 2022-06-20 23:53:26.953948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:53:30.065759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = 'filename'
    vault_secrets = []

    try:
        stream_ = AnsibleLoader(stream, file_name, vault_secrets)
        assert True
    except ImportError:
        assert True

# Generated at 2022-06-20 23:53:38.354253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import unittest
    from ansible.parsing.yaml.constructor import AnsibleConstructorError

    # Reset the yaml loader in case other tests changed it
    import warnings
    warnings.simplefilter("ignore", DeprecationWarning)
    from ansible.parsing.yaml.loader import AnsibleLoader
    warnings.simplefilter("default", DeprecationWarning)

    # Basic usage
    stream = io.StringIO('foo: bar\n')
    data = AnsibleLoader(stream, file_name='<string>').get_single_data()
    assert (data['foo'] == 'bar')

    # Error handling
    stream = io.StringIO('foo\n  bar\n')

# Generated at 2022-06-20 23:53:43.676394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\n- hosts: localhost'
    file_name = 'test_file'
    vault_secrets = 'test_secrets'
    loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert loader.stream == stream
    assert loader.vault_secrets == vault_secrets

# Generated at 2022-06-20 23:53:53.792623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    sys.path.append(os.path.dirname(__file__) + "/../..")
    from ansible.utils.vars import combine_vars
    yaml_str = """
  # comments
-   hosts:
  -   s1
  -   s2
  gather_facts: True
  tasks:
  -   name: ping
      ping:
"""
    loader = AnsibleLoader(yaml_str)
    yaml_data = loader.get_single_data()
    assert yaml_data == {'tasks': [{'ping': None, 'name': 'ping'}], 'hosts': ['s1', 's2'], 'gather_facts': True}


# Generated at 2022-06-20 23:54:05.120938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import get_yaml_loader

    class MyAnsibleLoader(AnsibleLoader):
        def __init__(self):
              super(MyAnsibleLoader, self).__init__(
                  "<string>",
                  vault_secrets=None
              )

        def construct_mapping(self, node, deep=False):
            return self.construct_ansible_mapping(node, deep)

        def construct_sequence(self, node, deep=False):
            return self.construct_ansible_sequence(node, deep)

    # test the parsing of lists

# Generated at 2022-06-20 23:54:10.319144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Loader construction
    loader = AnsibleLoader('{ a: 1 }')
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)
    # Loading
    doc = loader.get_single_data()
    assert isinstance(doc, dict)
    assert 'a' in doc
    assert doc['a'] == 1

# Generated at 2022-06-20 23:54:23.437310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)


# Generated at 2022-06-20 23:54:33.999314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    if sys.version_info >= (2, 7):
        from StringIO import StringIO
    else:
        from io import StringIO

    stream = StringIO(u'---\n- hosts: all')
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), list)

    stream = StringIO('---\n- hosts: all')
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), list)

    stream = StringIO('#!/usr/bin/ansible-playbook\n- hosts: all')
    loader = AnsibleLoader(stream)
    assert isinstance

# Generated at 2022-06-20 23:54:35.911893
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader


# Generated at 2022-06-20 23:54:47.339868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    if HAS_LIBYAML:
        import yaml
        # Generate a data structure (dict)
        data = {'a': 'ok', 'nested': {'b': 'good'}, 'list': [1,2,3]}
        # Generate the corresponding YAML code
        yaml_code = yaml.dump(data, default_flow_style=False)
        # Create a AnsibleLoader instead of a loader
        loader = AnsibleLoader(yaml_code)
        # Check if it is a AnsibleLoader
        assert isinstance(loader, AnsibleLoader) == True
        # Check if the constructor is callable
        assert callable(loader) == True


# Generated at 2022-06-20 23:54:56.886898
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml import objects

    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(''), objects.AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(''), ansible_unicode)

    vault_secrets = ['dummyvaultsecrets']
    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    assert isinstance(loader.construct_yaml_str(''), AnsibleVaultEncryptedUnicode)
    assert isinstance(loader.construct_yaml_str(''), ansible_unicode)



# Generated at 2022-06-20 23:54:58.770288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-20 23:55:01.684027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    loader = AnsibleLoader(yaml.load(''), None, None)
    assert(loader is not None)
    assert(isinstance(loader, AnsibleLoader))

# Generated at 2022-06-20 23:55:03.417923
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load('foo: bar')

# Generated at 2022-06-20 23:55:14.037105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys

    class StubFileName(object):
        def __init__(self, path):
            self.path = path
        def __str__(self):
            return '/foo/bar/' + self.path

    if sys.version_info[0] == 2:
        # Test date representation
        s = "date: 2013-06-07\n"
        data = AnsibleLoader(s, StubFileName('datetime')).get_single_data()
        assert type(data['date']) is datetime.date

        # Test datetime representation
        s = "datetime: 2013-06-07 10:02:00\n"


# Generated at 2022-06-20 23:55:19.899306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    test_file_name = "test_AnsibleLoader"
    test_vault_secret = VaultLib("test_AnsibleLoader")

    test_loader = AnsibleLoader('key: 1', file_name=test_file_name, vault_secrets=test_vault_secret)
    assert(test_loader.file_name == test_file_name)
    assert(test_loader.vault_secrets == test_vault_secret)

# Generated at 2022-06-20 23:55:44.221569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    test_AnsibleLoader: unit test for class AnsibleLoader
    '''
    stream = None
    file_name = 'test_file_name'
    vault_secrets = None
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert loader.file_name == file_name
    assert loader.vault_secrets == vault_secrets

# Generated at 2022-06-20 23:55:55.547164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import io
    import yaml

    vault = VaultLib(['--vault-password-file', 'test/ansible_vault.passwd'])

# Generated at 2022-06-20 23:56:00.423993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This is to test if the 'from' keyword in yaml files will be tried to load as python modules
    # If the test loads a real from module, it will segfault
    loader = AnsibleLoader(u'from: bad_from')
    try:
        loader.get_single_data()
    except Exception as e:
        assert isinstance(e, Exception) is True

# Generated at 2022-06-20 23:56:01.942294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=star-args
    assert AnsibleLoader('test')

# Generated at 2022-06-20 23:56:08.685042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # We don't check if the constructor is working with libyaml
    # because there nothing is called as AnsibleConstructor is
    # just a passive class.

    # We don't use yaml.load() to test the constructor due to
    # a bug in PyYaml < 5.1

    class Foo(AnsibleBaseYAMLObject):
        yaml_tag = u'!foo'


# Generated at 2022-06-20 23:56:18.067696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    # Use the current directory to load files
    current_dir = os.path.dirname(os.path.realpath(__file__))
    yaml_file = os.path.join(current_dir, '../../../lib/ansible/module_utils/facts/system/distribution.fact')
    with open(yaml_file) as y_stream:
        myloader = AnsibleLoader(y_stream, file_name=yaml_file, vault_secrets=None)
        myloader.get_single_data()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:56:26.619851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(''), str)
    assert isinstance(loader.construct_yaml_str('a'), str)
    assert isinstance(loader.construct_yaml_str('0'), str)
    assert isinstance(loader.construct_yaml_str('false'), str)
    assert isinstance(loader.construct_yaml_str('null'), str)
    assert isinstance(loader.construct_yaml_str('foo: bar'), dict)
    assert isinstance(loader.construct_yaml_str('- foo\n- bar'), list)

# Generated at 2022-06-20 23:56:28.064269
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This doesn't test the class constructor (yet).
    """

    assert True

# Generated at 2022-06-20 23:56:39.299058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    vault_password = '$ANSIBLE_VAULT;1.1;AES256\n363330346439343664356638643666336435303661353765626237323861353462353738353332\n363738616166626633333263356131613333653839653365363236383065363633303933633338\n3932343932396366663565303733626237613439\n'

    # Test constructor
    loader = AnsibleLoader('hello: world')
    assert loader.stream is not None

    # Test _construct_mapping
    construct_mapping = loader._construct_mapping

# Generated at 2022-06-20 23:56:47.544950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import text_type

    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Parser)

    data = """
    foo: bar
    baz: qux

    """
    stream = AnsibleUnicode(text_type(data))
    loader = AnsibleLoader(stream)
    foo = loader.get_single_data()
    assert foo == {'foo': 'bar', 'baz': 'qux'}

# Generated at 2022-06-20 23:57:28.464327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    AnsibleLoader({'a':0})

# Generated at 2022-06-20 23:57:31.007376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """\
- hosts: all
  gather_facts: no
"""
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-20 23:57:41.899326
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import load, dump
    import sys
    import StringIO
    # fake stdout for testing purpose
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()

    # test with_items
    with_items = """
    ---
    - name: test with_items
      action: command /bin/foo
      with_items:
        - foo
        - bar
        - baz
    """
    data = load(with_items, AnsibleLoader)
    assert data == [{'action': {'__ansible_arguments__': ['/bin/foo']}, 'name': 'test with_items', 'with_items': ['foo', 'bar', 'baz']}]

    # test with_items

# Generated at 2022-06-20 23:57:43.535134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.vault_secrets is None

# Generated at 2022-06-20 23:57:52.329633
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml.representer import Representer
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    class TestLoader(AnsibleLoader):
        pass

    class TestRepresenter(Representer):

        def represent_AnsibleSequence(self, data):
            return self.represent_list(data.get_wrapped_list())

        def represent_AnsibleMapping(self, data):
            return self.represent_dict(data.get_wrapped_mapping())


# Generated at 2022-06-20 23:57:54.707042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  pass
  


# Generated at 2022-06-20 23:58:02.589148
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
foo:
  - {baz: oof, # comment
      bam: a,
      # more comment
      bar: b,}
  - {baz: oof, bam: a, bar: b,}
'''
    ans_obj = AnsibleLoader(yaml_str)
    assert ans_obj.get_single_data() == {'foo': [{'baz': 'oof', 'bam': 'a', 'bar': 'b'}, {'baz': 'oof', 'bam': 'a', 'bar': 'b'}]}

# Generated at 2022-06-20 23:58:03.232564
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:58:12.337751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import six
    if six.PY3:
        from io import StringIO
        if sys.version_info[1] >= 5:
            from io import BytesIO
        else:
            BytesIO = StringIO
        from ansible.parsing.yaml import AnsibleLoader
        from ansible.module_utils.common.yaml import HAS_LIBYAML
    else:
        from cStringIO import StringIO
        from ansible.parsing.yaml import AnsibleLoader
        from ansible.module_utils.common.yaml import HAS_LIBYAML


# Generated at 2022-06-20 23:58:19.628628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.playbook.play_context import PlayContext

    class FakeVaultSecret(VaultLib):
        def __init__(self):
            self.secrets = []

        def reset(self):
            self.secrets = []

        def encrypt(self, value, _preferred_token=None):
            return_val = 'VaultEncrypt(' + str(len(self.secrets)) + '):' + value
            self.secrets.append(VaultSecret(return_val, True, {'key': 'value'}))
            return return_val

    class FakePlayContext(PlayContext):
        def __init__(self):
            self.become_pass = 'password'



# Generated at 2022-06-20 23:59:51.358356
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    stream = """
    foo:
      - 1
      - 2
    """

    loader = AnsibleLoader(stream, None)

    data = loader.get_single_data()
    assert data == {'foo': [1, 2]}


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:59:53.739372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-20 23:59:54.487782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-21 00:00:04.925119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test the ability of the class to load boolean values
    # Format of the input data
    boolean_data = '''
unknown:
- yes
- True
- true
- 1
- on
- no
- False
- false
- 0
- off
    '''
    # Expected output
    boolean_values = [ True, True, True, True, True,
        False, False, False, False, False ]
    # Create an AnsibleLoader object and load the input data
    loader = AnsibleLoader(boolean_data, vault_secrets=[])
    boolean_output = loader.get_single_data()
    # Check if the output is as expected
    assert isinstance(boolean_output, dict)
    assert boolean_output.get('unknown') == boolean_values
    print('Success')

# Generated at 2022-06-21 00:00:12.964280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    # Needs to import module_utils to initialize AnsibleLoader
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    example_data = """
- name: localhost
  hosts: localhost
  gather_facts: no
  tasks:
    - name: Setup vars
      set_fact:
        var: value
    - name: Setup vars2
      set_fact:
        var2: value2"""

    module_args = dict()

    # Create a AnsibleModule to be use to initialize AnsibleLoader
    am = AnsibleModule(argument_spec=module_args)

    # Create AnsibleLoader, so we can test all its methods

# Generated at 2022-06-21 00:00:13.590771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-21 00:00:14.424121
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-21 00:00:16.579252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    a: foo
    b: 123
    '''
    assert data == AnsibleLoader(data).get_single_data()

# Generated at 2022-06-21 00:00:27.220486
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    for yaml_string in (
            '- 1.2',
            '- !!float 1.2',
            '- !!float 1.2foo',
            '- !!float 1.2.3',
            '- 1.2.3'):
        print(yaml_string)
        try:
            AnsibleLoader(yaml_string).get_single_data()
        except Exception as e:
            print(e)
        print()
    print('1.2 ==', AnsibleLoader('1.2').get_single_data())
    print('1.2 ==', AnsibleLoader('1.2foo').get_single_data())
    #print('1.2.3 ==', AnsibleLoader('1.2.3').get_single_data())

# Generated at 2022-06-21 00:00:33.755467
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Tests if AnsibleLoader is a subclass of the correct classes
    """

    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)
    else:
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Composer)
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)