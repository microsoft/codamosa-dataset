

# Generated at 2022-06-20 23:50:47.850835
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the AnsibleLoader class for the deprecated ansible.utils.loader.__init__.py
    """
    assert False, "TODO"

# Generated at 2022-06-20 23:50:57.505941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    def load_file(filename):
        with open(filename, 'r') as f:
            try:
                data = AnsibleLoader(f).get_single_data()
            except Exception as e:
                print(e)

    test_files_dir = os.path.join(os.path.dirname(__file__), 'yaml_tests')
    for root, _, filenames in os.walk(test_files_dir):
        for filename in filenames:
            path = os.path.join(root, filename)
            try:
                load_file(path)
            except Exception as e:
                print('Failed to parse: %s' % path)
                raise e

if __name__ == "__main__":
    import sys
    import getopt


# Generated at 2022-06-20 23:51:08.655639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This test requires libyaml to be loaded and you should use an Ansible-style 
    vault to generate a vault password file.
    """
    test_string = """
vars:
  dict1:
    key: value
  list1:
    - item1
    - item2
  str1: foobar
hosts:
  - localhost
"""
    ansible_loader = AnsibleLoader(test_string, vault_secrets={"vault_password_file": "vault_password"})
    loaded_data = ansible_loader.get_single_data()
    assert loaded_data == {"vars": {"dict1": {"key": "value"}, "list1": ["item1", "item2"], "str1": "foobar"}, "hosts": ["localhost"]}

# Generated at 2022-06-20 23:51:12.243901
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os.path

    dummy_file = os.path.join(os.path.dirname(__file__), 'loader_dummy_file.yml')
    loader = AnsibleLoader(open(dummy_file,'rb').read())
    loader.get_single_data()

# Generated at 2022-06-20 23:51:23.445473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    sys.modules['__main__'].__file__ = 'test_ansible_loader.yml'
    yaml_loader = AnsibleLoader(open('../../../test/units/parsing/yaml/loader/test_ansible_loader.yml', 'r'))


# Generated at 2022-06-20 23:51:30.789053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #empty stream
    stream = ""
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.file_name == None
    assert ansible_loader.vault_secrets == None
    assert ansible_loader.parser == None
    assert ansible_loader.composer == None
    assert ansible_loader.constructor == None
    assert ansible_loader.resolver == None
    assert ansible_loader.flatten_mapping == None

# Generated at 2022-06-20 23:51:43.160833
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    d = dict(key='value')
    yaml = """
    key: value
    """
    assert AnsibleLoader(yaml).get_single_data() == d

    yaml = """
    ---
    key: value
    """
    assert AnsibleLoader(yaml).get_single_data() == d

    yaml = """
    ---
    - key: value
    """
    assert AnsibleLoader(yaml).get_single_data() == [d]

    yaml = """
    ---
    foo: &foo
      key: value
    bar: *foo
    """
    assert AnsibleLoader(yaml).get_single_data() == dict(foo=dict(key='value'), bar=dict(key='value'))

   

# Generated at 2022-06-20 23:51:50.794892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode

    (fd, fn) = tempfile.mkstemp()

    data = {u'unicode_key': u'unicode_value',
           u'unicode_key2': AnsibleUnicode(u'unicode_value'),
           u'byte_key': b'byte_value',
           u'integer_key': 42,
           u'float_key': 4.2,
           u'boolean_key': True,
           u'none_key': None,
           u'list_key': [u'unicode_value', b'byte_value', 42, 4.2, True, None]
          }


# Generated at 2022-06-20 23:52:02.568425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    stream=StringIO("""---
- name: test play
  hosts: all
  vars:
    a: b
  tasks:
  - name: ping
    ping:
    remote_user: ansible
    become: true
    become_user: root
    become_method: su
    register: result
  - debug:
      var: result
""")
    loader = AnsibleLoader(stream, vault_secrets=dict())
    result = [x for x in loader]

# Generated at 2022-06-20 23:52:12.259610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test custom scalars

    # datetime
    data = AnsibleLoader(None, None).construct_yaml_timestamp(DateTime=None, value="2000-01-01 00:01:02.345Z")
    assert data == datetime(2000, 1, 1, 0, 1, 2, 345)
    data = AnsibleLoader(None, None).construct_yaml_timestamp(DateTime=None, value="2000-01-01 00:01:02Z")
    assert data == datetime(2000, 1, 1, 0, 1, 2)
    data = AnsibleLoader(None, None).construct_yaml_timestamp(DateTime=None, value="2000-01-01 00:01:02Z")
    assert data == datetime(2000, 1, 1, 0, 1, 2)
    data = AnsibleLoader

# Generated at 2022-06-20 23:52:16.492675
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' AnsibleLoader.__init__ '''

    # Test with missing stream parameter
    try:
        loader = AnsibleLoader(None)
        assert False
    except TypeError:
        assert True

    # Test with invalid stream parameter
    try:
        loader = AnsibleLoader(123)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-20 23:52:18.192210
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, 'file_name')
    assert hasattr(loader, 'vault_secrets')

# Generated at 2022-06-20 23:52:20.283532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert HAS_LIBYAML, "libyaml is required to run tests"
    loader = AnsibleLoader(None)

    assert loader is not None

# Generated at 2022-06-20 23:52:27.949070
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-20 23:52:36.557822
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import yaml
    except ImportError:
        raise AssertionError("Unable to import yaml.")

    data = '''
    ---
    foo: "!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          [......]\n          "
    '''

    loader = AnsibleLoader(data, vault_secrets={'vault_key': 'secret'})
    loader.get_single_data()

    # We should not be able to decrypt with a wrong vault key
    loader = AnsibleLoader(data, vault_secrets={'vault_key': 'wrong'})
    try:
        loader.get_single_data()
    except yaml.constructor.ConstructorError as e:
        if "Decryption failed" not in e.problem:
            raise

# Generated at 2022-06-20 23:52:48.406942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    DATA = """
    ---
    - hosts: localhost
      tasks:
      - debug:
          msg: hello world
    """

    (fd, path) = tempfile.mkstemp(suffix='.yaml')
    fp = os.fdopen(fd, 'w+')
    fp.write(DATA)
    fp.close()

    (fd, vault_path) = tempfile.mkstemp(suffix='.yaml')
    fp = os.fdopen(fd, 'w+')

# Generated at 2022-06-20 23:52:59.688787
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:53:03.596218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml as yaml
    import io
    import sys
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        yaml_input="""---
- hosts: all
  gather_facts: yes
  tasks:
  - name: test
    ping:
    tags:
    - test
    with_items:
      - item: test
"""
        def setUp(self):
            self.ansible_loader = yaml.AnsibleLoader(io.StringIO(self.yaml_input))

        def test_attributes(self):
            self.assertEqual(isinstance(self.ansible_loader.stream, io.StringIO), True)


# Generated at 2022-06-20 23:53:11.535224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    vault_secrets = dict(vault_password_file='foo.txt')

# Generated at 2022-06-20 23:53:23.043313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader

    input_data = """
---
a: 1
b:
  - 2
  - 3
c: "4"
"""

    yaml_loader = DataLoader()
    parsed = yaml_loader.load(input_data)
    assert parsed == {u'a': 1, u'b': [2, 3], u'c': to_bytes("4")}

    input_data = """
---
a: "\\x3f"
"""
    parsed = yaml_loader.load(input_data)
    assert parsed == {u'a': to_bytes("?")}


# Generated at 2022-06-20 23:53:26.777568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:53:32.522621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = '''
foo:
- {x: 1}
- {x: 2}
- {x: 3}
'''

    data = AnsibleLoader(stream).get_single_data()
    assert data['foo'][0]['x'] == 1

    data = AnsibleLoader(stream).get_single_data()
    assert data['foo'][2]['x'] == 3

    data = AnsibleLoader(stream).get_single_data()
    assert data['foo'][2]['x'] == 3

# Generated at 2022-06-20 23:53:33.004923
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:38.354300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    If HAS_LIBYAML is True, every method is called from the parent class.
    If HAS_LIBYAML is False, every method from Parser is called from the parent class.
    """
    loader = AnsibleLoader('test string')
    assert loader.get_single_data() == 'test string'

# Generated at 2022-06-20 23:53:49.786305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This tests the ansibleLoader class
    '''
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json

    # Test for empty variables
    assert AnsibleLoader("").get_single_data() == None
    assert AnsibleLoader(" ").get_single_data() == None

    # Test against empty list
    assert AnsibleLoader("[]").get_single_data() == []

    # Test against empty dictionary
    assert AnsibleLoader('{}').get_single_data() == {}

    # Test against a simple string
    assert AnsibleLoader('"simple string"').get_single_data() == 'simple string'

    #

# Generated at 2022-06-20 23:53:54.065209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    ansible_loader = AnsibleLoader(None, None, None)
    assert ansible_loader.vault_secrets is None

    ansible_loader = AnsibleLoader(None, None, VaultLib())
    assert ansible_loader.vault_secrets is not None

# Generated at 2022-06-20 23:54:05.310090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals
    import io
    import unittest

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import Answers
    from ansible.parsing.vault import VaultEditor


# Generated at 2022-06-20 23:54:16.875495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
- hosts: all
  remote_user: root
  tasks:
    - name: test
      lineinfile:
        dest: /tmp/test.yml
        state: touch
        regexp: "^test: "
        line: "test: 1"
    - name: test
      lineinfile:
        dest: /tmp/test.yml
        state: touch
        regexp: "^test: "
        line: "test: 1"
'''
    loader = AnsibleLoader(data, vault_secrets=None, file_name=None)
    loader.index = 2
    loader._reader.index = 0
    assert loader._reader.get_mark() == (None, 1, 2)
    assert loader.get_mark() == (None, 1, 3)

# Generated at 2022-06-20 23:54:19.768090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Passing None here is not sensitive.
    assert(AnsibleLoader(None) is not None)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:54:20.782037
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:54:35.366844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test constructor
    '''

    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleUnicode

    if HAS_LIBYAML:
        from ansible.parsing.yaml import Parser
        class AnsibleLoader(Parser, AnsibleConstructor):
            def __init__(self, stream, file_name=None, vault_secrets=None):
                Parser.__init__(self, stream)
                AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
    else:
        from yaml import Reader, Scanner, Parser, Composer

# Generated at 2022-06-20 23:54:45.844046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Ansible class
    loader = AnsibleLoader('a: true')
    assert loader.get_data() == dict(a=True)
    loader = AnsibleLoader('a: {{b}}')
    assert loader.get_data() == dict(a='{{b}}')

    # Constructor class
    loader = AnsibleLoader('a: !!str foo', vault_secrets=dict(a=dict(c='!!str bar')))
    assert loader.get_data() == dict(a='{{c}}')

    # Reader class
    loader = AnsibleLoader('a: b')
    assert loader.peek() == 'a'

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:54:49.023079
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    ansible_loader = AnsibleLoader(file_name='test_file_name')
    assert ansible_loader.file_name == 'test_file_name'

# Generated at 2022-06-20 23:54:56.609568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader():
        def __init__(self, stream, file_name, vault_secrets):
            self.stream = stream
            self.file_name = file_name
            self.vault_secrets = vault_secrets

    yaml_parser = TestAnsibleLoader('001', 'test_file.yml', 'test_vault')
    assert(yaml_parser.stream == '001')
    assert(yaml_parser.file_name == 'test_file.yml')
    assert(yaml_parser.vault_secrets == 'test_vault')

# Generated at 2022-06-20 23:54:57.643472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-20 23:55:03.151660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file_content = """
    - hosts: localhost
    """
    test_file = open('test_AnsibleLoader.yml', 'w')
    test_file.write(test_file_content)
    test_file.close()
    test_file = open('test_AnsibleLoader.yml', 'r')
    AnsibleLoader(test_file)


# Generated at 2022-06-20 23:55:13.796573
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():   # pylint: disable=invalid-name
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    obj1 = AnsibleMapping()
    obj2 = AnsibleSequence()
    obj1['hosts'] = 'all'
    obj2.append('ping')
    obj1['tasks'] = obj2
    obj1.fa = 10

    print("\n---")
    print("Should get a dictionary not a class:" + str(type(obj1)))
    print("Foo is not in the object:" + str('foo' in obj1))
    print("`tasks` is in the object:" + str('tasks' in obj1))

# Generated at 2022-06-20 23:55:22.338794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.vars.unsafe_proxy import wrap_var

    stream = io.StringIO("foo: bar")
    loader = AnsibleLoader(stream)
    assert(isinstance(loader, AnsibleLoader))
    assert(isinstance(loader, Parser))
    assert(isinstance(loader, AnsibleConstructor))
    assert(isinstance(loader, Resolver))


# Generated at 2022-06-20 23:55:27.950597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj1 = AnsibleLoader(None)
    obj2 = AnsibleLoader(None, '/some/file')
    assert not obj1.file_name
    assert obj2.file_name == '/some/file'
    obj3 = AnsibleLoader(None, '/other/file')
    assert obj3.file_name == '/other/file'

# Generated at 2022-06-20 23:55:29.736451
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-20 23:55:42.549117
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_content = '''
    invalid: 123
    valid: abc
    float: 12.3
    '''
    ansible_loader = AnsibleLoader(yaml_content)
    assert ansible_loader.get_single_data() == {'invalid': 123, 'valid': u'abc', 'float': 12.3}

# Generated at 2022-06-20 23:55:53.779218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    ---
    obj:
      - key: value
      - key: value
    '''
    data_loaded = AnsibleLoader(data).get_single_data()
    assert data_loaded['obj'][0] == { u'key': u'value' }
    assert data_loaded['obj'][1] == { u'key': u'value' }

    data = '''
    block: |
        hello
        world
    '''
    data_loaded = AnsibleLoader(data).get_single_data()
    assert data_loaded['block'] == u'hello\nworld\n'

    data = """
    block: |
      { "key": "hello" }
    """
    data_loaded = AnsibleLoader(data).get_single_data()

# Generated at 2022-06-20 23:55:55.371997
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)


# Generated at 2022-06-20 23:56:01.232002
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(u'3')
    assert loader.get_single_data() == 3

    stream = u'foo: [bar, {a: b}, [{b: [1, 2]}]]'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {u'foo': [u'bar', {u'a': u'b'}, [{u'b': [1, 2]}]]}

# Generated at 2022-06-20 23:56:08.305428
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    from ansible.module_utils.common.yaml import HAS_LIBYAML

    for vault_password in ('vault password', None):
        for file_data in (
                'string: $ANSIBLE_VAULT;',
                '---\nval: $ANSIBLE_VAULT;',
                '---\nval: !vault |\n          $ANSIBLE_VAULT;',
                '---\nval:\n    nested: $ANSIBLE_VAULT;',
        ):
            file_data_text = file_data

# Generated at 2022-06-20 23:56:10.833046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This should fail when construction is completed
    assert AnsibleLoader

# Generated at 2022-06-20 23:56:11.993029
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:56:23.325899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    stream = '["one", "two", "three", "four"]'
    ansible_loader = AnsibleLoader(stream)
    data = ansible_loader.get_single_data()
    assert isinstance(data[0], AnsibleUnsafeText)
    assert data[0] == "one"
    assert isinstance(data[1], AnsibleUnsafeText)
    assert data[1] == "two"
    assert isinstance(data[2], AnsibleUnsafeText)
    assert data[2] == "three"
    assert isinstance(data[3], AnsibleUnsafeText)
    assert data[3] == "four"


# Generated at 2022-06-20 23:56:27.349475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
        ---
        - hosts: all
          tasks:
            - action: echo hey
              register: result
              changed_when: false
        """
    loader = AnsibleLoader(data)
    print(list(loader))

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:56:37.699092
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:57:01.420319
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert isinstance(AnsibleLoader(''), AnsibleLoader)
    # no longer testing for actual result, just that non-ascii data makes it out the other end
    assert AnsibleLoader(u'').get_single_data()
    assert AnsibleLoader('---\u2022').get_single_data()
    assert AnsibleLoader(u'---\u2022').get_single_data()

# Generated at 2022-06-20 23:57:10.771016
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.vars import BaseVarsPlugin

    class DummyVarsPlugin(BaseVarsPlugin):
        NAME = 'dummy'
        def get_vars(self, loader, path, entities):
            return entities

    vault_pass = 'secret'
    v = VaultLib(vault_pass)
    loader = AnsibleLoader(None)
    loader.vault = v

# Generated at 2022-06-20 23:57:21.422635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.plugins.loader import find_plugin

    a = AnsibleLoader(None, vault_secrets=None)
    a.set_file_name("foo")

    assert a._file_name == "foo"

    # test that the constructor doesn't overwrite the file_name
    b = AnsibleLoader(None, vault_secrets=None)
    b.set_file_name("bar")
    assert a._file_name == "foo"
    assert b._file_name == "bar"

    # test YAML aliases in role dependencies:

# Generated at 2022-06-20 23:57:27.332684
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''{foo: bar}'''
    stream_data = AnsibleLoader(stream).get_single_data()
    assert isinstance(stream_data, dict), 'This should be a dictionary.'
    assert stream_data['foo'] == 'bar', 'This should be bar.'
    file_data = AnsibleLoader(filename='tests/yaml_loader/constructor_yaml_loader.yml').get_single_data()
    assert isinstance(file_data, dict), 'This should be a dictionary.'
    assert file_data['foo'] == 'bar', 'This should be bar.'


# Generated at 2022-06-20 23:57:28.109000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:57:32.113626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Check that class AnsibleLoader constructor is called correctly
    """
    assert AnsibleLoader.__init__.__name__ == '__init__'
    assert AnsibleLoader.__init__.__doc__ == 'Constructs an instance of the Python YAML Loader (AnsibleOverride)'

# Generated at 2022-06-20 23:57:43.357876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import parse_vault_password_file

    vault_pass = parse_vault_password_file('/tmp/test')


# Generated at 2022-06-20 23:57:44.941612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    t = AnsibleLoader(None)
    assert isinstance(t, AnsibleLoader)

# Generated at 2022-06-20 23:57:50.270816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO()
    stream.write('---\n')
    stream.write('- set_fact:\n')
    stream.write('    project: MyProject\n')
    stream.write('    load_file: "{{ playbook_dir }}/file.yml"\n')
    stream.write('- include: t.yml\n')
    stream.seek(0)
    AnsibleLoader(stream)

# Generated at 2022-06-20 23:57:51.882462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)  # pylint: disable=no-value-for-parameter,unexpected-keyword-arg
    assert loader

# Generated at 2022-06-20 23:58:36.844007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(file_name='test_file')
    assert x

# Generated at 2022-06-20 23:58:46.768786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, 'construct_yaml_map')
    assert hasattr(AnsibleLoader, 'construct_yaml_str')
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert hasattr(AnsibleLoader, 'construct_yaml_int')
    assert hasattr(AnsibleLoader, 'construct_yaml_bool')
    assert hasattr(AnsibleLoader, 'construct_yaml_binary')
    assert hasattr(AnsibleLoader, 'construct_yaml_float')
    assert hasattr(AnsibleLoader, 'construct_yaml_omap')
    assert hasattr(AnsibleLoader, 'construct_yaml_pairs')

# Generated at 2022-06-20 23:58:47.631993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-20 23:58:48.397937
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None).get_single_data()
    assert(data == {})

# Generated at 2022-06-20 23:58:54.809412
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    yaml_str = """
    - hosts: localhost
      gather_facts: False
      tasks:
      - name: task 1
        command: /bin/true
        changed_when: False
        register: task1_result
      - name: task 2
        command: /bin/true
        changed_when: False
        register: task2_result
      - name: task 3
        command: /bin/true
        changed_when: False
        register: task3_result
      - debug: msg='{{ task1_result.stdout }} | {{ task2_result.stdout }} | {{ task3_result.stdout }}'
    """

    obj = AnsibleLoader(yaml_str)
    data = obj.get_single_data()


# Generated at 2022-06-20 23:58:55.378502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:58:56.618864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader()

# Generated at 2022-06-20 23:59:07.137848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    def my_constructor(loader, node):
        return node.value

    def my_re_constructor(loader, node):
        return loader.construct_yaml_str(node)

    def my_data_re_constructor(loader, node):
        return loader.construct_yaml_str(node)

    def my_multi_re_constructor(loader, node):
        return loader.construct_yaml_str(node)

    def my_reduce(loader, node):
        return AnsibleBaseYAMLObject(loader, node)

    def my_multi_re_constructor_debug(loader, node):
        return loader.construct_yaml

# Generated at 2022-06-20 23:59:14.322327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.utils.vars import combine_vars

    data = {
        'a': 'foo',
        'b': [1, 2, 3, 4],
        'c': {
            'd': {'e': 'f'},
        }
    }
    vault_secrets = {'_ansible_vault_password': None}

    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
    d = loader.construct_document(data)
    assert isinstance(d, AnsibleMapping)
    assert isinstance(d['a'], AnsibleUnicode)
    assert isinstance(d['b'], AnsibleSequence)

# Generated at 2022-06-20 23:59:24.615673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(u'{ foo: 1 }', file_name="foo")
    data = loader.get_single_data()
    assert data.get('foo') == 1

    loader = AnsibleLoader(u'[ foo, bar ]', file_name="bar")
    data = loader.get_single_data()
    assert data == [u'foo', u'bar']

    loader = AnsibleLoader(u'foo: !!null "null"\nbar: null', file_name="baz")
    data = loader.get_single_data()
    assert data.get('foo') == 'null'
    assert data.get('bar') == None

    loader = AnsibleLoader(u'foo: bar', file_name="biz")
    data = loader.get_single_data()
    assert data.get('foo')

# Generated at 2022-06-21 00:00:44.619098
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = '---\n- {foo: bar}'

    # Class AnsibleLoader requires vault_secrets to be set.
    # A ValueError exception will occur if it is not set.
    loader = AnsibleLoader(stream)
    try:
        loader.get_single_data()
    except ValueError as e:
        assert(e.args[0] == "Vault secrets are required when using the AnsibleLoader class")