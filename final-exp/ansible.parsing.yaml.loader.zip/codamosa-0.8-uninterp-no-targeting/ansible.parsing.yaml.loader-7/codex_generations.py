

# Generated at 2022-06-20 23:50:53.365416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import string_types

    # Test the constructor
    yaml_str = u"---\nkey: value"

    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data['key'], AnsibleUnicode)
    assert data['key'] == u'value'

# Generated at 2022-06-20 23:50:56.212264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' class AnsibleLoader unit test'''
    for Constructor in [AnsibleLoader]:
        obj = Constructor(stream=None)
        assert obj is not None

# Generated at 2022-06-20 23:51:00.748685
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream=None)
    assert ansible_loader.load_all() is None
    assert ansible_loader.load(None) is None


# if __name__ == '__main__':
#     test_AnsibleLoader()

# Generated at 2022-06-20 23:51:03.524544
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test if constructor is loaded
    assert AnsibleLoader
    # test if constructor returns a class AnsibleLoader
    assert isinstance(AnsibleLoader(None), AnsibleLoader)

# Generated at 2022-06-20 23:51:07.796555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import _construct_mapping
    # _construct_mapping has to be initialized before we construct a new AnsibleLoader
    _construct_mapping()
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:51:18.084043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    AnsibleLoader(StringIO(""))
    AnsibleLoader(StringIO("hey"))
    AnsibleLoader(StringIO("[]"))
    AnsibleLoader(StringIO("{}"))
    AnsibleLoader(StringIO("{'a': 1}"))
    AnsibleLoader(StringIO("{'a': 1, 'b': 2}"))

    try:
        # AnsibleLoader(StringIO("'a': 1"))
        AnsibleLoader(StringIO("a: 1"))
    except AnsibleParserError:
        pass
    else:
        raise AssertionError("AnsibleLoader allowed to serialize a dict without a key")

    # Now test the vault

# Generated at 2022-06-20 23:51:18.636075
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:51:25.502363
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from yaml.constructor import Constructor
    from yaml.parser import Parser
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from ansible.parsing.yaml.loader import AnsibleLoader

    s = '---\n- hosts: foo\n\n  tasks:\n  - action: ping\n\n'
    stream = s.split('\n')
    file_name = 'foo.yaml'
    loader = AnsibleLoader(stream, file_name)
    assert type(loader) is AnsibleLoader
    assert type(loader) is Parser
    assert type(loader) is Reader
    assert type(loader) is Scanner
    assert type(loader) is Constructor
    assert type

# Generated at 2022-06-20 23:51:32.908006
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('1')
    # We will use the python repr() function to print all attributes of the
    # class AnsibleLoader
    data = dict(y=dict(a='b'), x=dict(c='d'))
    loader = AnsibleLoader(data, "/tmp/file.yml")

    for attr in dir(loader):
        if attr[0] != '_':
            print("loader.{0} = {1}".format(attr, repr(getattr(loader, attr))))


# Generated at 2022-06-20 23:51:34.196153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

# Generated at 2022-06-20 23:51:42.957691
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader('test.yml', vault_secrets=[])
    assert x.yaml_constructor is not None
    assert x.file_name == 'test.yml'
    assert x.stream == 'test.yml'

if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-20 23:51:48.425947
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    obj = AnsibleLoader(None, file_name=None)
    assert obj.vault_secrets == None
    assert obj.file_name == None
    assert obj.stream == None
    obj = AnsibleLoader(None, file_name="foo")
    assert obj.vault_secrets == None
    assert obj.file_name == "foo"
    assert obj.stream == None

# Generated at 2022-06-20 23:51:58.763388
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
all:
  vars:
    var1: Hello
    var2: World

tests:
  tasks:
    - name: Print a message
      debug: msg="{{var1}} {{var2}}"
'''
    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['all']['vars']['var1'] == 'Hello'
    assert data['all']['vars']['var2'] == 'World'
    assert data['tests']['tasks'][0]['name'] == 'Print a message'

# Generated at 2022-06-20 23:52:00.177442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('{}')
    assert loader



# Generated at 2022-06-20 23:52:01.520423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)


# Generated at 2022-06-20 23:52:11.482034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing import vault

    # test secret decryption on the fly
    loader = AnsibleLoader('!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3239643435393832623331633634653930333366386236316262616237393361346139613431316236\n          3335663265323663303037663435626662616632333362306331656264373161326133363831663261\n          6362646636613465663164323337',
                            file_name='<string>',
                            vault_secrets=[vault.VaultSecret('incorrectpassword', 0)])
    assert loader.get_single_data() != 'thisisasecret'
   

# Generated at 2022-06-20 23:52:16.101647
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream="[IPV4:Address:1]", file_name="file.yml", vault_secrets=[])
    assert ansible_loader.file_name == "file.yml"
    assert ansible_loader.vault_secrets == []

# Generated at 2022-06-20 23:52:20.907777
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the class constructor ansible.parsing.yaml.loader.AnsibleLoader
    """
    class TestAnsibleLoader(object):
        def __init__(self):
            self.AnsibleLoader = AnsibleLoader

    test = TestAnsibleLoader()

    assert test

# Generated at 2022-06-20 23:52:25.887664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Execute constructor
    loader = AnsibleLoader(b"---\n")

    # Test if the constructor returned an instance of class AnsibleLoader
    assert loader is not None
    assert isinstance(loader, AnsibleLoader)

    # Test if the constructor's superclass is Reader.
    super_class = loader.__class__.__bases__
    assert super_class is not None
    assert isinstance(super_class, tuple)
    assert len(super_class) == 1
    assert Reader in super_class

# Generated at 2022-06-20 23:52:35.366850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    if HAS_LIBYAML:
        from ansible.parsing.yaml.loader import AnsibleLoader
    else:
        from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    test_content = "foo=bar"
    test_password = "test_password"
    test_file = "/tmp/test_AnsibleLoader_file"
    test_vault_id = "test_vault_id"

    if os.path.isfile(test_file):
        os.remove(test_file)


# Generated at 2022-06-20 23:52:45.744978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - name: test
      with_items: |
        1
        2
        3
      register: test
    '''
    loader = AnsibleLoader(stream)
    loader.get_single_data()
    assert loader


# Generated at 2022-06-20 23:52:49.708499
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name="filename", vault_secrets=None)
    assert loader.file_name == "filename"
    assert loader.vault_secrets == []
    assert loader.start_event_key is None


# Generated at 2022-06-20 23:53:00.918902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import ansible.constants as C
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestConstructor(unittest.TestCase):

        def setUp(self):
            self.a = AnsibleLoader(file_name='dummy/foo')
            self.FakeStream = ["---", "foo: bar"]

        def test_init(self):
            self.assertEqual(self.a._file_name, 'dummy/foo')
            self.assertEqual(self.a._vault_secrets, C.DEFAULT_VAULT_SECRETS)
            self.assertFalse(self.a._use_vault)


# Generated at 2022-06-20 23:53:04.339041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=no-self-use
    loader = AnsibleLoader("hi: [1]", file_name='/dev/null')
    assert loader.get_single_data() == {"hi": [1]}

# Generated at 2022-06-20 23:53:11.755286
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b"""
    ---
    - hosts: all
      tasks:
      - name: test with_items
        debug: msg="{{ item }}"
        with_items:
          - foo
          - bar
      - name: test with_items and with_together
        debug: msg="{{ item[0] }}: {{ item[1] }}"
        with_items:
          - ['a', 'b', 'c']
        with_together: True
    """

    class MockVaultSecret(object):
        def __init__(self):
            pass

        def load(self, data):
            return data

    vault_secrets = {'vault_password_file': MockVaultSecret()}

    loader = AnsibleLoader(data, vault_secrets=vault_secrets)
    assert loader.get_single_

# Generated at 2022-06-20 23:53:17.230971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
    - include_tasks: cool.yml
      when: not empty_var
    """

    loader = AnsibleLoader(content)
    results = loader.get_single_data()
    assert results[0]['include_tasks'] == 'cool.yml'
    assert results[0]['when'] == 'not empty_var'

# Generated at 2022-06-20 23:53:18.251693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:53:19.408521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader

# Generated at 2022-06-20 23:53:29.417348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=missing-docstring
    from ansible.parsing.yaml import objects
    from ansible.vars import combine_vars
    from six import text_type

    loader = AnsibleLoader(None)
    assert isinstance(loader.vault_secrets, list)

    data = loader.construct_yaml_map({'__ansible_vars__': ['foo', 'bar'], '__ansible_facts__': {'foo': 'bar'}})
    assert '_ansible_vars' in data
    assert '_ansible_facts' in data

    data = loader.construct_yaml_map({'__ansible_vars__': ['foo'], '__ansible_facts__': {'foo': 'bar'}})

# Generated at 2022-06-20 23:53:33.182005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=invalid-name
    """This is a test of the AnsibleLoader class"""

    ansl = AnsibleLoader('')

    # check if the AnsibleConstructor class is created inside the AnsibleLoader class
    assert ansl.file_name is None
    assert ansl.vault_secrets is None

# Generated at 2022-06-20 23:53:45.291571
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)


# Generated at 2022-06-20 23:53:51.193317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import ansible.parsing.yaml.constructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    import sys
    import operator

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def test_default(self):
            '''
            Ensure Ansible loader calls the base class(es) constructors
            '''

            class TestConstructor(AnsibleConstructor):
                def __init__(self, loaded=None):
                    self.loaded = loaded
                    AnsibleConstructor.__init__(self)

                def construct_yaml_str(self, node):
                    self.loaded = "yaml_str"

# Generated at 2022-06-20 23:53:58.175758
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Import the class and make an instance
    ansible_loader = AnsibleLoader(None, None)

    # Test for duplicate key insertion
    def insert_duplicate_key():
        test_dict = {}  # type: dict[Any, Any]
        ansible_loader.insert_duplicate_key(test_dict)
    try:
        insert_duplicate_key()
    except AttributeError:
        pass
    except Exception:
        assert False, "insert_duplicate_key() raised unexpected exception"
    else:
        assert False, "insert_duplicate_key() did not raise expected AttributeError"

    # Test for construction of a mapping node
    mapping_node = ansible_loader.construct_mapping()

# Generated at 2022-06-20 23:54:00.012536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(stream="Test stream", file_name="Test file", vault_secrets="Test vault_secrets")

# Generated at 2022-06-20 23:54:09.411027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from os import path
    from ansible.utils.vars import combine_vars
    from ansible import constants as C

    data = '''
    ---
    user: foo
    path: /foo/bar
    '''

    filepath = path.join(C.ANSIBLE_TEST_DATA_ROOT, 'file_include.yml')
    fake_filepath = path.join(C.ANSIBLE_TEST_DATA_ROOT, 'fake_file_include.yml')

    # import epdb; epdb.st()
    loader = AnsibleLoader(StringIO(data), file_name=filepath)
    res = next(loader)
    assert res['user'] == 'foo'
    assert res['path'] == '/foo/bar'

# Generated at 2022-06-20 23:54:11.348651
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO()
    loader = AnsibleLoader(stream)
    assert loader is not None, 'loader is None'

# Generated at 2022-06-20 23:54:12.483443
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Placeholder for future unit test
    pass

# Generated at 2022-06-20 23:54:24.924634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.dataloader import DataLoader
    from collections import namedtuple

    # Create a Connection Mock class that can be used by the Paramiko and SSH
    # classes to give these classes a connection to a remote system
    # This class has 2 methods: connect() and exec_command()
    # Also, allow the Connection class to be patched by the Paramiko SSH
    # class so that it can call the Connection classes connect() method
    class ConnectionMock:
        def __init__(self, *args):
            pass
        def connect(self):
            pass
        def exec_command(self, command):
            if command == 'test -x /usr/bin/python':
                out = namedtuple('Foo', 'channel')
                out.channel = named

# Generated at 2022-06-20 23:54:35.090012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import load
    from yaml.constructor import ConstructorError
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    # Basic data types

# Generated at 2022-06-20 23:54:46.620132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test_include(self):
            test_dir = os.path.dirname(os.path.realpath(__file__))
            d1 = tempfile.mkdtemp(prefix='ansible-test')
            d2 = tempfile.mkdtemp(prefix='ansible-test')
            test_file1 = os.path.join(d1, 'include_test1.yml')
            test_file2 = os.path.join(d2, 'include_test2.yml')


# Generated at 2022-06-20 23:55:11.143707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert Loader is not None

# Generated at 2022-06-20 23:55:18.805048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    "Test function for AnsibleLoader class"
    from ansible.module_utils.common.yaml import AnsibleLoader
    from yaml.scanner import ScannerError, Scanner
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicodeType
    # INIT module
    AnsibleLoader
    ScannerError
    Scanner
    AnsibleConstructor
    AnsibleVaultEncryptedUnicode
    AnsibleVaultEncryptedUnicodeType

# AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:55:19.801290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Test AnsibleLoader")

# Generated at 2022-06-20 23:55:22.796216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
    - name: test_object
      class: some.thing.Thing
    """

    d = AnsibleLoader(yaml).get_single_data()

    assert d[0]['name'] == 'test_object'
    assert d[0]['class'] == 'some.thing.Thing'

# Generated at 2022-06-20 23:55:28.834932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''AnsibleLoader can contruct a dictionary out of a yaml file'''
    from io import StringIO
    string_io = StringIO(u'{test_key: test_value}')
    loader = AnsibleLoader(string_io)
    assert(dict(loader.get_single_data()) == {'test_key': 'test_value'})

# Generated at 2022-06-20 23:55:33.656328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_AnsibleLoader = AnsibleLoader(stream='stream', file_name='file_name', vault_secrets='vault_secrets')
    assert isinstance(test_AnsibleLoader, Parser)
    assert isinstance(test_AnsibleLoader, AnsibleConstructor)
    assert isinstance(test_AnsibleLoader, Resolver)

# Generated at 2022-06-20 23:55:43.146009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping

    # Loader should accept string.
    loader = AnsibleLoader('[1, 2, 3]')
    assert loader is not None
    assert isinstance(loader, AnsibleLoader)

    # Loader should accept unicode.
    loader = AnsibleLoader(u'[1, 2, 3]')
    assert loader is not None
    assert isinstance(loader, AnsibleLoader)

    # Loader should also work as a context manager
    with AnsibleLoader('[1, 2, 3]') as loader:
        assert loader is not None

    # Loader should not accept int.

# Generated at 2022-06-20 23:55:48.702959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test object with an empty file_name
    my_loader = AnsibleLoader(file_name='')
    assert my_loader.file_name is None
    # Test object with a file_name containing a path
    my_loader = AnsibleLoader(file_name='/a/b/c/d.yaml')
    assert my_loader.file_name == '/a/b/c/d.yaml'

# Generated at 2022-06-20 23:55:49.263080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:55:56.996255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = b'---\n- hosts: localhost\n  vars:\n    var1: >-\n        this\n        is\n        a\n        test\n'
    loader = AnsibleLoader(yaml, 'test_loader')
    d = loader.get_single_data()
    assert d == [{
        'hosts': 'localhost',
        'vars': {
            'var1': 'this\n        is\n        a\n        test'
        }
    }]

# Generated at 2022-06-20 23:56:47.864224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.reader import Reader

    assert AnsibleLoader


# Generated at 2022-06-20 23:56:54.528871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.yaml import AnsibleLoader

    file_name = 'test'
    vault_secrets = dict(vault_password='vault_pass')

# Generated at 2022-06-20 23:57:02.089627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.vars import BaseVarsPlugin

    data = '''
    ---
    foo: 1
    bar:
      baz:
        - 1
        - 2
        - 3
    '''

    for cls in (AnsibleLoader, BaseVarsPlugin):
        assert not hasattr(cls, 'add_multi_json_path')
        assert not hasattr(cls, 'add_multi_yaml_path')

# Generated at 2022-06-20 23:57:11.103998
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

    vault = VaultLib(None)

    # FIXME: this test is incomplete

# Generated at 2022-06-20 23:57:21.658483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-branches,too-many-statements
    def test_constructor(data, expected_data):
        yaml = AnsibleLoader(data)
        yaml.get_data()

# Generated at 2022-06-20 23:57:25.971563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

    # An object created by AnsibleConstructor should have the following attributes
    assert hasattr(loader, "_yaml_get_lines")
    assert hasattr(loader, "file_name")
    assert hasattr(loader, "vault_secrets")
    assert hasattr(loader, "construct_yaml_map")
    assert hasattr(loader, "construct_yaml_seq")

# Generated at 2022-06-20 23:57:36.231728
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    # Create AnsibleLoader instance with an empty stream, vault secrets, and file name (for debug messages)
    loader = AnsibleLoader(sys.stdin, file_name='test_AnsibleLoader', vault_secrets=[])

    # Test construct_yaml_map()
    yaml_data = loader.construct_yaml_map(None)  # pylint: disable=assignment-from-no-return
    assert yaml_data.__class__.__name__ == 'OrderedDict'

    # Test construct_yaml_seq()
    yaml_data = loader.construct_yaml_seq(None)  # pylint: disable=assignment-from-no-return
    assert yaml_data.__class__.__name__ == 'list'

    # Test construct_yaml_str()

# Generated at 2022-06-20 23:57:47.249720
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)
    assert isinstance(loader, AnsibleConstructor)

    # test AnsibleBaseYAMLObject
    class MyYAMLObject(AnsibleBaseYAMLObject):
        yaml_tag

# Generated at 2022-06-20 23:57:54.291314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime

    class FakeDateTime(datetime.datetime):
        @classmethod
        def now(cls, tz=None):
            return cls(2014, 2, 20, 12, 00, 00)

    def _assert_result(data):
        assert isinstance(data, dict)
        assert data['k1'] == 'ok'
        assert data['k2'] == 2
        assert data['k3'][0] == u'a\u2713b'
        assert data['k3'][1] == u'a\u2713b'
        assert data['k4'] == 'a\n#comment\nb'
        assert data['k5'] == 'a\n\n#comment\nb'
        assert data['k6'] == 12
        assert data['k7'] == 'ok'
       

# Generated at 2022-06-20 23:58:04.282158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import AnsibleLoader
    loader = AnsibleLoader(['a: 1'])
    assert loader.get_single_data() == {'a': 1}


# Generated at 2022-06-20 23:59:55.173013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=missing-docstring
    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_AnsibleLoader(self):  # pylint: disable=no-self-use
        s = '''
        ---
        key1: value1
        key2:
            - item1
            - item2
        '''
        ansible_loader = AnsibleLoader(stream=s)
        assert ansible_loader.get_single_data() == {'key1': 'value1', 'key2': ['item1', 'item2']}


# Generated at 2022-06-20 23:59:57.424787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import UnsafeLoader
    from ansible.parsing.yaml.loader import AnsibleLoader as NotTestedAnsibleLoader

    assert issubclass(AnsibleLoader, NotTestedAnsibleLoader)
    assert not issubclass(AnsibleLoader, UnsafeLoader)

# Generated at 2022-06-21 00:00:07.967186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import yaml
    yaml_file = 'defaults/main.yml'
    yaml_file_name = os.path.join(os.path.dirname(__file__), yaml_file)
    stream = file(yaml_file_name, 'r')
    vault_secrets = ['some_pass']
    AnsibleLoader(stream, vault_secrets=vault_secrets)
    # load single doc
    ansible_loader = AnsibleLoader(stream, vault_secrets=vault_secrets)
    ansible_loader.get_single_data()
    # load multiple docs
    ansible_loader = AnsibleLoader(stream, vault_secrets=vault_secrets)
    ansible_loader.get_data()

# Generated at 2022-06-21 00:00:12.756422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import __main__
        del __main__.__builtins__
        import builtins
    except (ImportError, AttributeError):
        import __builtin__ as builtins

    import os
    import sys
    import types

    # Test importing ansible.parsing.yaml.objects

    # Test importing ansible.parsing.vault

    # Test importing ansible.parsing.yaml.constructor

    # Test importing ansible.parsing.yaml.representer

# Generated at 2022-06-21 00:00:22.642767
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    import os
    import yaml
    # Read configuration file into structure
    path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(path, '../../lib/ansible/parsing/yaml/constructor.py')
    with open(config_path, 'r') as config_file:
        try:
            config_data = yaml.load(config_file, AnsibleLoader)
        except yaml.YAMLError as exc:
            # print(exc)
            assert False

# Generated at 2022-06-21 00:00:31.462649
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2,7):
        import unittest
        from ansible.parsing.yaml.objects import AnsibleMapping
        from ansible.parsing.yaml.nodes import AnsibleSequenceNode

        class TestAnsibleLoader(unittest.TestCase):
            def setUp(self):
                class VaultSecretStub(object):
                    def is_encrypted(self, secret):
                        return False

                self.vault_secrets = VaultSecretStub()

                import io
                self.yaml_text = u"---\na: 1"
                self.yaml_bytes = b"---\na: 1"
                self.yaml_stream = io.BytesIO(self.yaml_bytes)

# Generated at 2022-06-21 00:00:33.627515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-21 00:00:36.882206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stre = 'start: [1 , 2, 3]\n'
    loader = AnsibleLoader(stre)
    ldata = loader.get_single_data()
    assert ldata['start'] == [1 , 2, 3]

# Generated at 2022-06-21 00:00:43.803420
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader().get_single_data() == None
    assert AnsibleLoader("").get_single_data() == None
    assert AnsibleLoader(" ").get_single_data() == None
    assert AnsibleLoader("""{'asdf':'asdf'}""").get_single_data() == {u'asdf': u'asdf'}
    assert AnsibleLoader("""{'asdf':'asdf'}
{'asdf':'asdf'}""").get_single_data() == {u'asdf': u'asdf'}

# Init AnsibleLoader class
AnsibleLoader()

if __name__ == "__main__":
    import sys
    import argparse
    parser = argparse.ArgumentParser()

    # Allow the user to specify the input file on the command line
   