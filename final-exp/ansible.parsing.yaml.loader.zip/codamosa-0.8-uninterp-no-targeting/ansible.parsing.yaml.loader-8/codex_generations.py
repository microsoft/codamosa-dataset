

# Generated at 2022-06-20 23:50:42.058342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:50:50.541685
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:50:58.883577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    import sys
    import os

    sys.path.append(os.path.join(os.path.dirname(__file__), '../../utils'))

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock


# Generated at 2022-06-20 23:50:59.957432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# Generated at 2022-06-20 23:51:00.546088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:51:10.800696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    loader = AnsibleLoader(None)
    assert loader.construct_yaml_null(None, None) is None
    assert loader.construct_yaml_bool(True, None) is True
    assert loader.construct_yaml_bool(False, None) is False
    assert loader.construct_yaml_int(0, None) == 0
    assert loader.construct_yaml_float(1.0, None) == 1.0
    assert loader.construct_yaml_str(u'', None) == ''
    assert loader.construct_yaml_str(u'a', None) == 'a'

# Generated at 2022-06-20 23:51:14.554437
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    test_data = b"---\ndata:\n    - a string"
    test_stream = io.BytesIO(test_data)
    ansible_loader = AnsibleLoader(test_stream)
    data = ansible_loader.get_data()
    assert data == dict(data=['a string'])


# Generated at 2022-06-20 23:51:21.551831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---

# sample
name:
  yaml: test1
  yaml2: test2
'''
    loader = AnsibleLoader(data, file_name='<string>')
    loader.get_single_data()
    assert loader is not None
    assert loader.file_name == '<string>'
    assert loader.vault_secrets is None
    assert loader.get_single_data() == {'name': {'yaml': 'test1', 'yaml2': 'test2'}}

# Generated at 2022-06-20 23:51:33.071290
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, 'construct_object')
    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, 'construct_yaml_int')
    assert hasattr(AnsibleLoader, 'construct_yaml_str')
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert hasattr(AnsibleLoader, 'construct_yaml_map')
    assert hasattr(AnsibleLoader, 'construct_yaml_omap')
    assert hasattr(AnsibleLoader, 'construct_yaml_set')

# Generated at 2022-06-20 23:51:34.958890
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None)
    assert(isinstance(data, AnsibleLoader))

# Generated at 2022-06-20 23:51:39.837891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = u'{"key": "value"}'
    AnsibleLoader(test_data)

# Generated at 2022-06-20 23:51:41.817740
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import copy
    from ansible.parsing.yaml.constructor import Ansi

# Generated at 2022-06-20 23:51:48.142284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(["hello: world"], 'loader.yml')
    try:
        data = loader.get_single_data()
    except:
        assert False, "Loader should return data for valid YAML"
    assert data, "get_single_data() should return something not empty"
    assert len(data.keys()) == 1 and "hello" in data, "data should have one key and it should be hello"
    assert data["hello"] == "world", "hello should be world"

# Generated at 2022-06-20 23:51:52.716875
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=len-as-condition
    assert hasattr(AnsibleLoader, '__init__')
    assert callable(AnsibleLoader.__init__)
    assert len(AnsibleLoader.__init__.__code__.co_varnames) == 4

# Generated at 2022-06-20 23:52:04.564716
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:52:13.348435
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from pprint import pprint

    # Test normal constructor
    test_text = """
---
# This is a hash with a key that has a value
key: value
# This is a list of hashes
list_of_hashes:
  - { a: b, c: d }
  - { e: f, g: h }
    """
    loader = AnsibleLoader(test_text)
    results = loader.get_single_data()

# Generated at 2022-06-20 23:52:23.537634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    try:
        import __builtin__ as builtins  # pylint: disable=import-error
    except ImportError:
        import builtins

    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)
    assert issubclass(AnsibleLoader, builtins.object)

# Test correct subclassing if libyaml is available

# Generated at 2022-06-20 23:52:24.626642
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:52:31.312883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
        - include: test.yml
        - include: this_is_valid.yml
        - include: "this_is_valid.txt"
        - include: "this_is_valid.txt"
        - hosts: localhost
          gather_facts: False
    """

    def check(data):
        assert isinstance(data, list)
        assert len(data) == 5

    AnsibleLoader(content).get_single_data()

# Generated at 2022-06-20 23:52:33.735510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # deprecated since 2.8
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert loader is not None

# Generated at 2022-06-20 23:52:46.225078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Loading all YAML documents in the file, one after another.
    """
    for (doc, _) in AnsibleLoader('---\n- name: test1'):
        assert doc == {'name': 'test1'}
    for (doc, _) in AnsibleLoader('---\n- name: test1\n...\n---\n- name: test2\n...'):
        assert doc == {'name': 'test2'}

# Generated at 2022-06-20 23:52:48.954213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert not HAS_LIBYAML
    print('AnsibleLoader defined')
    print('HAS_LIBYAML is false')


# Generated at 2022-06-20 23:53:00.623683
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.compat.tests import unittest
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def test_add_implicit_resolvers(self):
            # AnsibleLoader class should not add implicit resolvers
            loader = AnsibleLoader('')
            self.assertEqual(0, len(loader.yaml_implicit_resolvers))
            self.assertEqual(0, len(loader.yaml_path_resolvers))

        def test_ansible_unicode(self):
            # Ansible should return unicode strings
            loader = AnsibleLoader('')
            loader.construct_yaml_str('string')

# Generated at 2022-06-20 23:53:09.901288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
        - name: test
          vars:
            a_bool: true
            a_num: 1
            a_string: a string
          tasks:
            - debug:
                msg: all is {{ a_bool | ternary('well', 'not well') }} in {{ a_string }} land
                verbosity: 1 + 2
    """

    loader = AnsibleLoader(data)
    result = loader.get_single_data()

# Generated at 2022-06-20 23:53:10.920338
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:53:12.263516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:53:20.477576
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    # Create sample payload
    data = {'foo': 'bar'}

    # Create AnsibleLoader and load payload into it
    loader = AnsibleLoader(data)
    result = loader.get_single_data()

    # Ensure AnsibleMapping is correct type
    assert isinstance(result, AnsibleMapping)

    # Ensure keys are correct type
    assert isinstance(result.keys()[0], AnsibleUnicode)

# Generated at 2022-06-20 23:53:22.089408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream='')
    assert loader != None
    assert loader.GetScalarString() == None

# Generated at 2022-06-20 23:53:22.832460
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    testloader = AnsibleLoader()
    assert testloader

# Generated at 2022-06-20 23:53:24.094056
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """AnsibleLoader class - constructor"""
    al = AnsibleLoader('asdf')

# Generated at 2022-06-20 23:53:46.792705
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-return-statements,too-many-branches
    import sys

    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from io import BytesIO

    # Unit test for _get_yaml_loader_for_content
    def test_get_yaml_loader_for_content():
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

        content = '0'
        loader = AnsibleLoader._get_yaml_loader_for_content(content)
        assert isinstance(loader, AnsibleLoader)

        content = AnsibleVaultEncryptedUnicode('0')
        loader = AnsibleLoader._get_yaml_loader_for_content(content)

# Generated at 2022-06-20 23:53:56.188430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Testing for the class AnsibleLoader
    import ssl
    from ansible.utils.unsafe_proxy import to_str
    # Testing for the class AnsibleConstructor
    # Testing for the function construct_yaml_str
    assert AnsibleLoader(ssl.SSLContext()).construct_yaml_str('{foo: bar}') == to_str('{foo: bar}')
    from ansible.utils.unsafe_proxy import to_unicode
    # Testing for the function construct_yaml_map
    assert AnsibleLoader(ssl.SSLContext()).construct_yaml_map({'foo': 'bar'}) == to_unicode({'foo': 'bar'})
    # Testing for the function construct_yaml_seq

# Generated at 2022-06-20 23:54:07.902909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import io

    vault_secret_file = 'test_vault_secret_file'

    test_file = u'''
# The quick brown fox jumped over the lazy dog's back
- name: test
  hosts: jdoe
'''

    test_file2 = u'''
# The quick brown fox jumped over the lazy dog's back
- name: test
  hosts: jdoe
  vars:
    var_test: "{{ vault_test }}"
'''

    stream = io.StringIO(test_file)
    compare = AnsibleLoader(stream, vault_secrets=None).get_single_data()

    stream = io.StringIO(test_file)
    compare2 = AnsibleLoader(stream, vault_secrets=None).get_single

# Generated at 2022-06-20 23:54:10.019209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """

- 1
- 2
- 3
- 4

"""
    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-20 23:54:20.912594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.loader
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_src = '''
---
- name: first
  a: 1
- name: second
  a: 2
  b: 3
'''
    data = AnsibleLoader(yaml_src).get_single_data()
    assert data[0]['name'] == 'first'
    assert data[0]['a'] == 1
    assert data[1]['name'] == 'second'
    assert data[1]['a'] == 2
    assert data[1]['b'] == 3

# Generated at 2022-06-20 23:54:31.914055
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.path_loader import YamlReader
    from ansible.parsing.yaml import objects
    import six

    class MyAnsibleLoader(AnsibleLoader):

        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name=file_name, vault_secrets=vault_secrets)

        def construct_ansible_object(self, node):
            if isinstance(node, YamlReader.SafeRepresenter.represent_int):
                return objects.AnsibleUnicode(six.text_type(node.value))
            else:
                return AnsibleLoader.construct_object(self, node)


# Generated at 2022-06-20 23:54:32.505900
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    myloader = AnsibleLoader(None)

# Generated at 2022-06-20 23:54:37.594257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    loader = AnsibleLoader(stream=io.BytesIO('test'), file_name='test', vault_secrets=None)

    assert loader.stream == io.BytesIO('test')
    assert loader.file_name == 'test'

    # Loads the input data stream and returns the constructed object.
    assert loader.get_single_data() == 'test'

# Generated at 2022-06-20 23:54:40.528532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .loader import C
    loader = AnsibleLoader(C)
    assert loader.get_single_data() == {'key': 'value'}

# Generated at 2022-06-20 23:54:43.289989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader is not None

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:55:15.578816
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import collections
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    input_data = """
    option_a:
      - 1
      - 2
      - 3
      - 4
      - 5

    option_b:
      - 1
      - 2
      - 3
      - 4
      - 5

    option_c:
      - 1
      - 2
      - 3
      - 4
      - 5

    option_d:
      - 1
      - 2
      - 3
      - 4
      - 5
    """

    class OptionsDataclass(collections.Mapping):
        _options = dict()

        def __init__(self, options):
            self._options = options
            self._keys

# Generated at 2022-06-20 23:55:25.144763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile


# Generated at 2022-06-20 23:55:27.468209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert loader is not None

# Generated at 2022-06-20 23:55:38.108412
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedText
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-20 23:55:40.847752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = file('/dev/null')
    file_name = 'ansibleloader'
    vault_secrets = ['va', 'ult']
    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-20 23:55:50.825712
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.parser import ParserError
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-20 23:55:57.764685
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
- hosts: localhost
  remote_user: root
  tasks:
    - name: Ensure aws cli is installed.
      action: pip name=awscli
    - name: Ensure Docker is installed.
      action: apt pkg=docker.io state=installed update_cache=yes
"""

    import StringIO
    stream = StringIO.StringIO(yaml_str)
    loader = AnsibleLoader(stream)

    for item in loader:
        print(item)

# Generated at 2022-06-20 23:56:06.433899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import platform
    loader = AnsibleLoader(io.StringIO(u'---\nstring1: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35353637383932363134353736333838623832363962396636356137353033643666656331666130\n          616532626335626539323532353364643532366433656635656463336534386634363335623261\n          366638393830633664313264346239323963346161333132326661396163656330363964393330\n          36663536623464\n'))

# Generated at 2022-06-20 23:56:11.285566
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    filename = 'test_AnsibleLoader.yaml'
    stream_data = """
            - test_data_1
            - test_data_2
            """
    ansible_loader = AnsibleLoader(stream_data, filename)
    ansible_loader.get_single_data()

# Generated at 2022-06-20 23:56:18.461556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fd = open('playbooks/test_loader/fixtures/duplicate_keys.yaml', 'r')
    yaml_data = fd.read()
    fd.close()
    loader = AnsibleLoader(yaml_data)
    data = loader.get_single_data()
    assert type(data) == list
    assert data == [{'a': 'foo'}, {'b': 'bar'}]
    assert len(loader.duplicated) == 1
    assert 'b' in loader.duplicated


# Generated at 2022-06-20 23:57:11.383863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile
    from ansible.module_utils.common.yaml.dumper import AnsibleDumper
    from ansible.module_utils.common.yaml.ext import AnsibleUnsafeLoader
    from ansible.module_utils.common.yaml.ext import ansible_native_implicit_resolver
    from ansible.module_utils.common.yaml.ext import AnsibleUnsafeDumper

    yaml_file = tempfile.NamedTemporaryFile(delete=False)
    yaml_file.write(b'test: test')
    yaml_file.close()

    test_obj = AnsibleLoader(open(yaml_file.name))
    test_dict = next(iter(test_obj))
    os.unlink(yaml_file.name)

   

# Generated at 2022-06-20 23:57:16.444065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    simple_yml = '''
---
1: 1
2: 2
3: 3
'''
    foo = AnsibleLoader(simple_yml)
    d = foo.get_single_data()
    assert isinstance(d, dict)
    assert d == {'1': 1, '2': 2, '3': 3}

# Generated at 2022-06-20 23:57:25.485328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.json import AnsibleJSONEncoder
    import json

    import types

    simple = """
    foo: bar
    """
    complex = """
    foo:
      bar:
        - baz
        - 1
        - null
    a: 1
    b: "test"
    """

    # Create an example generator function
    def get_generator(data):
        def gen():
            yield data
        return gen

    def compare_unordered_lists(list1, list2):
        if sorted(list1) == sorted(list2):
            return True
        else:
            return False


# Generated at 2022-06-20 23:57:28.375371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Has to maintain backwards compat for now, so we can't enforce typing on the constructor
    data = dict(AnsibleLoader(stream=[]))  # pylint: disable=unsubscriptable-object
    assert isinstance(data, dict)
    assert data == {}

# Generated at 2022-06-20 23:57:29.448874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  loader = AnsibleLoader("")

# Generated at 2022-06-20 23:57:34.403333
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('["foo", "bar"]', file_name='file.yml')
    assert loader.get_single_data() == ['foo', 'bar']
    loader = AnsibleLoader("""
        ---
        foo: bar
        """, file_name='file.yml')
    assert loader.get_single_data() == dict(foo='bar')

# Generated at 2022-06-20 23:57:39.305140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    l = AnsibleLoader('{"hosts": [], "vars": {}, "tasks": [] }')
    parsed_data = l.get_single_data()

    assert 'hosts' in parsed_data
    assert 'vars' in parsed_data
    assert 'tasks' in parsed_data

# Generated at 2022-06-20 23:57:41.288814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ans_loader = AnsibleLoader(None)
    assert isinstance(ans_loader, AnsibleLoader)

# Generated at 2022-06-20 23:57:43.544622
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    class TestAnsibleLoader(AnsibleLoader):
        pass
    loader = TestAnsibleLoader(None)
    assert isinstance(loader.construct_yaml_map(), AnsibleMapping)
    assert isinstance(loader.construct_yaml_seq(), AnsibleSequence)

# Generated at 2022-06-20 23:57:45.022999
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    assert obj is not None


# Generated at 2022-06-20 23:59:27.734613
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Scanner, Parser, Composer, AnsibleConstructor and Resolver does nothing
    loader = AnsibleLoader("")
    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-20 23:59:35.823856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-20 23:59:42.753698
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - hosts: localhost
      vars:
        login:
          user: root
          password: "{{ lookup('env', 'SOME_SECURE') }}"
    '''
    loader = AnsibleLoader(stream, file_name='/tmp/hosts', vault_secrets={'vault_secret_1': 'password1', 'vault_secret_2': 'password2'})
    data = loader.get_single_data()
    assert not hasattr(loader, 'file_name')
    assert not hasattr(loader, 'vault_secrets')
    assert data is not None

# Generated at 2022-06-20 23:59:45.883074
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    stream = AnsibleUnicode('[foo, bar, {baz: boo}]').encode()
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_single_data()

# Generated at 2022-06-20 23:59:54.601943
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    if HAS_LIBYAML:
        from yaml.constructor import SafeConstructor
        from yaml.representer import SafeRepresenter
        from yaml.resolver import Resolver
        from ansible.module_utils.common.yaml import Parser
        assert issubclass(AnsibleLoader, Parser)

    else:
        from ansible.module_utils.common.yaml import Reader, Scanner, Parser, Composer
        from yaml.constructor import SafeConstructor
        from yaml.representer import SafeRepresenter
        from yaml.resolver import Resolver
        assert issubclass(AnsibleLoader, Reader)
        assert issub

# Generated at 2022-06-21 00:00:04.965747
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test all methods of class AnsibleLoader;
    '''
    import os
    import sys
    import ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secrets = [{'vault_id': 'abcdefg', 'secret': 'a1b2c3'}]
    file_name = 'ansible/parsing/yaml/loader.py'
    stream = open(file_name, 'r')
    loader = AnsibleLoader(stream, file_name, vault_secrets=vault_secrets)
    # AnsibleConstructor: __call__()
    data = loader.get_single_data()
    assert isinstance(data, dict)
    # AnsibleConstructor: construct_yaml_

# Generated at 2022-06-21 00:00:05.453733
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-21 00:00:12.659258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import sys
    if sys.version_info.major < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    loader = DataLoader()
    variable_manager = VariableManager()

    test_string = StringIO("""
    foo: bar
    baz:
      - 1
      - 2
    """)

    test_dict = loader.load(test_string, variable_manager, loader.parser)

    assert isinstance(test_dict, dict)
    assert test_dict == { 'foo': 'bar', 'baz': [1, 2] }

# Generated at 2022-06-21 00:00:18.911682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Create a resolver
    resolver = Resolver()

    # Create a constructor
    constructor = AnsibleConstructor()

    # Create a scanner
    scanner = Scanner()

    # Create a parser
    parser = Parser(resolver, constructor, scanner)

    # Create a composer
    composer = Composer(parser, constructor)

    # Create a loader
    loader = AnsibleLoader(composer)

    return loader

# Generated at 2022-06-21 00:00:28.968934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access

    # Test that we can create an AnsibleLoader
    AnsibleLoader('')

    # Test that the Resolver class has been set up with the Ansible tag prefix