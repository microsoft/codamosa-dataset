

# Generated at 2022-06-20 23:50:50.803725
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import string
    import random
    import tempfile
    import types
    import yaml

    test_vars = dict(
        foo=123,
        bar="abc",
        baz=dict(
            qux=True
        )
    )

    def rand_string(n):
        return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))

    al = AnsibleLoader(stream=None)

    for i in range(10):
        test_file_name = rand_string(10)
        test_data = rand_string(32)
        test_fd, test_path = tempfile.mkstemp()
        with os.fdopen(test_fd, 'w') as test_f:
            test_

# Generated at 2022-06-20 23:50:56.941883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class DummyClass:
        pass
    stream = DummyClass()
    file_name = 'dummy_file_name'
    vault_secrets = 'dummy_vault_secrets'
    obj = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert isinstance(obj, AnsibleLoader)
    assert isinstance(obj, Parser)
    assert isinstance(obj, AnsibleConstructor)
    assert isinstance(obj, Resolver)

# Generated at 2022-06-20 23:51:01.723787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None).get_single_data()
    assert data is None

    data = AnsibleLoader('').get_single_data()
    assert data is None

    import sys
    data = AnsibleLoader(sys.stdin).get_single_data()
    assert data is None

# Generated at 2022-06-20 23:51:11.608602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

# Generated at 2022-06-20 23:51:12.468492
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:16.685070
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, (Parser, Composer))
    assert isinstance(loader, (Reader, Scanner))
    assert isinstance(loader, (Resolver, AnsibleConstructor))

# Generated at 2022-06-20 23:51:22.415732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/tmp/hello', 'w')
    stream.write('hello, world!\n')
    stream.close()
    stream = open('/tmp/hello', 'r')
    loader = AnsibleLoader(stream)

    loader.get_data()
    loader.check_data()
    loader.compose_document()
    loader.construct_document()

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:51:28.330273
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    import ansible.parsing.yaml.loader
    stream = StringIO(u"---\n- hosts: all")
    l = ansible.parsing.yaml.loader.AnsibleLoader(stream)
    assert l.get_single_data() == [{u'hosts': u'all'}]
    assert stream.closed

# Generated at 2022-06-20 23:51:28.891701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:51:32.724351
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader=AnsibleLoader("""
    ---
    - name: hello
      action: command echo hello
    """)
    loader.get_single_data()


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:51:35.369208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:51:40.394425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class CAnsibleLoader:
        '''
            dummy class for testing AnsibleLoader
        '''
        pass
    loader = AnsibleLoader(None)
    assert isinstance(loader, CAnsibleLoader)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-20 23:51:49.801857
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = """---
- hosts:
    - a
    - b
  vars:
    ansible_python_interpreter: /usr/bin/python
"""
    loader = AnsibleLoader(data)
    object = loader.get_single_data()
    assert type(object) is list
    assert type(object[0]['hosts']) is list
    assert type(object[0]['hosts'][0]) is AnsibleUnicode
    assert type(object[0]['hosts'][1]) is AnsibleUnicode
    assert type(object[0]['vars']) is dict
    assert type(object[0]['vars']['ansible_python_interpreter']) is AnsibleUnicode

# Generated at 2022-06-20 23:52:01.617303
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    ansible_test_dict = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3, 4],
        'd': {'a': 1, 'b': 2, 'c': 3},
    }

    # String
    string = "a: 1 \nb: 2 \nc: \n  - 1\n  - 2\n  - 3\n  - 4"
    string += "\nd: a: 1\n    b: 2\n    c: 3"
    loaded_data = AnsibleLoader(string, 'memory').get_single_data()
    assert type(loaded_data) is Ansible

# Generated at 2022-06-20 23:52:02.605465
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('')

# Generated at 2022-06-20 23:52:04.563751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Unit tests for class AnsibleDumper
# TODO: Write unit tests for class AnsibleDumper

# Generated at 2022-06-20 23:52:05.538360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:52:07.985330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader('')
    assert loader

# Generated at 2022-06-20 23:52:11.847502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    options = combine_vars(loader=DataLoader(), variables={})

    tmp = AnsibleLoader(file_name='should.not.be.used', vault_secrets=options['vault_secrets'])
    assert tmp

# Generated at 2022-06-20 23:52:19.580689
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = """
    ---
    Test: 1
    ...
    """

    class AnsibleLoader(yaml.Loader):
        pass

    al = AnsibleLoader(data)
    # Needed to avoid problems with AnsibleLoader not getting a file name
    al.file_name = '/dev/null'
    al.vault_secrets = []
    data = al.get_single_data()

    assert(data['Test'] == 1)

# Generated at 2022-06-20 23:52:25.326563
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)

    assert isinstance(ansible_loader, AnsibleConstructor)

# Generated at 2022-06-20 23:52:35.195105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import inspect
    import sys
    from ansible.parsing.yaml.constructor import string_to_safe_bytes

    # Test that we exclude 'self' in the member variable names
    self_list = [ x for x in dir(AnsibleLoader) if x[0] != '_' and x != 'self' ]

    assert len(self_list) == len(AnsibleLoader._yaml_constructors)
    assert len(self_list) == len(AnsibleLoader._yaml_base_methods)

    # We define methods in the base class Resolver and we are overriding
    # them in the base constructor class.  This is a sanity check to make
    # sure we didn't forget any of those methods in the AnsibleConstructor
    # class.


# Generated at 2022-06-20 23:52:46.761749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    basic_yaml_str = """
    ---
    foo: bar
    baz:
    - foonly
    - baronly
    - bazonly
    """

    assert isinstance(AnsibleLoader(basic_yaml_str, file_name='foo').get_single_data(), dict)
    assert len(AnsibleLoader(basic_yaml_str, file_name='foo').get_single_data()) == 2
    assert 'foo' in AnsibleLoader(basic_yaml_str, file_name='foo').get_single_data()
    assert 'baz' in AnsibleLoader(basic_yaml_str, file_name='foo').get_single_data()

# Generated at 2022-06-20 23:52:53.371699
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("\n- foo: bar\n- baz: bar\n")
    assert loader.get_single_data() == [{'foo': 'bar'}, {'baz': 'bar'}]
    assert loader.get_single_data("\n---\n- foo: bar\n- baz: bar\n") == [{'foo': 'bar'}, {'baz': 'bar'}]

# Generated at 2022-06-20 23:52:53.954036
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:58.192832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None, 'my_test_file.yml', ['my_secret']).get_single_data()
    assert data
    assert data.file_name == 'my_test_file.yml'
    assert data.vault_secrets == ['my_secret']

# Generated at 2022-06-20 23:52:59.206433
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:53:00.522237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-20 23:53:03.676700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:11.559667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    vault_secret = VaultSecret(b'vaultpassword')
    vault_secrets = [ vault_secret ]
    variable_manager = VariableManager()

    # Load test data
    with open("./test/unit/parsing/yaml/constructor_data.yml") as f:
        test_data = f.read()

    # Call constructor
    loader = AnsibleLoader(test_data, vault_secrets=vault_secrets).get_single_data()


# Generated at 2022-06-20 23:53:20.891291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
- hosts: localhost
  gather_facts: no
  connection: local
  tasks:
    - debug: msg="Test"
    '''

    # Test AnsibleLoader
    ansibleloader_obj = AnsibleLoader(data)  # pylint: disable=too-many-function-args
    assert type(ansibleloader_obj) == AnsibleLoader

# Generated at 2022-06-20 23:53:30.575111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # We need to mock the ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode
    # class because that class does not exist in the global namespace
    # when this module is imported.
    # this is done in the unit test file.

    import ansible.parsing.yaml.loader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils import vault
    import sys

    # test loading
    try:
        # Check the existance of the vault_secrets parameter.
        # It is not used in the __init__ function, but it is used
        # in the AnsibleConstructor
        AnsibleLoader('test')
    except TypeError:
        pass


# Generated at 2022-06-20 23:53:32.717058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    # FIXME: figure out what to test

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:53:37.773251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
      - 1
      - 2
      - 3
      - 4
      - 5
    '''
    AnsibleLoader.add_to_builtins('int')
    AnsibleLoader.add_constructor('!int', AnsibleConstructor.construct_yaml_int)
    AnsibleLoader.add_constructor('!reduce', AnsibleConstructor.reduce)
    AnsibleLoader.add_multi_importer()
    AnsibleLoader.add_implicit_resolver('!int', AnsibleConstructor.yaml_int_re, int_values=True)
    assert AnsibleLoader(data).get_single_data() == 15

# Generated at 2022-06-20 23:53:43.018675
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    loader = AnsibleLoader(None)
    d = loader.construct_yaml_map()
    assert type(d) == AnsibleMapping
    l = loader.construct_yaml_seq()
    assert type(l) == AnsibleSequence

# Generated at 2022-06-20 23:53:44.532370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader('')
    assert isinstance(l, AnsibleLoader)

# Generated at 2022-06-20 23:53:46.358525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/tmp/file','r').read()
    loader = AnsibleLoader(stream)

# Generated at 2022-06-20 23:53:52.163503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    stream = open(os.path.join(os.path.dirname(__file__), 'ansible_constructor.yml'))
    al = AnsibleLoader(stream)
    data = al.get_single_data()
    assert data[0] == {
        # "base64-encoded-value" via !vault tag
        'encoded_value': 'Zm9vCg==',
        'value': 'foo',
        # "md5sum-hashed-password" via !password tag
        'md5sum_password': '$1$hashed',
        'one': 1,
        'two': 2
    }

    stream = tempfile.TemporaryFile()
    al = AnsibleLoader(stream)
    assert al.file_name == stream

# Generated at 2022-06-20 23:54:03.033097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence

    from _text import to_text

    class MockVaultSecret:
        def __init__(self):
            self.token = 'foo'


# Generated at 2022-06-20 23:54:05.889257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():                            # pylint: disable=missing-docstring,invalid-name
    loader = AnsibleLoader(vault_secrets='ok')
    assert loader.vault_secrets == 'ok'

# Generated at 2022-06-20 23:54:23.212909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert yaml is not None


# Generated at 2022-06-20 23:54:27.061382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    - hosts: localhost
      roles:
        - { role: foo, other: test }
    '''
    loader = AnsibleLoader(data)
    assert loader is not None
    for noop in loader:
        pass

# Generated at 2022-06-20 23:54:32.609719
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.serializer import Serializer
    from yaml.emitter import Emitter
    import sys

    stream = AnsibleLoader(open(__file__))
    serializer = Serializer(Emitter(sys.stdout), default_style=u't', default_flow_style=False)
    serializer.open()
    serializer.represent(stream)
    serializer.close()


# Generated at 2022-06-20 23:54:36.015248
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data_cls_str = 'ansible.parsing.yaml.objects.AnsibleBaseYAMLData'

    # check that the class of our data is correct
    calculated_data_cls = AnsibleLoader(None).get_single_data()
    assert calculated_data_cls.__name__ == data_cls_str

# Generated at 2022-06-20 23:54:36.731714
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:54:38.792778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    --- {}
    """
    AnsibleLoader(data)

# Generated at 2022-06-20 23:54:49.489715
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml
    from ansible.module_utils.common.yaml import HAS_LIBYAML, Parser, AnsibleConstructor, AnsibleLoader
    assert HAS_LIBYAML is True
    stream = io.StringIO(u"---\n- foobar\n- foobaz")
    assert type(stream) == io.StringIO

    assert type(Parser) == type
    assert issubclass(Parser, yaml.composer.Composer)
    assert issubclass(Parser, yaml.constructor.Constructor)
    assert issubclass(Parser, yaml.resolver.Resolver)
    assert issubclass(Parser, yaml.reader.Reader)
    assert issubclass(Parser, yaml.scanner.Scanner)

# Generated at 2022-06-20 23:54:51.030630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader(stream=False)
    assert al is not None

# Generated at 2022-06-20 23:54:54.151133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    key: value
    '''
    loader = AnsibleLoader(data)
    assert loader.get_data() == {'key':'value'}



# Generated at 2022-06-20 23:54:55.432512
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-20 23:55:37.582477
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    AnsibleLoader.add_constructor(
        u'tag:yaml.org,2002:str',
        AnsibleLoader._construct_yaml_str
    )

    # test construction of an encrypted unicode object
    def test_secret_construction():
        vault_secrets = {u'foo': u'bar'}

# Generated at 2022-06-20 23:55:44.073755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    yaml_str = """
        - {a: 1, b: "c"}
        - [1, 2, 3]
        - {key: value}
        - {key: {subkey: value}}
    """
    stream = StringIO(yaml_str)
    loader = AnsibleLoader(stream)
    for data in loader:
        assert data == {'a': 1, 'b': 'c'} or data == [1, 2, 3] or data == {'key': 'value'} or data == {'key': {'subkey': 'value'}}



# Generated at 2022-06-20 23:55:54.819000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])

    loader = AnsibleLoader(b"my_test: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          3339633938363161393136623231323862626661313737636639363364363035643334366431346364\n          31663930353865343033666665356666666536347D\n", vault_secrets=vault.secrets)
    data = loader.get_single_data()

    assert data['my_test'] == 'test vault string'


# Generated at 2022-06-20 23:55:58.840170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def docker_construct_mapping(self, node, deep=False):
        """
        This one is returning a different object type than the
        AnsibleConstructor does
        """
        constructor = AnsibleConstructor.construct_mapping
        value = constructor(self, node, deep)
        return DockerMapping(value)

    loader = AnsibleLoader('{ "foo": "bar"}', file_name='testfile')

    # Assert we have the correct loader
    assert type(loader) is AnsibleLoader, \
        "Assert the AnsibleLoader is of expected type"

    # Assert we have the correct constructor
    assert type(loader.constructor) is AnsibleConstructor, \
        'Assert the loader of AnsibleLoader has the expected constructor'

    # Check the constructor function is swapped
    loader.construct_mapping = docker_

# Generated at 2022-06-20 23:56:03.582196
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    test_contents = """
---
playbook: &playbook_name
    vars:
        var1: &example
            - a
            - b
            - c
    plays:
        - name: ping
          hosts: localhost
          gather_facts: False
          tasks:
              - ping:
playbook2: *playbook_name
"""
    AnsibleLoader(test_contents)

# Generated at 2022-06-20 23:56:04.411332
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None


# Generated at 2022-06-20 23:56:05.359663
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Nothing to do.
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-20 23:56:06.322828
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-20 23:56:13.156560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
---
- hosts: localhost
  tasks:
   - name: say hello
     debug: msg="Hello World!"
"""

    data = AnsibleLoader(yaml_str).get_single_data()

    assert (data[0]['hosts'] == 'localhost')
    assert (data[0]['tasks'][0]['debug']['msg'] == "Hello World!")


# Generated at 2022-06-20 23:56:23.329221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    vault = VaultLib([])
    basic_dict = dict(a=1, b=dict(ba=2, bb=3), c=4, d=5)
    basic_str = "a: 1\nb:\n  ba: 2\n  bb: 3\nc: 4\nd: 5\n"

# Generated at 2022-06-20 23:57:31.219708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    yaml_tag = 'tag:yaml.org,2002:map'

    loader = AnsibleLoader(None)
    for suffix in ('', '?', '&'):
        assert loader.construct_python_dict(yaml_tag + suffix, []) == {}
        assert loader.construct_python_dict_no_dupe_keys(yaml_tag + suffix, []) == {}
        assert loader.construct_python_str(yaml_tag + suffix) == ''

    loader = AnsibleLoader('test')
    for suffix in ('', '?', '&'):
        assert loader.construct_python_dict(yaml_tag + suffix, []) == {}

# Generated at 2022-06-20 23:57:42.289106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import json
    import hashlib
    import imp
    import unittest

    print('\n===========TEST CASE FOR ANSIBLE LOADER================')

    # pylint: disable=invalid-name
    # Load modules
    test_file_name = os.path.join(os.path.dirname(__file__), '../../ansible_test/_data/yaml/alias_expand_explicit_mapping.yml')
    with open(test_file_name, 'r') as ymlfile:
        Loader = AnsibleLoader(ymlfile)
        y = Loader.get_single_data()
    assert y == {'foo': 'bar', 'bar': 'snafu'}


# Generated at 2022-06-20 23:57:51.672889
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        from io import BytesIO
        inp = b'''
            ---
            - hosts: localhost
              vars:
                var1: val1
              tasks:
              - name: test
                shell: "/bin/echo {{ var1 }}"
              pre_tasks:
              - name: test
                shell: "/bin/echo 'hello from pre_tasks'"
              post_tasks:
              - name: test
                shell: "/bin/echo 'hello from post_tasks'"
        '''
    else:
        from io import StringIO

# Generated at 2022-06-20 23:58:01.205501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import re
    import unittest
    import yaml
    import tempfile
    try:
        from yaml import CSafeLoader as SafeLoader
    except ImportError:
        from yaml import SafeLoader

    VAULT_SECRET = 'v@ultsercret'
    VAULT_PWD_FILE = tempfile.mkstemp()[1]
    with open(VAULT_PWD_FILE, 'w') as f:
        f.write(VAULT_SECRET)


# Generated at 2022-06-20 23:58:05.245765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, 'construct_yaml_map')
    assert callable(loader.construct_yaml_map)
    assert hasattr(loader, 'construct_yaml_seq')
    assert callable(loader.construct_yaml_seq)

# Generated at 2022-06-20 23:58:08.677400
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Instance of class AnsibleLoader
    yaml_instance = AnsibleLoader(stream=None)
    # Check if the object is created successfully
    assert isinstance(yaml_instance, AnsibleLoader)


# Generated at 2022-06-20 23:58:13.723603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = '''
    ---
    test:
      foo: bar
      baz: 1
    '''
    loader = AnsibleLoader(stream, file_name='test')
    assert isinstance(loader.get_single_data(), dict)
    assert isinstance(loader.get_single_data()['test']['foo'], AnsibleUnicode)
    assert isinstance(loader.get_single_data()['test']['baz'], AnsibleUnicode)

# Generated at 2022-06-20 23:58:18.769430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    yaml_data = AnsibleLoader(file_name='/dev/null', vault_secrets=None).get_single_data()

    assert isinstance(yaml_data, AnsibleBaseYAMLObject)

# Generated at 2022-06-20 23:58:25.535972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import yaml

    test_file = """
    ---
    foo: 1
    bar:
      - 1
      - 2
      - 3
    baz:
      a: 1
      b: 2
    """
    fd, fdpath = tempfile.mkstemp()
    os.write(fd, test_file)
    os.close(fd)

    def test_tag(tag, data):
        if tag == '!foo':
            return 'foo_tag'
        if tag == '!bar':
            return 'bar_tag'
        if tag == '!baz':
            return 'baz_tag'

    yaml.add_multi_constructor(u'!foo', test_tag)

# Generated at 2022-06-20 23:58:35.635739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText, AnsibleSequence
    class TestLoader(AnsibleLoader):
        pass
    loader = TestLoader(None)

    # Test _construct_mapping
    vault_secrets = [u'$ANSIBLE_VAULT;1.1;AES256']
    data = dict(foo='$ANSIBLE_VAULT;1.1;AES256')
    loader.vault_secrets = vault_secrets
    result = loader._construct_mapping(None, data, deep=True)
    assert isinstance(result['foo'], AnsibleVaultEncryptedUnicode)
    is_unsafe_text = isinstance(result['foo'].vault.decrypted, AnsibleUnsafeText)
   