

# Generated at 2022-06-20 23:50:45.966282
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-20 23:50:48.298775
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass

    r = TestAnsibleLoader('{}')

# Generated at 2022-06-20 23:50:51.149129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = "---\n"
    file_name = 'test_file'
    vault_secrets = None

    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-20 23:50:59.019076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from string import split
    from sys import stdin, exc_info

    try:
        from cStringIO import StringIO
    except ImportError:
        from io import StringIO

    from ansible.parsing.vault import VaultLib

    # use stdin for input
    fh = stdin
    #helper = FakeVaultLib()

    # create vault-encrypted text via vault
    helper = VaultLib(vault_secrets=['/tmp/vaultsecret.txt'])
    vault_text = helper.encrypt('password=password')

    # write a string to a test file
    file_name = '/tmp/test_yaml'
    file_text = '---\nfoo: bar \nbaz: %s' % vault_text
    fh = open(file_name, 'w')

# Generated at 2022-06-20 23:51:00.448303
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None) # pylint: disable=no-value-for-parameter

# Generated at 2022-06-20 23:51:10.761186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    const = '''
---
- hosts: localhost
  gather_facts: no
  tasks:
    - debug: var=item
      with_items: ['a', 'b', 'c']
    - debug: var=solved_vault_id
      with_items: '{{ lookup("vault", "@vault_var", loader=loader, file=file_name) }}'
    - debug: var=solved_vault_id
      with_items: '{{ lookup("vault", "vault_var", loader=loader, file=file_name) }}'
    - debug:
        msg: '{{ lookup("vault", "vault_var", loader=loader, file=file_name) }}'
        # test the other loader
        loader: "safe"
'''

# Generated at 2022-06-20 23:51:14.009741
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("../../../test/units/parsing/yaml/basic.yaml", 'r')
    ansible_loader = AnsibleLoader(stream)
    assert isinstance(ansible_loader, AnsibleLoader)
    stream.close()

# Generated at 2022-06-20 23:51:23.314175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load, dump
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # True
    s = "\n-  True\n"
    d = load(s)
    assert d == [True]

    s = "\n-  yes\n"
    d = load(s)
    assert d == [True]

    s = "\n-  on\n"
    d = load(s)
    assert d == [True]

    s = "\n-  1\n"
    d = load(s)
    assert d == [True]

    s = "\n-  '1'\n"
    d = load(s)
    assert d == ['1']

    s = "\n-  'True'\n"
   

# Generated at 2022-06-20 23:51:26.598597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleloader = AnsibleLoader(None, file_name='/path/to/ansible/file')
    assert ansibleloader.file_name == '/path/to/ansible/file'

# Generated at 2022-06-20 23:51:38.318951
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    vault_secret = 'test_ansible'
    vault = VaultLib(vault_secret)
    encrypted_vault_id = vault.encrypt(b'\n---\n# test vault', False)
    encrypted_vault_id_v2 = vault.encrypt(b'\n---\n# test vault', True)


# Generated at 2022-06-20 23:51:49.935729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert HAS_LIBYAML, "yaml/cyaml is not installed"

    # pylint: disable=incomplete-protocol
    class Foo(object):
        pass

    class Bar(object):
        pass

    class AnsibleLoaderWithFoo(Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            Reader.__init__(self, stream)
            Scanner.__init__(self)
            Parser.__init__(self)
            Composer.__init__(self)
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self)


# Generated at 2022-06-20 23:51:51.427759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:51:52.863792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    vals = AnsibleLoader(stream=None)
    assert vals is not None

# Generated at 2022-06-20 23:51:59.822128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = """
        ---
        uno: 1
        dos: dos
        tres: [3,3,3]
    """

    ansible_loader = AnsibleLoader(yaml_string)
    doc = ansible_loader.get_single_data()

    assert doc.get('uno') == 1
    assert doc.get('dos') == 'dos'
    assert doc.get('tres') == [3,3,3]

# Generated at 2022-06-20 23:52:03.692522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, '__iter__')

    with open("/etc/hosts", "r") as f:
        for data in f:
            for loader in AnsibleLoader(data):
                assert loader is not None

# Generated at 2022-06-20 23:52:09.139919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    fixture_path = os.path.join(os.path.dirname(__file__), "fixtures")
    testdata = open(os.path.join(fixture_path, 'test_loader.yml')).read()
    testobj = AnsibleLoader(testdata)
    assert testobj
    # FIXME: add more tests here, this is just checking the class instantiates

# Generated at 2022-06-20 23:52:09.607204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:13.637287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ['{"foo": "bar"}', '---', '{"bar": "baz"}']
    loader = AnsibleLoader(stream)
    first_doc = loader.get_single_data()
    second_doc = loader.get_single_data()

    assert first_doc == dict(foo="bar")
    assert second_doc == dict(bar="baz")

# Generated at 2022-06-20 23:52:14.193194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:24.283745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper

    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleDumper, AnsibleLoader)

# Generated at 2022-06-20 23:52:37.914941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    file_name = os.path.join(os.path.dirname(__file__), 'data/vault_test_vault_id_only.yml')
    with open(file_name) as stream:
        loader = AnsibleLoader(stream)
        loader.set_vault_secrets(['9afd9b2c2df23eeda3076e1de71acb70'])
        loader.set_variable_manager(VariableManager())
        loader.set_inventory(InventoryManager(loader=loader, sources=[]))
        loader.get_single_data()

# Generated at 2022-06-20 23:52:39.116161
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:52:50.907366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.vault import VaultLib

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.vault = VaultLib([])

        def tearDown(self):
            pass


# Generated at 2022-06-20 23:53:01.953892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''
---
cat:
  - 1
  - 2
  - 3
dog:
  - 4
  - 5
  - 6
'''

    assert sorted(AnsibleLoader(s).get_single_data()) == sorted({'cat': [1, 2, 3], 'dog': [4, 5, 6]})

    # Test vaulted data

# Generated at 2022-06-20 23:53:07.953268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    stream = StringIO(u"---\n- 1")
    loader = AnsibleLoader(stream)
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-20 23:53:10.536469
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
---
[my-host]
foo.example.com:
    name: myhost
'''
    AnsibleLoader(data)

# Generated at 2022-06-20 23:53:22.544861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader(file_name='spec/loader/data/yaml')

        def tearDown(self):
            self.loader = None

        def test_constructor_set_file_name(self):
            self.assertEqual(self.loader.file_name, 'spec/loader/data/yaml')

        def test_yaml_dumper_noop(self):
            yaml_str = '''
            a: Hello World
            b: 1
            '''
            res = self.loader.get_single_

# Generated at 2022-06-20 23:53:25.293387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        ansible_loader = AnsibleLoader(None, file_name=None, vault_secrets=None)
        print(ansible_loader)
    except Exception as e:
        print(e)

# Generated at 2022-06-20 23:53:33.980398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  import datetime
  import io
  import os
  import tempfile
  import time
  import unittest

  class TestAnsibleLoader(unittest.TestCase):
    def setUp(self):
      self.loader = AnsibleLoader(
        io.BytesIO(
          "#!/bin/bash\n"
          "\n"
          "echo 'Hello World'\n"
          "\n"
          "# noqa: E501\n"
          "echo $1\n"
          "\n"
          "echo \"$2\"\n"
          "\n"
          "echo $3\n"
          "\n"
        ),
        "./test",
        ["testvar1", "testvar2", "testvar3"],
      )
      self.loader.get_single_data()


# Generated at 2022-06-20 23:53:45.718229
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the basic features of AnsibleLoader.
    """

    import yaml
    from ansible.parsing.vault import VaultLib

    # test vault class
    v = VaultLib('secret')
    assert '$ANSIBLE_VAULT;AES256' in v.encrypt('test')
    assert 'test' == v.decrypt(v.encrypt('test'))

    # test AnsibleLoader class

# Generated at 2022-06-20 23:53:58.174487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is used in several places so we need to be able to
    # construct an instance of it.
    ansible_loader = AnsibleLoader('')
    assert ansible_loader

# Generated at 2022-06-20 23:53:59.222092
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)



# Generated at 2022-06-20 23:54:08.854739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.vault import VaultLib
    vault_password = 'asdfasdf'
    loader = AnsibleLoader('abc')
    assert loader.vault_secrets == {}
    loader = AnsibleLoader('abc', vault_secrets={'default': VaultLib([vault_password])})
    assert os.path.split(loader.file_name)[1] == '<unicode string>'
    assert loader.vault_secrets == {'default': VaultLib([vault_password])}
    loader = AnsibleLoader('abc', file_name='/path/to/file', vault_secrets={'default': VaultLib([vault_password])})
    assert loader.file_name == '/path/to/file'

# Generated at 2022-06-20 23:54:20.774083
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    if sys.version_info[0] < 3:
        from StringIO import StringIO
    else:
        from io import StringIO

    data = StringIO("""
---
foo: !!str
bar: !!str "baz"
""".encode("utf-8"))

    loader = AnsibleLoader(data)
    loader.get_single_data()

    assert loader.construct_scalar("!test") == "!test"
    assert loader.construct_scalar("!test ") == "!test"
    assert loader.construct_scalar("!test bar") == "!test bar"
    assert loader.construct_scalar("!test\n- foo") == "!test\n- foo"

# Generated at 2022-06-20 23:54:23.438577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-20 23:54:27.766097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    # test list type spec_set
    test_yaml = "---\n- { 'foo': 1, 'bar': 2 }\n"
    loader = AnsibleLoader(test_yaml)
    loader.get_single_data()
    assert loader.construct_sequence() == [ dict(foo=1, bar=2) ]

    # test dict type spec_set
    test_yaml = "---\n{ 'foo': 1, 'bar': 2 }\n"
    loader = AnsibleLoader(test_yaml)
    loader.get_single_data()
    assert loader.construct_mapping() == dict(foo=1, bar=2)

    # test a vault string, which should be ignored

# Generated at 2022-06-20 23:54:36.453748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = AnsibleLoader('foo')
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

    loader = AnsibleLoader('!vault |\n    $ANSIBLE_VAULT;1.1;AES256\n')
    assert isinstance(loader.get_single_data(), AnsibleVaultEncryptedUnicode)
    assert loader.get_single_data().get_decrypted_text() == ''


# Generated at 2022-06-20 23:54:45.755206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        import unittest
        from io import StringIO

        class TestAnsibleLoader(unittest.TestCase):
            def setUp(self):
                self.loader = AnsibleLoader(StringIO(u"---\n- foo: bar\n"))

            def test_AnsibleLoader(self):
                self.assertEqual(self.loader.get_single_data(), [{u'foo': u'bar'}])

        if __name__ == '__main__':
            unittest.main()

# Generated at 2022-06-20 23:54:55.681628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-public-methods
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        from ansible.module_utils.common.yaml import Parser
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser
    assert issubclass(AnsibleLoader, (Parser, AnsibleConstructor, Resolver))

# Generated at 2022-06-20 23:54:56.844591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:55:19.459462
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    dumper = AnsibleLoader('[first, second]')
    assert len(dumper.yaml_data) == 2
    assert dumper.yaml_data[0] == 'first'
    assert dumper.yaml_data[1] == 'second'

# Generated at 2022-06-20 23:55:20.336878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

__all__ = ['AnsibleLoader']

# Generated at 2022-06-20 23:55:25.135887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = {}
    d['foo'] = 'bar'
    d['baz'] = 'bag'
    data = '---\n' + AnsibleLoader(None).serialize(d)
    assert AnsibleLoader(data, None).get_single_data() == d


# Generated at 2022-06-20 23:55:27.855618
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    class AnsibleLoader(AnsibleConstructor):
        pass

    assert AnsibleLoader

# Generated at 2022-06-20 23:55:34.285785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    doc = AnsibleLoader("foo: bar").get_single_data()
    assert doc['foo'] == 'bar'

    doc = AnsibleLoader("foo:\n - bar\n - 1").get_single_data()
    assert doc['foo'][0] == 'bar'
    assert doc['foo'][1] == 1

    doc = AnsibleLoader("foo:\n - bar\n").get_single_data()
    assert doc['foo'][0] == 'bar'

# Generated at 2022-06-20 23:55:43.616369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader, AnsibleDumper
    loader = AnsibleLoader(None)
    assert loader is not None
    assert loader.construct_scalar
    assert loader.construct_sequence
    assert loader.construct_mapping

    assert loader.substitutions
    assert len(loader.substitutions) == 5
    assert '$file' in loader.substitutions
    assert '$line' in loader.substitutions
    assert '$column' in loader.substitutions
    assert '$parent_line' in loader.substitutions
    assert '$parent_column' in loader.substitutions


# Generated at 2022-06-20 23:55:45.956482
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


from ansible.parsing.yaml.dumper import AnsibleDumper
from ansible.utils.yaml import *

# Generated at 2022-06-20 23:55:50.829105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test attempt to load a class method.
    content = '!!python/name:ansible.parsing.yaml.constructor.AnsibleLoader.from_yaml'
    AnsibleLoader(content)

from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject


# Generated at 2022-06-20 23:56:01.193572
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from io import StringIO

    # Test with vault
    vault_pass = 'my_vault_pass'
    vault_secrets = [VaultLib(vault_pass)]

# Generated at 2022-06-20 23:56:02.062603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None, None)

# Generated at 2022-06-20 23:56:43.081743
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # class AnsibleLoader has no method __init__()
    pass

# Generated at 2022-06-20 23:56:46.601682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.splitter import parse_kv
    loader = AnsibleLoader(None)
    value = loader.construct_yaml_kv(None, parse_kv(u'key=value'))
    assert value == ['key', 'value']

# Generated at 2022-06-20 23:56:48.106180
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, '_tag_handlers')

# Generated at 2022-06-20 23:56:48.956131
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(stream=[])
    assert obj is not None

# Generated at 2022-06-20 23:56:49.626335
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:56:57.611347
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version < '3':
        import __builtin__
        builtins = __builtin__
    else:
        import builtins
    stream = open("cfg_template.yml", 'r')
    constructed_obj = AnsibleLoader(stream).get_single_data()
    assert(constructed_obj['template_image']['url'] == "my/file/path.img")
    assert(constructed_obj['template_image']['format'] == "raw")
    assert(constructed_obj['template_image']['os_version'] == "7.1")

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:57:00.698301
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        inst = AnsibleLoader(stream='', file_name='', vault_secrets={})
    else:
        inst = AnsibleLoader(stream='')

# Generated at 2022-06-20 23:57:05.504168
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    string = '''
    # Comment
    name: "hello world"
    seq:
      - a
      - b
    '''
    loader = AnsibleLoader(io.StringIO(string))
    assert loader.get_single_data() == {
        'name': 'hello world',
        'seq': ['a', 'b']
    }

# Generated at 2022-06-20 23:57:13.381836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import BytesIO
    from ansible.parsing.vault import VaultLib
    stream = BytesIO('ansible: 123')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['ansible'], AnsibleUnicode)
    assert data['ansible'] == '123'
    dumper = AnsibleDumper()
    assert dumper.represent_mapping('tag:yaml.org,2002:map', data) == 'ansible: 123\n'

# Generated at 2022-06-20 23:57:13.910355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:58:47.786789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from io import BytesIO
    from yaml import load
    import sys
    if sys.version_info >= (3,):
        stream = BytesIO(u'{foo: bar}'.encode('utf-8'))
    else:
        stream = BytesIO('{foo: bar}')
    loader = AnsibleLoader(stream)
    mapobj = loader.get_single_data()
    assert isinstance(mapobj, AnsibleMapping)
    assert isinstance(mapobj['foo'], AnsibleUnicode)
    # Because 'load' always uses our loader, do a sanity check for it
    mapobj = load(stream)
    assert isinstance(mapobj, AnsibleMapping)
    assert isinstance

# Generated at 2022-06-20 23:58:50.907616
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    config = '''
        - name: test
          include: foo.yml
    '''

    loader = AnsibleLoader(config)
    mydata = loader.get_single_data()
    assert isinstance(mydata, list)
    assert isinstance(mydata[0], dict)

# Generated at 2022-06-20 23:58:59.732865
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    # Set parameters
    file_name = "AnsibleLoader.yml"
    vault_secrets = None
    stream = file(os.path.join(os.path.dirname(__file__), file_name), 'r')

    # Run test when vault_secrets is None
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    
    # Run test when vault_secrets is not None
    vault_secrets = [{"Password":"pwd"}] 
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-20 23:59:01.398063
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert hasattr(loader, '_yaml_get_val')

# Generated at 2022-06-20 23:59:11.102526
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = """
    - include_vars: /path/to/file.yaml
      tags: always
      when: False
    - include_vars: /path/to/file.yaml
      tags: always
    - include_vars: /path/to/file.yaml
      when: False

    - include_vars: /path/to/file.yaml
      when: True
      tags: always
    - include_vars: /path/to/file.yaml
      when: True
      tags: always
    """
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    #from yaml.emitter import Emitter
   

# Generated at 2022-06-20 23:59:20.784555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import _yaml
    import mock
    import os

    with mock.patch.dict('os.environ', {'HOME': '/path/to/home'}):
        test_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/parsing/yaml/__init__.py')
        mock_open = mock.mock_open(read_data='HOME = os.getenv(\'HOME\')')
        with mock.patch('ansible.parsing.yaml.loader.__builtin__.open', mock_open, create=True):
            sys.modules['_yaml'] = _yaml
            with mock.patch('ansible.parsing.yaml.loader.sys') as mock_sys:
                mock_sys.modules

# Generated at 2022-06-20 23:59:23.423981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')

# Generated at 2022-06-20 23:59:24.770361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-20 23:59:29.186537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    
    # Initialize loader
    loader = AnsibleLoader(None)

    data = {
        'a': 'b',
        'c': 'd',
    }
    
    # Check values
    assert(loader._data == data)
    assert(loader.vault_secrets is None)
    assert(loader.file_name is None)

# Generated at 2022-06-20 23:59:36.750770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.data import AnsibleMapping
    import sys
    import StringIO
    import re

    # Set up the objects we need to test
    stream = StringIO.StringIO("""
        ---
        - hosts: one
          tasks:
          - shell: echo {{ one }}
      """)

    # Construct the class under test
    AnsibleLoader(stream)

    # Test the members of the AnsibleLoader
    assert isinstance(AnsibleLoader.yaml_constructors, dict)
    assert isinstance(AnsibleLoader.yaml_multi_constructors, dict)

    # Test the class members
    assert isinstance(AnsibleLoader.yaml_implicit_resolvers, dict)

