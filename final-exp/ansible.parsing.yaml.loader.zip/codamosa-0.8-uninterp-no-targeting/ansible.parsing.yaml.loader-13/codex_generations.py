

# Generated at 2022-06-20 23:50:52.697320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence, AnsibleMapping, AnsibleUnicode
    from ansible.module_utils.common.yaml import Parser
    if HAS_LIBYAML:
        class AnsibleLoader(Parser, AnsibleConstructor):
            pass
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser
        class AnsibleLoader(Reader, Scanner, Parser, Composer, AnsibleConstructor):
            pass
    al = AnsibleLoader(stream="{foo: bar}")

# Generated at 2022-06-20 23:50:53.668385
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(None), AnsibleLoader)

# Generated at 2022-06-20 23:50:55.498083
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  stream=0
  AnsibleLoader(stream)
  #assert(str(TypeError("can't pickle SwigPyObject objects")) == "")

# Generated at 2022-06-20 23:51:00.306841
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('foo bar')
    if HAS_LIBYAML:
        assert loader.stream == 'foo bar'
    else:
        assert loader.stream.name == '<unicode string>'
        assert loader.stream.buffer == 'foo bar'

# Generated at 2022-06-20 23:51:07.184824
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('./test/unit/parsing/yaml/test.yml', 'r') as f:
        # Python 3.2 requires 'name' and 'encoding' to be specified.
        loader = AnsibleLoader(f, file_name="test", vault_secrets=None)
        data = loader.get_single_data()
        assert data[0] == "a"
        assert data[1] == "b"
        assert data[2] == "c"

# Generated at 2022-06-20 23:51:15.088757
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(stream=os.path.join(os.path.dirname(__file__), '../../test/yaml/ansible-vault-encrypt-input.yml'))
    vault_pass = 'dummy_vault_pass'
    loader._set_vault_secrets(vault_pass)

    vault_id = '$ANSIBLE_VAULT;1.1;AES256'
    vault_version = '1.1'
    vault_secret = vault_pass.encode('utf-8')

    if sys.version_info[0] == 3:
        vault_

# Generated at 2022-06-20 23:51:17.723013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader  # pylint: disable=redefined-outer-name
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:18.526727
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:25.432690
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPasswordError
    import re

    secret = VaultSecret(password=None)
    loader = AnsibleLoader('foo', vault_secrets=secret)

    # Test _get_vault_decrypted_text
    v = VaultLib(secret)

# Generated at 2022-06-20 23:51:26.084200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader

# Generated at 2022-06-20 23:51:39.836013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.text.converters import to_native

    file_name = os.path.realpath(sys.argv[0] or os.devnull)

    class AnsibleLoaderMock(AnsibleConstructor):
        def __init__(self):
            super(AnsibleLoaderMock, self).__init__(file_name)
            self.parser = None
            self.vault_secrets = list()
            self.load = None
            self.read = None
            self.get_data = None

    assert AnsibleLoaderMock().__class__.__name__ == 'AnsibleConstructor'

# Generated at 2022-06-20 23:51:49.118705
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = VaultLib()
    ansible_loader = AnsibleLoader(file_name=None, vault_secrets=vault_secrets)
    assert isinstance(ansible_loader, AnsibleLoader)
    assert isinstance(ansible_loader, AnsibleConstructor)
    assert isinstance(ansible_loader, Resolver)
    if HAS_LIBYAML:
        assert isinstance(ansible_loader, Parser)
    else:
        assert isinstance(ansible_loader, Reader)
        assert isinstance(ansible_loader, Scanner)
        assert isinstance(ansible_loader, Parser)
        assert isinstance(ansible_loader, Composer)

# Generated at 2022-06-20 23:51:56.010438
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = (
        '---\n'
        '- hosts: localhost\n'
        '  vars:\n'
        '    var_name: {{ lookup("env","HOME") }}\n'
        '  tasks:\n'
        '    - debug: msg="{{ var_name }}"\n'
    )
    data = AnsibleLoader(yaml_str).get_single_data()
    assert data

# Generated at 2022-06-20 23:52:07.239988
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from ansible.parsing.yaml import datastructure_filter

    if HAS_LIBYAML:
        stream = io.StringIO("{ test: [1,2,3]}\n")
    else:
        stream = io.BytesIO("{ test: [1,2,3]}\n".encode("utf-8"))

    loader = AnsibleLoader(stream)
    # pylint: disable=deprecated-method
    if sys.version_info < (3, 0):
        data = loader.get_single_data()
    else:
        data = loader.get_single_node()
    data = datastructure_filter.DataStructureFilter().filter(data)
    assert data

# Generated at 2022-06-20 23:52:07.810017
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:08.396354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:52:10.600961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = u'category: [ "test1", "test2" ]'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert type(data) == dict
    assert data['category'] == ['test1', 'test2']

# Generated at 2022-06-20 23:52:22.096567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import time
    import unittest

    from ansible.compat.tests import mock

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self._old_stdout = sys.stdout
            sys.stdout = open(os.devnull, 'w')

        def tearDown(self):
            sys.stdout.close()
            sys.stdout = self._old_stdout

        @mock.patch('ansible.parsing.dataloader.DataLoader.has_plugin')
        def test_constructor_plugin_not_found(self, mock_has_plugin):
            mock_has_plugin.return_value = False

# Generated at 2022-06-20 23:52:22.833862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    L = AnsibleLoader
    assert L

# Generated at 2022-06-20 23:52:33.011318
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    >>> import yaml
    >>> loader = yaml.AnsibleLoader
    >>> isinstance(loader, type)
    True
    >>> isinstance(loader(), yaml.Reader)
    True
    >>> isinstance(loader(), yaml.Scanner)
    True
    >>> isinstance(loader(), yaml.Parser)
    True
    >>> if hasattr(loader(), 'Composer'):
    ...     isinstance(loader(), yaml.Composer)
    ...     True
    >>> isinstance(loader(), yaml.AnsibleConstructor)
    True
    >>> isinstance(loader(), yaml.Resolver)
    True
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 23:52:48.556682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #Create an AnsibleLoader instance
    AnsibleLoader(None)

if HAS_LIBYAML:
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleSequence, AnsibleMapping

    class AnsibleUnicode(str, AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_tag = u'!ansible-unicode'

        def __new__(cls, value):
            return str.__new__(cls, value)


    class AnsibleSequence(list, AnsibleSequence):
        yaml_loader = AnsibleLoader


    class AnsibleMapping(dict, AnsibleMapping):
        yaml_loader = AnsibleLoader

# Generated at 2022-06-20 23:52:49.954528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # No unit test available (so far)
    pass

# Generated at 2022-06-20 23:52:50.437170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:51.058436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:02.152509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.text.converters import to_text

    class Data(object):
        pass

    data = Data()
    data.foo = u"bar"
    data.bam = [u"boom", u"bang", u"bust"]
    data.content = u"some text here"

# Generated at 2022-06-20 23:53:03.334969
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader()

# Generated at 2022-06-20 23:53:04.603729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Foo: pass
    AnsibleLoader(Foo())

# Generated at 2022-06-20 23:53:05.896159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Ensures that AnsibleLoader can be constructed
    AnsibleLoader('{}', None)

# Generated at 2022-06-20 23:53:11.539895
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ['---', 'aliases:', '  vim-pathogen:', '    - "git clone http://github.com/tpope/vim-pathogen.git ~/.vim/bundle/pathogen"', '', '']
    loa = AnsibleLoader(stream)
    assert type(loa) == AnsibleLoader

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:53:13.495204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None, None, None)
    assert ansible_loader is not None

# Generated at 2022-06-20 23:53:32.329801
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.common.collections import ImmutableDict

    all_vars = combine_vars(
        loader=DataLoader(),
        all_vars={'a': 1, 'b': 2},
        parameters={'c': 3, 'd': 4}
    )

    assert isinstance(all_vars, ImmutableDict)

    cfg = ConfigManager(config_dict=all_vars)

    assert isinstance(cfg.data, dict)
    assert isinstance(cfg.data_parser, str)
    assert isinstance(cfg._data, ImmutableDict)


# Generated at 2022-06-20 23:53:39.281631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import yaml
    except ImportError as e:
        raise AssertionError('Error importing yaml: %s' % e)

    if not hasattr(yaml, 'CLoader'):
        raise AssertionError('yaml.CLoader not found')

    testfile = ['[{key: value}]']

    if yaml.__with_libyaml__:
        AnsibleLoader(testfile)
    else:
        AnsibleConstructor(testfile)

# Generated at 2022-06-20 23:53:46.358888
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import data
    from io import StringIO

    ydata = ''
    for i in range(1, 22):
        ydata += "%s" % data.ANSIBLE_YAML_DATA[i]

    stream = StringIO(ydata)
    loader = AnsibleLoader(stream)
    data = loader.get_data()

    assert data == data.ANSIBLE_YAML_LOADS
    assert loader.file_name == "/home/core/data.yml"

# Generated at 2022-06-20 23:53:49.191361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b'\n- 42\n- 3.14\n- true\n- false\n- null\n'
    try:
        yaml = AnsibleLoader(data)
        assert yaml.get_data() == [42, 3.14, True, False, None]
    except AttributeError:
        assert False

# Generated at 2022-06-20 23:53:53.539610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = '''
    - hosts: localhost
      tasks:
        - name: Test
          debug:
            msg: Hello World
    '''
    loader = AnsibleLoader(yaml)
    assert len(loader.get_single_data()) == 1
    assert loader.get_single_data()[0]['hosts'] == 'localhost'

# Generated at 2022-06-20 23:54:04.766101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, value, input_data, environ=None):
            stream = open(input_data, 'rb')
            AnsibleLoader.__init__(self, stream)
            self.value = value

        def compose_node(self, parent, index):
            # call the parent method
            node = AnsibleLoader.compose_node(self, parent, index)

            if self.check_data(node):
                return self.construct_mapping(node, deep=True)
            return node

        def check_data(self, node):
            # insert your check here
            if isinstance(node, yaml.MappingNode):
                self.construct_mapping(node)
                return True
            return False


# Generated at 2022-06-20 23:54:11.805657
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from datetime import datetime
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MockFileHandle():
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    # Test vault with decryption

# Generated at 2022-06-20 23:54:22.170412
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    loader = DataLoader()
    inventory.set_variable_manager(variable_manager)

    test_data = """
    hosts:
      host1:
        somevar: somevalue
    """
    data = loader.load(test_data)
    assert data['hosts']['host1']['somevar'] == 'somevalue'

# Generated at 2022-06-20 23:54:32.994010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    if sys.version_info.major < 3:
        from io import BytesIO
    else:
        from io import StringIO
    if HAS_LIBYAML:
        data = b"foo: !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          32396466353162316231303933316232373730363939343336666162623735633033363030316331\n          62626364346264333538363661333132303130333639623264346239633666316236633639626462\n          6331633464333936"

# Generated at 2022-06-20 23:54:35.268451
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the AnsibleLoader class
    """
    pass

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:54:56.729829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Testing initialization
    assert AnsibleLoader("test", "custom_name", None)


# pylint: disable=too-many-locals

# Generated at 2022-06-20 23:55:00.069683
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = "test.yaml"
    vault_secrets = None
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert loader.file_name == file_name
    assert loader.vault_secrets == vault_secrets
    assert loader.stream == stream

# Generated at 2022-06-20 23:55:03.151302
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b'{ foo: [1, 2] }'
    loader = AnsibleLoader(data)
    assert loader.get_data() == {'foo': [1, 2]}

# Generated at 2022-06-20 23:55:13.788795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class DummyStream():
        def __init__(self, string):
            self.string = string
            self.index = 0
        def read(self, count=None):
            if count is None:
                r = self.string[self.index:]
                self.index = len(self.string)
            else:
                r = self.string[self.index: self.index + count]
                self.index += count
            return r


# Generated at 2022-06-20 23:55:22.309565
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    stream = """
    foo: 1
    bar:
      baz: 2
      quux: [3, 4]
    """

    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert data.get('foo') == 1
    assert data.get('bar').get('baz') == 2
    assert data.get('bar').get('quux')[0] == 3

# Generated at 2022-06-20 23:55:29.940919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Load a dictionary with a list as a key
    data = """
    foo:
      - bar: baz
        qux: quux
    """

    try:
        AnsibleLoader(data)
    except yaml.constructor.ConstructorError:
        # On PyYAML 3.10, this raises an error
        pass
    else:
        assert False, "Failed to raise exception"

# Generated at 2022-06-20 23:55:36.083156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    # test
    $ python Lib/ansible/parsing/yaml/loader.py
    [WARNING]: No YAML module installed, using pure python parser.

    # prepare
    $ python Lib/ansible/parsing/yaml/loader.py prepare
    """
    try:
        test = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    except Exception as e:
        print(e)



# Generated at 2022-06-20 23:55:44.825973
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    # Fake name of the file we pretend to read from
    file_name = "filename.yml"
    # The data we pretend is in the file
    data = """
    - hosts: hostname
      tasks:
      - name: make coffee
        coffee:
          beans: arabica
          milk: yes
          mug: large
    """
    # Build a stream to use with the loader
    # Python 3.x: the stream should be built from bytes
    if sys.version_info[0] < 3:
        stream = io.BytesIO(data)
    else:
        stream = io.StringIO(data)

    # Instantiate our loader with the stream. The VaultSecret here is used only in test mode,
    # when we have to monkey-patch the constructor's vault_secrets.
    loader

# Generated at 2022-06-20 23:55:49.901848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = '''
    hostname:
      - one
      - two
    '''
    loader = AnsibleLoader(test_data)
    result = loader.get_single_data()
    assert 'hostname' in result
    assert result['hostname'][0] == 'one'
    assert result['hostname'][1] == 'two'

# Generated at 2022-06-20 23:55:52.972778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-20 23:56:43.835057
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Check that AnsibleLoader class can be instantiated and has the expected attributes"""
    assert hasattr(AnsibleLoader, 'compose_node')
    assert hasattr(AnsibleLoader, 'construct_node')
    assert hasattr(AnsibleLoader, 'construct_document')
    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, '_construct_mapping_alt')
    assert hasattr(AnsibleLoader, 'construct_sequence')
    assert hasattr(AnsibleLoader, '_construct_sequence_alt')
    assert hasattr(AnsibleLoader, 'construct_scalar')
    assert hasattr(AnsibleLoader, 'construct_yaml_map')
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert has

# Generated at 2022-06-20 23:56:45.103546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(None), AnsibleLoader)

# Generated at 2022-06-20 23:56:48.934485
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_yaml = '''
---
- hosts: localhost
  user: someuser
  tasks:
  - name: test assemble task
    assemble:
      src: /etc/ansible/roles/common/templates
      dest: /tmp/{{ user }}
'''

    assert AnsibleLoader(input_yaml).get_single_data()

# Generated at 2022-06-20 23:56:50.114027
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:56:51.947805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
---
- hosts:
    - localhost
  tasks:
  - name: test
    shell: echo 123
'''
    AnsibleLoader(stream)

# Generated at 2022-06-20 23:56:56.571841
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import json
    sys.path.append(os.path.dirname(__file__) + '/../../')
    sys.path.append(os.path.dirname(__file__) + '/../../test/utils/')
    from AnsibleUnittest import TestCase
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(TestCase):
        def test_AnsibleLoader_init(self):
            loader = AnsibleLoader('fake stream')
            print('-----test ansible constructor')
            self.assertIsInstance(loader.process, dict)
            self.assertIsInstance(loader.process['snake'], bool)
            self.assertIsInstance(loader.process['unicode'], bool)

# Generated at 2022-06-20 23:56:57.654101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("foo")
    assert loader

# Generated at 2022-06-20 23:57:02.090864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)[1]
    assert loader.construct_scalar('tag:yaml.org,2002:str', 'foo') == 'foo'
    assert loader.construct_undefined('tag:yaml.org,2002:str', 'foo') == 'foo'

# Generated at 2022-06-20 23:57:09.254211
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    For now, just a quick check to make sure the ansible yaml constructor
    can handle a list inside of a dictionary. The code was doing something
    strange where it was using the keys from the first element of the list.
    '''
    import StringIO
    mystr = u"--- \nfoo: [{'bar': 'baz'}]\n"
    myfile = StringIO.StringIO(mystr)
    loader = AnsibleLoader(myfile)
    data = loader.get_single_data()
    assert data == { u'foo': [{u'bar': u'baz'}] }

# Generated at 2022-06-20 23:57:14.569295
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.stream is None
    assert loader.file_name is None
    assert loader.vault_secrets is None

    loader = AnsibleLoader('', file_name='test_file')
    assert loader.file_name == 'test_file'

    loader = AnsibleLoader('', vault_secrets=[])
    assert loader.vault_secrets == []

    loader = AnsibleLoader('', file_name='test_file', vault_secrets=[])
    assert loader.file_name == 'test_file'
    assert loader.vault_secrets == []

# Generated at 2022-06-20 23:58:49.633095
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        - hash_behaviour: merge
        - names:
            - name: "John"
            - age: 29
    '''
    loader = AnsibleLoader(data, vault_secrets=None)
    print(loader.get_single_data())
    assert loader.get_single_data()[0] == dict(hash_behaviour='merge')
    assert loader.get_single_data()[1] == dict(names=[dict(name="John"), dict(age=29)])

# Generated at 2022-06-20 23:59:00.159701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    test_yaml = b'''
    basestring:
       - string1
       - string2
       - {key1: value1, key2: value2}
       - [item1, item2, item3]
    '''
    stream = AnsibleLoader(test_yaml)
    basestring = stream.get_single_data()
    assert isinstance(basestring, dict)
    assert len(basestring) == 1
    assert 'basestring' in basestring
    strings = basestring.get('basestring')
    assert isinstance(strings, AnsibleSequence)
    assert len(strings) == 4

# Generated at 2022-06-20 23:59:05.075761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    assert isinstance(obj, Resolver)

    if HAS_LIBYAML:
        assert isinstance(obj, Parser)
    else:
        assert isinstance(obj, Reader)
        assert isinstance(obj, Scanner)
        assert isinstance(obj, Parser)
        assert isinstance(obj, Composer)

# Generated at 2022-06-20 23:59:07.598285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO

    data = AnsibleLoader(BytesIO('')).get_single_data()

    assert data == None

# Generated at 2022-06-20 23:59:10.429686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_data = b'{ test: this is a test }'
    loader = AnsibleLoader(stream=ansible_data)
    data = loader.get_single_data()
    assert data["test"] == "this is a test"

# Generated at 2022-06-20 23:59:14.083587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    loader = AnsibleLoader(file_name='some_file')
    assert isinstance(loader, AnsibleConstructor)
    assert loader.file_name == 'some_file'
    assert loader.vault_secrets is None

# Generated at 2022-06-20 23:59:24.423023
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:59:26.143518
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader(None, file_name=None, vault_secrets=None)
    assert al.file_name == None

# Generated at 2022-06-20 23:59:33.025793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class Tester(object):
        def __init__(self, test):
            self.test = test

    loader = AnsibleLoader(None)
    loader.add_constructor(u'!tester', lambda loader, node: Tester(node.value))
    item = loader.get_single_data(u'!tester 1')
    assert isinstance(item, Tester)
    assert item.test == 1
    item = loader.get_single_data(u'!tester foo')
    assert isinstance(item, Tester)
    assert item.test == 'foo'

# Generated at 2022-06-20 23:59:36.183517
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = None
    file_name = None
    load_obj = AnsibleLoader(stream, file_name)
    load_obj.get_single_data()
    load_obj.get_single_data()
    load_obj.dispose()

if __name__ == '__main__':
    test_AnsibleLoader()