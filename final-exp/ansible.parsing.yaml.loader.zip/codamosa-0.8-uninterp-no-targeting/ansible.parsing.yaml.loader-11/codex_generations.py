

# Generated at 2022-06-20 23:50:41.307473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:50:41.828625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:50:43.590384
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader is not None

# Generated at 2022-06-20 23:50:51.320341
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:50:54.800655
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    except Exception as err:
        print("test_AnsibleLoader failed with err=" + str(err))
        raise err

# Generated at 2022-06-20 23:50:56.895972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None
    assert Parser is not None

# Generated at 2022-06-20 23:51:08.117008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    import time
    import sys
    import os
    import io

    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.dumper
    import ansible.parsing.yaml.loader

    temp_sys = sys.modules.copy()
    sys.modules = dict()  # pylint: disable=blacklisted-function
    sys.modules.update(temp_sys)


# Generated at 2022-06-20 23:51:10.681158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')
    assert hasattr(loader, 'resolve')

# Generated at 2022-06-20 23:51:16.190981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(None)
    except TypeError as ex:
        assert ex.args[0] == '__init__() takes at least 2 arguments (1 given)'
    loader = AnsibleLoader([], None)
    assert loader.file_name == None
    assert loader.vault_secrets == None
    loader = AnsibleLoader([], '')
    assert loader.file_name == ''
    assert loader.vault_secrets == None
    loader = AnsibleLoader([], '', [])
    assert loader.file_name == ''
    assert loader.vault_secrets == []

# Generated at 2022-06-20 23:51:20.342407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
a: 1
b:
  c: 3
  d: 4
'''

    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'a': 1, 'b': {'c': 3, 'd': 4}}

# Generated at 2022-06-20 23:51:34.143476
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.object import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(None, file_name='memory')
    assert isinstance(loader, Resolver)
    assert isinstance(loader.get_SingleQuotedScalar(), str)
    assert isinstance(loader.get_DoubleQuotedScalar(), str)
    assert isinstance(loader.get_PlainScalar(), str)
    assert isinstance(loader.get_ruby_style_scalar(), str)
    assert isinstance(loader.get_unquoted_scalar(), str)
    assert isinstance(loader.get_plain(), str)
    assert isinstance(loader.get_single_quoted(), str)

# Generated at 2022-06-20 23:51:45.886628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os
    import sys
    import unittest

    # Do this early so exception is thrown properly if missing
    import ansible

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from .yaml_test_config import AnsibleVaultTest

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self._endian_marker = '\x60\x60\x60\x60\x60\x60\x60\x61'
            self._comment_prefix = '#'
            self._comment = u' Ansible vault password: $ANSIBLE_VAULT;1.1;AES256'
            self._vault_secret = u

# Generated at 2022-06-20 23:51:51.975005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # These are just examples of test cases.
    # More are possible.

    # Empty document
    assert AnsibleLoader('').get_single_data() == ''
    # Empty list
    assert AnsibleLoader('[]').get_single_data() == []
    # List of integers
    assert AnsibleLoader('[1, 2]').get_single_data() == [1, 2]

    # Test that the constructor is called
    assert AnsibleLoader('1').get_single_data() == 1
    assert AnsibleLoader('1').get_single_data().__class__.__name__ == 'One'

    # Test the error raised on duplicate key
    loader = AnsibleLoader('{a: 1, a: 2}')

# Generated at 2022-06-20 23:52:01.331738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test Parser
    stream = "blah blah blah"
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.stream[0:11] == "blah blah blah"
    assert ansible_loader.stream_pointer == 0

    # Test Constructor
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.data == None
    assert ansible_loader.objects == None
    assert ansible_loader.aliases == None
    assert ansible_loader.file_name == None
    assert ansible_loader.vault_secrets == None

# Generated at 2022-06-20 23:52:11.276926
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    # Test for list creation
    data = u"\n".join(['- a','    - b','    - c','    - d','  - e','  - f','  - g','  - 1','  - 2'])
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert list == type(loader.get_data())
    assert ['a', ['b', 'c', 'd'], 'e', 'f', 'g', 1, 2] == loader.get_data()
    # Test for dict creation
    data = u"\n".join(['a: 1','b:','  - 2','  - 3'])
    stream = StringIO(data)
    loader = AnsibleLoader(stream)
    assert dict == type(loader.get_data())

# Generated at 2022-06-20 23:52:18.950376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    contents = '''
    ---
    - hosts: localhost
      tasks:
      - name: test
        raw: test_module
        ichangethis: {{ test_var }}
        ...
      variables:
      - test_var: hello world
      ...
    '''
    obj = yaml.load(contents, Loader=AnsibleLoader)
    assert 'test_module' in obj[0]['tasks'][0]['raw']

# Generated at 2022-06-20 23:52:23.990934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This is a unit test for the loader of yaml.
    :return:
    """
    stream = open('/home/ansible/yaml_test/test.yml')
    loader = AnsibleLoader(stream)
    # Load data from yaml
    data = next(loader.get_single_data())
    print(data)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:52:34.197617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    loader = AnsibleLoader(None, './test_data/yaml/constructor/a.yaml')
    ansible_map = loader.get_single_data()
    assert isinstance(ansible_map, AnsibleMapping)
    assert ansible_map.get('f') == AnsibleUnicode("a is not bar")
    assert ansible_map.get('h') == AnsibleUnicode("a is not bar")
    assert ansible_map.get('g') == AnsibleUnicode("a is not bar")
    assert ansible_map.get('i') == AnsibleUnicode("a is not bar")

# Generated at 2022-06-20 23:52:37.579274
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Unit test for constructor of class AnsibleLoader."""
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert AnsibleLoader is not AnsibleConstructor
    assert AnsibleUnicode is not unicode

# Generated at 2022-06-20 23:52:49.106977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """---
- hosts: all
  gather_facts: false
  tasks:
  - name: test include_vars
    include_vars:
      file: '{{ role_path }}/vars/test.yml'
      name: test_var
    tags: test_tag
"""
    o = AnsibleLoader(stream)
    for i in o:
        for j in i.keys():
            assert j in ['hosts', 'gather_facts', 'tasks']
            assert i[j] != {}
        assert len(i['tasks']) == 1
        for k in i['tasks']:
            assert 'name' in k.keys()
            assert 'include_vars' in k.keys()
            assert k['name'] == 'test include_vars'

# Generated at 2022-06-20 23:53:02.094632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test that the AnsibleLoader class is able to
    handle a dict without a type (see #16286)
    '''

    # the dict to be yaml'ed
    data = dict(var=dict(foo='bar'))

    # the yaml data as a string
    yaml_data = "var:\n" \
                "  foo: bar"

    # load the string
    ansible_loader = AnsibleLoader(yaml_data)
    ansible_loader.get_single_data()

    # check that the returned data is correct
    assert data == ansible_loader.get_single_data()

# Generated at 2022-06-20 23:53:03.233745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Not implemented
    pass

# Generated at 2022-06-20 23:53:11.320907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unsubscriptable-object
    assert hasattr(AnsibleLoader, 'construct_yaml_int')  # method from AnsibleConstructor
    assert hasattr(AnsibleLoader, 'construct_yaml_str')  # method from AnsibleConstructor
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')  # method from AnsibleConstructor
    assert hasattr(AnsibleLoader, 'construct_yaml_map')  # method from AnsibleConstructor
    assert hasattr(AnsibleLoader, 'construct_undefined')  # method from AnsibleConstructor
    assert hasattr(AnsibleLoader, 'resolve')  # method from Resolver
    assert hasattr(AnsibleLoader, 'anchor_templates')  # method from AnsibleConstructor
    assert hasattr

# Generated at 2022-06-20 23:53:12.420793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-20 23:53:13.952266
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-20 23:53:18.010570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    test_yaml = u'\n\n - foo \r\n- bar\r\n'
    test_file = io.StringIO(test_yaml)
    AnsibleLoader(test_file)

# Generated at 2022-06-20 23:53:22.800465
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print()
    if HAS_LIBYAML:
        t = AnsibleLoader(None)
    else:
        t = AnsibleLoader(None, None)
    print()
    print('Test completed')

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:53:27.844200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\n'
    file_name = '/dev/null'
    vault_secrets = None
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert loader
    assert loader.stream == stream
    assert loader.file_name == file_name
    assert loader.vault_secrets == vault_secrets

# Generated at 2022-06-20 23:53:35.845933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import shutil
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.module_utils.basic import AnsibleModule

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    fname = os.path.join(tmpdir, 'ansible_yaml_object.yaml')
    with open(fname, 'w') as f:
        f.write('''
---
- hosts: localhost
  tasks:
   - debug: msg="hello world"
''')

    data = AnsibleLoader(open(fname)).get_single_data()


# Generated at 2022-06-20 23:53:38.354642
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'construct_python_tuple')

# Generated at 2022-06-20 23:53:46.688526
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:53:56.121860
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This test is to assert correct working of the AnsibleLoader class by
    loading a simple YAML file and asserting the values of the data loaded
    """
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import PY3

    if not PY3:
        builtin_module = '__builtin__'
    else:
        builtin_module = 'builtins'

    # Create a temporary YAML file to load
    test_yaml = os.path.join(tempfile.mkdtemp(), "ansible_loader_test.yml")

# Generated at 2022-06-20 23:54:06.887825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml1 = """
    a: 1
    b: 2
    c: [3, 4]
    """

    yaml2 = """
    - a: 5
      b: 6
    - a: 7
      b: 8
    """

    result1 = {'a': 1, 'b': 2, 'c': [3, 4]}
    result2 = [{'a': 5, 'b': 6}, {'a': 7, 'b': 8}]

    import sys
    if sys.version_info < (2, 7):
        assert result1 == AnsibleLoader(yaml1).get_single_data()
        assert result2 == AnsibleLoader(yaml2).get_single_data()
    else:
        assert result1 == AnsibleLoader(yaml1).get_single_data(safe=True)

# Generated at 2022-06-20 23:54:12.815908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    for test_case in [
        dict(test_in=dict(test="test"),
             test_out=dict(test="test")),

        dict(test_in=dict(test=dict({"a": "b"})),
             test_out=dict(test=dict({'a': 'b'}))),

        dict(test_in=dict(test=["test", "test2"]),
             test_out=dict(test=["test", "test2"])),

        dict(test_in=dict(test=dict({"a": "{{ b }}"})),
             test_out=dict(test=dict({'a': '{{ b }}'}))),
    ]:
        checked_in = False
        checked_out = False


# Generated at 2022-06-20 23:54:16.113311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    return AnsibleLoader(None)


# Generated at 2022-06-20 23:54:17.913850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader

# Generated at 2022-06-20 23:54:19.019020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-20 23:54:29.741101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from yaml.representer import SafeRepresenter

    from ansible.parsing.vault import VaultLib
    from ansible.utils.crypto import the_key


# Generated at 2022-06-20 23:54:34.374472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    class AnsibleLoaderTest(AnsibleLoader):
        pass

    file_name = __file__
    stream = 'Hello World!\n'

    test_AnsibleLoader = AnsibleLoaderTest(stream, file_name)

    assert test_AnsibleLoader.stream.name == file_name
    assert sys.version_info[0] > 2

# Generated at 2022-06-20 23:54:43.479449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = '''
    ---
    - hosts: localhost
      gather_facts: false
      tasks:
        - copy:
            content: "Hello"
            dest: "/tmp/hello.world"
    '''
    loader = AnsibleLoader(data)
    for host in loader.get_single_data():
        assert host == { 'gather_facts': False, 'hosts': 'localhost', 'tasks': [ { 'copy': { 'content': 'Hello', 'dest': '/tmp/hello.world' } } ] }

# Generated at 2022-06-20 23:54:59.839729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader({}, file_name='', vault_secrets='')

# Generated at 2022-06-20 23:55:07.709781
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.utils.yaml import AnsibleLoader

    hold_class = AnsibleLoader.yaml_constructors.get(u"!include")
    hold_regex = AnsibleLoader.yaml_multi_constructors[0][1]
    AnsibleLoader.yaml_constructors[u"!include"] = hold_class
    AnsibleLoader.yaml_multi_constructors[0] = (hold_regex, hold_class)



# pylint: disable=too-many-public-methods

# Generated at 2022-06-20 23:55:09.072317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    aloader = AnsibleLoader(None)
    assert aloader

# Generated at 2022-06-20 23:55:11.681568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    """
    Simple unit test to make sure that the AnsibleLoader is
    imported correctly.
    """

    assert AnsibleLoader



# Generated at 2022-06-20 23:55:15.148528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import unittest
    import tempfile

    class TestAnsibleLoader(unittest.TestCase):
        def test_AnsibleLoader(self):
            load = AnsibleLoader
            self.assertIsInstance(load, type(Parser))

    unittest.main()

# Generated at 2022-06-20 23:55:23.488856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[:2] == (2, 6):
        from ansible.utils.unsafe_proxy import wrap_var
        from io import BytesIO

        data = b"""
        simple: abc
        utf8:   "text: \xE2\x98\xA0"
        list: [1, 2, 3]
        """

        loader = AnsibleLoader(BytesIO(data))
        data_loaded = loader.get_single_data()
        assert data_loaded['simple'] == 'abc'

        # py2.6 doesn't support bytestrings and unicode together, so the string is missing the u' and '\u2620' is in the output instead

# Generated at 2022-06-20 23:55:28.107666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    # AnsibleLoader.constructor should be AnsibleConstructor
    assert(loader.constructor is AnsibleConstructor)
    # AnsibleLoader.resolver should be Resolver
    assert(loader.resolver is Resolver)

# Generated at 2022-06-20 23:55:32.978633
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None, file_name=None, vault_secrets=None)
    assert hasattr(x, '_construct_mapping')
    assert hasattr(x, '_file_name')
    assert hasattr(x, '_vault_secrets')
    assert hasattr(x, '_resolve_nodes')

# Generated at 2022-06-20 23:55:40.718078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_cases = [
        ('123', 123),
        ('foo.bar', 'foo.bar'),
        ('foo:bar', {'foo': 'bar'}),
        ('[1, 2, 3]', [1, 2, 3]),
        ('{"foo": "bar"}', {'foo': 'bar'}),
        ('foo', 'foo.yml')
    ]
    for test_case in test_cases:
        loader = AnsibleLoader(test_case[0], file_name=test_case[0])
        result = loader.get_single_data()
        assert result == test_case[1]

# Generated at 2022-06-20 23:55:47.325609
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test resolver.construct_object
    # Create AnsibleLoader instance
    from io import StringIO
    l = AnsibleLoader(StringIO(u'{"test": "123"}'))
    # Create AnsibleLoader.construct_object closure
    o = l.construct_object
    # Check that AnsibleLoader.construct_yaml_map is called, otherwise
    # AnsibleLoader.construct_mapping is called and the test fails
    l.construct_yaml_map = lambda node: True
    # Call AnsibleLoader.construct_object
    assert o(None, None) is True

# Generated at 2022-06-20 23:56:20.172308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:56:21.289242
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader

# Generated at 2022-06-20 23:56:28.408965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

if HAS_LIBYAML:
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.composer import AnsibleComposer
    from ansible.parsing.yaml.serializer import AnsibleSerializer
    from ansible.parsing.yaml.representer import AnsibleRepresenter


# Generated at 2022-06-20 23:56:35.458943
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    obj = AnsibleBaseYAMLObject()
    loader = AnsibleLoader(None, vault_secrets=[])
    loader.add_constructor(u'tag:yaml.org,2002:timestamp', obj.constructor)
    loader.add_constructor(u'tag:yaml.org,2002:str', obj.constructor)
    assert loader is not None

# Generated at 2022-06-20 23:56:45.273041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def assert_yaml_equal(expected, yaml_text):
        loader = AnsibleLoader(yaml_text)
        parsed = loader.get_single_data()
        if isinstance(expected, dict):
            assert type(parsed) is AnsibleMapping
            assert dict(parsed) == expected
        elif isinstance(expected, (list, tuple)):
            assert type(parsed) is AnsibleSequence
            assert list(parsed) == expected
        else:
            assert parsed == expected

        output = AnsibleDumper(indent=2).dump

# Generated at 2022-06-20 23:56:45.861245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:56:53.310175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if not HAS_LIBYAML:
        raise Exception("No libyaml available. Skipping test")
    import io
    import os
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    old_env = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE')

# Generated at 2022-06-20 23:57:02.131232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = [VaultLib({'vault_password_file':None})]
    cl = AnsibleLoader("""
    - hosts: all
      gather_facts: no
      tasks:
      - name: test command
        command: echo hello""", vault_secrets=vault_secrets)
    assert cl.get_single_data() == {u'hosts': u'all', u'gather_facts': u'no', u'tasks': [{u'command': u'echo hello', u'name': u'test command'}]}


# Generated at 2022-06-20 23:57:11.137682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os

    from ansible.parsing.yaml.loader import AnsibleLoader

    def _get_file_data(filename):
        with open(os.path.join(os.path.dirname(__file__), 'yaml_tests', filename), 'r') as test_data:
            return test_data.read()

    def _get_yaml(filename, vault_password=None):
        return AnsibleLoader(
            _get_file_data(filename),
            file_name=filename,
            vault_secrets=[('default', vault_password)]
        ).get_single_data()

    # Single document
    yaml = _get_yaml('single_document.yml')
    assert type(yaml) == dict, "single document test 1 failed"

# Generated at 2022-06-20 23:57:12.188832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:58:19.848784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    res = AnsibleLoader(None)
    assert res is not None

# Generated at 2022-06-20 23:58:26.050700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import tempfile
    import types
    import datetime

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence
    from ansible.module_utils.six import PY3

    # Patch this in for testing
    class MockVarsModule():
        def get_vars(self, loader, path, entities, cache=True):
            return dict(a=1, b=2, c=3)

    loader = AnsibleLoader(None, vault_secrets=None)
    loader._get_vars_files = MockVarsModule().get_vars

    # Byte Strings are not supported in Python 3.
    if PY3:
        assert type(loader.construct_binary(loader.construct_yaml_str(u'foo')))

# Generated at 2022-06-20 23:58:28.895134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Make sure that the custom loader class is used by Ansible
from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-20 23:58:29.420194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:58:31.356826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None
    assert hasattr(loader, 'construct_yaml_str')

# Generated at 2022-06-20 23:58:39.865567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test constructor
    d = AnsibleLoader(stream='[a,b]', vault_secrets=dict(a='abc'))
    assert hasattr(d, 'stream')
    assert hasattr(d, 'vault_secrets')
    assert hasattr(d, 'vault_password')
    assert hasattr(d, '_data')
    assert hasattr(d, '_file_name')
    assert hasattr(d, '_ansible_sphinx_syntax')
    assert d.vault_secrets['a'] == 'abc'

# Make sure we don't break anything with AnsibleLoader

# Generated at 2022-06-20 23:58:45.159426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  import sys
  # For testing purposes, use this Python script as the test data
  data = open( sys.argv[0] ).read()
  l = AnsibleLoader(data, '<string>', vault_secrets=None)
  l.get_single_data()

if __name__ == "__main__":
  test_AnsibleLoader()

# Generated at 2022-06-20 23:58:47.274887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Ensure that AnsibleLoader() can be instantiated
    """

    AnsibleLoader(file_name='myfile.yml')
    AnsibleLoader('myfile.yml')

# Generated at 2022-06-20 23:58:47.613176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:58:49.314983
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    loader = AnsibleLoader(io.BytesIO(b'2'))
    assert loader.get_single_data() == 2