

# Generated at 2022-06-20 23:50:51.859908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import six
    import string

    loader = AnsibleLoader(six.BytesIO(b'---\ntest: value\n'))
    obj = list(loader)

    assert isinstance(obj[0], dict)
    assert obj[0]['test'] == 'value'

    # Test legacy yaml loader
    test_string = '---\n'+"  - {0}".format('\n    '.join(['{0}: {0}'.format(x) for x in list(string.ascii_lowercase)]))
    loader = AnsibleLoader(six.BytesIO(test_string.encode('UTF-8')))
    obj = list(loader)
    assert isinstance(obj[0], list)

# Generated at 2022-06-20 23:50:55.918597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data_dir = os.path.join(os.path.dirname(__file__), 'yamlfiles')
    with open(os.path.join(test_data_dir, 'test.yml')) as ymlfile:
        # yaml.load(ymlfile)
        AnsibleLoader(ymlfile)

# Generated at 2022-06-20 23:51:07.524701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    def _test_decrypt(self, vault_secrets):
        raw = vault_secrets.get_secret('$ANSIBLE_VAULT;1.1;AES256')
        vault_secret = VaultSecret('$ANSIBLE_VAULT;1.1;AES256', password='changeme')
        key = vault_secret.get_decryption_key()
        decrypted = vault_secret.get_decrypted(raw, key)
        return decrypted


# Generated at 2022-06-20 23:51:12.076901
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' AnsibleLoader.__init__() is trivial '''
    from yaml.scanner import Scanner

    class MyLoader(AnsibleLoader):
        def __init__(self):
            pass
    myloader = MyLoader()
    assert myloader.file_name is None
    assert myloader.vault_secrets is None
    assert isinstance(myloader.scanner, Scanner)

# Generated at 2022-06-20 23:51:19.569159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # initialize instance
    a_loader = AnsibleLoader(stream='test_stream')
    # initialize arguments parameters values
    a_loader.file_name = 'test_file_name'
    a_loader.vault_secrets = ['vault_secret_1']

    # return parameter values
    assert a_loader.stream == 'test_stream'
    assert a_loader.file_name == 'test_file_name'
    assert a_loader.vault_secrets == ['vault_secret_1']

# Generated at 2022-06-20 23:51:23.048877
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .unittests.construct_data import data as test_data
    from .unittests import get_data

    # use the python loader and check that the output matches the
    # expected output from the yaml dumper.

    for (inp, outp) in test_data:
        yield check_data, inp, outp


# Generated at 2022-06-20 23:51:35.264855
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import types
    import yaml
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    OUTPUT_PATH = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))),
        "test/output/ansible_loader",
    )
    if not os.path.exists(OUTPUT_PATH):
        os.makedirs(OUTPUT_PATH)

# Generated at 2022-06-20 23:51:41.334713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
- hosts: all
  gather_facts: False
  tasks:
    - include: tasks/users.yml
      name: create users
'''
    data = AnsibleLoader(data).get_single_data()
    assert data[0]['hosts'] == 'all', 'got the wrong hosts value (== %s)' % data[0]['hosts']

# Generated at 2022-06-20 23:51:44.702234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = 'name: Steve D'
    l = AnsibleLoader(s, 'test_file.yml', [])
    l.get_single_data()

# Generated at 2022-06-20 23:51:45.671096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None)

# Generated at 2022-06-20 23:51:53.060853
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(file_name="../../../../../vars/main.yml", vault_secrets="../../../../../vault_pw.txt")
    assert ansible_loader
    print(ansible_loader)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-20 23:51:55.306887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleLoaderTest(AnsibleLoader):
        pass

    AnsibleLoaderTest()

# Generated at 2022-06-20 23:52:05.100826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from collections import OrderedDict
    with open('test/unit/parsing/yaml/dictionary_ordered.yaml', 'r') as stream:
        data = AnsibleLoader(stream).get_single_data()

    assert data == {'a': 1, 'b': 2, 'c': 3}

    with open('test/unit/parsing/yaml/dictionary_ordered.yaml', 'r') as stream:
        data = AnsibleLoader(stream, dict(yaml.SafeLoader.constructor.__dict__), object_pairs_hook=OrderedDict).get_single_data()

    assert data == OrderedDict([('a', 1), ('b', 2), ('c', 3)])

# Generated at 2022-06-20 23:52:06.049749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(AnsibleLoader)

# Generated at 2022-06-20 23:52:14.116969
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from sys import version_info
    py_version = version_info[0:2]

    class TestClassConstructor(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, vault_secrets=vault_secrets)

    stream = 'foo: bar'
    loader = TestClassConstructor(stream)

    assert isinstance(loader, Reader), 'loader should be an instance of Reader'
    if py_version < (2, 7):
        assert isinstance(loader, Scanner), 'loader should be an instance of Scanner'
    if py_version < (3, 3):
        assert isinstance(loader, Parser), 'loader should be an instance of Parser'

# Generated at 2022-06-20 23:52:25.046781
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import AnsibleLoader, Parser
    from ansible.module_utils._text import to_text
    import six

    test_yaml = to_text(u"""
    foo:
      - bar: baz
        key: value
    list:
      - item1
      - item2
    """
    )

    assert isinstance(AnsibleLoader, type)
    assert issubclass(AnsibleLoader, Parser)

    assert isinstance(AnsibleLoader, type)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert not issubclass('AnsibleLoader', AnsibleConstructor)

    # Need to ensure that '2' isn't treated as 2

# Generated at 2022-06-20 23:52:26.905154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(isinstance(loader, AnsibleLoader))

# Generated at 2022-06-20 23:52:28.344372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader([], None)
    assert loader is not None

# Generated at 2022-06-20 23:52:30.305638
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # check that you can create an instance of the class
    assert AnsibleLoader



# Generated at 2022-06-20 23:52:32.414259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''test_AnsibleLoader is used to test AnsibleLoader
    '''
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-20 23:52:48.151897
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def check(data, expected):
        class TestAnsibleLoader(AnsibleLoader):
            def __init__(self, stream, file_name=None, vault_secrets=None):
                AnsibleLoader.__init__(self, stream, file_name=None, vault_secrets=None)
            def construct_yaml_str(self, node):
                return node.value

        test = TestAnsibleLoader(data)
        d = test.get_single_data()
        assert expected == d


# Generated at 2022-06-20 23:52:55.091038
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        assert True
        return
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = StringIO(u'\u2603')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert data == u'\u2603'

# Generated at 2022-06-20 23:53:06.237613
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
      - hosts: all
        sudo: True
        tasks:
        - name: test
          command: /usr/bin/foo
          register: result
        - name: debug
          debug: var=result
      - hosts: other
        sudo: True
        tasks:
        - name: test
          command: /usr/bin/foo
          register: result
        - name: debug
          debug: var=result
        - name: debug
          debug:
            msg: |
              {{ result }}
    """

    loader = AnsibleLoader(data)
    results = loader.get_single_data()
    assert len(results) == 2

    assert results[0]['hosts'] == 'all'
    assert len(results[0]['tasks']) == 2


# Generated at 2022-06-20 23:53:09.204914
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream = "")
    assert loader.file_name is None
    assert loader.vault_secrets is None

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:53:13.384186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "nested_data: !!nested { 1: 2 }"
    loader = AnsibleLoader(data)
    yaml = loader.get_single_data()

    assert yaml["nested_data"][1] == 2

# Generated at 2022-06-20 23:53:17.087049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = (u'---\n'
            u' - hosts: local\n'
            u'   tasks:\n'
            u'    - command: foo')
    AnsibleLoader(data)

# Generated at 2022-06-20 23:53:21.178538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestLoader(AnsibleLoader):
        pass
    lines = '''
- a: b
- c: d
'''
    obj = TestLoader(lines).get_single_data()
    assert isinstance(obj, list)
    assert len(obj) == 2

# Generated at 2022-06-20 23:53:27.894399
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # To test vault with old ansible setup, we need to create a test vault passfile in a temporary directory.
    # Since ~/.ansible doesn't exist during pytest.
    # This path is the default path of AnsibleLoader.configured_vault_secrets
    ansible_config_base = os.path.join(os.path.expanduser("~"), ".ansible")

# Generated at 2022-06-20 23:53:31.553697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' Test the constructor of AnsibleLoader class'''


# Generated at 2022-06-20 23:53:38.935237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleloader = AnsibleLoader('', file_name='', vault_secrets=None)
    assert isinstance(ansibleloader, AnsibleLoader)
    assert isinstance(ansibleloader, Resolver)
    assert isinstance(ansibleloader, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(ansibleloader, Parser)
    else:
        assert isinstance(ansibleloader, Composer)
        assert isinstance(ansibleloader, Parser)
        assert isinstance(ansibleloader, Scanner)
        assert isinstance(ansibleloader, Reader)

# Generated at 2022-06-20 23:53:47.400438
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:53:56.346107
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from six import StringIO

    buf = StringIO()
    data = {
        'red': [1, 2, 3],
        'blue': {'a': 1, 'b': 2, 'c': 3},
        'green': {'a': 1, 'b': 2, 'c': 3}
    }
    AnsibleDumper(buf, default_flow_style=False).dump(data)
    raw = to_bytes(buf.getvalue())

# Generated at 2022-06-20 23:54:07.049557
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    if HAS_LIBYAML:
        from yaml import CSafeLoader as SafeLoader
        from yaml import CSafeDumper as SafeDumper
    else:
        from yaml import SafeLoader
        from yaml import SafeDumper
    
    from io import BytesIO
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-20 23:54:08.174162
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-20 23:54:10.650509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=invalid-name
    """Unit test for constructor of class AnsibleLoader"""
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:54:22.807636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test parsing objects with object_pairs_hook or dict in the construction
    '''
    import os
    import io
    from io import BytesIO
    from collections import OrderedDict
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    env_filename = '.test.yml'
    test_filename = 'test.yml'
    test_filename_expand = 'test.expand.yml'
    test_filename_yaml = 'test.yaml'
    test_filename_yaml_expand = 'test.expand.yaml'

    if HAS_LIBYAML and hasattr(yaml, 'CSafeLoader'):
        libyaml_loader = yaml.CSafeLoader

# Generated at 2022-06-20 23:54:29.693403
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('{}')
    assert(loader.construct_yaml_map == AnsibleConstructor.construct_yaml_map)

    # check we get our additional resolver methods
    assert(loader.resolve_yaml_null == Resolver.resolve_yaml_null)

    if HAS_LIBYAML:
        # check we get our additional parser methods
        assert(loader.peek_token() == Parser.peek_token(loader))

# Generated at 2022-06-20 23:54:36.682464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    sample1 = '''---
- hosts: localhost
  user: root
  tasks:
    - name: test
      ping:
      register: result
    - debug:
        msg: "{{result.success}}"
'''

    data = AnsibleLoader(sample1)
    assert data.get_single_data()

    sample2 = '''---
- hosts: localhost
  user: root
  tasks:
    - name: test
      ping:
      register: result
'''
    try:
        data = AnsibleLoader(sample2)
        assert data.get_single_data() is None
    except ValueError:
        pass

    sample3 = '''---
- hosts: localhost
  user: root
  tasks:
    - name: test
      ping:
      register: result
...
'''

# Generated at 2022-06-20 23:54:48.088372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    unit tests for AnsibleLoader, for coverage
    '''

    # test for _construct_mapping
    obj = AnsibleLoader('')
    assert obj._construct_mapping(None) == {}

    # test for _multi_constructor_check
    assert obj._multi_constructor_check(None) is True

    # test for round_trip_dict
    assert obj.round_trip_dict(None) == {}

    # test for include_yaml_0_1
    assert obj.include_yaml_0_1(None, None, None, None) == []

    # test for __init__
    assert AnsibleLoader([{}])._file_name == None
    assert AnsibleLoader([], file_name='/tmp/a')._file_name == '/tmp/a'
    assert AnsibleLoader

# Generated at 2022-06-20 23:54:57.708352
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Sanity checks of the AnsibleLoader class.
    """
    import os
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultEditor

    vault_pass = os.path.join(os.path.dirname(__file__), 'test_vault.txt')
    vault = VaultEditor(password_file=vault_pass)

    # A unittest variant of examples/playbook/vault.yml

# Generated at 2022-06-20 23:55:20.791165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    >>> a = AnsibleLoader(open('test_data/test_constructor_data.yaml'))
    >>> a.get_single_data()
    {'key_1': [{'hostvars': {'var_1': 'hello'}, 'hostname': 'host_1'}, {'hostvars': {'var_1': 'world'}, 'hostname': 'host_2'}, {'hostvars': {'var_1': '!'}, 'hostname': 'host_3'}]}
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-20 23:55:22.184669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor for AnsibleLoader is tested in test_vault.py
    pass

# Generated at 2022-06-20 23:55:33.656717
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test imported class
    assert AnsibleLoader


if HAS_LIBYAML:
    # unit test for constructor of class Parser
    def test_Parser():
        a = Parser(None)
        assert a

        # unit test for constructor of class Resolver
        def test_Resolver():
            b = Resolver()
            assert b
else:
    # unit test for constructor of class Reader
    def test_Reader():
        a = Reader(None)
        assert a

        # unit test for constructor of class Scanner
        def test_Scanner():
            b = Scanner()
            assert b
            try:
                b.peek_token()
            except AttributeError:
                pass

        # unit test for constructor of class Parser
        def test_Parser():
            c = Parser(None)
            assert c



# Generated at 2022-06-20 23:55:39.326480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    loader = AnsibleLoader( None, vault_secrets=None )
    assert loader.typemap[ u'!type' ] == loader.type
    assert loader.typemap[ u'!tag' ] == loader.tag
    assert loader.typemap[ u'!yaml.org,2002' ] == loader.tag
    assert loader.typemap[ u'!python' ] == loader.tag
    assert loader.typemap[ u'!python/name' ] == loader.tag
    assert loader.typemap[ u'!python/object' ] == loader.tag
    assert loader.typemap[ u'!python/module' ] == loader.tag
    assert loader.typemap[ u'!python/oct' ] == loader.tag

# Generated at 2022-06-20 23:55:40.681320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Doesn't need params, because AnsibleLoader doesn't create objects
    l = AnsibleLoader("mystream")  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-20 23:55:43.378455
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    users:
      - name: user1
      - name: user2
      - name: user3
    '''
    loader = AnsibleLoader(stream)
    users = loader.get_single_data()
    assert len(users['users']) == 3

# Generated at 2022-06-20 23:55:54.740457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.data import AnsibleSequence

    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader

    def assert_data_equal(d1, d2):
        assert d1 == d2
        assert type(d1) == type(d2)

    if not HAS_LIBYAML:
        assert AnsibleLoader is not None

    # Test constructor
    # ================

    # Simple test
    s = AnsibleLoader(None)
    assert s.file_name is None

    # Test vault_secrets
    s = AnsibleLoader(None, vault_secrets=[])
    assert s.vault_secrets == []

    # Test

# Generated at 2022-06-20 23:56:04.181063
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os.path

    # Build AnsibleLoader with input stream, file name as parameters
    file_name = AnsibleLoader.__name__
    data = '{"key":"value"}'
    parser = AnsibleLoader(data, file_name)

    assert parser.file_name == file_name
    assert parser.name == file_name
    assert parser.use_file_name == file_name
    assert parser.vault_secrets == []

    # Load first document from stream
    doc = parser.get_single_data()

    # Expected result:
    #   doc: {'key': 'value'}
    #   parser.stream_position: 14
    #   parser.file_name: None
    #   parser.name: None
    #   parser.use_file_name: None
    assert doc

# Generated at 2022-06-20 23:56:09.377997
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import _fixtures
    datastring = _fixtures.YAML_VARS_SINGLE
    aloader = AnsibleLoader(datastring, file_name='myfile.yml')
    assert aloader.get_single_data() == {u'number': 3}
    assert aloader.file_name == 'myfile.yml'
    datastring = _fixtures.YAML_VARS_MULTI
    aloader = AnsibleLoader(datastring)
    assert aloader.get_single_data() == {u'name': 'bob'}
    for data in aloader:
        assert data == {u'name': 'joe'}
    assert aloader.file_name == None

# Generated at 2022-06-20 23:56:13.443188
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_str')
    assert hasattr(loader, 'construct_yaml_seq')

# Generated at 2022-06-20 23:56:53.414640
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime
    import os
    import tempfile

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    def test_ansible_constructor():
        obj = dict(foo='bar', bam=100, baz=dict(fuz=100))
        data = '''
        bam: 100
        baz:
            fuz: 100
        foo: bar
        '''
        loader = AnsibleLoader(data)
        assert loader.get_single_data() == obj
        assert type(loader.get_single_data()) == AnsibleMapping
        assert loader.get_single_data()['baz'] == AnsibleMapping
        assert loader.get_single_data()['baz']['fuz'] == 100


# Generated at 2022-06-20 23:57:02.214342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.reserved import RESERVED_DEFAULTS

    RESERVED_DEFAULTS['foobar'] = 'test'
    loader = AnsibleLoader('foobar: !default "test"')
    result = loader.get_single_data()
    assert result == {'foobar': 'test'}

    RESERVED_DEFAULTS['foobar'] = 'test2'
    loader = AnsibleLoader('foobar: !default "test"')
    result = loader.get_single_data()
    assert result == {'foobar': 'test'}
    del RESERVED_DEFAULTS['foobar']

# Generated at 2022-06-20 23:57:05.720707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unicode import to_bytes
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert isinstance(AnsibleLoader(to_bytes(':')).get_single_data(), AnsibleUnicode)

# Generated at 2022-06-20 23:57:11.903585
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(b'')
    # the string ``u''`` is used here instead of the b'' because we are testing the
    # object construction, and there is no need to test if the constructor can handle bytes.
    # The name of the test is ``test_AnsibleLoader`` was chosen to reflect this.
    assert loader.construct_scalar(u'tag:yaml.org,2002:str', u'') == AnsibleUnicode(u'')

# Generated at 2022-06-20 23:57:14.440884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Initialize the instance
    obj = AnsibleLoader('stream', 'file_name', 'vault_secrets')

    # Do a dry run to verify the class is constructed correctly
    assert obj is not None

# Generated at 2022-06-20 23:57:16.393586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleLoader = AnsibleLoader("")
    assert ansibleLoader


# Generated at 2022-06-20 23:57:25.451748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Note: This is not a real test but just a simple way to
    # to generate the test code of the loaders by using
    # the loaders themselves.
    import sys
    import inspect

    def generate_ansible_loader(loader_class, filename='/dev/null'):
        class MockStream(object):
            def __init__(self):
                self.data = ''

            def read(self):
                return self.data

            def __len__(self):
                return len(self.data)

        import ansible.parsing.yaml.loader
        ansible_loader = loader_class(MockStream())
        test_filename = inspect.getfile(loader_class)
        output_filename = "%s.test" % test_filename


# Generated at 2022-06-20 23:57:30.968427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.vars import VariableManager

    class DummyInventory(object):
        def get_vars(self, *args):
            return {
                'group': {'foo': 'bar'},
                'hostvars': {
                    'testhost': {
                        'baz': 'quux'
                    }
                }
            }
    loader_obj = AnsibleLoader(stream='{"test": "{{ foo }}", "test2": "{{ baz }}"}')
    # pylint: disable=too-many-arguments
    vars_obj = VariableManager(loader=loader_obj, inventory=DummyInventory())
    data = loader_obj.get_single_data()
    vars_obj.add_host_vars('testhost', data['testhost'])
    vars_obj.add_

# Generated at 2022-06-20 23:57:36.275093
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "A test string"
    vault_secrets = "A test string"
    file_name = "A test file name"
    try:
        yaml.AnsibleLoader(stream, file_name, vault_secrets)
        assert True
    except:
        assert False

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:57:47.288541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # load a test file
    from ansible.utils.vars import load_extra_vars
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    stream = open('test_loader.yaml')
    loader = AnsibleLoader(stream, vault_secrets=['secret'])
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert to_text(data['test plain']) == 'test1'
    assert isinstance(data['test plain'], str)
    assert isinstance(data['test vault'], AnsibleVaultEncryptedUnicode)
    assert to_text(data['test vault']) == 'test2'

# Generated at 2022-06-20 23:59:01.511981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('')

# Generated at 2022-06-20 23:59:05.381939
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import doctest
    # we don't want to run the entire yaml test suite as a dependency so we will just
    # load the yaml module and standard test cases
    results = doctest.testmod(m=AnsibleLoader)
    assert results[0] == 0

# Generated at 2022-06-20 23:59:06.574751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleConstructor()


# Generated at 2022-06-20 23:59:10.250433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    class TestStream(io.TextIOBase):
        def __init__(self, value):
            self.value = value

        def read(self):
            return self.value

    loader = AnsibleLoader(TestStream('test'))
    assert loader.load(TestStream('test')) == u'test'

# Generated at 2022-06-20 23:59:19.961886
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Resolver)

# Backwards compatibility for class AnsibleLoader for 2.2 and 2.3
# Since 2.4, AnsibleLoader is a subclass of Parser, Resolver, and AnsibleConstructor
# Since 2.3, AnsibleLoader is a subclass of Parser, Resolver, and AnsibleConstructor
# Before 2.3, AnsibleLoader is a subclass of Reader, Scanner, Composer, Parser, Resolver, and AnsibleConstructor
import sys
if sys.version_info >= (2, 4):
    if sys.version_info < (2, 3):
        assert issubclass(AnsibleLoader, (Reader, Scanner, Composer, Parser, Resolver, AnsibleConstructor))

# Generated at 2022-06-20 23:59:29.645223
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import tempfile
    from ansible.vars.unsafe_proxy import wrap_var, is_unsafe_proxy


# Generated at 2022-06-20 23:59:34.754931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    with open("../../test/units/parsing/yaml/test_constructor/basic.yml") as f:
        data = f.read()

    loader = AnsibleLoader(data)
    result1 = loader.get_single_data()
    assert result1 == {'name': 'value'}

    loader = AnsibleLoader(data, vault_secrets=['password'])
    result2 = loader.get_single_data()
    assert result2 == {'name': 'value'}

# Generated at 2022-06-20 23:59:36.513952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
	from ansible.parsing.vault import VaultLib
	from ansible.parsing.vault import VaultSecret
	from ansible.parsing.vault import Answers
	pass

# Generated at 2022-06-20 23:59:41.623968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # Loader class unit test requires a string containing a yaml file, but since
  # we are only testing the constructor, we can just pass in a string with an
  # empty dict as the content of the yaml file.
  loader = AnsibleLoader("{}", "test_file")
  assert loader.file_name == "test_file"
  assert not loader.vault_secrets

# Generated at 2022-06-20 23:59:42.594197
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

