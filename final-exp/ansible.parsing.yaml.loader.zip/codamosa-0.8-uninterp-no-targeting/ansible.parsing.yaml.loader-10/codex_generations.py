

# Generated at 2022-06-20 23:50:53.483470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from yaml.nodes import MappingNode
    from yaml.resolver import Resolver
    from sys import version_info
    from ansible.constants import HAS_RUAML

    # If the PyYaml loader is not available, the import failed and we should
    # not do the unittest.
    if not HAS_RUAML:
        return

    # This tests if the class is available
    obj = AnsibleLoader(None)
    assert isinstance(obj, AnsibleLoader)

    # The AnsibleLoader class is only enabled if pyyaml loader is
    # not available.
    # Test if the methods are enabled
    assert hasattr

# Generated at 2022-06-20 23:51:05.067617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        expected_class_name = 'yaml.parser.Parser'
    else:
        expected_class_name = 'yaml.parser.Parser'

    assert AnsibleLoader.__bases__[0].__name__ == expected_class_name, "AnsibleLoader inherits from wrong class"
    assert AnsibleLoader.__bases__[1].__name__ == 'yaml.constructor.AnsibleConstructor', "AnsibleLoader inherits from wrong class"
    assert AnsibleLoader.__bases__[2].__name__ == 'yaml.resolver.Resolver', "AnsibleLoader inherits from wrong class"
    assert len(AnsibleLoader.__bases__) == 3, "AnsibleLoader inherits from too many classes"

# Generated at 2022-06-20 23:51:09.883902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader

# AnsibleLoader is used for yaml loading where the file name is needed
# by the ansible constructor.  By default, the file name is None, but
# can be set at runtime.  The Loader will keep a reference to the vault
# secrets so that they can be passed to the decryptor

# Generated at 2022-06-20 23:51:12.164677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def __init__(self, stream, file_name=None, vault_secrets=None):
        pass



# Generated at 2022-06-20 23:51:22.419391
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, "construct_yaml_map")
    assert hasattr(AnsibleLoader, "construct_yaml_seq")
    assert hasattr(AnsibleLoader, "construct_undefined")
    assert hasattr(AnsibleLoader, "construct_yaml_null")
    assert hasattr(AnsibleLoader, "construct_yaml_str")
    assert hasattr(AnsibleLoader, "construct_yaml_comment")
    assert hasattr(AnsibleLoader, "construct_yaml_binary")
    assert hasattr(AnsibleLoader, "construct_yaml_int")
    assert hasattr(AnsibleLoader, "construct_yaml_float")
    assert hasattr(AnsibleLoader, "construct_yaml_timestamp")

# Generated at 2022-06-20 23:51:24.117444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader('')
    assert isinstance(obj, object)

# Generated at 2022-06-20 23:51:30.380253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ansible.parsing.yaml.constructor.AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleLoader
    assert AnsibleLoader is not None

    # ansible.parsing.yaml.constructor.AnsibleConstructor
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    assert AnsibleConstructor is not None

# Generated at 2022-06-20 23:51:34.906003
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('lib/ansible/parsing/yaml/module_utils/tests/sample.yml')
    yaml = AnsibleLoader(stream)
    doc = yaml.get_single_data()
    assert doc == {'a': {'b': 'c'}}

# Generated at 2022-06-20 23:51:38.973908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # NOTE: this is just a simple test of the class creation, not
    # a functional test of the class.

    obj = AnsibleLoader(file_name='example', vault_secrets=None)
    assert obj is not None
    assert isinstance(obj, Resolver)

# Generated at 2022-06-20 23:51:48.204673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test bool constructor
    AnsibleLoader('True', '/some/file')
    AnsibleLoader('false', '/some/file')
    # Test int constructor
    AnsibleLoader('0', '/some/file')
    # Test string constructor
    AnsibleLoader('some string', '/some/file')
    # Test list constructor
    AnsibleLoader('[1,2,3]', '/some/file')
    AnsibleLoader('{1:2,3:4}', '/some/file')
    # Test sequence constructor
    AnsibleLoader('[1,2,3]', '/some/file')

    # FIXME: Howto test scalar constructor?
    # FIXME: Howto test mapping constructor?

# Generated at 2022-06-20 23:51:53.246170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not HAS_LIBYAML, 'The AnsibleLoader class should not exist when libyaml is installed.'
    assert 'AnsibleLoader' in globals()

# Generated at 2022-06-20 23:52:00.224809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Gives correct value for line number for last line
    data = "---\n- hosts: all\n  tasks: |\n    line 1\n    line 2\n"
    loader = AnsibleLoader(data)
    assert loader.get_single_data()[1] == {'tasks': 'line 1\nline 2\n', 'hosts': 'all'}
    assert loader.last_line_of_data == 6

# Generated at 2022-06-20 23:52:02.706831
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader

# pylint: disable=protected-access

# Generated at 2022-06-20 23:52:12.323299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-20 23:52:22.375308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    # Test with old interface
    # Test with old interface
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream):
            stream = io.StringIO(stream)
            super(TestAnsibleLoader, self).__init__(stream)
        def compose_document(self):
            self.get_event()
            return self.construct_document(None)

    test_data = u"""
    msg: '{{ TRUE }}'
    """
    loader = TestAnsibleLoader(test_data)
    data = loader.compose_document()
    assert data['msg']



# Generated at 2022-06-20 23:52:32.771111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

# Generated at 2022-06-20 23:52:38.709984
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    # Test the Round-Trip
    al = AnsibleLoader(u"hello\x00:")
    al.get_data()
    assert al.get_data() == {u'hello\x00': None}

    # Test unicode repr
    assert repr(al) == repr(u'hello\x00:')
    assert repr(al) != u'hello:', 'AnsibleLoader is a unicode subclass.'
    assert isinstance(repr(al), AnsibleUnicode), 'AnsibleLoader is a unicode subclass.'

    # Test the Round-Trip with unicode
    al = AnsibleLoader(u"\u2022:")

# Generated at 2022-06-20 23:52:50.562624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''))
        ]
    )

    # Since we are passing an empty play_source, we can expect
    # the task to bail out early before gather_facts.

# Generated at 2022-06-20 23:53:00.820791
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode, AnsibleNative
    data = u"foo: bar\nbaz: [ 1, 2, 3 ]"
    loader = AnsibleLoader(data, vault_secrets=None)
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert loader.get_single_data() == {u'foo':u'bar', u'baz':[1,2,3]}
    assert loader.get_single_data() is None
    assert loader.get_single_data() is None

# Generated at 2022-06-20 23:53:01.798638
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name='...')

# Generated at 2022-06-20 23:53:06.280429
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:11.205535
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #pylint: disable=protected-access

    loader = AnsibleLoader(file_name="foobar")
    assert loader._file_name == "foobar"

    loader = AnsibleLoader(vault_secrets=["foo", "bar"])
    assert loader._vault_secrets == ["foo", "bar"]

    loader = AnsibleLoader(file_name="foobar", vault_secrets=["foo", "bar"])
    assert loader._file_name == "foobar"
    assert loader._vault_secrets == ["foo", "bar"]

# Generated at 2022-06-20 23:53:13.280843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(["test"])
    assert x.stream == ["test"]


# Generated at 2022-06-20 23:53:23.443203
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from units.compat.mock import patch
    from ansible.parsing.yaml.constructor import AnsibleConstructorError

    # TODO: true unit test for this class(es)
    assert AnsibleLoader

    # No such file: file_name='/no/such/file'
    stream = """
    ---
    - include: /no/such/file
    """
    with patch.object(AnsibleConstructor, 'get_single_data') as get_single_data_mock:
        get_single_data_mock.side_effect = AnsibleConstructorError('AnsibleConstructorError: failed to find included file')
        load = AnsibleLoader(stream)
        assert load is not None

# Generated at 2022-06-20 23:53:25.208666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    a = AnsibleConstructor()

# Generated at 2022-06-20 23:53:30.226435
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # re-run this test for different yaml libs
    import os
    from ansible.parsing.vault import VaultLib
    example_yaml_file = os.path.join(os.path.dirname(__file__), 'example_vault.yml')
    loader = AnsibleLoader(open(example_yaml_file, 'r'), file_name=example_yaml_file, vault_secrets=['42', 'this is the secret'])
    vault_obj = {}
    vault_obj['42'] = VaultLib('this is the secret')
    data = loader.get_single_data()
    assert data['one'] == 'foo'
    assert data['two'] == 'bar'
    assert data['three'] == 'baz'
    assert data['four'] == vault_obj['42'].dec

# Generated at 2022-06-20 23:53:31.448322
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:53:31.976827
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:33.663467
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert not loader.is_multi_document_yaml()
    assert loader.get_single_data() is None

# Generated at 2022-06-20 23:53:34.512617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None


# Generated at 2022-06-20 23:53:53.417327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=no-member

    #from ansible.parsing.yaml.loader import AnsibleLoader
    """Python equivalent of the following yaml
    # Empty string
    - ""

    # Empty string with null
    - "~"

    # Empty string with null
    - ~

    # Empty list
    - []

    # Empty list with null
    - "~"

    # Empty list with null
    - ~

    # Empty dictionary
    - {}

    # Empty dictionary with null
    - "~"

    # Empty dictionary with null
    - ~
    """

    # construct from str
    # Dumper is not using any constructor(if you are using default dumper)

# Generated at 2022-06-20 23:53:54.752946
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader("")
    assert x is not None


# Generated at 2022-06-20 23:53:56.066093
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:53:59.980692
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Tests that AnsibleLoader is a subclass of both Parser and AnsibleConstructor
    '''

    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-20 23:54:02.594945
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor) and isinstance(loader, Resolver)

# Generated at 2022-06-20 23:54:10.653930
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    contents = """
foo:
  - hosts:
      - 127.0.0.1
    tasks:
      - name: ping
        ping:
    vars:
      - foo: bar
    with_items:
      - 1
      - 2
      - 3
"""

    loader = AnsibleLoader(contents, vault_secrets=dict(vault_password='password'))
    data = loader.get_single_data()

    assert 'foo' in data
    assert data['foo'] is not None
    assert isinstance(data['foo'], list)

    assert 'hosts' in data['foo'][0]
    assert data['foo'][0]['hosts'][0] == '127.0.0.1'

    assert 'tasks' in data['foo'][0]

# Generated at 2022-06-20 23:54:13.231276
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/dev/null', 'r')
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader is not None

# Generated at 2022-06-20 23:54:25.026859
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = {}
    test_data['hello'] = 'world'
    test_data['a'] = {
        'b': {
            'c': 5
        }
    }
    test_data['d'] = [
        { 'e': 6 },
        { 'f': 7 }
    ]

    # test with YAML constructed automatically by PyYAML
    ansible_loader = AnsibleLoader(None, file_name='<test_loader.yml>')
    ansible_loader.update(test_data)
    assert type(ansible_loader).__name__ == 'AnsibleLoader'
    assert type(next(iter(ansible_loader))).__name__ == 'CommentedMap'

# Generated at 2022-06-20 23:54:35.158843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import ansible.constants as C

    if not sys.version_info[0] == 2:
        print('The unittest is only supported in Python 2.x')
        sys.exit(0)

    os.environ['HOME'] = '/home/jenkins'

    test_path = os.path.join(C.TEST_DIR, 'sanity', 'test.yml')

    data = u'---\n'
    data += u'- !vault |\n'
    data += u'    $ANSIBLE_VAULT;1.1;AES256\n'
    data += u'    363138363730393238313365636136336638323963336638626166306239393730333432306231633537\n'

# Generated at 2022-06-20 23:54:46.668790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    from io import StringIO

    # The bare string '$ANSIBLE_VAULT' is
    # encrypted so this test can run in the
    # clear without exposing the vault secrets.
    vault_secrets = {'$ANSIBLE_VAULT': '$ANSIBLE_VAULT'}

    # data which is not encrypted
    unencrypted_data = u'hello world !\n'

    # same data but encrypted
    encrypted_data = u'!vault |\n          $ANSIBLE_VAULT\n          ZXhhbXBsZQ==\n'

    # build a document from unencrypted data
    data = StringIO(unencrypted_data)

# Generated at 2022-06-20 23:55:13.829970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    yaml_str = """
---
test: !vault |
          $ANSIBLE_VAULT;1.1;AES256
          30663739366634303262373636343063653936653631383830353433356533386136656532646331
          34653765323662303665333035363864343338303561
    """
    yaml_obj = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(yaml_obj['test'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-20 23:55:23.488964
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:55:33.948340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Load a simple YAML doc
    teststr = '''
pet:
  name: "spike"
  species: dog
  age: 7
  favorite_treat: "bone"
  friends:
    - "mia"
    - "murphy"
    - "noodles"
'''
    teststr = teststr[1:]
    loader = AnsibleLoader(teststr)
    data = loader.get_single_data()
    assert data == {'pet': {'name': 'spike', 'species': 'dog', 'age': 7, 'favorite_treat': 'bone', 'friends': ['mia', 'murphy', 'noodles']}}

# Generated at 2022-06-20 23:55:35.819763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader_test = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert ansible_loader_test is not None

# Generated at 2022-06-20 23:55:38.467894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test to verify that the correct class is constructed'''
    if HAS_LIBYAML:
        assert AnsibleLoader is Parser
    else:
        assert AnsibleLoader is Reader

# Generated at 2022-06-20 23:55:43.686580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None, file_name=None, vault_secrets=None)
    from ansible.parsing.yaml.constructor import ConstructorError, DuplicateKeyError
    try:
        obj = AnsibleLoader(None, file_name=None, vault_secrets=None)
    except (ConstructorError, DuplicateKeyError):
        pass
    else:
        assert False, "AnsibleLoader() should raise ConstructorError or DuplicateKeyError"

# Generated at 2022-06-20 23:55:44.831301
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("TEST", AnsibleLoader)

# Generated at 2022-06-20 23:55:56.054938
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:55:58.528722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader('---\n# comment')
    assert al.get_single_data() == "# comment"
    assert al.get_single_data() is None

# Generated at 2022-06-20 23:56:00.141790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from nose.tools import assert_true

    assert_true(AnsibleLoader)

# Generated at 2022-06-20 23:56:45.231784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultSecretStd
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_file = "test/unit/parsing/yaml/loader/vault.yml"

    with open(test_file, 'r') as stream:
        vault_secrets = [VaultSecret(password='pass', _process_secrets={'stdin': True}, force_stdin=True)]
        loader = AnsibleLoader(stream, file_name=test_file, vault_secrets=vault_secrets)

# Generated at 2022-06-20 23:56:47.977995
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ex_str = """
    ---
    - hosts: test_host
      tasks:
         - name: ping the control node
           ping:
    """
    loader = AnsibleLoader(ex_str)
    loader.get_single_data()

# Generated at 2022-06-20 23:56:51.069154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import needed for side effects of registering callbacks
    import ansible.parsing.yaml.objects

    loader = AnsibleLoader('''---
        - hosts: all
          tasks:
            - name: test
              shell: echo hi
        ''')
    assert isinstance(loader, AnsibleLoader)
    assert not hasattr(loader, 'vault_secrets')

# Generated at 2022-06-20 23:56:57.116738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import os
    # import glob

    # _, _, items = next(os.walk('lib/ansible/modules/'))
    # for item in items:
    #     if item.endswith('.py'):
    #         print('lib/ansible/modules/' + item)

    loader = AnsibleLoader(open('./test/mocks/modules/foo.yml', 'r'))

test_AnsibleLoader()

# Generated at 2022-06-20 23:57:00.572605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    assert(issubclass(AnsibleLoader, AnsibleConstructor))

# Generated at 2022-06-20 23:57:10.043848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from yaml import load, dump
    import sys
    import os

    # First we monkeypatch these methods whose sole purpose is to call sys.exit()
    #
    # 1. AnsibleLoader.construct_yaml_map() calls AnsibleLoader.check_data_under_key()
    # 2. AnsibleLoader.check_data_under_key() calls AnsibleLoader.display_params()
    # 3. AnsibleLoader.display_params() calls sys.exit()
    def pass_me(*args, **kwargs):
        return

    AnsibleConstructor.__init__ = pass_me
    AnsibleConstructor.check_data_under_key = pass_me
    AnsibleConstructor.display_params

# Generated at 2022-06-20 23:57:13.441353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
- test: 0
- ansible: 1
"""
    file_name = "my fake file name"
    vault_secrets = ['my fake vault secrets']

    AnsibleLoader(data, file_name, vault_secrets)

# Generated at 2022-06-20 23:57:18.077502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Construct the object
    s = AnsibleLoader("")
    # Check if type is a AnsibleConstructor
    assert isinstance(s, AnsibleConstructor)
    # Check if type is a Parser
    assert isinstance(s, Parser)

# Generated at 2022-06-20 23:57:22.118440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='/foo')
    assert loader.file_name == '/foo'
    loader = AnsibleLoader(file_name='/bar')
    assert loader.file_name == '/bar'

    # from AnsibleLoader.__init__
    loader.vault_secrets = None
    loader.host_names = []

# Generated at 2022-06-20 23:57:29.041457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-return-statements
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MyDumper(AnsibleDumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(MyDumper, self).increase_indent(flow, False)

    class Constructor(AnsibleConstructor):
        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))


# Generated at 2022-06-20 23:58:47.107830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'add_constructor')

# Generated at 2022-06-20 23:58:49.201417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    if not HAS_LIBYAML:
        return

    a = AnsibleLoader(None, None)
    assert a


# Generated at 2022-06-20 23:58:49.953577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)
    assert True

# Generated at 2022-06-20 23:58:54.758394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This test is only applicable on python 2.6-2.7
    # Python3 uses Parser class of pyyaml instead of AnsibleLoader.__init__
    # Hence, we can't test AnsibleLoader.__init__ on Python3
    if HAS_LIBYAML:
        return

    # Test that AnsibleConstructor.__init__ is called when initializing AnsibleLoader
    import types
    import warnings

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            self.file_name = file_name
            self.vault_secrets = vault_secrets

    original_constructor = AnsibleLoader.__init__

# Generated at 2022-06-20 23:58:55.978642
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader.__init__

# Generated at 2022-06-20 23:59:02.333921
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    stream = StringIO.StringIO("""
    - hosts: localhost
      tasks:
      - name: test
        debug: msg="AnsibleLoader test"
    """)
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data['hosts'] == 'localhost'
    assert data['tasks'][0]['name'] == 'test'
    assert data['tasks'][0]['debug']['msg'] == 'AnsibleLoader test'

# Generated at 2022-06-20 23:59:11.807931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
    - hosts: localhost
      tasks:
       - debug:
           msg: Hello world
    '''

    loader = AnsibleLoader(data, "test_AnsibleLoader")
    data = loader.get_single_data()

    # check hosts key
    assert "hosts" in data
    assert data['hosts'] == "localhost"

    # check tasks key
    assert "tasks" in data
    assert isinstance(data['tasks'], list)
    assert len(data['tasks']) == 1
    assert isinstance(data['tasks'][0], dict)

    task = data['tasks'][0]
    assert "debug" in task
    assert "msg" in task["debug"]
    assert task["debug"]["msg"] == "Hello world"

# Generated at 2022-06-20 23:59:12.522090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader, (object,))

# Generated at 2022-06-20 23:59:13.244115
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:59:19.265680
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = u'''
---
- name: "test1"
  debug:
    foo: "bar"
- name: "test2"
  include: "{{ playbook_dir }}/include.yml"
- name: "test3"
  include_vars: "{{ playbook_dir }}/include.yml"
'''
    a = AnsibleLoader(s, 'myfile.yml')
    a.get_single_data()