

# Generated at 2022-06-20 23:50:50.429492
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test with stringIO object
    from StringIO import StringIO
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper
    v_str = "VARIABLE STRING"
    o_str = "STRING"
    o_int = 1
    o_float = 1.1
    o_bool = True
    o_list = [o_str, o_int, o_float, o_bool]
    o_dict = dict(a=o_str, b=o_int, c=o_float, d=o_bool, e=o_list, f=dict(x=o_int, y=o_int, z=o_int))

# Generated at 2022-06-20 23:50:53.118648
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test_AnsibleLoader
    assert(AnsibleLoader)
    # test_AnsibleConstructor
    assert(AnsibleConstructor)

# Generated at 2022-06-20 23:50:57.708119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(stream="")

    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert isinstance(loader.get_single_data(file_name="test"), AnsibleUnicode)
    assert isinstance(loader.get_single_data(file_name="test", vault_secrets=[]), AnsibleUnicode)

# Generated at 2022-06-20 23:51:08.655800
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode
    from ansible.parsing.yaml.nodes import AnsibleMappingNode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    import sys
    # Python 3 support
    if sys.version_info[0:3] >= (3, 0, 0):
        import io
        import _yaml

# Generated at 2022-06-20 23:51:16.120799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # TODO: find a way to do this with setUp()
    for x in ['_aliases', '_construct_mapping', '_construct_yaml_map', '_mapping_tag', '_multi_constructor']:
        setattr(AnsibleLoader, x, getattr(AnsibleConstructor, x))

    data = AnsibleLoader(u"{ foo: bar }").get_single_data()
    assert data
    assert isinstance(data, dict)
    assert u'bar' == data[u'foo']

    data = AnsibleLoader(u"{ foo: { bar: baz }}").get_single_data()
    assert data
   

# Generated at 2022-06-20 23:51:17.523547
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert AnsibleConstructor
    assert Resolver

# Generated at 2022-06-20 23:51:18.720710
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleConstructor is not None

# Generated at 2022-06-20 23:51:25.563858
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    call_order = []

    class MockLoader(AnsibleLoader):
        def compose_node(self, parent, index):
            call_order.append('compose_node')

        def construct_yaml_map(self, node):
            call_order.append('construct_yaml_map')
            return AnsibleConstructor.construct_yaml_map(self, node)

        def construct_yaml_seq(self, node):
            call_order.append('construct_yaml_seq')
            return AnsibleConstructor.construct_yaml_seq(self, node)


# Generated at 2022-06-20 23:51:26.599626
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader([])

# Generated at 2022-06-20 23:51:38.316723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    test_data = StringIO.StringIO()
    test_data.write('---\n')
    test_data.write('- hosts: localhost\n')
    test_data.write('  pre_tasks:\n')
    test_data.write('    - debug: msg="pre_task"\n')
    test_data.write('  tasks:\n')
    test_data.write('    - debug: msg="task 1"\n')
    test_data.write('    - debug: msg="task 2"\n')
    test_data.write('  post_tasks:\n')
    test_data.write('    - debug: msg="post_task"\n')
    test_data.seek(0)


# Generated at 2022-06-20 23:51:50.060792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = "user_list:\n"\
            "- name: kate\n"\
            "  uid: 1000\n"\
            "  shell: /bin/bash\n"\
            "  groups: [root,vagrant]\n"\
            "  sudo: [ 'ALL=(ALL) NOPASSWD:ALL' ]\n"\
            "  ssh_key: <%= ENV['HOME'] %>/.ssh/id_rsa\n"\
            "  password: <%= my_password %>\n"\
            "- name: larry\n"\
            "  uid: 1001\n"\
            "  groups: [developers,users]\n"\
            "  password: <%= my_pwd %>\n"

    loader

# Generated at 2022-06-20 23:51:51.528399
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# AnsibleLoader instantiation test

# Generated at 2022-06-20 23:52:03.411092
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.Loader = AnsibleLoader

    with open('test_constructor.yml', 'r') as stream:
        data = yaml.safe_load(stream)
    assert data == {'a': 'b', 'c': 'd'}

    with open('test_constructor_list.yml', 'r') as stream:
        data = yaml.safe_load(stream)
    assert data == ['a', 'b', 'c']

    with open('test_constructor_dict_in_list.yml', 'r') as stream:
        data = yaml.safe_load(stream)
    assert data == [{'a': 'b'}, {'c': 'd'}]


# Generated at 2022-06-20 23:52:12.722117
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    def to_yaml(data, stream):
        dumper = AnsibleDumper(stream=stream)
        dumper.open()
        dumper.represent(data)
        dumper.close()


# Generated at 2022-06-20 23:52:13.436527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:52:14.317627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()


# Generated at 2022-06-20 23:52:20.387138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_map(None, None), dict)
    assert isinstance(loader.construct_yaml_seq(None, None), list)
    assert isinstance(loader.construct_yaml_str(None, None), str)
    assert isinstance(loader.construct_yaml_unicode(None, None), str)
    assert isinstance(loader.construct_yaml_seq(None, None), list)
    assert isinstance(loader.construct_yaml_int(None), int)
    assert isinstance(loader.construct_yaml_bool(None), bool)
    assert isinstance(loader.construct_yaml_float(None, None), float)

# Generated at 2022-06-20 23:52:21.449381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

# Generated at 2022-06-20 23:52:24.174999
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # construct an instance of the class and run __init__
    ansible_loader = AnsibleLoader(None, vault_secrets=None)
    # assert __init__ does not return any value
    assert ansible_loader is not None

# Generated at 2022-06-20 23:52:33.407458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleDumper(object):
        pass
    # Requires libyaml
    if HAS_LIBYAML:
        try:
            AnsibleLoader((1,2))
        except:
            pass
        else:
            assert False, "AnsibleLoader did not raise TypeError on no arguments"

# Generated at 2022-06-20 23:52:47.009457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This test case covers: ansible/module_utils/common/yaml.py AnsibleLoader class
    """
    # Skip this test case if libyaml is present
    if HAS_LIBYAML:
        return

    fake_stream = None
    fake_file_name = None
    fake_vault_secrets = None
    ansible_constructor = AnsibleLoader(fake_stream, fake_file_name, fake_vault_secrets)
    assert isinstance(ansible_constructor, AnsibleLoader)

# Generated at 2022-06-20 23:52:55.240836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test sanitizing files
    assert AnsibleLoader.sanitize_files({'a': 'b', 'b': 'c'}, '/some/path/') == {'a': '/some/path/b', 'b': '/some/path/c'}
    assert AnsibleLoader.sanitize_files({'a': 'b', 'b': ['c', 'd', 'e']}, '/some/path/') == {'a': '/some/path/b', 'b': ['/some/path/c', '/some/path/d', '/some/path/e']}

# Generated at 2022-06-20 23:52:55.828500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:53:07.953120
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os

    # Get text
    file_name = os.path.join(os.path.dirname(__file__), 'loader.yml')
    with open(file_name) as f:
        text = f.read()
    stream = text.decode(sys.getdefaultencoding()).splitlines()

    ansible_loader = AnsibleLoader(stream)

    # load into an AnsibleDict
    data = {}
    for token in ansible_loader.get_tokens():
        if token[0] is not None:
            data.setdefault(token[0], []).append(token[1])

    # check AnsibleDict
    assert data == {'key1': ['value1'], 'key2': ['value2'], 'key3': ['value3']}

# Generated at 2022-06-20 23:53:09.563713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'add_implicit_resolver')
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-20 23:53:13.757317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault = VaultLib([])
    loader = AnsibleLoader(None, vault_secrets=vault)
    assert hasattr(loader, 'construct_yaml_map')

# Generated at 2022-06-20 23:53:24.936857
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream):
            AnsibleLoader.__init__(self, stream)

        def construct_yaml_str(self, node):
            # Override the default string handling function
            # to always return unicode objects
            return AnsibleUnicode(self.construct_scalar(node))

        def construct_yaml_seq(self, node):
            # Override the default list handling function
            # to always return lists
            return AnsibleSequence(self.construct_sequence(node))

# Generated at 2022-06-20 23:53:29.637218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    ansible_loader = AnsibleLoader("{ a: 1 }", file_name="fake_name", vault_secrets=None)
    data = ansible_loader.get_single_data()
    assert type(data) is AnsibleMapping
    assert data.get("a") == 1

# Generated at 2022-06-20 23:53:31.528035
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:53:32.946605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert hasattr(loader, 'check_data_against_schema')

# Generated at 2022-06-20 23:53:54.296285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.plugins.vars import vault

    def test(loader, node):
        return loader.construct_yaml_str([node])


# Generated at 2022-06-20 23:53:56.819051
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_AnsibleLoader = AnsibleLoader(stream="foo")
    assert test_AnsibleLoader.stream == "foo"

# Generated at 2022-06-20 23:53:58.582014
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    a = AnsibleLoader("tests")
    assert a

# Generated at 2022-06-20 23:54:08.410354
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os.path
    import sys
    import pytest
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser

    # create test file with yaml content
    yaml_content = """
    foo:
      - name: foo1
        value: bar1
      - name: foo2
        value: bar2
    """
    test_file = "test_file.yml"
    with open(test_file, 'w') as f:
        f.write(yaml_content)

    # create AnsibleLoader object and load test file
    loader = AnsibleLoader(open(test_file, 'r'))
    assert(loader.stream is not None)
    assert(loader.filename is not None)

# Generated at 2022-06-20 23:54:09.466809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests for function-constructor
    assert AnsibleLoader

# Generated at 2022-06-20 23:54:11.390063
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleConstructor(file_name='/etc/ansible/roles/role_with_vars/vars/main.yml')

# Generated at 2022-06-20 23:54:15.567558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.get_single_data() is None

# vim: set expandtab ts=4 sw=4 tw=79

# Generated at 2022-06-20 23:54:16.820138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# Generated at 2022-06-20 23:54:17.725320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:54:28.559682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultConstructor
    from base64 import b64decode

    # In python2 str type can be a bytestring and a unicode string,
    # so we need to use unicode_literal_str to make sure we are
    # getting a unicode string.
    unicode_literal_str = u'\u1234\u5678'

    key = b'abcdef0123456789'

# Generated at 2022-06-20 23:54:58.702151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    data = """
    ---
    # Ensure that AnsibleUnicode is used for strings
    unicode_str: foo
    bytestring: "abc"
    bytestring2: "def"
    """
    loader = AnsibleLoader(data)
    loaded = loader.get_single_data()
    assert isinstance(loaded['unicode_str'], AnsibleUnicode)
    display.display(loaded['unicode_str'])

# Generated at 2022-06-20 23:54:59.971776
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None, file_name='test_file') is not None

# Generated at 2022-06-20 23:55:11.394398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    class fake_stream(object):
        _data = ['---', 'hello: world', '...']
        _i = 0
        def read(self, *args):
            ret = self._data[self._i]
            self._i += 1
            return ret
        def __iter__(self):
            return self
        def next(self):
            if self._i >= len(self._data):
                raise StopIteration
            ret = self._data[self._i]
            self._i += 1
            return ret

    l = AnsibleLoader(fake_stream(), file_name='fake_file')
    # Test a few methods of python 2.6 and 2.7 object base class
    assert l != 'foo'
    assert l != 123
    assert l != None
    assert l != 0

# Generated at 2022-06-20 23:55:20.342424
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib

    vault_pass = 'testpass'

# Generated at 2022-06-20 23:55:20.827556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:55:32.275028
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import copy
    import ansible.constants as C

    example_yaml = b"""
%YAML 1.2
---
Invoice: 34843
"""

    # TODO: use yaml loader and yaml dumper to read and write yaml file
    # This will require some rewrite of core.py
    file_name = '%s/test/test.yaml' % os.path.dirname(__file__)
    with open(file_name, 'wb') as f:
        f.write(example_yaml)

    # Instantiate the loader and read the file
    vault_secrets = copy.deepcopy(C.DEFAULT_VAULT_SECRETS_FILE)

# Generated at 2022-06-20 23:55:36.169316
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Testing init() of AnsibleLoader
    ansible_loader = AnsibleLoader(None, None, None)
    assert isinstance(ansible_loader, Parser)
    assert isinstance(ansible_loader, AnsibleConstructor)
    assert isinstance(ansible_loader, Resolver)

# Generated at 2022-06-20 23:55:40.974189
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    assert issubclass(AnsibleLoader, AnsibleBaseYAMLObject)
    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleMapping)
    assert AnsibleLoader("hello", vault_secrets="secret")

# Generated at 2022-06-20 23:55:47.492599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import types
    import unittest

    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Map class attributes to their expected value
    attr_map = {
        'nodes': {},
        'node_defaults': {},
    }

    loader = AnsibleLoader(None)

    # Test attributes to make sure they have the expected value
    for attr, expected in attr_map.items():
        actual = getattr(loader, attr)
        assert actual == expected, ("Expected AnsibleLoader to have a '%s' attribute of '%s' but got '%s'" % (attr, expected, actual))

    # Test methods to make sure they have the expected value

# Generated at 2022-06-20 23:55:58.442918
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.parsing.vault import VaultLib

    _data = '''
- name: test
  foo:
    {% vault |
      $ANSIBLE_VAULT;1.1;AES256
      62386235393164626263376339366431366639663031623331623137313139333565633862333630
      626531653265383538396137396363623432646561306331336563
    %}
'''
    _data_plaintext = '''
- name: test
  foo: bar
'''
    _vault_secrets = {'1.1': VaultLib([u'password'])}

# Generated at 2022-06-20 23:56:50.812443
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = """\
    hash:
        key: value
    list:
        - 1st
        - 2nd
    int: 1
    """
    stream = AnsibleLoader(data)
    assert type(stream.get_data()) == type(dict())
    assert type(stream.get_data()['hash']) == type(dict())
    assert type(stream.get_data()['list']) == type(list())
    assert type(stream.get_data()['int']) == type(int())

# Generated at 2022-06-20 23:56:56.186151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = """
    - pre_tasks:
        - name: copy test results
          copy:
            content: "{{ lookup('pipe', 'cat {{ results_dir }}/results.*.json') }}"
            dest: "{{ results_dir }}/results_all.json"
          delegate_to: localhost
          run_once: true
          register: results_all
    """

    AnsibleLoader(yaml_string)

# Generated at 2022-06-20 23:57:03.575127
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    stream = open('../../test/loader/data.yml')
    loader = AnsibleLoader(stream, vault_secrets=VaultLib())
    data = loader.get_single_data()
    assert data == \
        {'key':
            {'subkey':
                {'subsubkey':
                    {'subsubsubkey': 'test'}
                }
            }
        }

# Generated at 2022-06-20 23:57:09.323370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

    assert not loader.StreamStartEvent

    assert loader.StreamEndEvent

    assert loader.DocumentStartEvent

    assert loader.DocumentEndEvent

    assert loader.SequenceStartEvent

    assert loader.SequenceEndEvent

    assert loader.MappingStartEvent

    assert loader.MappingEndEvent

    assert not loader.AliasEvent

    assert not loader.ScalarEvent

    assert not loader.AnchorAliasEvent



# Generated at 2022-06-20 23:57:12.984356
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    stream = io.StringIO()
    #sys.stderr = stream
    loader = AnsibleLoader(stream)
    assert loader != None


# Generated at 2022-06-20 23:57:18.262862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.manager import AnsibleYAMLManager

    AnsibleYAMLManager.clear()
    mgr = AnsibleYAMLManager()
    loader = mgr.loader_for("foo.yaml", vault_secrets=[])
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:57:19.151503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ This is a compile only test. """
    assert True

# Generated at 2022-06-20 23:57:19.779835
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:57:24.765061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name ="/root/test.yml"
    vault_secrets = None
    stream = "test"
    an = AnsibleLoader(stream,file_name,vault_secrets)
    file_name2 = an.file_name
    vault_secrets2 = an.vault_secrets
    assert file_name2 == file_name
    assert vault_secrets2 == vault_secrets

# Generated at 2022-06-20 23:57:25.244794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:59:08.554213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = '--- \n[1,2,3]\n'
    loader = AnsibleLoader(x)
    datum = loader.get_single_data()
    assert datum == [1,2,3]

# Generated at 2022-06-20 23:59:12.477343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    host_list = ("localhost ansible_connection=local", )
    hosts = "\n".join(host_list)
    file_name = "hosts"

    loader = AnsibleLoader(hosts, file_name)
    hosts_struct = loader.get_single_data()
    assert loader.file_name == file_name
    assert hosts_struct == host_list


# Generated at 2022-06-20 23:59:14.297132
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #TODO: need to fix test.py
    print ("AnsibleLoader()")
    AnsibleLoader()

# Generated at 2022-06-20 23:59:23.158837
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = b'''\
one:
- 1
- [1,2]
two:
- 2
- [2,2]
'''
    import io
    import sys
    l = AnsibleLoader(io.BytesIO(text), file_name='<string>')
    assert l.get_single_data() == {'one': [1, [1, 2]], 'two': [2, [2, 2]]}
    if sys.version_info < (2, 7, 1):
        assert l.compose_document() == {'one': [1, [1, 2]], 'two': [2, [2, 2]]}
        assert l._compose_mapping_node([], False) == {}

# Generated at 2022-06-20 23:59:29.058318
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO

    # Some YAML data
    data = b'{foo: bar}'

    # Define an AnsibleLoader
    ansible_loader = AnsibleLoader(BytesIO(data))

    # Handle the YAML data with the AnsibleLoader
    content = list(ansible_loader.get_single_data())

    # Check the result
    assert content == [{'foo': 'bar'}]

# Generated at 2022-06-20 23:59:32.535667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=no-self-use
    if HAS_LIBYAML:
        is_yaml_present = True
    else:
        is_yaml_present = False
    assert is_yaml_present == True

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-20 23:59:35.500153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream='test_stream',
                           file_name='test_file_name',
                           vault_secrets='test_vault_secrets')
    assert loader.stream == 'test_stream'
    assert loader.file_name == 'test_file_name'
    assert loader.vault_secrets == 'test_vault_secrets'

# Generated at 2022-06-20 23:59:38.285178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml, os
    os.environ['ANSIBLE_VAULT_PASSWORD_FILE'] = "../test/vault-pw-dummy"

    with open('../test/test_loader.yml', 'r') as f:
        data = yaml.load(f, Loader=AnsibleLoader)

    assert data['password'] == 'hunter2'

# Generated at 2022-06-20 23:59:42.728473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    def _bytes_for_str(str_data):
        # For Python3, we need to convert native strings to byte strings.
        # Python2: str -> str
        # Python3: str -> bytes
        try:
            return bytes(str_data)
        except TypeError:
            return str_data


# Generated at 2022-06-20 23:59:51.160287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # Fixture of a single key/value item to prevent the need to repeat it
    #
    single_key_value_item = "\n".join((
        "---",
        "key: value",
    ))

    #
    # Test fixture of a complete document with a single key
    #
    single_key_document = "\n".join((
        "---",
        "key: value",
    ))

    #
    # Test fixture of a list with a single key
    #
    single_key_list = "\n".join((
        "---",
        "- key: value",
    ))

    #
    # Test fixture of a dictionary with a single key
    #