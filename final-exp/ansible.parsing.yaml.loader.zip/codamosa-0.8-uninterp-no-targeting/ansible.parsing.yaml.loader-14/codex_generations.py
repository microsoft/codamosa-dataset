

# Generated at 2022-06-20 23:50:53.376664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Loader contains two types of constructors
    #  - PyYAML constructor and Ansible custom constructor
    #  - PyYAML resolves which constructor to use based on the tag in the
    #    YAML stream.
    #  - Ansible custom constructor is used to override some of the PyYAML
    #    constructors and only when it finds a tag starting with '!', otherwise
    #    PyYAML constructors are used.

# Generated at 2022-06-20 23:51:04.970338
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Unit test for AnsibleLoader

    AnsibleLoader is a subclass of the python-yaml library's classes
    Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver.
    All but AnsibleConstructor are subclasses of the Base class, which
    defines a constructor.  We call the superclass constructors here
    to eliminate pylint errors and to confirm that they don't do
    anything that would break AnsibleLoader.

    TODO: rework python-yaml classes to use super all the way down,
    and then these calls to superclass constructors can be eliminated.
    """
    if HAS_LIBYAML:
        yaml_stream = ''
        yaml_vault_secrets = None
        yaml_file_name = None

# Generated at 2022-06-20 23:51:05.755306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:51:15.510980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader('test')
    assert ansible_loader.file_name == 'test'
    #assert ansible_loader.resolver == None
    assert ansible_loader.yaml_additions == True
    ansible_loader.get_single_data()
    ansible_loader.construct_yaml_map(u'tag:yaml.org,2002:map')
    ansible_loader.construct_yaml_str(u'tag:yaml.org,2002:str')
    ansible_loader.construct_yaml_seq(u'tag:yaml.org,2002:seq')
    ansible_loader.construct_yaml_set(u'tag:yaml.org,2002:set')

# Generated at 2022-06-20 23:51:18.190371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    AnsibleBaseYAMLObject()

# Generated at 2022-06-20 23:51:27.657084
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    output = loader.load_from_file('test/unit/parsing/yaml/constructor_test.yml')
    assert len(output) == 3
    assert output[0]['name'] == 'bob'
    assert output[0]['age'] == 31
    assert output[1]['name'] == 'nick'
    assert output[1]['age'] == 17
    assert output[2]['name'] == 'jim'
    assert output[2]['age'] == 22

# Generated at 2022-06-20 23:51:31.364640
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    >>> loader = AnsibleLoader(None)
    >>> loader.construct_yaml_map()
    {}
    >>> loader.construct_yaml_seq()
    []
    '''

    return True


# Generated at 2022-06-20 23:51:31.982830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()

# Generated at 2022-06-20 23:51:37.036261
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create a new AnsibleLoader to test AnsibleConstructor and Resolver
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)
    # Can't obtain a method if it's not defined
    assert not hasattr(loader, 'construct_yaml_null')


# Generated at 2022-06-20 23:51:38.823683
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load(stream=None, Loader=AnsibleLoader)

# Generated at 2022-06-20 23:51:50.036767
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.six import StringIO
    stream = StringIO(u"""
    ---
    # This is just a simple test
    # It's really not that hard,
    # it's really not that complicated
    foo: bar
    """)
    data = AnsibleLoader(stream).get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data.get('foo'), basestring)
    stream = StringIO(u"""
    ---
    foo:
     - 1
     - 2
     - 3
    """)
    data = AnsibleLoader(stream).get_single_data()

# Generated at 2022-06-20 23:52:01.882084
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader

    class DictLoader(AnsibleLoader):  # pylint: disable=too-few-public-methods
        def __init__(self, stream):
            super(DictLoader, self).__init__(stream)
            self.datas = []

        def construct_yaml_map(self, node):
            data = AnsibleLoader.construct_yaml_map(self, node)
            self.datas.append(data)
            return data

        def construct_yaml_str(self, node):  # pylint: disable=unused-argument
            return u'nope'

        def construct_yaml_seq(self, node):  # pylint: disable=unused-argument
            data = AnsibleLoader.construct_y

# Generated at 2022-06-20 23:52:09.816243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    >>> import ansible.parsing
    >>> import StringIO
    >>> stream = StringIO.StringIO("---\\n- hosts: localhost\\n  tasks:\\n  - name: test\\n    debug:\\n      msg: hello\\n")
    >>> yaml_loader = ansible.parsing.yaml.objects.AnsibleLoader(stream)
    >>> yaml_loader.get_single_data()
    {'tasks': [{'debug': {'msg': 'hello'}, 'name': 'test'}], 'hosts': ['localhost']}
    """

# Generated at 2022-06-20 23:52:21.005829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ANSIBLE0003: string indices must be integers, not str
    # pylint: disable=E1136

    # make sure our class can handle all the types
    # that the yaml lib can dump
    import yaml

# Generated at 2022-06-20 23:52:26.448982
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# pylint: disable=unused-import
from ansible.compat.tests.mock import patch
from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedFile
from ansible.parsing.yaml import dumper, loader

try:
    from __main__ import display
except ImportError:
    from ansible.utils.display import Display
    display = Display()

from units.mock.vault import VaultLib

vault_password = '$6$foobar'


# Generated at 2022-06-20 23:52:27.043278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-20 23:52:32.095204
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TAnsibleLoader(AnsibleLoader):
        pass

    s = """\
d1: d1-v1
d2: d2-v1
d3: d3-v1"""

    l = TAnsibleLoader(s)
    l.get_single_data()

    assert l.data['d1'] == 'd1-v1'

# Generated at 2022-06-20 23:52:37.083344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load, dump

    yaml_str = """- 'test'
          -
            - {a: [test, test]}
            - [test, test]
      - {test: test2}
      - test2
  {test: test2}
  {}
  """
    data = load(yaml_str)
    print(dump(data))

    return data is not None


if __name__ == '__main__':
    print(test_AnsibleLoader())

# Generated at 2022-06-20 23:52:46.554082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_loader_name

    try:
        loader_class = AnsibleLoader
        data_loader = DataLoader()
        for loader_name in get_all_plugin_loaders():
            loader_class = data_loader.get_plugin_loader(loader_name)
            if loader_class:
                break
        loader = loader_class.load('')
        assert type(loader).__name__ == get_loader_name()
    except:
        assert False

# Generated at 2022-06-20 23:52:47.572070
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    AnsibleLoader('test')

# Generated at 2022-06-20 23:52:56.510564
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = file(__file__, 'r').read()

    loader = AnsibleLoader(stream)

    assert hasattr(loader, '_parserbuf')
    assert hasattr(loader, '_vault_secrets')
    assert hasattr(loader, '_vault')
    assert hasattr(loader, '_file_name')
    assert hasattr(loader, '_loader_name')
    assert hasattr(loader, '_loader_ext')
    assert hasattr(loader, '_jinja2_native_types')
    assert hasattr(loader, '_data_tokens_base')
    assert hasattr(loader, '_data_tokens_jinja2')
    assert hasattr(loader, '_data_tokens_yaml')

# Generated at 2022-06-20 23:52:58.295002
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Just test a basic instantiation of the class
    AnsibleLoader(None, None)

# Generated at 2022-06-20 23:53:08.474656
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml import AnsibleLoader
    import io
    import sys
    from ansible.module_utils._text import to_bytes

    assert HAS_LIBYAML is not None

    if sys.version_info[0] < 3:
        mystr = to_bytes(u'foo: bar', encoding='utf-8')
    else:
        mystr = io.StringIO(u'foo: bar')

    aloader = AnsibleLoader(mystr)
    ansible_unicode_obj = aloader.get_single_data()
    assert isinstance(ansible_unicode_obj, dict)

# Generated at 2022-06-20 23:53:09.538737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-20 23:53:20.378621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.module_utils.six import StringIO

    class MyStringIO(StringIO):
        def close(self):
            return

    fake_yaml_str = '''
    - hosts: all
      gather_facts: False
    '''
    loader = AnsibleLoader(MyStringIO(fake_yaml_str))
    parsed = loader.get_single_data()
    assert isinstance(parsed, AnsibleMapping)
    assert len(parsed.keys()) == 1
    assert isinstance(parsed.get('hosts'), AnsibleSequence)

# Generated at 2022-06-20 23:53:21.620004
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=W0612
    obj = AnsibleLoader('')

# Generated at 2022-06-20 23:53:28.398808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.compat.tests import unittest
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.config.data import ConfigData

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.config_data = ConfigData()
            self.config_data.load()
            self.config_data.set_config('DEFAULT', vault_password_file='/dev/null')
            vault_secrets = VaultLib(self.config_data)
            vault_secret = VaultSecret('vaultpassword', ['1'])
            vault_secrets.secrets = {'vaultpassword': vault_secret}
            self.vault_secrets = vault_secrets


# Generated at 2022-06-20 23:53:29.682106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-20 23:53:36.982639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test the loader by parsing a single document with a top-level mapping.
    # The expected python representation is:
    #   {'test': {'string1': 'foo', 'string2': 'bar', 'string3': 'baz'}}
    #
    # This is a representation of the following document:
    #
    #    ---
    #    test:
    #      string1: foo
    #      string2: bar
    #      string3: baz
    #
    stream = "---\n\ttest:\n\t  string1: foo\n\t  string2: bar\n\t  string3: baz\n"
    expected_result = {'test': {'string1': 'foo', 'string2': 'bar', 'string3': 'baz'}}

# Generated at 2022-06-20 23:53:48.564754
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:54:07.761112
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import yaml
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    from ansible.parsing.yaml.loader import AnsibleLoader

    from ansible.module_utils.six import PY3

    if PY3:
        string_types = str
        binary_type = bytes
    else:
        string_types = basestring
        binary_type = str

    class MockVaultSecret(object):
        def __init__(self):
            self.path = "ansible/vault/mock.yml"

    if not HAS_LIBYAML and PY3:
        # PyYAML 3.10 and earlier has problems with unicode variables.
        sys.exit(0)

    # On Python 2.7, pypy and

# Generated at 2022-06-20 23:54:15.756108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    def get_path(file_name):
        return os.path.join(os.path.dirname(os.path.realpath(__file__)), 'yaml', file_name)

    def test_yaml_file(file_name):
        test_yaml_instance = AnsibleLoader(file(get_path(file_name))).get_single_data()
        assert test_yaml_instance is not None

    test_yaml_file('test_yaml_ansible_loader_1.yml')

# Generated at 2022-06-20 23:54:24.442974
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
my_key: "my_value"

# a comment
# another comment with an empty line above

# a comment with a variable
#   {{ my_variable }}

a_list: [ 1, 2, 3 ]
a_dict:
  key1: value1
'''
    for cls in [AnsibleLoader]:
        loader = cls(stream)
        data = loader.get_single_data()
        assert data['my_key'] == "my_value"
        assert data['a_list'][0] == 1
        assert data['a_dict']['key1'] == 'value1'

# Generated at 2022-06-20 23:54:30.712261
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class TestAnsibleLoader(AnsibleLoader):
        pass
    stream = open('test.yml')
    loader = TestAnsibleLoader(stream, file_name='test.yml')
    data = loader.get_single_data()
    assert isinstance(data, AnsibleBaseYAMLObject)

# Generated at 2022-06-20 23:54:37.809737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
	test_yaml = '''
				- hosts: localhost
				  gather_facts: false
				  vars:
					foo: bar
				  post_tasks:
					- name: test
					  test_connection:
						path: /foo
						hosts:
							- abc.com
						port: 1234
						args:
						  test_args: ["arg1", "arg2"]
						  test_kwargs:
							kwarg1: 1
							kwarg2: 2
				'''

# Generated at 2022-06-20 23:54:48.690786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib

    yaml_str = '''---
name: "{{ user }}"
password: "{{ password | default('password', true) }}"
'''
    passwords = {'vault_password': 'secret'}
    vault = VaultLib(passwords=passwords)

    loader = AnsibleLoader(yaml_str, file_name='<string>')
    data = loader.get_single_data()
    assert(isinstance(data, dict))
    assert(len(data) == 2)
    assert(data['name'] == AnsibleUnicode('{{ user }}'))
    assert(data['password'] == AnsibleUnicode("{{ password | default('password', true) }}"))

# Generated at 2022-06-20 23:54:58.122945
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import unittest
    import sys
    import os
    import tempfile

    class AnsibleLoaderTestCase(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_vars_path1 = os.path.join(self.test_dir, 'vars', 'vars1.yml')
            self.test_vars_path2 = os.path.join(self.test_dir, 'vars', 'vars2.yml')
            self.vault_password_file = os.path.join(self.test_dir, 'vars', 'vault_password.txt')

# Generated at 2022-06-20 23:55:02.493876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    ---
    - hosts: localhost
      tasks:
       - set_fact: x=hello
       - debug: msg={{ x }}
    '''
    loader = AnsibleLoader(data)
    for task in loader.get_single_data():
        print(task)

# Generated at 2022-06-20 23:55:04.147719
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    assert obj is not None

# Generated at 2022-06-20 23:55:14.433272
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from io import StringIO

    # Test something that should evaluate to None
    t1_loader = AnsibleLoader(StringIO(u'---\n'))
    t1 = t1_loader.get_single_data()
    assert t1 is None

    # Test a single string
    for t2_str in [u'test', u'测试']:
        t2_loader = AnsibleLoader(StringIO(u'---\n' + t2_str))
        t2 = t2_loader.get_single_data()
        assert t2 == t2_str
        assert isinstance(t2, AnsibleUnicode)

    # Test a single integer

# Generated at 2022-06-20 23:55:32.683782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-20 23:55:42.078700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleScalarNode

    loader = AnsibleLoader(None)
    data_source = AnsibleSequence()
    dct = AnsibleMapping()
    dct.yaml_set_comment_before_after_key(None, None)
    dct['foo'] = AnsibleScalarNode(None, 'foo')
    dct['bar'] = AnsibleScalarNode(None, 'bar')
    data_source.append(dct)
    data = loader.construct_object(data_source, deep=True)
    assert isinstance(data, list)
    assert isinstance(data[0], dict)

# Generated at 2022-06-20 23:55:47.955305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test_init(self):
            loader = AnsibleLoader(None)
            self.assertIsInstance(loader, AnsibleLoader)

            if sys.version_info[0] < 3:
                self.assertIsInstance(loader, Reader)
                self.assertIsInstance(loader, Scanner)
                self.assertIsInstance(loader, Parser)
                self.assertIsInstance(loader, Composer)
            else:
                self.assertNotIsInstance(loader, Reader)
                self.assertNotIsInstance(loader, Scanner)
                self.assertNotIsInstance(loader, Parser)
                self.assertNotIsInstance(loader, Composer)

            self.assertIsInstance(loader, AnsibleConstructor)
           

# Generated at 2022-06-20 23:55:59.244788
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-20 23:56:07.145227
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.scanner import ScannerError

    # Test basic constructor
    assert AnsibleLoader(open(__file__)) is not None

    # Test constructor with stream
    stream = open(__file__)
    assert AnsibleLoader(stream) is not None
    stream.close()

    # Test constructor with file_name
    assert AnsibleLoader(open(__file__), file_name=__file__) is not None

    # Test constructor with vault_secrets
    assert AnsibleLoader(open(__file__), vault_secrets=[{'name': 'foo', 'key': 'bar'}]) is not None

    # Test normal loading
    data = AnsibleLoader(open(__file__)).get_single_data()
    assert isinstance(data, dict)

    # Test empty file

# Generated at 2022-06-20 23:56:18.540126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import difflib

    currentdir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.abspath(os.path.join(currentdir, '..', 'library')))
    from ansible.module_utils.common.yaml import AnsibleLoader, HAS_LIBYAML, Parser, YAML_VERSION

    filenames = [
        "parser1.yaml",
        "parser2.yaml",
        "parser3.yaml",
        "parser4.yaml",
        "parser5.yaml",
        "parser6.yaml",
        "parser7.yaml",
    ]


# Generated at 2022-06-20 23:56:21.817461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    stream = """
    ---
    - hosts: localhost
      tasks:
      - name: Task 1
    """
    AnsibleLoader(stream)

# Generated at 2022-06-20 23:56:26.096591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    contents = io.StringIO("{% foo %}")
    loader = AnsibleLoader(contents, 'myfile.yml')

    assert loader._file_name == 'myfile.yml'
    assert loader._vault_secrets == None
    assert loader.config.constructor == loader.construct_python_dict
    assert loader.config.constructor == AnsibleConstructor.construct_python_dict

# Generated at 2022-06-20 23:56:31.206281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader can not be instantiated with empty string and None
    # as it is not a valid stream, file_name, or vault_secrets
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.parsing.yaml.objects import AnsibleVaultSecretStub
    stream = ''
    file_name = None
    vault_secrets = None
    try:
        AnsibleLoader(stream)
        raise AssertionError("AnsibleLoader should not be instantiated with '' as stream")
    except TypeError:
        pass
    try:
        AnsibleLoader(stream, file_name)
        raise AssertionError("AnsibleLoader should not be instantiated with '' as stream and None as file_name")
    except TypeError:
        pass

# Generated at 2022-06-20 23:56:32.670854
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    sl = AnsibleLoader(None)
    assert sl is not None

# Generated at 2022-06-20 23:57:08.651585
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-20 23:57:15.332586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    #
    # test __init__
    assert isinstance(AnsibleLoader(str()), AnsibleLoader)

    if HAS_LIBYAML:
        assert isinstance(AnsibleLoader(str())._parser, Parser)
        assert isinstance(AnsibleLoader(str())._reader, Parser)
        assert isinstance(AnsibleLoader(str())._scanner, Parser)
    else:
        assert isinstance(AnsibleLoader(str())._parser, Parser)
        assert isinstance(AnsibleLoader(str())._reader, Reader)
        assert isinstance(AnsibleLoader(str())._scanner, Scanner)

    assert isinstance(AnsibleLoader(str())._composer, Composer)

# Generated at 2022-06-20 23:57:24.957530
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    vault = AnsibleVaultEncryptedUnicode.from_plaintext('vault-password', u'Hello world !')
    assert vault.vault_id == u'vault-password'
    assert vault.vault_secret_id == u'vault-password'
    assert vault == u'Hello world !'

# Generated at 2022-06-20 23:57:25.933500
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # The following code is based of code from test_constructor.py
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-20 23:57:26.756426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # print("AnsibleLoader()=%s" % AnsibleLoader)
    assert AnsibleLoader

# Generated at 2022-06-20 23:57:30.396653
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
    ---
    - hosts: all
      tasks:
        - user: name=foo
    """
    stream = AnsibleLoader(content)
    assert(stream.get_single_data()['hosts'] == 'all')

# Generated at 2022-06-20 23:57:34.617387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestAnsibleLoader(AnsibleLoader):
        pass

    stream = ''
    vault_secrets = []
    instance = TestAnsibleLoader(stream, vault_secrets)

    stream = ''
    vault_secrets = []
    instance = TestAnsibleLoader(stream)

# Generated at 2022-06-20 23:57:45.656900
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- hosts: somehost
  user: ansible
  gather_facts: no
  tasks:
    - name: actionone
      debug: msg="one"
      tags: one

    - debug: msg="two"
      tags:
        - two
        - three'''
    yaml_obj = AnsibleLoader(stream)
    assert 1 == yaml_obj.get_data_for_role(None, target_tag='one')['tasks'][0]['debug']['msg']
    assert 2 == yaml_obj.get_data_for_role(None, target_tag='two')['tasks'][0]['debug']['msg']

# Generated at 2022-06-20 23:57:48.471059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    input_stream = io.BytesIO(b"foo: bar")
    loader = AnsibleLoader(input_stream)
    assert loader.get_single_data() == {'foo':'bar'}

# Generated at 2022-06-20 23:57:54.965948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    import ansible.constants as C

    class TestAnsibleLoader(unittest.TestCase):

        def test_vault_constructor(self):
            from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
            from ansible.parsing.dataloader import DataLoader
            loader = DataLoader()

# Generated at 2022-06-20 23:59:18.447624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('test')

# Generated at 2022-06-20 23:59:23.125824
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(stream="")
    assert isinstance(loader, Loader)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-20 23:59:32.609687
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    invalid_yaml = [
        "foo: 1\nbaz: 2",
        "{ foo: 1 }\nbaz: 2",
        "foo: 1\n{ baz: 2 }",
        "foo: [ 1,\n2 ]\nbaz: 3",
        "foo: { bar: 1,\nbaz: 2 }",
    ]
    for yaml_string in invalid_yaml:
        try:
            AnsibleLoader(yaml_string)
        except Exception as e:
            print("Invalid yaml string %s failed with %s as expected" % (yaml_string, e.__class__.__name__))

# Generated at 2022-06-20 23:59:34.577934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    loader = AnsibleLoader(sys.stdin)
    print(os.path.expandvars("$HOME"))
    print(loader)
    print(type(loader))


# Generated at 2022-06-20 23:59:40.215993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    try:
        import __main__
    except ImportError:
        __main__ = None

    # Set up ansible.cfg file
    cfgfile = """
[defaults]
roles_path = %s/../../../../../roles
""" % __main__.__file__.split("/")[0:-1]
    fd, path = tempfile.mkstemp()
    os.write(fd, cfgfile)
    os.close(fd)
    os.environ['ANSIBLE_CONFIG'] = path

    # Test file
    fd, path = tempfile.mkstemp()
    os.write(fd, "---\nhosts:\n- host1\n")
    os.close(fd)

    # Test a file with a custom plugin

# Generated at 2022-06-20 23:59:48.639896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test AnsibleConstructor
    with open("test/unit/parsing/yaml/ansiblec.yml") as f:
        loader = AnsibleLoader(f)
        # AnsibleConstructor has not implemented the method make_multi_constructor of yaml.constructor.BaseConstructor
        # so yaml.constructor.BaseConstructor.make_multi_constructor(self) will be called
        # the parameter loader.constructor is an instance of yaml.constructor.BaseConstructor
        # the parameter loader.resolver is an instance of yaml.resolver.Resolver
        # yaml.constructor.BaseConstructor.make_multi_constructor(self) will call the method make_yaml_constructor(self.resolver)
        # yaml.resolver.Resolver.make_yaml_constructor is

# Generated at 2022-06-20 23:59:50.166224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    try:
        AnsibleLoader(sys.stdin)
    except:
        raise AssertionError()

# Generated at 2022-06-20 23:59:52.353480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")
    assert hasattr(loader, 'file_name')
    assert hasattr(loader, 'vault_secrets')



# Generated at 2022-06-20 23:59:54.254267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert AnsibleLoader.__doc__ == "Custom loader that uses the default loader with a custom constructor and resolver."



# Generated at 2022-06-21 00:00:04.755757
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader

    # Test constructor
    loader = DataLoader()
    assert loader.vault_secrets == [DEFAULT_VAULT_ID_MATCH]
    loader = DataLoader(vault_secrets=['bar'])
    assert loader.vault_secrets == ['bar']

    # Test loading non-encrypted
    yaml_string = '''
        foo:
          bar: baz
          buzz: bing
    '''
    data = loader.load(StringIO(yaml_string))