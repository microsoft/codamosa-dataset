

# Generated at 2022-06-23 05:31:54.399054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # TODO:  Add test cases for AnsibleLoader
    pass


# Generated at 2022-06-23 05:31:55.646042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None


# Generated at 2022-06-23 05:31:57.523212
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader, AnsibleLoader)


# Generated at 2022-06-23 05:31:58.361398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)


# Generated at 2022-06-23 05:32:05.683365
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    import ansible.parsing.dataloader
    dummy_file = '/dev/null'
    ansible_loader_instance = ansible.parsing.dataloader.DataLoader().get_single_data(dummy_file)
    assert isinstance(ansible_loader_instance, AnsibleLoader)
    assert isinstance(ansible_loader_instance.loader, ansible.parsing.yaml.objects.AnsibleLoader)

# Generated at 2022-06-23 05:32:16.538048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import io
    import pickle
    import sys
    import unittest

    yaml_code = """
    - hosts: localhost
      tasks:
        - shell: echo
          register: result
      post_tasks:
        - fail: msg="test failure"
          when: result.rc != 0
    """

    if sys.version_info >= (3,):
        # for python3, convert to bytes
        yaml_code = bytes(yaml_code, 'UTF-8')

    fh = io.StringIO(yaml_code)
    loader = AnsibleLoader(fh)

    data = loader.get_single_data()

    if sys.version_info < (3,):
        # py26
        pickle.dumps(data)

    assert type(data) == type({})

# Generated at 2022-06-23 05:32:18.827555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("test: data", "test")
    doc = loader.get_single_data()
    assert doc == "data"

# Generated at 2022-06-23 05:32:22.491160
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    ansibleloader = AnsibleLoader('{"a":1}')
    assert ansibleloader != None
    assert AnsibleLoader != None

# Generated at 2022-06-23 05:32:31.678589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Ensure that AnsibleLoader.__init__ calls all methods correctly
    '''
    class Arguments:
        pass
    args = Arguments()
    args.file_name = 'test'
    args.vault_secrets = {}

    class TestParser(Parser):
        def __init__(self, stream):
            pass
    args.Parser = TestParser

    # with libyaml loaded
    def reset():
        AnsibleLoader.__init__ = super(AnsibleLoader, AnsibleLoader).__init__
    reset()

# Generated at 2022-06-23 05:32:42.308696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_pass = 'root'
    vault_secrets = ['password']
    vault_data = {'password': '$6$V0yXrHrk$Dp0F/C7I1H3mq3eV0mjK04x6RzxO9X0QsVgE6O1jV7wMqI3qF7UKBcygxuR6U.X9IuV6E09h6UJZ7wIOTNCYS1'}
    ans_loader = AnsibleLoader('', vault_secrets=vault_secrets)
    vault_obj = VaultLib(vault_pass, vault_secrets)
    vault_data = vault_obj.encrypt(vault_data)
    encrypted_

# Generated at 2022-06-23 05:32:52.951701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    vault_secrets = dict(vault_password='dummy_password')

# Generated at 2022-06-23 05:32:56.000216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    obj = AnsibleConstructor()
    assert isinstance(obj, AnsibleConstructor)


# Generated at 2022-06-23 05:32:56.588278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:01.739270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # In Python 3, bytestrings are decoded to unicode
    # In Python 2, encoding has to be done explicity
    loader = AnsibleLoader('hello: !include hello.yaml')
    assert loader.get_single_data() == dict(hello=dict(include='hello.yaml'))

# Generated at 2022-06-23 05:33:05.699090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    foo:
      "{{bar}}": 1
    '''
    loader = AnsibleLoader(data)
    for datum in loader:
        assert datum == {'foo': {'1': 1}}

# Generated at 2022-06-23 05:33:10.697376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None, 'somefile', ['some', 'secret'])
    assert a.file_name == 'somefile'
    assert a.vault_secrets == ['some', 'secret']
    assert a.file_path is None

# Generated at 2022-06-23 05:33:16.133209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode
    v = AnsibleVaultEncryptedUnicode()
    print(v)
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    AnsibleConstructor()

# Generated at 2022-06-23 05:33:18.031950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO:
    # The following test should be implemented
    #     the class should be derived from yaml.BaseLoader
    raise NotImplementedError

# Generated at 2022-06-23 05:33:19.824664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader("foo")

# Generated at 2022-06-23 05:33:26.219510
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:33:30.048368
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # both in python2.6 and 2.7, creating an instance of Loader
    # immediately invokes the compose_node method, which wants
    # the first_event() which is the BOM.  skip that here because
    # it's a valid test in the unit test for Reader
    # pylint: disable=too-many-function-args
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-23 05:33:37.673748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # setUp
    stream = open('./test_ansiballz/roles/testrole/tasks/main.yml')
    file_name = './test_ansiballz/roles/testrole/tasks/main.yml'
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

    # test
    assert ansible_loader.get_single_data() == [{'debug': {'msg': 'hello world'}}, {'debug': {'msg': '{{ user }}'}}]

# Generated at 2022-06-23 05:33:39.293851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '{}'
    assert AnsibleLoader(stream) is not None

# Generated at 2022-06-23 05:33:42.501944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    yaml = DataLoader()
    yaml.load_from_file('/dev/null')

# Generated at 2022-06-23 05:33:48.960612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # pylint: disable=no-self-use
    class TestAnsibleLoader(AnsibleLoader):
        # needed so we don't loop forever in AnsibleConstructor.__init__
        def __init__(self, stream):
            AnsibleLoader.__init__(self, stream)

        def test_exc_1():
            ansible_loader = TestAnsibleLoader(None)
            assert ansible_loader

    TestAnsibleLoader.test_exc_1()

# Generated at 2022-06-23 05:33:51.282696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream='[{"a": "b"}]')

# Generated at 2022-06-23 05:34:02.465145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    class YamlTest:

        def load_string(self, string_to_load):
            the_item = None
            try:
                the_item = yaml.load(string_to_load, Loader=AnsibleLoader)
            except yaml.YAMLError as exc:
                print(exc)

            return the_item

        def dump_dict(self, dictionary_to_dump):
            return yaml.dump(dictionary_to_dump, default_flow_style=False)

    class TestVault(object):

        def get_decryption_key(self, secret_id):
            return "FAKEKEY"

    string = """
    1: one
    2: two
    3: three
    """
    yaml_test = YamlTest()
    item = yaml

# Generated at 2022-06-23 05:34:05.888090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='test.yml')
    assert loader is not None

# Generated at 2022-06-23 05:34:06.728968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:34:09.891092
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import textwrap
    input = textwrap.dedent("""
    - &anchor a
    - &anchor
    - *anchor
    """)
    stream = AnsibleLoader(input)
    assert stream.get_data() == [{}, {}, {}]

# Generated at 2022-06-23 05:34:19.633063
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import ansible.utils.unsafe_proxy as unsafe_proxy
    # Create a dict object to use as stream
    stream = dict(a=1,
        b=2,
        c=dict(d='{{ foobar }}',
               e=unsafe_proxy.wrap_var('foobar'),
               f=['this', '{{ foobar }}', 'that', unsafe_proxy.wrap_var('foobar'), list(unsafe_proxy.wrap_var('foobar'))]))
    # Create a AnsibleLoader object
    loader = AnsibleLoader(stream)
    # Get a Python object from the AnsibleLoader object
    data = loader.get_single_data()
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c']['d'] == '{{ foobar }}'

# Generated at 2022-06-23 05:34:21.587146
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(file_name='/test/test.yml', vault_secrets=None).get_single_data()
    assert data is None

# Generated at 2022-06-23 05:34:24.922432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(open('fixtures/safevars.yml', 'r'))
    d = loader.get_single_data()
    assert d['vault_password'].is_encrypted

# Generated at 2022-06-23 05:34:31.489650
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
            ---
            - hosts: tagged_hosts
              tasks:
                - debug: msg="I'm in a tag!"
            """
    obj = AnsibleLoader(stream, vaults=[1,2,3,4])
    assert obj.vault_secrets == [1,2,3,4]
    assert obj.file_name == None
    assert obj.constructor == AnsibleConstructor

# Generated at 2022-06-23 05:34:43.961472
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:34:47.978505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    contents = """
---
- include:
    file: yaml-dir/test.yml
    name: yaml-dir/test.yml
"""

    loader = AnsibleLoader(contents, 'fake-file-name')
    assert loader
    assert loader.get_single_data()

# Generated at 2022-06-23 05:34:49.361237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('test')

    assert loader is not None

# Generated at 2022-06-23 05:34:56.433009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class DummyYaml(object):
        yaml_loader = AnsibleLoader

    source = ("result:\n"
              "  a: 1\n"
              "  b: 2\n"
              "  c: 3\n"
              "foo: {bar: 'baz'}")

    result = DummyYaml.yaml_loader(source).get_single_data()

    assert result == {'result': {'a': 1, 'c': 3, 'b': 2}, 'foo': {'bar': 'baz'}}

# Generated at 2022-06-23 05:35:05.203891
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:35:13.088672
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Basic test - private_key is a string, and always should be a string
    data = """
vars:
  ssh_private_key: "{{ lookup('file', lookup_file) }}"
"""
    my_loader = AnsibleLoader(data)
    obj = my_loader.get_single_data()
    assert isinstance(obj['vars']['ssh_private_key'], basestring)
    assert obj['vars']['ssh_private_key'] == "$ANSIBLE_VAULT;1.1;AES256"

# Generated at 2022-06-23 05:35:15.200537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# vim: set noet ts=4 sw=4 ft=python :

# Generated at 2022-06-23 05:35:18.082449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a_loader = AnsibleLoader(file_name='test',vault_secrets=None)
    assert(a_loader != None)
    a_loader.dispose()

# Generated at 2022-06-23 05:35:30.657546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = '''
        ---
        # This is a comment
        name: Toto
        age: 6
    '''
    ldr = AnsibleLoader(data.splitlines(), file_name="fname")
    data2 = ldr.get_single_data()
    assert data2 is not None
    assert len(data2) == 2
    assert "comment" in data2
    assert data2["comment"] == "This is a comment"
    assert "name" in data2
    assert "age" in data2
    assert data2["age"] == 6
    assert data2["name"] == "Toto"

    # Test constructor for dict
    data = '''
        ---
         name: value1
         other: value2
    '''

# Generated at 2022-06-23 05:35:41.182732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.serializer import Serializer
    from yaml.emitter import Emitter
    from yaml.representer import Representer

    yaml.add_constructor(u'!include', AnsibleLoader.include)
    yaml.add_constructor(u'!include_vars', AnsibleLoader.include_vars)
    yaml.add_constructor(u'!include_role', AnsibleLoader.include_role)
    yaml.add_constructor(u'!include_tasks', AnsibleLoader.include_tasks)
    yaml.add_constructor(u'!import_playbook', AnsibleLoader.import_playbook)
    yaml.add_constructor(u'!block', AnsibleLoader.block)

# Generated at 2022-06-23 05:35:52.789448
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types
    import pytest
    if not hasattr(yaml.Loader, '__new__'):
        pytest.skip("yaml.Loader does not have __new__")

    assert isinstance(AnsibleLoader.__new__, types.FunctionType)
    assert isinstance(AnsibleLoader, type)

    assert not hasattr(yaml.Loader, '_ansible_file_name')
    assert not hasattr(yaml.Loader, '_ansible_vault_secrets')

    loader1 = AnsibleLoader('')
    assert isinstance(loader1, yaml.Loader)
    loader2 = AnsibleLoader(file_name='/tmp/foo.yml')
    assert isinstance(loader2, yaml.Loader)

# Generated at 2022-06-23 05:35:57.135439
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Initialize AnsibleLoader object
    loader = AnsibleLoader('---\n- hosts: testhost\n  remote_user: testuser\n')

    # Check that loader is initialized
    assert loader

# Generated at 2022-06-23 05:35:58.080930
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:36:08.115705
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys

    buffer = io.StringIO()

    # Just testing if these would work, no output is expected.
    buffer.write(u'---\n')
    loader = AnsibleLoader(buffer)
    buffer.write(u'{0}: value\n'.format(loader.resolve(u'tag:yaml.org,2002:str', u'!foo')))
    buffer.write(u'{0}: {1}\n'.format(loader.resolve(u'tag:yaml.org,2002:str', u'!foo'), loader.resolve(u'tag:yaml.org,2002:str', u'!bar')))

    buffer.seek(0)
    print(u'Starting test\n', file=sys.stderr)

# Generated at 2022-06-23 05:36:12.999340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with None stream
    loader = None
    try:
        loader = AnsibleLoader(None)
        assert 0, "AnsibleLoader not raise exception with None stream"
    except:
        pass
    # Test with wrong stream
    loader = None
    try:
        loader = AnsibleLoader(1)
        assert 0, "AnsibleLoader not raise exception with wrong type stream"
    except:
        pass

# Generated at 2022-06-23 05:36:14.685328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:18.544618
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    assert hasattr(AnsibleLoader, "from_file")
    assert hasattr(AnsibleLoader, "get_single_data")
    assert hasattr(AnsibleLoader, "__init__")

# Generated at 2022-06-23 05:36:20.393093
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(open(__file__))
    assert loader.get_single_data()

# Generated at 2022-06-23 05:36:31.739983
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    import StringIO
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    #
    # Write an encrypted string
    #
    f1 = StringIO.StringIO()
    v = AnsibleVaultEncryptedUnicode(u'test', vault_password='secret')
    v.get_encrypted_data()
    if HAS_LIBYAML:
        v.yaml_representer(None, f1)
    else:
        v.to_yaml(f1, None, None)
    f1.seek(0)

    #
    # Read it back in
    #
    loader = Ans

# Generated at 2022-06-23 05:36:32.398377
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:39.094809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    yaml_data = """
    ---
    # this is a comment that includes an empty line:
    #

    ansible: { key: value }
    """
    result = loader.load(yaml_data)
    assert 'ansible' in result
    assert 'key' in result['ansible']
    assert result['ansible']['key'] == 'value'

# Generated at 2022-06-23 05:36:45.569357
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj2 = AnsibleLoader(None)
    assert isinstance(obj2, AnsibleLoader)
    assert isinstance(obj2, Resolver)
    assert isinstance(obj2, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(obj2, Parser)
    else:
        assert isinstance(obj2, Reader)
        assert isinstance(obj2, Scanner)
        assert isinstance(obj2, Parser)
        assert isinstance(obj2, Composer)

# Generated at 2022-06-23 05:36:47.577185
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # initialize AnsibleLoader
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:36:53.320466
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Loading yaml file, executing the callback and checking the result
    yaml_stream = open("../test/test.yaml", 'r')
    yaml_loader = AnsibleLoader(yaml_stream)
    assert yaml_loader.get_single_data() == ['results']
    yaml_stream.close()

# Generated at 2022-06-23 05:36:55.432284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    # we should not crash when calling the above
    assert True

# Generated at 2022-06-23 05:36:57.116741
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-23 05:37:03.145116
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class test_AnsibleLoader:
        def __init__(self, stream, file_name=None, vault_secrets=None):
            pass
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        assert issubclass(type(AnsibleLoader(None)), test_AnsibleLoader)
    else:
        assert issubclass(type(AnsibleLoader(None)), test_AnsibleLoader)

# Generated at 2022-06-23 05:37:12.012522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the constructor of class AnsibleLoader
    """
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from yaml.resolver import Resolver
    from io import StringIO

# Generated at 2022-06-23 05:37:20.019082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, (Parser, AnsibleConstructor, Resolver))
    else:
        assert issubclass(AnsibleLoader, (Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver))

# Generated at 2022-06-23 05:37:20.624144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:37:24.932501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = "hminh.txt"
    vault_secrets = "password"
    obj = AnsibleLoader(stream,file_name=file_name,vault_secrets=vault_secrets)
    assert obj != None


# Generated at 2022-06-23 05:37:27.645959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('/home/runner/work/ansible/ansible/lib/ansible/parsing/yaml/constructor.py')
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:37:31.982301
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """  Test for class AnsibleLoader
    """
    str_to_test = '[1, 2, 3]'
    ans_loader = AnsibleLoader(str_to_test)
    ans_constructor_list = ans_loader.get_single_data()
    assert ans_constructor_list == [1, 2, 3]


# Generated at 2022-06-23 05:37:42.956852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    x = b'''
 - name: user1
   uid: 1000
   group: wheel
   groups: [ 'test', 'wheel' ]
   state: present
 - name: user2
   uid: 1001
   state: absent
 - user:
     name: user3
     uid: 1002
'''

    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
        if not display.verbosity:
            display.verbosity = 4

    loader = AnsibleLoader(x)
    display.display(loader.get_single_data())

    for d in loader:
        display.display(d)

# Generated at 2022-06-23 05:37:44.850966
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Very basic test as the class constructor doesn't do anything
    AnsibleLoader('stream', 'file_name', vault_secrets=[])


# Generated at 2022-06-23 05:37:48.591726
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    ansible_loader = AnsibleLoader(io.StringIO())
    pass

# Generated at 2022-06-23 05:37:49.385096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:37:53.598482
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    stream = StringIO("""\
- hosts: localhost
  tasks:
    - name: ping
      ping:
      register: output
    - name: show result
      debug:
        var: output.stdout
""")
    loader = AnsibleLoader(stream)
    assert loader.get_single_data()

# Generated at 2022-06-23 05:37:54.978327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test
    x = AnsibleLoader(None)
    assert x is not None

# Generated at 2022-06-23 05:38:05.299377
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class DummyStream:
        def __init__(self):
            self.tokens = ['a_token']
            self.current_token = self.tokens.pop(0)

        def peek(self):
            return self.current_token

        def get(self):
            res = self.current_token
            if self.tokens:
                self.current_token = self.tokens.pop(0)
            else:
                self.current_token = None
            return res

        def get_token(self):
            return self.get()

        def check_token(self, *choices):
            return self.current_token in choices

        def check_type(self, *choices):
            return False


# Generated at 2022-06-23 05:38:05.838435
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:16.673545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_null(), type(None))
    assert loader.construct_yaml_bool(True) is True
    assert loader.construct_yaml_bool(False) is False
    assert loader.construct_yaml_int(1) == 1
    assert loader.construct_yaml_float(1.1) == 1.1
    assert loader.construct_yaml_binary(b'binary') == b'binary'

# Generated at 2022-06-23 05:38:28.805310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=import-error
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import sys
    from .test_loader import MockVaultSecret
    from .test_loader import vault_secret_mock
    from .test_loader import FakeFile
    from .test_loader import fake_file_mock


# Generated at 2022-06-23 05:38:37.793486
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("foo")
    assert hasattr(loader, "construct_object"), "AnsibleLoader does not have the construct_object attribute"
    assert hasattr(loader, "construct_sequence"), "AnsibleLoader does not have the construct_sequence attribute"
    assert hasattr(loader, "construct_yaml_map"), "AnsibleLoader does not have the construct_yaml_map attribute"
    assert hasattr(loader, "construct_yaml_str"), "AnsibleLoader does not have the construct_yaml_str attribute"
    assert hasattr(loader, "construct_yaml_seq"), "AnsibleLoader does not have the construct_yaml_seq attribute"
    assert hasattr(loader, "construct_yaml_int"), "AnsibleLoader does not have the construct_yaml_int attribute"

# Generated at 2022-06-23 05:38:50.125502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    example = """
    - hosts: all
      gather_facts: False
      tasks:
        - name: ensure apache is at the latest version
          yum: name=httpd state=latest
    """

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(example)

        def test_init(self):
            self.assertIsInstance(self.loader, Reader)
            self.assertIsInstance(self.loader, Scanner)
            self.assertIsInstance(self.loader, Parser)
            self.assertIsInstance(self.loader, Composer)
            self.assertIsInstance

# Generated at 2022-06-23 05:38:59.791826
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib  # pylint: disable=import-error
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode  # pylint: disable=import-error


# Generated at 2022-06-23 05:39:05.061670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader_content = AnsibleLoader("YAML text")
    assert isinstance(loader_content, AnsibleLoader)
    assert isinstance(loader_content.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-23 05:39:07.217913
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader  # Using dummy internal object to force pyflakes not complain

# Generated at 2022-06-23 05:39:18.875763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    filename = os.path.join(os.path.dirname(__file__), 'vault-id.yml')
    doc = """---
vault_password_file: '/some/path'
        """

    test_fd, test_path = tempfile.mkstemp()
    os.close(test_fd)
    with open(test_path, 'wb') as test_file:
        test_file.write(to_bytes(doc))
    x = AnsibleLoader(open(filename, 'r'), file_name=test_path).get_single_data()
    assert x == {"vault_password_file": "/some/path"}
    os.unlink(test_path)

# Generated at 2022-06-23 05:39:30.885297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.unsafe_proxy import wrap_var

    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader.vault_secrets_lookup_key is None

    vault_secrets = {'vault': 'secrets'}
    vault_secrets_lookup_key = 'secrets'

    loader = AnsibleLoader(None, 'f1', vault_secrets=vault_secrets)
    assert loader.file_name == 'f1'
    assert loader.vault_secrets is vault_secrets
    assert loader.vault_secrets_lookup_key == vault_secrets_lookup_key

    loader = AnsibleLoader(None, vault_secrets=vault_secrets)
   

# Generated at 2022-06-23 05:39:33.874761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None, None)
    assert a.file_name == None
    assert a.vault_secrets == None

# Generated at 2022-06-23 05:39:34.916833
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)



# Generated at 2022-06-23 05:39:41.946697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This test is a sanity check. It makes sure the constructor of class AnsibleLoader is
    functionning properly.
    """
    assert hasattr(AnsibleLoader, "__init__")
    # Test calls of constructor
    try:
        # Instantiate without passing arguments
        AnsibleLoader()
    except TypeError as ex:
        assert "__init__() takes at least 2 arguments (1 given)" in ex.message
    # Instantiate with a stream argument
    AnsibleLoader(None)

# Generated at 2022-06-23 05:39:47.363971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load a test string
    test_string = "{'var1': '{{ foo }}'}"
    loader = AnsibleLoader(test_string, 'TestFile', None)

    # Turn the string into a data structure
    data = loader.get_single_data()

    # Check that the data structure is the right type and has the right contents
    assert isinstance(data, dict)
    assert data['var1'] == '{{ foo }}'


# Generated at 2022-06-23 05:39:53.869001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = '---\nkey: 12345\n'
    yaml_obj = AnsibleLoader(stream, vault_secrets=[{'test': 'vault'}])
    assert yaml_obj.stream is not None
    assert yaml_obj.get_data() == {'key': AnsibleUnicode(u'12345')}


# Generated at 2022-06-23 05:39:54.886105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-23 05:40:06.951677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.error
    with io.BytesIO(b'''---
- hosts: localhost
  tasks:
  - name: be_idle
    command: /bin/true
''') as stream:
        ansible_loader = AnsibleLoader(stream)
        ansible_loader.get_single_data()
        assert isinstance(ansible_loader, ansible.parsing.yaml.objects.AnsibleBaseYAMLObject)
        assert isinstance(ansible_loader, ansible.parsing.yaml.error.AnsibleError)

# Generated at 2022-06-23 05:40:13.129200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    import yaml
    loader = AnsibleLoader(yaml.compose(YAML_DOCUMENT))
    assert loader.get_single_data() == {'key1': 'value1', 'key2': 123, 'key3': 'value2', 'key4': {'key5': 'value3'}}

# Generated at 2022-06-23 05:40:14.621492
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:40:15.904456
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None, None)
    assert obj is not None

# Generated at 2022-06-23 05:40:28.196835
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-statements
    import yaml

    yaml.SafeLoader = AnsibleLoader
    ansible_loader = yaml.SafeLoader
    assert isinstance(ansible_loader(yaml.compose('')), yaml.SafeLoader)

    data = '{"key": "value"}'
    data = yaml.load(data)
    assert isinstance(data, dict)

    data = "key: value"
    data = yaml.load(data)
    assert isinstance(data, dict)

    data = '''\
key:
  - {a: b}
'''
    data = yaml.load(data)
    assert isinstance(data, dict)

    data = '''
# comment
key: value
'''
    data = yaml.load(data)


# Generated at 2022-06-23 05:40:29.488417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:40:39.105072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access

    # test empty string
    loader = AnsibleLoader('')
    assert loader.stream.check_token() is None

    # test single string with no newline
    loader = AnsibleLoader('a')
    assert loader.stream.check_token() == 'a'

    # test adding more text after a scan
    loader = AnsibleLoader('a\n')
    assert loader.stream.check_token() == 'a'
    loader.stream.fetch_more_tokens()
    assert loader.stream.check_token() is None
    loader.stream.fetch_more_tokens()
    loader.stream.push_token('b')
    assert loader.stream.check_token() == 'b'

    # test adding more tokens before a scan
    loader = AnsibleLoader

# Generated at 2022-06-23 05:40:47.670355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
- hosts: localhost
  tasks:
  - name: task 1
    debug: msg="{{ test }}"
    when: 1
  - name: task 2
    debug: msg="{{ test }}"
    when: 0
"""
    expected_result = [
        {"hosts": "localhost",
         "tasks": [{"debug": {"msg": "{{ test }}"},
                    "name": "task 1", "when": 1},
                   {"debug": {"msg": "{{ test }}"},
                    "name": "task 2", "when": 0}]
         }
    ]

    loader = AnsibleLoader(
        content,
        vault_secrets=None
    )
    data = loader.get_single_data()
    assert data == expected_result


# Generated at 2022-06-23 05:40:58.305701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pprint
    pp = pprint.PrettyPrinter(indent=4)

    loader1 = AnsibleLoader("foo: bar\n")
    try:
        print("loader1:")
        pp.pprint(loader1.get_single_data())
    except:
        print("loader1: --- ERROR ---")
        pass

    loader2 = AnsibleLoader(["foo: bar\n", "baz: boz\n"])
    try:
        print("loader2:")
        pp.pprint(loader2.get_single_data())
    except:
        print("loader2: --- ERROR ---")
        pass

    data = "foo: bar\nbaz: boz\n"
    loader3 = AnsibleLoader(data)

# Generated at 2022-06-23 05:40:59.210788
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None)
    assert True

# Generated at 2022-06-23 05:41:01.132367
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:41:05.286489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.constants import DEFAULT_VAULT_IDENTITY_LIST
    loader = AnsibleLoader(file_name='/tmp/foo', vault_secrets=[])
    assert loader.file_name == '/tmp/foo'
    assert loader.vault_secrets == [dict(identity=x, password='fake') for x in DEFAULT_VAULT_IDENTITY_LIST]
    assert loader.get_single_data() is None

# Generated at 2022-06-23 05:41:10.829113
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def check_loader(data, expected):
        loader = AnsibleLoader(data)
        result = loader.get_single_data()
        assert result == expected

    check_loader('key: value', {'key': 'value'})
    check_loader('key: 1.0', {'key': 1.0})
    check_loader('key: [1, 2]', {'key': [1, 2]})

# Generated at 2022-06-23 05:41:22.251007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import unittest

    class TestModule(unittest.TestCase):
        def test_AnsibleLoader_fails_with_no_args(self):
            args = []
            if py3compat.PY3:
                self.assertRaises(TypeError, AnsibleLoader, *args)
            else:
                self.assertRaises(TypeError, AnsibleLoader, *args)

        def test_AnsibleLoader_passes_with_one_arg(self):
            stream = ""
            args = [stream]
            instance = AnsibleLoader(*args)
            self.assertEqual(instance.stream, stream)
            self.assertEqual(instance._file_name, None)
            self.assertEqual(instance._vault_secrets, None)


# Generated at 2022-06-23 05:41:22.889160
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:34.432323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = u"""
- hosts: all
  tasks:
   - name: test
     debug: msg="hello world"

- hosts: testhost
  tasks:
   - name: test
     debug: msg="hello world"
"""
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    assert data == [{u'hosts': u'all', u'tasks': [{u'name': u'test', u'debug': {u'msg': u'hello world'}}]},
                    {u'hosts': u'testhost', u'tasks': [{u'name': u'test', u'debug': {u'msg': u'hello world'}}]}]



# Generated at 2022-06-23 05:41:45.002357
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .yaml_loader import DataLoader
    from .secure_overlay import VaultLib, VaultSecret
    from ansible.parsing.vault import VaultLib as LegacyVaultLib

    vault_secrets = (VaultLib()).read_vault_secrets(['tests/test_vault_pass.txt'])
    assert vault_secrets == {VaultSecret('$ANSIBLE_VAULT;1.1;AES256', 'secret\n')}

    loader = DataLoader()
    loader.set_vault_secrets([('default', vault_secrets)])
    assert loader.vault_secrets == {'default': vault_secrets}


# Generated at 2022-06-23 05:41:56.481615
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import sys
    import ansible.parsing.dataloader.vault as vault
    import ansible.parsing.dataloader.templates as templates

    # Basic test: Re-run the same test from unit_loader.py, but now
    # using the AnsibleConstructor explicitly instead of implicitly
    # through the Loader.

    loader = AnsibleLoader(file("unit/tests/sample_yaml_vault.yaml"), file_name="unit/tests/sample_yaml_vault.yaml", vault_secrets=[('vault', vault.VaultLib("mysecret"))])
    loader.vault_secrets[0][1].is_encrypted_data("$ANSIBLE_VAULT;1.1;AES256;bb")
    loader.vault_secrets[0][1].is_