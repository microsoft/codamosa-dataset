

# Generated at 2022-06-23 05:31:57.564324
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test that the required methods for yaml-loader are implemented
    """
    loader = AnsibleLoader(None)
    assert hasattr(loader, '_yaml_get_value')
    assert hasattr(loader, '_yaml_add_implicit_resolver')
    assert hasattr(loader, '_yaml_add_path_resolver')
    assert hasattr(loader, '_yaml_construct_mapping')
    assert hasattr(loader, '_yaml_construct_mapping_with_defaults')

# Generated at 2022-06-23 05:32:02.206805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_attributes = [
        'contents',
        'best_effort_order',
        'file_name',
        'vault_secrets',
        '_curr_indent',
        '_curr_line',
        '_curr_col',
        '_curr_buf'
    ]

    for attr in class_attributes:
        assert hasattr(AnsibleLoader, attr)

# Generated at 2022-06-23 05:32:10.350614
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import subprocess

    # TODO: need a more robust "is running from within test?" check
    run_under_test = 'nosetests' in sys.modules

    if not run_under_test:
        print("Only for testing purposes")
        sys.exit()

    input_string = """
    1:
      one: 1
      two: two
      three: 3
      four:
      - 1
      - 2
      - 3
      - four
      bool: yes
    2:
      foo: bar
      baz: foo
    """

    ansible_loader = AnsibleLoader(input_string)
    data = ansible_loader.get_single_data()

# Generated at 2022-06-23 05:32:14.770243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_text = '''
- name: test
  hosts: localhost
  tasks:
    - action: command echo '123'
'''
    yaml.safe_load(yaml_text)

# Generated at 2022-06-23 05:32:25.468779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load a string
    loader = AnsibleLoader(u'this is a test')
    assert loader.get_single_data() == u'this is a test'

    # Load invalid YAML
    loader = AnsibleLoader(u'[foo,bar:baz]')
    try:
        loader.get_single_data()
        assert False
    except Exception as e:
        assert 'mapping values are not allowed here' in str(e) or 'while scanning a simple key' in str(e)

    # Load a non-unicode string
    loader = AnsibleLoader('this is a test')
    assert loader.get_single_data() == u'this is a test'

    # Test the default Ansible explicit type

# Generated at 2022-06-23 05:32:31.456398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = '''
- name: host1
  ansible_host: 127.0.0.1
- name: host2
  ansible_host: 127.0.0.2
'''
    loader = AnsibleLoader(test_data)
    host_list = [host for host in loader]

    assert host_list[0]['name'] == "host1"
    assert host_list[1]['name'] == "host2"


# Generated at 2022-06-23 05:32:33.696992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import SafeLoader

    assert issubclass(AnsibleLoader, SafeLoader)


# Generated at 2022-06-23 05:32:36.277057
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Convert a string to a AnsibleLoader object
    loader = AnsibleLoader("string_with_no_format")
    assert isinstance(loader, AnsibleLoader)


# Generated at 2022-06-23 05:32:39.821040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("data", file_name="dummy_file_name")
    assert loader.file_name == "dummy_file_name"

# Generated at 2022-06-23 05:32:47.655396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test loader class without libyaml
    has_libyaml=False
    global HAS_LIBYAML
    HAS_LIBYAML=has_libyaml
    global AnsibleLoader
    AnsibleLoader = AnsibleLoader
    loader = AnsibleLoader(None, None, None)
    assert loader.composer is not None

    # Test loader class with libyaml
    has_libyaml=True
    global HAS_LIBYAML
    HAS_LIBYAML=has_libyaml
    global AnsibleLoader
    AnsibleLoader = AnsibleLoader
    loader = AnsibleLoader(None, None, None)
    assert loader.composer is None

# Generated at 2022-06-23 05:32:53.443387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml_str = '''
- hosts: test_host
  vars:
    var1: True
  tasks:
  - name: test task
    debug:
      msg: "This is {{ var1 }}"
    when: var1
'''
    yaml_obj = yaml.load(yaml_str, Loader=AnsibleLoader)
    print(yaml_obj)

# Generated at 2022-06-23 05:32:58.925899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "---"
    loader = AnsibleLoader(stream)
    assert isinstance(loader.stream, Reader)
    assert isinstance(loader.scanner, Scanner)
    assert isinstance(loader.parser, Parser)
    assert isinstance(loader.composer, Composer)
    assert isinstance(loader.constructor, AnsibleConstructor)
    assert isinstance(loader.resolver, Resolver)

# Generated at 2022-06-23 05:33:04.934633
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    loader = AnsibleLoader(None)
    assert isinstance(loader.compose_node(None, None, None), AnsibleMapping)
    assert isinstance(loader.compose_sequence_node(None, None, None), AnsibleSequence)
    loader.dispose()

# Generated at 2022-06-23 05:33:13.507737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml.constructor import ConstructorError
    from yaml.resolver import ResolverError

    assert issubclass(AnsibleLoader, AnsibleConstructor)

    # It shouldn't be possible to instantiate AnsibleLoader directly
    try:
        AnsibleLoader(1)
    except TypeError as e:
        assert "Can't instantiate abstract class AnsibleLoader with abstract methods __init__" in str(e)


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:33:20.460903
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    class AnsibleLoader is a subclass of yaml.Reader, yaml.Scanner, yaml.Parser, yaml.Composer, AnsibleConstructor, and yaml.Resolver.
    """

    # pylint: disable=too-many-ancestors
    from ansible.utils.path import unfrackpath
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping

    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)

# Generated at 2022-06-23 05:33:32.227759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    import os
    test_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'vault_test.yml')
    test_str = open(test_file, 'rb').read()
    test_str_unicode = test_str.decode('utf-8')
    stream = StringIO(test_str_unicode)
    loader = AnsibleLoader(stream, vault_secrets=['test'])
    vault = VaultLib

# Generated at 2022-06-23 05:33:33.399693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-23 05:33:42.455933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Read string data as YAML document
    loader = AnsibleLoader('[1,2,3]')
    data = loader.get_single_data()
    assert type(data) == list
    assert data == [1, 2, 3]

    # Read list of string data as YAML stream
    loader = AnsibleLoader(['[1,2,3]', '{key: value}'])
    data = loader.get_single_data()
    assert type(data) == list
    assert data == [1, 2, 3]
    data = loader.get_single_data()
    assert type(data) == dict
    assert data == {'key': 'value'}

    # Read file-like object as YAML stream
    import io

# Generated at 2022-06-23 05:33:53.362651
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects

    # Check attributes set by Parser constructor
    assert AnsibleLoader.ID == 'id'
    assert isinstance(AnsibleLoader.resolver, Resolver)

    # Check attributes set by AnsibleConstructor constructor
    # Note: AnsibleConstructor.yaml_constructors is
    # set in the AnsibleConstructor constructor.
    assert AnsibleLoader.yaml_constructors == objects.AnsibleConstructor._yaml_constructors  # pylint: disable=protected-access
    assert AnsibleLoader.yaml_multi_constructors == objects.AnsibleConstructor._yaml_multi_constructors  # pylint: disable=protected-access

    # Check attributes set by Resolver constructor
    assert AnsibleLoader.yaml_implicit_resolvers == {}


# Generated at 2022-06-23 05:34:04.396481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals
    '''unit test for constructor of class AnsibleLoader'''

    from ansible.parsing.utils.yaml import from_yaml

    # test_AnsibleLoader_vault_id #
    # from ansible.parsing.vault import VaultLib
    # v = VaultLib(None)  # vault_secrets = None
    # loader = AnsibleLoader(None, vault_secrets=v)
    # assert loader.vault_secrets is v
    # assert loader._vault_id is None
    #
    # # test_AnsibleLoader_vault_id #
    # v = VaultLib({'vault_pass': 'secret', 'vault_identity': 'vault-id'})
    # loader = AnsibleLoader(None

# Generated at 2022-06-23 05:34:13.787231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    - include:
        file: '{{ myfile }}'
    - include:
        file: '{{ myfile2 }}'
    - include:
        file: '{{ myfile3 }}'
    '''
    loader = AnsibleLoader(data)
    loader.advance()
    token = loader.advance()
    loader.get_tokens()
    loader.get_mark()
    loader.get_token_id()
    loader.get_data()
    loader.get_start_mark()
    loader.get_end_mark()
    loader.peek_token()
    loader.peek_token()
    loader.check_token()
    loader.check_token()
    loader.check_type('test')
    loader.check_type('test')
    loader.check_version

# Generated at 2022-06-23 05:34:19.177722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
key:
    sub1: value1
    sub2: value2
        '''
    loader = AnsibleLoader(data)
    yaml_data = loader.get_data()
    assert yaml_data.get('key').get('sub1') == 'value1'
    assert yaml_data.get('key').get('sub2') == 'value2'

# Generated at 2022-06-23 05:34:30.310548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data1 = """
    foo:
      - bar:
          baz: quux
    """

    data2 = """
    foo:
      - bar:
          baz: { a: 1 }
    """

    obj1 = AnsibleLoader(data1).get_single_data()
    obj2 = AnsibleLoader(data2).get_single_data()

    for obj in (obj1, obj2):
        assert isinstance(obj, dict)
        assert isinstance(obj['foo'], list)
        assert isinstance(obj['foo'][0], dict)
        assert isinstance(obj['foo'][0]['bar'], dict)

    assert obj1['foo'][0]['bar']['baz'] == 'quux'

# Generated at 2022-06-23 05:34:33.290576
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:34:44.486073
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test case 1:
    # No file_name attribute is added to class AnsibleLoader
    loader = AnsibleLoader(None)
    assert(not hasattr(loader, 'file_name'))

    # Test case 2:
    # file_name attribute is added to class AnsibleLoader
    loader = AnsibleLoader(None, 'test_file')
    assert(hasattr(loader, 'file_name'))
    assert(loader.file_name == 'test_file')

    # Test case 3:
    # No vault_secrets attribute is added to class AnsibleLoader
    loader = AnsibleLoader(None)
    assert(not hasattr(loader, 'vault_secrets'))

    # Test case 4:
    # vault_secrets attribute is added to class AnsibleLoader

# Generated at 2022-06-23 05:34:47.013034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.loader import AnsibleLoader
    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader, AnsibleLoader)

# Generated at 2022-06-23 05:34:51.047050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    document = StringIO.StringIO("""
        ---
        - hosts: all
        - hosts: somehost
        """)

    assert AnsibleLoader(document)
    assert AnsibleLoader(document,file_name="testfile")
    assert AnsibleLoader(document,vault_secrets=[])

# Generated at 2022-06-23 05:34:52.486420
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('foo')._file_name == 'foo'

# Generated at 2022-06-23 05:34:55.081832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    content = AnsibleLoader(None)
    assert content

if __name__ == '__main__':
    import unittest
    unittest.main(module=__name__)

# Generated at 2022-06-23 05:35:03.856342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
        from ansible.parsing.yaml.objects import AnsibleUnicode
        test_string = AnsibleUnicode(u"""
        ---
        foo: 1
        bar:
          bam: true
        """)
        test_stream = StringIO(test_string)
    else:
        from StringIO import StringIO
        test_stream = StringIO("""
        ---
        foo: 1
        bar:
          bam: true
        """)

    loader = AnsibleLoader(test_stream)
    data = loader.get_single_data()

    assert data['foo'] == 1
    assert data['bar']['bam'] is True

# Generated at 2022-06-23 05:35:04.976555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:35:06.408298
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:35:08.418619
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Class AnsibleLoader is a subclass of Parser
    assert issubclass(AnsibleLoader, Parser)

# Generated at 2022-06-23 05:35:18.806804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.attribute import Attribute, FieldAttribute

    class AYO(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_tag = u'!AYO'

        attr = FieldAttribute(isa='str')

    ayo = AYO()
    ayo.attr = "bar"
    data = dict(__ayo__=ayo)

    x = AnsibleLoader("__ayo__: !AYO attr: bar").get_single_data()
    assert x == data

    ayo_dict = dict(__ayo__=dict(attr="bar"))
    x = AnsibleLoader("__ayo__:\n  { 'attr': 'bar' }").get

# Generated at 2022-06-23 05:35:21.735858
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    constructor=AnsibleConstructor()

# Generated at 2022-06-23 05:35:23.822527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test __init__ by asserting that there's no exception when loading the empty string
    AnsibleLoader(string='')

# Generated at 2022-06-23 05:35:29.925285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_loader = AnsibleLoader("")
    assert yaml_loader.file_name is None

    # The following tests the default contructor of class AnsibleConstructor.
    # This is the only 'default' constructor that uses file_name.
    yaml_loader = AnsibleLoader("", file_name='test')
    assert yaml_loader.file_name == 'test'

# Generated at 2022-06-23 05:35:31.043223
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-23 05:35:33.709033
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    check_data = yaml.load(u'---\nhello world', Loader=yaml.SafeLoader)
    assert check_data == "hello world"

# Generated at 2022-06-23 05:35:35.463635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)  # pylint: disable=too-many-function-args

# Generated at 2022-06-23 05:35:47.588659
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    ansible_loader = AnsibleLoader(file_name='foobar.yml')
    assert ansible_loader.stream is None
    assert ansible_loader.file_name == 'foobar.yml'
    assert isinstance(ansible_loader.vault_secrets, list)
    assert isinstance(ansible_loader.vault_secrets[0], AnsibleUnicode)
    assert isinstance(ansible_loader.resolver.yaml_constructors.loc['tag:yaml.org,2002:str'], AnsibleUnicode)
    assert isinstance(ansible_loader.resolver.yaml_constructors.loc['tag:yaml.org,2002:python/unicode'], AnsibleUnicode)

   

# Generated at 2022-06-23 05:35:50.501861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible
    AnsibleLoader(stream=ansible.__file__, file_name=ansible.__file__, vault_secrets=None)

# Generated at 2022-06-23 05:36:00.505960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import ansible.parsing.yaml.loader

    if not hasattr(io, 'StringIO'):
        from io import BytesIO as StringIO
    else:
        from io import StringIO

    ansible.parsing.yaml.constructor.AnsibleConstructor.add_constructor(
        u'tag:yaml.org,2002:timestamp',
        type(u''),
        ansible.parsing.yaml.loader.construct_yaml_str)

    AnsibleLoader(StringIO(u"--- !!str 2012-12-15"))

# Generated at 2022-06-23 05:36:06.697360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    stream, file_name, vault_secrets = ['test_value'], 'test.yml', 'vault_secrets'

    loader = AnsibleLoader(stream, file_name, vault_secrets)

    assert loader.stream is stream
    assert loader.file_name is file_name
    assert loader.vault_secrets is vault_secrets
    assert loader.vault is AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:36:14.820039
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=no-self-use
    if HAS_LIBYAML:
        from yaml import CSafeLoader as yLoader
    else:
        from yaml import SafeLoader as yLoader

    loader = AnsibleLoader(stream='', file_name='test_file_name')

    assert isinstance(loader, yLoader)
    assert loader.file_name == 'test_file_name'
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:36:24.579569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedFile
    ansible_loader = AnsibleLoader("")

    assert isinstance(ansible_loader.construct_yaml_seq(""), AnsibleSequence)
    assert isinstance(ansible_loader.construct_yaml_map(""), AnsibleMapping)

    # Check that the AnsibleLoader knows how to construct
    # an AnsibleVaultEncryptedUnicode object when given a string that
    # starts with $ANSIBLE_VAULT
    expected_token = '$ANSIBLE_VAULT;1.1;AES256'

# Generated at 2022-06-23 05:36:26.459016
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:36:27.503540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-23 05:36:30.606953
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(b"", "")
    assert loader.get_single_data() is None


# Generated at 2022-06-23 05:36:35.126184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = AnsibleLoader('')
    assert yaml.file_name == None

    yaml = AnsibleLoader('', file_name="foobar", vault_secrets={})
    assert yaml.file_name == "foobar"

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:45.490534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.compat.tests import unittest
    from ansible.vars import AnsibleVars
    from ansible.template import AnsibleTemplate
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    import ansible.parsing.yaml.data

    class TestAnsibleLoader(unittest.TestCase):
        def test_basic_yaml_constructor(self):
            '''
            Basic ansible yaml constructor test
            '''
            loader = AnsibleLoader('')

            YamlObj = AnsibleBaseYAMLObject()
            YamlObj.ansible_pos = (0,0)

            # Check if ansible_pos is set properly
            self.assertEqual(YamlObj.ansible_pos, (0,0))

# Generated at 2022-06-23 05:36:50.692096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        loader = AnsibleLoader('[1, 2]', file_name='foo.yaml')
        loader.construct_yaml_seq(None)
    else:
        # pylint: disable=unused-variable
        loader = AnsibleLoader('[1, 2]', file_name='foo.yaml')

# Generated at 2022-06-23 05:36:58.273000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
---
foo: 42
bar:
- item: value
- item: value
baz: !!python/object/apply:os.system [ echo 42 ]
"""

    loader = AnsibleLoader(stream, file_name='<string>')
    result = loader.get_single_data()

    assert result.get('foo', None) == 42
    assert result.get('bar', None) == [{'item': 'value'}, {'item': 'value'}]
    assert result.get('baz', None) is None
    assert loader.get_failed_data('baz') == '!!python/object/apply:os.system [ echo 42 ]'

# Generated at 2022-06-23 05:37:08.814387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.stream = u"---\n"
            self.loader = AnsibleLoader(io.StringIO(self.stream))

        def test_composer(self):
            self.loader.get_data()
            self.assertIsInstance(self.loader.composer, type(self.loader))

        def test_construct_scalar(self):
            self.assertEqual(
                self.loader.construct_scalar('tag', 'string'),
                'string'
            )


# Generated at 2022-06-23 05:37:10.406755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Just test to verify that the class is implemented without any error
    AnsibleLoader('')

# Generated at 2022-06-23 05:37:21.141663
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    test_string = u"""
---
a: 1
b:
  c: 3
  d: 4
"""
    test_stream = StringIO(test_string)
    test_loader = AnsibleLoader(test_stream)
    assert str(type(test_loader)) == "<class 'ansible.parsing.yaml.loader.AnsibleLoader'>"

    test_data = test_loader.get_single_data()
    assert isinstance(test_data, dict)
    assert test_data.get('a') == 1
    assert isinstance(test_data.get('b'), dict)
    assert test_data.get('b', {}).get('c')

# Generated at 2022-06-23 05:37:26.374472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load

    data = ('[1, 2, 3]', '{foo: bar}', '{foo: !!int \'123\'}')

    for d in data:
        yaml = load(d)
        assert isinstance(yaml, list) or isinstance(yaml, dict)

# Generated at 2022-06-23 05:37:35.436460
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from yaml import CLoader as Loader
    except ImportError:
        from yaml import Loader

    loader = Loader(stream="""
       - !!python/object:inspect.getmembers
         args:
         - !!python/name:__main__.Foo
    """, Loader=AnsibleLoader)

    data = loader.get_data()

# Generated at 2022-06-23 05:37:38.854392
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    unit test for AnsibleLoader
    '''
    stream = '''
#
# This is a test.
#
- name: test case
  hosts:
    - server1
    - server2'''
    loader = AnsibleLoader(stream)
    loader

# Generated at 2022-06-23 05:37:44.834311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from nose.tools import assert_equal

    def get_AnsibleLoader():
        stream = '''
        ---
        key1: val1
        key2: val2
        '''
        obj = AnsibleLoader(stream, file_name="test_loader.yml")
        return obj

    obj = get_AnsibleLoader()
    assert_equal(obj.data, {'key1': 'val1', 'key2': 'val2'})

# Generated at 2022-06-23 05:37:48.913240
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)
    representation = loader.represent_data(None)
    assert representation == Null

# Generated at 2022-06-23 05:37:49.617382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:51.766519
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string = "Happy Days!"
    loader = AnsibleLoader(test_string)
    assert loader.get_single_data() == "Happy Days!"

# Generated at 2022-06-23 05:37:53.869059
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load(u'foo: bar', Loader=AnsibleLoader)

# Generated at 2022-06-23 05:38:04.229663
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_native

    def _test_value(string, expected_value):
        loader = AnsibleLoader(string)
        value = loader.get_single_data()
        assert isinstance(value, type(expected_value))
        assert value == expected_value

        # Verify that the value can be dumped back to the same YAML string.
        stream = to_native(to_bytes(u'---\n'), encoding='utf-8')
        stream += to_native(to_bytes(u'...\n'), encoding='utf-8')
        dumper = AnsibleDumper(stream)
        dumper

# Generated at 2022-06-23 05:38:04.737799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:38:15.576630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    data = """
---
# This is some sample data for testing the constructor

- name: very simple data
  some_key: some value

- name: complex data
  some_dict:
    hostname: localhost
    port: 5309
  some_list:
    - item1
    - item2
    - item3
  a_dict_with_list:
    a_list:
      - 1
      - 2
      - 4
      - 5
    another_list:
      - 9
      - 8
      - 7
      - 6
      - 5
      - 4
      - 3
"""
    datafile = String

# Generated at 2022-06-23 05:38:27.309722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    stream = '!vault |\n          $ANSIBLE_VAULT;1.1;AES256\n         6236353338616263636533353132663866323064623731653262323738633839\n         33353863316166666532656530613032373133393339373665666562633334653\n         1336332373166303339393565323433623339\n  '
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:38:28.751898
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(open(__file__).read())



# Generated at 2022-06-23 05:38:30.864719
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_loader = AnsibleLoader(stream=None, file_name=None)
    assert isinstance(test_loader, AnsibleLoader)

# Generated at 2022-06-23 05:38:33.246496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass
    # TODO

# Generated at 2022-06-23 05:38:39.257709
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Following line will fail if the class AnsibleLoader is not defined
    x = AnsibleLoader(None)

    # Following line will fail if the class AnsibleLoader is not a subclass of AnsibleConstructor
    assert isinstance(x, AnsibleConstructor)

    # Following line will fail if the class AnsibleLoader does not define a function called __init__
    assert hasattr(x, '__init__')

# Generated at 2022-06-23 05:38:46.011284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = b'{ foo: bar }'
    loader = AnsibleLoader(data)
    obj = loader.get_single_data()
    assert isinstance(obj, dict)
    assert 'foo' in obj
    assert isinstance(obj['foo'], AnsibleUnicode)
    assert obj['foo'] == 'bar'

# Generated at 2022-06-23 05:38:54.688323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    test_cases = [
        ["---\n{hello: world}\n", {'hello': 'world'}],
        ["{hello: world}\n", {"hello": "world"}],
        ["[hello,world]\n", ["hello", "world"]],
        ["hello world\n", "hello world\n"],
        [123, 123],
        [True, True],
        [None, None],
    ]
    for test in test_cases:
        loader = AnsibleLoader(test[0])
        data = loader.get_single_data()
        assert(test[1] == data)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 05:39:02.277422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import getpass
    import yaml
    import shutil
    from ansible.errors import AnsibleParserError
    from ansible.parsing.vault import VaultLib

    # Test AnsibleConstructor.file_name
    stream = open(__file__, 'rb')
    loader = AnsibleLoader(stream)
    assert loader.file_name == __file__

    # Test resolving tokens
    loader.file_name = None
    if sys.version_info[0] < 3:
        name = 'name'
    else:
        name = b'name'
    if sys.version_info[0] < 3:
        ansible_type = '!!ansible'
    else:
        ansible_type = b'!!ansible'

# Generated at 2022-06-23 05:39:09.658347
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    yaml_str = StringIO.StringIO("""
- hosts: localhost
  tasks:
  - shell: echo "hello world"
  - name: test with_items
    debug: msg="{{item}}"
    with_items:
      - one
      - two
""")
    data = AnsibleLoader(yaml_str).get_single_data()
    assert data['hosts'] == 'localhost'
    assert data['tasks'][0]['shell'] == 'echo "hello world"'
    assert data['tasks'][1]['name'] == 'test with_items'
    assert data['tasks'][1]['debug']['msg'] == '{{item}}'
    assert data['tasks'][1]['with_items'][0] == 'one'

# Generated at 2022-06-23 05:39:11.424894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Checking if the constructor is working or not
    assert AnsibleLoader("abcd")

# Generated at 2022-06-23 05:39:12.580954
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader  # avoiding warning from pylint

# Generated at 2022-06-23 05:39:23.139695
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
- hosts: localhost
  tasks:
  - name: test
    yum:
      name: "{{ item }}"
    with_items:
    - test
    - test2
- hosts: localhost
  tasks:
  - name: test
    yum:
      name: "{{ item }}"
      state: present
    with_items:
    - test
    - test2
- hosts: localhost
  tasks:
  - name: This is a test
    with_items:
      - test
      - test2
    yum:
      name: "{{ item }}"
- hosts: localhost
  tasks:
  - name: This is a test
    with_items:
      - test
      - test2
    yum: "{{ item }}"
"""
    data = Ansible

# Generated at 2022-06-23 05:39:34.550207
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
        ---
        a_string: hello
        a_list:
            - yaml
            - seems
            - easy
    '''
    loader = AnsibleLoader(stream)
    result = loader.get_single_data()
    assert result == {'a_string': 'hello', 'a_list': ['yaml', 'seems', 'easy']}

    # Set file_name to 'foo' and vault_secrets to [VaultSecret('bar')]
    loader = AnsibleLoader(stream, file_name='foo', vault_secrets=[VaultSecret('bar')])
    result = loader.get_single_data()
    assert result == {'a_string': 'hello', 'a_list': ['yaml', 'seems', 'easy']}


# Generated at 2022-06-23 05:39:44.853144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import sys
    import io

    class MyStream:
        def __init__(self, value):
            self._value = value
            self._start = 0

        def read(self, count=None):
            if count is None:
                count = len(self._value)
            end = self._start + count
            if end > len(self._value):
                end = None
            result = self._value[self._start:end]
            self._start += count
            return result

    stream = MyStream("{foo: !bar !baz 'abc'}")

    loader = AnsibleLoader(stream)
    loader.construct_yaml_map.add_constructor(u'!bar', loader.simple_constructor)

# Generated at 2022-06-23 05:39:47.882729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    :return:
    """
    x = AnsibleLoader(file_name=None, stream=None, vault_secrets=None)

# Generated at 2022-06-23 05:39:54.431815
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from collections import namedtuple, OrderedDict

    loader = AnsibleLoader(StringIO(''))
    assert loader.ordered_dict is OrderedDict

    loader = AnsibleLoader(StringIO(''), use_ordered_dict=True)
    assert loader.ordered_dict is OrderedDict

    loader = AnsibleLoader(StringIO(''), use_ordered_dict=False)
    assert loader.ordered_dict is dict

# Generated at 2022-06-23 05:40:06.495328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_yaml = 'test.yml'
    data = {'a': 1}
    from yaml import load, dump, Dumper
    from yaml.representer import Representer
    from ansible.parsing.yaml.constructor import AnsibleSafeRepresenter
    import ansible.parsing.yaml.objects

    AnsibleLoader(stream=data, file_name=my_yaml)
    load(stream=data, Loader=AnsibleLoader, file_name=my_yaml)

# Generated at 2022-06-23 05:40:16.564871
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    secret_data = 'my_secret'
    plaintext_vault = AnsibleVaultEncryptedUnicode.from_plaintext(secret_data, username='someuser', password='somepass')
    plaintext_vault.vault = True

    yaml = AnsibleDumper()
    testyml = yaml.encode(plaintext_vault)

    # This is a valid YAML file, so the following should not throw any exceptions
    al = AnsibleLoader(testyml, file_name=None, vault_secrets=['somepass'])

# Generated at 2022-06-23 05:40:19.512414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import inspect
    m = inspect.getmembers(AnsibleLoader, predicate=inspect.ismethod)
    assert m

# Generated at 2022-06-23 05:40:20.139312
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:40:29.377269
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b"""
hosts: localhost
user: root
tasks:
  - debug: msg="Hello"
  - debug: msg="World"
    when: 1 > 0
  - fail: msg="Goodbye"
    when: 1 == 0
"""
    data = AnsibleLoader(data).get_single_data()

    assert data['user'] == 'root'
    assert data['hosts'] == 'localhost'

    assert len(data['tasks']) == 3
    assert data['tasks'][1]['when'] == '1 > 0'
    assert data['tasks'][2]['when'] == '1 == 0'

# Generated at 2022-06-23 05:40:30.025226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:40:32.417540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    # TODO: Need to add a unit test for class AnsibleLoader
    assert True

# Generated at 2022-06-23 05:40:40.083770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        fh = open('test/unit/module_utils/common/test_module_utils_common_yaml.py')
        loader = AnsibleLoader(fh)
        fh.close()
    else:
        fh = open('test/unit/module_utils/common/test_module_utils_common_yaml.py')
        ansible_loader = AnsibleLoader(fh)
        ansible_loader.check_data()
        fh.close()

# Generated at 2022-06-23 05:40:53.330817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    def fail_on_load(stream):
        loader = AnsibleLoader(stream)
        loader.get_single_data()

    import sys
    if sys.version_info >= (2, 7):

        from yaml.reader import ReaderError
        from yaml.scanner import ScannerError
        from yaml.parser import ParserError
        from yaml.composer import ComposerError
        import yaml

        # Test Reader issue

        # Test issue https://github.com/yaml/pyyaml/issues/37
        #   Reader should not be line based
        #   Reader has been fixed in PyYaml 4.0
        check_reader = True
        if check_reader and hasattr(yaml, '__with_libyaml__') and yaml.__with_libyaml__:
            check_reader = False

# Generated at 2022-06-23 05:41:03.590294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import json

    # file test/units/parsing/yaml/yaml_constructor.yml contains a list with two
    # dictionaries:
    #
    # - { when: W, result: WIN }
    # - { when: L, result: LOSE }
    #
    # The first dictionary has a tag !!str so it is converted to a string on
    # load.  The second dictionary has no tag and is a Python dictionary.

    file_name = 'test/units/parsing/yaml/yaml_constructor.yml'
    with open(file_name) as f:
        data = f.read()

    assert data == """---
- !!str {when: 'W', result: WIN}
- {when: 'L', result: LOSE}
"""

    # file test/units/p

# Generated at 2022-06-23 05:41:11.893729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import needed for call to ansible.module_utils.six._text_type
    from ansible.module_utils.six import PY3, text_type as _text_type

    # We are testing the AnsibleLoader class that accepts a file name
    file_name = 'f1'

    # Create AnsibleLoader object
    loader = AnsibleLoader(None, file_name)

    # Test that filename is set correctly
    assert loader.file_name == file_name

    # Test that the AnsibleConstructor.add_constructor() was called
    test_constructor = (
        u'tag:yaml.org,2002:str', _text_type, loader.yaml_constructors[_text_type])
    assert AnsibleConstructor.add_constructor.call_args_list[0][0] == test_constructor



# Generated at 2022-06-23 05:41:15.575623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('[{"a": 1, "b": 2}, "foo"]')
    AnsibleLoader('[{"a": 1, "b": 2}, "foo"]', vault_secrets=['vault_secret_1'])

# Generated at 2022-06-23 05:41:24.983898
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml
    import sys

    # workaround to add the loader class where it is looked up by yaml
    # this makes it possible to call it via `load` below
    sys.modules['ansible.parsing.yaml.loader'] = sys.modules[__name__]

    in_data = '''
    somekey: somevalue
    some:
        other:
            key: value
    '''

    # Create an instance of AnsibleLoader and call it
    aloader = AnsibleLoader(in_data)
    result = from_yaml(aloader)

    import json
    print(json.dumps(result, indent=4))

    assert type(result) == dict
    assert result['somekey'] == 'somevalue'

# Generated at 2022-06-23 05:41:30.454283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = b"file: \"/etc/file.conf\""
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert(type(data) == dict)
    assert 'file' in data
    assert data['file'] == "/etc/file.conf"

# Generated at 2022-06-23 05:41:41.356782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        from yaml.parser import ParserError
    from tests.unit.parsing.yaml import BaseYAMLTests, YamlTestUtils

    class TestAnsibleLoader(BaseYAMLTests, YamlTestUtils):
        pass

    for cls in TestAnsibleLoader.YAML_TEST_CLASSES:
        klass = getattr(cls, 'AnsibleLoader', None)
        if klass is not None:
            setattr(TestAnsibleLoader, klass.__name__, klass)

    TestAnsibleLoader.setUpClass()

    suite = TestAnsibleLoader()
    suite.setUpModule()

    suite.setUp()

# Generated at 2022-06-23 05:41:50.897262
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = dict(
        a_string='string',
        a_number=42,
        a_float=3.14,
        a_bool=True,
        a_none=None,
        a_dict=dict(
            dict_string='string',
            dict_number=42,
            dict_float=3.14,
            dict_bool=True,
            dict_none=None,
        ),
        a_list=list(
            'one',
            2,
            3.14,
            True,
            None,
            dict(
                one=1,
                two=2,
                three=3
            )
        )
    )

# Generated at 2022-06-23 05:41:53.750621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_stream = ""
    ansible_loader = AnsibleLoader(test_stream)
    assert isinstance(ansible_loader, AnsibleLoader)

