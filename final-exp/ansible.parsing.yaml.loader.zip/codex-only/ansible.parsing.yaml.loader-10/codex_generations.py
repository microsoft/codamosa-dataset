

# Generated at 2022-06-23 05:31:58.541250
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("var: value")
    assert loader.get_single_data() == {"var": "value"}

# Generated at 2022-06-23 05:32:03.227287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = """
a: b
c:
  - 10.1.1.1
  - 10.1.1.2
d: "{{ lookup('dig', 'example.com', 'A') }}"
e:
  - {{ lookup('dig', 'example.com', 'A') }}
  - {{ lookup('dig', 'example.com', 'A') }}
"""
    loader = AnsibleLoader(text)
    loader.get_single_data()


# Generated at 2022-06-23 05:32:07.483950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import doctest
    results = doctest.testmod(sys.modules[__name__])
    assert results.failed == 0

# Generated at 2022-06-23 05:32:13.501477
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for constructor of class AnsibleLoader'''
    pass

if __name__ == '__main__':
    import sys
    import os
    sys.path.insert(1, os.path.dirname(os.path.dirname(sys.path[0])))

    from ansible.module_utils.common.yaml import AnsibleLoader
    test_AnsibleLoader()

# Generated at 2022-06-23 05:32:24.232896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.reader as yaml_reader
    import ansible.parsing.yaml.objects as yaml_objects
    import ansible.parsing.yaml.dumper as yaml_dumper
    import ansible.parsing.yaml.representer as yaml_representer
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    loader = DataLoader()
    stream = BytesIO("""\
---
foo:
  - 1
  - 2
""")
    data = loader.load(stream)
    assert data is not None
    assert data == {u'foo': [1, 2]}

    ansible

# Generated at 2022-06-23 05:32:32.966224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    # This utility function is not being used at the moment and not needed
    # to be tested.
    # TODO: if the function has more to test, please remove the exclusion
    # decorator and fix the issue.
    def _load_yaml_from_file(file_name):
        ''' load a yaml file, return the data structure '''
        config_data = {}

# Generated at 2022-06-23 05:32:36.332329
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fp = file('../../test/unit/parser/ansible-hosts.yml', 'r')
    data = AnsibleLoader(fp).get_single_data()
    # FIXME
    assert 1 == data[0]

# Generated at 2022-06-23 05:32:38.777096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=invalid-name
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-23 05:32:42.973144
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader("")
    assert isinstance(loader.construct_yaml_str(""), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(""), AnsibleSequence)

# Generated at 2022-06-23 05:32:49.424167
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    s = '{ key: {{ test }} }'
    loader = AnsibleLoader(s)
    data = loader.get_single_data()
    assert type(data) == dict
    assert data['key'] == '{{ test }}'
    data = loader.get_single_data()
    assert type(data) == AnsibleBaseYAMLObject

# Generated at 2022-06-23 05:32:51.464156
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:52.091978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:00.034496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
    ---
    - hosts: localhost
      tasks:
      - name: test
        debug:
          msg: hello world
    """

    loader = AnsibleLoader(data, "test_AnsibleLoader")
    assert loader is not None

    data = loader.get_single_data()
    assert data is not None

    assert len(data.keys()) == 1
    assert data.keys() == ['playbook']

    assert len(data['playbook']) == 1
    assert 'tasks' in data['playbook'][0]

# Generated at 2022-06-23 05:33:03.203159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    answer = AnsibleLoader(None)
    assert hasattr(answer, 'construct_yaml_str'), "No construct_yaml_str method"
    assert hasattr(answer, 'construct_yaml_int'), "No construct_yaml_int method"

# Generated at 2022-06-23 05:33:12.885600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.module_utils.common.yaml import AnsibleLoader

    def test_assert_equal(test_name, expected, actual):
        if expected != actual:
            raise AssertionError("%s != %s" % (expected, actual))
        print("** passed: %s" % test_name)

    # use default settings
    data = """
    - hosts: 127.0.0.1
      gather_facts: no
      tasks:
      - name: foo
        ping:
    """

    # ensure that the string is converted to a list properly
    test_assert_equal('string to list', ['127.0.0.1'],
                      AnsibleLoader(StringIO(data)).get_single_data()['hosts'])

# Generated at 2022-06-23 05:33:14.198483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_obj = AnsibleLoader(None)
    assert my_obj is not None

# Generated at 2022-06-23 05:33:15.116234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml.Loader = AnsibleLoader

# Generated at 2022-06-23 05:33:26.421659
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_raw = '''{
        "one": 1,
        "two": "2",
        "dict": {
          "one": 1,
          "two": "2"
        },
        "list": [
          1,
          "2",
          {
            "one": 1,
            "two": "2"
          }
        ]
    }'''

    loader = AnsibleLoader(yaml_raw)

    data = loader.get_single_data()
    assert data['one'] == 1
    assert data['two'] == "2"
    assert data['dict']['one'] == 1
    assert data['dict']['two'] == "2"
    assert data['list'][0] == 1
    assert data['list'][1] == "2"

# Generated at 2022-06-23 05:33:30.707789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b'')
    assert loader is not None
    assert hasattr(loader, 'construct_sequence')
    assert hasattr(loader, 'construct_yaml_str')
    assert hasattr(loader, 'construct_mapping')
    assert hasattr(loader, 'construct_undefined')

# Generated at 2022-06-23 05:33:39.921722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    # These tests are being moved eventually to
    # test/units/module_utils/common/yaml/test_AnsibleLoader.py

    # Test an empty file.
    assert AnsibleLoader(io.BytesIO(b'')).get_single_data() == None

    # Test a file containing just a percent symbol.
    assert AnsibleLoader(io.BytesIO(b'%')).get_single_data() == '%'

    # Test that a file containing a single integer is returned as an
    # integer.
    assert AnsibleLoader(io.BytesIO(b'-5')).get_single_data() == -5

    # Test that a file containing a single boolean is returned as an
    # boolean.
    assert AnsibleLoader(io.BytesIO(b'True')).get_single_data() == True



# Generated at 2022-06-23 05:33:48.678540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = u"---\n- !vault |\n          $ANSIBLE_VAULT;1.1;AES256\n          35303332626339343230376137613665626533633431653036613839336331383634363337656634\n          36356162653835333330313430616230393034633865613963636130336130393638626339633530\n          63663130303830336266663666663366366537363930633332656536353161653533313134373730\n          36623962626566306431666233373164636562376564316237613463663933366130336234613664\n          35\n    key: val"

# Generated at 2022-06-23 05:33:51.792701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader object has no attribute __init__
    obj = AnsibleLoader('test')
    assert isinstance(obj, AnsibleLoader)

# Generated at 2022-06-23 05:33:53.247179
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.construct_yaml_bool

# Generated at 2022-06-23 05:34:04.314635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    TEST_YAML_DATA_DIR = 'test/units/parsing/yaml/yaml_data'
    ANSIBLE_YAML_DIR = os.path.join(os.path.dirname(__file__), TEST_YAML_DATA_DIR)
    TEST_YML = 'test_yaml_constructor.yml'
    TEST_YML_PATH = os.path.join(ANSIBLE_YAML_DIR, TEST_YML)

    with open(TEST_YML_PATH) as fd:
        data = AnsibleLoader(fd, TEST_YML_PATH).get_data()

    assert data is not None
    assert data['a'] == 'value'
    assert data['b'][0] == 'value'
    assert data['b'][1]

# Generated at 2022-06-23 05:34:09.993570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = """\
        ---
        - hosts: all
          gather_facts: no
        """
    yaml_file = StringIO(yaml_str)

    playbook = AnsibleLoader(file_name=yaml_file).get_single_data()
    assert playbook is not None

    AnsibleDumper().dump(data=playbook, stream=None)

# Generated at 2022-06-23 05:34:15.592533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
        # Example
        name:
            - "{{ inventory_hostname }}"
            - "{{ inventory_hostname_short }}"
        # Example
        name: "{{ inventory_hostname_short }}"     # Example
        # Example
        name: "{{ inventory_hostname }}"           # Example
        # Example
        name: "{{ inventory_hostname_short }}"     # Example
    """
    ansibleloader = AnsibleLoader(stream)
    #test_line = ansibleloader.get_line_number()
    #assert test_line == 6

# Generated at 2022-06-23 05:34:20.409794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(file_name='/dev/null', vault_secrets=['vault_secret'])
    data = loader.get_single_data()

    assert isinstance(data, AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:34:26.760229
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common._collections_compat import MutableMapping

    # Loading from a dict
    data = dict(a=dict(b=1, c=2))
    assert isinstance(AnsibleLoader(data).get_single_data(), MutableMapping)
    assert AnsibleLoader(data).get_single_data() == dict(a=dict(b=1, c=2))

# Generated at 2022-06-23 05:34:29.914008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.construct_mapping is not None
    assert loader.construct_sequence is not None

# Generated at 2022-06-23 05:34:30.920762
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-23 05:34:32.854221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:36.903525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file = 'test/ansible_loader_test.yml'
    with open(test_file, 'r') as stream:
        data = AnsibleLoader(stream).get_data()
        assert len(data) > 0

# Generated at 2022-06-23 05:34:37.475307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:39.678243
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass
    TestAnsibleLoader(None)

# Generated at 2022-06-23 05:34:42.568600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    assert (hasattr(AnsibleLoader, '__init__'))

# Generated at 2022-06-23 05:34:47.059856
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str='''
a:
  b:
    c: test1
'''
    loader = AnsibleLoader(stream=yaml_str, file_name=None, vault_secrets=None)
    data = loader.get_single_data()
    assert data['a']['b']['c'] == 'test1'

# Generated at 2022-06-23 05:34:57.186277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, 'construct_yaml_str')
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert hasattr(AnsibleLoader, 'check_data_under_key')
    assert hasattr(AnsibleLoader, 'check_valid_mapping')
    assert hasattr(AnsibleLoader, 'check_valid_yaml_seq')
    assert hasattr(AnsibleLoader, 'check_valid_yaml_str')
    assert hasattr(AnsibleLoader, 'load')
    assert hasattr(AnsibleLoader, 'get_single_data')

# Generated at 2022-06-23 05:35:06.997588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Tests basic functionality of the default AnsibleLoader
    # via input and output validation.
    #
    # Since AnsibleLoader is just a wrapper around `yaml`,
    # the tests here validate that the class is correctly
    # constructed from the underlying base classes.
    #
    # This test does not execute the whole class, which is
    # not ideal, but it's not clear how to test AnsibleLoader
    # for basic functionality without executing methods
    # that exceed the scope of testing AnsibleLoader itself.
    loader = AnsibleLoader('[{host: localhost, port: 1234}]')
    assert(hasattr(loader, 'get_single_data'))
    assert(hasattr(loader, '_reader'))
    assert(hasattr(loader, '_parser'))

# Generated at 2022-06-23 05:35:09.233512
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    loader = AnsibleLoader(StringIO.StringIO("---\n- hosts: all\n"))
    loader.get_single_data()

# Generated at 2022-06-23 05:35:11.156562
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('', 'file_name', 'vault_secrets').__init__()


# Generated at 2022-06-23 05:35:12.828461
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Just ensure that the class can be created and we are not missing any required parameters
    AnsibleLoader('', '', '')

# Generated at 2022-06-23 05:35:20.803244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = """'''
- { host: all, gather_facts: False }
- hosts: server1
- hosts: server2
  remote_user: test
'''"""
    loader = AnsibleLoader(text)
    loaded_yaml = loader.get_single_data()
    assert loaded_yaml[0].get('host') == 'server1'
    assert loaded_yaml[2].get('host') == 'server2'
    assert loaded_yaml[0].get('remote_user') is None
    assert loaded_yaml[2].get('remote_user') == 'test'

# Generated at 2022-06-23 05:35:32.466538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import UnsafeText
    import base64

    # This test uses the same vault-encrypted string as the test in the VaultLib class

# Generated at 2022-06-23 05:35:34.661532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "---\nhosts: localhost"

    loader = AnsibleLoader(data)
    assert type(loader) == AnsibleLoader

# Generated at 2022-06-23 05:35:36.578194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass
#   d = AnsibleLoader(data).get_single_data()
#   assert_equals(data, d)

# Generated at 2022-06-23 05:35:38.674504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: implement unit test
    pass

# Generated at 2022-06-23 05:35:45.964172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import warnings
    warnings.simplefilter('error')
    stream = u'{ foo: bar }'  # Ensure 'unicode' type for Python 2
    loader = AnsibleLoader(stream)
    the_data = loader.get_single_data()
    assert isinstance(the_data, dict)
    assert isinstance(the_data['foo'], AnsibleUnicode)
    assert the_data['foo'] == u'bar'

# Generated at 2022-06-23 05:35:55.852072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def test_load_list_integers_as_int(self):
            loader = AnsibleLoader('')
            self.assertEqual(loader.construct_yaml_int('123'), 123)

        def test_load_list_with_unicode_strings(self):
            loader = AnsibleLoader('')
            self.assertEqual(loader.construct_yaml_str('foo'), u'foo')


# Generated at 2022-06-23 05:35:56.418294
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:35:58.168339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(True)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:59.069601
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-23 05:36:06.440259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.plugins.loader import vault_load

    vault = VaultLib([VaultSecret('foo', ['keys'], None)])
    file_name = 'foo'
    vault_secrets = [vault_load(file_name, vault)]
    loader = AnsibleLoader(None, file_name, vault_secrets)

    assert loader.file_name == 'foo'
    assert loader.vault_secrets == [vault_load('foo', vault)]

# Generated at 2022-06-23 05:36:11.530258
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:36:13.082033
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fixture = AnsibleLoader(file_name="a_filename")
    assert isinstance(fixture, AnsibleLoader)

# Generated at 2022-06-23 05:36:15.112379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

# Generated at 2022-06-23 05:36:17.096509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test AnsibleConstructer constructor
    loader = AnsibleLoader(open(__file__, 'r'), vault_secrets='vault_secrets')
    assert loader != None

# Generated at 2022-06-23 05:36:28.055007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import unittest
    import tempfile
    import os

    class TestConstructorMethods(unittest.TestCase):
        def test_load_list(self):
            test_list = [1, 2, 'test', 'here', {'a':'different', 'b': 'dictionary'}]
            fd, temp_file = tempfile.mkstemp()
            with open(temp_file, 'w') as f:
                f.write(yaml.dump(test_list))
            with open(temp_file, 'r') as f:
                loaded_list = yaml.safe_load(f)
            os.close(fd)
            os.remove(temp_file)
            self.assertEqual(loaded_list, test_list)


# Generated at 2022-06-23 05:36:36.762108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.cyaml import CSafeLoader as SafeLoader
    from ansible.parsing.yaml.cyaml import CSafeDumper as SafeDumper
    from ansible.parsing.yaml.cyaml import CSafeDumper
    from ansible.parsing.yaml.cyaml import CSafeLoader
    from ansible.parsing.yaml.objects import AnsibleMapping

    assert SafeLoader
    assert SafeDumper

    assert CSafeLoader
    assert CSafeDumper

    assert AnsibleLoader
    assert AnsibleUnicode
    assert AnsibleMapping

# Generated at 2022-06-23 05:36:46.668583
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Parse the following yaml with AnsibleConstructor
    - name: test
    - a:
        b: 3
        c: 4
    """
    input_yaml = '''
- name: test
- a:
    b: 3
    c: 4
'''
    loader = AnsibleLoader(input_yaml)
    data = loader.get_single_data()
    assert len(data) == 2, 'data should have 2 items'
    first_item, second_item = data[0], data[1]
    assert first_item['name'] == 'test', 'first item should have "name" set to "test"'
    assert second_item['a']['b'] == 3, 'second item should have "a" set with "b" set to 3'

# Generated at 2022-06-23 05:36:56.831805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from yaml.nodes import MappingNode

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.vault import VaultLib

    class TestYAMLObject(AnsibleBaseYAMLObject):
        pass

    class AnsibleLoaderTest(unittest.TestCase):
        def test_AnsibleLoader_constructor_for_ansible_tags(self):
            from ansible.parsing.yaml.loader import AnsibleLoader
            loader = AnsibleLoader("", "")

            base_obj = AnsibleBaseYAMLObject("", {})

# Generated at 2022-06-23 05:37:06.732885
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:37:18.626629
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # Initialise
    data = ''
    stream = '''
        - hosts: all
          gather_facts: no
          tasks:
            - name: setup
              command: /bin/true
    '''
    stream = stream.splitlines()
    for line in stream:
        data += line + '\n'
    stream = data

    # Load data
    data = AnsibleLoader(stream)

    # Test AnsibleLoader.get_single_data()
    assert data.get_single_data() == [{'gather_facts': False,
                                       'hosts': 'all',
                                       'tasks': [{'command': '/bin/true', 'name': 'setup'}]}]

    # Test AnsibleLoader.get_data()


# Generated at 2022-06-23 05:37:20.101311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for class AnsibleLoader'''
    pass

# Generated at 2022-06-23 05:37:21.051558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:37:32.305288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, your_arg='your_value', **kwargs):
            super(TestAnsibleLoader, self).__init__(stream, file_name, **kwargs)
            self.your_arg = your_arg

        def get_your_arg(self):
            return self.your_arg

    def assert_args(your_arg, **kwargs):
        stream = '[]'
        loader = TestAnsibleLoader(stream, file_name='test_file', your_arg=your_arg, **kwargs)
        assert loader.get_your_arg() == your_arg

    assert_args('your_value')
    assert_args('your_specified_value', your_arg='your_specified_value')

# Generated at 2022-06-23 05:37:44.147874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:37:48.485728
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    # Unit test
    import doctest
    doctest.testmod(verbose=1)

# Generated at 2022-06-23 05:37:51.288234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Sanity test for class AnsibleLoader
    """

    assert AnsibleLoader

# unit test for method AnsibleLoader.construct_yaml_map

# Generated at 2022-06-23 05:38:03.123084
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {'a': 1, 'b': 2, 'c': 3}
    serialized = AnsibleDumper().dump(data)
    ansible_data = AnsibleLoader(serialized).get_single_data()
    assert isinstance(ansible_data, AnsibleMapping)
    assert isinstance(ansible_data, AnsibleSequence)
    assert not isinstance(ansible_data, AnsibleUnicode)

# Generated at 2022-06-23 05:38:04.217336
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:38:14.961498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    # pylint: disable=unused-variable
    if sys.version_info >= (2, 7):
        stream = io.StringIO("""
---
foo:
  - bar

""")
    else:
        stream = io.BytesIO("""
---
foo:
  - bar
""")

    # pylint: enable=unused-variable
    loader = AnsibleLoader(stream)
    # 1- This testcase demonstrate that the instance of 'AnsibleLoader' class
    # is instance of 'AnsibleConstructor' class.
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:38:26.525458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from datetime import datetime
    from unittest import TestCase

    class AnsibleLoaderTestCase(TestCase):
        def test_sequence(self):
            loader = AnsibleLoader('[1,2,3]')
            loader.get_single_data()
            self.assertIsInstance(loader.get_single_data(), AnsibleSequence)

        def test_unicode(self):
            loader = AnsibleLoader('"test"')
            loader.get_single_data()
            self.assertIsInstance(loader.get_single_data(), AnsibleUnicode)

        def test_datetime(self):
            loader = AnsibleLoader('2012-11-15 18:02:53.610731')
            loader

# Generated at 2022-06-23 05:38:27.107708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:38:28.943091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, type(AnsibleLoader))

# Generated at 2022-06-23 05:38:30.307111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types
    assert isinstance(AnsibleLoader, types.TypeType)

# Generated at 2022-06-23 05:38:33.490284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    assert AnsibleLoader(None)

# Generated at 2022-06-23 05:38:40.085309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    document = """
    foo: - bar
    """

    loader = AnsibleLoader(document)
    data = loader.get_single_data()
    assert data == {'foo': ['bar']}

    document = """
    foo:
      - bar: baz
    """

    loader = AnsibleLoader(document)
    data = loader.get_single_data()
    assert data == {'foo': [{'bar': 'baz'}]}

# Generated at 2022-06-23 05:38:51.565970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a1 = AnsibleLoader("a: hello world")
    assert a1.get_single_data() == "a: hello world"
    a1 = AnsibleLoader("", None, [])
    a1.get_single_data()
    a2 = AnsibleLoader("", "a.yaml", ["a", "b", "c"])
    assert a2.get_single_data() == ""
    a3 = AnsibleLoader("a: !var a\nb: !var b", None, ["a", "b", "c"])
    assert a3.get_single_data() == {"a": "a", "b": "b"}
    a4 = AnsibleLoader("a: !var d\n", None, ["a", "b", "c"])

# Generated at 2022-06-23 05:39:02.173551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class Constructor(object):
        def construct_yaml_str(self, node):
            return AnsibleUnicode(self.construct_scalar(node))

        def construct_yaml_seq(self, node):
            return [self.construct_object(x) for x in node.value]

        def construct_yaml_map(self, node):
            return dict((self.construct_object(k), self.construct_object(v)) for k, v in node.value)

        def construct_undefined(self, node):
            raise NotImplementedError

    data = """
    foo: bar
    bar: baz
    """

    d

# Generated at 2022-06-23 05:39:03.154311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # assert AnsibleLoader
    pass

# Generated at 2022-06-23 05:39:12.328128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data1 = """
var1: 1
var2: string
list_var:
  - item1
  - item2
"""
    data2 = """
dict_var:
  key1: value1
  key2: value2
"""
    data3 = """
another_dict:
  key1: value1
  key2: value2
"""
    list_data = "\n".join([data1, data2, data3])
    data = """
first: %s
second: %s
third: %s
""" % (data1, data2, data3)

    # Using AnsibleLoader to load a dict
    aload = AnsibleLoader(stream=data)
    new_data = aload.get_single_data()
    assert new_data.get('first') == data1

# Generated at 2022-06-23 05:39:20.598000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    dir(loader)


# for test_yaml_data
yaml_data = '''
- hosts: all
  gather_facts: False
  tasks:
  - name: test 1
    command: /bin/false
  - name: test 2
    command: /bin/false
    register: foo
  - name: test 3
    command: /bin/false
    when: foo.rc > 0
'''

# Generated at 2022-06-23 05:39:21.908409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader([], 'samplefile')

# Generated at 2022-06-23 05:39:34.044783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestClass(object):
        pass

    vault_secrets = TestClass()
    file_name = 'my_file.yml'
    stream = 'key: {{ my_var }}'
    al = AnsibleLoader(stream, file_name, vault_secrets)

    assert al.file_name == 'my_file.yml'
    assert al.vault_secrets is vault_secrets
    assert al.stream == 'key: {{ my_var }}'
    assert al.data == dict()
    assert al.level == 0
    assert al.anchors == dict()
    assert al.version is None
    assert al.tags is None
    assert not al.parser
    assert not al.composer
    assert al.constructor == al
    assert al.resolver == al

# Generated at 2022-06-23 05:39:35.321498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:39:35.998241
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:39:39.383393
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ This function performs a unit test on AnsibleLoader. It does so by
        asserting that the AnsibleConstructor class is a base class for the
        AnsibleLoader class.
    """
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-23 05:39:41.135022
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(stream='test', file_name='test', vault_secrets='test')

# Generated at 2022-06-23 05:39:47.018325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    test_load = '''
    - host: test
      tasks:
      - debug:
          msg: "Hello"
    '''
    myloader = AnsibleLoader(test_load)
    result = next(iter(myloader))
    assert result['host'] == "test"
    result = result['tasks']
    assert result[0]['debug']['msg'] == "Hello"

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:39:58.264661
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Foo(AnsibleConstructor):
        def __init__(self, file_name=None, vault_secrets=None):
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)

    class Bar(Parser):
        def __init__(self, stream):
            Parser.__init__(self, stream)

    if not HAS_LIBYAML:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser

        class Bar(Reader, Scanner, Parser, Composer):
            def __init__(self, stream):
                Reader.__init__(self, stream)
                Scanner.__init__(self)


# Generated at 2022-06-23 05:39:58.975713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:40:02.602431
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestLoader(AnsibleLoader):
        pass

    loader = TestLoader("data")
    assert loader is not None

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:40:04.782959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:40:07.342521
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    constructors = AnsibleLoader._yaml_constructors
    assert constructors['!include'] == AnsibleConstructor.construct_include

# Generated at 2022-06-23 05:40:12.734099
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    input_string = "%s" % ("unicode string")
    loader = AnsibleLoader(input_string)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleUnicode)

# Generated at 2022-06-23 05:40:19.764480
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
    ---
    method: "{{a}}"
    """

    import os
    import sys
    import StringIO

    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO.StringIO()

    loader = AnsibleLoader(data, file_name='/etc/hosts', vault_secrets=None)
    foo = loader.get_single_data()

    sys.stdout = old_stdout

    assert foo == {u'method': u'{{a}}'}

# Generated at 2022-06-23 05:40:24.878737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    fake_loader = AnsibleLoader(sys.stdin)
    assert isinstance(fake_loader, AnsibleLoader)
    assert isinstance(fake_loader, (Reader, Scanner, Parser, Composer))
    assert isinstance(fake_loader, AnsibleConstructor)
    assert isinstance(fake_loader, Resolver)

# Generated at 2022-06-23 05:40:27.874398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # The purpose of this test is to make sure no error will be thrown from
    # AnsibleLoader class
    from io import StringIO
    data = u'---\n'
    stream = StringIO(data)
    loader = AnsibleLoader(stream, file_name=None, vault_secrets=None)

# Generated at 2022-06-23 05:40:38.027969
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError
    from yaml.composer import ComposerError
    from yaml.constructor import ConstructorError

    # test empty input
    try:
        AnsibleLoader('').get_single_data()
    except ScannerError:
        pass # nothing to do
    except Exception as e:
        assert False, "Unexpected exception {}".format(e)

    # test bad input
    try:
        AnsibleLoader('---\nfoo: bar\nbaz').get_single_data()
    except ParserError:
        pass # nothing to do
    except Exception as e:
        assert False, "Unexpected exception {}".format(e)

    # test bad input

# Generated at 2022-06-23 05:40:47.646477
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert '_AnsibleLoader__load_constructed' in dir(AnsibleLoader)
    assert '_AnsibleLoader__load_yaml_guess' in dir(AnsibleLoader)
    assert '_AnsibleLoader__locate_and_load' in dir(AnsibleLoader)
    assert '_AnsibleLoader__safe_load_all' in dir(AnsibleLoader)
    if HAS_LIBYAML:
        assert '_AnsibleLoader__init__' in dir(AnsibleLoader)
    else:
        assert '_AnsibleLoader__compose_node' in dir(AnsibleLoader)

# Generated at 2022-06-23 05:40:49.926256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_loader = AnsibleLoader(b'')
    assert isinstance(my_loader, AnsibleLoader)

# Generated at 2022-06-23 05:40:52.801779
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # smoke test - we just want to make sure it works!
    data = AnsibleLoader(open('/dev/null')).get_single_data()
    assert data is None

# Generated at 2022-06-23 05:40:53.940070
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert (AnsibleLoader is not None)

# Generated at 2022-06-23 05:41:04.258612
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:41:08.136902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    txt = "---\n" \
          ":1: foo\n" \
          ":2: bar\n" \
          "...\n"
    import io
    AnsibleLoader(io.StringIO(txt))

# Generated at 2022-06-23 05:41:17.862749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''\
    foo:
      - bar
      - "{{ baz }}"
      - yaml
      -
        - key: "{{ foobar }}"
          val: "{{ barbaz }}"
    qux:
      - "{{ quux }}"
    '''
    ansible_loader = AnsibleLoader(yaml_str, vault_secrets=[])
    yaml_obj = ansible_loader.get_single_data()

    assert 'foo' in yaml_obj
    assert 'bar' in yaml_obj['foo']
    assert '{{ baz }}' in yaml_obj['foo']
    assert 'yaml' in yaml_obj['foo']
    assert '{{ foobar }}' in yaml_obj['foo'][3][0]['key']

# Generated at 2022-06-23 05:41:25.979935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Create VaultLib object
    vault_secrets_loader = VaultLib("test vault password")

    # Create AnsibleLoader object
    loader = AnsibleLoader(stream="test", vault_secrets=vault_secrets_loader)
    # Create unmarshaler
    loader.construct_mapping("tag:yaml.org,2002:map", [("test", "vault")])

    # Check if instance is created
    assert isinstance(AnsibleVaultEncryptedUnicode("test", vault_secrets_loader), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:41:30.907514
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    for stream in [
        '---\n- 1\n- 2\n',
        '---\n- 1\n- 2\n',
    ]:
        try:
            AnsibleLoader(stream)
        except:
            assert False, 'error raised parsing: %s' % stream

# Generated at 2022-06-23 05:41:37.300744
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest

    output = io.StringIO()
    loader = AnsibleLoader('')

    class TestAnsibleLoader(unittest.TestCase):
        def test_init(self):
            self.assertIsInstance(loader, AnsibleLoader)

    # Run test
    unittest.main(
        testRunner=unittest.TextTestRunner(stream=output, verbosity=2),
        exit=False
    )

# Generated at 2022-06-23 05:41:48.047816
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:41:57.394309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import six

    obj = AnsibleLoader('hello world!')
    assert isinstance(obj, AnsibleLoader)
    assert isinstance(obj, Reader)
    assert isinstance(obj, Scanner)
    assert isinstance(obj, Parser)
    assert isinstance(obj, Composer)
    assert isinstance(obj, AnsibleConstructor)
    assert isinstance(obj, Resolver)

    obj = 'hello world!'
    if six.PY2:
        obj = obj.decode('utf-8')