

# Generated at 2022-06-23 05:32:05.962342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b'---\n')

    # Tests for AnsibleConstructor.__init__
    assert loader.file_name is None
    assert loader.vault_secrets is None
    assert loader._constructors == {
        'tag:yaml.org,2002:map': loader.construct_yaml_map,
        'tag:yaml.org,2002:seq': loader.construct_yaml_seq
    }
    assert loader._constructors_org == {
        'tag:yaml.org,2002:map': loader.construct_yaml_map,
        'tag:yaml.org,2002:seq': loader.construct_yaml_seq
    }

# Generated at 2022-06-23 05:32:14.874643
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # comment for class AnsibleLoader
    # inject a 'yaml_class' parameter in the class AnsibleLoader
    # 'yaml_class': class AnsibleConstructor
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.vault import VaultLib
    # create a instance of class VaultLib
    file_name = ''
    vault_secrets = VaultLib()
    # create a instance of class AnsibleLoader
    loader = AnsibleLoader(file_name, vault_secrets)
    assert isinstance(loader.vault_secrets, VaultLib)

# Generated at 2022-06-23 05:32:25.604941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import warnings
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.dataloader import DataLoader

    test_file = os.path.join(os.path.dirname(__file__), '../../test/sanity/playbooks/vaulted.yml')
    (fd, tmp_file) = tempfile.mkstemp()

    yaml_file = open(test_file, 'r')
    yaml_contents = yaml_file.read()
    yaml_file.close()

# Generated at 2022-06-23 05:32:28.754053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("""
            ---
            test_yaml:
                - a
                - b
            """)

    data = loader.get_single_data()
    assert data == {'test_yaml': ['a', 'b']}

# Generated at 2022-06-23 05:32:39.915073
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' test class AnsibleLoader '''

    import os
    import sys
    import tempfile
    import unittest

    # skip this test if yaml lib is missing
    if not HAS_LIBYAML:
        raise unittest.SkipTest('no yaml module installed, skipping test')


# Generated at 2022-06-23 05:32:45.798645
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        from collections import OrderedDict
        from yaml.constructor import ConstructorError
        from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

        test_string = '''
foobar:
  foo: bar
  blocks:
  - block_a
  - block_b
  - block_c
'''

        loader = AnsibleLoader(test_string)
        loader.get_single_data()

    else:
        pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:32:52.816541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.constructor import AnsibleConstructor

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    a = AnsibleLoader('')
    assert isinstance(a._construct_object(None, None, None), AnsibleUnicode)
    assert isinstance(a._construct_object(None, None, list()), AnsibleSequence)
    assert isinstance(a._construct_object(None, None, dict()), AnsibleMapping)

# Generated at 2022-06-23 05:33:02.861867
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils import context_objects as co

    co.value[co.VAULT_SALT] = b'2'
    co.value[co.VAULT_SECRET] = b"vault-password"
    co.value[co.ENCODED_VAULT_SECRET] = b"vault-password"
    co.value[co.VAULT_CIPHER] = b"AES256"
    co.value[co.VAULT_VERSION] = b'1'
    co.value[co.VAULT_PASSWORDS] = {}
    co.value[co.VAULT_FILES] = {}


# Generated at 2022-06-23 05:33:03.521950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:33:06.624849
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
    - "{{ foo }}"
    - "{{ foo }}"'''
    loader = AnsibleLoader(stream)
    assert '{{ foo }}' in loader.get_data()

# Generated at 2022-06-23 05:33:07.934672
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This is needed to prevent a "TypeError: object.__new__() takes no
    parameters" on Python 3.2, which happens with nosetests.
    """
    assert AnsibleLoader(None, None, None)

# Generated at 2022-06-23 05:33:09.004528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, object)

# Generated at 2022-06-23 05:33:09.594760
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:15.785284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    import os

    LOADER_DIR = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'lib', 'ansible', 'parsing', 'yaml', 'constructor')
    LOADER_TEST_FILE = os.path.join(LOADER_DIR, 'loader_global_vars.yml')

    loader = AnsibleLoader(open(LOADER_TEST_FILE))
    loader.get_single_data()

# Generated at 2022-06-23 05:33:21.686950
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    >>> import StringIO
    >>> stream = StringIO.StringIO()
    >>> stream.write("[]")
    2
    >>> stream.seek(0)
    0
    >>> loader = AnsibleLoader(stream, file_name='test')
    >>> loader.get_single_data()
    []
    >>> loader.file_name
    'test'
    """

    pass

# Generated at 2022-06-23 05:33:33.190653
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # this test data contains a vault encrypted object
    # it was encrypted with password 'testpass'

# Generated at 2022-06-23 05:33:42.420343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b''
    loader = AnsibleLoader(data)
    assert loader.stream == data, 'invalid stream in loader'
    assert loader._file_name is None, 'loader file name is not None'
    assert loader._vault_secrets is None, 'vault secrets is not None'

if HAS_LIBYAML:
    data = b''
    loader = AnsibleLoader(data, vault_secrets=dict())
    assert loader.stream == data, 'invalid stream in loader'
    assert loader._file_name is None, 'loader file name is not None'
    assert loader._vault_secrets == dict(), 'vault secrets is not dict()'
else:
    data = b'stream'
    vault_secrets = {'a': 'b'}

# Generated at 2022-06-23 05:33:46.138712
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(["a", "b", "c"])
    assert loader.stream == ["a", "b", "c"]
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-23 05:33:48.000669
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import Loader
    try:
        AnsibleLoader(Loader)
    except:
        pass
    return True

# Generated at 2022-06-23 05:33:54.802597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('../../module_utils/facts/system/os.py', 'rb')
    loader = AnsibleLoader(stream)
    the_doc = loader.get_single_data()
    print(type(the_doc))
    print(the_doc)
    for key in the_doc:
        print(key, ':', the_doc[key])


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:34:04.082520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.playbook.play import Play
    import StringIO

    source = StringIO.StringIO(u'---\n- name: test play\n  hosts: all\n  gather_facts: no')
    loader = AnsibleLoader(source)
    play = loader.get_single_data()

    assert isinstance(play, Play)

# Generated at 2022-06-23 05:34:05.042183
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:05.888187
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-23 05:34:10.580323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
- hosts: localhost
  tasks:
    - name: hello
      local_action:
        module: command
        args:
          chdir: /
          creates: file1
          executable: /bin/sh
          free_form: whoami
'''

    loader = AnsibleLoader(stream)
    loader.get_single_data()

    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-23 05:34:11.320281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:18.443076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.reader import AnsibleFileReader

    # This is a very minimal test of AnsibleLoader, just to make sure we have
    # enough class machinery to support the easiest of YAML files
    r = AnsibleFileReader("---\n- hosts: localhost\n  tasks: []")
    l = AnsibleLoader(r)
    defs = l.get_single_data()
    assert defs[0] == {u"hosts": u"localhost", u"tasks": []}

# Generated at 2022-06-23 05:34:18.983323
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:30.187593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io


# Generated at 2022-06-23 05:34:35.075858
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string = '''
---
# A simple hash
- hosts:
    - host1
    - host2
  remote_user: root
  tasks:
    - name: ensure apache is at the latest version
      yum: pkg=httpd state=latest
'''
    one_loader = AnsibleLoader(test_string)
    one_loader.get_single_data()



# Generated at 2022-06-23 05:34:45.639287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml

    data = from_yaml("""
---
str: '123456789'
int: 123456789
float: 123456789.0
null: ~
bool: True
list:
- foo
- bar
- 1
- 2
- 3
- baz
- null
- True
dict:
  foo: bar
  1: 2
  3: 4
  null: ~
  True: False
""")

    assert data["str"] == '123456789'
    assert data["int"] == 123456789
    assert data["float"] == 123456789.0
    assert data["null"] is None
    assert data["bool"] is True


# Generated at 2022-06-23 05:34:52.335214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml import objects

    loader = AnsibleLoader(None, vault_secrets=None)
    assert isinstance(loader, objects.AnsibleBaseLoader)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:02.096111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        with open('test/constructor', 'w', encoding='utf8') as f:
            f.write("""\
--- !vault |
          $ANSIBLE_VAULT;1.1;AES256
          61393532316239633761623661653330663839393035643338376437616532643531613836663034
          63616662376335636136393461333131643632373063333230383465336163326330356639333330
          37333830336228
          string: 'value'
""")

# Generated at 2022-06-23 05:35:03.763470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        assert True
    else:
        assert False

# Generated at 2022-06-23 05:35:15.201256
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-locals
    yaml_str = """
- hosts: all
  gather_facts: no
  tasks:
    - name: ping
      ping:
- name: another play
  hosts: foo
"""
    import ansible.parsing.yaml.objects
    import ansible.playbook.play
    import ansible.playbook.task
    vault_secrets = dict(vault_password='blah')
    loader = AnsibleLoader(yaml_str, file_name='/dev/null', vault_secrets=vault_secrets)
    datastream = loader.get_single_data()

    assert(isinstance(datastream, list))

    play1 = datastream[0]

# Generated at 2022-06-23 05:35:24.464453
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """If it actually fails this test will tell you."""
    class AnsibleFileLoader(object):

        def __init__(self, file_name):
            self.file_name = file_name

        def get_source(self, data):
            return self.file_name, data.read()

    data1 = '''
        hello: world!
    '''

    data2 = '''
        hello: test!
    '''

    stream1 = open('/test1.yaml', 'w')
    stream1.write(data1)
    stream1.close()

    stream2 = open('/test2.yaml', 'w')
    stream2.write(data2)
    stream2.close()

    loader = AnsibleLoader(AnsibleFileLoader('/test1.yaml'))
    new_

# Generated at 2022-06-23 05:35:34.478677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Construct object
    file_name = 'test_file.yml'
    vault_secrets = None
    stream = '---\n'
    obj = AnsibleLoader(stream, file_name, vault_secrets)

    # Given
    ansible_constructor = AnsibleConstructor(file_name, vault_secrets)

    # When
    # ansible_constructor.add_constructors()

    # Then
    try:
        assert obj.__class__.__name__ == ansible_constructor.__class__.__name__
        assert obj.file_name == ansible_constructor.file_name
        assert obj.vault_secrets == ansible_constructor.vault_secrets
    except:
        print('FAIL')
        return 1
    print('PASS')


# Generated at 2022-06-23 05:35:43.595878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = """
    foo:
      - { age: 63, first: Samuel, last: Clemens }
      - { age: 44, first: Mark, last: Twain }
    """

    stream = Parser.from_string(data)
    constructor = AnsibleLoader(stream)

    # Verify that the constructor is used
    assert isinstance(constructor.get_single_data(), AnsibleMapping)

    # Verify that the dumper is used
    dumper = AnsibleDumper()
    constructor.set_dump_type(None)
    assert isinstance(dumper.represent_data(constructor.get_single_data()), str)

   

# Generated at 2022-06-23 05:35:48.374523
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Constructor
    loader = AnsibleLoader('')
    assert loader
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)
    return loader

if HAS_LIBYAML:
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:50.206755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-23 05:35:50.663452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:00.906238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test AnsibleLoader():
    assert isinstance(AnsibleLoader([]), AnsibleConstructor)
    assert isinstance(AnsibleLoader([]), Resolver)
    # If there is libyaml
    if HAS_LIBYAML:
        assert isinstance(AnsibleLoader([]), Parser)
    # If there isn't libyaml
    else:
        assert isinstance(AnsibleLoader([]), Reader)
        assert isinstance(AnsibleLoader([]), Scanner)
        assert isinstance(AnsibleLoader([]), Parser)
        assert isinstance(AnsibleLoader([]), Composer)

# Generated at 2022-06-23 05:36:06.766217
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # This is to make sure that the Resolver class has __init__()
    # See https://github.com/ansible/ansible/issues/15262
    # See https://github.com/PyYAML/pyyaml/issues/30
    try:
        AnsibleLoader(None, None)
    except TypeError:
        assert False, "constructor of class AnsibleLoader is broken."
    else:
        assert True, "constructor of class AnsibleLoader is working."

# Generated at 2022-06-23 05:36:08.593466
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- ansible:
    test: foo
    '''
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-23 05:36:16.635959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
        ---
        hosts:
            - localhost
        tasks:
            - name: ping
              ping:
    """
    file_name = '/path/to/myfile.yaml'
    obj = AnsibleLoader(yaml, file_name=file_name).get_single_data()
    assert isinstance(obj, dict)
    assert obj['hosts'] == ['localhost']
    assert obj['tasks'][0]['name'] == 'ping'
    assert obj['tasks'][0]['ping']['file'] == '/path/to/myfile.yaml'

# Generated at 2022-06-23 05:36:27.344738
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    now = datetime.datetime.now()

# Generated at 2022-06-23 05:36:34.363834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load_yaml
    from ansible.parsing.dataloader import DataLoader

    data = (
        "---\n"
        "  # test comment\n"
        "  key: value\n"
        "  key2: value2\n"
    )
    loader = DataLoader()
    result = load_yaml(data, loader)
    assert result == {
        'key': 'value',
        'key2': 'value2',
    }

# Generated at 2022-06-23 05:36:45.119899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    res = AnsibleLoader('---\nfoo: bar\n').get_single_data()
    assert isinstance(res, dict)
    assert res['foo'] == 'bar'

    res = AnsibleLoader('---\nfoo: \'b ar\'\n').get_single_data()
    assert isinstance(res, dict)
    assert res['foo'] == 'b ar'

    res = AnsibleLoader('---\nfoo: |\n  1st line\n  2nd line\n  3rd line\n').get_single_data()
    assert isinstance(res, dict)
    assert res['foo'] == '1st line\n2nd line\n3rd line'

# Generated at 2022-06-23 05:36:51.150164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''{
        "test": {
            "age": "12",
            "height": "s14"
        }
    }'''
    ansible_loader = AnsibleLoader(stream)
    assert ansible_loader.get_single_data() == {
        "test": {
            "age": "12",
            "height": "s14"
        }
    }

# Generated at 2022-06-23 05:36:55.054430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("test1: test2\n")
    assert 2 == len(loader)
    assert dict == type(loader[0])
    assert dict == type(loader[1])
    assert "test1" == loader[1].keys()[0]
    assert "test2" == loader[1].values()[0]

# Generated at 2022-06-23 05:37:05.772079
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Must be done before creating VaultSecret in the ctor
    vault_secrets_file = tempfile.NamedTemporaryFile("w")
    vault_secrets_file.write("ansible: test\n")
    vault_secrets_file.flush()


# Generated at 2022-06-23 05:37:13.478304
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:37:23.246076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test IPv4 address
    stream = '10.0.0.3'
    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert '10.0.0.3' == data

    # Test IPv6 address
    stream = 'fc00::1'
    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert 'fc00::1' == data

    # Test inventory variable
    stream = '$inventory_hostname'
    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert '$inventory_hostname' == data

    # Test variable
    stream = '{{ something }}'
    loader = AnsibleLoader(stream)
    data = loader.get_data()
    assert '{{ something }}' == data

    # Test j

# Generated at 2022-06-23 05:37:30.245199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    data = {
        'a': 1,
        'b': 2,
        'c': wrap_var(UnsafeProxy({1: 2, 3: 4})),
        'd': wrap_var(UnsafeProxy('test'))
    }
    loader = AnsibleLoader(data)
    assert loader.load() == data

# Generated at 2022-06-23 05:37:39.785403
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import unittest
    import io

    class TestAnsibleLoader(unittest.TestCase):

        def test_AnsibleLoader(self):
            '''This test will fail on both Python 2 and Python 3 because the
            yaml.Loader class uses super() in a non-pythonic way. If a class
            overrides __init__, it must call its parents __init__.
            '''
            stream = io.StringIO(u'---\nfoo')
            loader = AnsibleLoader(stream)
            stream.close()
            self.assertTrue(isinstance(loader, Reader))
            self.assertTrue(isinstance(loader, Scanner))
            self.assertTrue(isinstance(loader, Parser))
            self.assertTrue(isinstance(loader, Composer))

# Generated at 2022-06-23 05:37:48.938806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #Arrange
    #Act
    ansible_loader = AnsibleLoader("stream", "file_name", "vault_secrets")
    #Assert
    assert hasattr(ansible_loader, '_Reader__reader'), '_Reader__reader attribute is missing'
    assert hasattr(ansible_loader, '_Reader__buffer_size'), '_Reader__buffer_size attribute is missing'
    assert hasattr(ansible_loader, '_Reader__input'), '_Reader__input attribute is missing'
    assert hasattr(ansible_loader, '_Reader__eof'), '_Reader__eof attribute is missing'
    assert hasattr(ansible_loader, '_Reader__name'), '_Reader__name attribute is missing'

# Generated at 2022-06-23 05:37:57.464942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_data = '''all:
                hosts:
                    foo:
                      var1: 1
                      var2: 2
                    bar:
                      var1: 3
                      var2: 4
                    baz:
                      var1: 5
                      var2: 6
                     '''
    yaml = AnsibleLoader(my_data)
    assert yaml.get_single_data() == {'all': {'hosts': {'foo': {'var2': 2, 'var1': 1}, 'bar': {'var2': 4, 'var1': 3}, 'baz': {'var2': 6, 'var1': 5}}}}

# Generated at 2022-06-23 05:38:06.944578
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

    yaml_str = """
foo:
- 1
- 2
- 3
bar:
  baz:
    a: 1
    b: 2
    c: 3
qux: &quxx
  d: 4
  e: 5
  f: 6
corge: *quxx
"""
    loader = AnsibleLoader(yaml_str, vault_secrets=None)
    data = loader.get_single_data()

    assert loader is not None

# Generated at 2022-06-23 05:38:10.762455
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert AnsibleLoader.__module__ == 'ansible.parsing.yaml.loader'
    assert AnsibleLoader.__name__ == 'AnsibleLoader'
    assert AnsibleLoader.__doc__ == "Create a loader for YAML data."

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:38:19.724395
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.literals import Literal


# Generated at 2022-06-23 05:38:31.139121
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    test_yaml = """
        - 123
        - !!str
        - Yes
        - No
        - True
        - False
        - null
        """

    obj = AnsibleLoader(test_yaml)
    data = obj.get_single_data()
    assert isinstance(data, AnsibleSequence)
    assert len(data) == 7
    assert data[2] == 'Yes'
    assert data[3] == 'No'
    assert data[4] == True
    assert data[5] == False
    assert data[6] is None


# Generated at 2022-06-23 05:38:42.298343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import io

    stream = io.BytesIO(b"""
        foo: &foo bar
        bar: *foo
        """)
    loader = AnsibleLoader(stream)

    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['bar'], AnsibleUnicode)

    stream = io.BytesIO(b"foo: [bar, baz]")
    loader = AnsibleLoader(stream)

    data = loader.get_single_data

# Generated at 2022-06-23 05:38:44.611709
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''\
    foo:
      bar: baz
    '''
    AnsibleLoader(data)  # should not throw an exception

# Generated at 2022-06-23 05:38:56.140522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    data_yaml = """
- hosts: localhost
  gather_facts: false
  tasks:
    - name: test 
      shell: echo hello world
    """

    data_yaml_object = AnsibleLoader(stream=data_yaml).get_single_data()
    print(data_yaml_object)
    data_yaml_object[0]['tasks'][0]['shell'] = 'echo hello universe'
    data_yaml_object[0]['tasks'][0]['args'] = {'chdir':'/tmp'}
    data_yaml_object[0]['tasks'].append({}) #here we append a new task to the yaml data object
    data_yaml_object[0]['tasks'][1]['name'] = 'test2'


# Generated at 2022-06-23 05:38:58.748863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fake_loader = AnsibleLoader(None)
    assert fake_loader is not None

# Generated at 2022-06-23 05:39:09.660491
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class ConstructorLoader(object):
        def __init__(self, stream):
            pass

        def get_single_data(self):
            return 42

    def test_func():
        assert True

    class Loader_1(AnsibleLoader):
        def __init__(self, stream):
            AnsibleLoader.__init__(self, stream)
        _yaml_constructors = AnsibleLoader._yaml_constructors.copy()
        _yaml_constructors.update({u'tag:yaml.org,2002:int': test_func})
        _yaml_constructors.update({u'tag:yaml.org,2002:str': test_func})

    loader_1 = Loader_1(ConstructorLoader)
    assert loader_1 is not None



# Generated at 2022-06-23 05:39:10.514588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:39:11.652905
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-23 05:39:22.482498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping, AnsibleVaultEncryptedUnicode
    import io

    # ansible unicode
    assert isinstance(AnsibleLoader(io.BytesIO('foo')).get_single_data(), AnsibleUnicode)
    assert isinstance(AnsibleLoader(io.BytesIO('foo')).construct_scalar('tag:yaml.org,2002:str'), AnsibleUnicode)
    assert isinstance(AnsibleLoader(io.BytesIO('foo')).construct_yaml_str('tag:yaml.org,2002:str'), AnsibleUnicode)

    # ansible sequence

# Generated at 2022-06-23 05:39:26.387954
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This is not a proper unit test, but it will validate that
    # the call to AnsibleConstructor in __init__() does not
    # cause an exception.
    AnsibleLoader('test')

# Generated at 2022-06-23 05:39:29.032593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-23 05:39:40.473994
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml
    yaml_text = """
---
test:
 - 1
 - 0

test2:
 - 1
 - 0
"""

    yaml_data = from_yaml(yaml_text, AnswersFile='/tmp/test.yml')
    assert yaml_data is not None
    assert yaml_data.get('test') == [1, 0]
    assert yaml_data.get('test2') == [1, 0]

    yaml_text = """
---
test:
 - 1
 - 0

test2:
 - 1
 - 0
"""

    yaml_data = from_yaml(yaml_text, AnswersFile='/tmp/test2.yml')
    assert yaml_data is not None

# Generated at 2022-06-23 05:39:49.800578
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    yaml_str = u"test_dict:\n  key1: val1"


# Generated at 2022-06-23 05:39:51.291330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Constructor of class AnsibleLoader"""
    assert('AnsibleLoader' in globals()), "class AnsibleLoader not found in global scope"

# Generated at 2022-06-23 05:40:01.665011
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from datetime import datetime

    stream = '- 1234\n- 5678\n- 90'
    loader = AnsibleLoader(stream)
    loader.get_single_data() == [1234, 5678, 90]

    stream = '1234'
    loader = AnsibleLoader(stream)
    loader.get_single_data() == 1234

    stream = '- [1, 2, 3]\n- [4, 5, 6]\n- [7, 8, 9]'
    loader = AnsibleLoader(stream)
    loader.get_single_data() == [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

    stream = '''
        - foo
        - bar
        - baz
    '''
    loader = AnsibleLoader(stream)
    loader.get

# Generated at 2022-06-23 05:40:04.285328
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, 'test_AnsibleLoader')

# Generated at 2022-06-23 05:40:15.139415
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:40:16.316880
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name="filename", vault_secrets=[])

# Generated at 2022-06-23 05:40:28.489764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the (de)serialization of data structures with the AnsibleLoader and
    AnsibleDumper. This does not test the Vault integration.

    See also: plugins/lookup/vault.py for the Vault integration tests.
    """
    import ansible.parsing.dataloader
    import ansible.parsing.yaml.objects

    class MyDumper(ansible.parsing.yaml.objects.AnsibleDumper):
        """
        A custom dumper class that forces the representation of certain data
        types (integers, booleans, and floats) instead of letting PyYAML decide
        how to represent them.
        """

# Generated at 2022-06-23 05:40:38.514829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib

    # set up our test vault password
    test_pass = "testpass"
    test_file = tempfile.NamedTemporaryFile(delete=False)

    # create a simple inventory file with a vault

# Generated at 2022-06-23 05:40:43.393909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = """
    ---
    foo: !!python/object/apply:os.system ["echo hi"]
    """

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:40:56.762076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import ansible.constants as C


# Generated at 2022-06-23 05:40:59.131630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader("abcde\nfghij")
    AnsibleLoader("abcde\nfghij", vault_secrets='dummy_vault_secrets')

# Generated at 2022-06-23 05:41:10.281934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    from ansible.parsing.dataloader import DataLoader

    vault_secrets = [VaultSecret(id="foo", secret=b"secret foo")]
    vault_secrets[0]._

# Generated at 2022-06-23 05:41:20.769837
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This should be run with pytest
    import sys
    print("Python %s, pytest %s, pytest-cov %s" % (sys.version, pytest.__version__, pytest_cov.__version__))

    import io

# Generated at 2022-06-23 05:41:28.959430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    import io
    import sys

    def assert_loader_yaml(input_yaml, expected_python):
        with io.StringIO(u(input_yaml)) as stream:
            ansible_loader = AnsibleLoader(stream, file_name='myplay.yml')
            assert ansible_loader.get_data() == expected_python


# Generated at 2022-06-23 05:41:31.437689
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(['a: b'], file_name='test_AnsibleLoader')
    res = loader.get_single_data()
    assert type(res) == dict
    assert res == dict(a='b')

# Generated at 2022-06-23 05:41:33.100473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This will fail if there's a missing parent class
    loader = AnsibleLoader('')

# Generated at 2022-06-23 05:41:34.545452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml.Loader = ansible.parsing.dataloader.DataLoader

# Generated at 2022-06-23 05:41:44.073785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=redefined-outer-name
    yaml_str = (
        "%YAML 1.2\n"
        "---\n"
        "incorrect_date: 2002-04-28T19:14:45.000651\n"
        "correct_date: !!python/object/apply:datetime.datetime "
        "[2002, 4, 28, 19, 14, 45, 651]\n"
        "..\n"
        "more: 'blah'\n"
    )

    from io import StringIO
    import datetime

    stream = StringIO(yaml_str)
    loader = AnsibleLoader(stream)
    data = loader.get_data()

    assert isinstance(data.get('incorrect_date'), str)

# Generated at 2022-06-23 05:41:49.482048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\nfoo: "bar"\n'
    loader = AnsibleLoader(stream)
    result = []
    for data in loader:
        result.append(data)
    assert result == [{'foo': 'bar'}]

# Generated at 2022-06-23 05:41:53.148652
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_obj = """
- hosts:
    - localhost
- hosts:
    - localhost
"""
    yaml = AnsibleLoader(yaml_obj)
    yaml.get_single_data()

# Generated at 2022-06-23 05:41:58.438847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test invalid stream
    try:
        loader = AnsibleLoader(None)
    except TypeError as e:
        assert str(e) == 'expected str, bytes or os.PathLike object, not NoneType'

    # Test valid stream
    stream = 'test'
    loader = AnsibleLoader(stream)