

# Generated at 2022-06-23 05:32:00.548471
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence


# Generated at 2022-06-23 05:32:08.680291
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils._text import to_bytes
    from ansible.vars.unsafe_proxy import wrap_var
    a = AnsibleLoader("---\nfoo:\n  123: val")
    assert a.get_single_data() == {'foo': {u'123': u'val'}}
    a = AnsibleLoader("---\nfoo:\n  123: {a: b}")
    assert a.get_single_data() == {'foo': {u'123': {u'a': u'b'}}}
    a = AnsibleLoader("---\nfoo:\n  123: {a: 'b'}")

# Generated at 2022-06-23 05:32:09.800787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:32:11.085782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    Alb = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:20.699189
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import copy
import sys
import os

if sys.version_info[0] == 2:
    from StringIO import StringIO
else:
    from io import StringIO


from ansible.errors import AnsibleError
from ansible.module_utils._text import to_bytes, to_native

try:
    from yaml import CSafeLoader as SafeLoader, CSafeDumper as SafeDumper
except ImportError:
    from yaml import SafeLoader, SafeDumper


# Generated at 2022-06-23 05:32:29.207529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars import VariableManager
    stream = '{ "foo": { "bar": 1, "baz": 2 } }'
    file_name = '/some/file'
    vault_secrets = {'vault_password': 'test_password'}
    vm = VariableManager()
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    loader.construct_mapping()
    #print(dir(loader))
    #print(dir(AnsibleConstructor))
    #print(loader.construct_yaml_map)
    #print(loader.construct_yaml_timestamp)
    #print(AnsibleConstructor.construct_yaml_timestamp)
    #print('ok')

# Generated at 2022-06-23 05:32:40.347043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    loader = AnsibleLoader(None)
    # test unquoted string
    data = loader.construct_scalar(u'tag:yaml.org,2002:str', u'"abcd"')
    assert isinstance(data, basestring)
    assert u'"abcd"' == data
    try:
        data = loader.construct_scalar(u'tag:yaml.org,2002:str', u'abcd')
        assert False
    except UnicodeDecodeError:
        assert True
    # test quoted string

# Generated at 2022-06-23 05:32:42.876113
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader(None)
    # No assert is required.
    # To be improved:
    # * Check that no exception is raised.
    # * Write a test that the loader performs as expected.

# Generated at 2022-06-23 05:32:45.082497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    d = AnsibleLoader(sys.stdin).get_single_data()
    assert d is None

# Generated at 2022-06-23 05:32:55.577341
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    class MockStdout(object):
        # pylint: disable=too-few-public-methods
        def __setattr__(self, *args, **kwargs):
            pass

        def write(self, *args, **kwargs):
            pass

    class MockStderr(object):
        # pylint: disable=too-few-public-methods
        def __setattr__(self, *args, **kwargs):
            pass

        def write(self, *args, **kwargs):
            pass

    class MockStdin(object):
        # pylint: disable=too-few-public-methods
        def __setattr__(self, *args, **kwargs):
            pass

        def read(self, *args, **kwargs):
            pass


# Generated at 2022-06-23 05:33:01.537145
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert isinstance(loader, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(loader, Parser)
    else:
        assert isinstance(loader, Reader)
        assert isinstance(loader, Scanner)
        assert isinstance(loader, Parser)
        assert isinstance(loader, Composer)

# Generated at 2022-06-23 05:33:12.225015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import yaml

# Generated at 2022-06-23 05:33:20.749723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        # This is tested in test_yaml_loader.py
        return
    yaml_str = '''
    ---
    - hosts: all
      vars:
        http_port: 80
        max_clients: 200
      remote_user: root
      tasks:
      - name: ensure apache is at the latest version
        yum: pkg=httpd state=latest
      - name: write the apache config file
        template: src=/srv/httpd.j2 dest=/etc/httpd.conf
        notify:
      - name: ensure apache is running
        service: name=httpd state=started
    '''
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

# Generated at 2022-06-23 05:33:32.412586
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    # Direct construction
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)
    assert issubclass(loader.constructor.__class__, AnsibleConstructor)
    assert issubclass(loader.resolver.__class__, Resolver)

    # Indirect construction
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_seq(), AnsibleSequence)
    assert isinstance(loader.construct_yaml_map(), AnsibleMapping)

# Generated at 2022-06-23 05:33:41.823391
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import tempfile
    import time

    # pylint: disable=import-error,no-name-in-module,global-statement
    global ANSIBLE_TEST_DATA_ROOT

    if 'ANSIBLE_TEST_DATA_ROOT' in os.environ:
        ANSIBLE_TEST_DATA_ROOT = os.environ['ANSIBLE_TEST_DATA_ROOT']
    else:
        ANSIBLE_TEST_DATA_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    def test_parse(filename, vault_password=None):
        """
        Tests if parsing a YAML file is successful.
        """


# Generated at 2022-06-23 05:33:49.097976
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        from io import StringIO
    else:
        from StringIO import StringIO
    s = StringIO(u'[1, 2]')
    AnsibleLoader(s)

    s = StringIO(u'[1, 2]')
    AnsibleLoader(s)

    # new in Ansible 2.8
    s = StringIO(u'[1, 2]')
    AnsibleLoader(s, vault_secrets=['mypassword', 'mypassword2'])

# Generated at 2022-06-23 05:33:53.945527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='/etc/ansible/hosts')
    assert loader is not None

#constants used by the loader
from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:34:04.845610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile

    if HAS_LIBYAML:
        file_name = tempfile.NamedTemporaryFile(delete=False)
        file_name.write(b'''
            ---
            - hosts: localhost
              tasks:
                - name: should_succeed
                  debug: msg="{{ foo }}"
                  vars:
                      foo: bar
        ''')
        file_name.close()
        file_name = os.path.basename(file_name.name)

        vault_secrets = {
            'key_1': 'value_1',
            'key_2': 'value_2',
        }
        tmp_loader = AnsibleLoader(stream=file_name, file_name=file_name, vault_secrets=vault_secrets)
        assert isinstance

# Generated at 2022-06-23 05:34:09.100562
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)


# Generated at 2022-06-23 05:34:11.978769
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:34:12.624295
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:15.473355
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "test: 123"
    ansible_loader = AnsibleLoader(stream)
    data = ansible_loader.get_single_data()
    assert data['test'] == 123

# Generated at 2022-06-23 05:34:18.954656
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml
    d = from_yaml("- foo\n- 1")
    assert isinstance(d, list), 'got: %s' % repr(d)
    assert d == ['foo', 1], 'got: %s' % repr(d)

# Generated at 2022-06-23 05:34:24.921278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    - hosts:
        - foo
        - bar
      vars:
        - a=b
        - c=d
    """
    result = AnsibleLoader(data, '/path/to/file.yml').get_single_data()
    assert result == {'hosts': ['foo', 'bar'], 'vars': {'a': 'b', 'c': 'd'}}

# Generated at 2022-06-23 05:34:28.940580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert isinstance(AnsibleVaultEncryptedUnicode(), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:34:32.696676
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    yaml_data = StringIO('''
---
- hosts: all
  gather_facts: no
  tasks:
  - name: this is a test
    command: /bin/false
''')

    AnsibleLoader(yaml_data)

# Generated at 2022-06-23 05:34:33.648948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None,None)

# Generated at 2022-06-23 05:34:44.681925
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.compat.tests import unittest

    from ansible.parsing.yaml.wrapper import AnsibleLoader

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.loader = AnsibleLoader

        def tearDown(self):
            pass

        def test_NewInstance(self):
            inst = self.loader("test")
            self.assertIsInstance(inst, AnsibleLoader)

        def test_get_single_data(self):
            with open(os.path.join(os.path.dirname(__file__), 'loadertests/ansible_load.yml'), 'r') as testdata:
                yaml_list = list(self.loader(testdata))

# Generated at 2022-06-23 05:34:45.220496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:49.221176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None, file_name="foo", vault_secrets="bar")
    assert x.file_name == "foo"
    assert x.vault_secrets == "bar"

# Generated at 2022-06-23 05:34:49.817599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:59.905817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import os

    current_dir = os.path.dirname(os.path.realpath(__file__))
    vault_password = AnsibleUnsafeText.from_native('vault_password')
    vault_secrets = VaultSecret('vault_password', vault_password)
    vault_secrets = [vault_secrets]


# Generated at 2022-06-23 05:35:08.027331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import yaml

    class TestLoader(AnsibleLoader):
        def test_function(self, node):
            pass

    if not yaml.Loader is Parser:
        return

    file_name = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'type_to_technique.yml')
    file_stream = open(file_name, 'r')
    new_loader = TestLoader(file_stream)
    try:
        print(new_loader.get_single_data())
    except yaml.constructor.ConstructorError as e:
        print(repr(e))

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:19.271687
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vault import VaultSecret


# Generated at 2022-06-23 05:35:31.636934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import textwrap
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # We use textwrap.dedent on all the text here because other we get odd
    # failures due to the way YAML and python deal with trailing whitespace.

    # Read from a file
    text = textwrap.dedent(u"""
        ---
        - hosts: localhost
          tasks:
          - name: Hello World
            debug:
              msg: "Hello World"
    """)
    stream = io.StringIO(text)
    loader = AnsibleLoader(stream)
    result = loader.get_single_data()

# Generated at 2022-06-23 05:35:37.238190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader
    #yaml.dumps = yaml_dumps
    #yaml.load = yaml_load
    yaml.safe_load = yaml_safe_load
    #yaml.scan = yaml_scan
    yaml.load_all = yaml_load_all
    yaml.safe_load_all = yaml_safe_load_all

# Generated at 2022-06-23 05:35:49.913977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This is a class representing AnsibleLoader
    -It should be able to parse with valid yaml input
    -It should be able to parse with invalid yaml input
    -It should raise a yaml.constructor.ConstructorError exception in case of invalid yaml
    '''
    # AnsibleLoader can parse with valid input
    valid_yaml = "---\n- hosts: all\n  tasks: []\n"

    # AnsibleLoader can parse with invalid input
    invalid_yaml = "---\n- hosts: all\n  tasks: \n"
    loader = AnsibleLoader(invalid_yaml)
    parsed = loader.get_single_data()
    assert isinstance(parsed, dict)
    assert 'tasks' not in parsed['hosts']

    # AnsibleLoader raises exception on invalid

# Generated at 2022-06-23 05:35:54.907224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    src = '''
- { skidoo: 123, filter: "trim" }
- { skidoo: 345, filter: "trim" }
- { skidoo: 567, filter: "trim" }
- { skidoo: 789, filter: "trim" }
'''
    data = AnsibleLoader(src).get_single_data()
    assert data[0]['skidoo'] == 123

# Generated at 2022-06-23 05:36:04.663050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # for testing purposes
    def build(self, node):
        return "CCCCCCCCCC"

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleScalarNode

    def construct_yaml_seq(self, node):
        value = AnsibleSequence()
        yield value
        value.extend(self.construct_sequence(node))

    def construct_yaml_map(self, node):
        value = AnsibleMapping()
        yield value
        value.update(self.construct_mapping(node))


# Generated at 2022-06-23 05:36:07.459537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from io import StringIO
    ansible_loader = AnsibleLoader(StringIO(""), "")
    assert sys.getrefcount(ansible_loader)

# Generated at 2022-06-23 05:36:16.084755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = b'''
- hosts: localhost
  tasks:
  - name: test task
    debug: msg="{{# import os; print os.path.relpath('/foo/bar/baz/qux', '/foo/bar') #}}"
    '''
    loader = AnsibleLoader(content)
    data = loader.get_single_data()
    assert data == {u'hosts': u'localhost', u'tasks': [{u'debug': {u'msg': u'baz/qux'}, u'name': u'test task'}]}

# Generated at 2022-06-23 05:36:16.758923
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:27.343061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test case 1:
    test1 = '''
---
- hosts: all
  vars:
    password: "{{ vault_password }}"
  tasks:
   - name: test shell
     shell: "echo {{ password }}"
'''
    yaml_obj = AnsibleLoader(test1)
    assert yaml_obj.get_single_data() == {'hosts': 'all', 'vars': {'password': '{{ vault_password }}'},
                                          'tasks': [{'name': 'test shell', 'shell': 'echo {{ password }}'}]}

    # Test case 2:

# Generated at 2022-06-23 05:36:35.978131
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    loader = AnsibleLoader(file_name='test_yaml_loader.yml')

    data = loader.get_single_data()
    assert data == {'key1': 'value1', 'key2': AnsibleUnsafeText(u'value2')}

    loader = AnsibleLoader(data="""
---
key3: value3
key4: "{{ lookup('env','USER') }}"
""")
    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert 'key3' in data
    assert data['key3'] == 'value3'
    assert 'key4' in data
    assert isinstance(data['key4'], AnsibleUnsafeText)

# Generated at 2022-06-23 05:36:43.139501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    try:
        import StringIO
    except ImportError:
        from io import StringIO

    data = StringIO.StringIO("""
---
{foo: bar, bar: baz}
---
[foo, bar, baz]
---
[{foo: bar}, {bar: baz}]
---
...
""")

    data.isatty = lambda: False
    data.encoding = lambda: 'utf-8'
    results = []
    for e in AnsibleLoader(data, file_name=sys.stderr).get_single_data():
        results.append(e)
    assert len(results) == 3
    assert results[0] == {'foo': 'bar', 'bar': 'baz'}
    assert results[1] == ['foo', 'bar', 'baz']


# Generated at 2022-06-23 05:36:52.244540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    stream = StringIO.StringIO('''
    ---
    - {host: "host1", group: "group1", username: "username1"}
    - {host: "host2", group: "group1", username: "username2"}
    - {host: "host3", group: "group2", username: "username3"}
    ''')
    loader = AnsibleLoader(stream)
    module_args = loader.get_single_data()
    print(module_args)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:53.348872
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:37:01.130249
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import io

    sample_vault_password = '$ANSIBLE_VAULT;1.1;AES256\n34623462346234623462346234623462346234623462346234623462346234623\n'
    sample_vault_password_file = io.StringIO(sample_vault_password)
    vault_secrets = [{'vault_password_file': sample_vault_password_file}]
    vault = VaultLib(vault_secrets)
    stream = '''$ANSIBLE_VAULT;1.1;AES256\n3564623564623564623564623564623564623564623564623564623564623564623\n'''

# Generated at 2022-06-23 05:37:09.129317
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = 'foo: bar\n'
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleUnicode)
    assert AnsibleDumper().represent_scalar('tag:yaml.org,2002:str', 'foo') == 'foo'
    assert AnsibleDumper().represent_scalar('tag:yaml.org,2002:str', 'foo') == 'foo'

# Generated at 2022-06-23 05:37:13.700208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = '''
        test:
            - foo # foo
            - !foo # not foo
            - !!str foo # foo
            - !!str !foo # foo
    '''

    loader = AnsibleLoader(yaml)
    loader.get_single_data()

# Generated at 2022-06-23 05:37:17.936546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Import module
    import ansible.parsing.yaml.loader
    # Create object of class AnsibleLoader
    obj = ansible.parsing.yaml.loader.AnsibleLoader(
        stream=None,
        file_name=None,
        vault_secrets=None
    )

# Generated at 2022-06-23 05:37:20.869989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert len(ansible_loader.yaml_constructors) == 1
    assert len(ansible_loader.yaml_multi_constructors) == 2

# Generated at 2022-06-23 05:37:28.129307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Parser)
    else:
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Composer)

# Generated at 2022-06-23 05:37:30.800137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('hello: world')
    assert loader is not None
    assert loader.get_single_data() == {u'hello': u'world'}

# Generated at 2022-06-23 05:37:33.057587
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '123'
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:37:41.897499
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
      hosts: all
      tasks:  
        - name: check the ansible version.
          command: ansible --version
    """
    ansible_loader = AnsibleLoader(None)
    data = ansible_loader.get_single_data(yaml_str)
    for k, v in data.items():
        assert k == 'hosts' and v == 'all'
    for task in data['tasks']:
        assert task['name'] == 'check the ansible version.'
        assert task['command'] == 'ansible --version'

# Generated at 2022-06-23 05:37:48.048560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    vars = {'var1': 'value1'}
    stream = '''
- var1
- {{ var1 }}
- {{ var1 }}
- {% if var1 %}
- {{ var1 }}
- {% endif %}
'''
    loader = AnsibleLoader(stream, vault_secrets=vars)
    data = loader.get_single_data()
    assert data == [u'var1', u'value1', u'value1', u'value1'], "AnsibleLoader() returned invalid data"

# Generated at 2022-06-23 05:37:55.740065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Setup AnsibleLoader instance using default vault secrets
    stream = '{"key1": "value1", "key2": "value2"}'
    loader = AnsibleLoader(stream)

    # Check the AnsibleLoader object
    assert loader.stream == stream
    assert loader.file_name is None
    assert loader.vault_secrets is None

    # Setup AnsibleLoader instance using specified file_name, vault secrets and stream
    file_name = 'filename'
    vault_secrets = ['vault1']
    stream = '{"key3": "value3", "key4": "value4"}'
    loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

    # Check the AnsibleLoader object
    assert loader.stream == stream
    assert loader.file_name == file

# Generated at 2022-06-23 05:38:05.833487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # To avoid error messages like this,
    #  WARNING: The full traceback of the error was:
    #  File "/Users/nakagawa_sho/dev/oss/ansible/ansible/parsing/yaml/loader.py", line 49, in __init__
    #    super(AnsibleLoader, self).__init__(file_name=file_name, vault_secrets=vault_secrets)
    #  TypeError: Error when calling the metaclass bases
    #      function() argument 1 must be code, not str
    # ... add import of necessary library
    import sys
    import types

    loader = AnsibleLoader(file_name='some_file')

    # __init__() has 7 args
    assert AnsibleLoader.__init__.__code__.co_argcount == 4

   

# Generated at 2022-06-23 05:38:06.740053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    _ = AnsibleLoader('')

# Generated at 2022-06-23 05:38:07.292193
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:09.104971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Just an empty test to add coverage
    """
    stream = u''
    assert AnsibleLoader(stream) is not None

# Generated at 2022-06-23 05:38:09.767468
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:10.414753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:38:16.087385
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''
---
a: b
c: &d e
f:
  - g
  - h
'''
    loader = AnsibleLoader(s)
    assert loader is not None
    assert loader.construct_yaml_map is not None
    assert loader.construct_yaml_seq is not None
    assert loader.construct_mapping is not None
    assert loader.construct_sequence is not None

# Generated at 2022-06-23 05:38:22.880299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """This is the test for AnsibleLoader"""
    obj = AnsibleLoader("Stream", "FileName", "VaultSecrets")
    assert hasattr(obj, "BaseConstructor")
    assert hasattr(obj, "AnsibleConstructor")
    assert hasattr(obj, "AnsibleSet")
    assert hasattr(obj, "AnsibleSequence")

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:38:23.724095
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(AnsibleLoader)

# Generated at 2022-06-23 05:38:29.337620
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    stream = file('../../lib/ansible/module_utils/common/network/ios/argspec/vlan.yaml')

    data = yaml.load(stream, Loader = AnsibleLoader)
    print(data.keys())


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:38:30.725785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(None), AnsibleLoader)


# Generated at 2022-06-23 05:38:34.744491
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """pytest for AnsibleLoader class"""
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:38:36.265081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader([], file_name=None, vault_secrets=None)

# Generated at 2022-06-23 05:38:38.016008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader != None

# Generated at 2022-06-23 05:38:44.767445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    test_stream = io.BytesIO(b"""
ansible_connection: ssh
ansible_ssh_user: root
ansible_host: 192.168.1.1
ansible_ssh_pass: 'password'
""")
    loader = AnsibleLoader(stream=test_stream)
    data = loader.get_single_data()
    print(data)
    assert data['ansible_ssh_pass'] == 'password'

# Generated at 2022-06-23 05:38:54.476672
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    loader = AnsibleLoader(None)
    assert loader.construct_python_str('foo') == 'foo'
    assert loader.construct_python_str('foo') == 'foo'
    assert loader.construct_yaml_str('foo') == 'foo'
    assert loader.construct_yaml_str('foo') == 'foo'

    # Test vault_secrets display - no vault_secrets provided
    loader1 = AnsibleLoader(None)
    assert loader1.construct_yaml_str('foo') == 'foo'

    # Test vault_secrets display - empty vault_secrets provided
    loader2 = AnsibleLoader(None, vault_secrets={})
    assert loader

# Generated at 2022-06-23 05:38:55.020717
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:39:02.646895
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = {'key': 'value', 'with': 'spaces'}
    assert isinstance(data['key'], str)
    assert isinstance(data['with'], str)

    assert isinstance(AnsibleLoader(None).construct_object(data['key']), AnsibleUnicode)
    assert isinstance(AnsibleLoader(None).construct_object(data['with']), AnsibleUnicode)
    assert isinstance(AnsibleLoader(None).construct_object(data), dict)
    assert isinstance(AnsibleLoader(None).construct_object(data.keys()), list)
    assert isinstance(AnsibleLoader(None).construct_object(data.values()), list)

# Generated at 2022-06-23 05:39:09.776591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import json
    import yaml

    # YAML heavy use constructor AnsibleLoader
    # and create yaml object.

    # ansible_loader
    ansible_loader = yaml.AnsibleLoader

    # yaml object
    yaml_obj = yaml.load

    # test_yaml_path
    test_yaml_path = os.path.join(os.path.dirname(__file__), '..', 'constructor', 'test_yaml')

    # list _test_yaml_files

# Generated at 2022-06-23 05:39:21.085782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    import yaml

    yaml_str = """
a: 1
b:
  c: 3
  d: 4
"""

    if HAS_LIBYAML:
        loader = AnsibleLoader(yaml_str)
        data = loader.get_single_data()
        assert isinstance(data, AnsibleMapping)
        assert 'a' in data
        assert 'b' in data
        assert data['a'] == 1
        assert isinstance(data['b'], AnsibleMapping)
        assert data['b']['c'] == 3
        assert data['b']['d'] == 4
    else:
        data = yaml.safe_load(yaml_str)

# Generated at 2022-06-23 05:39:33.342848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

    # Test variables
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.parsing.convert_bool import boolean
    vault_secrets = [('default', VaultLib(['secret']))]
    context = PlayContext()
    context.network_group = 'group1'
    context.remote_addr = '127.0.0.1'
    facts = {}
    combine_vars(facts, context.CLIARGS)
    combine_vars(facts, context.SETUP_CACHE)

    # Test AnsibleLoader with no vault_secrets

# Generated at 2022-06-23 05:39:34.916200
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.tag_to_name

# Generated at 2022-06-23 05:39:36.446961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # TODO: write unit tests
  assert True

# Generated at 2022-06-23 05:39:46.791637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-argument
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:39:48.973718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None)
    assert loader.file_name == None
    assert loader.vault_secrets == None

# Generated at 2022-06-23 05:39:52.036671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '--- 1\n...'
    loader = AnsibleLoader(stream, None)
    assert loader.construct_yaml_int(u'1') == 1
    assert loader.deprecation_warnings == []
    assert loader.failure_warnings == []

# Generated at 2022-06-23 05:40:01.908932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import module_constructor
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleUnicodeString

    data = '''
a: 1
b:
  - 1
  - 2
  - 3
c: { d: 1, e: 2, f: 3 }
'''
    loader = AnsibleLoader(data)
    ds = loader.get_single_data()
    assert isinstance(ds['a'], int)
    assert isinstance(ds['b'], AnsibleSequence)

# Generated at 2022-06-23 05:40:08.443765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Ensure the output of AnsibleLoader is an AnsibleDict instance
    """
    data = "---\n"
    data += "- name: hello world\n"
    data += "  uri:\n"
    data += "    url: http://example.com"
    loader = AnsibleLoader(data)
    loader.get_single_data()

# Generated at 2022-06-23 05:40:19.891247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    from pprint import pprint
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    class TestConstructor(unittest.TestCase):
        def setUp(self):
            self.yaml = '''
            - hosts: all
              tasks:
                - test:
                    foo: bar
              vars:
                - foo: bar
            '''
            self.data = None
            self.stream = StringIO.StringIO(self.yaml)
            self.loader = AnsibleLoader(self.stream)

        def tearDown(self):
            self.stream.close()


# Generated at 2022-06-23 05:40:28.965119
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.six import text_type

    valid_yaml = u"foo: bar baz: true"
    invalid_yaml = u"foo: [ { "
    loader = AnsibleLoader(valid_yaml)
    assert loader.get_single_data() == dict(foo=u"bar", baz=True)

    loader = AnsibleLoader(invalid_yaml)
    try:
        loader.get_single_data()
        assert False
    except AnsibleLoader.AnsibleParserError:
        assert True

# Generated at 2022-06-23 05:40:36.641013
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:40:45.324331
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = '''
        ansible_facts:
            configured_module_groups:
                - name: Core
                  description: Basic default modules shipped with Ansible
                  modules:
                      - setup
                      - uri
            version:
                ansible: 2.2.0.0
                ansible_date: 2016-02-18
                ansible_version: 2.2.0.0
                ansible_search_path: ['/etc/ansible']
    '''

    data = AnsibleLoader(string, file_name='/etc/ansible/ansible.cfg').get_single_data()

# Generated at 2022-06-23 05:40:48.999690
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass
    tl = TestAnsibleLoader('')

# Generated at 2022-06-23 05:40:59.707195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from nose.tools import assert_equal
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader('')
    assert_equal(loader.get_single_data(), None)
    assert_equal(loader.construct_yaml_nil(), None)
    assert_equal(loader.construct_yaml_str(None), '')

    u = loader.construct_yaml_str(u'unicode!')
    assert_equal(u, u'unicode!')
    assert_equal(type(u), type(u'unicode!'))

    assert_equal(loader.construct_yaml_int(u'42'), 42)
    assert_equal(loader.construct_yaml_float(u'4.2'), 4.2)

# Generated at 2022-06-23 05:41:08.183042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.vault import VaultLib
    ansible_loader = AnsibleLoader(None, os.path.join(os.path.dirname(__file__), "test_vault_a.yml"))
    vault = VaultLib([])
    vault_pass = vault.decrypt(ansible_loader.vault_secrets)
    assert vault_pass == ["password"]

if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-23 05:41:15.468141
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from ansible.parsing.yaml.constructor import AnsibleConstructor
        from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    except ImportError:
        print("SKIP: Ansible 2.5+ required for this test")
        import sys
        sys.exit(0)

    for cls in (AnsibleSequence, AnsibleMapping):
        o = cls()
        assert isinstance(o, cls)

    # FIXME: add some more tests here

# Generated at 2022-06-23 05:41:21.820641
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError
    vault_secrets = [VaultLib(['vault_password'])]

    # Test fail
    with open(__file__) as stream:
        try:
            AnsibleLoader(stream, vault_secrets=vault_secrets)
            assert False
        except AnsibleParserError as e:
            assert str(e).startswith('No YAML found in:')

# Generated at 2022-06-23 05:41:33.659400
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.plugins.loader import find_plugin

    data = {'a': 1, 'b': 2, 'c': 3}
    # just testing that the plugin loader works
    mod = find_plugin('copy')
    assert mod is not None, mod
    stream = open(mod._original_path, 'r')
    data = yaml.load(stream, Loader=AnsibleLoader)
    assert isinstance(data, dict), data
    assert data is not None

    # test round-trip of data
    stream = StringIO()
    yaml.dump(data, stream, Dumper=AnsibleDumper, default_flow_style=False)
    stream.seek(0)

# Generated at 2022-06-23 05:41:44.257721
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.errors import AnsibleParserError

    # a unicode string
    yaml_str = u'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, dict)
    assert not isinstance(data['foo'], AnsibleVaultEncryptedUnicode)

    # a byte string
    yaml_str = b'foo: bar'
    data = AnsibleLoader(yaml_str).get_single_data()
    assert isinstance(data, dict)
    assert not isinstance(data['foo'], AnsibleVaultEncryptedUnicode)

    # a byte string that contains a vault string
    yaml_

# Generated at 2022-06-23 05:41:45.938723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")


# Generated at 2022-06-23 05:41:56.848808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    docs = AnsibleLoader("""
- 2014-06-29
- "2014-06-29"
- datetime.date(2014, 6, 29)
- { some: "nested object" }
- "{{ ansible_hostname }}"
""")
    assert docs.construct_object(docs.get_node()) == datetime.date(2014, 6, 29)
    assert docs.construct_object(docs.get_node()) == datetime.date(2014, 6, 29)
    assert docs.construct_object(docs.get_node()) == datetime.date(2014, 6, 29)
    assert docs.construct_object(docs.get_node()) == {'some': 'nested object'}
    assert docs.construct_object(docs.get_node()) == '{{ ansible_hostname }}'