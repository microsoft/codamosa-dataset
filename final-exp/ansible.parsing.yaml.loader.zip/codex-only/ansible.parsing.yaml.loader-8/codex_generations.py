

# Generated at 2022-06-23 05:32:00.569677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:32:01.416714
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:32:07.327952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Instantiate a dummy stream (should be impossible to do anything with it directly)
    stream = 'dummy_stream'
    # Instantiate an AnsibleLoader object
    al = AnsibleLoader(stream)
    # Test the object is a AnsibleLoader object
    assert type(al) is AnsibleLoader
    # Test the object is instance of a parent class
    assert isinstance(al, Parser)
    # Test the object is instance of a parent class
    assert isinstance(al, AnsibleConstructor)
    # Test the object is instance of a parent class
    assert isinstance(al, Resolver)

# Generated at 2022-06-23 05:32:08.433422
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: write this
    pass

# Generated at 2022-06-23 05:32:17.949353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test_loader(file_name):
        stream = file(file_name, 'r')
        loader = AnsibleLoader(stream, file_name=file_name)
        data = loader.get_single_data()
        return data
    data = test_loader('test_AnsibleConstructor.yaml')
    assert data == {'a': {'b': 'c'}, 'd': 'e'}
    data = test_loader('test_AnsibleConstructor_2.yaml')
    assert data == 'foo'
    data = test_loader('test_AnsibleConstructor_3.yaml')
    assert data == [{'foo': 'bar'}, {'baz': 'faz'}]
    data = test_loader('test_AnsibleConstructor_4.yaml')

# Generated at 2022-06-23 05:32:27.450101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleScalar

    data = dict(
        a_sequence=[1,2,3],
        a_mapping=dict(
            key1='value1',
            key2='value2',
            key3='value3',
        ),
        a_scalar='value4',
        a_unicode=u'\xE1\x88\xB4',
    )

    stream = AnsibleDumper.represent_dict(data)
    loader = AnsibleLoader(stream)
    data2 = loader.get

# Generated at 2022-06-23 05:32:36.771938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class FakeStream:
        stream = None

    class FakeVaultSecret:
        vault_secret = None

    fake_stream = FakeStream()
    fake_vault_secrets = FakeVaultSecret()
    ansible_loader = AnsibleLoader(fake_stream, file_name="fake_file_name", vault_secrets=fake_vault_secrets)
    assert ansible_loader.stream == fake_stream.stream
    assert ansible_loader.file_name == "fake_file_name"
    assert ansible_loader.vault_secrets == fake_vault_secrets.vault_secrets

    class FakeLoad:
        load_all = None

    class FakeScan:
        check_token = None

    class FakeParse:
        compose_document = None
        compose_node = None


# Generated at 2022-06-23 05:32:44.861560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

# Generated at 2022-06-23 05:32:47.496972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
    ---
    {}
    ---
    {foo: bar}
    ---
    keys are ignored
    """
    loader = AnsibleLoader(stream)
    for token in loader:
        print(token)

# Generated at 2022-06-23 05:32:54.940264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.vault import VaultLib
    from ansible.errors import AnsibleParserError
    import yaml


# Generated at 2022-06-23 05:32:56.781602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader("---[local]\n").get_single_data()
    assert data == "[local]"

# Generated at 2022-06-23 05:33:08.462908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    import ansible.parsing.yaml.objects

    yaml_str = '''
- hosts: localhost
  connection: local
  tasks:
    - name: test string type
      shell: echo "{{ test_string }}"
      register: result
      vars:
        test_string: "some string"
    - debug: var=result.stdout_lines
'''
    yaml_stream = io.StringIO(yaml_str)

    loader = AnsibleLoader(yaml_stream)  # pylint: disable=no-member
    data = loader.get_single_data()
    task = data.get('tasks')[0]
    task_var = task.get('vars')

# Generated at 2022-06-23 05:33:10.550193
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test that AnsibleLoader is working properly
    '''
    # Just make sure it does not fail
    AnsibleLoader('{}', None)

# Generated at 2022-06-23 05:33:11.835724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: AnsibleLoader doesn't have a test case yet
    pass

# Generated at 2022-06-23 05:33:12.732623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print(AnsibleLoader)



# Generated at 2022-06-23 05:33:15.052885
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    validate our base class for yaml loading is callable with no error
    '''
    a = AnsibleLoader(None)
    assert(a is not None)

# Generated at 2022-06-23 05:33:21.981306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # initialize the loader
    stream = "---\nfoo: bar"
    loader = AnsibleLoader(stream)

    # initialize the dumper
    dumper = AnsibleDumper()

    # parse the YAML and generate a datastructure
    data = loader.get_single_data()

    # convert the datastructure back to YAML and verify it matches the original
    assert dumper.dump(data) == 'foo: bar\n'

    # verify the datastructure created is an AnsibleMapping
    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-23 05:33:24.870075
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = 'test: !var derp'
    loader = AnsibleLoader(s)
    loader.get_single_data()

# Generated at 2022-06-23 05:33:34.589957
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    fd = open("tests/yaml/unicode_variables.yml")
    stream = fd.read()
    t = AnsibleLoader(stream, file_name="test.yml")
    data = t.get_single_data()
    print(data, file=sys.stderr)

    import sys
    fd = open("tests/yaml/unicode_variables.yml")
    stream = fd.read()
    t = Parser(stream)
    data = t.get_single_data()
    print(data, file=sys.stderr)


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:33:35.205914
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:46.601896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    # Create Variable manager
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(vault_pass='secret')

    # Create dataloader
    loader = DataLoader()

    # Create vault_secrets match
    vault_secrets_match = dict(DEFAULT_VAULT_ID_MATCH)
    vault_secrets_match.update({'vault_pass': 'secret'})

    # Set vault_secrets match
    loader.set_vault_secrets(vault_secrets_match)

    # Create AnsibleLoader instance

# Generated at 2022-06-23 05:33:47.991635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert (issubclass(AnsibleLoader, Parser))

# Generated at 2022-06-23 05:33:55.674281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = b"""
- name: test_host
  vars:
    var: var_value_1

- name: test_host_2
  include:
    - var: var_value_2
      other: value
"""
    loader = AnsibleLoader(data)
    results = loader.get_single_data()
    assert results[0]['vars']['var'] == 'var_value_1'
    assert results[1]['include'][0]['var'] == 'var_value_2'

# Generated at 2022-06-23 05:33:58.454726
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test_AnsibleLoader_init(self):
            stream = io.StringIO()
            AnsibleLoader(file_name='test_file', stream=stream, vault_secrets=[])

# Generated at 2022-06-23 05:34:02.973548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    d = AnsibleLoader(sys.stdin)
    print(d)

# Generated at 2022-06-23 05:34:08.795601
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert not hasattr(loader, '_composer'), \
        "_composer attribute should not exist when constructing AnsibleLoader"
    assert hasattr(loader, '_constructor'), "Ansible constructor attribute should exist"
    assert isinstance(loader._constructor, AnsibleConstructor), \
        "The _constructor attribute should be of type AnsibleConstructor"

# Generated at 2022-06-23 05:34:10.392889
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    AnsibleLoader([])

# Generated at 2022-06-23 05:34:11.558755
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # FIXME: add tests
    pass


# Generated at 2022-06-23 05:34:14.429808
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO

    stream = StringIO.StringIO("testvalue: !testtag 1")
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-23 05:34:18.512360
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secret = VaultLib('hello')
    vault_secret.update_password('bye', None, 1)
    vault_secrets = { '1' : vault_secret }
    x = AnsibleLoader(file_name='test', vault_secrets=vault_secrets)

# Generated at 2022-06-23 05:34:24.682661
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader:
        def __init__(self):
            self.file_name = "test.yml"
            self.vault_secrets = {'test': 'secret'}

    loader = AnsibleLoader(stream = [], file_name = TestAnsibleLoader.file_name, vault_secrets = TestAnsibleLoader.vault_secrets)
    assert loader.file_name == TestAnsibleLoader.file_name
    assert loader.vault_secrets == TestAnsibleLoader.vault_secrets

# Generated at 2022-06-23 05:34:28.689042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

    assert isinstance(loader, Parser)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)



# Generated at 2022-06-23 05:34:29.515511
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:34:38.099441
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert AnsibleLoader('')
    assert AnsibleLoader('', file_name='test_file_name')
    assert AnsibleLoader('', vault_secrets=['a', 'b', 'c'])
    assert AnsibleLoader.construct_yaml_map(AnsibleLoader('')) == {}
    assert AnsibleLoader.construct_yaml_str(AnsibleLoader('')) == u''
    assert AnsibleLoader.construct_yaml_seq(AnsibleLoader('')) == []
    assert AnsibleLoader.construct_yaml_unicode(AnsibleLoader('')) == AnsibleUnicode(u'')
    assert AnsibleLoader.construct_yaml

# Generated at 2022-06-23 05:34:44.674648
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # load the test data
    data = open('../test/test_data.yaml').read()
    loader = AnsibleLoader(data)

    # test the load
    data = loader.get_single_data()
    assert data == {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9}

# Generated at 2022-06-23 05:34:54.546806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    # input data
    data = '''
    stage:
      - name: stage-1
        file: /tmp/file1
        action: delete
      - name: stage-2
        file: /tmp/file2
        action: create
    '''
    AnsiLoader = AnsibleLoader(data, file_name='test')
    # executing of _construct_mapping method (private)
    mapping = AnsiLoader._construct_mapping(AnsiLoader.get_single_data())
    assert mapping.tag == 'tag:yaml.org,2002:map'
    assert len(mapping.value) == 1
    assert mapping.value[0].value[0].value == 'stage'

# Generated at 2022-06-23 05:35:02.731015
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_password = '$1$WtH8oKLD$o7yek0nJGVlk0BJvZXjIg.'

# Generated at 2022-06-23 05:35:13.991035
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:35:19.952301
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    stream = u'foo: bar'
    assert isinstance(AnsibleLoader(stream).get_single_data(), dict)
    assert isinstance(AnsibleLoader(stream).get_single_data()[u'foo'], AnsibleUnicode)
    assert AnsibleLoader(stream).get_single_data()[u'foo'] == u'bar'

# Generated at 2022-06-23 05:35:23.420989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Set up Class
    ansible_loader = AnsibleLoader(stream=None)
    # Test type of object
    assert isinstance(ansible_loader, AnsibleLoader)

# Generated at 2022-06-23 05:35:34.049208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.module_utils.six import string_types


# Generated at 2022-06-23 05:35:44.452965
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:35:55.168782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.module_utils.six import PY3
    loader = AnsibleLoader(b"abc: def\nghi: jkl")
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data.get('abc'), AnsibleUnicode)
    assert isinstance(data.get('ghi'), AnsibleUnicode)
    assert data['abc'] == "def"
    assert data['ghi'] == "jkl"
    #
    loader = AnsibleLoader(b"- abc\n- def\n- ghi")
    data = loader.get_single_data()

# Generated at 2022-06-23 05:36:01.947575
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    stream = '''
    - name: Execute /etc/init.d/httpd and only start if not running
      action: service name=httpd state=started
      become: yes
      become_user: root
      args:
        chdir: /tmp
    '''
    loader = AnsibleLoader(stream)
    #print(loader)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:05.955042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml_str = """
foo:
- name: test
  value: the_value
"""
    loaded_str = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert loaded_str == {
        'foo': [{
            'name': 'test',
            'value': 'the_value',
        }],
    }

# Generated at 2022-06-23 05:36:13.191556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml
    yaml_str = """
    - test
    - a_string
    - 12345
    - 1.2345
    - {'a': 'b'}
    - test2
    """
    data = yaml.load(yaml_str, Loader=AnsibleLoader)
    assert data[0] == 'test'
    assert data[1] == 'a_string'
    assert data[2] == 12345
    assert data[3] == 1.2345
    assert data[4] == {'a': 'b'}
    assert data[5] == 'test2'

# Generated at 2022-06-23 05:36:15.222263
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-23 05:36:20.711764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test(data, expected_data):
        loader = AnsibleLoader(data)
        value = loader.get_single_data()
        assert value == expected_data

    test.unittest = ['constructor']

    # Test if file_name is set
    loader = AnsibleLoader('')
    assert loader._loader.file_name is not None

    # Test if empty string is loaded
    test('', '')

    # Test if string with spaces is loaded
    test('  ', '  ')

    # Test if empty array is loaded
    test('[]', [])

    # Test if array with empty elements is loaded
    test('[,,,]', [None, None, None])

    # Test if array with empty elements and spaces is loaded
    test('[ , , , ]', [None, None, None, None])

   

# Generated at 2022-06-23 05:36:31.912682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from yaml.resolver import Resolver
    from io import StringIO
    import yaml
    yaml_str = """
---
hosts:
  - localhost
  - localhost
name: ansible-test
vars:
  var1:
    - 1
    - 2
"""
    yaml_stream = StringIO(yaml_str)
    ansible_loader = AnsibleLoader(yaml_stream)
    ansible_loader.get_data()
    print(ansible_loader.data)

# Generated at 2022-06-23 05:36:35.834123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
- hosts: localhost
  roles:
    - { role: foo, bar: baz }
"""
    l = AnsibleLoader(data)
    assert("bar" in l.get_single_data().get("roles")[0])

# Generated at 2022-06-23 05:36:42.109342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    assert isinstance(obj, AnsibleLoader)

    # Test the properties of obj
    assert not obj._parser
    assert isinstance(obj._constructor, AnsibleConstructor)
    assert not obj.nodes
    assert not obj.node
    assert not obj.index
    assert obj.file_name == None
    assert obj.vault_secrets == None
    assert obj.check_type_id == True

# Generated at 2022-06-23 05:36:42.799224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:36:44.809117
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-23 05:36:45.413488
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:36:46.074570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:56.377647
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import StringIO
    from ansible.constants import mk_boolean
    from ansible.module_utils.common.yaml import transform

    test_yaml = StringIO.StringIO()
    test_yaml.write("""
    - regular:
        yaml: '---'
        string:
          - with:
              - embedded:
                  - yaml: '---'

    - regular:
      yaml: '---'
      string:
        - with:
            - embedded:
                - yaml: '---'
    """)
    test_yaml.seek(0, os.SEEK_SET)

    yaml_data = AnsibleLoader(test_yaml).get_single_data()

    transform(yaml_data, mk_boolean, 'false', 'true')


# Generated at 2022-06-23 05:36:57.503861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:36:59.028723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:37:09.169260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    ---
    - hosts: localhost
      tasks:
      - name: test1
        ping:
      - ping:
      - name: test2
        ping:
    '''
    loader = AnsibleLoader(stream)
    assert loader
    data = loader.get_single_data()
    assert data
    assert 'tasks' in data[0]
    assert len(data[0]['tasks']) == 3
    assert data[0]['tasks'][0] == {'name': 'test1', 'ping': True}
    assert data[0]['tasks'][1] == {'ping': True}
    assert data[0]['tasks'][2] == {'name': 'test2', 'ping': True}


# Generated at 2022-06-23 05:37:14.945774
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
        ---
        - hosts:
            - server-a
            - server-b
        tasks:
            - name: install package with apt
              apt:
                 name: apache2
        """

    r = AnsibleLoader(yaml_str, file_name="lol.yml")
    print(r.get_single_data())


# Generated at 2022-06-23 05:37:20.284143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    with open('test/data/vault_test_data') as vault_file:
        vault_secret = vault_file.read()
    loader = AnsibleLoader('test/data/vault_test.yaml', vault_secrets=[VaultLib(vault_secret)])
    loader.get_single_data()
    assert loader.stream.closed is True

# Generated at 2022-06-23 05:37:20.922486
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:37:22.544117
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# vim: set et sts=4 sw=4 ts=4 :

# Generated at 2022-06-23 05:37:33.558210
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text

    # check if implicit resolver is used
    def constructor(loader, node):
        return AnsibleUnicode(u'foo')

    class AnsibleLoader(Parser, AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            Parser.__init__(self, stream)  # pylint: disable=non-parent-init-called
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self, loader=self)


# Generated at 2022-06-23 05:37:35.942896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    test_AnsibleLoader:
    check if this class is accessible
    '''
    pass

# Generated at 2022-06-23 05:37:41.163852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_text
    data = """
    ---
    foo: 123
    """

    actual = AnsibleLoader(data).get_data()
    assert actual == {u'foo': 123}

    actual = to_text(AnsibleLoader(data))
    assert actual == '\nfoo: 123\n'

# Generated at 2022-06-23 05:37:42.705154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:37:50.705447
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:37:52.558886
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None


# Generated at 2022-06-23 05:37:57.856106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # checking the case when a dict has a key named "yaml_tag"
    data_dict = dict()
    data_dict["yaml_tag"] = "#test"
    data_dict["testkey"] = "testvalue"
    assert AnsibleLoader(data_dict).get_single_data() == data_dict

# Generated at 2022-06-23 05:37:58.456829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:09.323771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class Foo(AnsibleBaseYAMLObject):
        pass

    class Bar(AnsibleUnicode):
        pass

    class Baz(AnsibleUnicode):
        pass

    data = dict(
        foo=Foo,
        bar=Bar,
        baz=Baz,
    )

    loader = AnsibleLoader(data)
    assert loader.construct_yaml_map(node=None) == data

# Generated at 2022-06-23 05:38:12.012507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, object)
    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-23 05:38:19.494746
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys

    if sys.version_info[0] > 2:
        unicode = str

    stream = 'foo: bar\n'
    loader = AnsibleLoader(stream, AnsibleVaultEncryptedUnicode('A' * 32, 'A' * 32, 'A' * 16))

    data = loader.get_single_data()

    assert isinstance(data, dict)
    assert isinstance(data['foo'], unicode) and data['foo'] == u'bar'

# Generated at 2022-06-23 05:38:31.020525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.module_utils.six import string_types, text_type

    data = """
    foo: 1
    bar:
      - 2
      - 3
    baz: foobar
    """
    loader = AnsibleLoader(data)
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    root = loader.get_single_data()
    assert isinstance(root, AnsibleMapping)
    assert isinstance(root['foo'], int)
    assert isinstance(root['bar'], AnsibleSequence)
    assert isinstance(root['bar'][0], int)
    assert isinstance(root['bar'][1], int)

# Generated at 2022-06-23 05:38:36.161724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None, None)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)
    if HAS_LIBYAML:
        assert isinstance(loader, Parser)

# Generated at 2022-06-23 05:38:40.950535
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    file_name = os.path.join(os.path.dirname(__file__), "test_data/test.yaml")
    test_file = open(file_name)
    collection = AnsibleLoader(test_file).get_single_data()
    assert isinstance(collection, dict)
    assert collection['foo'] == 1
    assert collection['bar'] == [2, 3]
    assert collection['foobar'] == {'a': 5, 'b': 6}

# Generated at 2022-06-23 05:38:53.109543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import datetime
    import os
    import re
    import sys

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    cur_dir = os.path.dirname(__file__)
    data_loader = AnsibleLoader(open(os.path.join(cur_dir, 'test_loader_constructor.yml')).read())
    data = data_loader.get_single_data()
    #assert type(data[0]) is AnsibleUnicode
    assert str(data[1]) == 'string'
    assert str(data[2]) == 'unicode: ascii'


# Generated at 2022-06-23 05:39:03.843048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import copy
    from ansible.module_utils.common.yaml.objects import AnsibleBaseYAMLObject
    from ansible.module_utils.common.yaml.objects import AnsibleMapping
    from ansible.module_utils.common.yaml.objects import AnsibleSequence
    from ansible.module_utils.common.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 05:39:08.560479
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import StringIO
    s = StringIO.StringIO('--- {}\n')
    l = AnsibleLoader(s, file_name='test_file')
    assert l.get_single_data() == {}

# Generated at 2022-06-23 05:39:20.120014
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    class TestAnsibleLoader(AnsibleLoader):
        pass


# Generated at 2022-06-23 05:39:32.537300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    class MyYAMLObject(AnsibleBaseYAMLObject):
        yaml_tag = u'!look-ma-I-m-a-tag'

    def construct_yaml_object(self, node):
        data = AnsibleLoader.construct_mapping(self, node)
        return MyYAMLObject(**data)
    AnsibleLoader.add_constructor(u'!look-ma-I-m-a-tag',
                                  construct_yaml_object)


# Generated at 2022-06-23 05:39:38.314847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Place your unit tests here.  Some must-haves that you may want to
    # test:
    #
    # * Ability to construct using the empty string as a parameter
    # * Pass a unicode string expression and verify that it does the correct thing
    # * Pass a non-string parameter and verify that it raises the correct exception.
    # * Pass a string expression with an undefined reference and verify that it raises the correct exception.
    pass

# Generated at 2022-06-23 05:39:39.439937
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:39:48.632850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import ansible.parsing.yaml.loader

    data = """
    a: 1
    b:
      c: 2
      d: "{{ foo }}"
    """

    class TestConstructor(AnsibleConstructor):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)

    class TestLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name=file_name, vault_secrets=vault_secrets)

    def test_constructor(cls):
        obj

# Generated at 2022-06-23 05:39:54.952559
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os

    # Make sure we have a file to play with
    if not os.path.exists('/tmp/test'):
        with open('/tmp/test', 'w') as _file:
            _file.write('foo: [bar,baz]')

    # Test default constructor
    yaml = AnsibleLoader(open('/tmp/test'))
    assert 'foo' in yaml
    assert type(yaml['foo']) is list

    # Test that we preserve keys order
    yaml = AnsibleLoader(open('/tmp/test'))
    yaml['foo'].append('test')
    yaml['bar'] = 'test2'
    yaml.append('foo: {test3: test4}') # Should be added at the end

# Generated at 2022-06-23 05:39:57.775103
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # make sure we can at least instantiate it even with empty stream
    AnsibleLoader(stream='')

# Generated at 2022-06-23 05:40:04.320868
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    construct_yaml = u"""
!!python/object/new:ansible.parsing.yaml.objects.AnsibleUnicode
arguments: [u'test']
"""
    stream = BytesIO(construct_yaml.encode('utf-8'))
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == 'test'

# Generated at 2022-06-23 05:40:15.181110
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import unittest

    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    class TestAnsibleLoader(unittest.TestCase):

        def test_AnsibleConstructor(self):
            class TestAnsibleConstructor(AnsibleConstructor):
                def __init__(self):
                    self.state = 0

            test_constructor = TestAnsibleConstructor()
            test_constructor.construct_yaml_map('test_data')
            self.assertEqual(test_constructor.state, 1)


# Generated at 2022-06-23 05:40:24.805415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    data = '''
    a:
      - 1
      - 2
      - 3
      - b: 4
        c: 5
        d: 6
      - [7, 8, 9]
    '''

    def assert_AnsibleLoader(data, expected):
        # pylint: disable=protected-access
        assert expected == \
            AnsibleLoader(data, vault_secrets=dict()).get_single_data()
        assert isinstance(expected, list)

    assert_AnsibleLoader(data,
                         [{'a': [1, 2, 3, {'d': 6, 'c': 5, 'b': 4}, [7, 8, 9]]}])


# Generated at 2022-06-23 05:40:27.574621
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_string = '''---
        name: test
        u'{test}': 'test'
    '''

    loader = AnsibleLoader(test_string)

    # if we fail here, it means that we didn't get the right thing back
    assert loader.get_single_data()

# Generated at 2022-06-23 05:40:32.258964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = """
    ---
    - hosts: localhost
      connection: local
      gather_facts: False
      tasks:
        - name: AnsibleLoader test
          debug:
              msg: "This is a test"
    """
    assert isinstance(AnsibleLoader(string).get_single_data(), list)

# Generated at 2022-06-23 05:40:34.713079
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-23 05:40:44.072690
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib

    if HAS_LIBYAML:
        from ansible import constants as C
        from yaml.error import MarkedYAMLError
    else:
        from ansible.parsing.yaml.error import MarkedYAMLError

    class FakeVaultSecret(VaultLib):
        def decrypt(self, vaulttext):
            return 'secret'


# Generated at 2022-06-23 05:40:55.024866
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import sys
    import tempfile

    # for test_vault.py
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    yaml = """
    dirs:
        - /tmp/test
        - /tmp/test2
    """

    p = VaultLib([])
    data = p.decrypt(yaml)
    print(data)

    try:
        fd, path = tempfile.mkstemp()
        f = open(path, 'w')
        f.write(data)
        f.close()
        fd.close()

        f = open(path)
        a = AnsibleLoader(f)
        data = a.get_single_data()
        print(data)

    finally:
        os

# Generated at 2022-06-23 05:40:59.479977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''\
a: &A
  b: *A
'''
    loader = AnsibleLoader(s)
    data = loader.get_single_data()
    assert data['a']['b']['b']['b']['b']['b'] == data['a']

# Generated at 2022-06-23 05:41:05.321134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_data = """
    test_variable_1: 1
    test_variable_2: 2
    """
    loader = AnsibleLoader(yaml_data, 'non_existent_file.yml') # pylint: disable=too-many-function-args
    loader.get_single_data()

# Generated at 2022-06-23 05:41:06.365671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader('')

# Generated at 2022-06-23 05:41:15.918825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    class TestAnsibleConstructorBase(unittest.TestCase):
        file_name = 'example.yaml'
        data = '''
                 ---
                 !include_vars "/ansible/vars.yaml"
                 ...
                 ---
                 !include "/ansible/play.yaml"
                 ...
              '''
        def test_dummy(self):
            loader = AnsibleLoader(self.data, file_name=self.file_name)
            loader.get_single_data()
    unittest.main()

# Generated at 2022-06-23 05:41:25.909746
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import pytest
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    f = os.path.join(os.path.dirname(__file__), 'data', 'yaml_loader.yml')
    with open(f, 'rb') as stream:
        loader = AnsibleLoader(stream, vault_secrets=None)
        load = loader.get_single_data()
        assert load == {'a': 'foo', 'b': 'bar', 'c': 'baz'}
    stream.close()

    vault_secret = VaultLib([])
    vault_secret.secrets['vault_password'] = 'foo'

# Generated at 2022-06-23 05:41:26.926453
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:41:31.024138
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    stream = StringIO("# Hello World\n---\n- hosts: localhost\n")
    loader = AnsibleLoader(stream)
    assert loader is not None   # the simplest test we can do

# Generated at 2022-06-23 05:41:41.583624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    y = yaml.load('''
receivers:
- name: "logging_file"
  max_bytes: 10485760 # 10MB
  backup_count: 10
  level: DEBUG
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  class: logging.handlers.RotatingFileHandler
  args: ["/var/log/ansible/ansible-cmdb.log"]
- name: "logging_console"
  level: DEBUG
  format: "%(asctime)s - %(levelname)s - %(message)s"
  class: logging.StreamHandler
  args: ["sys.stderr"]
''', Loader=AnsibleLoader)

# Generated at 2022-06-23 05:41:44.549263
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream="Test")
    assert hasattr(loader, "compose_node")
    assert hasattr(loader, "construct_yaml_str")

# Generated at 2022-06-23 05:41:45.942596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Basic check
    assert isinstance(AnsibleLoader, type)

# Generated at 2022-06-23 05:41:56.857358
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class DummyStream:
        def read(self):
            return None

    # most simple test
    loader = AnsibleLoader(DummyStream())
    assert loader is not None

    # more complex test
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing import vault
    from ansible.parsing.dataloader import DataLoader