

# Generated at 2022-06-23 05:31:54.113536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass



# Generated at 2022-06-23 05:32:01.443313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    stream = '---\n' \
             '- hosts: localhost\n' \
             '  gather_facts: no\n' \
             '  tasks:\n' \
             '    - debug:\n' \
             '        msg: Name is {{ item.name }}\n' \
             '      with_items:\n' \
             '        - { name: "A" }\n' \
             '        - { name: "B" }\n'

    loader = AnsibleLoader(stream, vault_secrets=None)
    for i in range(4):
        print(next(loader.stream))

# Generated at 2022-06-23 05:32:02.725245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:32:14.233602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.plugin_docs import read_docstring

    # Create an empty AnsibleLoader. Its class parent and grandparent is AnsibleConstructor.
    c = type('AnsibleLoader', (AnsibleConstructor,), {})()

    # Create a fake module.
    #
    # Note that the fake module has no 'DOCUMENTATION' key, so the docstrings of
    # fake module will be empty.
    #
    # Note that the fake AnsibleLoader has no 'file_name' attribute, so the
    # 'file_name' argument of read_docstring will be None, and read_docstring will
    # return empty docstring.
    fake_module = type('fake_module', (object,), {})
    # If the AnsibleLoader is not empty, following line will produce an error.
   

# Generated at 2022-06-23 05:32:18.266099
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')


# Generated at 2022-06-23 05:32:29.672543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = '''
        foo:
            bar: 1
        baz:
            - 2
            - 3
            - 4
    '''

# Generated at 2022-06-23 05:32:41.027934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test that with enough time to execute:
    #   AnsibleLoader(stream).get_single_data()
    # doesn't raise an error.
    import marshal
    stream_dumped = marshal.dumps(("1233", "465", "2.3"))
    stream = open("test_AnsibleLoader_dump", "w")

# Generated at 2022-06-23 05:32:51.912247
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dict import dict_constructor
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping
    from ansible.vars import VariableManager

    class TestAnsibleLoader():
        def __init__(self, some_var):
            self.some_var = some_var

    # Test instantiation
    test_vault_secrets = {'key': 'value'}
    l = AnsibleLoader(None, vault_secrets=test_vault_secrets)
    assert l.file_name is None
    assert l.vault_secrets == test_vault_secrets
    assert isinstance(l.constructor, dict_constructor)

    # Test Ansible constructor

# Generated at 2022-06-23 05:33:02.216839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import warnings
    import shutil

    tempdir = tempfile.mkdtemp()
    test_file = os.path.join(tempdir, 'test.yml')

    with open(test_file, 'wb') as f:
        f.write(b'foo: bar')

    # Ensure that the exception is raised and it warns the user
    with warnings.catch_warnings(record=True) as w:
        _ = AnsibleLoader(open(test_file, 'rb'))
        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "exist, or you are running ansible from a directory " \
               "which contains a file named constructor.py" in str(w[-1].message)

    shutil.r

# Generated at 2022-06-23 05:33:08.364632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_data = '''
a:
  b:
    c: 1
    d: 2
'''
    loader = AnsibleLoader(yaml_data)
    loader.get_single_data()
    assert loader.file_name == '<unicode string>'
    assert loader.get_data() == {'a': {'b': {'c': 1, 'd': 2}}}

# Generated at 2022-06-23 05:33:17.182960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml


# Generated at 2022-06-23 05:33:28.116774
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test AnsibleLoader using a test yaml file
    """
    import os
    loader = AnsibleLoader(open(os.path.join(os.path.dirname(__file__), 'test_loader.yml'), 'r'))
    data = loader.get_single_data()


# Generated at 2022-06-23 05:33:30.312091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .yaml_loader_test import AnsibleLoaderTest
    AnsibleLoaderTest('loader')

# Generated at 2022-06-23 05:33:31.786281
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:33:34.589971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    for line in open(__file__):
        AnsibleLoader(line).get_single_data()

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-23 05:33:36.270077
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    reader = AnsibleLoader(file_name='test')
    reader.get_single_data()

# Generated at 2022-06-23 05:33:38.587829
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # FIXME: write this test
    pass

# Generated at 2022-06-23 05:33:42.254356
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader

    assert(hasattr(ansible.parsing.yaml.loader.AnsibleLoader, 'add_constructor'))


# Generated at 2022-06-23 05:33:53.250894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML

    assert DataLoader is not None

    script_file = os.path.join(os.path.dirname(__file__), '../../../test/data/run_once/test1.yml')
    with open(script_file) as f:
        src = f.read()

    print("testing dataloader, load a script file")
    loader = DataLoader()
    data = loader.load_from_file(script_file)

# Generated at 2022-06-23 05:33:57.122787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:34:10.469935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from io import BytesIO
    fp = BytesIO(b"foo: \"{{nonesuch}}\"")
    try:
        data = AnsibleLoader(fp, file_name='<test_AnsibleLoader>').get_single_data()
    except SystemExit as e:
        assert e.code == 1
    else:
        raise AssertionError('Expected a SystemExit exception')
    fp.close()
    fp = BytesIO(b"foo: \"{{foobar}}\"")

# Generated at 2022-06-23 05:34:11.557844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:34:20.577375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Simple test of YAML loading in AnsibleLoader."""
    from ansible.module_utils.common.yaml import HashableDict
    import yaml
    test_yaml = '''---
a: some
b: "{{ c | quote }}"
c: data
d:
  e: some
  f: "{{ c | quote }}"
  g: data
'''
    test_data = {
        'a': "some",
        'b': "{{ c | quote }}",
        'c': "data",
        'd': {
            'e': "some",
            'f': "{{ c | quote }}",
            'g': "data",
        }
    }

    # do we get HashableDict?

# Generated at 2022-06-23 05:34:26.049143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    source = '''---
- hosts: localhost
  gather_facts: false
  tasks:
    - name: some task
      debug:
        msg: Hello world'''

    loader = AnsibleLoader(source)
    objects = list(loader.get_single_data())

    assert len(objects) == 1
    assert objects[0]['hosts'] == 'localhost'

# Generated at 2022-06-23 05:34:34.102265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    simple_yaml = """
    - foo
    - bar
    - baz
    """

    stream = Parser(simple_yaml)
    stream.check_version((1, 2))
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), list)
    assert loader.get_single_data() == ['foo', 'bar', 'baz']
    assert isinstance(loader.get_single_data(), AnsibleUnicode)

# Generated at 2022-06-23 05:34:35.076064
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream=None)

# Generated at 2022-06-23 05:34:36.962458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = u'a: 1\n'
    d = AnsibleLoader(s).get_single_data()
    assert d['a'] == 1

# Generated at 2022-06-23 05:34:48.023308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    stream = '''
    null: !!vault |
          $ANSIBLE_VAULT;1.1;AES256
          31323334353637383930313233343536373839303132333435363738393031323334353637383930
          31323334353637383930313233343536373839303132333435363738393031323334353637383930
          31323334
          salt: ffffffffffffffffffffffff
          iterations: 10000
          hmac: ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    '''  # pylint: disable=trailing-whitespace

    vault_secrets = ['mysecret']
    loader = AnsibleLoader

# Generated at 2022-06-23 05:34:50.952706
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    yaml_str = "---\n- hosts: localhost\n  tasks:\n  - ping:\n"
    AnsibleLoader(io.StringIO(yaml_str))

# Generated at 2022-06-23 05:34:54.385907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        foo:
            bar: 1
        baz:
            - 1
            - 2
            - 3
    '''
    loader = AnsibleLoader(data)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:35:02.646219
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode

    # Empty YAML file
    data = b''
    l = AnsibleLoader(data)
    assert(l.get_single_data() is None)

    # YAML file with Scalar values
    # int value
    data = b'1'
    l = AnsibleLoader(data)
    assert(l.get_single_data() == 1)
    # long value
    data = b'999999999999999999999999999999999999999999999'
    l = AnsibleLoader(data)
    assert(l.get_single_data() == 999999999999999999999999999999999999999999999)
    # string

# Generated at 2022-06-23 05:35:06.259091
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects

    stream = open("/tmp/foo.yaml", "r")
    loader = AnsibleLoader(stream)

    assert isinstance(loader, objects.AnsibleLoader)

# Generated at 2022-06-23 05:35:07.313108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('doc', file_name='file_name', vault_secrets=None)

# Generated at 2022-06-23 05:35:17.257861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import StringIO
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    data = '''
---
- abcd
- qwerty
-
  - 1234
  - 5678
  -
    - hello
    - world
'''
    assert isinstance(AnsibleLoader(StringIO.StringIO(data)).get_single_data(), AnsibleSequence)

    data = '''
---
foo: abcd
bar: qwerty
baz:
  - 1234
  - 5678
  -
    - hello
    - world
'''
    assert isinstance(AnsibleLoader(StringIO.StringIO(data)).get_single_data(), AnsibleMapping)

# Generated at 2022-06-23 05:35:30.111304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Pass some yaml code to load
    code = """
- test:
  - {test_var: 'Test'}
  - test_var: 'Test'
  - test_var: [Test, Test]
    test_var: 'Test'
"""
    # Save the result to a variable
    result = AnsibleLoader(code).get_single_data()

    # Make sure it's not empty
    assert (result)

    # Make sure it's correct
    assert (result[0]["test"][0] == {'test_var': 'Test'})
    assert (result[0]["test"][1] == {'test_var': 'Test'})
    assert (result[0]["test"][2] == {'test_var': ['Test', 'Test'], 'test_var': 'Test'})

# Generated at 2022-06-23 05:35:40.232088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import unittest
    import tempfile

    # Prefer libyaml.
    if HAS_LIBYAML:
        from ansible.parsing.yaml.loader import AnsibleLoader
    else:
        from ansible.parsing.yaml.loader import AnsibleLoader

    class TestClass(object):
        def test(self, file_name, vault_secrets=None):
            stream = open(file_name, 'r')

            if sys.version_info[0] >= 3:
                stream = open(file_name, 'r', encoding='utf-8')

            AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
            stream.close()


# Generated at 2022-06-23 05:35:40.843010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:35:48.826722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    file_name = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    try:
        file_name.write('{"a": "b"}')
        file_name.close()
        loader = AnsibleLoader(open(file_name.name, 'r'), file_name=file_name.name)
        data = loader.get_single_data()
        assert data == {"a": "b"}
    finally:
        os.unlink(file_name.name)

# Generated at 2022-06-23 05:35:49.818642
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:35:57.381618
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # https://github.com/ansible/ansible/pull/32996
    # roles:
    #   - test/{{role.name}}

    # Start to use AnsibleLoader to load yaml file
    vault_pass = VaultLib.generate_random_password()
    vault = VaultLib(vault_pass)

# Generated at 2022-06-23 05:36:01.555741
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('foobar')
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:36:08.519619
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import string
    import random

    for i in range(1000):
        line_nums = random.randint(1, 1000)
        line_len = random.randint(1, 100)
        lines = []
        for j in range(line_nums):
            lines.append(''.join([random.choice(string.printable) for _ in range(line_len)]))
        stream = io.StringIO('\n'.join(lines))
        loader = AnsibleLoader(stream)
        for j, line in enumerate(lines):
            assert loader.line_nums[j] == len(line)

# Generated at 2022-06-23 05:36:12.291341
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = u'[1, 2, 3]'
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    assert data == [1, 2, 3]

# Generated at 2022-06-23 05:36:23.146167
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader takes a stream (some form of iterable of lines) and a file name.
    # This is the only way to instantiate it, so no actual default values are available.
    # We want to test the parameter defaults and it is not possible to do so because
    # parameter defaults don't exist.
    test_stream = "stuff"
    test_file_name = "asdf"

    test_loader = AnsibleLoader(test_stream, test_file_name)

    assert test_loader.stream == test_stream
    assert test_loader.file_name == test_file_name
    assert test_loader.vault_secrets is None
    assert test_loader.vault_secrets_cache is None


#Unit test for method safe_load of class AnsibleLoader

# Generated at 2022-06-23 05:36:27.177417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Needed to make AnsibleLoader call load_all with the proper stream
    def empty_gen():
        return

    AnsibleLoader(empty_gen())

    # Needed to make AnsibleLoader call __init__ with the proper arguments
    AnsibleLoader(empty_gen(), file_name="foo")

# Generated at 2022-06-23 05:36:28.636722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    results = AnsibleLoader('')
    assert isinstance(results, AnsibleLoader)

# Generated at 2022-06-23 05:36:36.865384
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.vars.vault import VaultLib

    t = AnsibleLoader(None, vault_secrets=[VaultLib(b'123')], file_name='/foo/bar')
    assert isinstance(t.get_single_data(), AnsibleBaseYAMLObject)
    assert isinstance(t.get_single_data()._seq, AnsibleSequence)
    assert isinstance(t.get_single_data()._mapping, AnsibleMapping)
    assert t.get_single_data()._file_name == '/foo/bar'
    #

# Generated at 2022-06-23 05:36:41.130644
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    stream = '''
---
foo:
    - bar
    - baz
...
'''
    data = yaml.load(stream, Loader=AnsibleLoader)
    assert data == {'foo': ['bar', 'baz']}

# Generated at 2022-06-23 05:36:50.201863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    class ConstructorLoader(DataLoader):
        ''' materializes an object from a datastream from _load_data '''

        def _construct_mapping(self, node):
            ''' materializes the node for a mapping object '''
            loader = self._safe_constructor
            mapping = loader.construct_yaml_map(node)
            return loader.construct_mapping(node, deep=True)

        def _load_data(self, file_name, unsafe=False):
            ''' load the data file (YAML or JSON) and return the data object '''
            # FIXME: This code should be able to be shared with the parent class
            # for loading data files.
            # TODO: it could be a method of a base class DataLoader,


# Generated at 2022-06-23 05:36:59.064129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    constructor = AnsibleConstructor
    assert constructor

    def simple_test():
        """ this tests a simple example that loads a list of synonyms with
        a class defined inline, in the same yaml document.
        """

        # this is the yaml that is being loaded

# Generated at 2022-06-23 05:37:06.177184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test :class:`AnsibleLoader`
    '''
    # Test AnsibleLoader constructor
    try:
        AnsibleLoader(file_name="/dev/null")
    except TypeError:
        # test if AnsibleLoader accept file_name argument
        assert False, "Test if AnsibleLoader accept file_name argument failed"
    loader = AnsibleLoader("")
    assert isinstance(loader, AnsibleLoader), "Test AnsibleLoader constructor failed"

# Generated at 2022-06-23 05:37:15.101599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''\
---
- name: test
  hosts: localhost
  gather_facts: no
  tasks:
  - debug:
      msg: This is a message
'''

    with open('test.yml', 'w') as f:
        f.write(data)
    assert AnsibleLoader(data).get_single_data() == {'name': 'test', 'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [{'debug': {'msg': 'This is a message'}}]}


# Generated at 2022-06-23 05:37:18.447206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    module = AnsibleLoader(None)
    assert hasattr(module, '_construct_yaml_int')
    assert hasattr(module, '_construct_yaml_float')
    assert hasattr(module, '_construct_yaml_omap')

# Generated at 2022-06-23 05:37:29.905820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    vault = VaultLib([])

# Generated at 2022-06-23 05:37:32.549682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    data = StringIO('[foo]\nbar: baz')

    loader = AnsibleLoader(data)
    loader.get_single_data()

# Generated at 2022-06-23 05:37:38.311550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # make sure that it parses to a dict
    data = """
    foo: bar
    baz: bam
    """

    ds = AnsibleLoader(data, 'test.yml', None).get_single_data()
    assert ds.get('foo') == 'bar'
    assert ds.get('baz') == 'bam'

# Generated at 2022-06-23 05:37:41.525545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import __main__
    loader = AnsibleLoader(stream='---\n- hosts: all\n  gather_facts: false')
    assert loader.__module__ == __main__.__module__

# Generated at 2022-06-23 05:37:49.758809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib

    class DictWithError(dict):
        def __getitem__(self, key):
            raise RuntimeError('boom')

    class VaultSecret:
        def __init__(self, secret):
            self.vault_secrets = {'_AnsibleVaultSecret': secret}

    # initial values which are not used in this test
    stream = []
    file_name = 'test.yml'
    vault_secrets = []

    # test vault secret string
    vault_secrets = VaultSecret('test')


# Generated at 2022-06-23 05:38:00.634014
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = """
- hosts: localhost
  gather_facts: no
  tasks:
    - debug: msg="System {{ ansible_system }}"
    - debug: msg="Distribution {{ ansible_distribution }}"
    - debug: msg="Distribution Version {{ ansible_distribution_version }}"
    - debug: msg="Distribution Release {{ ansible_distribution_release }}"
    - debug: msg="Product Name {{ ansible_product_name }}"
    - debug: msg="Product Version {{ ansible_product_version }}"
"""
    stream = yaml_string.replace('%', '%%')
    stream = yaml.AnsibleLoader(stream)
    results = list(stream)

# Generated at 2022-06-23 05:38:12.860259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml
    data = yaml.load('''{
        "blah": [1, 2],
        "foo": {
            "bar": "asdf",
        }
    }''', Loader=AnsibleLoader)
    assert isinstance(data.get('blah'), AnsibleSequence)
    assert isinstance(data.get('foo'), AnsibleMapping)
    assert isinstance(data.get('foo').get('bar'), AnsibleUnicode)


# Generated at 2022-06-23 05:38:19.952565
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name = "test_file", vault_secrets = "test_secrets")
    assert loader.file_name == "test_file"
    assert loader.vault_secrets == "test_secrets"
    if HAS_LIBYAML:
        assert loader.line == 1
        assert loader.column == 0
        assert loader.name == "!python/object:ansible.parsing.yaml.constructor.AnsibleLoader"
    else:
        assert loader.index == 0
        assert loader.line == 0
        assert loader.name == "!python/object/apply:ansible.parsing.yaml.constructor.AnsibleLoader"

# Generated at 2022-06-23 05:38:27.103878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # set up fake data
    class Options:
        _ansible_vault_password_file = None
        def __init__(self):
            self._ansible_vault_password_file = list()

    options = Options()
    options._ansible_vault_password_file.append("bar")

    loader = AnsibleLoader("data", vault_secrets=options._ansible_vault_password_file)

    assert loader.data == "data"

# Generated at 2022-06-23 05:38:36.452056
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:38:40.244850
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    input_yaml = '''---
- hosts: localhost
  vars:
    foo: 'yes'
  tasks:
    - debug: msg="hello"
      tags: test
    - fail:
        when: foo == 'yes'
        ignore_errors: yes
        tags: never

- hosts: localhost
  tasks:
    - debug: msg="hello"
      tags: test
    - fail:
        when: foo == 'yes'
        ignore_errors: yes
        tags: never
'''
    filename = 'test/test_playbook.yaml'
    loader = AnsibleLoader(input_yaml, file_name=filename)
    data = loader.get_single_data()
    assert len(data) == 2

# Generated at 2022-06-23 05:38:42.532232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    loader = AnsibleLoader([], None)
    assert(loader is not None)

# Generated at 2022-06-23 05:38:43.980118
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:38:44.846289
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader("stream")

# Generated at 2022-06-23 05:38:49.052701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_nmae = "test"
    arr = []
    loader = AnsibleLoader(stream, file_name=file_nmae, vault_secrets=arr)
    assert loader.file_name == file_nmae
    assert loader.vault_secrets == arr

# Generated at 2022-06-23 05:38:58.233310
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestLoader(AnsibleLoader):
        def __init__(self, stream=None, file_name='TestFileName', vault_secrets=None):
            self.stream = stream
            self.file_name = file_name
            self.vault_secrets = vault_secrets


# Generated at 2022-06-23 05:39:05.747473
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader('')
    assert loader.construct_scalar('tag:yaml.org,2002:str', 'foo') == 'foo'
    assert loader.construct_scalar('!vault', None) is None
    assert type(loader.construct_scalar('!vault', 'foo')) == AnsibleVaultEncryptedUnicode
    assert loader.construct_scalar('!vault', '$ANSIBLE_VAULT;1.1;AES256;somesalt\nfoo') == 'foo'
    assert loader.construct_scalar('!vault', '$ANSIBLE_VAULT;1.1;AES256;somesalt\nbar') == 'bar'

# Generated at 2022-06-23 05:39:07.107534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-23 05:39:11.075683
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    # make sure we can create an instance of this class without an error
    test_loader = DataLoader()
    assert(test_loader is not None)


# Generated at 2022-06-23 05:39:15.005932
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    data = b"foobar\n"
    stream = BytesIO(data)
    loader = AnsibleLoader(stream, vault_secrets=[])
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:39:20.020904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Check that AnsibleLoader was initialized properly
    loader = AnsibleLoader(None)
    assert loader.yaml_constructors == AnsibleConstructor.yaml_constructors
    # pylint: disable=protected-access
    assert loader._yaml_base_loader_class == Parser
    assert loader.flow_style is False

# Generated at 2022-06-23 05:39:28.639226
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import YAMLLoaderException

    data = {False: 'a', True: 'b'}
    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    if data[False] != 'a':
        raise YAMLLoaderException('%s, expected True' % data[False])
    if data[True] != 'b':
        raise YAMLLoaderException('%s, expected True' % data[True])

# Generated at 2022-06-23 05:39:32.515708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Class AnsibleLoader initialized with no arguments generates error."""
    try:
        loader = AnsibleLoader()
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-23 05:39:33.959577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.load("hello", Loader=AnsibleLoader)

# Generated at 2022-06-23 05:39:36.298685
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader([], file_name='should_be_ignored')
    assert loader.get_single_data() == {}

# Generated at 2022-06-23 05:39:44.172158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = """
    ---
    #
    {
      'someKey': 'someValue',
      'anotherKey': 'anotherValue'
    }
    #

    ---
    {
      'someKey': 'someValue',
      'anotherKey': 'anotherValue'
    }
    ---
    "someValue"
    """
    a_loader = AnsibleLoader(data)
    a_loader.get_single_data()
    b_loader = yaml.Loader(data)
    b_loader.get_single_data()
    assert a_loader == b_loader

# Generated at 2022-06-23 05:39:56.086795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible_loader import AnsibleLoader
    from yaml import load
    import os
    import tempfile
    import shutil
    import stat

    datadir = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'parsing', 'yaml', 'data')
    #print datadir
    vars_files = ['all.yml', 'group_vars/all.yml', 'host_vars/one.yml', 'host_vars/two.yml']
    host1 = 'one.example.org'
    host2 = 'two.example.org'
    group_vars = {}
    host_vars = {}
    for vars_file in vars_files:
        path = os.path

# Generated at 2022-06-23 05:39:59.094484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    constructor = AnsibleLoader(None, file_name='test_file')
    assert constructor.file_name == 'test_file'

# Generated at 2022-06-23 05:40:09.247852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
---
- hosts:
    - localhost
  tasks:
    - name: test
      debug:
        msg: "test"
'''
    loader = AnsibleLoader(yaml_str, '<test>')
    doc = loader.get_single_data()
    assert doc != None
    assert doc[0]['hosts'][0] == 'localhost'
    assert doc[0]['tasks'][0]['name'] == 'test'

# Generated at 2022-06-23 05:40:12.358658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert(isinstance(AnsibleLoader(None), AnsibleLoader))

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:40:15.552147
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO(u"---\n- hosts: localhost", newline=None)
    loader = AnsibleLoader(stream)
    loader.get_data()


# Generated at 2022-06-23 05:40:21.254421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import inspect

    # Check that all classes are in the method resolution order of AnsibleLoader
    mro = inspect.getmro(AnsibleLoader)
    assert mro[0] == AnsibleLoader
    if HAS_LIBYAML:
        assert mro[1:] == [Parser, AnsibleConstructor, Resolver, object]
    else:
        assert mro[1:] == [Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver, object]

# Generated at 2022-06-23 05:40:29.598184
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    yml_file = os.path.join(os.path.dirname(__file__), 'test-loader.yml')
    with open(yml_file, 'r') as stream:
        loader = AnsibleLoader(stream)
        data = loader.get_single_data()
        assert data is not None

    non_yml_file = os.path.join(os.path.dirname(__file__), '__init__.py')
    fail_loader = AnsibleLoader(non_yml_file)
    assert fail_loader is None

# Generated at 2022-06-23 05:40:35.158506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = u"""
---
# This is a comment.
- name: Example task 1
  hosts: all
  become: yes
  become_method: sudo
  become_user: root
  connection: ssh
  gather_facts: no
  tasks:
  - name: Example task 1.1
    command: /bin/true
  tasks:
  - name: Example task 1.2
    command: /bin/true
  - name: Example task 2
    command: /bin/true
- name: Example task 3
  command: /bin/true
"""
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:40:37.121821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader(None, None)
    assert isinstance(al, AnsibleConstructor)

# Generated at 2022-06-23 05:40:38.543752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader
    assert ansible_loader

# Generated at 2022-06-23 05:40:39.963216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader.__name__ == 'AnsibleLoader'

# Generated at 2022-06-23 05:40:52.765457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    global HAS_LIBYAML

    if not HAS_LIBYAML:
        # SKIP: PyYaml installed library is older than 3.10.
        return
    else:
        HAS_LIBYAML = False

        import yaml

        try:
            yaml.CLoader
        except AttributeError:
            # SKIP: PyYaml installed library is older than 3.10.
            return

    def test_AnsibleLoader_methods():
        # Just check if all methods are avilable
        loader = AnsibleLoader(open('../../lib/ansible/playbooks/playbook_template.yml'))
        loader.get_single_data()
        loader.get_data()

    test_AnsibleLoader_methods()

# Generated at 2022-06-23 05:41:03.212251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import time
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    def get_object(stream):
        loader = AnsibleLoader(stream)
        return loader.get_single_data()

    assert get_object("foo") == "foo"
    assert get_object(123) == 123
    assert get_object([1, 2, 3]) == [1, 2, 3]
    assert get_object(dict(a=1, b=2, c=3)) == dict(a=1, b=2, c=3)

# Generated at 2022-06-23 05:41:11.696570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    # Test for VaultSecrets with vault_secrets

# Generated at 2022-06-23 05:41:14.474555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Test the AnsibleLoader

    This method tests the AnsibleLoader's constructor
    """
    a = AnsibleLoader("alice")
    assert a is not None

# Generated at 2022-06-23 05:41:24.167234
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.vault import VaultLib
    vault_secrets = [VaultLib(1, 1)]

    data = AnsibleLoader(None, vault_secrets=vault_secrets).get_single_data()
    assert isinstance(data, AnsibleMapping), data

    data = AnsibleLoader("---\nfoo: bar\n", vault_secrets=vault_secrets).get_single_data()
    assert isinstance(data, AnsibleMapping), data
    assert data["foo"] == "bar", data

    data = AnsibleLoader("\n- foo\n- bar\n", vault_secrets=vault_secrets).get_single_data()

# Generated at 2022-06-23 05:41:24.677752
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:25.709971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert False, "Unit test not implemented"

# Generated at 2022-06-23 05:41:26.687887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('')

# Generated at 2022-06-23 05:41:36.078770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    with open(__file__) as f:
        code = f.read()
    loader = AnsibleLoader(code, file_name="<test>")
    data = loader.get_single_data()

    assert isinstance(data, AnsibleBaseYAMLObject)
    assert data._line_number == 3
    assert data._column_number == 0
    assert data._line_offset == 0
    assert data.fa == 1
    assert data.fb == 2
    assert data.fc == 3
    assert data['fa'] == 1
    assert data['fb'] == 2
    assert data['fc'] == 3

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:41:43.947694
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = '''---
    date: 2012-12-20
    hosts: all
    tasks:
      - name: test
        ping:
    '''

    loader = AnsibleLoader(yaml_string)

    yaml_data = loader.get_single_data()

    assert yaml_data.get('date') == '2012-12-20'
    assert yaml_data.get('hosts') == 'all'
    assert yaml_data.get('tasks')[0].get('ping') is None

# Generated at 2022-06-23 05:41:44.952284
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader.__init__

# Generated at 2022-06-23 05:41:53.376061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib as VaultSecret
    from binascii import hexlify, unhexlify
    from ansible.parsing.vault import VaultEditor

    # Test the default behavior.
    # Raw Vault should be outputted and the file name should be from the stream.

# Generated at 2022-06-23 05:41:57.871703
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    with open('../../ansible/playbooks/test_playbook.yaml', 'r') as stream:
        obj = yaml.load(stream, Loader=AnsibleLoader)
        assert obj != None