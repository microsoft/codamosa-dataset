

# Generated at 2022-06-23 05:31:55.210794
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    y = AnsibleLoader(yaml.load)

# Generated at 2022-06-23 05:32:00.938072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# vim: set fileencoding=utf-8

# Generated at 2022-06-23 05:32:04.015795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:32:06.279369
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_data = AnsibleLoader(None, file_name='test').get_single_data()
    assert my_data.namespace == 'file'
    assert my_data.data == 'test'

# Generated at 2022-06-23 05:32:16.793798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types

    # Create AnsibleLoader object
    ansible_loader = AnsibleLoader(None)

    # Test that the AnsibleLoader object has all the expected attributes
    assert hasattr(ansible_loader, 'get_single_data')
    assert hasattr(ansible_loader, '_new_yaml_object')
    assert hasattr(ansible_loader, 'construct_yaml_map')
    assert hasattr(ansible_loader, 'construct_yaml_seq')
    assert hasattr(ansible_loader, 'construct_undefined')
    assert hasattr(ansible_loader, 'construct_yaml_str')
    assert hasattr(ansible_loader, 'construct_yaml_int')
    assert hasattr(ansible_loader, 'construct_yaml_float')

# Generated at 2022-06-23 05:32:20.606012
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, '/foo')
    assert loader.file_name == '/foo'

    loader = AnsibleLoader(None, vault_secrets='vault_secrets')
    assert loader.vault_secrets == 'vault_secrets'


# Generated at 2022-06-23 05:32:22.337416
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, (Parser, AnsibleConstructor, Resolver))

# Generated at 2022-06-23 05:32:31.568452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    # We need to add the current working dir to the Python path,
    # as we are running this test programmatically.
    # Determine the current working dir and add to the path if needed.
    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.append(cwd)

    # Create dummy stream
    stream = """
- name: test
  hosts: all

  tasks:
    - name: task1
      ping:
"""

    # Create an instance of AnsibleLoader and load the stream
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    # Test loaded data
    assert 'name' in data
    assert data['name'] == 'test'
    assert 'hosts' in data

# Generated at 2022-06-23 05:32:38.750885
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        # AnsibleLoader(stream, file_name=None, vault_secrets=None)
        AnsibleLoader('stream', file_name='file_name', vault_secrets='vault_secrets')
    else:
        # AnsibleLoader(stream, file_name=None, vault_secrets=None)
        AnsibleLoader('stream', file_name='file_name', vault_secrets='vault_secrets')

# Generated at 2022-06-23 05:32:46.007314
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import sys
    import os

    class Dummy(object):
        pass

    obj = Dummy()
    obj.stream = sys.stdin
    obj.file_name = os.path.basename('test_name')
    obj.vault_secrets = None
    obj.Reader = Reader
    obj.Scanner = Scanner
    obj.Parser = AnsibleConstructor
    obj.Composer = Composer
    obj.Resolver = Resolver
    AnsibleLoader(obj)

# Generated at 2022-06-23 05:32:51.544791
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(None, None, vault_secrets=[b'thesecretthesecretthesecretthesecret'])
    loader.constructed_objects = {}
    assert isinstance(loader.constructed_objects[AnsibleVaultEncryptedUnicode], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:32:57.475583
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # A AnsibleLoader object should be instantiable
    class DummyFile(object):
        def read(self):
            return ''

    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = AnsibleLoader(DummyFile())
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.construct_yaml_str('test'), AnsibleUnicode)

# Generated at 2022-06-23 05:32:58.964591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    testcase = ""
    AnsibleLoader(testcase)

# Generated at 2022-06-23 05:33:10.255761
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncrypted
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # array, string
    loader = AnsibleLoader(u"[foo, bar]")
    # An instance of class AnsibleLoader has methods "get_single_data"
    # and "get_multi_data", while class Loader has only "get_single_data".
    x = loader.get_single_data()
    assert isinstance(x, AnsibleSequence)
    assert x.ansible_type == 'list'
    assert len(x) == 2
    for item in x:
        assert isinstance(item, AnsibleUnicode)
        assert item.ansible_

# Generated at 2022-06-23 05:33:19.045478
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from cStringIO import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    # build string to load with AnsibleLoader
    test_loader_string = StringIO(u"\n".join([
        u"---",
        u"- name: first item",
        u"- name: second item",
        u"  when: second condition",
    ]))

    # load the string
    test_loader_string.seek(0)
    test_loader_data = list(AnsibleLoader(test_loader_string).get_single_data())

    # test the loaded data

# Generated at 2022-06-23 05:33:25.393847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys

    if sys.version_info < (2, 7):
        sys.exit("Python 2.6 is not supported")

    loader = AnsibleLoader(io.BytesIO(b"test: 2"), vault_secrets='default')
    data = loader.get_data()
    assert data == {u'test': 2}

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:33:36.277082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-23 05:33:44.926169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    REGTEST_DATA = '{"'

    with open('/tmp/test_loader.json', 'w') as test_file:
        test_file.write(REGTEST_DATA)

    with open('/tmp/test_loader.json') as stream:
        ansible_loader = AnsibleLoader(stream)

    assert ansible_loader.get_single_data() == \
        {"": {"": ""}}

    # tear down
    import os
    os.remove('/tmp/test_loader.json')

# Generated at 2022-06-23 05:33:55.002934
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vars import VarsModule
    from ansible.utils.vars import combine_vars, merge_hash

    ####
    # Test 1: Construct class object with empty vault secrets
    ####

    # Create a stream for the AnsibleLoader object
    stream = 'a=1'
    vault_secrets = {}

    # Create a file name to set
    file_name = './test_name'

    # Create an AnsibleLoader object
    a_loader = AnsibleLoader(stream, file_name, vault_secrets)

    # Test the correctness of instance variable "file_name" of AnsibleLoader
    assert a_loader.file_name == file_name

    # Test the correctness of instance variable "vault_secrets" of

# Generated at 2022-06-23 05:33:57.537924
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name='file_name', vault_secrets='vault_secrets')

# Generated at 2022-06-23 05:34:07.391191
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    data = """
    foo:
    - bar
    - baz
    """

    loader = AnsibleLoader(data)
    foo = loader.get_single_data()

    assert isinstance(foo, AnsibleMapping)
    assert len(foo.items()) == 1
    assert foo['foo'] == AnsibleSequence(loader=loader, data=['bar', 'baz'])

# Generated at 2022-06-23 05:34:08.600507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, vault_secrets=None)
    assert loader

# Generated at 2022-06-23 05:34:19.562817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml = yaml
    stream = yaml.load("""
    ---
    - hosts:
      - localhost
      remote_user: root
      become: yes
    tasks:
      - name: test
        debug:
          msg: 'Hello World!'
    """)
    assert stream is not None
    assert isinstance(stream, list)
    assert len(stream) == 1
    assert isinstance(stream[0], dict)
    assert 'hosts' in stream[0]
    assert 'remote_user' in stream[0]
    assert 'become' in stream[0]
    assert 'tasks' in stream[0]
    assert isinstance(stream[0]['hosts'], list)
    assert len(stream[0]['hosts']) == 1

# Generated at 2022-06-23 05:34:26.699431
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_str = "---\n" + \
               "- hosts: localhost\n" + \
               "  tasks:\n" + \
               "    - debug: msg='hello world'\n" + \
               "...\n"

    obj = AnsibleLoader(yaml_str)
    data = obj.get_single_data()
    assert data[0]['hosts'] == 'localhost'
    assert data[0]['tasks'] == [
        {'debug': {'msg': 'hello world'}},
    ]

# Generated at 2022-06-23 05:34:29.524769
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Testing is not possible because - super(...) should be called.
    obj = AnsibleLoader(None)

# Generated at 2022-06-23 05:34:33.784902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Check result returned by constructor of class AnsibleLoader
    """
    # Create an object of class AnsibleLoader
    ansible_loader = AnsibleLoader(None, '/home/vagrant/ansible_playbooks/playbooks/test.yml', None)

    # Check type of the object
    assert isinstance(ansible_loader, AnsibleLoader)

# Generated at 2022-06-23 05:34:43.506791
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def _construct_yaml_str(self, node):
        """ Override the default string handling function
            to always return unicode objects """
        return self.construct_scalar(node)

    AnsibleLoader.add_constructor(u'tag:yaml.org,2002:str', _construct_yaml_str)
    AnsibleLoader.add_constructor(u'tag:yaml.org,2002:python/str', _construct_yaml_str)

    loader = AnsibleLoader(file_name='hacking/test_yaml_loader')
    data = loader.get_single_data()
    assert data['k1'] == 'v1'

# Generated at 2022-06-23 05:34:48.094054
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types

    assert issubclass(AnsibleLoader, types.ObjectType)
    assert AnsibleLoader.__module__ == 'ansible.parsing.yaml.loader'
    assert AnsibleLoader.__doc__ == 'Custom AnsibleLoader for YAML.'

# Generated at 2022-06-23 05:34:49.465107
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert AnsibleConstructor
    assert Resolver

# Generated at 2022-06-23 05:34:56.527513
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    import unittest

    loader = unittest.TestLoader()
    this_dir = os.path.dirname(__file__)
    test_case_dir = os.path.join(this_dir, '../module_utils/common/yaml')
    test_suite = loader.discover(test_case_dir, pattern='test_AnsibleLoader.py')
    runner = unittest.TextTestRunner()
    sys.exit(not runner.run(test_suite).wasSuccessful())

# Generated at 2022-06-23 05:35:05.269884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader

    def _fake_empty_vault_secrets():
        vault = VaultLib([])
        return [vault.secrets]

    loader = DataLoader()
    tags = {'!vault': 'ansible.parsing.vault.VaultLib'}
    loader.set_vault_secrets(['fake_secret'], tags, _fake_empty_vault_secrets)
    loader.set_vault_password('fake_password')

    # testing a simple file with no vault

# Generated at 2022-06-23 05:35:06.801427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Write unit test for constructor of class AnsibleLoader
    pass

# Generated at 2022-06-23 05:35:11.343707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "a: b\nc:\n  - d\n  - e"
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'a': 'b', 'c': ['d', 'e']}


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 05:35:20.847902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yamlLoader = AnsibleLoader
    assert(yamlLoader.__name__ == 'AnsibleLoader')
    assert(yamlLoader.__bases__[0].__name__ == 'Reader')
    assert(yamlLoader.__bases__[1].__name__ == 'Scanner')
    assert(yamlLoader.__bases__[2].__name__ == 'Parser')
    assert(yamlLoader.__bases__[3].__name__ == 'Composer')
    assert(yamlLoader.__bases__[4].__name__ == 'AnsibleConstructor')
    assert(yamlLoader.__bases__[5].__name__ == 'Resolver')


# Generated at 2022-06-23 05:35:32.466449
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = '''
    # children
    children:
      - name: Alica
        age: 5
      - name: Bob
        age: 7
    # children2
    children2:
    - name: Alica
      age: 5
    - name: Bob
      age: 7
    # children3-4
    children3:
     - name: Alica
       age: 5
     - name: Bob
       age: 7

    children4:
    - { name: Alica, age: 5 }
    - { name: Bob, age: 7 }
    '''

# Generated at 2022-06-23 05:35:40.675759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
        - hosts: localhost

          tasks:
            - name: ping
              ping:

    """
    ansible_loader = AnsibleLoader(data)
    print (ansible_loader)
    assert ansible_loader.construct_yaml_map() == {'hosts': 'localhost', 'tasks': [{'name': 'ping', 'ping': None}]}

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:41.842552
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:35:43.375781
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO

    AnsibleLoader(BytesIO())

# Generated at 2022-06-23 05:35:53.845656
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.construtor import AnsibleConstructor
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser
    from yaml.composer import Composer
    from yaml.resolver import Resolver
    yaml.load(None, Loader=AnsibleLoader)
    assert issubclass(AnsibleLoader, Reader)
    assert issubclass(AnsibleLoader, Scanner)
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, Composer)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-23 05:36:03.986560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    import shutil

    # Create temp directory
    temp_dir = tempfile.mkdtemp()

    # Create test files

# Generated at 2022-06-23 05:36:13.593109
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Load empty yaml document
    data = AnsibleLoader('').get_single_data()
    assert data is None, data

    # Load file with a single empty yaml document
    (stream, file_name) = open_file('empty.yaml')
    data = AnsibleLoader(stream, file_name).get_single_data()
    assert data is None, data

    # Load file with a two empty yaml document
    (stream, file_name) = open_file('two_empty.yaml')
    data = AnsibleLoader(stream, file_name).get_single_data()
    assert data is None, data

    # Load file with one integer yaml document
    (stream, file_name) = open_file('one_integer.yaml')
    data = AnsibleLoader(stream, file_name).get_

# Generated at 2022-06-23 05:36:17.296223
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert hasattr(loader,'construct_object')

# Import AnsibleLoader class for backwards compatibility
AnsibleLoader = AnsibleLoader

# Generated at 2022-06-23 05:36:20.136637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    loader = AnsibleLoader(file_name=None, vault_secrets=[])

# Generated at 2022-06-23 05:36:20.720386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:31.047269
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from ansible.module_utils._text import to_bytes

    # test for yaml.constructor.Constructor.__init__
    with mock.patch.object(AnsibleConstructor, '__init__') as mock_constructor_init:
        loader = AnsibleLoader(object())
        assert mock_constructor_init.call_count == 1

    if HAS_LIBYAML:
        # test for yaml.constructor.Constructor.__init__
        with mock.patch.object(AnsibleConstructor, '__init__') as mock_constructor_init:
            loader = AnsibleLoader(object())
            assert mock_constructor_init.call_count == 1
        # test for yaml.loader.Loader.__

# Generated at 2022-06-23 05:36:42.071846
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.composer import Composer
    from yaml.reader import Reader
    from yaml.scanner import Scanner
    from yaml.parser import Parser

    with open('/Users/Chao/Desktop/t.yaml', 'a+') as yaml_file:
        yaml_file.write('a: 1\nb: 1')
    with open('/Users/Chao/Desktop/t.yaml', 'r') as yaml_file:
        stream = yaml_file.read()
    loader = AnsibleLoader(stream)
    assert isinstance(loader, Reader), 'The super class of AnsibleLoader is Reader'
    assert isinstance(loader, Scanner), 'The super class of AnsibleLoader is Scanner'

# Generated at 2022-06-23 05:36:43.450254
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert not hasattr(AnsibleLoader, 'check_data')

# Generated at 2022-06-23 05:36:45.513221
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader is not None

# Generated at 2022-06-23 05:36:55.969553
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence

# Generated at 2022-06-23 05:36:56.705341
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:57.391540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:58.448625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:36:58.985729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:09.456943
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # for py2.6, py2.7, 3.2, 3.3, 3.4
    import sys
    try:
        from types import InstanceType
        assert InstanceType
    except ImportError:
        # for py3.5, 3.6
        from _types import InstanceType
        assert InstanceType

    from ansible.parsing.yaml.loader import AnsibleLoader
    from sys import version_info

    if version_info.major == 2:
        iversion = 2
    else:
        iversion = 3

    ansible_loader = AnsibleLoader('{"a": 1, "b": 2}', vault_secrets=None)
    assert isinstance(ansible_loader, InstanceType)
    assert ansible_loader.constructor_args == (None, None)

    ans

# Generated at 2022-06-23 05:37:16.521834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    a = AnsibleLoader(bytes())
    assert isinstance(a.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(a.construct_yaml_seq(None), list)
    assert isinstance(a.construct_yaml_map(None), dict)
    assert isinstance(a.construct_undefined(None), AnsibleUnicode)

# Generated at 2022-06-23 05:37:20.240952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    ansible.parsing.yaml.loader.AnsibleLoader
    """
    obj = AnsibleLoader(stream=None)
    assert obj

    # TODO: Currently there is no way to test this class.  It needs to be
    #       generalized in the future.

# Generated at 2022-06-23 05:37:23.402789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Create an instance of AnsibleLoader
    loader = AnsibleLoader('')

    # Test if the instance is an instance of yaml.resolver.BaseResolver
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:37:32.925158
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    # set up a data loader for the test
    fake_loader = DataLoader()

    # create an example vault encrypted yaml file to load

# Generated at 2022-06-23 05:37:44.209622
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import unittest
    from ansible.module_utils.common.yaml import AnsibleLoader

    # Test load
    class TestAnsibleLoader(unittest.TestCase):
        def test_load(self):
            stream = io.StringIO(u'{"key":"value"}')
            result = AnsibleLoader(stream).get_single_data()
            self.assertEqual(result, {'key': 'value'})

        def test_non_ascii_load(self):
            stream = io.StringIO(u'---\xa3\n')
            result = AnsibleLoader(stream).get_single_data()
            self.assertEqual(result, '£')

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-23 05:37:50.436116
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = """
    ---
    - name: test
      foo: [ 1, 2, 3 ]
    """
    loader = yaml.Loader(data)
    assert loader.construct_yaml_seq(node=None) == [{'foo': [1, 2, 3], 'name': 'test'}]

# Generated at 2022-06-23 05:37:51.544032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None)

# Generated at 2022-06-23 05:37:58.689847
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '{"some": "stuff", "a": 1, "b": false, "c": true, "d": null}'
    file_name = "test"
    vault_secrets = "secret"
    t = AnsibleLoader(stream, file_name, vault_secrets)
    assert t.stream == stream
    assert t.file_name == file_name
    assert t.vault_secrets == vault_secrets

# Generated at 2022-06-23 05:38:06.897760
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Creates an AnsibleLoader instance as AnsibleLoader(file_name=file_name)
    """
    import unittest
    from ansible.vars.unsafe_proxy import wrap_var

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.file_name = "../../lib/ansible/parsing/yaml/constructor.py"
            self.file_name = 'tests/lib/ansible/parsing/yaml/constructor_data.yml'
            #try:
            self.loader = AnsibleLoader(file_name=self.file_name)
            #except:
            #    self.loader = AnsibleLoader(file_name=self.file_name)

        def tearDown(self):
            pass


# Generated at 2022-06-23 05:38:14.430564
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class CallbackModule(CallbackBase):
        """
        Callback module for use by tests
        """
        def __init__(self, *args, **kwargs):
            super(CallbackModule, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 05:38:20.133944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
    name: b
    pre_tasks:
      - name: a
        shell: echo "a"
    """
    loader = AnsibleLoader(stream, file_name=None, vault_secrets=None)
    doc = loader.get_single_data()
    assert doc['pre_tasks'][0]['name'] == "a"

# Generated at 2022-06-23 05:38:27.663032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)
    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Parser)
    else:
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Composer)

# Generated at 2022-06-23 05:38:35.945274
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects

    data = """
    - hosts: localhost
      tasks:
      - name: localhost
        debug: msg="Hello World"
    """

    loader = AnsibleLoader(data)
    options = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode.VAULT_SECRETS_DEFAULT
    loader.vault_secrets = options
    playbook = loader.get_single_data()

    assert playbook['hosts'] == 'localhost'

    task = playbook['tasks'][0]
    assert task['name'] == 'localhost'
    assert task['debug']['msg'] == "Hello World"

# Generated at 2022-06-23 05:38:44.691610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.module_utils.common.json import AnsibleJSONEncoder

    class DummyStream:
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def read(self, num=None):
            r = self.data[self.pos:self.pos+num]
            self.pos += num
            return r

    ds = DummyStream(b'{"nested": {"key": "value", "list": ["1", "2"], "dict": {"key": "value"}}}')
    loader = AnsibleLoader(ds)

    # check that the constructor was called twice, one with sys.stdin and
    # another with the given file name, to seed the vault secrets cache

# Generated at 2022-06-23 05:38:45.582843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:38:54.263102
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import types
    assert issubclass(AnsibleLoader, types.ObjectType)
    assert AnsibleLoader.__module__ == 'ansible.parsing.yaml.loader'
    assert AnsibleLoader.__doc__ is not None
    if HAS_LIBYAML:
        assert isinstance(AnsibleLoader.__init__, types.UnboundMethodType)
        assert AnsibleLoader.__init__.__module__ == 'ansible.parsing.yaml.loader'
    else:
        assert isinstance(AnsibleLoader.__init__, types.FunctionType)
        assert AnsibleLoader.__init__.__module__ == 'ansible.parsing.yaml.loader'

# Generated at 2022-06-23 05:38:57.558472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #pylint: disable=unused-variable
    stream = None
    file_name = None
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)

# Generated at 2022-06-23 05:39:05.374539
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    # pylint: disable=too-many-locals
    loader = AnsibleLoader(file_name='/dev/null')

# Generated at 2022-06-23 05:39:06.834348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name="test.yml")

# Generated at 2022-06-23 05:39:07.933025
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None, None, None)

# Generated at 2022-06-23 05:39:19.571581
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-23 05:39:25.511350
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' AnsibleLoader() '''
    from io import StringIO
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    loader = AnsibleLoader(StringIO('foo: bar'), vault_secrets=VaultLib())
    loader.get_single_data()

# Generated at 2022-06-23 05:39:27.564851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)  # pylint: disable=abstract-class-instantiated

# Generated at 2022-06-23 05:39:30.505188
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' test for constructor of class AnsibleLoader '''
    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader, AnsibleLoader)

# Generated at 2022-06-23 05:39:32.944754
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert type(loader) is AnsibleLoader


# Generated at 2022-06-23 05:39:43.493348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from io import StringIO

    from ansible.parsing.yaml.constructor import AnsibleConstructor, AnsiBleSafeConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    NULL_BYTES = b'\x00'

    class Constructor(AnsibleConstructor):

        def construct_yaml_null(self, node):
            return None

        def construct_yaml_bool(self, node):
            value = Composer.construct_yaml_bool(self, node)
            if value == 'true':
                return True
            if value == 'false':
                return False
            raise ValueError

        def construct_yaml_int(self, node):
            value = Compos

# Generated at 2022-06-23 05:39:44.449468
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name='test')

# Generated at 2022-06-23 05:39:53.076069
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_text = '''
a: 1
b: 2
'''
    ansible_loader = AnsibleLoader(yaml_text)
    data = ansible_loader.get_single_data()
    assert "a" in data
    assert "b" in data

    yaml_text = '''
a: 1
b: 2
'''
    ansible_loader = AnsibleLoader(yaml_text)
    data = ansible_loader.get_single_data()
    assert "a" in data
    assert "b" in data

# Generated at 2022-06-23 05:40:02.393737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
      ---
      name: Test
      state: present
      users:
        - name: joe
          groups:
            - first
            - last
        - name: bob
          groups:
            - one
            - two
    '''

    loader = AnsibleLoader(stream)
    datadict = loader.get_single_data()

    assert datadict['name'] == 'Test'
    assert datadict['state'] == 'present'
    assert datadict['users'][0]['name'] == 'joe'
    assert datadict['users'][0]['groups'][0] == 'first'
    assert datadict['users'][0]['groups'][1] == 'last'
    assert datadict['users'][1]['name'] == 'bob'
   

# Generated at 2022-06-23 05:40:07.843497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test when vault_secrets is None
    loader = AnsibleLoader('abc')
    assert loader.vault_secrets == None

    # test when the vault_secrets is set
    loader.vault_secrets = 'mock_secret'
    assert loader.vault_secrets == 'mock_secret'

# Generated at 2022-06-23 05:40:15.004873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] == 2:
        stream = '''
            ---
            test: 'value'
        '''
    else:
        stream = '''
            ---
            test: 'value'
        '''.encode()

    loader = AnsibleLoader(stream)
    value = loader.get_single_data()
    assert isinstance(value, dict)
    assert value['test'] == 'value'

# Generated at 2022-06-23 05:40:17.985776
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' constructor of class AnsibleLoader '''

    obj = AnsibleLoader('')
    if HAS_LIBYAML:
        assert obj.__class__.__name__ == 'AnsibleLoader'
    else:
        assert obj.__class__.__name__ == 'AnsibleLoader'

# Generated at 2022-06-23 05:40:24.203928
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '# test yaml\n- hosts: localhost'
    stream = StringIO.StringIO(yaml_str)
    stream.name = 'test'
    loader = AnsibleLoader(stream)
    d = loader.get_single_data()
    assert 'hosts' in d and d['hosts'] == 'localhost', 'AnsibleLoader constructor fails'

# Generated at 2022-06-23 05:40:34.649405
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys, os

    sys.path.insert(0, os.path.dirname(__file__))
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    from ansible.parsing.vault import VaultLib

    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    from ansible.parsing.yaml import objects

    #yaml_str = '''!!python/object/apply:os.system ["echo hi"]\n- my_item\n- !!python/object/apply:os.system ["echo hi"]\n- !!python/object/apply:os.system\n- !!python/object/apply:os.

# Generated at 2022-06-23 05:40:44.007040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=bare-except
    # pylint: disable=too-few-public-methods
    class MyAnsibleLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream=stream, file_name=file_name, vault_secrets=vault_secrets)
    try:
        import StringIO
    except:
        from io import StringIO
    code = StringIO("""
---
a: 'b'
""")
    loader = MyAnsibleLoader(stream=code, file_name='<string>')
    assert isinstance(loader, AnsibleLoader)
    assert loader.stream is not None
    assert loader.file_name == '<string>'
   

# Generated at 2022-06-23 05:40:55.028679
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=bare-except
    try:
        from yaml.error import YAMLError
    except:
        from yaml.scanner import ScannerError as YAMLError
    # pylint: enable=bare-except

    try:
        from yaml import CSafeLoader as SafeLoader
    except:
        from yaml import SafeLoader

    s = '''
    # Minimal syntax
    key: value
    '''
    try:
        loader = AnsibleLoader(s)
        loader.get_single_data()
    except YAMLError as exc:
        raise AssertionError(exc)


# Generated at 2022-06-23 05:40:55.519277
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:40:56.123176
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:00.357645
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''
---
- hosts: all
  become_method: sudo
  become_user: root
  tasks:
    - command: echo hello
      changed_when: false
'''
    # load the string
    loader = AnsibleLoader(s)
    loader.get_single_data()

# Generated at 2022-06-23 05:41:03.725488
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader({'attrs': {'foo': 'bar'}})
    assert loader.get_single_data() == {'attrs': {'foo': 'bar'}}

# Generated at 2022-06-23 05:41:11.972620
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml
    stream = io.BytesIO(b"""
---
- hosts:
    - localhost
  tasks:
    - name: test
      ping:
      vars:
        local_var: value
    - name: another test
      shell: echo {{ local_var }}
""")
    vault_secrets = [b'1234']
    for i in range(4):
        out = yaml.load(stream, Loader=AnsibleLoader)

# Generated at 2022-06-23 05:41:19.922108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Fixture for the test
    class Fixture:
        stream = "---\n- hosts: all\n  become: true\n  tasks:\n  - name: test\n    debug:\n      msg: test\n"
        file_name = "fixture_file_name"
        vault_secrets = []

    fixture = Fixture()

    # Run the test
    result = AnsibleLoader(fixture.stream, file_name=fixture.file_name, vault_secrets=fixture.vault_secrets)

    # Assertions
    assert(isinstance(result, AnsibleLoader))

# Generated at 2022-06-23 05:41:20.864581
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('some text')

# Generated at 2022-06-23 05:41:22.569520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("../file_include.yml", 'r')
    loader = AnsibleLoader(stream)

# Generated at 2022-06-23 05:41:24.519915
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    assert AnsibleLoader(stream) is not None

# Generated at 2022-06-23 05:41:25.951963
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("foo")
    assert loader is not None

# Generated at 2022-06-23 05:41:27.314096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.AnsibleLoader = AnsibleLoader

# Generated at 2022-06-23 05:41:36.534992
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for constructor of class AnsibleLoader'''
    loader = AnsibleLoader('')
    # NOTE: we cannot test the following methods because they are only
    # annotated and thus look like they don't exist in Python 3.

    # def add_constructor(self, tag, constructor):
    # def add_multi_constructor(self, tag_prefix, multi_constructor):
    # def add_path_resolver(self, tag, path_resolver):
    # def add_implicit_resolver(self, tag, regexp, first=None):

    # def compose_node(self, parent, index):
    # def construct_document(self, node):
    # def construct_sequence(self, node):
    # def construct_mapping(self, node):
    # def construct_object(self, node,

# Generated at 2022-06-23 05:41:47.322533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import eval_loader
    from ansible.parsing.vault import VaultLib

    vault_id = 'somerandomevaultsecretkeyhere'
    vault_pass = 'VaultPassw0rd'
    vault_secrets = {'vault_password_file': vault_id}

# Generated at 2022-06-23 05:41:49.144749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader != None

# Generated at 2022-06-23 05:41:57.835287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  # test case 1
  state = AnsibleLoader('''
  foo:
    - name: "virtual environment"
      path: "~/.virtualenvs/"
  ''')

  assert state.get_data() == {'foo': [{'name': 'virtual environment', 'path': '~/.virtualenvs/'}]}

  # test case 2
  state = AnsibleLoader('''
  ---
  - hosts: localhost
  ''')

  assert state.get_data() == {'hosts': 'localhost'}

  # test case 3
  state = AnsibleLoader('''
    - name: Configure repo and install mongodb
      apt_repository: repo='{{ item.key }}' state={{ item.value }}
    ''')
