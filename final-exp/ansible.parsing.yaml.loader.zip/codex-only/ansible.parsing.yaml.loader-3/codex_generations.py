

# Generated at 2022-06-23 05:32:02.430605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
        ["a", "b", "c", "d"]
        {"a": [1, 2], "c": [3, 4]}
        ["a", "b", "c", "d", 1, 2, 3, 4]
        {"a": 1, "c": [3, 4]}
    """
    loader = AnsibleLoader(data)
    results = loader.get_single_data()

    assert type(results) == list
    assert len(results) == 4
    loader = AnsibleLoader(data)
    assert type(loader.get_single_data()) == list
    assert len(loader.get_single_data()) == 4

# Generated at 2022-06-23 05:32:03.423554
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:32:11.028151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256
    import ansible.parsing.vault as vault

    # Setup
    vault_secrets = [VaultSecret('secret', 1, VaultAES256('password'))]
    fake_stream = '$ANSIBLE_VAULT;1.1;AES256\n353735303334366335643433335433373466643133366532393733633631613338356165626532\n393736323562333861636137366633323965663436396332353533376232396538333539343065\n363531356330373839310a'

    # Execute

# Generated at 2022-06-23 05:32:14.482529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_undefined')

# Generated at 2022-06-23 05:32:18.991267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Ensure that AnsibleLoader accepts a file name, and stores it as an attribute.
    """
    file_name = 'foo/bar.yml'
    stream = None
    loader = AnsibleLoader(stream, file_name)

    assert loader.file_name == file_name

# Generated at 2022-06-23 05:32:27.597214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-return-statements
    stream = None
    file_name = None
    vault_secrets = None

    # stream is None and file_name is None
    loader = AnsibleLoader(stream)
    assert isinstance(loader, Parser)

    # stream is None and file_name is not None
    loader = AnsibleLoader(stream, file_name)
    assert isinstance(loader, Parser)

    # stream is not None and file_name is None
    loader = AnsibleLoader(stream, file_name)
    assert isinstance(loader, Parser)

    # stream is not None and file_name is not None
    loader = AnsibleLoader(stream, file_name)
    assert isinstance(loader, Parser)

# Generated at 2022-06-23 05:32:30.146107
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')

# Generated at 2022-06-23 05:32:41.352300
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    loader = AnsibleLoader("---\n - 1\n")
    data = loader.get_single_data()
    assert data == [1]

    loader = AnsibleLoader("---\n - 1\n")
    loader.set_vault_secrets([1])
    data = loader.get_single_data()
    assert data == [1]

    loader = AnsibleLoader("---\n - 1\n")
    loader.set_vault_secrets(['1'])
    data = loader.get_single_data()
    assert data == [1]

    loader = AnsibleLoader("---\n - 1\n")
    loader.set_vault_secrets([u'1'])
    data = loader.get_single

# Generated at 2022-06-23 05:32:45.186153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader([], 'testfile')
    has_vault_secrets = hasattr(loader, 'vault_secrets')
    assert has_vault_secrets is True
    assert loader.file_name == 'testfile'

# Generated at 2022-06-23 05:32:53.138627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib

    class VaultSecretStub(object):
        def __init__(self, password):
            self.password = password  # pylint: disable=attribute-defined-outside-init

    loader = AnsibleLoader("a: 1", vault_secrets=VaultSecretStub("pass"))

    assert isinstance(loader.get_single_data(), dict)
    assert loader.get_single_data()["a"] == 1
    assert not isinstance(loader.get_single_data()["a"], AnsibleUnsafeText)


# Generated at 2022-06-23 05:33:00.373006
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    - 123
    - ork
    '''
    loader = AnsibleLoader(stream)
    assert hasattr(loader, '_reader')
    assert loader.construct_yaml_int(123) == 123
    assert loader.construct_yaml_str('ork') == 'ork'
    loader.construct_yaml_map({'a': 123})
    loader.construct_yaml_seq([1, 2, 3])
    loader.construct_scalar('ork')
    loader.construct_undefined(None)

# Generated at 2022-06-23 05:33:05.749872
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, "foo.yml", vault_secrets={})
    assert loader.file_name == 'foo.yml'
    assert loader.vault_secrets == {}

    loader = AnsibleLoader(None)
    assert loader.file_name == None
    assert loader.vault_secrets == None


# Generated at 2022-06-23 05:33:11.700072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_file_name = 'sample_yaml'
    sample_data = {"name":"DummyName", "name1":"DummyName1", "name2":"DummyName2" }
    loader_object = AnsibleLoader(sample_data, input_file_name) 
    assert loader_object.construct_mapping(node) == sample_data

# Generated at 2022-06-23 05:33:15.926647
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader.construct_yaml_str(None, None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(None, ""), AnsibleUnicode)

# Generated at 2022-06-23 05:33:22.411170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    input_data = u"""
        ---
        - { item:
             - a
             - b
             - c
          }
        """
    stream = io.StringIO(input_data)
    loader = AnsibleLoader(stream)
    #print(loader.get_single_data())
    assert loader.get_single_data() == [{u'item': [u'a', u'b', u'c']}]

# Generated at 2022-06-23 05:33:23.710612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:34.744431
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.parsing.yaml.modules import AnsibleModule
    from os.path import dirname, join, abspath

    def make_loader(data):
        filename = abspath(join(dirname(__file__), 'constructor_test.yml'))
        return AnsibleLoader(data, file_name=filename)

    class TestAnsibleLoader(unittest.TestCase):
        def test_constructor(self):
            data = '''
            ---
            - hosts: localhost
              tasks:
                - name: test
                  debug: msg="hello world"
            '''
            loader = make_loader(data)

# Generated at 2022-06-23 05:33:46.192897
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 05:33:52.672770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        stream = '---\n - foo\n - bar'
    else:
        stream = b'---\n - foo\n - bar'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, list)
    assert len(data) == 2
    assert data[0] == "foo"
    assert data[1] == "bar"

# Generated at 2022-06-23 05:33:55.456766
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    --- !!str "123"
    """
    ansible_loader = AnsibleLoader(data)
    assert ansible_loader.get_single_data() == "123"

# Generated at 2022-06-23 05:34:02.066674
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # With libyaml, test that Parser constructor is called
    stream = 'cheese: pizza'
    if HAS_LIBYAML:
        assert Parser.__init__.called
        Parser.__init__.assert_called_with(stream)

    AnsibleConstructor.__init__.assert_called_with(file_name=None, vault_secrets=None)
    Resolver.__init__.assert_called_with()

# Generated at 2022-06-23 05:34:09.108396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    class TestClass:
        pass

    assert type(TestClass()) is not TestClass
    assert type(AnsibleConstructor.construct_yaml_obj(None, TestClass(), {})) is TestClass

    assert type(TestClass()) is not TestClass
    assert type(AnsibleConstructor.construct_object(None, TestClass(), {})) is TestClass


# Generated at 2022-06-23 05:34:19.563126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test_assertion(code, expected):
        loader = AnsibleLoader(code, vault_secrets=[('AES','mypassword')])
        data = loader.get_single_data()
        assert data == expected

    yield test_assertion, b"{{ foo }}", '[$ANSIBLE_VAULT]\n$encrypted_string$AES$mypassword$v5n4m4Jmfp4ZgDTWcabv1A=='

    # Duplicate secret
    yield test_assertion, b"{{ foo }}", '[$ANSIBLE_VAULT]\n$encrypted_string$AES$mypassword$v5n4m4Jmfp4ZgDTWcabv1A=='

    # Check that ansible:vault is loaded as a string

# Generated at 2022-06-23 05:34:22.532002
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name=None, vault_secrets=None)
    assert loader.stream is None
    loader.stream = ''
    assert loader.stream == ''
    assert loader.file_name is None

# Generated at 2022-06-23 05:34:24.073397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    foo = AnsibleLoader(stream)
    assert foo

# Generated at 2022-06-23 05:34:34.963442
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    import yaml

    # Test for plain string
    a = AnsibleLoader("test string")
    b = a.get_single_data()
    assert isinstance(b, AnsibleUnicode)
    assert b == "test string"

    # Test for string
    a = AnsibleLoader("'''test string'''")
    b = a.get_single_data()
    assert isinstance(b, AnsibleUnicode)
    assert b == "test string"

    # Test for dict
    a = AnsibleLoader("'''key1: value1'''")

# Generated at 2022-06-23 05:34:36.517078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Add a unit test for AnsibleLoader here
    pass

# Generated at 2022-06-23 05:34:37.163604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:48.208503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    from units.compat import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test__init__(self):
            l = AnsibleLoader(open('/dev/null'))
            self.assertIsInstance(l, AnsibleLoader)

        def test_construct_mapping(self):
            s = '''\
            name: test
            foo: bar'''
            l = AnsibleLoader(s)
            self.assertIsInstance(l.get_single_data(), AnsibleMapping)

        def test_construct_mapping_unicode(self):
            s = '''\
            name: test
            foo: система'''
            l = Ans

# Generated at 2022-06-23 05:34:54.368964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = '''
list:
  - one
  - two
  - three
'''
    stream = BytesIO(data.encode('utf-8'))
    loader = AnsibleLoader(stream)
    assert(isinstance(loader, AnsibleConstructor))

# Generated at 2022-06-23 05:34:59.338629
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
- hosts: test1
  remote_user: test
- hosts: test2
  remote_user: test
    '''
    obj = AnsibleLoader(stream)
    ds = obj.get_single_data()
    assert(ds[0]['hosts'] == 'test1')
    assert(ds[1]['hosts'] == 'test2')

# Generated at 2022-06-23 05:35:01.340478
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    # obj is a AnsibleLoader object
    assert isinstance(obj, AnsibleLoader)

# Generated at 2022-06-23 05:35:09.997948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
- hosts: all
  remote_user: root
  tasks:
  - name: install ntp
    yum: name=ntp state=latest
    when: ansible_os_family == "RedHat"

- hosts: all
  remote_user: root
  tasks:
  - name: install ntp
    apt: name=ntp state=latest
    when: ansible_os_family == "Debian"
'''

    from io import StringIO
    import yaml

    result = yaml.load(StringIO(data), Loader=AnsibleLoader)

    assert result[0]['tasks'][0]['name'] == 'install ntp'
    assert result[0]['tasks'][0]['when'] == 'ansible_os_family == "RedHat"'
   

# Generated at 2022-06-23 05:35:14.123475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys

    d = AnsibleLoader(io.BytesIO("FRUIT: [apple,  banana, cherry]\n"), file_name='/fake/file')
    print(d)
    assert d == {'FRUIT': ['apple', 'banana', 'cherry']}

# Generated at 2022-06-23 05:35:23.732869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    class OurLoader(AnsibleLoader):
        def construct_yaml_int(self, node):
            return 42

    class OurDumper(AnsibleDumper):
        def represent_int(self, data):
            return self.represent_scalar('tag:yaml.org,2002:int', str(data))

    yaml_str = "foo: 1\n"
    data = yaml.load(yaml_str, Loader=OurLoader)
    assert data == {u'foo': 42}

    data = yaml.load(yaml_str, Loader=OurLoader)
    assert data == {u'foo': 42}



# Generated at 2022-06-23 05:35:34.230257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-statements
    import os
    import sys

    from ansible.clone import _clone_dict
    from ansible.module_utils.common.yaml import AnsibleYAMLObjectMetaclass
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_bytes, to_text

    from ansible.errors import AnsibleParserError
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    ANSIBLE_TEST_DATA_ROOT = os.path.join(os.path.dirname(__file__), 'test_data')


# Generated at 2022-06-23 05:35:35.393584
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(isinstance(loader, AnsibleLoader))

# Generated at 2022-06-23 05:35:37.833528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "---\nfoo: bar"
    loader = AnsibleLoader(data)
    loader.get_data()
    assert loader.file_name is None

# Generated at 2022-06-23 05:35:39.892723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        ansible_loader = AnsibleLoader(None)
    except Exception as e:
        raise e

# Generated at 2022-06-23 05:35:51.865490
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    my_list = ['foo.bar.yml', 'bar.baz.yml']
    my_list_loader = yaml.Loader(yaml.dump(my_list))
    my_list_loader.add_constructor(u'tag:yaml.org,2002:timestamp', AnsibleLoader.construct_yaml_str)
    new_list = my_list_loader.get_single_data()
    assert new_list == my_list

    my_dict = {'foo': 'bar', 'baz': 'bat'}
    my_dict_loader = yaml.Loader(yaml.dump(my_dict))
    my_dict_loader.add_constructor(u'tag:yaml.org,2002:timestamp', AnsibleLoader.construct_yaml_str)
    new

# Generated at 2022-06-23 05:36:03.187634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.utils import md5s
    import os

    AnsibleLoader('')
    loader = AnsibleLoader(u'{"a": "b"}')
    if HAS_LIBYAML:
        assert loader.stream.__class__.__name__ == 'Scanner'
        assert loader.composer.__class__.__name__ == 'Composer'
        assert loader.constructor.__class__.__name__ == 'AnsibleConstructor'
        assert loader.resolver.__class__.__name__ == 'Resolver'
        assert loader.check_data() is False
    else:
        assert loader.reader.__class__.__name__ == 'Reader'

# Generated at 2022-06-23 05:36:10.240010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.error import MarkedYAMLError
    from yaml.events import MappingStartEvent
    from yaml.nodes import MappingNode

    loader = AnsibleLoader(file_name='testfile', vault_secrets=[])
    loader.compose_node = lambda *args, **kwargs: loader.construct_mapping(MappingNode(*args, **kwargs), deep=True)
    loader.add_constructor('tag:yaml.org,2002:map', lambda *args: loader.compose_node(*args))
    loader.check_event = lambda event: None
    fake_event = MappingStartEvent('test_event', 'test_anchor', 'test_tag', False, [], None, None)

# Generated at 2022-06-23 05:36:15.706632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''constructor should set AnsibleConstructor attributes'''

    file_name = 'foobar'
    vault_secrets = [1,2,3]

    myloader = AnsibleLoader(None, file_name=file_name, vault_secrets=vault_secrets)

    assert myloader.file_name == file_name
    assert myloader.vault_secrets == vault_secrets

# Generated at 2022-06-23 05:36:20.948891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = u"""
    ---
    - hosts: all
      tasks:
      - debug: msg="this is a unicode test: h\xe9"
      - debug: msg="this is an escaped unicode test: h\u0065\u0301"
    """

    loader = AnsibleLoader(text)
    data = loader.get_single_data()

    assert isinstance(data, list)
    assert isinstance(data[0], dict)
    assert isinstance(data[0]['tasks'], list)
    assert isinstance(data[0]['tasks'][0], dict)
    assert data[0]['tasks'][0]['debug']['msg'] == u"this is a unicode test: h\xe9"

# Generated at 2022-06-23 05:36:30.454884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Tests AnsibleLoader class
    """
    import sys
    import os

    curr_dir=(os.path.dirname(os.path.abspath(__file__)))
    test_loader_file = os.path.join(curr_dir, "../../../lib/ansible/playbook/test_loader.yml")
    f = open(test_loader_file, 'r')
    data = f.read()
    f.close()

    f = open(test_loader_file, 'r')
    ansible_loader = AnsibleLoader(f)
    test = ansible_loader.get_single_data()
    assert (data == test)

# Generated at 2022-06-23 05:36:39.297665
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dict import AnsibleDict
    from ansible.parsing.yaml.sequences import AnsibleSequence
    loader = AnsibleLoader(stream=BytesIO(b"%YAML 1.1\n---\n- [1, 2]"), file_name="foo.yml")
    parsed_data = loader.get_single_data()
    assert isinstance(parsed_data, list)
    assert isinstance(parsed_data[0], AnsibleSequence)


# Generated at 2022-06-23 05:36:42.171386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None)
    assert isinstance(ansible_loader, AnsibleLoader), 'ansible_loader should be instance of AnsibleLoader'

# Generated at 2022-06-23 05:36:51.163862
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:36:53.750714
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '{"variable": "value"}'
    loader = AnsibleLoader(data)
    assert loader.data == data
    assert loader.data == b'{"variable": "value"}'

# Generated at 2022-06-23 05:36:58.769280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    class Dummy(object):
        def __init__(self, fp, name="a.yaml"):
            self.fp = fp
            self.name = name

    stream = Dummy(open(os.path.join(os.path.dirname(__file__), '../../../../test/sanity/playbooks/test.yaml')))
    loader = AnsibleLoader(stream)
    print(loader.get_single_data())

# Generated at 2022-06-23 05:36:59.334672
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:07.133891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    src = StringIO(u'''a:
    - 1
    - 2
    - 3
b: 1
c:
    d: 1
    e: 2
''')
    ansible_loader = AnsibleLoader(src)
    result = ansible_loader.get_single_data()
    assert result == {'a': [1, 2, 3],
                      'b': 1,
                      'c': {'d': 1, 'e': 2},
                      }

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 05:37:09.740268
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:37:16.368376
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Load some sample data
    sample_data = '''
    ---
    - hosts: all
      roles:
        - role: some.role
        - role: another.role
    '''

    # Create an AnsibleLoader object
    l = AnsibleLoader(sample_data)

    # Make sure it is of the correct class
    assert l.__class__.__name__ == 'AnsibleLoader'


# Generated at 2022-06-23 05:37:19.482676
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info >= (2, 7):
        import StringIO
    else:
        import io as StringIO
    the_loader = AnsibleLoader(StringIO.StringIO())
    assert the_loader

# Generated at 2022-06-23 05:37:30.613682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    class TestLoader(AnsibleLoader):
        pass
    # test init
    AnsibleLoader("foo")
    AnsibleLoader("foo", "bar")
    AnsibleLoader("foo", "bar", "baz")
    # test construct_yaml_str
    assert TestLoader.construct_yaml_str(None, None) == ""
    assert TestLoader.construct_yaml_str(None, "foo") == "foo"
    assert isinstance(TestLoader.construct_yaml_str(None, "foo"), AnsibleUnicode)
    assert TestLoader.construct_yaml_str(None, "foo:bar") == "foo:bar"

# Generated at 2022-06-23 05:37:40.082475
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = """
        a: !!python/tuple [1, 2, 3]
        b: !!python/dict {"one": 1, "two": 2.0}
        c: !!python/str 'str'
        d: !!python/unicode 'unicode'
        e: !!python/bool True
        f: !!python/int '1'
        g: !!python/long '1'
    """

    ansible_loader = AnsibleLoader(stream)
    result = ansible_loader.get_single_data()
    assert(result == {'a': (1, 2, 3), 'b': {'two': 2.0, 'one': 1}, 'c': 'str', 'd': u'unicode', 'e': True, 'f': 1, 'g': 1})



# Generated at 2022-06-23 05:37:42.451305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    obj = AnsibleLoader(file_name='/tmp/foo')

    assert obj is not None, 'AnsibleLoader failed to initialize'

# Generated at 2022-06-23 05:37:50.734280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print("Testing AnsibleLoader")

# Generated at 2022-06-23 05:38:02.640572
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os
    import sys
    import unittest

    if sys.version_info >= (2, 7):
        class TestModuleLoader(unittest.TestCase):
            # AnsibleLoader
            def test_AnsibleLoader_init(self):
                pass

            def test_AnsibleLoader_composer_class(self):
                pass

            def test_AnsibleLoader_constructor_class(self):
                pass

            def test_AnsibleLoader_parser_class(self):
                pass

            def test_AnsibleLoader_reader_class(self):
                pass

            def test_AnsibleLoader_resolver_class(self):
                pass

            def test_AnsibleLoader_scanner_class(self):
                pass

# Generated at 2022-06-23 05:38:07.788514
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.get_single_data() is None
    assert loader.file_name is None
    assert loader.vault_secrets is None

    loader = AnsibleLoader('test', 'test.yaml', ['vault_secret'])
    assert loader.get_single_data() == 'test'
    assert loader.file_name == 'test.yaml'
    assert loader.vault_secrets == ['vault_secret']

# Generated at 2022-06-23 05:38:18.375549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is a subclass of
    #   yaml.reader.Reader,
    #   yaml.scanner.Scanner,
    #   yaml.parser.Parser,
    #   yaml.composer.Composer,
    #   AnsibleConstructor,
    #   yaml.resolver.Resolver
    # and the last two functions of yaml.reader.Reader
    # (get_event, and peek_event).
    if HAS_LIBYAML:
        expected = ['__init__', 'get_event', 'peek_event', '__init__', '__init__', '__init__', '__new__', '__init__']

# Generated at 2022-06-23 05:38:23.199175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    if sys.version_info[0] == 2:
        test_text = b"text"
    else:
        test_text = "text"
    ansible_loader = AnsibleLoader(io.BytesIO(test_text))
    assert type(ansible_loader) == AnsibleLoader

# Generated at 2022-06-23 05:38:25.744602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass

    obj = TestAnsibleLoader(stream=None)
    assert obj

# Generated at 2022-06-23 05:38:33.587414
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = '{ foo: 1, bar: "1", baz: [1,2,3] }'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data['foo'], AnsibleUnicode)
    assert isinstance(data['bar'], AnsibleUnicode)
    assert data['foo'] == '1'
    assert data['bar'] == '1'
    assert len(data['baz']) == 3
    assert data['baz'][2] == 3

# Generated at 2022-06-23 05:38:34.317600
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:38:44.051433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    # This is a temporary fix to python-vault that removes
    # its dependency on cryptography, which is required to
    # be installed on the system. This is not available on
    # Fedora.
    # TODO: Remove the below lines once python-vault is
    # updated to fix its dependency on cryptography.
    import sys
    import encryptors.aes
    sys.modules['vault.encryptors.aes'] = encryptors.aes

    # Testing constructor of AnsibleLoader
    # No attributes
    ansible_loader = AnsibleLoader(None, None, None)

    # file_name

# Generated at 2022-06-23 05:38:50.939104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    ---
    - hosts: localhost
      tasks:
      - debug: msg="hello there Ansible"
    '''
    loader_obj = AnsibleLoader(stream)
    loaded_data = loader_obj.get_single_data()

    assert loaded_data == [{
        u'hosts': u'localhost',
        u'tasks': [
            {
                u'debug': {
                    u'msg': u'hello there Ansible'
                }
            }
        ]
    }]

# Generated at 2022-06-23 05:38:59.988265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=no-self-use
    import re

    data = """
    ---
    foo: !include foo.yml
    """

    loader = AnsibleLoader(data)
    assert loader.get_single_data() is not None

    data = """
    ---
    # Test multi line YAML 1.2
    foo: |
      foo
      bar
    """

    loader = AnsibleLoader(data)
    assert loader.get_single_data() is not None

    data = """
    ---
    # Test multi line YAML 1.1
    foo: >
      foo
      bar
    """

    loader = AnsibleLoader(data)
    assert loader.get_single_data() is not None


# Generated at 2022-06-23 05:39:07.080665
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    to_inspect = (
        'Reader',
        'Scanner',
        'Parser',
        'Composer',
        'AnsibleConstructor',
        'Resolver',
    )
    for superclass in to_inspect:
        assert getattr(loader, '_%s__%s' % (superclass, superclass[0].lower())) is not None

# Generated at 2022-06-23 05:39:18.772342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    The following are tests for the AnsibleLoader constructor. The AnsibleLoader
    class is a child class of the yaml.reader.Reader, yaml.scanner.Scanner,
    yaml.parser.Parser, yaml.composer.Composer, and yaml.constructor.BaseConstructor
    classes. Thus it inherits all of their instance variables and has one of its
    own, file_name. It also inherits five methods from yaml.resolver.Resolver,
    that is, resolve(), add_implicit_resolver(), add_path_resolver(),
    add_regexp_resolver(), and descend_resolver().
    """
    class DummyConstructor(object):
        """Dummy constructor class"""
        pass

    class DummyResolver(object):
        """Dummy resolver class"""


# Generated at 2022-06-23 05:39:20.846801
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Make sure AnsibleLoader's init method can safely be called without required arguments
    AnsibleLoader(None)

# Generated at 2022-06-23 05:39:33.050747
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.module_utils.six.moves import StringIO
    import yaml

    data = """
    foo: bar
    bar:
      - 1
      - 2
      - 3
    """

    loader = yaml.Loader(data)
    assert loader.get_single_data() == {'foo': 'bar', 'bar': [1, 2, 3]}
    assert loader.get_data() == [{'foo': 'bar', 'bar': [1, 2, 3]}]

    loader = yaml.RoundTripLoader(data)
    assert loader.get_single_data() == {'foo': 'bar', 'bar': [1, 2, 3]}
    assert loader.get_data() == [{'foo': 'bar', 'bar': [1, 2, 3]}]

    # Test load_string()

# Generated at 2022-06-23 05:39:43.592917
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vars_loader, action_loader
    import ansible.constants as C
    import os

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=C.DEFAULT_HOST_LIST)
    vars_manager = VariableManager(loader=vars_loader, inventory=inv_manager)

# Generated at 2022-06-23 05:39:51.002495
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import logging
    import sys

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

    stream = """
- hosts: all
  tasks:
  - include_vars: "{{ play_dir }}/../vars/main.yml"
    name: include_vars
"""

    yaml = AnsibleLoader(stream, file_name='test_AnsibleLoader/input')
    data = yaml.get_single_data()

    print("Data:", data)

# Generated at 2022-06-23 05:39:57.585605
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.file_name is None
    assert loader.vault_secrets is None

    loader = AnsibleLoader('', file_name='/foo/bar', vault_secrets=[])
    assert loader.file_name == '/foo/bar'
    assert loader.vault_secrets == []


# pylint: disable=no-self-use

# Generated at 2022-06-23 05:40:08.321762
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    yaml_data = """
        ---
        roles:
            - { role: common, tags: [foo,bar] }
        tasks:
            - debug: msg={{foo}}
        """

    yaml = YAML()
    yaml.default_flow_style = False
    yaml_dict = yaml.load(yaml_data)
    loader = DataLoader()
    loader.set_vault_secrets(['vault_secret'])
    vault = VaultLib(password_files=['vault_secret'])
    yaml_dict = vault.decrypt(yaml_dict, vault.secrets[0])


# Generated at 2022-06-23 05:40:19.810819
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def test_AnsibleLoader_input(data, expected_output):
        loader = AnsibleLoader(data, vault_secrets=None)
        output = loader.get_single_data()
        assert output == expected_output
    test_AnsibleLoader_input('1', 1)
    test_AnsibleLoader_input('{}', {})
    test_AnsibleLoader_input('{1: 2}', {1: 2})
    test_AnsibleLoader_input('"hello"', 'hello')
    test_AnsibleLoader_input('"hello\\nworld"', 'hello\nworld')
    test_AnsibleLoader_input('"hello\\rworld"', 'hello\rworld')
    test_AnsibleLoader_input('"hello\\tworld"', 'hello\tworld')
   

# Generated at 2022-06-23 05:40:21.348143
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, vault_secrets=[])

# Generated at 2022-06-23 05:40:21.989971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:40:33.316904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - hosts:
        - 127.0.0.1
      connection: local
      gather_facts: False
      tasks:
        - name: test file exists
          stat:
            path: /etc/hosts
    """

    # Catch warning on instantiation
    class AnsibleLoader(Parser, AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            Parser.__init__(self, stream)  # pylint: disable=non-parent-init-called
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self)

    AnsibleLoader(yaml_str)

# Generated at 2022-06-23 05:40:36.062965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    constructor = AnsibleLoader(u'[ foo, [ bar, baz ]]', u'test file')
    assert isinstance(constructor, AnsibleLoader)

# Generated at 2022-06-23 05:40:44.894269
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import types

    # These are the method names that are the same as built-in
    # functions, but are actually not implemented as C functions.
    # This is for Python 2.6, 2.7 and 3.2.
    othermethods = ['__eq__', '__format__', '__ge__', '__getattribute__',
                    '__gt__', '__hash__', '__init__', '__le__', '__lt__',
                    '__ne__', '__new__', '__reduce__', '__reduce_ex__',
                    '__repr__', '__setattr__', '__sizeof__', '__str__',
                    '__subclasshook__']

    # These are the names of the methods that are supported by
    # the built-in 'set' type, but which are

# Generated at 2022-06-23 05:40:47.952538
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('{ a: 10 }')
    assert loader is not None

# Generated at 2022-06-23 05:40:51.061765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader  # annoying pyflakes

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-23 05:41:02.334006
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of AnsibleLoader
    stream = None
    file_name = None
    vault_secrets = None
    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)
    # Verify that ansible_loader is an instance of AnsibleLoader class
    assert isinstance(ansible_loader, AnsibleLoader)
    # Verify that ansible_loader is also an instance of Parser class
    assert isinstance(ansible_loader, Parser)
    # Verify that ansible_loader is also an instance of AnsibleConstructor class
    assert isinstance(ansible_loader, AnsibleConstructor)
    # Verify that ansible_loader is also an instance of Resolver class
    assert isinstance(ansible_loader, Resolver)


# Generated at 2022-06-23 05:41:11.367878
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO
    from sys import version_info

    # use any unicode key combination which fails with cPyYaml

# Generated at 2022-06-23 05:41:21.682570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import textwrap
    # Set up a stream

# Generated at 2022-06-23 05:41:25.092379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
---
[all]
hosts:
  foo:
    bar: baz
'''
    loader = AnsibleLoader(stream)
    assert loader is not None

# Generated at 2022-06-23 05:41:34.512507
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # AnsibleLoader with vault_secrets set
    user_loader = AnsibleLoader("some text", 'some_file', vault_secrets=[1])
    assert(isinstance(user_loader, AnsibleLoader))
    assert(user_loader.file_name == 'some_file')
    assert(user_loader.vault_secrets == [1])

    # AnsibleLoader without vault_secrets
    user_loader = AnsibleLoader("some text", 'other_file', None)
    assert(isinstance(user_loader, AnsibleLoader))
    assert(user_loader.file_name == 'other_file')
    assert(user_loader.vault_secrets == [])

# Generated at 2022-06-23 05:41:40.072013
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
---
- hosts: all
  gather_facts: False
  tasks:
    - name: ping
      ping:
      register: ping_result
    - debug:
        var: ping_result
'''
    ansible_loader = AnsibleLoader(stream, 'hosts')
    ansible_loader.get_single_data()
    assert ansible_loader.file_name == 'hosts'

# Generated at 2022-06-23 05:41:49.189539
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = {
        'delta': 'hamster',
        'yam': [
            'toast',
            'cheese',
            {'coffee': 'beans'}
        ]
    }
    from io import StringIO
    from six import PY3
    if PY3:
        from io import BytesIO
        stream = BytesIO(unicode(yaml.dump(data, Dumper=yaml.SafeDumper).encode('utf-8')))
    else:
        stream = StringIO(unicode(yaml.dump(data, Dumper=yaml.SafeDumper)))
    loader = AnsibleLoader(stream)
    new_data = loader.get_single_data()
    assert new_data == data

# Generated at 2022-06-23 05:41:57.857279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches, too-many-statements,too-many-locals,too-many-nested-blocks
    import os
    import tempfile
    import subprocess
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    plaintext_vault_string = "decrypted" + os.linesep