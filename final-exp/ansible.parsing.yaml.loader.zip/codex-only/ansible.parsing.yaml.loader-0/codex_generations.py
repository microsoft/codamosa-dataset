

# Generated at 2022-06-23 05:32:03.497961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    stream = "---\n# comment\n- foo: bar\n  baz: qux\n- one: two\n  three: four\n\n"
    loader = AnsibleLoader(stream)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert isinstance(loader.get_single_data(), AnsibleSequence)
    assert isinstance(loader.get_single_data()[0], dict)
    assert isinstance(loader.get_single_data()[0]['foo'], AnsibleUnicode)
    assert loader.get_single_data()[0]['foo'] == "bar"

# Generated at 2022-06-23 05:32:07.042286
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleYaml = AnsibleLoader(stream="a: 1\nb:\n  c: 3\n  d: 4\n", vault_secrets=[], file_name=None)
    data = ansibleYaml.get_single_data()
    assert data['a'] == 1
    assert data['b'] == {'c': 3, 'd': 4}

# Generated at 2022-06-23 05:32:09.569661
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader('')
    except Exception as e:
        # Exception may be expected
        pass

# Generated at 2022-06-23 05:32:14.129701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def check_constructor(data, expected):
        loader = AnsibleLoader(data)
        assert loader.get_single_data() == expected

    # Check that constructor doesn't fail with empty data
    check_constructor('', None)

    # Check that constructor doesn't fail with empty data
    check_constructor('{}', {})

# Generated at 2022-06-23 05:32:16.978617
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        pass

# ansible.parsing.yaml.dumper

# Generated at 2022-06-23 05:32:18.020308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:18.644593
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:32:26.452938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    # Constructor parameters: stream, file_name=None, vault_secrets=None
    # yaml.reader.Reader does not have any parameter.
    # yaml.scanner.Scanner does not have any parameter.
    # yaml.parser.Parser does not have any parameter.
    # yaml.composer.Composer does not have any parameter.
    # AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
    # yaml.resolver.Resolver does not have any parameter.
    assert True

# Generated at 2022-06-23 05:32:36.366152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.insert(0, os.getcwd())
    from ansible.parsing.yaml.objects import AnsibleUnicode
    print(AnsibleLoader(b'foo: bar\nbaz: bam\n').get_data())
    print(AnsibleLoader(u'foo: bar\nbaz: bam\n').get_data())
    print(AnsibleLoader(u'foo: bar\nbaz: bam\n', file_name='akira.yaml').get_data())
    assert isinstance(AnsibleLoader(u'foo: bar\nbaz: bam\n', file_name='akira.yaml').get_single_data(), AnsibleUnicode)

# Generated at 2022-06-23 05:32:46.897631
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    vault_pass = VaultLib()._get_new_vault_password()
    vault = VaultEditor(vault_pass)

    # Generate a test file for our loader class to parse

# Generated at 2022-06-23 05:32:47.940408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Just test if it doesn't raise an exception
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:58.924985
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=unused-variable
    """This function is only a unit test for AnsibleLoader
    """
    import warnings
    from ansible.module_utils.common.yaml import AnsibleLoader

    has_libyaml = AnsibleLoader.HAS_LIBYAML
    warnings.warn("has_libyaml = {}".format(has_libyaml))
    if not has_libyaml:
        return

    loader = AnsibleLoader(b'[1,2,3]')
    lst = loader.get_single_data()
    warnings.warn("lst = {}".format(lst))
    assert lst == [1,2,3]

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set

# Generated at 2022-06-23 05:33:10.211548
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import load, dump

    # Can be used to generate tests with valid yaml files and
    # their corresponding python structures.
    # print(dump(load("test/sanity/yaml/test_file.yaml")))


# Generated at 2022-06-23 05:33:12.922977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    # test absent vault_secrets
    test_loader = AnsibleLoader(io.StringIO('---\nkey: "value"'))
    assert test_loader.vault_secrets == None

# Generated at 2022-06-23 05:33:20.239297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime

    test_stream = '''
      1:
        key: value
      2:
        {0}: value
    '''.format(datetime.datetime.now().strftime("%Y%m%d%H%M%S%f"))

    test_stream_with_none = '''
      1:
        key: value
      2:
        {0}: value
      3:
        key1:
        key2:
    '''.format(datetime.datetime.now().strftime("%Y%m%d%H%M%S%f"))

    output_stream = '''
    1: {key: value}
    2: {%s: value}
    ''' % datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")



# Generated at 2022-06-23 05:33:26.945282
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = "{'a': {'b': 'c'}, 'd': [{'e': 'f'}]}"
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    assert data == {'a': {'b': 'c'}, 'd': [{'e': 'f'}]}

# Generated at 2022-06-23 05:33:28.696302
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()

# Generated at 2022-06-23 05:33:32.913020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open(__file__) as f:
        code = f.read()
        loader = AnsibleLoader(code)
        loaded = loader.get_single_data()
        assert loaded, 'AnsibleLoader should return a loadable object'

# Generated at 2022-06-23 05:33:40.893961
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import json
    import tempfile
    import shutil
    import pytest

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.constants import DEFAULT_VAULT_ID_MATCH

    tmpdir = tempfile.mkdtemp()
    vault_password_file = os.path.join(tmpdir, 'vault_password')
    # This is the password we use in vault_test.yml
    vault_password = "my-secret-password"

    # Make a vault encrypted file

# Generated at 2022-06-23 05:33:41.757105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert 1==1

# Generated at 2022-06-23 05:33:43.595055
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(stream='', file_name='', vault_secrets=None)
    assert loader is not None

# Generated at 2022-06-23 05:33:54.178417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    # Test returning empty object
    yaml_empty = io.StringIO("{}")
    loader = AnsibleLoader(yaml_empty)
    assert {} == loader.get_single_data()

    # Test returning with ansible-playbook-style {{ ... }}
    yaml_cp = io.StringIO('''
        {
            "key": "{{ value }}",
            "key2": "{{ value }} test",
            "key3": "\\{{ value }} test"
        }
    ''')
    loader = AnsibleLoader(yaml_cp)
    data = loader.get_single_data()
    assert "{{ value }}" == data['key']
    assert "{{ value }} test" == data['key2']
    assert "{{ value }} test" == data['key3']
    yaml

# Generated at 2022-06-23 05:34:08.633228
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
- hosts:
  - localhost
- name: test
  hosts:
    - localhost
  remote_user: test
  become: yes
  tasks:
    - name: test ping
      ping:
'''
    loader = AnsibleLoader(stream)
    data = loader.get_data()

    assert len(data) == 2
    assert data[0]['hosts'] == ['localhost']
    assert data[0]['name'] == 'test'
    assert data[0]['hosts'] == ['localhost']
    assert data[0]['remote_user'] == 'test'
    assert data[0]['become'] == True
    assert data[0]['tasks'] == [{'name': 'test ping', 'ping': None}]


# Generated at 2022-06-23 05:34:11.467927
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None)
    assert isinstance(data, AnsibleLoader)

# Generated at 2022-06-23 05:34:22.621689
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    from ansible.module_utils.common.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml.representer import AnsibleDumper
    from ansible.module_utils.common.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleUnicode

    test_yaml = '''
- hosts: localhost
  vars:
    var_with_unicode: æøå ÃÆØÅ
  tasks:
  - debug:
      msg: "{{ var_with_unicode }}"
    '''
    stream = io.StringIO(test_yaml)
    stream.seek(0)

# Generated at 2022-06-23 05:34:27.827543
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    environment = {
        'name': 'example',
        'description': 'This is an example environment'
    }
    loader = '''
    name: example
    description: This is an example environment
    '''
    ansible_loader = AnsibleLoader(loader)
    environment_loader = ansible_loader.get_single_data()
    assert environment == environment_loader

# Generated at 2022-06-23 05:34:32.652515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.config.data import ConfigData
    from ansible.config.yaml.loader import load_yaml_config_file
    from ansible.config.loader import ConfigLoader

    config_data = ConfigData()
    config_loader = ConfigLoader(config_data)

    load_yaml_config_file(config_loader, '/some/file')

# Generated at 2022-06-23 05:34:35.384129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('[foo,bar]')
    data = loader.get_single_data()
    assert isinstance(data, list)

# Generated at 2022-06-23 05:34:36.026129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:42.671601
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
- item1
- item2
- item3
- item4
"""

    loader = AnsibleLoader(stream)

    data = loader.get_data()
    assert data == ['item1', 'item2', 'item3', 'item4']

    assert loader.get_single_data() == loader.get_single_data() == ['item1', 'item2', 'item3', 'item4']

# Generated at 2022-06-23 05:34:52.656562
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.vars import merge_hash
    #from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleSequenceNode, AnsibleMappingNode
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml


# Generated at 2022-06-23 05:35:01.781636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():   # pylint: disable=too-many-statements
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    import sys

    if sys.version_info[0] > 2:
        byte_construct_handler = Parser.byte_construct_handler
    else:
        byte_construct_handler = None

    def byte_construct_handler_wrapper(self, node):
        return byte_construct_handler(self, node)

    def test_loader_object(loader, obj, cls):
        # test for object type
        assert isinstance(obj, cls)

        # test for native python data
        data = loader.get_single_data()
        assert isinstance(data, dict)
        assert isinstance(data, cls)


# Generated at 2022-06-23 05:35:05.638196
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def new_AnsibleLoader(*args, **kwargs):
        return AnsibleLoader(*args, **kwargs)

    yield (new_AnsibleLoader, b"blah")
    yield (new_AnsibleLoader, "blah")

# Generated at 2022-06-23 05:35:10.671671
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    ansible_loader = AnsibleConstructor(None)
    assert loader._root is ansible_loader._root
    assert loader._multi_line_blocks[0] == ansible_loader._multi_line_blocks[0]
    assert loader.vault_secrets == ansible_loader.vault_secrets

# Generated at 2022-06-23 05:35:17.300064
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from pprint import pprint
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    data = loader.load_from_file("conftest.yml")
    pprint(data)
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['list_of_ints'], AnsibleSequence)

# Generated at 2022-06-23 05:35:30.153627
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-branches,too-many-statements,anomalous-backslash-in-string
    # pylint: disable=bad-continuation
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    from ansible.plugins import module_loader

    class FakeDisplay(object):
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass

    display = FakeDisplay()

    try:
        from ansible.plugins.loader import module_loader
    except ImportError:
        module_loader = None

    import sys
    import types


# Generated at 2022-06-23 05:35:32.341782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
    pass

# Generated at 2022-06-23 05:35:36.413370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    sample_yaml = """
- hosts: localhost
  connection: local
  gather_facts: False
  tasks:
  - action:
      module: ping
"""
    data = yaml.load(sample_yaml)
    assert data[0]['hosts'] == 'localhost'

# Generated at 2022-06-23 05:35:39.168678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleloader = AnsibleLoader("")
    assert ansibleloader

# Generated at 2022-06-23 05:35:50.895993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert issubclass(AnsibleLoader, Resolver)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert AnsibleLoader.construct_yaml_map == AnsibleConstructor.construct_yaml_map
    assert AnsibleLoader.construct_yaml_str == AnsibleConstructor.construct_yaml_str
    assert AnsibleLoader.construct_yaml_seq == AnsibleConstructor.construct_yaml_seq
    assert AnsibleLoader.add_implicit_resolver == Resolver.add_implicit_resolver
    if HAS_LIBYAML:
        assert AnsibleLoader.add_constructor == Parser.add_constructor

    loader = AnsibleLoader('')  # pylint

# Generated at 2022-06-23 05:35:52.767809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:35:59.250591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = """---
    hosts: localhost
    tasks:
    - name: timezone
      timezone: name={{ timezone }}
      register: tz_result
      when:
        - timezone is defined
        - tz_result is not defined
    """
    stream = StringIO(string)
    loader = AnsibleLoader(stream)
    print(loader.get_single_data())

# Generated at 2022-06-23 05:36:00.179081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None, None)

# Generated at 2022-06-23 05:36:03.823434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    file_name = sys.argv[0]
    stream = open(file_name)
    AnsibleLoader(stream, file_name)

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:04.789199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    module = AnsibleLoader()
    assert module is not None

# Generated at 2022-06-23 05:36:06.752483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Tests that we can create an object of AnsibleLoader class'''
    AnsibleLoader('fs.yml')

# Generated at 2022-06-23 05:36:08.567271
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("data")
    assert type(loader) == AnsibleLoader

# Generated at 2022-06-23 05:36:18.241311
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=import-error
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import combine_vars
    from ansible.vars.clean import module_response_deepcopy
    from ansible.parsing.vault import VaultLib

    data = """
    one:
      two:
      - 1
      - 2
      - 3
      three:
      - 3
      - 2
      - 1
    false: False
    null:
    """

    # pylint: disable=redefined-variable-type
    # this test is written generic enough to be refactored
    # if we want to keep the class, or use a function
    loader = AnsibleLoader(data, vault_secrets=dict())
    results = loader

# Generated at 2022-06-23 05:36:26.911411
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class args(object):
        pass

    stream = "test"
    file_name = "test.yml"
    vault_secrets = []

    ansible_loader = AnsibleLoader(stream, file_name, vault_secrets)

    assert isinstance(ansible_loader, Reader)
    assert isinstance(ansible_loader, Scanner)
    assert isinstance(ansible_loader, Parser)
    assert isinstance(ansible_loader, Composer)
    assert isinstance(ansible_loader, AnsibleConstructor)
    assert isinstance(ansible_loader, Resolver)

# Generated at 2022-06-23 05:36:27.949381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None, None)

# Generated at 2022-06-23 05:36:30.192164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert loader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:40.566854
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
---
- name: config
  hosts: localhost
  gather_facts: no
  tasks:
  - gohai:
    - name: "{{ gohai_name }}"
    - age: "{{ gohai_age }}"
    - message: "name:{{ gohai_name }} age:{{ gohai_age }}"
    register: result
  ...
"""
    loader = AnsibleLoader(yaml)
    print(loader)
    print(dir(loader))
    print(dir(loader.get_single_data()))
    print(dir(loader.get_single_data().get('tasks')))
    print(dir(loader.get_single_data().get('tasks')[0]))

# Generated at 2022-06-23 05:36:49.784696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = '''
    - hosts: localhost
      gather_facts: yes
      tasks:
      - include_vars: "{{ ansible_distribution }}-{{ ansible_distribution_version }}.yml"

    - hosts: test
      vars:
        test: "{{ test }}"
      tasks:
      - debug: msg="{{ test }}"
      roles:
      - role: role1

    - hosts: test2
      tasks:
      - include_role: name=role1
      - include_role: name=role2
    '''
    data = AnsibleLoader(yaml).get_single_data()
    assert len(data) == 3
    assert 'hosts' in data[0]
    assert 'gather_facts' in data[0]

# Generated at 2022-06-23 05:36:56.717386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    t = AnsibleLoader(stream=None)
    assert t.stream is None
    assert t.file_name is None
    assert t.vault_secrets == []
    assert t.document is None
    assert t.documents is None
    assert isinstance(t.resolver, Resolver)
    assert isinstance(t.constructor, AnsibleConstructor)
    assert isinstance(t.composer, Composer)
    assert isinstance(t.parser, Parser)
    assert isinstance(t.scanner, Scanner)
    assert isinstance(t.reader, Reader)

# Generated at 2022-06-23 05:36:58.239088
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:36:59.900550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    ansible.parsing.yaml.objects

# Generated at 2022-06-23 05:37:03.879789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This is a very simple test for class AnsibleLoader
    # The test does not verify the functionality
    # It is only verifying that the AnsibleLoader can be instanciated
    loader = AnsibleLoader(None, None)
    assert loader is not None

# Generated at 2022-06-23 05:37:06.541217
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("foo")
    assert loader.file_name == 'foo'
    assert loader.vault_secrets == {}

# Generated at 2022-06-23 05:37:11.780527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None)
    assert hasattr(x, 'construct_yaml_map')
    assert hasattr(x, 'construct_yaml_seq')
    assert hasattr(x, 'construct_mapping')
    assert hasattr(x, 'construct_undefined')
    assert hasattr(x, 'resolve')
    assert hasattr(x, 'check_data')
    assert hasattr(x, 'get_single_data')
    assert hasattr(x, 'get_data')

# Generated at 2022-06-23 05:37:16.318386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''test_AnsibleLoader'''
    from io import BytesIO

    stream = BytesIO(b"---\nkey: value\n")
    loader = AnsibleLoader(stream)
    loader.get_single_data()

    assert loader.file_name is None

# Generated at 2022-06-23 05:37:19.296782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    ---
    hostvars:
      '{{ web_servers }}':
        foo: bar
    '''

    assert data == str(AnsibleLoader(data))


# Generated at 2022-06-23 05:37:24.296445
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    from io import BytesIO

    # AnsibleLoader()
    # ---------------
    # Constructor
    # ---------------

    # Shouldn't be able to instantiate the class directly because it has abstract methods
    with pytest.raises(TypeError):
        AnsibleLoader()

# Generated at 2022-06-23 05:37:25.868487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(None, None), AnsibleConstructor)

# Generated at 2022-06-23 05:37:36.446754
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultLib, VaultSecret
    vault_secret = VaultSecret('abc', 'my-vault-password')
    vault = VaultLib([vault_secret])

    loader = AnsibleLoader('a: 1', file_name='test-loader', vault_secrets=[vault_secret])
    assert loader.file_name == 'test-loader'
    assert loader.get_single_data() == {'a': 1}


# Generated at 2022-06-23 05:37:46.852006
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.nodes import AnsibleScalarNode

    class TestVaultSecrets(object):
        def get(self, filename, vault_password):
            if filename == 'test.yml':
                return 'foo'

    vault_secrets = TestVaultSecrets()

    # Create a fake YAML document and check AnsibleLoader output.
    # Note: 'name' key is encrypted with vault.

# Generated at 2022-06-23 05:37:52.267919
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-many-function-args
    stream = None
    file_name = 'test_file_name'
    vault_secrets = 'test_vault_secrets'
    ansible_loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
    assert ansible_loader.file_name == file_name
    assert ansible_loader.vault_secrets == vault_secrets

# Generated at 2022-06-23 05:38:03.717610
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import os
    import os.path
    import sys

    the_data = '''
a: 1
b: 2
c: 3
'''

    (fd, fn) = tempfile.mkstemp(suffix='.yml')
    os.write(fd, the_data)
    os.close(fd)

    # Test that constructor finds the right file
    l = AnsibleLoader(the_data, file_name=fn)

    os.unlink(fn)

    # Test the vault test function
    (fd, fn) = tempfile.mkstemp(suffix='.yml')

# Generated at 2022-06-23 05:38:05.023142
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Test for creation of new object
# Test for proper initialization of object

# Generated at 2022-06-23 05:38:06.156549
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-argument
    assert AnsibleLoader

# Generated at 2022-06-23 05:38:10.561213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class A():
        pass
    a = A()
    a.name = 'hello'
    a.parser = AnsibleConstructor()
    a.reader = Resolver()
    assert isinstance(a.parser, AnsibleConstructor)
    assert isinstance(a.reader, Resolver)

# Generated at 2022-06-23 05:38:19.594153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.utils.vars import combine_vars
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    class FakeVaultSecret(object):
        def __init__(self):
            self.secret = 'foo'

        def decode(self):
            return self.secret

    class FakeUnsafeText(AnsibleUnsafeText):
        # Force the compose_node to call the constructor
        def __new__(cls, data=None):
            obj = super(FakeUnsafeText, cls).__new__(cls, data)
            if data is None:
                obj.data = []
            else:
                obj.data = data
            return obj

        def joined_str(self):
            return ''.join(self.data)


# Generated at 2022-06-23 05:38:21.598700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)


# Generated at 2022-06-23 05:38:32.444259
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString
    from ansible.vars.clean import ansible_module_clean
    import ansible.constants as C


# Generated at 2022-06-23 05:38:42.733643
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''---
- hosts: localhost
  vars:
    var1: value1
    var2: value2
  tasks:
  - file:
      path: /tmp/test
      state: touch
    when: ansible_os_family == 'Debian'
    tags: testme
'''
    filenm = 'file1'
    vault_secrets = dict()
    loader = AnsibleLoader(stream, file_name=filenm, vault_secrets=vault_secrets)
    result = loader.get_single_data()
    assert 'tasks' in result
    assert 'vars' in result
    assert result['file_name'] == filenm
    assert result['vault_secrets'] == vault_secrets

# Generated at 2022-06-23 05:38:52.798883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = u"---\n- hosts: localhost\n"
    loader = AnsibleLoader(stream)
    loader.get_single_data()

    # create a dict with a unicode key
    loader.stream = u"---\n- hosts: localhost\n{foo: {greek: \u039d}}\n"
    loader.get_single_data()

    # create a dict with a non-string (list) key
    stream = u"---\n- hosts: localhost\n{[a,b,c]: test}\n"
    loader = AnsibleLoader(stream)
    loader.get_single_data()

    # create a dict with a non-string (boolean) key
    stream = u"---\n- hosts: localhost\n{true: test}\n"
    loader = Ansible

# Generated at 2022-06-23 05:39:01.423792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    try:
        from collections import OrderedDict
    except ImportError:
        OrderedDict = dict

    class AnsibleDumper(AnsibleLoader):
        def increase_indent(self, flow=False, indentless=False):
            return super(AnsibleDumper, self).increase_indent(flow, False)

    class AnsibleUnicode(str, AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_dumper = AnsibleDumper

    class AnsibleOrderedDict(OrderedDict, AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_dumper = AnsibleDumper


# Generated at 2022-06-23 05:39:11.124858
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MockVaultSecret(object):

        def __init__(self, value="SECRET"):
            self.value = value

    def mock_construct_secret(loader, node):
        return AnsibleUnicode(loader.construct_scalar(node))

    def mock_construct_data(loader, node):
        if node.id == "tag:yaml.org,2002:str":
            return MockVaultSecret()
        else:
            return loader.construct_scalar(node)

    class MockVaultSecretDumper(AnsibleDumper):
        pass


# Generated at 2022-06-23 05:39:22.079909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleConstructor.from_yaml does not work as an ordinary constructor
    # as it needs a file_name to be passed, so we cannot load AnsibleLoader
    # directly from a string.
    import io
    import collections
    from contextlib import contextmanager
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    def check_yaml(string, expected):
        yaml_str = '---\n' + string
        file_name = 'test_loader.yaml'
        stream = io.StringIO(unicode(yaml_str))
        loader = AnsibleLoader(stream, file_name=file_name)
        assert loader.get_single_data() == expected
        assert stream.tell() == len(yaml_str)

    #
    #

# Generated at 2022-06-23 05:39:34.044810
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
        ---
        - hosts:
          - all
        tasks:
          - shell: echo hello world
            when: ansible_os_family == 'foo'
            register: foo
          - name: bar
            shell: echo hello world | md5sum
            when: foo.stdout.startswith('hello')
    """
    loader = AnsibleLoader(stream)
    loader = loader.get_single_data()

    assert 'hosts' in loader
    assert len(loader['hosts']) == 1
    assert loader['hosts'][0] == 'all'
    assert 'tasks' in loader
    assert len(loader['tasks']) == 2
    assert loader['tasks'][0]['shell'] == 'echo hello world'

# Generated at 2022-06-23 05:39:34.967758
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    d = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert d is not None

# Generated at 2022-06-23 05:39:41.987546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = Parser('[1,2,3]')
    file_name = 'test'

    loader = AnsibleLoader(stream, file_name)
    print(loader.get_single_data())

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    encrypted = AnsibleVaultEncryptedUnicode()
    print(encrypted)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:39:49.317124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unicode import to_unicode

    yaml_str = '''
            failed: false
            changed: [192.168.1.1]
            skipped: ["192.168.1.2"]'''
    yaml_str = to_unicode(yaml_str)

    options = {'ansible_facts': dict()}
    loader = AnsibleLoader(yaml_str, file_name='<string>', vault_secrets=None)
    data = loader.get_single_data()
    assert data == dict(failed=False, changed=['192.168.1.1'], skipped=['192.168.1.2'])

# Generated at 2022-06-23 05:39:53.603436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    stream = u'tag: !foo 123\n'
    loader = AnsibleLoader(stream)
    loader.add_multi_constructor('!foo', lambda loader, node: AnsibleUnicode(u'unicode'))
    assert loader.get_single_data() == u'unicode'
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 05:39:55.032589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: write a test
    pass


# Generated at 2022-06-23 05:40:07.035464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    fake_secret = '$ANSIBLE_VAULT;' + AnsibleVaultEncryptedUnicode.VAULT_ID + ';AES256'
    fake_secret2 = AnsibleVaultEncryptedUnicode.SECRET_MARKER.strip() + '\nabcdefghijklmnopqrstuvwxyz\n'
    fake_secret3 = AnsibleVaultEncryptedUnicode.SECRET_MARKER.strip() + '\nabcdefghijklmnopqrstuvwxyz\n'

# Generated at 2022-06-23 05:40:18.484686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test to verify that our constructor works
    result = AnsibleLoader('test').get_single_data()
    assert type(result) is str
    assert result == 'test'

    result = AnsibleLoader('---\ntest').get_single_data()
    assert type(result) is str
    assert result == 'test'

    # Test the string type
    result = AnsibleLoader('test', file_name='string').get_single_data()
    assert type(result) is str
    assert result == 'test'

    # Test the file type
    fd = open('test1.yml', 'w')
    fd.write('test')
    fd.close()

    result = AnsibleLoader(open('test1.yml', 'r'), file_name='file').get_single_data()

# Generated at 2022-06-23 05:40:20.238237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    l = AnsibleLoader(sys.stdin)

# Generated at 2022-06-23 05:40:25.090511
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader

    with open('test/test.yml', 'r') as f:
        data = yaml.load(f, Loader=AnsibleLoader)
    assert type(data) == dict
    assert 'foo' in data and data['foo'] == 42

# Generated at 2022-06-23 05:40:34.681081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_input = """
- hosts: all
  gather_facts: False
  tasks:
  - name: test
    shell: /bin/false
    no_log: True
    when:
    - test1
    - test2
    - test3
"""

    loader = AnsibleLoader(my_input)
    data = loader.get_single_data()
    hosts = data['hosts']
    gather_facts = data['gather_facts']
    assert hosts == 'all'
    assert gather_facts == False
    tasks = data['tasks']
    task = tasks[0]
    assert task['name'] == 'test'
    assert task['shell'] == '/bin/false'
    assert task['no_log'] == True
    assert task['when'] == ['test1', 'test2', 'test3']

# Generated at 2022-06-23 05:40:35.299598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:40:44.440139
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence


# Generated at 2022-06-23 05:40:50.836178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import load_yaml
    text = load_yaml('admin.yml')
    loader = AnsibleLoader(text)
    print(loader)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:40:58.712637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''[
        {   a: 1
        },
        {
            a: 1
        }
    ]'''
    loader = AnsibleLoader(stream, file_name="test_file")
    assert isinstance(loader, AnsibleLoader)
    assert loader.stream == stream
    assert loader.parser == Parser
    assert loader.composer == Composer
    assert loader.constructor == AnsibleConstructor
    assert loader.resolver == Resolver


# Generated at 2022-06-23 05:41:03.610194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "!!python/object/new:module.ClassName {key: value}"
    loader = AnsibleLoader(data)
    loader.get_single_data()

# Generated at 2022-06-23 05:41:11.894126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.errors import AnsibleParserError

    try:
        from yaml.nodes import MappingNode
    except ImportError:
        from yaml.nodes import MappingNode

    # test for `sequence_add` method
    loader = AnsibleLoader(None)
    data = AnsibleSequence()
    node = MappingNode(None, None, False, None, None)
    node.value = [('key', 'value')]


# Generated at 2022-06-23 05:41:21.351364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from six import StringIO
    import unittest.mock as mock

    my_data = """
    - hosts: all
      tasks:
      - name: test
        debug:
            msg: hello world
    """

    mock_vault = mock.Mock()
    loader = AnsibleLoader(StringIO(my_data), vault_secrets=mock_vault)
    parsed_data = loader.get_single_data()
    assert parsed_data == [{
        u'hosts': u'all',
        u'tasks': [{u'debug': {u'msg': u'hello world'}, u'name': u'test'}]}]
    mock_vault.get_decrypted_value.assert_not_called()

# Generated at 2022-06-23 05:41:27.361993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = "---\n" + \
            "1\n" + \
            "---\n" + \
            "2\n" + \
            "---\n" + \
            "3\n"
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == 1
    assert loader.get_single_data() == 2
    assert loader.get_single_data() == 3

# Generated at 2022-06-23 05:41:33.792918
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=no-member
    stream = u'[1, 2, 3]'
    al = AnsibleLoader(stream)
    assert al.construct_yaml_seq == getattr(AnsibleConstructor, 'construct_yaml_seq', None)
    assert al.construct_yaml_map == getattr(AnsibleConstructor, 'construct_yaml_map', None)

# Generated at 2022-06-23 05:41:35.690520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    load = AnsibleLoader(None)
    assert hasattr(load, 'construct_yaml_undefined')

# Generated at 2022-06-23 05:41:38.041741
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream=None
    file_name=None
    vault_secrets=None
    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-23 05:41:48.512891
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib


# Generated at 2022-06-23 05:41:51.233195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    if HAS_LIBYAML:
        loader = AnsibleLoader('')
    else:
        loader = AnsibleLoader('')

# Generated at 2022-06-23 05:41:58.170330
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Following yaml should load to same python structure
    #
    # a: 1
    # b:
    #   c: 3
    #   d: 4
    data1 = '\n'.join((
        'a: 1',
        'b:',
        '  c: 3',
        '  d: 4',
    ))
    data2 = '\n'.join((
        'a:1',
        'b : { c : 3, d : 4 }',
    ))
    loader = AnsibleLoader(data1)
    d1 = loader.get_single_data()
    loader = AnsibleLoader(data2)
    d2 = loader.get_single_data()
    assert d1 == d2
