

# Generated at 2022-06-23 05:32:00.206116
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import tempfile

    # Test with empty data
    str_empty = "     "
    temp_file = tempfile.TemporaryFile()
    temp_file.write(str_empty.encode(encoding='utf_8'))
    temp_file.seek(0)
    loader = AnsibleLoader(temp_file)
    assert loader.get_single_data() is None

    # Test with data
    str_normal = "---\ntest: 1\n"
    temp_file = tempfile.TemporaryFile()
    temp_file.write(str_normal.encode(encoding='utf_8'))
    temp_file.seek(0)
    loader = AnsibleLoader(temp_file)
    assert loader.get_single_data() == {'test': 1}

# Generated at 2022-06-23 05:32:07.995510
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:32:17.631577
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.module_utils.basic import json


# Generated at 2022-06-23 05:32:20.926725
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
         - 123
         - abcd
         - {a:1,b:3}
    """
    l = AnsibleLoader(stream)
    l.get_single_data()
    l.dispose()

# Generated at 2022-06-23 05:32:24.370208
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create mock stream object
    stream = None

    # Create AnsibleLoader object
    ansible_loader_obj = AnsibleLoader(stream)

    # Check if AnsibleLoader object is created
    assert ansible_loader_obj is not None

# Generated at 2022-06-23 05:32:31.837246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader.get_single_data() is None
    # Test a simple case
    loader = AnsibleLoader('name2: value2')
    assert loader.get_single_data() == {'name2': 'value2'}
    # Test a int case
    loader = AnsibleLoader('name: 1')
    assert loader.get_single_data() == {'name': 1}
    # Test a Ipv4 case
    loader = AnsibleLoader('name: 1.1.1.1')
    assert loader.get_single_data() == {'name': '1.1.1.1'}
    # Test a Ipv6 case
    loader = AnsibleLoader('name: ::1')

# Generated at 2022-06-23 05:32:33.695258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(None)
    except TypeError:
        pass

# Generated at 2022-06-23 05:32:38.475632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    input_str = '''
      - include: my_file
'''
    input_stream = StringIO(input_str)
    loader = AnsibleLoader(input_stream)

    data = loader.get_single_data()
    assert data[0]['include'] == 'my_file'

# Generated at 2022-06-23 05:32:43.273641
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test to make sure we can construct an AnsibleLoader object without crashing.
    """
    import io
    stream = io.BytesIO('\x00\x01\x02\x03')
    loader = AnsibleLoader(stream)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:32:43.895582
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:32:47.047533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '---\nkey: value\n'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'key': 'value'}

# Generated at 2022-06-23 05:32:48.503972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Testing the constructor of class AnsibleLoader'''
    pass

# Generated at 2022-06-23 05:32:58.217929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    my_string = AnsibleVaultEncryptedUnicode(value='my_password')
    loader = AnsibleLoader('')
    data = loader.construct_yaml_str(my_string)

# Generated at 2022-06-23 05:33:00.844757
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)

# Generated at 2022-06-23 05:33:01.390111
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:02.118390
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:09.555045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml

    class MockObject(object):
        pass

    data = {'obj': MockObject()}
    data['obj']._yaml_base_class = MockObject

    # Create the loader
    loader = yaml.AnsibleLoader(yaml.dump(data))

    # Load the yaml
    yaml_data = loader.get_single_data()

    # Assert the object was properly constructed
    assert isinstance(yaml_data['obj'], MockObject)
    assert isinstance(yaml_data, AnsibleMapping)

# Generated at 2022-06-23 05:33:15.421134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the example given in the docstring
    """
    data = """
---
# given:
- { b: 2, c: 3, a: 1 }
- 1

# expect:
- a: 1
  b: 2
  c: 3
- - 1
"""

    result = yaml.load(data, Loader=AnsibleLoader)
    assert result[0] == dict(a=1, b=2, c=3)
    assert result[1] == [1]

# Generated at 2022-06-23 05:33:16.743195
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(None), AnsibleLoader)

# Generated at 2022-06-23 05:33:24.928539
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    test_str = "---\n" \
               "key: !include vault_test.yaml\n"

    vault_secrets = [
        {
            "secret_id": "test.yaml",
            "contents": "file_content"
        }
    ]

    class MockVault:
        def load_vault_file(self, path):
            return "vault_content"

    AnsibleLoader(test_str, vault_secrets=vault_secrets).get_single_data()

# Generated at 2022-06-23 05:33:31.685789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import BytesIO
    content = b'{"a": "b"}'
    buf = BytesIO(content)
    stream = [_f for _f in buf.read().splitlines()]
    assert stream == [b'{"a": "b"}']
    yaml = AnsibleLoader(stream, 'test.yml')
    assert yaml.construct_document(yaml.get_node(False, None, None)) == {'a': 'b'}



# Generated at 2022-06-23 05:33:40.564020
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # First, we will do basic tests for AnsibleLoader
    stream = u"foo: [1, 2, 3]\n"
    stream_len = len(stream)

    # We are now going to test the Reader class, since it is a base class of AnsibleLoader
    assert not AnsibleLoader(stream).check_stream(None)

    # Now, we set stream to a Reader object
    stream = Reader(stream)

    # Test the Reader class' attributes
    assert stream.name == u'<unicode string>'
    assert stream.encoding == u'utf-8'
    assert stream.buffer == u'foo: [1, 2, 3]\n'
    assert stream.index == 0
    assert stream.line == 0
    assert stream.column == 0
    assert stream.pointer == 0

    # Now, we test Reader

# Generated at 2022-06-23 05:33:48.632152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = r'''
- hosts: localhost
  connection: local
  tasks:
    - dd:
        path: /dev/null
        count: 1
        bs: 1M
      register: dd
    - fail:
        msg: "{{dd.failed}}"
'''
    loader = AnsibleLoader(stream)
    dct = loader.get_single_data()
    assert dct is not None
    assert 'hosts' in dct
    assert dct['hosts'] == 'localhost'
    assert 'connection' in dct
    assert dct['connection'] == 'local'
    assert 'tasks' in dct
    assert isinstance(dct['tasks'], list)
    assert len(dct['tasks']) == 2

# Generated at 2022-06-23 05:34:00.022401
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    data = yaml.load('''
        - hosts: all
          vars:
            str: "{{ ansible_hostname }}"
            list:
            - {{ ansible_hostname }}
            - bar
            dict:
              foo: "{{ ansible_hostname }}"
              bar: "baz"
          tasks:
          - debug:
              msg: "{{ item }}"
            with_items:
            - "{{ str }}"
            - "{{ list }}"
            - "{{ dict }}"
    ''', Loader=AnsibleLoader)

# Generated at 2022-06-23 05:34:09.434106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = """
key: value
unicode_value: "{{alias('passed')}}"
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert isinstance(data['unicode_value'], AnsibleUnicode)
    assert data['unicode_value']._data == "{{alias('passed')}}"
    assert data['unicode_value']._volatile is True

    loader._vault_secrets = ['passed']

    data = loader.get_single_data()
    assert isinstance(data['unicode_value'], AnsibleUnicode)
    assert data['unicode_value']._data == u'passed'

# Generated at 2022-06-23 05:34:19.598024
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    # Test a custom tag
    yaml_str = "{foo: !TaggedEntry [1, 2]}"
    data = yaml.safe_load(yaml_str)
    t = data.get("foo")
    assert type(t) == type(1), "TaggedEntry constructor did not work"

    # Test a non-native python scalar
    assert type(data.get("foo")) != type(dict())

    # Test a non-native python scalar
    yaml_str = "foo: !!python/name:time.asctime\ndate: 'Sat Mar  7 23:03:32 2009'"
    data = yaml.safe_load(yaml_str)

# Generated at 2022-06-23 05:34:21.277172
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader), 'loader instance should be of its class'

# Generated at 2022-06-23 05:34:31.828319
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import VaultLibYAMLLoader, VaultLoader
    if HAS_LIBYAML:
        vault_loader = VaultLibYAMLLoader
    else:
        vault_loader = VaultLoader

    #TEST: create AnsibleVaultEncryptedUnicode and
    #      construct return value
    with open('test/ansible-vault-secret') as fin:
        stream = fin.read()
    ansible_vault_encrypted_unicode = AnsibleVaultEncryptedUnicode(stream)
    ret = AnsibleLoader.construct_yaml_str(None, ansible_vault_encrypted_unicode)

# Generated at 2022-06-23 05:34:36.024150
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    test:
        - string
    '''
    d = AnsibleLoader(data)
    d.get_single_data()
    assert d._vault_secrets is None

# Generated at 2022-06-23 05:34:46.198246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-23 05:34:49.276255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)
    assert hasattr(loader, 'construct_yaml_map')

# Generated at 2022-06-23 05:34:50.724722
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:35:00.579231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable
    # pylint: disable=no-init
    # pylint: disable=unused-argument
    class CustomDumper():
        def __init__(self):
            pass

    class CustomConstructor():
        def __init__(self):
            pass

    class CustomResolver():
        def __init__(self):
            pass

    class CustomReader():
        def __init__(self):
            pass

    class CustomScanner():
        def __init__(self):
            pass

    class CustomParser():
        def __init__(self):
            pass

    class CustomComposer():
        def __init__(self):
            pass

    class CustomRepresenter():
        def __init__(self):
            pass


# Generated at 2022-06-23 05:35:09.013267
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_constructor = AnsibleLoader(None)
    assert test_constructor._vault_secrets == None
    assert test_constructor._file_name == None
    assert test_constructor._construct_yaml_set == False
    assert test_constructor._construct_yaml_omap == False
    assert test_constructor._construct_yaml_str == False
    assert test_constructor._construct_yaml_seq == False
    assert test_constructor._construct_yaml_int == False
    assert test_constructor._construct_yaml_bool == False
    assert test_constructor._construct_yaml_map == False
    assert test_constructor._construct_yaml_pairs == False
    assert test_constructor._construct_yaml_binary == False
    assert test_constructor._construct_yaml_

# Generated at 2022-06-23 05:35:19.147512
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars

    # construct class AnsibleLoader
    data_loader = AnsibleLoader(None)
    data_loader_1 = AnsibleLoader(None, file_name="/etc/ansible/hosts")
    data_loader_2 = AnsibleLoader(None, file_name="/etc/ansible/hosts", vault_secrets={"vault_secret_1":"secret_1", "vault_secret_2":"secret_2"})

    # load construction values
    file_name = data_loader.file_name
    file_name_1 = data_loader_1.file_name
    file_name_2 = data_loader_2.file_name
    vault_secrets = data_loader.v

# Generated at 2022-06-23 05:35:21.136836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:35:27.644899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    parent = AnsibleLoader({'foo': '{{ bar }}', 'bar': 'baz'}, vault_secrets={"vault_password_file": "/tmp"})
    print(parent.get_single_data())
    # {'foo': u'baz', 'bar': u'baz'}

# Generated at 2022-06-23 05:35:32.055920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file = '../../../../.travis.yml'
    loader = AnsibleLoader(open(test_file))
    all_data = loader.get_single_data()

    for key, value in all_data.items():
        print(key, value)

# Generated at 2022-06-23 05:35:42.795590
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    test_yaml = io.StringIO('''\
---
- hosts: localhost
  vars:
    key: val
  tasks:
    - debug:
        msg: "test"
    - include_vars:
        file: other.yml''')
    loader = AnsibleLoader(test_yaml)
    data = loader.get_single_data()
    assert data[0]['hosts'] == 'localhost'
    assert data[0]['vars']['key'] == 'val'
    assert data[0]['tasks'][0]['debug']['msg'] == 'test'
    assert data[0]['tasks'][1]['include_vars']['file'] == 'other.yml'

# Generated at 2022-06-23 05:35:54.020433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    from ansible.parsing.yaml.constructor import AnsibleConstructor

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    # Test constructor
    assert AnsibleConstructor
    data = AnsibleConstructor(StringIO(''))
    assert data.file_name is None
    assert data.vault_secrets is None
    assert data.objects == []

    # Test AnsibleConstructor
    x = AnsibleConstructor()
    assert x
    x = AnsibleConstructor(StringIO(''))
    assert x
    x = AnsibleConstructor(vault_secrets='value')
    assert x.vault_secrets == 'value'

# Generated at 2022-06-23 05:36:02.035001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    constructors = dict(getattr(sys.modules[__name__], '__dict__', {}))
    constructors.update(getattr(AnsibleLoader, '__dict__', {}))
    assert constructors['AnsibleConstructor'].__init__ == getattr(AnsibleConstructor, '__init__')
    assert constructors['Resolver'].__init__ == getattr(Resolver, '__init__')
    if HAS_LIBYAML:
        parser = Parser
    else:
        parser = Parser
    assert constructors['Parser'].__init__ == getattr(parser, '__init__')

# Generated at 2022-06-23 05:36:04.821608
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class test_loader(AnsibleLoader):
        pass
    tl = test_loader
    obj = tl({'foo':'bar'})
    assert type(obj) == dict
    assert obj.get('foo') == 'bar'

# Generated at 2022-06-23 05:36:09.212758
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():    # pylint: disable=invalid-name
    src = '''
    ---
    foo: bar
    '''
    loader = AnsibleLoader(src, vault_secrets=dict(doesnt_matter=42))
    for data in loader:
        break
    assert data['foo'] == 'bar'

# Generated at 2022-06-23 05:36:17.504834
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    list_prefix = "&"
    list_start = "<"
    stream = None
    file_name=None
    vault_secrets=None
    ansible_constructor = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    ansible_constructor.list_prefix = list_prefix
    ansible_constructor.list_start = list_start
    assert ansible_constructor.list_prefix == list_prefix
    assert ansible_constructor.list_start == list_start
    # assert False # TODO: implement your test here

# Generated at 2022-06-23 05:36:24.425433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = '''
        - file: /tmp/{{foo}}
          state: directory
          mode: "0644"

        - file: /tmp/bar
          state: directory
          mode: "0644"
    '''

    data = AnsibleLoader(yaml).get_single_data()

    assert data is not None
    assert data[0]['mode'] == "0644"
    assert data[1]['file'] == "/tmp/bar"

# Generated at 2022-06-23 05:36:27.052637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: improve this unit test.
    loader = AnsibleLoader(None)
    try:
        assert loader
    except AssertionError:
        assert False

# Generated at 2022-06-23 05:36:30.095280
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    This test makes sure that we can construct an AnsibleLoader object without
    raising any exceptions.
    """
    loader = AnsibleLoader(None)
    assert type(loader) is AnsibleLoader

# Generated at 2022-06-23 05:36:31.128306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # No exceptions should be raised
    AnsibleLoader(None)

# Generated at 2022-06-23 05:36:31.700502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:36:35.740975
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    text = "text:\n  ansible: test\n  un: test"
    expected = {'text': {'ansible': 'test', 'un': 'test'}}

    loader = AnsibleLoader(text)
    data = loader.get_single_data()
    assert data == expected



# Generated at 2022-06-23 05:36:38.907065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.loader import AnsibleLoader

    assert DataLoader._loader_class == AnsibleLoader

# Generated at 2022-06-23 05:36:48.199597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = {'string': 'foo', 'number': 123, 'plain_dict': {'key': 'value'}, 'list': [1, 2, 3]}
    vault_secrets = [{'password': 'secret', 'name': 'vault_secret'}]
    vault_editor = VaultEditor(vault_secrets, 'yaml')
    data_encoded = vault_editor.encode(data)
    loader = AnsibleLoader(data_encoded, file_name='<ansible-vault>')
    data_decoded = loader.get_single_data()

# Generated at 2022-06-23 05:36:57.821452
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
{
  "cisco": {
    "host": "cisco.domain.com",
    "username": "cisco_user",
    "password": "cisco_password"
  },
  "juniper": {
    "host": "juniper.domain.com",
    "username": "juniper_user",
    "password": "juniper_password"
  }
}
'''
    loader = AnsibleLoader(stream, file_name='<string>')
    loader = loader.get_single_data()
    assert loader["cisco"]["host"] == "cisco.domain.com"
    assert loader["cisco"]["username"] == "cisco_user"
    assert loader["cisco"]["password"] == "cisco_password"

# Generated at 2022-06-23 05:36:59.272181
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:37:09.671874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    ansible.parsing.yaml.loader.AnsibleLoader
    """
    import datetime
    import ansible.parsing.yaml.loader
    dt = datetime.datetime(2001, 2, 3, 4, 5, 6, 123456)
    data = {
        'a': dt,
        'b': "%Y-%m-%d %H:%M:%S.%f" % (dt.timetuple()),
    }
    output = ansible.parsing.yaml.loader.AnsibleLoader(data).get_data()
    assert output['a'] == dt
    assert output['b'] == "%Y-%m-%d %H:%M:%S.%f" % (dt.timetuple())

# Generated at 2022-06-23 05:37:20.552933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unicode import to_unicode
    import ansible.parsing.yaml.objects


# Generated at 2022-06-23 05:37:31.765952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class FakeArgs(object):
        flag_vault_ids = None

    fake_args = FakeArgs()


# Generated at 2022-06-23 05:37:44.099219
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    try:
        from yaml import CLoader as Loader
    except ImportError:
        from yaml import Loader

    sample = """
---
host: testhost
user: root
become: false
vars:
  var1: "{{ansible_distribution}}"
  var2: "{{ansible_distribution_version}}"
"""

    loader = AnsibleLoader(sample, file_name='/dev/null')
    assert isinstance(loader, Loader)

    data = loader.get_single_data()
    assert isinstance(data, dict)
    assert 'host' in data
    assert 'user' in data
    assert 'become' in data
    assert 'vars' in data
    assert 'var1' in data['vars']
    assert 'var2' in data['vars']



# Generated at 2022-06-23 05:37:53.456532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_str = """---
    - hosts: something
      vars:
          to_be_inherited: "{{ myVar }}"
          myVar: ansssssswer
      tasks:
      - name: "debug inherite"
        debug:
            msg: "{{ to_be_inherited }}"
    """

    result = AnsibleLoader(yaml_str).get_single_data()
    assert result['hosts'] == "something"
    assert result['vars']['to_be_inherited'] == "{{ myVar }}"
    assert result['vars']['myVar'] == "anssssssswer"

# Generated at 2022-06-23 05:37:58.561046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.compat import StringIO

    stream = StringIO('[1, 2, 3]')
    # Should not fail
    AnsibleLoader(stream)
    stream = StringIO('{a: b}')
    # Will fail without the exception handling in AnsibleConstructor
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:37:59.870491
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-23 05:38:00.637673
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:04.920371
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:09.029724
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    invalid_data = """
    - hosts: all
      vars:
        foo: bar
        bar:
          - %s
          - 10
          - 20
    """
    with pytest.raises(AnsibleParserError):
        AnsibleLoader(invalid_data % "foo").get_single_data()

# Generated at 2022-06-23 05:38:11.771098
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
    foo: "bar"
    """

    my_loader = AnsibleLoader(data)
    assert isinstance(my_loader, AnsibleLoader)

# Generated at 2022-06-23 05:38:13.274249
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None, None, None)

# Generated at 2022-06-23 05:38:16.669046
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    data = "some text"
    filename = "somefilename"
    vault_secrets = ["vault_pw"]
    a = AnsibleLoader(data, filename, vault_secrets)

# Generated at 2022-06-23 05:38:18.761190
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    pass

# Generated at 2022-06-23 05:38:26.894010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.module_utils.common.yaml import AnsibleLoader

    test_stream = '#/bin/ansible: ansible'
    test_file_name = 'file.yml'
    test_vault_secrets = {'vault_secret_1': 'password_1', 'vault_secret_2': 'password_2'}

    # test instantiation of an AnsibleLoader object
    AnsibleLoader(test_stream, test_file_name, test_vault_secrets)


# Generated at 2022-06-23 05:38:29.462194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b'foo: bar\n')
    foo = loader.get_single_data()
    assert foo == {'foo': 'bar'}


# Generated at 2022-06-23 05:38:38.296996
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError
    from yaml.composer import ComposerError
    from yaml.constructor import ConstructorError
    from yaml.reader import ReaderError
    from yaml.resolver import ResolverError

    try:
        AnsibleLoader('abc string')
    except TypeError as e:
        assert isinstance(e, TypeError)
        assert 'expected str instance, not unicode' in str(e)
    except AttributeError as e:
        assert isinstance(e, AttributeError)
        assert 'non-printable unicode' in str(e)
    except ScannerError as e:
        assert isinstance(e, ScannerError)
        assert 'not proper unicode' in str(e)

# Generated at 2022-06-23 05:38:42.380720
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    yaml.safe_load("{'key': 'value'}")
    print("AnsibleLoader constructor was called")

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:38:47.390585
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # type: () -> None
    stream = u"{a: 1}\n"
    stream = stream.encode('utf-8')
    loader = AnsibleLoader(stream)

    # get the first node of the stream
    data = loader.get_single_data()
    assert 'a' in data
    assert data['a'] == 1

# Generated at 2022-06-23 05:38:58.863787
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader('hello')
    results = loader.get_single_data()
    assert results == 'hello'
    loader = AnsibleLoader('"hello"')
    results = loader.get_single_data()
    assert results == 'hello'
    loader = AnsibleLoader('"hel\'lo"')
    results = loader.get_single_data()
    assert results == "hel'lo"
    loader = AnsibleLoader('\'hel"lo\'')
    results = loader.get_single_data()
    assert results == 'hel"lo'
    loader = AnsibleLoader('hello: world')
    results = loader.get_single_data()
    assert results == {'hello': 'world'}
    loader = AnsibleLoader('[hello, world]')
    results = loader.get_single_data()
   

# Generated at 2022-06-23 05:39:00.040739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_loader = AnsibleLoader(None)


# Generated at 2022-06-23 05:39:09.078223
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_data = AnsibleLoader(open(__file__, 'r')).get_single_data()
    assert isinstance(my_data, dict)
    assert 'my_data' in my_data
    assert 'stream' in my_data
    assert 'file_name' in my_data
    assert 'vault_secrets' in my_data
    assert my_data['my_data'] == 'my_data'
    assert my_data['stream'] == 'stream'
    assert my_data['file_name'] == 'file_name'
    assert my_data['vault_secrets'] == 'vault_secrets'

# Generated at 2022-06-23 05:39:20.612633
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    import tempfile
    tf = tempfile.NamedTemporaryFile()
    tf.write(b"a: 1\nb: [2,3,4]")
    tf.seek(0)

    loader = AnsibleLoader(file_name=tf.name)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['a'], AnsibleUnicode)
    assert isinstance(data['b'], AnsibleSequence)
    assert len(data) == 2

# Generated at 2022-06-23 05:39:31.577224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('[1,2,3]')
    data = loader.get_single_data()
    assert data == [1, 2, 3]

    loader = AnsibleLoader('foo: [1,2,3]')
    data = loader.get_single_data()
    assert data == {'foo': [1, 2, 3]}

    # data_merge test
    loader = AnsibleLoader('---\n{}')
    data_merge = {'bar': [7, 8, 9]}
    loader.set_data_merge(data_merge)
    data = loader.get_single_data()
    assert data == {'bar': [7, 8, 9]}

# Generated at 2022-06-23 05:39:36.298286
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test with empty string
    data = u''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == []

    # Test with simple string
    data = u'foo'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == 'foo'



# Generated at 2022-06-23 05:39:46.363929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # AnsibleVaultEncryptedUnicode must be pickleable
    from cPickle import dumps, loads
    val = AnsibleVaultEncryptedUnicode("foo")
    new_val = loads(dumps(val))
    assert val == new_val

    # Dumper should generate comments for AnsibleVaultEncryptedUnicode
    assert AnsibleDumper(None, default_style=None, default_flow_style=None).represent_scalar('!vault', val, style='|')

# Generated at 2022-06-23 05:39:56.485843
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.vault_secrets is None
    assert loader.file_name is None
    loader = AnsibleLoader(None, vault_secrets=None)
    assert loader.vault_secrets is None
    assert loader.file_name is None
    loader = AnsibleLoader(None, file_name="file.yml")
    assert loader.vault_secrets is None
    assert loader.file_name == "file.yml"
    loader = AnsibleLoader(None, file_name="file.yml", vault_secrets={'password': "foo"})
    assert loader.vault_secrets == {'password': "foo"}
    assert loader.file_name == "file.yml"

# Generated at 2022-06-23 05:40:07.765524
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load, dump

    yaml_str = '''
    key: value
    list: [ item1, item2 ]
    empty_list: []
    empty_dict: {}
    dict: { key: value }
    string: "string"
    int: 1
    float: 2.3
    '''
    yaml_data = load(yaml_str)
    assert isinstance(yaml_data, dict)

    assert yaml_data['key'] == 'value'
    assert yaml_data['list'] == [ 'item1', 'item2' ]
    assert yaml_data['empty_list'] == []
    assert yaml_data['empty_dict'] == {}
    assert yaml_data['dict'] == { 'key': 'value' }
   

# Generated at 2022-06-23 05:40:10.504296
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader({"a":1})
    assert loader.get_single_data() == {"a":1}

# Generated at 2022-06-23 05:40:13.420149
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''
        ---
        '''
    loader = AnsibleLoader(s)
    assert(isinstance(loader, AnsibleConstructor))
    loader.get_data()

# Generated at 2022-06-23 05:40:16.980451
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from .__init__ import AnsibleLoader
    file_name = 'test.yaml'
    stream = open(file_name, 'r')
    loader = AnsibleLoader(stream, vault_secrets=None)
    #print(loader)
    pass

# Generated at 2022-06-23 05:40:23.231246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    # This will fail if AnsibleLoader is not a class
    assert issubclass(AnsibleLoader, Parser)
    # This will fail if AnsibleLoader is not a class
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    # This will fail if AnsibleLoader is not a class
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-23 05:40:24.725943
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader(''), AnsibleLoader)

# Generated at 2022-06-23 05:40:27.228729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Call dummy method, no exception should be raised
    AnsibleLoader(None).get_single_data()


import unittest


# Generated at 2022-06-23 05:40:29.968458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')
    assert hasattr(AnsibleLoader, '_construct_yaml_map')



# Generated at 2022-06-23 05:40:32.361534
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = """
    ---
    this is a test
    """
    loader = AnsibleLoader(stream, vault_secrets=[], file_name='foo')

# Generated at 2022-06-23 05:40:43.069889
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    var_manager_dict = { 'inventory': inventory, '_fact_cache': {} }
    testObj = AnsibleLoader(None, file_name='test_file/file.yml', vault_secrets=['vault_word']).get_single_data()

# Generated at 2022-06-23 05:40:56.587110
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  from ansible.parsing.yaml.objects import AnsibleUnicode
  from ansible.parsing.yaml.loader import AnsibleLoader

  data = 'hello: world'
  ansible_loader = AnsibleLoader(data)
  data = ansible_loader.get_single_data()

  assert(isinstance(data, dict))
  assert('hello' in data)
  assert(isinstance(data['hello'], AnsibleUnicode))
  assert(data['hello'] == 'world')

  data = 'hello: [world]'
  ansible_loader = AnsibleLoader(data)
  data = ansible_loader.get_single_data()

  assert(isinstance(data, dict))
  assert('hello' in data)
  assert(isinstance(data['hello'], list))

# Generated at 2022-06-23 05:41:05.886903
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:41:12.800344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    import os

    vault_pass = os.environ['VAULT_PASS']
    vault_secrets = [{'secret': vault_pass}]


# Generated at 2022-06-23 05:41:16.421309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    data = StringIO(u'{"hello": "world"}')
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {"hello": "world"}



# Generated at 2022-06-23 05:41:26.732963
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import types


# Generated at 2022-06-23 05:41:36.102986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    data = '''
    foo: &foo
      bar: 1
      bam: 2
    bar: *foo
    baz: 3'''

    loader = AnsibleLoader(data)
    datamap = loader.get_single_data()
    assert isinstance(datamap['foo'], dict)
    assert isinstance(datamap['foo']['bar'], int)
    assert isinstance(datamap['foo']['bam'], int)
    assert isinstance(datamap['bar']['bar'], int)
    assert isinstance(datamap['bar']['bam'], int)
    assert isinstance(datamap['baz'], int)

# Generated at 2022-06-23 05:41:38.158862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test construction of class AnsibleLoader
    AnsibleLoader("StreamParser")


# Generated at 2022-06-23 05:41:48.609504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # No one should test class AnsibleLoader directly except `test_AnsibleLoader` function.
    # If someone tests this class directly, it causes fatal bug that continue looping.
    assert test_AnsibleLoader.__name__ == 'test_AnsibleLoader'

    # for Python 2.6
    if not HAS_LIBYAML:
        from yaml.composer import Composer

        # This is workaround to build test_AnsibleLoader. Because loading class AnsibleLoader causes looping.
        # So loading class AnsibleLoader before defining class TestComposer.
        # This is a new class that overrides `AnsibleLoader._compose_node` method.

# Generated at 2022-06-23 05:41:51.334481
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(None)
    except TypeError:
        pass
    else:
        raise AssertionError("no exception raised")