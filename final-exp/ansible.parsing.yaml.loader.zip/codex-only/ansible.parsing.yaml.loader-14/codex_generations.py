

# Generated at 2022-06-23 05:32:01.537965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # Create an AnsibleLoader object
    al = AnsibleLoader(None)
    assert al is not None

    #
    # Create a second AnsibleLoader object with one parameter (None)
    al = AnsibleLoader(None, "my_file")
    assert al is not None

    #
    # Create a third AnsibleLoader object with a vault_secrets parameter
    class VaultSecret:
        def __init__(self):
            self.vault_secrets = ['foo']
    al = AnsibleLoader(None, vault_secrets=VaultSecret())
    assert al is not None

    #
    # Create a fourth AnsibleLoader object with a vault_secrets parameter
    class VaultSecret:
        def __init__(self):
            self.vault_secrets = [None]

# Generated at 2022-06-23 05:32:08.481420
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils._text import to_text
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    datadict = dict(
        a="foo",
        b="bar",
        c={"c1": "hello"},
        d=[1, 2, 3, 4],
        e=ImmutableDict((('key', 'value'), ('otherkey', 'othervalue'))),
        f=AnsibleUnicode("baz")
    )

    data = to_text(AnsibleDumper(sort_keys=True).encode(datadict), errors='surrogate_then_replace')

# Generated at 2022-06-23 05:32:17.949215
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

# Generated at 2022-06-23 05:32:21.607181
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  import sys
  if sys.version_info[0] > 2:
    stream = open('/dev/null', 'r', encoding='utf-8')
  else:
    stream = open('/dev/null', 'r')
  assert AnsibleLoader(stream)

# Generated at 2022-06-23 05:32:24.277978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    loader = AnsibleLoader(StringIO(u'---\n- test'))
    assert loader.get_single_data() == ['test']

# Generated at 2022-06-23 05:32:29.947674
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test empty stream
    assert list(AnsibleLoader('')) == []
    # test a stream with a single document
    assert list(AnsibleLoader('[]')) == [[]]
    # test a stream with two documents
    assert list(AnsibleLoader('{}\n{}')) == [{}, {}]
    # test a stream with three documents
    assert list(AnsibleLoader('{}\n{}\n{}\n')) == [{}, {}, {}]

# Generated at 2022-06-23 05:32:39.716532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    a = AnsibleLoader(b'foo: bar')
    assert (isinstance(a.get_single_data(), dict))
    assert (isinstance(next(iter(a.get_single_data())), AnsibleUnicode))
    data = a.get_single_data()
    assert (data['foo'] == 'bar')
    # Regression test for Issue #5826
    a = AnsibleLoader(b'"foo: bar"')
    assert (isinstance(a.get_single_data(), AnsibleUnicode))
    assert (a.get_single_data() == 'foo: bar')

# Generated at 2022-06-23 05:32:44.804489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    sample = """
        - hosts: 127.0.0.1
          gather_facts: False
          vars:
            key1: val1
            key2: val2
          tasks:
          - set_fact:
              key1: newval1
          - set_fact:
              key2: newval2
    """
    test_object = AnsibleLoader(sample)

    assert 'gather_facts' in test_object.get_single_data()
    assert 'key1' in test_object.get_single_data()['vars']

# Generated at 2022-06-23 05:32:45.491387
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()

# Generated at 2022-06-23 05:32:46.113988
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:32:51.268008
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_obj = AnsibleLoader(stream='test_stream', file_name='test_filename', vault_secrets='test_vault_secrets')
    assert test_obj.stream == 'test_stream'
    assert test_obj.file_name == 'test_filename'
    assert test_obj.vault_secrets == 'test_vault_secrets'

# Generated at 2022-06-23 05:33:01.591235
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # Test the AnsibleLoader object
    test_string = b'\xef\xbb\xbf- hosts: localhost\n\n' \
                  b'  vars:\n\n' \
                  b'    var: "{{ lookup(\'pipe\', \'echo hello\') }}"\n\n'
    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp.write(test_string)

    with open(temp.name) as temp_yml:

        try:
            data = AnsibleLoader(temp_yml).get_single_data()
        finally:
            os.unlink(temp.name)


# Generated at 2022-06-23 05:33:02.543948
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:33:07.782870
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open(os.path.join(os.path.dirname(__file__), '../../lib/ansible/playbook/__init__.py'), 'rb')
    loader = AnsibleLoader(stream)

    stream.close()
    assert(loader.stream == None)
    assert(loader.file_name == None)
    assert(loader.vault_secrets == None)

# Generated at 2022-06-23 05:33:16.818551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.data import DataLoader
    from ansible.vars import VariableManager
    load = AnsibleLoader(dict(a=1, b=dict(c=3, d=4)), variable_manager=VariableManager())
    assert isinstance(load.get_single_data(), AnsibleBaseYAMLObject)
    assert load.get_single_data().a == 1
    assert load.get_single_data().b.c == 3
    loader = DataLoader()
    assert isinstance(loader.load(dict(a=1, b=dict(c=3, d=4))), AnsibleBaseYAMLObject)

# Generated at 2022-06-23 05:33:28.021624
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    results = loader.load('''
    - name: "james bond"
      password: $6$AFgEiwQc$K0uLNQeVCRXuMjA8T7y4p.Yz4IjKmD0mV7KjJpGtjZL9yyvhrtWLHuJhP2YlYCbAAeqvw8WnDtZ1JbZjb9XFd/
      state: present
    - name: "moneypenny"
      password: test
      state: absent
    ''')


# Generated at 2022-06-23 05:33:30.571125
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestClass:
        pass

    loader = AnsibleLoader(None)
    assert TestClass == loader.construct_yaml_map(None, TestClass)

# Generated at 2022-06-23 05:33:33.788000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("""\
some_key:
  - some_item
  - some_other_item""")
    loader.get_single_data()

# Generated at 2022-06-23 05:33:42.704432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.template import Templar
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.collections import ImmutableDict
    logger = None
    loader = AnsibleLoader(None)

    # These aren't actually used, but we need to pass them
    inventory = None
    variables = combine_vars(loader=loader, templar=Templar(loader=loader, inventory=inventory))
    all_vars = variables

    # These are taken from the above examples
    args = {
        'test_arg': 'My arg',
        'result': True,
        'test_arg_2': {
            'test': 'Test arg 2',
        },
        'test_arg_3': 'My arg 3',
    }

# Generated at 2022-06-23 05:33:53.546206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError
    from yaml.composer import ComposerError
    from yaml.constructor import ConstructorError
    from yaml.resolver import ResolverError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import UnsafeProxy

    # Use a default value for vault_secrets
    vault_secrets = [(None, None)]

    # Check that ScannerError, ParserError, ComposerError, ConstructorError and ResolverError are handled
    reader = AnsibleLoader('', vault_secrets=vault_secrets)
    reader.dispose()


# Generated at 2022-06-23 05:34:04.569038
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-branches
    '''test AnsibleLoader'''

    import collections
    import copy
    import datetime
    import os
    import shutil
    import tempfile
    import textwrap
    import time

    from ansible import constants as C
    from ansible.module_utils.common.yaml import make_yaml_safe, strip_yaml_comments, yaml_encode
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    yaml_loader = YAMLLoader

    def _load(input_data):
        '''wrapper function to test yaml.load()'''
        return yaml_loader.load(input_data)


# Generated at 2022-06-23 05:34:13.498231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test for constructor of AnsibleLoader
    loader = AnsibleLoader(None, file_name='test.yaml')
    assert hasattr(loader, 'file_name')
    assert loader.file_name == 'test.yaml'
    assert hasattr(loader, 'vault_secrets')
    assert loader.vault_secrets is None
    assert hasattr(loader, 'stream')
    assert loader.stream is None

# Generated at 2022-06-23 05:34:24.611421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from io import StringIO
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO as StringIO

# Generated at 2022-06-23 05:34:34.387032
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-locals
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping
    from io import BytesIO

    stream = BytesIO("spam: eggs\n")

    # pylint: disable=unused-variable
    loader = AnsibleLoader(stream)

    # pylint: disable=protected-access
    assert isinstance(loader.get_single_data(), AnsibleMapping)
    assert isinstance(list(loader.get_single_data().keys())[0], AnsibleUnicode)
    assert isinstance(list(loader.get_single_data().values())[0], AnsibleUnicode)


# Generated at 2022-06-23 05:34:38.931790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = '''
    ---
    - hosts: localhost
      tasks:
      - include: '{{ ansible_os_family }}.yml'
    '''

    ansible_loader = AnsibleLoader(test_data)
    assert isinstance(ansible_loader, AnsibleLoader)


# Generated at 2022-06-23 05:34:44.327862
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("{}", vault_secrets=[])
    assert isinstance(loader, Reader)
    assert isinstance(loader, Scanner)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Composer)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:34:53.825875
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    content = """
        - hosts: localhost
          tasks:
            - yum:
                name: httpd
                state: latest
    """
    loader = AnsibleLoader(content)
    data = loader.get_single_data()

    assert isinstance(data, list)
    assert data[0]['hosts'] == 'localhost'

    # load_from_file
    with open('/tmp/test_file', 'w') as fp:
        fp.write(content)

    data = AnsibleLoader.load_from_file('/tmp/test_file')

    assert isinstance(data, list)
    assert data[0]['hosts'] == 'localhost'

# Generated at 2022-06-23 05:35:02.390115
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    data = '''
    foo: 1
    bar:
      baz: 3
    '''

    stream = to_bytes(data)
    loader = AnsibleLoader(stream)

    assert isinstance(loader.get_single_data(), AnsibleBaseYAMLObject)
    assert loader.get_single_data().foo == 1
    assert loader.get_single_data().bar.baz == 3

    stream = to_bytes('[1,2,3]')
    loader = AnsibleLoader(stream)

    assert isinstance(loader.get_single_data(), list)
    assert loader.get_single_data() == [1, 2, 3]

# Generated at 2022-06-23 05:35:03.352090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# Generated at 2022-06-23 05:35:14.761378
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:35:24.122382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys

    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.vars.hostvars import HostVars

    sys.path.append("lib/ansible")

    yaml_text = "{a: 1, b: A}  # comment\n---\n- {c: 3, d: D}...\n"

    if sys.version_info[0] == 3:
        # Python 3
        ordered_dict_type = dict
    else:
        # Python 2
        import collections
        ordered_dict_type = collections.OrderedDict

    loader = AnsibleLoader(yaml_text)
   

# Generated at 2022-06-23 05:35:34.409188
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import os
    import sys
    # Windows support tests
    if sys.platform == "win32":
        import ntpath

        path = ntpath
    else:
        import posixpath

        path = posixpath

    assert os.path.join('a', 'b') == AnsibleLoader.path_dwim(os.getcwd(), 'a', 'b')
    assert os.path.join('a', 'b') == AnsibleLoader.path_dwim('a', 'b')

    # Windows support tests
    if sys.platform == "win32":
        assert os.path.join('a', 'b') == AnsibleLoader.path_dwim(os.getcwd(), '/', 'a', 'b')
        assert os

# Generated at 2022-06-23 05:35:44.757368
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from time import time
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedString


# Generated at 2022-06-23 05:35:46.632736
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(file_name='/tmp/ansible.yaml')

# Generated at 2022-06-23 05:35:56.167239
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence

    loader = DataLoader()
    # pass a unicode to the loader
    data = loader.load(u"normal_string:\n  - unicode_string: test\n")
    assert isinstance(data, AnsibleMapping)
    assert isinstance(data['normal_string'], AnsibleSequence)
    assert isinstance(data['normal_string'][0], AnsibleMapping)
    assert isinstance(data['normal_string'][0]['unicode_string'], AnsibleUnicode)

# Generated at 2022-06-23 05:35:56.748305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:35:57.696041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:35:58.796199
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-23 05:36:00.044537
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert loader is not None

# Generated at 2022-06-23 05:36:04.733598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import from_yaml

    x = from_yaml("""
        ---
        foo:
            sub:
                - item: 1
                - item: 2
        """,Loader=AnsibleLoader)
    assert x['foo']['sub'][0]['item'] == 1

# Generated at 2022-06-23 05:36:10.903946
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test yaml.load by AnsibleLoader
    ansible_loader = AnsibleLoader("[1, 2, 3]")
    result = ansible_loader.get_single_data()
    assert result == [1, 2, 3]

    # Test yaml.full_load by AnsibleLoader
    ansible_loader = AnsibleLoader("[1, 2, 3]")
    result = ansible_loader.get_data()
    assert result == [1, 2, 3]

# Generated at 2022-06-23 05:36:19.445005
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_file = open('/tmp/test.yml', 'w')
    test_file.write('a: b\ntest: example\n')
    test_file.close()
    ansible_loader_instance = AnsibleLoader(open('/tmp/test.yml'))
    assert ansible_loader_instance is not None, "Instance of AnsibleLoader should be instantiated"
    assert ansible_loader_instance.get_single_data() == {'a': 'b', 'test': 'example'}, "Instance of AnsibleLoader should be instantiated"

# Generated at 2022-06-23 05:36:21.300448
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert loader != None

# Generated at 2022-06-23 05:36:31.610979
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test alias 
    #yaml = YAML()
    #yaml.register_class(AnsibleLoader)

    # Test Block Sequence
    data = """
- - osx
  - 10.9
- - windows
  - 10.1
- - linux
  - ubuntu
  - debian
- - "*"
"""
    import yaml
    yaml.add_constructor(u'tag:yaml.org,2002:python/dict', AnsibleConstructor.construct_yaml_map)
    yaml.add_constructor(u'tag:yaml.org,2002:python/object/apply', AnsibleConstructor.construct_python_object)

# Generated at 2022-06-23 05:36:39.204697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # create a dummy file obj
    with open('/tmp/test_dummy_file', 'w') as f:
        stream = f.read()

    # create instance of AnsibleLoader
    loader = AnsibleLoader(stream=stream, file_name="/tmp/test_dummy_file")
    assert(isinstance(loader, AnsibleLoader))

    # create a dummy loader class
    class DummyLoader(AnsibleLoader):
        pass

    # create instance of DummyLoader
    loader = DummyLoader(stream=stream, file_name="/tmp/test_dummy_file")
    assert(isinstance(loader, DummyLoader))

# Generated at 2022-06-23 05:36:40.202735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-23 05:36:42.667100
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.yaml import YAMLLoader
    assert issubclass(YAMLLoader, AnsibleLoader)

# Generated at 2022-06-23 05:36:54.470179
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.errors import AnsibleParserError
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml = '''
- test1: 1
- test2: 2
- test3: 3
'''
    yaml_struct = [{'test1': 1}, {'test2': 2}, {'test3': 3}]

    # Struct must be OK
    assert yaml_struct == yaml.load(yaml)

    # Load must be OK
    assert yaml_struct == AnsibleLoader(yaml).get_single_data()

    # Load must be OK with filename
    assert yaml_struct == AnsibleLoader(yaml, file_name='default').get_single_data()

    # Load from file must be OK

# Generated at 2022-06-23 05:36:58.818980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.inventory.host import Host

    loader = AnsibleLoader(None)
    loader.add_constructor(u'!AnsibleHost', Host)
    assert loader.construct_yaml_map(u'!AnsibleHost')

# Generated at 2022-06-23 05:37:01.143485
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    # creating an instance of the class AnsibleLoader
    AnsibleLoader(stream='')
    # TODO: Write more unit tests

# Generated at 2022-06-23 05:37:02.494735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:37:03.454270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader


# Generated at 2022-06-23 05:37:08.189907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    s = b"""
        - hosts:
            - localhost
    """

    results = AnsibleLoader(s, file_name='file.yml', vault_secrets=[]).get_single_data()
    assert results == [{'hosts': ['localhost']}]

# Generated at 2022-06-23 05:37:15.310989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_parser = AnsibleLoader(stream=None)
    assert isinstance(test_parser, Parser)
    assert hasattr(test_parser, 'construct_yaml_map')
    assert isinstance(test_parser, AnsibleConstructor)
    assert hasattr(test_parser, 'construct_mapping')
    assert isinstance(test_parser, Resolver)
    assert hasattr(test_parser, '_start_event')

# Generated at 2022-06-23 05:37:24.493124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing import vault
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedFile
    from ansible.errors import AnsibleError

    from io import StringIO

    # test loading encrypted data

    # this is a valid encrypted vault

# Generated at 2022-06-23 05:37:26.069081
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    asloader = AnsibleLoader(stream=None)
    assert asloader is not None

# Generated at 2022-06-23 05:37:30.631873
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # load_module_source should call `self.stream.read`
    stream = MockFileReader()
    stream.read = Mock(return_value='')
    AnsibleLoader(stream)
    assert stream.read.call_count == 1
    assert stream.close.call_count == 1


# Generated at 2022-06-23 05:37:32.450504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('test string')
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:37:34.160458
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:37:35.094348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:41.269989
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)

    if HAS_LIBYAML:
        assert isinstance(loader, Parser)
    else:
        assert isinstance(loader, Reader)
        assert isinstance(loader, Scanner)
        assert isinstance(loader, Parser)
        assert isinstance(loader, Composer)

# Generated at 2022-06-23 05:37:42.270440
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('[]')

# Generated at 2022-06-23 05:37:43.701516
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_class = AnsibleLoader(None)
    assert test_class is not None

# Generated at 2022-06-23 05:37:50.973001
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os

    parent_dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    yaml_file = parent_dir + '/test/unit/module_utils/test_loader_data.yaml'
    with open(yaml_file, 'r') as stream:
        loader = AnsibleLoader(stream)

        content = loader.get_single_data()
        assert content['key1'] == 'value1'
        assert content['list1'] == ['val1', 'val2']

        content = loader.get_single_data()
        assert content['key1'] == 'value1'
        assert content['list1'] == ['val1', 'val2']

        loader.dispose()

# Generated at 2022-06-23 05:37:53.719707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert loader is not None

# Generated at 2022-06-23 05:38:04.123707
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    import os
    import yaml
    homedir = os.path.expanduser('~')
    vault_password_file = os.path.join(homedir, '.vault_pass.txt')
    vault_id = '524d12a8-0c3f-4847-bf3d-ac2a48d3b7f6'
    vault_secrets = VaultLib(vault_password_file, vault_id)

# Generated at 2022-06-23 05:38:09.488309
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class TestAnsibleLoader(AnsibleLoader):
        def construct_yaml_str(self, node):
            return 'Hello World!'

    instance = TestAnsibleLoader(stream=None)
    data = instance.get_single_data()
    assert data == AnsibleUnicode('Hello World!')

# Generated at 2022-06-23 05:38:18.950424
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=redefined-outer-name
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    assert (issubclass(AnsibleLoader, AnsibleConstructor))
    assert (isinstance(AnsibleLoader(''), AnsibleConstructor))
    assert (isinstance(AnsibleLoader(''), AnsibleLoader))

    result = AnsibleLoader(u"foo: !!python/unicode 'bar'").get_single_data()
    assert (isinstance(result, dict))
    assert (result.get(u'foo', u'not found') == u'bar')
    assert (isinstance(result.get(u'foo'), AnsibleUnicode))

# Generated at 2022-06-23 05:38:22.769295
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():   # pylint: disable=unused-variable
    class Test(AnsibleLoader):
        pass
    try:
        Test()
        assert True
    except TypeError as e:
        assert False, "Should have created constructor %s" % str(e)

# Generated at 2022-06-23 05:38:26.822892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert isinstance(data, Parser)
    assert isinstance(data, AnsibleConstructor)
    assert isinstance(data, Resolver)

# Generated at 2022-06-23 05:38:36.217515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import io


# Generated at 2022-06-23 05:38:45.016844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 05:38:54.692378
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unicode import to_bytes
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    INVALID_UTF8 = b'\xef\xbb\xbf- hosts: localhost\n\xc2\xbfname: fail\n'
    VALID_UTF8 = b'\xef\xbb\xbf- hosts: localhost\n  name: success\n\n'

    # Make sure we fail to load invalid yaml
    yaml_obj = AnsibleLoader(INVALID_UTF8)
    assert yaml_obj.get_single_data() is None

    # Make sure valid utf-8 works
    yaml_obj = AnsibleLoader(VALID_UTF8)
    data = yaml_obj.get_single_data()
    assert data

# Generated at 2022-06-23 05:38:58.744522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    data = '''
    - slug:
        title: hello world
    '''

    d = DataLoader()
    d.set_data('file.yml', data)

    assert d.get_data('file.yml') == [{'slug': {'title': 'hello world'}}]

# Generated at 2022-06-23 05:39:05.962861
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_str = '''
    - { foo: bar }
    - baz: '2015-01-08T02:53:40.194686Z'
    '''

    data = AnsibleLoader(yaml_str, None, None).get_single_data()
    assert isinstance(data, AnsibleSequence)
    for item in data:
        assert isinstance(item, AnsibleMapping)

# Generated at 2022-06-23 05:39:07.271497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-23 05:39:14.506683
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import load
    from ansible.parsing.yaml.objects import AnsibleUnicode

    test_vals = {
        'int': 5
    }

    test_doc = """
int: '5'
"""

    obj = load(test_doc, Loader=AnsibleLoader)
    assert isinstance(obj, dict)
    assert isinstance(obj['int'], AnsibleUnicode)
    assert obj['int'] == test_vals['int']

# Generated at 2022-06-23 05:39:24.426010
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = '''
vars:
  my_name: bruce
  my_age: 30
  my_handsomeness: very

people:
  - name: {{ my_name }}
    age: {{ my_age }}
    handsomeness: {{ my_handsomeness }}
    tasks:
    - debug:
        msg: "This is {{ my_name }}"
        verbosity: 2
    - debug:
        msg: "This is {{ my_name }} again"
        verbosity: 1
    - debug:
        msg: "This is {{ my_name }} for the third time"
'''

    loader = AnsibleLoader(data)


# Generated at 2022-06-23 05:39:29.548906
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    dl = DataLoader()
    stream = dl.load_from_file("test/ansible_loader_test_file.yml")
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_data()

# Generated at 2022-06-23 05:39:38.216265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Assign
    file_content = b'''
        ---
        - hosts: all
          tasks:
          - name: test loop
            debug: msg="{{ item }}"
            with_items:
            - 1
            - 2
            - 3
        '''
    stream = file_content
    file_name = 'test.yml'
    # Act
    loader = AnsibleLoader(stream, file_name)
    # Assert
    assert loader is not None
    assert loader.stream == file_content
    assert loader.file_name == 'test.yml'

# Generated at 2022-06-23 05:39:42.061731
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
        name: clear
        apt:
          name: "{{ item }}"
          state: present
        with_items:
          - vim
          - emacs
    """
    loader = AnsibleLoader(data)
    loader.get_single_data()

# Generated at 2022-06-23 05:39:48.860931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=protected-access
    data = """
    ---
    a:
      -
      - 1
      - |
        foo
        bar
    """
    loader = AnsibleLoader(data)
    loader._scan_node()  # pylint: disable=protected-access
    rdata = loader.get_single_data()
    assert len(rdata) == 1
    assert rdata[0]['a'][2] == 'foo\nbar\n'
    assert rdata[0]['a'][1] == 1
    assert rdata[0]['a'][0] is None

# Generated at 2022-06-23 05:39:59.832837
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test basic attributes of AnsibleLoader constructor
    '''

    # Check that AnsibleLoader is a subclass of Parser
    assert issubclass(AnsibleLoader, Parser)

    # Check that AnsibleLoader is a subclass of AnsibleConstructor
    assert issubclass(AnsibleLoader, AnsibleConstructor)

    # Check that AnsibleLoader is a subclass of Resolver
    assert issubclass(AnsibleLoader, Resolver)

    # Check that Resolver is a subclass of AnsibleConstructor
    assert issubclass(Resolver, AnsibleConstructor)

    # Check that AnsibleConstructor is a subclass of Resolver
    assert issubclass(AnsibleConstructor, Resolver)

    # Check that Parser is not a subclass of AnsibleConstructor

# Generated at 2022-06-23 05:40:07.741018
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader

    contents = """
- hosts: all
  gather_facts: no
  tasks:
    - debug:
        msg: hello world
"""

    loader = DataLoader()
    result = loader.load(contents)
    assert result[0]['hosts'] == 'all'
    assert result[0]['gather_facts'] == 'no'

# Generated at 2022-06-23 05:40:19.288859
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils._text import to_bytes
    vault_secret = to_bytes('$ANSIBLE_VAULT;1.1;AES256')
    for path in sys.path:
        if path.endswith('yaml/lib'):
            path += '/../../test/vault/test_vault.yml'
            break
    file_name = open(path, 'rb')
    loader = AnsibleLoader(file_name.read(), file_name=path, vault_secrets=[vault_secret])
    loader.get_single_data()
    file_name.close()
    assert isinstance(loader.get_single_data(), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:40:22.093899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)

# Generated at 2022-06-23 05:40:33.415713
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.objects import AnsibleSequence

    # Test for empty list
    text1 = """[]"""
    object1 = AnsibleLoader(text1).get_single_data()
    assert isinstance(object1, AnsibleSequence)
    assert len(object1) == 0

    # Test for list of length 1
    text2 = """[l2]"""
    object2 = AnsibleLoader(text2).get_single_data()
    assert isinstance(object2, AnsibleSequence)
    assert len(object2) == 1
    assert object2[0] == "l2"

    # Test for list of length 2
    text3 = """[l21, l22]"""
    object3 = AnsibleLoader(text3).get_single_data()
    assert isinstance

# Generated at 2022-06-23 05:40:39.216113
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(vault_secrets=[], file_name="test")
    test_input = """
    ---
    this is a test with various :
      - item1
      - item2
    test it with main method
    """
    test_output = ansible_loader.gen_plain_yaml_from_vaulted(test_input)
    print(test_output)

# Generated at 2022-06-23 05:40:43.270171
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='test_loader')
    assert loader.file_name == 'test_loader'
    loader = AnsibleLoader(vault_secrets='test_vault_secrets')
    assert loader.vault_secrets == 'test_vault_secrets'

# Generated at 2022-06-23 05:40:56.849409
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import Loader, SafeLoader

    # test object
    a_string = (
        '{a: {b: {c: 1}, d: {e: 2}, f: {g: 3}}}\n'
    )

    # expected results
    a_dict_keys = set(['a'])
    a_dict_no_keys = set(['a'])

    # check class/object
    assert isinstance(AnsibleLoader(a_string), Loader)
    assert isinstance(AnsibleLoader(a_string), SafeLoader)

    # test AnsibleLoader
    a_dict = AnsibleLoader(a_string).get_single_data()
    assert isinstance(a_dict, dict)
    assert a_dict_keys == set(a_dict.keys())
    assert a_dict_no_

# Generated at 2022-06-23 05:41:04.797206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedBytes


# Generated at 2022-06-23 05:41:15.817174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    # Create a vault_secrets dictionary with a VaultSecret
    vault_secrets = [VaultSecret()]

    # Initialize an AnsibleLoader, specify the vault_secrets parameter
    loader = AnsibleLoader(stream=None, file_name='myfile', vault_secrets=vault_secrets)

    # Verify that AnsibleLoader.file_name is correctly set
    assert loader.file_name == 'myfile'

    # Initialize a loader with no vault_secrets parameter
    loader = AnsibleLoader(stream=None, file_name='myfile')

    # Verify that loader.file_name is correctly set, and that loader.vault_secrets is an empty list
    assert loader.file_name == 'myfile'
    assert loader.vault_secrets

# Generated at 2022-06-23 05:41:17.142750
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:41:18.098362
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('', '')

# Generated at 2022-06-23 05:41:27.081695
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    yaml_str = ('- 1\n'
                '- 2\n'
                '- 3\n')

    assert isinstance(AnsibleLoader(yaml_str).get_single_data(), AnsibleSequence)

    yaml_str = ('host1: 192.168.0.1\n'
                'host2: 192.168.0.2\n'
                'host3: 192.168.0.3\n')

    assert isinstance(AnsibleLoader(yaml_str).get_single_data(), AnsibleMapping)

    # test the vault_secrets setting

# Generated at 2022-06-23 05:41:27.704124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:36.681960
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

# Generated at 2022-06-23 05:41:47.364159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    import yaml


# Generated at 2022-06-23 05:41:48.741623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")

# Generated at 2022-06-23 05:41:55.155206
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = '''
---
thing:
- one:
    two: yet another thing
    '''
    assert[] == AnsibleLoader(None, vault_secrets=[]).construct_yaml_seq(None)
    assert{} == AnsibleLoader(None, vault_secrets=[]).construct_yaml_map(None)
    assert None == AnsibleLoader(None).get_single_data()
    assert AnsibleLoader(text).get_single_data()