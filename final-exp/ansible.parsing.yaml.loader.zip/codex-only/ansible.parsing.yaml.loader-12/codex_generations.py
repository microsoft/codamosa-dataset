

# Generated at 2022-06-23 05:31:56.005635
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_yaml = """
    test_mapping:
      foo: bar
    """
    data = AnsibleLoader(test_yaml).get_data()
    assert data.get('test_mapping').get('foo') == 'bar'
    assert type(data).__name__ == 'dict'

# Generated at 2022-06-23 05:31:56.615153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:32:06.051694
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    class Loader(AnsibleLoader):
        pass

    # Test if using an alias with a variable, the variable is removed from
    # the returned data structure
    test_var_string = "{{ testvar }}"
    data = Loader(test_var_string).get_single_data()
    assert data.startswith("{{")

    test_alias_string = "testalias: &testaliasref {{ testvar }}"
    data = Loader(test_alias_string).get_single_data()
    assert "&testaliasref" in data

# Generated at 2022-06-23 05:32:13.022748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import json

    class FakeStream(object):
        data = "[1, {\"a\": [2, 3]}]"
        def read(self, numbytes):
            try:
                return self.data
            finally:
                self.data = None
            raise StopIteration()

    loader = AnsibleLoader(FakeStream())
    data = loader.get_single_data()

    json.dumps(data)

# Generated at 2022-06-23 05:32:19.889483
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    target = AnsibleLoader(open('test_data/yaml_loader.yml'))
    result = target.get_single_data()
    assert result == dict(
        test_list=[1, 2, 'a'],
        test_dict=dict(key='value'),
        test_timestamp=datetime.datetime(2017, 5, 26, 17, 0, 5, 627481),
        test_float=3.42)

# Generated at 2022-06-23 05:32:21.939515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:32:28.796756
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.data
    import ansible.parsing.yaml.loader
    ansible.parsing.yaml.objects.AnsibleBaseYAMLObject = object
    ansible.parsing.yaml.data.AnsibleSequence = list
    ansible.parsing.yaml.data.AnsibleMapping = dict
    ansible.parsing.yaml.loader.AnsibleLoader = object

# Generated at 2022-06-23 05:32:30.466415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    loader_obj = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:36.775260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        - hosts: all
          tasks:
             - name: ping
               ping: >
                 data to
                 preserve
                 newlines
    '''

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['tasks'][0]['ping'] == 'data to\npreserve\nnewlines\n'

# Generated at 2022-06-23 05:32:44.263386
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """This is a unit test for class AnsibleLoader"""
    from io import StringIO

    data = '''
    - hosts: localhost
      tasks:
      - ping:
    '''
    test_name = "test_AnsibleLoader"
    test_pass = False
    try:
        loader = AnsibleLoader(StringIO(data),
                               file_name=test_name, vault_secrets=None)
    except:
        pass
    else:
        test_pass = True
    assert test_pass



# Generated at 2022-06-23 05:32:54.553432
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import tempfile

    d = tempfile.mkdtemp()
    fh, fn = tempfile.mkstemp(suffix='', prefix='test_AnsibleLoader_', dir=d)
    f = os.fdopen(fh, 'w')
    f.write("""
    - hosts: all
      remote_user: root
      gather_facts: true
    """)
    f.close()

    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    import ansible.parsing.yaml.objects
    sys.modules['ansible.parsing.yaml.objects'] = ansible.parsing.yaml.objects
    from ansible.parsing.yaml.loader import AnsibleLoader

# Generated at 2022-06-23 05:33:04.301884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ make sure our constructors allow for empty map and list keys """

# Generated at 2022-06-23 05:33:14.000232
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    def get_vault_password(vault_id):
        if vault_id == "VaultPassword1":
            return "VaultPassword1"
        elif vault_id == "VaultPassword2":
            return "VaultPassword2"
        elif vault_id == "VaultPassword3":
            return "VaultPassword3"
        else:
            raise AnsibleError("unable to find vault password for: %s" % vault_id)

    def get_vault_secret(vault_id):
        if vault_id == "VaultSecret1":
            return "VaultSecret1"

# Generated at 2022-06-23 05:33:20.768257
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    loader = AnsibleLoader("[1,2,3]")
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, AnsibleConstructor)
    assert not isinstance(loader, Parser)

# Generated at 2022-06-23 05:33:28.781894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        foo: 1
        bar: blah
    '''
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == {'foo': 1, 'bar': 'blah'}

    data = '''
        foo: 1
        bar: blah
    '''
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == {'foo': 1, 'bar': 'blah'}

# Generated at 2022-06-23 05:33:31.054113
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(object):
        pass
    assert issubclass(AnsibleLoader, TestAnsibleLoader)

# Generated at 2022-06-23 05:33:36.081933
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert HAS_LIBYAML
    loader = AnsibleLoader('foo: bar')
    assert loader is not None
    assert loader.construct_yaml_map() == {'foo': 'bar'}
    data = loader.get_single_data()
    assert data == {'foo': 'bar'}
    assert loader.construct_yaml_str() == 'bar'


# Generated at 2022-06-23 05:33:47.333653
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    class AnsibleDumpLocalYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_tag = u'!AnsibleDumpLocalYAMLObject'

    class AnsibleLocalYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleLoader
        yaml_tag = u'!AnsibleLocalYAMLObject'

    obj_local = AnsibleLocalYAMLObject()
    obj_local.attr1 = 'Local String'
    obj_local.attr2 = 5

    obj_dump_local = AnsibleDumpLocalYAMLObject()
    obj_dump_local.attr1 = obj_local

    import sys

# Generated at 2022-06-23 05:33:58.585520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, 'add_constructor')
    assert hasattr(loader, 'add_multi_constructor')

    # test for constructor
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_str')
    assert hasattr(loader, 'construct_yaml_seq')
    assert hasattr(loader, 'construct_yaml_binary')
    assert hasattr(loader, 'construct_yaml_bool')
    assert hasattr(loader, 'construct_yaml_int')
    assert hasattr(loader, 'construct_yaml_float')
    assert hasattr(loader, 'construct_undefined')
    assert hasattr(loader, 'construct_yaml_null')

# Generated at 2022-06-23 05:34:12.032730
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_name = 'AnsibleLoader'
    obj = AnsibleLoader(stream='', file_name=None, vault_secrets=None)
    assert hasattr(obj, '_Class__yaml_aliases')
    assert hasattr(obj, '_Class__yaml_comment_tokens')
    assert hasattr(obj, '_Class__yaml_data_tokens')
    assert hasattr(obj, '_Class__yaml_key_tokens')
    assert hasattr(obj, '_Class__yaml_stream')
    assert hasattr(obj, '_Class__yaml_value_tokens')
    assert getattr(obj, '_Class__yaml_data_tokens') == []
    assert getattr(obj, '_Class__yaml_aliases') == {}
   

# Generated at 2022-06-23 05:34:21.243916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import sys
    sys.path[0:0] = [ os.path.join(os.path.dirname(__file__), '../lib/ansible/module_utils'), ]
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    stream = 'true'
    file_name = 'test.yaml'
    vault_secrets = 'XXXXXXXXXXXXXXXXXX'
    al = AnsibleLoader(stream, file_name, vault_secrets)
    assert al.check_data()
    assert al.stream is stream
    assert al.file_name is file_name
    assert al.vault_secrets is vault_secrets

# Generated at 2022-06-23 05:34:21.908632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:34:28.966248
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    class TestAnsibleLoader(AnsibleLoader):
        def get_single_data(self):
            return self.compose_document()

    stream = io.StringIO(u'foo: 123\nbar: [ a, b, c ]')
    data = TestAnsibleLoader(stream).get_single_data()
    assert data['foo'] == 123
    assert data['bar'] == [u'a', u'b', u'c']

# Generated at 2022-06-23 05:34:30.001806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader([])
    assert al is not None

# Generated at 2022-06-23 05:34:32.429646
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader
    assert AnsibleLoader(stream=None)

# Generated at 2022-06-23 05:34:33.441025
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:34:44.246097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test if yaml_loader() in utils.py returns an instance of AnsibleLoader
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    import yaml
    loader = yaml.Loader(stream=wrap_var("hi: 5"))
    assert isinstance(loader, AnsibleLoader)
    assert loader.stream == "hi: 5"
    assert loader.file_name is None
    assert loader.vault_secrets is None

    loader = yaml.Loader(stream=wrap_var("hi: 5"), file_name="fname")
    assert loader.file_name == "fname"
    assert isinstance(loader.file_name, AnsibleUnsafeText)

# Generated at 2022-06-23 05:34:47.715216
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from tests.test_loader import TestLoader
    except ImportError:
        from .test_loader import TestLoader
    loader = TestLoader()
    loader.load()

# Generated at 2022-06-23 05:34:48.700597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:34:50.970916
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name='test_file_name')
    assert loader.file_name == 'test_file_name'

# Generated at 2022-06-23 05:34:53.569011
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader

    loader = ansible.parsing.yaml.loader.AnsibleLoader([])
    assert loader


# Generated at 2022-06-23 05:35:02.274519
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Verify that AnsibleLoader is derived from the Parser class
    loader = AnsibleLoader("file.yml", vault_secrets=[])

    assert isinstance(loader, Parser)

    assert loader.file_name

    # Verify that AnsibleLoader is derived from the AnsibleConstructor class
    assert isinstance(loader, AnsibleConstructor)

    # Verify that AnsibleLoader is derived from the Resolver class
    assert isinstance(loader, Resolver)

    # Verify that the Resolver method add_implicit_resolver is updated by AnsibleConstructor
    assert 'tag:yaml.org,2002:bool' in loader.yaml_implicit_resolvers

    # Verify that the Resolver method add_path_resolver is updated by AnsibleConstructor

# Generated at 2022-06-23 05:35:03.572064
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    AnsibleLoader('[42, 43]')

# Generated at 2022-06-23 05:35:04.234460
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:35:07.138105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    loader = AnsibleLoader(file_name=__file__)
    assert(loader.file_name == __file__)

# Generated at 2022-06-23 05:35:17.734562
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os, tempfile
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # Write data to a temporary file
    tfile = tempfile.NamedTemporaryFile()
    tfile.write(b"""
    ---
    - hosts: localhost
      tasks:
      - name: test1
        command: /usr/bin/false

      - name: test2
        command: /usr/bin/false
        ignore_errors: True
    """)
    tfile.flush()

    # Create AnsibleLoader object
    loader = AnsibleLoader(file_name=tfile.name)

    # Load data from the file
    data = loader.get_single_data()

    # Dump it back to YAML
    dumper = AnsibleDumper()
    ydata = dumper.dump

# Generated at 2022-06-23 05:35:27.191737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader_obj = AnsibleLoader(None)
    assert isinstance(loader_obj, AnsibleLoader)
    assert isinstance(loader_obj, Resolver)
    assert isinstance(loader_obj, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(loader_obj, Parser)
    else:
        assert isinstance(loader_obj, Reader)
        assert isinstance(loader_obj, Scanner)
        assert isinstance(loader_obj, Parser)
        assert isinstance(loader_obj, Composer)

# Generated at 2022-06-23 05:35:38.018719
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime

    tag = 'tag:yaml.org,2002:timestamp'
    val = '2002-12-14T21:59:43.1Z'
    data = '!!python/object/apply:datetime.datetime {}'.format(val)

    loader = AnsibleLoader(data)
    assert loader.construct_yaml_str(node=None) == val
    assert loader.construct_python_str(node=None) == val
    assert loader.construct_yaml_timestamp(node=None) == datetime.datetime(2002, 12, 14, 21, 59, 43, 100000)
    assert loader.construct_yaml_seq(node=None) == []
    assert loader.construct_yaml_map(node=None) == {}

# Generated at 2022-06-23 05:35:47.736307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    data = """
    a: 1
    b:
      c: 3
      d: 4
    """

    l = AnsibleLoader(data)
    d = l.get_single_data()

    assert isinstance(d, AnsibleMapping)
    assert isinstance(d.get('a'), int)
    assert isinstance(d.get('b'), AnsibleMapping)
    assert isinstance(d.get('b').get('c'), int)
    assert isinstance(d.get('b').get('d'), int)

   

# Generated at 2022-06-23 05:35:50.986612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_content = "def __init__(self, stream, file_name=None, vault_secrets=None)"
    assert class_content in AnsibleLoader.__init__.__doc__

# Generated at 2022-06-23 05:36:02.409325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.six import StringIO
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    data = '''
- hosts: localhost
  vars:
    a: 1
    b: 2
  tasks:
    - debug: msg="{{ a }} {{ b }}"
    - debug: msg="{{ a }} {{ b }}"
    - debug: msg="{{ a }} {{ b }}"
'''
    stream = StringIO(data)
    loader = AnsibleLoader(stream)

    for item in loader:
        assert(type(item) == dict)
        assert(item['hosts'] == 'localhost')

# Generated at 2022-06-23 05:36:03.218040
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:04.466207
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class_name = AnsibleLoader.__name__
    assert class_name == "AnsibleLoader"

# Generated at 2022-06-23 05:36:08.478339
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader

    if HAS_LIBYAML:
        assert isinstance(loader, (Parser, AnsibleConstructor, Resolver))
    else:
        assert isinstance(loader, (Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver))

# Generated at 2022-06-23 05:36:14.780570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleLoader(Parser, AnsibleConstructor, Resolver):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            Parser.__init__(self, stream)
            AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
            Resolver.__init__(self)

# Generated at 2022-06-23 05:36:24.540558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import from_yaml

    # initialize
    _loader = AnsibleLoader(stream=None)
    assert _loader is not None
    assert isinstance(_loader, AnsibleLoader)
    assert isinstance(_loader, Parser)
    assert isinstance(_loader, Resolver)
    assert isinstance(_loader, AnsibleConstructor)
    if HAS_LIBYAML:
        assert isinstance(_loader, Parser)
    else:
        assert isinstance(_loader, Reader)
        assert isinstance(_loader, Scanner)
        assert isinstance(_loader, Parser)
        assert isinstance(_loader, Composer)

    # construct_yaml_dict
    data = "test1: test2\ntest3: test4"

# Generated at 2022-06-23 05:36:29.535760
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    constructor = AnsibleLoader.add_constructor(u'tag:yaml.org,2002:str', lambda loader, node: loader.construct_yaml_str(node))

    my_str = u'''hello world !
    this is a test
    '''

    AnsibleLoader.remove_constructor(u'tag:yaml.org,2002:str')

    my_unicode = AnsibleUnicode(my_str)
    assert(isinstance(my_unicode, AnsibleUnicode))

# Generated at 2022-06-23 05:36:35.769078
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import HashLoader
    from ansible.module_utils.common.yaml import SafeLoader
    from ansible.module_utils.common.yaml import FullLoader
    from ansible.module_utils.common.yaml import UnsafeLoader

    assert issubclass(HashLoader, AnsibleLoader)
    assert issubclass(SafeLoader, AnsibleLoader)
    assert issubclass(FullLoader, AnsibleLoader)
    assert issubclass(UnsafeLoader, AnsibleLoader)

# Generated at 2022-06-23 05:36:42.124525
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('ansible/parsing/yaml/tests/data/ansible_loader.yml', 'r')
    AnsiLoader = AnsibleLoader(stream)
    data = AnsiLoader.get_single_data()

    assert 'a' in data
    assert 'b' in data
    assert 'c' in data
    assert data['a'] == 1
    assert data['b'] == 2
    assert data['c'] == 3

# Generated at 2022-06-23 05:36:46.475929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    data = b'foo: bar\n'
    with io.BytesIO(data) as stream:
        with pytest.raises(AnsibleLoader):
            loader = AnsibleLoader(stream)
            loader.get_single_data()

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:36:50.030852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This is a test function for AnsibleLoader class for enabling Unit test for constructors
    '''
    try:
        AnsibleLoader(None)
    except TypeError:
        pass

# Generated at 2022-06-23 05:36:58.962830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnicode
    test_values_1 = {"vault_password_file": "/tmp/foo"}
    test_values_2 = {"vault_password_file": "/tmp/foo", "vault_secrets": [("foo", "bar")]}
    test_data_1 = """
---
foo: bar
"""

# Generated at 2022-06-23 05:37:09.405604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    import io

    stream = io.StringIO('{ "key": "value" }')
    loader = AnsibleLoader(stream)
    assert isinstance(loader, AnsibleLoader)
    assert hasattr(loader, '_reader')
    assert loader.construct_scalar('test') == AnsibleUnicode(u'test')
    assert isinstance(loader.construct_mapping('test'), AnsibleMapping)
    assert isinstance(loader.construct_yaml_map('test'), AnsibleMapping)
    assert loader.construct_yaml_str('test') == AnsibleUnicode(u'test')
    assert loader.construct_yaml_seq('test') == list()
    assert loader.construct_yaml_map

# Generated at 2022-06-23 05:37:11.362463
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream=None)
    assert ansible_loader is not None

# Generated at 2022-06-23 05:37:22.088325
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO
    from ansible.vars.unsafe_proxy import UnsafeProxy

    test_string = """
    {% raw %}[
    {% endraw %}
        {% raw %}"foo",
    {% endraw %}
        {% raw %}"bar"
    {% endraw %}
    {% raw %}]
    {% endraw %}
    """

    stream = StringIO(test_string)
    ansible_loader = AnsibleLoader(stream=stream)
    data = ansible_loader.get_single_data()
    assert len(data) == 2

    assert type(data[0]) == UnsafeProxy
    assert type(data[1]) == Unsafe

# Generated at 2022-06-23 05:37:33.189482
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import base64


# Generated at 2022-06-23 05:37:42.014165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import os
    import sys
    import unittest

    if sys.version_info[0] >= 3:
        unicode = str

    class TestConstructor(unittest.TestCase):

        def test_str_constructor(self):
            # Constructor should create Python strings from YAML unquoted style
            # scalars in the canonical YAML format (i.e. no tabs, not too many
            # spaces, ...)
            self.assertIsInstance(AnsibleLoader(u'').get_single_data(), unicode)
            self.assertIsInstance(AnsibleLoader(u'foo').get_single_data(), unicode)

# Generated at 2022-06-23 05:37:50.858353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils import six

    # ANSIBLE_SHOW_CUSTOM_STDERR environment variable triggers the display of custom generated stderr for the tests
    # However, this is only useful when running the tests manually. When running the tests with pytest-ansible, pytest-ansible will always capture the stderr regardless of this setting
    # And when running the tests with python-nose, nose will always capture the stderr regardless of this setting

# Generated at 2022-06-23 05:38:02.731275
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import unittest
    import tempfile

    class TestAnsibleLoader(unittest.TestCase):
        def test_type(self):
            with tempfile.NamedTemporaryFile() as f:
                f.write(b'foo: {bar: baz}\n')
                f.seek(0)
                loader = AnsibleLoader(f)
                res = loader.get_single_data()
                self.assertEqual(dict, type(res))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestAnsibleLoader)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    import sys
    import doctest
    import unittest

# Generated at 2022-06-23 05:38:07.242228
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
---
- hosts: all
  tasks:
    - name: test1
      debug:
        msg: Hello
        world
"""
    loader = AnsibleLoader(data)
    result = [{'hosts': 'all', 'tasks': [{'debug': {'msg': 'Hello world'}, 'name': 'test1'}]}]
    assert result == loader.get_single_data()

# Generated at 2022-06-23 05:38:09.360860
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert callable(getattr(AnsibleLoader, '__init__'))


# Generated at 2022-06-23 05:38:13.803382
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    assert issubclass(AnsibleLoader, yaml.Loader) is True
    assert issubclass(AnsibleLoader, yaml.constructor.Constructor) is True
    assert issubclass(AnsibleLoader, yaml.resolver.Resolver) is True

# Generated at 2022-06-23 05:38:16.437237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader([1, 2, 3])
    except Exception:
        pass
    else:
        raise AssertionError('AnsibleLoader() did not raise an exception')


# Generated at 2022-06-23 05:38:25.585182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class DummyStream:
        def __init__(self):
            self.data = ""
        def read(self):
            if self.data:
                return self.data
            else:
                return None

    test_data = '''
- hosts: all
  tasks:
    - name: install vim
      package:
        name: vim
        state: present
'''

    test_stream = DummyStream()
    test_stream.data = test_data

    test_loader = AnsibleLoader(test_stream, vault_secrets=[])
    test_loader.get_single_data()

# Generated at 2022-06-23 05:38:35.597589
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils.common.yaml import YAML
    data = {
            "this is a string": "value",
            "this is a list": [1, 2, 3],
            # (1, 2) is a tuple
            "this is a tuple": (1, 2),
            "this is a dict": {
                "a": 1,
                "b": 2,
                "c": [3, 4, 5]
            },
            "this is a unicode": u"value",
            "this is a null": None,
            "this is a bool": True,
            # 1 is an int
            "this is an int": 1,
            "this is a float": 1.23
        }

# Generated at 2022-06-23 05:38:38.147262
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # Ansible loader does not implement __init__ to initialize variables
    # so it needs to be called in the test function
    #
    assert True

# Generated at 2022-06-23 05:38:39.927734
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:38:51.393809
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.dataloader import DataLoader

    data = '''
    a: 1
    b:
      - 2
      - 3
    '''

    my_loader = DataLoader()

    # Test the pyyaml object loader
    result = my_loader.load(data)
    assert isinstance(result, AnsibleMapping)
    for x in result.keys():
        assert isinstance(x, str)
    assert isinstance(result['b'], AnsibleSequence)
    for x in result['b']:
        assert isinstance(x, int)

    # Test the scanner and parser classes directly
    result = AnsibleLoader(data).get_single_data

# Generated at 2022-06-23 05:38:52.747682
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        AnsibleLoader(None, None)
    except TypeError:
        pass

# Generated at 2022-06-23 05:39:00.164501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = \
'''
test_dict:
    test_key: test_value
    test_key2: test_value2

test_list:
    - test_item1
    - test_item2
'''

    loader = AnsibleLoader(yaml_str)
    assert loader is not None
    assert 'test_dict' in loader
    assert loader['test_dict'] == {'test_key': 'test_value', 'test_key2': 'test_value2'}
    assert loader.get('test_dict') == {'test_key': 'test_value', 'test_key2': 'test_value2'}


# Generated at 2022-06-23 05:39:01.608106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO
    assert False

# Generated at 2022-06-23 05:39:11.194680
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    vault_secrets = ['secret1', 'secret2', VaultLib('secret3')]
    file_name = 'test.yml'
    yaml_obj = AnsibleVaultEncryptedUnicode.from_plaintext('$ANSIBLE_VAULT;1.1;AES256\n0w7PD+rQfQm9y1G0xuNHnA==\n', vault_identity=vault_secrets)
    yaml_dict = {
        'a': 1,
        'b': 2,
        'c': 3,
        'vault_secret': yaml_obj
        }


# Generated at 2022-06-23 05:39:13.289528
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(stream=None, file_name=None, vault_secrets=None) is not None

# Generated at 2022-06-23 05:39:19.235196
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import StringIO
    from yaml.scanner import ScannerError
    from yaml.parser import ParserError
    from yaml.composer import ComposerError
    from yaml.reader import ReaderError
    from yaml.resolver import ResolverError

    # Test that exception is raised when file name is not given:
    # ansible_file_name_required_error

# Generated at 2022-06-23 05:39:24.497126
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert AnsibleLoader

# Generated at 2022-06-23 05:39:33.788959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = yaml.error.MarkedYAMLError(None, None, None, None, None)
    ansible_loader = AnsibleLoader(stream)

    # Testing abstract property purpose
    assert ansible_loader.purpose == ""

    # Testing abstract property filename
    assert ansible_loader.filename == None

    # Testing abstract method __getitem__
    try:
        ansible_loader.__getitem__()
        assert False
    except NotImplementedError:
        assert True

    # Testing abstract method reject
    try:
        ansible_loader.reject()
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-23 05:39:35.334957
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None)
    assert loader is not None

# Generated at 2022-06-23 05:39:43.726733
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = u'---\ndefault: my default\n'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert 'default' in data
    assert data['default'] == 'my default'

    stream = u'---\n- one\n- two\n'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data[0] == 'one'
    assert data[1] == 'two'


# Loader for testing AnsibleLoader creation outside of __init__ method

# Generated at 2022-06-23 05:39:54.329128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    vault = VaultLib(password='password')
    encrypted = vault.encrypt('test')

    a = AnsibleLoader(None)
    assert isinstance(a, Parser)
    assert isinstance(a, AnsibleConstructor)
    assert isinstance(a, Resolver)

    a = AnsibleLoader(None, vault_secrets='password')
    assert isinstance(a.construct_yaml_str(encrypted), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:40:06.366430
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Basic AnsibleLoader test
    """
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    stream = dl.load_from_file('../../test/sanity/group_vars/all')
    al = AnsibleLoader(stream)
    data = al.get_single_data()
    assert data['my_var'] == 1
    assert data['my_int'] == 1
    assert data['my_str'] == 'foo'
    assert data['my_bool'] == True
    assert data['my_bool_str'] == True
    assert data['my_list'] == ['a', 'b', 'c']
    assert data['my_dict'] == {'a':'b', 'c':'d'}
    assert data['my_complex_dict']

# Generated at 2022-06-23 05:40:12.486469
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    stream = StringIO("""
        - name: hello world
          hosts: all
          remote_user: root
          sudo: true
          tasks:
            - shell: echo hello
    """)

    loader = AnsibleLoader(stream)
    objs = list(loader.get_single_data())

    assert 'name' in objs[0]
    assert objs[0]['name'] == 'hello world'

# Generated at 2022-06-23 05:40:22.132637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from io import BytesIO

    Yaml = AnsibleLoader(BytesIO(b'[1,2,3]'))
    Yaml = AnsibleLoader(BytesIO(b'---\n- name: test\n  foo: bar\n'))
    Yaml = AnsibleLoader(BytesIO(b'---\n- name: test\n  foo: bar\n'), vault_secrets=[])
    Yaml = AnsibleLoader(BytesIO(b'---\n- name: test\n  foo: bar\n'), file_name='foo')
    assert isinstance(Yaml.get_single_data(), list)

# Generated at 2022-06-23 05:40:33.472185
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # testing yaml.load
    for stream, expected_data in (
        (b'1', 1),
        (b'[a, b, c]', AnsibleSequence([u'a', u'b', u'c'])),
        (b'{a: b, c: d}', AnsibleMapping({u'a': u'b', u'c': u'd'})),
    ):
        # TODO: Move AnsibleLoader and AnsibleDumper to use the context manager
        actual_data = AnsibleLoader(stream).get_single_data()

# Generated at 2022-06-23 05:40:34.256455
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert (False)

# Generated at 2022-06-23 05:40:37.363373
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Parser)
    assert isinstance(loader, Resolver)
    return loader.get_single_data()

# Generated at 2022-06-23 05:40:38.773936
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    constructor = AnsibleLoader(None)
    assert(constructor is not None)

# Generated at 2022-06-23 05:40:45.083869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.loader import AnsibleLoader

    stream = '''
    - include_tasks: foo.yml
      when: true
    - include_tasks: bar.yml
      when: false
    '''

    data = AnsibleLoader(stream, file_name='/tmp/foo').get_single_data()
    assert not data[0]['when']
    assert data[1]['when']

# Generated at 2022-06-23 05:40:55.091759
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
    ---
    -   a: 1
        b: 2
    -   c:
        - 3
        - 4
    -   d:
        -   e: 5
            f: 6
        -   g: [ 7, 8 ]
            h: 9
    """
    from io import StringIO
    c = StringIO(yaml)

    loader = AnsibleLoader(c)
    data = loader.get_single_data()
    assert len(data) == 3

    assert data[0]['a'] == 1
    assert data[0]['b'] == 2

    assert data[1]['c'] == [3, 4]

    assert data[2]['d'][0]['e'] == 5
    assert data[2]['d'][0]['f'] == 6
    assert data

# Generated at 2022-06-23 05:41:00.855470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    my_ansible_loader = AnsibleLoader(None)
    assert(my_ansible_loader._yaml_get_block_style() is None)
    assert(my_ansible_loader._yaml_get_scalar_style() is None)
    assert(my_ansible_loader._yaml_get_node_type() is None)

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:41:07.251836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import AnsibleVaultNoKey
    from ansible.vars.manager import VariableManager
    '''
    Test our custom loader class
    '''

    # Example of vaulted yaml file

# Generated at 2022-06-23 05:41:17.054596
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    class UnicodeStream(object):
        def __init__(self, data_list):
            self._data = data_list
            self._index = 0

        def read(self):
            if self._index < len(self._data):
                out = self._data[self._index]
                self._index += 1
                return out
            return ""

    class Test(object):
        pass

    # Constructor should return an instance of AnsibleLoader class
    # tests with Python 2.7

# Generated at 2022-06-23 05:41:18.367974
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:41:19.921622
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "test"
    assert AnsibleLoader(stream).stream == stream

# Generated at 2022-06-23 05:41:23.961784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    fake_data = '{"blah": "foo"}'
    class FakeVaultLib(object):
        def decrypt(self, data):
            return fake_data
    loader = AnsibleLoader(file_name='fake_name', vault_secrets=FakeVaultLib())
    assert loader.get_single_data() == fake_data

# Generated at 2022-06-23 05:41:32.637000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    sys.path.append(os.path.dirname(__file__))
    import lib
    lib_path = os.path.dirname(lib.__file__)
    test_file_path = os.path.join(lib_path, 'test_yaml.yml')
    with open(test_file_path) as f:
        loader = AnsibleLoader(f)
    assert loader.get_single_data() == {'First item': {'Nested': {'item': 1}}, 'Second item': 2, 'Third item': 3}

# Generated at 2022-06-23 05:41:38.688079
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Sample data for testing instance of class AnsibleLoader
    data = "[{'b': 1}]"

    # Creation of instance of class AnsibleLoader
    test_inst = AnsibleLoader(data)

    # Check if object test_inst is an instance of class AnsibleLoader
    assert isinstance(test_inst, AnsibleLoader)
    assert isinstance(test_inst, Parser)


# Test class AnsibleLoader by using the following functions

# Generated at 2022-06-23 05:41:39.447599
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:41:45.846700
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.config.manager import ConfigManager
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultAES256

    configManager = ConfigManager(['/etc/ansible.cfg', '~/.ansible.cfg'])

    vault_secrets = []
    vault_secrets.append(VaultSecret('vault_password_file', 'ansible', '/etc/ansible/vault_pass'))
    vault_secrets.append(VaultSecret('vault_secret_file', 'ansible', '/etc/ansible/vault_secret'))

# Generated at 2022-06-23 05:41:48.463315
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")
    assert loader

# Generated at 2022-06-23 05:41:52.683686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert hasattr(loader, 'yaml_constructors')
    assert hasattr(loader, 'yaml_multi_constructors')