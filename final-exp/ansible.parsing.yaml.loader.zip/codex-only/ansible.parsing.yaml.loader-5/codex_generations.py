

# Generated at 2022-06-23 05:32:03.216410
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleMapping, AnsibleSequence

    data = AnsibleMapping({
        'key1': ['val1', 'val2'],
        'key2': AnsibleVaultEncryptedUnicode("$ANSIBLE_VAULT;1.1;AES256", u"test"),
        'key3': AnsibleMapping({'test': 'test'}),
        'key4': AnsibleSequence('test', 'test2')
    })
    # TODO: Add unit test once AnsibleUnsafeText has been added
    # data = AnsibleUnsafeText("testing")

# Generated at 2022-06-23 05:32:07.481832
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    snl = AnsibleLoader(None, 'test_AnsibleLoader', None)
    assert snl.file_name == 'test_AnsibleLoader'

# Generated at 2022-06-23 05:32:14.796777
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = dict(
        key1='value1',
        key2=2,
        key3=['item1', 'item2'],
        key4=dict(
            sub_key1=dict(
                subsub_key1='value1'
            ),
            sub_key2='value2'
        )
    )
    stream = Parser.serialize(data)
    loader = AnsibleLoader(stream)
    contents = loader.get_single_data()
    assert contents == data, 'AnsibleLoader was unable to parse its own output'

# Generated at 2022-06-23 05:32:25.111892
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Create a temporary private key file for the Vault unittest.
    '''
    import tempfile
    import os
    os.environ['ANSIBLE_VAULT'] = '1.2'
    s = tempfile.NamedTemporaryFile()
    s.write(b'ANSIBLE_VAULT')
    s.seek(0)
    vault_secrets = [{'key_data': u'bar', 'identifier': u'foo'}]
    a = AnsibleLoader(s, vault_secrets=vault_secrets)
    s.close()
    assert a.file_name == s.name
    assert a.vault_secrets == [{'key_data': u'bar', 'identifier': u'foo'}]

# Generated at 2022-06-23 05:32:30.312604
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    >>> from ansible.parsing.yaml.loader import AnsibleLoader
    >>> from StringIO import StringIO
    '''


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 05:32:41.512865
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VaultSecret
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils.common.yaml import from_yaml

    # TODO: create more comprehensive tests for more use cases in the future.
    # Currently we only test for the case that ansible-vault is used.
    yaml_loader = AnsibleLoader(stream='')


# Generated at 2022-06-23 05:32:46.008977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects

    loader = AnsibleLoader(file_name='myfile')
    assert isinstance(loader.construct_yaml_map(None), objects.AnsibleMapping)
    assert isinstance(loader.construct_yaml_seq(None), objects.AnsibleSequence)

# Generated at 2022-06-23 05:32:46.975695
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = AnsibleLoader(None).get_single_data()
    assert test_data is None

# Generated at 2022-06-23 05:32:57.103502
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.parser import AnsibleParser
    from ansible.parsing.yaml.loader import AnsibleLoader
    from yaml import YAMLObject
    from os import urandom, path
    from tempfile import mktemp
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE
    from ansible.module_utils.six import PY3

    def test_BOOLEAN(obj):
        if obj in BOOLEANS_TRUE:
            return True

# Generated at 2022-06-23 05:33:04.304913
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.construct_python_str == AnsibleConstructor.construct_python_str
    assert loader.construct_yaml_str == AnsibleConstructor.construct_yaml_str
    assert loader.construct_yaml_seq == AnsibleConstructor.construct_yaml_seq
    assert loader.fix_multi_line_strings == AnsibleConstructor.fix_multi_line_strings

# Generated at 2022-06-23 05:33:14.503459
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    def is_dict(yaml_data):
        return isinstance(yaml_data, dict)

    assert(is_dict(AnsibleLoader("{ item1: value1 }")))
    assert(is_dict(AnsibleLoader("{ item1: value1, item2: value2 }")))
    assert(is_dict(AnsibleLoader("""{ item1: value1, item2: { item21: value21, item22: value22 } }""")))
    assert(is_dict(AnsibleLoader(""": item1 : value1\n  item2: value2""")))
    assert(is_dict(AnsibleLoader("""item1: value1\nitem2: value2""")))

# Generated at 2022-06-23 05:33:16.798065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # It should be possible to initialize a class AnsibleLoader with only one parameter (stream)
    aloader = AnsibleLoader(stream=None)
    assert hasattr(aloader, 'vault_secrets')

# Generated at 2022-06-23 05:33:20.862318
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = u"{% raw %} 'raw_string_test' {% endraw %}"

    test_object = AnsibleLoader(stream)

    assert isinstance(test_object, AnsibleLoader)

# Generated at 2022-06-23 05:33:30.807380
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' test ansible.parsing.yaml.loader.AnsibleLoader '''

    loader = AnsibleLoader(None)
    # TODO: check if member variables have been initialized correctly

    if HAS_LIBYAML:
        assert isinstance(loader, Parser)
        assert isinstance(loader, AnsibleConstructor)
        assert isinstance(loader, Resolver)
    else:
        assert isinstance(loader, Reader)
        assert isinstance(loader, Scanner)
        assert isinstance(loader, Parser)
        assert isinstance(loader, Composer)
        assert isinstance(loader, AnsibleConstructor)
        assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:33:39.920634
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class FakeStream(object):
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def read(self, size):
            if self.pos == len(self.data):
                return ''
            if (self.pos + size) > len(self.data):
                size = len(self.data) - self.pos
            s = self.data[self.pos:self.pos + size]
            self.pos += size
            return s

    class FakeVaultSecret(object):
        def __init__(self, secret):
            self.secret = secret

    # Use text from https://docs.python.org/3/library/stdtypes.html#str.islower
    s = u'''\
hello
:
  world
  '''
    fake_vault_

# Generated at 2022-06-23 05:33:48.655465
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret


# Generated at 2022-06-23 05:33:50.237667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream=None)

# Generated at 2022-06-23 05:33:51.896364
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:34:03.149793
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.config.manager import ConfigManager
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode


# Generated at 2022-06-23 05:34:08.187959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('Test AnsibleLoader:')
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO
    else:
        from io import BytesIO
    s = "---"
    al = AnsibleLoader(BytesIO(s.encode('utf-8')))
    al.get_single_data()

# Generated at 2022-06-23 05:34:18.185751
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    example_data = dict(
        boolean=True,
        list=['string', 1, [1, 2, 3]],
        complex_list=['string', 1, dict(a=4, b=5)],
        dict=dict(key=1, key2=2),
        unicode=u'unicode',
        string='string',
    )
    import yaml
    yaml_data = yaml.dump(example_data, default_flow_style=False)
    loader = AnsibleLoader(yaml_data)
    data = loader.get_single_data()
    assert data == example_data
    import json
    json.dumps(example_data)

# Generated at 2022-06-23 05:34:27.382279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an example yaml file
    from io import StringIO
    yaml_content = StringIO(u'''---
- hosts: localhost
  tasks:
  - shell: echo "Hello world!"
''')

    # Load a yaml file with the AnsibleLoader
    import yaml
    loader = AnsibleLoader(yaml_content)
    yaml_content.seek(0)
    loaded_yaml = yaml.load(yaml_content)
    assert loaded_yaml == loader.get_single_data()

    yaml_content.seek(0)
    assert yaml.load(yaml_content) == loader.get_single_data()



# Generated at 2022-06-23 05:34:28.589425
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """Test case for AnsibleLoader class."""
    pass

# Generated at 2022-06-23 05:34:33.076532
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
# We will use this Host entry in another play
- host: tag_Name_WebServer
  gather_facts: no
      '''
    loader = AnsibleLoader(stream)
    loader = loader.get_single_data()
    assert loader == {'host': 'tag_Name_WebServer', 'gather_facts': 'no'}

# Generated at 2022-06-23 05:34:44.365822
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = AnsibleUnicode(
        '''
        a: 1
        b:
            c: 2
            d: [3,4]
        '''
    )

    stream = io.StringIO(data)
    stream.name = 'test'
    loader = AnsibleLoader(stream)
    try:
        res = loader.get_single_data()
    except AttributeError:  # 'list' object has no attribute 'name'
        pass
    except SystemExit:  # 2.7 on Mac OS X has a weird "exit code"
        pass
    else:
        del res  # pyflakes
        raise Ass

# Generated at 2022-06-23 05:34:54.273968
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    loader = AnsibleLoader('')
    assert(loader.construct_yaml_map(None) == {})
    assert(loader.construct_mapping(None) == {})
    assert(loader.construct_yaml_seq(None) == [])
    assert(loader.construct_sequence(None) == [])
    assert(loader.construct_yaml_str(None) == '')
    assert(loader.construct_python_str(None) == '')
    assert(loader.construct_yaml_int(None) == 0)
    assert(loader.construct_yaml_float(None) == 0.0)
    assert(loader.construct_yaml_bool(None) == False)

# Generated at 2022-06-23 05:35:03.620851
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    import io
    import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def _test_representer_loader(self, data):
            loader = AnsibleLoader(data)
            value = loader.get_single_data()
            return yaml.dump(value)

        def test_variable_resolution(self):
            data = u"""
            This is a test.
            --- foo
            bar:
                - 1
                - 2
            """
            expected = u"""
            This is a test.
            --- foo
            bar:
            - 1
            - 2
            """
            self.assertEqual(self._test_representer_loader(data), expected)


# Generated at 2022-06-23 05:35:10.701394
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence

    stream = '''part1: {name} Part 2: {age}'''.format(name=AnsibleUnicode('foo'), age=AnsibleUnicode('18'))

    res = {}
    AnsibleLoader(stream, file_name=None, vault_secrets=None).construct_mapping(None, res)
    assert 'part1' in res
    assert res['part1'] == 'foo Part 2: 18'
    assert isinstance(res['part1'], AnsibleUnicode)

    stream = '''
    part1:
        {name}: foo
        {age}: 18
    '''.format(name=AnsibleUnicode('name'), age=AnsibleUnicode('age'))

# Generated at 2022-06-23 05:35:21.343504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    # pylint: disable=unused-variable

    name1 = 'test_obj'
    name2 = 'test_obj'
    obj1 = {name1: 10}
    obj2 = {name2: 20}
    loader = AnsibleLoader(obj1)
    loaded = loader.get_single_data()
    assert loaded[name1] == obj1[name1]

    # Test overriding __getitem__ in constructor
    loader = AnsibleLoader(obj2)
    loaded = loader.get_single_data()
    assert loaded[name2] == obj2[name2]

    # Test overriding get_single_data


# Generated at 2022-06-23 05:35:26.568133
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    sys.stderr = open("/dev/null", "w")

    try:
        stream = io.StringIO(u"---\nfoo: bar")
        loader = AnsibleLoader(file_name='/dev/null', stream=stream, vault_secrets={})
        assert loader is not None
    finally:
        sys.stderr = sys.__stderr__


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:35.487225
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:35:42.938584
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import yaml

    # Create a loader without a vault secret passed in.
    loader = yaml.AnsibleLoader(stream=None)
    assert loader is not None

    # Create a loader with a vault secret passed in
    loader = yaml.AnsibleLoader(stream=None, vault_secrets=[b'foo'])
    assert loader is not None
    assert loader.vault_secrets[0] == b'foo'



# Generated at 2022-06-23 05:35:49.051061
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = ""
    obj = AnsibleLoader(yaml)
    assert isinstance(obj, Reader)
    assert isinstance(obj, Scanner)
    assert isinstance(obj, Parser)
    assert isinstance(obj, Composer)
    assert isinstance(obj, AnsibleConstructor)
    assert isinstance(obj, Resolver)


# Generated at 2022-06-23 05:35:57.117446
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.dumper import AnsibleDumper

    class D(AnsibleDumper):
        pass

    data = """
---
foo:
  bar: baz
  bam:
    - 1
    - 2
    - "3"
  bof:
    name: bob
    job: builder
    skill: amateur
caf:
  - foo
  - bar
---
foo: &foo
  bar: baz
  bam:
    - 1
    - 2
    - "3"
  bof:
    name: bob
    job: builder
    skill: amateur
caf:
  - foo
  - bar
...
"""

    l = AnsibleLoader(data)
    n = l.get_single_data()
    d = D()
    r

# Generated at 2022-06-23 05:35:58.036555
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('string')

# Generated at 2022-06-23 05:35:58.944959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    pass

# Generated at 2022-06-23 05:36:09.113942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestVaultLib:
        def is_encrypted(self, data):
            return isinstance(data, AnsibleVaultEncryptedUnicode)
        def decrypt(self, data):
            return 'decrypted'

        def get_vault_secrets(self, force=False):
            pass


# Generated at 2022-06-23 05:36:18.465838
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.quoting import quotedScalarString, quotedScalar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils._text import to_text

    yaml_str = """
    # This example is from http://yaml.org/type/bool.html
    # Note also that YAML accepts the strings "true" and "false" as
    # a bool, so you can use that as a string without quotes if you prefer.
    ---
    boolean: yes
    string: "{{ '%s' | quote }}"
    """ % quotedScalarString('$ANSIBLE_VAULT;1.1;AES256')


# Generated at 2022-06-23 05:36:20.667620
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ''' Test load of AnsibleLoader '''

    # Test that the class AnsibleLoader can be loaded
    loader = AnsibleLoader([])

# Generated at 2022-06-23 05:36:23.323941
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    text = '''
    ---
    foo: bar
    '''
    loader = AnsibleLoader(text)
    assert hasattr(loader, 'construct_yaml_map')

# Generated at 2022-06-23 05:36:33.620995
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    loader = AnsibleLoader(None)
    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'add_constructor')
    assert hasattr(loader, 'construct_mapping')
    assert hasattr(loader, 'construct_yaml_seq')
    assert hasattr(loader, '_check_type')
    assert hasattr(loader, '_flatten_mapping')
    assert hasattr(loader, '_flatten_seq')

    with open('test/units/parsing/yaml/loader.yml') as f:
        data = yaml.load(f, Loader=AnsibleLoader)
        assert data is not None
        assert data['test_host']['hostname'] == "{{inventory_hostname}}"


# Generated at 2022-06-23 05:36:35.754614
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    The constructor for AnsibleLoader does not take any arguments.
    :return: nothing
    '''
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:36:43.055504
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, '_MARKER')
    assert hasattr(loader, '_LOADER_ARGS')
    assert hasattr(loader, '_ROLES_PATH_CACHE')
    assert hasattr(loader, '_CONFIG_SECTION')
    assert hasattr(loader, '_config_data')
    assert hasattr(loader, '_config_path')
    assert hasattr(loader, '_config_file_name')
    assert hasattr(loader, '_file_name')
    assert hasattr(loader, '_vault_secrets')
    assert hasattr(loader, '_vault')
    assert hasattr(loader, '_vault_password')
    assert hasattr(loader, '_vault_ids')

# Generated at 2022-06-23 05:36:51.802424
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Unit test for AnsibleLoader

    See https://github.com/ansible/ansible/issues/10139
    """
    stream = u'\x02\r\n\u0001:\x0b\x00\x00\x00\x00\x00\x00\x01\x02\x00\x00\x00@\x00\x00\x00\x00\x00\x00\x00\x00'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == 1

# Generated at 2022-06-23 05:36:52.297094
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:36:53.650628
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open(__file__)
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-23 05:36:54.606094
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:05.394246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    try:
        from yaml import CSafeLoader as SafeLoader, CSafeDumper as SafeDumper
    except ImportError:
        from yaml import SafeLoader, SafeDumper

    from io import StringIO
    import unittest


# Generated at 2022-06-23 05:37:08.513870
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    variable_manager.set_nonpersistent_facts(dict())
    loader = AnsibleLoader(stream=None, variable_manager=variable_manager)

# Generated at 2022-06-23 05:37:10.796546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_yaml_loader = AnsibleLoader(None)
    assert test_yaml_loader

# Generated at 2022-06-23 05:37:15.696496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    stream = StringIO(u'{"a": 1}')
    assert "a" in AnsibleLoader(stream, file_name="test_filename", vault_secrets=None).get_single_data()



# Generated at 2022-06-23 05:37:17.473959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("")
    assert isinstance(loader, AnsibleLoader)


# Generated at 2022-06-23 05:37:25.907253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.elements import AnsibleSequenceNode, AnsibleMappingNode
    from ansible.module_utils.common.yaml import Parser
    from ansible.parsing.yaml.loader import AnsibleLoader
    a = io.BytesIO(b'---\n    - a\n    - b\n    - c\n')

    # Create a class and inherit from the above 5 classes
    class MyLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name=file_name, vault_secrets=vault_secrets)

    #

# Generated at 2022-06-23 05:37:28.637929
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.constructor
    assert issubclass(ansible.parsing.yaml.constructor.AnsibleLoader, AnsibleLoader)

# Generated at 2022-06-23 05:37:38.649931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    load = AnsibleLoader

    # load Vault secrets dict
    v = VaultLib([])
    vault_dict = v.secrets
    vault_dict['id'] = 42
    vault_secrets = {'vaULTsEcrETs': vault_dict}

    # items that should be detected by AnsibleVaultEncryptedUnicode in AnsibleLoader

# Generated at 2022-06-23 05:37:39.411395
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:37:48.692545
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import BytesIO

    a = AnsibleLoader(BytesIO(b"foo:\n  bar"))
    assert isinstance(a.get_single_data(), AnsibleMapping)
    assert isinstance(list(a.get_single_data().keys())[0], AnsibleUnicode)
    assert isinstance(list(a.get_single_data().values())[0], AnsibleMapping)
    assert a.get_single_data()["foo"]["bar"] is None


# Generated at 2022-06-23 05:37:51.724763
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Check that AnsibleLoader is the expected type
    '''
    loader = AnsibleLoader('')

    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-23 05:37:52.979344
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:38:04.266399
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Make sure that if the class is instantiated outside of __init__ that the
    # vault_secrets and file_name members are not overwritten
    # See issue #20273 and PR #20277
    import io

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible import constants as C
    from ansible.parsing.vault import VaultLib

    vault_secrets = dict(
        password='topsecret',
        secret1='secretsauce',
        secret2="moresecret"
    )


# Generated at 2022-06-23 05:38:15.049771
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    import os
    import sys
    import tempfile

    temp_dir = tempfile.mkdtemp()
    yaml_file = os.path.join(temp_dir, 'test.yml')
    with open(yaml_file, 'wb') as test_fd:
        test_fd.write(b'[1,2,3]')
    stream = open(yaml_file, 'rb')
    ansible_loader = AnsibleLoader(stream)
    assert isinstance(next(ansible_loader), list)
    stream.close()
    os.remove(yaml_file)
    os.rmdir(temp_dir)

if __name__ == '__main__':
    if sys.version_info[0] < 3:
        import pickle

# Generated at 2022-06-23 05:38:26.702625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os
    import pytest
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    TEST_DATA_DIR = os.path.join(os.path.dirname(__file__), 'loader_data')
    TEST_FILES = (
        'key_value_pair.yml',
        'list_of_key_value_pairs.yml',
        'complex_key_value_pair.yml',
        'dict_of_key_value_pairs.yml',
    )
    for test_file in TEST_FILES:
        with open(os.path.join(TEST_DATA_DIR, test_file)) as stream:
            data = yaml.load(stream, Loader=AnsibleLoader)


# Generated at 2022-06-23 05:38:28.516053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader(None, None)
    assert isinstance(instance, AnsibleLoader)

# Generated at 2022-06-23 05:38:31.262914
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    assert hasattr(AnsibleLoader, '__init__')
    assert callable(AnsibleLoader.__init__)



# Generated at 2022-06-23 05:38:37.752417
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Unit test for AnsibleLoader constructor'''

    # Test if AnsibleLoader is an instance of Parser, AnsibleConstructor and Resolver
    load = AnsibleLoader('{}')
    assert isinstance(load, Parser)
    assert isinstance(load, AnsibleConstructor)
    assert isinstance(load, Resolver)

# Generated at 2022-06-23 05:38:50.078375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.errors import AnsibleError

    # from ansible.parsing.yaml.loader import AnsibleLoader

    # ==========================================
    # Ansible Constructor Unit Test Subroutines
    # ==========================================

    def ansible_constructor_unit_test(yaml_data):
        if yaml_data is None:
            yaml_data = {}
        yaml_data['__ansible_loader__'] = AnsibleLoader
        return yaml_data

    # ==================================
    # Constructor Unit Test Description
    # ==================================

    def ansible_constructor_unit_test_description():
        return "Ansible Constructor Unit Tests"

    # ==========================================
    # Constructor Unit Test Subroutine
    # ==========================================


# Generated at 2022-06-23 05:38:53.672049
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This is done in a function because it needs to be done after load,
    # otherwise the other modules will not have loaded the plugin_loader
    # and will fail with an import error.

    # TODO: add more tests here
    assert AnsibleLoader

# Generated at 2022-06-23 05:38:56.348982
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert 'yaml.constructor.Constructor' in str(loader)

# This "class" is only to be used in tests. It is not actually used at run time.

# Generated at 2022-06-23 05:39:01.536546
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Object(object):
        pass

    stream = ''
    file_name = Object()
    vault_secrets = Object()
    loader = AnsibleLoader(stream, file_name, vault_secrets)
    assert loader is not None

# Generated at 2022-06-23 05:39:10.384167
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
        foo: 1
        bar: "{{bam}}"
        bam: 2
        list:
        - {{item}}
        - item: {{item}}
        - "{{item}}"
        - "item: {{item}}"
        """

    loader = AnsibleLoader(data)
    loader.construct_yaml_map(data)  # pylint: disable=no-member
    assert loader.get_single_data() == {
        'foo': 1,
        'bar': '2',
        'bam': 2,
        'list': [
            2,
            {'item': 2},
            '{{item}}',
            'item: {{item}}'
        ]
    }

# Generated at 2022-06-23 05:39:14.784782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = VaultLib('AZERTY').secrets
    stream = '{%s}' % vault_secrets
    loader = AnsibleLoader(stream)
    loader.get_single_data()

# Generated at 2022-06-23 05:39:25.791869
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.dumper import AnsibleDumper

    class MyVaultLib(VaultLib):
        ''' subclass VaultLib to avoid loading vault secrets from disk '''

        # pylint: disable=too-many-arguments
        def __init__(self, filename, password=None, password_file=None, vault_secrets=None, raw_contents=None):
            self.filename = filename
            self.raw_contents = raw_contents
            if vault_secrets is None:
                vault_secrets = AnsibleLoader(filename).get_single_data()
            VaultLib.__init__(self, vault_secrets=vault_secrets, password=password, password_file=password_file)

# Generated at 2022-06-23 05:39:29.757148
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # No vars_prompt set
    obj = AnsibleLoader(None, vault_secrets=('default',))
    assert obj.vars_prompt == []
    assert obj.vault_secrets == ('default',)

# Generated at 2022-06-23 05:39:41.232105
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml
    try:
        # python2
        from StringIO import StringIO
    except ImportError:
        # python3
        from io import StringIO

    loader = AnsibleLoader(None)
    # constructor should accept any object that has 'read()' and 'readline()' methods
    assert loader.stream == None

    def readline(self):
        return self.buffer.readline()
    readline_method = type(io.StringIO().readline)
    readline = readline_method(readline, io.StringIO)

    def read(self, size=-1):
        return self.buffer.read(size)
    read_method = type(io.StringIO().read)
    read = read_method(read, io.StringIO)

    class MockStream:
        buffer = StringIO

# Generated at 2022-06-23 05:39:45.762321
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml.error import MarkedYAMLError

    try:
        AnsibleLoader('')
    except MarkedYAMLError as e:
        assert e.problem == 'could not find expected \':\'', 'AnsibleLoader test failed'
    else:
        assert False, 'AnsibleLoader test failed'

# Generated at 2022-06-23 05:39:47.934153
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = dict(a=1)
    ansible_loader = AnsibleLoader(None)
    ansible_loader.construct_yaml_map(None, data)

# Generated at 2022-06-23 05:39:52.205580
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        from yaml import CLoader as Loader
    except ImportError:
        from yaml import Loader
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        assert Loader.__module__ == 'yaml'
    else:
        assert Loader.__module__ == 'ansible.parsing.yaml.loader'

# Generated at 2022-06-23 05:39:53.775821
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader  # pylint: disable=no-member

# Generated at 2022-06-23 05:40:03.168917
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    result = AnsibleLoader('', '', '').__dict__
    assert result['stream'] in result['yaml_reader'].__dict__.values()
    assert result['yaml_reader'] in result['yaml_scanner'].__dict__.values()
    assert result['yaml_scanner'] in result['yaml_parser'].__dict__.values()
    assert 'yaml_parser' in result['yaml_composer'].__dict__
    assert result['file_name'] in result['file_name']
    assert result['vault_secrets'] in result['vault_secrets']

# Generated at 2022-06-23 05:40:14.505443
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Empty file, no vars
    data = b''
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert loader.nodelist == []

    # No vars
    data = b'---\n'
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert loader.nodelist == []

    # No vars
    data = b'---\n# some comment\n'
    loader = AnsibleLoader(data)
    loader.get_single_data()
    assert loader.nodelist == []

    # Vars, no tasks

# Generated at 2022-06-23 05:40:16.167169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=unused-variable
    ansibleloader = AnsibleLoader(None)

# Generated at 2022-06-23 05:40:26.269361
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.utils.unicode import to_unicode
    from ansible.utils.dateutil import parse_date

    data = """
    - hosts: localhost
      user: foo
      sudo: yes
      tasks:
        - name: test
          debug: msg="{{ '\\u2713' }}"
    """

    loader = AnsibleLoader(data)
    yaml_data = loader.get_single_data()
    if yaml_data.get('user') == to_unicode('foo'):
        test = True
    else:
        test = False
    assert test is True

# Generated at 2022-06-23 05:40:34.155905
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load our test YAML
    from ansible.utils.unsafe_proxy import to_bytes
    from ansible.parsing.yaml.loader import construct_yaml_str
    yaml_str = to_bytes('''
- name: test yaml
  hosts: all
  tasks:
  - name: test ps output
    win_shell: ipconfig
    register: ipconfig
''')
    data = construct_yaml_str(yaml_str)

# if called from command line, run unit tests
if __name__ == "__main__":
    impor

# Generated at 2022-06-23 05:40:35.296510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader



# Generated at 2022-06-23 05:40:44.441123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os

    # Get the module search path
    test_dir = os.path.dirname(__file__)
    modules_path = os.path.join(test_dir, '..', '..', '..', 'lib', 'ansible', 'modules')
    sys.path.append(modules_path)
    from units.mock.sys_modules_mock import SYS_MODULES_MOCK

    # Mock a module in the modules path
    sys.modules = SYS_MODULES_MOCK

# Generated at 2022-06-23 05:40:46.540283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:40:55.473106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info < (2, 7):
        # Class AnsibleLoader has been tested with Python version 2.7 only.
        # Since it mixes classes for Python 2.6 and 2.7, it is unclear how
        # it would behave with Python 2.5 and lower.
        # In addition the unit test returns a failure when run with lower Python versions.
        return
    from StringIO import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructorError
    stream = StringIO(u"test: '{{ foo }}'")
    loader = AnsibleLoader(stream)
    assert loader
    # test if AnsibleLoader constructor has raised an exception

# Generated at 2022-06-23 05:40:56.081045
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:05.614035
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-return-statements,too-many-branches
    """This is to test the constructor of class AnsibleLoader"""
    def load_fixture():
        """Try loading a fixture"""
        stream = open('../../test/units/modules/utils/fixtures/constructor.yaml')
        return yaml.load(stream)

    if HAS_LIBYAML:
        try:
            import yaml
            yaml.Loader = AnsibleLoader
        except ImportError:
            print('libyaml Python module not found')
    else:
        try:
            import yaml
            yaml.loader.Reader = AnsibleLoader
        except ImportError:
            print('PyYAML Python module not found')


# Generated at 2022-06-23 05:41:16.844792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml import objects

    yaml_data = """
a_dict:
  key1: value1
  key2:
    key3: value3
  key4:
    - value4_1
    - value4_2
    - value4_3
a_str: value2
a_int: 1
a_list:
    - list1
    - list2
    - list3
"""

    data = AnsibleLoader(yaml_data).get_single_data()
    assert isinstance(data, dict) and len(data) == 5


# Generated at 2022-06-23 05:41:22.118942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import pytest

    simple_yaml_str = b"""
    - hosts: all
      gather_facts: no
      tasks:
        - name: test
          command: /bin/false
    """
    loader = AnsibleLoader(io.BytesIO(simple_yaml_str))
    assert isinstance(loader, AnsibleLoader)
    pytest.raises(StopIteration, next, loader)

# Generated at 2022-06-23 05:41:30.450742
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)
    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, Parser)
    else:
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Composer)

# Generated at 2022-06-23 05:41:33.243104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Ensures that AnsibleLoader() can be instantiated
    """
    assert isinstance(AnsibleLoader(None), AnsibleLoader)

# Generated at 2022-06-23 05:41:33.883804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:41:42.634253
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    test_filename = "test_yaml_loader.yml"
    data = """
- hosts: all
  gather_facts: False
  tasks:
  - command: /bin/foo
    register: foo
    ignore_errors: True
  - debug: var=foo.stdout_lines
"""

    def run_test():
        stream = AnsibleLoader(data, file_name=test_filename)
        data = stream.get_single_data()
        assert isinstance(data, list)
        for task in data:
            assert isinstance(task, AnsibleMapping)

# Generated at 2022-06-23 05:41:50.595970
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml_data = """
    - hosts: localhost
      vars:
        var1: "{{ lookup('env','HOME') }}/{{ inventory_hostname }}"
      tasks:
      - shell: echo {{ var1 }}
        register: result
      - debug: var=result.stdout
    """

    loader = AnsibleLoader(yaml_data).get_single_data()
    assert loader is not None
    assert loader.get('hosts') == 'localhost'
    assert loader.get('vars') == {'var1': "{{ lookup('env','HOME') }}/{{ inventory_hostname }}"}
    assert loader.get('tasks')



# Generated at 2022-06-23 05:41:53.281632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #Culprit is the call to super(AnsibleLoader, self).__init__() which is not supported for multiple inheritance
    AnsibleLoader('')

# Generated at 2022-06-23 05:41:55.711778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # FIXME: No unit tests at the moment
    assert True