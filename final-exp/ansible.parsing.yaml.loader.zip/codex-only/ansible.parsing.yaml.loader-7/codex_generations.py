

# Generated at 2022-06-23 05:31:57.101313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    module = AnsibleLoader("", file_name='t.yaml')
    module.get_single_data()

# Generated at 2022-06-23 05:32:06.171697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.reader import AnsibleReader
    from ansible.parsing.yaml.scanner import AnsibleScanner
    from ansible.parsing.yaml.parser import AnsibleParser

    assert issubclass(AnsibleLoader, AnsibleReader)
    assert issubclass(AnsibleLoader, AnsibleScanner)
    assert issubclass(AnsibleLoader, AnsibleParser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-23 05:32:12.263884
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
    #!/usr/bin/python

    - hosts: "{{ host_pattern | default('all') }}"
    '''
    load = AnsibleLoader(stream)
    data = load.get_single_data()
    assert data['hosts'] == '{{ host_pattern | default(\'all\') }}'

# Generated at 2022-06-23 05:32:13.233357
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:32:23.991560
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import yaml

    test_data = """
    - hosts: all
      tasks:
      - shell: date
        register: date
      - debug: msg="{{ date.stdout }}"

    - hosts: webservers
      tasks:
      - debug: msg="{{ item }}"
        with_items:
        - foo
        - bar
        - baz
        when: ansible_os_family == 'RedHat'
    """

    # need to override base class members because they use super()
    old_base_ctor = yaml.BaseConstructor.__init__
    yaml.BaseConstructor.__init__ = lambda self, loader=None: None

    old_base_res = yaml.BaseResolver.__init__
    yaml.BaseResolver.__init__ = lambda self: None



# Generated at 2022-06-23 05:32:26.914836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(file_name="test", vault_secrets=["test_secret"])
    assert loader.vault_secrets == ["test_secret"]
    assert loader.file_name == "test"

# Generated at 2022-06-23 05:32:36.510935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    loader = AnsibleLoader(None)
    # test set_vault_secrets()
    new_vault_secrets = dict(test_key='test_value')
    loader.set_vault_secrets(new_vault_secrets)
    assert loader.vault_secrets == new_vault_secrets
    # test add_constructor()
    from ansible.parsing.yaml.constructor import SafeConstructor
    loader.add_constructor(u'!vault', AnsibleVaultEncryptedUnicode.construct_yaml_vault)
    assert loader.constructors[u'!vault'] == AnsibleVaultEncryptedUnicode.construct_yaml_vault
    #

# Generated at 2022-06-23 05:32:40.088154
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert issubclass(AnsibleLoader, AnsibleBaseYAMLObject)

# Generated at 2022-06-23 05:32:49.059258
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader

    class Fake:
        pass

    fake = Fake()
    fake.file_name = "fname"
    fake.vault_secrets = "somesecrets"

    c = AnsibleConstructor(file_name=fake.file_name, vault_secrets=fake.vault_secrets)
    assert c.file_name == fake.file_name
    assert c.vault_secrets == fake.vault_secrets

    c = AnsibleConstructor.__new__(AnsibleConstructor)
    assert c.file_name is None
    assert c.vault_secrets is None



# Generated at 2022-06-23 05:33:00.705515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    if HAS_LIBYAML:
        from ansible.parsing.yaml.loader import AnsibleLoader
    else:
        from ansible.parsing.yaml.loader import AnsibleLoader as AnsibleLoader
    from yaml.constructor import ConstructorError
    import yaml

    content = '{"foo": "bar"}'
    assert(list(AnsibleLoader(content)) == [{u'foo': u'bar'}])

    content = '{"foo": 1}'
    assert(list(AnsibleLoader(content)) == [{u'foo': 1}])

    content = '{"foo": 1.2}'

# Generated at 2022-06-23 05:33:11.651533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.module_utils._text import to_bytes, to_text

    # Round trip an empty dict
    data = {}
    # the extra blank line prevents a scan error
    stream = to_bytes("""\n
---
""")
    loader = AnsibleLoader(stream)
    output = AnsibleDumper().dump(loader.get_single_data())

    assert data == loader.get_single_data()
    assert '\n' not in to_text(output)
    assert output.strip() == b'{}'

    # Round trip an empty list
    data = []
    stream = to_bytes("""\n
---
-
""")
    loader = AnsibleLoader(stream)
    output = AnsibleDumper().dump

# Generated at 2022-06-23 05:33:14.856814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=invalid-name
    my_yaml_loader = AnsibleLoader(file_name='filename', vault_secrets=['defaultpassword'])
    my_yaml_loader.get_single_data()

# Generated at 2022-06-23 05:33:17.744287
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    stream = io.StringIO(u"""
        ---
        # Empty
        {}

        # Empty
        """)
    loader = AnsibleLoader(stream)
    assert list(loader) == [{}, {}]



# Generated at 2022-06-23 05:33:19.568231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:33:21.002014
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    a = AnsibleLoader(None)
    assert isinstance(a, AnsibleLoader)

# Generated at 2022-06-23 05:33:32.461375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Simplest possible constructor test is to instantiate a class AnsibleLoader
    try:
        x = AnsibleLoader(None)
        assert x is not None
    except:
        assert False

    # Test __init__() of AnsibleLoader, the value of self.file_name is None
    # in the AnsibleLoader, the attribute 'file_name' should be set
    # Note: This test would not work with PyYAML < 5.1
    if hasattr(x, "file_name"):
        assert x.file_name is None
    else:
        assert True  # PyYAML < 5.1 does not have attribute file_name

    # Test __init__() of AnsibleLoader, the value of self.vault_secrets is None
    # in the AnsibleLoader, the attribute 'vault_secrets' should

# Generated at 2022-06-23 05:33:36.434551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ""
    file_name = "file_name"
    vault_secrets = ["vault_secret_0", "vault_secret_1"]

    loader = AnsibleLoader(stream, file_name, vault_secrets)

    assert loader.file_name == file_name
    assert vault_secrets == loader._vault_secrets

# Generated at 2022-06-23 05:33:38.588825
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# Generated at 2022-06-23 05:33:48.002214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        assert (issubclass(AnsibleLoader, Parser))
        assert (issubclass(AnsibleLoader, AnsibleConstructor))
        assert (issubclass(AnsibleLoader, Resolver))

    # pylint: disable=protected-access
    assert (not hasattr(AnsibleLoader, 'Reader'))
    assert (not hasattr(AnsibleLoader, 'Scanner'))
    assert (not hasattr(AnsibleLoader, 'Parser'))
    assert (not hasattr(AnsibleLoader, 'Composer'))

    if sys.version_info[0] < 3:
        assert (hasattr(AnsibleLoader, 'BaseConstructor'))

# Generated at 2022-06-23 05:33:53.516270
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open("test/unit/parsing/yaml/data/sample2.yaml")
    l = AnsibleLoader(stream, "test/unit/parsing/yaml/data/sample2.yaml")
    data = l.get_data()
    assert isinstance(data, dict)
    stream.close()

# Generated at 2022-06-23 05:34:04.519134
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleUnsafeText
    from ansible.parsing.vault import VaultLib
    loader = AnsibleLoader(None, vault_secrets=['test1', 'test2'])

    my_secret = "my secret string"
    vault = VaultLib([u'test1'])
    enc_data = vault.encrypt(my_secret)
    data = loader.construct_yaml_str(enc_data)
    assert data == AnsibleVaultEncryptedUnicode(my_secret)

    loader = AnsibleLoader(None, vault_secrets=None)

    # v1 format
    data = loader.construct_yaml_str(enc_data)

# Generated at 2022-06-23 05:34:11.217289
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    import StringIO

    s = StringIO.StringIO(u"""
    ---
    foo: bar
    """)

    vault_secrets = dict(vault_password='vault1')
    loader = AnsibleLoader(s, vault_secrets=vault_secrets)
    data = loader.get_single_data()

    assert 'foo' in data
    assert data['foo'] == 'bar'

# Generated at 2022-06-23 05:34:13.638509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert loader.vault_secrets is None

# Generated at 2022-06-23 05:34:15.995252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    i = AnsibleLoader('[]')
    assert isinstance(i, AnsibleLoader)

# vim: set expandtab:ts=4:sw=4:

# Generated at 2022-06-23 05:34:25.336786
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test that the constructor is a subclass of
    # the correct yaml classes.
    assert issubclass(AnsibleLoader, Parser)
    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)
    else:
        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Composer)
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Resolver)


# Generated at 2022-06-23 05:34:36.227093
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # For pyyaml/yaml < 5.1
    try:
        AnsibleLoader(stream=None)
    except TypeError as e:
        if '__init__() takes at least 3 arguments' in str(e):
            raise SkipTest("yaml < 5.1")

    assert 'object' == AnsibleLoader(stream=None).construct_yaml_str(node=None)

    try:
        AnsibleLoader(stream=None).construct_yaml_seq(node=None)
    except NotImplementedError:
        pass

    try:
        AnsibleLoader(stream=None).construct_yaml_map(node=None)
    except NotImplementedError:
        pass

    assert 'object' == AnsibleLoader(stream=None).construct_yaml_omap(node=None)


# Generated at 2022-06-23 05:34:46.326080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    #
    # Test AnsibleLoader
    #
    # Instantiate AnsibleLoader
    ansible_loader = AnsibleLoader(file_name='test', vault_secrets='abc')
    #print("AnsibleLoader: %s" % (ansible_loader))

    # Test __init__()
    assert ansible_loader.file_name == 'test'
    assert ansible_loader.vault_secrets == 'abc'

    # Test file name
    ft  = dict()
    ft['a'] = 1
    ansible_loader.file_name('foo')
    ansible_loader.file_name(ft)
    ansible_loader.file_name(None)

    # Test vault secrets
    ansible_loader.vault_secrets('foo')

# Generated at 2022-06-23 05:34:56.976019
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.common.yaml import HAS_LIBYAML
    from io import StringIO

    data = StringIO('''\
    # before
    - host: www1
      user: example
      roles:
        - common
        - web
        - foo

    # after
    - host: www2
      user: example
      roles:
        - common
        - web
        - foo
    ''')

    class MockHost:
        pass

    host = MockHost()
    host.get_vault_secrets = lambda: None

    loader = AnsibleLoader(data, 'test_anynines.yml', host=host)
    list_of_hosts = loader.get_single_data()


# Generated at 2022-06-23 05:35:06.900723
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test passing invalid arguments to constructor

    # TODO: fail because we are not passing file_name
    # loader = AnsibleLoader(None)
    # try:
    #     loader.get_single_data()
    #     assert(False)
    # except AssertionError:
    #     assert(True)

    # Test passing valid arguments to constructor

    loader = AnsibleLoader(None, file_name="test/ansible_loader/test1.yml")
    assert loader.get_single_data() == {"a": "b", "c": "d"}

    loader = AnsibleLoader(None, file_name="test/ansible_loader/test2.yml")
    assert loader.get_single_data() == ["a", "b", "c"]


# Generated at 2022-06-23 05:35:11.231292
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleUnicode

    source = 'label: {{ ansible_eth0.device }}'
    loader = AnsibleLoader(source)
    data = loader.get_single_data()
    assert isinstance(data['label'], AnsibleUnicode)

# Generated at 2022-06-23 05:35:16.972804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Ensure that base classes of AnsibleLoader are properly initialized

    This is a very simple test, we just instantiate the class with
    any arguments and make sure that it doesn't raise any exception.
    '''
    class FakeStringIO:
        pass

    AnsibleLoader(FakeStringIO(''), file_name="my_file", vault_secrets={})

# Generated at 2022-06-23 05:35:29.877152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    l = AnsibleLoader(b"---\n- {foo: bar}")
    l.get_single_data()
    assert isinstance(l.get_single_data(), AnsibleSequence)
    assert isinstance(l.get_single_data()[0], AnsibleMapping)
    assert l.get_single_data()[0]["foo"] == "bar"

    d = AnsibleDumper(explicit_start=True, explicit_end=True)
    s = d.dump(l.get_single_data())
    assert s == b"---\n- {foo: bar}\n..."

    l.dispose()

# Generated at 2022-06-23 05:35:31.812400
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    ansible_loader = AnsibleLoader(sys.stdin)
    assert ansible_loader

# Generated at 2022-06-23 05:35:36.272520
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml import objects

    l = AnsibleLoader(file_name="test", vault_secrets=[objects.VaultSecret('secret', 'password')])

    assert l.file_name == "test"
    assert l.vault_secrets == [objects.VaultSecret('secret', 'password')]

# Generated at 2022-06-23 05:35:48.876424
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import yaml
    except ImportError:
        print("For unit testing of AnsibleLoader, you need to install PyYAML")
        sys.exit(1)

    class FakeStream:
        read_data = """---
- hosts: localhost
  tasks:
  - name: test
    user: root
    ping:
    when: 1 < 2
        """
        def __init__(self):
            self.read_pos = 0
        def read(self, length):
            result = self.read_data[self.read_pos:self.read_pos + length]
            self.read_pos += length
            return result

    def test_method(stream):
        """Check AnsibleLoader works"""

# Generated at 2022-06-23 05:35:52.256690
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # read yaml file
    f = open("playbook.yml", 'r')
    yaml_data = f.read()
    f.close()

    # construct a AnsibleLoader
    loader = AnsibleLoader(yaml_data)
    print (loader)

    
if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:55.315242
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    stream = None
    file_name = None
    vault_secrets = None

    assert AnsibleLoader(stream, file_name, vault_secrets)



# Generated at 2022-06-23 05:36:01.447899
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestLoader(AnsibleLoader):
        def check_data(self):
            assert isinstance(self.get_single_data(), dict)

    data = """
    ---
    - hosts: localhost
      gather_facts: no
      tasks: []
    """
    assert isinstance(AnsibleLoader(data).get_data(), list)
    assert isinstance(TestLoader(data).get_single_data(), dict)

# Generated at 2022-06-23 05:36:07.009151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    loader = AnsibleLoader(StringIO(""))
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.get_single_data(), list)
    assert isinstance(loader.get_single_data(), list)
    assert isinstance(loader._vault, VaultLib)
    assert loader.stream == StringIO("")

# Generated at 2022-06-23 05:36:09.457025
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-23 05:36:11.353252
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    i = AnsibleLoader(None, None)
    assert i


# Generated at 2022-06-23 05:36:15.782255
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name, vault_secrets)

    assert TestLoader


# Note:
#   Needs yaml.safe_load() to be mocked

# Generated at 2022-06-23 05:36:25.990894
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import _safe_load_all, _safe_load
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib, VaultEditor

    # Create an encrypted string
    vault_secret = "1234567890"
    vault = VaultLib(vault_secret)
    encrypt_string = vault.encrypt("top_secret")

    # Create a string with encrypted string
    encrypt_string = str(encrypt_string)
    yaml_test = ("{test: " + encrypt_string + "}")
    yaml_test = yaml_test.encode()

    # Load the test string with Ansible

# Generated at 2022-06-23 05:36:27.404182
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    r = AnsibleLoader(stream=None)
    assert r

# Generated at 2022-06-23 05:36:31.611312
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = dict(a=1, b=2, c=3)
    stream = '''
---
a: 1
b: 2
c: 3
'''
    loader = AnsibleLoader(stream)
    assert loader.get_single_data() == data
    assert loader.get_data() == data

# Generated at 2022-06-23 05:36:33.916951
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(file_name="test.yaml", vault_secrets="testVaultSecrets")
    assert ansible_loader

# Generated at 2022-06-23 05:36:38.603672
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    ansible_loader = AnsibleLoader(None)

    assert isinstance(ansible_loader, AnsibleBaseYAMLObject), 'AnsibleLoader is not a AnsibleBaseYAMLObject'

# Generated at 2022-06-23 05:36:46.821278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    def test_pass_in_file_name():
        stream = '{"key": "value", "key2": 3}'
        loader = AnsibleLoader(stream, file_name='test.yml')
        assert loader.file_name == 'test.yml'

    def test_pass_in_vault_secrets():
        stream = '{"key": "value", "key2": 3}'
        vault_secrets = {'key': 'vaultvalue', 'key2': 'vaultvalue2'}
        loader = AnsibleLoader(stream, vault_secrets=vault_secrets)
        assert loader.vault_secrets == vault_secrets

# Generated at 2022-06-23 05:36:55.409301
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #test_yaml_scripts = os.path.join(os.path.dirname(__file__), '../../test/yaml')
    #yaml_files = [ os.path.join(test_yaml_scripts, f) for f in os.listdir(test_yaml_scripts) ]
    #for yaml_file in yaml_files:
    #    with open(yaml_file, 'r') as stream:
    #        try:
    #            AnsibleLoader(stream)
    #        except:
    #            print("Failed on %s" % yaml_file)
    #            raise
    pass

# Generated at 2022-06-23 05:37:05.961598
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    import yaml

    vault_password = '$ecret'
    vault = VaultLib(vault_password).encrypt("my secret string")

    data_mapping = dict(
        a=1,
        b=2,
        c=dict(
            d=3,
            e=4,
            f=dict(
                g=5,
                h=6,
            ),
        ),
        vault=vault,
    )


# Generated at 2022-06-23 05:37:13.593307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib

    # Test simple vault ID loading

# Generated at 2022-06-23 05:37:14.654096
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader({}), AnsibleLoader)


# Generated at 2022-06-23 05:37:20.780307
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    filename = './test/data/vault_mixed.yml'
    vault_secrets = [('vault_variable', 'secret_value')]

    with open(filename,'r') as stream:
        loader = AnsibleLoader(stream, file_name=filename, vault_secrets=vault_secrets)
        yaml = loader.get_single_data()

    assert yaml['vault_variable'] == vault_secrets[0][1]

# Generated at 2022-06-23 05:37:32.023068
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml

    # Input data (to be fed to the AnsibleLoader class)
    data = b'''
    - hosts: localhost
      tasks:
      - debug: msg="Hello world!"
      - debug: var={{ lookup('env', 'USER') }}
    '''

    # Declare that the input data is in YAML format
    loader = yaml.Loader(data)

    # Apply the parsing
    yaml_data = loader.get_single_data()

    # Print the resulting data structure
    import pprint
    pprint.pprint(yaml_data)

    # Expected output:
    # [{'hosts': 'localhost',
    #   'tasks': [{'debug': {'msg': 'Hello world!'}},
    #             {'debug': {'var': '{{ lookup('

# Generated at 2022-06-23 05:37:44.149503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is the class defined in this file
    # instantiate AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    al = AnsibleLoader("foobar", vault_secrets="foobar")
    # test AnsibleLoader
    assert al.vault_secrets == "foobar"
    # test AnsibleLoader.construct_yaml_str
    # pylint: disable=protected-access

# Generated at 2022-06-23 05:37:51.557874
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Test the AnsibleLoader class constructor
    """

    data = """
- hosts: localhost
  tasks:
    - name: test
      debug:
        msg: Hello world
"""

    with open('testAnsibleLoader.yml', 'w') as output:
         output.write(data)

    loader = AnsibleLoader(data)
    data_loaded = loader.get_single_data()

    assert isinstance(data_loaded, list)

# Generated at 2022-06-23 05:37:53.668561
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(isinstance(loader, AnsibleLoader))


# Generated at 2022-06-23 05:38:04.802498
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    construct_yaml_map = """
    test_seq:
      - item1
      - item2
      - 3
    test_map:
      key1: value1
      key2: value2
      key3: 3
    """
    construct_yaml_map_expected = {
        'test_seq': ['item1', 'item2', 3],
        'test_map': {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 3
        }
    }

    construct_yaml_omap = """
    test_omap: !!omap
      - key1: value1
      - key2: value2
      - key3: 3
    """

# Generated at 2022-06-23 05:38:12.321658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 05:38:20.473170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Load plain data
    data1 = """
    foo:
      bar: baz
    """

    data = AnsibleLoader(data1).get_single_data()
    assert data.get('foo') == dict(bar='baz')

    # Load with prefix
    data2 = """
    ---
    foo:
      bar: baz
    """

    data = AnsibleLoader(data2).get_single_data()
    assert data.get('foo') == dict(bar='baz')

    # Load with suffix
    data3 = """
    foo:
      bar: baz
    ...
    """

    data = AnsibleLoader(data3).get_single_data()
    assert data.get('foo') == dict(bar='baz')

    # Load with both prefix and suffix

# Generated at 2022-06-23 05:38:26.308527
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    valid_content = """
---
- hosts: localhost
  tasks:
  - name: Test task
    debug:
      msg: "System {{ ansible_distribution }} is of type {{ ansible_distribution_version }}"
"""

    loader = AnsibleLoader(stream=valid_content)
    assert loader is not None
    assert loader.get_single_data() is not None

# Generated at 2022-06-23 05:38:35.833616
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    vault = VaultLib(['vaultpassword'])

# Generated at 2022-06-23 05:38:36.648372
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO
    pass

# Generated at 2022-06-23 05:38:45.460297
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.nodes import AnsibleScalarNode
    from ansible.parsing.yaml.representer import AnsibleRepresenter
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def test_constructor(self):

            # create a unicode object and check the results on python2 and python3
            test_unicode = AnsibleUnicode(u'\u263a')
            self.assertEqual(test_unicode, u'\u263a')

# Generated at 2022-06-23 05:38:45.998496
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:46.769108
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:49.366327
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml
    yaml.load("", Loader=AnsibleLoader)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 05:38:57.030522
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an instance of the AnsibleLoader class class
    # and test the object creation
    al = AnsibleLoader('stream')
    assert isinstance(al, AnsibleConstructor)
    #assert isinstance(al, Resolver)
    assert isinstance(al, Parser)
    if HAS_LIBYAML:
        assert isinstance(al, Parser)
    else:
        assert isinstance(al, Reader)
        assert isinstance(al, Scanner)
        assert isinstance(al, Parser)
        assert isinstance(al, Composer)
    assert al.stream == 'stream'

# Generated at 2022-06-23 05:38:58.656681
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:39:05.672773
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
- hosts: localhost
  tasks:
  - debug:
      msg: hello
  - debug:
      msg: world
'''
    loader = AnsibleLoader(data)
    for x in loader:
        print(x)


if __name__ == '__main__':
    loader = AnsibleLoader(open('./test.yml', 'r'))
    print(loader.get_single_data())

# Generated at 2022-06-23 05:39:17.642902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-statements
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnicode
    import os
    import re

    test_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    data_dir = os.path.join(test_dir, 'lib', 'ansible', 'parsing', 'yaml', 'data')

    def _get_data(name):
        with open(os.path.join(data_dir, name), 'rb') as data_file:
            data = data_file.read()
        return data

    # data = AnsibleLoader(stream=_get_data('example.y

# Generated at 2022-06-23 05:39:27.207379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test valid Ansible yaml
    s = "---\nvar: val"
    assert AnsibleLoader(s).get_single_data() == {"var": "val"}
    # see https://github.com/yaml/pyyaml/wiki/PyYAML-yaml.load(input)-Deprecation
    assert AnsibleLoader(s).get_single_data() == {"var": "val"}
    # test invalid Ansible yaml, should raise YAMLError
    s = "---\n- a: b\n- c: d"
    try:
        AnsibleLoader(s).get_single_data()
        assert 0
    except:  # pylint: disable=bare-except
        pass
    # see https://github.com/yaml/pyyaml/wiki/PyYAML-y

# Generated at 2022-06-23 05:39:30.204313
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    AnsibleConstructor(file_name='test', vault_secrets=None)

# Generated at 2022-06-23 05:39:33.980658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class AnsibleLoaderTest(AnsibleLoader):
        pass

    # inherited __init__ should be replaced
    _ = AnsibleLoaderTest('stream', "file_name", "vault_secrets")

# Generated at 2022-06-23 05:39:37.628632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test constructor without parameters
    loader = AnsibleLoader(None)
    assert loader is not None

    # test constructor with parameters
    loader = AnsibleLoader(None, file_name='file.yml', vault_secrets=[])
    assert loader is not None
    assert loader.file_name == 'file.yml'
    assert loader.vault_secrets == []

# Generated at 2022-06-23 05:39:43.180383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = b'''
        - hosts: localhost
          gather_facts: no
          tasks:
            - name: ping
              ping:
    '''

    assert AnsibleLoader(data).get_single_data() == [{'hosts': 'localhost', 'gather_facts': 'no', 'tasks': [{'name': 'ping', 'ping': None}]}]

# Generated at 2022-06-23 05:39:47.301128
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ AnsibleLoader unit test (pylint)"""
    results = {}
    results['file_name'] = 'sample_ansible_loader.yaml'
    results['vault_secrets'] = None

    loader = AnsibleLoader(results, results['file_name'], results['vault_secrets'])

    assert loader is not None

# Generated at 2022-06-23 05:39:58.528367
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleUnicode
    import sys

    def __roundtrip_test(data, expected):
        '''
            This test takes a byte string, passes it to AnsibleLoader, then
            converts it back to a byte string.  The byte string which comes
            out the other end should exactly equal the byte string which went
            in.  No changes should be made to the data.
            '''
        with open(sys.argv[0], 'rb') as f:
            loader = AnsibleLoader(f)
            results = loader.get_single_data()
            assert results == u''


# Generated at 2022-06-23 05:40:06.993902
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # make sure you can load an empty file with no error
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    yaml.load("", Loader=AnsibleLoader)
    yaml.load("---", Loader=AnsibleLoader)
    stream = """
---
{
  a: b
}
"""
    obj = yaml.load(stream, Loader=AnsibleLoader)
    assert obj == {'a': 'b'}

    assert isinstance(obj['a'], AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-23 05:40:17.223209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime

    from yaml import load

    data = """
    - hosts: localhost
      gather_facts: no
      tasks:
      - name: test
        shell: echo hello
        changed_when: false
        when: inventory_hostname == 'localhost' and ansible_date_time.month == '%s'
    """ % datetime.datetime.now().strftime('%B')

    result = load(data, AnsibleLoader)
    assert result[0]['tasks'][0]['when'] == "(inventory_hostname == 'localhost') and (ansible_date_time.month == '%s')" % datetime.datetime.now().strftime('%B')

# Generated at 2022-06-23 05:40:29.268466
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys
    import io

    src_yaml = '''---
- hosts: all
  gather_facts: yes
  vars:
    var1: {a: 1, b: [2, 3]}
    var2: "{{ lookup('env','HOME') }}"
  tasks:
  - debug: msg="{{ var1.a }}"
  - debug: msg="{{ var2 }}"
  - debug: msg="{{ lookup('env','HOME') }}"
  - debug: msg="{{ lookup('env','ANSIBLE_LIBRARY') }}"
'''

    # construct
    AnsibleLoader(io.StringIO(src_yaml))

    # dump
    stream = io.StringIO()

# Generated at 2022-06-23 05:40:33.362326
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=no-self-use
    '''
    Make sure the constructor will not fail.
    '''
    loader = AnsibleLoader(None)
    assert loader
    assert loader.construct_yaml_map({}, {}) == {}

    loader = AnsibleLoader(None)
    assert loader.construct_yaml_seq({}, {}) == []

# Generated at 2022-06-23 05:40:36.464043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    assert HAS_LIBYAML
    from ansible.parsing.yaml.loader import AnsibleLoader

    ansible_loader = AnsibleLoader("test")
    assert ansible_loader

# Generated at 2022-06-23 05:40:45.218288
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import unittest
    import yaml

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.AnsibleLoader = AnsibleLoader


        def tearDown(self):
            pass


        def test_base_loader(self):
            raw = "---\n- hosts: all\n  tasks:\n  - name: ping\n    ping: {}"
            data = yaml.load(raw, Loader=AnsibleLoader)
            self.assertTrue(data is not None)
            self.assertTrue(data['tasks'][0]['name'] == 'ping')
            self.assertTrue(data['tasks'][0]['ping'], {})



# Generated at 2022-06-23 05:40:48.351881
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test code here
    # (nothing yet)
    pass

# Generated at 2022-06-23 05:40:56.904122
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test case for AnsibleLoader constructor
    '''

# Generated at 2022-06-23 05:41:00.149632
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Parser)
    assert issubclass(AnsibleLoader, AnsibleConstructor)
    assert issubclass(AnsibleLoader, Resolver)


if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:41:10.347304
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import VaultPassword
    import re

    secret = VaultSecret('vaultpassword', 'foobar')
    password = VaultPassword(secret, False)
    vault = VaultLib(password)


# Generated at 2022-06-23 05:41:20.817421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ast
    import yaml
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    def string_representer(dumper, data):
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)

    def unicode_representer(dumper, data):
        return dumper.represent_scalar('tag:yaml.org,2002:str', data)

    def secret_representer(dumper, data):
        return dumper.represent_scalar(u'tag:yaml.org,2002:str', u'this-is-an-encrypted-value')

# Generated at 2022-06-23 05:41:24.519841
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from io import BytesIO

    loader = AnsibleLoader(BytesIO(b'{"foo": "2013-09-30T22:59:38Z"}'))

    result = next(loader)
    assert result == {"foo": datetime.datetime(2013, 9, 30, 22, 59, 38)}

# Generated at 2022-06-23 05:41:26.338798
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(open('test_data.yml', 'rb'))
    x.get_single_data()

# Generated at 2022-06-23 05:41:27.362450
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('hello world')

# Generated at 2022-06-23 05:41:35.227625
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_loader = AnsibleLoader('string', 'file')

    assert test_loader.file_name == 'file'

    test_loader = AnsibleLoader('string', 'file', ['a', 'b'])

    assert test_loader.file_name == 'file'
    assert test_loader.vault_secrets == ['a', 'b']

    test_loader = AnsibleLoader('string', vault_secrets=['a', 'b'])

    assert test_loader.file_name is None
    assert test_loader.vault_secrets == ['a', 'b']

# Generated at 2022-06-23 05:41:45.747728
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 05:41:56.753035
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.nodes import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleVaultSecret
    import ansible.parsing.yaml.objects
    class _AnsibleVaultSecret:
        def __init__(self):
            self.vault_pass = "password"
    ansible.parsing.yaml.objects.AnsibleVaultSecret = _AnsibleVaultSecret