

# Generated at 2022-06-23 05:32:01.865415
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "---\nfoo: True\nbar: False\n"
    loader = AnsibleLoader(stream)
    loader = loader.get_single_data()

if __name__ == "__main__":
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-23 05:32:08.302067
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test AnsibleLoader.
    '''
    import sys

    if sys.version_info < (2,7):
        import unittest2 as unittest
    else:
        import unittest

    # AnsibleLoader(stream, file_name=None, vault_secrets=None)

    class TestAnsibleLoader(unittest.TestCase):

        def test_init(self):
            '''
            Test AnsibleLoader.__init__()
            '''
            stream = []
            file_name = None
            vault_secret = {}
            loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secret)
            self.assertIsInstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:32:13.815896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    FAKEYAML = '''
- hosts: all
  gather_facts: True
  sudo: True
  tasks:
  - name: bogus | SUCCESS => {
      "changed": false,
      "ping": "pong"
    }
'''
    loader = AnsibleLoader(FAKEYAML, vault_secrets=None)
    assert loader

# Generated at 2022-06-23 05:32:20.478209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    # pylint: disable=unsubscriptable-object
    stream = io.StringIO(u'{"var1": "bar"}')
    ansible_loader = AnsibleLoader(stream)
    yaml_object = ansible_loader.get_single_data()
    assert yaml_object['var1'] == 'bar'
    assert ansible_loader.data is not None
    if HAS_LIBYAML:
        assert ansible_loader.data[0]['var1'] == 'bar'
    else:
        assert ansible_loader.data[0]['value']['var1'] == 'bar'

# Generated at 2022-06-23 05:32:29.314911
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import stat

    # test bool constructor
    yaml = '''
    - bool
    - Yes
    - No
    - True
    - False
    - On
    - Off
    - 1
    - 0
    '''
    data = AnsibleLoader(yaml).get_single_data()
    assert data[0] is True
    assert data[1] is True
    assert data[2] is False
    assert data[3] is True
    assert data[4] is False
    assert data[5] is True
    assert data[6] is False
    assert data[7] is True
    assert data[8] is False

    # test octal
    yaml = '''
    - 0o34
    - 0o25
    '''
    data = AnsibleLoader(yaml).get_single_data

# Generated at 2022-06-23 05:32:40.647009
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Test case for AnsibleLoader class
    '''

    # Test case 1: Check that "AnsibleLoader" class is inherited from "Reader"
    # class
    loader_1 = AnsibleLoader(None)
    assert isinstance(loader_1, Reader), 'Test Failed: AnsibleLoader is not inherited from Reader class'

    # Test case 2: Check that "AnsibleLoader" class is inherited from "Scanner"
    # class
    loader_2 = AnsibleLoader(None)
    assert isinstance(loader_2, Scanner), 'Test Failed: AnsibleLoader is not inherited from Scanner class'

    # Test case 3: Check that "AnsibleLoader" class is inherited from "Parser"
    # class
    loader_3 = AnsibleLoader(None)

# Generated at 2022-06-23 05:32:42.325677
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, Reader)

# Generated at 2022-06-23 05:32:52.950952
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals
    import ansible.parsing.yaml.objects as yaml_objects
    import datetime
    import os

    data = '''
---
- name: file
  src: /etc/hosts
  dest: /tmp/hosts
'''
    filename = 'ansible_test_file'
    stream = file(filename, 'w')
    stream.write(data)
    stream.close()
    stream = file(filename, 'r')
    loader = AnsibleLoader(stream)
    stream.close()
    os.unlink(filename)

    hostvars = loader.get_single_data()
    first_var = hostvars[0]
    assert first_var['name'] == 'file'

# Generated at 2022-06-23 05:33:02.939142
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:33:08.107152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# class TestAnsibleLoader(unittest.TestCase):
#     def test_AnsibleLoader(self):
#         yaml_dict = AnsibleLoader(open("../../../../../HISTORY.rst"))
#         print(yaml_dict)
#
# if __name__ == '__main__':
#     unittest.main()

# Generated at 2022-06-23 05:33:17.019588
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 05:33:28.083668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    import decimal
    import time

    class FakeVault:
        def __init__(self):
            self.decrypted_file = None
            self.encrypted_file = None
            pass

        def decrypt(self, value):
            fd = open(self.decrypted_file, 'r')
            return fd.read()

        def encrypt(self, value):
            fd = open(self.encrypted_file, 'r')
            return fd.read()

    class FakeLoader(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name, vault_secrets)


# Generated at 2022-06-23 05:33:28.950343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert True

# Generated at 2022-06-23 05:33:30.172612
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: should test AnsibleLoader
    pass

# Generated at 2022-06-23 05:33:32.032487
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: why is there no test_AnsibleLoader?
    loader = AnsibleLoader(None)

# Generated at 2022-06-23 05:33:41.472248
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode

    # Test class AnsibleConstructor.
    data = dict(
        ansible_variable=1,
        ansible_loop=2,
        ansible_host=3,
        _ansible_var=4,
        _ansible_loop_var=5,
        _ansible_host_var=6,
        ansible_no_log=7,
    )
    stream = ''.join(AnsibleLoader.org_represent_sequence(None, data.items()))
    stream = '---\n' + stream

    constructor = AnsibleLoader(stream, file_name='<string>', vault_secrets=[])
    node = constructor.get_single_data()
    assert isinstance(node, MappingNode)

# Generated at 2022-06-23 05:33:52.436209
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_secrets = [VaultLib(password='ansible').encrypt("a_secret")]

# Generated at 2022-06-23 05:33:58.113246
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    ---
    # Make sure to test empty and single value lists.
    foo: []

    # Make sure to test single and double valued dicts
    bar: {}
    baz:
      - {a:1}
    """

    loader = AnsibleLoader(data)
    data = loader.get_single_data()
    assert data['baz'][0]['a'] == 1

# Generated at 2022-06-23 05:34:11.633947
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=too-many-locals
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.utils.yaml import from_yaml, to_yaml

    secret_text = "this is a secret"


# Generated at 2022-06-23 05:34:20.610541
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # pylint: disable=bad-whitespace,too-many-branches,too-many-statements,no-self-use
    import datetime
    from ansible.parsing.yaml.objects import AnsibleUnicode


# Generated at 2022-06-23 05:34:25.689056
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_str = '''
# Test file with just comments
# and one variable

foo: bar
    '''
    data = AnsibleLoader(test_str).get_single_data()
    assert data == {'foo': 'bar'}


if __name__ == "__main__":
    import sys
    sys.exit(0)

# Generated at 2022-06-23 05:34:27.639770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-23 05:34:37.165907
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():   # pylint: disable=invalid-name

    class TestLoader(AnsibleLoader):
        def __init__(self, test_string):
            self.test_string = test_string

        def read_yaml_string(self, data):
            return self.test_string

    def _test(test_string, expected):
        loader = TestLoader(test_string)
        assert loader.get_single_data() == expected

    # Constructor test
    _test("# comment\n- test\n", ["test"])
    _test("- test: test_string\n", [{"test": "test_string"}])
    _test("- test: test_string\n  ansible: 1\n", [{"test": "test_string", "ansible": 1}])

# Generated at 2022-06-23 05:34:47.476637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yaml = '''
    ---
    - hosts: all
      tasks:
      - name: who am i
        raw: echo $HOME
        changed_when: False
    '''

    loader = AnsibleLoader(yaml)
    tasks = loader.get_single_data()[0]['tasks']
    assert tasks[0]['name'] == 'who am i'
    assert tasks[0]['raw'] == 'echo $HOME'
    assert tasks[0]['changed_when'] == 'False'

    # Verify the value of current_line_number in get_single_data method
    loader = AnsibleLoader(yaml)
    data = loader.get_single_data()
    assert loader.current_line_number == 9

# Generated at 2022-06-23 05:34:57.733322
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    if sys.version_info.major >= 3:
        unicode = str
    # For testing purposes, we replace the self.file_name attr with a fake value
    file_name = u'foobar'
    # Create a 'stream' to read our test data

# Generated at 2022-06-23 05:35:06.264981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_string = '''
        ---
        - { role: common, when: ansible_os_family == "RedHat" }
        - { role: common, when: ansible_os_family == "Debian" }
    '''

    yaml_result = AnsibleLoader(yaml_string).get_single_data()

    assert isinstance(yaml_result, list)
    assert yaml_result[0] == {'role': 'common', 'when': 'ansible_os_family == "RedHat"'}
    assert yaml_result[1] == {'role': 'common', 'when': 'ansible_os_family == "Debian"'}

# Generated at 2022-06-23 05:35:17.182485
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os.path

    base_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    test_file_path = os.path.join(base_path, 'test/yaml/complex_vars.yaml')
    test_file_stream = open(test_file_path, 'r')
    test_file_data = test_file_stream.read()

    loader = AnsibleLoader(test_file_stream, vault_secrets=['vault_password'])
    loader = loader.get_single_data()

    assert loader['i18n']['languages']['en']['hello'] == 'world'
    assert loader['i18n']['languages']['es']['hello'] == 'mundo'
    assert loader

# Generated at 2022-06-23 05:35:18.354308
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# Generated at 2022-06-23 05:35:30.897104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import ansible.parsing.yaml.objects
    data = '''
        foo:
          - hosts: all
            gather_facts: no
            tasks:
              - debug:
                  msg: "Hello World"
    '''
    # Constructor of class AnsibleLoader
    # that is imported from ansible.parsing.utils.load_list
    loader = AnsibleLoader(data)
    # Print class name and unit test status:
    # if class instantiation is successful
    # the unit test passes, otherwise it fails.
    print('Testing class:', type(loader).__name__)
    if loader != None:
        print('Unit test pass')
    else:
        print('Unit test fail')
    # Instantiate object
    loader.get_single_data()


# Generated at 2022-06-23 05:35:41.420606
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-locals, too-many-branches, too-many-statements
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.plugins.loader import vault_load

    import os
    from io import StringIO
    from yaml.compat import PY3

    if PY3:
        from io import BytesIO as BytesStringIO  # pylint: disable=ungrouped-imports
        from builtins import bytes
        from itertools import chain
    else:
        from cStringIO import StringIO as BytesStringIO  # pylint: disable=ungrouped-imports

    # create some test data

# Generated at 2022-06-23 05:35:52.002550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Unit test for class AnsibleLoader
    '''
    import argparse
    import os

    # This parser object is used to get cli arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--file', type=str, default="", help='Input YAML file name')
    args = parser.parse_args()
    input_file = args.file

    # Create the AnsibleLoader object
    input_stream = file(input_file)
    ansible_loader = AnsibleLoader(input_stream)

    print(ansible_loader.get_single_data())

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:35:55.471151
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    loader = AnsibleLoader(None, '/path/to/file')
    assert isinstance(loader, AnsibleConstructor)

# Generated at 2022-06-23 05:36:05.189106
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import loaders
    from ansible.module_utils.common.yaml import to_yaml
    from ansible import constants as C

    assert AnsibleLoader is loaders.AnsibleLoader
    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, 'construct_yaml_map')
    assert hasattr(AnsibleLoader, 'construct_yaml_str')
    assert hasattr(AnsibleLoader, 'construct_yaml_seq')
    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')
    assert hasattr(AnsibleLoader, 'add_implicit_resolver')

    # first test the class used when we have libyaml

# Generated at 2022-06-23 05:36:13.878262
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Test AnsibleLoader when using libyaml
    if HAS_LIBYAML:
        loader = AnsibleLoader('test', '/dev/null')

        assert(isinstance(loader, Parser))
        assert(isinstance(loader, AnsibleConstructor))
        assert(isinstance(loader, Resolver))

    # Test AnsibleLoader when not using libyaml
    else:
        loader = AnsibleLoader('test', '/dev/null')

        assert(isinstance(loader, Reader))
        assert(isinstance(loader, Scanner))
        assert(isinstance(loader, Parser))
        assert(isinstance(loader, Composer))
        assert(isinstance(loader, AnsibleConstructor))
        assert(isinstance(loader, Resolver))

# Generated at 2022-06-23 05:36:18.014283
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert issubclass(AnsibleLoader, AnsibleBaseYAMLObject)

# Generated at 2022-06-23 05:36:29.098299
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    text = '''
        ---
        foo: bar
        baz:
            - qux
        quux:
        - quuz
        - corge
        grault:
          garply: waldo
          fred: plugh
          xyzzy:
            thud:
              - wibble
              - wubble
          '''

    loader = AnsibleLoader(text)
    foo = loader.get_single_data()
    assert foo == dict(foo='bar', baz=['qux'], quux=['quuz', 'corge'], grault=dict(garply='waldo', fred='plugh', xyzzy=dict(thud=['wibble', 'wubble'])))


# Generated at 2022-06-23 05:36:30.442666
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    al = AnsibleLoader('')
    assert al

# Generated at 2022-06-23 05:36:37.608570
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:36:39.002880
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader, AnsibleLoader)

# Generated at 2022-06-23 05:36:48.234570
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    class TestAnsibleLoader(AnsibleLoader):
        ''' Override AnsibleLoader to test vault secret class'''
        def __init__(self, stream):
            super(TestAnsibleLoader, self).__init__(stream)


# Generated at 2022-06-23 05:36:53.093038
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=unused-variable,unused-argument
    def test_construct_yaml_int(self, node):
        return int(self.construct_scalar(node))

    AnsibleLoader.add_constructor(u'tag:yaml.org,2002:int', test_construct_yaml_int)

# Generated at 2022-06-23 05:37:00.970104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=missing-docstring
    import datetime
    import re
    import sys
    import unittest
    try:
        from unittest import mock
    except ImportError:
        import mock


    class TestAnsibleLoader(unittest.TestCase):  # pylint: disable=missing-docstring
        def test_undefined(self):
            obj = AnsibleLoader('').construct_undefined(None)
            self.assertIsNone(obj)

        def test_binary(self):
            obj = AnsibleLoader('', vault_secrets=['test']).construct_yaml_binary(None)

            if sys.version_info[0] < 3:
                self.assertIsInstance(obj, str)
            else:
                self.assertIsInstance(obj, bytes)
            self

# Generated at 2022-06-23 05:37:10.784609
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    # AnsibleLoader extends yaml.cloader.Loader (which is already tested in python2.7/lib/test/test_yaml.py test_cloader)

    # AnsibleLoader extends AnsibleConstructor
    al = AnsibleLoader(sys.stdin, file_name='test')
    from ansible.plugins.loader.test import TestModule
    from ansible.plugins.loader.test import TestModule_empty
    for cls in al.__class__.__bases__:
        if cls.__name__ == 'AnsibleConstructor':
            assert isinstance(cls, AnsibleConstructor)
            assert hasattr(cls, '_construct_python_name')
            assert isinstance(cls._construct_python_name, TestModule)

# Generated at 2022-06-23 05:37:12.225912
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Test for function load_from_file

# Generated at 2022-06-23 05:37:15.902938
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    assert isinstance(loader._flatten(1), AnsibleUnicode)

# Generated at 2022-06-23 05:37:24.830231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.text.converters import to_unicode

    loader = AnsibleLoader(None)

    assert loader.get_single_data() == None
    assert loader.get_single_data() == None

    assert loader.construct_mapping(None) == {}
    assert loader.construct_sequence(None) == []

    assert loader.construct_yaml_map() == {}
    assert loader.construct_yaml_seq() == []

    assert loader.construct_yaml_str(None) == ''
    assert loader.construct_yaml_str(None) == ''

    assert loader.construct_yaml_int(None) == 0

    assert loader.construct_yaml_bool(None) == False
    assert loader.construct_yaml_bool(None) == True


# Generated at 2022-06-23 05:37:31.280050
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import load
    from ansible.parsing.yaml.objects import AnsibleUnicode
    input_data = u"\n\n- foo: !unsafe |\n\n   TEST DATA\n\n"
    assert isinstance(load(input_data), list)
    assert isinstance(load(input_data)[0]['foo'], AnsibleUnicode)
    assert load(input_data)[0]['foo'] == "TEST DATA"

# Generated at 2022-06-23 05:37:43.455981
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_data = '''
[True]
    {
    "name": "test",
    "answer": 42,
    "list": [1, 2, 3],
    "list_of_dicts": [
        { "foo": "bar", "baz": "qux" },
        { "foo": "xx", "baz": "yy" }
    ],
    "dict_with_unicode_values": {
        "foo": "bar",
        "baz": "qux",
        "Ω": "with unicode"
    }
}
    '''

    test_object = AnsibleLoader(test_data).get_single_data()
    assert test_object["name"] == "test"
    assert test_object["answer"] == 42

# Generated at 2022-06-23 05:37:53.622775
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import textwrap
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-23 05:38:04.048966
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader({}, "test_file_name", {'test_secret': None, 'test_secret_utf8': '☃'})
    loader.ansible_vault_password = 'test_password'
    loader.ansible_vault_secret_id = 'test_secret'

    # test vault decryption with non-ascii password as well as secret_id

# Generated at 2022-06-23 05:38:07.788231
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #pylint:disable=protected-access
    loader = AnsibleLoader(None)

    assert loader.reader == Reader
    assert loader.scanner == Scanner
    assert loader.parser == Parser
    assert loader.composer == Composer
    assert loader.constructor == AnsibleConstructor
    assert loader.resolver == Resolver

# Generated at 2022-06-23 05:38:18.375920
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-23 05:38:19.160708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:38:30.684558
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ This is a more basic test as AnsibleConstructor testing is handled in test_constructor.py
    """

    # pylint: disable=too-many-locals,too-many-branches,too-many-statements

# Generated at 2022-06-23 05:38:42.224864
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.vault import VaultLib
    from io import StringIO
    import yaml
    data = {'a': 1, 'b': 2}
    stream = StringIO()
    VaultLib().dump(data, stream)
    stream.seek(0)
    vault_secrets = yaml.safe_load(stream.read())
    assert vault_secrets == data

    stream = StringIO()
    yaml.dump(vault_secrets, stream, Dumper=AnsibleDumper, default_flow_style=False, allow_unicode=True)
    stream.seek(0)
    data = yaml.load(stream, Loader=AnsibleLoader, vault_secrets=vault_secrets)


# Generated at 2022-06-23 05:38:54.224080
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '_add_implicit_resolvers')
    assert hasattr(AnsibleLoader, 'convert_to_tags')
    assert hasattr(AnsibleLoader, 'construct_yaml_map')
    assert hasattr(AnsibleLoader, 'construct_mapping')
    assert hasattr(AnsibleLoader, 'decrypt_text')
    assert hasattr(AnsibleLoader, 'get_data')
    assert hasattr(AnsibleLoader, 'get_single_data')
    assert hasattr(AnsibleLoader, 'has_yaml_tag')
    assert hasattr(AnsibleLoader, 'process_decrypt')
    assert hasattr(AnsibleLoader, 'process_vault_yaml')
    assert hasattr(AnsibleLoader, 'safe_load')

# Generated at 2022-06-23 05:39:04.729844
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader
    from io import BytesIO
    from ansible.vars import VariableManager

    variable_manager = VariableManager()
    loader = DataLoader()

    # test string loading
    data = b"foo: bar\n"
    obj = loader.load(BytesIO(data))
    assert isinstance(obj, dict)
    assert isinstance(obj, AnsibleBaseYAMLObject)
    assert obj['foo'] == 'bar'

    # try the same thing with a different file name
    obj = loader.load(BytesIO(data), file_name='/path/to/data.yml')
    assert isinstance(obj, dict)

# Generated at 2022-06-23 05:39:17.313845
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import io
    import textwrap

    test_cases = [
        (u"{a: '{{  b }}'}", {u"a": u"{{ b }}"}),
        (u"a: '{{ b }}'", {u"a": u"{{ b }}"}),
        (textwrap.dedent(u'''
            a:
              - '{{ b }}'
              - ''
              - '{{ c }}'
            '''), {u"a": [u"{{ b }}", u"", u"{{ c }}"]}),
    ]

    for yaml_str, expected in test_cases:

        stream = io.BytesIO(yaml_str.encode('utf-8'))
        ansible_loader = AnsibleLoader(stream)
        result = ansible_loader.get_single_data()

# Generated at 2022-06-23 05:39:25.091142
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from io import StringIO

    string_io = StringIO('---\n- foo: "{{ test_var }}"')
    try:
        loader = AnsibleLoader(string_io)
    except TypeError as e:
        AnsibleLoader(string_io, 'test_file_name')

    loader.get_single_data()
    loader.dispose()

    stream = StringIO()
    dumper = AnsibleDumper(stream)
    dumper.open()
    dumper.descend(loader.get_single_data())
    dumper.ascend()
    dumper.close()

# Generated at 2022-06-23 05:39:35.835218
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.vault import VaultLib
    vault = VaultLib('test')


# Generated at 2022-06-23 05:39:46.441660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # We will use the md5.yml file to test the constructor
    # file_name = 'tests/sanity/code-smell/md5.yml'
    file_name = '/home/kp/Documents/ansible/ansible/tests/sanity/code-smell/md5.yml'
    file_stream = open(file_name, 'r')
    # The file_names is set to file_name in the constructor
    loader = AnsibleLoader(file_stream, file_name=file_name)
    print(loader.get_file_name())
    # This will print all the information about the AnsibleLoader, at the end of all this information
    # it will return back 'data' as shown in the md5.py file
    print(loader.get_single_data())


# Generated at 2022-06-23 05:39:47.174830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-23 05:39:58.441607
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.compat.tests import unittest

    class TestAnsibleLoader(unittest.TestCase):

        def setUp(self):
            self.stream = ''
            self.file_name = None
            self.vault_secrets = None
            self.ansible_loader = AnsibleLoader(self.stream, self.file_name, self.vault_secrets)

        def test_an_instance(self):
            self.assertIsInstance(self.ansible_loader, AnsibleLoader)


# Generated at 2022-06-23 05:40:08.897140
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # If you need to test this, run
    # nosetests -s -v ansible.parsing.yaml.loader:test_AnsibleLoader
    from io import StringIO
    import sys

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO


# Generated at 2022-06-23 05:40:13.171446
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    data_loader = DataLoader()
    AnsibleLoader(data='')

# Generated at 2022-06-23 05:40:14.620986
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-23 05:40:15.932753
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """empty test function for test-modules to allow import of module"""
    pass

# Generated at 2022-06-23 05:40:21.934436
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("""
        # from: http://yaml.org/
        - Mark McGwire
        - Sammy Sosa
        - Ken Griffey
        """, vault_secrets={})

    assert loader.get_data() == [
        "Mark McGwire",
        "Sammy Sosa",
        "Ken Griffey"
    ]

# Generated at 2022-06-23 05:40:32.466076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Load string
    loader = AnsibleLoader('test_string')
    assert loader is not None
    assert loader.get_single_data() == 'test_string'

    # Load list
    loader = AnsibleLoader('[test_string_1, test_string_2]')
    assert loader is not None
    assert loader.get_single_data() == ['test_string_1', 'test_string_2']

    # Load dictionary
    loader = AnsibleLoader('{test_key1: test_value1, test_key2: test_value2}')
    assert loader is not None
    assert loader.get_single_data() == {'test_key1': 'test_value1', 'test_key2': 'test_value2'}

# Generated at 2022-06-23 05:40:36.514820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO

    s = StringIO.StringIO("hello: world")
    l = AnsibleLoader(s)
    assert l.get_single_data() == {'hello': 'world'}

# Generated at 2022-06-23 05:40:38.750279
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = 'test.yml'
    stream = open(file_name)
    AnsibleLoader(stream, file_name, None)
    stream.close()

# Generated at 2022-06-23 05:40:42.551591
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\nstring: hi'
    
    # Constructor
    AnsibleLoader(stream)

# Generated at 2022-06-23 05:40:56.276017
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import unittest
    import re
    import ansible.parsing.yaml.objects
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    class AliasYamlObject (AnsibleBaseYAMLObject):

        yaml_loader = AnsibleLoader
        yaml_tag = u'!Alias'

        def __init__(self, key):
            self.key = key

        @classmethod
        def from_yaml(cls, loader, node):
            return AliasYamlObject(node.value)

        def to_yaml(self, dumper=None, data=None):
            return "%s" % self.key


# Generated at 2022-06-23 05:41:00.855459
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()

    d = dataloader.load("---\n# test comment\nfoo: 1")
    assert d == {'foo': 1}

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-23 05:41:02.415764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO (Ansible 2.6 only)
    pass

# Generated at 2022-06-23 05:41:05.049930
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert isinstance(loader.constructor, AnsibleConstructor), "constructor should be AnsibleConstructor"

# Generated at 2022-06-23 05:41:06.564342
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None)
    assert(x)

# Generated at 2022-06-23 05:41:07.980066
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    _test_AnsibleLoader(AnsibleLoader)

#

# Generated at 2022-06-23 05:41:12.759820
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import yaml

    stringInput = "test_string: Hello World"
    objectInput = yaml.load(stringInput, Loader=AnsibleLoader)
    print (objectInput['test_string'])

    assert objectInput['test_string'] == 'Hello World'

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-23 05:41:22.902260
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.six import text_type
    from ansible.parsing.yaml.objects import AnsibleSequence

    source = '''
a: "foo"
b:
 - "bar1"
 - "bar2"
c:
 - foo: "bar1"
   baz: "qux1"
 - foo: "bar2"
   baz: "qux2"
'''

    # need to construct a fake stream object for this to work
    import io
    stream = io.BytesIO(source.encode('utf-8'))
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping)

# Generated at 2022-06-23 05:41:34.471278
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Creating a mock variable manager
    variable_manager = VariableManager()
    # Creating a mock data loader
    data = DataLoader()

    # Mock string that is configurable
    test_string = '{"foo": "bar"}'
    # Creating a mock variable name
    variable_name = "test_var"
    # Creating the variable within the variable manager
    variable_manager.set_variable(variable_name, test_string)

    # Creating a new ansible loader and specifying the variable manager
    ansible_loader = AnsibleLoader(data, variable_manager)
    # Retrieving the variable from the variable manager
    variable = ansible_loader.get_variable(variable_name)

    # Variable should be equal to test

# Generated at 2022-06-23 05:41:36.823579
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.file_name == None
    assert loader.vault_secrets == None

# Generated at 2022-06-23 05:41:38.475544
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')

# Generated at 2022-06-23 05:41:45.155745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.dataloader
    dl = ansible.parsing.dataloader.DataLoader()
    data = """
---
- hosts:
    - localhost
  tasks:
    - name: test
      ping:
...
"""
    stream = dl.load(data, "<string>", 'yaml', vault_secrets=[], allow_insecure=False)
    assert stream[0]['tasks'][0]['ping'] == {}

# Generated at 2022-06-23 05:41:53.644097
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from yaml import load
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.compat.six import PY3
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 05:41:58.440181
# Unit test for constructor of class AnsibleLoader