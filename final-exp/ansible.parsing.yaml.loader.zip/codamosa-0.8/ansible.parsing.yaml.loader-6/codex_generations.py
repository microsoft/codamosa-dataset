

# Generated at 2022-06-11 09:25:30.979608
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader(None)
    assert x is not None

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:25:33.067251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    contents = """
- name: test host chain
  hosts:
    - host1
  tasks:
  - name: task 1
    debug:
      msg: 'hello world'
  """
    try:
        results = list(AnsibleLoader(None, contents, None).get_single_data())
    except:
        results = None
    assert results is not None

# Generated at 2022-06-11 09:25:35.902716
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_constructor = AnsibleLoader(None)
    assert test_constructor.construct_mapping == AnsibleConstructor.construct_mapping

# Generated at 2022-06-11 09:25:36.876678
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(None)

# Generated at 2022-06-11 09:25:43.155703
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Create an input stream
    stream = u"---\nname: \"{{ inventory_hostname }}\""

    # Create the loader object and load YAML data
    loader = AnsibleLoader(stream)
    # Obtain a Python object representing the YAML stream
    obj = loader.get_single_data()

    # Compare the result
    assert obj == {'name': '{{ inventory_hostname }}'}


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:25:51.936135
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader('')
    assert isinstance(loader.construct_yaml_str(None), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str(''), AnsibleUnicode)
    assert isinstance(loader.construct_yaml_str('foo'), AnsibleUnicode)

    # create a new dummy class to test the add_constructor method
    class Dummy:
        pass
    dummy = Dummy()
    dummy.name = 'foo'
    loader.add_constructor(u'tag:yaml.org,2002:foo', lambda loader, node: dummy)
    assert loader.construct_yaml_map(None) is dummy

# Generated at 2022-06-11 09:25:55.919494
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO
    test_string = StringIO.StringIO("- hosts: all\n  sudo: yes\n  tasks:\n  - name: test1\n    command: /bin/true")
    AnsibleLoader(test_string)
    test_string.close()

# Generated at 2022-06-11 09:25:59.236909
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    data = AnsibleLoader('{a: 1}').get_single_data()
    assert data == {'a': 1}

# Generated at 2022-06-11 09:26:05.124667
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # import yaml
    loader = AnsibleLoader('')
    if HAS_LIBYAML:
        from yaml.constructor import ConstructorError
        loader.__init__('')
        try:
            loader.get_single_data()
        except ConstructorError:
            pass

# Generated at 2022-06-11 09:26:09.670689
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(None, file_name='test.yaml')
    assert ansible_loader.construct_yaml_str.__self__ is ansible_loader
    assert ansible_loader.construct_yaml_seq.__self__ is ansible_loader

# Generated at 2022-06-11 09:26:14.880765
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleConstructor(None)
    assert isinstance(loader, AnsibleConstructor)
    #assert isinstance(loader, yaml.BaseConstructor)
    assert isinstance(loader, Resolver)

# Generated at 2022-06-11 09:26:19.760835
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    vault_secrets = VaultLib('badpassword')
    data = AnsibleLoader("""
        ---
        foo: [bar]
        """, vault_secrets=vault_secrets)
    assert 'foo' in data
    assert data['foo'] == ['bar']

# Generated at 2022-06-11 09:26:27.632407
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys
    import ansible.parsing.yaml.constructor

    test_stream = io.StringIO('---\n- hosts: localhost\n')
    loader = AnsibleLoader(test_stream, file_name='test_file', vault_secrets='vault_password')
    module = loader.get_single_data()

    assert module[0]['hosts'] == 'localhost'

# Generated at 2022-06-11 09:26:40.417799
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
foo:
- a: 1
  b: two
  c: [3, 4]
- d: [1, 2]
- e: {x: 1, y: 2}
    '''
    for stream, file_name in (StringIO(data), None), (None, 'test_file'):
        loader = AnsibleLoader(stream, file_name)
        d = loader.get_single_data()
        assert isinstance(d, dict)
        assert d == {'foo': [{'a': 1, 'b': 'two', 'c': [3, 4]},
                             {'d': [1, 2]},
                             {'e': {'x': 1, 'y': 2}}]}

# pylint: disable=protected-access

# Generated at 2022-06-11 09:26:41.912863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # This function is just to unit test __init__ of class AnsibleLoader
    pass

# Generated at 2022-06-11 09:26:48.747965
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.dumper import AnsibleDumper
    yaml_str = '''---
name:
- foo
'''
    y = AnsibleLoader(StringIO(yaml_str))
    assert y.get_single_data() == {"name": ["foo"]}

    # round-trip
    yaml_obj = y.get_single_data()
    yaml_rt = AnsibleDumper(yaml_obj)
    assert yaml_rt.get_data() == yaml_obj

# Generated at 2022-06-11 09:26:59.049814
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open('/tmp/hello.yml','w') as f:
        f.write('hello: world')
    with open('/tmp/hello.yml','r') as f:
        loader = AnsibleLoader(f)
        assert loader.get_data() == dict(hello="world")
    with open('/tmp/hello.yml','w') as f:
        f.write('hello: world\n')
    with open('/tmp/hello.yml','r') as f:
        loader = AnsibleLoader(f)
        assert loader.get_data() == dict(hello="world")

# Generated at 2022-06-11 09:27:00.195264
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Test
    al = AnsibleLoader(None)
    assert al is not None

# Generated at 2022-06-11 09:27:01.963433
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = AnsibleLoader(None, vault_secrets="secret").get_single_data()
    assert data is not None

# Generated at 2022-06-11 09:27:15.066550
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test construcror with no args
    ansible_loader = AnsibleLoader(None)
    assert ansible_loader is not None
    assert not hasattr(ansible_loader, 'file_name')
    assert not hasattr(ansible_loader, 'vault_secrets')

    # test with file_name and vault_secrets
    ansible_loader = AnsibleLoader(None, 'foo', 'bar')
    assert ansible_loader is not None
    assert hasattr(ansible_loader, 'file_name')
    assert hasattr(ansible_loader, 'vault_secrets')
    assert ansible_loader.file_name == 'foo'
    assert ansible_loader.vault_secrets == 'bar'

    # test with only file_name

# Generated at 2022-06-11 09:27:29.322993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    variable_manager = VariableManager()
    d = DataLoader(variable_manager=variable_manager)
    a = AnsibleLoader(stream=None, file_name='file.yml', vault_secrets=None)
    assert a
    assert isinstance(a, Reader)
    assert isinstance(a, Scanner)
    assert isinstance(a, Parser)
    assert isinstance(a, Composer)
    assert isinstance(a, AnsibleConstructor)
    assert isinstance(a, Resolver)
    assert isinstance(d, DataLoader)
    assert isinstance(variable_manager, VariableManager)
    # generate/read a yaml file from yaml.load()

# Generated at 2022-06-11 09:27:35.568089
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    variable_manager = VariableManager()
    loader = DataLoader()

    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='/etc/ansible/hosts')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 09:27:39.218972
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("---\n"
                           "test: foo\n")
    assert loader.get_single_data() == {'test': 'foo'}

# Generated at 2022-06-11 09:27:50.630038
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    import tempfile
    stream = tempfile.NamedTemporaryFile(mode='wt')
    import sys
    try:
        with stream:
            stream.write('---\n{1: foo, 2: bar}\n')
            stream.flush()
            stream.seek(0)
            loader = AnsibleLoader(stream)
            builtins.__dict__['_'] = lambda x: x
            data = loader.get_single_data()
            builtins.__dict__.pop('_')
    finally:
        del builtins.__dict__['__file__']
        stream.close()
        stream = None
        sys.modules.pop('__main__', None)

# Generated at 2022-06-11 09:27:51.964178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("string is not important at this moment")
    assert loader is not None

# Generated at 2022-06-11 09:28:05.632784
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    import io
    import sys

    stream = io.BytesIO(b'{foo: bar, bam: [1,2,3]}')
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 2
    assert 'foo' in data
    assert 'bam' in data
    assert data['foo'] == 'bar'
    assert isinstance(data['bam'], AnsibleSequence)

    if sys.version_info < (3,):
        stream = io.BytesIO('{foo: bar, bam: [1,2,3]}')

# Generated at 2022-06-11 09:28:16.432602
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.vars import VariableManager


# Generated at 2022-06-11 09:28:29.023594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    
    # First test: no content in the stream
    stream = ""  # pylint: disable=invalid-name
    with pytest.raises(Exception) as excinfo:
        AnsibleLoader(stream)
    assert "expected a single document in the stream" in str(excinfo.value)
    
    # Second test: stream does not start with '---'
    stream = "test"
    with pytest.raises(Exception) as excinfo:
        AnsibleLoader(stream)
    assert "found character 't' that cannot start any token" in str(excinfo.value)
    
    # Third test: stream starts with '---' but no content
    stream = "---"
    with pytest.raises(Exception) as excinfo:
        AnsibleLoader(stream)
    assert "expected the document end" in str

# Generated at 2022-06-11 09:28:35.106854
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    vault_passwords = {}
    vault_password = "hunter2"
    vault_passwords['default'] = VaultLib([vault_password])

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-11 09:28:38.684732
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    constructor = AnsibleLoader(stream='Hello World!', vault_secrets=['my secret'])
    assert constructor.stream == 'Hello World!'
    assert constructor.vault_secrets == ['my secret']

# Generated at 2022-06-11 09:28:53.510397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing import vault
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess

    from ansible.plugins.loader import vault_loader
    from ansible.utils.vars import load_extra_vars

    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

# Generated at 2022-06-11 09:28:58.707931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader(): # pylint: disable=no-self-use
    from ansible.parsing.yaml.objects import AnsibleMapping
    stream = '''---
- hosts: all
  gather_facts: True
'''
    loader = AnsibleLoader(stream)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.get_single_data(), AnsibleMapping)

# Generated at 2022-06-11 09:29:09.412035
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml import objects
    from ansible.utils.unicode import to_bies
    s = """
- hosts: all
  gather_facts: false
  tasks:
    - name: test
      debug:
         var: {{ ansible_date_time.year }}
      when: %s > 2014
      tags:
        - debug
""" % (objects.AnsibleVaultEncryptedUnicode.ANSIBLE_VAULT)

    yaml_src = to_bies(s)
    data = AnsibleLoader(yaml_src).get_single_data()
    assert data[0].get('tasks')[0]['when'] == s.split('\n')[4][-28:]
    assert data[0].get('tasks')[0]['tags'] == ['debug']
   

# Generated at 2022-06-11 09:29:12.322484
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansibleLoader = AnsibleLoader(None, None, None)
    assert hasattr(ansibleLoader, 'vault_secrets') == True

# Generated at 2022-06-11 09:29:25.878408
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import string
    import random
    import itertools

    def test_ansible_loader(source):
        if source:
            source = source.encode('utf-8')
        else:
            source = b''

        # We must use BytesIO as a stream because that is what the AnsibleLoader
        # expects when reading from stdin
        stream = io.BytesIO(source)
        loader = AnsibleLoader(stream)
        return loader.get_single_data()

    # Test some simple cases

# Generated at 2022-06-11 09:29:32.224023
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ansible/parsing/yaml/constructor uses the string value of yaml classes to reference them
    # we want to make sure this doesn't change between PyYAML versions
    assert str(AnsibleLoader) == '<class \'ansible.parsing.yaml.loader.AnsibleLoader\'>'

# Generated at 2022-06-11 09:29:42.377192
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(sys.stdin)
    assert isinstance(loader, AnsibleLoader)
    assert isinstance(loader.construct_object(u'test'), AnsibleUnicode)
    assert len(loader.construct_yaml_map(u'')) == 0
    assert len(loader.construct_yaml_seq(u'[1,2,3]')) == 3
    assert loader.construct_yaml_str(b'abc', b'tag:yaml.org,2002:str') == 'abc'

if __name__ == '__main__':
    import sys
    test_AnsibleLoader()
    sys.exit(0)

# Generated at 2022-06-11 09:29:43.915803
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(None)

# unit test for class AnsibleLoader

# Generated at 2022-06-11 09:29:46.498817
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-few-public-methods

    class TestAnsibleLoader(AnsibleLoader):
        pass

    assert TestAnsibleLoader is not None

# Generated at 2022-06-11 09:29:59.081790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader

# Run tests if this file is called as script
if __name__ == '__main__':
    from ansible.module_utils._text import to_bytes
    import sys
    import unittest

    # Test class AnsibleLoader
    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            # Test data
            self.data = '''
a: 1
b:
  - 2
  - 3
c:
  aaa: 4
  bbb: 5
  ccc: 6
    '''
            self.data = to_bytes(self.data, errors='surrogate_or_strict')


# Generated at 2022-06-11 09:30:12.306497
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 09:30:17.254410
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader

if HAS_LIBYAML:
    yaml = AnsibleLoader
else:
    import yaml
    yaml.AnsibleLoader = AnsibleLoader


# Compatibility code for unsupported Python versions
# Backported from Python 2.7/3.4 for compatibility with Python 2.6/3.3
try:
    # Python 2.6
    from ordereddict import OrderedDict
except ImportError:
    try:
        # Python 2.7
        from collections import OrderedDict
    except ImportError:
        # Python 3.3 and onwards
        from collections.abc import MutableMapping as OrderedDict

# Generated at 2022-06-11 09:30:27.716123
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Unit test to check if AnsibleLoader can load all necessary yaml modules from yaml when LibYAML is not installed
    if not HAS_LIBYAML:
        for module in ['Reader', 'Scanner', 'Parser', 'Composer', 'AnsibleConstructor', 'Resolver']:
            assert hasattr(AnsibleLoader, module)

    # Unit test to check if AnsibleLoader can load all necessary yaml modules from ansible.module_utils.common.yaml when LibYAML is installed
    if HAS_LIBYAML:
        for module in ['Parser', 'AnsibleConstructor', 'Resolver']:
            assert hasattr(AnsibleLoader, module)

# Generated at 2022-06-11 09:30:29.715359
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(None)
    assert isinstance(obj, AnsibleLoader)

# Generated at 2022-06-11 09:30:33.290413
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import StringIO
    sys.stderr = StringIO.StringIO()
    l = AnsibleLoader('')
    assert(l is not None)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-11 09:30:35.216887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert issubclass(AnsibleLoader, Resolver), 'AnsibleLoader is not a subclass of Resolver'

# Generated at 2022-06-11 09:30:40.630764
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
        shell: mycommand arg1 arg2
        when: arg1 = "foo" or arg2 != "bar"
        register: mycommand_out
    '''
    loader = AnsibleLoader(data)
    doc = loader.get_single_data()
    assert doc.get('shell') == 'mycommand arg1 arg2'
    assert doc.get('when') == 'arg1 = "foo" or arg2 != "bar"'
    assert doc.get('register') == 'mycommand_out'

# Generated at 2022-06-11 09:30:45.277908
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string1 = ('{"foo": "bar"}')
    string2 = ('{"bar": "foo"}')

    assert isinstance(AnsibleLoader(string1).get_data(), dict)
    assert isinstance(AnsibleLoader(string2).get_data(), dict)

# Generated at 2022-06-11 09:30:55.999658
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    yamlstr = '''
    - include: include_me.yaml
    - name: play
      include:
        file: include_me.yaml
        name: included_play
        vars:
            foo: bar
    - include: include_me.yaml
      when: some_var is defined
    - name: conditional include
      include:
        - include_me.yaml
        - include_me.yaml
    - name: conditional inclusion in a loop
      include:
        - "{{item}}"
      with_items:
        - include_me.yaml
        - include_me.yaml
    '''

    loader = AnsibleLoader(yamlstr)
    data = loader.get_single_data()

    assert len(data) == 5


# Generated at 2022-06-11 09:31:05.798980
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    from io import StringIO

    data = '''
    foo: !vault |
           $ANSIBLE_VAULT;1.2;AES256;pavel.kouznetsov
           32663436663535323664616235343361656430353938393963623166623133613335623232373065
           3530346633386538
    '''
    secret = 'the secret message'

    steam = StringIO(data)
    vault = yaml.AnsibleVaultEncryptedUnicode(secret)
    loader = AnsibleLoader(steam)
    d = loader.get_single_data()
    assert d['foo'] == vault

# Generated at 2022-06-11 09:31:25.053175
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.loader
    loader = ansible.parsing.yaml.loader.AnsibleLoader(None)

# Generated at 2022-06-11 09:31:26.165857
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None


# Generated at 2022-06-11 09:31:27.832447
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # fails if constructor has not this signature
    AnsibleLoader(None)

# Generated at 2022-06-11 09:31:30.016244
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Loader class needs a file name to provide better errors
    AnsibleLoader('/some/random/file.yaml')

# Generated at 2022-06-11 09:31:34.008245
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Make a mock stream object
    stream = "tests/units/parsing/yaml/files/yaml_constructor.yml"
    ansible_loader = AnsibleLoader(stream)
    ansible_loader.get_data()

# Generated at 2022-06-11 09:31:38.642072
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
        ---
        foo: 1
        bar: 2
    '''
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    assert loader
    assert isinstance(data, dict)
    assert data == {'foo': 1, 'bar': 2}

# Generated at 2022-06-11 09:31:48.149169
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader("!var foo")
    node = loader.compose_node(None, None)
    assert isinstance(node, AnsibleUnicode)
    assert node == u"foo"

# Generated at 2022-06-11 09:31:50.089320
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml = """
    a: 1
    b: 2
    """

    loader = AnsibleLoader(yaml)
    assert loader.get_single_data() == {'a': 1, 'b': 2}

# Generated at 2022-06-11 09:31:57.244029
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pytest
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    def test_ansible_constructor_deepcopy(monkeypatch):
        from ansible.parsing.yaml.constructor import AnsibleConstructor
        import copy

        an = AnsibleConstructor()
        an1 = copy.deepcopy(an)
        assert isinstance(an1, AnsibleConstructor)

    def test_ansible_constructor_getattr(monkeypatch):
        from ansible.parsing.yaml.constructor import AnsibleConstructor
        from ansible.parsing.yaml.objects import AnsibleUnicode

        an = AnsibleConstructor()


# Generated at 2022-06-11 09:32:03.730402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib

    # create a secret string and write the vault to a file
    vault_password_file = '~/.vault_pass.txt'
    vault_secret = 'mysecret'
    with open(vault_password_file, 'w') as f:
        f.write(vault_secret)

    # create a vault section in an inventory file
    inventory_file = '~/ansible_test_inventory'

# Generated at 2022-06-11 09:32:48.120472
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-11 09:32:54.698042
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def setUp(self):
            self.loader = AnsibleLoader(sys.stdin)

        def tearDown(self):
            self.loader = None

        def test_init_Exceptions(self):
            # Test for various Exceptions
            with self.assertRaisesRegexp(TypeError, "expected string or buffer"):
                self.loader_param_none = AnsibleLoader(None)
            with self.assertRaisesRegexp(TypeError, "expected string or buffer"):
                self.loader_param_list = AnsibleLoader([1, 2, 4, 5])
            with self.assertRaisesRegexp(TypeError, "expected string or buffer"):
                self.loader_param_dict = Ansible

# Generated at 2022-06-11 09:33:04.670993
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Function to check if an AnsibleLoader object can be instantiated.
    '''

    test_file_txt = """
    - name: test1
      ignore_errors: True
    - name: test2
      ignore_errors: True
    """
    with open('test_file.yml', 'w') as test_file:
        test_file.write(test_file_txt)

    test_AnsibleLoader = AnsibleLoader(file_name='test_file.yml')
    assert type(test_AnsibleLoader) == AnsibleLoader

# Generated at 2022-06-11 09:33:07.057650
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Validate we can construct an AnsibleLoader object'''
    AnsibleLoader(None)

# Generated at 2022-06-11 09:33:16.510636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    input_buffer = """---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
---
"""

    # Test with no libyaml
    AnsibleLoader(input_buffer.splitlines())

    # Test with libyaml
    try:
        import yaml # pylint: disable=unused-variable
        AnsibleLoader(input_buffer.splitlines())
    except ImportError:
        pass

# Generated at 2022-06-11 09:33:29.121171
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader(b'[1, 2, 3]')
    data = l.get_single_data()
    assert isinstance(data, list)
    assert data == [1, 2, 3]

    l = AnsibleLoader(b'- 1\n- 2\n- 3\n')
    data = l.get_single_data()
    assert isinstance(data, list)
    assert data == [1, 2, 3]

    l = AnsibleLoader(b'name: ping\ncommand: /bin/ping -c 2 -w 2 {% for h in hostvars %}{{h.name}} {% endfor %}')
    data = l.get_single_data()
    assert isinstance(data, dict)

# Generated at 2022-06-11 09:33:30.576805
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader("foo")
    assert loader is not None

# Generated at 2022-06-11 09:33:41.256778
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
        foo: !!python/object/apply:operator.add [1, 2, 3]
        bar: !!python/object/apply:operator.add [5, 7, foo]
        baz: !!python/object/apply:operator.add [bar, 10, 20]
    '''

    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.parsing.yaml.data import data_from_ansible_vault

    loader = AnsibleLoader(stream, vault_secrets=['secret'])
    data = loader.get_single_data()
    assert isinstance(data, AnsibleUnicode)
    assert data == 'secret'

    data = loader.get_single_data()

# Generated at 2022-06-11 09:33:48.225464
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml.objects import AnsibleSafeDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import StringIO

    loader = AnsibleLoader("[ 1, 2, 3 ]")
    assert loader.get_single_data() == [1, 2, 3]
    loader = AnsibleLoader("[ 1, 2, 3 ]")
    assert AnsibleSafeDumper(explicit_start=True).dump(loader.get_single_data()) == '[1, 2, 3]\n...\n'
    loader = AnsibleLoader("""
    ---
    - &a
      key: value
    - *a
    """)

# Generated at 2022-06-11 09:33:49.565000
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader(stream='', file_name='', vault_secrets='')

# Generated at 2022-06-11 09:35:11.103597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader
    from six import StringIO
    from ansible.module_utils import six
    import os

    vault_password = os.environ.get('ANSIBLE_VAULT_PASSWORD_FILE', None)
    if vault_password:
        vault_secrets = [('default', vault_password)]
    else:
        vault_secrets = None

    yaml_str = """
---
name: test_dict_and_list
list:
  - item1
  - item2
dict:
  key1: value1
  key2: value2
"""
    yaml_file = StringIO(unicode(yaml_str))
    data = Ans

# Generated at 2022-06-11 09:35:19.982887
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnicode

    class FakeVaultLib:  # test vault secrets
        _secrets = ['secret1', 'secret2']
        def get_secret(self, index):
            return self._secrets[index]

    # Create an AnsibleLoader
    raw_data = """
    {% raw %}
    name: "{{ unvault }}"
    {% endraw %}
    """
    raw_loader = AnsibleLoader(raw_data, vault_secrets=FakeVaultLib())
    raw_node = raw_loader.get_single_data()
    assert isinstance(raw_node.get('name'), AnsibleUnicode)
    assert raw

# Generated at 2022-06-11 09:35:22.274858
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = open('test_vault.yml')
    file_name = 'test_vault.yml'
    vault_secrets = None
    AnsibleLoader(stream, file_name, vault_secrets)

# Generated at 2022-06-11 09:35:25.628880
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import _get_loader_cls
    test_class = _get_loader_cls()

    assert issubclass(test_class, AnsibleLoader)
    assert test_class.__init__.__module__ == AnsibleLoader.__module__

# Generated at 2022-06-11 09:35:34.389383
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
