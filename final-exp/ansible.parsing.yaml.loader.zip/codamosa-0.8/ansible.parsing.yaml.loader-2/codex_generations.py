

# Generated at 2022-06-11 09:25:33.086390
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = "a_list: [a, b, c]"
    ans = AnsibleLoader(stream)
    ans.get_single_data()

# Generated at 2022-06-11 09:25:39.933977
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name='/tmp/test_AnsibleLoader')
    import ansible.parsing.yaml.loader
    assert isinstance(loader, ansible.parsing.yaml.loader.Loader)
    assert isinstance(loader, AnsibleConstructor)
    assert isinstance(loader, Resolver)
    if HAS_LIBYAML:
        import yaml
        assert isinstance(loader, yaml.parser.Parser)

# Generated at 2022-06-11 09:25:41.639551
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, vault_secrets=None)
    assert loader is not None

# Generated at 2022-06-11 09:25:43.237734
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    try:
        loader = AnsibleLoader(None)
    except TypeError:
        raise
    else:
        assert True

# Generated at 2022-06-11 09:25:52.010421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io, sys
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # A simple example to test reading of strings from yaml
    #
    # python3 -c 'from ansible.parsing.yaml.loader import *; test_AnsibleLoader(); sys.exit(0)'
    #
    stream = io.StringIO('''
foo
''')

    loader = AnsibleLoader(stream, file_name='<string>')
    data = loader.get_single_data()
    assert data == 'foo'

    # Test construction of plain string
    stream = io.StringIO('''!plain foo''')

# Generated at 2022-06-11 09:25:53.925931
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    myloader = AnsibleLoader(stream='', file_name='', vault_secrets=None)


# Generated at 2022-06-11 09:26:06.424883
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    if PY3:
        import io
        import sys
        stream = io.StringIO("---\n")
    else:
        import StringIO
        stream = StringIO.StringIO("---\n")

    yaml_loader = Parser(stream)
    assert isinstance(yaml_loader, Parser)

    ansible_loader = AnsibleConstructor(yaml_loader)
    assert isinstance(ansible_loader, AnsibleConstructor)

    a_loader

# Generated at 2022-06-11 09:26:16.473007
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    yaml_str = '''
        key: val
        list:
        - a
        - b
        - c
        '''

    loader = AnsibleLoader(StringIO(yaml_str))

    data = loader.get_single_data()

    assert isinstance(data, AnsibleMapping), "data is not type AnsibleMapping"
    assert isinstance(data.get('list'), AnsibleSequence), "data['list'] is not type AnsibleSequence"

    assert loader.get_data() == [ data ]

# Generated at 2022-06-11 09:26:23.176379
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    val = AnsibleLoader(u"---\n- foo: [one, two, three]\n- bar: { one: 1, two: 2, three: 3 }\n").get_single_data()
    assert isinstance(val, AnsibleSequence)
    for v in val:
        assert isinstance(v, AnsibleMapping)

# Generated at 2022-06-11 09:26:37.441590
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import io

    # create AnsibleLoader object
    loader = AnsibleLoader(io.StringIO('---\n- 1\n- 2\n'))

    # call get_single_data
    assert loader.get_single_data() == [1, 2]

    # call get_single_data
    loader = AnsibleLoader(io.StringIO('---\n- 1\n- 2\n'))
    assert loader.get_single_data() == [1, 2]

    # call get_multi_data
    loader = AnsibleLoader(io.StringIO('---\n- 1\n- 2\n...\n---\n- 3\n- 4\n...\n'))
    assert loader.get_multi_data() == [[1, 2], [3, 4]]

    # call get_

# Generated at 2022-06-11 09:26:42.069366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    with open(__file__) as f:
        loader = AnsibleLoader(f)
        for data in loader:
            pass

# Generated at 2022-06-11 09:26:50.633745
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.module_utils.common.yaml import Parser
    from yaml.resolver import Resolver

    if HAS_LIBYAML:
        assert issubclass(AnsibleLoader, AnsibleConstructor)
        assert issubclass(AnsibleLoader, Parser)
        assert issubclass(AnsibleLoader, Resolver)
    else:
        from yaml.composer import Composer
        from yaml.reader import Reader
        from yaml.scanner import Scanner
        from yaml.parser import Parser

        assert issubclass(AnsibleLoader, Reader)
        assert issubclass(AnsibleLoader, Scanner)
        assert issubclass(AnsibleLoader, Parser)
        assert issub

# Generated at 2022-06-11 09:26:59.584427
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml = AnsibleLoader(None)
    assert yaml is not None
    assert hasattr(yaml, 'construct_python_object')
    assert yaml.construct_python_object == AnsibleBaseYAMLObject.construct_python_object
    assert hasattr(yaml, 'construct_object')
    assert yaml.construct_object == AnsibleBaseYAMLObject.construct_object

# Generated at 2022-06-11 09:27:00.378804
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    raise NotImplementedError

# Generated at 2022-06-11 09:27:02.162426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    >>> AnsibleLoader("", file_name="foo").file_name
    'foo'
    """
    pass

# Generated at 2022-06-11 09:27:10.624178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  import sys
  import io
  import unittest
  import codecs
  from yaml.error import YAMLError

  stream = io.BytesIO("name: ken")
  loader = AnsibleLoader(stream)

  try:
    r = loader.get_single_data()
  except YAMLError as exc:
    print("ERROR:", sys.exc_info())
  assert r == {u'name': u'ken'}

if __name__ == '__main__':
  test_AnsibleLoader()

# Generated at 2022-06-11 09:27:13.047623
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:27:16.305426
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # pylint: disable=too-few-public-methods
    class AnsibleLoaderTest(AnsibleLoader):
        pass

    return AnsibleLoaderTest

# Generated at 2022-06-11 09:27:28.421396
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # Test the different types of strings that can be returned by yaml
    #
    # yaml.load_all(input)
    # yaml.load(input)
    # yaml.safe_load(input)
    # yaml.safe_load_all(input)
    #
    from io import BytesIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

#    obj = AnsibleLoader(BytesIO('invalid: invalid')).get_single_data()
#    assert not isinstance(obj, AnsibleMapping)

    obj = AnsibleLoader(BytesIO('test_string: str')).get_single_data()
    assert isinstance(obj, AnsibleMapping)


# Generated at 2022-06-11 09:27:32.970848
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    import datetime

    loader = AnsibleLoader(None)
    assert loader is not None

    data = datetime.datetime(2013, 9, 27, 15, 32, 48)
    ansible_obj = AnsibleUnicode.from_datetime(data)

    obj = loader.construct_object(data)
    assert isinstance(obj, AnsibleUnicode)

    assert ansible_obj == obj

# Generated at 2022-06-11 09:27:36.549353
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:27:48.929639
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(
        stream = None,
        file_name = '../../../build/ansible-yaml-loader-test-data.yml',
        vault_secrets = None,
    )
    data = loader.get_single_data()
    assert type(data) is dict
    assert data['key1'] == 'value1'

    # Test constructed attribute
    assert data['constructed']['constructed_key'] == 'constructed_value'

    # Test anchors and aliases in YAML
    assert data['anchors']['key1'] == 'value1'
    # pylint: disable=no-member
    assert data['anchors']['key2'] == data['anchors']
    assert data['anchors']['key3'] == data['anchors']

    # Test literals

# Generated at 2022-06-11 09:27:53.512238
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    import os

    # Set current working directory to a temp directory
    tempdir = os.getcwd()
    os.chdir(os.path.dirname(os.path.dirname(__file__)))

    loader = AnsibleLoader(''.join(sys.stdin))

    # Reset current working directory back to old directory
    os.chdir(tempdir)

# Generated at 2022-06-11 09:28:06.935876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    class MyAnsibleLoader(AnsibleLoader):
        pass

    data = '''
---
- hosts: localhost
  roles:
    - test
...
'''
    class MyDumper(yaml.dumper.Dumper):
        def increase_indent(self, flow=False, indentless=False):
            return super(MyDumper, self).increase_indent(flow, False)
    my_dump = yaml.dump(yaml.load(data, Loader=MyAnsibleLoader), Dumper=MyDumper)
    assert my_dump.count("- role: test") == 1, "role should be in one line"
    assert "- role: test" in my_dump, "role should be in yaml"

# Generated at 2022-06-11 09:28:13.430569
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    This is a unit test for AnsibleLoader.
    '''
    loader = AnsibleLoader(None)
    assert loader
    # We can't test that the loaders are different without having a file to read (yaml.load()
    # reads the file).  But, if the loaders were not different, this would fail because
    # the custom loader is not a dict.
    assert loader.loader != dict


# Generated at 2022-06-11 09:28:22.743410
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    contents = b'---\nfoo: bar\n'
    loader = AnsibleLoader(contents)
    assert isinstance(loader, AnsibleLoader)
    assert loader.construct_yaml_map.__name__ == AnsibleConstructor.construct_yaml_map.__name__
    assert loader.construct_yaml_seq.__name__ == AnsibleConstructor.construct_yaml_seq.__name__
    assert loader.construct_yaml_str.__name__ == AnsibleConstructor.construct_yaml_str.__name__

# Generated at 2022-06-11 09:28:23.831955
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:28:28.037783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream=None)
    assert isinstance(ansible_loader, (Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver))
    assert ansible_loader.stream == None

# Generated at 2022-06-11 09:28:36.946164
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    yaml_text = """
---
a: 1
b: 2
c: [3, 4]
d:
  e: 5
  f: 6
"""
    val = AnsibleLoader(yaml_text).get_single_data()
    assert isinstance(val, AnsibleMapping)
    assert 'a' in val
    assert 'b' in val
    assert 'c' in val
    assert 'd' in val
    assert isinstance(val['c'], AnsibleSequence)

# Generated at 2022-06-11 09:28:40.101568
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = ".test: test\n"
    loader = AnsibleLoader(stream)

    assert loader.get_single_data() == {'.test': 'test'}

# Generated at 2022-06-11 09:28:56.991506
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper
    source = """
    - hosts: all
      gather_facts: yes
      environment:
        http_proxy: '{{ proxy }}'
    """
    data = AnsibleLoader(StringIO(source)).get_single_data()
    assert isinstance(data, list)
    assert len(data) == 1
    assert isinstance(data[0], dict)
    assert 'environment' in data[0]
    assert isinstance(data[0]['environment'], dict)
    assert 'http_proxy' in data[0]['environment']

    output = AnsibleDumper(None, None, None).represent_data(data)


# Generated at 2022-06-11 09:28:58.446529
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    inst = AnsibleLoader(b"")
    assert inst is not None

# Generated at 2022-06-11 09:29:09.193124
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    from ansible.parsing.vault import UnsafeText
    from ansible.parsing.vault import VaultPassword
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    mysecret = UnsafeText(b"this is my secret")
    mypassword = VaultPassword(mysecret)
    myvault = VaultLib([mypassword])


# Generated at 2022-06-11 09:29:22.402660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():  # pylint: disable=too-many-statements
    def check(data, expected):
        loader = AnsibleLoader(data, vault_secrets=[])
        result = loader.get_single_data()
        assert result == expected, "%s != %s" % (result, expected)

    check("{foo: 1}", {"foo": 1})
    check('{foo: [ "a", "b", "{{c}}" ]}', {"foo": ["a", "b", "{{c}}"]})
    check('foo: 1\nbar: 2', {"foo": 1, "bar": 2})
    check('---\n- foo: 1\n  bar: 2', [{"foo": 1, "bar": 2}])



# Generated at 2022-06-11 09:29:28.641686
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    sample = '''---
- hosts: localhost
  gather_facts: no
  tasks:
    - debug: var=hostvars['foobar']
    - debug: var=groups['test_group']
'''
    ansible_loader = AnsibleLoader(sample, file_name='blah')

    result = ansible_loader.get_single_data()
    assert result['tasks'][0]['debug']['var'] == "hostvars['foobar']"
    assert result['tasks'][1]['debug']['var'] == "groups['test_group']"

# Generated at 2022-06-11 09:29:41.112770
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = '''
---
# valid YAML w/ hash comments
a: 1
b: 2
'''
    data = AnsibleLoader(s).get_single_data()
    assert type(data.get('a')) == int
    assert data.get('a') == 1
    assert data.get('b') == 2

    # check round trip
    assert AnsibleLoader(s, file_name='<string>').get_single_data() == data
    assert AnsibleLoader(s, file_name='<string>').get_single_data() == {'a': 1, 'b': 2}

    s = '''
# TODO valid YAML w/ non-hash comments
a: 1
b: 2
'''
    # not valid YAML, but no error should be thrown on comments
    data = Ans

# Generated at 2022-06-11 09:29:48.143340
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os.path

    filename = os.path.join(os.path.dirname(__file__), 'datastructure_loader.yml')

    with open(filename, 'r') as myfile:
        content = myfile.read()

    loader = AnsibleLoader(content, file_name=filename)
    assert loader.get_data() == {'a': 1, 'b': {'c': 'ok', 'd': [3, 4, 5]}}

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:30:00.865594
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    test_yaml = b"""
a: 1
b:
  - &id001 {c: 3, d: 4}
  - *id001
"""
    test_yaml = test_yaml.replace(b'\n', b'\r\n')
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None)
    data = loader.get_single_data(test_yaml)
    assert isinstance(data, dict), "data is not a dict: %s" % data
    assert len(data.keys()) == 2, "data does not have 2 keys: %s" % data.keys()
    assert 'a' in data, "data does not contain key 'a': %s" % data.keys()

# Generated at 2022-06-11 09:30:01.893748
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader(stream=None)

# Generated at 2022-06-11 09:30:04.816836
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    stream = open(sys.argv[1], 'r')
    loader = AnsibleLoader(stream)
    print('constructor success')
    stream.close()

# Generated at 2022-06-11 09:30:27.326474
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    vault_secrets = [VaultSecret('vault_password', VaultLib('vault_password'))]

# Generated at 2022-06-11 09:30:37.853357
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    # We need a valid VaultSecret
    from ansible.parsing.vault import VaultSecret
    data = """
        ---
        foo: bar
        baz:
            - one
            - two
            - three
        dict:
            one: two
        """
    loader = AnsibleLoader(data)
    ds = loader.get_single_data()
    assert type(ds) == AnsibleMapping
    assert type(ds['baz']) == AnsibleSequence
    assert len(ds['baz']) == 3
    assert type(ds['dict']) == AnsibleMapping
    # Test with vault_secret
    vault_secret = VaultSecret('password')

# Generated at 2022-06-11 09:30:49.741888
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping

    class AnsibleLoader(object):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            self._stream = stream
            self._vault_secrets = vault_secrets
            self._file_name = file_name

        def get_single_data(self):
            return yaml.safe_load(self._stream)


# Generated at 2022-06-11 09:30:58.552082
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml
    vault_secrets = [VaultLib(password='testvaultpassword')]

# Generated at 2022-06-11 09:31:03.585170
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # set up
    from io import StringIO
    buf = '''
    ---
    - name: test
    '''

    # test
    l = AnsibleLoader(StringIO(buf))
    dd = l.get_data()
    assert dd[0]['name'] == 'test'

# Generated at 2022-06-11 09:31:09.106630
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
    - 1
    - 2
    '''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == [1, 2]

    data = '''
    - 1
    - 2
    '''
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == [1, 2]

# Generated at 2022-06-11 09:31:10.104509
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:31:17.465402
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestAnsibleLoader(AnsibleLoader):
        def __init__(self, stream):
            super(TestAnsibleLoader, self).__init__(stream, file_name='file_name', vault_secrets='vault_secrets')

    # Unfortunately, this requires a real YAML file to test the constructor.
    # This test assumes the YAML file being loaded is already valid and will
    # only test whether AnsibleConstructor was initialized with the expected
    # arguments.
    with open('/etc/ansible/hosts', 'r') as stream:
        loader = TestAnsibleLoader(stream)
        assert loader.file_name == 'file_name'
        assert loader.vault_secrets == 'vault_secrets'

# Generated at 2022-06-11 09:31:18.172791
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream="test")

# Generated at 2022-06-11 09:31:28.421090
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # for the test we need a class with a working __init__ function,
    # which is currently not the case in AnsibleLoader
    class dummy(AnsibleLoader):
        def __init__(self, stream, file_name=None, vault_secrets=None):
            AnsibleLoader.__init__(self, stream, file_name, vault_secrets)

    from io import BytesIO
    yaml_str = "---\n"
    yaml_bytes = yaml_str.encode()
    dummy(BytesIO(yaml_bytes))

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:31:52.489152
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import ansible.parsing.yaml.objects
    class Loader(AnsibleLoader):
        def construct_object(self, node, deep=False):
            return ansible.parsing.yaml.objects.AnsibleMapping(None, deep)

    loader = Loader(stream=None)
    loader.construct_object(None, None)

# Generated at 2022-06-11 09:31:54.363139
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    datastring = '''
    - include: test.yml
    '''
    assert hasattr(AnsibleLoader(datastring, file_name='hello'), file_name)

# Generated at 2022-06-11 09:31:57.244305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    loader = AnsibleLoader(None, file_name='file_name')
    assert isinstance(loader.file_name, AnsibleUnicode)
    assert loader.vault_secrets is None

# Generated at 2022-06-11 09:32:03.729768
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.module_utils.common.yaml import YAML
    from ansible.module_utils.json_utils import AnsibleJSONEncoder

    obj = YAML(typ='rt', pure=True).load('''
        ---
        - foo
        - bar
        - 1
        - 2
        - 3
        - quux
        - { a: alpha, b: beta, c: charlie }
    ''')

    assert isinstance(obj, AnsibleSequence)
    assert obj == ["foo", "bar", 1, 2, 3, "quux", {"a": "alpha", "b": "beta", "c": "charlie"}]

# Generated at 2022-06-11 09:32:12.512693
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.nodes import AnsibleScalarNode, AnsibleSequenceNode, AnsibleMappingNode

    v = b'{foo: bar}'
    stream = yaml.compat.BytesIO(v)
    loader = AnsibleLoader(stream)
    result = loader.get_single_data()

    assert isinstance(result, AnsibleMapping)
    assert len(result) == 1

    k = next(iter(result))
    assert isinstance(k, AnsibleUnicode)
    assert k == u'foo'

    v = result[k]
    assert isinstance(v, AnsibleUnicode)
    assert v == u'bar'



# Generated at 2022-06-11 09:32:18.407670
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input = """foo: !!str 123
bar: !!str
  long string
baz: !!str "
  long
  string
"
qux: !!str
  "long
  string
"
"""
    loader = AnsibleLoader(input)
    loader.get_single_data()
    assert loader.stream is input, 'loader.stream is not input.'

# Generated at 2022-06-11 09:32:27.906958
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert isinstance(AnsibleLoader({'one': ['a','b','c'], 'two':[1,2,3]}).get_single_data(), dict)
    assert isinstance(AnsibleLoader('[1,2,3]').get_single_data(), list)
    assert isinstance(AnsibleLoader('this is a string').get_single_data(), AnsibleUnsafeText)
    assert isinstance(AnsibleLoader('42').get_single_data(), int)
    assert isinstance(AnsibleLoader('3.14159').get_single_data(), float)
    assert AnsibleLoader('true').get_single_data() is True
    assert AnsibleLoader('false').get_single_data() is False

# Generated at 2022-06-11 09:32:29.534306
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    loader = AnsibleLoader(sys.stdin)
    assert loader
    return loader

# Generated at 2022-06-11 09:32:30.220662
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader

# Generated at 2022-06-11 09:32:31.118998
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # base test
    assert AnsibleLoader(None)

# Generated at 2022-06-11 09:33:14.615792
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:33:16.672510
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # FIXME: This should be a real unit test
    pass

# Generated at 2022-06-11 09:33:23.307448
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Unit test for AnsibleLoader class
    """
    example_yaml = """
    - foo: 1
    - bar:
       baz: 3
    - foobar: 4
    """
    result = AnsibleLoader(example_yaml).get_single_data()
    assert result['foo'] == 1
    assert result['bar']['baz'] == 3
    assert result['foobar'] == 4

# Generated at 2022-06-11 09:33:25.157668
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

# Generated at 2022-06-11 09:33:26.960806
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    instance = AnsibleLoader(None)
    assert isinstance(instance, AnsibleLoader)

# Generated at 2022-06-11 09:33:29.075198
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream_from_str = AnsibleLoader(None)
    assert isinstance(stream_from_str, AnsibleLoader)

# Generated at 2022-06-11 09:33:33.100165
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    input_string = """
---
hosts: localhost
tasks:
    - name: test
      ping:
"""
    yaml_loader = AnsibleLoader(input_string)
    obj = yaml_loader.get_single_data()
    assert obj

# Generated at 2022-06-11 09:33:36.930556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '---\nstring: "{{ foo }} baz"\n'
    loader = AnsibleLoader(stream)
    data = loader.get_single_data()
    assert data == {'string': '{{ foo }} baz'}

# Generated at 2022-06-11 09:33:45.761939
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:33:55.537742
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:35:28.008499
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

# Generated at 2022-06-11 09:35:30.153795
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass


# AnsibleLoder is a deep subclass of the PyYAML Loader class.
# pylint: disable=too-many-ancestors