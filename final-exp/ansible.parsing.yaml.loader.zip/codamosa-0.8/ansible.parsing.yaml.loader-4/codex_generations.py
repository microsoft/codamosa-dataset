

# Generated at 2022-06-11 09:25:40.139674
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
    foo:
      - bar:
          baz: 1
          qux: 2
      - baz: 3
        qux: 4
    """
    file_name = 'AnsibleLoadertest.yml'
    vault_secrets=None

    loader = AnsibleLoader(data, file_name=file_name, vault_secrets=vault_secrets)

    # test AnsibleConstructor
    parser = AnsibleConstructor(file_name=file_name, vault_secrets=vault_secrets)
    assert parser.file_name == file_name
    assert parser._vault_secrets is None

    # test AnsibleLoader
    assert loader.file_name == file_name
    assert loader._vault_secrets is None

    # test Reader
    assert loader.stream == data

# Generated at 2022-06-11 09:25:49.261178
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-11 09:25:51.051857
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.add_constructor(u'!vault', AnsibleConstructor.construct_yaml_vault)

# Generated at 2022-06-11 09:25:56.720233
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class TestVaultSecret(object):
        unvaulted = {'foo': 'bar'}

    class TestConstructor(object):
        vault_secrets = TestVaultSecret()

    data = {"foo": "{{ bar }}"}
    loader = AnsibleLoader(data, vault_secrets=TestConstructor().vault_secrets)
    assert loader.get_single_data() == data

# Generated at 2022-06-11 09:26:09.658920
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    sample_data_1 = '''
hello: world
'''

    sample_data_2 = '''
---
hello: world
'''

    sample_data_3 = '''
---
{a_dict}
'''.format(a_dict=sample_data_2)

    def test_data(data):
        try:
            from io import StringIO
        except ImportError:
            from StringIO import StringIO

        ansible_loader = AnsibleLoader(StringIO(data))
        data = ansible_loader.get_single_data()
        return data

    # test_data(sample_data_1)
    assert test_data(sample_data_1) == {'hello': 'world'}, 'failed to parse yaml data: %s'%sample_data_1

    # test_data(sample_data

# Generated at 2022-06-11 09:26:10.305444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:26:19.629423
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Add tests to ensure correct class members exist
    #       and that yaml can be loaded and parsed correctly
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import types

    # m = AnsibleLoader(None, 'foo', None)

    # 1. does dict-lookup work?
    assert isinstance(AnsibleLoader.SafeLoader, type)

    # 2. does base-class construction work?
    # AnsibleLoader([])

    # 3. can encrypted strings be loaded?

# Generated at 2022-06-11 09:26:33.770319
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import pprint
    def _check(s):
        pprint.pprint(_AnsibleLoader(s).get_single_data())
    _check('foo')
    _check('"foo"')
    _check('[ foo ]')
    _check('{ foo: bar }')
    _check('foo: [ bar ]')
    _check('foo: { bar: baz }')
    _check('---\nfoo')
    _check('---\n"foo"')
    _check('---\n[ foo ]')
    _check('---\n{ foo: bar }')
    _check('---\nfoo: [ bar ]')
    _check('---\nfoo: { bar: baz }')
    _check('---\n#comment\nfoo')

# Generated at 2022-06-11 09:26:45.257398
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    Unit test for constructor of class AnsibleLoader
    '''

    import ansible.parsing.yaml.loader

    # Constructor of AnsibleLoader is imported from the __init__.py file of module ansible.parsing.yaml.loader
    # ansible.parsing.yaml.loader.__init__.AnsibleLoader

    # The constructor of AnsibleLoader depends on HAS_LIBYAML

# Generated at 2022-06-11 09:26:46.658237
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader.stream == None

# Generated at 2022-06-11 09:26:56.794915
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
vault_password: mysecret

name: stuff
my_dict:
    dn: 'something'
    foo: 'bar'
'''

    loader = AnsibleLoader(data, vault_secrets=[{'password': 'mysecret', 'identities': ['mysecret']}])
    loader.get_single_data()


if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:26:57.317971
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    AnsibleLoader(file_name=None, vault_secrets=None, stream=None)

# Generated at 2022-06-11 09:26:59.349906
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
  config = '''
- name: hostname
  hosts: all
  variables:
    var1: 1
'''
  ansible_loader = AnsibleLoader(config)
  assert type(ansible_loader.get_single_data()) == list
  assert ansible_loader.get_single_data()[0]['name'] == 'hostname'

# Generated at 2022-06-11 09:27:03.360351
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - hosts: localhost
      tasks:
         - shell: cat /etc/passwd
    """
    stream = yaml_str.encode('utf-8')
    result = AnsibleLoader(stream).get_single_data()
    assert result is not None

# Generated at 2022-06-11 09:27:15.822959
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.dumper import AnsibleDumper

    source = '''
- hosts: localhost
  gather_facts: False
  tasks:
  - name: test
    debug:
      msg: hello
'''

    data = AnsibleLoader(source).get_single_data()

    # the following assert will fail if AnsibleLoader is not a subclass of AnsibleBaseYAMLObject
    assert isinstance(data, AnsibleBaseYAMLObject)

    # check that the AnsibleBaseYAMLObject class is working correctly
    check_data = AnsibleDumper().dump(data, default_style=None)[0]
    assert check_data == source

# Generated at 2022-06-11 09:27:18.512186
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = '''
---
name: "test"
'''
    loader = AnsibleLoader(stream)
    loader.get_single_data()


# Generated at 2022-06-11 09:27:20.355729
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('test_stream', 'test_file_name', 'test_vault_secrets')

# Generated at 2022-06-11 09:27:28.993381
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # If libyaml is not installed, constructors are loaded in
    # the super class for Reader, Scanner, Parser and Composer.
    # The base class for AnsibleLoader is Parser, which is loaded
    # into the super class for Reader and Scanner, so we test against
    # Parser in this case.
    if not HAS_LIBYAML:
        assert isinstance(AnsibleLoader(None), Parser)
    else:
        assert isinstance(AnsibleLoader(None), Parser)

# Generated at 2022-06-11 09:27:29.855478
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader('', '')

# Generated at 2022-06-11 09:27:32.190137
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert(isinstance(loader, AnsibleLoader))

# Generated at 2022-06-11 09:27:47.934076
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    - hosts: localhost
      user: root
      tasks:
        - name: echo foo
          shell: echo "foo"
    """
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    expected_dic = {
        'hosts': 'localhost',
        'user': 'root',
        'tasks': [{
            'name': 'echo foo',
            'shell': 'echo "foo"'
        }]
    }
    loader = AnsibleLoader(yaml_str)
    assert isinstance(loader.get_single_data(), AnsibleBaseYAMLObject)
    assert loader.get_single_data().get_data() == expected_dic

# Generated at 2022-06-11 09:27:51.230454
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml.load("""
        - hosts: localhost
          tasks:
          - set_fact:
              my_fact: |
                string with
                multiple lines
            """, Loader=AnsibleLoader)


# Generated at 2022-06-11 09:27:52.548077
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, "__init__")

# Generated at 2022-06-11 09:28:02.932708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    class Test(object):
        def __init__(self, test=None):
            self.test = test
    stream = b"---\ntest: yaml\n"
    loader = AnsibleLoader(stream)
    loader.get_single_data()
    assert isinstance(loader.get_single_data(), Test)
    assert isinstance(loader.get_single_data().test, AnsibleUnicode)
    assert loader.get_single_data().test == u'yaml'

# Generated at 2022-06-11 09:28:14.423155
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    # test 1
    data = '''
    ---
    - hosts: 1.2.3.4
      gather_facts: false
      roles:
        - { role: 'test', x: 1, y: 2 }
    '''
    loader = AnsibleLoader(data)
    obj = loader.get_single_data()
    assert obj['hosts'] == "1.2.3.4"
    assert obj['gather_facts'] is False
    assert obj['roles'][0]['role'] == 'test'
    assert obj['roles'][0]['x'] == 1
    assert obj['roles'][0]['y'] == 2

    # test 2

# Generated at 2022-06-11 09:28:21.541434
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(stream="")
    assert loader.file_name == None
    assert loader.vault_secrets == None
    assert loader.stream == ""

    data = yaml.load("""
        - hosts: localhost
          vars:
            key: val
    """, Loader=AnsibleLoader)
    assert 'localhost' in data

# Generated at 2022-06-11 09:28:26.731488
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
        Test the loader constructor
    '''
    try:
        from yaml import CSafeLoader as SafeLoader
    except ImportError:
        from yaml import SafeLoader

    assert issubclass(AnsibleLoader, SafeLoader)
    assert issubclass(AnsibleLoader, AnsibleConstructor)

# Generated at 2022-06-11 09:28:28.198839
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert hasattr(loader, '__init__')

# Generated at 2022-06-11 09:28:39.633782
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import json

# Generated at 2022-06-11 09:28:44.794696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data='{foo: [1, 2]}'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': [1, 2]}

    data='{foo: [1, bar: 2, baz: 3]}'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': [1, {'bar': 2, 'baz': 3}]}

    data='{foo: [1, 2, baz: 3]}'
    loader = AnsibleLoader(data)
    assert loader.get_single_data() == {'foo': [1, 2, {'baz': 3}]}

# Generated at 2022-06-11 09:29:04.350939
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    dl = DataLoader()
    vault_secret = '$ANSIBLE_VAULT;1.1;AES256'
    vault_password = 'ansible'
    vault = VaultLib(vault_password)
    file_name = 'file_name'
    s = "vault_test: !vault |\n          %s\n          6368616e676520746869732070617373776f726420746f\n          2061207761746c6520666f72207468652064617461206d657373616765" % vault_secret
    data = d

# Generated at 2022-06-11 09:29:13.144830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import datetime
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import io
    import sys
    import unittest

    class TestAnsibleLoader(unittest.TestCase):
        def test_constructor(self):
            yaml_str = u'''
            - 1
            - 2
            '''
            loader = AnsibleLoader(io.StringIO(yaml_str))
            data = loader.get_single_data()
            self.assertEqual(data, [1, 2])
            self.assertIsInstance(data[0], int)
            self.assertIsInstance(data[1], int)
            self.assertEqual(loader.file_name, None)


# Generated at 2022-06-11 09:29:26.197567
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.yaml import objects

    vault_secret = VaultLib('mysecret')
    loader = AnsibleLoader(file_name='/tmp/foo', vault_secrets={'default': vault_secret})

    assert loader is not None, "AnsibleLoader should return an object"
    assert isinstance(loader, AnsibleLoader), "AnsibleLoader should return an object of AnsibleLoader class"

    assert len(loader.vault_secrets) == 1, "Loader should have one vault secret in secrets"

    assert loader.vault_secrets['default'] == vault_secret, "Loader's vault secrets should match"

    assert loader.vault_password_files == [], "Loader's vault password files should start empty"

    assert loader.construct_yaml

# Generated at 2022-06-11 09:29:37.944597
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins  # pylint: disable=redefined-builtin
    from ansible.parsing.yaml.loader import AnsibleLoader

    class MockLoader(AnsibleLoader):
        pass

    assert builtins.__dict__['_'] == AnsibleLoader._  # pylint: disable=protected-access
    assert '_' in dir(MockLoader)  # pylint: disable=protected-access
    assert MockLoader._ == AnsibleLoader._  # pylint: disable=protected-access

# Generated at 2022-06-11 09:29:39.297343
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # AnsibleLoader is actually a load() function, it cannot be instantiated
    pass

# Generated at 2022-06-11 09:29:41.618900
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''ansible.parsing.yaml.loader.AnsibleLoader unit tests'''
    # test AnsibleLoader in 2.x and 3.x
    assert AnsibleLoader is AnsibleConstructor

# Generated at 2022-06-11 09:29:52.803696
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    # Create a vault-encrypted data block and create a loader that can handle it
    vault_secret = 'vaultsecret'

    vault = VaultLib(vault_secret)
    data = vault.encode('foo')

    loader_data = b'---\n' + data
    with DataLoader() as loader:
        loader.set_vault_secrets(['vaultsecret'])
        data = loader.load(loader_data, None, cache=False)

    # Create a data block that is handled by the ansible loader

# Generated at 2022-06-11 09:29:54.675224
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader('')

# Generated at 2022-06-11 09:29:57.144776
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    string = b'''
    - hosts: all
      gather_facts: no
      tasks:
        - block:
            - debug: msg="this is a block"

          rescue:
            - debug: msg="this is a rescue for the block"

          always:
            - debug: msg="this is always"
    '''
    data = AnsibleLoader(string).get_single_data()
    assert data
    assert data[0]
    assert 'hosts' in data[0]

# Generated at 2022-06-11 09:30:08.096718
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile
    from ansible.parsing.vault import VaultLib
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    vault_secret = 'changeme'
    vault_secrets = [vault_secret]

# Generated at 2022-06-11 09:30:31.431214
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, file_name='<string>')
    assert loader.file_name == '<string>'
    loader = AnsibleLoader(None, file_name=None)
    assert loader.file_name == '<unicode string>'
    loader = AnsibleLoader(None, file_name=12)
    assert loader.file_name == '<unicode string>'


# Generated at 2022-06-11 09:30:32.478114
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader()


# Generated at 2022-06-11 09:30:41.213285
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.dumper import AnsibleDumper

# Generated at 2022-06-11 09:30:49.744801
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars import VaultLib

    loader = AnsibleLoader(None, vault_secrets=[VaultLib(b'foo')])
    assert isinstance(loader.construct_yaml_str(None), AnsibleVaultEncryptedUnicode)
    assert isinstance(loader.construct_scalar(None), AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-11 09:30:58.563735
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import FakeAnsibleConstructor, FakeAnsibleConstructor2
    if HAS_LIBYAML:
        loader = AnsibleLoader(None, file_name='test_file', vault_secrets=None)
        assert hasattr(loader, '_yaml_base_loader_cls')
        assert loader.constructor == FakeAnsibleConstructor
        assert loader.base_loader_cls == loader._yaml_base_loader_cls
    else:
        loader = AnsibleLoader(None, file_name='test_file', vault_secrets=None)
        assert not hasattr(loader, '_yaml_base_loader_cls')
        assert loader.constructor == FakeAnsibleConstructor2
        assert loader.base_loader_cls == None

# Generated at 2022-06-11 09:31:10.148592
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml

    class FakeVaultedFile:
        def __init__(self):
            self.filename = 'fake_vaulted_file.yml'
            self.ssh_key = 'fake_ssh_key'
        def _get_decrypted_contents(self):
            return 'fake_decrypted_contents'

    plain_data = {
        'a': 'b',
        'c': 'd',
        'e': 'f'
        }
    plain_yml = yaml.dump(plain_data, default_flow_style=False)


# Generated at 2022-06-11 09:31:23.056896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # given
    s = str(
        '- name: Prerequisites\n'
        '  raw:\n'
        '    apt:\n'
        '      name: foo\n'
        '      state: present\n'
        '- name: Add foo user\n'
        '  user:\n'
        '    name: foo\n'
        '    state: present'
    )

    # when
    ansible_loader = AnsibleLoader(s)

    # then
    assert len(ansible_loader.get_data()) == 2
    assert len(ansible_loader.construct_mapping(None)) == 2
    assert len(ansible_loader.construct_sequence(None)) == 2
    assert len(ansible_loader.construct_yaml_map(None)) == 2

# Generated at 2022-06-11 09:31:30.924174
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.dataloader import DataLoader
    d = DataLoader()
    content = '''
    ---
    - hosts: all
      gather_facts: false
      tasks:
        - debug:
            msg: hello world
    '''

    data = d.load(content)[0]
    assert data.get('hosts') == ['all']
    assert data.get('gather_facts') is False
    assert data.get('tasks') == [{'debug': {'msg': 'hello world'}}]

# Generated at 2022-06-11 09:31:38.460675
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = """
    ---
    roles:
      - {role: common, tags: [common]}
      - {role: web, tags: [web]}
    """

    yaml_obj = {'roles': [{u'role': u'common', u'tags': [u'common']}, {u'role': u'web', u'tags': [u'web']}]}
    loader = AnsibleLoader(yaml_str)
    data = loader.get_single_data()
    assert data == yaml_obj



# Generated at 2022-06-11 09:31:41.896515
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    if sys.version_info[0] > 2:
        assert issubclass(AnsibleLoader, Parser)
    else:
        assert issubclass(AnsibleLoader, (Reader, Scanner, Parser, Composer))

# Generated at 2022-06-11 09:32:26.204659
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys
    sys.path.append("../")
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    # Test that ansible-specific datatypes are constructed and used
    loader = AnsibleLoader("---\n- 1\n- 2\n")
    data = loader.get_single_data()
    assert isinstance(data, AnsibleMapping)
    assert len(data) == 0
    seq = loader.construct_sequence()
    assert isinstance(seq, AnsibleSequence)
    assert len(seq) == 2
    assert seq[0] == 1
    assert seq[1] == 2
    # Test that ansible-specific datatypes are constructed and used
    loader = AnsibleLoader("---\n1: a\n2: b\n")

# Generated at 2022-06-11 09:32:27.810603
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert isinstance(AnsibleLoader((x for x in ())), AnsibleLoader)

# Generated at 2022-06-11 09:32:37.387052
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    stream = b"test: {{ test }}"
    loader = AnsibleLoader(StringIO(stream), file_name='test', vault_secrets=[])
    d = loader.get_single_data()
    assert d == "test: {{ test }}"
    stream = b"test: {{ test }}"
    loader = AnsibleLoader(StringIO(stream), file_name='test', vault_secrets=[])
    d = loader.get_single_data()
    assert d == "test: {{ test }}"

# Generated at 2022-06-11 09:32:39.415556
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Can't really test this.  If anything, it's only really testing that
    # the code compiles as this is a wrapper class.
    pass

# Generated at 2022-06-11 09:32:41.402203
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Shouldn't call __init__, but don't want to throw error
    pass


# Generated at 2022-06-11 09:32:49.830348
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader('foo')
    assert isinstance(loader.construct_yaml_str('!vault |\n\n foo\n bar\n'), AnsibleVaultEncryptedUnicode)
    assert isinstance(loader.construct_yaml_str('!vault |\n    foo\n    bar\n'), AnsibleVaultEncryptedUnicode)
    assert isinstance(loader.construct_yaml_str('!vault\n  foo: bar\n'), AnsibleVaultEncryptedUnicode)
    assert loader.construct_yaml_str('!vault foo\n') == '!vault foo'

# Generated at 2022-06-11 09:32:56.278785
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # load a dict
    data = '{"key": "value"}'
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == {'key': 'value'}

    # load a list
    data = '[1, 2, 3]'
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == [1, 2, 3]

    # load with unicode
    data = u'{ "item1": "日本語", "item2": "value2" }'
    loader = AnsibleLoader(data)
    result = loader.get_single_data()
    assert result == {'item1': u'日本語', 'item2': 'value2'}

    # load from file

# Generated at 2022-06-11 09:33:00.568998
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    yaml_str = '''
---
[0, 1, 2]: {a: b}
'''
    loader = AnsibleLoader(yaml_str)
    loader.get_data()

# Generated at 2022-06-11 09:33:14.536065
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    import sys

    data = u"""
    ---
    # list
    - app1
    - app2: value1
      app3: value2

    # list
    - one
    - two
    - three
    """

    results = []
    if sys.version[0] == '2':
        results = [
            [u'app1'],
            [{u'app3': u'value2', u'app2': u'value1'}],
            [u'one', u'two', u'three']
        ]

# Generated at 2022-06-11 09:33:20.924708
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.included_file import IncludedFile

    loader = DataLoader()

    stream = u"name: test"
    data = '\n'.join([u'---', stream, ''])
    data_result = loader.load(data)
    stream_result = loader.load(stream)
    assert stream_result == data_result

    # Loaders should be reusable
    stream_result

# Generated at 2022-06-11 09:34:38.430043
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #import yaml
    yaml.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, AnsibleLoader.construct_mapping)
    #from ansible.parsing.yaml.objects import AnsibleUnicode
   
    stream = open('/home/gitlab-runner/builds/5b5d5b5f/0/qwerty/ansible-inventory-visualizer/examples/test.yml')
    loader = AnsibleLoader(stream)
    print( type(loader) )
    print( loader )

    for i in loader:
        print( type(i) )
        print( i )

if __name__ == "__main__":
    test_AnsibleLoader()

# Generated at 2022-06-11 09:34:41.571375
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import StringIO

    test_yaml = StringIO.StringIO(u'[ 1, 2, 3 ]')
    loader = AnsibleLoader(test_yaml)
    assert loader.get_single_data() == [1, 2, 3]

# Generated at 2022-06-11 09:34:48.619104
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    datastring = '''
- hosts:
    - server1
    - server2
  sudo: yes
  tasks:
    - name: echo "Hello World"
      command: /bin/echo "{{item}}"
      with_items:
        - "Hello World"
'''

    data = AnsibleLoader(datastring, file_name='test.yml').get_single_data()

    assert data['hosts'] == ['server1', 'server2']
    assert data['sudo']
    assert data['tasks'][0]['name'] == 'echo "Hello World"'

# Generated at 2022-06-11 09:34:56.995572
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io, sys
    test_filename = "tests/test_loader.yml"

    # Constructor without arguments
    loader = AnsibleLoader(None)

    # Constructor with arguments
    with io.open(test_filename, 'r', encoding="utf-8") as stream:
        loader = AnsibleLoader(stream)

    # Constructor with other arguments
    loader = AnsibleLoader(None, vault_secrets=['vault_secret_password'])

    # Various attributes
    assert loader.stream is None
    loader.stream = stream
    assert loader.stream is not None

    assert loader.file_name is None
    loader.file_name = test_filename
    assert loader.file_name is not None

    assert loader.vault_secrets == ['vault_secret_password']
    loader.vault_secrets

# Generated at 2022-06-11 09:35:04.022378
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = AnsibleLoader(None, file_name='/path/to/file', vault_secrets=['123'])
    assert loader.file_name == '/path/to/file'

    # Vault EncryptedUnicode
    vault_obj = AnsibleVaultEncryptedUnicode('$ANSIBLE_VAULT;123;YmFzZTY0IGNvZGUgZm9yIHRlc3Q=')
    loader.vault_secrets.append('123')
    assert loader.construct_yaml_str(None, vault_obj) == 'test'

    loader.vault_secrets.pop()

# Generated at 2022-06-11 09:35:06.065783
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import BaseConstructor
    assert issubclass(AnsibleLoader, BaseConstructor)

# Generated at 2022-06-11 09:35:06.987501
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:35:12.664576
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import YAML
    data = r'''
some_var: 1
other_var: 2
some_dict:
    key: value
other_dict:
    key: value
some_list:
    - list_value1
    - list_value2
'''
    loader = AnsibleLoader(data)
    loader.ansible_vault_secrets = ['dummy']
    data = loader.get_single_data()
    assert data == YAML().load(data)

# Generated at 2022-06-11 09:35:21.535675
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:35:30.249404
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    #
    # Example 1:
    #
    #  input_data:
    #   - name: "foo"
    #     hosts: 1.2.3.4
    #     tasks:
    #        - action: ping
    #
    #  output_data:
    #    {
    #        'hosts': 1.2.3.4,
    #        'name': 'foo',
    #        'tasks':
    #        [
    #            {
    #                'action': 'ping'
    #            }
    #        ]
    #    }
    #
    input_data = \
    """
    - name: "foo"
      hosts: 1.2.3.4
      tasks:
        - action: ping
    """