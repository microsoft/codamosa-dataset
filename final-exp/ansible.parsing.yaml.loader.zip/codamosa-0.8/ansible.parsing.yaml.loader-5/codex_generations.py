

# Generated at 2022-06-11 09:25:38.444435
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    code = """
authorized_key:
  user: ansible
  state: present
  key: '{{ lookup("file", item) }}'
with_fileglob:
  - ~/.ssh/id_rsa.pub

# test_dict is a dict with a "key" key
test_dict:
  key: value

# test_list is a list of dicts
test_list:
  - foo: bar
  - 1

test_var: "{{test_dict}}"
    """
    data = AnsibleLoader(code).get_single_data()

# Generated at 2022-06-11 09:25:40.256654
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    obj = AnsibleLoader(stream=None)
    assert obj is not None

# Generated at 2022-06-11 09:25:49.382366
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io

    class TestAnsibleLoader(AnsibleLoader):
        def disallow_implicit_resolvers(self):
            pass

    stream = io.StringIO("""
    - hosts: localhost
      gather_facts: no
      vars:
          var1: a_string
          var2: 123
      tasks:
          - debug: var=var1
          - debug: var=var2
    """)
    data = TestAnsibleLoader(stream).get_single_data()
    for h in data:
        assert isinstance(h, dict), "h is not a dict"
        assert isinstance(h['hosts'], basestring), "hosts is not a string"
        assert isinstance(h['gather_facts'], bool), "gather_facts is not a bool"

# Generated at 2022-06-11 09:25:56.880421
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    file_name = '/foo/bar.yaml'
    loader = AnsibleLoader(stream='', file_name=file_name, vault_secrets=[])
    assert hasattr(loader, 'stream') and loader.stream == ''
    assert hasattr(loader, 'file_name') and loader.file_name == file_name
    assert hasattr(loader, 'vault_secrets') and loader.vault_secrets == []
    assert hasattr(loader, '_vault') and loader._vault is None

# Generated at 2022-06-11 09:26:04.462888
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    construct_mapping = AnsibleLoader.yaml_constructors['tag:yaml.org,2002:map']

    # Testing mapping construction with unordered dict
    construct_mapping('Test', [('key1', 'value1'), ('key2', 'value2')])

    # Testing map construction with ordered dict
    construct_mapping('Test', [('key1', 'value1'), ('key2', 'value2'), ('key3', 'value3')])

# Generated at 2022-06-11 09:26:11.234788
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import sys

    # Check for Python 2
    if sys.version_info < (3,):
        file_contents = io.BytesIO(b'{"foo": "bar"}')
    else:
        file_contents = io.StringIO('{"foo": "bar"}')

    loader = AnsibleLoader(file_contents, vault_secrets=[])

    assert "foo" in loader.get_single_data()

# Generated at 2022-06-11 09:26:16.557536
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    a = AnsibleLoader(['---\n', '- foo: bar'])
    assert a.get_single_data() == ['foo', 'bar']

    a = AnsibleLoader(['---\n', 'foo: bar'])
    assert a.get_single_data() == {'foo': 'bar'}

    if __name__ == '__main__':
        test_AnsibleLoader()

# Generated at 2022-06-11 09:26:28.126265
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """
    Create an AnsibleLoader object and instantiate its various data structures.
    """
    loader = AnsibleLoader(None)

    assert isinstance(loader.construct_mapping, type(dict()))
    assert isinstance(loader.yaml_constructors, type(dict()))
    assert isinstance(loader.tagged_classes, type(dict()))
    assert isinstance(loader.vault_secrets, type(list()))
    assert isinstance(loader.file_name, type(None))

    assert isinstance(loader.resolver.yaml_implicit_resolvers, type(dict()))
    assert isinstance(loader.resolver.yaml_path_resolvers, type(dict()))

# Generated at 2022-06-11 09:26:40.822789
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    res = AnsibleLoader(None, vault_secrets=[], file_name='test_file').get_single_data()
    assert isinstance(res, AnsibleUnicode)
    assert not res
    res = AnsibleLoader(None, vault_secrets=[]).get_single_data()
    assert isinstance(res, AnsibleUnicode)
    assert not res
    test_str = "test string"
    res = AnsibleLoader(test_str, vault_secrets=[]).get_single_data()
    assert isinstance(res, AnsibleUnicode)
    assert res == test_str
    test_dict = dict(a=1, b=2)
    res = Ansible

# Generated at 2022-06-11 09:26:49.959101
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    import os
    import sys
    import textwrap
    import yaml

    import ansible.parsing.yaml.objects
    import ansible.parsing.yaml.dumper

    class TestAnsibleDumper(yaml.SafeDumper):
        pass

    AnsibleLoader.add_to_loader_class(TestAnsibleDumper, '!test', ansible.parsing.yaml.objects.AnsibleSequence)

    TestAnsibleDumper.add_representer(ansible.parsing.yaml.objects.AnsibleSequence,
                                      ansible.parsing.yaml.dumper.AnsibleDumper.represent_sequence)


# Generated at 2022-06-11 09:27:02.605944
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    class Test(object):

        def __init__(self):
            self.yaml_data = '''
                foo: 1
                bar:
                  - hosta
                  - hostb
                bam: {a: 1, b: 2, c: 3}
                baz:
                  - {a: 1, b: 2, c: 3}
                  - {a: 4, b: 5, c: 6}
                  - {a: 7, b: 8, c: 9}
            '''

        def test_constructor(self):
            loader = AnsibleLoader(self.yaml_data)
            data = loader.get_single_data()

# Generated at 2022-06-11 09:27:05.779470
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    assert hasattr(AnsibleLoader, '__init__')
    assert AnsibleLoader.__init__ != AnsibleConstructor.__init__

# Generated at 2022-06-11 09:27:11.622964
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    ansible_loader = AnsibleLoader(stream=None, file_name=None, vault_secrets=None)
    assert ansible_loader.get_single_data() is None
    assert isinstance(ansible_loader, AnsibleConstructor)
    assert isinstance(ansible_loader, Resolver)

# Generated at 2022-06-11 09:27:14.822205
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None, None)
    assert isinstance(loader, (AnsibleLoader, Parser, AnsibleConstructor, Resolver))

# Generated at 2022-06-11 09:27:15.389114
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:27:27.441397
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleMapping

    data = '''---
a: 1
b:
 - 1
 - 2
c:
 - name: c1
   val: 3
 - name: c2
   val: 4
'''
    loader = AnsibleLoader(data)
    datamap = loader.get_single_data()

    assert isinstance(datamap, AnsibleMapping)
    assert datamap.get('a') == 1
    assert datamap.get('b') == [1, 2]
    assert datamap.get('c')[0].get('name') == 'c1'
    assert datamap.get('c')[0].get('val') == 3

# Generated at 2022-06-11 09:27:29.855034
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader

if __name__ == '__main__':
    test_AnsibleLoader()

# Generated at 2022-06-11 09:27:35.472159
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert hasattr(AnsibleLoader, '__init__')
    assert hasattr(AnsibleLoader, 'add_constructor')
    assert hasattr(AnsibleLoader, 'add_multi_constructor')
    assert hasattr(AnsibleLoader, 'get_single_data')



# Generated at 2022-06-11 09:27:42.332867
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible import constants as C

    class DummyStream(object):
        def read(self):
            return 'a: !var b'

    DummyStreamObj = DummyStream()
    loader = AnsibleLoader(stream=DummyStreamObj)
    data = loader.get_single_data()
    assert data == {'a': C.DEFAULT_UNDEFINED}

# Generated at 2022-06-11 09:27:45.159457
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
#   module.fail_json(msg="this is a unit test")
    module = AnsibleLoader

# if __name__ == '__main__':
    # test_AnsibleLoader()

# Generated at 2022-06-11 09:27:51.049664
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = '''
- hosts: localhost
  connection: local
  remote_user: root
  tasks:
  - command: whoami
'''

    loader = AnsibleLoader(data, vault_secrets=[])
    loader.get_single_data()

# Generated at 2022-06-11 09:27:55.691533
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    data = """
---
 - hosts:   localhost
   tasks:
    - name: echo {{ foo }}
"""

    loader = AnsibleLoader(data)
    for host in loader:
        for task in host['tasks']:
            if 'foo' in task['name']:
                assert True


# Generated at 2022-06-11 09:28:00.046489
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import os

    loader = AnsibleLoader(io.StringIO(u"{% if True %}T{% else %}F{% endif %}"))
    loader.get_single_data()

# Generated at 2022-06-11 09:28:02.478749
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # TODO: Proper unit test. Don't know how to do that without a Vault
    pass

# Generated at 2022-06-11 09:28:12.427681
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # Set up test data
    yaml_text = """
---
a:
  - 0
  - 1
  - 2
  - 3
  - 4
  - 5
  - 6
  - 7
  - 8
  - 9
"""

    # Parse test data
    loader = AnsibleLoader(yaml_text)
    data = loader.get_single_data()

    # Check results
    assert isinstance(data, dict), "Type of result is not 'dict'"
    assert 'a' in data, "Data has no 'a' key"
    assert data['a'] == list(range(10)), "Values of key 'a' differ from expected"

# Generated at 2022-06-11 09:28:24.868737
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Without libyaml installed
    assert not HAS_LIBYAML
    assert AnsibleLoader.__bases__ == (Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver)

    # With libyaml installed
    def _has_libyaml():
        from ansible.module_utils.common.yaml import HAS_LIBYAML
        return HAS_LIBYAML

    def _AnsibleLoader_bases():
        from ansible.parsing.yaml.loader import AnsibleLoader
        return AnsibleLoader.__bases__

    old_value = HAS_LIBYAML
    HAS_LIBYAML = True
    assert _has_libyaml()
    # Due to the way AnsibleLoader is defined, we need to refresh its value
    # from parsing.yaml.loader

# Generated at 2022-06-11 09:28:36.228251
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    data = """
- hosts: localhost
  vars:
    foo: "{{ '42' | int }}"
- hosts: localhost
  vars:
    bar: "{{ 42 }}"
- hosts: localhost
  vars:
    baz: "{{ '42' | int + 2 }}"
- hosts: localhost
  vars:
    quux: "{{ foo }}"
- hosts: localhost
  vars:
    qux: "{{ baz }}"
- hosts: localhost
  vars:
    norf: "{{ qux }}"
"""
    loader = AnsibleLoader(data)
    for x in loader:
        for k, v in x['vars'].items():
            assert isinstance(v, int)

# Generated at 2022-06-11 09:28:45.837041
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from callback_plugins.defaults import CallbackModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.vars import combine_vars
    from ansible.utils.helpers import combine_hash

# Generated at 2022-06-11 09:28:47.138896
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # ensure the new class was created
    assert AnsibleLoader is not None

# Generated at 2022-06-11 09:28:58.901305
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.safety import ansible_safe_load, safe_load
    from ansible.parsing.yaml.loader import AnsibleLoader

    # ansible_safe_load

# Generated at 2022-06-11 09:29:04.500503
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(b'')
    assert loader is not None

# Generated at 2022-06-11 09:29:11.904697
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import load

    data = """
    foo:
      - bar: [ a, b, c ]
    """

    results = load(data)
    assert isinstance(results['foo'][0], dict)
    assert isinstance(results['foo'][0]['bar'][0], AnsibleUnicode)
    assert isinstance(results['foo'][0]['bar'][1], AnsibleUnicode)
    assert isinstance(results['foo'][0]['bar'][2], AnsibleUnicode)

# Generated at 2022-06-11 09:29:13.511508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    l = AnsibleLoader("{}")

# Generated at 2022-06-11 09:29:14.900637
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader('')

# Generated at 2022-06-11 09:29:17.375272
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # just ensure that the class was created properly
    assert AnsibleLoader

# Generated at 2022-06-11 09:29:24.101790
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.utils.display import Display
    display = Display()

    loader = AnsibleLoader('')
    assert loader.construct_scalar != Resolver.construct_scalar
    assert loader.construct_sequence != Resolver.construct_sequence
    assert loader.construct_mapping != Resolver.construct_mapping
    assert loader.find_yaml_anchor() is None



# Generated at 2022-06-11 09:29:27.378978
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    x = AnsibleLoader({})
    assert x is not None

# Generated at 2022-06-11 09:29:29.451031
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader is not None

# Generated at 2022-06-11 09:29:41.593942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import sys

    from ansible.parsing.mod_args import ModuleArgsParser


# Generated at 2022-06-11 09:29:44.212660
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():    # pylint: disable=too-few-public-methods
    '''
    This is really a class factory and __init__ is not overridden
    '''
    pass

# Generated at 2022-06-11 09:29:53.503824
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)
    assert loader

# Generated at 2022-06-11 09:30:05.649830
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    import sys
    import unittest

    if sys.version_info[0] < 3:
        from ansible.compat.tests import unittest
        from ansible.compat.tests.mock import patch

    # unit test for ansible loader
    data = StringIO('''
    ---
    - A:
        a: 1
        b: 2
    - B:
        c: 3
        d: 4
    - C:
        e: 5
        f: 6
    ''')

    # Test Ansible Loader
    expected_results = [{'A':{'a':1,'b':2}}, {'B':{'c':3,'d':4}}, {'C':{'e':5,'f':6}}]


# Generated at 2022-06-11 09:30:06.280444
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:08.362194
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader
    loader = AnsibleLoader(None)

    assert loader

# Generated at 2022-06-11 09:30:09.981676
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # just instantiate it for now
    x = AnsibleLoader('foo')
    assert(x)

# Generated at 2022-06-11 09:30:17.067241
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    from ansible.parsing.yaml.constructor import AnsibleConstructor

    from test.units.compat.mock import MagicMock

    constructor = AnsibleConstructor.for_yaml_constructor
    loader = AnsibleLoader(stream=MagicMock())
    assert(callable(constructor))

    obj = {'test': 'str'}
    from yaml.nodes import MappingNode, ScalarNode
    mapping_node = MappingNode(None, None, [(ScalarNode(None, None, 'test'), ScalarNode(None, None, 'str'))])
    assert(obj == loader.construct_object(mapping_node))

    # Load a document with a YAML anchor of '&' and alias '*'.
    loader.vault_secrets = []

# Generated at 2022-06-11 09:30:17.648739
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:30:19.164505
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    stream = AnsibleLoader(None)
    assert stream is not None

# Generated at 2022-06-11 09:30:31.484512
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    # no init parameters
    loader = AnsibleLoader(None)
    assert loader.file_name is None
    assert isinstance(loader._root_value_type, AnsibleBaseYAMLObject)
    assert loader.vault_secrets is None

    # only file_name parameter given
    loader = AnsibleLoader(None, file_name='test.yml')
    assert loader.file_name == 'test.yml'
    assert loader.vault_secrets is None

    # only vault_secrets parameter given
    loader = AnsibleLoader(None, vault_secrets='secret')
    assert loader.file_name is None
    assert loader.vault_secrets == 'secret'

    # both file_name and vault_secrets

# Generated at 2022-06-11 09:30:33.766180
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''
    class AnsibleLoader(Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver):
    '''
    pass

# Generated at 2022-06-11 09:30:51.283863
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    print('Testing AnsibleLoader()')

# Generated at 2022-06-11 09:30:59.220762
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import io
    import datetime
    import yaml
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible import constants as C

    class TestAnsibleConstructor(AnsibleConstructor):
        def __init__(self):
            self._yaml_get_implicit_resolvers()['!vault'] = self._construct_yaml_vault

        def _construct_yaml_vault(self, node):
            # decrypt data
            print("data is: %s" % node.value)
            print("type(data) is: %s" % type(node.value))
            return yaml.ScalarNode(tag='tag:yaml.org,2002:str', value=node.value)

    TestLoader = yaml.Loader
    TestLoader.add

# Generated at 2022-06-11 09:31:10.824062
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader, yaml_include
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import StringIO

# Generated at 2022-06-11 09:31:18.442508
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.utils.unicode import _unicode
    from ansible.module_utils import six

    data = {'element1': 'foo', 'element2': 'bar'}
    yaml_str = _unicode("""
        element1: foo
        element2: bar
    """)
    yaml_str = '\n'.join(yaml_str.split())
    if six.PY2:
        loader = AnsibleLoader(None)
        result = loader.construct_yaml_map(loader.construct_pairs(yaml_str))
        assert isinstance(result['element1'], AnsibleUnicode)
        assert isinstance(result['element2'], AnsibleUnicode)
        assert result == data



# Generated at 2022-06-11 09:31:30.872876
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from datetime import datetime

    class MyLoader(AnsibleConstructor):
        @staticmethod
        def construct_object(loader, node):
            return datetime(2017, 1, 1)

    yaml_anonymous_example = '{{ foo }}'  # Anonymous variable should not be expanded
    yaml_legacy_example = '{{foo}}'  # Legacy variable format should be expanded
    yaml_example = '{{ foo.bar }}'  # Standard variable format should be expanded

    loader = AnsibleLoader(yaml_anonymous_example)
    loaded = loader.get_single_data()
    assert '{{ foo }}' == loaded

    loader = AnsibleLoader(yaml_legacy_example)
    loaded = loader.get_single_data()
    assert '{{foo}}' != loaded
    assert 'foo' == loaded

# Generated at 2022-06-11 09:31:38.032048
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import tempfile

    stream = open('test.yml', 'r')
    file_name = "test.yml"
    vault_secrets = "test.yml"

    input_stream = stream
    file_name = file_name
    vault_secrets = vault_secrets
    loader = AnsibleLoader(input_stream)
    loader = AnsibleLoader(input_stream, file_name)
    loader = AnsibleLoader(input_stream, file_name, vault_secrets)

# Generated at 2022-06-11 09:31:47.694515
# Unit test for constructor of class AnsibleLoader

# Generated at 2022-06-11 09:31:49.068129
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.loader import AnsibleLoader
    assert AnsibleLoader
#

# Generated at 2022-06-11 09:31:50.000852
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # Cannot be tested as __init__ base classes are not available
    assert True

# Generated at 2022-06-11 09:31:57.177942
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import os
    import shutil
    import tempfile

    TEST_DATA_DIR = os.path.dirname(__file__) + os.sep + "loader_fixtures" + os.sep

    def test(file_name=None, vault_secrets=None):
        if file_name is None:
            return
        stream = open(file_name, 'r')
        ansible_loader = AnsibleLoader(stream, file_name=file_name, vault_secrets=vault_secrets)
        stream.close()
        return ansible_loader

    test(TEST_DATA_DIR + 'reference.yml')

    # create a temporary directory
    tmp_dir = tempfile.mkdtemp(prefix='ansible_test_loader_')

    # create a temporary directory with a vault_password_file


# Generated at 2022-06-11 09:32:39.415031
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    s = "\n".join([
        "---",
        "# file: test.yaml",
        "# user: root",
        "test: 1",
        "---",
        "# file: test2.yaml",
        "test2: 2",
        "..."
    ])

    # HAS_LIBYAML
    if HAS_LIBYAML:
        q = AnsibleLoader(s, file_name="test.yaml").get_single_data()
        assert q == {'test': 1}

        q = AnsibleLoader(s, file_name="test2.yaml").get_single_data()
        assert q == {'test2': 2}
    # NO_LIBYAML
    else:
        q = AnsibleLoader(s, file_name="test.yaml").get_single_data()

# Generated at 2022-06-11 09:32:41.402062
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.constructor import AnsibleLoader


# Generated at 2022-06-11 09:32:50.391161
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedString

    class TestVaultSecret:
        def decrypt(self, data):
            return data

    string = '''
        ---
        some_variable: !vault |
            $ANSIBLE_VAULT;1.1;AES256
            32343566376538396661623534333164376138363461653933313236653938346565316237383061
            39303339373533616338633031303933636630626239
            64383731386630336466343636663034343533373734393365
        '''
    loader = AnsibleLoader(StringIO(string), vault_secrets=[TestVaultSecret()])

# Generated at 2022-06-11 09:32:50.828936
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    pass

# Generated at 2022-06-11 09:32:51.634058
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    import yaml
    yaml.Loader = AnsibleLoader

# Generated at 2022-06-11 09:33:04.018213
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.yaml import construct_yaml_str

    file_name = 'sample_loader.yml'
    vault_password = 'secret'

# Generated at 2022-06-11 09:33:05.216337
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    assert AnsibleLoader is not None

# Generated at 2022-06-11 09:33:07.714636
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    """ This is a procedural test for class AnsibleLoader. """

    # AnsibleLoader test
    assert AnsibleLoader

# Generated at 2022-06-11 09:33:17.674904
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    AnsibleLoader

if __name__ == "__main__":
    AnsibleLoader
    # class AnsibleLoader(Reader, Scanner, Parser, Composer, AnsibleConstructor, Resolver):
    #     def __init__(self, stream, file_name=None, vault_secrets=None):
    #         Reader.__init__(self, stream)
    #         Scanner.__init__(self)
    #         Parser.__init__(self)
    #         Composer.__init__(self)
    #         AnsibleConstructor.__init__(self, file_name=file_name, vault_secrets=vault_secrets)
    #         Resolver.__init__(self)

# Generated at 2022-06-11 09:33:29.930540
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.parsing.vault import VaultEditor  # pylint: disable=redefined-outer-name
    vault_secrets = [VaultEditor(b'$ANSIBLE_VAULT;1.1;AES256\n34663737356639316439343637616465333438326263383430623963653133313231336662626364\n303933653632396537336162626266636638336135643537376231327a\n', b'hunter2')]
    loader = AnsibleLoader('', vault_secrets=vault_secrets)
    assert loader.vault_secrets == vault_secrets
    assert loader.file_name is None

# Generated at 2022-06-11 09:34:48.053935
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import load
    read_data = u"""
        stage:
            name: "{{ inventory_hostname }}"
            hosts: localhost
            tasks:
            - name: ensure config file is created
            tags:
            - always
            - set_fact:
                key: val"""
    data = load(read_data, loader=AnsibleLoader)
    assert data == {'stage': {'hosts': 'localhost', 'name': '{{ inventory_hostname }}', 'tasks': [{'name': 'ensure config file is created', 'tags': [
        'always', {'key': 'val'}]}]}}
    read_data = u''
    data = load(read_data, loader=AnsibleLoader)
    assert data == None

# Generated at 2022-06-11 09:34:56.581370
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from ansible.module_utils.common.yaml import AnsibleLoader
    from ansible.vars.unsafe_proxy import UnsafeProxy


# Generated at 2022-06-11 09:35:03.901966
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    '''Test the constructor of class AnsibleLoader'''
    if HAS_LIBYAML:
        # pylint: disable=no-member
        assert isinstance(AnsibleLoader([]), Parser)
        assert isinstance(AnsibleLoader([]), AnsibleConstructor)
        assert isinstance(AnsibleLoader([]), Resolver)

    else:
        generator = (x for x in range(10))
        # pylint: disable=no-member
        assert isinstance(AnsibleLoader(generator), Reader)
        assert isinstance(AnsibleLoader(generator), Scanner)
        assert isinstance(AnsibleLoader(generator), Parser)
        assert isinstance(AnsibleLoader(generator), Composer)

# Generated at 2022-06-11 09:35:12.443701
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():

    # AnsibleLoader.__init__(self, stream, file_name=None, vault_secrets=None):

    from StringIO import StringIO
    from ansible.parsing.yaml.objects import AnsibleUnicode

    data = '{"key": "value"}'
    stream = StringIO(data)

    loader = AnsibleLoader(stream=stream)

    assert loader is not None
    assert isinstance(loader, AnsibleLoader)

    assert loader.stream == stream

    # Reader.__init__(self, stream)
    assert isinstance(loader.stream, StringIO)

    # Scanner.__init__(self):
    assert isinstance(loader.line, int)
    assert isinstance(loader.column, int)
    assert loader.line == 0
    assert loader.column == 0

    # Parser.

# Generated at 2022-06-11 09:35:21.311053
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    # test list construct
    data = AnsibleLoader('''
- x:
    b: 1
    c: 2
''').get_single_data()
    assert data == [{u'x': {u'b': 1, u'c': 2}}]

    # test dict
    data = AnsibleLoader('''
x:
   b: 1
   c: 2
''').get_single_data()
    assert data == {u'x': {u'b': 1, u'c': 2}}

    # test dict with string instead of space
    data = AnsibleLoader('''
x:b: 1
c: 2
''').get_single_data()
    assert data == {u'x:b': 1, u'c': 2}

    # test dict with colon but no space
    data = AnsibleLoader

# Generated at 2022-06-11 09:35:23.895358
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    loader = AnsibleLoader(None)

    assert isinstance(loader, AnsibleConstructor)

    assert hasattr(loader, 'construct_yaml_map')
    assert hasattr(loader, 'construct_yaml_seq')

# Generated at 2022-06-11 09:35:28.647167
# Unit test for constructor of class AnsibleLoader
def test_AnsibleLoader():
    from io import StringIO

    config = StringIO("""
      1:
      - one: foo
      - two: bar
      2:
      - three: baz
      - four: bax
    """)

    loader = AnsibleLoader(config)

    # All of these should be equivalent, however the first one is preferred
    assert loader.get_single_data() == loader.get_single_data() == loader.get_data()
